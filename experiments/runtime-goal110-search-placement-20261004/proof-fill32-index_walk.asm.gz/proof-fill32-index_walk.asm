
/home/epentland/ai/canopy/mylang-worktrees/goal110-floor-result-range-20261004/.mylang-cache/goal110-search-placement/fill32/text-my-llvm:     file format elf64-x86-64


Disassembly of section .text:

0000000001090ee0 <index_walk>:
 1090ee0:	push   %rbp
 1090ee1:	mov    %rsp,%rbp
 1090ee4:	push   %r15
 1090ee6:	push   %r14
 1090ee8:	push   %rbx
 1090ee9:	push   %rax
 1090eea:	mov    0x8(%rdi),%rdx
 1090eee:	mov    %rdx,%rax
 1090ef1:	sub    %rsi,%rax
 1090ef4:	jbe    1090f5a <index_walk+0x7a>
 1090ef6:	mov    0x10(%rdi),%r9d
 1090efa:	lea    0x18(%rdi),%r8
 1090efe:	mov    %r8,%rcx
 1090f01:	test   $0x4,%r9b
 1090f05:	je     1090f16 <index_walk+0x36>
 1090f07:	mov    0x18(%rdi),%rcx
 1090f0b:	mov    0x14(%rdi),%r10d
 1090f0f:	add    %r10,%rcx
 1090f12:	add    $0x18,%rcx
 1090f16:	cmp    %rax,%rsi
 1090f19:	mov    %rax,%r10
 1090f1c:	cmovb  %rsi,%r10
 1090f20:	cmp    $0x401,%r10
 1090f27:	jb     1090f47 <index_walk+0x67>
 1090f29:	test   $0x8,%r9b
 1090f2d:	jne    1090f75 <index_walk+0x95>
 1090f2f:	test   $0x4,%r9b
 1090f33:	je     1090f47 <index_walk+0x67>
 1090f35:	mov    (%r8),%rbx
 1090f38:	test   %rbx,%rbx
 1090f3b:	je     1090f47 <index_walk+0x67>
 1090f3d:	testb  $0x8,0x10(%rbx)
 1090f41:	jne    1091517 <index_walk+0x637>
 1090f47:	cmp    %rax,%rsi
 1090f4a:	jbe    1090f62 <index_walk+0x82>
 1090f4c:	lea    0x8(%rsi),%rax
 1090f50:	cmp    %rdx,%rax
 1090f53:	jbe    1090f84 <index_walk+0xa4>
 1090f55:	xor    %r8d,%r8d
 1090f58:	jmp    1090fd6 <index_walk+0xf6>
 1090f5a:	mov    (%rdi),%rax
 1090f5d:	jmp    1091540 <index_walk+0x660>
 1090f62:	cmp    $0x8,%rsi
 1090f66:	jae    1091001 <index_walk+0x121>
 1090f6c:	xor    %eax,%eax
 1090f6e:	xor    %edx,%edx
 1090f70:	jmp    1091229 <index_walk+0x349>
 1090f75:	add    $0x8,%rsp
 1090f79:	pop    %rbx
 1090f7a:	pop    %r14
 1090f7c:	pop    %r15
 1090f7e:	pop    %rbp
 1090f7f:	jmp    1091560 <index_at>
 1090f84:	movabs $0x101010101010101,%rax
 1090f8e:	xor    %r8d,%r8d
 1090f91:	mov    %rsi,%r9
 1090f94:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 1090fa0:	mov    (%rcx,%r9,1),%rsi
 1090fa4:	mov    %rsi,%r10
 1090fa7:	not    %r10
 1090faa:	add    %r10,%r10
 1090fad:	and    %rsi,%r10
 1090fb0:	shr    $0x7,%r10
 1090fb4:	and    %rax,%r10
 1090fb7:	imul   %rax,%r10
 1090fbb:	shr    $0x38,%r10
 1090fbf:	sub    %r10,%r8
 1090fc2:	add    $0x8,%r8
 1090fc6:	lea    0x8(%r9),%rsi
 1090fca:	add    $0x10,%r9
 1090fce:	cmp    %rdx,%r9
 1090fd1:	mov    %rsi,%r9
 1090fd4:	jbe    1090fa0 <index_walk+0xc0>
 1090fd6:	mov    (%rdi),%rax
 1090fd9:	mov    %rdx,%rdi
 1090fdc:	sub    %rsi,%rdi
 1090fdf:	jbe    10913a5 <index_walk+0x4c5>
 1090fe5:	cmp    $0x3,%rdi
 1090fe9:	jbe    1091390 <index_walk+0x4b0>
 1090fef:	cmp    $0x10,%rdi
 1090ff3:	jae    1091251 <index_walk+0x371>
 1090ff9:	xor    %r9d,%r9d
 1090ffc:	jmp    109132f <index_walk+0x44f>
 1091001:	lea    -0x8(%rsi),%r8
 1091005:	cmp    $0x78,%r8
 1091009:	jae    1091019 <index_walk+0x139>
 109100b:	mov    $0x8,%edi
 1091010:	xor    %edx,%edx
 1091012:	xor    %eax,%eax
 1091014:	jmp    10911e1 <index_walk+0x301>
 1091019:	shr    $0x3,%r8
 109101d:	inc    %r8
 1091020:	mov    %r8,%r9
 1091023:	and    $0xfffffffffffffff0,%r9
 1091027:	lea    0x0(,%r9,8),%rdx
 109102f:	lea    0x8(,%r9,8),%rdi
 1091037:	vpxor  %xmm2,%xmm2,%xmm2
 109103b:	xor    %eax,%eax
 109103d:	vpbroadcastq -0x89f06(%rip),%ymm0        # 1007140 <__abi_tag+0x6e44>
 1091046:	vpbroadcastq -0x89f07(%rip),%ymm1        # 1007148 <__abi_tag+0x6e4c>
 109104f:	vpbroadcastq -0x89f88(%rip),%ymm3        # 10070d0 <__abi_tag+0x6dd4>
 1091058:	vpcmpeqd %ymm4,%ymm4,%ymm4
 109105c:	vpxor  %xmm7,%xmm7,%xmm7
 1091060:	vpxor  %xmm6,%xmm6,%xmm6
 1091064:	vpxor  %xmm5,%xmm5,%xmm5
 1091068:	nopl   0x0(%rax,%rax,1)
 1091070:	vmovdqu (%rcx,%rax,8),%ymm8
 1091075:	vmovdqu 0x20(%rcx,%rax,8),%ymm9
 109107b:	vmovdqu 0x40(%rcx,%rax,8),%ymm10
 1091081:	vmovdqu 0x60(%rcx,%rax,8),%ymm11
 1091087:	vpxor  %ymm4,%ymm8,%ymm12
 109108b:	vpaddq %ymm12,%ymm12,%ymm12
 1091090:	vpxor  %ymm4,%ymm9,%ymm13
 1091094:	vpaddq %ymm13,%ymm13,%ymm13
 1091099:	vpxor  %ymm4,%ymm10,%ymm14
 109109d:	vpaddq %ymm14,%ymm14,%ymm14
 10910a2:	vpxor  %ymm4,%ymm11,%ymm15
 10910a6:	vpaddq %ymm15,%ymm15,%ymm15
 10910ab:	vpand  %ymm12,%ymm8,%ymm8
 10910b0:	vpand  %ymm13,%ymm9,%ymm9
 10910b5:	vpand  %ymm14,%ymm10,%ymm10
 10910ba:	vpand  %ymm15,%ymm11,%ymm11
 10910bf:	vpsrlq $0x7,%ymm8,%ymm8
 10910c5:	vpsrlq $0x7,%ymm9,%ymm9
 10910cb:	vpsrlq $0x7,%ymm10,%ymm10
 10910d1:	vpsrlq $0x7,%ymm11,%ymm11
 10910d7:	vpand  %ymm0,%ymm8,%ymm8
 10910db:	vpand  %ymm0,%ymm9,%ymm9
 10910df:	vpand  %ymm0,%ymm10,%ymm10
 10910e3:	vpand  %ymm0,%ymm11,%ymm11
 10910e7:	vpmuludq %ymm1,%ymm8,%ymm12
 10910eb:	vpsrlq $0x20,%ymm8,%ymm13
 10910f1:	vpmuludq %ymm0,%ymm13,%ymm13
 10910f5:	vpaddq %ymm13,%ymm12,%ymm12
 10910fa:	vpsllq $0x20,%ymm12,%ymm12
 1091100:	vpmuludq %ymm0,%ymm8,%ymm8
 1091104:	vpaddq %ymm12,%ymm8,%ymm8
 1091109:	vpmuludq %ymm1,%ymm9,%ymm12
 109110d:	vpsrlq $0x20,%ymm9,%ymm13
 1091113:	vpmuludq %ymm0,%ymm13,%ymm13
 1091117:	vpaddq %ymm13,%ymm12,%ymm12
 109111c:	vpsllq $0x20,%ymm12,%ymm12
 1091122:	vpmuludq %ymm0,%ymm9,%ymm9
 1091126:	vpaddq %ymm12,%ymm9,%ymm9
 109112b:	vpmuludq %ymm1,%ymm10,%ymm12
 109112f:	vpsrlq $0x20,%ymm10,%ymm13
 1091135:	vpmuludq %ymm0,%ymm13,%ymm13
 1091139:	vpaddq %ymm13,%ymm12,%ymm12
 109113e:	vpsllq $0x20,%ymm12,%ymm12
 1091144:	vpmuludq %ymm0,%ymm10,%ymm10
 1091148:	vpaddq %ymm12,%ymm10,%ymm10
 109114d:	vpmuludq %ymm1,%ymm11,%ymm12
 1091151:	vpsrlq $0x20,%ymm11,%ymm13
 1091157:	vpmuludq %ymm0,%ymm13,%ymm13
 109115b:	vpaddq %ymm13,%ymm12,%ymm12
 1091160:	vpsllq $0x20,%ymm12,%ymm12
 1091166:	vpmuludq %ymm0,%ymm11,%ymm11
 109116a:	vpaddq %ymm12,%ymm11,%ymm11
 109116f:	vpsrlq $0x38,%ymm8,%ymm8
 1091175:	vpsubq %ymm8,%ymm2,%ymm2
 109117a:	vpsrlq $0x38,%ymm9,%ymm8
 1091180:	vpsubq %ymm8,%ymm7,%ymm7
 1091185:	vpsrlq $0x38,%ymm10,%ymm8
 109118b:	vpsubq %ymm8,%ymm6,%ymm6
 1091190:	vpsrlq $0x38,%ymm11,%ymm8
 1091196:	vpsubq %ymm8,%ymm5,%ymm5
 109119b:	vpaddq %ymm3,%ymm2,%ymm2
 109119f:	vpaddq %ymm3,%ymm7,%ymm7
 10911a3:	vpaddq %ymm3,%ymm6,%ymm6
 10911a7:	vpaddq %ymm3,%ymm5,%ymm5
 10911ab:	add    $0x10,%rax
 10911af:	cmp    %rax,%r9
 10911b2:	jne    1091070 <index_walk+0x190>
 10911b8:	vpaddq %ymm2,%ymm7,%ymm0
 10911bc:	vpaddq %ymm0,%ymm6,%ymm0
 10911c0:	vpaddq %ymm0,%ymm5,%ymm0
 10911c4:	vextracti128 $0x1,%ymm0,%xmm1
 10911ca:	vpaddq %xmm1,%xmm0,%xmm0
 10911ce:	vpshufd $0xee,%xmm0,%xmm1
 10911d3:	vpaddq %xmm1,%xmm0,%xmm0
 10911d7:	vmovq  %xmm0,%rax
 10911dc:	cmp    %r9,%r8
 10911df:	je     1091229 <index_walk+0x349>
 10911e1:	movabs $0x101010101010101,%r8
 10911eb:	nopl   0x0(%rax,%rax,1)
 10911f0:	mov    (%rcx,%rdx,1),%r9
 10911f4:	mov    %rdi,%rdx
 10911f7:	mov    %r9,%rdi
 10911fa:	not    %rdi
 10911fd:	add    %rdi,%rdi
 1091200:	and    %r9,%rdi
 1091203:	shr    $0x7,%rdi
 1091207:	and    %r8,%rdi
 109120a:	imul   %r8,%rdi
 109120e:	shr    $0x38,%rdi
 1091212:	sub    %rdi,%rax
 1091215:	add    $0x8,%rax
 1091219:	lea    0x8(%rdx),%rdi
 109121d:	cmp    %rsi,%rdi
 1091220:	jbe    10911f0 <index_walk+0x310>
 1091222:	add    $0xfffffffffffffff8,%rdi
 1091226:	mov    %rdi,%rdx
 1091229:	mov    %rsi,%rdi
 109122c:	sub    %rdx,%rdi
 109122f:	jbe    1091540 <index_walk+0x660>
 1091235:	cmp    $0x3,%rdi
 1091239:	jbe    1091500 <index_walk+0x620>
 109123f:	cmp    $0x10,%rdi
 1091243:	jae    10913ad <index_walk+0x4cd>
 1091249:	xor    %r8d,%r8d
 109124c:	jmp    109148f <index_walk+0x5af>
 1091251:	mov    %rdi,%r9
 1091254:	and    $0xfffffffffffffff0,%r9
 1091258:	vmovq  %r8,%xmm0
 109125d:	lea    (%rsi,%rcx,1),%r8
 1091261:	add    $0xc,%r8
 1091265:	vpxor  %xmm1,%xmm1,%xmm1
 1091269:	xor    %r10d,%r10d
 109126c:	vmovdqa -0x8f844(%rip),%xmm2        # 1001a30 <__abi_tag+0x1734>
 1091274:	vpbroadcastq -0x8a165(%rip),%ymm3        # 1007118 <__abi_tag+0x6e1c>
 109127d:	vpxor  %xmm4,%xmm4,%xmm4
 1091281:	vpxor  %xmm5,%xmm5,%xmm5
 1091285:	data16 cs nopw 0x0(%rax,%rax,1)
 1091290:	vmovd  -0xc(%r8,%r10,1),%xmm6
 1091297:	vmovd  -0x8(%r8,%r10,1),%xmm7
 109129e:	vmovd  -0x4(%r8,%r10,1),%xmm8
 10912a5:	vmovd  (%r8,%r10,1),%xmm9
 10912ab:	vpcmpgtb %xmm2,%xmm6,%xmm6
 10912af:	vpmovzxbq %xmm6,%ymm6
 10912b4:	vpand  %ymm3,%ymm6,%ymm6
 10912b8:	vpaddq %ymm6,%ymm0,%ymm0
 10912bc:	vpcmpgtb %xmm2,%xmm7,%xmm6
 10912c0:	vpmovzxbq %xmm6,%ymm6
 10912c5:	vpand  %ymm3,%ymm6,%ymm6
 10912c9:	vpaddq %ymm6,%ymm1,%ymm1
 10912cd:	vpcmpgtb %xmm2,%xmm8,%xmm6
 10912d1:	vpmovzxbq %xmm6,%ymm6
 10912d6:	vpand  %ymm3,%ymm6,%ymm6
 10912da:	vpaddq %ymm6,%ymm4,%ymm4
 10912de:	vpcmpgtb %xmm2,%xmm9,%xmm6
 10912e2:	vpmovzxbq %xmm6,%ymm6
 10912e7:	vpand  %ymm3,%ymm6,%ymm6
 10912eb:	vpaddq %ymm6,%ymm5,%ymm5
 10912ef:	add    $0x10,%r10
 10912f3:	cmp    %r10,%r9
 10912f6:	jne    1091290 <index_walk+0x3b0>
 10912f8:	vpaddq %ymm0,%ymm1,%ymm0
 10912fc:	vpaddq %ymm0,%ymm4,%ymm0
 1091300:	vpaddq %ymm0,%ymm5,%ymm0
 1091304:	vextracti128 $0x1,%ymm0,%xmm1
 109130a:	vpaddq %xmm1,%xmm0,%xmm0
 109130e:	vpshufd $0xee,%xmm0,%xmm1
 1091313:	vpaddq %xmm1,%xmm0,%xmm0
 1091317:	vmovq  %xmm0,%r8
 109131c:	cmp    %r9,%rdi
 109131f:	je     10913a5 <index_walk+0x4c5>
 1091325:	test   $0xc,%dil
 1091329:	je     109154e <index_walk+0x66e>
 109132f:	mov    %rdi,%r10
 1091332:	and    $0xfffffffffffffffc,%r10
 1091336:	vmovq  %r8,%xmm0
 109133b:	lea    (%rcx,%rsi,1),%r8
 109133f:	vmovdqa -0x8f917(%rip),%xmm1        # 1001a30 <__abi_tag+0x1734>
 1091347:	vpbroadcastq -0x8a238(%rip),%ymm2        # 1007118 <__abi_tag+0x6e1c>
 1091350:	vmovd  (%r8,%r9,1),%xmm3
 1091356:	vpcmpgtb %xmm1,%xmm3,%xmm3
 109135a:	vpmovzxbq %xmm3,%ymm3
 109135f:	vpand  %ymm2,%ymm3,%ymm3
 1091363:	vpaddq %ymm3,%ymm0,%ymm0
 1091367:	add    $0x4,%r9
 109136b:	cmp    %r9,%r10
 109136e:	jne    1091350 <index_walk+0x470>
 1091370:	vextracti128 $0x1,%ymm0,%xmm1
 1091376:	vpaddq %xmm1,%xmm0,%xmm0
 109137a:	vpshufd $0xee,%xmm0,%xmm1
 109137f:	vpaddq %xmm1,%xmm0,%xmm0
 1091383:	vmovq  %xmm0,%r8
 1091388:	cmp    %r10,%rdi
 109138b:	je     10913a5 <index_walk+0x4c5>
 109138d:	add    %r10,%rsi
 1091390:	xor    %edi,%edi
 1091392:	cmpb   $0xc0,(%rcx,%rsi,1)
 1091396:	setge  %dil
 109139a:	add    %rdi,%r8
 109139d:	inc    %rsi
 10913a0:	cmp    %rsi,%rdx
 10913a3:	jne    1091390 <index_walk+0x4b0>
 10913a5:	sub    %r8,%rax
 10913a8:	jmp    1091540 <index_walk+0x660>
 10913ad:	mov    %rdi,%r8
 10913b0:	and    $0xfffffffffffffff0,%r8
 10913b4:	vmovq  %rax,%xmm0
 10913b9:	lea    (%rdx,%rcx,1),%rax
 10913bd:	add    $0xc,%rax
 10913c1:	vpxor  %xmm1,%xmm1,%xmm1
 10913c5:	xor    %r9d,%r9d
 10913c8:	vmovdqa -0x8f9a0(%rip),%xmm2        # 1001a30 <__abi_tag+0x1734>
 10913d0:	vpbroadcastq -0x8a2c1(%rip),%ymm3        # 1007118 <__abi_tag+0x6e1c>
 10913d9:	vpxor  %xmm4,%xmm4,%xmm4
 10913dd:	vpxor  %xmm5,%xmm5,%xmm5
 10913e1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 10913f0:	vmovd  -0xc(%rax,%r9,1),%xmm6
 10913f7:	vmovd  -0x8(%rax,%r9,1),%xmm7
 10913fe:	vmovd  -0x4(%rax,%r9,1),%xmm8
 1091405:	vmovd  (%rax,%r9,1),%xmm9
 109140b:	vpcmpgtb %xmm2,%xmm6,%xmm6
 109140f:	vpmovzxbq %xmm6,%ymm6
 1091414:	vpand  %ymm3,%ymm6,%ymm6
 1091418:	vpaddq %ymm6,%ymm0,%ymm0
 109141c:	vpcmpgtb %xmm2,%xmm7,%xmm6
 1091420:	vpmovzxbq %xmm6,%ymm6
 1091425:	vpand  %ymm3,%ymm6,%ymm6
 1091429:	vpaddq %ymm6,%ymm1,%ymm1
 109142d:	vpcmpgtb %xmm2,%xmm8,%xmm6
 1091431:	vpmovzxbq %xmm6,%ymm6
 1091436:	vpand  %ymm3,%ymm6,%ymm6
 109143a:	vpaddq %ymm6,%ymm4,%ymm4
 109143e:	vpcmpgtb %xmm2,%xmm9,%xmm6
 1091442:	vpmovzxbq %xmm6,%ymm6
 1091447:	vpand  %ymm3,%ymm6,%ymm6
 109144b:	vpaddq %ymm6,%ymm5,%ymm5
 109144f:	add    $0x10,%r9
 1091453:	cmp    %r9,%r8
 1091456:	jne    10913f0 <index_walk+0x510>
 1091458:	vpaddq %ymm0,%ymm1,%ymm0
 109145c:	vpaddq %ymm0,%ymm4,%ymm0
 1091460:	vpaddq %ymm0,%ymm5,%ymm0
 1091464:	vextracti128 $0x1,%ymm0,%xmm1
 109146a:	vpaddq %xmm1,%xmm0,%xmm0
 109146e:	vpshufd $0xee,%xmm0,%xmm1
 1091473:	vpaddq %xmm1,%xmm0,%xmm0
 1091477:	vmovq  %xmm0,%rax
 109147c:	cmp    %r8,%rdi
 109147f:	je     1091540 <index_walk+0x660>
 1091485:	test   $0xc,%dil
 1091489:	je     1091556 <index_walk+0x676>
 109148f:	mov    %esi,%r9d
 1091492:	and    $0x3,%r9d
 1091496:	sub    %r9,%rdi
 1091499:	vmovq  %rax,%xmm0
 109149e:	mov    %rsi,%rax
 10914a1:	and    $0xfffffffffffffffc,%rax
 10914a5:	add    %rdx,%r8
 10914a8:	vmovdqa -0x8fa80(%rip),%xmm1        # 1001a30 <__abi_tag+0x1734>
 10914b0:	vpbroadcastq -0x8a3a1(%rip),%ymm2        # 1007118 <__abi_tag+0x6e1c>
 10914b9:	nopl   0x0(%rax)
 10914c0:	vmovd  (%rcx,%r8,1),%xmm3
 10914c6:	vpcmpgtb %xmm1,%xmm3,%xmm3
 10914ca:	vpmovzxbq %xmm3,%ymm3
 10914cf:	vpand  %ymm2,%ymm3,%ymm3
 10914d3:	vpaddq %ymm3,%ymm0,%ymm0
 10914d7:	add    $0x4,%r8
 10914db:	cmp    %r8,%rax
 10914de:	jne    10914c0 <index_walk+0x5e0>
 10914e0:	vextracti128 $0x1,%ymm0,%xmm1
 10914e6:	vpaddq %xmm1,%xmm0,%xmm0
 10914ea:	vpshufd $0xee,%xmm0,%xmm1
 10914ef:	vpaddq %xmm1,%xmm0,%xmm0
 10914f3:	vmovq  %xmm0,%rax
 10914f8:	test   %r9,%r9
 10914fb:	je     1091540 <index_walk+0x660>
 10914fd:	add    %rdi,%rdx
 1091500:	xor    %edi,%edi
 1091502:	cmpb   $0xc0,(%rcx,%rdx,1)
 1091506:	setge  %dil
 109150a:	add    %rdi,%rax
 109150d:	inc    %rdx
 1091510:	cmp    %rdx,%rsi
 1091513:	jne    1091500 <index_walk+0x620>
 1091515:	jmp    1091540 <index_walk+0x660>
 1091517:	mov    0x14(%rdi),%eax
 109151a:	add    %rax,%rsi
 109151d:	mov    %rdi,%r15
 1091520:	mov    %rbx,%rdi
 1091523:	call   1091560 <index_at>
 1091528:	mov    %rax,%r14
 109152b:	mov    0x14(%r15),%esi
 109152f:	mov    %rbx,%rdi
 1091532:	call   1091560 <index_at>
 1091537:	mov    %rax,%rcx
 109153a:	mov    %r14,%rax
 109153d:	sub    %rcx,%rax
 1091540:	add    $0x8,%rsp
 1091544:	pop    %rbx
 1091545:	pop    %r14
 1091547:	pop    %r15
 1091549:	pop    %rbp
 109154a:	vzeroupper
 109154d:	ret
 109154e:	add    %r9,%rsi
 1091551:	jmp    1091390 <index_walk+0x4b0>
 1091556:	add    %r8,%rdx
 1091559:	jmp    1091500 <index_walk+0x620>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
