
/home/epentland/ai/canopy/mylang-worktrees/goal110-floor-result-range-20261004/.mylang-cache/goal110-search-placement/fill32/text-my-llvm:     file format elf64-x86-64


Disassembly of section .text:

0000000001093440 <equal_large_octets>:
 1093440:	mov    (%rdi),%rcx
 1093443:	xor    %eax,%eax
 1093445:	cmp    (%rsi),%rcx
 1093448:	jne    1093475 <equal_large_octets+0x35>
 109344a:	mov    -0x8(%rsi,%rdx,1),%rcx
 109344f:	cmp    %rcx,-0x8(%rdi,%rdx,1)
 1093454:	jne    1093475 <equal_large_octets+0x35>
 1093456:	push   %rbp
 1093457:	mov    %rsp,%rbp
 109345a:	add    $0x8,%rdi
 109345e:	add    $0x8,%rsi
 1093462:	add    $0xfffffffffffffff0,%rdx
 1093466:	call   10ad2e0 <bcmp@plt>
 109346b:	mov    %eax,%ecx
 109346d:	xor    %eax,%eax
 109346f:	test   %ecx,%ecx
 1093471:	sete   %al
 1093474:	pop    %rbp
 1093475:	ret

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
