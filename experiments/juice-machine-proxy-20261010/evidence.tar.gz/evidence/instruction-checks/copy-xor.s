# LLVM-EXEGESIS-DEFREG RAX 123456789abcdef
# LLVM-EXEGESIS-DEFREG R12 fedcba987654321
movq %rax, %rcx
xorq %r12, %rcx
movq %rcx, %rax
