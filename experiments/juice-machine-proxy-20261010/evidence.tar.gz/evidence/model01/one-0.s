.intel_syntax noprefix
.Ltarget:
mov    rcx,r13
shl    rcx,0x34
mov    rdx,r13
shl    rdx,0xd
xor    rdx,rcx
xor    rdx,r13
mov    rcx,rdx
shl    rcx,0x1a
xor    rcx,rdx
mov    r13,rcx
shl    r13,0xd
xor    r13,rcx
add    r12,-8
jne .Ltarget
