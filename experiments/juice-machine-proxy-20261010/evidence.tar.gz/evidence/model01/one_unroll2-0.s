.intel_syntax noprefix
.Ltarget:
mov    rcx,r13
shl    rcx,0x34
mov    rdx,r13
shl    rdx,0x1a
xor    rdx,rcx
xor    rdx,r13
mov    r13,rdx
shl    r13,0x1a
xor    r13,rdx
add    r12,-8
jne .Ltarget
