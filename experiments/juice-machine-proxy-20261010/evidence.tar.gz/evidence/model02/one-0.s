.intel_syntax noprefix
.Ltarget:
# LLVM-MCA-LATENCY 0
mov    rcx,r13
# LLVM-MCA-LATENCY
shl    rcx,0x34
# LLVM-MCA-LATENCY 0
mov    rdx,r13
# LLVM-MCA-LATENCY
shl    rdx,0xd
# LLVM-MCA-LATENCY 1
xor    rdx,rcx
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 1
xor    rdx,r13
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rcx,rdx
# LLVM-MCA-LATENCY
shl    rcx,0x1a
# LLVM-MCA-LATENCY 1
xor    rcx,rdx
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    r13,rcx
# LLVM-MCA-LATENCY
shl    r13,0xd
# LLVM-MCA-LATENCY 1
xor    r13,rcx
# LLVM-MCA-LATENCY
add    r12,-8
jne .Ltarget
