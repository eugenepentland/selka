.intel_syntax noprefix
.Ltarget:
# LLVM-MCA-LATENCY 0
mov    rdx,rax
# LLVM-MCA-LATENCY
shl    rdx,0xd
# LLVM-MCA-LATENCY 1
xor    rdx,rax
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rax,rdx
# LLVM-MCA-LATENCY
sar    rax,0x7
# LLVM-MCA-LATENCY 1
xor    rax,rdx
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rdx,rax
# LLVM-MCA-LATENCY
shl    rdx,0x11
# LLVM-MCA-LATENCY 1
xor    rdx,rax
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rax,rdx
# LLVM-MCA-LATENCY
shl    rax,0xd
# LLVM-MCA-LATENCY 1
xor    rax,rdx
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rdx,rax
# LLVM-MCA-LATENCY
sar    rdx,0x7
# LLVM-MCA-LATENCY 1
xor    rdx,rax
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rax,rdx
# LLVM-MCA-LATENCY
shl    rax,0x11
# LLVM-MCA-LATENCY 1
xor    rax,rdx
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rdx,rax
# LLVM-MCA-LATENCY
shl    rdx,0xd
# LLVM-MCA-LATENCY 1
xor    rdx,rax
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rax,rdx
# LLVM-MCA-LATENCY
sar    rax,0x7
# LLVM-MCA-LATENCY 1
xor    rax,rdx
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rdx,rax
# LLVM-MCA-LATENCY
shl    rdx,0x11
# LLVM-MCA-LATENCY 1
xor    rdx,rax
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rax,rdx
# LLVM-MCA-LATENCY
shl    rax,0xd
# LLVM-MCA-LATENCY 1
xor    rax,rdx
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rdx,rax
# LLVM-MCA-LATENCY
sar    rdx,0x7
# LLVM-MCA-LATENCY 1
xor    rdx,rax
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rax,rdx
# LLVM-MCA-LATENCY
shl    rax,0x11
# LLVM-MCA-LATENCY 1
xor    rax,rdx
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rdx,rax
# LLVM-MCA-LATENCY
shl    rdx,0xd
# LLVM-MCA-LATENCY 1
xor    rdx,rax
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rax,rdx
# LLVM-MCA-LATENCY
sar    rax,0x7
# LLVM-MCA-LATENCY 1
xor    rax,rdx
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rdx,rax
# LLVM-MCA-LATENCY
shl    rdx,0x11
# LLVM-MCA-LATENCY 1
xor    rdx,rax
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rax,rdx
# LLVM-MCA-LATENCY
shl    rax,0xd
# LLVM-MCA-LATENCY 1
xor    rax,rdx
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rdx,rax
# LLVM-MCA-LATENCY
sar    rdx,0x7
# LLVM-MCA-LATENCY 1
xor    rdx,rax
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rax,rdx
# LLVM-MCA-LATENCY
shl    rax,0x11
# LLVM-MCA-LATENCY 1
xor    rax,rdx
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rdx,rax
# LLVM-MCA-LATENCY
shl    rdx,0xd
# LLVM-MCA-LATENCY 1
xor    rdx,rax
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rax,rdx
# LLVM-MCA-LATENCY
sar    rax,0x7
# LLVM-MCA-LATENCY 1
xor    rax,rdx
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rdx,rax
# LLVM-MCA-LATENCY
shl    rdx,0x11
# LLVM-MCA-LATENCY 1
xor    rdx,rax
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rax,rdx
# LLVM-MCA-LATENCY
shl    rax,0xd
# LLVM-MCA-LATENCY 1
xor    rax,rdx
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rdx,rax
# LLVM-MCA-LATENCY
sar    rdx,0x7
# LLVM-MCA-LATENCY 1
xor    rdx,rax
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rax,rdx
# LLVM-MCA-LATENCY
shl    rax,0x11
# LLVM-MCA-LATENCY 1
xor    rax,rdx
# LLVM-MCA-LATENCY
add    rcx,-2
jne .Ltarget
