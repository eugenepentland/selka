.intel_syntax noprefix
.Ltarget:
mov    ecx,0x20
nop
nop
nop
nop
# LLVM-MCA-LATENCY 0
mov    rdx,r13
# LLVM-MCA-LATENCY
shl    rdx,0xd
# LLVM-MCA-LATENCY 1
xor    rdx,r13
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rsi,rdx
# LLVM-MCA-LATENCY
sar    rsi,0x7
# LLVM-MCA-LATENCY 1
xor    rsi,rdx
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rdx,rsi
# LLVM-MCA-LATENCY
shl    rdx,0x11
# LLVM-MCA-LATENCY 1
xor    rdx,rsi
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rsi,rdx
# LLVM-MCA-LATENCY
shl    rsi,0xd
# LLVM-MCA-LATENCY 1
xor    rsi,rdx
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rdx,rsi
# LLVM-MCA-LATENCY
sar    rdx,0x7
# LLVM-MCA-LATENCY 1
xor    rdx,rsi
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rsi,rdx
# LLVM-MCA-LATENCY
shl    rsi,0x11
# LLVM-MCA-LATENCY 1
xor    rsi,rdx
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rdx,rsi
# LLVM-MCA-LATENCY
shl    rdx,0xd
# LLVM-MCA-LATENCY 1
xor    rdx,rsi
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rsi,rdx
# LLVM-MCA-LATENCY
sar    rsi,0x7
# LLVM-MCA-LATENCY 1
xor    rsi,rdx
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rdx,rsi
# LLVM-MCA-LATENCY
shl    rdx,0x11
# LLVM-MCA-LATENCY 1
xor    rdx,rsi
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rsi,rdx
# LLVM-MCA-LATENCY
shl    rsi,0xd
# LLVM-MCA-LATENCY 1
xor    rsi,rdx
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rdx,rsi
# LLVM-MCA-LATENCY
sar    rdx,0x7
# LLVM-MCA-LATENCY 1
xor    rdx,rsi
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rsi,rdx
# LLVM-MCA-LATENCY
shl    rsi,0x11
# LLVM-MCA-LATENCY 1
xor    rsi,rdx
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rdx,rsi
# LLVM-MCA-LATENCY
shl    rdx,0xd
# LLVM-MCA-LATENCY 1
xor    rdx,rsi
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rsi,rdx
# LLVM-MCA-LATENCY
sar    rsi,0x7
# LLVM-MCA-LATENCY 1
xor    rsi,rdx
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rdx,rsi
# LLVM-MCA-LATENCY
shl    rdx,0x11
# LLVM-MCA-LATENCY 1
xor    rdx,rsi
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rsi,rdx
# LLVM-MCA-LATENCY
shl    rsi,0xd
# LLVM-MCA-LATENCY 1
xor    rsi,rdx
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rdx,rsi
# LLVM-MCA-LATENCY
sar    rdx,0x7
# LLVM-MCA-LATENCY 1
xor    rdx,rsi
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rsi,rdx
# LLVM-MCA-LATENCY
shl    rsi,0x11
# LLVM-MCA-LATENCY 1
xor    rsi,rdx
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rdx,rsi
# LLVM-MCA-LATENCY
shl    rdx,0xd
# LLVM-MCA-LATENCY 1
xor    rdx,rsi
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rsi,rdx
# LLVM-MCA-LATENCY
sar    rsi,0x7
# LLVM-MCA-LATENCY 1
xor    rsi,rdx
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rdx,rsi
# LLVM-MCA-LATENCY
shl    rdx,0x11
# LLVM-MCA-LATENCY 1
xor    rdx,rsi
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rsi,rdx
# LLVM-MCA-LATENCY
shl    rsi,0xd
# LLVM-MCA-LATENCY 1
xor    rsi,rdx
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rdx,rsi
# LLVM-MCA-LATENCY
sar    rdx,0x7
# LLVM-MCA-LATENCY 1
xor    rdx,rsi
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    r13,rdx
# LLVM-MCA-LATENCY
shl    r13,0x11
# LLVM-MCA-LATENCY 1
xor    r13,rdx
# LLVM-MCA-LATENCY
add    rcx,-8
jne .Ltarget
# LLVM-MCA-LATENCY 0
mov    rdx,r13
# LLVM-MCA-LATENCY
shl    rdx,0xd
# LLVM-MCA-LATENCY 1
xor    rdx,r13
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rsi,rdx
# LLVM-MCA-LATENCY
sar    rsi,0x7
# LLVM-MCA-LATENCY 1
xor    rsi,rdx
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rdx,rsi
# LLVM-MCA-LATENCY
shl    rdx,0x11
# LLVM-MCA-LATENCY 1
xor    rdx,rsi
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rsi,rdx
# LLVM-MCA-LATENCY
shl    rsi,0xd
# LLVM-MCA-LATENCY 1
xor    rsi,rdx
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rdx,rsi
# LLVM-MCA-LATENCY
sar    rdx,0x7
# LLVM-MCA-LATENCY 1
xor    rdx,rsi
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rsi,rdx
# LLVM-MCA-LATENCY
shl    rsi,0x11
# LLVM-MCA-LATENCY 1
xor    rsi,rdx
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rdx,rsi
# LLVM-MCA-LATENCY
shl    rdx,0xd
# LLVM-MCA-LATENCY 1
xor    rdx,rsi
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rsi,rdx
# LLVM-MCA-LATENCY
sar    rsi,0x7
# LLVM-MCA-LATENCY 1
xor    rsi,rdx
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rdx,rsi
# LLVM-MCA-LATENCY
shl    rdx,0x11
# LLVM-MCA-LATENCY 1
xor    rdx,rsi
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rsi,rdx
# LLVM-MCA-LATENCY
shl    rsi,0xd
# LLVM-MCA-LATENCY 1
xor    rsi,rdx
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rdx,rsi
# LLVM-MCA-LATENCY
sar    rdx,0x7
# LLVM-MCA-LATENCY 1
xor    rdx,rsi
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rsi,rdx
# LLVM-MCA-LATENCY
shl    rsi,0x11
# LLVM-MCA-LATENCY 1
xor    rsi,rdx
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rdx,rsi
# LLVM-MCA-LATENCY
shl    rdx,0xd
# LLVM-MCA-LATENCY 1
xor    rdx,rsi
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rsi,rdx
# LLVM-MCA-LATENCY
sar    rsi,0x7
# LLVM-MCA-LATENCY 1
xor    rsi,rdx
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rdx,rsi
# LLVM-MCA-LATENCY
shl    rdx,0x11
# LLVM-MCA-LATENCY 1
xor    rdx,rsi
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rsi,rdx
# LLVM-MCA-LATENCY
shl    rsi,0xd
# LLVM-MCA-LATENCY 1
xor    rsi,rdx
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rdx,rsi
# LLVM-MCA-LATENCY
sar    rdx,0x7
# LLVM-MCA-LATENCY 1
xor    rdx,rsi
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rsi,rdx
# LLVM-MCA-LATENCY
shl    rsi,0x11
# LLVM-MCA-LATENCY 1
xor    rsi,rdx
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rdx,rsi
# LLVM-MCA-LATENCY
shl    rdx,0xd
# LLVM-MCA-LATENCY 1
xor    rdx,rsi
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rsi,rdx
# LLVM-MCA-LATENCY
sar    rsi,0x7
# LLVM-MCA-LATENCY 1
xor    rsi,rdx
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rdx,rsi
# LLVM-MCA-LATENCY
shl    rdx,0x11
# LLVM-MCA-LATENCY 1
xor    rdx,rsi
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rsi,rdx
# LLVM-MCA-LATENCY
shl    rsi,0xd
# LLVM-MCA-LATENCY 1
xor    rsi,rdx
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rdx,rsi
# LLVM-MCA-LATENCY
sar    rdx,0x7
# LLVM-MCA-LATENCY 1
xor    rdx,rsi
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    r13,rdx
# LLVM-MCA-LATENCY
shl    r13,0x11
# LLVM-MCA-LATENCY 1
xor    r13,rdx
# LLVM-MCA-LATENCY
add    rcx,-8
jne .Ltarget
# LLVM-MCA-LATENCY 0
mov    rdx,r13
# LLVM-MCA-LATENCY
shl    rdx,0xd
# LLVM-MCA-LATENCY 1
xor    rdx,r13
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rsi,rdx
# LLVM-MCA-LATENCY
sar    rsi,0x7
# LLVM-MCA-LATENCY 1
xor    rsi,rdx
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rdx,rsi
# LLVM-MCA-LATENCY
shl    rdx,0x11
# LLVM-MCA-LATENCY 1
xor    rdx,rsi
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rsi,rdx
# LLVM-MCA-LATENCY
shl    rsi,0xd
# LLVM-MCA-LATENCY 1
xor    rsi,rdx
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rdx,rsi
# LLVM-MCA-LATENCY
sar    rdx,0x7
# LLVM-MCA-LATENCY 1
xor    rdx,rsi
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rsi,rdx
# LLVM-MCA-LATENCY
shl    rsi,0x11
# LLVM-MCA-LATENCY 1
xor    rsi,rdx
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rdx,rsi
# LLVM-MCA-LATENCY
shl    rdx,0xd
# LLVM-MCA-LATENCY 1
xor    rdx,rsi
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rsi,rdx
# LLVM-MCA-LATENCY
sar    rsi,0x7
# LLVM-MCA-LATENCY 1
xor    rsi,rdx
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rdx,rsi
# LLVM-MCA-LATENCY
shl    rdx,0x11
# LLVM-MCA-LATENCY 1
xor    rdx,rsi
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rsi,rdx
# LLVM-MCA-LATENCY
shl    rsi,0xd
# LLVM-MCA-LATENCY 1
xor    rsi,rdx
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rdx,rsi
# LLVM-MCA-LATENCY
sar    rdx,0x7
# LLVM-MCA-LATENCY 1
xor    rdx,rsi
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rsi,rdx
# LLVM-MCA-LATENCY
shl    rsi,0x11
# LLVM-MCA-LATENCY 1
xor    rsi,rdx
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rdx,rsi
# LLVM-MCA-LATENCY
shl    rdx,0xd
# LLVM-MCA-LATENCY 1
xor    rdx,rsi
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rsi,rdx
# LLVM-MCA-LATENCY
sar    rsi,0x7
# LLVM-MCA-LATENCY 1
xor    rsi,rdx
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rdx,rsi
# LLVM-MCA-LATENCY
shl    rdx,0x11
# LLVM-MCA-LATENCY 1
xor    rdx,rsi
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rsi,rdx
# LLVM-MCA-LATENCY
shl    rsi,0xd
# LLVM-MCA-LATENCY 1
xor    rsi,rdx
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rdx,rsi
# LLVM-MCA-LATENCY
sar    rdx,0x7
# LLVM-MCA-LATENCY 1
xor    rdx,rsi
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rsi,rdx
# LLVM-MCA-LATENCY
shl    rsi,0x11
# LLVM-MCA-LATENCY 1
xor    rsi,rdx
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rdx,rsi
# LLVM-MCA-LATENCY
shl    rdx,0xd
# LLVM-MCA-LATENCY 1
xor    rdx,rsi
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rsi,rdx
# LLVM-MCA-LATENCY
sar    rsi,0x7
# LLVM-MCA-LATENCY 1
xor    rsi,rdx
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rdx,rsi
# LLVM-MCA-LATENCY
shl    rdx,0x11
# LLVM-MCA-LATENCY 1
xor    rdx,rsi
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rsi,rdx
# LLVM-MCA-LATENCY
shl    rsi,0xd
# LLVM-MCA-LATENCY 1
xor    rsi,rdx
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rdx,rsi
# LLVM-MCA-LATENCY
sar    rdx,0x7
# LLVM-MCA-LATENCY 1
xor    rdx,rsi
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    r13,rdx
# LLVM-MCA-LATENCY
shl    r13,0x11
# LLVM-MCA-LATENCY 1
xor    r13,rdx
# LLVM-MCA-LATENCY
add    rcx,-8
jne .Ltarget
# LLVM-MCA-LATENCY 0
mov    rdx,r13
# LLVM-MCA-LATENCY
shl    rdx,0xd
# LLVM-MCA-LATENCY 1
xor    rdx,r13
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rsi,rdx
# LLVM-MCA-LATENCY
sar    rsi,0x7
# LLVM-MCA-LATENCY 1
xor    rsi,rdx
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rdx,rsi
# LLVM-MCA-LATENCY
shl    rdx,0x11
# LLVM-MCA-LATENCY 1
xor    rdx,rsi
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rsi,rdx
# LLVM-MCA-LATENCY
shl    rsi,0xd
# LLVM-MCA-LATENCY 1
xor    rsi,rdx
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rdx,rsi
# LLVM-MCA-LATENCY
sar    rdx,0x7
# LLVM-MCA-LATENCY 1
xor    rdx,rsi
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rsi,rdx
# LLVM-MCA-LATENCY
shl    rsi,0x11
# LLVM-MCA-LATENCY 1
xor    rsi,rdx
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rdx,rsi
# LLVM-MCA-LATENCY
shl    rdx,0xd
# LLVM-MCA-LATENCY 1
xor    rdx,rsi
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rsi,rdx
# LLVM-MCA-LATENCY
sar    rsi,0x7
# LLVM-MCA-LATENCY 1
xor    rsi,rdx
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rdx,rsi
# LLVM-MCA-LATENCY
shl    rdx,0x11
# LLVM-MCA-LATENCY 1
xor    rdx,rsi
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rsi,rdx
# LLVM-MCA-LATENCY
shl    rsi,0xd
# LLVM-MCA-LATENCY 1
xor    rsi,rdx
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rdx,rsi
# LLVM-MCA-LATENCY
sar    rdx,0x7
# LLVM-MCA-LATENCY 1
xor    rdx,rsi
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rsi,rdx
# LLVM-MCA-LATENCY
shl    rsi,0x11
# LLVM-MCA-LATENCY 1
xor    rsi,rdx
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rdx,rsi
# LLVM-MCA-LATENCY
shl    rdx,0xd
# LLVM-MCA-LATENCY 1
xor    rdx,rsi
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rsi,rdx
# LLVM-MCA-LATENCY
sar    rsi,0x7
# LLVM-MCA-LATENCY 1
xor    rsi,rdx
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rdx,rsi
# LLVM-MCA-LATENCY
shl    rdx,0x11
# LLVM-MCA-LATENCY 1
xor    rdx,rsi
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rsi,rdx
# LLVM-MCA-LATENCY
shl    rsi,0xd
# LLVM-MCA-LATENCY 1
xor    rsi,rdx
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rdx,rsi
# LLVM-MCA-LATENCY
sar    rdx,0x7
# LLVM-MCA-LATENCY 1
xor    rdx,rsi
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rsi,rdx
# LLVM-MCA-LATENCY
shl    rsi,0x11
# LLVM-MCA-LATENCY 1
xor    rsi,rdx
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rdx,rsi
# LLVM-MCA-LATENCY
shl    rdx,0xd
# LLVM-MCA-LATENCY 1
xor    rdx,rsi
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rsi,rdx
# LLVM-MCA-LATENCY
sar    rsi,0x7
# LLVM-MCA-LATENCY 1
xor    rsi,rdx
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rdx,rsi
# LLVM-MCA-LATENCY
shl    rdx,0x11
# LLVM-MCA-LATENCY 1
xor    rdx,rsi
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rsi,rdx
# LLVM-MCA-LATENCY
shl    rsi,0xd
# LLVM-MCA-LATENCY 1
xor    rsi,rdx
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rdx,rsi
# LLVM-MCA-LATENCY
sar    rdx,0x7
# LLVM-MCA-LATENCY 1
xor    rdx,rsi
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    r13,rdx
# LLVM-MCA-LATENCY
shl    r13,0x11
# LLVM-MCA-LATENCY 1
xor    r13,rdx
# LLVM-MCA-LATENCY
add    rcx,-8
jne .Ltarget
inc    rax
cmp    rax,r12
jne .Ltarget
