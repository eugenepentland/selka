.intel_syntax noprefix
.Ltarget:
# LLVM-MCA-LATENCY 0
mov    r8,rcx
# LLVM-MCA-LATENCY
shl    r8,0xd
# LLVM-MCA-LATENCY 1
xor    r8,rcx
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rcx,r8
# LLVM-MCA-LATENCY
sar    rcx,0x7
# LLVM-MCA-LATENCY 1
xor    rcx,r8
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    r8,rcx
# LLVM-MCA-LATENCY
shl    r8,0x11
# LLVM-MCA-LATENCY 1
xor    r8,rcx
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rcx,r8
# LLVM-MCA-LATENCY
shl    rcx,0xd
# LLVM-MCA-LATENCY 1
xor    rcx,r8
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    r8,rcx
# LLVM-MCA-LATENCY
sar    r8,0x7
# LLVM-MCA-LATENCY 1
xor    r8,rcx
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rcx,r8
# LLVM-MCA-LATENCY
shl    rcx,0x11
# LLVM-MCA-LATENCY 1
xor    rcx,r8
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    r8,rcx
# LLVM-MCA-LATENCY
shl    r8,0xd
# LLVM-MCA-LATENCY 1
xor    r8,rcx
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rcx,r8
# LLVM-MCA-LATENCY
sar    rcx,0x7
# LLVM-MCA-LATENCY 1
xor    rcx,r8
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    r8,rcx
# LLVM-MCA-LATENCY
shl    r8,0x11
# LLVM-MCA-LATENCY 1
xor    r8,rcx
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rcx,r8
# LLVM-MCA-LATENCY
shl    rcx,0xd
# LLVM-MCA-LATENCY 1
xor    rcx,r8
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    r8,rcx
# LLVM-MCA-LATENCY
sar    r8,0x7
# LLVM-MCA-LATENCY 1
xor    r8,rcx
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rcx,r8
# LLVM-MCA-LATENCY
shl    rcx,0x11
# LLVM-MCA-LATENCY 1
xor    rcx,r8
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    r8,rcx
# LLVM-MCA-LATENCY
shl    r8,0xd
# LLVM-MCA-LATENCY 1
xor    r8,rcx
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rcx,r8
# LLVM-MCA-LATENCY
sar    rcx,0x7
# LLVM-MCA-LATENCY 1
xor    rcx,r8
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    r8,rcx
# LLVM-MCA-LATENCY
shl    r8,0x11
# LLVM-MCA-LATENCY 1
xor    r8,rcx
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rcx,r8
# LLVM-MCA-LATENCY
shl    rcx,0xd
# LLVM-MCA-LATENCY 1
xor    rcx,r8
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    r8,rcx
# LLVM-MCA-LATENCY
sar    r8,0x7
# LLVM-MCA-LATENCY 1
xor    r8,rcx
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rcx,r8
# LLVM-MCA-LATENCY
shl    rcx,0x11
# LLVM-MCA-LATENCY 1
xor    rcx,r8
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    r8,rcx
# LLVM-MCA-LATENCY
shl    r8,0xd
# LLVM-MCA-LATENCY 1
xor    r8,rcx
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rcx,r8
# LLVM-MCA-LATENCY
sar    rcx,0x7
# LLVM-MCA-LATENCY 1
xor    rcx,r8
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    r8,rcx
# LLVM-MCA-LATENCY
shl    r8,0x11
# LLVM-MCA-LATENCY 1
xor    r8,rcx
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rcx,r8
# LLVM-MCA-LATENCY
shl    rcx,0xd
# LLVM-MCA-LATENCY 1
xor    rcx,r8
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    r8,rcx
# LLVM-MCA-LATENCY
sar    r8,0x7
# LLVM-MCA-LATENCY 1
xor    r8,rcx
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rcx,r8
# LLVM-MCA-LATENCY
shl    rcx,0x11
# LLVM-MCA-LATENCY 1
xor    rcx,r8
# LLVM-MCA-LATENCY
add    rdi,-8
jne .Ltarget
