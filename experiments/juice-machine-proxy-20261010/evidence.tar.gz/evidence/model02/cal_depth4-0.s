.intel_syntax noprefix
.Ltarget:
# LLVM-MCA-LATENCY 0
mov    rcx,r13
# LLVM-MCA-LATENCY
shl    rcx,0xd
# LLVM-MCA-LATENCY 1
xor    rcx,r13
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rdx,rcx
# LLVM-MCA-LATENCY
sar    rdx,0x7
# LLVM-MCA-LATENCY 1
xor    rdx,rcx
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rcx,rdx
# LLVM-MCA-LATENCY
shl    rcx,0x11
# LLVM-MCA-LATENCY 1
xor    rcx,rdx
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rdx,rcx
# LLVM-MCA-LATENCY
sar    rdx,0xb
# LLVM-MCA-LATENCY 1
xor    rdx,rcx
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rcx,rdx
# LLVM-MCA-LATENCY
shl    rcx,0xd
# LLVM-MCA-LATENCY 1
xor    rcx,rdx
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rdx,rcx
# LLVM-MCA-LATENCY
sar    rdx,0x7
# LLVM-MCA-LATENCY 1
xor    rdx,rcx
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rcx,rdx
# LLVM-MCA-LATENCY
shl    rcx,0x11
# LLVM-MCA-LATENCY 1
xor    rcx,rdx
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rdx,rcx
# LLVM-MCA-LATENCY
sar    rdx,0xb
# LLVM-MCA-LATENCY 1
xor    rdx,rcx
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rcx,rdx
# LLVM-MCA-LATENCY
shl    rcx,0xd
# LLVM-MCA-LATENCY 1
xor    rcx,rdx
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rdx,rcx
# LLVM-MCA-LATENCY
sar    rdx,0x7
# LLVM-MCA-LATENCY 1
xor    rdx,rcx
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rcx,rdx
# LLVM-MCA-LATENCY
shl    rcx,0x11
# LLVM-MCA-LATENCY 1
xor    rcx,rdx
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rdx,rcx
# LLVM-MCA-LATENCY
sar    rdx,0xb
# LLVM-MCA-LATENCY 1
xor    rdx,rcx
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rcx,rdx
# LLVM-MCA-LATENCY
shl    rcx,0xd
# LLVM-MCA-LATENCY 1
xor    rcx,rdx
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rdx,rcx
# LLVM-MCA-LATENCY
sar    rdx,0x7
# LLVM-MCA-LATENCY 1
xor    rdx,rcx
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    rcx,rdx
# LLVM-MCA-LATENCY
shl    rcx,0x11
# LLVM-MCA-LATENCY 1
xor    rcx,rdx
# LLVM-MCA-LATENCY
# LLVM-MCA-LATENCY 0
mov    r13,rcx
# LLVM-MCA-LATENCY
sar    r13,0xb
# LLVM-MCA-LATENCY 1
xor    r13,rcx
# LLVM-MCA-LATENCY
add    r12,-4
jne .Ltarget
