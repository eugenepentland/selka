heap::string_obj

.tmp-mut-argument/lox-post-record/current/qbe-production:     file format elf64-x86-64


Disassembly of section .text:

00000000011041fd <myl_f_b54eeed03870b797a96d1738a2f42781bb5db72dae7d2f57e436551c3d0172dd+0x62d>:
 11041fd:	39 d1                	cmp    %edx,%ecx
 11041ff:	72 0d                	jb     110420e <myl_f_b54eeed03870b797a96d1738a2f42781bb5db72dae7d2f57e436551c3d0172dd+0x63e>
 1104201:	48 89 ce             	mov    %rcx,%rsi
 1104204:	48 89 fb             	mov    %rdi,%rbx
 1104207:	e8 e4 d9 1c 00       	call   12d1bf0 <myl_qbe_fail_normalized_index_bounds>
 110420c:	0f 0b                	ud2
 110420e:	48 87 fb             	xchg   %rdi,%rbx
 1104211:	48 8b 40 20          	mov    0x20(%rax),%rax
 1104215:	48 6b c9 38          	imul   $0x38,%rcx,%rcx
 1104219:	48 01 c1             	add    %rax,%rcx
 110421c:	48 89 4d c8          	mov    %rcx,-0x38(%rbp)
 1104220:	48 8d 95 d8 fe ff ff 	lea    -0x128(%rbp),%rdx
 1104227:	49 89 f6             	mov    %rsi,%r14
 110422a:	48 8d 35 07 ab 2b 00 	lea    0x2bab07(%rip),%rsi        # 13bed38 <myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14>
 1104231:	49 89 fd             	mov    %rdi,%r13
 1104234:	e8 67 43 1e 00       	call   12e85a0 <myl_rc_native_loan>
 1104239:	4d 89 f8             	mov    %r15,%r8

heap::set_object_field

.tmp-mut-argument/lox-post-record/current/qbe-production:     file format elf64-x86-64


Disassembly of section .text:

00000000010e2cf3 <myl_f_0b5b0c24ddddb193a115c6cacf83410e46d60453431effc245241a64d30eed3b+0x1ba3>:
 10e2cf3:	58                   	pop    %rax
 10e2cf4:	ff                   	(bad)
 10e2cf5:	ff                   	(bad)
 10e2cf6:	ff 48 8b             	decl   -0x75(%rax)
 10e2cf9:	85 c0                	test   %eax,%eax
 10e2cfb:	fe                   	(bad)
 10e2cfc:	ff                   	(bad)
 10e2cfd:	ff 48 89             	decl   -0x77(%rax)
 10e2d00:	85 60 ff             	test   %esp,-0x1(%rax)
 10e2d03:	ff                   	(bad)
 10e2d04:	ff 48 8b             	decl   -0x75(%rax)
 10e2d07:	16                   	(bad)
 10e2d08:	48 39 d1             	cmp    %rdx,%rcx
 10e2d0b:	72 0d                	jb     10e2d1a <myl_f_0b5b0c24ddddb193a115c6cacf83410e46d60453431effc245241a64d30eed3b+0x1bca>
 10e2d0d:	48 89 ce             	mov    %rcx,%rsi
 10e2d10:	48 89 fb             	mov    %rdi,%rbx
 10e2d13:	e8 d8 ee 1e 00       	call   12d1bf0 <myl_qbe_fail_normalized_index_bounds>
 10e2d18:	0f 0b                	ud2
 10e2d1a:	48 87 fb             	xchg   %rdi,%rbx
 10e2d1d:	49 89 ce             	mov    %rcx,%r14
 10e2d20:	48 8d 8d 30 ff ff ff 	lea    -0xd0(%rbp),%rcx
 10e2d27:	4c 89 f2             	mov    %r14,%rdx
 10e2d2a:	e8 21 92 1f 00       	call   12dbf50 <myl_rc_list_set>
 10e2d2f:	4c 89 ee             	mov    %r13,%rsi

heap::set_object_field

.tmp-mut-argument/lox-post-record/current/qbe-production:     file format elf64-x86-64


Disassembly of section .text:

00000000010e18a0 <myl_f_0b5b0c24ddddb193a115c6cacf83410e46d60453431effc245241a64d30eed3b+0x750>:
 10e18a0:	0d 48 89 ce 48       	or     $0x48ce8948,%eax
 10e18a5:	89 fb                	mov    %edi,%ebx
 10e18a7:	e8 44 03 1f 00       	call   12d1bf0 <myl_qbe_fail_normalized_index_bounds>
 10e18ac:	0f 0b                	ud2
 10e18ae:	48 87 fb             	xchg   %rdi,%rbx
 10e18b1:	48 8b 40 20          	mov    0x20(%rax),%rax
 10e18b5:	48 6b c9 38          	imul   $0x38,%rcx,%rcx
 10e18b9:	48 01 c1             	add    %rax,%rcx
 10e18bc:	48 89 8d c8 fe ff ff 	mov    %rcx,-0x138(%rbp)
 10e18c3:	48 8d 95 d0 fd ff ff 	lea    -0x230(%rbp),%rdx
 10e18ca:	49 89 f5             	mov    %rsi,%r13
 10e18cd:	48 8d 35 64 d4 2d 00 	lea    0x2dd464(%rip),%rsi        # 13bed38 <myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14>
 10e18d4:	49 89 fc             	mov    %rdi,%r12
 10e18d7:	e8 c4 6c 20 00       	call   12e85a0 <myl_rc_native_loan>
 10e18dc:	4d 89 f8             	mov    %r15,%r8

vm::load_frame

.tmp-mut-argument/lox-post-record/current/qbe-production:     file format elf64-x86-64


Disassembly of section .text:

00000000012c1b3f <myl_f_bf0431d3d9e553eacefcb10ebb00251bb8b43354cc87fd12c99ceb5644f705d6+0x146f>:
 12c1b3f:	0d 48 89 ce 49       	or     $0x49ce8948,%eax
 12c1b44:	89 fc                	mov    %edi,%esp
 12c1b46:	e8 a5 00 01 00       	call   12d1bf0 <myl_qbe_fail_normalized_index_bounds>
 12c1b4b:	0f 0b                	ud2
 12c1b4d:	49 87 fc             	xchg   %rdi,%r12
 12c1b50:	48 8b 40 20          	mov    0x20(%rax),%rax
 12c1b54:	48 6b c9 38          	imul   $0x38,%rcx,%rcx
 12c1b58:	48 01 c1             	add    %rax,%rcx
 12c1b5b:	48 89 8d 10 ff ff ff 	mov    %rcx,-0xf0(%rbp)
 12c1b62:	48 8d 95 d0 fd ff ff 	lea    -0x230(%rbp),%rdx
 12c1b69:	49 89 f6             	mov    %rsi,%r14
 12c1b6c:	48 8d 35 c5 d1 0f 00 	lea    0xfd1c5(%rip),%rsi        # 13bed38 <myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14>
 12c1b73:	49 89 fd             	mov    %rdi,%r13
 12c1b76:	e8 25 6a 02 00       	call   12e85a0 <myl_rc_native_loan>
 12c1b7b:	4d 89 f8             	mov    %r15,%r8

vm::load_frame

.tmp-mut-argument/lox-post-record/current/qbe-production:     file format elf64-x86-64


Disassembly of section .text:

00000000012c0fce <myl_f_bf0431d3d9e553eacefcb10ebb00251bb8b43354cc87fd12c99ceb5644f705d6+0x8fe>:
 12c0fce:	0d 48 89 ce 49       	or     $0x49ce8948,%eax
 12c0fd3:	89 fc                	mov    %edi,%esp
 12c0fd5:	e8 16 0c 01 00       	call   12d1bf0 <myl_qbe_fail_normalized_index_bounds>
 12c0fda:	0f 0b                	ud2
 12c0fdc:	49 87 fc             	xchg   %rdi,%r12
 12c0fdf:	48 8b 40 20          	mov    0x20(%rax),%rax
 12c0fe3:	48 6b c9 38          	imul   $0x38,%rcx,%rcx
 12c0fe7:	48 01 c1             	add    %rax,%rcx
 12c0fea:	48 89 8d 10 ff ff ff 	mov    %rcx,-0xf0(%rbp)
 12c0ff1:	48 8d 95 d0 fd ff ff 	lea    -0x230(%rbp),%rdx
 12c0ff8:	49 89 f6             	mov    %rsi,%r14
 12c0ffb:	48 8d 35 36 dd 0f 00 	lea    0xfdd36(%rip),%rsi        # 13bed38 <myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14>
 12c1002:	49 89 fd             	mov    %rdi,%r13
 12c1005:	e8 96 75 02 00       	call   12e85a0 <myl_rc_native_loan>
 12c100a:	4d 89 f8             	mov    %r15,%r8

heap::set_instance_field

.tmp-mut-argument/lox-post-record/current/qbe-production:     file format elf64-x86-64


Disassembly of section .text:

00000000010e3b5c <myl_f_1c0bd1b7bb117cc78f49bded6cea445b0f0085cd72c106cf259efd77a43b555f+0xc5c>:
 10e3b5c:	8b 85 a8 fb ff ff    	mov    -0x458(%rbp),%eax
 10e3b62:	8b 8d 20 fb ff ff    	mov    -0x4e0(%rbp),%ecx
 10e3b68:	83 e1 18             	and    $0x18,%ecx
 10e3b6b:	83 f9 00             	cmp    $0x0,%ecx
 10e3b6e:	0f 94 c1             	sete   %cl
 10e3b71:	0f b6 c9             	movzbl %cl,%ecx
 10e3b74:	85 c1                	test   %eax,%ecx
 10e3b76:	0f 85 b4 00 00 00    	jne    10e3c30 <myl_f_1c0bd1b7bb117cc78f49bded6cea445b0f0085cd72c106cf259efd77a43b555f+0xd30>
 10e3b7c:	4c 89 e9             	mov    %r13,%rcx
 10e3b7f:	48 8d 95 a0 fc ff ff 	lea    -0x360(%rbp),%rdx
 10e3b86:	49 89 f6             	mov    %rsi,%r14
 10e3b89:	48 8d 35 98 c3 2d 00 	lea    0x2dc398(%rip),%rsi        # 13bff28 <myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28>
 10e3b90:	49 89 fc             	mov    %rdi,%r12
 10e3b93:	e8 08 4a 20 00       	call   12e85a0 <myl_rc_native_loan>
 10e3b98:	4c 89 f6             	mov    %r14,%rsi

vm::get_property

.tmp-mut-argument/lox-post-record/current/qbe-production:     file format elf64-x86-64


Disassembly of section .text:

00000000012a3302 <myl_f_9997f25fb78e8fa6d0d7377b866a60fc0115d73452e18cfb6fc361c19bf67784+0x912>:
 12a3302:	0d 48 89 ce 48       	or     $0x48ce8948,%eax
 12a3307:	89 fb                	mov    %edi,%ebx
 12a3309:	e8 e2 e8 02 00       	call   12d1bf0 <myl_qbe_fail_normalized_index_bounds>
 12a330e:	0f 0b                	ud2
 12a3310:	48 87 fb             	xchg   %rdi,%rbx
 12a3313:	48 8b 40 20          	mov    0x20(%rax),%rax
 12a3317:	48 6b c9 38          	imul   $0x38,%rcx,%rcx
 12a331b:	48 01 c1             	add    %rax,%rcx
 12a331e:	48 89 8d 78 ff ff ff 	mov    %rcx,-0x88(%rbp)
 12a3325:	48 8d 95 70 fe ff ff 	lea    -0x190(%rbp),%rdx
 12a332c:	49 89 f7             	mov    %rsi,%r15
 12a332f:	48 8d 35 02 ba 11 00 	lea    0x11ba02(%rip),%rsi        # 13bed38 <myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14>
 12a3336:	49 89 fd             	mov    %rdi,%r13
 12a3339:	e8 62 52 04 00       	call   12e85a0 <myl_rc_native_loan>
 12a333e:	4c 89 fe             	mov    %r15,%rsi

heap::set_instance_field

.tmp-mut-argument/lox-post-record/current/qbe-production:     file format elf64-x86-64


Disassembly of section .text:

00000000010e3eb7 <myl_f_1c0bd1b7bb117cc78f49bded6cea445b0f0085cd72c106cf259efd77a43b555f+0xfb7>:
 10e3eb7:	8d 20                	lea    (%rax),%esp
 10e3eb9:	fb                   	sti
 10e3eba:	ff                   	(bad)
 10e3ebb:	ff 83 e1 18 83 f9    	incl   -0x67ce71f(%rbx)
 10e3ec1:	00 0f                	add    %cl,(%rdi)
 10e3ec3:	94                   	xchg   %eax,%esp
 10e3ec4:	c1 0f b6             	rorl   $0xb6,(%rdi)
 10e3ec7:	c9                   	leave
 10e3ec8:	85 c1                	test   %eax,%ecx
 10e3eca:	0f 85 a0 00 00 00    	jne    10e3f70 <myl_f_1c0bd1b7bb117cc78f49bded6cea445b0f0085cd72c106cf259efd77a43b555f+0x1070>
 10e3ed0:	4d 89 c7             	mov    %r8,%r15
 10e3ed3:	48 8d 8d c0 fd ff ff 	lea    -0x240(%rbp),%rcx
 10e3eda:	48 8d 95 a0 fc ff ff 	lea    -0x360(%rbp),%rdx
 10e3ee1:	49 89 f6             	mov    %rsi,%r14
 10e3ee4:	48 8d 35 3d c0 2d 00 	lea    0x2dc03d(%rip),%rsi        # 13bff28 <myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28>
 10e3eeb:	49 89 fc             	mov    %rdi,%r12
 10e3eee:	e8 5d 4b 20 00       	call   12e8a50 <myl_rc_native_retain>
 10e3ef3:	4c 89 f6             	mov    %r14,%rsi

heap::class_method

.tmp-mut-argument/lox-post-record/current/qbe-production:     file format elf64-x86-64


Disassembly of section .text:

00000000010eb955 <myl_f_548c7924fb70947e5821a6480ca42591925741aed8a343767696180a416dee48+0x6b5>:
 10eb955:	39 d1                	cmp    %edx,%ecx
 10eb957:	72 0d                	jb     10eb966 <myl_f_548c7924fb70947e5821a6480ca42591925741aed8a343767696180a416dee48+0x6c6>
 10eb959:	48 89 ce             	mov    %rcx,%rsi
 10eb95c:	49 89 fc             	mov    %rdi,%r12
 10eb95f:	e8 8c 62 1e 00       	call   12d1bf0 <myl_qbe_fail_normalized_index_bounds>
 10eb964:	0f 0b                	ud2
 10eb966:	49 87 fc             	xchg   %rdi,%r12
 10eb969:	48 8b 40 20          	mov    0x20(%rax),%rax
 10eb96d:	48 6b c9 38          	imul   $0x38,%rcx,%rcx
 10eb971:	48 01 c1             	add    %rax,%rcx
 10eb974:	48 89 4d a0          	mov    %rcx,-0x60(%rbp)
 10eb978:	48 8d 95 a8 fe ff ff 	lea    -0x158(%rbp),%rdx
 10eb97f:	49 89 f7             	mov    %rsi,%r15
 10eb982:	48 8d 35 af 33 2d 00 	lea    0x2d33af(%rip),%rsi        # 13bed38 <myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14>
 10eb989:	49 89 fe             	mov    %rdi,%r14
 10eb98c:	e8 0f cc 1f 00       	call   12e85a0 <myl_rc_native_loan>
 10eb991:	4c 89 fe             	mov    %r15,%rsi

heap::function_arity

.tmp-mut-argument/lox-post-record/current/qbe-production:     file format elf64-x86-64


Disassembly of section .text:

00000000010eaaed <myl_f_348eaa393d464f443236774283a696a5c7c7c1537d537e751cd490a80ac6e63c+0x62d>:
 10eaaed:	39 d1                	cmp    %edx,%ecx
 10eaaef:	72 0d                	jb     10eaafe <myl_f_348eaa393d464f443236774283a696a5c7c7c1537d537e751cd490a80ac6e63c+0x63e>
 10eaaf1:	48 89 ce             	mov    %rcx,%rsi
 10eaaf4:	48 89 fb             	mov    %rdi,%rbx
 10eaaf7:	e8 f4 70 1e 00       	call   12d1bf0 <myl_qbe_fail_normalized_index_bounds>
 10eaafc:	0f 0b                	ud2
 10eaafe:	48 87 fb             	xchg   %rdi,%rbx
 10eab01:	48 8b 40 20          	mov    0x20(%rax),%rax
 10eab05:	48 6b c9 38          	imul   $0x38,%rcx,%rcx
 10eab09:	48 01 c1             	add    %rax,%rcx
 10eab0c:	48 89 4d c8          	mov    %rcx,-0x38(%rbp)
 10eab10:	48 8d 95 b8 fe ff ff 	lea    -0x148(%rbp),%rdx
 10eab17:	49 89 f6             	mov    %rsi,%r14
 10eab1a:	48 8d 35 17 42 2d 00 	lea    0x2d4217(%rip),%rsi        # 13bed38 <myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14>
 10eab21:	49 89 fd             	mov    %rdi,%r13
 10eab24:	e8 77 da 1f 00       	call   12e85a0 <myl_rc_native_loan>
 10eab29:	4d 89 f8             	mov    %r15,%r8

heap::set_instance_field

.tmp-mut-argument/lox-post-record/current/qbe-production:     file format elf64-x86-64


Disassembly of section .text:

00000000010e3820 <myl_f_1c0bd1b7bb117cc78f49bded6cea445b0f0085cd72c106cf259efd77a43b555f+0x920>:
 10e3820:	8b 85 a8 fb ff ff    	mov    -0x458(%rbp),%eax
 10e3826:	8b 8d 20 fb ff ff    	mov    -0x4e0(%rbp),%ecx
 10e382c:	83 e1 18             	and    $0x18,%ecx
 10e382f:	83 f9 00             	cmp    $0x0,%ecx
 10e3832:	0f 94 c1             	sete   %cl
 10e3835:	0f b6 c9             	movzbl %cl,%ecx
 10e3838:	85 c1                	test   %eax,%ecx
 10e383a:	0f 85 b4 00 00 00    	jne    10e38f4 <myl_f_1c0bd1b7bb117cc78f49bded6cea445b0f0085cd72c106cf259efd77a43b555f+0x9f4>
 10e3840:	4c 89 e9             	mov    %r13,%rcx
 10e3843:	48 8d 95 a0 fc ff ff 	lea    -0x360(%rbp),%rdx
 10e384a:	49 89 f6             	mov    %rsi,%r14
 10e384d:	48 8d 35 d4 c6 2d 00 	lea    0x2dc6d4(%rip),%rsi        # 13bff28 <myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28>
 10e3854:	49 89 fc             	mov    %rdi,%r12
 10e3857:	e8 44 4d 20 00       	call   12e85a0 <myl_rc_native_loan>
 10e385c:	4c 89 f6             	mov    %r14,%rsi

heap::sweep

.tmp-mut-argument/lox-post-record/current/qbe-production:     file format elf64-x86-64


Disassembly of section .text:

00000000010e804c <myl_f_2d3327a14cbd7e79d75ced9a8334e2957edb6b819e232d4bfaaec5e6f20a417c+0x13ec>:
 10e804c:	38 f9                	cmp    %bh,%cl
 10e804e:	ff                   	(bad)
 10e804f:	ff 01                	incl   (%rcx)
 10e8051:	00 00                	add    %al,(%rax)
 10e8053:	00 48 8d             	add    %cl,-0x73(%rax)
 10e8056:	85 58 f9             	test   %ebx,-0x7(%rax)
 10e8059:	ff                   	(bad)
 10e805a:	ff 48 89             	decl   -0x77(%rax)
 10e805d:	85 78 fe             	test   %edi,-0x2(%rax)
 10e8060:	ff                   	(bad)
 10e8061:	ff 41 89             	incl   -0x77(%rcx)
 10e8064:	d0 48 8d             	rorb   $1,-0x73(%rax)
 10e8067:	8d 58 f9             	lea    -0x7(%rax),%ebx
 10e806a:	ff                   	(bad)
 10e806b:	ff 48 8d             	decl   -0x73(%rax)
 10e806e:	95                   	xchg   %eax,%ebp
 10e806f:	f8                   	clc
 10e8070:	fa                   	cli
 10e8071:	ff                   	(bad)
 10e8072:	ff 49 89             	decl   -0x77(%rcx)
 10e8075:	f7 48 8d 35 bb 6c 2d 	testl  $0x2d6cbb35,-0x73(%rax)
 10e807c:	00 49 89             	add    %cl,-0x77(%rcx)
 10e807f:	fe 4c 89 e7          	decb   -0x19(%rcx,%rcx,4)
 10e8083:	e8 c8 09 20 00       	call   12e8a50 <myl_rc_native_retain>
 10e8088:	4c 89 fe             	mov    %r15,%rsi
