
.tmp-mut-argument/joined-flat-measure/schematic-qbe-production:     file format elf64-x86-64


Disassembly of section .text:

00000000010fc430 <myl_rc_native_retain>:
 10fc430:	push   %rbp
 10fc431:	mov    %rsp,%rbp
 10fc434:	push   %r15
 10fc436:	push   %r14
 10fc438:	push   %r13
 10fc43a:	push   %r12
 10fc43c:	push   %rbx
 10fc43d:	sub    $0x48,%rsp
 10fc441:	mov    %r8d,%r12d
 10fc444:	mov    %rcx,%r15
 10fc447:	mov    %rdx,%r14
 10fc44a:	mov    %rsi,%r13
 10fc44d:	mov    %rdi,%rbx
 10fc450:	call   10f46a0 <myl_rc_descriptor_find>
 10fc455:	test   %rax,%rax
 10fc458:	mov    %r15,-0x30(%rbp)
 10fc45c:	je     10fc504 <myl_rc_native_retain+0xd4>
 10fc462:	cmpl   $0x0,0x78(%rax)
 10fc466:	jne    10fc47a <myl_rc_native_retain+0x4a>
 10fc468:	mov    0x1608(%rbx),%rcx
 10fc46f:	cmpq   $0x0,0x60(%rcx)
 10fc474:	je     10fc52e <myl_rc_native_retain+0xfe>
 10fc47a:	mov    0x8(%rax),%r15
 10fc47e:	test   %r15,%r15
 10fc481:	je     10fc51b <myl_rc_native_retain+0xeb>
 10fc487:	mov    %rbx,%rdi
 10fc48a:	mov    %r13,%rsi
 10fc48d:	call   10f6560 <myl_rc_native_has_unique>
 10fc492:	test   %eax,%eax
 10fc494:	jne    10fc592 <myl_rc_native_retain+0x162>
 10fc49a:	mov    0x0(%r13),%rdx
 10fc49e:	xor    %r13d,%r13d
 10fc4a1:	mov    %r14,%rdi
 10fc4a4:	xor    %esi,%esi
 10fc4a6:	call   10fc7c0 <compiler_rt.fastMemset>
 10fc4ab:	mov    %r15,-0x50(%rbp)
 10fc4af:	mov    %r14,-0x48(%rbp)
 10fc4b3:	movq   $0x0,-0x40(%rbp)
 10fc4bb:	mov    %r12d,-0x38(%rbp)
 10fc4bf:	movl   $0x0,-0x34(%rbp)
 10fc4c6:	mov    %r15,-0x70(%rbp)
 10fc4ca:	mov    -0x30(%rbp),%rax
 10fc4ce:	mov    %rax,-0x68(%rbp)
 10fc4d2:	vxorps %xmm0,%xmm0,%xmm0
 10fc4d6:	vmovups %xmm0,-0x60(%rbp)
 10fc4db:	lea    -0x50(%rbp),%rsi
 10fc4df:	lea    -0x70(%rbp),%rdx
 10fc4e3:	mov    $0x1,%ecx
 10fc4e8:	mov    %rbx,%rdi
 10fc4eb:	call   10f9a60 <myl_rc_value_retain_many>
 10fc4f0:	test   %eax,%eax
 10fc4f2:	je     10fc57a <myl_rc_native_retain+0x14a>
 10fc4f8:	mov    %rbx,%rdi
 10fc4fb:	mov    %eax,%esi
 10fc4fd:	call   10f3a10 <myl_rc_record_failure>
 10fc502:	jmp    10fc580 <myl_rc_native_retain+0x150>
 10fc504:	mov    %rbx,%rdi
 10fc507:	mov    %r13,%rsi
 10fc50a:	call   10fb8a0 <myl_rc_native_shape>
 10fc50f:	mov    %rax,%r15
 10fc512:	test   %r15,%r15
 10fc515:	jne    10fc487 <myl_rc_native_retain+0x57>
 10fc51b:	mov    0x0(%r13),%rdx
 10fc51f:	xor    %r13d,%r13d
 10fc522:	mov    %r14,%rdi
 10fc525:	xor    %esi,%esi
 10fc527:	call   10fc7c0 <compiler_rt.fastMemset>
 10fc52c:	jmp    10fc580 <myl_rc_native_retain+0x150>
 10fc52e:	mov    0x0(%r13),%rdx
 10fc532:	test   %rdx,%rdx
 10fc535:	je     10fc47a <myl_rc_native_retain+0x4a>
 10fc53b:	mov    %r14,%rcx
 10fc53e:	sub    %r15,%rcx
 10fc541:	ja     10fc549 <myl_rc_native_retain+0x119>
 10fc543:	mov    %r15,%rcx
 10fc546:	sub    %r14,%rcx
 10fc549:	cmp    %rdx,%rcx
 10fc54c:	jb     10fc47a <myl_rc_native_retain+0x4a>
 10fc552:	cmp    0x70(%rbx),%r12d
 10fc556:	jbe    10fc56f <myl_rc_native_retain+0x13f>
 10fc558:	xor    %r13d,%r13d
 10fc55b:	mov    %r14,%rdi
 10fc55e:	xor    %esi,%esi
 10fc560:	call   10fc7c0 <compiler_rt.fastMemset>
 10fc565:	mov    %rbx,%rdi
 10fc568:	mov    $0x3,%esi
 10fc56d:	jmp    10fc4fd <myl_rc_native_retain+0xcd>
 10fc56f:	mov    %r14,%rdi
 10fc572:	mov    %r15,%rsi
 10fc575:	call   10fccc0 <compiler_rt.memcpy.memcpyFast>
 10fc57a:	mov    $0x1,%r13d
 10fc580:	mov    %r13d,%eax
 10fc583:	add    $0x48,%rsp
 10fc587:	pop    %rbx
 10fc588:	pop    %r12
 10fc58a:	pop    %r13
 10fc58c:	pop    %r14
 10fc58e:	pop    %r15
 10fc590:	pop    %rbp
 10fc591:	ret
 10fc592:	call   10f38ae <myl_rc_invariant_failed>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
