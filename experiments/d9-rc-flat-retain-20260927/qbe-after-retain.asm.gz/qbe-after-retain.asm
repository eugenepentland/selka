
.tmp-mut-argument/flat-retain-measure/schematic-qbe-production:     file format elf64-x86-64


Disassembly of section .text:

00000000010fc430 <myl_rc_native_retain>:
 10fc430:	push   %rbp
 10fc431:	mov    %rsp,%rbp
 10fc434:	push   %r15
 10fc436:	push   %r14
 10fc438:	push   %r13
 10fc43a:	push   %r12
 10fc43c:	push   %rbx
 10fc43d:	sub    $0x68,%rsp
 10fc441:	mov    %r8d,-0x2c(%rbp)
 10fc445:	mov    %rcx,%r15
 10fc448:	mov    %rdx,%r14
 10fc44b:	mov    %rsi,%r13
 10fc44e:	mov    %rdi,%rbx
 10fc451:	call   10f46a0 <myl_rc_descriptor_find>
 10fc456:	test   %rax,%rax
 10fc459:	mov    %r15,-0x38(%rbp)
 10fc45d:	je     10fc58d <myl_rc_native_retain+0x15d>
 10fc463:	mov    %rax,%r12
 10fc466:	cmpl   $0x0,0x78(%rax)
 10fc46a:	jne    10fc47e <myl_rc_native_retain+0x4e>
 10fc46c:	mov    0x1608(%rbx),%rax
 10fc473:	cmpq   $0x0,0x60(%rax)
 10fc478:	je     10fc5ee <myl_rc_native_retain+0x1be>
 10fc47e:	mov    %r13,-0x50(%rbp)
 10fc482:	mov    (%r12),%rax
 10fc486:	mov    (%rax),%rdx
 10fc489:	cmpl   $0x0,0x7c(%r12)
 10fc48f:	setne  %al
 10fc492:	test   %rdx,%rdx
 10fc495:	setne  %cl
 10fc498:	and    %al,%cl
 10fc49a:	cmp    $0x1,%cl
 10fc49d:	jne    10fc4f0 <myl_rc_native_retain+0xc0>
 10fc49f:	test   %rbx,%rbx
 10fc4a2:	mov    -0x38(%rbp),%rcx
 10fc4a6:	je     10fc72a <myl_rc_native_retain+0x2fa>
 10fc4ac:	mov    0x1608(%rbx),%rax
 10fc4b3:	test   %rax,%rax
 10fc4b6:	je     10fc72a <myl_rc_native_retain+0x2fa>
 10fc4bc:	test   %rcx,%rcx
 10fc4bf:	je     10fc72a <myl_rc_native_retain+0x2fa>
 10fc4c5:	test   %r14,%r14
 10fc4c8:	je     10fc72a <myl_rc_native_retain+0x2fa>
 10fc4ce:	cmpq   $0x0,0x58(%rax)
 10fc4d3:	jne    10fc72a <myl_rc_native_retain+0x2fa>
 10fc4d9:	mov    %r14,%rax
 10fc4dc:	sub    %rcx,%rax
 10fc4df:	ja     10fc4e7 <myl_rc_native_retain+0xb7>
 10fc4e1:	mov    %rcx,%rax
 10fc4e4:	sub    %r14,%rax
 10fc4e7:	cmp    %rdx,%rax
 10fc4ea:	jae    10fc5ba <myl_rc_native_retain+0x18a>
 10fc4f0:	mov    0x8(%r12),%r12
 10fc4f5:	mov    -0x50(%rbp),%r13
 10fc4f9:	test   %r12,%r12
 10fc4fc:	je     10fc5a4 <myl_rc_native_retain+0x174>
 10fc502:	mov    %rbx,%rdi
 10fc505:	mov    %r13,%rsi
 10fc508:	call   10f6560 <myl_rc_native_has_unique>
 10fc50d:	test   %eax,%eax
 10fc50f:	jne    10fc72a <myl_rc_native_retain+0x2fa>
 10fc515:	mov    0x0(%r13),%rdx
 10fc519:	xor    %r15d,%r15d
 10fc51c:	mov    %r14,%rdi
 10fc51f:	xor    %esi,%esi
 10fc521:	call   10fc950 <compiler_rt.fastMemset>
 10fc526:	mov    %r12,-0x70(%rbp)
 10fc52a:	mov    %r14,-0x68(%rbp)
 10fc52e:	movq   $0x0,-0x60(%rbp)
 10fc536:	mov    -0x2c(%rbp),%eax
 10fc539:	mov    %eax,-0x58(%rbp)
 10fc53c:	movl   $0x0,-0x54(%rbp)
 10fc543:	mov    %r12,-0x90(%rbp)
 10fc54a:	mov    -0x38(%rbp),%rax
 10fc54e:	mov    %rax,-0x88(%rbp)
 10fc555:	vxorps %xmm0,%xmm0,%xmm0
 10fc559:	vmovups %xmm0,-0x80(%rbp)
 10fc55e:	lea    -0x70(%rbp),%rsi
 10fc562:	lea    -0x90(%rbp),%rdx
 10fc569:	mov    $0x1,%ecx
 10fc56e:	mov    %rbx,%rdi
 10fc571:	call   10f9a60 <myl_rc_value_retain_many>
 10fc576:	test   %eax,%eax
 10fc578:	je     10fc6da <myl_rc_native_retain+0x2aa>
 10fc57e:	mov    %rbx,%rdi
 10fc581:	mov    %eax,%esi
 10fc583:	call   10f3a10 <myl_rc_record_failure>
 10fc588:	jmp    10fc6e0 <myl_rc_native_retain+0x2b0>
 10fc58d:	mov    %rbx,%rdi
 10fc590:	mov    %r13,%rsi
 10fc593:	call   10fb8a0 <myl_rc_native_shape>
 10fc598:	mov    %rax,%r12
 10fc59b:	test   %r12,%r12
 10fc59e:	jne    10fc502 <myl_rc_native_retain+0xd2>
 10fc5a4:	mov    0x0(%r13),%rdx
 10fc5a8:	xor    %r15d,%r15d
 10fc5ab:	mov    %r14,%rdi
 10fc5ae:	xor    %esi,%esi
 10fc5b0:	call   10fc950 <compiler_rt.fastMemset>
 10fc5b5:	jmp    10fc6e0 <myl_rc_native_retain+0x2b0>
 10fc5ba:	mov    $0x3,%r13d
 10fc5c0:	mov    -0x2c(%rbp),%eax
 10fc5c3:	cmp    0x70(%rbx),%eax
 10fc5c6:	jbe    10fc638 <myl_rc_native_retain+0x208>
 10fc5c8:	xor    %r15d,%r15d
 10fc5cb:	mov    %r14,%rdi
 10fc5ce:	xor    %esi,%esi
 10fc5d0:	call   10fc950 <compiler_rt.fastMemset>
 10fc5d5:	mov    %rbx,%rdi
 10fc5d8:	call   10f6230 <myl_rc_drain>
 10fc5dd:	test   %r13d,%r13d
 10fc5e0:	js     10fc4f0 <myl_rc_native_retain+0xc0>
 10fc5e6:	mov    %rbx,%rdi
 10fc5e9:	mov    %r13d,%esi
 10fc5ec:	jmp    10fc583 <myl_rc_native_retain+0x153>
 10fc5ee:	mov    0x0(%r13),%rdx
 10fc5f2:	test   %rdx,%rdx
 10fc5f5:	je     10fc47e <myl_rc_native_retain+0x4e>
 10fc5fb:	mov    %r14,%rax
 10fc5fe:	sub    %r15,%rax
 10fc601:	ja     10fc609 <myl_rc_native_retain+0x1d9>
 10fc603:	mov    %r15,%rax
 10fc606:	sub    %r14,%rax
 10fc609:	cmp    %rdx,%rax
 10fc60c:	jb     10fc47e <myl_rc_native_retain+0x4e>
 10fc612:	mov    -0x2c(%rbp),%eax
 10fc615:	cmp    0x70(%rbx),%eax
 10fc618:	jbe    10fc6f2 <myl_rc_native_retain+0x2c2>
 10fc61e:	xor    %r15d,%r15d
 10fc621:	mov    %r14,%rdi
 10fc624:	xor    %esi,%esi
 10fc626:	call   10fc950 <compiler_rt.fastMemset>
 10fc62b:	mov    %rbx,%rdi
 10fc62e:	mov    $0x3,%esi
 10fc633:	jmp    10fc583 <myl_rc_native_retain+0x153>
 10fc638:	mov    %rbx,-0x40(%rbp)
 10fc63c:	mov    %r14,%rdi
 10fc63f:	mov    -0x38(%rbp),%r15
 10fc643:	mov    %r15,%rsi
 10fc646:	mov    %rdx,-0x48(%rbp)
 10fc64a:	call   10fce50 <compiler_rt.memcpy.memcpyFast>
 10fc64f:	cmpl   $0x0,0x78(%r12)
 10fc655:	je     10fc6d1 <myl_rc_native_retain+0x2a1>
 10fc657:	xor    %eax,%eax
 10fc659:	nopl   0x0(%rax)
 10fc660:	mov    0x38(%r12,%rax,8),%rcx
 10fc665:	movq   $0x0,(%r14,%rcx,1)
 10fc66d:	inc    %rax
 10fc670:	mov    0x78(%r12),%ecx
 10fc675:	cmp    %rcx,%rax
 10fc678:	jb     10fc660 <myl_rc_native_retain+0x230>
 10fc67a:	test   %ecx,%ecx
 10fc67c:	je     10fc6d1 <myl_rc_native_retain+0x2a1>
 10fc67e:	xor    %ebx,%ebx
 10fc680:	mov    0x38(%r12,%rbx,8),%rax
 10fc685:	mov    (%r15,%rax,1),%r15
 10fc689:	test   %r15,%r15
 10fc68c:	je     10fc6a7 <myl_rc_native_retain+0x277>
 10fc68e:	mov    -0x10(%r15),%rax
 10fc692:	bt     $0x3e,%rax
 10fc697:	jae    10fc6a7 <myl_rc_native_retain+0x277>
 10fc699:	shr    $0x28,%rax
 10fc69d:	and    $0xfffff,%eax
 10fc6a2:	cmp    -0x2c(%rbp),%eax
 10fc6a5:	ja     10fc704 <myl_rc_native_retain+0x2d4>
 10fc6a7:	mov    -0x40(%rbp),%rdi
 10fc6ab:	mov    %r15,%rsi
 10fc6ae:	call   10f3dd0 <myl_rc_owner_acquire>
 10fc6b3:	test   %eax,%eax
 10fc6b5:	jne    10fc6ff <myl_rc_native_retain+0x2cf>
 10fc6b7:	mov    0x38(%r12,%rbx,8),%rax
 10fc6bc:	mov    %r15,(%r14,%rax,1)
 10fc6c0:	inc    %rbx
 10fc6c3:	mov    0x78(%r12),%eax
 10fc6c8:	cmp    %rax,%rbx
 10fc6cb:	mov    -0x38(%rbp),%r15
 10fc6cf:	jb     10fc680 <myl_rc_native_retain+0x250>
 10fc6d1:	mov    -0x40(%rbp),%rdi
 10fc6d5:	call   10f6230 <myl_rc_drain>
 10fc6da:	mov    $0x1,%r15d
 10fc6e0:	mov    %r15d,%eax
 10fc6e3:	add    $0x68,%rsp
 10fc6e7:	pop    %rbx
 10fc6e8:	pop    %r12
 10fc6ea:	pop    %r13
 10fc6ec:	pop    %r14
 10fc6ee:	pop    %r15
 10fc6f0:	pop    %rbp
 10fc6f1:	ret
 10fc6f2:	mov    %r14,%rdi
 10fc6f5:	mov    %r15,%rsi
 10fc6f8:	call   10fce50 <compiler_rt.memcpy.memcpyFast>
 10fc6fd:	jmp    10fc6da <myl_rc_native_retain+0x2aa>
 10fc6ff:	mov    %eax,%r13d
 10fc702:	jmp    10fc70a <myl_rc_native_retain+0x2da>
 10fc704:	mov    $0x3,%r13d
 10fc70a:	mov    $0x1,%ecx
 10fc70f:	mov    -0x40(%rbp),%rbx
 10fc713:	mov    %rbx,%rdi
 10fc716:	mov    %r12,%rsi
 10fc719:	mov    %r14,%rdx
 10fc71c:	call   10f6130 <myl_rc_flat_edges_release>
 10fc721:	mov    -0x48(%rbp),%rdx
 10fc725:	jmp    10fc5c8 <myl_rc_native_retain+0x198>
 10fc72a:	call   10f38ae <myl_rc_invariant_failed>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
