
.tmp-mut-argument/flat-retain-measure/schematic-llvm-production:     file format elf64-x86-64


Disassembly of section .text:

00000000010fc500 <myl_rc_native_retain>:
 10fc500:	push   %rbp
 10fc501:	mov    %rsp,%rbp
 10fc504:	push   %r15
 10fc506:	push   %r14
 10fc508:	push   %r13
 10fc50a:	push   %r12
 10fc50c:	push   %rbx
 10fc50d:	sub    $0x208,%rsp
 10fc514:	mov    %r8d,-0x2c(%rbp)
 10fc518:	mov    %rcx,%r15
 10fc51b:	mov    %rdx,%r14
 10fc51e:	mov    %rsi,%r12
 10fc521:	mov    %rdi,%rbx
 10fc524:	test   %rdi,%rdi
 10fc527:	je     10fc622 <myl_rc_native_retain+0x122>
 10fc52d:	mov    0x1608(%rbx),%rax
 10fc534:	test   %rax,%rax
 10fc537:	sete   %cl
 10fc53a:	test   %r12,%r12
 10fc53d:	sete   %dl
 10fc540:	or     %cl,%dl
 10fc542:	jne    10fc622 <myl_rc_native_retain+0x122>
 10fc548:	mov    0x40(%rax),%rcx
 10fc54c:	test   %rcx,%rcx
 10fc54f:	je     10fc622 <myl_rc_native_retain+0x122>
 10fc555:	mov    0x30(%rax),%rdx
 10fc559:	mov    %r12,%rsi
 10fc55c:	shr    $0x3,%rsi
 10fc560:	mov    %r12,%rdi
 10fc563:	shr    $0x21,%rdi
 10fc567:	xor    %rsi,%rdi
 10fc56a:	movabs $0xbf58476d1ce4e5b9,%r8
 10fc574:	imul   %rdi,%r8
 10fc578:	mov    %r8,%rsi
 10fc57b:	shr    $0x1b,%rsi
 10fc57f:	xor    %r8,%rsi
 10fc582:	xor    $0x2,%rsi
 10fc586:	dec    %rcx
 10fc589:	jmp    10fc593 <myl_rc_native_retain+0x93>
 10fc58b:	nopl   0x0(%rax,%rax,1)
 10fc590:	inc    %rsi
 10fc593:	and    %rcx,%rsi
 10fc596:	lea    (%rsi,%rsi,4),%rdi
 10fc59a:	mov    (%rdx,%rdi,8),%rdi
 10fc59e:	test   %rdi,%rdi
 10fc5a1:	je     10fc622 <myl_rc_native_retain+0x122>
 10fc5a3:	cmp    %r12,%rdi
 10fc5a6:	jne    10fc590 <myl_rc_native_retain+0x90>
 10fc5a8:	lea    (%rsi,%rsi,4),%rdi
 10fc5ac:	cmpl   $0x2,0x20(%rdx,%rdi,8)
 10fc5b1:	jne    10fc590 <myl_rc_native_retain+0x90>
 10fc5b3:	lea    (%rdx,%rdi,8),%rcx
 10fc5b7:	mov    0x8(%rcx),%r13
 10fc5bb:	test   %r13,%r13
 10fc5be:	je     10fc622 <myl_rc_native_retain+0x122>
 10fc5c0:	cmpl   $0x0,0x78(%r13)
 10fc5c5:	jne    10fc5d2 <myl_rc_native_retain+0xd2>
 10fc5c7:	cmpq   $0x0,0x60(%rax)
 10fc5cc:	je     10fc938 <myl_rc_native_retain+0x438>
 10fc5d2:	mov    0x0(%r13),%rcx
 10fc5d6:	mov    (%rcx),%rdx
 10fc5d9:	cmpl   $0x0,0x7c(%r13)
 10fc5de:	setne  %cl
 10fc5e1:	test   %rdx,%rdx
 10fc5e4:	setne  %sil
 10fc5e8:	and    %cl,%sil
 10fc5eb:	cmp    $0x1,%sil
 10fc5ef:	jne    10fc61c <myl_rc_native_retain+0x11c>
 10fc5f1:	test   %r15,%r15
 10fc5f4:	je     10fc930 <myl_rc_native_retain+0x430>
 10fc5fa:	cmpq   $0x0,0x58(%rax)
 10fc5ff:	jne    10fc930 <myl_rc_native_retain+0x430>
 10fc605:	mov    %r14,%rax
 10fc608:	sub    %r15,%rax
 10fc60b:	ja     10fc613 <myl_rc_native_retain+0x113>
 10fc60d:	mov    %r15,%rax
 10fc610:	sub    %r14,%rax
 10fc613:	cmp    %rdx,%rax
 10fc616:	jae    10fc8fa <myl_rc_native_retain+0x3fa>
 10fc61c:	mov    0x8(%r13),%r13
 10fc620:	jmp    10fc630 <myl_rc_native_retain+0x130>
 10fc622:	mov    %rbx,%rdi
 10fc625:	mov    %r12,%rsi
 10fc628:	call   10fb370 <myl_rc_native_shape>
 10fc62d:	mov    %rax,%r13
 10fc630:	test   %r13,%r13
 10fc633:	je     10fc75e <myl_rc_native_retain+0x25e>
 10fc639:	mov    %rbx,%rdi
 10fc63c:	mov    %r12,%rsi
 10fc63f:	call   10f5bf0 <myl_rc_native_has_unique>
 10fc644:	test   %eax,%eax
 10fc646:	jne    10fc930 <myl_rc_native_retain+0x430>
 10fc64c:	mov    (%r12),%rdx
 10fc650:	mov    %r14,%rdi
 10fc653:	xor    %esi,%esi
 10fc655:	call   10fcfa0 <memset@plt>
 10fc65a:	test   %rbx,%rbx
 10fc65d:	je     10fc930 <myl_rc_native_retain+0x430>
 10fc663:	mov    0x1608(%rbx),%rcx
 10fc66a:	test   %rcx,%rcx
 10fc66d:	je     10fc930 <myl_rc_native_retain+0x430>
 10fc673:	movabs $0xbf58476d1ce4e5b9,%rax
 10fc67d:	vxorps %xmm0,%xmm0,%xmm0
 10fc681:	vmovups %ymm0,-0x90(%rbp)
 10fc689:	vmovups %ymm0,-0xb0(%rbp)
 10fc691:	vmovups %ymm0,-0xd0(%rbp)
 10fc699:	vmovups %ymm0,-0xf0(%rbp)
 10fc6a1:	vmovups %ymm0,-0x110(%rbp)
 10fc6a9:	vmovups %ymm0,-0x130(%rbp)
 10fc6b1:	movq   $0x0,-0x70(%rbp)
 10fc6b9:	mov    %rbx,-0x68(%rbp)
 10fc6bd:	lea    -0x230(%rbp),%rdx
 10fc6c4:	mov    %rdx,-0x60(%rbp)
 10fc6c8:	movq   $0x8,-0x58(%rbp)
 10fc6d0:	vxorps %xmm0,%xmm0,%xmm0
 10fc6d4:	vmovups %xmm0,-0x50(%rbp)
 10fc6d9:	lea    -0x130(%rbp),%rdx
 10fc6e0:	mov    %rdx,-0x40(%rbp)
 10fc6e4:	mov    0x40(%rcx),%rdx
 10fc6e8:	test   %rdx,%rdx
 10fc6eb:	je     10fc774 <myl_rc_native_retain+0x274>
 10fc6f1:	mov    0x30(%rcx),%rsi
 10fc6f5:	mov    %r13,%rdi
 10fc6f8:	shr    $0x3,%rdi
 10fc6fc:	mov    %r13,%r8
 10fc6ff:	shr    $0x21,%r8
 10fc703:	xor    %rdi,%r8
 10fc706:	imul   %rax,%r8
 10fc70a:	mov    %r8,%rdi
 10fc70d:	shr    $0x1b,%rdi
 10fc711:	xor    %r8,%rdi
 10fc714:	xor    $0x1,%rdi
 10fc718:	dec    %rdx
 10fc71b:	and    %rdx,%rdi
 10fc71e:	lea    (%rdi,%rdi,4),%r8
 10fc722:	mov    (%rsi,%r8,8),%r8
 10fc726:	xor    %r12d,%r12d
 10fc729:	jmp    10fc73e <myl_rc_native_retain+0x23e>
 10fc72b:	nopl   0x0(%rax,%rax,1)
 10fc730:	inc    %rdi
 10fc733:	and    %rdx,%rdi
 10fc736:	lea    (%rdi,%rdi,4),%r8
 10fc73a:	mov    (%rsi,%r8,8),%r8
 10fc73e:	test   %r8,%r8
 10fc741:	je     10fc777 <myl_rc_native_retain+0x277>
 10fc743:	cmp    %r13,%r8
 10fc746:	jne    10fc730 <myl_rc_native_retain+0x230>
 10fc748:	lea    (%rdi,%rdi,4),%r8
 10fc74c:	cmpl   $0x1,0x20(%rsi,%r8,8)
 10fc752:	jne    10fc730 <myl_rc_native_retain+0x230>
 10fc754:	lea    (%rsi,%r8,8),%rdx
 10fc758:	mov    0x8(%rdx),%r12
 10fc75c:	jmp    10fc777 <myl_rc_native_retain+0x277>
 10fc75e:	mov    (%r12),%rdx
 10fc762:	xor    %r15d,%r15d
 10fc765:	mov    %r14,%rdi
 10fc768:	xor    %esi,%esi
 10fc76a:	call   10fcfa0 <memset@plt>
 10fc76f:	jmp    10fc8d2 <myl_rc_native_retain+0x3d2>
 10fc774:	xor    %r12d,%r12d
 10fc777:	mov    0x40(%rcx),%rdx
 10fc77b:	test   %rdx,%rdx
 10fc77e:	je     10fc930 <myl_rc_native_retain+0x430>
 10fc784:	mov    0x30(%rcx),%rcx
 10fc788:	mov    %r13,%rsi
 10fc78b:	shr    $0x3,%rsi
 10fc78f:	mov    %r13,%rdi
 10fc792:	shr    $0x21,%rdi
 10fc796:	xor    %rsi,%rdi
 10fc799:	imul   %rax,%rdi
 10fc79d:	mov    %rdi,%rax
 10fc7a0:	shr    $0x1b,%rax
 10fc7a4:	xor    %rdi,%rax
 10fc7a7:	xor    $0x1,%rax
 10fc7ab:	dec    %rdx
 10fc7ae:	jmp    10fc7b3 <myl_rc_native_retain+0x2b3>
 10fc7b0:	inc    %rax
 10fc7b3:	and    %rdx,%rax
 10fc7b6:	lea    (%rax,%rax,4),%rsi
 10fc7ba:	mov    (%rcx,%rsi,8),%rsi
 10fc7be:	test   %rsi,%rsi
 10fc7c1:	je     10fc930 <myl_rc_native_retain+0x430>
 10fc7c7:	cmp    %r13,%rsi
 10fc7ca:	jne    10fc7b0 <myl_rc_native_retain+0x2b0>
 10fc7cc:	lea    (%rax,%rax,4),%rsi
 10fc7d0:	cmpl   $0x1,0x20(%rcx,%rsi,8)
 10fc7d5:	jne    10fc7b0 <myl_rc_native_retain+0x2b0>
 10fc7d7:	test   %r12,%r12
 10fc7da:	je     10fc930 <myl_rc_native_retain+0x430>
 10fc7e0:	lea    (%rcx,%rsi,8),%rax
 10fc7e4:	mov    0x8(%rax),%rax
 10fc7e8:	test   %rax,%rax
 10fc7eb:	je     10fc930 <myl_rc_native_retain+0x430>
 10fc7f1:	mov    (%r12),%rcx
 10fc7f5:	cmp    (%rax),%rcx
 10fc7f8:	jne    10fc930 <myl_rc_native_retain+0x430>
 10fc7fe:	cmp    %r14,%r15
 10fc801:	je     10fc930 <myl_rc_native_retain+0x430>
 10fc807:	mov    %r14,-0x38(%rbp)
 10fc80b:	mov    $0x3,%r14d
 10fc811:	mov    -0x2c(%rbp),%eax
 10fc814:	cmp    0x70(%rbx),%eax
 10fc817:	ja     10fc8a8 <myl_rc_native_retain+0x3a8>
 10fc81d:	lea    -0x68(%rbp),%rdi
 10fc821:	mov    %r12,%rsi
 10fc824:	vzeroupper
 10fc827:	call   10f85b0 <prepare_frames>
 10fc82c:	mov    $0x1,%r14d
 10fc832:	test   %eax,%eax
 10fc834:	jne    10fc8a8 <myl_rc_native_retain+0x3a8>
 10fc836:	mov    $0x1,%r8d
 10fc83c:	mov    %rbx,%rdi
 10fc83f:	mov    %r12,%rsi
 10fc842:	mov    -0x38(%rbp),%r14
 10fc846:	mov    %r14,%rdx
 10fc849:	mov    %r15,%rcx
 10fc84c:	call   10f5dc0 <myl_rc_value_seed>
 10fc851:	mov    -0x2c(%rbp),%eax
 10fc854:	mov    %eax,-0x48(%rbp)
 10fc857:	lea    -0x68(%rbp),%rdi
 10fc85b:	mov    $0x10f9fc0,%r8d
 10fc861:	mov    %r12,%rsi
 10fc864:	mov    %r14,%rdx
 10fc867:	mov    %r15,%rcx
 10fc86a:	call   10f8770 <visit>
 10fc86f:	test   %eax,%eax
 10fc871:	jne    10fc880 <myl_rc_native_retain+0x380>
 10fc873:	lea    -0x68(%rbp),%rdi
 10fc877:	call   10f9560 <finish_clones>
 10fc87c:	test   %eax,%eax
 10fc87e:	je     10fc8e7 <myl_rc_native_retain+0x3e7>
 10fc880:	mov    %eax,%r14d
 10fc883:	mov    $0x1,%ecx
 10fc888:	mov    %rbx,%rdi
 10fc88b:	mov    %r13,%rsi
 10fc88e:	mov    -0x38(%rbp),%r15
 10fc892:	mov    %r15,%rdx
 10fc895:	call   10f5220 <myl_rc_edges_release>
 10fc89a:	mov    0x0(%r13),%rdx
 10fc89e:	mov    %r15,%rdi
 10fc8a1:	xor    %esi,%esi
 10fc8a3:	call   10fcfa0 <memset@plt>
 10fc8a8:	lea    -0x68(%rbp),%rdi
 10fc8ac:	mov    $0x1,%esi
 10fc8b1:	vzeroupper
 10fc8b4:	call   10f9900 <dispose_walk>
 10fc8b9:	mov    0x1608(%rbx),%rax
 10fc8c0:	test   %rax,%rax
 10fc8c3:	je     10fc930 <myl_rc_native_retain+0x430>
 10fc8c5:	xor    %r15d,%r15d
 10fc8c8:	cmpl   $0x0,0x78(%rax)
 10fc8cc:	jne    10fc8d2 <myl_rc_native_retain+0x3d2>
 10fc8ce:	mov    %r14d,0x78(%rax)
 10fc8d2:	mov    %r15d,%eax
 10fc8d5:	add    $0x208,%rsp
 10fc8dc:	pop    %rbx
 10fc8dd:	pop    %r12
 10fc8df:	pop    %r13
 10fc8e1:	pop    %r14
 10fc8e3:	pop    %r15
 10fc8e5:	pop    %rbp
 10fc8e6:	ret
 10fc8e7:	lea    -0x68(%rbp),%rdi
 10fc8eb:	xor    %esi,%esi
 10fc8ed:	call   10f9900 <dispose_walk>
 10fc8f2:	mov    $0x1,%r15d
 10fc8f8:	jmp    10fc8d2 <myl_rc_native_retain+0x3d2>
 10fc8fa:	mov    %r14,%r12
 10fc8fd:	mov    $0x3,%r14d
 10fc903:	mov    -0x2c(%rbp),%eax
 10fc906:	cmp    0x70(%rbx),%eax
 10fc909:	jbe    10fc997 <myl_rc_native_retain+0x497>
 10fc90f:	xor    %r15d,%r15d
 10fc912:	mov    %r12,%rdi
 10fc915:	xor    %esi,%esi
 10fc917:	call   10fcfa0 <memset@plt>
 10fc91c:	mov    %rbx,%rdi
 10fc91f:	call   10f5740 <myl_rc_drain>
 10fc924:	mov    0x1608(%rbx),%rax
 10fc92b:	test   %rax,%rax
 10fc92e:	jne    10fc8c8 <myl_rc_native_retain+0x3c8>
 10fc930:	vzeroupper
 10fc933:	call   10f3164 <myl_rc_invariant_failed>
 10fc938:	mov    (%r12),%rdx
 10fc93c:	test   %rdx,%rdx
 10fc93f:	je     10fc5d2 <myl_rc_native_retain+0xd2>
 10fc945:	mov    %r14,%rcx
 10fc948:	sub    %r15,%rcx
 10fc94b:	ja     10fc953 <myl_rc_native_retain+0x453>
 10fc94d:	mov    %r15,%rcx
 10fc950:	sub    %r14,%rcx
 10fc953:	cmp    %rdx,%rcx
 10fc956:	jb     10fc5d2 <myl_rc_native_retain+0xd2>
 10fc95c:	mov    -0x2c(%rbp),%eax
 10fc95f:	cmp    0x70(%rbx),%eax
 10fc962:	jbe    10fca82 <myl_rc_native_retain+0x582>
 10fc968:	xor    %r15d,%r15d
 10fc96b:	mov    %r14,%rdi
 10fc96e:	xor    %esi,%esi
 10fc970:	call   10fcfa0 <memset@plt>
 10fc975:	mov    0x1608(%rbx),%rax
 10fc97c:	test   %rax,%rax
 10fc97f:	je     10fc930 <myl_rc_native_retain+0x430>
 10fc981:	cmpl   $0x0,0x78(%rax)
 10fc985:	jne    10fc8d2 <myl_rc_native_retain+0x3d2>
 10fc98b:	movl   $0x3,0x78(%rax)
 10fc992:	jmp    10fc8d2 <myl_rc_native_retain+0x3d2>
 10fc997:	mov    %r12,%r14
 10fc99a:	mov    %r12,%rdi
 10fc99d:	mov    %r15,%rsi
 10fc9a0:	mov    %rdx,-0x38(%rbp)
 10fc9a4:	call   10fcfb0 <memcpy@plt>
 10fc9a9:	cmpl   $0x0,0x78(%r13)
 10fc9ae:	je     10fca6f <myl_rc_native_retain+0x56f>
 10fc9b4:	xor    %eax,%eax
 10fc9b6:	mov    0x38(%r13,%rax,8),%rcx
 10fc9bb:	movq   $0x0,(%r14,%rcx,1)
 10fc9c3:	inc    %rax
 10fc9c6:	mov    0x78(%r13),%ecx
 10fc9ca:	cmp    %rcx,%rax
 10fc9cd:	jb     10fc9b6 <myl_rc_native_retain+0x4b6>
 10fc9cf:	test   %ecx,%ecx
 10fc9d1:	je     10fca6f <myl_rc_native_retain+0x56f>
 10fc9d7:	movabs $0x4000000000000000,%rax
 10fc9e1:	xor    %ecx,%ecx
 10fc9e3:	lea    0x2(%rax),%rdx
 10fc9e7:	jmp    10fca10 <myl_rc_native_retain+0x510>
 10fc9e9:	cmpq   $0x0,-0x18(%rsi)
 10fc9ee:	je     10fc930 <myl_rc_native_retain+0x430>
 10fc9f4:	inc    %rdi
 10fc9f7:	mov    %rdi,-0x20(%rsi)
 10fc9fb:	mov    0x38(%r13,%rcx,8),%rdi
 10fca00:	mov    %rsi,(%r14,%rdi,1)
 10fca04:	inc    %rcx
 10fca07:	mov    0x78(%r13),%esi
 10fca0b:	cmp    %rsi,%rcx
 10fca0e:	jae    10fca6f <myl_rc_native_retain+0x56f>
 10fca10:	mov    0x38(%r13,%rcx,8),%rdi
 10fca15:	mov    (%r15,%rdi,1),%rsi
 10fca19:	test   %rsi,%rsi
 10fca1c:	je     10fca00 <myl_rc_native_retain+0x500>
 10fca1e:	mov    -0x10(%rsi),%r8
 10fca22:	test   %rax,%r8
 10fca25:	je     10fca3b <myl_rc_native_retain+0x53b>
 10fca27:	mov    %r8,%r9
 10fca2a:	shr    $0x28,%r9
 10fca2e:	and    $0xfffff,%r9d
 10fca35:	cmp    -0x2c(%rbp),%r9d
 10fca39:	ja     10fca98 <myl_rc_native_retain+0x598>
 10fca3b:	test   %rdx,%r8
 10fca3e:	jne    10fca00 <myl_rc_native_retain+0x500>
 10fca40:	cmpq   $0x0,0x1608(%rbx)
 10fca48:	je     10fc930 <myl_rc_native_retain+0x430>
 10fca4e:	test   $0x1,%r8b
 10fca52:	jne    10fc930 <myl_rc_native_retain+0x430>
 10fca58:	mov    -0x20(%rsi),%rdi
 10fca5c:	test   %rdi,%rdi
 10fca5f:	je     10fc9e9 <myl_rc_native_retain+0x4e9>
 10fca61:	cmp    $0xffffffffffffffff,%rdi
 10fca65:	jne    10fc9f4 <myl_rc_native_retain+0x4f4>
 10fca67:	mov    $0x2,%r14d
 10fca6d:	jmp    10fca9e <myl_rc_native_retain+0x59e>
 10fca6f:	mov    %rbx,%rdi
 10fca72:	call   10f5740 <myl_rc_drain>
 10fca77:	mov    $0x1,%r15d
 10fca7d:	jmp    10fc8d2 <myl_rc_native_retain+0x3d2>
 10fca82:	mov    %r14,%rdi
 10fca85:	mov    %r15,%rsi
 10fca88:	call   10fcfb0 <memcpy@plt>
 10fca8d:	mov    $0x1,%r15d
 10fca93:	jmp    10fc8d2 <myl_rc_native_retain+0x3d2>
 10fca98:	mov    $0x3,%r14d
 10fca9e:	mov    $0x1,%ecx
 10fcaa3:	mov    %rbx,%rdi
 10fcaa6:	mov    %r13,%rsi
 10fcaa9:	mov    %r12,%rdx
 10fcaac:	call   10f55f0 <myl_rc_flat_edges_release>
 10fcab1:	mov    -0x38(%rbp),%rdx
 10fcab5:	jmp    10fc90f <myl_rc_native_retain+0x40f>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
