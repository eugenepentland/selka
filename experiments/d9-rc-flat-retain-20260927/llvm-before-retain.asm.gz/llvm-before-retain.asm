
.tmp-mut-argument/joined-flat-measure/schematic-llvm-production:     file format elf64-x86-64


Disassembly of section .text:

00000000010fc500 <myl_rc_native_retain>:
 10fc500:	push   %rbp
 10fc501:	mov    %rsp,%rbp
 10fc504:	push   %r15
 10fc506:	push   %r14
 10fc508:	push   %r13
 10fc50a:	push   %r12
 10fc50c:	push   %rbx
 10fc50d:	sub    $0x208,%rsp
 10fc514:	mov    %r8d,-0x2c(%rbp)
 10fc518:	mov    %rcx,%r15
 10fc51b:	mov    %rdx,%r14
 10fc51e:	mov    %rsi,%r12
 10fc521:	mov    %rdi,%rbx
 10fc524:	test   %rdi,%rdi
 10fc527:	je     10fc5d7 <myl_rc_native_retain+0xd7>
 10fc52d:	mov    0x1608(%rbx),%rax
 10fc534:	test   %rax,%rax
 10fc537:	sete   %cl
 10fc53a:	test   %r12,%r12
 10fc53d:	sete   %dl
 10fc540:	or     %cl,%dl
 10fc542:	jne    10fc5d7 <myl_rc_native_retain+0xd7>
 10fc548:	mov    0x40(%rax),%rcx
 10fc54c:	test   %rcx,%rcx
 10fc54f:	je     10fc5d7 <myl_rc_native_retain+0xd7>
 10fc555:	mov    0x30(%rax),%rdx
 10fc559:	mov    %r12,%rsi
 10fc55c:	shr    $0x3,%rsi
 10fc560:	mov    %r12,%rdi
 10fc563:	shr    $0x21,%rdi
 10fc567:	xor    %rsi,%rdi
 10fc56a:	movabs $0xbf58476d1ce4e5b9,%r8
 10fc574:	imul   %rdi,%r8
 10fc578:	mov    %r8,%rsi
 10fc57b:	shr    $0x1b,%rsi
 10fc57f:	xor    %r8,%rsi
 10fc582:	xor    $0x2,%rsi
 10fc586:	dec    %rcx
 10fc589:	jmp    10fc593 <myl_rc_native_retain+0x93>
 10fc58b:	nopl   0x0(%rax,%rax,1)
 10fc590:	inc    %rsi
 10fc593:	and    %rcx,%rsi
 10fc596:	lea    (%rsi,%rsi,4),%rdi
 10fc59a:	mov    (%rdx,%rdi,8),%rdi
 10fc59e:	test   %rdi,%rdi
 10fc5a1:	je     10fc5d7 <myl_rc_native_retain+0xd7>
 10fc5a3:	cmp    %r12,%rdi
 10fc5a6:	jne    10fc590 <myl_rc_native_retain+0x90>
 10fc5a8:	lea    (%rsi,%rsi,4),%rdi
 10fc5ac:	cmpl   $0x2,0x20(%rdx,%rdi,8)
 10fc5b1:	jne    10fc590 <myl_rc_native_retain+0x90>
 10fc5b3:	lea    (%rdx,%rdi,8),%rcx
 10fc5b7:	mov    0x8(%rcx),%rcx
 10fc5bb:	test   %rcx,%rcx
 10fc5be:	je     10fc5d7 <myl_rc_native_retain+0xd7>
 10fc5c0:	cmpl   $0x0,0x78(%rcx)
 10fc5c4:	jne    10fc5d1 <myl_rc_native_retain+0xd1>
 10fc5c6:	cmpq   $0x0,0x60(%rax)
 10fc5cb:	je     10fc8aa <myl_rc_native_retain+0x3aa>
 10fc5d1:	mov    0x8(%rcx),%r13
 10fc5d5:	jmp    10fc5e5 <myl_rc_native_retain+0xe5>
 10fc5d7:	mov    %rbx,%rdi
 10fc5da:	mov    %r12,%rsi
 10fc5dd:	call   10fb370 <myl_rc_native_shape>
 10fc5e2:	mov    %rax,%r13
 10fc5e5:	test   %r13,%r13
 10fc5e8:	je     10fc70e <myl_rc_native_retain+0x20e>
 10fc5ee:	mov    %rbx,%rdi
 10fc5f1:	mov    %r12,%rsi
 10fc5f4:	call   10f5bf0 <myl_rc_native_has_unique>
 10fc5f9:	test   %eax,%eax
 10fc5fb:	jne    10fc914 <myl_rc_native_retain+0x414>
 10fc601:	mov    (%r12),%rdx
 10fc605:	mov    %r14,%rdi
 10fc608:	xor    %esi,%esi
 10fc60a:	call   10fce00 <memset@plt>
 10fc60f:	test   %rbx,%rbx
 10fc612:	je     10fc914 <myl_rc_native_retain+0x414>
 10fc618:	mov    0x1608(%rbx),%rcx
 10fc61f:	test   %rcx,%rcx
 10fc622:	je     10fc914 <myl_rc_native_retain+0x414>
 10fc628:	movabs $0xbf58476d1ce4e5b9,%rax
 10fc632:	vxorps %xmm0,%xmm0,%xmm0
 10fc636:	vmovups %ymm0,-0x90(%rbp)
 10fc63e:	vmovups %ymm0,-0xb0(%rbp)
 10fc646:	vmovups %ymm0,-0xd0(%rbp)
 10fc64e:	vmovups %ymm0,-0xf0(%rbp)
 10fc656:	vmovups %ymm0,-0x110(%rbp)
 10fc65e:	vmovups %ymm0,-0x130(%rbp)
 10fc666:	movq   $0x0,-0x70(%rbp)
 10fc66e:	mov    %rbx,-0x60(%rbp)
 10fc672:	lea    -0x230(%rbp),%rdx
 10fc679:	mov    %rdx,-0x58(%rbp)
 10fc67d:	movq   $0x8,-0x50(%rbp)
 10fc685:	vxorps %xmm0,%xmm0,%xmm0
 10fc689:	vmovups %xmm0,-0x48(%rbp)
 10fc68e:	lea    -0x130(%rbp),%rdx
 10fc695:	mov    %rdx,-0x38(%rbp)
 10fc699:	mov    0x40(%rcx),%rdx
 10fc69d:	test   %rdx,%rdx
 10fc6a0:	je     10fc724 <myl_rc_native_retain+0x224>
 10fc6a6:	mov    0x30(%rcx),%r9
 10fc6aa:	mov    %r13,%rdi
 10fc6ad:	shr    $0x3,%rdi
 10fc6b1:	mov    %r13,%r8
 10fc6b4:	shr    $0x21,%r8
 10fc6b8:	xor    %rdi,%r8
 10fc6bb:	imul   %rax,%r8
 10fc6bf:	mov    %r8,%rdi
 10fc6c2:	shr    $0x1b,%rdi
 10fc6c6:	xor    %r8,%rdi
 10fc6c9:	xor    $0x1,%rdi
 10fc6cd:	dec    %rdx
 10fc6d0:	and    %rdx,%rdi
 10fc6d3:	lea    (%rdi,%rdi,4),%r8
 10fc6d7:	mov    (%r9,%r8,8),%r8
 10fc6db:	xor    %esi,%esi
 10fc6dd:	jmp    10fc6ee <myl_rc_native_retain+0x1ee>
 10fc6df:	nop
 10fc6e0:	inc    %rdi
 10fc6e3:	and    %rdx,%rdi
 10fc6e6:	lea    (%rdi,%rdi,4),%r8
 10fc6ea:	mov    (%r9,%r8,8),%r8
 10fc6ee:	test   %r8,%r8
 10fc6f1:	je     10fc726 <myl_rc_native_retain+0x226>
 10fc6f3:	cmp    %r13,%r8
 10fc6f6:	jne    10fc6e0 <myl_rc_native_retain+0x1e0>
 10fc6f8:	lea    (%rdi,%rdi,4),%r8
 10fc6fc:	cmpl   $0x1,0x20(%r9,%r8,8)
 10fc702:	jne    10fc6e0 <myl_rc_native_retain+0x1e0>
 10fc704:	lea    (%r9,%r8,8),%rdx
 10fc708:	mov    0x8(%rdx),%rsi
 10fc70c:	jmp    10fc726 <myl_rc_native_retain+0x226>
 10fc70e:	mov    (%r12),%rdx
 10fc712:	xor    %r12d,%r12d
 10fc715:	mov    %r14,%rdi
 10fc718:	xor    %esi,%esi
 10fc71a:	call   10fce00 <memset@plt>
 10fc71f:	jmp    10fc882 <myl_rc_native_retain+0x382>
 10fc724:	xor    %esi,%esi
 10fc726:	mov    0x40(%rcx),%rdx
 10fc72a:	test   %rdx,%rdx
 10fc72d:	je     10fc914 <myl_rc_native_retain+0x414>
 10fc733:	mov    0x30(%rcx),%rcx
 10fc737:	mov    %r13,%r8
 10fc73a:	shr    $0x3,%r8
 10fc73e:	mov    %r13,%rdi
 10fc741:	shr    $0x21,%rdi
 10fc745:	xor    %r8,%rdi
 10fc748:	imul   %rax,%rdi
 10fc74c:	mov    %rdi,%rax
 10fc74f:	shr    $0x1b,%rax
 10fc753:	xor    %rdi,%rax
 10fc756:	xor    $0x1,%rax
 10fc75a:	dec    %rdx
 10fc75d:	jmp    10fc763 <myl_rc_native_retain+0x263>
 10fc75f:	nop
 10fc760:	inc    %rax
 10fc763:	and    %rdx,%rax
 10fc766:	lea    (%rax,%rax,4),%rdi
 10fc76a:	mov    (%rcx,%rdi,8),%rdi
 10fc76e:	test   %rdi,%rdi
 10fc771:	je     10fc914 <myl_rc_native_retain+0x414>
 10fc777:	cmp    %r13,%rdi
 10fc77a:	jne    10fc760 <myl_rc_native_retain+0x260>
 10fc77c:	lea    (%rax,%rax,4),%rdi
 10fc780:	cmpl   $0x1,0x20(%rcx,%rdi,8)
 10fc785:	jne    10fc760 <myl_rc_native_retain+0x260>
 10fc787:	test   %rsi,%rsi
 10fc78a:	je     10fc914 <myl_rc_native_retain+0x414>
 10fc790:	lea    (%rcx,%rdi,8),%rax
 10fc794:	mov    0x8(%rax),%rax
 10fc798:	test   %rax,%rax
 10fc79b:	je     10fc914 <myl_rc_native_retain+0x414>
 10fc7a1:	mov    (%rsi),%rcx
 10fc7a4:	cmp    (%rax),%rcx
 10fc7a7:	jne    10fc914 <myl_rc_native_retain+0x414>
 10fc7ad:	cmp    %r14,%r15
 10fc7b0:	je     10fc914 <myl_rc_native_retain+0x414>
 10fc7b6:	mov    %r15,%r12
 10fc7b9:	mov    $0x3,%r15d
 10fc7bf:	mov    -0x2c(%rbp),%eax
 10fc7c2:	cmp    0x70(%rbx),%eax
 10fc7c5:	ja     10fc854 <myl_rc_native_retain+0x354>
 10fc7cb:	lea    -0x60(%rbp),%rdi
 10fc7cf:	mov    %rsi,%r15
 10fc7d2:	vzeroupper
 10fc7d5:	call   10f85b0 <prepare_frames>
 10fc7da:	mov    %r15,%rsi
 10fc7dd:	mov    $0x1,%r15d
 10fc7e3:	test   %eax,%eax
 10fc7e5:	jne    10fc854 <myl_rc_native_retain+0x354>
 10fc7e7:	mov    $0x1,%r8d
 10fc7ed:	mov    %rbx,%rdi
 10fc7f0:	mov    %r14,%rdx
 10fc7f3:	mov    %r12,%r15
 10fc7f6:	mov    %r12,%rcx
 10fc7f9:	mov    %rsi,%r12
 10fc7fc:	call   10f5dc0 <myl_rc_value_seed>
 10fc801:	mov    -0x2c(%rbp),%eax
 10fc804:	mov    %eax,-0x40(%rbp)
 10fc807:	lea    -0x60(%rbp),%rdi
 10fc80b:	mov    $0x10f9fc0,%r8d
 10fc811:	mov    %r12,%rsi
 10fc814:	mov    %r14,%rdx
 10fc817:	mov    %r15,%rcx
 10fc81a:	call   10f8770 <visit>
 10fc81f:	test   %eax,%eax
 10fc821:	jne    10fc830 <myl_rc_native_retain+0x330>
 10fc823:	lea    -0x60(%rbp),%rdi
 10fc827:	call   10f9560 <finish_clones>
 10fc82c:	test   %eax,%eax
 10fc82e:	je     10fc897 <myl_rc_native_retain+0x397>
 10fc830:	mov    %eax,%r15d
 10fc833:	mov    $0x1,%ecx
 10fc838:	mov    %rbx,%rdi
 10fc83b:	mov    %r13,%rsi
 10fc83e:	mov    %r14,%rdx
 10fc841:	call   10f5220 <myl_rc_edges_release>
 10fc846:	mov    0x0(%r13),%rdx
 10fc84a:	mov    %r14,%rdi
 10fc84d:	xor    %esi,%esi
 10fc84f:	call   10fce00 <memset@plt>
 10fc854:	lea    -0x60(%rbp),%rdi
 10fc858:	mov    $0x1,%esi
 10fc85d:	vzeroupper
 10fc860:	call   10f9900 <dispose_walk>
 10fc865:	mov    0x1608(%rbx),%rax
 10fc86c:	test   %rax,%rax
 10fc86f:	je     10fc914 <myl_rc_native_retain+0x414>
 10fc875:	xor    %r12d,%r12d
 10fc878:	cmpl   $0x0,0x78(%rax)
 10fc87c:	jne    10fc882 <myl_rc_native_retain+0x382>
 10fc87e:	mov    %r15d,0x78(%rax)
 10fc882:	mov    %r12d,%eax
 10fc885:	add    $0x208,%rsp
 10fc88c:	pop    %rbx
 10fc88d:	pop    %r12
 10fc88f:	pop    %r13
 10fc891:	pop    %r14
 10fc893:	pop    %r15
 10fc895:	pop    %rbp
 10fc896:	ret
 10fc897:	lea    -0x60(%rbp),%rdi
 10fc89b:	xor    %esi,%esi
 10fc89d:	call   10f9900 <dispose_walk>
 10fc8a2:	mov    $0x1,%r12d
 10fc8a8:	jmp    10fc882 <myl_rc_native_retain+0x382>
 10fc8aa:	mov    (%r12),%rdx
 10fc8ae:	test   %rdx,%rdx
 10fc8b1:	je     10fc5d1 <myl_rc_native_retain+0xd1>
 10fc8b7:	mov    %r14,%rax
 10fc8ba:	sub    %r15,%rax
 10fc8bd:	ja     10fc8c5 <myl_rc_native_retain+0x3c5>
 10fc8bf:	mov    %r15,%rax
 10fc8c2:	sub    %r14,%rax
 10fc8c5:	cmp    %rdx,%rax
 10fc8c8:	jb     10fc5d1 <myl_rc_native_retain+0xd1>
 10fc8ce:	mov    -0x2c(%rbp),%eax
 10fc8d1:	cmp    0x70(%rbx),%eax
 10fc8d4:	jbe    10fc8fe <myl_rc_native_retain+0x3fe>
 10fc8d6:	xor    %r12d,%r12d
 10fc8d9:	mov    %r14,%rdi
 10fc8dc:	xor    %esi,%esi
 10fc8de:	call   10fce00 <memset@plt>
 10fc8e3:	mov    0x1608(%rbx),%rax
 10fc8ea:	test   %rax,%rax
 10fc8ed:	je     10fc914 <myl_rc_native_retain+0x414>
 10fc8ef:	cmpl   $0x0,0x78(%rax)
 10fc8f3:	jne    10fc882 <myl_rc_native_retain+0x382>
 10fc8f5:	movl   $0x3,0x78(%rax)
 10fc8fc:	jmp    10fc882 <myl_rc_native_retain+0x382>
 10fc8fe:	mov    %r14,%rdi
 10fc901:	mov    %r15,%rsi
 10fc904:	call   10fce10 <memcpy@plt>
 10fc909:	mov    $0x1,%r12d
 10fc90f:	jmp    10fc882 <myl_rc_native_retain+0x382>
 10fc914:	vzeroupper
 10fc917:	call   10f3164 <myl_rc_invariant_failed>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
