
/home/epentland/ai/canopy/mylang-worktrees/goal110-g4-rf-20261004/.mylang-cache/goal110-g4-rf/runner/bin/text-my-llvm:     file format elf64-x86-64


Disassembly of section .text:

0000000001093d60 <join_short>:
 1093d60:	48 85 d2             	test   %rdx,%rdx
 1093d63:	0f 84 91 05 00 00    	je     10942fa <join_short+0x59a>
 1093d69:	55                   	push   %rbp
 1093d6a:	48 89 e5             	mov    %rsp,%rbp
 1093d6d:	53                   	push   %rbx
 1093d6e:	49 83 f8 08          	cmp    $0x8,%r8
 1093d72:	72 50                	jb     1093dc4 <join_short+0x64>
 1093d74:	48 8b 01             	mov    (%rcx),%rax
 1093d77:	4a 8b 4c 01 f8       	mov    -0x8(%rcx,%r8,1),%rcx
 1093d7c:	4c 8b 16             	mov    (%rsi),%r10
 1093d7f:	4d 8b 4a 08          	mov    0x8(%r10),%r9
 1093d83:	4d 85 c9             	test   %r9,%r9
 1093d86:	0f 84 11 01 00 00    	je     1093e9d <join_short+0x13d>
 1093d8c:	41 f6 42 10 04       	testb  $0x4,0x10(%r10)
 1093d91:	0f 85 dd 00 00 00    	jne    1093e74 <join_short+0x114>
 1093d97:	49 83 c2 18          	add    $0x18,%r10
 1093d9b:	49 83 f9 07          	cmp    $0x7,%r9
 1093d9f:	0f 87 e8 00 00 00    	ja     1093e8d <join_short+0x12d>
 1093da5:	49 83 f9 03          	cmp    $0x3,%r9
 1093da9:	0f 86 e4 01 00 00    	jbe    1093f93 <join_short+0x233>
 1093daf:	45 8b 1a             	mov    (%r10),%r11d
 1093db2:	47 8b 54 0a fc       	mov    -0x4(%r10,%r9,1),%r10d
 1093db7:	44 89 1f             	mov    %r11d,(%rdi)
 1093dba:	46 89 54 0f fc       	mov    %r10d,-0x4(%rdi,%r9,1)
 1093dbf:	e9 d9 00 00 00       	jmp    1093e9d <join_short+0x13d>
 1093dc4:	49 83 f8 04          	cmp    $0x4,%r8
 1093dc8:	72 4f                	jb     1093e19 <join_short+0xb9>
 1093dca:	8b 01                	mov    (%rcx),%eax
 1093dcc:	42 8b 4c 01 fc       	mov    -0x4(%rcx,%r8,1),%ecx
 1093dd1:	4c 8b 16             	mov    (%rsi),%r10
 1093dd4:	4d 8b 4a 08          	mov    0x8(%r10),%r9
 1093dd8:	4d 85 c9             	test   %r9,%r9
 1093ddb:	0f 84 f1 01 00 00    	je     1093fd2 <join_short+0x272>
 1093de1:	41 f6 42 10 04       	testb  $0x4,0x10(%r10)
 1093de6:	0f 85 bd 01 00 00    	jne    1093fa9 <join_short+0x249>
 1093dec:	49 83 c2 18          	add    $0x18,%r10
 1093df0:	49 83 f9 07          	cmp    $0x7,%r9
 1093df4:	0f 87 c8 01 00 00    	ja     1093fc2 <join_short+0x262>
 1093dfa:	49 83 f9 03          	cmp    $0x3,%r9
 1093dfe:	0f 86 31 03 00 00    	jbe    1094135 <join_short+0x3d5>
 1093e04:	45 8b 1a             	mov    (%r10),%r11d
 1093e07:	47 8b 54 0a fc       	mov    -0x4(%r10,%r9,1),%r10d
 1093e0c:	44 89 1f             	mov    %r11d,(%rdi)
 1093e0f:	46 89 54 0f fc       	mov    %r10d,-0x4(%rdi,%r9,1)
 1093e14:	e9 b9 01 00 00       	jmp    1093fd2 <join_short+0x272>
 1093e19:	49 83 f8 02          	cmp    $0x2,%r8
 1093e1d:	0f 82 40 01 00 00    	jb     1093f63 <join_short+0x203>
 1093e23:	0f b7 01             	movzwl (%rcx),%eax
 1093e26:	42 0f b7 4c 01 fe    	movzwl -0x2(%rcx,%r8,1),%ecx
 1093e2c:	4c 8b 16             	mov    (%rsi),%r10
 1093e2f:	4d 8b 4a 08          	mov    0x8(%r10),%r9
 1093e33:	4d 85 c9             	test   %r9,%r9
 1093e36:	0f 84 38 03 00 00    	je     1094174 <join_short+0x414>
 1093e3c:	41 f6 42 10 04       	testb  $0x4,0x10(%r10)
 1093e41:	0f 85 04 03 00 00    	jne    109414b <join_short+0x3eb>
 1093e47:	49 83 c2 18          	add    $0x18,%r10
 1093e4b:	49 83 f9 07          	cmp    $0x7,%r9
 1093e4f:	0f 87 0f 03 00 00    	ja     1094164 <join_short+0x404>
 1093e55:	49 83 f9 03          	cmp    $0x3,%r9
 1093e59:	0f 86 2c 04 00 00    	jbe    109428b <join_short+0x52b>
 1093e5f:	45 8b 1a             	mov    (%r10),%r11d
 1093e62:	47 8b 54 0a fc       	mov    -0x4(%r10,%r9,1),%r10d
 1093e67:	44 89 1f             	mov    %r11d,(%rdi)
 1093e6a:	46 89 54 0f fc       	mov    %r10d,-0x4(%rdi,%r9,1)
 1093e6f:	e9 00 03 00 00       	jmp    1094174 <join_short+0x414>
 1093e74:	4d 8b 5a 18          	mov    0x18(%r10),%r11
 1093e78:	45 8b 52 14          	mov    0x14(%r10),%r10d
 1093e7c:	4d 01 da             	add    %r11,%r10
 1093e7f:	49 83 c2 18          	add    $0x18,%r10
 1093e83:	49 83 f9 07          	cmp    $0x7,%r9
 1093e87:	0f 86 18 ff ff ff    	jbe    1093da5 <join_short+0x45>
 1093e8d:	4d 8b 1a             	mov    (%r10),%r11
 1093e90:	4f 8b 54 0a f8       	mov    -0x8(%r10,%r9,1),%r10
 1093e95:	4c 89 1f             	mov    %r11,(%rdi)
 1093e98:	4e 89 54 0f f8       	mov    %r10,-0x8(%rdi,%r9,1)
 1093e9d:	48 83 fa 01          	cmp    $0x1,%rdx
 1093ea1:	0f 84 51 04 00 00    	je     10942f8 <join_short+0x598>
 1093ea7:	4c 01 cf             	add    %r9,%rdi
 1093eaa:	41 b9 01 00 00 00    	mov    $0x1,%r9d
 1093eb0:	eb 2d                	jmp    1093edf <join_short+0x17f>
 1093eb2:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1093eb9:	1f 84 00 00 00 00 00 
 1093ec0:	49 8b 1b             	mov    (%r11),%rbx
 1093ec3:	4f 8b 5c 13 f8       	mov    -0x8(%r11,%r10,1),%r11
 1093ec8:	48 89 1f             	mov    %rbx,(%rdi)
 1093ecb:	4e 89 5c 17 f8       	mov    %r11,-0x8(%rdi,%r10,1)
 1093ed0:	4c 01 d7             	add    %r10,%rdi
 1093ed3:	49 ff c1             	inc    %r9
 1093ed6:	4c 39 ca             	cmp    %r9,%rdx
 1093ed9:	0f 84 19 04 00 00    	je     10942f8 <join_short+0x598>
 1093edf:	48 89 07             	mov    %rax,(%rdi)
 1093ee2:	4a 89 4c 07 f8       	mov    %rcx,-0x8(%rdi,%r8,1)
 1093ee7:	4c 01 c7             	add    %r8,%rdi
 1093eea:	4e 8b 1c ce          	mov    (%rsi,%r9,8),%r11
 1093eee:	4d 8b 53 08          	mov    0x8(%r11),%r10
 1093ef2:	4d 85 d2             	test   %r10,%r10
 1093ef5:	74 d9                	je     1093ed0 <join_short+0x170>
 1093ef7:	41 f6 43 10 04       	testb  $0x4,0x10(%r11)
 1093efc:	75 12                	jne    1093f10 <join_short+0x1b0>
 1093efe:	49 83 c3 18          	add    $0x18,%r11
 1093f02:	49 83 fa 08          	cmp    $0x8,%r10
 1093f06:	73 b8                	jae    1093ec0 <join_short+0x160>
 1093f08:	eb 1b                	jmp    1093f25 <join_short+0x1c5>
 1093f0a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
 1093f10:	49 8b 5b 18          	mov    0x18(%r11),%rbx
 1093f14:	45 8b 5b 14          	mov    0x14(%r11),%r11d
 1093f18:	49 01 db             	add    %rbx,%r11
 1093f1b:	49 83 c3 18          	add    $0x18,%r11
 1093f1f:	49 83 fa 08          	cmp    $0x8,%r10
 1093f23:	73 9b                	jae    1093ec0 <join_short+0x160>
 1093f25:	49 83 fa 04          	cmp    $0x4,%r10
 1093f29:	72 11                	jb     1093f3c <join_short+0x1dc>
 1093f2b:	41 8b 1b             	mov    (%r11),%ebx
 1093f2e:	47 8b 5c 13 fc       	mov    -0x4(%r11,%r10,1),%r11d
 1093f33:	89 1f                	mov    %ebx,(%rdi)
 1093f35:	46 89 5c 17 fc       	mov    %r11d,-0x4(%rdi,%r10,1)
 1093f3a:	eb 94                	jmp    1093ed0 <join_short+0x170>
 1093f3c:	49 83 fa 01          	cmp    $0x1,%r10
 1093f40:	75 09                	jne    1093f4b <join_short+0x1eb>
 1093f42:	45 0f b6 1b          	movzbl (%r11),%r11d
 1093f46:	44 88 1f             	mov    %r11b,(%rdi)
 1093f49:	eb 85                	jmp    1093ed0 <join_short+0x170>
 1093f4b:	41 0f b7 1b          	movzwl (%r11),%ebx
 1093f4f:	47 0f b7 5c 13 fe    	movzwl -0x2(%r11,%r10,1),%r11d
 1093f55:	66 89 1f             	mov    %bx,(%rdi)
 1093f58:	66 46 89 5c 17 fe    	mov    %r11w,-0x2(%rdi,%r10,1)
 1093f5e:	e9 6d ff ff ff       	jmp    1093ed0 <join_short+0x170>
 1093f63:	4d 85 c0             	test   %r8,%r8
 1093f66:	0f 84 27 01 00 00    	je     1094093 <join_short+0x333>
 1093f6c:	0f b6 01             	movzbl (%rcx),%eax
 1093f6f:	4c 8b 06             	mov    (%rsi),%r8
 1093f72:	49 8b 48 08          	mov    0x8(%r8),%rcx
 1093f76:	48 85 c9             	test   %rcx,%rcx
 1093f79:	0f 84 73 03 00 00    	je     10942f2 <join_short+0x592>
 1093f7f:	41 f6 40 10 04       	testb  $0x4,0x10(%r8)
 1093f84:	0f 85 c2 02 00 00    	jne    109424c <join_short+0x4ec>
 1093f8a:	49 83 c0 18          	add    $0x18,%r8
 1093f8e:	e9 c8 02 00 00       	jmp    109425b <join_short+0x4fb>
 1093f93:	49 83 f9 01          	cmp    $0x1,%r9
 1093f97:	0f 85 96 02 00 00    	jne    1094233 <join_short+0x4d3>
 1093f9d:	45 0f b6 12          	movzbl (%r10),%r10d
 1093fa1:	44 88 17             	mov    %r10b,(%rdi)
 1093fa4:	e9 f4 fe ff ff       	jmp    1093e9d <join_short+0x13d>
 1093fa9:	4d 8b 5a 18          	mov    0x18(%r10),%r11
 1093fad:	45 8b 52 14          	mov    0x14(%r10),%r10d
 1093fb1:	4d 01 da             	add    %r11,%r10
 1093fb4:	49 83 c2 18          	add    $0x18,%r10
 1093fb8:	49 83 f9 07          	cmp    $0x7,%r9
 1093fbc:	0f 86 38 fe ff ff    	jbe    1093dfa <join_short+0x9a>
 1093fc2:	4d 8b 1a             	mov    (%r10),%r11
 1093fc5:	4f 8b 54 0a f8       	mov    -0x8(%r10,%r9,1),%r10
 1093fca:	4c 89 1f             	mov    %r11,(%rdi)
 1093fcd:	4e 89 54 0f f8       	mov    %r10,-0x8(%rdi,%r9,1)
 1093fd2:	48 83 fa 01          	cmp    $0x1,%rdx
 1093fd6:	0f 84 1c 03 00 00    	je     10942f8 <join_short+0x598>
 1093fdc:	4c 01 cf             	add    %r9,%rdi
 1093fdf:	41 b9 01 00 00 00    	mov    $0x1,%r9d
 1093fe5:	eb 28                	jmp    109400f <join_short+0x2af>
 1093fe7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
 1093fee:	00 00 
 1093ff0:	49 8b 1b             	mov    (%r11),%rbx
 1093ff3:	4f 8b 5c 13 f8       	mov    -0x8(%r11,%r10,1),%r11
 1093ff8:	48 89 1f             	mov    %rbx,(%rdi)
 1093ffb:	4e 89 5c 17 f8       	mov    %r11,-0x8(%rdi,%r10,1)
 1094000:	4c 01 d7             	add    %r10,%rdi
 1094003:	49 ff c1             	inc    %r9
 1094006:	4c 39 ca             	cmp    %r9,%rdx
 1094009:	0f 84 e9 02 00 00    	je     10942f8 <join_short+0x598>
 109400f:	89 07                	mov    %eax,(%rdi)
 1094011:	42 89 4c 07 fc       	mov    %ecx,-0x4(%rdi,%r8,1)
 1094016:	4c 01 c7             	add    %r8,%rdi
 1094019:	4e 8b 1c ce          	mov    (%rsi,%r9,8),%r11
 109401d:	4d 8b 53 08          	mov    0x8(%r11),%r10
 1094021:	4d 85 d2             	test   %r10,%r10
 1094024:	74 da                	je     1094000 <join_short+0x2a0>
 1094026:	41 f6 43 10 04       	testb  $0x4,0x10(%r11)
 109402b:	75 13                	jne    1094040 <join_short+0x2e0>
 109402d:	49 83 c3 18          	add    $0x18,%r11
 1094031:	49 83 fa 08          	cmp    $0x8,%r10
 1094035:	73 b9                	jae    1093ff0 <join_short+0x290>
 1094037:	eb 1c                	jmp    1094055 <join_short+0x2f5>
 1094039:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
 1094040:	49 8b 5b 18          	mov    0x18(%r11),%rbx
 1094044:	45 8b 5b 14          	mov    0x14(%r11),%r11d
 1094048:	49 01 db             	add    %rbx,%r11
 109404b:	49 83 c3 18          	add    $0x18,%r11
 109404f:	49 83 fa 08          	cmp    $0x8,%r10
 1094053:	73 9b                	jae    1093ff0 <join_short+0x290>
 1094055:	49 83 fa 04          	cmp    $0x4,%r10
 1094059:	72 11                	jb     109406c <join_short+0x30c>
 109405b:	41 8b 1b             	mov    (%r11),%ebx
 109405e:	47 8b 5c 13 fc       	mov    -0x4(%r11,%r10,1),%r11d
 1094063:	89 1f                	mov    %ebx,(%rdi)
 1094065:	46 89 5c 17 fc       	mov    %r11d,-0x4(%rdi,%r10,1)
 109406a:	eb 94                	jmp    1094000 <join_short+0x2a0>
 109406c:	49 83 fa 01          	cmp    $0x1,%r10
 1094070:	75 09                	jne    109407b <join_short+0x31b>
 1094072:	45 0f b6 1b          	movzbl (%r11),%r11d
 1094076:	44 88 1f             	mov    %r11b,(%rdi)
 1094079:	eb 85                	jmp    1094000 <join_short+0x2a0>
 109407b:	41 0f b7 1b          	movzwl (%r11),%ebx
 109407f:	47 0f b7 5c 13 fe    	movzwl -0x2(%r11,%r10,1),%r11d
 1094085:	66 89 1f             	mov    %bx,(%rdi)
 1094088:	66 46 89 5c 17 fe    	mov    %r11w,-0x2(%rdi,%r10,1)
 109408e:	e9 6d ff ff ff       	jmp    1094000 <join_short+0x2a0>
 1094093:	31 c0                	xor    %eax,%eax
 1094095:	eb 28                	jmp    10940bf <join_short+0x35f>
 1094097:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
 109409e:	00 00 
 10940a0:	4d 8b 08             	mov    (%r8),%r9
 10940a3:	4d 8b 44 08 f8       	mov    -0x8(%r8,%rcx,1),%r8
 10940a8:	4c 89 0f             	mov    %r9,(%rdi)
 10940ab:	4c 89 44 0f f8       	mov    %r8,-0x8(%rdi,%rcx,1)
 10940b0:	48 01 cf             	add    %rcx,%rdi
 10940b3:	48 ff c0             	inc    %rax
 10940b6:	48 39 c2             	cmp    %rax,%rdx
 10940b9:	0f 84 39 02 00 00    	je     10942f8 <join_short+0x598>
 10940bf:	4c 8b 04 c6          	mov    (%rsi,%rax,8),%r8
 10940c3:	49 8b 48 08          	mov    0x8(%r8),%rcx
 10940c7:	48 85 c9             	test   %rcx,%rcx
 10940ca:	74 e4                	je     10940b0 <join_short+0x350>
 10940cc:	41 f6 40 10 04       	testb  $0x4,0x10(%r8)
 10940d1:	75 0d                	jne    10940e0 <join_short+0x380>
 10940d3:	49 83 c0 18          	add    $0x18,%r8
 10940d7:	48 83 f9 08          	cmp    $0x8,%rcx
 10940db:	73 c3                	jae    10940a0 <join_short+0x340>
 10940dd:	eb 16                	jmp    10940f5 <join_short+0x395>
 10940df:	90                   	nop
 10940e0:	4d 8b 48 18          	mov    0x18(%r8),%r9
 10940e4:	45 8b 40 14          	mov    0x14(%r8),%r8d
 10940e8:	4d 01 c8             	add    %r9,%r8
 10940eb:	49 83 c0 18          	add    $0x18,%r8
 10940ef:	48 83 f9 08          	cmp    $0x8,%rcx
 10940f3:	73 ab                	jae    10940a0 <join_short+0x340>
 10940f5:	48 83 f9 04          	cmp    $0x4,%rcx
 10940f9:	72 12                	jb     109410d <join_short+0x3ad>
 10940fb:	45 8b 08             	mov    (%r8),%r9d
 10940fe:	45 8b 44 08 fc       	mov    -0x4(%r8,%rcx,1),%r8d
 1094103:	44 89 0f             	mov    %r9d,(%rdi)
 1094106:	44 89 44 0f fc       	mov    %r8d,-0x4(%rdi,%rcx,1)
 109410b:	eb a3                	jmp    10940b0 <join_short+0x350>
 109410d:	48 83 f9 01          	cmp    $0x1,%rcx
 1094111:	75 09                	jne    109411c <join_short+0x3bc>
 1094113:	45 0f b6 00          	movzbl (%r8),%r8d
 1094117:	44 88 07             	mov    %r8b,(%rdi)
 109411a:	eb 94                	jmp    10940b0 <join_short+0x350>
 109411c:	45 0f b7 08          	movzwl (%r8),%r9d
 1094120:	45 0f b7 44 08 fe    	movzwl -0x2(%r8,%rcx,1),%r8d
 1094126:	66 44 89 0f          	mov    %r9w,(%rdi)
 109412a:	66 44 89 44 0f fe    	mov    %r8w,-0x2(%rdi,%rcx,1)
 1094130:	e9 7b ff ff ff       	jmp    10940b0 <join_short+0x350>
 1094135:	49 83 f9 01          	cmp    $0x1,%r9
 1094139:	0f 85 5e 01 00 00    	jne    109429d <join_short+0x53d>
 109413f:	45 0f b6 12          	movzbl (%r10),%r10d
 1094143:	44 88 17             	mov    %r10b,(%rdi)
 1094146:	e9 87 fe ff ff       	jmp    1093fd2 <join_short+0x272>
 109414b:	4d 8b 5a 18          	mov    0x18(%r10),%r11
 109414f:	45 8b 52 14          	mov    0x14(%r10),%r10d
 1094153:	4d 01 da             	add    %r11,%r10
 1094156:	49 83 c2 18          	add    $0x18,%r10
 109415a:	49 83 f9 07          	cmp    $0x7,%r9
 109415e:	0f 86 f1 fc ff ff    	jbe    1093e55 <join_short+0xf5>
 1094164:	4d 8b 1a             	mov    (%r10),%r11
 1094167:	4f 8b 54 0a f8       	mov    -0x8(%r10,%r9,1),%r10
 109416c:	4c 89 1f             	mov    %r11,(%rdi)
 109416f:	4e 89 54 0f f8       	mov    %r10,-0x8(%rdi,%r9,1)
 1094174:	48 83 fa 01          	cmp    $0x1,%rdx
 1094178:	0f 84 7a 01 00 00    	je     10942f8 <join_short+0x598>
 109417e:	4c 01 cf             	add    %r9,%rdi
 1094181:	41 b9 01 00 00 00    	mov    $0x1,%r9d
 1094187:	eb 26                	jmp    10941af <join_short+0x44f>
 1094189:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
 1094190:	49 8b 1b             	mov    (%r11),%rbx
 1094193:	4f 8b 5c 13 f8       	mov    -0x8(%r11,%r10,1),%r11
 1094198:	48 89 1f             	mov    %rbx,(%rdi)
 109419b:	4e 89 5c 17 f8       	mov    %r11,-0x8(%rdi,%r10,1)
 10941a0:	4c 01 d7             	add    %r10,%rdi
 10941a3:	49 ff c1             	inc    %r9
 10941a6:	4c 39 ca             	cmp    %r9,%rdx
 10941a9:	0f 84 49 01 00 00    	je     10942f8 <join_short+0x598>
 10941af:	66 89 07             	mov    %ax,(%rdi)
 10941b2:	66 42 89 4c 07 fe    	mov    %cx,-0x2(%rdi,%r8,1)
 10941b8:	4c 01 c7             	add    %r8,%rdi
 10941bb:	4e 8b 1c ce          	mov    (%rsi,%r9,8),%r11
 10941bf:	4d 8b 53 08          	mov    0x8(%r11),%r10
 10941c3:	4d 85 d2             	test   %r10,%r10
 10941c6:	74 d8                	je     10941a0 <join_short+0x440>
 10941c8:	41 f6 43 10 04       	testb  $0x4,0x10(%r11)
 10941cd:	75 11                	jne    10941e0 <join_short+0x480>
 10941cf:	49 83 c3 18          	add    $0x18,%r11
 10941d3:	49 83 fa 08          	cmp    $0x8,%r10
 10941d7:	73 b7                	jae    1094190 <join_short+0x430>
 10941d9:	eb 1a                	jmp    10941f5 <join_short+0x495>
 10941db:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
 10941e0:	49 8b 5b 18          	mov    0x18(%r11),%rbx
 10941e4:	45 8b 5b 14          	mov    0x14(%r11),%r11d
 10941e8:	49 01 db             	add    %rbx,%r11
 10941eb:	49 83 c3 18          	add    $0x18,%r11
 10941ef:	49 83 fa 08          	cmp    $0x8,%r10
 10941f3:	73 9b                	jae    1094190 <join_short+0x430>
 10941f5:	49 83 fa 04          	cmp    $0x4,%r10
 10941f9:	72 11                	jb     109420c <join_short+0x4ac>
 10941fb:	41 8b 1b             	mov    (%r11),%ebx
 10941fe:	47 8b 5c 13 fc       	mov    -0x4(%r11,%r10,1),%r11d
 1094203:	89 1f                	mov    %ebx,(%rdi)
 1094205:	46 89 5c 17 fc       	mov    %r11d,-0x4(%rdi,%r10,1)
 109420a:	eb 94                	jmp    10941a0 <join_short+0x440>
 109420c:	49 83 fa 01          	cmp    $0x1,%r10
 1094210:	75 09                	jne    109421b <join_short+0x4bb>
 1094212:	45 0f b6 1b          	movzbl (%r11),%r11d
 1094216:	44 88 1f             	mov    %r11b,(%rdi)
 1094219:	eb 85                	jmp    10941a0 <join_short+0x440>
 109421b:	41 0f b7 1b          	movzwl (%r11),%ebx
 109421f:	47 0f b7 5c 13 fe    	movzwl -0x2(%r11,%r10,1),%r11d
 1094225:	66 89 1f             	mov    %bx,(%rdi)
 1094228:	66 46 89 5c 17 fe    	mov    %r11w,-0x2(%rdi,%r10,1)
 109422e:	e9 6d ff ff ff       	jmp    10941a0 <join_short+0x440>
 1094233:	45 0f b7 1a          	movzwl (%r10),%r11d
 1094237:	47 0f b7 54 0a fe    	movzwl -0x2(%r10,%r9,1),%r10d
 109423d:	66 44 89 1f          	mov    %r11w,(%rdi)
 1094241:	66 46 89 54 0f fe    	mov    %r10w,-0x2(%rdi,%r9,1)
 1094247:	e9 51 fc ff ff       	jmp    1093e9d <join_short+0x13d>
 109424c:	4d 8b 48 18          	mov    0x18(%r8),%r9
 1094250:	45 8b 40 14          	mov    0x14(%r8),%r8d
 1094254:	4d 01 c8             	add    %r9,%r8
 1094257:	49 83 c0 18          	add    $0x18,%r8
 109425b:	48 83 f9 07          	cmp    $0x7,%rcx
 109425f:	76 12                	jbe    1094273 <join_short+0x513>
 1094261:	4d 8b 08             	mov    (%r8),%r9
 1094264:	4d 8b 44 08 f8       	mov    -0x8(%r8,%rcx,1),%r8
 1094269:	4c 89 0f             	mov    %r9,(%rdi)
 109426c:	4c 89 44 0f f8       	mov    %r8,-0x8(%rdi,%rcx,1)
 1094271:	eb 7f                	jmp    10942f2 <join_short+0x592>
 1094273:	48 83 f9 03          	cmp    $0x3,%rcx
 1094277:	76 3d                	jbe    10942b6 <join_short+0x556>
 1094279:	45 8b 08             	mov    (%r8),%r9d
 109427c:	45 8b 44 08 fc       	mov    -0x4(%r8,%rcx,1),%r8d
 1094281:	44 89 0f             	mov    %r9d,(%rdi)
 1094284:	44 89 44 0f fc       	mov    %r8d,-0x4(%rdi,%rcx,1)
 1094289:	eb 67                	jmp    10942f2 <join_short+0x592>
 109428b:	49 83 f9 01          	cmp    $0x1,%r9
 109428f:	75 34                	jne    10942c5 <join_short+0x565>
 1094291:	45 0f b6 12          	movzbl (%r10),%r10d
 1094295:	44 88 17             	mov    %r10b,(%rdi)
 1094298:	e9 d7 fe ff ff       	jmp    1094174 <join_short+0x414>
 109429d:	45 0f b7 1a          	movzwl (%r10),%r11d
 10942a1:	47 0f b7 54 0a fe    	movzwl -0x2(%r10,%r9,1),%r10d
 10942a7:	66 44 89 1f          	mov    %r11w,(%rdi)
 10942ab:	66 46 89 54 0f fe    	mov    %r10w,-0x2(%rdi,%r9,1)
 10942b1:	e9 1c fd ff ff       	jmp    1093fd2 <join_short+0x272>
 10942b6:	48 83 f9 01          	cmp    $0x1,%rcx
 10942ba:	75 22                	jne    10942de <join_short+0x57e>
 10942bc:	45 0f b6 00          	movzbl (%r8),%r8d
 10942c0:	44 88 07             	mov    %r8b,(%rdi)
 10942c3:	eb 2d                	jmp    10942f2 <join_short+0x592>
 10942c5:	45 0f b7 1a          	movzwl (%r10),%r11d
 10942c9:	47 0f b7 54 0a fe    	movzwl -0x2(%r10,%r9,1),%r10d
 10942cf:	66 44 89 1f          	mov    %r11w,(%rdi)
 10942d3:	66 46 89 54 0f fe    	mov    %r10w,-0x2(%rdi,%r9,1)
 10942d9:	e9 96 fe ff ff       	jmp    1094174 <join_short+0x414>
 10942de:	45 0f b7 08          	movzwl (%r8),%r9d
 10942e2:	45 0f b7 44 08 fe    	movzwl -0x2(%r8,%rcx,1),%r8d
 10942e8:	66 44 89 0f          	mov    %r9w,(%rdi)
 10942ec:	66 44 89 44 0f fe    	mov    %r8w,-0x2(%rdi,%rcx,1)
 10942f2:	48 83 fa 01          	cmp    $0x1,%rdx
 10942f6:	75 03                	jne    10942fb <join_short+0x59b>
 10942f8:	5b                   	pop    %rbx
 10942f9:	5d                   	pop    %rbp
 10942fa:	c3                   	ret
 10942fb:	48 01 cf             	add    %rcx,%rdi
 10942fe:	b9 01 00 00 00       	mov    $0x1,%ecx
 1094303:	eb 26                	jmp    109432b <join_short+0x5cb>
 1094305:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
 109430c:	00 00 00 00 
 1094310:	4d 8b 11             	mov    (%r9),%r10
 1094313:	4f 8b 4c 01 f8       	mov    -0x8(%r9,%r8,1),%r9
 1094318:	4c 89 17             	mov    %r10,(%rdi)
 109431b:	4e 89 4c 07 f8       	mov    %r9,-0x8(%rdi,%r8,1)
 1094320:	4c 01 c7             	add    %r8,%rdi
 1094323:	48 ff c1             	inc    %rcx
 1094326:	48 39 ca             	cmp    %rcx,%rdx
 1094329:	74 cd                	je     10942f8 <join_short+0x598>
 109432b:	88 07                	mov    %al,(%rdi)
 109432d:	48 ff c7             	inc    %rdi
 1094330:	4c 8b 0c ce          	mov    (%rsi,%rcx,8),%r9
 1094334:	4d 8b 41 08          	mov    0x8(%r9),%r8
 1094338:	4d 85 c0             	test   %r8,%r8
 109433b:	74 e3                	je     1094320 <join_short+0x5c0>
 109433d:	41 f6 41 10 04       	testb  $0x4,0x10(%r9)
 1094342:	75 0c                	jne    1094350 <join_short+0x5f0>
 1094344:	49 83 c1 18          	add    $0x18,%r9
 1094348:	49 83 f8 08          	cmp    $0x8,%r8
 109434c:	73 c2                	jae    1094310 <join_short+0x5b0>
 109434e:	eb 15                	jmp    1094365 <join_short+0x605>
 1094350:	4d 8b 51 18          	mov    0x18(%r9),%r10
 1094354:	45 8b 49 14          	mov    0x14(%r9),%r9d
 1094358:	4d 01 d1             	add    %r10,%r9
 109435b:	49 83 c1 18          	add    $0x18,%r9
 109435f:	49 83 f8 08          	cmp    $0x8,%r8
 1094363:	73 ab                	jae    1094310 <join_short+0x5b0>
 1094365:	49 83 f8 04          	cmp    $0x4,%r8
 1094369:	72 12                	jb     109437d <join_short+0x61d>
 109436b:	45 8b 11             	mov    (%r9),%r10d
 109436e:	47 8b 4c 01 fc       	mov    -0x4(%r9,%r8,1),%r9d
 1094373:	44 89 17             	mov    %r10d,(%rdi)
 1094376:	46 89 4c 07 fc       	mov    %r9d,-0x4(%rdi,%r8,1)
 109437b:	eb a3                	jmp    1094320 <join_short+0x5c0>
 109437d:	49 83 f8 01          	cmp    $0x1,%r8
 1094381:	75 09                	jne    109438c <join_short+0x62c>
 1094383:	45 0f b6 09          	movzbl (%r9),%r9d
 1094387:	44 88 0f             	mov    %r9b,(%rdi)
 109438a:	eb 94                	jmp    1094320 <join_short+0x5c0>
 109438c:	45 0f b7 11          	movzwl (%r9),%r10d
 1094390:	47 0f b7 4c 01 fe    	movzwl -0x2(%r9,%r8,1),%r9d
 1094396:	66 44 89 17          	mov    %r10w,(%rdi)
 109439a:	66 46 89 4c 07 fe    	mov    %r9w,-0x2(%rdi,%r8,1)
 10943a0:	e9 7b ff ff ff       	jmp    1094320 <join_short+0x5c0>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
