
/home/epentland/ai/canopy/mylang-worktrees/goal110-g4-rf-20261004/.mylang-cache/goal110-g4-rf/runner/bin/text-my-qbe:     file format elf64-x86-64


Disassembly of section .text:

00000000010c9140 <join_short>:
 10c9140:	48 85 d2             	test   %rdx,%rdx
 10c9143:	0f 84 91 05 00 00    	je     10c96da <join_short+0x59a>
 10c9149:	55                   	push   %rbp
 10c914a:	48 89 e5             	mov    %rsp,%rbp
 10c914d:	53                   	push   %rbx
 10c914e:	49 83 f8 08          	cmp    $0x8,%r8
 10c9152:	72 50                	jb     10c91a4 <join_short+0x64>
 10c9154:	48 8b 01             	mov    (%rcx),%rax
 10c9157:	4a 8b 4c 01 f8       	mov    -0x8(%rcx,%r8,1),%rcx
 10c915c:	4c 8b 16             	mov    (%rsi),%r10
 10c915f:	4d 8b 4a 08          	mov    0x8(%r10),%r9
 10c9163:	4d 85 c9             	test   %r9,%r9
 10c9166:	0f 84 11 01 00 00    	je     10c927d <join_short+0x13d>
 10c916c:	41 f6 42 10 04       	testb  $0x4,0x10(%r10)
 10c9171:	0f 85 dd 00 00 00    	jne    10c9254 <join_short+0x114>
 10c9177:	49 83 c2 18          	add    $0x18,%r10
 10c917b:	49 83 f9 07          	cmp    $0x7,%r9
 10c917f:	0f 87 e8 00 00 00    	ja     10c926d <join_short+0x12d>
 10c9185:	49 83 f9 03          	cmp    $0x3,%r9
 10c9189:	0f 86 e4 01 00 00    	jbe    10c9373 <join_short+0x233>
 10c918f:	45 8b 1a             	mov    (%r10),%r11d
 10c9192:	47 8b 54 0a fc       	mov    -0x4(%r10,%r9,1),%r10d
 10c9197:	44 89 1f             	mov    %r11d,(%rdi)
 10c919a:	46 89 54 0f fc       	mov    %r10d,-0x4(%rdi,%r9,1)
 10c919f:	e9 d9 00 00 00       	jmp    10c927d <join_short+0x13d>
 10c91a4:	49 83 f8 04          	cmp    $0x4,%r8
 10c91a8:	72 4f                	jb     10c91f9 <join_short+0xb9>
 10c91aa:	8b 01                	mov    (%rcx),%eax
 10c91ac:	42 8b 4c 01 fc       	mov    -0x4(%rcx,%r8,1),%ecx
 10c91b1:	4c 8b 16             	mov    (%rsi),%r10
 10c91b4:	4d 8b 4a 08          	mov    0x8(%r10),%r9
 10c91b8:	4d 85 c9             	test   %r9,%r9
 10c91bb:	0f 84 f1 01 00 00    	je     10c93b2 <join_short+0x272>
 10c91c1:	41 f6 42 10 04       	testb  $0x4,0x10(%r10)
 10c91c6:	0f 85 bd 01 00 00    	jne    10c9389 <join_short+0x249>
 10c91cc:	49 83 c2 18          	add    $0x18,%r10
 10c91d0:	49 83 f9 07          	cmp    $0x7,%r9
 10c91d4:	0f 87 c8 01 00 00    	ja     10c93a2 <join_short+0x262>
 10c91da:	49 83 f9 03          	cmp    $0x3,%r9
 10c91de:	0f 86 31 03 00 00    	jbe    10c9515 <join_short+0x3d5>
 10c91e4:	45 8b 1a             	mov    (%r10),%r11d
 10c91e7:	47 8b 54 0a fc       	mov    -0x4(%r10,%r9,1),%r10d
 10c91ec:	44 89 1f             	mov    %r11d,(%rdi)
 10c91ef:	46 89 54 0f fc       	mov    %r10d,-0x4(%rdi,%r9,1)
 10c91f4:	e9 b9 01 00 00       	jmp    10c93b2 <join_short+0x272>
 10c91f9:	49 83 f8 02          	cmp    $0x2,%r8
 10c91fd:	0f 82 40 01 00 00    	jb     10c9343 <join_short+0x203>
 10c9203:	0f b7 01             	movzwl (%rcx),%eax
 10c9206:	42 0f b7 4c 01 fe    	movzwl -0x2(%rcx,%r8,1),%ecx
 10c920c:	4c 8b 16             	mov    (%rsi),%r10
 10c920f:	4d 8b 4a 08          	mov    0x8(%r10),%r9
 10c9213:	4d 85 c9             	test   %r9,%r9
 10c9216:	0f 84 38 03 00 00    	je     10c9554 <join_short+0x414>
 10c921c:	41 f6 42 10 04       	testb  $0x4,0x10(%r10)
 10c9221:	0f 85 04 03 00 00    	jne    10c952b <join_short+0x3eb>
 10c9227:	49 83 c2 18          	add    $0x18,%r10
 10c922b:	49 83 f9 07          	cmp    $0x7,%r9
 10c922f:	0f 87 0f 03 00 00    	ja     10c9544 <join_short+0x404>
 10c9235:	49 83 f9 03          	cmp    $0x3,%r9
 10c9239:	0f 86 2c 04 00 00    	jbe    10c966b <join_short+0x52b>
 10c923f:	45 8b 1a             	mov    (%r10),%r11d
 10c9242:	47 8b 54 0a fc       	mov    -0x4(%r10,%r9,1),%r10d
 10c9247:	44 89 1f             	mov    %r11d,(%rdi)
 10c924a:	46 89 54 0f fc       	mov    %r10d,-0x4(%rdi,%r9,1)
 10c924f:	e9 00 03 00 00       	jmp    10c9554 <join_short+0x414>
 10c9254:	4d 8b 5a 18          	mov    0x18(%r10),%r11
 10c9258:	45 8b 52 14          	mov    0x14(%r10),%r10d
 10c925c:	4d 01 da             	add    %r11,%r10
 10c925f:	49 83 c2 18          	add    $0x18,%r10
 10c9263:	49 83 f9 07          	cmp    $0x7,%r9
 10c9267:	0f 86 18 ff ff ff    	jbe    10c9185 <join_short+0x45>
 10c926d:	4d 8b 1a             	mov    (%r10),%r11
 10c9270:	4f 8b 54 0a f8       	mov    -0x8(%r10,%r9,1),%r10
 10c9275:	4c 89 1f             	mov    %r11,(%rdi)
 10c9278:	4e 89 54 0f f8       	mov    %r10,-0x8(%rdi,%r9,1)
 10c927d:	48 83 fa 01          	cmp    $0x1,%rdx
 10c9281:	0f 84 51 04 00 00    	je     10c96d8 <join_short+0x598>
 10c9287:	4c 01 cf             	add    %r9,%rdi
 10c928a:	41 b9 01 00 00 00    	mov    $0x1,%r9d
 10c9290:	eb 2d                	jmp    10c92bf <join_short+0x17f>
 10c9292:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 10c9299:	1f 84 00 00 00 00 00 
 10c92a0:	49 8b 1b             	mov    (%r11),%rbx
 10c92a3:	4f 8b 5c 13 f8       	mov    -0x8(%r11,%r10,1),%r11
 10c92a8:	48 89 1f             	mov    %rbx,(%rdi)
 10c92ab:	4e 89 5c 17 f8       	mov    %r11,-0x8(%rdi,%r10,1)
 10c92b0:	4c 01 d7             	add    %r10,%rdi
 10c92b3:	49 ff c1             	inc    %r9
 10c92b6:	4c 39 ca             	cmp    %r9,%rdx
 10c92b9:	0f 84 19 04 00 00    	je     10c96d8 <join_short+0x598>
 10c92bf:	48 89 07             	mov    %rax,(%rdi)
 10c92c2:	4a 89 4c 07 f8       	mov    %rcx,-0x8(%rdi,%r8,1)
 10c92c7:	4c 01 c7             	add    %r8,%rdi
 10c92ca:	4e 8b 1c ce          	mov    (%rsi,%r9,8),%r11
 10c92ce:	4d 8b 53 08          	mov    0x8(%r11),%r10
 10c92d2:	4d 85 d2             	test   %r10,%r10
 10c92d5:	74 d9                	je     10c92b0 <join_short+0x170>
 10c92d7:	41 f6 43 10 04       	testb  $0x4,0x10(%r11)
 10c92dc:	75 12                	jne    10c92f0 <join_short+0x1b0>
 10c92de:	49 83 c3 18          	add    $0x18,%r11
 10c92e2:	49 83 fa 08          	cmp    $0x8,%r10
 10c92e6:	73 b8                	jae    10c92a0 <join_short+0x160>
 10c92e8:	eb 1b                	jmp    10c9305 <join_short+0x1c5>
 10c92ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
 10c92f0:	49 8b 5b 18          	mov    0x18(%r11),%rbx
 10c92f4:	45 8b 5b 14          	mov    0x14(%r11),%r11d
 10c92f8:	49 01 db             	add    %rbx,%r11
 10c92fb:	49 83 c3 18          	add    $0x18,%r11
 10c92ff:	49 83 fa 08          	cmp    $0x8,%r10
 10c9303:	73 9b                	jae    10c92a0 <join_short+0x160>
 10c9305:	49 83 fa 04          	cmp    $0x4,%r10
 10c9309:	72 11                	jb     10c931c <join_short+0x1dc>
 10c930b:	41 8b 1b             	mov    (%r11),%ebx
 10c930e:	47 8b 5c 13 fc       	mov    -0x4(%r11,%r10,1),%r11d
 10c9313:	89 1f                	mov    %ebx,(%rdi)
 10c9315:	46 89 5c 17 fc       	mov    %r11d,-0x4(%rdi,%r10,1)
 10c931a:	eb 94                	jmp    10c92b0 <join_short+0x170>
 10c931c:	49 83 fa 01          	cmp    $0x1,%r10
 10c9320:	75 09                	jne    10c932b <join_short+0x1eb>
 10c9322:	45 0f b6 1b          	movzbl (%r11),%r11d
 10c9326:	44 88 1f             	mov    %r11b,(%rdi)
 10c9329:	eb 85                	jmp    10c92b0 <join_short+0x170>
 10c932b:	41 0f b7 1b          	movzwl (%r11),%ebx
 10c932f:	47 0f b7 5c 13 fe    	movzwl -0x2(%r11,%r10,1),%r11d
 10c9335:	66 89 1f             	mov    %bx,(%rdi)
 10c9338:	66 46 89 5c 17 fe    	mov    %r11w,-0x2(%rdi,%r10,1)
 10c933e:	e9 6d ff ff ff       	jmp    10c92b0 <join_short+0x170>
 10c9343:	4d 85 c0             	test   %r8,%r8
 10c9346:	0f 84 27 01 00 00    	je     10c9473 <join_short+0x333>
 10c934c:	0f b6 01             	movzbl (%rcx),%eax
 10c934f:	4c 8b 06             	mov    (%rsi),%r8
 10c9352:	49 8b 48 08          	mov    0x8(%r8),%rcx
 10c9356:	48 85 c9             	test   %rcx,%rcx
 10c9359:	0f 84 73 03 00 00    	je     10c96d2 <join_short+0x592>
 10c935f:	41 f6 40 10 04       	testb  $0x4,0x10(%r8)
 10c9364:	0f 85 c2 02 00 00    	jne    10c962c <join_short+0x4ec>
 10c936a:	49 83 c0 18          	add    $0x18,%r8
 10c936e:	e9 c8 02 00 00       	jmp    10c963b <join_short+0x4fb>
 10c9373:	49 83 f9 01          	cmp    $0x1,%r9
 10c9377:	0f 85 96 02 00 00    	jne    10c9613 <join_short+0x4d3>
 10c937d:	45 0f b6 12          	movzbl (%r10),%r10d
 10c9381:	44 88 17             	mov    %r10b,(%rdi)
 10c9384:	e9 f4 fe ff ff       	jmp    10c927d <join_short+0x13d>
 10c9389:	4d 8b 5a 18          	mov    0x18(%r10),%r11
 10c938d:	45 8b 52 14          	mov    0x14(%r10),%r10d
 10c9391:	4d 01 da             	add    %r11,%r10
 10c9394:	49 83 c2 18          	add    $0x18,%r10
 10c9398:	49 83 f9 07          	cmp    $0x7,%r9
 10c939c:	0f 86 38 fe ff ff    	jbe    10c91da <join_short+0x9a>
 10c93a2:	4d 8b 1a             	mov    (%r10),%r11
 10c93a5:	4f 8b 54 0a f8       	mov    -0x8(%r10,%r9,1),%r10
 10c93aa:	4c 89 1f             	mov    %r11,(%rdi)
 10c93ad:	4e 89 54 0f f8       	mov    %r10,-0x8(%rdi,%r9,1)
 10c93b2:	48 83 fa 01          	cmp    $0x1,%rdx
 10c93b6:	0f 84 1c 03 00 00    	je     10c96d8 <join_short+0x598>
 10c93bc:	4c 01 cf             	add    %r9,%rdi
 10c93bf:	41 b9 01 00 00 00    	mov    $0x1,%r9d
 10c93c5:	eb 28                	jmp    10c93ef <join_short+0x2af>
 10c93c7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
 10c93ce:	00 00 
 10c93d0:	49 8b 1b             	mov    (%r11),%rbx
 10c93d3:	4f 8b 5c 13 f8       	mov    -0x8(%r11,%r10,1),%r11
 10c93d8:	48 89 1f             	mov    %rbx,(%rdi)
 10c93db:	4e 89 5c 17 f8       	mov    %r11,-0x8(%rdi,%r10,1)
 10c93e0:	4c 01 d7             	add    %r10,%rdi
 10c93e3:	49 ff c1             	inc    %r9
 10c93e6:	4c 39 ca             	cmp    %r9,%rdx
 10c93e9:	0f 84 e9 02 00 00    	je     10c96d8 <join_short+0x598>
 10c93ef:	89 07                	mov    %eax,(%rdi)
 10c93f1:	42 89 4c 07 fc       	mov    %ecx,-0x4(%rdi,%r8,1)
 10c93f6:	4c 01 c7             	add    %r8,%rdi
 10c93f9:	4e 8b 1c ce          	mov    (%rsi,%r9,8),%r11
 10c93fd:	4d 8b 53 08          	mov    0x8(%r11),%r10
 10c9401:	4d 85 d2             	test   %r10,%r10
 10c9404:	74 da                	je     10c93e0 <join_short+0x2a0>
 10c9406:	41 f6 43 10 04       	testb  $0x4,0x10(%r11)
 10c940b:	75 13                	jne    10c9420 <join_short+0x2e0>
 10c940d:	49 83 c3 18          	add    $0x18,%r11
 10c9411:	49 83 fa 08          	cmp    $0x8,%r10
 10c9415:	73 b9                	jae    10c93d0 <join_short+0x290>
 10c9417:	eb 1c                	jmp    10c9435 <join_short+0x2f5>
 10c9419:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
 10c9420:	49 8b 5b 18          	mov    0x18(%r11),%rbx
 10c9424:	45 8b 5b 14          	mov    0x14(%r11),%r11d
 10c9428:	49 01 db             	add    %rbx,%r11
 10c942b:	49 83 c3 18          	add    $0x18,%r11
 10c942f:	49 83 fa 08          	cmp    $0x8,%r10
 10c9433:	73 9b                	jae    10c93d0 <join_short+0x290>
 10c9435:	49 83 fa 04          	cmp    $0x4,%r10
 10c9439:	72 11                	jb     10c944c <join_short+0x30c>
 10c943b:	41 8b 1b             	mov    (%r11),%ebx
 10c943e:	47 8b 5c 13 fc       	mov    -0x4(%r11,%r10,1),%r11d
 10c9443:	89 1f                	mov    %ebx,(%rdi)
 10c9445:	46 89 5c 17 fc       	mov    %r11d,-0x4(%rdi,%r10,1)
 10c944a:	eb 94                	jmp    10c93e0 <join_short+0x2a0>
 10c944c:	49 83 fa 01          	cmp    $0x1,%r10
 10c9450:	75 09                	jne    10c945b <join_short+0x31b>
 10c9452:	45 0f b6 1b          	movzbl (%r11),%r11d
 10c9456:	44 88 1f             	mov    %r11b,(%rdi)
 10c9459:	eb 85                	jmp    10c93e0 <join_short+0x2a0>
 10c945b:	41 0f b7 1b          	movzwl (%r11),%ebx
 10c945f:	47 0f b7 5c 13 fe    	movzwl -0x2(%r11,%r10,1),%r11d
 10c9465:	66 89 1f             	mov    %bx,(%rdi)
 10c9468:	66 46 89 5c 17 fe    	mov    %r11w,-0x2(%rdi,%r10,1)
 10c946e:	e9 6d ff ff ff       	jmp    10c93e0 <join_short+0x2a0>
 10c9473:	31 c0                	xor    %eax,%eax
 10c9475:	eb 28                	jmp    10c949f <join_short+0x35f>
 10c9477:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
 10c947e:	00 00 
 10c9480:	4d 8b 08             	mov    (%r8),%r9
 10c9483:	4d 8b 44 08 f8       	mov    -0x8(%r8,%rcx,1),%r8
 10c9488:	4c 89 0f             	mov    %r9,(%rdi)
 10c948b:	4c 89 44 0f f8       	mov    %r8,-0x8(%rdi,%rcx,1)
 10c9490:	48 01 cf             	add    %rcx,%rdi
 10c9493:	48 ff c0             	inc    %rax
 10c9496:	48 39 c2             	cmp    %rax,%rdx
 10c9499:	0f 84 39 02 00 00    	je     10c96d8 <join_short+0x598>
 10c949f:	4c 8b 04 c6          	mov    (%rsi,%rax,8),%r8
 10c94a3:	49 8b 48 08          	mov    0x8(%r8),%rcx
 10c94a7:	48 85 c9             	test   %rcx,%rcx
 10c94aa:	74 e4                	je     10c9490 <join_short+0x350>
 10c94ac:	41 f6 40 10 04       	testb  $0x4,0x10(%r8)
 10c94b1:	75 0d                	jne    10c94c0 <join_short+0x380>
 10c94b3:	49 83 c0 18          	add    $0x18,%r8
 10c94b7:	48 83 f9 08          	cmp    $0x8,%rcx
 10c94bb:	73 c3                	jae    10c9480 <join_short+0x340>
 10c94bd:	eb 16                	jmp    10c94d5 <join_short+0x395>
 10c94bf:	90                   	nop
 10c94c0:	4d 8b 48 18          	mov    0x18(%r8),%r9
 10c94c4:	45 8b 40 14          	mov    0x14(%r8),%r8d
 10c94c8:	4d 01 c8             	add    %r9,%r8
 10c94cb:	49 83 c0 18          	add    $0x18,%r8
 10c94cf:	48 83 f9 08          	cmp    $0x8,%rcx
 10c94d3:	73 ab                	jae    10c9480 <join_short+0x340>
 10c94d5:	48 83 f9 04          	cmp    $0x4,%rcx
 10c94d9:	72 12                	jb     10c94ed <join_short+0x3ad>
 10c94db:	45 8b 08             	mov    (%r8),%r9d
 10c94de:	45 8b 44 08 fc       	mov    -0x4(%r8,%rcx,1),%r8d
 10c94e3:	44 89 0f             	mov    %r9d,(%rdi)
 10c94e6:	44 89 44 0f fc       	mov    %r8d,-0x4(%rdi,%rcx,1)
 10c94eb:	eb a3                	jmp    10c9490 <join_short+0x350>
 10c94ed:	48 83 f9 01          	cmp    $0x1,%rcx
 10c94f1:	75 09                	jne    10c94fc <join_short+0x3bc>
 10c94f3:	45 0f b6 00          	movzbl (%r8),%r8d
 10c94f7:	44 88 07             	mov    %r8b,(%rdi)
 10c94fa:	eb 94                	jmp    10c9490 <join_short+0x350>
 10c94fc:	45 0f b7 08          	movzwl (%r8),%r9d
 10c9500:	45 0f b7 44 08 fe    	movzwl -0x2(%r8,%rcx,1),%r8d
 10c9506:	66 44 89 0f          	mov    %r9w,(%rdi)
 10c950a:	66 44 89 44 0f fe    	mov    %r8w,-0x2(%rdi,%rcx,1)
 10c9510:	e9 7b ff ff ff       	jmp    10c9490 <join_short+0x350>
 10c9515:	49 83 f9 01          	cmp    $0x1,%r9
 10c9519:	0f 85 5e 01 00 00    	jne    10c967d <join_short+0x53d>
 10c951f:	45 0f b6 12          	movzbl (%r10),%r10d
 10c9523:	44 88 17             	mov    %r10b,(%rdi)
 10c9526:	e9 87 fe ff ff       	jmp    10c93b2 <join_short+0x272>
 10c952b:	4d 8b 5a 18          	mov    0x18(%r10),%r11
 10c952f:	45 8b 52 14          	mov    0x14(%r10),%r10d
 10c9533:	4d 01 da             	add    %r11,%r10
 10c9536:	49 83 c2 18          	add    $0x18,%r10
 10c953a:	49 83 f9 07          	cmp    $0x7,%r9
 10c953e:	0f 86 f1 fc ff ff    	jbe    10c9235 <join_short+0xf5>
 10c9544:	4d 8b 1a             	mov    (%r10),%r11
 10c9547:	4f 8b 54 0a f8       	mov    -0x8(%r10,%r9,1),%r10
 10c954c:	4c 89 1f             	mov    %r11,(%rdi)
 10c954f:	4e 89 54 0f f8       	mov    %r10,-0x8(%rdi,%r9,1)
 10c9554:	48 83 fa 01          	cmp    $0x1,%rdx
 10c9558:	0f 84 7a 01 00 00    	je     10c96d8 <join_short+0x598>
 10c955e:	4c 01 cf             	add    %r9,%rdi
 10c9561:	41 b9 01 00 00 00    	mov    $0x1,%r9d
 10c9567:	eb 26                	jmp    10c958f <join_short+0x44f>
 10c9569:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
 10c9570:	49 8b 1b             	mov    (%r11),%rbx
 10c9573:	4f 8b 5c 13 f8       	mov    -0x8(%r11,%r10,1),%r11
 10c9578:	48 89 1f             	mov    %rbx,(%rdi)
 10c957b:	4e 89 5c 17 f8       	mov    %r11,-0x8(%rdi,%r10,1)
 10c9580:	4c 01 d7             	add    %r10,%rdi
 10c9583:	49 ff c1             	inc    %r9
 10c9586:	4c 39 ca             	cmp    %r9,%rdx
 10c9589:	0f 84 49 01 00 00    	je     10c96d8 <join_short+0x598>
 10c958f:	66 89 07             	mov    %ax,(%rdi)
 10c9592:	66 42 89 4c 07 fe    	mov    %cx,-0x2(%rdi,%r8,1)
 10c9598:	4c 01 c7             	add    %r8,%rdi
 10c959b:	4e 8b 1c ce          	mov    (%rsi,%r9,8),%r11
 10c959f:	4d 8b 53 08          	mov    0x8(%r11),%r10
 10c95a3:	4d 85 d2             	test   %r10,%r10
 10c95a6:	74 d8                	je     10c9580 <join_short+0x440>
 10c95a8:	41 f6 43 10 04       	testb  $0x4,0x10(%r11)
 10c95ad:	75 11                	jne    10c95c0 <join_short+0x480>
 10c95af:	49 83 c3 18          	add    $0x18,%r11
 10c95b3:	49 83 fa 08          	cmp    $0x8,%r10
 10c95b7:	73 b7                	jae    10c9570 <join_short+0x430>
 10c95b9:	eb 1a                	jmp    10c95d5 <join_short+0x495>
 10c95bb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
 10c95c0:	49 8b 5b 18          	mov    0x18(%r11),%rbx
 10c95c4:	45 8b 5b 14          	mov    0x14(%r11),%r11d
 10c95c8:	49 01 db             	add    %rbx,%r11
 10c95cb:	49 83 c3 18          	add    $0x18,%r11
 10c95cf:	49 83 fa 08          	cmp    $0x8,%r10
 10c95d3:	73 9b                	jae    10c9570 <join_short+0x430>
 10c95d5:	49 83 fa 04          	cmp    $0x4,%r10
 10c95d9:	72 11                	jb     10c95ec <join_short+0x4ac>
 10c95db:	41 8b 1b             	mov    (%r11),%ebx
 10c95de:	47 8b 5c 13 fc       	mov    -0x4(%r11,%r10,1),%r11d
 10c95e3:	89 1f                	mov    %ebx,(%rdi)
 10c95e5:	46 89 5c 17 fc       	mov    %r11d,-0x4(%rdi,%r10,1)
 10c95ea:	eb 94                	jmp    10c9580 <join_short+0x440>
 10c95ec:	49 83 fa 01          	cmp    $0x1,%r10
 10c95f0:	75 09                	jne    10c95fb <join_short+0x4bb>
 10c95f2:	45 0f b6 1b          	movzbl (%r11),%r11d
 10c95f6:	44 88 1f             	mov    %r11b,(%rdi)
 10c95f9:	eb 85                	jmp    10c9580 <join_short+0x440>
 10c95fb:	41 0f b7 1b          	movzwl (%r11),%ebx
 10c95ff:	47 0f b7 5c 13 fe    	movzwl -0x2(%r11,%r10,1),%r11d
 10c9605:	66 89 1f             	mov    %bx,(%rdi)
 10c9608:	66 46 89 5c 17 fe    	mov    %r11w,-0x2(%rdi,%r10,1)
 10c960e:	e9 6d ff ff ff       	jmp    10c9580 <join_short+0x440>
 10c9613:	45 0f b7 1a          	movzwl (%r10),%r11d
 10c9617:	47 0f b7 54 0a fe    	movzwl -0x2(%r10,%r9,1),%r10d
 10c961d:	66 44 89 1f          	mov    %r11w,(%rdi)
 10c9621:	66 46 89 54 0f fe    	mov    %r10w,-0x2(%rdi,%r9,1)
 10c9627:	e9 51 fc ff ff       	jmp    10c927d <join_short+0x13d>
 10c962c:	4d 8b 48 18          	mov    0x18(%r8),%r9
 10c9630:	45 8b 40 14          	mov    0x14(%r8),%r8d
 10c9634:	4d 01 c8             	add    %r9,%r8
 10c9637:	49 83 c0 18          	add    $0x18,%r8
 10c963b:	48 83 f9 07          	cmp    $0x7,%rcx
 10c963f:	76 12                	jbe    10c9653 <join_short+0x513>
 10c9641:	4d 8b 08             	mov    (%r8),%r9
 10c9644:	4d 8b 44 08 f8       	mov    -0x8(%r8,%rcx,1),%r8
 10c9649:	4c 89 0f             	mov    %r9,(%rdi)
 10c964c:	4c 89 44 0f f8       	mov    %r8,-0x8(%rdi,%rcx,1)
 10c9651:	eb 7f                	jmp    10c96d2 <join_short+0x592>
 10c9653:	48 83 f9 03          	cmp    $0x3,%rcx
 10c9657:	76 3d                	jbe    10c9696 <join_short+0x556>
 10c9659:	45 8b 08             	mov    (%r8),%r9d
 10c965c:	45 8b 44 08 fc       	mov    -0x4(%r8,%rcx,1),%r8d
 10c9661:	44 89 0f             	mov    %r9d,(%rdi)
 10c9664:	44 89 44 0f fc       	mov    %r8d,-0x4(%rdi,%rcx,1)
 10c9669:	eb 67                	jmp    10c96d2 <join_short+0x592>
 10c966b:	49 83 f9 01          	cmp    $0x1,%r9
 10c966f:	75 34                	jne    10c96a5 <join_short+0x565>
 10c9671:	45 0f b6 12          	movzbl (%r10),%r10d
 10c9675:	44 88 17             	mov    %r10b,(%rdi)
 10c9678:	e9 d7 fe ff ff       	jmp    10c9554 <join_short+0x414>
 10c967d:	45 0f b7 1a          	movzwl (%r10),%r11d
 10c9681:	47 0f b7 54 0a fe    	movzwl -0x2(%r10,%r9,1),%r10d
 10c9687:	66 44 89 1f          	mov    %r11w,(%rdi)
 10c968b:	66 46 89 54 0f fe    	mov    %r10w,-0x2(%rdi,%r9,1)
 10c9691:	e9 1c fd ff ff       	jmp    10c93b2 <join_short+0x272>
 10c9696:	48 83 f9 01          	cmp    $0x1,%rcx
 10c969a:	75 22                	jne    10c96be <join_short+0x57e>
 10c969c:	45 0f b6 00          	movzbl (%r8),%r8d
 10c96a0:	44 88 07             	mov    %r8b,(%rdi)
 10c96a3:	eb 2d                	jmp    10c96d2 <join_short+0x592>
 10c96a5:	45 0f b7 1a          	movzwl (%r10),%r11d
 10c96a9:	47 0f b7 54 0a fe    	movzwl -0x2(%r10,%r9,1),%r10d
 10c96af:	66 44 89 1f          	mov    %r11w,(%rdi)
 10c96b3:	66 46 89 54 0f fe    	mov    %r10w,-0x2(%rdi,%r9,1)
 10c96b9:	e9 96 fe ff ff       	jmp    10c9554 <join_short+0x414>
 10c96be:	45 0f b7 08          	movzwl (%r8),%r9d
 10c96c2:	45 0f b7 44 08 fe    	movzwl -0x2(%r8,%rcx,1),%r8d
 10c96c8:	66 44 89 0f          	mov    %r9w,(%rdi)
 10c96cc:	66 44 89 44 0f fe    	mov    %r8w,-0x2(%rdi,%rcx,1)
 10c96d2:	48 83 fa 01          	cmp    $0x1,%rdx
 10c96d6:	75 03                	jne    10c96db <join_short+0x59b>
 10c96d8:	5b                   	pop    %rbx
 10c96d9:	5d                   	pop    %rbp
 10c96da:	c3                   	ret
 10c96db:	48 01 cf             	add    %rcx,%rdi
 10c96de:	b9 01 00 00 00       	mov    $0x1,%ecx
 10c96e3:	eb 26                	jmp    10c970b <join_short+0x5cb>
 10c96e5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
 10c96ec:	00 00 00 00 
 10c96f0:	4d 8b 11             	mov    (%r9),%r10
 10c96f3:	4f 8b 4c 01 f8       	mov    -0x8(%r9,%r8,1),%r9
 10c96f8:	4c 89 17             	mov    %r10,(%rdi)
 10c96fb:	4e 89 4c 07 f8       	mov    %r9,-0x8(%rdi,%r8,1)
 10c9700:	4c 01 c7             	add    %r8,%rdi
 10c9703:	48 ff c1             	inc    %rcx
 10c9706:	48 39 ca             	cmp    %rcx,%rdx
 10c9709:	74 cd                	je     10c96d8 <join_short+0x598>
 10c970b:	88 07                	mov    %al,(%rdi)
 10c970d:	48 ff c7             	inc    %rdi
 10c9710:	4c 8b 0c ce          	mov    (%rsi,%rcx,8),%r9
 10c9714:	4d 8b 41 08          	mov    0x8(%r9),%r8
 10c9718:	4d 85 c0             	test   %r8,%r8
 10c971b:	74 e3                	je     10c9700 <join_short+0x5c0>
 10c971d:	41 f6 41 10 04       	testb  $0x4,0x10(%r9)
 10c9722:	75 0c                	jne    10c9730 <join_short+0x5f0>
 10c9724:	49 83 c1 18          	add    $0x18,%r9
 10c9728:	49 83 f8 08          	cmp    $0x8,%r8
 10c972c:	73 c2                	jae    10c96f0 <join_short+0x5b0>
 10c972e:	eb 15                	jmp    10c9745 <join_short+0x605>
 10c9730:	4d 8b 51 18          	mov    0x18(%r9),%r10
 10c9734:	45 8b 49 14          	mov    0x14(%r9),%r9d
 10c9738:	4d 01 d1             	add    %r10,%r9
 10c973b:	49 83 c1 18          	add    $0x18,%r9
 10c973f:	49 83 f8 08          	cmp    $0x8,%r8
 10c9743:	73 ab                	jae    10c96f0 <join_short+0x5b0>
 10c9745:	49 83 f8 04          	cmp    $0x4,%r8
 10c9749:	72 12                	jb     10c975d <join_short+0x61d>
 10c974b:	45 8b 11             	mov    (%r9),%r10d
 10c974e:	47 8b 4c 01 fc       	mov    -0x4(%r9,%r8,1),%r9d
 10c9753:	44 89 17             	mov    %r10d,(%rdi)
 10c9756:	46 89 4c 07 fc       	mov    %r9d,-0x4(%rdi,%r8,1)
 10c975b:	eb a3                	jmp    10c9700 <join_short+0x5c0>
 10c975d:	49 83 f8 01          	cmp    $0x1,%r8
 10c9761:	75 09                	jne    10c976c <join_short+0x62c>
 10c9763:	45 0f b6 09          	movzbl (%r9),%r9d
 10c9767:	44 88 0f             	mov    %r9b,(%rdi)
 10c976a:	eb 94                	jmp    10c9700 <join_short+0x5c0>
 10c976c:	45 0f b7 11          	movzwl (%r9),%r10d
 10c9770:	47 0f b7 4c 01 fe    	movzwl -0x2(%r9,%r8,1),%r9d
 10c9776:	66 44 89 17          	mov    %r10w,(%rdi)
 10c977a:	66 46 89 4c 07 fe    	mov    %r9w,-0x2(%rdi,%r8,1)
 10c9780:	e9 7b ff ff ff       	jmp    10c9700 <join_short+0x5c0>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
