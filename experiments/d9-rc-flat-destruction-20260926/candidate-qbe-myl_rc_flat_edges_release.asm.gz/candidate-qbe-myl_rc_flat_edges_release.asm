
/home/epentland/ai/canopy/mylang-worktrees/d9-rc-flat-destruction-astra/.tmp-flat/candidate-qbe-rc-n12:     file format elf64-x86-64


Disassembly of section .text:

0000000001022ff0 <myl_rc_flat_edges_release>:
 1022ff0:	push   %rbp
 1022ff1:	mov    %rsp,%rbp
 1022ff4:	push   %r15
 1022ff6:	push   %r14
 1022ff8:	push   %r13
 1022ffa:	push   %r12
 1022ffc:	push   %rbx
 1022ffd:	sub    $0x18,%rsp
 1023001:	mov    %rcx,-0x30(%rbp)
 1023005:	test   %rdi,%rdi
 1023008:	je     10230e6 <myl_rc_flat_edges_release+0xf6>
 102300e:	mov    %rdi,%r12
 1023011:	mov    0x1608(%rdi),%rax
 1023018:	test   %rax,%rax
 102301b:	je     10230e6 <myl_rc_flat_edges_release+0xf6>
 1023021:	cmpq   $0x0,0x58(%rax)
 1023026:	jne    10230e6 <myl_rc_flat_edges_release+0xf6>
 102302c:	mov    %rsi,%r15
 102302f:	cmpl   $0x9,0x78(%rsi)
 1023033:	jae    10230e6 <myl_rc_flat_edges_release+0xf6>
 1023039:	mov    %rdx,%r14
 102303c:	mov    (%r15),%rax
 102303f:	mov    (%rax),%rdi
 1023042:	lea    -0x38(%rbp),%rdx
 1023046:	mov    -0x30(%rbp),%rsi
 102304a:	call   1020880 <myl_rc_size_mul>
 102304f:	test   %eax,%eax
 1023051:	je     10230e6 <myl_rc_flat_edges_release+0xf6>
 1023057:	test   %r14,%r14
 102305a:	jne    1023067 <myl_rc_flat_edges_release+0x77>
 102305c:	cmpq   $0x0,-0x38(%rbp)
 1023061:	jne    10230e6 <myl_rc_flat_edges_release+0xf6>
 1023067:	cmpl   $0x0,0x78(%r15)
 102306c:	sete   %al
 102306f:	cmpq   $0x0,-0x30(%rbp)
 1023074:	sete   %cl
 1023077:	or     %al,%cl
 1023079:	jne    10230d7 <myl_rc_flat_edges_release+0xe7>
 102307b:	mov    $0x1,%eax
 1023080:	xor    %r13d,%r13d
 1023083:	jmp    102309f <myl_rc_flat_edges_release+0xaf>
 1023085:	data16 cs nopw 0x0(%rax,%rax,1)
 1023090:	mov    (%r15),%rcx
 1023093:	add    (%rcx),%r14
 1023096:	inc    %r13
 1023099:	cmp    -0x30(%rbp),%r13
 102309d:	je     10230d7 <myl_rc_flat_edges_release+0xe7>
 102309f:	test   %eax,%eax
 10230a1:	mov    $0x0,%eax
 10230a6:	je     1023090 <myl_rc_flat_edges_release+0xa0>
 10230a8:	xor    %ebx,%ebx
 10230aa:	nopw   0x0(%rax,%rax,1)
 10230b0:	mov    0x38(%r15,%rbx,8),%rax
 10230b5:	mov    (%r14,%rax,1),%rsi
 10230b9:	movq   $0x0,(%r14,%rax,1)
 10230c1:	mov    %r12,%rdi
 10230c4:	call   1020dd0 <myl_rc_edge_release>
 10230c9:	inc    %rbx
 10230cc:	mov    0x78(%r15),%eax
 10230d0:	cmp    %rax,%rbx
 10230d3:	jb     10230b0 <myl_rc_flat_edges_release+0xc0>
 10230d5:	jmp    1023090 <myl_rc_flat_edges_release+0xa0>
 10230d7:	add    $0x18,%rsp
 10230db:	pop    %rbx
 10230dc:	pop    %r12
 10230de:	pop    %r13
 10230e0:	pop    %r14
 10230e2:	pop    %r15
 10230e4:	pop    %rbp
 10230e5:	ret
 10230e6:	call   102084e <myl_rc_invariant_failed>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
