
/home/epentland/ai/canopy/mylang-worktrees/d9-rc-flat-destruction-astra/.tmp-flat/candidate-llvm-rc-n12:     file format elf64-x86-64


Disassembly of section .text:

0000000001025390 <myl_rc_drain>:
 1025390:	push   %rbp
 1025391:	mov    %rsp,%rbp
 1025394:	push   %r15
 1025396:	push   %r14
 1025398:	push   %r13
 102539a:	push   %r12
 102539c:	push   %rbx
 102539d:	push   %rax
 102539e:	test   %rdi,%rdi
 10253a1:	je     10256ba <myl_rc_drain+0x32a>
 10253a7:	mov    %rdi,%rbx
 10253aa:	mov    0x1608(%rdi),%rax
 10253b1:	test   %rax,%rax
 10253b4:	je     10256ba <myl_rc_drain+0x32a>
 10253ba:	cmpl   $0x0,0x68(%rax)
 10253be:	jne    10256c6 <myl_rc_drain+0x336>
 10253c4:	cmpq   $0x0,0x58(%rax)
 10253c9:	jne    10256c6 <myl_rc_drain+0x336>
 10253cf:	movl   $0x1,0x68(%rax)
 10253d6:	mov    0x60(%rax),%r12
 10253da:	test   %r12,%r12
 10253dd:	je     10256bf <myl_rc_drain+0x32f>
 10253e3:	movabs $0x4000000000000002,%r13
 10253ed:	nopl   (%rax)
 10253f0:	mov    (%r12),%rcx
 10253f4:	mov    %rcx,0x60(%rax)
 10253f8:	mov    0x18(%r12),%rcx
 10253fd:	test   %rcx,%rcx
 1025400:	je     10256ba <myl_rc_drain+0x32a>
 1025406:	test   %rax,%rax
 1025409:	je     10256ba <myl_rc_drain+0x32a>
 102540f:	mov    0x40(%rax),%rdx
 1025413:	test   %rdx,%rdx
 1025416:	je     10256ba <myl_rc_drain+0x32a>
 102541c:	mov    0x30(%rax),%rsi
 1025420:	mov    %rcx,%rdi
 1025423:	shr    $0x3,%rdi
 1025427:	mov    %rcx,%r8
 102542a:	shr    $0x21,%r8
 102542e:	xor    %rdi,%r8
 1025431:	movabs $0xbf58476d1ce4e5b9,%rdi
 102543b:	imul   %rdi,%r8
 102543f:	mov    %r8,%rdi
 1025442:	shr    $0x1b,%rdi
 1025446:	xor    %r8,%rdi
 1025449:	xor    $0x2,%rdi
 102544d:	dec    %rdx
 1025450:	and    %rdx,%rdi
 1025453:	lea    (%rdi,%rdi,4),%r8
 1025457:	mov    (%rsi,%r8,8),%r8
 102545b:	test   %r8,%r8
 102545e:	je     10256ba <myl_rc_drain+0x32a>
 1025464:	lea    0x20(%r12),%r14
 1025469:	jmp    1025487 <myl_rc_drain+0xf7>
 102546b:	nopl   0x0(%rax,%rax,1)
 1025470:	inc    %rdi
 1025473:	and    %rdx,%rdi
 1025476:	lea    (%rdi,%rdi,4),%r8
 102547a:	mov    (%rsi,%r8,8),%r8
 102547e:	test   %r8,%r8
 1025481:	je     10256ba <myl_rc_drain+0x32a>
 1025487:	cmp    %rcx,%r8
 102548a:	jne    1025470 <myl_rc_drain+0xe0>
 102548c:	lea    (%rdi,%rdi,4),%r8
 1025490:	cmpl   $0x2,0x20(%rsi,%r8,8)
 1025496:	jne    1025470 <myl_rc_drain+0xe0>
 1025498:	lea    (%rsi,%r8,8),%rdx
 102549c:	mov    0x8(%rdx),%rsi
 10254a0:	test   %rsi,%rsi
 10254a3:	je     10256ba <myl_rc_drain+0x32a>
 10254a9:	mov    $0x3c,%edx
 10254ae:	bzhi   %rdx,0x10(%r12),%r15
 10254b5:	shr    $0x2,%r15
 10254b9:	mov    0x78(%rsi),%edx
 10254bc:	cmp    $0x8,%edx
 10254bf:	ja     1025560 <myl_rc_drain+0x1d0>
 10254c5:	cmp    $0x1,%r15
 10254c9:	jne    1025650 <myl_rc_drain+0x2c0>
 10254cf:	test   %edx,%edx
 10254d1:	je     102565e <myl_rc_drain+0x2ce>
 10254d7:	xor    %eax,%eax
 10254d9:	jmp    10254ef <myl_rc_drain+0x15f>
 10254db:	nopl   0x0(%rax,%rax,1)
 10254e0:	inc    %rax
 10254e3:	mov    0x78(%rsi),%ecx
 10254e6:	cmp    %rcx,%rax
 10254e9:	jae    102565e <myl_rc_drain+0x2ce>
 10254ef:	mov    0x38(%rsi,%rax,8),%rdx
 10254f4:	mov    (%r14,%rdx,1),%rcx
 10254f8:	movq   $0x0,(%r14,%rdx,1)
 1025500:	test   %rcx,%rcx
 1025503:	je     10254e0 <myl_rc_drain+0x150>
 1025505:	mov    -0x10(%rcx),%rdx
 1025509:	test   %r13,%rdx
 102550c:	jne    10254e0 <myl_rc_drain+0x150>
 102550e:	mov    0x1608(%rbx),%rdi
 1025515:	test   %rdi,%rdi
 1025518:	je     10256ba <myl_rc_drain+0x32a>
 102551e:	test   $0x1,%dl
 1025521:	jne    10256ba <myl_rc_drain+0x32a>
 1025527:	lea    -0x20(%rcx),%r8
 102552b:	mov    (%r8),%r9
 102552e:	test   %r9,%r9
 1025531:	je     10256ba <myl_rc_drain+0x32a>
 1025537:	dec    %r9
 102553a:	mov    %r9,(%r8)
 102553d:	jne    10254e0 <myl_rc_drain+0x150>
 102553f:	cmpq   $0x0,-0x18(%rcx)
 1025544:	jne    10254e0 <myl_rc_drain+0x150>
 1025546:	or     $0x1,%rdx
 102554a:	mov    %rdx,-0x10(%rcx)
 102554e:	mov    0x60(%rdi),%rdx
 1025552:	mov    %rdx,-0x20(%rcx)
 1025556:	mov    %r8,0x60(%rdi)
 102555a:	jmp    10254e0 <myl_rc_drain+0x150>
 102555c:	nopl   0x0(%rax)
 1025560:	mov    0x18(%rsi),%rdx
 1025564:	test   %rdx,%rdx
 1025567:	je     102557d <myl_rc_drain+0x1ed>
 1025569:	mov    %rbx,%rdi
 102556c:	mov    %r14,%rsi
 102556f:	call   *%rdx
 1025571:	mov    0x18(%r12),%rcx
 1025576:	mov    0x1608(%rbx),%rax
 102557d:	test   %rcx,%rcx
 1025580:	je     10256ba <myl_rc_drain+0x32a>
 1025586:	test   %rax,%rax
 1025589:	je     10256ba <myl_rc_drain+0x32a>
 102558f:	mov    0x40(%rax),%rdx
 1025593:	test   %rdx,%rdx
 1025596:	je     10256ba <myl_rc_drain+0x32a>
 102559c:	mov    0x30(%rax),%rsi
 10255a0:	mov    %rcx,%rdi
 10255a3:	shr    $0x3,%rdi
 10255a7:	mov    %rcx,%r8
 10255aa:	shr    $0x21,%r8
 10255ae:	xor    %rdi,%r8
 10255b1:	movabs $0xbf58476d1ce4e5b9,%rdi
 10255bb:	imul   %rdi,%r8
 10255bf:	mov    %r8,%rdi
 10255c2:	shr    $0x1b,%rdi
 10255c6:	xor    %r8,%rdi
 10255c9:	xor    $0x2,%rdi
 10255cd:	dec    %rdx
 10255d0:	jmp    10255e3 <myl_rc_drain+0x253>
 10255d2:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 10255e0:	inc    %rdi
 10255e3:	and    %rdx,%rdi
 10255e6:	lea    (%rdi,%rdi,4),%r8
 10255ea:	mov    (%rsi,%r8,8),%r8
 10255ee:	test   %r8,%r8
 10255f1:	je     10256ba <myl_rc_drain+0x32a>
 10255f7:	cmp    %rcx,%r8
 10255fa:	jne    10255e0 <myl_rc_drain+0x250>
 10255fc:	lea    (%rdi,%rdi,4),%r8
 1025600:	cmpl   $0x2,0x20(%rsi,%r8,8)
 1025606:	jne    10255e0 <myl_rc_drain+0x250>
 1025608:	lea    (%rsi,%r8,8),%rcx
 102560c:	mov    0x8(%rcx),%rcx
 1025610:	test   %rcx,%rcx
 1025613:	je     10256ba <myl_rc_drain+0x32a>
 1025619:	cmpq   $0x0,0x58(%rax)
 102561e:	jne    10256ba <myl_rc_drain+0x32a>
 1025624:	mov    0x10(%rcx),%rax
 1025628:	test   %rax,%rax
 102562b:	je     102569a <myl_rc_drain+0x30a>
 102562d:	mov    %rbx,%rdi
 1025630:	mov    %r14,%rsi
 1025633:	mov    %r15,%rdx
 1025636:	call   *%rax
 1025638:	mov    0x1608(%rbx),%rax
 102563f:	cmpq   $0x0,0x58(%rax)
 1025644:	je     102566c <myl_rc_drain+0x2dc>
 1025646:	jmp    10256ba <myl_rc_drain+0x32a>
 1025648:	nopl   0x0(%rax,%rax,1)
 1025650:	mov    %rbx,%rdi
 1025653:	mov    %r14,%rdx
 1025656:	mov    %r15,%rcx
 1025659:	call   1025240 <myl_rc_flat_edges_release>
 102565e:	mov    0x1608(%rbx),%rax
 1025665:	cmpq   $0x0,0x58(%rax)
 102566a:	jne    10256ba <myl_rc_drain+0x32a>
 102566c:	mov    0x10(%r12),%rcx
 1025671:	test   %r13,%rcx
 1025674:	jne    10256ba <myl_rc_drain+0x32a>
 1025676:	test   $0x1,%cl
 1025679:	je     10256ba <myl_rc_drain+0x32a>
 102567b:	mov    %rbx,%rdi
 102567e:	mov    %r14,%rsi
 1025681:	call   *0x8(%rax)
 1025684:	mov    0x1608(%rbx),%rax
 102568b:	mov    0x60(%rax),%r12
 102568f:	test   %r12,%r12
 1025692:	jne    10253f0 <myl_rc_drain+0x60>
 1025698:	jmp    10256bf <myl_rc_drain+0x32f>
 102569a:	mov    0x8(%rcx),%rsi
 102569e:	mov    %rbx,%rdi
 10256a1:	mov    %r14,%rdx
 10256a4:	mov    %r15,%rcx
 10256a7:	call   1024ec0 <myl_rc_edges_release>
 10256ac:	mov    0x1608(%rbx),%rax
 10256b3:	cmpq   $0x0,0x58(%rax)
 10256b8:	je     102566c <myl_rc_drain+0x2dc>
 10256ba:	call   1022ed1 <myl_rc_invariant_failed>
 10256bf:	movl   $0x0,0x68(%rax)
 10256c6:	add    $0x8,%rsp
 10256ca:	pop    %rbx
 10256cb:	pop    %r12
 10256cd:	pop    %r13
 10256cf:	pop    %r14
 10256d1:	pop    %r15
 10256d3:	pop    %rbp
 10256d4:	ret

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
