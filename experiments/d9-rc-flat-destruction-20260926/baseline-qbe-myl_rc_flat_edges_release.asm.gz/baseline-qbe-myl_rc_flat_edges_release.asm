
/home/epentland/ai/canopy/mylang-worktrees/d9-rc-flat-destruction-astra/.tmp-flat/inert-qbe-rc-repeat:     file format elf64-x86-64


Disassembly of section .text:

0000000001023070 <myl_rc_flat_edges_release>:
 1023070:	push   %rbp
 1023071:	mov    %rsp,%rbp
 1023074:	push   %r15
 1023076:	push   %r14
 1023078:	push   %r13
 102307a:	push   %r12
 102307c:	push   %rbx
 102307d:	sub    $0x18,%rsp
 1023081:	mov    %rcx,-0x30(%rbp)
 1023085:	test   %rdi,%rdi
 1023088:	je     1023166 <myl_rc_flat_edges_release+0xf6>
 102308e:	mov    %rdi,%r12
 1023091:	mov    0x1608(%rdi),%rax
 1023098:	test   %rax,%rax
 102309b:	je     1023166 <myl_rc_flat_edges_release+0xf6>
 10230a1:	cmpq   $0x0,0x58(%rax)
 10230a6:	jne    1023166 <myl_rc_flat_edges_release+0xf6>
 10230ac:	mov    %rsi,%r15
 10230af:	cmpl   $0x9,0x78(%rsi)
 10230b3:	jae    1023166 <myl_rc_flat_edges_release+0xf6>
 10230b9:	mov    %rdx,%r14
 10230bc:	mov    (%r15),%rax
 10230bf:	mov    (%rax),%rdi
 10230c2:	lea    -0x38(%rbp),%rdx
 10230c6:	mov    -0x30(%rbp),%rsi
 10230ca:	call   1020900 <myl_rc_size_mul>
 10230cf:	test   %eax,%eax
 10230d1:	je     1023166 <myl_rc_flat_edges_release+0xf6>
 10230d7:	test   %r14,%r14
 10230da:	jne    10230e7 <myl_rc_flat_edges_release+0x77>
 10230dc:	cmpq   $0x0,-0x38(%rbp)
 10230e1:	jne    1023166 <myl_rc_flat_edges_release+0xf6>
 10230e7:	cmpl   $0x0,0x78(%r15)
 10230ec:	sete   %al
 10230ef:	cmpq   $0x0,-0x30(%rbp)
 10230f4:	sete   %cl
 10230f7:	or     %al,%cl
 10230f9:	jne    1023157 <myl_rc_flat_edges_release+0xe7>
 10230fb:	mov    $0x1,%eax
 1023100:	xor    %r13d,%r13d
 1023103:	jmp    102311f <myl_rc_flat_edges_release+0xaf>
 1023105:	data16 cs nopw 0x0(%rax,%rax,1)
 1023110:	mov    (%r15),%rcx
 1023113:	add    (%rcx),%r14
 1023116:	inc    %r13
 1023119:	cmp    -0x30(%rbp),%r13
 102311d:	je     1023157 <myl_rc_flat_edges_release+0xe7>
 102311f:	test   %eax,%eax
 1023121:	mov    $0x0,%eax
 1023126:	je     1023110 <myl_rc_flat_edges_release+0xa0>
 1023128:	xor    %ebx,%ebx
 102312a:	nopw   0x0(%rax,%rax,1)
 1023130:	mov    0x38(%r15,%rbx,8),%rax
 1023135:	mov    (%r14,%rax,1),%rsi
 1023139:	movq   $0x0,(%r14,%rax,1)
 1023141:	mov    %r12,%rdi
 1023144:	call   1020e50 <myl_rc_edge_release>
 1023149:	inc    %rbx
 102314c:	mov    0x78(%r15),%eax
 1023150:	cmp    %rax,%rbx
 1023153:	jb     1023130 <myl_rc_flat_edges_release+0xc0>
 1023155:	jmp    1023110 <myl_rc_flat_edges_release+0xa0>
 1023157:	add    $0x18,%rsp
 102315b:	pop    %rbx
 102315c:	pop    %r12
 102315e:	pop    %r13
 1023160:	pop    %r14
 1023162:	pop    %r15
 1023164:	pop    %rbp
 1023165:	ret
 1023166:	call   10208ce <myl_rc_invariant_failed>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
