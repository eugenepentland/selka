
/home/epentland/ai/canopy/mylang-worktrees/d9-rc-flat-destruction-astra/.tmp-flat/candidate-llvm-rc-n12:     file format elf64-x86-64


Disassembly of section .text:

0000000001025240 <myl_rc_flat_edges_release>:
 1025240:	push   %rbp
 1025241:	mov    %rsp,%rbp
 1025244:	push   %r15
 1025246:	push   %r14
 1025248:	push   %rbx
 1025249:	push   %rax
 102524a:	test   %rdi,%rdi
 102524d:	je     1025389 <myl_rc_flat_edges_release+0x149>
 1025253:	mov    0x1608(%rdi),%rax
 102525a:	test   %rax,%rax
 102525d:	je     1025389 <myl_rc_flat_edges_release+0x149>
 1025263:	cmpq   $0x0,0x58(%rax)
 1025268:	jne    1025389 <myl_rc_flat_edges_release+0x149>
 102526e:	mov    0x78(%rsi),%r10d
 1025272:	cmp    $0x9,%r10d
 1025276:	jae    1025389 <myl_rc_flat_edges_release+0x149>
 102527c:	mov    %rdx,%r8
 102527f:	mov    (%rsi),%rax
 1025282:	mov    (%rax),%r9
 1025285:	test   %r9,%r9
 1025288:	je     1025296 <myl_rc_flat_edges_release+0x56>
 102528a:	mov    %r9,%rax
 102528d:	mul    %rcx
 1025290:	jo     1025389 <myl_rc_flat_edges_release+0x149>
 1025296:	test   %r8,%r8
 1025299:	jne    10252ab <myl_rc_flat_edges_release+0x6b>
 102529b:	mov    %rcx,%rax
 102529e:	imul   %r9,%rax
 10252a2:	test   %rax,%rax
 10252a5:	jne    1025389 <myl_rc_flat_edges_release+0x149>
 10252ab:	test   %r10d,%r10d
 10252ae:	sete   %al
 10252b1:	test   %rcx,%rcx
 10252b4:	sete   %dl
 10252b7:	or     %al,%dl
 10252b9:	jne    102537e <myl_rc_flat_edges_release+0x13e>
 10252bf:	mov    $0x1,%r10d
 10252c5:	xor    %eax,%eax
 10252c7:	movabs $0x4000000000000002,%rdx
 10252d1:	jmp    10252f5 <myl_rc_flat_edges_release+0xb5>
 10252d3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 10252e0:	mov    (%rsi),%r9
 10252e3:	mov    (%r9),%r9
 10252e6:	add    %r9,%r8
 10252e9:	inc    %rax
 10252ec:	cmp    %rcx,%rax
 10252ef:	je     102537e <myl_rc_flat_edges_release+0x13e>
 10252f5:	test   %r10d,%r10d
 10252f8:	mov    $0x0,%r10d
 10252fe:	je     10252e6 <myl_rc_flat_edges_release+0xa6>
 1025300:	xor    %r9d,%r9d
 1025303:	jmp    102531c <myl_rc_flat_edges_release+0xdc>
 1025305:	data16 cs nopw 0x0(%rax,%rax,1)
 1025310:	inc    %r9
 1025313:	mov    0x78(%rsi),%r10d
 1025317:	cmp    %r10,%r9
 102531a:	jae    10252e0 <myl_rc_flat_edges_release+0xa0>
 102531c:	mov    0x38(%rsi,%r9,8),%r11
 1025321:	mov    (%r8,%r11,1),%r10
 1025325:	movq   $0x0,(%r8,%r11,1)
 102532d:	test   %r10,%r10
 1025330:	je     1025310 <myl_rc_flat_edges_release+0xd0>
 1025332:	mov    -0x10(%r10),%r11
 1025336:	test   %rdx,%r11
 1025339:	jne    1025310 <myl_rc_flat_edges_release+0xd0>
 102533b:	mov    0x1608(%rdi),%rbx
 1025342:	test   %rbx,%rbx
 1025345:	je     1025389 <myl_rc_flat_edges_release+0x149>
 1025347:	test   $0x1,%r11b
 102534b:	jne    1025389 <myl_rc_flat_edges_release+0x149>
 102534d:	lea    -0x20(%r10),%r14
 1025351:	mov    (%r14),%r15
 1025354:	test   %r15,%r15
 1025357:	je     1025389 <myl_rc_flat_edges_release+0x149>
 1025359:	dec    %r15
 102535c:	mov    %r15,(%r14)
 102535f:	jne    1025310 <myl_rc_flat_edges_release+0xd0>
 1025361:	cmpq   $0x0,-0x18(%r10)
 1025366:	jne    1025310 <myl_rc_flat_edges_release+0xd0>
 1025368:	or     $0x1,%r11
 102536c:	mov    %r11,-0x10(%r10)
 1025370:	mov    0x60(%rbx),%r11
 1025374:	mov    %r11,-0x20(%r10)
 1025378:	mov    %r14,0x60(%rbx)
 102537c:	jmp    1025310 <myl_rc_flat_edges_release+0xd0>
 102537e:	add    $0x8,%rsp
 1025382:	pop    %rbx
 1025383:	pop    %r14
 1025385:	pop    %r15
 1025387:	pop    %rbp
 1025388:	ret
 1025389:	call   1022ed1 <myl_rc_invariant_failed>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
