
/home/epentland/ai/canopy/mylang-worktrees/d9-rc-flat-destruction-astra/.tmp-flat/inert-qbe-rc-repeat:     file format elf64-x86-64


Disassembly of section .text:

0000000001020e50 <myl_rc_edge_release>:
 1020e50:	push   %rbp
 1020e51:	mov    %rsp,%rbp
 1020e54:	test   %rsi,%rsi
 1020e57:	je     1020e6c <myl_rc_edge_release+0x1c>
 1020e59:	mov    -0x10(%rsi),%rax
 1020e5d:	movabs $0x4000000000000002,%rcx
 1020e67:	test   %rcx,%rax
 1020e6a:	je     1020e6e <myl_rc_edge_release+0x1e>
 1020e6c:	pop    %rbp
 1020e6d:	ret
 1020e6e:	test   %rdi,%rdi
 1020e71:	je     1020eb4 <myl_rc_edge_release+0x64>
 1020e73:	mov    0x1608(%rdi),%rcx
 1020e7a:	test   %rcx,%rcx
 1020e7d:	je     1020eb4 <myl_rc_edge_release+0x64>
 1020e7f:	test   $0x1,%al
 1020e81:	jne    1020eb4 <myl_rc_edge_release+0x64>
 1020e83:	lea    -0x20(%rsi),%rdx
 1020e87:	mov    (%rdx),%rdi
 1020e8a:	test   %rdi,%rdi
 1020e8d:	je     1020eb4 <myl_rc_edge_release+0x64>
 1020e8f:	dec    %rdi
 1020e92:	mov    %rdi,(%rdx)
 1020e95:	jne    1020e6c <myl_rc_edge_release+0x1c>
 1020e97:	cmpq   $0x0,-0x18(%rsi)
 1020e9c:	jne    1020e6c <myl_rc_edge_release+0x1c>
 1020e9e:	or     $0x1,%rax
 1020ea2:	mov    %rax,-0x10(%rsi)
 1020ea6:	mov    0x60(%rcx),%rax
 1020eaa:	mov    %rax,-0x20(%rsi)
 1020eae:	mov    %rdx,0x60(%rcx)
 1020eb2:	pop    %rbp
 1020eb3:	ret
 1020eb4:	call   10208ce <myl_rc_invariant_failed>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
