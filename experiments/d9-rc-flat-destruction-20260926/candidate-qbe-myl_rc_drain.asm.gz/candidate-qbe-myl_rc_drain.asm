
/home/epentland/ai/canopy/mylang-worktrees/d9-rc-flat-destruction-astra/.tmp-flat/candidate-qbe-rc-n12:     file format elf64-x86-64


Disassembly of section .text:

00000000010230f0 <myl_rc_drain>:
 10230f0:	push   %rbp
 10230f1:	mov    %rsp,%rbp
 10230f4:	push   %r15
 10230f6:	push   %r14
 10230f8:	push   %r13
 10230fa:	push   %r12
 10230fc:	push   %rbx
 10230fd:	push   %rax
 10230fe:	test   %rdi,%rdi
 1023101:	je     10232a7 <myl_rc_drain+0x1b7>
 1023107:	mov    %rdi,%rbx
 102310a:	mov    0x1608(%rdi),%rax
 1023111:	test   %rax,%rax
 1023114:	je     10232a7 <myl_rc_drain+0x1b7>
 102311a:	cmpl   $0x0,0x68(%rax)
 102311e:	jne    1023298 <myl_rc_drain+0x1a8>
 1023124:	cmpq   $0x0,0x58(%rax)
 1023129:	jne    1023298 <myl_rc_drain+0x1a8>
 102312f:	movl   $0x1,0x68(%rax)
 1023136:	mov    0x60(%rax),%r13
 102313a:	test   %r13,%r13
 102313d:	je     1023291 <myl_rc_drain+0x1a1>
 1023143:	add    $0x60,%rax
 1023147:	mov    %rax,%rcx
 102314a:	nopw   0x0(%rax,%rax,1)
 1023150:	mov    0x0(%r13),%rax
 1023154:	mov    %rax,(%rcx)
 1023157:	mov    0x18(%r13),%rsi
 102315b:	mov    %rbx,%rdi
 102315e:	call   10215b0 <myl_rc_descriptor_find>
 1023163:	test   %rax,%rax
 1023166:	je     10232a7 <myl_rc_drain+0x1b7>
 102316c:	mov    %rax,%r12
 102316f:	mov    $0x3c,%eax
 1023174:	bzhi   %rax,0x10(%r13),%r15
 102317a:	lea    0x20(%r13),%r14
 102317e:	shr    $0x2,%r15
 1023182:	mov    0x78(%r12),%eax
 1023187:	cmp    $0x8,%eax
 102318a:	ja     10231e0 <myl_rc_drain+0xf0>
 102318c:	cmp    $0x1,%r15
 1023190:	jne    1023230 <myl_rc_drain+0x140>
 1023196:	test   %eax,%eax
 1023198:	je     1023260 <myl_rc_drain+0x170>
 102319e:	xor    %r15d,%r15d
 10231a1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 10231b0:	mov    0x38(%r12,%r15,8),%rax
 10231b5:	mov    (%r14,%rax,1),%rsi
 10231b9:	movq   $0x0,(%r14,%rax,1)
 10231c1:	mov    %rbx,%rdi
 10231c4:	call   1020dd0 <myl_rc_edge_release>
 10231c9:	inc    %r15
 10231cc:	mov    0x78(%r12),%eax
 10231d1:	cmp    %rax,%r15
 10231d4:	jb     10231b0 <myl_rc_drain+0xc0>
 10231d6:	jmp    1023260 <myl_rc_drain+0x170>
 10231db:	nopl   0x0(%rax,%rax,1)
 10231e0:	mov    0x18(%r12),%rax
 10231e5:	test   %rax,%rax
 10231e8:	je     10231f2 <myl_rc_drain+0x102>
 10231ea:	mov    %rbx,%rdi
 10231ed:	mov    %r14,%rsi
 10231f0:	call   *%rax
 10231f2:	mov    0x18(%r13),%rsi
 10231f6:	mov    %rbx,%rdi
 10231f9:	call   10215b0 <myl_rc_descriptor_find>
 10231fe:	test   %rax,%rax
 1023201:	je     10232a7 <myl_rc_drain+0x1b7>
 1023207:	mov    0x1608(%rbx),%rcx
 102320e:	cmpq   $0x0,0x58(%rcx)
 1023213:	jne    10232a7 <myl_rc_drain+0x1b7>
 1023219:	mov    0x10(%rax),%rcx
 102321d:	test   %rcx,%rcx
 1023220:	je     1023243 <myl_rc_drain+0x153>
 1023222:	mov    %rbx,%rdi
 1023225:	mov    %r14,%rsi
 1023228:	mov    %r15,%rdx
 102322b:	call   *%rcx
 102322d:	jmp    1023260 <myl_rc_drain+0x170>
 102322f:	nop
 1023230:	mov    %rbx,%rdi
 1023233:	mov    %r12,%rsi
 1023236:	mov    %r14,%rdx
 1023239:	mov    %r15,%rcx
 102323c:	call   1022ff0 <myl_rc_flat_edges_release>
 1023241:	jmp    1023260 <myl_rc_drain+0x170>
 1023243:	mov    0x8(%rax),%rsi
 1023247:	mov    %rbx,%rdi
 102324a:	mov    %r14,%rdx
 102324d:	mov    %r15,%rcx
 1023250:	call   1022ee0 <myl_rc_edges_release>
 1023255:	data16 cs nopw 0x0(%rax,%rax,1)
 1023260:	mov    0x1608(%rbx),%rax
 1023267:	cmpq   $0x0,0x58(%rax)
 102326c:	jne    10232a7 <myl_rc_drain+0x1b7>
 102326e:	mov    %rbx,%rdi
 1023271:	mov    %r14,%rsi
 1023274:	call   1020d30 <myl_rc_allocator_retire>
 1023279:	mov    0x1608(%rbx),%rax
 1023280:	lea    0x60(%rax),%rcx
 1023284:	mov    0x60(%rax),%r13
 1023288:	test   %r13,%r13
 102328b:	jne    1023150 <myl_rc_drain+0x60>
 1023291:	movl   $0x0,0x68(%rax)
 1023298:	add    $0x8,%rsp
 102329c:	pop    %rbx
 102329d:	pop    %r12
 102329f:	pop    %r13
 10232a1:	pop    %r14
 10232a3:	pop    %r15
 10232a5:	pop    %rbp
 10232a6:	ret
 10232a7:	call   102084e <myl_rc_invariant_failed>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
