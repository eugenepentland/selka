
/home/epentland/ai/canopy/mylang-worktrees/d9-rc-flat-destruction-astra/.tmp-flat/inert-llvm-rc-repeat:     file format elf64-x86-64


Disassembly of section .text:

0000000001025e70 <myl_rc_drain>:
 1025e70:	push   %rbp
 1025e71:	mov    %rsp,%rbp
 1025e74:	push   %r15
 1025e76:	push   %r14
 1025e78:	push   %r13
 1025e7a:	push   %r12
 1025e7c:	push   %rbx
 1025e7d:	push   %rax
 1025e7e:	test   %rdi,%rdi
 1025e81:	je     102610b <myl_rc_drain+0x29b>
 1025e87:	mov    %rdi,%rbx
 1025e8a:	mov    0x1608(%rdi),%rax
 1025e91:	test   %rax,%rax
 1025e94:	je     102610b <myl_rc_drain+0x29b>
 1025e9a:	cmpl   $0x0,0x68(%rax)
 1025e9e:	jne    10260fc <myl_rc_drain+0x28c>
 1025ea4:	cmpq   $0x0,0x58(%rax)
 1025ea9:	jne    10260fc <myl_rc_drain+0x28c>
 1025eaf:	movl   $0x1,0x68(%rax)
 1025eb6:	mov    0x60(%rax),%r13
 1025eba:	test   %r13,%r13
 1025ebd:	je     10260f5 <myl_rc_drain+0x285>
 1025ec3:	movabs $0xbf58476d1ce4e5b9,%r12
 1025ecd:	nopl   (%rax)
 1025ed0:	mov    0x0(%r13),%rcx
 1025ed4:	mov    %rcx,0x60(%rax)
 1025ed8:	mov    0x18(%r13),%rcx
 1025edc:	test   %rcx,%rcx
 1025edf:	je     102610b <myl_rc_drain+0x29b>
 1025ee5:	test   %rax,%rax
 1025ee8:	je     102610b <myl_rc_drain+0x29b>
 1025eee:	mov    0x40(%rax),%rdx
 1025ef2:	test   %rdx,%rdx
 1025ef5:	je     102610b <myl_rc_drain+0x29b>
 1025efb:	mov    0x30(%rax),%rsi
 1025eff:	mov    %rcx,%rdi
 1025f02:	shr    $0x3,%rdi
 1025f06:	mov    %rcx,%r8
 1025f09:	shr    $0x21,%r8
 1025f0d:	xor    %rdi,%r8
 1025f10:	imul   %r12,%r8
 1025f14:	mov    %r8,%rdi
 1025f17:	shr    $0x1b,%rdi
 1025f1b:	xor    %r8,%rdi
 1025f1e:	xor    $0x2,%rdi
 1025f22:	dec    %rdx
 1025f25:	and    %rdx,%rdi
 1025f28:	lea    (%rdi,%rdi,4),%r8
 1025f2c:	mov    (%rsi,%r8,8),%r8
 1025f30:	test   %r8,%r8
 1025f33:	je     102610b <myl_rc_drain+0x29b>
 1025f39:	lea    0x20(%r13),%r14
 1025f3d:	jmp    1025f57 <myl_rc_drain+0xe7>
 1025f3f:	nop
 1025f40:	inc    %rdi
 1025f43:	and    %rdx,%rdi
 1025f46:	lea    (%rdi,%rdi,4),%r8
 1025f4a:	mov    (%rsi,%r8,8),%r8
 1025f4e:	test   %r8,%r8
 1025f51:	je     102610b <myl_rc_drain+0x29b>
 1025f57:	cmp    %rcx,%r8
 1025f5a:	jne    1025f40 <myl_rc_drain+0xd0>
 1025f5c:	lea    (%rdi,%rdi,4),%r8
 1025f60:	cmpl   $0x2,0x20(%rsi,%r8,8)
 1025f66:	jne    1025f40 <myl_rc_drain+0xd0>
 1025f68:	lea    (%rsi,%r8,8),%rdx
 1025f6c:	mov    0x8(%rdx),%rsi
 1025f70:	test   %rsi,%rsi
 1025f73:	je     102610b <myl_rc_drain+0x29b>
 1025f79:	mov    $0x3c,%edx
 1025f7e:	bzhi   %rdx,0x10(%r13),%r15
 1025f84:	shr    $0x2,%r15
 1025f88:	cmpl   $0x8,0x78(%rsi)
 1025f8c:	ja     1025fc0 <myl_rc_drain+0x150>
 1025f8e:	mov    %rbx,%rdi
 1025f91:	mov    %r14,%rdx
 1025f94:	mov    %r15,%rcx
 1025f97:	call   1025d20 <myl_rc_flat_edges_release>
 1025f9c:	mov    0x1608(%rbx),%rax
 1025fa3:	cmpq   $0x0,0x58(%rax)
 1025fa8:	je     10260c0 <myl_rc_drain+0x250>
 1025fae:	jmp    102610b <myl_rc_drain+0x29b>
 1025fb3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1025fc0:	mov    0x18(%rsi),%rdx
 1025fc4:	test   %rdx,%rdx
 1025fc7:	je     1025fdc <myl_rc_drain+0x16c>
 1025fc9:	mov    %rbx,%rdi
 1025fcc:	mov    %r14,%rsi
 1025fcf:	call   *%rdx
 1025fd1:	mov    0x18(%r13),%rcx
 1025fd5:	mov    0x1608(%rbx),%rax
 1025fdc:	test   %rcx,%rcx
 1025fdf:	je     102610b <myl_rc_drain+0x29b>
 1025fe5:	test   %rax,%rax
 1025fe8:	je     102610b <myl_rc_drain+0x29b>
 1025fee:	mov    0x40(%rax),%rdx
 1025ff2:	test   %rdx,%rdx
 1025ff5:	je     102610b <myl_rc_drain+0x29b>
 1025ffb:	mov    0x30(%rax),%rsi
 1025fff:	mov    %rcx,%rdi
 1026002:	shr    $0x3,%rdi
 1026006:	mov    %rcx,%r8
 1026009:	shr    $0x21,%r8
 102600d:	xor    %rdi,%r8
 1026010:	imul   %r12,%r8
 1026014:	mov    %r8,%rdi
 1026017:	shr    $0x1b,%rdi
 102601b:	xor    %r8,%rdi
 102601e:	xor    $0x2,%rdi
 1026022:	dec    %rdx
 1026025:	jmp    1026033 <myl_rc_drain+0x1c3>
 1026027:	nopw   0x0(%rax,%rax,1)
 1026030:	inc    %rdi
 1026033:	and    %rdx,%rdi
 1026036:	lea    (%rdi,%rdi,4),%r8
 102603a:	mov    (%rsi,%r8,8),%r8
 102603e:	test   %r8,%r8
 1026041:	je     102610b <myl_rc_drain+0x29b>
 1026047:	cmp    %rcx,%r8
 102604a:	jne    1026030 <myl_rc_drain+0x1c0>
 102604c:	lea    (%rdi,%rdi,4),%r8
 1026050:	cmpl   $0x2,0x20(%rsi,%r8,8)
 1026056:	jne    1026030 <myl_rc_drain+0x1c0>
 1026058:	lea    (%rsi,%r8,8),%rcx
 102605c:	mov    0x8(%rcx),%rcx
 1026060:	test   %rcx,%rcx
 1026063:	je     102610b <myl_rc_drain+0x29b>
 1026069:	cmpq   $0x0,0x58(%rax)
 102606e:	jne    102610b <myl_rc_drain+0x29b>
 1026074:	mov    0x10(%rcx),%rax
 1026078:	test   %rax,%rax
 102607b:	je     1026098 <myl_rc_drain+0x228>
 102607d:	mov    %rbx,%rdi
 1026080:	mov    %r14,%rsi
 1026083:	mov    %r15,%rdx
 1026086:	call   *%rax
 1026088:	mov    0x1608(%rbx),%rax
 102608f:	cmpq   $0x0,0x58(%rax)
 1026094:	je     10260c0 <myl_rc_drain+0x250>
 1026096:	jmp    102610b <myl_rc_drain+0x29b>
 1026098:	mov    0x8(%rcx),%rsi
 102609c:	mov    %rbx,%rdi
 102609f:	mov    %r14,%rdx
 10260a2:	mov    %r15,%rcx
 10260a5:	call   10259a0 <myl_rc_edges_release>
 10260aa:	mov    0x1608(%rbx),%rax
 10260b1:	cmpq   $0x0,0x58(%rax)
 10260b6:	jne    102610b <myl_rc_drain+0x29b>
 10260b8:	nopl   0x0(%rax,%rax,1)
 10260c0:	mov    0x10(%r13),%rcx
 10260c4:	movabs $0x4000000000000002,%rdx
 10260ce:	test   %rdx,%rcx
 10260d1:	jne    102610b <myl_rc_drain+0x29b>
 10260d3:	test   $0x1,%cl
 10260d6:	je     102610b <myl_rc_drain+0x29b>
 10260d8:	mov    %rbx,%rdi
 10260db:	mov    %r14,%rsi
 10260de:	call   *0x8(%rax)
 10260e1:	mov    0x1608(%rbx),%rax
 10260e8:	mov    0x60(%rax),%r13
 10260ec:	test   %r13,%r13
 10260ef:	jne    1025ed0 <myl_rc_drain+0x60>
 10260f5:	movl   $0x0,0x68(%rax)
 10260fc:	add    $0x8,%rsp
 1026100:	pop    %rbx
 1026101:	pop    %r12
 1026103:	pop    %r13
 1026105:	pop    %r14
 1026107:	pop    %r15
 1026109:	pop    %rbp
 102610a:	ret
 102610b:	call   10239b1 <myl_rc_invariant_failed>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
