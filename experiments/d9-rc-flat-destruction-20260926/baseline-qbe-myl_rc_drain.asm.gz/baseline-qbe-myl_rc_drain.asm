
/home/epentland/ai/canopy/mylang-worktrees/d9-rc-flat-destruction-astra/.tmp-flat/inert-qbe-rc-repeat:     file format elf64-x86-64


Disassembly of section .text:

0000000001023170 <myl_rc_drain>:
 1023170:	push   %rbp
 1023171:	mov    %rsp,%rbp
 1023174:	push   %r15
 1023176:	push   %r14
 1023178:	push   %r13
 102317a:	push   %r12
 102317c:	push   %rbx
 102317d:	push   %rax
 102317e:	test   %rdi,%rdi
 1023181:	je     10232c7 <myl_rc_drain+0x157>
 1023187:	mov    %rdi,%rbx
 102318a:	mov    0x1608(%rdi),%rax
 1023191:	test   %rax,%rax
 1023194:	je     10232c7 <myl_rc_drain+0x157>
 102319a:	cmpl   $0x0,0x68(%rax)
 102319e:	jne    10232b8 <myl_rc_drain+0x148>
 10231a4:	cmpq   $0x0,0x58(%rax)
 10231a9:	jne    10232b8 <myl_rc_drain+0x148>
 10231af:	movl   $0x1,0x68(%rax)
 10231b6:	mov    0x60(%rax),%r13
 10231ba:	test   %r13,%r13
 10231bd:	je     10232b1 <myl_rc_drain+0x141>
 10231c3:	add    $0x60,%rax
 10231c7:	mov    $0x3c,%r12d
 10231cd:	mov    %rax,%rcx
 10231d0:	mov    0x0(%r13),%rax
 10231d4:	mov    %rax,(%rcx)
 10231d7:	mov    0x18(%r13),%rsi
 10231db:	mov    %rbx,%rdi
 10231de:	call   1021630 <myl_rc_descriptor_find>
 10231e3:	test   %rax,%rax
 10231e6:	je     10232c7 <myl_rc_drain+0x157>
 10231ec:	bzhi   %r12,0x10(%r13),%r15
 10231f2:	lea    0x20(%r13),%r14
 10231f6:	shr    $0x2,%r15
 10231fa:	cmpl   $0x8,0x78(%rax)
 10231fe:	ja     1023220 <myl_rc_drain+0xb0>
 1023200:	mov    %rbx,%rdi
 1023203:	mov    %rax,%rsi
 1023206:	mov    %r14,%rdx
 1023209:	mov    %r15,%rcx
 102320c:	call   1023070 <myl_rc_flat_edges_release>
 1023211:	jmp    1023280 <myl_rc_drain+0x110>
 1023213:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1023220:	mov    0x18(%rax),%rax
 1023224:	test   %rax,%rax
 1023227:	je     1023231 <myl_rc_drain+0xc1>
 1023229:	mov    %rbx,%rdi
 102322c:	mov    %r14,%rsi
 102322f:	call   *%rax
 1023231:	mov    0x18(%r13),%rsi
 1023235:	mov    %rbx,%rdi
 1023238:	call   1021630 <myl_rc_descriptor_find>
 102323d:	test   %rax,%rax
 1023240:	je     10232c7 <myl_rc_drain+0x157>
 1023246:	mov    0x1608(%rbx),%rcx
 102324d:	cmpq   $0x0,0x58(%rcx)
 1023252:	jne    10232c7 <myl_rc_drain+0x157>
 1023254:	mov    0x10(%rax),%rcx
 1023258:	test   %rcx,%rcx
 102325b:	je     102326a <myl_rc_drain+0xfa>
 102325d:	mov    %rbx,%rdi
 1023260:	mov    %r14,%rsi
 1023263:	mov    %r15,%rdx
 1023266:	call   *%rcx
 1023268:	jmp    1023280 <myl_rc_drain+0x110>
 102326a:	mov    0x8(%rax),%rsi
 102326e:	mov    %rbx,%rdi
 1023271:	mov    %r14,%rdx
 1023274:	mov    %r15,%rcx
 1023277:	call   1022f60 <myl_rc_edges_release>
 102327c:	nopl   0x0(%rax)
 1023280:	mov    0x1608(%rbx),%rax
 1023287:	cmpq   $0x0,0x58(%rax)
 102328c:	jne    10232c7 <myl_rc_drain+0x157>
 102328e:	mov    %rbx,%rdi
 1023291:	mov    %r14,%rsi
 1023294:	call   1020db0 <myl_rc_allocator_retire>
 1023299:	mov    0x1608(%rbx),%rax
 10232a0:	lea    0x60(%rax),%rcx
 10232a4:	mov    0x60(%rax),%r13
 10232a8:	test   %r13,%r13
 10232ab:	jne    10231d0 <myl_rc_drain+0x60>
 10232b1:	movl   $0x0,0x68(%rax)
 10232b8:	add    $0x8,%rsp
 10232bc:	pop    %rbx
 10232bd:	pop    %r12
 10232bf:	pop    %r13
 10232c1:	pop    %r14
 10232c3:	pop    %r15
 10232c5:	pop    %rbp
 10232c6:	ret
 10232c7:	call   10208ce <myl_rc_invariant_failed>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
