
/home/epentland/ai/canopy/mylang-worktrees/d9-rc-flat-destruction-astra/.tmp-flat/inert-llvm-rc-repeat:     file format elf64-x86-64


Disassembly of section .text:

0000000001025d20 <myl_rc_flat_edges_release>:
 1025d20:	push   %rbp
 1025d21:	mov    %rsp,%rbp
 1025d24:	push   %r15
 1025d26:	push   %r14
 1025d28:	push   %rbx
 1025d29:	push   %rax
 1025d2a:	test   %rdi,%rdi
 1025d2d:	je     1025e69 <myl_rc_flat_edges_release+0x149>
 1025d33:	mov    0x1608(%rdi),%rax
 1025d3a:	test   %rax,%rax
 1025d3d:	je     1025e69 <myl_rc_flat_edges_release+0x149>
 1025d43:	cmpq   $0x0,0x58(%rax)
 1025d48:	jne    1025e69 <myl_rc_flat_edges_release+0x149>
 1025d4e:	mov    0x78(%rsi),%r10d
 1025d52:	cmp    $0x9,%r10d
 1025d56:	jae    1025e69 <myl_rc_flat_edges_release+0x149>
 1025d5c:	mov    %rdx,%r8
 1025d5f:	mov    (%rsi),%rax
 1025d62:	mov    (%rax),%r9
 1025d65:	test   %r9,%r9
 1025d68:	je     1025d76 <myl_rc_flat_edges_release+0x56>
 1025d6a:	mov    %r9,%rax
 1025d6d:	mul    %rcx
 1025d70:	jo     1025e69 <myl_rc_flat_edges_release+0x149>
 1025d76:	test   %r8,%r8
 1025d79:	jne    1025d8b <myl_rc_flat_edges_release+0x6b>
 1025d7b:	mov    %rcx,%rax
 1025d7e:	imul   %r9,%rax
 1025d82:	test   %rax,%rax
 1025d85:	jne    1025e69 <myl_rc_flat_edges_release+0x149>
 1025d8b:	test   %r10d,%r10d
 1025d8e:	sete   %al
 1025d91:	test   %rcx,%rcx
 1025d94:	sete   %dl
 1025d97:	or     %al,%dl
 1025d99:	jne    1025e5e <myl_rc_flat_edges_release+0x13e>
 1025d9f:	mov    $0x1,%r10d
 1025da5:	xor    %eax,%eax
 1025da7:	movabs $0x4000000000000002,%rdx
 1025db1:	jmp    1025dd5 <myl_rc_flat_edges_release+0xb5>
 1025db3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1025dc0:	mov    (%rsi),%r9
 1025dc3:	mov    (%r9),%r9
 1025dc6:	add    %r9,%r8
 1025dc9:	inc    %rax
 1025dcc:	cmp    %rcx,%rax
 1025dcf:	je     1025e5e <myl_rc_flat_edges_release+0x13e>
 1025dd5:	test   %r10d,%r10d
 1025dd8:	mov    $0x0,%r10d
 1025dde:	je     1025dc6 <myl_rc_flat_edges_release+0xa6>
 1025de0:	xor    %r9d,%r9d
 1025de3:	jmp    1025dfc <myl_rc_flat_edges_release+0xdc>
 1025de5:	data16 cs nopw 0x0(%rax,%rax,1)
 1025df0:	inc    %r9
 1025df3:	mov    0x78(%rsi),%r10d
 1025df7:	cmp    %r10,%r9
 1025dfa:	jae    1025dc0 <myl_rc_flat_edges_release+0xa0>
 1025dfc:	mov    0x38(%rsi,%r9,8),%r11
 1025e01:	mov    (%r8,%r11,1),%r10
 1025e05:	movq   $0x0,(%r8,%r11,1)
 1025e0d:	test   %r10,%r10
 1025e10:	je     1025df0 <myl_rc_flat_edges_release+0xd0>
 1025e12:	mov    -0x10(%r10),%r11
 1025e16:	test   %rdx,%r11
 1025e19:	jne    1025df0 <myl_rc_flat_edges_release+0xd0>
 1025e1b:	mov    0x1608(%rdi),%rbx
 1025e22:	test   %rbx,%rbx
 1025e25:	je     1025e69 <myl_rc_flat_edges_release+0x149>
 1025e27:	test   $0x1,%r11b
 1025e2b:	jne    1025e69 <myl_rc_flat_edges_release+0x149>
 1025e2d:	lea    -0x20(%r10),%r14
 1025e31:	mov    (%r14),%r15
 1025e34:	test   %r15,%r15
 1025e37:	je     1025e69 <myl_rc_flat_edges_release+0x149>
 1025e39:	dec    %r15
 1025e3c:	mov    %r15,(%r14)
 1025e3f:	jne    1025df0 <myl_rc_flat_edges_release+0xd0>
 1025e41:	cmpq   $0x0,-0x18(%r10)
 1025e46:	jne    1025df0 <myl_rc_flat_edges_release+0xd0>
 1025e48:	or     $0x1,%r11
 1025e4c:	mov    %r11,-0x10(%r10)
 1025e50:	mov    0x60(%rbx),%r11
 1025e54:	mov    %r11,-0x20(%r10)
 1025e58:	mov    %r14,0x60(%rbx)
 1025e5c:	jmp    1025df0 <myl_rc_flat_edges_release+0xd0>
 1025e5e:	add    $0x8,%rsp
 1025e62:	pop    %rbx
 1025e63:	pop    %r14
 1025e65:	pop    %r15
 1025e67:	pop    %rbp
 1025e68:	ret
 1025e69:	call   10239b1 <myl_rc_invariant_failed>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
