import importlib.util,subprocess,sys
from pathlib import Path
r=Path.cwd();w=r/'.tmp-rc/dict-word';name=sys.argv[1];directory=w/('c-'+name);directory.mkdir(exist_ok=True)
source=directory/'native_dictionary.c'
if name=='before':source.write_text(subprocess.check_output(['git','show','88f4e477:src/native_dictionary.c'],text=True))
else:
 text=(r/'src/native_dictionary.c').read_text();assert '!heap->rc->dead.head && region<=heap->region_depth' in text
 source.write_text(text.replace('!heap->rc->dead.head && region<=heap->region_depth','region<=heap->region_depth'))
s=importlib.util.spec_from_file_location('native_memory',r/'scripts/test_native_memory.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
original=subprocess.run
def wrapped(command,*args,**kw):
 command=[str(source) if x==str(r/'src/native_dictionary.c') else x for x in command]
 return original(command,*args,**kw)
m.subprocess.run=wrapped
m.run_suite(r,['cc','-std=c11','-Wall','-Wextra','-Werror','-g','-fsanitize=address,undefined','-fno-omit-frame-pointer','-ffunction-sections','-fdata-sections','-Wl,--gc-sections'],directory,'native_rc_collections',['native_heap.c','native_text_methods.c','native_print.c'])
