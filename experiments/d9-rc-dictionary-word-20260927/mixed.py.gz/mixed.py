from pathlib import Path
import os,subprocess,json,hashlib,statistics
r=Path.cwd();w=r/'.tmp-rc/dict-word';e={k:v for k,v in os.environ.items() if not k.startswith('MYLANG_') and k!='LD_PRELOAD'};e['TMPDIR']=str(r/'.tmp-rc/tmp')
cs={'before':r/'.tmp-rc/install-dict-loop/bin/mylang','find':r/'.tmp-rc/install-dict-word-find/bin/mylang','repeat':r/'.tmp-rc/install-dict-word-repeat/bin/mylang'}
s=w/'mixed.my';d={'source':s.read_text(),'source_sha256':hashlib.sha256(s.read_bytes()).hexdigest(),'builds':[],'runs':[],'medians':{}};expected=None
save=lambda:(w/'mixed.json').write_text(json.dumps(d,indent=2)+'\n')
for backend in ('qbe','llvm'):
 for side,c in cs.items():
  b=w/('mixed-'+side+'-'+backend);cmd=[str(r/'scripts/build-slot.sh'),'build',str(c),'build',str(s),'-o',str(b),'--cache-dir='+str(w/('mixed-cache-'+side)),'--keep-symbols','--rc-runtime','--backend='+backend,'--mode=ReleaseFast']
  if backend=='llvm':cmd+=['--llvm-opt=3','--lto=full']
  p=subprocess.run(cmd,env=e,text=True,capture_output=True);row=dict(backend=backend,side=side,command=cmd,status=p.returncode,stdout=p.stdout,stderr=p.stderr,compiler_sha256=hashlib.sha256(c.read_bytes()).hexdigest());d['builds'].append(row);save();assert not p.returncode,row
  m=json.loads(Path(str(b)+'.qbe-manifest.json').read_text());assert m['backend']==backend;row['manifest']=m;row['binary_sha256']=hashlib.sha256(b.read_bytes()).hexdigest();save()
  values=[]
  for repeat in range(3):
   stat=w/('mixed-'+side+'-'+backend+'-'+str(repeat)+'.stat');cmd=['taskset','-c','11','perf','stat','-x,','-e','instructions:u','-o',str(stat),str(b)];p=subprocess.run(cmd,env=e,text=True,capture_output=True,timeout=120);raw=stat.read_text();lines=[x for x in raw.splitlines() if 'instructions' in x and x.split(',')[0].isdigit()];assert len(lines)==1 and float(lines[0].split(',')[4])==100.0,raw;n=int(lines[0].split(',')[0]);values.append(n)
   expected=p.stdout if expected is None else expected;row=dict(side=side,backend=backend,command=cmd,status=p.returncode,stdout=p.stdout,stderr=p.stderr,perf=raw,instructions=n);d['runs'].append(row);save();assert not p.returncode and p.stdout==expected,row
  d['medians'][side+'-'+backend]=statistics.median(values);save()
 print(backend,'repeat/find',d['medians']['repeat-'+backend]/d['medians']['find-'+backend],'repeat/before',d['medians']['repeat-'+backend]/d['medians']['before-'+backend],flush=True)
