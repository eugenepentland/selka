import importlib.util
from pathlib import Path
r=Path.cwd(); w=r/'.tmp-rc/dict-word'
s=importlib.util.spec_from_file_location('native_memory',r/'scripts/test_native_memory.py')
m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
m.run_suite(r,['cc','-std=c11','-Wall','-Wextra','-Werror','-g','-fsanitize=address,undefined','-fno-omit-frame-pointer','-ffunction-sections','-fdata-sections','-Wl,--gc-sections'],w,'native_rc_collections',['native_heap.c','native_text_methods.c','native_print.c'])
