from pathlib import Path
import os,subprocess,json,hashlib,statistics,sys
r=Path.cwd(); w=r/'.tmp-rc/dict-word'; variant=sys.argv[1]; f=w/variant; f.mkdir(exist_ok=True)
c=r/('.tmp-rc/install-dict-word-'+variant+'/bin/mylang'); s=r/'bench/parity/micro/dict_count.my'; expected=s.with_suffix('.expected').read_text()
e={k:v for k,v in os.environ.items() if not k.startswith('MYLANG_') and k!='LD_PRELOAD'}; e['TMPDIR']=str(r/'.tmp-rc/tmp')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
d={'variant':variant,'source':{'path':str(s),'sha256':sha(s)},'compiler':{'path':str(c),'sha256':sha(c)},'builds':[],'runs':[],'medians':{}}
def save():(w/(variant+'-measurements.json')).write_text(json.dumps(d,indent=2)+'\n')
for backend in ('qbe','llvm'):
 for stats in (False,True):
  b=f/(backend+('-stats' if stats else '-rc'))
  cmd=[str(r/'scripts/build-slot.sh'),'build',str(c),'build',str(s),'-o',str(b),'--cache-dir='+str(w/('cache-'+variant)),'--keep-symbols','--rc-runtime'+('=stats' if stats else ''),'--backend',backend]
  cmd+=['--mode=ReleaseFast','--llvm-opt','3','--lto=full'] if backend=='llvm' else ['--mode=ReleaseFast']
  p=subprocess.run(cmd,env=e,text=True,capture_output=True);row=dict(backend=backend,stats=stats,command=cmd,status=p.returncode,stdout=p.stdout,stderr=p.stderr); d['builds'].append(row);save();assert not p.returncode,row
  manifest=json.loads(Path(str(b)+'.qbe-manifest.json').read_text());assert manifest['backend']==backend
  row.update(binary_sha256=sha(b),manifest=manifest);save()
  if not stats:
   for name in ('myl_native_dictionary_write','myl_rc_native_retain_replace','myl_rc_descriptor_find','myl_rc_descriptor_repeat'):
    p=subprocess.run(['objdump','-d','--disassemble='+name,str(b)],text=True,capture_output=True,check=True); (f/(backend+'-'+name+'.asm')).write_text(p.stdout)
   print(variant,backend,'native built; inspect',f/(backend+'-myl_native_dictionary_write.asm'),flush=True)
 if os.environ.get('DICT_WORD_BUILD_ONLY'):continue
 for side in ('gc','before',variant):
  b=r.parent/'d9-rc-performance/.tmp-rc-performance/bin/gc'/('parity-micro-dict_count.'+backend) if side=='gc' else r/'.tmp-rc/dict-loop/full'/('after-'+backend+'-rc') if side=='before' else f/(backend+'-rc')
  counts=[]
  for repeat in range(3):
   stat=f/(side+'-'+backend+'-'+str(repeat)+'.stat');cmd=['taskset','-c','11','perf','stat','-x,','-e','instructions:u','-o',str(stat),str(b)]
   p=subprocess.run(cmd,env=e,text=True,capture_output=True,timeout=600); raw=stat.read_text();lines=[x for x in raw.splitlines() if 'instructions' in x and x.split(',')[0].isdigit()];assert len(lines)==1,raw
   line=lines[0];n=int(line.split(',')[0]);assert float(line.split(',')[4])==100.0,line
   row=dict(side=side,backend=backend,repeat=repeat,command=cmd,status=p.returncode,stdout=p.stdout,stderr=p.stderr,perf=raw,instructions=n,binary_sha256=sha(b));d['runs'].append(row);save();assert not p.returncode and p.stdout==expected,row;counts.append(n)
  d['medians'][side+'-'+backend]=statistics.median(counts);save()
 for side in ('before',variant):
  b=r/'.tmp-rc/dict-loop/full'/('after-'+backend+'-stats') if side=='before' else f/(backend+'-stats');cmd=['taskset','-c','11',str(b)]
  p=subprocess.run(cmd,env=e,text=True,capture_output=True,timeout=600);row=dict(side=side,backend=backend,stats=True,command=cmd,status=p.returncode,stdout=p.stdout,stderr=p.stderr,binary_sha256=sha(b));d['runs'].append(row);save();assert not p.returncode and p.stdout==expected,row
  counts=json.loads(next(x.removeprefix('MYLANG_RC_COUNTS ') for x in p.stderr.splitlines() if x.startswith('MYLANG_RC_COUNTS ')));row['counts']=counts;save()
  assert counts['heap_allocate']==counts['retire'] and counts['hold_acquire']==counts['hold_release'] and counts['owner_acquire']+counts['heap_allocate']==counts['owner_release'],counts
 print(backend,variant+'/before',d['medians'][variant+'-'+backend]/d['medians']['before-'+backend],variant+'/GC',d['medians'][variant+'-'+backend]/d['medians']['gc-'+backend],flush=True)
