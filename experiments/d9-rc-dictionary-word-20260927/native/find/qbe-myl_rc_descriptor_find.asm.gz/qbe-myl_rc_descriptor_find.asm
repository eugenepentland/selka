
/home/epentland/ai/canopy/mylang-worktrees/d9-rc-compiler-astra/.tmp-rc/dict-word/find/qbe-rc:     file format elf64-x86-64


Disassembly of section .text:

00000000010244d0 <myl_rc_descriptor_find>:
 10244d0:	48 85 ff             	test   %rdi,%rdi
 10244d3:	0f 84 a5 00 00 00    	je     102457e <myl_rc_descriptor_find+0xae>
 10244d9:	48 8b 87 08 16 00 00 	mov    0x1608(%rdi),%rax
 10244e0:	48 85 c0             	test   %rax,%rax
 10244e3:	0f 94 c1             	sete   %cl
 10244e6:	48 85 f6             	test   %rsi,%rsi
 10244e9:	0f 94 c2             	sete   %dl
 10244ec:	08 ca                	or     %cl,%dl
 10244ee:	0f 85 8a 00 00 00    	jne    102457e <myl_rc_descriptor_find+0xae>
 10244f4:	55                   	push   %rbp
 10244f5:	48 89 e5             	mov    %rsp,%rbp
 10244f8:	48 8b 48 40          	mov    0x40(%rax),%rcx
 10244fc:	48 85 c9             	test   %rcx,%rcx
 10244ff:	0f 84 7c 00 00 00    	je     1024581 <myl_rc_descriptor_find+0xb1>
 1024505:	48 8b 50 30          	mov    0x30(%rax),%rdx
 1024509:	48 89 f0             	mov    %rsi,%rax
 102450c:	48 c1 e8 03          	shr    $0x3,%rax
 1024510:	48 89 f7             	mov    %rsi,%rdi
 1024513:	48 c1 ef 21          	shr    $0x21,%rdi
 1024517:	48 31 c7             	xor    %rax,%rdi
 102451a:	48 b8 b9 e5 e4 1c 6d 	movabs $0xbf58476d1ce4e5b9,%rax
 1024521:	47 58 bf 
 1024524:	48 0f af c7          	imul   %rdi,%rax
 1024528:	48 89 c7             	mov    %rax,%rdi
 102452b:	48 c1 ef 1b          	shr    $0x1b,%rdi
 102452f:	48 31 c7             	xor    %rax,%rdi
 1024532:	48 83 f7 02          	xor    $0x2,%rdi
 1024536:	48 ff c9             	dec    %rcx
 1024539:	48 21 cf             	and    %rcx,%rdi
 102453c:	48 8d 04 bf          	lea    (%rdi,%rdi,4),%rax
 1024540:	4c 8b 04 c2          	mov    (%rdx,%rax,8),%r8
 1024544:	31 c0                	xor    %eax,%eax
 1024546:	eb 16                	jmp    102455e <myl_rc_descriptor_find+0x8e>
 1024548:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
 102454f:	00 
 1024550:	48 ff c7             	inc    %rdi
 1024553:	48 21 cf             	and    %rcx,%rdi
 1024556:	4c 8d 04 bf          	lea    (%rdi,%rdi,4),%r8
 102455a:	4e 8b 04 c2          	mov    (%rdx,%r8,8),%r8
 102455e:	4d 85 c0             	test   %r8,%r8
 1024561:	74 19                	je     102457c <myl_rc_descriptor_find+0xac>
 1024563:	49 39 f0             	cmp    %rsi,%r8
 1024566:	75 e8                	jne    1024550 <myl_rc_descriptor_find+0x80>
 1024568:	4c 8d 04 bf          	lea    (%rdi,%rdi,4),%r8
 102456c:	42 83 7c c2 20 02    	cmpl   $0x2,0x20(%rdx,%r8,8)
 1024572:	75 dc                	jne    1024550 <myl_rc_descriptor_find+0x80>
 1024574:	4a 8d 04 c2          	lea    (%rdx,%r8,8),%rax
 1024578:	48 8b 40 08          	mov    0x8(%rax),%rax
 102457c:	5d                   	pop    %rbp
 102457d:	c3                   	ret
 102457e:	31 c0                	xor    %eax,%eax
 1024580:	c3                   	ret
 1024581:	31 c0                	xor    %eax,%eax
 1024583:	5d                   	pop    %rbp
 1024584:	c3                   	ret

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
