
/home/epentland/ai/canopy/mylang-worktrees/d9-rc-compiler-astra/.tmp-rc/dict-word/find/qbe-rc:     file format elf64-x86-64


Disassembly of section .text:

000000000102c1b0 <myl_rc_native_retain_replace>:
 102c1b0:	b8 01 00 00 00       	mov    $0x1,%eax
 102c1b5:	48 39 ca             	cmp    %rcx,%rdx
 102c1b8:	0f 84 f3 00 00 00    	je     102c2b1 <myl_rc_native_retain_replace+0x101>
 102c1be:	55                   	push   %rbp
 102c1bf:	48 89 e5             	mov    %rsp,%rbp
 102c1c2:	41 57                	push   %r15
 102c1c4:	41 56                	push   %r14
 102c1c6:	41 55                	push   %r13
 102c1c8:	41 54                	push   %r12
 102c1ca:	53                   	push   %rbx
 102c1cb:	48 81 ec 88 00 00 00 	sub    $0x88,%rsp
 102c1d2:	44 89 c3             	mov    %r8d,%ebx
 102c1d5:	49 89 cd             	mov    %rcx,%r13
 102c1d8:	49 89 d4             	mov    %rdx,%r12
 102c1db:	49 89 f7             	mov    %rsi,%r15
 102c1de:	49 89 fe             	mov    %rdi,%r14
 102c1e1:	e8 ea 82 ff ff       	call   10244d0 <myl_rc_descriptor_find>
 102c1e6:	48 85 c0             	test   %rax,%rax
 102c1e9:	74 18                	je     102c203 <myl_rc_native_retain_replace+0x53>
 102c1eb:	83 78 78 00          	cmpl   $0x0,0x78(%rax)
 102c1ef:	75 12                	jne    102c203 <myl_rc_native_retain_replace+0x53>
 102c1f1:	49 8b 86 08 16 00 00 	mov    0x1608(%r14),%rax
 102c1f8:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
 102c1fd:	0f 84 af 00 00 00    	je     102c2b2 <myl_rc_native_retain_replace+0x102>
 102c203:	89 5d d0             	mov    %ebx,-0x30(%rbp)
 102c206:	49 8b 37             	mov    (%r15),%rsi
 102c209:	48 81 fe 81 00 00 00 	cmp    $0x81,%rsi
 102c210:	73 09                	jae    102c21b <myl_rc_native_retain_replace+0x6b>
 102c212:	48 8d 9d 50 ff ff ff 	lea    -0xb0(%rbp),%rbx
 102c219:	eb 19                	jmp    102c234 <myl_rc_native_retain_replace+0x84>
 102c21b:	c7 45 d4 00 00 00 00 	movl   $0x0,-0x2c(%rbp)
 102c222:	4c 89 f7             	mov    %r14,%rdi
 102c225:	31 d2                	xor    %edx,%edx
 102c227:	e8 64 ec ff ff       	call   102ae90 <myl_rc_storage_bytes>
 102c22c:	48 89 c3             	mov    %rax,%rbx
 102c22f:	48 85 c0             	test   %rax,%rax
 102c232:	74 69                	je     102c29d <myl_rc_native_retain_replace+0xed>
 102c234:	4c 89 f7             	mov    %r14,%rdi
 102c237:	4c 89 fe             	mov    %r15,%rsi
 102c23a:	48 89 da             	mov    %rbx,%rdx
 102c23d:	4c 89 e9             	mov    %r13,%rcx
 102c240:	44 8b 45 d0          	mov    -0x30(%rbp),%r8d
 102c244:	e8 67 fc ff ff       	call   102beb0 <myl_rc_native_retain>
 102c249:	89 45 d4             	mov    %eax,-0x2c(%rbp)
 102c24c:	85 c0                	test   %eax,%eax
 102c24e:	74 36                	je     102c286 <myl_rc_native_retain_replace+0xd6>
 102c250:	49 83 3f 00          	cmpq   $0x0,(%r15)
 102c254:	74 22                	je     102c278 <myl_rc_native_retain_replace+0xc8>
 102c256:	31 c0                	xor    %eax,%eax
 102c258:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
 102c25f:	00 
 102c260:	41 0f b6 0c 04       	movzbl (%r12,%rax,1),%ecx
 102c265:	0f b6 14 03          	movzbl (%rbx,%rax,1),%edx
 102c269:	41 88 14 04          	mov    %dl,(%r12,%rax,1)
 102c26d:	88 0c 03             	mov    %cl,(%rbx,%rax,1)
 102c270:	48 ff c0             	inc    %rax
 102c273:	49 3b 07             	cmp    (%r15),%rax
 102c276:	72 e8                	jb     102c260 <myl_rc_native_retain_replace+0xb0>
 102c278:	4c 89 f7             	mov    %r14,%rdi
 102c27b:	4c 89 fe             	mov    %r15,%rsi
 102c27e:	48 89 da             	mov    %rbx,%rdx
 102c281:	e8 da f7 ff ff       	call   102ba60 <myl_rc_native_drop>
 102c286:	48 8d 85 50 ff ff ff 	lea    -0xb0(%rbp),%rax
 102c28d:	48 39 c3             	cmp    %rax,%rbx
 102c290:	74 0b                	je     102c29d <myl_rc_native_retain_replace+0xed>
 102c292:	4c 89 f7             	mov    %r14,%rdi
 102c295:	48 89 de             	mov    %rbx,%rsi
 102c298:	e8 a3 7a ff ff       	call   1023d40 <myl_rc_owner_release>
 102c29d:	8b 45 d4             	mov    -0x2c(%rbp),%eax
 102c2a0:	48 81 c4 88 00 00 00 	add    $0x88,%rsp
 102c2a7:	5b                   	pop    %rbx
 102c2a8:	41 5c                	pop    %r12
 102c2aa:	41 5d                	pop    %r13
 102c2ac:	41 5e                	pop    %r14
 102c2ae:	41 5f                	pop    %r15
 102c2b0:	5d                   	pop    %rbp
 102c2b1:	c3                   	ret
 102c2b2:	41 3b 5e 70          	cmp    0x70(%r14),%ebx
 102c2b6:	76 11                	jbe    102c2c9 <myl_rc_native_retain_replace+0x119>
 102c2b8:	4c 89 f7             	mov    %r14,%rdi
 102c2bb:	be 03 00 00 00       	mov    $0x3,%esi
 102c2c0:	e8 eb 75 ff ff       	call   10238b0 <myl_rc_record_failure>
 102c2c5:	31 c0                	xor    %eax,%eax
 102c2c7:	eb d7                	jmp    102c2a0 <myl_rc_native_retain_replace+0xf0>
 102c2c9:	49 8b 17             	mov    (%r15),%rdx
 102c2cc:	4c 89 e7             	mov    %r12,%rdi
 102c2cf:	4c 89 ee             	mov    %r13,%rsi
 102c2d2:	e8 49 02 00 00       	call   102c520 <compiler_rt.memmove.memmoveFast>
 102c2d7:	b8 01 00 00 00       	mov    $0x1,%eax
 102c2dc:	eb c2                	jmp    102c2a0 <myl_rc_native_retain_replace+0xf0>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
