
.tmp-rc/dict-loop/full/after-qbe-rc:     file format elf64-x86-64


Disassembly of section .text:

000000000101eec0 <myl_native_dictionary_read>:
 101eec0:	55                   	push   %rbp
 101eec1:	48 89 e5             	mov    %rsp,%rbp
 101eec4:	41 57                	push   %r15
 101eec6:	41 56                	push   %r14
 101eec8:	41 55                	push   %r13
 101eeca:	41 54                	push   %r12
 101eecc:	53                   	push   %rbx
 101eecd:	50                   	push   %rax
 101eece:	83 bf f8 00 00 00 01 	cmpl   $0x1,0xf8(%rdi)
 101eed5:	0f 85 86 02 00 00    	jne    101f161 <myl_native_dictionary_read+0x2a1>
 101eedb:	44 8b 7f 24          	mov    0x24(%rdi),%r15d
 101eedf:	41 83 ff 02          	cmp    $0x2,%r15d
 101eee3:	74 14                	je     101eef9 <myl_native_dictionary_read+0x39>
 101eee5:	41 83 ff 01          	cmp    $0x1,%r15d
 101eee9:	74 09                	je     101eef4 <myl_native_dictionary_read+0x34>
 101eeeb:	45 85 ff             	test   %r15d,%r15d
 101eeee:	0f 85 6d 02 00 00    	jne    101f161 <myl_native_dictionary_read+0x2a1>
 101eef4:	4c 8b 36             	mov    (%rsi),%r14
 101eef7:	eb 6c                	jmp    101ef65 <myl_native_dictionary_read+0xa5>
 101eef9:	48 8b 47 08          	mov    0x8(%rdi),%rax
 101eefd:	48 8b 08             	mov    (%rax),%rcx
 101ef00:	48 c7 45 d0 00 00 00 	movq   $0x0,-0x30(%rbp)
 101ef07:	00 
 101ef08:	f3 48 0f b8 c1       	popcnt %rcx,%rax
 101ef0d:	83 f8 01             	cmp    $0x1,%eax
 101ef10:	75 21                	jne    101ef33 <myl_native_dictionary_read+0x73>
 101ef12:	f3 48 0f bc c1       	tzcnt  %rcx,%rax
 101ef17:	48 83 f8 03          	cmp    $0x3,%rax
 101ef1b:	77 16                	ja     101ef33 <myl_native_dictionary_read+0x73>
 101ef1d:	48 8d 0d 44 b6 fe ff 	lea    -0x149bc(%rip),%rcx        # 100a568 <octet_type+0x70>
 101ef24:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
 101ef28:	48 01 c8             	add    %rcx,%rax
 101ef2b:	ff e0                	jmp    *%rax
 101ef2d:	44 0f b6 36          	movzbl (%rsi),%r14d
 101ef31:	eb 32                	jmp    101ef65 <myl_native_dictionary_read+0xa5>
 101ef33:	48 83 f9 08          	cmp    $0x8,%rcx
 101ef37:	b8 08 00 00 00       	mov    $0x8,%eax
 101ef3c:	48 0f 42 c1          	cmovb  %rcx,%rax
 101ef40:	48 8d 4d d0          	lea    -0x30(%rbp),%rcx
 101ef44:	49 89 fe             	mov    %rdi,%r14
 101ef47:	48 89 cf             	mov    %rcx,%rdi
 101ef4a:	48 89 f3             	mov    %rsi,%rbx
 101ef4d:	49 89 d4             	mov    %rdx,%r12
 101ef50:	48 89 c2             	mov    %rax,%rdx
 101ef53:	e8 f8 d8 00 00       	call   102c850 <compiler_rt.memcpy.memcpyFast>
 101ef58:	48 89 de             	mov    %rbx,%rsi
 101ef5b:	4c 89 f7             	mov    %r14,%rdi
 101ef5e:	4c 89 e2             	mov    %r12,%rdx
 101ef61:	4c 8b 75 d0          	mov    -0x30(%rbp),%r14
 101ef65:	4c 3b b7 e0 00 00 00 	cmp    0xe0(%rdi),%r14
 101ef6c:	0f 85 ef 01 00 00    	jne    101f161 <myl_native_dictionary_read+0x2a1>
 101ef72:	48 8b 0f             	mov    (%rdi),%rcx
 101ef75:	48 8b 87 e8 00 00 00 	mov    0xe8(%rdi),%rax
 101ef7c:	48 3b 01             	cmp    (%rcx),%rax
 101ef7f:	0f 83 dc 01 00 00    	jae    101f161 <myl_native_dictionary_read+0x2a1>
 101ef85:	48 8b 5f 30          	mov    0x30(%rdi),%rbx
 101ef89:	48 0f af d8          	imul   %rax,%rbx
 101ef8d:	48 03 59 20          	add    0x20(%rcx),%rbx
 101ef91:	41 83 ff 02          	cmp    $0x2,%r15d
 101ef95:	74 0e                	je     101efa5 <myl_native_dictionary_read+0xe5>
 101ef97:	41 83 ff 01          	cmp    $0x1,%r15d
 101ef9b:	75 41                	jne    101efde <myl_native_dictionary_read+0x11e>
 101ef9d:	48 8b 03             	mov    (%rbx),%rax
 101efa0:	e9 8d 00 00 00       	jmp    101f032 <myl_native_dictionary_read+0x172>
 101efa5:	48 8b 47 08          	mov    0x8(%rdi),%rax
 101efa9:	48 8b 08             	mov    (%rax),%rcx
 101efac:	48 c7 45 d0 00 00 00 	movq   $0x0,-0x30(%rbp)
 101efb3:	00 
 101efb4:	f3 48 0f b8 c1       	popcnt %rcx,%rax
 101efb9:	83 f8 01             	cmp    $0x1,%eax
 101efbc:	75 3f                	jne    101effd <myl_native_dictionary_read+0x13d>
 101efbe:	f3 48 0f bc c1       	tzcnt  %rcx,%rax
 101efc3:	48 83 f8 03          	cmp    $0x3,%rax
 101efc7:	77 34                	ja     101effd <myl_native_dictionary_read+0x13d>
 101efc9:	48 8d 0d a8 b5 fe ff 	lea    -0x14a58(%rip),%rcx        # 100a578 <octet_type+0x80>
 101efd0:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
 101efd4:	48 01 c8             	add    %rcx,%rax
 101efd7:	ff e0                	jmp    *%rax
 101efd9:	0f b6 03             	movzbl (%rbx),%eax
 101efdc:	eb 54                	jmp    101f032 <myl_native_dictionary_read+0x172>
 101efde:	48 8b 0b             	mov    (%rbx),%rcx
 101efe1:	4c 8b 16             	mov    (%rsi),%r10
 101efe4:	4c 39 d1             	cmp    %r10,%rcx
 101efe7:	74 52                	je     101f03b <myl_native_dictionary_read+0x17b>
 101efe9:	41 f6 42 10 04       	testb  $0x4,0x10(%r10)
 101efee:	0f 85 93 00 00 00    	jne    101f087 <myl_native_dictionary_read+0x1c7>
 101eff4:	4d 8d 42 18          	lea    0x18(%r10),%r8
 101eff8:	e9 99 00 00 00       	jmp    101f096 <myl_native_dictionary_read+0x1d6>
 101effd:	48 83 f9 08          	cmp    $0x8,%rcx
 101f001:	b8 08 00 00 00       	mov    $0x8,%eax
 101f006:	48 0f 42 c1          	cmovb  %rcx,%rax
 101f00a:	48 8d 4d d0          	lea    -0x30(%rbp),%rcx
 101f00e:	49 89 ff             	mov    %rdi,%r15
 101f011:	48 89 cf             	mov    %rcx,%rdi
 101f014:	49 89 f4             	mov    %rsi,%r12
 101f017:	48 89 de             	mov    %rbx,%rsi
 101f01a:	49 89 d5             	mov    %rdx,%r13
 101f01d:	48 89 c2             	mov    %rax,%rdx
 101f020:	e8 2b d8 00 00       	call   102c850 <compiler_rt.memcpy.memcpyFast>
 101f025:	4c 89 e6             	mov    %r12,%rsi
 101f028:	4c 89 ff             	mov    %r15,%rdi
 101f02b:	4c 89 ea             	mov    %r13,%rdx
 101f02e:	48 8b 45 d0          	mov    -0x30(%rbp),%rax
 101f032:	4c 39 f0             	cmp    %r14,%rax
 101f035:	0f 85 26 01 00 00    	jne    101f161 <myl_native_dictionary_read+0x2a1>
 101f03b:	48 03 5f 18          	add    0x18(%rdi),%rbx
 101f03f:	48 8b 47 10          	mov    0x10(%rdi),%rax
 101f043:	48 8b 00             	mov    (%rax),%rax
 101f046:	48 83 f8 08          	cmp    $0x8,%rax
 101f04a:	75 08                	jne    101f054 <myl_native_dictionary_read+0x194>
 101f04c:	48 8b 03             	mov    (%rbx),%rax
 101f04f:	48 89 02             	mov    %rax,(%rdx)
 101f052:	eb 0e                	jmp    101f062 <myl_native_dictionary_read+0x1a2>
 101f054:	48 89 d7             	mov    %rdx,%rdi
 101f057:	48 89 de             	mov    %rbx,%rsi
 101f05a:	48 89 c2             	mov    %rax,%rdx
 101f05d:	e8 5e d4 00 00       	call   102c4c0 <compiler_rt.memmove.memmoveFast>
 101f062:	b8 01 00 00 00       	mov    $0x1,%eax
 101f067:	48 83 c4 08          	add    $0x8,%rsp
 101f06b:	5b                   	pop    %rbx
 101f06c:	41 5c                	pop    %r12
 101f06e:	41 5d                	pop    %r13
 101f070:	41 5e                	pop    %r14
 101f072:	41 5f                	pop    %r15
 101f074:	5d                   	pop    %rbp
 101f075:	c3                   	ret
 101f076:	44 8b 36             	mov    (%rsi),%r14d
 101f079:	e9 e7 fe ff ff       	jmp    101ef65 <myl_native_dictionary_read+0xa5>
 101f07e:	44 0f b7 36          	movzwl (%rsi),%r14d
 101f082:	e9 de fe ff ff       	jmp    101ef65 <myl_native_dictionary_read+0xa5>
 101f087:	4d 8b 42 18          	mov    0x18(%r10),%r8
 101f08b:	45 8b 4a 14          	mov    0x14(%r10),%r9d
 101f08f:	4d 01 c8             	add    %r9,%r8
 101f092:	49 83 c0 18          	add    $0x18,%r8
 101f096:	4c 8b 49 08          	mov    0x8(%rcx),%r9
 101f09a:	4d 3b 4a 08          	cmp    0x8(%r10),%r9
 101f09e:	0f 85 bd 00 00 00    	jne    101f161 <myl_native_dictionary_read+0x2a1>
 101f0a4:	49 83 f9 08          	cmp    $0x8,%r9
 101f0a8:	72 1f                	jb     101f0c9 <myl_native_dictionary_read+0x209>
 101f0aa:	45 31 d2             	xor    %r10d,%r10d
 101f0ad:	4d 8d 5a 08          	lea    0x8(%r10),%r11
 101f0b1:	4d 39 cb             	cmp    %r9,%r11
 101f0b4:	73 3e                	jae    101f0f4 <myl_native_dictionary_read+0x234>
 101f0b6:	4e 8b 74 11 18       	mov    0x18(%rcx,%r10,1),%r14
 101f0bb:	4f 3b 34 10          	cmp    (%r8,%r10,1),%r14
 101f0bf:	4d 89 da             	mov    %r11,%r10
 101f0c2:	74 e9                	je     101f0ad <myl_native_dictionary_read+0x1ed>
 101f0c4:	e9 98 00 00 00       	jmp    101f161 <myl_native_dictionary_read+0x2a1>
 101f0c9:	49 83 f9 03          	cmp    $0x3,%r9
 101f0cd:	76 42                	jbe    101f111 <myl_native_dictionary_read+0x251>
 101f0cf:	44 8b 51 18          	mov    0x18(%rcx),%r10d
 101f0d3:	47 8b 5c 08 fc       	mov    -0x4(%r8,%r9,1),%r11d
 101f0d8:	45 33 10             	xor    (%r8),%r10d
 101f0db:	46 33 5c 09 14       	xor    0x14(%rcx,%r9,1),%r11d
 101f0e0:	45 09 d3             	or     %r10d,%r11d
 101f0e3:	eb 19                	jmp    101f0fe <myl_native_dictionary_read+0x23e>
 101f0e5:	8b 03                	mov    (%rbx),%eax
 101f0e7:	e9 46 ff ff ff       	jmp    101f032 <myl_native_dictionary_read+0x172>
 101f0ec:	0f b7 03             	movzwl (%rbx),%eax
 101f0ef:	e9 3e ff ff ff       	jmp    101f032 <myl_native_dictionary_read+0x172>
 101f0f4:	4a 8b 4c 09 10       	mov    0x10(%rcx,%r9,1),%rcx
 101f0f9:	4b 3b 4c 08 f8       	cmp    -0x8(%r8,%r9,1),%rcx
 101f0fe:	0f 94 c1             	sete   %cl
 101f101:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
 101f105:	74 5a                	je     101f161 <myl_native_dictionary_read+0x2a1>
 101f107:	84 c9                	test   %cl,%cl
 101f109:	0f 85 2c ff ff ff    	jne    101f03b <myl_native_dictionary_read+0x17b>
 101f10f:	eb 50                	jmp    101f161 <myl_native_dictionary_read+0x2a1>
 101f111:	4d 85 c9             	test   %r9,%r9
 101f114:	0f 84 21 ff ff ff    	je     101f03b <myl_native_dictionary_read+0x17b>
 101f11a:	44 0f b6 51 18       	movzbl 0x18(%rcx),%r10d
 101f11f:	45 3a 10             	cmp    (%r8),%r10b
 101f122:	75 3d                	jne    101f161 <myl_native_dictionary_read+0x2a1>
 101f124:	49 83 f9 01          	cmp    $0x1,%r9
 101f128:	75 0c                	jne    101f136 <myl_native_dictionary_read+0x276>
 101f12a:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
 101f12e:	0f 85 07 ff ff ff    	jne    101f03b <myl_native_dictionary_read+0x17b>
 101f134:	eb 2b                	jmp    101f161 <myl_native_dictionary_read+0x2a1>
 101f136:	44 0f b6 51 19       	movzbl 0x19(%rcx),%r10d
 101f13b:	45 3a 50 01          	cmp    0x1(%r8),%r10b
 101f13f:	75 20                	jne    101f161 <myl_native_dictionary_read+0x2a1>
 101f141:	49 83 f9 02          	cmp    $0x2,%r9
 101f145:	74 e3                	je     101f12a <myl_native_dictionary_read+0x26a>
 101f147:	0f b6 49 1a          	movzbl 0x1a(%rcx),%ecx
 101f14b:	41 3a 48 02          	cmp    0x2(%r8),%cl
 101f14f:	0f 95 c1             	setne  %cl
 101f152:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
 101f156:	0f 94 c0             	sete   %al
 101f159:	08 c8                	or     %cl,%al
 101f15b:	0f 84 da fe ff ff    	je     101f03b <myl_native_dictionary_read+0x17b>
 101f161:	48 83 c4 08          	add    $0x8,%rsp
 101f165:	5b                   	pop    %rbx
 101f166:	41 5c                	pop    %r12
 101f168:	41 5d                	pop    %r13
 101f16a:	41 5e                	pop    %r14
 101f16c:	41 5f                	pop    %r15
 101f16e:	5d                   	pop    %rbp
 101f16f:	e9 0c 00 00 00       	jmp    101f180 <read_walk>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
