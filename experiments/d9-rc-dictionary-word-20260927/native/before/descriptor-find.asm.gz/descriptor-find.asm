
.tmp-rc/dict-loop/full/after-qbe-rc:     file format elf64-x86-64


Disassembly of section .text:

0000000001024470 <myl_rc_descriptor_find>:
 1024470:	48 85 ff             	test   %rdi,%rdi
 1024473:	0f 84 a5 00 00 00    	je     102451e <myl_rc_descriptor_find+0xae>
 1024479:	48 8b 87 08 16 00 00 	mov    0x1608(%rdi),%rax
 1024480:	48 85 c0             	test   %rax,%rax
 1024483:	0f 94 c1             	sete   %cl
 1024486:	48 85 f6             	test   %rsi,%rsi
 1024489:	0f 94 c2             	sete   %dl
 102448c:	08 ca                	or     %cl,%dl
 102448e:	0f 85 8a 00 00 00    	jne    102451e <myl_rc_descriptor_find+0xae>
 1024494:	55                   	push   %rbp
 1024495:	48 89 e5             	mov    %rsp,%rbp
 1024498:	48 8b 48 40          	mov    0x40(%rax),%rcx
 102449c:	48 85 c9             	test   %rcx,%rcx
 102449f:	0f 84 7c 00 00 00    	je     1024521 <myl_rc_descriptor_find+0xb1>
 10244a5:	48 8b 50 30          	mov    0x30(%rax),%rdx
 10244a9:	48 89 f0             	mov    %rsi,%rax
 10244ac:	48 c1 e8 03          	shr    $0x3,%rax
 10244b0:	48 89 f7             	mov    %rsi,%rdi
 10244b3:	48 c1 ef 21          	shr    $0x21,%rdi
 10244b7:	48 31 c7             	xor    %rax,%rdi
 10244ba:	48 b8 b9 e5 e4 1c 6d 	movabs $0xbf58476d1ce4e5b9,%rax
 10244c1:	47 58 bf 
 10244c4:	48 0f af c7          	imul   %rdi,%rax
 10244c8:	48 89 c7             	mov    %rax,%rdi
 10244cb:	48 c1 ef 1b          	shr    $0x1b,%rdi
 10244cf:	48 31 c7             	xor    %rax,%rdi
 10244d2:	48 83 f7 02          	xor    $0x2,%rdi
 10244d6:	48 ff c9             	dec    %rcx
 10244d9:	48 21 cf             	and    %rcx,%rdi
 10244dc:	48 8d 04 bf          	lea    (%rdi,%rdi,4),%rax
 10244e0:	4c 8b 04 c2          	mov    (%rdx,%rax,8),%r8
 10244e4:	31 c0                	xor    %eax,%eax
 10244e6:	eb 16                	jmp    10244fe <myl_rc_descriptor_find+0x8e>
 10244e8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
 10244ef:	00 
 10244f0:	48 ff c7             	inc    %rdi
 10244f3:	48 21 cf             	and    %rcx,%rdi
 10244f6:	4c 8d 04 bf          	lea    (%rdi,%rdi,4),%r8
 10244fa:	4e 8b 04 c2          	mov    (%rdx,%r8,8),%r8
 10244fe:	4d 85 c0             	test   %r8,%r8
 1024501:	74 19                	je     102451c <myl_rc_descriptor_find+0xac>
 1024503:	49 39 f0             	cmp    %rsi,%r8
 1024506:	75 e8                	jne    10244f0 <myl_rc_descriptor_find+0x80>
 1024508:	4c 8d 04 bf          	lea    (%rdi,%rdi,4),%r8
 102450c:	42 83 7c c2 20 02    	cmpl   $0x2,0x20(%rdx,%r8,8)
 1024512:	75 dc                	jne    10244f0 <myl_rc_descriptor_find+0x80>
 1024514:	4a 8d 04 c2          	lea    (%rdx,%r8,8),%rax
 1024518:	48 8b 40 08          	mov    0x8(%rax),%rax
 102451c:	5d                   	pop    %rbp
 102451d:	c3                   	ret
 102451e:	31 c0                	xor    %eax,%eax
 1024520:	c3                   	ret
 1024521:	31 c0                	xor    %eax,%eax
 1024523:	5d                   	pop    %rbp
 1024524:	c3                   	ret

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
