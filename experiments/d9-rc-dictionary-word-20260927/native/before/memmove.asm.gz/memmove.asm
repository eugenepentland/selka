
.tmp-rc/dict-loop/full/after-qbe-rc:     file format elf64-x86-64


Disassembly of section .text:

000000000102c4c0 <compiler_rt.memmove.memmoveFast>:
 102c4c0:	48 89 f8             	mov    %rdi,%rax
 102c4c3:	48 83 fa 0f          	cmp    $0xf,%rdx
 102c4c7:	77 33                	ja     102c4fc <compiler_rt.memmove.memmoveFast+0x3c>
 102c4c9:	48 83 fa 03          	cmp    $0x3,%rdx
 102c4cd:	0f 87 9c 00 00 00    	ja     102c56f <compiler_rt.memmove.memmoveFast+0xaf>
 102c4d3:	48 85 d2             	test   %rdx,%rdx
 102c4d6:	0f 84 bf 00 00 00    	je     102c59b <compiler_rt.memmove.memmoveFast+0xdb>
 102c4dc:	48 89 d1             	mov    %rdx,%rcx
 102c4df:	48 d1 e9             	shr    $1,%rcx
 102c4e2:	0f b6 3e             	movzbl (%rsi),%edi
 102c4e5:	44 0f b6 04 0e       	movzbl (%rsi,%rcx,1),%r8d
 102c4ea:	0f b6 74 16 ff       	movzbl -0x1(%rsi,%rdx,1),%esi
 102c4ef:	40 88 38             	mov    %dil,(%rax)
 102c4f2:	44 88 04 08          	mov    %r8b,(%rax,%rcx,1)
 102c4f6:	40 88 74 10 ff       	mov    %sil,-0x1(%rax,%rdx,1)
 102c4fb:	c3                   	ret
 102c4fc:	55                   	push   %rbp
 102c4fd:	48 89 e5             	mov    %rsp,%rbp
 102c500:	41 56                	push   %r14
 102c502:	53                   	push   %rbx
 102c503:	48 83 ec 40          	sub    $0x40,%rsp
 102c507:	48 83 fa 3f          	cmp    $0x3f,%rdx
 102c50b:	0f 87 8b 00 00 00    	ja     102c59c <compiler_rt.memmove.memmoveFast+0xdc>
 102c511:	89 d1                	mov    %edx,%ecx
 102c513:	d1 e9                	shr    $1,%ecx
 102c515:	83 e1 10             	and    $0x10,%ecx
 102c518:	48 8d 7a f0          	lea    -0x10(%rdx),%rdi
 102c51c:	48 29 cf             	sub    %rcx,%rdi
 102c51f:	c5 f8 10 06          	vmovups (%rsi),%xmm0
 102c523:	c5 f8 29 45 b0       	vmovaps %xmm0,-0x50(%rbp)
 102c528:	c5 f8 10 0c 0e       	vmovups (%rsi,%rcx,1),%xmm1
 102c52d:	c5 f8 29 4d e0       	vmovaps %xmm1,-0x20(%rbp)
 102c532:	c5 f8 10 0c 3e       	vmovups (%rsi,%rdi,1),%xmm1
 102c537:	c5 f8 29 4d d0       	vmovaps %xmm1,-0x30(%rbp)
 102c53c:	c5 f8 10 4c 16 f0    	vmovups -0x10(%rsi,%rdx,1),%xmm1
 102c542:	c5 f8 29 4d c0       	vmovaps %xmm1,-0x40(%rbp)
 102c547:	c5 f8 11 00          	vmovups %xmm0,(%rax)
 102c54b:	c5 f8 28 45 e0       	vmovaps -0x20(%rbp),%xmm0
 102c550:	c5 f8 11 04 08       	vmovups %xmm0,(%rax,%rcx,1)
 102c555:	c5 f8 28 45 d0       	vmovaps -0x30(%rbp),%xmm0
 102c55a:	c5 f8 11 04 38       	vmovups %xmm0,(%rax,%rdi,1)
 102c55f:	c5 f8 28 45 c0       	vmovaps -0x40(%rbp),%xmm0
 102c564:	c5 f8 11 44 10 f0    	vmovups %xmm0,-0x10(%rax,%rdx,1)
 102c56a:	e9 cf 02 00 00       	jmp    102c83e <compiler_rt.memmove.memmoveFast+0x37e>
 102c56f:	89 d1                	mov    %edx,%ecx
 102c571:	d1 e9                	shr    $1,%ecx
 102c573:	83 e1 04             	and    $0x4,%ecx
 102c576:	48 8d 7a fc          	lea    -0x4(%rdx),%rdi
 102c57a:	48 29 cf             	sub    %rcx,%rdi
 102c57d:	44 8b 06             	mov    (%rsi),%r8d
 102c580:	44 8b 0c 0e          	mov    (%rsi,%rcx,1),%r9d
 102c584:	44 8b 14 3e          	mov    (%rsi,%rdi,1),%r10d
 102c588:	8b 74 16 fc          	mov    -0x4(%rsi,%rdx,1),%esi
 102c58c:	44 89 00             	mov    %r8d,(%rax)
 102c58f:	44 89 0c 08          	mov    %r9d,(%rax,%rcx,1)
 102c593:	44 89 14 38          	mov    %r10d,(%rax,%rdi,1)
 102c597:	89 74 10 fc          	mov    %esi,-0x4(%rax,%rdx,1)
 102c59b:	c3                   	ret
 102c59c:	48 39 c6             	cmp    %rax,%rsi
 102c59f:	0f 83 4e 01 00 00    	jae    102c6f3 <compiler_rt.memmove.memmoveFast+0x233>
 102c5a5:	48 8d 4a e0          	lea    -0x20(%rdx),%rcx
 102c5a9:	c5 fc 10 44 16 e0    	vmovups -0x20(%rsi,%rdx,1),%ymm0
 102c5af:	c5 fc 11 45 90       	vmovups %ymm0,-0x70(%rbp)
 102c5b4:	c5 fc 10 06          	vmovups (%rsi),%ymm0
 102c5b8:	c5 fc 11 85 70 ff ff 	vmovups %ymm0,-0x90(%rbp)
 102c5bf:	ff 
 102c5c0:	48 01 c2             	add    %rax,%rdx
 102c5c3:	48 83 e2 e0          	and    $0xffffffffffffffe0,%rdx
 102c5c7:	49 89 d0             	mov    %rdx,%r8
 102c5ca:	49 29 c0             	sub    %rax,%r8
 102c5cd:	4d 89 c1             	mov    %r8,%r9
 102c5d0:	49 c1 e9 05          	shr    $0x5,%r9
 102c5d4:	0f 84 fe 00 00 00    	je     102c6d8 <compiler_rt.memmove.memmoveFast+0x218>
 102c5da:	44 89 cf             	mov    %r9d,%edi
 102c5dd:	83 e7 07             	and    $0x7,%edi
 102c5e0:	41 ba 01 00 00 00    	mov    $0x1,%r10d
 102c5e6:	49 81 f8 00 01 00 00 	cmp    $0x100,%r8
 102c5ed:	0f 82 b4 00 00 00    	jb     102c6a7 <compiler_rt.memmove.memmoveFast+0x1e7>
 102c5f3:	4d 8d 1c 30          	lea    (%r8,%rsi,1),%r11
 102c5f7:	49 83 c3 e0          	add    $0xffffffffffffffe0,%r11
 102c5fb:	49 83 e1 f8          	and    $0xfffffffffffffff8,%r9
 102c5ff:	49 f7 d9             	neg    %r9
 102c602:	48 c7 c3 e0 ff ff ff 	mov    $0xffffffffffffffe0,%rbx
 102c609:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
 102c610:	c4 c1 7c 10 44 1b 20 	vmovups 0x20(%r11,%rbx,1),%ymm0
 102c617:	c5 fc 29 04 1a       	vmovaps %ymm0,(%rdx,%rbx,1)
 102c61c:	c4 c1 7c 10 04 1b    	vmovups (%r11,%rbx,1),%ymm0
 102c622:	c5 fc 29 44 1a e0    	vmovaps %ymm0,-0x20(%rdx,%rbx,1)
 102c628:	c4 c1 7c 10 44 1b e0 	vmovups -0x20(%r11,%rbx,1),%ymm0
 102c62f:	c5 fc 29 44 1a c0    	vmovaps %ymm0,-0x40(%rdx,%rbx,1)
 102c635:	c4 c1 7c 10 44 1b c0 	vmovups -0x40(%r11,%rbx,1),%ymm0
 102c63c:	c5 fc 29 44 1a a0    	vmovaps %ymm0,-0x60(%rdx,%rbx,1)
 102c642:	c4 c1 7c 10 44 1b a0 	vmovups -0x60(%r11,%rbx,1),%ymm0
 102c649:	c5 fc 29 44 1a 80    	vmovaps %ymm0,-0x80(%rdx,%rbx,1)
 102c64f:	c4 c1 7c 10 44 1b 80 	vmovups -0x80(%r11,%rbx,1),%ymm0
 102c656:	c5 fc 29 84 1a 60 ff 	vmovaps %ymm0,-0xa0(%rdx,%rbx,1)
 102c65d:	ff ff 
 102c65f:	c4 c1 7c 10 84 1b 60 	vmovups -0xa0(%r11,%rbx,1),%ymm0
 102c666:	ff ff ff 
 102c669:	c5 fc 29 84 1a 40 ff 	vmovaps %ymm0,-0xc0(%rdx,%rbx,1)
 102c670:	ff ff 
 102c672:	c4 c1 7c 10 84 1b 40 	vmovups -0xc0(%r11,%rbx,1),%ymm0
 102c679:	ff ff ff 
 102c67c:	c5 fc 29 84 1a 20 ff 	vmovaps %ymm0,-0xe0(%rdx,%rbx,1)
 102c683:	ff ff 
 102c685:	48 81 c3 00 ff ff ff 	add    $0xffffffffffffff00,%rbx
 102c68c:	4f 8d 34 11          	lea    (%r9,%r10,1),%r14
 102c690:	49 83 c6 08          	add    $0x8,%r14
 102c694:	49 83 c2 08          	add    $0x8,%r10
 102c698:	49 83 fe 01          	cmp    $0x1,%r14
 102c69c:	0f 85 6e ff ff ff    	jne    102c610 <compiler_rt.memmove.memmoveFast+0x150>
 102c6a2:	48 85 ff             	test   %rdi,%rdi
 102c6a5:	74 31                	je     102c6d8 <compiler_rt.memmove.memmoveFast+0x218>
 102c6a7:	49 c1 e2 05          	shl    $0x5,%r10
 102c6ab:	4d 29 d0             	sub    %r10,%r8
 102c6ae:	4c 01 c6             	add    %r8,%rsi
 102c6b1:	4c 29 d2             	sub    %r10,%rdx
 102c6b4:	c1 e7 05             	shl    $0x5,%edi
 102c6b7:	45 31 c0             	xor    %r8d,%r8d
 102c6ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
 102c6c0:	c4 a1 7c 10 04 06    	vmovups (%rsi,%r8,1),%ymm0
 102c6c6:	c4 a1 7c 29 04 02    	vmovaps %ymm0,(%rdx,%r8,1)
 102c6cc:	49 83 c0 e0          	add    $0xffffffffffffffe0,%r8
 102c6d0:	49 89 f9             	mov    %rdi,%r9
 102c6d3:	4d 01 c1             	add    %r8,%r9
 102c6d6:	75 e8                	jne    102c6c0 <compiler_rt.memmove.memmoveFast+0x200>
 102c6d8:	c5 fc 10 85 70 ff ff 	vmovups -0x90(%rbp),%ymm0
 102c6df:	ff 
 102c6e0:	c5 fc 11 00          	vmovups %ymm0,(%rax)
 102c6e4:	c5 fc 10 45 90       	vmovups -0x70(%rbp),%ymm0
 102c6e9:	c5 fc 11 04 08       	vmovups %ymm0,(%rax,%rcx,1)
 102c6ee:	e9 4b 01 00 00       	jmp    102c83e <compiler_rt.memmove.memmoveFast+0x37e>
 102c6f3:	c5 fc 10 06          	vmovups (%rsi),%ymm0
 102c6f7:	c5 fc 11 85 50 ff ff 	vmovups %ymm0,-0xb0(%rbp)
 102c6fe:	ff 
 102c6ff:	48 8d 4a e0          	lea    -0x20(%rdx),%rcx
 102c703:	c5 fc 10 44 16 e0    	vmovups -0x20(%rsi,%rdx,1),%ymm0
 102c709:	c5 fc 11 85 30 ff ff 	vmovups %ymm0,-0xd0(%rbp)
 102c710:	ff 
 102c711:	89 f7                	mov    %esi,%edi
 102c713:	83 e7 1f             	and    $0x1f,%edi
 102c716:	4c 8d 04 3a          	lea    (%rdx,%rdi,1),%r8
 102c71a:	49 83 c0 e0          	add    $0xffffffffffffffe0,%r8
 102c71e:	49 c1 e8 05          	shr    $0x5,%r8
 102c722:	4d 8d 48 ff          	lea    -0x1(%r8),%r9
 102c726:	44 89 c2             	mov    %r8d,%edx
 102c729:	83 e2 07             	and    $0x7,%edx
 102c72c:	49 83 f9 07          	cmp    $0x7,%r9
 102c730:	73 08                	jae    102c73a <compiler_rt.memmove.memmoveFast+0x27a>
 102c732:	45 31 c9             	xor    %r9d,%r9d
 102c735:	e9 af 00 00 00       	jmp    102c7e9 <compiler_rt.memmove.memmoveFast+0x329>
 102c73a:	49 83 e0 f8          	and    $0xfffffffffffffff8,%r8
 102c73e:	41 ba 00 01 00 00    	mov    $0x100,%r10d
 102c744:	49 29 fa             	sub    %rdi,%r10
 102c747:	45 31 c9             	xor    %r9d,%r9d
 102c74a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
 102c750:	c4 a1 7c 28 84 16 20 	vmovaps -0xe0(%rsi,%r10,1),%ymm0
 102c757:	ff ff ff 
 102c75a:	c4 a1 7c 11 84 10 20 	vmovups %ymm0,-0xe0(%rax,%r10,1)
 102c761:	ff ff ff 
 102c764:	c4 a1 7c 28 84 16 40 	vmovaps -0xc0(%rsi,%r10,1),%ymm0
 102c76b:	ff ff ff 
 102c76e:	c4 a1 7c 11 84 10 40 	vmovups %ymm0,-0xc0(%rax,%r10,1)
 102c775:	ff ff ff 
 102c778:	c4 a1 7c 28 84 16 60 	vmovaps -0xa0(%rsi,%r10,1),%ymm0
 102c77f:	ff ff ff 
 102c782:	c4 a1 7c 11 84 10 60 	vmovups %ymm0,-0xa0(%rax,%r10,1)
 102c789:	ff ff ff 
 102c78c:	c4 a1 7c 28 44 16 80 	vmovaps -0x80(%rsi,%r10,1),%ymm0
 102c793:	c4 a1 7c 11 44 10 80 	vmovups %ymm0,-0x80(%rax,%r10,1)
 102c79a:	c4 a1 7c 28 44 16 a0 	vmovaps -0x60(%rsi,%r10,1),%ymm0
 102c7a1:	c4 a1 7c 11 44 10 a0 	vmovups %ymm0,-0x60(%rax,%r10,1)
 102c7a8:	c4 a1 7c 28 44 16 c0 	vmovaps -0x40(%rsi,%r10,1),%ymm0
 102c7af:	c4 a1 7c 11 44 10 c0 	vmovups %ymm0,-0x40(%rax,%r10,1)
 102c7b6:	c4 a1 7c 28 44 16 e0 	vmovaps -0x20(%rsi,%r10,1),%ymm0
 102c7bd:	c4 a1 7c 11 44 10 e0 	vmovups %ymm0,-0x20(%rax,%r10,1)
 102c7c4:	c4 a1 7c 28 04 16    	vmovaps (%rsi,%r10,1),%ymm0
 102c7ca:	c4 a1 7c 11 04 10    	vmovups %ymm0,(%rax,%r10,1)
 102c7d0:	49 83 c1 08          	add    $0x8,%r9
 102c7d4:	49 81 c2 00 01 00 00 	add    $0x100,%r10
 102c7db:	4d 39 c8             	cmp    %r9,%r8
 102c7de:	0f 85 6c ff ff ff    	jne    102c750 <compiler_rt.memmove.memmoveFast+0x290>
 102c7e4:	48 85 d2             	test   %rdx,%rdx
 102c7e7:	74 3c                	je     102c825 <compiler_rt.memmove.memmoveFast+0x365>
 102c7e9:	49 c1 e1 05          	shl    $0x5,%r9
 102c7ed:	49 29 f9             	sub    %rdi,%r9
 102c7f0:	4c 01 ce             	add    %r9,%rsi
 102c7f3:	48 83 c6 20          	add    $0x20,%rsi
 102c7f7:	4a 8d 3c 08          	lea    (%rax,%r9,1),%rdi
 102c7fb:	48 83 c7 20          	add    $0x20,%rdi
 102c7ff:	c1 e2 05             	shl    $0x5,%edx
 102c802:	45 31 c0             	xor    %r8d,%r8d
 102c805:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
 102c80c:	00 00 00 00 
 102c810:	c4 a1 7c 28 04 06    	vmovaps (%rsi,%r8,1),%ymm0
 102c816:	c4 a1 7c 11 04 07    	vmovups %ymm0,(%rdi,%r8,1)
 102c81c:	49 83 c0 20          	add    $0x20,%r8
 102c820:	4c 39 c2             	cmp    %r8,%rdx
 102c823:	75 eb                	jne    102c810 <compiler_rt.memmove.memmoveFast+0x350>
 102c825:	c5 fc 10 85 30 ff ff 	vmovups -0xd0(%rbp),%ymm0
 102c82c:	ff 
 102c82d:	c5 fc 11 04 08       	vmovups %ymm0,(%rax,%rcx,1)
 102c832:	c5 fc 10 85 50 ff ff 	vmovups -0xb0(%rbp),%ymm0
 102c839:	ff 
 102c83a:	c5 fc 11 00          	vmovups %ymm0,(%rax)
 102c83e:	48 83 c4 40          	add    $0x40,%rsp
 102c842:	5b                   	pop    %rbx
 102c843:	41 5e                	pop    %r14
 102c845:	5d                   	pop    %rbp
 102c846:	c5 f8 77             	vzeroupper
 102c849:	c3                   	ret

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
