
.tmp-rc/dict-loop/full/after-qbe-rc:     file format elf64-x86-64


Disassembly of section .text:

000000000101f440 <myl_native_dictionary_write>:
 101f440:	55                   	push   %rbp
 101f441:	48 89 e5             	mov    %rsp,%rbp
 101f444:	41 57                	push   %r15
 101f446:	41 56                	push   %r14
 101f448:	41 55                	push   %r13
 101f44a:	41 54                	push   %r12
 101f44c:	53                   	push   %rbx
 101f44d:	48 83 ec 28          	sub    $0x28,%rsp
 101f451:	48 89 4d c0          	mov    %rcx,-0x40(%rbp)
 101f455:	49 89 d4             	mov    %rdx,%r12
 101f458:	49 89 f7             	mov    %rsi,%r15
 101f45b:	49 89 fe             	mov    %rdi,%r14
 101f45e:	e8 cd 43 00 00       	call   1023830 <myl_rc_enabled>
 101f463:	85 c0                	test   %eax,%eax
 101f465:	74 32                	je     101f499 <myl_native_dictionary_write+0x59>
 101f467:	45 8b 6f 24          	mov    0x24(%r15),%r13d
 101f46b:	41 8b 9f f8 00 00 00 	mov    0xf8(%r15),%ebx
 101f472:	83 fb 01             	cmp    $0x1,%ebx
 101f475:	0f 85 78 02 00 00    	jne    101f6f3 <myl_native_dictionary_write+0x2b3>
 101f47b:	41 83 fd 02          	cmp    $0x2,%r13d
 101f47f:	74 45                	je     101f4c6 <myl_native_dictionary_write+0x86>
 101f481:	41 83 fd 01          	cmp    $0x1,%r13d
 101f485:	74 09                	je     101f490 <myl_native_dictionary_write+0x50>
 101f487:	45 85 ed             	test   %r13d,%r13d
 101f48a:	0f 85 63 02 00 00    	jne    101f6f3 <myl_native_dictionary_write+0x2b3>
 101f490:	49 8b 3c 24          	mov    (%r12),%rdi
 101f494:	e9 c7 00 00 00       	jmp    101f560 <myl_native_dictionary_write+0x120>
 101f499:	41 83 bf f8 00 00 00 	cmpl   $0x1,0xf8(%r15)
 101f4a0:	01 
 101f4a1:	0f 85 63 01 00 00    	jne    101f60a <myl_native_dictionary_write+0x1ca>
 101f4a7:	41 8b 5f 24          	mov    0x24(%r15),%ebx
 101f4ab:	83 fb 02             	cmp    $0x2,%ebx
 101f4ae:	74 51                	je     101f501 <myl_native_dictionary_write+0xc1>
 101f4b0:	83 fb 01             	cmp    $0x1,%ebx
 101f4b3:	74 08                	je     101f4bd <myl_native_dictionary_write+0x7d>
 101f4b5:	85 db                	test   %ebx,%ebx
 101f4b7:	0f 85 4d 01 00 00    	jne    101f60a <myl_native_dictionary_write+0x1ca>
 101f4bd:	49 8b 0c 24          	mov    (%r12),%rcx
 101f4c1:	e9 ff 00 00 00       	jmp    101f5c5 <myl_native_dictionary_write+0x185>
 101f4c6:	49 8b 47 08          	mov    0x8(%r15),%rax
 101f4ca:	48 8b 00             	mov    (%rax),%rax
 101f4cd:	48 c7 45 d0 00 00 00 	movq   $0x0,-0x30(%rbp)
 101f4d4:	00 
 101f4d5:	f3 48 0f b8 c8       	popcnt %rax,%rcx
 101f4da:	83 f9 01             	cmp    $0x1,%ecx
 101f4dd:	75 64                	jne    101f543 <myl_native_dictionary_write+0x103>
 101f4df:	f3 48 0f bc c8       	tzcnt  %rax,%rcx
 101f4e4:	48 83 f9 03          	cmp    $0x3,%rcx
 101f4e8:	77 59                	ja     101f543 <myl_native_dictionary_write+0x103>
 101f4ea:	48 8d 05 a7 b0 fe ff 	lea    -0x14f59(%rip),%rax        # 100a598 <octet_type+0xa0>
 101f4f1:	48 63 0c 88          	movslq (%rax,%rcx,4),%rcx
 101f4f5:	48 01 c1             	add    %rax,%rcx
 101f4f8:	ff e1                	jmp    *%rcx
 101f4fa:	41 0f b6 3c 24       	movzbl (%r12),%edi
 101f4ff:	eb 5f                	jmp    101f560 <myl_native_dictionary_write+0x120>
 101f501:	49 8b 47 08          	mov    0x8(%r15),%rax
 101f505:	48 8b 00             	mov    (%rax),%rax
 101f508:	48 c7 45 d0 00 00 00 	movq   $0x0,-0x30(%rbp)
 101f50f:	00 
 101f510:	f3 48 0f b8 c8       	popcnt %rax,%rcx
 101f515:	83 f9 01             	cmp    $0x1,%ecx
 101f518:	0f 85 8a 00 00 00    	jne    101f5a8 <myl_native_dictionary_write+0x168>
 101f51e:	f3 48 0f bc c8       	tzcnt  %rax,%rcx
 101f523:	48 83 f9 03          	cmp    $0x3,%rcx
 101f527:	77 7f                	ja     101f5a8 <myl_native_dictionary_write+0x168>
 101f529:	48 8d 05 98 b0 fe ff 	lea    -0x14f68(%rip),%rax        # 100a5c8 <octet_type+0xd0>
 101f530:	48 63 0c 88          	movslq (%rax,%rcx,4),%rcx
 101f534:	48 01 c1             	add    %rax,%rcx
 101f537:	ff e1                	jmp    *%rcx
 101f539:	41 0f b6 0c 24       	movzbl (%r12),%ecx
 101f53e:	e9 82 00 00 00       	jmp    101f5c5 <myl_native_dictionary_write+0x185>
 101f543:	48 83 f8 08          	cmp    $0x8,%rax
 101f547:	ba 08 00 00 00       	mov    $0x8,%edx
 101f54c:	48 0f 42 d0          	cmovb  %rax,%rdx
 101f550:	48 8d 7d d0          	lea    -0x30(%rbp),%rdi
 101f554:	4c 89 e6             	mov    %r12,%rsi
 101f557:	e8 f4 d2 00 00       	call   102c850 <compiler_rt.memcpy.memcpyFast>
 101f55c:	48 8b 7d d0          	mov    -0x30(%rbp),%rdi
 101f560:	49 3b bf e0 00 00 00 	cmp    0xe0(%r15),%rdi
 101f567:	0f 85 86 01 00 00    	jne    101f6f3 <myl_native_dictionary_write+0x2b3>
 101f56d:	49 8b 0f             	mov    (%r15),%rcx
 101f570:	49 8b 87 e8 00 00 00 	mov    0xe8(%r15),%rax
 101f577:	48 3b 01             	cmp    (%rcx),%rax
 101f57a:	0f 83 73 01 00 00    	jae    101f6f3 <myl_native_dictionary_write+0x2b3>
 101f580:	49 8b 77 30          	mov    0x30(%r15),%rsi
 101f584:	48 0f af f0          	imul   %rax,%rsi
 101f588:	48 03 71 20          	add    0x20(%rcx),%rsi
 101f58c:	41 83 fd 02          	cmp    $0x2,%r13d
 101f590:	0f 84 94 00 00 00    	je     101f62a <myl_native_dictionary_write+0x1ea>
 101f596:	41 83 fd 01          	cmp    $0x1,%r13d
 101f59a:	0f 85 c6 00 00 00    	jne    101f666 <myl_native_dictionary_write+0x226>
 101f5a0:	48 8b 0e             	mov    (%rsi),%rcx
 101f5a3:	e9 42 01 00 00       	jmp    101f6ea <myl_native_dictionary_write+0x2aa>
 101f5a8:	48 83 f8 08          	cmp    $0x8,%rax
 101f5ac:	ba 08 00 00 00       	mov    $0x8,%edx
 101f5b1:	48 0f 42 d0          	cmovb  %rax,%rdx
 101f5b5:	48 8d 7d d0          	lea    -0x30(%rbp),%rdi
 101f5b9:	4c 89 e6             	mov    %r12,%rsi
 101f5bc:	e8 8f d2 00 00       	call   102c850 <compiler_rt.memcpy.memcpyFast>
 101f5c1:	48 8b 4d d0          	mov    -0x30(%rbp),%rcx
 101f5c5:	49 3b 8f e0 00 00 00 	cmp    0xe0(%r15),%rcx
 101f5cc:	75 3c                	jne    101f60a <myl_native_dictionary_write+0x1ca>
 101f5ce:	49 8b 07             	mov    (%r15),%rax
 101f5d1:	4d 8b af e8 00 00 00 	mov    0xe8(%r15),%r13
 101f5d8:	4c 3b 28             	cmp    (%rax),%r13
 101f5db:	73 2d                	jae    101f60a <myl_native_dictionary_write+0x1ca>
 101f5dd:	4d 0f af 6f 30       	imul   0x30(%r15),%r13
 101f5e2:	4c 03 68 20          	add    0x20(%rax),%r13
 101f5e6:	85 db                	test   %ebx,%ebx
 101f5e8:	0f 84 9a 00 00 00    	je     101f688 <myl_native_dictionary_write+0x248>
 101f5ee:	48 8d 55 b0          	lea    -0x50(%rbp),%rdx
 101f5f2:	4c 89 ff             	mov    %r15,%rdi
 101f5f5:	4c 89 ee             	mov    %r13,%rsi
 101f5f8:	48 89 cb             	mov    %rcx,%rbx
 101f5fb:	e8 80 25 00 00       	call   1021b80 <record_key>
 101f600:	48 39 5d b0          	cmp    %rbx,-0x50(%rbp)
 101f604:	0f 84 91 00 00 00    	je     101f69b <myl_native_dictionary_write+0x25b>
 101f60a:	4c 89 f7             	mov    %r14,%rdi
 101f60d:	4c 89 fe             	mov    %r15,%rsi
 101f610:	4c 89 e2             	mov    %r12,%rdx
 101f613:	48 8b 4d c0          	mov    -0x40(%rbp),%rcx
 101f617:	48 83 c4 28          	add    $0x28,%rsp
 101f61b:	5b                   	pop    %rbx
 101f61c:	41 5c                	pop    %r12
 101f61e:	41 5d                	pop    %r13
 101f620:	41 5e                	pop    %r14
 101f622:	41 5f                	pop    %r15
 101f624:	5d                   	pop    %rbp
 101f625:	e9 a6 03 00 00       	jmp    101f9d0 <write_walk>
 101f62a:	49 8b 4f 08          	mov    0x8(%r15),%rcx
 101f62e:	48 8b 09             	mov    (%rcx),%rcx
 101f631:	48 c7 45 d0 00 00 00 	movq   $0x0,-0x30(%rbp)
 101f638:	00 
 101f639:	f3 48 0f b8 d1       	popcnt %rcx,%rdx
 101f63e:	83 fa 01             	cmp    $0x1,%edx
 101f641:	75 7d                	jne    101f6c0 <myl_native_dictionary_write+0x280>
 101f643:	f3 48 0f bc d1       	tzcnt  %rcx,%rdx
 101f648:	48 83 fa 03          	cmp    $0x3,%rdx
 101f64c:	77 72                	ja     101f6c0 <myl_native_dictionary_write+0x280>
 101f64e:	48 8d 0d 53 af fe ff 	lea    -0x150ad(%rip),%rcx        # 100a5a8 <octet_type+0xb0>
 101f655:	48 63 14 91          	movslq (%rcx,%rdx,4),%rdx
 101f659:	48 01 ca             	add    %rcx,%rdx
 101f65c:	ff e2                	jmp    *%rdx
 101f65e:	0f b6 0e             	movzbl (%rsi),%ecx
 101f661:	e9 84 00 00 00       	jmp    101f6ea <myl_native_dictionary_write+0x2aa>
 101f666:	49 89 c5             	mov    %rax,%r13
 101f669:	48 89 f7             	mov    %rsi,%rdi
 101f66c:	4c 89 e6             	mov    %r12,%rsi
 101f66f:	e8 9c 25 00 00       	call   1021c10 <same_text_key>
 101f674:	85 c0                	test   %eax,%eax
 101f676:	4c 89 e8             	mov    %r13,%rax
 101f679:	0f 85 23 02 00 00    	jne    101f8a2 <myl_native_dictionary_write+0x462>
 101f67f:	49 8d 47 24          	lea    0x24(%r15),%rax
 101f683:	e9 80 00 00 00       	jmp    101f708 <myl_native_dictionary_write+0x2c8>
 101f688:	4c 89 ef             	mov    %r13,%rdi
 101f68b:	4c 89 e6             	mov    %r12,%rsi
 101f68e:	e8 7d 25 00 00       	call   1021c10 <same_text_key>
 101f693:	85 c0                	test   %eax,%eax
 101f695:	0f 84 6f ff ff ff    	je     101f60a <myl_native_dictionary_write+0x1ca>
 101f69b:	4d 03 6f 18          	add    0x18(%r15),%r13
 101f69f:	49 8b 47 10          	mov    0x10(%r15),%rax
 101f6a3:	48 8b 10             	mov    (%rax),%rdx
 101f6a6:	48 83 fa 08          	cmp    $0x8,%rdx
 101f6aa:	0f 85 be 02 00 00    	jne    101f96e <myl_native_dictionary_write+0x52e>
 101f6b0:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
 101f6b4:	48 8b 00             	mov    (%rax),%rax
 101f6b7:	49 89 45 00          	mov    %rax,0x0(%r13)
 101f6bb:	e9 ba 02 00 00       	jmp    101f97a <myl_native_dictionary_write+0x53a>
 101f6c0:	48 83 f9 08          	cmp    $0x8,%rcx
 101f6c4:	ba 08 00 00 00       	mov    $0x8,%edx
 101f6c9:	48 0f 42 d1          	cmovb  %rcx,%rdx
 101f6cd:	48 89 7d b8          	mov    %rdi,-0x48(%rbp)
 101f6d1:	48 8d 7d d0          	lea    -0x30(%rbp),%rdi
 101f6d5:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
 101f6d9:	e8 72 d1 00 00       	call   102c850 <compiler_rt.memcpy.memcpyFast>
 101f6de:	48 8b 7d b8          	mov    -0x48(%rbp),%rdi
 101f6e2:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
 101f6e6:	48 8b 4d d0          	mov    -0x30(%rbp),%rcx
 101f6ea:	48 39 f9             	cmp    %rdi,%rcx
 101f6ed:	0f 84 af 01 00 00    	je     101f8a2 <myl_native_dictionary_write+0x462>
 101f6f3:	49 8d 47 24          	lea    0x24(%r15),%rax
 101f6f7:	41 83 fd 02          	cmp    $0x2,%r13d
 101f6fb:	74 3e                	je     101f73b <myl_native_dictionary_write+0x2fb>
 101f6fd:	41 83 fd 01          	cmp    $0x1,%r13d
 101f701:	74 1d                	je     101f720 <myl_native_dictionary_write+0x2e0>
 101f703:	45 85 ed             	test   %r13d,%r13d
 101f706:	75 72                	jne    101f77a <myl_native_dictionary_write+0x33a>
 101f708:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
 101f70c:	4d 8b 2c 24          	mov    (%r12),%r13
 101f710:	31 c0                	xor    %eax,%eax
 101f712:	83 fb 02             	cmp    $0x2,%ebx
 101f715:	0f 84 ab 00 00 00    	je     101f7c6 <myl_native_dictionary_write+0x386>
 101f71b:	e9 b3 00 00 00       	jmp    101f7d3 <myl_native_dictionary_write+0x393>
 101f720:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
 101f724:	4d 8b 2c 24          	mov    (%r12),%r13
 101f728:	b8 01 00 00 00       	mov    $0x1,%eax
 101f72d:	83 fb 02             	cmp    $0x2,%ebx
 101f730:	0f 84 90 00 00 00    	je     101f7c6 <myl_native_dictionary_write+0x386>
 101f736:	e9 98 00 00 00       	jmp    101f7d3 <myl_native_dictionary_write+0x393>
 101f73b:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
 101f73f:	49 8b 47 08          	mov    0x8(%r15),%rax
 101f743:	48 8b 00             	mov    (%rax),%rax
 101f746:	48 c7 45 d0 00 00 00 	movq   $0x0,-0x30(%rbp)
 101f74d:	00 
 101f74e:	f3 48 0f b8 c8       	popcnt %rax,%rcx
 101f753:	83 f9 01             	cmp    $0x1,%ecx
 101f756:	75 47                	jne    101f79f <myl_native_dictionary_write+0x35f>
 101f758:	f3 48 0f bc c8       	tzcnt  %rax,%rcx
 101f75d:	48 83 f9 03          	cmp    $0x3,%rcx
 101f761:	77 3c                	ja     101f79f <myl_native_dictionary_write+0x35f>
 101f763:	48 8d 05 4e ae fe ff 	lea    -0x151b2(%rip),%rax        # 100a5b8 <octet_type+0xc0>
 101f76a:	48 63 0c 88          	movslq (%rax,%rcx,4),%rcx
 101f76e:	48 01 c1             	add    %rax,%rcx
 101f771:	ff e1                	jmp    *%rcx
 101f773:	45 0f b6 2c 24       	movzbl (%r12),%r13d
 101f778:	eb 42                	jmp    101f7bc <myl_native_dictionary_write+0x37c>
 101f77a:	4c 89 ff             	mov    %r15,%rdi
 101f77d:	4c 89 e6             	mov    %r12,%rsi
 101f780:	e8 6b 25 00 00       	call   1021cf0 <probe_any>
 101f785:	41 c7 87 f8 00 00 00 	movl   $0x0,0xf8(%r15)
 101f78c:	00 00 00 00 
 101f790:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
 101f794:	0f 85 08 01 00 00    	jne    101f8a2 <myl_native_dictionary_write+0x462>
 101f79a:	e9 90 01 00 00       	jmp    101f92f <myl_native_dictionary_write+0x4ef>
 101f79f:	48 83 f8 08          	cmp    $0x8,%rax
 101f7a3:	ba 08 00 00 00       	mov    $0x8,%edx
 101f7a8:	48 0f 42 d0          	cmovb  %rax,%rdx
 101f7ac:	48 8d 7d d0          	lea    -0x30(%rbp),%rdi
 101f7b0:	4c 89 e6             	mov    %r12,%rsi
 101f7b3:	e8 98 d0 00 00       	call   102c850 <compiler_rt.memcpy.memcpyFast>
 101f7b8:	4c 8b 6d d0          	mov    -0x30(%rbp),%r13
 101f7bc:	b8 02 00 00 00       	mov    $0x2,%eax
 101f7c1:	83 fb 02             	cmp    $0x2,%ebx
 101f7c4:	75 0d                	jne    101f7d3 <myl_native_dictionary_write+0x393>
 101f7c6:	4d 3b af e0 00 00 00 	cmp    0xe0(%r15),%r13
 101f7cd:	0f 84 5c 01 00 00    	je     101f92f <myl_native_dictionary_write+0x4ef>
 101f7d3:	49 83 bf d8 00 00 00 	cmpq   $0x0,0xd8(%r15)
 101f7da:	00 
 101f7db:	74 7a                	je     101f857 <myl_native_dictionary_write+0x417>
 101f7dd:	83 f8 01             	cmp    $0x1,%eax
 101f7e0:	0f 84 0a 01 00 00    	je     101f8f0 <myl_native_dictionary_write+0x4b0>
 101f7e6:	85 c0                	test   %eax,%eax
 101f7e8:	0f 85 1c 01 00 00    	jne    101f90a <myl_native_dictionary_write+0x4ca>
 101f7ee:	49 8b 34 24          	mov    (%r12),%rsi
 101f7f2:	4c 89 ff             	mov    %r15,%rdi
 101f7f5:	e8 16 26 00 00       	call   1021e10 <probe_text>
 101f7fa:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
 101f7fe:	75 68                	jne    101f868 <myl_native_dictionary_write+0x428>
 101f800:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
 101f804:	83 38 00             	cmpl   $0x0,(%rax)
 101f807:	0f 84 17 01 00 00    	je     101f924 <myl_native_dictionary_write+0x4e4>
 101f80d:	89 d0                	mov    %edx,%eax
 101f80f:	83 f8 ff             	cmp    $0xffffffff,%eax
 101f812:	0f 84 0c 01 00 00    	je     101f924 <myl_native_dictionary_write+0x4e4>
 101f818:	4d 89 af e0 00 00 00 	mov    %r13,0xe0(%r15)
 101f81f:	49 c7 87 e8 00 00 00 	movq   $0x0,0xe8(%r15)
 101f826:	00 00 00 00 
 101f82a:	49 89 97 f0 00 00 00 	mov    %rdx,0xf0(%r15)
 101f831:	41 c7 87 f8 00 00 00 	movl   $0x2,0xf8(%r15)
 101f838:	02 00 00 00 
 101f83c:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
 101f840:	c4 c1 78 11 87 fc 00 	vmovups %xmm0,0xfc(%r15)
 101f847:	00 00 
 101f849:	c4 c1 78 11 87 08 01 	vmovups %xmm0,0x108(%r15)
 101f850:	00 00 
 101f852:	e9 d8 00 00 00       	jmp    101f92f <myl_native_dictionary_write+0x4ef>
 101f857:	4c 89 ff             	mov    %r15,%rdi
 101f85a:	4c 89 e6             	mov    %r12,%rsi
 101f85d:	e8 8e 24 00 00       	call   1021cf0 <probe_any>
 101f862:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
 101f866:	74 98                	je     101f800 <myl_native_dictionary_write+0x3c0>
 101f868:	4d 89 af e0 00 00 00 	mov    %r13,0xe0(%r15)
 101f86f:	49 89 87 e8 00 00 00 	mov    %rax,0xe8(%r15)
 101f876:	49 c7 87 f0 00 00 00 	movq   $0x0,0xf0(%r15)
 101f87d:	00 00 00 00 
 101f881:	41 c7 87 f8 00 00 00 	movl   $0x1,0xf8(%r15)
 101f888:	01 00 00 00 
 101f88c:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
 101f890:	c4 c1 78 11 87 fc 00 	vmovups %xmm0,0xfc(%r15)
 101f897:	00 00 
 101f899:	c4 c1 78 11 87 08 01 	vmovups %xmm0,0x108(%r15)
 101f8a0:	00 00 
 101f8a2:	49 8b 77 10          	mov    0x10(%r15),%rsi
 101f8a6:	49 8b 4f f0          	mov    -0x10(%r15),%rcx
 101f8aa:	49 8b 17             	mov    (%r15),%rdx
 101f8ad:	49 0f af 47 30       	imul   0x30(%r15),%rax
 101f8b2:	48 03 42 20          	add    0x20(%rdx),%rax
 101f8b6:	49 03 47 18          	add    0x18(%r15),%rax
 101f8ba:	48 89 ca             	mov    %rcx,%rdx
 101f8bd:	48 c1 ea 28          	shr    $0x28,%rdx
 101f8c1:	81 e2 ff ff 0f 00    	and    $0xfffff,%edx
 101f8c7:	45 31 c0             	xor    %r8d,%r8d
 101f8ca:	48 0f ba e1 3e       	bt     $0x3e,%rcx
 101f8cf:	44 0f 42 c2          	cmovb  %edx,%r8d
 101f8d3:	4c 89 f7             	mov    %r14,%rdi
 101f8d6:	48 89 c2             	mov    %rax,%rdx
 101f8d9:	48 8b 4d c0          	mov    -0x40(%rbp),%rcx
 101f8dd:	48 83 c4 28          	add    $0x28,%rsp
 101f8e1:	5b                   	pop    %rbx
 101f8e2:	41 5c                	pop    %r12
 101f8e4:	41 5d                	pop    %r13
 101f8e6:	41 5e                	pop    %r14
 101f8e8:	41 5f                	pop    %r15
 101f8ea:	5d                   	pop    %rbp
 101f8eb:	e9 60 c8 00 00       	jmp    102c150 <myl_rc_native_retain_replace>
 101f8f0:	4c 89 ff             	mov    %r15,%rdi
 101f8f3:	4c 89 ee             	mov    %r13,%rsi
 101f8f6:	e8 b5 26 00 00       	call   1021fb0 <probe_word>
 101f8fb:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
 101f8ff:	0f 85 63 ff ff ff    	jne    101f868 <myl_native_dictionary_write+0x428>
 101f905:	e9 f6 fe ff ff       	jmp    101f800 <myl_native_dictionary_write+0x3c0>
 101f90a:	4c 89 ff             	mov    %r15,%rdi
 101f90d:	4c 89 ee             	mov    %r13,%rsi
 101f910:	e8 4b 27 00 00       	call   1022060 <probe_scalar>
 101f915:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
 101f919:	0f 85 49 ff ff ff    	jne    101f868 <myl_native_dictionary_write+0x428>
 101f91f:	e9 dc fe ff ff       	jmp    101f800 <myl_native_dictionary_write+0x3c0>
 101f924:	41 c7 87 f8 00 00 00 	movl   $0x0,0xf8(%r15)
 101f92b:	00 00 00 00 
 101f92f:	4c 89 f7             	mov    %r14,%rdi
 101f932:	4c 89 fe             	mov    %r15,%rsi
 101f935:	4c 89 e2             	mov    %r12,%rdx
 101f938:	48 8b 4d c0          	mov    -0x40(%rbp),%rcx
 101f93c:	45 31 c0             	xor    %r8d,%r8d
 101f93f:	48 83 c4 28          	add    $0x28,%rsp
 101f943:	5b                   	pop    %rbx
 101f944:	41 5c                	pop    %r12
 101f946:	41 5d                	pop    %r13
 101f948:	41 5e                	pop    %r14
 101f94a:	41 5f                	pop    %r15
 101f94c:	5d                   	pop    %rbp
 101f94d:	e9 4e 09 00 00       	jmp    10202a0 <rc_insert_result>
 101f952:	45 8b 2c 24          	mov    (%r12),%r13d
 101f956:	e9 61 fe ff ff       	jmp    101f7bc <myl_native_dictionary_write+0x37c>
 101f95b:	4d 8b 2c 24          	mov    (%r12),%r13
 101f95f:	e9 58 fe ff ff       	jmp    101f7bc <myl_native_dictionary_write+0x37c>
 101f964:	45 0f b7 2c 24       	movzwl (%r12),%r13d
 101f969:	e9 4e fe ff ff       	jmp    101f7bc <myl_native_dictionary_write+0x37c>
 101f96e:	4c 89 ef             	mov    %r13,%rdi
 101f971:	48 8b 75 c0          	mov    -0x40(%rbp),%rsi
 101f975:	e8 46 cb 00 00       	call   102c4c0 <compiler_rt.memmove.memmoveFast>
 101f97a:	b8 01 00 00 00       	mov    $0x1,%eax
 101f97f:	48 83 c4 28          	add    $0x28,%rsp
 101f983:	5b                   	pop    %rbx
 101f984:	41 5c                	pop    %r12
 101f986:	41 5d                	pop    %r13
 101f988:	41 5e                	pop    %r14
 101f98a:	41 5f                	pop    %r15
 101f98c:	5d                   	pop    %rbp
 101f98d:	c3                   	ret
 101f98e:	41 8b 3c 24          	mov    (%r12),%edi
 101f992:	e9 c9 fb ff ff       	jmp    101f560 <myl_native_dictionary_write+0x120>
 101f997:	41 0f b7 3c 24       	movzwl (%r12),%edi
 101f99c:	e9 bf fb ff ff       	jmp    101f560 <myl_native_dictionary_write+0x120>
 101f9a1:	41 8b 0c 24          	mov    (%r12),%ecx
 101f9a5:	e9 1b fc ff ff       	jmp    101f5c5 <myl_native_dictionary_write+0x185>
 101f9aa:	41 0f b7 0c 24       	movzwl (%r12),%ecx
 101f9af:	e9 11 fc ff ff       	jmp    101f5c5 <myl_native_dictionary_write+0x185>
 101f9b4:	8b 0e                	mov    (%rsi),%ecx
 101f9b6:	e9 2f fd ff ff       	jmp    101f6ea <myl_native_dictionary_write+0x2aa>
 101f9bb:	0f b7 0e             	movzwl (%rsi),%ecx
 101f9be:	e9 27 fd ff ff       	jmp    101f6ea <myl_native_dictionary_write+0x2aa>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
