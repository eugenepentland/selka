
.tmp-rc/dict-loop/full/after-qbe-rc:     file format elf64-x86-64


Disassembly of section .text:

000000000102c150 <myl_rc_native_retain_replace>:
 102c150:	b8 01 00 00 00       	mov    $0x1,%eax
 102c155:	48 39 ca             	cmp    %rcx,%rdx
 102c158:	0f 84 f3 00 00 00    	je     102c251 <myl_rc_native_retain_replace+0x101>
 102c15e:	55                   	push   %rbp
 102c15f:	48 89 e5             	mov    %rsp,%rbp
 102c162:	41 57                	push   %r15
 102c164:	41 56                	push   %r14
 102c166:	41 55                	push   %r13
 102c168:	41 54                	push   %r12
 102c16a:	53                   	push   %rbx
 102c16b:	48 81 ec 88 00 00 00 	sub    $0x88,%rsp
 102c172:	44 89 c3             	mov    %r8d,%ebx
 102c175:	49 89 cd             	mov    %rcx,%r13
 102c178:	49 89 d4             	mov    %rdx,%r12
 102c17b:	49 89 f7             	mov    %rsi,%r15
 102c17e:	49 89 fe             	mov    %rdi,%r14
 102c181:	e8 ea 82 ff ff       	call   1024470 <myl_rc_descriptor_find>
 102c186:	48 85 c0             	test   %rax,%rax
 102c189:	74 18                	je     102c1a3 <myl_rc_native_retain_replace+0x53>
 102c18b:	83 78 78 00          	cmpl   $0x0,0x78(%rax)
 102c18f:	75 12                	jne    102c1a3 <myl_rc_native_retain_replace+0x53>
 102c191:	49 8b 86 08 16 00 00 	mov    0x1608(%r14),%rax
 102c198:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
 102c19d:	0f 84 af 00 00 00    	je     102c252 <myl_rc_native_retain_replace+0x102>
 102c1a3:	89 5d d0             	mov    %ebx,-0x30(%rbp)
 102c1a6:	49 8b 37             	mov    (%r15),%rsi
 102c1a9:	48 81 fe 81 00 00 00 	cmp    $0x81,%rsi
 102c1b0:	73 09                	jae    102c1bb <myl_rc_native_retain_replace+0x6b>
 102c1b2:	48 8d 9d 50 ff ff ff 	lea    -0xb0(%rbp),%rbx
 102c1b9:	eb 19                	jmp    102c1d4 <myl_rc_native_retain_replace+0x84>
 102c1bb:	c7 45 d4 00 00 00 00 	movl   $0x0,-0x2c(%rbp)
 102c1c2:	4c 89 f7             	mov    %r14,%rdi
 102c1c5:	31 d2                	xor    %edx,%edx
 102c1c7:	e8 64 ec ff ff       	call   102ae30 <myl_rc_storage_bytes>
 102c1cc:	48 89 c3             	mov    %rax,%rbx
 102c1cf:	48 85 c0             	test   %rax,%rax
 102c1d2:	74 69                	je     102c23d <myl_rc_native_retain_replace+0xed>
 102c1d4:	4c 89 f7             	mov    %r14,%rdi
 102c1d7:	4c 89 fe             	mov    %r15,%rsi
 102c1da:	48 89 da             	mov    %rbx,%rdx
 102c1dd:	4c 89 e9             	mov    %r13,%rcx
 102c1e0:	44 8b 45 d0          	mov    -0x30(%rbp),%r8d
 102c1e4:	e8 67 fc ff ff       	call   102be50 <myl_rc_native_retain>
 102c1e9:	89 45 d4             	mov    %eax,-0x2c(%rbp)
 102c1ec:	85 c0                	test   %eax,%eax
 102c1ee:	74 36                	je     102c226 <myl_rc_native_retain_replace+0xd6>
 102c1f0:	49 83 3f 00          	cmpq   $0x0,(%r15)
 102c1f4:	74 22                	je     102c218 <myl_rc_native_retain_replace+0xc8>
 102c1f6:	31 c0                	xor    %eax,%eax
 102c1f8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
 102c1ff:	00 
 102c200:	41 0f b6 0c 04       	movzbl (%r12,%rax,1),%ecx
 102c205:	0f b6 14 03          	movzbl (%rbx,%rax,1),%edx
 102c209:	41 88 14 04          	mov    %dl,(%r12,%rax,1)
 102c20d:	88 0c 03             	mov    %cl,(%rbx,%rax,1)
 102c210:	48 ff c0             	inc    %rax
 102c213:	49 3b 07             	cmp    (%r15),%rax
 102c216:	72 e8                	jb     102c200 <myl_rc_native_retain_replace+0xb0>
 102c218:	4c 89 f7             	mov    %r14,%rdi
 102c21b:	4c 89 fe             	mov    %r15,%rsi
 102c21e:	48 89 da             	mov    %rbx,%rdx
 102c221:	e8 da f7 ff ff       	call   102ba00 <myl_rc_native_drop>
 102c226:	48 8d 85 50 ff ff ff 	lea    -0xb0(%rbp),%rax
 102c22d:	48 39 c3             	cmp    %rax,%rbx
 102c230:	74 0b                	je     102c23d <myl_rc_native_retain_replace+0xed>
 102c232:	4c 89 f7             	mov    %r14,%rdi
 102c235:	48 89 de             	mov    %rbx,%rsi
 102c238:	e8 a3 7a ff ff       	call   1023ce0 <myl_rc_owner_release>
 102c23d:	8b 45 d4             	mov    -0x2c(%rbp),%eax
 102c240:	48 81 c4 88 00 00 00 	add    $0x88,%rsp
 102c247:	5b                   	pop    %rbx
 102c248:	41 5c                	pop    %r12
 102c24a:	41 5d                	pop    %r13
 102c24c:	41 5e                	pop    %r14
 102c24e:	41 5f                	pop    %r15
 102c250:	5d                   	pop    %rbp
 102c251:	c3                   	ret
 102c252:	41 3b 5e 70          	cmp    0x70(%r14),%ebx
 102c256:	76 11                	jbe    102c269 <myl_rc_native_retain_replace+0x119>
 102c258:	4c 89 f7             	mov    %r14,%rdi
 102c25b:	be 03 00 00 00       	mov    $0x3,%esi
 102c260:	e8 eb 75 ff ff       	call   1023850 <myl_rc_record_failure>
 102c265:	31 c0                	xor    %eax,%eax
 102c267:	eb d7                	jmp    102c240 <myl_rc_native_retain_replace+0xf0>
 102c269:	49 8b 17             	mov    (%r15),%rdx
 102c26c:	4c 89 e7             	mov    %r12,%rdi
 102c26f:	4c 89 ee             	mov    %r13,%rsi
 102c272:	e8 49 02 00 00       	call   102c4c0 <compiler_rt.memmove.memmoveFast>
 102c277:	b8 01 00 00 00       	mov    $0x1,%eax
 102c27c:	eb c2                	jmp    102c240 <myl_rc_native_retain_replace+0xf0>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
