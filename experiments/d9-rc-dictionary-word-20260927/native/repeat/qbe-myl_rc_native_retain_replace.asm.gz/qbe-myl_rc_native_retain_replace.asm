
/home/epentland/ai/canopy/mylang-worktrees/d9-rc-compiler-astra/.tmp-rc/dict-word/repeat/qbe-rc:     file format elf64-x86-64


Disassembly of section .text:

000000000102c2f0 <myl_rc_native_retain_replace>:
 102c2f0:	b8 01 00 00 00       	mov    $0x1,%eax
 102c2f5:	48 39 ca             	cmp    %rcx,%rdx
 102c2f8:	0f 84 f3 00 00 00    	je     102c3f1 <myl_rc_native_retain_replace+0x101>
 102c2fe:	55                   	push   %rbp
 102c2ff:	48 89 e5             	mov    %rsp,%rbp
 102c302:	41 57                	push   %r15
 102c304:	41 56                	push   %r14
 102c306:	41 55                	push   %r13
 102c308:	41 54                	push   %r12
 102c30a:	53                   	push   %rbx
 102c30b:	48 81 ec 88 00 00 00 	sub    $0x88,%rsp
 102c312:	44 89 c3             	mov    %r8d,%ebx
 102c315:	49 89 cd             	mov    %rcx,%r13
 102c318:	49 89 d4             	mov    %rdx,%r12
 102c31b:	49 89 f7             	mov    %rsi,%r15
 102c31e:	49 89 fe             	mov    %rdi,%r14
 102c321:	e8 ea 81 ff ff       	call   1024510 <myl_rc_descriptor_find>
 102c326:	48 85 c0             	test   %rax,%rax
 102c329:	74 18                	je     102c343 <myl_rc_native_retain_replace+0x53>
 102c32b:	83 78 78 00          	cmpl   $0x0,0x78(%rax)
 102c32f:	75 12                	jne    102c343 <myl_rc_native_retain_replace+0x53>
 102c331:	49 8b 86 08 16 00 00 	mov    0x1608(%r14),%rax
 102c338:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
 102c33d:	0f 84 af 00 00 00    	je     102c3f2 <myl_rc_native_retain_replace+0x102>
 102c343:	89 5d d0             	mov    %ebx,-0x30(%rbp)
 102c346:	49 8b 37             	mov    (%r15),%rsi
 102c349:	48 81 fe 81 00 00 00 	cmp    $0x81,%rsi
 102c350:	73 09                	jae    102c35b <myl_rc_native_retain_replace+0x6b>
 102c352:	48 8d 9d 50 ff ff ff 	lea    -0xb0(%rbp),%rbx
 102c359:	eb 19                	jmp    102c374 <myl_rc_native_retain_replace+0x84>
 102c35b:	c7 45 d4 00 00 00 00 	movl   $0x0,-0x2c(%rbp)
 102c362:	4c 89 f7             	mov    %r14,%rdi
 102c365:	31 d2                	xor    %edx,%edx
 102c367:	e8 64 ec ff ff       	call   102afd0 <myl_rc_storage_bytes>
 102c36c:	48 89 c3             	mov    %rax,%rbx
 102c36f:	48 85 c0             	test   %rax,%rax
 102c372:	74 69                	je     102c3dd <myl_rc_native_retain_replace+0xed>
 102c374:	4c 89 f7             	mov    %r14,%rdi
 102c377:	4c 89 fe             	mov    %r15,%rsi
 102c37a:	48 89 da             	mov    %rbx,%rdx
 102c37d:	4c 89 e9             	mov    %r13,%rcx
 102c380:	44 8b 45 d0          	mov    -0x30(%rbp),%r8d
 102c384:	e8 67 fc ff ff       	call   102bff0 <myl_rc_native_retain>
 102c389:	89 45 d4             	mov    %eax,-0x2c(%rbp)
 102c38c:	85 c0                	test   %eax,%eax
 102c38e:	74 36                	je     102c3c6 <myl_rc_native_retain_replace+0xd6>
 102c390:	49 83 3f 00          	cmpq   $0x0,(%r15)
 102c394:	74 22                	je     102c3b8 <myl_rc_native_retain_replace+0xc8>
 102c396:	31 c0                	xor    %eax,%eax
 102c398:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
 102c39f:	00 
 102c3a0:	41 0f b6 0c 04       	movzbl (%r12,%rax,1),%ecx
 102c3a5:	0f b6 14 03          	movzbl (%rbx,%rax,1),%edx
 102c3a9:	41 88 14 04          	mov    %dl,(%r12,%rax,1)
 102c3ad:	88 0c 03             	mov    %cl,(%rbx,%rax,1)
 102c3b0:	48 ff c0             	inc    %rax
 102c3b3:	49 3b 07             	cmp    (%r15),%rax
 102c3b6:	72 e8                	jb     102c3a0 <myl_rc_native_retain_replace+0xb0>
 102c3b8:	4c 89 f7             	mov    %r14,%rdi
 102c3bb:	4c 89 fe             	mov    %r15,%rsi
 102c3be:	48 89 da             	mov    %rbx,%rdx
 102c3c1:	e8 da f7 ff ff       	call   102bba0 <myl_rc_native_drop>
 102c3c6:	48 8d 85 50 ff ff ff 	lea    -0xb0(%rbp),%rax
 102c3cd:	48 39 c3             	cmp    %rax,%rbx
 102c3d0:	74 0b                	je     102c3dd <myl_rc_native_retain_replace+0xed>
 102c3d2:	4c 89 f7             	mov    %r14,%rdi
 102c3d5:	48 89 de             	mov    %rbx,%rsi
 102c3d8:	e8 a3 79 ff ff       	call   1023d80 <myl_rc_owner_release>
 102c3dd:	8b 45 d4             	mov    -0x2c(%rbp),%eax
 102c3e0:	48 81 c4 88 00 00 00 	add    $0x88,%rsp
 102c3e7:	5b                   	pop    %rbx
 102c3e8:	41 5c                	pop    %r12
 102c3ea:	41 5d                	pop    %r13
 102c3ec:	41 5e                	pop    %r14
 102c3ee:	41 5f                	pop    %r15
 102c3f0:	5d                   	pop    %rbp
 102c3f1:	c3                   	ret
 102c3f2:	41 3b 5e 70          	cmp    0x70(%r14),%ebx
 102c3f6:	76 11                	jbe    102c409 <myl_rc_native_retain_replace+0x119>
 102c3f8:	4c 89 f7             	mov    %r14,%rdi
 102c3fb:	be 03 00 00 00       	mov    $0x3,%esi
 102c400:	e8 eb 74 ff ff       	call   10238f0 <myl_rc_record_failure>
 102c405:	31 c0                	xor    %eax,%eax
 102c407:	eb d7                	jmp    102c3e0 <myl_rc_native_retain_replace+0xf0>
 102c409:	49 8b 17             	mov    (%r15),%rdx
 102c40c:	4c 89 e7             	mov    %r12,%rdi
 102c40f:	4c 89 ee             	mov    %r13,%rsi
 102c412:	e8 49 02 00 00       	call   102c660 <compiler_rt.memmove.memmoveFast>
 102c417:	b8 01 00 00 00       	mov    $0x1,%eax
 102c41c:	eb c2                	jmp    102c3e0 <myl_rc_native_retain_replace+0xf0>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
