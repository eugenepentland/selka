
/home/epentland/ai/canopy/mylang-worktrees/d9-rc-compiler-astra/.tmp-rc/dict-word/repeat/qbe-rc:     file format elf64-x86-64


Disassembly of section .text:

0000000001025200 <myl_rc_descriptor_repeat>:
 1025200:	48 85 ff             	test   %rdi,%rdi
 1025203:	0f 84 e9 00 00 00    	je     10252f2 <myl_rc_descriptor_repeat+0xf2>
 1025209:	48 8b 87 08 16 00 00 	mov    0x1608(%rdi),%rax
 1025210:	48 85 c0             	test   %rax,%rax
 1025213:	0f 94 c1             	sete   %cl
 1025216:	48 85 f6             	test   %rsi,%rsi
 1025219:	0f 94 c2             	sete   %dl
 102521c:	08 ca                	or     %cl,%dl
 102521e:	0f 85 ce 00 00 00    	jne    10252f2 <myl_rc_descriptor_repeat+0xf2>
 1025224:	55                   	push   %rbp
 1025225:	48 89 e5             	mov    %rsp,%rbp
 1025228:	48 8b 50 40          	mov    0x40(%rax),%rdx
 102522c:	48 85 d2             	test   %rdx,%rdx
 102522f:	0f 84 c0 00 00 00    	je     10252f5 <myl_rc_descriptor_repeat+0xf5>
 1025235:	48 8b 48 30          	mov    0x30(%rax),%rcx
 1025239:	8b 79 24             	mov    0x24(%rcx),%edi
 102523c:	48 85 ff             	test   %rdi,%rdi
 102523f:	0f 94 c0             	sete   %al
 1025242:	48 39 fa             	cmp    %rdi,%rdx
 1025245:	41 0f 92 c0          	setb   %r8b
 1025249:	41 08 c0             	or     %al,%r8b
 102524c:	75 1a                	jne    1025268 <myl_rc_descriptor_repeat+0x68>
 102524e:	ff cf                	dec    %edi
 1025250:	48 8d 04 bf          	lea    (%rdi,%rdi,4),%rax
 1025254:	48 39 34 c1          	cmp    %rsi,(%rcx,%rax,8)
 1025258:	75 0e                	jne    1025268 <myl_rc_descriptor_repeat+0x68>
 102525a:	48 8d 04 c1          	lea    (%rcx,%rax,8),%rax
 102525e:	83 78 20 02          	cmpl   $0x2,0x20(%rax)
 1025262:	0f 84 7f 00 00 00    	je     10252e7 <myl_rc_descriptor_repeat+0xe7>
 1025268:	48 89 f0             	mov    %rsi,%rax
 102526b:	48 c1 e8 03          	shr    $0x3,%rax
 102526f:	48 89 f7             	mov    %rsi,%rdi
 1025272:	48 c1 ef 21          	shr    $0x21,%rdi
 1025276:	48 31 c7             	xor    %rax,%rdi
 1025279:	48 b8 b9 e5 e4 1c 6d 	movabs $0xbf58476d1ce4e5b9,%rax
 1025280:	47 58 bf 
 1025283:	48 0f af c7          	imul   %rdi,%rax
 1025287:	48 89 c7             	mov    %rax,%rdi
 102528a:	48 c1 ef 1b          	shr    $0x1b,%rdi
 102528e:	48 31 c7             	xor    %rax,%rdi
 1025291:	48 83 f7 02          	xor    $0x2,%rdi
 1025295:	48 ff ca             	dec    %rdx
 1025298:	48 21 d7             	and    %rdx,%rdi
 102529b:	48 8d 04 bf          	lea    (%rdi,%rdi,4),%rax
 102529f:	4c 8b 04 c1          	mov    (%rcx,%rax,8),%r8
 10252a3:	31 c0                	xor    %eax,%eax
 10252a5:	eb 17                	jmp    10252be <myl_rc_descriptor_repeat+0xbe>
 10252a7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
 10252ae:	00 00 
 10252b0:	48 ff c7             	inc    %rdi
 10252b3:	48 21 d7             	and    %rdx,%rdi
 10252b6:	4c 8d 04 bf          	lea    (%rdi,%rdi,4),%r8
 10252ba:	4e 8b 04 c1          	mov    (%rcx,%r8,8),%r8
 10252be:	4d 85 c0             	test   %r8,%r8
 10252c1:	74 2d                	je     10252f0 <myl_rc_descriptor_repeat+0xf0>
 10252c3:	49 39 f0             	cmp    %rsi,%r8
 10252c6:	75 e8                	jne    10252b0 <myl_rc_descriptor_repeat+0xb0>
 10252c8:	4c 8d 04 bf          	lea    (%rdi,%rdi,4),%r8
 10252cc:	42 83 7c c1 20 02    	cmpl   $0x2,0x20(%rcx,%r8,8)
 10252d2:	75 dc                	jne    10252b0 <myl_rc_descriptor_repeat+0xb0>
 10252d4:	8d 47 01             	lea    0x1(%rdi),%eax
 10252d7:	31 d2                	xor    %edx,%edx
 10252d9:	be ff ff ff ff       	mov    $0xffffffff,%esi
 10252de:	48 39 f7             	cmp    %rsi,%rdi
 10252e1:	0f 42 d0             	cmovb  %eax,%edx
 10252e4:	89 51 24             	mov    %edx,0x24(%rcx)
 10252e7:	48 8d 04 bf          	lea    (%rdi,%rdi,4),%rax
 10252eb:	48 8b 44 c1 08       	mov    0x8(%rcx,%rax,8),%rax
 10252f0:	5d                   	pop    %rbp
 10252f1:	c3                   	ret
 10252f2:	31 c0                	xor    %eax,%eax
 10252f4:	c3                   	ret
 10252f5:	31 c0                	xor    %eax,%eax
 10252f7:	5d                   	pop    %rbp
 10252f8:	c3                   	ret

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
