
/home/epentland/ai/canopy/mylang-worktrees/d9-rc-compiler-astra/.tmp-rc/dict-word/repeat/qbe-rc:     file format elf64-x86-64


Disassembly of section .text:

000000000101f480 <myl_native_dictionary_write>:
 101f480:	55                   	push   %rbp
 101f481:	48 89 e5             	mov    %rsp,%rbp
 101f484:	41 57                	push   %r15
 101f486:	41 56                	push   %r14
 101f488:	41 55                	push   %r13
 101f48a:	41 54                	push   %r12
 101f48c:	53                   	push   %rbx
 101f48d:	48 83 ec 28          	sub    $0x28,%rsp
 101f491:	48 89 4d c0          	mov    %rcx,-0x40(%rbp)
 101f495:	49 89 d4             	mov    %rdx,%r12
 101f498:	49 89 f7             	mov    %rsi,%r15
 101f49b:	49 89 fe             	mov    %rdi,%r14
 101f49e:	e8 2d 44 00 00       	call   10238d0 <myl_rc_enabled>
 101f4a3:	85 c0                	test   %eax,%eax
 101f4a5:	74 32                	je     101f4d9 <myl_native_dictionary_write+0x59>
 101f4a7:	45 8b 6f 24          	mov    0x24(%r15),%r13d
 101f4ab:	41 8b 9f f8 00 00 00 	mov    0xf8(%r15),%ebx
 101f4b2:	83 fb 01             	cmp    $0x1,%ebx
 101f4b5:	0f 85 78 02 00 00    	jne    101f733 <myl_native_dictionary_write+0x2b3>
 101f4bb:	41 83 fd 02          	cmp    $0x2,%r13d
 101f4bf:	74 45                	je     101f506 <myl_native_dictionary_write+0x86>
 101f4c1:	41 83 fd 01          	cmp    $0x1,%r13d
 101f4c5:	74 09                	je     101f4d0 <myl_native_dictionary_write+0x50>
 101f4c7:	45 85 ed             	test   %r13d,%r13d
 101f4ca:	0f 85 63 02 00 00    	jne    101f733 <myl_native_dictionary_write+0x2b3>
 101f4d0:	49 8b 3c 24          	mov    (%r12),%rdi
 101f4d4:	e9 c7 00 00 00       	jmp    101f5a0 <myl_native_dictionary_write+0x120>
 101f4d9:	41 83 bf f8 00 00 00 	cmpl   $0x1,0xf8(%r15)
 101f4e0:	01 
 101f4e1:	0f 85 63 01 00 00    	jne    101f64a <myl_native_dictionary_write+0x1ca>
 101f4e7:	41 8b 5f 24          	mov    0x24(%r15),%ebx
 101f4eb:	83 fb 02             	cmp    $0x2,%ebx
 101f4ee:	74 51                	je     101f541 <myl_native_dictionary_write+0xc1>
 101f4f0:	83 fb 01             	cmp    $0x1,%ebx
 101f4f3:	74 08                	je     101f4fd <myl_native_dictionary_write+0x7d>
 101f4f5:	85 db                	test   %ebx,%ebx
 101f4f7:	0f 85 4d 01 00 00    	jne    101f64a <myl_native_dictionary_write+0x1ca>
 101f4fd:	49 8b 0c 24          	mov    (%r12),%rcx
 101f501:	e9 ff 00 00 00       	jmp    101f605 <myl_native_dictionary_write+0x185>
 101f506:	49 8b 47 08          	mov    0x8(%r15),%rax
 101f50a:	48 8b 00             	mov    (%rax),%rax
 101f50d:	48 c7 45 d0 00 00 00 	movq   $0x0,-0x30(%rbp)
 101f514:	00 
 101f515:	f3 48 0f b8 c8       	popcnt %rax,%rcx
 101f51a:	83 f9 01             	cmp    $0x1,%ecx
 101f51d:	75 64                	jne    101f583 <myl_native_dictionary_write+0x103>
 101f51f:	f3 48 0f bc c8       	tzcnt  %rax,%rcx
 101f524:	48 83 f9 03          	cmp    $0x3,%rcx
 101f528:	77 59                	ja     101f583 <myl_native_dictionary_write+0x103>
 101f52a:	48 8d 05 67 b0 fe ff 	lea    -0x14f99(%rip),%rax        # 100a598 <octet_type+0xa0>
 101f531:	48 63 0c 88          	movslq (%rax,%rcx,4),%rcx
 101f535:	48 01 c1             	add    %rax,%rcx
 101f538:	ff e1                	jmp    *%rcx
 101f53a:	41 0f b6 3c 24       	movzbl (%r12),%edi
 101f53f:	eb 5f                	jmp    101f5a0 <myl_native_dictionary_write+0x120>
 101f541:	49 8b 47 08          	mov    0x8(%r15),%rax
 101f545:	48 8b 00             	mov    (%rax),%rax
 101f548:	48 c7 45 d0 00 00 00 	movq   $0x0,-0x30(%rbp)
 101f54f:	00 
 101f550:	f3 48 0f b8 c8       	popcnt %rax,%rcx
 101f555:	83 f9 01             	cmp    $0x1,%ecx
 101f558:	0f 85 8a 00 00 00    	jne    101f5e8 <myl_native_dictionary_write+0x168>
 101f55e:	f3 48 0f bc c8       	tzcnt  %rax,%rcx
 101f563:	48 83 f9 03          	cmp    $0x3,%rcx
 101f567:	77 7f                	ja     101f5e8 <myl_native_dictionary_write+0x168>
 101f569:	48 8d 05 58 b0 fe ff 	lea    -0x14fa8(%rip),%rax        # 100a5c8 <octet_type+0xd0>
 101f570:	48 63 0c 88          	movslq (%rax,%rcx,4),%rcx
 101f574:	48 01 c1             	add    %rax,%rcx
 101f577:	ff e1                	jmp    *%rcx
 101f579:	41 0f b6 0c 24       	movzbl (%r12),%ecx
 101f57e:	e9 82 00 00 00       	jmp    101f605 <myl_native_dictionary_write+0x185>
 101f583:	48 83 f8 08          	cmp    $0x8,%rax
 101f587:	ba 08 00 00 00       	mov    $0x8,%edx
 101f58c:	48 0f 42 d0          	cmovb  %rax,%rdx
 101f590:	48 8d 7d d0          	lea    -0x30(%rbp),%rdi
 101f594:	4c 89 e6             	mov    %r12,%rsi
 101f597:	e8 54 d4 00 00       	call   102c9f0 <compiler_rt.memcpy.memcpyFast>
 101f59c:	48 8b 7d d0          	mov    -0x30(%rbp),%rdi
 101f5a0:	49 3b bf e0 00 00 00 	cmp    0xe0(%r15),%rdi
 101f5a7:	0f 85 86 01 00 00    	jne    101f733 <myl_native_dictionary_write+0x2b3>
 101f5ad:	49 8b 0f             	mov    (%r15),%rcx
 101f5b0:	49 8b 87 e8 00 00 00 	mov    0xe8(%r15),%rax
 101f5b7:	48 3b 01             	cmp    (%rcx),%rax
 101f5ba:	0f 83 73 01 00 00    	jae    101f733 <myl_native_dictionary_write+0x2b3>
 101f5c0:	49 8b 77 30          	mov    0x30(%r15),%rsi
 101f5c4:	48 0f af f0          	imul   %rax,%rsi
 101f5c8:	48 03 71 20          	add    0x20(%rcx),%rsi
 101f5cc:	41 83 fd 02          	cmp    $0x2,%r13d
 101f5d0:	0f 84 94 00 00 00    	je     101f66a <myl_native_dictionary_write+0x1ea>
 101f5d6:	41 83 fd 01          	cmp    $0x1,%r13d
 101f5da:	0f 85 c6 00 00 00    	jne    101f6a6 <myl_native_dictionary_write+0x226>
 101f5e0:	48 8b 0e             	mov    (%rsi),%rcx
 101f5e3:	e9 42 01 00 00       	jmp    101f72a <myl_native_dictionary_write+0x2aa>
 101f5e8:	48 83 f8 08          	cmp    $0x8,%rax
 101f5ec:	ba 08 00 00 00       	mov    $0x8,%edx
 101f5f1:	48 0f 42 d0          	cmovb  %rax,%rdx
 101f5f5:	48 8d 7d d0          	lea    -0x30(%rbp),%rdi
 101f5f9:	4c 89 e6             	mov    %r12,%rsi
 101f5fc:	e8 ef d3 00 00       	call   102c9f0 <compiler_rt.memcpy.memcpyFast>
 101f601:	48 8b 4d d0          	mov    -0x30(%rbp),%rcx
 101f605:	49 3b 8f e0 00 00 00 	cmp    0xe0(%r15),%rcx
 101f60c:	75 3c                	jne    101f64a <myl_native_dictionary_write+0x1ca>
 101f60e:	49 8b 07             	mov    (%r15),%rax
 101f611:	4d 8b af e8 00 00 00 	mov    0xe8(%r15),%r13
 101f618:	4c 3b 28             	cmp    (%rax),%r13
 101f61b:	73 2d                	jae    101f64a <myl_native_dictionary_write+0x1ca>
 101f61d:	4d 0f af 6f 30       	imul   0x30(%r15),%r13
 101f622:	4c 03 68 20          	add    0x20(%rax),%r13
 101f626:	85 db                	test   %ebx,%ebx
 101f628:	0f 84 9a 00 00 00    	je     101f6c8 <myl_native_dictionary_write+0x248>
 101f62e:	48 8d 55 b0          	lea    -0x50(%rbp),%rdx
 101f632:	4c 89 ff             	mov    %r15,%rdi
 101f635:	4c 89 ee             	mov    %r13,%rsi
 101f638:	48 89 cb             	mov    %rcx,%rbx
 101f63b:	e8 e0 25 00 00       	call   1021c20 <record_key>
 101f640:	48 39 5d b0          	cmp    %rbx,-0x50(%rbp)
 101f644:	0f 84 91 00 00 00    	je     101f6db <myl_native_dictionary_write+0x25b>
 101f64a:	4c 89 f7             	mov    %r14,%rdi
 101f64d:	4c 89 fe             	mov    %r15,%rsi
 101f650:	4c 89 e2             	mov    %r12,%rdx
 101f653:	48 8b 4d c0          	mov    -0x40(%rbp),%rcx
 101f657:	48 83 c4 28          	add    $0x28,%rsp
 101f65b:	5b                   	pop    %rbx
 101f65c:	41 5c                	pop    %r12
 101f65e:	41 5d                	pop    %r13
 101f660:	41 5e                	pop    %r14
 101f662:	41 5f                	pop    %r15
 101f664:	5d                   	pop    %rbp
 101f665:	e9 06 04 00 00       	jmp    101fa70 <write_walk>
 101f66a:	49 8b 4f 08          	mov    0x8(%r15),%rcx
 101f66e:	48 8b 09             	mov    (%rcx),%rcx
 101f671:	48 c7 45 d0 00 00 00 	movq   $0x0,-0x30(%rbp)
 101f678:	00 
 101f679:	f3 48 0f b8 d1       	popcnt %rcx,%rdx
 101f67e:	83 fa 01             	cmp    $0x1,%edx
 101f681:	75 7d                	jne    101f700 <myl_native_dictionary_write+0x280>
 101f683:	f3 48 0f bc d1       	tzcnt  %rcx,%rdx
 101f688:	48 83 fa 03          	cmp    $0x3,%rdx
 101f68c:	77 72                	ja     101f700 <myl_native_dictionary_write+0x280>
 101f68e:	48 8d 0d 13 af fe ff 	lea    -0x150ed(%rip),%rcx        # 100a5a8 <octet_type+0xb0>
 101f695:	48 63 14 91          	movslq (%rcx,%rdx,4),%rdx
 101f699:	48 01 ca             	add    %rcx,%rdx
 101f69c:	ff e2                	jmp    *%rdx
 101f69e:	0f b6 0e             	movzbl (%rsi),%ecx
 101f6a1:	e9 84 00 00 00       	jmp    101f72a <myl_native_dictionary_write+0x2aa>
 101f6a6:	49 89 c5             	mov    %rax,%r13
 101f6a9:	48 89 f7             	mov    %rsi,%rdi
 101f6ac:	4c 89 e6             	mov    %r12,%rsi
 101f6af:	e8 fc 25 00 00       	call   1021cb0 <same_text_key>
 101f6b4:	85 c0                	test   %eax,%eax
 101f6b6:	4c 89 e8             	mov    %r13,%rax
 101f6b9:	0f 85 23 02 00 00    	jne    101f8e2 <myl_native_dictionary_write+0x462>
 101f6bf:	49 8d 47 24          	lea    0x24(%r15),%rax
 101f6c3:	e9 80 00 00 00       	jmp    101f748 <myl_native_dictionary_write+0x2c8>
 101f6c8:	4c 89 ef             	mov    %r13,%rdi
 101f6cb:	4c 89 e6             	mov    %r12,%rsi
 101f6ce:	e8 dd 25 00 00       	call   1021cb0 <same_text_key>
 101f6d3:	85 c0                	test   %eax,%eax
 101f6d5:	0f 84 6f ff ff ff    	je     101f64a <myl_native_dictionary_write+0x1ca>
 101f6db:	4d 03 6f 18          	add    0x18(%r15),%r13
 101f6df:	49 8b 47 10          	mov    0x10(%r15),%rax
 101f6e3:	48 8b 10             	mov    (%rax),%rdx
 101f6e6:	48 83 fa 08          	cmp    $0x8,%rdx
 101f6ea:	0f 85 16 03 00 00    	jne    101fa06 <myl_native_dictionary_write+0x586>
 101f6f0:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
 101f6f4:	48 8b 00             	mov    (%rax),%rax
 101f6f7:	49 89 45 00          	mov    %rax,0x0(%r13)
 101f6fb:	e9 12 03 00 00       	jmp    101fa12 <myl_native_dictionary_write+0x592>
 101f700:	48 83 f9 08          	cmp    $0x8,%rcx
 101f704:	ba 08 00 00 00       	mov    $0x8,%edx
 101f709:	48 0f 42 d1          	cmovb  %rcx,%rdx
 101f70d:	48 89 7d b8          	mov    %rdi,-0x48(%rbp)
 101f711:	48 8d 7d d0          	lea    -0x30(%rbp),%rdi
 101f715:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
 101f719:	e8 d2 d2 00 00       	call   102c9f0 <compiler_rt.memcpy.memcpyFast>
 101f71e:	48 8b 7d b8          	mov    -0x48(%rbp),%rdi
 101f722:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
 101f726:	48 8b 4d d0          	mov    -0x30(%rbp),%rcx
 101f72a:	48 39 f9             	cmp    %rdi,%rcx
 101f72d:	0f 84 af 01 00 00    	je     101f8e2 <myl_native_dictionary_write+0x462>
 101f733:	49 8d 47 24          	lea    0x24(%r15),%rax
 101f737:	41 83 fd 02          	cmp    $0x2,%r13d
 101f73b:	74 3e                	je     101f77b <myl_native_dictionary_write+0x2fb>
 101f73d:	41 83 fd 01          	cmp    $0x1,%r13d
 101f741:	74 1d                	je     101f760 <myl_native_dictionary_write+0x2e0>
 101f743:	45 85 ed             	test   %r13d,%r13d
 101f746:	75 72                	jne    101f7ba <myl_native_dictionary_write+0x33a>
 101f748:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
 101f74c:	4d 8b 2c 24          	mov    (%r12),%r13
 101f750:	31 c0                	xor    %eax,%eax
 101f752:	83 fb 02             	cmp    $0x2,%ebx
 101f755:	0f 84 ab 00 00 00    	je     101f806 <myl_native_dictionary_write+0x386>
 101f75b:	e9 b3 00 00 00       	jmp    101f813 <myl_native_dictionary_write+0x393>
 101f760:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
 101f764:	4d 8b 2c 24          	mov    (%r12),%r13
 101f768:	b8 01 00 00 00       	mov    $0x1,%eax
 101f76d:	83 fb 02             	cmp    $0x2,%ebx
 101f770:	0f 84 90 00 00 00    	je     101f806 <myl_native_dictionary_write+0x386>
 101f776:	e9 98 00 00 00       	jmp    101f813 <myl_native_dictionary_write+0x393>
 101f77b:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
 101f77f:	49 8b 47 08          	mov    0x8(%r15),%rax
 101f783:	48 8b 00             	mov    (%rax),%rax
 101f786:	48 c7 45 d0 00 00 00 	movq   $0x0,-0x30(%rbp)
 101f78d:	00 
 101f78e:	f3 48 0f b8 c8       	popcnt %rax,%rcx
 101f793:	83 f9 01             	cmp    $0x1,%ecx
 101f796:	75 47                	jne    101f7df <myl_native_dictionary_write+0x35f>
 101f798:	f3 48 0f bc c8       	tzcnt  %rax,%rcx
 101f79d:	48 83 f9 03          	cmp    $0x3,%rcx
 101f7a1:	77 3c                	ja     101f7df <myl_native_dictionary_write+0x35f>
 101f7a3:	48 8d 05 0e ae fe ff 	lea    -0x151f2(%rip),%rax        # 100a5b8 <octet_type+0xc0>
 101f7aa:	48 63 0c 88          	movslq (%rax,%rcx,4),%rcx
 101f7ae:	48 01 c1             	add    %rax,%rcx
 101f7b1:	ff e1                	jmp    *%rcx
 101f7b3:	45 0f b6 2c 24       	movzbl (%r12),%r13d
 101f7b8:	eb 42                	jmp    101f7fc <myl_native_dictionary_write+0x37c>
 101f7ba:	4c 89 ff             	mov    %r15,%rdi
 101f7bd:	4c 89 e6             	mov    %r12,%rsi
 101f7c0:	e8 cb 25 00 00       	call   1021d90 <probe_any>
 101f7c5:	41 c7 87 f8 00 00 00 	movl   $0x0,0xf8(%r15)
 101f7cc:	00 00 00 00 
 101f7d0:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
 101f7d4:	0f 85 08 01 00 00    	jne    101f8e2 <myl_native_dictionary_write+0x462>
 101f7da:	e9 e8 01 00 00       	jmp    101f9c7 <myl_native_dictionary_write+0x547>
 101f7df:	48 83 f8 08          	cmp    $0x8,%rax
 101f7e3:	ba 08 00 00 00       	mov    $0x8,%edx
 101f7e8:	48 0f 42 d0          	cmovb  %rax,%rdx
 101f7ec:	48 8d 7d d0          	lea    -0x30(%rbp),%rdi
 101f7f0:	4c 89 e6             	mov    %r12,%rsi
 101f7f3:	e8 f8 d1 00 00       	call   102c9f0 <compiler_rt.memcpy.memcpyFast>
 101f7f8:	4c 8b 6d d0          	mov    -0x30(%rbp),%r13
 101f7fc:	b8 02 00 00 00       	mov    $0x2,%eax
 101f801:	83 fb 02             	cmp    $0x2,%ebx
 101f804:	75 0d                	jne    101f813 <myl_native_dictionary_write+0x393>
 101f806:	4d 3b af e0 00 00 00 	cmp    0xe0(%r15),%r13
 101f80d:	0f 84 b4 01 00 00    	je     101f9c7 <myl_native_dictionary_write+0x547>
 101f813:	49 83 bf d8 00 00 00 	cmpq   $0x0,0xd8(%r15)
 101f81a:	00 
 101f81b:	74 7a                	je     101f897 <myl_native_dictionary_write+0x417>
 101f81d:	83 f8 01             	cmp    $0x1,%eax
 101f820:	0f 84 62 01 00 00    	je     101f988 <myl_native_dictionary_write+0x508>
 101f826:	85 c0                	test   %eax,%eax
 101f828:	0f 85 74 01 00 00    	jne    101f9a2 <myl_native_dictionary_write+0x522>
 101f82e:	49 8b 34 24          	mov    (%r12),%rsi
 101f832:	4c 89 ff             	mov    %r15,%rdi
 101f835:	e8 76 26 00 00       	call   1021eb0 <probe_text>
 101f83a:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
 101f83e:	75 68                	jne    101f8a8 <myl_native_dictionary_write+0x428>
 101f840:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
 101f844:	83 38 00             	cmpl   $0x0,(%rax)
 101f847:	0f 84 6f 01 00 00    	je     101f9bc <myl_native_dictionary_write+0x53c>
 101f84d:	89 d0                	mov    %edx,%eax
 101f84f:	83 f8 ff             	cmp    $0xffffffff,%eax
 101f852:	0f 84 64 01 00 00    	je     101f9bc <myl_native_dictionary_write+0x53c>
 101f858:	4d 89 af e0 00 00 00 	mov    %r13,0xe0(%r15)
 101f85f:	49 c7 87 e8 00 00 00 	movq   $0x0,0xe8(%r15)
 101f866:	00 00 00 00 
 101f86a:	49 89 97 f0 00 00 00 	mov    %rdx,0xf0(%r15)
 101f871:	41 c7 87 f8 00 00 00 	movl   $0x2,0xf8(%r15)
 101f878:	02 00 00 00 
 101f87c:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
 101f880:	c4 c1 78 11 87 fc 00 	vmovups %xmm0,0xfc(%r15)
 101f887:	00 00 
 101f889:	c4 c1 78 11 87 08 01 	vmovups %xmm0,0x108(%r15)
 101f890:	00 00 
 101f892:	e9 30 01 00 00       	jmp    101f9c7 <myl_native_dictionary_write+0x547>
 101f897:	4c 89 ff             	mov    %r15,%rdi
 101f89a:	4c 89 e6             	mov    %r12,%rsi
 101f89d:	e8 ee 24 00 00       	call   1021d90 <probe_any>
 101f8a2:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
 101f8a6:	74 98                	je     101f840 <myl_native_dictionary_write+0x3c0>
 101f8a8:	4d 89 af e0 00 00 00 	mov    %r13,0xe0(%r15)
 101f8af:	49 89 87 e8 00 00 00 	mov    %rax,0xe8(%r15)
 101f8b6:	49 c7 87 f0 00 00 00 	movq   $0x0,0xf0(%r15)
 101f8bd:	00 00 00 00 
 101f8c1:	41 c7 87 f8 00 00 00 	movl   $0x1,0xf8(%r15)
 101f8c8:	01 00 00 00 
 101f8cc:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
 101f8d0:	c4 c1 78 11 87 fc 00 	vmovups %xmm0,0xfc(%r15)
 101f8d7:	00 00 
 101f8d9:	c4 c1 78 11 87 08 01 	vmovups %xmm0,0x108(%r15)
 101f8e0:	00 00 
 101f8e2:	49 8b 4f f0          	mov    -0x10(%r15),%rcx
 101f8e6:	49 8b 17             	mov    (%r15),%rdx
 101f8e9:	49 0f af 47 30       	imul   0x30(%r15),%rax
 101f8ee:	48 03 42 20          	add    0x20(%rdx),%rax
 101f8f2:	49 03 47 18          	add    0x18(%r15),%rax
 101f8f6:	48 89 ca             	mov    %rcx,%rdx
 101f8f9:	48 c1 ea 28          	shr    $0x28,%rdx
 101f8fd:	81 e2 ff ff 0f 00    	and    $0xfffff,%edx
 101f903:	45 31 c0             	xor    %r8d,%r8d
 101f906:	48 0f ba e1 3e       	bt     $0x3e,%rcx
 101f90b:	44 0f 42 c2          	cmovb  %edx,%r8d
 101f90f:	4c 8b 6d c0          	mov    -0x40(%rbp),%r13
 101f913:	4c 39 e8             	cmp    %r13,%rax
 101f916:	0f 84 f6 00 00 00    	je     101fa12 <myl_native_dictionary_write+0x592>
 101f91c:	49 8b 77 10          	mov    0x10(%r15),%rsi
 101f920:	83 7e 30 00          	cmpl   $0x0,0x30(%rsi)
 101f924:	75 46                	jne    101f96c <myl_native_dictionary_write+0x4ec>
 101f926:	48 83 3e 08          	cmpq   $0x8,(%rsi)
 101f92a:	75 40                	jne    101f96c <myl_native_dictionary_write+0x4ec>
 101f92c:	4c 89 f7             	mov    %r14,%rdi
 101f92f:	49 89 f7             	mov    %rsi,%r15
 101f932:	48 89 c3             	mov    %rax,%rbx
 101f935:	45 89 c4             	mov    %r8d,%r12d
 101f938:	e8 c3 58 00 00       	call   1025200 <myl_rc_descriptor_repeat>
 101f93d:	4c 89 fe             	mov    %r15,%rsi
 101f940:	45 89 e0             	mov    %r12d,%r8d
 101f943:	48 89 c1             	mov    %rax,%rcx
 101f946:	48 89 d8             	mov    %rbx,%rax
 101f949:	48 85 c9             	test   %rcx,%rcx
 101f94c:	74 1e                	je     101f96c <myl_native_dictionary_write+0x4ec>
 101f94e:	83 79 78 00          	cmpl   $0x0,0x78(%rcx)
 101f952:	75 18                	jne    101f96c <myl_native_dictionary_write+0x4ec>
 101f954:	49 8b 8e 08 16 00 00 	mov    0x1608(%r14),%rcx
 101f95b:	48 83 79 60 00       	cmpq   $0x0,0x60(%rcx)
 101f960:	75 0a                	jne    101f96c <myl_native_dictionary_write+0x4ec>
 101f962:	45 3b 46 70          	cmp    0x70(%r14),%r8d
 101f966:	0f 86 ef 00 00 00    	jbe    101fa5b <myl_native_dictionary_write+0x5db>
 101f96c:	4c 89 f7             	mov    %r14,%rdi
 101f96f:	48 89 c2             	mov    %rax,%rdx
 101f972:	4c 89 e9             	mov    %r13,%rcx
 101f975:	48 83 c4 28          	add    $0x28,%rsp
 101f979:	5b                   	pop    %rbx
 101f97a:	41 5c                	pop    %r12
 101f97c:	41 5d                	pop    %r13
 101f97e:	41 5e                	pop    %r14
 101f980:	41 5f                	pop    %r15
 101f982:	5d                   	pop    %rbp
 101f983:	e9 68 c9 00 00       	jmp    102c2f0 <myl_rc_native_retain_replace>
 101f988:	4c 89 ff             	mov    %r15,%rdi
 101f98b:	4c 89 ee             	mov    %r13,%rsi
 101f98e:	e8 bd 26 00 00       	call   1022050 <probe_word>
 101f993:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
 101f997:	0f 85 0b ff ff ff    	jne    101f8a8 <myl_native_dictionary_write+0x428>
 101f99d:	e9 9e fe ff ff       	jmp    101f840 <myl_native_dictionary_write+0x3c0>
 101f9a2:	4c 89 ff             	mov    %r15,%rdi
 101f9a5:	4c 89 ee             	mov    %r13,%rsi
 101f9a8:	e8 53 27 00 00       	call   1022100 <probe_scalar>
 101f9ad:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
 101f9b1:	0f 85 f1 fe ff ff    	jne    101f8a8 <myl_native_dictionary_write+0x428>
 101f9b7:	e9 84 fe ff ff       	jmp    101f840 <myl_native_dictionary_write+0x3c0>
 101f9bc:	41 c7 87 f8 00 00 00 	movl   $0x0,0xf8(%r15)
 101f9c3:	00 00 00 00 
 101f9c7:	4c 89 f7             	mov    %r14,%rdi
 101f9ca:	4c 89 fe             	mov    %r15,%rsi
 101f9cd:	4c 89 e2             	mov    %r12,%rdx
 101f9d0:	48 8b 4d c0          	mov    -0x40(%rbp),%rcx
 101f9d4:	45 31 c0             	xor    %r8d,%r8d
 101f9d7:	48 83 c4 28          	add    $0x28,%rsp
 101f9db:	5b                   	pop    %rbx
 101f9dc:	41 5c                	pop    %r12
 101f9de:	41 5d                	pop    %r13
 101f9e0:	41 5e                	pop    %r14
 101f9e2:	41 5f                	pop    %r15
 101f9e4:	5d                   	pop    %rbp
 101f9e5:	e9 56 09 00 00       	jmp    1020340 <rc_insert_result>
 101f9ea:	45 8b 2c 24          	mov    (%r12),%r13d
 101f9ee:	e9 09 fe ff ff       	jmp    101f7fc <myl_native_dictionary_write+0x37c>
 101f9f3:	4d 8b 2c 24          	mov    (%r12),%r13
 101f9f7:	e9 00 fe ff ff       	jmp    101f7fc <myl_native_dictionary_write+0x37c>
 101f9fc:	45 0f b7 2c 24       	movzwl (%r12),%r13d
 101fa01:	e9 f6 fd ff ff       	jmp    101f7fc <myl_native_dictionary_write+0x37c>
 101fa06:	4c 89 ef             	mov    %r13,%rdi
 101fa09:	48 8b 75 c0          	mov    -0x40(%rbp),%rsi
 101fa0d:	e8 4e cc 00 00       	call   102c660 <compiler_rt.memmove.memmoveFast>
 101fa12:	b8 01 00 00 00       	mov    $0x1,%eax
 101fa17:	48 83 c4 28          	add    $0x28,%rsp
 101fa1b:	5b                   	pop    %rbx
 101fa1c:	41 5c                	pop    %r12
 101fa1e:	41 5d                	pop    %r13
 101fa20:	41 5e                	pop    %r14
 101fa22:	41 5f                	pop    %r15
 101fa24:	5d                   	pop    %rbp
 101fa25:	c3                   	ret
 101fa26:	41 8b 3c 24          	mov    (%r12),%edi
 101fa2a:	e9 71 fb ff ff       	jmp    101f5a0 <myl_native_dictionary_write+0x120>
 101fa2f:	41 0f b7 3c 24       	movzwl (%r12),%edi
 101fa34:	e9 67 fb ff ff       	jmp    101f5a0 <myl_native_dictionary_write+0x120>
 101fa39:	41 8b 0c 24          	mov    (%r12),%ecx
 101fa3d:	e9 c3 fb ff ff       	jmp    101f605 <myl_native_dictionary_write+0x185>
 101fa42:	41 0f b7 0c 24       	movzwl (%r12),%ecx
 101fa47:	e9 b9 fb ff ff       	jmp    101f605 <myl_native_dictionary_write+0x185>
 101fa4c:	8b 0e                	mov    (%rsi),%ecx
 101fa4e:	e9 d7 fc ff ff       	jmp    101f72a <myl_native_dictionary_write+0x2aa>
 101fa53:	0f b7 0e             	movzwl (%rsi),%ecx
 101fa56:	e9 cf fc ff ff       	jmp    101f72a <myl_native_dictionary_write+0x2aa>
 101fa5b:	49 8b 4d 00          	mov    0x0(%r13),%rcx
 101fa5f:	48 89 08             	mov    %rcx,(%rax)
 101fa62:	eb ae                	jmp    101fa12 <myl_native_dictionary_write+0x592>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
