
/home/epentland/ai/canopy/mylang-worktrees/d9-rc-compiler-astra/.tmp-rc/dict-word/repeat/qbe-rc:     file format elf64-x86-64


Disassembly of section .text:

0000000001024510 <myl_rc_descriptor_find>:
 1024510:	48 85 ff             	test   %rdi,%rdi
 1024513:	0f 84 a5 00 00 00    	je     10245be <myl_rc_descriptor_find+0xae>
 1024519:	48 8b 87 08 16 00 00 	mov    0x1608(%rdi),%rax
 1024520:	48 85 c0             	test   %rax,%rax
 1024523:	0f 94 c1             	sete   %cl
 1024526:	48 85 f6             	test   %rsi,%rsi
 1024529:	0f 94 c2             	sete   %dl
 102452c:	08 ca                	or     %cl,%dl
 102452e:	0f 85 8a 00 00 00    	jne    10245be <myl_rc_descriptor_find+0xae>
 1024534:	55                   	push   %rbp
 1024535:	48 89 e5             	mov    %rsp,%rbp
 1024538:	48 8b 48 40          	mov    0x40(%rax),%rcx
 102453c:	48 85 c9             	test   %rcx,%rcx
 102453f:	0f 84 7c 00 00 00    	je     10245c1 <myl_rc_descriptor_find+0xb1>
 1024545:	48 8b 50 30          	mov    0x30(%rax),%rdx
 1024549:	48 89 f0             	mov    %rsi,%rax
 102454c:	48 c1 e8 03          	shr    $0x3,%rax
 1024550:	48 89 f7             	mov    %rsi,%rdi
 1024553:	48 c1 ef 21          	shr    $0x21,%rdi
 1024557:	48 31 c7             	xor    %rax,%rdi
 102455a:	48 b8 b9 e5 e4 1c 6d 	movabs $0xbf58476d1ce4e5b9,%rax
 1024561:	47 58 bf 
 1024564:	48 0f af c7          	imul   %rdi,%rax
 1024568:	48 89 c7             	mov    %rax,%rdi
 102456b:	48 c1 ef 1b          	shr    $0x1b,%rdi
 102456f:	48 31 c7             	xor    %rax,%rdi
 1024572:	48 83 f7 02          	xor    $0x2,%rdi
 1024576:	48 ff c9             	dec    %rcx
 1024579:	48 21 cf             	and    %rcx,%rdi
 102457c:	48 8d 04 bf          	lea    (%rdi,%rdi,4),%rax
 1024580:	4c 8b 04 c2          	mov    (%rdx,%rax,8),%r8
 1024584:	31 c0                	xor    %eax,%eax
 1024586:	eb 16                	jmp    102459e <myl_rc_descriptor_find+0x8e>
 1024588:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
 102458f:	00 
 1024590:	48 ff c7             	inc    %rdi
 1024593:	48 21 cf             	and    %rcx,%rdi
 1024596:	4c 8d 04 bf          	lea    (%rdi,%rdi,4),%r8
 102459a:	4e 8b 04 c2          	mov    (%rdx,%r8,8),%r8
 102459e:	4d 85 c0             	test   %r8,%r8
 10245a1:	74 19                	je     10245bc <myl_rc_descriptor_find+0xac>
 10245a3:	49 39 f0             	cmp    %rsi,%r8
 10245a6:	75 e8                	jne    1024590 <myl_rc_descriptor_find+0x80>
 10245a8:	4c 8d 04 bf          	lea    (%rdi,%rdi,4),%r8
 10245ac:	42 83 7c c2 20 02    	cmpl   $0x2,0x20(%rdx,%r8,8)
 10245b2:	75 dc                	jne    1024590 <myl_rc_descriptor_find+0x80>
 10245b4:	4a 8d 04 c2          	lea    (%rdx,%r8,8),%rax
 10245b8:	48 8b 40 08          	mov    0x8(%rax),%rax
 10245bc:	5d                   	pop    %rbp
 10245bd:	c3                   	ret
 10245be:	31 c0                	xor    %eax,%eax
 10245c0:	c3                   	ret
 10245c1:	31 c0                	xor    %eax,%eax
 10245c3:	5d                   	pop    %rbp
 10245c4:	c3                   	ret

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
