
/home/epentland/ai/canopy/mylang-worktrees/d9-rc-mut-argument-astra/.tmp-mut-argument/tree-profile/llvm-rc-repeat:     file format elf64-x86-64


Disassembly of section .text:

000000000101ac50 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531>:
 101ac50:	55                   	push   %rbp
 101ac51:	41 57                	push   %r15
 101ac53:	41 56                	push   %r14
 101ac55:	41 55                	push   %r13
 101ac57:	41 54                	push   %r12
 101ac59:	53                   	push   %rbx
 101ac5a:	48 81 ec 18 01 00 00 	sub    $0x118,%rsp
 101ac61:	48 89 fb             	mov    %rdi,%rbx
 101ac64:	48 39 67 40          	cmp    %rsp,0x40(%rdi)
 101ac68:	0f 87 2c 08 00 00    	ja     101b49a <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x84a>
 101ac6e:	49 89 f7             	mov    %rsi,%r15
 101ac71:	48 85 f6             	test   %rsi,%rsi
 101ac74:	0f 84 4e 07 00 00    	je     101b3c8 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x778>
 101ac7a:	44 8b a3 c8 02 00 00 	mov    0x2c8(%rbx),%r12d
 101ac81:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
 101ac85:	c5 fc 11 44 24 10    	vmovups %ymm0,0x10(%rsp)
 101ac8b:	48 c7 44 24 60 e8 9b 	movq   $0x1009be8,0x60(%rsp)
 101ac92:	00 01 
 101ac94:	c7 44 24 78 00 00 00 	movl   $0x0,0x78(%rsp)
 101ac9b:	00 
 101ac9c:	48 8d 44 24 30       	lea    0x30(%rsp),%rax
 101aca1:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
 101aca6:	48 8d 44 24 10       	lea    0x10(%rsp),%rax
 101acab:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
 101acb0:	48 c7 84 24 80 00 00 	movq   $0x1009be8,0x80(%rsp)
 101acb7:	00 e8 9b 00 01 
 101acbc:	c7 84 24 98 00 00 00 	movl   $0x0,0x98(%rsp)
 101acc3:	00 00 00 00 
 101acc7:	48 8d 44 24 48       	lea    0x48(%rsp),%rax
 101accc:	48 89 84 24 88 00 00 	mov    %rax,0x88(%rsp)
 101acd3:	00 
 101acd4:	48 8d 44 24 18       	lea    0x18(%rsp),%rax
 101acd9:	48 89 84 24 90 00 00 	mov    %rax,0x90(%rsp)
 101ace0:	00 
 101ace1:	48 c7 84 24 a0 00 00 	movq   $0x1009be8,0xa0(%rsp)
 101ace8:	00 e8 9b 00 01 
 101aced:	c7 84 24 b8 00 00 00 	movl   $0x0,0xb8(%rsp)
 101acf4:	00 00 00 00 
 101acf8:	48 89 e0             	mov    %rsp,%rax
 101acfb:	48 89 84 24 a8 00 00 	mov    %rax,0xa8(%rsp)
 101ad02:	00 
 101ad03:	48 8d 44 24 20       	lea    0x20(%rsp),%rax
 101ad08:	48 89 84 24 b0 00 00 	mov    %rax,0xb0(%rsp)
 101ad0f:	00 
 101ad10:	48 c7 84 24 c0 00 00 	movq   $0x1009be8,0xc0(%rsp)
 101ad17:	00 e8 9b 00 01 
 101ad1c:	c7 84 24 d8 00 00 00 	movl   $0x0,0xd8(%rsp)
 101ad23:	00 00 00 00 
 101ad27:	48 8d 44 24 58       	lea    0x58(%rsp),%rax
 101ad2c:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
 101ad33:	00 
 101ad34:	4c 8d 6c 24 28       	lea    0x28(%rsp),%r13
 101ad39:	4c 89 ac 24 d0 00 00 	mov    %r13,0xd0(%rsp)
 101ad40:	00 
 101ad41:	48 85 db             	test   %rbx,%rbx
 101ad44:	0f 84 33 07 00 00    	je     101b47d <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x82d>
 101ad4a:	48 8b 83 60 18 00 00 	mov    0x1860(%rbx),%rax
 101ad51:	48 85 c0             	test   %rax,%rax
 101ad54:	0f 84 23 07 00 00    	je     101b47d <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x82d>
 101ad5a:	48 8b 8b 80 3d 00 00 	mov    0x3d80(%rbx),%rcx
 101ad61:	48 8b 40 70          	mov    0x70(%rax),%rax
 101ad65:	48 89 8c 24 f0 00 00 	mov    %rcx,0xf0(%rsp)
 101ad6c:	00 
 101ad6d:	48 8d 4c 24 60       	lea    0x60(%rsp),%rcx
 101ad72:	48 89 8c 24 f8 00 00 	mov    %rcx,0xf8(%rsp)
 101ad79:	00 
 101ad7a:	48 c7 84 24 00 01 00 	movq   $0x4,0x100(%rsp)
 101ad81:	00 04 00 00 00 
 101ad86:	48 89 84 24 08 01 00 	mov    %rax,0x108(%rsp)
 101ad8d:	00 
 101ad8e:	4c 8d b4 24 f0 00 00 	lea    0xf0(%rsp),%r14
 101ad95:	00 
 101ad96:	4c 89 b3 80 3d 00 00 	mov    %r14,0x3d80(%rbx)
 101ad9d:	4c 89 f8             	mov    %r15,%rax
 101ada0:	48 f7 d8             	neg    %rax
 101ada3:	0f 80 f9 06 00 00    	jo     101b4a2 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x852>
 101ada9:	49 ff cf             	dec    %r15
 101adac:	48 89 df             	mov    %rbx,%rdi
 101adaf:	4c 89 fe             	mov    %r15,%rsi
 101adb2:	c5 f8 77             	vzeroupper
 101adb5:	e8 96 fe ff ff       	call   101ac50 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531>
 101adba:	48 89 04 24          	mov    %rax,(%rsp)
 101adbe:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
 101adc3:	48 c7 84 24 a0 00 00 	movq   $0x100a308,0xa0(%rsp)
 101adca:	00 08 a3 00 01 
 101adcf:	c7 84 24 b8 00 00 00 	movl   $0x2,0xb8(%rsp)
 101add6:	02 00 00 00 
 101adda:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
 101addf:	48 89 54 24 38       	mov    %rdx,0x38(%rsp)
 101ade4:	48 c7 44 24 60 08 a3 	movq   $0x100a308,0x60(%rsp)
 101adeb:	00 01 
 101aded:	c7 44 24 78 02 00 00 	movl   $0x2,0x78(%rsp)
 101adf4:	00 
 101adf5:	c7 44 24 20 00 00 00 	movl   $0x0,0x20(%rsp)
 101adfc:	00 
 101adfd:	c7 44 24 10 01 00 00 	movl   $0x1,0x10(%rsp)
 101ae04:	00 
 101ae05:	48 83 bb 60 18 00 00 	cmpq   $0x0,0x1860(%rbx)
 101ae0c:	00 
 101ae0d:	0f 84 77 06 00 00    	je     101b48a <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x83a>
 101ae13:	48 8d ab 58 02 00 00 	lea    0x258(%rbx),%rbp
 101ae1a:	8b 8b c8 02 00 00    	mov    0x2c8(%rbx),%ecx
 101ae20:	be b8 98 00 01       	mov    $0x10098b8,%esi
 101ae25:	ba 01 00 00 00       	mov    $0x1,%edx
 101ae2a:	48 89 ef             	mov    %rbp,%rdi
 101ae2d:	e8 6e f6 00 00       	call   102a4a0 <myl_rc_storage_alloc>
 101ae32:	48 85 c0             	test   %rax,%rax
 101ae35:	0f 84 4f 06 00 00    	je     101b48a <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x83a>
 101ae3b:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
 101ae40:	48 c7 84 24 c0 00 00 	movq   $0x1009928,0xc0(%rsp)
 101ae47:	00 28 99 00 01 
 101ae4c:	48 8d 4c 24 58       	lea    0x58(%rsp),%rcx
 101ae51:	48 89 8c 24 c8 00 00 	mov    %rcx,0xc8(%rsp)
 101ae58:	00 
 101ae59:	4c 89 ac 24 d0 00 00 	mov    %r13,0xd0(%rsp)
 101ae60:	00 
 101ae61:	c7 84 24 d8 00 00 00 	movl   $0x4,0xd8(%rsp)
 101ae68:	04 00 00 00 
 101ae6c:	c7 44 24 28 01 00 00 	movl   $0x1,0x28(%rsp)
 101ae73:	00 
 101ae74:	f6 44 24 78 18       	testb  $0x18,0x78(%rsp)
 101ae79:	75 18                	jne    101ae93 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x243>
 101ae7b:	8b 4c 24 10          	mov    0x10(%rsp),%ecx
 101ae7f:	83 e1 01             	and    $0x1,%ecx
 101ae82:	74 0f                	je     101ae93 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x243>
 101ae84:	c5 f8 10 44 24 30    	vmovups 0x30(%rsp),%xmm0
 101ae8a:	c5 f8 11 00          	vmovups %xmm0,(%rax)
 101ae8e:	e9 aa 00 00 00       	jmp    101af3d <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x2ed>
 101ae93:	48 8b 4c 24 30       	mov    0x30(%rsp),%rcx
 101ae98:	48 85 c9             	test   %rcx,%rcx
 101ae9b:	74 10                	je     101aead <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x25d>
 101ae9d:	48 ba 01 00 00 00 00 	movabs $0x5000000000000001,%rdx
 101aea4:	00 00 50 
 101aea7:	48 85 51 f0          	test   %rdx,-0x10(%rcx)
 101aeab:	75 1a                	jne    101aec7 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x277>
 101aead:	48 8b 4c 24 38       	mov    0x38(%rsp),%rcx
 101aeb2:	48 85 c9             	test   %rcx,%rcx
 101aeb5:	74 4a                	je     101af01 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x2b1>
 101aeb7:	48 ba 01 00 00 00 00 	movabs $0x5000000000000001,%rdx
 101aebe:	00 00 50 
 101aec1:	48 85 51 f0          	test   %rdx,-0x10(%rcx)
 101aec5:	74 3a                	je     101af01 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x2b1>
 101aec7:	48 89 e2             	mov    %rsp,%rdx
 101aeca:	48 8d 4c 24 30       	lea    0x30(%rsp),%rcx
 101aecf:	be 08 a3 00 01       	mov    $0x100a308,%esi
 101aed4:	48 89 ef             	mov    %rbp,%rdi
 101aed7:	45 89 e0             	mov    %r12d,%r8d
 101aeda:	49 89 ed             	mov    %rbp,%r13
 101aedd:	4c 89 f5             	mov    %r14,%rbp
 101aee0:	49 89 c6             	mov    %rax,%r14
 101aee3:	e8 a8 07 01 00       	call   102b690 <myl_rc_native_take>
 101aee8:	89 c1                	mov    %eax,%ecx
 101aeea:	4c 89 f0             	mov    %r14,%rax
 101aeed:	49 89 ee             	mov    %rbp,%r14
 101aef0:	4c 89 ed             	mov    %r13,%rbp
 101aef3:	4c 8d 6c 24 28       	lea    0x28(%rsp),%r13
 101aef8:	85 c9                	test   %ecx,%ecx
 101aefa:	75 19                	jne    101af15 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x2c5>
 101aefc:	e9 9a 03 00 00       	jmp    101b29b <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x64b>
 101af01:	c5 f8 10 44 24 30    	vmovups 0x30(%rsp),%xmm0
 101af07:	c5 f8 29 04 24       	vmovaps %xmm0,(%rsp)
 101af0c:	48 c7 44 24 38 00 00 	movq   $0x0,0x38(%rsp)
 101af13:	00 00 
 101af15:	48 c7 84 24 a0 00 00 	movq   $0x100a308,0xa0(%rsp)
 101af1c:	00 08 a3 00 01 
 101af21:	c7 84 24 b8 00 00 00 	movl   $0x2,0xb8(%rsp)
 101af28:	02 00 00 00 
 101af2c:	c5 f8 28 04 24       	vmovaps (%rsp),%xmm0
 101af31:	c5 f8 11 00          	vmovups %xmm0,(%rax)
 101af35:	c7 44 24 20 00 00 00 	movl   $0x0,0x20(%rsp)
 101af3c:	00 
 101af3d:	48 c7 84 24 c0 00 00 	movq   $0x1009fd8,0xc0(%rsp)
 101af44:	00 d8 9f 00 01 
 101af49:	c7 84 24 d8 00 00 00 	movl   $0x2,0xd8(%rsp)
 101af50:	02 00 00 00 
 101af54:	48 8d 8c 24 10 01 00 	lea    0x110(%rsp),%rcx
 101af5b:	00 
 101af5c:	48 89 8c 24 c8 00 00 	mov    %rcx,0xc8(%rsp)
 101af63:	00 
 101af64:	4c 89 ac 24 d0 00 00 	mov    %r13,0xd0(%rsp)
 101af6b:	00 
 101af6c:	48 89 84 24 10 01 00 	mov    %rax,0x110(%rsp)
 101af73:	00 
 101af74:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
 101af79:	48 c7 44 24 60 d8 9f 	movq   $0x1009fd8,0x60(%rsp)
 101af80:	00 01 
 101af82:	c7 44 24 78 02 00 00 	movl   $0x2,0x78(%rsp)
 101af89:	00 
 101af8a:	c7 44 24 10 01 00 00 	movl   $0x1,0x10(%rsp)
 101af91:	00 
 101af92:	c7 44 24 28 00 00 00 	movl   $0x0,0x28(%rsp)
 101af99:	00 
 101af9a:	48 89 df             	mov    %rbx,%rdi
 101af9d:	4c 89 fe             	mov    %r15,%rsi
 101afa0:	e8 ab fc ff ff       	call   101ac50 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531>
 101afa5:	48 89 04 24          	mov    %rax,(%rsp)
 101afa9:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
 101afae:	48 c7 84 24 a0 00 00 	movq   $0x100a308,0xa0(%rsp)
 101afb5:	00 08 a3 00 01 
 101afba:	c7 84 24 b8 00 00 00 	movl   $0x2,0xb8(%rsp)
 101afc1:	02 00 00 00 
 101afc5:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
 101afca:	48 89 54 24 50       	mov    %rdx,0x50(%rsp)
 101afcf:	48 c7 84 24 80 00 00 	movq   $0x100a308,0x80(%rsp)
 101afd6:	00 08 a3 00 01 
 101afdb:	c7 84 24 98 00 00 00 	movl   $0x2,0x98(%rsp)
 101afe2:	02 00 00 00 
 101afe6:	c7 44 24 20 00 00 00 	movl   $0x0,0x20(%rsp)
 101afed:	00 
 101afee:	c7 44 24 18 01 00 00 	movl   $0x1,0x18(%rsp)
 101aff5:	00 
 101aff6:	48 83 bb 60 18 00 00 	cmpq   $0x0,0x1860(%rbx)
 101affd:	00 
 101affe:	0f 84 8e 04 00 00    	je     101b492 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x842>
 101b004:	8b 8b c8 02 00 00    	mov    0x2c8(%rbx),%ecx
 101b00a:	be b8 98 00 01       	mov    $0x10098b8,%esi
 101b00f:	ba 01 00 00 00       	mov    $0x1,%edx
 101b014:	48 89 ef             	mov    %rbp,%rdi
 101b017:	e8 84 f4 00 00       	call   102a4a0 <myl_rc_storage_alloc>
 101b01c:	48 85 c0             	test   %rax,%rax
 101b01f:	0f 84 6d 04 00 00    	je     101b492 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x842>
 101b025:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
 101b02a:	48 c7 84 24 c0 00 00 	movq   $0x1009928,0xc0(%rsp)
 101b031:	00 28 99 00 01 
 101b036:	48 8d 4c 24 58       	lea    0x58(%rsp),%rcx
 101b03b:	48 89 8c 24 c8 00 00 	mov    %rcx,0xc8(%rsp)
 101b042:	00 
 101b043:	4c 89 ac 24 d0 00 00 	mov    %r13,0xd0(%rsp)
 101b04a:	00 
 101b04b:	c7 84 24 d8 00 00 00 	movl   $0x4,0xd8(%rsp)
 101b052:	04 00 00 00 
 101b056:	c7 44 24 28 01 00 00 	movl   $0x1,0x28(%rsp)
 101b05d:	00 
 101b05e:	f6 84 24 98 00 00 00 	testb  $0x18,0x98(%rsp)
 101b065:	18 
 101b066:	75 18                	jne    101b080 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x430>
 101b068:	8b 4c 24 18          	mov    0x18(%rsp),%ecx
 101b06c:	83 e1 01             	and    $0x1,%ecx
 101b06f:	74 0f                	je     101b080 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x430>
 101b071:	c5 f8 10 44 24 48    	vmovups 0x48(%rsp),%xmm0
 101b077:	c5 f8 11 00          	vmovups %xmm0,(%rax)
 101b07b:	e9 99 00 00 00       	jmp    101b119 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x4c9>
 101b080:	48 8b 4c 24 48       	mov    0x48(%rsp),%rcx
 101b085:	48 85 c9             	test   %rcx,%rcx
 101b088:	74 10                	je     101b09a <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x44a>
 101b08a:	48 ba 01 00 00 00 00 	movabs $0x5000000000000001,%rdx
 101b091:	00 00 50 
 101b094:	48 85 51 f0          	test   %rdx,-0x10(%rcx)
 101b098:	75 1a                	jne    101b0b4 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x464>
 101b09a:	48 8b 4c 24 50       	mov    0x50(%rsp),%rcx
 101b09f:	48 85 c9             	test   %rcx,%rcx
 101b0a2:	74 39                	je     101b0dd <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x48d>
 101b0a4:	48 ba 01 00 00 00 00 	movabs $0x5000000000000001,%rdx
 101b0ab:	00 00 50 
 101b0ae:	48 85 51 f0          	test   %rdx,-0x10(%rcx)
 101b0b2:	74 29                	je     101b0dd <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x48d>
 101b0b4:	48 89 e2             	mov    %rsp,%rdx
 101b0b7:	48 8d 4c 24 48       	lea    0x48(%rsp),%rcx
 101b0bc:	be 08 a3 00 01       	mov    $0x100a308,%esi
 101b0c1:	48 89 ef             	mov    %rbp,%rdi
 101b0c4:	45 89 e0             	mov    %r12d,%r8d
 101b0c7:	49 89 c7             	mov    %rax,%r15
 101b0ca:	e8 c1 05 01 00       	call   102b690 <myl_rc_native_take>
 101b0cf:	89 c1                	mov    %eax,%ecx
 101b0d1:	4c 89 f8             	mov    %r15,%rax
 101b0d4:	85 c9                	test   %ecx,%ecx
 101b0d6:	75 19                	jne    101b0f1 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x4a1>
 101b0d8:	e9 be 01 00 00       	jmp    101b29b <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x64b>
 101b0dd:	c5 f8 10 44 24 48    	vmovups 0x48(%rsp),%xmm0
 101b0e3:	c5 f8 29 04 24       	vmovaps %xmm0,(%rsp)
 101b0e8:	48 c7 44 24 50 00 00 	movq   $0x0,0x50(%rsp)
 101b0ef:	00 00 
 101b0f1:	48 c7 84 24 a0 00 00 	movq   $0x100a308,0xa0(%rsp)
 101b0f8:	00 08 a3 00 01 
 101b0fd:	c7 84 24 b8 00 00 00 	movl   $0x2,0xb8(%rsp)
 101b104:	02 00 00 00 
 101b108:	c5 f8 28 04 24       	vmovaps (%rsp),%xmm0
 101b10d:	c5 f8 11 00          	vmovups %xmm0,(%rax)
 101b111:	c7 44 24 20 00 00 00 	movl   $0x0,0x20(%rsp)
 101b118:	00 
 101b119:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
 101b11e:	48 c7 84 24 80 00 00 	movq   $0x1009fd8,0x80(%rsp)
 101b125:	00 d8 9f 00 01 
 101b12a:	c7 84 24 98 00 00 00 	movl   $0x2,0x98(%rsp)
 101b131:	02 00 00 00 
 101b135:	c7 44 24 18 01 00 00 	movl   $0x1,0x18(%rsp)
 101b13c:	00 
 101b13d:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
 101b141:	c5 f8 29 84 24 e0 00 	vmovaps %xmm0,0xe0(%rsp)
 101b148:	00 00 
 101b14a:	48 c7 84 24 c0 00 00 	movq   $0x100a308,0xc0(%rsp)
 101b151:	00 08 a3 00 01 
 101b156:	c7 84 24 d8 00 00 00 	movl   $0x2,0xd8(%rsp)
 101b15d:	02 00 00 00 
 101b161:	48 8d 8c 24 e0 00 00 	lea    0xe0(%rsp),%rcx
 101b168:	00 
 101b169:	48 89 8c 24 c8 00 00 	mov    %rcx,0xc8(%rsp)
 101b170:	00 
 101b171:	4c 89 ac 24 d0 00 00 	mov    %r13,0xd0(%rsp)
 101b178:	00 
 101b179:	c7 44 24 28 01 00 00 	movl   $0x1,0x28(%rsp)
 101b180:	00 
 101b181:	f6 44 24 78 18       	testb  $0x18,0x78(%rsp)
 101b186:	75 1b                	jne    101b1a3 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x553>
 101b188:	8b 4c 24 10          	mov    0x10(%rsp),%ecx
 101b18c:	83 e1 01             	and    $0x1,%ecx
 101b18f:	74 12                	je     101b1a3 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x553>
 101b191:	48 8b 4c 24 30       	mov    0x30(%rsp),%rcx
 101b196:	48 89 8c 24 e0 00 00 	mov    %rcx,0xe0(%rsp)
 101b19d:	00 
 101b19e:	e9 87 00 00 00       	jmp    101b22a <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x5da>
 101b1a3:	48 89 e2             	mov    %rsp,%rdx
 101b1a6:	48 8d 4c 24 30       	lea    0x30(%rsp),%rcx
 101b1ab:	be d8 9f 00 01       	mov    $0x1009fd8,%esi
 101b1b0:	48 89 ef             	mov    %rbp,%rdi
 101b1b3:	45 89 e0             	mov    %r12d,%r8d
 101b1b6:	e8 45 0a 01 00       	call   102bc00 <myl_rc_native_retain>
 101b1bb:	85 c0                	test   %eax,%eax
 101b1bd:	0f 84 d8 00 00 00    	je     101b29b <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x64b>
 101b1c3:	48 c7 84 24 a0 00 00 	movq   $0x1009fd8,0xa0(%rsp)
 101b1ca:	00 d8 9f 00 01 
 101b1cf:	c7 84 24 b8 00 00 00 	movl   $0x2,0xb8(%rsp)
 101b1d6:	02 00 00 00 
 101b1da:	c7 44 24 20 01 00 00 	movl   $0x1,0x20(%rsp)
 101b1e1:	00 
 101b1e2:	83 7c 24 10 00       	cmpl   $0x0,0x10(%rsp)
 101b1e7:	74 0d                	je     101b1f6 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x5a6>
 101b1e9:	48 8d 74 24 60       	lea    0x60(%rsp),%rsi
 101b1ee:	48 89 df             	mov    %rbx,%rdi
 101b1f1:	e8 2a 27 00 00       	call   101d920 <myl_qbe_rc_slot_drop>
 101b1f6:	48 8b 04 24          	mov    (%rsp),%rax
 101b1fa:	48 89 84 24 e0 00 00 	mov    %rax,0xe0(%rsp)
 101b201:	00 
 101b202:	c7 44 24 20 00 00 00 	movl   $0x0,0x20(%rsp)
 101b209:	00 
 101b20a:	f6 84 24 98 00 00 00 	testb  $0x18,0x98(%rsp)
 101b211:	18 
 101b212:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
 101b217:	0f 85 c1 01 00 00    	jne    101b3de <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x78e>
 101b21d:	8b 4c 24 18          	mov    0x18(%rsp),%ecx
 101b221:	83 e1 01             	and    $0x1,%ecx
 101b224:	0f 84 b4 01 00 00    	je     101b3de <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x78e>
 101b22a:	48 89 84 24 e8 00 00 	mov    %rax,0xe8(%rsp)
 101b231:	00 
 101b232:	c7 44 24 18 00 00 00 	movl   $0x0,0x18(%rsp)
 101b239:	00 
 101b23a:	c5 f8 28 84 24 e0 00 	vmovaps 0xe0(%rsp),%xmm0
 101b241:	00 00 
 101b243:	c5 f8 29 44 24 30    	vmovaps %xmm0,0x30(%rsp)
 101b249:	48 c7 44 24 60 08 a3 	movq   $0x100a308,0x60(%rsp)
 101b250:	00 01 
 101b252:	c7 44 24 78 02 00 00 	movl   $0x2,0x78(%rsp)
 101b259:	00 
 101b25a:	c7 44 24 28 00 00 00 	movl   $0x0,0x28(%rsp)
 101b261:	00 
 101b262:	c5 f8 29 04 24       	vmovaps %xmm0,(%rsp)
 101b267:	c7 44 24 10 00 00 00 	movl   $0x0,0x10(%rsp)
 101b26e:	00 
 101b26f:	4c 39 b3 80 3d 00 00 	cmp    %r14,0x3d80(%rbx)
 101b276:	0f 85 01 02 00 00    	jne    101b47d <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x82d>
 101b27c:	48 8b 83 60 18 00 00 	mov    0x1860(%rbx),%rax
 101b283:	48 85 c0             	test   %rax,%rax
 101b286:	74 47                	je     101b2cf <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x67f>
 101b288:	48 8b 40 70          	mov    0x70(%rax),%rax
 101b28c:	48 3b 84 24 08 01 00 	cmp    0x108(%rsp),%rax
 101b293:	00 
 101b294:	74 49                	je     101b2df <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x68f>
 101b296:	e9 e2 01 00 00       	jmp    101b47d <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x82d>
 101b29b:	48 8b 8b 60 18 00 00 	mov    0x1860(%rbx),%rcx
 101b2a2:	48 85 c9             	test   %rcx,%rcx
 101b2a5:	0f 84 d2 01 00 00    	je     101b47d <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x82d>
 101b2ab:	8b 41 78             	mov    0x78(%rcx),%eax
 101b2ae:	c7 41 78 00 00 00 00 	movl   $0x0,0x78(%rcx)
 101b2b5:	48 85 c0             	test   %rax,%rax
 101b2b8:	74 5b                	je     101b315 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x6c5>
 101b2ba:	83 f8 01             	cmp    $0x1,%eax
 101b2bd:	75 3d                	jne    101b2fc <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x6ac>
 101b2bf:	be 72 74 00 01       	mov    $0x1007472,%esi
 101b2c4:	83 bb c4 02 00 00 00 	cmpl   $0x0,0x2c4(%rbx)
 101b2cb:	75 40                	jne    101b30d <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x6bd>
 101b2cd:	eb 36                	jmp    101b305 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x6b5>
 101b2cf:	31 c0                	xor    %eax,%eax
 101b2d1:	48 3b 84 24 08 01 00 	cmp    0x108(%rsp),%rax
 101b2d8:	00 
 101b2d9:	0f 85 9e 01 00 00    	jne    101b47d <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x82d>
 101b2df:	48 8b 84 24 f0 00 00 	mov    0xf0(%rsp),%rax
 101b2e6:	00 
 101b2e7:	48 89 83 80 3d 00 00 	mov    %rax,0x3d80(%rbx)
 101b2ee:	48 8b 04 24          	mov    (%rsp),%rax
 101b2f2:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
 101b2f7:	e9 d0 00 00 00       	jmp    101b3cc <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x77c>
 101b2fc:	83 f8 04             	cmp    $0x4,%eax
 101b2ff:	0f 83 80 01 00 00    	jae    101b485 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x835>
 101b305:	48 8b 34 c5 50 d6 00 	mov    0x100d650(,%rax,8),%rsi
 101b30c:	01 
 101b30d:	48 89 df             	mov    %rbx,%rdi
 101b310:	e8 9b 31 00 00       	call   101e4b0 <fail>
 101b315:	4c 39 b3 80 3d 00 00 	cmp    %r14,0x3d80(%rbx)
 101b31c:	0f 85 5b 01 00 00    	jne    101b47d <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x82d>
 101b322:	4d 89 f4             	mov    %r14,%r12
 101b325:	48 8b b4 24 08 01 00 	mov    0x108(%rsp),%rsi
 101b32c:	00 
 101b32d:	48 89 ef             	mov    %rbp,%rdi
 101b330:	e8 cb ce 00 00       	call   1028200 <myl_rc_scope_unwind>
 101b335:	4c 8b b4 24 00 01 00 	mov    0x100(%rsp),%r14
 101b33c:	00 
 101b33d:	4d 85 f6             	test   %r14,%r14
 101b340:	74 3b                	je     101b37d <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x72d>
 101b342:	4d 89 f7             	mov    %r14,%r15
 101b345:	49 c1 e7 05          	shl    $0x5,%r15
 101b349:	49 83 c7 e0          	add    $0xffffffffffffffe0,%r15
 101b34d:	eb 15                	jmp    101b364 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x714>
 101b34f:	90                   	nop
 101b350:	4c 01 fe             	add    %r15,%rsi
 101b353:	48 89 df             	mov    %rbx,%rdi
 101b356:	e8 c5 25 00 00       	call   101d920 <myl_qbe_rc_slot_drop>
 101b35b:	49 83 c7 e0          	add    $0xffffffffffffffe0,%r15
 101b35f:	49 ff ce             	dec    %r14
 101b362:	74 19                	je     101b37d <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x72d>
 101b364:	48 8b b4 24 f8 00 00 	mov    0xf8(%rsp),%rsi
 101b36b:	00 
 101b36c:	4a 8b 44 3e 10       	mov    0x10(%rsi,%r15,1),%rax
 101b371:	48 85 c0             	test   %rax,%rax
 101b374:	74 da                	je     101b350 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x700>
 101b376:	83 38 00             	cmpl   $0x0,(%rax)
 101b379:	75 d5                	jne    101b350 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x700>
 101b37b:	eb de                	jmp    101b35b <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x70b>
 101b37d:	4c 39 a3 80 3d 00 00 	cmp    %r12,0x3d80(%rbx)
 101b384:	0f 85 f3 00 00 00    	jne    101b47d <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x82d>
 101b38a:	48 8b 83 60 18 00 00 	mov    0x1860(%rbx),%rax
 101b391:	48 85 c0             	test   %rax,%rax
 101b394:	74 13                	je     101b3a9 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x759>
 101b396:	48 8b 40 70          	mov    0x70(%rax),%rax
 101b39a:	48 3b 84 24 08 01 00 	cmp    0x108(%rsp),%rax
 101b3a1:	00 
 101b3a2:	74 15                	je     101b3b9 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x769>
 101b3a4:	e9 d4 00 00 00       	jmp    101b47d <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x82d>
 101b3a9:	31 c0                	xor    %eax,%eax
 101b3ab:	48 3b 84 24 08 01 00 	cmp    0x108(%rsp),%rax
 101b3b2:	00 
 101b3b3:	0f 85 c4 00 00 00    	jne    101b47d <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x82d>
 101b3b9:	48 8b 84 24 f0 00 00 	mov    0xf0(%rsp),%rax
 101b3c0:	00 
 101b3c1:	48 89 83 80 3d 00 00 	mov    %rax,0x3d80(%rbx)
 101b3c8:	31 c0                	xor    %eax,%eax
 101b3ca:	31 d2                	xor    %edx,%edx
 101b3cc:	48 81 c4 18 01 00 00 	add    $0x118,%rsp
 101b3d3:	5b                   	pop    %rbx
 101b3d4:	41 5c                	pop    %r12
 101b3d6:	41 5d                	pop    %r13
 101b3d8:	41 5e                	pop    %r14
 101b3da:	41 5f                	pop    %r15
 101b3dc:	5d                   	pop    %rbp
 101b3dd:	c3                   	ret
 101b3de:	48 85 c0             	test   %rax,%rax
 101b3e1:	74 32                	je     101b415 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x7c5>
 101b3e3:	48 b9 01 00 00 00 00 	movabs $0x5000000000000001,%rcx
 101b3ea:	00 00 50 
 101b3ed:	48 85 48 f0          	test   %rcx,-0x10(%rax)
 101b3f1:	74 22                	je     101b415 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x7c5>
 101b3f3:	48 89 e2             	mov    %rsp,%rdx
 101b3f6:	48 8d 4c 24 48       	lea    0x48(%rsp),%rcx
 101b3fb:	be d8 9f 00 01       	mov    $0x1009fd8,%esi
 101b400:	48 89 ef             	mov    %rbp,%rdi
 101b403:	45 89 e0             	mov    %r12d,%r8d
 101b406:	e8 85 02 01 00       	call   102b690 <myl_rc_native_take>
 101b40b:	85 c0                	test   %eax,%eax
 101b40d:	74 43                	je     101b452 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x802>
 101b40f:	48 8b 04 24          	mov    (%rsp),%rax
 101b413:	eb 09                	jmp    101b41e <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x7ce>
 101b415:	48 c7 44 24 48 00 00 	movq   $0x0,0x48(%rsp)
 101b41c:	00 00 
 101b41e:	c7 44 24 18 00 00 00 	movl   $0x0,0x18(%rsp)
 101b425:	00 
 101b426:	48 c7 84 24 a0 00 00 	movq   $0x1009fd8,0xa0(%rsp)
 101b42d:	00 d8 9f 00 01 
 101b432:	c7 84 24 b8 00 00 00 	movl   $0x2,0xb8(%rsp)
 101b439:	02 00 00 00 
 101b43d:	48 89 84 24 e8 00 00 	mov    %rax,0xe8(%rsp)
 101b444:	00 
 101b445:	c7 44 24 20 00 00 00 	movl   $0x0,0x20(%rsp)
 101b44c:	00 
 101b44d:	e9 e8 fd ff ff       	jmp    101b23a <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x5ea>
 101b452:	48 8b 83 60 18 00 00 	mov    0x1860(%rbx),%rax
 101b459:	48 85 c0             	test   %rax,%rax
 101b45c:	74 1f                	je     101b47d <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x82d>
 101b45e:	8b 70 78             	mov    0x78(%rax),%esi
 101b461:	c7 40 78 00 00 00 00 	movl   $0x0,0x78(%rax)
 101b468:	48 89 df             	mov    %rbx,%rdi
 101b46b:	e8 20 24 00 00       	call   101d890 <myl_qbe_rc_status>
 101b470:	4c 39 b3 80 3d 00 00 	cmp    %r14,0x3d80(%rbx)
 101b477:	0f 84 a5 fe ff ff    	je     101b322 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x6d2>
 101b47d:	c5 f8 77             	vzeroupper
 101b480:	e8 1c 89 00 00       	call   1023da1 <myl_rc_invariant_failed>
 101b485:	e8 e6 3f 01 00       	call   102f470 <abort@plt>
 101b48a:	48 89 df             	mov    %rbx,%rdi
 101b48d:	e8 ce 36 00 00       	call   101eb60 <myl_qbe_fail_allocation>
 101b492:	48 89 df             	mov    %rbx,%rdi
 101b495:	e8 c6 36 00 00       	call   101eb60 <myl_qbe_fail_allocation>
 101b49a:	48 89 df             	mov    %rbx,%rdi
 101b49d:	e8 be 37 00 00       	call   101ec60 <myl_qbe_fail_frame>
 101b4a2:	48 ba 00 00 00 00 00 	movabs $0x8000000000000000,%rdx
 101b4a9:	00 00 80 
 101b4ac:	be 01 00 00 00       	mov    $0x1,%esi
 101b4b1:	b9 01 00 00 00       	mov    $0x1,%ecx
 101b4b6:	48 89 df             	mov    %rbx,%rdi
 101b4b9:	c5 f8 77             	vzeroupper
 101b4bc:	e8 2f 37 00 00       	call   101ebf0 <myl_qbe_fail_overflow_op>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
