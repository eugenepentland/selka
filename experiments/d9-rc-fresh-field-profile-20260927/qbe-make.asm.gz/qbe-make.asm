
/home/epentland/ai/canopy/mylang-worktrees/d9-rc-mut-argument-astra/.tmp-mut-argument/tree-profile/qbe-rc-repeat:     file format elf64-x86-64


Disassembly of section .text:

0000000001012ac0 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531>:
 1012ac0:	f3 0f 1e fa          	endbr64
 1012ac4:	55                   	push   %rbp
 1012ac5:	48 89 e5             	mov    %rsp,%rbp
 1012ac8:	48 81 ec 78 01 00 00 	sub    $0x178,%rsp
 1012acf:	53                   	push   %rbx
 1012ad0:	41 54                	push   %r12
 1012ad2:	41 55                	push   %r13
 1012ad4:	41 56                	push   %r14
 1012ad6:	41 57                	push   %r15
 1012ad8:	49 89 f5             	mov    %rsi,%r13
 1012adb:	48 8b 47 40          	mov    0x40(%rdi),%rax
 1012adf:	48 8d 4d e8          	lea    -0x18(%rbp),%rcx
 1012ae3:	48 39 c1             	cmp    %rax,%rcx
 1012ae6:	0f 82 42 0d 00 00    	jb     101382e <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xd6e>
 1012aec:	49 83 fd 00          	cmp    $0x0,%r13
 1012af0:	0f 84 09 0d 00 00    	je     10137ff <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xd3f>
 1012af6:	48 89 fb             	mov    %rdi,%rbx
 1012af9:	e8 d2 6f 00 00       	call   1019ad0 <myl_qbe_heap>
 1012afe:	48 89 df             	mov    %rbx,%rdi
 1012b01:	48 89 c3             	mov    %rax,%rbx
 1012b04:	49 89 fc             	mov    %rdi,%r12
 1012b07:	e8 04 93 00 00       	call   101be10 <myl_qbe_region_mark>
 1012b0c:	4c 89 ea             	mov    %r13,%rdx
 1012b0f:	4c 89 e7             	mov    %r12,%rdi
 1012b12:	49 89 c7             	mov    %rax,%r15
 1012b15:	4c 89 7d f8          	mov    %r15,-0x8(%rbp)
 1012b19:	49 89 d5             	mov    %rdx,%r13
 1012b1c:	ba 20 00 00 00       	mov    $0x20,%edx
 1012b21:	be 00 00 00 00       	mov    $0x0,%esi
 1012b26:	49 89 fc             	mov    %rdi,%r12
 1012b29:	48 8d bd 60 ff ff ff 	lea    -0xa0(%rbp),%rdi
 1012b30:	e8 6b 74 01 00       	call   1029fa0 <compiler_rt.fastMemset>
 1012b35:	4c 89 ea             	mov    %r13,%rdx
 1012b38:	4c 89 e7             	mov    %r12,%rdi
 1012b3b:	48 8d 05 46 19 ff ff 	lea    -0xe6ba(%rip),%rax        # 1004488 <myl_t_385cfdbc00ec32031699460779c15099b2bba3cad0e440fffb08e10df0acb9e1>
 1012b42:	48 89 85 e0 fe ff ff 	mov    %rax,-0x120(%rbp)
 1012b49:	c7 85 f8 fe ff ff 00 	movl   $0x0,-0x108(%rbp)
 1012b50:	00 00 00 
 1012b53:	48 8d 45 80          	lea    -0x80(%rbp),%rax
 1012b57:	48 89 85 e8 fe ff ff 	mov    %rax,-0x118(%rbp)
 1012b5e:	48 8d 85 60 ff ff ff 	lea    -0xa0(%rbp),%rax
 1012b65:	48 89 85 f0 fe ff ff 	mov    %rax,-0x110(%rbp)
 1012b6c:	48 8d 05 15 19 ff ff 	lea    -0xe6eb(%rip),%rax        # 1004488 <myl_t_385cfdbc00ec32031699460779c15099b2bba3cad0e440fffb08e10df0acb9e1>
 1012b73:	48 89 85 00 ff ff ff 	mov    %rax,-0x100(%rbp)
 1012b7a:	c7 85 18 ff ff ff 00 	movl   $0x0,-0xe8(%rbp)
 1012b81:	00 00 00 
 1012b84:	48 8d 45 90          	lea    -0x70(%rbp),%rax
 1012b88:	48 89 85 08 ff ff ff 	mov    %rax,-0xf8(%rbp)
 1012b8f:	48 8d 85 60 ff ff ff 	lea    -0xa0(%rbp),%rax
 1012b96:	48 83 c0 08          	add    $0x8,%rax
 1012b9a:	48 89 85 10 ff ff ff 	mov    %rax,-0xf0(%rbp)
 1012ba1:	48 8d 05 e0 18 ff ff 	lea    -0xe720(%rip),%rax        # 1004488 <myl_t_385cfdbc00ec32031699460779c15099b2bba3cad0e440fffb08e10df0acb9e1>
 1012ba8:	48 89 85 20 ff ff ff 	mov    %rax,-0xe0(%rbp)
 1012baf:	c7 85 38 ff ff ff 00 	movl   $0x0,-0xc8(%rbp)
 1012bb6:	00 00 00 
 1012bb9:	48 8d 45 a0          	lea    -0x60(%rbp),%rax
 1012bbd:	48 89 85 28 ff ff ff 	mov    %rax,-0xd8(%rbp)
 1012bc4:	48 8d 85 60 ff ff ff 	lea    -0xa0(%rbp),%rax
 1012bcb:	48 83 c0 10          	add    $0x10,%rax
 1012bcf:	48 89 85 30 ff ff ff 	mov    %rax,-0xd0(%rbp)
 1012bd6:	48 8d 05 ab 18 ff ff 	lea    -0xe755(%rip),%rax        # 1004488 <myl_t_385cfdbc00ec32031699460779c15099b2bba3cad0e440fffb08e10df0acb9e1>
 1012bdd:	48 89 85 40 ff ff ff 	mov    %rax,-0xc0(%rbp)
 1012be4:	c7 85 58 ff ff ff 00 	movl   $0x0,-0xa8(%rbp)
 1012beb:	00 00 00 
 1012bee:	48 8d 45 b0          	lea    -0x50(%rbp),%rax
 1012bf2:	48 89 85 48 ff ff ff 	mov    %rax,-0xb8(%rbp)
 1012bf9:	48 8d 85 60 ff ff ff 	lea    -0xa0(%rbp),%rax
 1012c00:	49 89 c4             	mov    %rax,%r12
 1012c03:	49 83 c4 18          	add    $0x18,%r12
 1012c07:	4c 89 a5 50 ff ff ff 	mov    %r12,-0xb0(%rbp)
 1012c0e:	b9 04 00 00 00       	mov    $0x4,%ecx
 1012c13:	49 89 d5             	mov    %rdx,%r13
 1012c16:	48 8d 95 e0 fe ff ff 	lea    -0x120(%rbp),%rdx
 1012c1d:	48 8d b5 c0 fe ff ff 	lea    -0x140(%rbp),%rsi
 1012c24:	49 89 fe             	mov    %rdi,%r14
 1012c27:	e8 b4 65 00 00       	call   10191e0 <myl_qbe_rc_frame_enter>
 1012c2c:	4c 89 f7             	mov    %r14,%rdi
 1012c2f:	4c 89 6d b8          	mov    %r13,-0x48(%rbp)
 1012c33:	48 c7 45 c0 01 00 00 	movq   $0x1,-0x40(%rbp)
 1012c3a:	00 
 1012c3b:	48 b8 01 00 00 00 00 	movabs $0x8000000000000001,%rax
 1012c42:	00 00 80 
 1012c45:	49 39 c5             	cmp    %rax,%r13
 1012c48:	0f 8c 97 0b 00 00    	jl     10137e5 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xd25>
 1012c4e:	4c 89 ee             	mov    %r13,%rsi
 1012c51:	48 83 ee 01          	sub    $0x1,%rsi
 1012c55:	48 89 75 f0          	mov    %rsi,-0x10(%rbp)
 1012c59:	48 89 75 b8          	mov    %rsi,-0x48(%rbp)
 1012c5d:	49 89 fe             	mov    %rdi,%r14
 1012c60:	e8 5b fe ff ff       	call   1012ac0 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531>
 1012c65:	4c 89 f7             	mov    %r14,%rdi
 1012c68:	48 89 c1             	mov    %rax,%rcx
 1012c6b:	48 89 d0             	mov    %rdx,%rax
 1012c6e:	4c 89 ea             	mov    %r13,%rdx
 1012c71:	48 89 8d 90 fe ff ff 	mov    %rcx,-0x170(%rbp)
 1012c78:	48 89 85 98 fe ff ff 	mov    %rax,-0x168(%rbp)
 1012c7f:	48 8d 85 90 fe ff ff 	lea    -0x170(%rbp),%rax
 1012c86:	48 89 45 b8          	mov    %rax,-0x48(%rbp)
 1012c8a:	48 8b 85 90 fe ff ff 	mov    -0x170(%rbp),%rax
 1012c91:	48 89 45 a0          	mov    %rax,-0x60(%rbp)
 1012c95:	48 8b 85 98 fe ff ff 	mov    -0x168(%rbp),%rax
 1012c9c:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
 1012ca0:	48 8d 05 09 bb 01 00 	lea    0x1bb09(%rip),%rax        # 102e7b0 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 1012ca7:	48 89 85 20 ff ff ff 	mov    %rax,-0xe0(%rbp)
 1012cae:	c7 85 38 ff ff ff 02 	movl   $0x2,-0xc8(%rbp)
 1012cb5:	00 00 00 
 1012cb8:	c7 85 70 ff ff ff 01 	movl   $0x1,-0x90(%rbp)
 1012cbf:	00 00 00 
 1012cc2:	48 8b 45 a0          	mov    -0x60(%rbp),%rax
 1012cc6:	48 89 45 80          	mov    %rax,-0x80(%rbp)
 1012cca:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
 1012cce:	48 89 45 88          	mov    %rax,-0x78(%rbp)
 1012cd2:	48 8d 05 d7 ba 01 00 	lea    0x1bad7(%rip),%rax        # 102e7b0 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 1012cd9:	48 89 85 e0 fe ff ff 	mov    %rax,-0x120(%rbp)
 1012ce0:	c7 85 f8 fe ff ff 02 	movl   $0x2,-0x108(%rbp)
 1012ce7:	00 00 00 
 1012cea:	c7 85 f8 fe ff ff 02 	movl   $0x2,-0x108(%rbp)
 1012cf1:	00 00 00 
 1012cf4:	c7 85 70 ff ff ff 00 	movl   $0x0,-0x90(%rbp)
 1012cfb:	00 00 00 
 1012cfe:	c7 85 60 ff ff ff 01 	movl   $0x1,-0xa0(%rbp)
 1012d05:	00 00 00 
 1012d08:	48 8d 45 80          	lea    -0x80(%rbp),%rax
 1012d0c:	48 89 45 b8          	mov    %rax,-0x48(%rbp)
 1012d10:	49 89 d6             	mov    %rdx,%r14
 1012d13:	ba 01 00 00 00       	mov    $0x1,%edx
 1012d18:	48 8d 35 81 b7 01 00 	lea    0x1b781(%rip),%rsi        # 102e4a0 <myl_t_1e414bd82e4b50b54939760a2d591f88da97e2f1c8252dbd7dcbc73438e46afb_body>
 1012d1f:	49 89 fd             	mov    %rdi,%r13
 1012d22:	48 89 df             	mov    %rbx,%rdi
 1012d25:	e8 86 b4 00 00       	call   101e1b0 <myl_native_heap_alloc>
 1012d2a:	4d 89 f8             	mov    %r15,%r8
 1012d2d:	4c 89 f2             	mov    %r14,%rdx
 1012d30:	4c 89 ef             	mov    %r13,%rdi
 1012d33:	49 89 c5             	mov    %rax,%r13
 1012d36:	41 83 fd 00          	cmp    $0x0,%r13d
 1012d3a:	75 0a                	jne    1012d46 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x286>
 1012d3c:	48 89 fb             	mov    %rdi,%rbx
 1012d3f:	e8 0c 6b 00 00       	call   1019850 <myl_qbe_fail_allocation>
 1012d44:	0f 0b                	ud2
 1012d46:	48 87 fb             	xchg   %rdi,%rbx
 1012d49:	4c 89 6d b0          	mov    %r13,-0x50(%rbp)
 1012d4d:	48 8d 05 bc b7 01 00 	lea    0x1b7bc(%rip),%rax        # 102e510 <myl_t_1e414bd82e4b50b54939760a2d591f88da97e2f1c8252dbd7dcbc73438e46afb>
 1012d54:	48 89 85 40 ff ff ff 	mov    %rax,-0xc0(%rbp)
 1012d5b:	c7 85 58 ff ff ff 02 	movl   $0x2,-0xa8(%rbp)
 1012d62:	00 00 00 
 1012d65:	48 8d 45 b0          	lea    -0x50(%rbp),%rax
 1012d69:	48 89 85 48 ff ff ff 	mov    %rax,-0xb8(%rbp)
 1012d70:	4c 89 a5 50 ff ff ff 	mov    %r12,-0xb0(%rbp)
 1012d77:	c7 85 58 ff ff ff 04 	movl   $0x4,-0xa8(%rbp)
 1012d7e:	00 00 00 
 1012d81:	c7 85 78 ff ff ff 01 	movl   $0x1,-0x88(%rbp)
 1012d88:	00 00 00 
 1012d8b:	48 8b 45 b8          	mov    -0x48(%rbp),%rax
 1012d8f:	8b 8d 60 ff ff ff    	mov    -0xa0(%rbp),%ecx
 1012d95:	8b b5 f8 fe ff ff    	mov    -0x108(%rbp),%esi
 1012d9b:	83 e6 18             	and    $0x18,%esi
 1012d9e:	83 fe 00             	cmp    $0x0,%esi
 1012da1:	40 0f 94 c6          	sete   %sil
 1012da5:	40 0f b6 f6          	movzbl %sil,%esi
 1012da9:	85 ce                	test   %ecx,%esi
 1012dab:	0f 85 0a 01 00 00    	jne    1012ebb <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x3fb>
 1012db1:	48 8b 08             	mov    (%rax),%rcx
 1012db4:	48 83 f9 00          	cmp    $0x0,%rcx
 1012db8:	74 1a                	je     1012dd4 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x314>
 1012dba:	48 83 e9 10          	sub    $0x10,%rcx
 1012dbe:	48 8b 09             	mov    (%rcx),%rcx
 1012dc1:	48 be 01 00 00 00 00 	movabs $0x5000000000000001,%rsi
 1012dc8:	00 00 50 
 1012dcb:	48 21 f1             	and    %rsi,%rcx
 1012dce:	48 83 f9 00          	cmp    $0x0,%rcx
 1012dd2:	75 5a                	jne    1012e2e <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x36e>
 1012dd4:	48 8b 48 08          	mov    0x8(%rax),%rcx
 1012dd8:	48 83 f9 00          	cmp    $0x0,%rcx
 1012ddc:	74 1a                	je     1012df8 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x338>
 1012dde:	48 83 e9 10          	sub    $0x10,%rcx
 1012de2:	48 8b 09             	mov    (%rcx),%rcx
 1012de5:	48 be 01 00 00 00 00 	movabs $0x5000000000000001,%rsi
 1012dec:	00 00 50 
 1012def:	48 21 f1             	and    %rsi,%rcx
 1012df2:	48 83 f9 00          	cmp    $0x0,%rcx
 1012df6:	75 36                	jne    1012e2e <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x36e>
 1012df8:	48 8b 08             	mov    (%rax),%rcx
 1012dfb:	48 89 4d a0          	mov    %rcx,-0x60(%rbp)
 1012dff:	48 8b 48 08          	mov    0x8(%rax),%rcx
 1012e03:	48 89 4d a8          	mov    %rcx,-0x58(%rbp)
 1012e07:	49 89 d7             	mov    %rdx,%r15
 1012e0a:	ba 10 00 00 00       	mov    $0x10,%edx
 1012e0f:	be 00 00 00 00       	mov    $0x0,%esi
 1012e14:	49 89 fe             	mov    %rdi,%r14
 1012e17:	48 89 c7             	mov    %rax,%rdi
 1012e1a:	e8 81 71 01 00       	call   1029fa0 <compiler_rt.fastMemset>
 1012e1f:	4c 89 fa             	mov    %r15,%rdx
 1012e22:	4c 89 f7             	mov    %r14,%rdi
 1012e25:	4c 8b 45 f8          	mov    -0x8(%rbp),%r8
 1012e29:	4d 89 c7             	mov    %r8,%r15
 1012e2c:	eb 45                	jmp    1012e73 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x3b3>
 1012e2e:	4d 89 c7             	mov    %r8,%r15
 1012e31:	48 89 c1             	mov    %rax,%rcx
 1012e34:	49 89 d7             	mov    %rdx,%r15
 1012e37:	48 8d 55 a0          	lea    -0x60(%rbp),%rdx
 1012e3b:	48 8d 35 6e b9 01 00 	lea    0x1b96e(%rip),%rsi        # 102e7b0 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 1012e42:	49 89 fe             	mov    %rdi,%r14
 1012e45:	e8 66 6c 01 00       	call   1029ab0 <myl_rc_native_take>
 1012e4a:	4c 89 fa             	mov    %r15,%rdx
 1012e4d:	4c 89 f7             	mov    %r14,%rdi
 1012e50:	4c 8b 7d f8          	mov    -0x8(%rbp),%r15
 1012e54:	83 f8 00             	cmp    $0x0,%eax
 1012e57:	75 1a                	jne    1012e73 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x3b3>
 1012e59:	e8 c2 eb 00 00       	call   1021a20 <myl_rc_take_failure>
 1012e5e:	48 89 df             	mov    %rbx,%rdi
 1012e61:	89 c6                	mov    %eax,%esi
 1012e63:	48 89 fb             	mov    %rdi,%rbx
 1012e66:	e8 85 62 00 00       	call   10190f0 <myl_qbe_rc_status>
 1012e6b:	48 89 df             	mov    %rbx,%rdi
 1012e6e:	e9 57 08 00 00       	jmp    10136ca <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xc0a>
 1012e73:	c7 85 60 ff ff ff 00 	movl   $0x0,-0xa0(%rbp)
 1012e7a:	00 00 00 
 1012e7d:	48 8d 05 2c b9 01 00 	lea    0x1b92c(%rip),%rax        # 102e7b0 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 1012e84:	48 89 85 20 ff ff ff 	mov    %rax,-0xe0(%rbp)
 1012e8b:	c7 85 38 ff ff ff 02 	movl   $0x2,-0xc8(%rbp)
 1012e92:	00 00 00 
 1012e95:	c7 85 70 ff ff ff 01 	movl   $0x1,-0x90(%rbp)
 1012e9c:	00 00 00 
 1012e9f:	48 8b 45 a0          	mov    -0x60(%rbp),%rax
 1012ea3:	49 89 45 00          	mov    %rax,0x0(%r13)
 1012ea7:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
 1012eab:	49 89 45 08          	mov    %rax,0x8(%r13)
 1012eaf:	c7 85 70 ff ff ff 00 	movl   $0x0,-0x90(%rbp)
 1012eb6:	00 00 00 
 1012eb9:	eb 1c                	jmp    1012ed7 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x417>
 1012ebb:	4d 89 c7             	mov    %r8,%r15
 1012ebe:	48 8b 08             	mov    (%rax),%rcx
 1012ec1:	49 89 4d 00          	mov    %rcx,0x0(%r13)
 1012ec5:	48 8b 40 08          	mov    0x8(%rax),%rax
 1012ec9:	49 89 45 08          	mov    %rax,0x8(%r13)
 1012ecd:	c7 85 60 ff ff ff 00 	movl   $0x0,-0xa0(%rbp)
 1012ed4:	00 00 00 
 1012ed7:	4c 89 6d b8          	mov    %r13,-0x48(%rbp)
 1012edb:	48 8b 45 b8          	mov    -0x48(%rbp),%rax
 1012edf:	48 89 45 80          	mov    %rax,-0x80(%rbp)
 1012ee3:	48 8d 05 26 b6 01 00 	lea    0x1b626(%rip),%rax        # 102e510 <myl_t_1e414bd82e4b50b54939760a2d591f88da97e2f1c8252dbd7dcbc73438e46afb>
 1012eea:	48 89 85 e0 fe ff ff 	mov    %rax,-0x120(%rbp)
 1012ef1:	c7 85 f8 fe ff ff 02 	movl   $0x2,-0x108(%rbp)
 1012ef8:	00 00 00 
 1012efb:	c7 85 60 ff ff ff 01 	movl   $0x1,-0xa0(%rbp)
 1012f02:	00 00 00 
 1012f05:	4c 89 6d b8          	mov    %r13,-0x48(%rbp)
 1012f09:	c7 85 78 ff ff ff 00 	movl   $0x0,-0x88(%rbp)
 1012f10:	00 00 00 
 1012f13:	49 89 d6             	mov    %rdx,%r14
 1012f16:	ba 08 00 00 00       	mov    $0x8,%edx
 1012f1b:	be 00 00 00 00       	mov    $0x0,%esi
 1012f20:	49 89 fd             	mov    %rdi,%r13
 1012f23:	48 8d 7d c8          	lea    -0x38(%rbp),%rdi
 1012f27:	e8 74 70 01 00       	call   1029fa0 <compiler_rt.fastMemset>
 1012f2c:	4c 89 f2             	mov    %r14,%rdx
 1012f2f:	4c 89 ef             	mov    %r13,%rdi
 1012f32:	48 8b 75 f0          	mov    -0x10(%rbp),%rsi
 1012f36:	48 8d 05 03 b8 01 00 	lea    0x1b803(%rip),%rax        # 102e740 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 1012f3d:	48 89 85 40 ff ff ff 	mov    %rax,-0xc0(%rbp)
 1012f44:	c7 85 58 ff ff ff 02 	movl   $0x2,-0xa8(%rbp)
 1012f4b:	00 00 00 
 1012f4e:	48 8d 45 c8          	lea    -0x38(%rbp),%rax
 1012f52:	48 89 85 48 ff ff ff 	mov    %rax,-0xb8(%rbp)
 1012f59:	4c 89 a5 50 ff ff ff 	mov    %r12,-0xb0(%rbp)
 1012f60:	c7 85 78 ff ff ff 01 	movl   $0x1,-0x88(%rbp)
 1012f67:	00 00 00 
 1012f6a:	8b 85 60 ff ff ff    	mov    -0xa0(%rbp),%eax
 1012f70:	8b 8d f8 fe ff ff    	mov    -0x108(%rbp),%ecx
 1012f76:	83 e1 18             	and    $0x18,%ecx
 1012f79:	83 f9 00             	cmp    $0x0,%ecx
 1012f7c:	0f 94 c1             	sete   %cl
 1012f7f:	0f b6 c9             	movzbl %cl,%ecx
 1012f82:	85 c1                	test   %eax,%ecx
 1012f84:	0f 85 e6 00 00 00    	jne    1013070 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x5b0>
 1012f8a:	48 8b 45 b8          	mov    -0x48(%rbp),%rax
 1012f8e:	48 83 f8 00          	cmp    $0x0,%rax
 1012f92:	74 1a                	je     1012fae <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x4ee>
 1012f94:	48 83 e8 10          	sub    $0x10,%rax
 1012f98:	48 8b 00             	mov    (%rax),%rax
 1012f9b:	48 b9 01 00 00 00 00 	movabs $0x5000000000000001,%rcx
 1012fa2:	00 00 50 
 1012fa5:	48 21 c8             	and    %rcx,%rax
 1012fa8:	48 83 f8 00          	cmp    $0x0,%rax
 1012fac:	75 36                	jne    1012fe4 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x524>
 1012fae:	48 8b 45 b8          	mov    -0x48(%rbp),%rax
 1012fb2:	48 89 45 a0          	mov    %rax,-0x60(%rbp)
 1012fb6:	49 89 d6             	mov    %rdx,%r14
 1012fb9:	ba 08 00 00 00       	mov    $0x8,%edx
 1012fbe:	be 00 00 00 00       	mov    $0x0,%esi
 1012fc3:	49 89 fd             	mov    %rdi,%r13
 1012fc6:	48 8d 7d b8          	lea    -0x48(%rbp),%rdi
 1012fca:	e8 d1 6f 01 00       	call   1029fa0 <compiler_rt.fastMemset>
 1012fcf:	4d 89 f8             	mov    %r15,%r8
 1012fd2:	4c 89 f2             	mov    %r14,%rdx
 1012fd5:	4c 89 ef             	mov    %r13,%rdi
 1012fd8:	48 8b 75 f0          	mov    -0x10(%rbp),%rsi
 1012fdc:	4d 89 c7             	mov    %r8,%r15
 1012fdf:	48 87 df             	xchg   %rbx,%rdi
 1012fe2:	eb 4c                	jmp    1013030 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x570>
 1012fe4:	4d 89 f8             	mov    %r15,%r8
 1012fe7:	4d 89 c7             	mov    %r8,%r15
 1012fea:	48 8d 4d b8          	lea    -0x48(%rbp),%rcx
 1012fee:	49 89 d6             	mov    %rdx,%r14
 1012ff1:	48 8d 55 a0          	lea    -0x60(%rbp),%rdx
 1012ff5:	48 8d 35 14 b5 01 00 	lea    0x1b514(%rip),%rsi        # 102e510 <myl_t_1e414bd82e4b50b54939760a2d591f88da97e2f1c8252dbd7dcbc73438e46afb>
 1012ffc:	49 89 fd             	mov    %rdi,%r13
 1012fff:	e8 ac 6a 01 00       	call   1029ab0 <myl_rc_native_take>
 1013004:	4c 89 f2             	mov    %r14,%rdx
 1013007:	4c 89 ef             	mov    %r13,%rdi
 101300a:	48 8b 75 f0          	mov    -0x10(%rbp),%rsi
 101300e:	83 f8 00             	cmp    $0x0,%eax
 1013011:	75 1a                	jne    101302d <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x56d>
 1013013:	e8 08 ea 00 00       	call   1021a20 <myl_rc_take_failure>
 1013018:	48 89 df             	mov    %rbx,%rdi
 101301b:	89 c6                	mov    %eax,%esi
 101301d:	48 89 fb             	mov    %rdi,%rbx
 1013020:	e8 cb 60 00 00       	call   10190f0 <myl_qbe_rc_status>
 1013025:	48 89 df             	mov    %rbx,%rdi
 1013028:	e9 9d 06 00 00       	jmp    10136ca <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xc0a>
 101302d:	48 87 df             	xchg   %rbx,%rdi
 1013030:	c7 85 60 ff ff ff 00 	movl   $0x0,-0xa0(%rbp)
 1013037:	00 00 00 
 101303a:	48 8d 05 cf b4 01 00 	lea    0x1b4cf(%rip),%rax        # 102e510 <myl_t_1e414bd82e4b50b54939760a2d591f88da97e2f1c8252dbd7dcbc73438e46afb>
 1013041:	48 89 85 20 ff ff ff 	mov    %rax,-0xe0(%rbp)
 1013048:	c7 85 38 ff ff ff 02 	movl   $0x2,-0xc8(%rbp)
 101304f:	00 00 00 
 1013052:	c7 85 70 ff ff ff 01 	movl   $0x1,-0x90(%rbp)
 1013059:	00 00 00 
 101305c:	48 8b 45 a0          	mov    -0x60(%rbp),%rax
 1013060:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
 1013064:	c7 85 70 ff ff ff 00 	movl   $0x0,-0x90(%rbp)
 101306b:	00 00 00 
 101306e:	eb 15                	jmp    1013085 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x5c5>
 1013070:	48 87 df             	xchg   %rbx,%rdi
 1013073:	48 8b 45 b8          	mov    -0x48(%rbp),%rax
 1013077:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
 101307b:	c7 85 60 ff ff ff 00 	movl   $0x0,-0xa0(%rbp)
 1013082:	00 00 00 
 1013085:	48 8d 45 c8          	lea    -0x38(%rbp),%rax
 1013089:	48 89 45 b8          	mov    %rax,-0x48(%rbp)
 101308d:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
 1013091:	48 89 45 80          	mov    %rax,-0x80(%rbp)
 1013095:	48 8d 05 a4 b6 01 00 	lea    0x1b6a4(%rip),%rax        # 102e740 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 101309c:	48 89 85 e0 fe ff ff 	mov    %rax,-0x120(%rbp)
 10130a3:	c7 85 f8 fe ff ff 02 	movl   $0x2,-0x108(%rbp)
 10130aa:	00 00 00 
 10130ad:	c7 85 60 ff ff ff 01 	movl   $0x1,-0xa0(%rbp)
 10130b4:	00 00 00 
 10130b7:	48 8d 45 80          	lea    -0x80(%rbp),%rax
 10130bb:	48 89 45 b8          	mov    %rax,-0x48(%rbp)
 10130bf:	c7 85 78 ff ff ff 00 	movl   $0x0,-0x88(%rbp)
 10130c6:	00 00 00 
 10130c9:	48 89 55 c0          	mov    %rdx,-0x40(%rbp)
 10130cd:	48 89 75 c0          	mov    %rsi,-0x40(%rbp)
 10130d1:	49 89 fd             	mov    %rdi,%r13
 10130d4:	e8 e7 f9 ff ff       	call   1012ac0 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531>
 10130d9:	4c 89 ef             	mov    %r13,%rdi
 10130dc:	48 89 c1             	mov    %rax,%rcx
 10130df:	48 89 d0             	mov    %rdx,%rax
 10130e2:	48 89 8d a0 fe ff ff 	mov    %rcx,-0x160(%rbp)
 10130e9:	48 89 85 a8 fe ff ff 	mov    %rax,-0x158(%rbp)
 10130f0:	48 8d 85 a0 fe ff ff 	lea    -0x160(%rbp),%rax
 10130f7:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
 10130fb:	48 8b 85 a0 fe ff ff 	mov    -0x160(%rbp),%rax
 1013102:	48 89 45 a0          	mov    %rax,-0x60(%rbp)
 1013106:	48 8b 85 a8 fe ff ff 	mov    -0x158(%rbp),%rax
 101310d:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
 1013111:	48 8d 05 98 b6 01 00 	lea    0x1b698(%rip),%rax        # 102e7b0 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 1013118:	48 89 85 20 ff ff ff 	mov    %rax,-0xe0(%rbp)
 101311f:	c7 85 38 ff ff ff 02 	movl   $0x2,-0xc8(%rbp)
 1013126:	00 00 00 
 1013129:	c7 85 70 ff ff ff 01 	movl   $0x1,-0x90(%rbp)
 1013130:	00 00 00 
 1013133:	48 8b 45 a0          	mov    -0x60(%rbp),%rax
 1013137:	48 89 45 90          	mov    %rax,-0x70(%rbp)
 101313b:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
 101313f:	48 89 45 98          	mov    %rax,-0x68(%rbp)
 1013143:	48 8d 05 66 b6 01 00 	lea    0x1b666(%rip),%rax        # 102e7b0 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 101314a:	48 89 85 00 ff ff ff 	mov    %rax,-0x100(%rbp)
 1013151:	c7 85 18 ff ff ff 02 	movl   $0x2,-0xe8(%rbp)
 1013158:	00 00 00 
 101315b:	c7 85 18 ff ff ff 02 	movl   $0x2,-0xe8(%rbp)
 1013162:	00 00 00 
 1013165:	c7 85 70 ff ff ff 00 	movl   $0x0,-0x90(%rbp)
 101316c:	00 00 00 
 101316f:	c7 85 68 ff ff ff 01 	movl   $0x1,-0x98(%rbp)
 1013176:	00 00 00 
 1013179:	48 8d 45 90          	lea    -0x70(%rbp),%rax
 101317d:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
 1013181:	ba 01 00 00 00       	mov    $0x1,%edx
 1013186:	48 8d 35 13 b3 01 00 	lea    0x1b313(%rip),%rsi        # 102e4a0 <myl_t_1e414bd82e4b50b54939760a2d591f88da97e2f1c8252dbd7dcbc73438e46afb_body>
 101318d:	49 89 fd             	mov    %rdi,%r13
 1013190:	48 89 df             	mov    %rbx,%rdi
 1013193:	e8 18 b0 00 00       	call   101e1b0 <myl_native_heap_alloc>
 1013198:	4c 89 ef             	mov    %r13,%rdi
 101319b:	49 89 c5             	mov    %rax,%r13
 101319e:	41 83 fd 00          	cmp    $0x0,%r13d
 10131a2:	75 0a                	jne    10131ae <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x6ee>
 10131a4:	48 89 fb             	mov    %rdi,%rbx
 10131a7:	e8 a4 66 00 00       	call   1019850 <myl_qbe_fail_allocation>
 10131ac:	0f 0b                	ud2
 10131ae:	48 87 fb             	xchg   %rdi,%rbx
 10131b1:	4c 89 6d b0          	mov    %r13,-0x50(%rbp)
 10131b5:	48 8d 05 54 b3 01 00 	lea    0x1b354(%rip),%rax        # 102e510 <myl_t_1e414bd82e4b50b54939760a2d591f88da97e2f1c8252dbd7dcbc73438e46afb>
 10131bc:	48 89 85 40 ff ff ff 	mov    %rax,-0xc0(%rbp)
 10131c3:	c7 85 58 ff ff ff 02 	movl   $0x2,-0xa8(%rbp)
 10131ca:	00 00 00 
 10131cd:	48 8d 45 b0          	lea    -0x50(%rbp),%rax
 10131d1:	48 89 85 48 ff ff ff 	mov    %rax,-0xb8(%rbp)
 10131d8:	4c 89 a5 50 ff ff ff 	mov    %r12,-0xb0(%rbp)
 10131df:	c7 85 58 ff ff ff 04 	movl   $0x4,-0xa8(%rbp)
 10131e6:	00 00 00 
 10131e9:	c7 85 78 ff ff ff 01 	movl   $0x1,-0x88(%rbp)
 10131f0:	00 00 00 
 10131f3:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
 10131f7:	8b 8d 68 ff ff ff    	mov    -0x98(%rbp),%ecx
 10131fd:	8b 95 18 ff ff ff    	mov    -0xe8(%rbp),%edx
 1013203:	83 e2 18             	and    $0x18,%edx
 1013206:	83 fa 00             	cmp    $0x0,%edx
 1013209:	0f 94 c2             	sete   %dl
 101320c:	0f b6 d2             	movzbl %dl,%edx
 101320f:	85 ca                	test   %ecx,%edx
 1013211:	0f 85 fc 00 00 00    	jne    1013313 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x853>
 1013217:	48 8b 08             	mov    (%rax),%rcx
 101321a:	48 83 f9 00          	cmp    $0x0,%rcx
 101321e:	74 1a                	je     101323a <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x77a>
 1013220:	48 83 e9 10          	sub    $0x10,%rcx
 1013224:	48 8b 09             	mov    (%rcx),%rcx
 1013227:	48 ba 01 00 00 00 00 	movabs $0x5000000000000001,%rdx
 101322e:	00 00 50 
 1013231:	48 21 d1             	and    %rdx,%rcx
 1013234:	48 83 f9 00          	cmp    $0x0,%rcx
 1013238:	75 53                	jne    101328d <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x7cd>
 101323a:	48 8b 48 08          	mov    0x8(%rax),%rcx
 101323e:	48 83 f9 00          	cmp    $0x0,%rcx
 1013242:	74 1a                	je     101325e <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x79e>
 1013244:	48 83 e9 10          	sub    $0x10,%rcx
 1013248:	48 8b 09             	mov    (%rcx),%rcx
 101324b:	48 ba 01 00 00 00 00 	movabs $0x5000000000000001,%rdx
 1013252:	00 00 50 
 1013255:	48 21 d1             	and    %rdx,%rcx
 1013258:	48 83 f9 00          	cmp    $0x0,%rcx
 101325c:	75 2f                	jne    101328d <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x7cd>
 101325e:	48 8b 08             	mov    (%rax),%rcx
 1013261:	48 89 4d a0          	mov    %rcx,-0x60(%rbp)
 1013265:	48 8b 48 08          	mov    0x8(%rax),%rcx
 1013269:	48 89 4d a8          	mov    %rcx,-0x58(%rbp)
 101326d:	ba 10 00 00 00       	mov    $0x10,%edx
 1013272:	be 00 00 00 00       	mov    $0x0,%esi
 1013277:	49 89 fe             	mov    %rdi,%r14
 101327a:	48 89 c7             	mov    %rax,%rdi
 101327d:	e8 1e 6d 01 00       	call   1029fa0 <compiler_rt.fastMemset>
 1013282:	4d 89 f8             	mov    %r15,%r8
 1013285:	4c 89 f7             	mov    %r14,%rdi
 1013288:	4d 89 c6             	mov    %r8,%r14
 101328b:	eb 3e                	jmp    10132cb <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x80b>
 101328d:	4d 89 f8             	mov    %r15,%r8
 1013290:	4d 89 c6             	mov    %r8,%r14
 1013293:	48 89 c1             	mov    %rax,%rcx
 1013296:	48 8d 55 a0          	lea    -0x60(%rbp),%rdx
 101329a:	48 8d 35 0f b5 01 00 	lea    0x1b50f(%rip),%rsi        # 102e7b0 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 10132a1:	49 89 ff             	mov    %rdi,%r15
 10132a4:	e8 07 68 01 00       	call   1029ab0 <myl_rc_native_take>
 10132a9:	4c 89 ff             	mov    %r15,%rdi
 10132ac:	83 f8 00             	cmp    $0x0,%eax
 10132af:	75 1a                	jne    10132cb <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x80b>
 10132b1:	e8 6a e7 00 00       	call   1021a20 <myl_rc_take_failure>
 10132b6:	48 89 df             	mov    %rbx,%rdi
 10132b9:	89 c6                	mov    %eax,%esi
 10132bb:	48 89 fb             	mov    %rdi,%rbx
 10132be:	e8 2d 5e 00 00       	call   10190f0 <myl_qbe_rc_status>
 10132c3:	48 89 df             	mov    %rbx,%rdi
 10132c6:	e9 ff 03 00 00       	jmp    10136ca <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xc0a>
 10132cb:	c7 85 68 ff ff ff 00 	movl   $0x0,-0x98(%rbp)
 10132d2:	00 00 00 
 10132d5:	48 8d 05 d4 b4 01 00 	lea    0x1b4d4(%rip),%rax        # 102e7b0 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 10132dc:	48 89 85 20 ff ff ff 	mov    %rax,-0xe0(%rbp)
 10132e3:	c7 85 38 ff ff ff 02 	movl   $0x2,-0xc8(%rbp)
 10132ea:	00 00 00 
 10132ed:	c7 85 70 ff ff ff 01 	movl   $0x1,-0x90(%rbp)
 10132f4:	00 00 00 
 10132f7:	48 8b 45 a0          	mov    -0x60(%rbp),%rax
 10132fb:	49 89 45 00          	mov    %rax,0x0(%r13)
 10132ff:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
 1013303:	49 89 45 08          	mov    %rax,0x8(%r13)
 1013307:	c7 85 70 ff ff ff 00 	movl   $0x0,-0x90(%rbp)
 101330e:	00 00 00 
 1013311:	eb 1c                	jmp    101332f <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x86f>
 1013313:	4d 89 fe             	mov    %r15,%r14
 1013316:	48 8b 08             	mov    (%rax),%rcx
 1013319:	49 89 4d 00          	mov    %rcx,0x0(%r13)
 101331d:	48 8b 40 08          	mov    0x8(%rax),%rax
 1013321:	49 89 45 08          	mov    %rax,0x8(%r13)
 1013325:	c7 85 68 ff ff ff 00 	movl   $0x0,-0x98(%rbp)
 101332c:	00 00 00 
 101332f:	4c 89 6d c0          	mov    %r13,-0x40(%rbp)
 1013333:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
 1013337:	48 89 45 90          	mov    %rax,-0x70(%rbp)
 101333b:	48 8d 05 ce b1 01 00 	lea    0x1b1ce(%rip),%rax        # 102e510 <myl_t_1e414bd82e4b50b54939760a2d591f88da97e2f1c8252dbd7dcbc73438e46afb>
 1013342:	48 89 85 00 ff ff ff 	mov    %rax,-0x100(%rbp)
 1013349:	c7 85 18 ff ff ff 02 	movl   $0x2,-0xe8(%rbp)
 1013350:	00 00 00 
 1013353:	c7 85 68 ff ff ff 01 	movl   $0x1,-0x98(%rbp)
 101335a:	00 00 00 
 101335d:	4c 89 6d c0          	mov    %r13,-0x40(%rbp)
 1013361:	c7 85 78 ff ff ff 00 	movl   $0x0,-0x88(%rbp)
 1013368:	00 00 00 
 101336b:	ba 08 00 00 00       	mov    $0x8,%edx
 1013370:	be 00 00 00 00       	mov    $0x0,%esi
 1013375:	49 89 fd             	mov    %rdi,%r13
 1013378:	48 8d 7d d0          	lea    -0x30(%rbp),%rdi
 101337c:	e8 1f 6c 01 00       	call   1029fa0 <compiler_rt.fastMemset>
 1013381:	4c 89 ef             	mov    %r13,%rdi
 1013384:	48 8d 05 b5 b3 01 00 	lea    0x1b3b5(%rip),%rax        # 102e740 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 101338b:	48 89 85 40 ff ff ff 	mov    %rax,-0xc0(%rbp)
 1013392:	c7 85 58 ff ff ff 02 	movl   $0x2,-0xa8(%rbp)
 1013399:	00 00 00 
 101339c:	48 8d 45 d0          	lea    -0x30(%rbp),%rax
 10133a0:	48 89 85 48 ff ff ff 	mov    %rax,-0xb8(%rbp)
 10133a7:	4c 89 a5 50 ff ff ff 	mov    %r12,-0xb0(%rbp)
 10133ae:	c7 85 78 ff ff ff 01 	movl   $0x1,-0x88(%rbp)
 10133b5:	00 00 00 
 10133b8:	8b 85 68 ff ff ff    	mov    -0x98(%rbp),%eax
 10133be:	8b 8d 18 ff ff ff    	mov    -0xe8(%rbp),%ecx
 10133c4:	83 e1 18             	and    $0x18,%ecx
 10133c7:	83 f9 00             	cmp    $0x0,%ecx
 10133ca:	0f 94 c1             	sete   %cl
 10133cd:	0f b6 c9             	movzbl %cl,%ecx
 10133d0:	85 c1                	test   %eax,%ecx
 10133d2:	0f 85 cc 00 00 00    	jne    10134a4 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x9e4>
 10133d8:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
 10133dc:	48 83 f8 00          	cmp    $0x0,%rax
 10133e0:	74 1a                	je     10133fc <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x93c>
 10133e2:	48 83 e8 10          	sub    $0x10,%rax
 10133e6:	48 8b 00             	mov    (%rax),%rax
 10133e9:	48 b9 01 00 00 00 00 	movabs $0x5000000000000001,%rcx
 10133f0:	00 00 50 
 10133f3:	48 21 c8             	and    %rcx,%rax
 10133f6:	48 83 f8 00          	cmp    $0x0,%rax
 10133fa:	75 29                	jne    1013425 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x965>
 10133fc:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
 1013400:	48 89 45 a0          	mov    %rax,-0x60(%rbp)
 1013404:	ba 08 00 00 00       	mov    $0x8,%edx
 1013409:	be 00 00 00 00       	mov    $0x0,%esi
 101340e:	49 89 fd             	mov    %rdi,%r13
 1013411:	48 8d 7d c0          	lea    -0x40(%rbp),%rdi
 1013415:	e8 86 6b 01 00       	call   1029fa0 <compiler_rt.fastMemset>
 101341a:	4d 89 f0             	mov    %r14,%r8
 101341d:	4c 89 ef             	mov    %r13,%rdi
 1013420:	4d 89 c6             	mov    %r8,%r14
 1013423:	eb 3f                	jmp    1013464 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x9a4>
 1013425:	4d 89 f0             	mov    %r14,%r8
 1013428:	4d 89 c6             	mov    %r8,%r14
 101342b:	48 8d 4d c0          	lea    -0x40(%rbp),%rcx
 101342f:	48 8d 55 a0          	lea    -0x60(%rbp),%rdx
 1013433:	48 8d 35 d6 b0 01 00 	lea    0x1b0d6(%rip),%rsi        # 102e510 <myl_t_1e414bd82e4b50b54939760a2d591f88da97e2f1c8252dbd7dcbc73438e46afb>
 101343a:	49 89 fd             	mov    %rdi,%r13
 101343d:	e8 6e 66 01 00       	call   1029ab0 <myl_rc_native_take>
 1013442:	4c 89 ef             	mov    %r13,%rdi
 1013445:	83 f8 00             	cmp    $0x0,%eax
 1013448:	75 1a                	jne    1013464 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x9a4>
 101344a:	e8 d1 e5 00 00       	call   1021a20 <myl_rc_take_failure>
 101344f:	48 89 df             	mov    %rbx,%rdi
 1013452:	89 c6                	mov    %eax,%esi
 1013454:	48 89 fb             	mov    %rdi,%rbx
 1013457:	e8 94 5c 00 00       	call   10190f0 <myl_qbe_rc_status>
 101345c:	48 89 df             	mov    %rbx,%rdi
 101345f:	e9 66 02 00 00       	jmp    10136ca <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xc0a>
 1013464:	c7 85 68 ff ff ff 00 	movl   $0x0,-0x98(%rbp)
 101346b:	00 00 00 
 101346e:	48 8d 05 9b b0 01 00 	lea    0x1b09b(%rip),%rax        # 102e510 <myl_t_1e414bd82e4b50b54939760a2d591f88da97e2f1c8252dbd7dcbc73438e46afb>
 1013475:	48 89 85 20 ff ff ff 	mov    %rax,-0xe0(%rbp)
 101347c:	c7 85 38 ff ff ff 02 	movl   $0x2,-0xc8(%rbp)
 1013483:	00 00 00 
 1013486:	c7 85 70 ff ff ff 01 	movl   $0x1,-0x90(%rbp)
 101348d:	00 00 00 
 1013490:	48 8b 45 a0          	mov    -0x60(%rbp),%rax
 1013494:	48 89 45 d0          	mov    %rax,-0x30(%rbp)
 1013498:	c7 85 70 ff ff ff 00 	movl   $0x0,-0x90(%rbp)
 101349f:	00 00 00 
 10134a2:	eb 12                	jmp    10134b6 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x9f6>
 10134a4:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
 10134a8:	48 89 45 d0          	mov    %rax,-0x30(%rbp)
 10134ac:	c7 85 68 ff ff ff 00 	movl   $0x0,-0x98(%rbp)
 10134b3:	00 00 00 
 10134b6:	48 8d 45 d0          	lea    -0x30(%rbp),%rax
 10134ba:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
 10134be:	48 8b 45 d0          	mov    -0x30(%rbp),%rax
 10134c2:	48 89 45 90          	mov    %rax,-0x70(%rbp)
 10134c6:	48 8d 05 73 b2 01 00 	lea    0x1b273(%rip),%rax        # 102e740 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 10134cd:	48 89 85 00 ff ff ff 	mov    %rax,-0x100(%rbp)
 10134d4:	c7 85 18 ff ff ff 02 	movl   $0x2,-0xe8(%rbp)
 10134db:	00 00 00 
 10134de:	c7 85 68 ff ff ff 01 	movl   $0x1,-0x98(%rbp)
 10134e5:	00 00 00 
 10134e8:	48 8d 45 90          	lea    -0x70(%rbp),%rax
 10134ec:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
 10134f0:	c7 85 78 ff ff ff 00 	movl   $0x0,-0x88(%rbp)
 10134f7:	00 00 00 
 10134fa:	ba 10 00 00 00       	mov    $0x10,%edx
 10134ff:	be 00 00 00 00       	mov    $0x0,%esi
 1013504:	49 89 fd             	mov    %rdi,%r13
 1013507:	48 8d 7d d8          	lea    -0x28(%rbp),%rdi
 101350b:	e8 90 6a 01 00       	call   1029fa0 <compiler_rt.fastMemset>
 1013510:	4d 89 f0             	mov    %r14,%r8
 1013513:	4c 89 ef             	mov    %r13,%rdi
 1013516:	48 8d 05 93 b2 01 00 	lea    0x1b293(%rip),%rax        # 102e7b0 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 101351d:	48 89 85 40 ff ff ff 	mov    %rax,-0xc0(%rbp)
 1013524:	c7 85 58 ff ff ff 02 	movl   $0x2,-0xa8(%rbp)
 101352b:	00 00 00 
 101352e:	48 8d 45 d8          	lea    -0x28(%rbp),%rax
 1013532:	48 89 85 48 ff ff ff 	mov    %rax,-0xb8(%rbp)
 1013539:	4c 89 a5 50 ff ff ff 	mov    %r12,-0xb0(%rbp)
 1013540:	c7 85 78 ff ff ff 01 	movl   $0x1,-0x88(%rbp)
 1013547:	00 00 00 
 101354a:	48 8b 45 b8          	mov    -0x48(%rbp),%rax
 101354e:	8b 8d 60 ff ff ff    	mov    -0xa0(%rbp),%ecx
 1013554:	8b 95 f8 fe ff ff    	mov    -0x108(%rbp),%edx
 101355a:	83 e2 18             	and    $0x18,%edx
 101355d:	83 fa 00             	cmp    $0x0,%edx
 1013560:	0f 94 c2             	sete   %dl
 1013563:	0f b6 d2             	movzbl %dl,%edx
 1013566:	85 ca                	test   %ecx,%edx
 1013568:	0f 85 99 00 00 00    	jne    1013607 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xb47>
 101356e:	4d 89 c5             	mov    %r8,%r13
 1013571:	48 89 c1             	mov    %rax,%rcx
 1013574:	48 8d 55 a0          	lea    -0x60(%rbp),%rdx
 1013578:	48 8d 35 c1 b1 01 00 	lea    0x1b1c1(%rip),%rsi        # 102e740 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 101357f:	49 89 fc             	mov    %rdi,%r12
 1013582:	e8 69 68 01 00       	call   1029df0 <myl_rc_native_retain>
 1013587:	4c 89 e7             	mov    %r12,%rdi
 101358a:	83 f8 00             	cmp    $0x0,%eax
 101358d:	75 1a                	jne    10135a9 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xae9>
 101358f:	e8 8c e4 00 00       	call   1021a20 <myl_rc_take_failure>
 1013594:	48 89 df             	mov    %rbx,%rdi
 1013597:	89 c6                	mov    %eax,%esi
 1013599:	48 89 fb             	mov    %rdi,%rbx
 101359c:	e8 4f 5b 00 00       	call   10190f0 <myl_qbe_rc_status>
 10135a1:	48 89 df             	mov    %rbx,%rdi
 10135a4:	e9 21 01 00 00       	jmp    10136ca <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xc0a>
 10135a9:	48 87 df             	xchg   %rbx,%rdi
 10135ac:	48 8d 05 8d b1 01 00 	lea    0x1b18d(%rip),%rax        # 102e740 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 10135b3:	48 89 85 20 ff ff ff 	mov    %rax,-0xe0(%rbp)
 10135ba:	c7 85 38 ff ff ff 02 	movl   $0x2,-0xc8(%rbp)
 10135c1:	00 00 00 
 10135c4:	c7 85 70 ff ff ff 01 	movl   $0x1,-0x90(%rbp)
 10135cb:	00 00 00 
 10135ce:	8b 85 60 ff ff ff    	mov    -0xa0(%rbp),%eax
 10135d4:	83 f8 00             	cmp    $0x0,%eax
 10135d7:	75 05                	jne    10135de <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xb1e>
 10135d9:	4d 89 e8             	mov    %r13,%r8
 10135dc:	eb 15                	jmp    10135f3 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xb33>
 10135de:	48 8d b5 e0 fe ff ff 	lea    -0x120(%rbp),%rsi
 10135e5:	49 89 fc             	mov    %rdi,%r12
 10135e8:	e8 d3 5c 00 00       	call   10192c0 <myl_qbe_rc_slot_drop>
 10135ed:	4d 89 e8             	mov    %r13,%r8
 10135f0:	4c 89 e7             	mov    %r12,%rdi
 10135f3:	48 8b 45 a0          	mov    -0x60(%rbp),%rax
 10135f7:	48 89 45 d8          	mov    %rax,-0x28(%rbp)
 10135fb:	c7 85 70 ff ff ff 00 	movl   $0x0,-0x90(%rbp)
 1013602:	00 00 00 
 1013605:	eb 14                	jmp    101361b <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xb5b>
 1013607:	48 87 df             	xchg   %rbx,%rdi
 101360a:	48 8b 00             	mov    (%rax),%rax
 101360d:	48 89 45 d8          	mov    %rax,-0x28(%rbp)
 1013611:	c7 85 60 ff ff ff 00 	movl   $0x0,-0xa0(%rbp)
 1013618:	00 00 00 
 101361b:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
 101361f:	48 8d 4d d8          	lea    -0x28(%rbp),%rcx
 1013623:	49 89 cc             	mov    %rcx,%r12
 1013626:	49 83 c4 08          	add    $0x8,%r12
 101362a:	8b 8d 68 ff ff ff    	mov    -0x98(%rbp),%ecx
 1013630:	8b 95 18 ff ff ff    	mov    -0xe8(%rbp),%edx
 1013636:	83 e2 18             	and    $0x18,%edx
 1013639:	83 fa 00             	cmp    $0x0,%edx
 101363c:	0f 94 c2             	sete   %dl
 101363f:	0f b6 d2             	movzbl %dl,%edx
 1013642:	85 ca                	test   %ecx,%edx
 1013644:	0f 85 0c 01 00 00    	jne    1013756 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xc96>
 101364a:	48 8b 08             	mov    (%rax),%rcx
 101364d:	48 83 f9 00          	cmp    $0x0,%rcx
 1013651:	74 1a                	je     101366d <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xbad>
 1013653:	48 83 e9 10          	sub    $0x10,%rcx
 1013657:	48 8b 09             	mov    (%rcx),%rcx
 101365a:	48 ba 01 00 00 00 00 	movabs $0x5000000000000001,%rdx
 1013661:	00 00 50 
 1013664:	48 21 d1             	and    %rdx,%rcx
 1013667:	48 83 f9 00          	cmp    $0x0,%rcx
 101366b:	75 27                	jne    1013694 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xbd4>
 101366d:	48 8b 08             	mov    (%rax),%rcx
 1013670:	48 89 4d a0          	mov    %rcx,-0x60(%rbp)
 1013674:	ba 08 00 00 00       	mov    $0x8,%edx
 1013679:	be 00 00 00 00       	mov    $0x0,%esi
 101367e:	48 89 fb             	mov    %rdi,%rbx
 1013681:	48 89 c7             	mov    %rax,%rdi
 1013684:	e8 17 69 01 00       	call   1029fa0 <compiler_rt.fastMemset>
 1013689:	48 89 df             	mov    %rbx,%rdi
 101368c:	4c 89 e3             	mov    %r12,%rbx
 101368f:	e9 83 00 00 00       	jmp    1013717 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xc57>
 1013694:	48 87 fb             	xchg   %rdi,%rbx
 1013697:	48 89 c1             	mov    %rax,%rcx
 101369a:	48 8d 55 a0          	lea    -0x60(%rbp),%rdx
 101369e:	48 8d 35 9b b0 01 00 	lea    0x1b09b(%rip),%rsi        # 102e740 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 10136a5:	49 89 fd             	mov    %rdi,%r13
 10136a8:	e8 03 64 01 00       	call   1029ab0 <myl_rc_native_take>
 10136ad:	4c 89 ef             	mov    %r13,%rdi
 10136b0:	83 f8 00             	cmp    $0x0,%eax
 10136b3:	75 5c                	jne    1013711 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xc51>
 10136b5:	e8 66 e3 00 00       	call   1021a20 <myl_rc_take_failure>
 10136ba:	48 89 df             	mov    %rbx,%rdi
 10136bd:	89 c6                	mov    %eax,%esi
 10136bf:	48 89 fb             	mov    %rdi,%rbx
 10136c2:	e8 29 5a 00 00       	call   10190f0 <myl_qbe_rc_status>
 10136c7:	48 89 df             	mov    %rbx,%rdi
 10136ca:	48 8d b5 c0 fe ff ff 	lea    -0x140(%rbp),%rsi
 10136d1:	48 89 fb             	mov    %rdi,%rbx
 10136d4:	e8 17 5d 00 00       	call   10193f0 <myl_qbe_rc_frame_cleanup>
 10136d9:	48 89 df             	mov    %rbx,%rdi
 10136dc:	48 8d b5 c0 fe ff ff 	lea    -0x140(%rbp),%rsi
 10136e3:	e8 78 5b 00 00       	call   1019260 <myl_qbe_rc_frame_leave>
 10136e8:	ba 10 00 00 00       	mov    $0x10,%edx
 10136ed:	be 00 00 00 00       	mov    $0x0,%esi
 10136f2:	48 8d bd b0 fe ff ff 	lea    -0x150(%rbp),%rdi
 10136f9:	e8 a2 68 01 00       	call   1029fa0 <compiler_rt.fastMemset>
 10136fe:	48 8b 85 b0 fe ff ff 	mov    -0x150(%rbp),%rax
 1013705:	48 8b 95 b8 fe ff ff 	mov    -0x148(%rbp),%rdx
 101370c:	e9 12 01 00 00       	jmp    1013823 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xd63>
 1013711:	48 89 df             	mov    %rbx,%rdi
 1013714:	4c 89 e3             	mov    %r12,%rbx
 1013717:	c7 85 68 ff ff ff 00 	movl   $0x0,-0x98(%rbp)
 101371e:	00 00 00 
 1013721:	48 8d 05 18 b0 01 00 	lea    0x1b018(%rip),%rax        # 102e740 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 1013728:	48 89 85 20 ff ff ff 	mov    %rax,-0xe0(%rbp)
 101372f:	c7 85 38 ff ff ff 02 	movl   $0x2,-0xc8(%rbp)
 1013736:	00 00 00 
 1013739:	c7 85 70 ff ff ff 01 	movl   $0x1,-0x90(%rbp)
 1013740:	00 00 00 
 1013743:	48 8b 45 a0          	mov    -0x60(%rbp),%rax
 1013747:	48 89 03             	mov    %rax,(%rbx)
 101374a:	c7 85 70 ff ff ff 00 	movl   $0x0,-0x90(%rbp)
 1013751:	00 00 00 
 1013754:	eb 13                	jmp    1013769 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xca9>
 1013756:	4c 89 e3             	mov    %r12,%rbx
 1013759:	48 8b 00             	mov    (%rax),%rax
 101375c:	48 89 03             	mov    %rax,(%rbx)
 101375f:	c7 85 68 ff ff ff 00 	movl   $0x0,-0x98(%rbp)
 1013766:	00 00 00 
 1013769:	48 8d 45 d8          	lea    -0x28(%rbp),%rax
 101376d:	48 89 45 b8          	mov    %rax,-0x48(%rbp)
 1013771:	48 8b 45 d8          	mov    -0x28(%rbp),%rax
 1013775:	48 89 45 80          	mov    %rax,-0x80(%rbp)
 1013779:	48 8b 45 e0          	mov    -0x20(%rbp),%rax
 101377d:	48 89 45 88          	mov    %rax,-0x78(%rbp)
 1013781:	48 8d 05 28 b0 01 00 	lea    0x1b028(%rip),%rax        # 102e7b0 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 1013788:	48 89 85 e0 fe ff ff 	mov    %rax,-0x120(%rbp)
 101378f:	c7 85 f8 fe ff ff 02 	movl   $0x2,-0x108(%rbp)
 1013796:	00 00 00 
 1013799:	c7 85 60 ff ff ff 01 	movl   $0x1,-0xa0(%rbp)
 10137a0:	00 00 00 
 10137a3:	48 8d 45 80          	lea    -0x80(%rbp),%rax
 10137a7:	48 89 45 b8          	mov    %rax,-0x48(%rbp)
 10137ab:	c7 85 78 ff ff ff 00 	movl   $0x0,-0x88(%rbp)
 10137b2:	00 00 00 
 10137b5:	48 8b 45 80          	mov    -0x80(%rbp),%rax
 10137b9:	48 89 45 a0          	mov    %rax,-0x60(%rbp)
 10137bd:	48 8b 45 88          	mov    -0x78(%rbp),%rax
 10137c1:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
 10137c5:	c7 85 60 ff ff ff 00 	movl   $0x0,-0xa0(%rbp)
 10137cc:	00 00 00 
 10137cf:	48 8d b5 c0 fe ff ff 	lea    -0x140(%rbp),%rsi
 10137d6:	e8 85 5a 00 00       	call   1019260 <myl_qbe_rc_frame_leave>
 10137db:	48 8b 45 a0          	mov    -0x60(%rbp),%rax
 10137df:	48 8b 55 a8          	mov    -0x58(%rbp),%rdx
 10137e3:	eb 3e                	jmp    1013823 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xd63>
 10137e5:	4c 89 ea             	mov    %r13,%rdx
 10137e8:	41 b8 40 00 00 00    	mov    $0x40,%r8d
 10137ee:	b9 01 00 00 00       	mov    $0x1,%ecx
 10137f3:	be 01 00 00 00       	mov    $0x1,%esi
 10137f8:	e8 93 61 00 00       	call   1019990 <myl_qbe_fail_overflow_op>
 10137fd:	0f 0b                	ud2
 10137ff:	48 c7 85 b0 fe ff ff 	movq   $0x0,-0x150(%rbp)
 1013806:	00 00 00 00 
 101380a:	48 c7 85 b8 fe ff ff 	movq   $0x0,-0x148(%rbp)
 1013811:	00 00 00 00 
 1013815:	48 8b 85 b0 fe ff ff 	mov    -0x150(%rbp),%rax
 101381c:	48 8b 95 b8 fe ff ff 	mov    -0x148(%rbp),%rdx
 1013823:	41 5f                	pop    %r15
 1013825:	41 5e                	pop    %r14
 1013827:	41 5d                	pop    %r13
 1013829:	41 5c                	pop    %r12
 101382b:	5b                   	pop    %rbx
 101382c:	c9                   	leave
 101382d:	c3                   	ret
 101382e:	e8 ad 62 00 00       	call   1019ae0 <myl_qbe_fail_frame>
 1013833:	0f 0b                	ud2

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
