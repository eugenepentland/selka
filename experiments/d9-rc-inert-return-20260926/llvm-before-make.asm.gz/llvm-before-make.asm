
.tmp-rc/profile/gap-allocator-llvm-rc-n12:     file format elf64-x86-64


Disassembly of section .text:

0000000001016da0 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531>:
 1016da0:	55                   	push   %rbp
 1016da1:	41 57                	push   %r15
 1016da3:	41 56                	push   %r14
 1016da5:	41 55                	push   %r13
 1016da7:	41 54                	push   %r12
 1016da9:	53                   	push   %rbx
 1016daa:	48 81 ec a8 01 00 00 	sub    $0x1a8,%rsp
 1016db1:	48 89 fb             	mov    %rdi,%rbx
 1016db4:	48 39 67 40          	cmp    %rsp,0x40(%rdi)
 1016db8:	0f 87 3e 0e 00 00    	ja     1017bfc <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xe5c>
 1016dbe:	48 89 b4 24 80 01 00 	mov    %rsi,0x180(%rsp)
 1016dc5:	00 
 1016dc6:	8b 83 c8 02 00 00    	mov    0x2c8(%rbx),%eax
 1016dcc:	89 44 24 0c          	mov    %eax,0xc(%rsp)
 1016dd0:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
 1016dd4:	c5 fc 11 44 24 50    	vmovups %ymm0,0x50(%rsp)
 1016dda:	c5 fc 11 44 24 40    	vmovups %ymm0,0x40(%rsp)
 1016de0:	48 8d 44 24 50       	lea    0x50(%rsp),%rax
 1016de5:	c5 fc 11 84 24 b8 00 	vmovups %ymm0,0xb8(%rsp)
 1016dec:	00 00 
 1016dee:	c5 fc 11 84 24 d8 00 	vmovups %ymm0,0xd8(%rsp)
 1016df5:	00 00 
 1016df7:	c5 fc 11 84 24 f8 00 	vmovups %ymm0,0xf8(%rsp)
 1016dfe:	00 00 
 1016e00:	c5 fc 11 84 24 18 01 	vmovups %ymm0,0x118(%rsp)
 1016e07:	00 00 
 1016e09:	c5 fc 11 84 24 38 01 	vmovups %ymm0,0x138(%rsp)
 1016e10:	00 00 
 1016e12:	48 c7 84 24 58 01 00 	movq   $0x0,0x158(%rsp)
 1016e19:	00 00 00 00 00 
 1016e1e:	48 c7 84 24 a0 00 00 	movq   $0x1009850,0xa0(%rsp)
 1016e25:	00 50 98 00 01 
 1016e2a:	48 8d 8c 24 80 01 00 	lea    0x180(%rsp),%rcx
 1016e31:	00 
 1016e32:	48 89 8c 24 a8 00 00 	mov    %rcx,0xa8(%rsp)
 1016e39:	00 
 1016e3a:	48 8d 4c 24 40       	lea    0x40(%rsp),%rcx
 1016e3f:	48 89 8c 24 b0 00 00 	mov    %rcx,0xb0(%rsp)
 1016e46:	00 
 1016e47:	48 c7 84 24 c0 00 00 	movq   $0x1009be8,0xc0(%rsp)
 1016e4e:	00 e8 9b 00 01 
 1016e53:	48 8d 4c 24 20       	lea    0x20(%rsp),%rcx
 1016e58:	48 89 8c 24 c8 00 00 	mov    %rcx,0xc8(%rsp)
 1016e5f:	00 
 1016e60:	48 8d 4c 24 48       	lea    0x48(%rsp),%rcx
 1016e65:	48 89 8c 24 d0 00 00 	mov    %rcx,0xd0(%rsp)
 1016e6c:	00 
 1016e6d:	48 c7 84 24 e0 00 00 	movq   $0x1009be8,0xe0(%rsp)
 1016e74:	00 e8 9b 00 01 
 1016e79:	48 8d 54 24 70       	lea    0x70(%rsp),%rdx
 1016e7e:	48 89 94 24 e8 00 00 	mov    %rdx,0xe8(%rsp)
 1016e85:	00 
 1016e86:	48 89 84 24 f0 00 00 	mov    %rax,0xf0(%rsp)
 1016e8d:	00 
 1016e8e:	48 c7 84 24 00 01 00 	movq   $0x1009be8,0x100(%rsp)
 1016e95:	00 e8 9b 00 01 
 1016e9a:	48 8d 84 24 a0 01 00 	lea    0x1a0(%rsp),%rax
 1016ea1:	00 
 1016ea2:	48 89 84 24 08 01 00 	mov    %rax,0x108(%rsp)
 1016ea9:	00 
 1016eaa:	48 8d 44 24 58       	lea    0x58(%rsp),%rax
 1016eaf:	48 89 84 24 10 01 00 	mov    %rax,0x110(%rsp)
 1016eb6:	00 
 1016eb7:	48 c7 84 24 20 01 00 	movq   $0x1009be8,0x120(%rsp)
 1016ebe:	00 e8 9b 00 01 
 1016ec3:	4c 8d 74 24 10       	lea    0x10(%rsp),%r14
 1016ec8:	4c 89 b4 24 28 01 00 	mov    %r14,0x128(%rsp)
 1016ecf:	00 
 1016ed0:	48 8d 44 24 60       	lea    0x60(%rsp),%rax
 1016ed5:	48 89 84 24 30 01 00 	mov    %rax,0x130(%rsp)
 1016edc:	00 
 1016edd:	48 c7 84 24 40 01 00 	movq   $0x1009be8,0x140(%rsp)
 1016ee4:	00 e8 9b 00 01 
 1016ee9:	4c 8d ac 24 88 01 00 	lea    0x188(%rsp),%r13
 1016ef0:	00 
 1016ef1:	4c 89 ac 24 48 01 00 	mov    %r13,0x148(%rsp)
 1016ef8:	00 
 1016ef9:	48 8d 6c 24 68       	lea    0x68(%rsp),%rbp
 1016efe:	48 89 ac 24 50 01 00 	mov    %rbp,0x150(%rsp)
 1016f05:	00 
 1016f06:	48 85 db             	test   %rbx,%rbx
 1016f09:	0f 84 d8 0c 00 00    	je     1017be7 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xe47>
 1016f0f:	48 8b 83 60 18 00 00 	mov    0x1860(%rbx),%rax
 1016f16:	48 85 c0             	test   %rax,%rax
 1016f19:	0f 84 c8 0c 00 00    	je     1017be7 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xe47>
 1016f1f:	48 8b 8b 80 3d 00 00 	mov    0x3d80(%rbx),%rcx
 1016f26:	48 8b 40 70          	mov    0x70(%rax),%rax
 1016f2a:	48 89 8c 24 80 00 00 	mov    %rcx,0x80(%rsp)
 1016f31:	00 
 1016f32:	48 8d 8c 24 a0 00 00 	lea    0xa0(%rsp),%rcx
 1016f39:	00 
 1016f3a:	48 89 8c 24 88 00 00 	mov    %rcx,0x88(%rsp)
 1016f41:	00 
 1016f42:	48 c7 84 24 90 00 00 	movq   $0x6,0x90(%rsp)
 1016f49:	00 06 00 00 00 
 1016f4e:	48 89 84 24 98 00 00 	mov    %rax,0x98(%rsp)
 1016f55:	00 
 1016f56:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
 1016f5d:	00 
 1016f5e:	4c 89 a3 80 3d 00 00 	mov    %r12,0x3d80(%rbx)
 1016f65:	48 85 f6             	test   %rsi,%rsi
 1016f68:	0f 84 7d 01 00 00    	je     10170eb <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x34b>
 1016f6e:	48 89 74 24 30       	mov    %rsi,0x30(%rsp)
 1016f73:	48 c7 44 24 38 01 00 	movq   $0x1,0x38(%rsp)
 1016f7a:	00 00 
 1016f7c:	48 89 f0             	mov    %rsi,%rax
 1016f7f:	48 f7 d8             	neg    %rax
 1016f82:	0f 80 84 0c 00 00    	jo     1017c0c <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xe6c>
 1016f88:	4d 89 e7             	mov    %r12,%r15
 1016f8b:	48 ff ce             	dec    %rsi
 1016f8e:	48 89 74 24 30       	mov    %rsi,0x30(%rsp)
 1016f93:	48 89 df             	mov    %rbx,%rdi
 1016f96:	c5 f8 77             	vzeroupper
 1016f99:	e8 02 fe ff ff       	call   1016da0 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531>
 1016f9e:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
 1016fa3:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
 1016fa8:	48 c7 84 24 20 01 00 	movq   $0x100a308,0x120(%rsp)
 1016faf:	00 08 a3 00 01 
 1016fb4:	c7 84 24 38 01 00 00 	movl   $0x2,0x138(%rsp)
 1016fbb:	02 00 00 00 
 1016fbf:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
 1016fc4:	48 89 54 24 28       	mov    %rdx,0x28(%rsp)
 1016fc9:	48 c7 84 24 c0 00 00 	movq   $0x100a308,0xc0(%rsp)
 1016fd0:	00 08 a3 00 01 
 1016fd5:	c7 84 24 d8 00 00 00 	movl   $0x2,0xd8(%rsp)
 1016fdc:	02 00 00 00 
 1016fe0:	c7 44 24 60 00 00 00 	movl   $0x0,0x60(%rsp)
 1016fe7:	00 
 1016fe8:	c7 44 24 48 01 00 00 	movl   $0x1,0x48(%rsp)
 1016fef:	00 
 1016ff0:	48 8d 44 24 20       	lea    0x20(%rsp),%rax
 1016ff5:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
 1016ffa:	48 83 bb 60 18 00 00 	cmpq   $0x0,0x1860(%rbx)
 1017001:	00 
 1017002:	0f 84 ec 0b 00 00    	je     1017bf4 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xe54>
 1017008:	8b 8b c8 02 00 00    	mov    0x2c8(%rbx),%ecx
 101700e:	be c0 98 00 01       	mov    $0x10098c0,%esi
 1017013:	ba 01 00 00 00       	mov    $0x1,%edx
 1017018:	48 8d bb 58 02 00 00 	lea    0x258(%rbx),%rdi
 101701f:	e8 7c 22 01 00       	call   10292a0 <myl_rc_storage_alloc>
 1017024:	48 85 c0             	test   %rax,%rax
 1017027:	0f 84 c7 0b 00 00    	je     1017bf4 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xe54>
 101702d:	49 89 c4             	mov    %rax,%r12
 1017030:	48 89 84 24 88 01 00 	mov    %rax,0x188(%rsp)
 1017037:	00 
 1017038:	48 c7 84 24 40 01 00 	movq   $0x1009930,0x140(%rsp)
 101703f:	00 30 99 00 01 
 1017044:	4c 89 ac 24 48 01 00 	mov    %r13,0x148(%rsp)
 101704b:	00 
 101704c:	48 89 ac 24 50 01 00 	mov    %rbp,0x150(%rsp)
 1017053:	00 
 1017054:	c7 84 24 58 01 00 00 	movl   $0x4,0x158(%rsp)
 101705b:	04 00 00 00 
 101705f:	c7 44 24 68 01 00 00 	movl   $0x1,0x68(%rsp)
 1017066:	00 
 1017067:	48 8b 4c 24 30       	mov    0x30(%rsp),%rcx
 101706c:	48 89 c8             	mov    %rcx,%rax
 101706f:	4c 29 f0             	sub    %r14,%rax
 1017072:	4c 89 f2             	mov    %r14,%rdx
 1017075:	48 29 ca             	sub    %rcx,%rdx
 1017078:	48 83 f8 10          	cmp    $0x10,%rax
 101707c:	0f 92 c0             	setb   %al
 101707f:	48 83 fa 10          	cmp    $0x10,%rdx
 1017083:	0f 92 c2             	setb   %dl
 1017086:	08 c2                	or     %al,%dl
 1017088:	75 39                	jne    10170c3 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x323>
 101708a:	48 8b 01             	mov    (%rcx),%rax
 101708d:	48 85 c0             	test   %rax,%rax
 1017090:	74 10                	je     10170a2 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x302>
 1017092:	48 ba 01 00 00 00 00 	movabs $0x5000000000000001,%rdx
 1017099:	00 00 50 
 101709c:	48 85 50 f0          	test   %rdx,-0x10(%rax)
 10170a0:	75 21                	jne    10170c3 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x323>
 10170a2:	48 8b 41 08          	mov    0x8(%rcx),%rax
 10170a6:	48 85 c0             	test   %rax,%rax
 10170a9:	0f 84 be 01 00 00    	je     101726d <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x4cd>
 10170af:	48 ba 01 00 00 00 00 	movabs $0x5000000000000001,%rdx
 10170b6:	00 00 50 
 10170b9:	48 85 50 f0          	test   %rdx,-0x10(%rax)
 10170bd:	0f 84 aa 01 00 00    	je     101726d <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x4cd>
 10170c3:	48 8d 54 24 10       	lea    0x10(%rsp),%rdx
 10170c8:	be 08 a3 00 01       	mov    $0x100a308,%esi
 10170cd:	48 8d bb 58 02 00 00 	lea    0x258(%rbx),%rdi
 10170d4:	44 8b 44 24 0c       	mov    0xc(%rsp),%r8d
 10170d9:	e8 22 39 01 00       	call   102aa00 <myl_rc_native_take>
 10170de:	85 c0                	test   %eax,%eax
 10170e0:	0f 85 99 01 00 00    	jne    101727f <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x4df>
 10170e6:	e9 67 02 00 00       	jmp    1017352 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x5b2>
 10170eb:	48 c7 84 24 e0 00 00 	movq   $0x1009fd8,0xe0(%rsp)
 10170f2:	00 d8 9f 00 01 
 10170f7:	c7 84 24 f8 00 00 00 	movl   $0x2,0xf8(%rsp)
 10170fe:	02 00 00 00 
 1017102:	48 89 54 24 38       	mov    %rdx,0x38(%rsp)
 1017107:	48 c7 84 24 40 01 00 	movq   $0x100a308,0x140(%rsp)
 101710e:	00 08 a3 00 01 
 1017113:	c7 84 24 58 01 00 00 	movl   $0x2,0x158(%rsp)
 101711a:	02 00 00 00 
 101711e:	48 8d 84 24 90 01 00 	lea    0x190(%rsp),%rax
 1017125:	00 
 1017126:	48 89 84 24 48 01 00 	mov    %rax,0x148(%rsp)
 101712d:	00 
 101712e:	48 89 ac 24 50 01 00 	mov    %rbp,0x150(%rsp)
 1017135:	00 
 1017136:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
 101713a:	c5 f8 11 84 24 90 01 	vmovups %xmm0,0x190(%rsp)
 1017141:	00 00 
 1017143:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
 101714a:	00 00 
 101714c:	48 c7 44 24 70 00 00 	movq   $0x0,0x70(%rsp)
 1017153:	00 00 
 1017155:	c7 44 24 50 00 00 00 	movl   $0x0,0x50(%rsp)
 101715c:	00 
 101715d:	48 c7 84 24 20 01 00 	movq   $0x1009fd8,0x120(%rsp)
 1017164:	00 d8 9f 00 01 
 1017169:	c7 84 24 38 01 00 00 	movl   $0x2,0x138(%rsp)
 1017170:	02 00 00 00 
 1017174:	c7 44 24 60 00 00 00 	movl   $0x0,0x60(%rsp)
 101717b:	00 
 101717c:	c5 f8 10 84 24 90 01 	vmovups 0x190(%rsp),%xmm0
 1017183:	00 00 
 1017185:	c5 f8 29 44 24 20    	vmovaps %xmm0,0x20(%rsp)
 101718b:	48 c7 84 24 c0 00 00 	movq   $0x100a308,0xc0(%rsp)
 1017192:	00 08 a3 00 01 
 1017197:	c7 84 24 d8 00 00 00 	movl   $0x2,0xd8(%rsp)
 101719e:	02 00 00 00 
 10171a2:	c7 44 24 48 01 00 00 	movl   $0x1,0x48(%rsp)
 10171a9:	00 
 10171aa:	48 8d 4c 24 20       	lea    0x20(%rsp),%rcx
 10171af:	48 89 4c 24 30       	mov    %rcx,0x30(%rsp)
 10171b4:	c7 44 24 68 00 00 00 	movl   $0x0,0x68(%rsp)
 10171bb:	00 
 10171bc:	48 89 c8             	mov    %rcx,%rax
 10171bf:	4c 29 f0             	sub    %r14,%rax
 10171c2:	49 29 ce             	sub    %rcx,%r14
 10171c5:	48 83 f8 10          	cmp    $0x10,%rax
 10171c9:	0f 92 c0             	setb   %al
 10171cc:	49 83 fe 10          	cmp    $0x10,%r14
 10171d0:	0f 92 c1             	setb   %cl
 10171d3:	08 c1                	or     %al,%cl
 10171d5:	75 32                	jne    1017209 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x469>
 10171d7:	48 b8 01 00 00 00 00 	movabs $0x5000000000000001,%rax
 10171de:	00 00 50 
 10171e1:	48 8b 4c 24 20       	mov    0x20(%rsp),%rcx
 10171e6:	48 85 c9             	test   %rcx,%rcx
 10171e9:	74 06                	je     10171f1 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x451>
 10171eb:	48 85 41 f0          	test   %rax,-0x10(%rcx)
 10171ef:	75 18                	jne    1017209 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x469>
 10171f1:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
 10171f6:	48 85 c9             	test   %rcx,%rcx
 10171f9:	0f 84 67 03 00 00    	je     1017566 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x7c6>
 10171ff:	48 85 41 f0          	test   %rax,-0x10(%rcx)
 1017203:	0f 84 5d 03 00 00    	je     1017566 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x7c6>
 1017209:	48 8d 54 24 10       	lea    0x10(%rsp),%rdx
 101720e:	48 8d 4c 24 20       	lea    0x20(%rsp),%rcx
 1017213:	be 08 a3 00 01       	mov    $0x100a308,%esi
 1017218:	48 8d bb 58 02 00 00 	lea    0x258(%rbx),%rdi
 101721f:	44 8b 44 24 0c       	mov    0xc(%rsp),%r8d
 1017224:	c5 f8 77             	vzeroupper
 1017227:	e8 d4 37 01 00       	call   102aa00 <myl_rc_native_take>
 101722c:	85 c0                	test   %eax,%eax
 101722e:	0f 84 98 07 00 00    	je     10179cc <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xc2c>
 1017234:	4c 39 a3 80 3d 00 00 	cmp    %r12,0x3d80(%rbx)
 101723b:	c7 44 24 48 00 00 00 	movl   $0x0,0x48(%rsp)
 1017242:	00 
 1017243:	48 c7 84 24 20 01 00 	movq   $0x100a308,0x120(%rsp)
 101724a:	00 08 a3 00 01 
 101724f:	c7 84 24 38 01 00 00 	movl   $0x2,0x138(%rsp)
 1017256:	02 00 00 00 
 101725a:	c7 44 24 60 00 00 00 	movl   $0x0,0x60(%rsp)
 1017261:	00 
 1017262:	0f 84 3e 03 00 00    	je     10175a6 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x806>
 1017268:	e9 7a 09 00 00       	jmp    1017be7 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xe47>
 101726d:	c5 f8 10 01          	vmovups (%rcx),%xmm0
 1017271:	c5 f8 29 44 24 10    	vmovaps %xmm0,0x10(%rsp)
 1017277:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
 101727b:	c5 f8 11 01          	vmovups %xmm0,(%rcx)
 101727f:	48 c7 84 24 20 01 00 	movq   $0x100a308,0x120(%rsp)
 1017286:	00 08 a3 00 01 
 101728b:	c7 84 24 38 01 00 00 	movl   $0x2,0x138(%rsp)
 1017292:	02 00 00 00 
 1017296:	c5 f8 28 44 24 10    	vmovaps 0x10(%rsp),%xmm0
 101729c:	c4 c1 78 11 04 24    	vmovups %xmm0,(%r12)
 10172a2:	c7 44 24 60 00 00 00 	movl   $0x0,0x60(%rsp)
 10172a9:	00 
 10172aa:	4c 89 64 24 20       	mov    %r12,0x20(%rsp)
 10172af:	48 c7 84 24 c0 00 00 	movq   $0x1009930,0xc0(%rsp)
 10172b6:	00 30 99 00 01 
 10172bb:	c7 84 24 d8 00 00 00 	movl   $0x2,0xd8(%rsp)
 10172c2:	02 00 00 00 
 10172c6:	c7 44 24 48 01 00 00 	movl   $0x1,0x48(%rsp)
 10172cd:	00 
 10172ce:	4c 89 64 24 30       	mov    %r12,0x30(%rsp)
 10172d3:	48 c7 84 24 78 01 00 	movq   $0x0,0x178(%rsp)
 10172da:	00 00 00 00 00 
 10172df:	48 c7 84 24 40 01 00 	movq   $0x1009fd8,0x140(%rsp)
 10172e6:	00 d8 9f 00 01 
 10172eb:	c7 84 24 58 01 00 00 	movl   $0x2,0x158(%rsp)
 10172f2:	02 00 00 00 
 10172f6:	48 8d 84 24 78 01 00 	lea    0x178(%rsp),%rax
 10172fd:	00 
 10172fe:	48 89 84 24 48 01 00 	mov    %rax,0x148(%rsp)
 1017305:	00 
 1017306:	48 89 ac 24 50 01 00 	mov    %rbp,0x150(%rsp)
 101730d:	00 
 101730e:	c7 44 24 68 01 00 00 	movl   $0x1,0x68(%rsp)
 1017315:	00 
 1017316:	48 b8 01 00 00 00 00 	movabs $0x5000000000000001,%rax
 101731d:	00 00 50 
 1017320:	49 85 44 24 f0       	test   %rax,-0x10(%r12)
 1017325:	74 55                	je     101737c <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x5dc>
 1017327:	48 8d 54 24 10       	lea    0x10(%rsp),%rdx
 101732c:	48 8d 4c 24 30       	lea    0x30(%rsp),%rcx
 1017331:	be 30 99 00 01       	mov    $0x1009930,%esi
 1017336:	48 8d bb 58 02 00 00 	lea    0x258(%rbx),%rdi
 101733d:	44 8b 44 24 0c       	mov    0xc(%rsp),%r8d
 1017342:	e8 b9 36 01 00       	call   102aa00 <myl_rc_native_take>
 1017347:	85 c0                	test   %eax,%eax
 1017349:	74 07                	je     1017352 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x5b2>
 101734b:	4c 8b 64 24 10       	mov    0x10(%rsp),%r12
 1017350:	eb 2f                	jmp    1017381 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x5e1>
 1017352:	48 8b 8b 60 18 00 00 	mov    0x1860(%rbx),%rcx
 1017359:	48 85 c9             	test   %rcx,%rcx
 101735c:	0f 84 85 08 00 00    	je     1017be7 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xe47>
 1017362:	8b 41 78             	mov    0x78(%rcx),%eax
 1017365:	c7 41 78 00 00 00 00 	movl   $0x0,0x78(%rcx)
 101736c:	85 c0                	test   %eax,%eax
 101736e:	4d 89 fc             	mov    %r15,%r12
 1017371:	0f 85 73 06 00 00    	jne    10179ea <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xc4a>
 1017377:	e9 a3 06 00 00       	jmp    1017a1f <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xc7f>
 101737c:	4c 89 64 24 10       	mov    %r12,0x10(%rsp)
 1017381:	48 c7 84 24 20 01 00 	movq   $0x1009930,0x120(%rsp)
 1017388:	00 30 99 00 01 
 101738d:	c7 84 24 38 01 00 00 	movl   $0x2,0x138(%rsp)
 1017394:	02 00 00 00 
 1017398:	4c 89 a4 24 78 01 00 	mov    %r12,0x178(%rsp)
 101739f:	00 
 10173a0:	c7 44 24 60 00 00 00 	movl   $0x0,0x60(%rsp)
 10173a7:	00 
 10173a8:	4c 89 64 24 20       	mov    %r12,0x20(%rsp)
 10173ad:	48 c7 84 24 c0 00 00 	movq   $0x1009fd8,0xc0(%rsp)
 10173b4:	00 d8 9f 00 01 
 10173b9:	c7 84 24 d8 00 00 00 	movl   $0x2,0xd8(%rsp)
 10173c0:	02 00 00 00 
 10173c4:	c7 44 24 48 01 00 00 	movl   $0x1,0x48(%rsp)
 10173cb:	00 
 10173cc:	48 8d 44 24 20       	lea    0x20(%rsp),%rax
 10173d1:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
 10173d6:	c7 44 24 68 00 00 00 	movl   $0x0,0x68(%rsp)
 10173dd:	00 
 10173de:	48 8b b4 24 80 01 00 	mov    0x180(%rsp),%rsi
 10173e5:	00 
 10173e6:	48 89 74 24 38       	mov    %rsi,0x38(%rsp)
 10173eb:	48 ba 00 00 00 00 00 	movabs $0x8000000000000000,%rdx
 10173f2:	00 00 80 
 10173f5:	48 39 d6             	cmp    %rdx,%rsi
 10173f8:	0f 84 2d 08 00 00    	je     1017c2b <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xe8b>
 10173fe:	48 ff ce             	dec    %rsi
 1017401:	48 89 74 24 38       	mov    %rsi,0x38(%rsp)
 1017406:	48 89 df             	mov    %rbx,%rdi
 1017409:	e8 92 f9 ff ff       	call   1016da0 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531>
 101740e:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
 1017413:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
 1017418:	48 c7 84 24 20 01 00 	movq   $0x100a308,0x120(%rsp)
 101741f:	00 08 a3 00 01 
 1017424:	c7 84 24 38 01 00 00 	movl   $0x2,0x138(%rsp)
 101742b:	02 00 00 00 
 101742f:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
 1017434:	48 89 54 24 78       	mov    %rdx,0x78(%rsp)
 1017439:	48 c7 84 24 e0 00 00 	movq   $0x100a308,0xe0(%rsp)
 1017440:	00 08 a3 00 01 
 1017445:	c7 84 24 f8 00 00 00 	movl   $0x2,0xf8(%rsp)
 101744c:	02 00 00 00 
 1017450:	c7 44 24 60 00 00 00 	movl   $0x0,0x60(%rsp)
 1017457:	00 
 1017458:	c7 44 24 50 01 00 00 	movl   $0x1,0x50(%rsp)
 101745f:	00 
 1017460:	48 8d 44 24 70       	lea    0x70(%rsp),%rax
 1017465:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
 101746a:	48 83 bb 60 18 00 00 	cmpq   $0x0,0x1860(%rbx)
 1017471:	00 
 1017472:	0f 84 8c 07 00 00    	je     1017c04 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xe64>
 1017478:	4d 89 fc             	mov    %r15,%r12
 101747b:	8b 8b c8 02 00 00    	mov    0x2c8(%rbx),%ecx
 1017481:	be c0 98 00 01       	mov    $0x10098c0,%esi
 1017486:	ba 01 00 00 00       	mov    $0x1,%edx
 101748b:	48 8d bb 58 02 00 00 	lea    0x258(%rbx),%rdi
 1017492:	e8 09 1e 01 00       	call   10292a0 <myl_rc_storage_alloc>
 1017497:	48 85 c0             	test   %rax,%rax
 101749a:	0f 84 64 07 00 00    	je     1017c04 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xe64>
 10174a0:	49 89 c7             	mov    %rax,%r15
 10174a3:	48 89 84 24 88 01 00 	mov    %rax,0x188(%rsp)
 10174aa:	00 
 10174ab:	48 c7 84 24 40 01 00 	movq   $0x1009930,0x140(%rsp)
 10174b2:	00 30 99 00 01 
 10174b7:	4c 89 ac 24 48 01 00 	mov    %r13,0x148(%rsp)
 10174be:	00 
 10174bf:	48 89 ac 24 50 01 00 	mov    %rbp,0x150(%rsp)
 10174c6:	00 
 10174c7:	c7 84 24 58 01 00 00 	movl   $0x4,0x158(%rsp)
 10174ce:	04 00 00 00 
 10174d2:	c7 44 24 68 01 00 00 	movl   $0x1,0x68(%rsp)
 10174d9:	00 
 10174da:	48 8d 54 24 70       	lea    0x70(%rsp),%rdx
 10174df:	48 89 d0             	mov    %rdx,%rax
 10174e2:	4c 29 f0             	sub    %r14,%rax
 10174e5:	4c 89 f1             	mov    %r14,%rcx
 10174e8:	48 29 d1             	sub    %rdx,%rcx
 10174eb:	48 83 f8 10          	cmp    $0x10,%rax
 10174ef:	0f 92 c0             	setb   %al
 10174f2:	48 83 f9 10          	cmp    $0x10,%rcx
 10174f6:	0f 92 c1             	setb   %cl
 10174f9:	08 c1                	or     %al,%cl
 10174fb:	75 3c                	jne    1017539 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x799>
 10174fd:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
 1017502:	48 85 c0             	test   %rax,%rax
 1017505:	74 10                	je     1017517 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x777>
 1017507:	48 b9 01 00 00 00 00 	movabs $0x5000000000000001,%rcx
 101750e:	00 00 50 
 1017511:	48 85 48 f0          	test   %rcx,-0x10(%rax)
 1017515:	75 22                	jne    1017539 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x799>
 1017517:	48 8b 44 24 78       	mov    0x78(%rsp),%rax
 101751c:	48 85 c0             	test   %rax,%rax
 101751f:	0f 84 ec 00 00 00    	je     1017611 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x871>
 1017525:	48 b9 01 00 00 00 00 	movabs $0x5000000000000001,%rcx
 101752c:	00 00 50 
 101752f:	48 85 48 f0          	test   %rcx,-0x10(%rax)
 1017533:	0f 84 d8 00 00 00    	je     1017611 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x871>
 1017539:	48 8d 54 24 10       	lea    0x10(%rsp),%rdx
 101753e:	48 8d 4c 24 70       	lea    0x70(%rsp),%rcx
 1017543:	be 08 a3 00 01       	mov    $0x100a308,%esi
 1017548:	48 8d bb 58 02 00 00 	lea    0x258(%rbx),%rdi
 101754f:	44 8b 44 24 0c       	mov    0xc(%rsp),%r8d
 1017554:	e8 a7 34 01 00       	call   102aa00 <myl_rc_native_take>
 1017559:	85 c0                	test   %eax,%eax
 101755b:	0f 85 c5 00 00 00    	jne    1017626 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x886>
 1017561:	e9 66 04 00 00       	jmp    10179cc <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xc2c>
 1017566:	c5 f8 10 84 24 90 01 	vmovups 0x190(%rsp),%xmm0
 101756d:	00 00 
 101756f:	c5 f8 29 44 24 10    	vmovaps %xmm0,0x10(%rsp)
 1017575:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
 1017579:	c5 f8 29 44 24 20    	vmovaps %xmm0,0x20(%rsp)
 101757f:	c7 44 24 48 00 00 00 	movl   $0x0,0x48(%rsp)
 1017586:	00 
 1017587:	48 c7 84 24 20 01 00 	movq   $0x100a308,0x120(%rsp)
 101758e:	00 08 a3 00 01 
 1017593:	c7 84 24 38 01 00 00 	movl   $0x2,0x138(%rsp)
 101759a:	02 00 00 00 
 101759e:	c7 44 24 60 00 00 00 	movl   $0x0,0x60(%rsp)
 10175a5:	00 
 10175a6:	48 8b b4 24 98 00 00 	mov    0x98(%rsp),%rsi
 10175ad:	00 
 10175ae:	48 8d bb 58 02 00 00 	lea    0x258(%rbx),%rdi
 10175b5:	c5 f8 77             	vzeroupper
 10175b8:	e8 63 fe 00 00       	call   1027420 <myl_rc_scope_unwind>
 10175bd:	4c 8b b4 24 90 00 00 	mov    0x90(%rsp),%r14
 10175c4:	00 
 10175c5:	4d 85 f6             	test   %r14,%r14
 10175c8:	0f 84 bf 05 00 00    	je     1017b8d <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xded>
 10175ce:	4d 89 f7             	mov    %r14,%r15
 10175d1:	49 c1 e7 05          	shl    $0x5,%r15
 10175d5:	49 83 c7 e0          	add    $0xffffffffffffffe0,%r15
 10175d9:	eb 1d                	jmp    10175f8 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x858>
 10175db:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
 10175e0:	4c 01 fe             	add    %r15,%rsi
 10175e3:	48 89 df             	mov    %rbx,%rdi
 10175e6:	e8 e5 57 00 00       	call   101cdd0 <myl_qbe_rc_slot_drop>
 10175eb:	49 83 c7 e0          	add    $0xffffffffffffffe0,%r15
 10175ef:	49 ff ce             	dec    %r14
 10175f2:	0f 84 95 05 00 00    	je     1017b8d <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xded>
 10175f8:	48 8b b4 24 88 00 00 	mov    0x88(%rsp),%rsi
 10175ff:	00 
 1017600:	4a 8b 44 3e 10       	mov    0x10(%rsi,%r15,1),%rax
 1017605:	48 85 c0             	test   %rax,%rax
 1017608:	74 d6                	je     10175e0 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x840>
 101760a:	83 38 00             	cmpl   $0x0,(%rax)
 101760d:	75 d1                	jne    10175e0 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x840>
 101760f:	eb da                	jmp    10175eb <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x84b>
 1017611:	c5 f8 10 44 24 70    	vmovups 0x70(%rsp),%xmm0
 1017617:	c5 f8 29 44 24 10    	vmovaps %xmm0,0x10(%rsp)
 101761d:	48 c7 44 24 78 00 00 	movq   $0x0,0x78(%rsp)
 1017624:	00 00 
 1017626:	48 c7 84 24 20 01 00 	movq   $0x100a308,0x120(%rsp)
 101762d:	00 08 a3 00 01 
 1017632:	c7 84 24 38 01 00 00 	movl   $0x2,0x138(%rsp)
 1017639:	02 00 00 00 
 101763d:	c5 f8 28 44 24 10    	vmovaps 0x10(%rsp),%xmm0
 1017643:	c4 c1 78 11 07       	vmovups %xmm0,(%r15)
 1017648:	c7 44 24 60 00 00 00 	movl   $0x0,0x60(%rsp)
 101764f:	00 
 1017650:	4c 89 7c 24 70       	mov    %r15,0x70(%rsp)
 1017655:	48 c7 84 24 e0 00 00 	movq   $0x1009930,0xe0(%rsp)
 101765c:	00 30 99 00 01 
 1017661:	c7 84 24 f8 00 00 00 	movl   $0x2,0xf8(%rsp)
 1017668:	02 00 00 00 
 101766c:	c7 44 24 50 01 00 00 	movl   $0x1,0x50(%rsp)
 1017673:	00 
 1017674:	4c 89 7c 24 38       	mov    %r15,0x38(%rsp)
 1017679:	48 c7 84 24 70 01 00 	movq   $0x0,0x170(%rsp)
 1017680:	00 00 00 00 00 
 1017685:	48 c7 84 24 40 01 00 	movq   $0x1009fd8,0x140(%rsp)
 101768c:	00 d8 9f 00 01 
 1017691:	c7 84 24 58 01 00 00 	movl   $0x2,0x158(%rsp)
 1017698:	02 00 00 00 
 101769c:	48 8d 84 24 70 01 00 	lea    0x170(%rsp),%rax
 10176a3:	00 
 10176a4:	48 89 84 24 48 01 00 	mov    %rax,0x148(%rsp)
 10176ab:	00 
 10176ac:	48 89 ac 24 50 01 00 	mov    %rbp,0x150(%rsp)
 10176b3:	00 
 10176b4:	c7 44 24 68 01 00 00 	movl   $0x1,0x68(%rsp)
 10176bb:	00 
 10176bc:	48 b8 01 00 00 00 00 	movabs $0x5000000000000001,%rax
 10176c3:	00 00 50 
 10176c6:	49 85 47 f0          	test   %rax,-0x10(%r15)
 10176ca:	74 2f                	je     10176fb <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x95b>
 10176cc:	48 8d 54 24 10       	lea    0x10(%rsp),%rdx
 10176d1:	48 8d 4c 24 38       	lea    0x38(%rsp),%rcx
 10176d6:	be 30 99 00 01       	mov    $0x1009930,%esi
 10176db:	48 8d bb 58 02 00 00 	lea    0x258(%rbx),%rdi
 10176e2:	44 8b 44 24 0c       	mov    0xc(%rsp),%r8d
 10176e7:	e8 14 33 01 00       	call   102aa00 <myl_rc_native_take>
 10176ec:	85 c0                	test   %eax,%eax
 10176ee:	0f 84 d8 02 00 00    	je     10179cc <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xc2c>
 10176f4:	4c 8b 7c 24 10       	mov    0x10(%rsp),%r15
 10176f9:	eb 05                	jmp    1017700 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x960>
 10176fb:	4c 89 7c 24 10       	mov    %r15,0x10(%rsp)
 1017700:	48 c7 84 24 20 01 00 	movq   $0x1009930,0x120(%rsp)
 1017707:	00 30 99 00 01 
 101770c:	c7 84 24 38 01 00 00 	movl   $0x2,0x138(%rsp)
 1017713:	02 00 00 00 
 1017717:	4c 89 bc 24 70 01 00 	mov    %r15,0x170(%rsp)
 101771e:	00 
 101771f:	c7 44 24 60 00 00 00 	movl   $0x0,0x60(%rsp)
 1017726:	00 
 1017727:	4c 89 7c 24 70       	mov    %r15,0x70(%rsp)
 101772c:	48 c7 84 24 e0 00 00 	movq   $0x1009fd8,0xe0(%rsp)
 1017733:	00 d8 9f 00 01 
 1017738:	c7 84 24 f8 00 00 00 	movl   $0x2,0xf8(%rsp)
 101773f:	02 00 00 00 
 1017743:	c7 44 24 50 01 00 00 	movl   $0x1,0x50(%rsp)
 101774a:	00 
 101774b:	48 8d 44 24 70       	lea    0x70(%rsp),%rax
 1017750:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
 1017755:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
 1017759:	c5 f8 29 84 24 60 01 	vmovaps %xmm0,0x160(%rsp)
 1017760:	00 00 
 1017762:	48 c7 84 24 40 01 00 	movq   $0x100a308,0x140(%rsp)
 1017769:	00 08 a3 00 01 
 101776e:	c7 84 24 58 01 00 00 	movl   $0x2,0x158(%rsp)
 1017775:	02 00 00 00 
 1017779:	48 8d 84 24 60 01 00 	lea    0x160(%rsp),%rax
 1017780:	00 
 1017781:	48 89 84 24 48 01 00 	mov    %rax,0x148(%rsp)
 1017788:	00 
 1017789:	48 89 ac 24 50 01 00 	mov    %rbp,0x150(%rsp)
 1017790:	00 
 1017791:	c7 44 24 68 01 00 00 	movl   $0x1,0x68(%rsp)
 1017798:	00 
 1017799:	48 8b 4c 24 30       	mov    0x30(%rsp),%rcx
 101779e:	83 7c 24 48 00       	cmpl   $0x0,0x48(%rsp)
 10177a3:	74 5a                	je     10177ff <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xa5f>
 10177a5:	48 89 c8             	mov    %rcx,%rax
 10177a8:	4c 29 f0             	sub    %r14,%rax
 10177ab:	4c 89 f2             	mov    %r14,%rdx
 10177ae:	48 29 ca             	sub    %rcx,%rdx
 10177b1:	48 83 f8 08          	cmp    $0x8,%rax
 10177b5:	0f 92 c0             	setb   %al
 10177b8:	48 83 fa 08          	cmp    $0x8,%rdx
 10177bc:	0f 92 c2             	setb   %dl
 10177bf:	08 c2                	or     %al,%dl
 10177c1:	75 18                	jne    10177db <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xa3b>
 10177c3:	48 8b 01             	mov    (%rcx),%rax
 10177c6:	48 85 c0             	test   %rax,%rax
 10177c9:	74 58                	je     1017823 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xa83>
 10177cb:	48 ba 01 00 00 00 00 	movabs $0x5000000000000001,%rdx
 10177d2:	00 00 50 
 10177d5:	48 85 50 f0          	test   %rdx,-0x10(%rax)
 10177d9:	74 48                	je     1017823 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xa83>
 10177db:	48 8d 54 24 10       	lea    0x10(%rsp),%rdx
 10177e0:	be d8 9f 00 01       	mov    $0x1009fd8,%esi
 10177e5:	48 8d bb 58 02 00 00 	lea    0x258(%rbx),%rdi
 10177ec:	44 8b 44 24 0c       	mov    0xc(%rsp),%r8d
 10177f1:	e8 0a 32 01 00       	call   102aa00 <myl_rc_native_take>
 10177f6:	85 c0                	test   %eax,%eax
 10177f8:	75 35                	jne    101782f <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xa8f>
 10177fa:	e9 cd 01 00 00       	jmp    10179cc <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xc2c>
 10177ff:	48 8d 54 24 10       	lea    0x10(%rsp),%rdx
 1017804:	be d8 9f 00 01       	mov    $0x1009fd8,%esi
 1017809:	48 8d bb 58 02 00 00 	lea    0x258(%rbx),%rdi
 1017810:	44 8b 44 24 0c       	mov    0xc(%rsp),%r8d
 1017815:	e8 76 2c 01 00       	call   102a490 <myl_rc_native_copy>
 101781a:	85 c0                	test   %eax,%eax
 101781c:	75 19                	jne    1017837 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xa97>
 101781e:	e9 a9 01 00 00       	jmp    10179cc <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xc2c>
 1017823:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
 1017828:	48 c7 01 00 00 00 00 	movq   $0x0,(%rcx)
 101782f:	c7 44 24 48 00 00 00 	movl   $0x0,0x48(%rsp)
 1017836:	00 
 1017837:	48 c7 84 24 20 01 00 	movq   $0x1009fd8,0x120(%rsp)
 101783e:	00 d8 9f 00 01 
 1017843:	c7 84 24 38 01 00 00 	movl   $0x2,0x138(%rsp)
 101784a:	02 00 00 00 
 101784e:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
 1017853:	48 89 84 24 60 01 00 	mov    %rax,0x160(%rsp)
 101785a:	00 
 101785b:	c7 44 24 60 00 00 00 	movl   $0x0,0x60(%rsp)
 1017862:	00 
 1017863:	48 8b 4c 24 38       	mov    0x38(%rsp),%rcx
 1017868:	48 89 c8             	mov    %rcx,%rax
 101786b:	4c 29 f0             	sub    %r14,%rax
 101786e:	4c 89 f2             	mov    %r14,%rdx
 1017871:	48 29 ca             	sub    %rcx,%rdx
 1017874:	48 83 f8 08          	cmp    $0x8,%rax
 1017878:	0f 92 c0             	setb   %al
 101787b:	48 83 fa 08          	cmp    $0x8,%rdx
 101787f:	0f 92 c2             	setb   %dl
 1017882:	08 c2                	or     %al,%dl
 1017884:	75 18                	jne    101789e <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xafe>
 1017886:	48 8b 01             	mov    (%rcx),%rax
 1017889:	48 85 c0             	test   %rax,%rax
 101788c:	74 34                	je     10178c2 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xb22>
 101788e:	48 ba 01 00 00 00 00 	movabs $0x5000000000000001,%rdx
 1017895:	00 00 50 
 1017898:	48 85 50 f0          	test   %rdx,-0x10(%rax)
 101789c:	74 24                	je     10178c2 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xb22>
 101789e:	48 8d 54 24 10       	lea    0x10(%rsp),%rdx
 10178a3:	be d8 9f 00 01       	mov    $0x1009fd8,%esi
 10178a8:	48 8d bb 58 02 00 00 	lea    0x258(%rbx),%rdi
 10178af:	44 8b 44 24 0c       	mov    0xc(%rsp),%r8d
 10178b4:	e8 47 31 01 00       	call   102aa00 <myl_rc_native_take>
 10178b9:	85 c0                	test   %eax,%eax
 10178bb:	75 11                	jne    10178ce <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xb2e>
 10178bd:	e9 0a 01 00 00       	jmp    10179cc <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xc2c>
 10178c2:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
 10178c7:	48 c7 01 00 00 00 00 	movq   $0x0,(%rcx)
 10178ce:	c7 44 24 50 00 00 00 	movl   $0x0,0x50(%rsp)
 10178d5:	00 
 10178d6:	48 c7 84 24 20 01 00 	movq   $0x1009fd8,0x120(%rsp)
 10178dd:	00 d8 9f 00 01 
 10178e2:	c7 84 24 38 01 00 00 	movl   $0x2,0x138(%rsp)
 10178e9:	02 00 00 00 
 10178ed:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
 10178f2:	48 89 84 24 68 01 00 	mov    %rax,0x168(%rsp)
 10178f9:	00 
 10178fa:	c7 44 24 60 00 00 00 	movl   $0x0,0x60(%rsp)
 1017901:	00 
 1017902:	48 8b 84 24 60 01 00 	mov    0x160(%rsp),%rax
 1017909:	00 
 101790a:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
 101790f:	48 8b 84 24 68 01 00 	mov    0x168(%rsp),%rax
 1017916:	00 
 1017917:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
 101791c:	48 c7 84 24 c0 00 00 	movq   $0x100a308,0xc0(%rsp)
 1017923:	00 08 a3 00 01 
 1017928:	c7 84 24 d8 00 00 00 	movl   $0x2,0xd8(%rsp)
 101792f:	02 00 00 00 
 1017933:	c7 44 24 48 01 00 00 	movl   $0x1,0x48(%rsp)
 101793a:	00 
 101793b:	48 8d 4c 24 20       	lea    0x20(%rsp),%rcx
 1017940:	48 89 4c 24 30       	mov    %rcx,0x30(%rsp)
 1017945:	c7 44 24 68 00 00 00 	movl   $0x0,0x68(%rsp)
 101794c:	00 
 101794d:	48 89 c8             	mov    %rcx,%rax
 1017950:	4c 29 f0             	sub    %r14,%rax
 1017953:	49 29 ce             	sub    %rcx,%r14
 1017956:	48 83 f8 10          	cmp    $0x10,%rax
 101795a:	0f 92 c0             	setb   %al
 101795d:	49 83 fe 10          	cmp    $0x10,%r14
 1017961:	0f 92 c1             	setb   %cl
 1017964:	08 c1                	or     %al,%cl
 1017966:	75 3c                	jne    10179a4 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xc04>
 1017968:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
 101796d:	48 85 c0             	test   %rax,%rax
 1017970:	74 10                	je     1017982 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xbe2>
 1017972:	48 b9 01 00 00 00 00 	movabs $0x5000000000000001,%rcx
 1017979:	00 00 50 
 101797c:	48 85 48 f0          	test   %rcx,-0x10(%rax)
 1017980:	75 22                	jne    10179a4 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xc04>
 1017982:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
 1017987:	48 85 c0             	test   %rax,%rax
 101798a:	0f 84 51 01 00 00    	je     1017ae1 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xd41>
 1017990:	48 b9 01 00 00 00 00 	movabs $0x5000000000000001,%rcx
 1017997:	00 00 50 
 101799a:	48 85 48 f0          	test   %rcx,-0x10(%rax)
 101799e:	0f 84 3d 01 00 00    	je     1017ae1 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xd41>
 10179a4:	48 8d 54 24 10       	lea    0x10(%rsp),%rdx
 10179a9:	48 8d 4c 24 20       	lea    0x20(%rsp),%rcx
 10179ae:	be 08 a3 00 01       	mov    $0x100a308,%esi
 10179b3:	48 8d bb 58 02 00 00 	lea    0x258(%rbx),%rdi
 10179ba:	44 8b 44 24 0c       	mov    0xc(%rsp),%r8d
 10179bf:	e8 3c 30 01 00       	call   102aa00 <myl_rc_native_take>
 10179c4:	85 c0                	test   %eax,%eax
 10179c6:	0f 85 2e 01 00 00    	jne    1017afa <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xd5a>
 10179cc:	48 8b 8b 60 18 00 00 	mov    0x1860(%rbx),%rcx
 10179d3:	48 85 c9             	test   %rcx,%rcx
 10179d6:	0f 84 0b 02 00 00    	je     1017be7 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xe47>
 10179dc:	8b 41 78             	mov    0x78(%rcx),%eax
 10179df:	c7 41 78 00 00 00 00 	movl   $0x0,0x78(%rcx)
 10179e6:	85 c0                	test   %eax,%eax
 10179e8:	74 35                	je     1017a1f <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xc7f>
 10179ea:	83 f8 01             	cmp    $0x1,%eax
 10179ed:	75 15                	jne    1017a04 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xc64>
 10179ef:	be 5f 74 00 01       	mov    $0x100745f,%esi
 10179f4:	83 bb c4 02 00 00 00 	cmpl   $0x0,0x2c4(%rbx)
 10179fb:	75 1a                	jne    1017a17 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xc77>
 10179fd:	b8 01 00 00 00       	mov    $0x1,%eax
 1017a02:	eb 09                	jmp    1017a0d <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xc6d>
 1017a04:	83 f8 04             	cmp    $0x4,%eax
 1017a07:	0f 83 e2 01 00 00    	jae    1017bef <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xe4f>
 1017a0d:	89 c0                	mov    %eax,%eax
 1017a0f:	48 8b 34 c5 d0 d2 00 	mov    0x100d2d0(,%rax,8),%rsi
 1017a16:	01 
 1017a17:	48 89 df             	mov    %rbx,%rdi
 1017a1a:	e8 c1 5d 00 00       	call   101d7e0 <fail>
 1017a1f:	4c 39 a3 80 3d 00 00 	cmp    %r12,0x3d80(%rbx)
 1017a26:	0f 85 bb 01 00 00    	jne    1017be7 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xe47>
 1017a2c:	48 8b b4 24 98 00 00 	mov    0x98(%rsp),%rsi
 1017a33:	00 
 1017a34:	48 8d bb 58 02 00 00 	lea    0x258(%rbx),%rdi
 1017a3b:	e8 e0 f9 00 00       	call   1027420 <myl_rc_scope_unwind>
 1017a40:	4c 8b b4 24 90 00 00 	mov    0x90(%rsp),%r14
 1017a47:	00 
 1017a48:	4d 85 f6             	test   %r14,%r14
 1017a4b:	74 40                	je     1017a8d <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xced>
 1017a4d:	4d 89 f7             	mov    %r14,%r15
 1017a50:	49 c1 e7 05          	shl    $0x5,%r15
 1017a54:	49 83 c7 e0          	add    $0xffffffffffffffe0,%r15
 1017a58:	eb 1a                	jmp    1017a74 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xcd4>
 1017a5a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
 1017a60:	4c 01 fe             	add    %r15,%rsi
 1017a63:	48 89 df             	mov    %rbx,%rdi
 1017a66:	e8 65 53 00 00       	call   101cdd0 <myl_qbe_rc_slot_drop>
 1017a6b:	49 83 c7 e0          	add    $0xffffffffffffffe0,%r15
 1017a6f:	49 ff ce             	dec    %r14
 1017a72:	74 19                	je     1017a8d <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xced>
 1017a74:	48 8b b4 24 88 00 00 	mov    0x88(%rsp),%rsi
 1017a7b:	00 
 1017a7c:	4a 8b 44 3e 10       	mov    0x10(%rsi,%r15,1),%rax
 1017a81:	48 85 c0             	test   %rax,%rax
 1017a84:	74 da                	je     1017a60 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xcc0>
 1017a86:	83 38 00             	cmpl   $0x0,(%rax)
 1017a89:	75 d5                	jne    1017a60 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xcc0>
 1017a8b:	eb de                	jmp    1017a6b <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xccb>
 1017a8d:	4c 39 a3 80 3d 00 00 	cmp    %r12,0x3d80(%rbx)
 1017a94:	0f 85 4d 01 00 00    	jne    1017be7 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xe47>
 1017a9a:	48 8b 83 60 18 00 00 	mov    0x1860(%rbx),%rax
 1017aa1:	48 85 c0             	test   %rax,%rax
 1017aa4:	74 13                	je     1017ab9 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xd19>
 1017aa6:	48 8b 40 70          	mov    0x70(%rax),%rax
 1017aaa:	48 3b 84 24 98 00 00 	cmp    0x98(%rsp),%rax
 1017ab1:	00 
 1017ab2:	74 15                	je     1017ac9 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xd29>
 1017ab4:	e9 2e 01 00 00       	jmp    1017be7 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xe47>
 1017ab9:	31 c0                	xor    %eax,%eax
 1017abb:	48 3b 84 24 98 00 00 	cmp    0x98(%rsp),%rax
 1017ac2:	00 
 1017ac3:	0f 85 1e 01 00 00    	jne    1017be7 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xe47>
 1017ac9:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
 1017ad0:	00 
 1017ad1:	48 89 83 80 3d 00 00 	mov    %rax,0x3d80(%rbx)
 1017ad8:	31 c0                	xor    %eax,%eax
 1017ada:	31 d2                	xor    %edx,%edx
 1017adc:	e9 e8 00 00 00       	jmp    1017bc9 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xe29>
 1017ae1:	c5 f8 28 84 24 60 01 	vmovaps 0x160(%rsp),%xmm0
 1017ae8:	00 00 
 1017aea:	c5 f8 29 44 24 10    	vmovaps %xmm0,0x10(%rsp)
 1017af0:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
 1017af4:	c5 f8 29 44 24 20    	vmovaps %xmm0,0x20(%rsp)
 1017afa:	c7 44 24 48 00 00 00 	movl   $0x0,0x48(%rsp)
 1017b01:	00 
 1017b02:	48 c7 84 24 20 01 00 	movq   $0x100a308,0x120(%rsp)
 1017b09:	00 08 a3 00 01 
 1017b0e:	c7 84 24 38 01 00 00 	movl   $0x2,0x138(%rsp)
 1017b15:	02 00 00 00 
 1017b19:	c7 44 24 60 00 00 00 	movl   $0x0,0x60(%rsp)
 1017b20:	00 
 1017b21:	4c 39 a3 80 3d 00 00 	cmp    %r12,0x3d80(%rbx)
 1017b28:	0f 85 b9 00 00 00    	jne    1017be7 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xe47>
 1017b2e:	48 8b b4 24 98 00 00 	mov    0x98(%rsp),%rsi
 1017b35:	00 
 1017b36:	48 8d bb 58 02 00 00 	lea    0x258(%rbx),%rdi
 1017b3d:	e8 de f8 00 00       	call   1027420 <myl_rc_scope_unwind>
 1017b42:	4c 8b b4 24 90 00 00 	mov    0x90(%rsp),%r14
 1017b49:	00 
 1017b4a:	4d 85 f6             	test   %r14,%r14
 1017b4d:	74 3e                	je     1017b8d <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xded>
 1017b4f:	4d 89 f7             	mov    %r14,%r15
 1017b52:	49 c1 e7 05          	shl    $0x5,%r15
 1017b56:	49 83 c7 e0          	add    $0xffffffffffffffe0,%r15
 1017b5a:	eb 18                	jmp    1017b74 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xdd4>
 1017b5c:	0f 1f 40 00          	nopl   0x0(%rax)
 1017b60:	4c 01 fe             	add    %r15,%rsi
 1017b63:	48 89 df             	mov    %rbx,%rdi
 1017b66:	e8 65 52 00 00       	call   101cdd0 <myl_qbe_rc_slot_drop>
 1017b6b:	49 83 c7 e0          	add    $0xffffffffffffffe0,%r15
 1017b6f:	49 ff ce             	dec    %r14
 1017b72:	74 19                	je     1017b8d <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xded>
 1017b74:	48 8b b4 24 88 00 00 	mov    0x88(%rsp),%rsi
 1017b7b:	00 
 1017b7c:	4a 8b 44 3e 10       	mov    0x10(%rsi,%r15,1),%rax
 1017b81:	48 85 c0             	test   %rax,%rax
 1017b84:	74 da                	je     1017b60 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xdc0>
 1017b86:	83 38 00             	cmpl   $0x0,(%rax)
 1017b89:	75 d5                	jne    1017b60 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xdc0>
 1017b8b:	eb de                	jmp    1017b6b <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xdcb>
 1017b8d:	4c 39 a3 80 3d 00 00 	cmp    %r12,0x3d80(%rbx)
 1017b94:	75 51                	jne    1017be7 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xe47>
 1017b96:	48 8b 83 60 18 00 00 	mov    0x1860(%rbx),%rax
 1017b9d:	48 85 c0             	test   %rax,%rax
 1017ba0:	74 39                	je     1017bdb <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xe3b>
 1017ba2:	48 8b 40 70          	mov    0x70(%rax),%rax
 1017ba6:	48 3b 84 24 98 00 00 	cmp    0x98(%rsp),%rax
 1017bad:	00 
 1017bae:	75 37                	jne    1017be7 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xe47>
 1017bb0:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
 1017bb7:	00 
 1017bb8:	48 89 83 80 3d 00 00 	mov    %rax,0x3d80(%rbx)
 1017bbf:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
 1017bc4:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
 1017bc9:	48 81 c4 a8 01 00 00 	add    $0x1a8,%rsp
 1017bd0:	5b                   	pop    %rbx
 1017bd1:	41 5c                	pop    %r12
 1017bd3:	41 5d                	pop    %r13
 1017bd5:	41 5e                	pop    %r14
 1017bd7:	41 5f                	pop    %r15
 1017bd9:	5d                   	pop    %rbp
 1017bda:	c3                   	ret
 1017bdb:	31 c0                	xor    %eax,%eax
 1017bdd:	48 3b 84 24 98 00 00 	cmp    0x98(%rsp),%rax
 1017be4:	00 
 1017be5:	74 c9                	je     1017bb0 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xe10>
 1017be7:	c5 f8 77             	vzeroupper
 1017bea:	e8 f2 b4 00 00       	call   10230e1 <myl_rc_invariant_failed>
 1017bef:	e8 2c 66 01 00       	call   102e220 <abort@plt>
 1017bf4:	48 89 df             	mov    %rbx,%rdi
 1017bf7:	e8 94 62 00 00       	call   101de90 <myl_qbe_fail_allocation>
 1017bfc:	48 89 df             	mov    %rbx,%rdi
 1017bff:	e8 8c 63 00 00       	call   101df90 <myl_qbe_fail_frame>
 1017c04:	48 89 df             	mov    %rbx,%rdi
 1017c07:	e8 84 62 00 00       	call   101de90 <myl_qbe_fail_allocation>
 1017c0c:	be 01 00 00 00       	mov    $0x1,%esi
 1017c11:	b9 01 00 00 00       	mov    $0x1,%ecx
 1017c16:	48 89 df             	mov    %rbx,%rdi
 1017c19:	48 ba 00 00 00 00 00 	movabs $0x8000000000000000,%rdx
 1017c20:	00 00 80 
 1017c23:	c5 f8 77             	vzeroupper
 1017c26:	e8 f5 62 00 00       	call   101df20 <myl_qbe_fail_overflow_op>
 1017c2b:	be 01 00 00 00       	mov    $0x1,%esi
 1017c30:	b9 01 00 00 00       	mov    $0x1,%ecx
 1017c35:	48 89 df             	mov    %rbx,%rdi
 1017c38:	e8 e3 62 00 00       	call   101df20 <myl_qbe_fail_overflow_op>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
