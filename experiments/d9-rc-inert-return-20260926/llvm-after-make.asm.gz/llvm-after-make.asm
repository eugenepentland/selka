
.tmp-rc/profile/inert-return-final-llvm-rc-n12:     file format elf64-x86-64


Disassembly of section .text:

0000000001016d80 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531>:
 1016d80:	55                   	push   %rbp
 1016d81:	41 57                	push   %r15
 1016d83:	41 56                	push   %r14
 1016d85:	41 55                	push   %r13
 1016d87:	41 54                	push   %r12
 1016d89:	53                   	push   %rbx
 1016d8a:	48 81 ec 98 01 00 00 	sub    $0x198,%rsp
 1016d91:	48 89 fb             	mov    %rdi,%rbx
 1016d94:	48 39 67 40          	cmp    %rsp,0x40(%rdi)
 1016d98:	0f 87 30 0c 00 00    	ja     10179ce <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xc4e>
 1016d9e:	48 85 f6             	test   %rsi,%rsi
 1016da1:	0f 84 15 09 00 00    	je     10176bc <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x93c>
 1016da7:	48 89 b4 24 80 01 00 	mov    %rsi,0x180(%rsp)
 1016dae:	00 
 1016daf:	8b 83 c8 02 00 00    	mov    0x2c8(%rbx),%eax
 1016db5:	89 44 24 0c          	mov    %eax,0xc(%rsp)
 1016db9:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
 1016dbd:	c5 fc 11 44 24 70    	vmovups %ymm0,0x70(%rsp)
 1016dc3:	c5 fc 11 44 24 60    	vmovups %ymm0,0x60(%rsp)
 1016dc9:	48 8d 44 24 70       	lea    0x70(%rsp),%rax
 1016dce:	c5 fc 11 84 24 c8 00 	vmovups %ymm0,0xc8(%rsp)
 1016dd5:	00 00 
 1016dd7:	c5 fc 11 84 24 e8 00 	vmovups %ymm0,0xe8(%rsp)
 1016dde:	00 00 
 1016de0:	c5 fc 11 84 24 08 01 	vmovups %ymm0,0x108(%rsp)
 1016de7:	00 00 
 1016de9:	c5 fc 11 84 24 28 01 	vmovups %ymm0,0x128(%rsp)
 1016df0:	00 00 
 1016df2:	c5 fc 11 84 24 48 01 	vmovups %ymm0,0x148(%rsp)
 1016df9:	00 00 
 1016dfb:	48 c7 84 24 68 01 00 	movq   $0x0,0x168(%rsp)
 1016e02:	00 00 00 00 00 
 1016e07:	48 c7 84 24 b0 00 00 	movq   $0x1009850,0xb0(%rsp)
 1016e0e:	00 50 98 00 01 
 1016e13:	48 8d 8c 24 80 01 00 	lea    0x180(%rsp),%rcx
 1016e1a:	00 
 1016e1b:	48 89 8c 24 b8 00 00 	mov    %rcx,0xb8(%rsp)
 1016e22:	00 
 1016e23:	48 8d 4c 24 60       	lea    0x60(%rsp),%rcx
 1016e28:	48 89 8c 24 c0 00 00 	mov    %rcx,0xc0(%rsp)
 1016e2f:	00 
 1016e30:	48 c7 84 24 d0 00 00 	movq   $0x1009be8,0xd0(%rsp)
 1016e37:	00 e8 9b 00 01 
 1016e3c:	4c 8d a4 24 90 00 00 	lea    0x90(%rsp),%r12
 1016e43:	00 
 1016e44:	4c 89 a4 24 d8 00 00 	mov    %r12,0xd8(%rsp)
 1016e4b:	00 
 1016e4c:	48 8d 4c 24 68       	lea    0x68(%rsp),%rcx
 1016e51:	48 89 8c 24 e0 00 00 	mov    %rcx,0xe0(%rsp)
 1016e58:	00 
 1016e59:	48 c7 84 24 f0 00 00 	movq   $0x1009be8,0xf0(%rsp)
 1016e60:	00 e8 9b 00 01 
 1016e65:	48 8d 4c 24 30       	lea    0x30(%rsp),%rcx
 1016e6a:	48 89 8c 24 f8 00 00 	mov    %rcx,0xf8(%rsp)
 1016e71:	00 
 1016e72:	48 89 84 24 00 01 00 	mov    %rax,0x100(%rsp)
 1016e79:	00 
 1016e7a:	48 c7 84 24 10 01 00 	movq   $0x1009be8,0x110(%rsp)
 1016e81:	00 e8 9b 00 01 
 1016e86:	48 8d 84 24 90 01 00 	lea    0x190(%rsp),%rax
 1016e8d:	00 
 1016e8e:	48 89 84 24 18 01 00 	mov    %rax,0x118(%rsp)
 1016e95:	00 
 1016e96:	48 8d 44 24 78       	lea    0x78(%rsp),%rax
 1016e9b:	48 89 84 24 20 01 00 	mov    %rax,0x120(%rsp)
 1016ea2:	00 
 1016ea3:	48 c7 84 24 30 01 00 	movq   $0x1009be8,0x130(%rsp)
 1016eaa:	00 e8 9b 00 01 
 1016eaf:	4c 8d 6c 24 10       	lea    0x10(%rsp),%r13
 1016eb4:	4c 89 ac 24 38 01 00 	mov    %r13,0x138(%rsp)
 1016ebb:	00 
 1016ebc:	48 8d 84 24 80 00 00 	lea    0x80(%rsp),%rax
 1016ec3:	00 
 1016ec4:	48 89 84 24 40 01 00 	mov    %rax,0x140(%rsp)
 1016ecb:	00 
 1016ecc:	48 c7 84 24 50 01 00 	movq   $0x1009be8,0x150(%rsp)
 1016ed3:	00 e8 9b 00 01 
 1016ed8:	48 8d ac 24 88 01 00 	lea    0x188(%rsp),%rbp
 1016edf:	00 
 1016ee0:	48 89 ac 24 58 01 00 	mov    %rbp,0x158(%rsp)
 1016ee7:	00 
 1016ee8:	4c 8d b4 24 88 00 00 	lea    0x88(%rsp),%r14
 1016eef:	00 
 1016ef0:	4c 89 b4 24 60 01 00 	mov    %r14,0x160(%rsp)
 1016ef7:	00 
 1016ef8:	48 85 db             	test   %rbx,%rbx
 1016efb:	0f 84 b8 0a 00 00    	je     10179b9 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xc39>
 1016f01:	48 8b 83 60 18 00 00 	mov    0x1860(%rbx),%rax
 1016f08:	48 85 c0             	test   %rax,%rax
 1016f0b:	0f 84 a8 0a 00 00    	je     10179b9 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xc39>
 1016f11:	48 8b 8b 80 3d 00 00 	mov    0x3d80(%rbx),%rcx
 1016f18:	48 8b 40 70          	mov    0x70(%rax),%rax
 1016f1c:	48 89 4c 24 40       	mov    %rcx,0x40(%rsp)
 1016f21:	48 8d 8c 24 b0 00 00 	lea    0xb0(%rsp),%rcx
 1016f28:	00 
 1016f29:	48 89 4c 24 48       	mov    %rcx,0x48(%rsp)
 1016f2e:	48 c7 44 24 50 06 00 	movq   $0x6,0x50(%rsp)
 1016f35:	00 00 
 1016f37:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
 1016f3c:	48 8d 44 24 40       	lea    0x40(%rsp),%rax
 1016f41:	48 89 83 80 3d 00 00 	mov    %rax,0x3d80(%rbx)
 1016f48:	48 89 74 24 20       	mov    %rsi,0x20(%rsp)
 1016f4d:	48 c7 44 24 28 01 00 	movq   $0x1,0x28(%rsp)
 1016f54:	00 00 
 1016f56:	48 89 f0             	mov    %rsi,%rax
 1016f59:	48 f7 d8             	neg    %rax
 1016f5c:	0f 80 7c 0a 00 00    	jo     10179de <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xc5e>
 1016f62:	48 ff ce             	dec    %rsi
 1016f65:	48 89 74 24 20       	mov    %rsi,0x20(%rsp)
 1016f6a:	48 89 df             	mov    %rbx,%rdi
 1016f6d:	c5 f8 77             	vzeroupper
 1016f70:	e8 0b fe ff ff       	call   1016d80 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531>
 1016f75:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
 1016f7a:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
 1016f7f:	48 c7 84 24 30 01 00 	movq   $0x100a308,0x130(%rsp)
 1016f86:	00 08 a3 00 01 
 1016f8b:	c7 84 24 48 01 00 00 	movl   $0x2,0x148(%rsp)
 1016f92:	02 00 00 00 
 1016f96:	48 89 84 24 90 00 00 	mov    %rax,0x90(%rsp)
 1016f9d:	00 
 1016f9e:	48 89 94 24 98 00 00 	mov    %rdx,0x98(%rsp)
 1016fa5:	00 
 1016fa6:	48 c7 84 24 d0 00 00 	movq   $0x100a308,0xd0(%rsp)
 1016fad:	00 08 a3 00 01 
 1016fb2:	c7 84 24 e8 00 00 00 	movl   $0x2,0xe8(%rsp)
 1016fb9:	02 00 00 00 
 1016fbd:	c7 84 24 80 00 00 00 	movl   $0x0,0x80(%rsp)
 1016fc4:	00 00 00 00 
 1016fc8:	c7 44 24 68 01 00 00 	movl   $0x1,0x68(%rsp)
 1016fcf:	00 
 1016fd0:	4c 89 64 24 20       	mov    %r12,0x20(%rsp)
 1016fd5:	48 83 bb 60 18 00 00 	cmpq   $0x0,0x1860(%rbx)
 1016fdc:	00 
 1016fdd:	0f 84 e3 09 00 00    	je     10179c6 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xc46>
 1016fe3:	4d 89 e7             	mov    %r12,%r15
 1016fe6:	48 8d bb 58 02 00 00 	lea    0x258(%rbx),%rdi
 1016fed:	8b 8b c8 02 00 00    	mov    0x2c8(%rbx),%ecx
 1016ff3:	be c0 98 00 01       	mov    $0x10098c0,%esi
 1016ff8:	ba 01 00 00 00       	mov    $0x1,%edx
 1016ffd:	e8 6e 20 01 00       	call   1029070 <myl_rc_storage_alloc>
 1017002:	48 85 c0             	test   %rax,%rax
 1017005:	0f 84 bb 09 00 00    	je     10179c6 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xc46>
 101700b:	49 89 c4             	mov    %rax,%r12
 101700e:	48 89 84 24 88 01 00 	mov    %rax,0x188(%rsp)
 1017015:	00 
 1017016:	48 c7 84 24 50 01 00 	movq   $0x1009930,0x150(%rsp)
 101701d:	00 30 99 00 01 
 1017022:	48 89 ac 24 58 01 00 	mov    %rbp,0x158(%rsp)
 1017029:	00 
 101702a:	4c 89 b4 24 60 01 00 	mov    %r14,0x160(%rsp)
 1017031:	00 
 1017032:	c7 84 24 68 01 00 00 	movl   $0x4,0x168(%rsp)
 1017039:	04 00 00 00 
 101703d:	c7 84 24 88 00 00 00 	movl   $0x1,0x88(%rsp)
 1017044:	01 00 00 00 
 1017048:	48 8b 4c 24 20       	mov    0x20(%rsp),%rcx
 101704d:	48 89 c8             	mov    %rcx,%rax
 1017050:	4c 29 e8             	sub    %r13,%rax
 1017053:	4c 89 ea             	mov    %r13,%rdx
 1017056:	48 29 ca             	sub    %rcx,%rdx
 1017059:	48 83 f8 10          	cmp    $0x10,%rax
 101705d:	0f 92 c0             	setb   %al
 1017060:	48 83 fa 10          	cmp    $0x10,%rdx
 1017064:	0f 92 c2             	setb   %dl
 1017067:	08 c2                	or     %al,%dl
 1017069:	75 31                	jne    101709c <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x31c>
 101706b:	48 8b 01             	mov    (%rcx),%rax
 101706e:	48 85 c0             	test   %rax,%rax
 1017071:	74 10                	je     1017083 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x303>
 1017073:	48 ba 01 00 00 00 00 	movabs $0x5000000000000001,%rdx
 101707a:	00 00 50 
 101707d:	48 85 50 f0          	test   %rdx,-0x10(%rax)
 1017081:	75 19                	jne    101709c <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x31c>
 1017083:	48 8b 41 08          	mov    0x8(%rcx),%rax
 1017087:	48 85 c0             	test   %rax,%rax
 101708a:	74 34                	je     10170c0 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x340>
 101708c:	48 ba 01 00 00 00 00 	movabs $0x5000000000000001,%rdx
 1017093:	00 00 50 
 1017096:	48 85 50 f0          	test   %rdx,-0x10(%rax)
 101709a:	74 24                	je     10170c0 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x340>
 101709c:	48 8d 54 24 10       	lea    0x10(%rsp),%rdx
 10170a1:	be 08 a3 00 01       	mov    $0x100a308,%esi
 10170a6:	48 8d bb 58 02 00 00 	lea    0x258(%rbx),%rdi
 10170ad:	44 8b 44 24 0c       	mov    0xc(%rsp),%r8d
 10170b2:	e8 19 37 01 00       	call   102a7d0 <myl_rc_native_take>
 10170b7:	85 c0                	test   %eax,%eax
 10170b9:	75 17                	jne    10170d2 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x352>
 10170bb:	e9 00 05 00 00       	jmp    10175c0 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x840>
 10170c0:	c5 f8 10 01          	vmovups (%rcx),%xmm0
 10170c4:	c5 f8 29 44 24 10    	vmovaps %xmm0,0x10(%rsp)
 10170ca:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
 10170ce:	c5 f8 11 01          	vmovups %xmm0,(%rcx)
 10170d2:	48 c7 84 24 30 01 00 	movq   $0x100a308,0x130(%rsp)
 10170d9:	00 08 a3 00 01 
 10170de:	c7 84 24 48 01 00 00 	movl   $0x2,0x148(%rsp)
 10170e5:	02 00 00 00 
 10170e9:	c5 f8 28 44 24 10    	vmovaps 0x10(%rsp),%xmm0
 10170ef:	c4 c1 78 11 04 24    	vmovups %xmm0,(%r12)
 10170f5:	c7 84 24 80 00 00 00 	movl   $0x0,0x80(%rsp)
 10170fc:	00 00 00 00 
 1017100:	4c 89 a4 24 90 00 00 	mov    %r12,0x90(%rsp)
 1017107:	00 
 1017108:	48 c7 84 24 d0 00 00 	movq   $0x1009930,0xd0(%rsp)
 101710f:	00 30 99 00 01 
 1017114:	c7 84 24 e8 00 00 00 	movl   $0x2,0xe8(%rsp)
 101711b:	02 00 00 00 
 101711f:	c7 44 24 68 01 00 00 	movl   $0x1,0x68(%rsp)
 1017126:	00 
 1017127:	4c 89 64 24 20       	mov    %r12,0x20(%rsp)
 101712c:	48 c7 84 24 78 01 00 	movq   $0x0,0x178(%rsp)
 1017133:	00 00 00 00 00 
 1017138:	48 c7 84 24 50 01 00 	movq   $0x1009fd8,0x150(%rsp)
 101713f:	00 d8 9f 00 01 
 1017144:	c7 84 24 68 01 00 00 	movl   $0x2,0x168(%rsp)
 101714b:	02 00 00 00 
 101714f:	48 8d 84 24 78 01 00 	lea    0x178(%rsp),%rax
 1017156:	00 
 1017157:	48 89 84 24 58 01 00 	mov    %rax,0x158(%rsp)
 101715e:	00 
 101715f:	4c 89 b4 24 60 01 00 	mov    %r14,0x160(%rsp)
 1017166:	00 
 1017167:	c7 84 24 88 00 00 00 	movl   $0x1,0x88(%rsp)
 101716e:	01 00 00 00 
 1017172:	48 b8 01 00 00 00 00 	movabs $0x5000000000000001,%rax
 1017179:	00 00 50 
 101717c:	49 85 44 24 f0       	test   %rax,-0x10(%r12)
 1017181:	74 2f                	je     10171b2 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x432>
 1017183:	48 8d 54 24 10       	lea    0x10(%rsp),%rdx
 1017188:	48 8d 4c 24 20       	lea    0x20(%rsp),%rcx
 101718d:	be 30 99 00 01       	mov    $0x1009930,%esi
 1017192:	48 8d bb 58 02 00 00 	lea    0x258(%rbx),%rdi
 1017199:	44 8b 44 24 0c       	mov    0xc(%rsp),%r8d
 101719e:	e8 2d 36 01 00       	call   102a7d0 <myl_rc_native_take>
 10171a3:	85 c0                	test   %eax,%eax
 10171a5:	0f 84 15 04 00 00    	je     10175c0 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x840>
 10171ab:	4c 8b 64 24 10       	mov    0x10(%rsp),%r12
 10171b0:	eb 05                	jmp    10171b7 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x437>
 10171b2:	4c 89 64 24 10       	mov    %r12,0x10(%rsp)
 10171b7:	48 c7 84 24 30 01 00 	movq   $0x1009930,0x130(%rsp)
 10171be:	00 30 99 00 01 
 10171c3:	c7 84 24 48 01 00 00 	movl   $0x2,0x148(%rsp)
 10171ca:	02 00 00 00 
 10171ce:	4c 89 a4 24 78 01 00 	mov    %r12,0x178(%rsp)
 10171d5:	00 
 10171d6:	c7 84 24 80 00 00 00 	movl   $0x0,0x80(%rsp)
 10171dd:	00 00 00 00 
 10171e1:	4c 89 a4 24 90 00 00 	mov    %r12,0x90(%rsp)
 10171e8:	00 
 10171e9:	48 c7 84 24 d0 00 00 	movq   $0x1009fd8,0xd0(%rsp)
 10171f0:	00 d8 9f 00 01 
 10171f5:	c7 84 24 e8 00 00 00 	movl   $0x2,0xe8(%rsp)
 10171fc:	02 00 00 00 
 1017200:	c7 44 24 68 01 00 00 	movl   $0x1,0x68(%rsp)
 1017207:	00 
 1017208:	4c 89 7c 24 20       	mov    %r15,0x20(%rsp)
 101720d:	c7 84 24 88 00 00 00 	movl   $0x0,0x88(%rsp)
 1017214:	00 00 00 00 
 1017218:	48 8b b4 24 80 01 00 	mov    0x180(%rsp),%rsi
 101721f:	00 
 1017220:	48 89 74 24 28       	mov    %rsi,0x28(%rsp)
 1017225:	48 ba 00 00 00 00 00 	movabs $0x8000000000000000,%rdx
 101722c:	00 00 80 
 101722f:	48 39 d6             	cmp    %rdx,%rsi
 1017232:	0f 84 c5 07 00 00    	je     10179fd <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xc7d>
 1017238:	4d 89 fc             	mov    %r15,%r12
 101723b:	48 ff ce             	dec    %rsi
 101723e:	48 89 74 24 28       	mov    %rsi,0x28(%rsp)
 1017243:	48 89 df             	mov    %rbx,%rdi
 1017246:	e8 35 fb ff ff       	call   1016d80 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531>
 101724b:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
 1017250:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
 1017255:	48 c7 84 24 30 01 00 	movq   $0x100a308,0x130(%rsp)
 101725c:	00 08 a3 00 01 
 1017261:	c7 84 24 48 01 00 00 	movl   $0x2,0x148(%rsp)
 1017268:	02 00 00 00 
 101726c:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
 1017271:	48 89 54 24 38       	mov    %rdx,0x38(%rsp)
 1017276:	48 c7 84 24 f0 00 00 	movq   $0x100a308,0xf0(%rsp)
 101727d:	00 08 a3 00 01 
 1017282:	c7 84 24 08 01 00 00 	movl   $0x2,0x108(%rsp)
 1017289:	02 00 00 00 
 101728d:	c7 84 24 80 00 00 00 	movl   $0x0,0x80(%rsp)
 1017294:	00 00 00 00 
 1017298:	c7 44 24 70 01 00 00 	movl   $0x1,0x70(%rsp)
 101729f:	00 
 10172a0:	48 8d 44 24 30       	lea    0x30(%rsp),%rax
 10172a5:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
 10172aa:	48 83 bb 60 18 00 00 	cmpq   $0x0,0x1860(%rbx)
 10172b1:	00 
 10172b2:	0f 84 1e 07 00 00    	je     10179d6 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xc56>
 10172b8:	8b 8b c8 02 00 00    	mov    0x2c8(%rbx),%ecx
 10172be:	be c0 98 00 01       	mov    $0x10098c0,%esi
 10172c3:	ba 01 00 00 00       	mov    $0x1,%edx
 10172c8:	48 8d bb 58 02 00 00 	lea    0x258(%rbx),%rdi
 10172cf:	e8 9c 1d 01 00       	call   1029070 <myl_rc_storage_alloc>
 10172d4:	48 85 c0             	test   %rax,%rax
 10172d7:	0f 84 f9 06 00 00    	je     10179d6 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xc56>
 10172dd:	49 89 c7             	mov    %rax,%r15
 10172e0:	48 89 84 24 88 01 00 	mov    %rax,0x188(%rsp)
 10172e7:	00 
 10172e8:	48 c7 84 24 50 01 00 	movq   $0x1009930,0x150(%rsp)
 10172ef:	00 30 99 00 01 
 10172f4:	48 89 ac 24 58 01 00 	mov    %rbp,0x158(%rsp)
 10172fb:	00 
 10172fc:	4c 89 b4 24 60 01 00 	mov    %r14,0x160(%rsp)
 1017303:	00 
 1017304:	c7 84 24 68 01 00 00 	movl   $0x4,0x168(%rsp)
 101730b:	04 00 00 00 
 101730f:	c7 84 24 88 00 00 00 	movl   $0x1,0x88(%rsp)
 1017316:	01 00 00 00 
 101731a:	48 8d 54 24 30       	lea    0x30(%rsp),%rdx
 101731f:	48 89 d0             	mov    %rdx,%rax
 1017322:	4c 29 e8             	sub    %r13,%rax
 1017325:	4c 89 e9             	mov    %r13,%rcx
 1017328:	48 29 d1             	sub    %rdx,%rcx
 101732b:	48 83 f8 10          	cmp    $0x10,%rax
 101732f:	0f 92 c0             	setb   %al
 1017332:	48 83 f9 10          	cmp    $0x10,%rcx
 1017336:	0f 92 c1             	setb   %cl
 1017339:	08 c1                	or     %al,%cl
 101733b:	75 34                	jne    1017371 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x5f1>
 101733d:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
 1017342:	48 85 c0             	test   %rax,%rax
 1017345:	74 10                	je     1017357 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x5d7>
 1017347:	48 b9 01 00 00 00 00 	movabs $0x5000000000000001,%rcx
 101734e:	00 00 50 
 1017351:	48 85 48 f0          	test   %rcx,-0x10(%rax)
 1017355:	75 1a                	jne    1017371 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x5f1>
 1017357:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
 101735c:	48 85 c0             	test   %rax,%rax
 101735f:	74 39                	je     101739a <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x61a>
 1017361:	48 b9 01 00 00 00 00 	movabs $0x5000000000000001,%rcx
 1017368:	00 00 50 
 101736b:	48 85 48 f0          	test   %rcx,-0x10(%rax)
 101736f:	74 29                	je     101739a <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x61a>
 1017371:	48 8d 54 24 10       	lea    0x10(%rsp),%rdx
 1017376:	48 8d 4c 24 30       	lea    0x30(%rsp),%rcx
 101737b:	be 08 a3 00 01       	mov    $0x100a308,%esi
 1017380:	48 8d bb 58 02 00 00 	lea    0x258(%rbx),%rdi
 1017387:	44 8b 44 24 0c       	mov    0xc(%rsp),%r8d
 101738c:	e8 3f 34 01 00       	call   102a7d0 <myl_rc_native_take>
 1017391:	85 c0                	test   %eax,%eax
 1017393:	75 1a                	jne    10173af <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x62f>
 1017395:	e9 26 02 00 00       	jmp    10175c0 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x840>
 101739a:	c5 f8 10 44 24 30    	vmovups 0x30(%rsp),%xmm0
 10173a0:	c5 f8 29 44 24 10    	vmovaps %xmm0,0x10(%rsp)
 10173a6:	48 c7 44 24 38 00 00 	movq   $0x0,0x38(%rsp)
 10173ad:	00 00 
 10173af:	48 c7 84 24 30 01 00 	movq   $0x100a308,0x130(%rsp)
 10173b6:	00 08 a3 00 01 
 10173bb:	c7 84 24 48 01 00 00 	movl   $0x2,0x148(%rsp)
 10173c2:	02 00 00 00 
 10173c6:	c5 f8 28 44 24 10    	vmovaps 0x10(%rsp),%xmm0
 10173cc:	c4 c1 78 11 07       	vmovups %xmm0,(%r15)
 10173d1:	c7 84 24 80 00 00 00 	movl   $0x0,0x80(%rsp)
 10173d8:	00 00 00 00 
 10173dc:	4c 89 7c 24 30       	mov    %r15,0x30(%rsp)
 10173e1:	48 c7 84 24 f0 00 00 	movq   $0x1009930,0xf0(%rsp)
 10173e8:	00 30 99 00 01 
 10173ed:	c7 84 24 08 01 00 00 	movl   $0x2,0x108(%rsp)
 10173f4:	02 00 00 00 
 10173f8:	c7 44 24 70 01 00 00 	movl   $0x1,0x70(%rsp)
 10173ff:	00 
 1017400:	4c 89 7c 24 28       	mov    %r15,0x28(%rsp)
 1017405:	48 c7 84 24 70 01 00 	movq   $0x0,0x170(%rsp)
 101740c:	00 00 00 00 00 
 1017411:	48 c7 84 24 50 01 00 	movq   $0x1009fd8,0x150(%rsp)
 1017418:	00 d8 9f 00 01 
 101741d:	c7 84 24 68 01 00 00 	movl   $0x2,0x168(%rsp)
 1017424:	02 00 00 00 
 1017428:	48 8d 84 24 70 01 00 	lea    0x170(%rsp),%rax
 101742f:	00 
 1017430:	48 89 84 24 58 01 00 	mov    %rax,0x158(%rsp)
 1017437:	00 
 1017438:	4c 89 b4 24 60 01 00 	mov    %r14,0x160(%rsp)
 101743f:	00 
 1017440:	c7 84 24 88 00 00 00 	movl   $0x1,0x88(%rsp)
 1017447:	01 00 00 00 
 101744b:	48 b8 01 00 00 00 00 	movabs $0x5000000000000001,%rax
 1017452:	00 00 50 
 1017455:	49 85 47 f0          	test   %rax,-0x10(%r15)
 1017459:	74 2f                	je     101748a <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x70a>
 101745b:	48 8d 54 24 10       	lea    0x10(%rsp),%rdx
 1017460:	48 8d 4c 24 28       	lea    0x28(%rsp),%rcx
 1017465:	be 30 99 00 01       	mov    $0x1009930,%esi
 101746a:	48 8d bb 58 02 00 00 	lea    0x258(%rbx),%rdi
 1017471:	44 8b 44 24 0c       	mov    0xc(%rsp),%r8d
 1017476:	e8 55 33 01 00       	call   102a7d0 <myl_rc_native_take>
 101747b:	85 c0                	test   %eax,%eax
 101747d:	0f 84 3d 01 00 00    	je     10175c0 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x840>
 1017483:	4c 8b 7c 24 10       	mov    0x10(%rsp),%r15
 1017488:	eb 05                	jmp    101748f <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x70f>
 101748a:	4c 89 7c 24 10       	mov    %r15,0x10(%rsp)
 101748f:	48 c7 84 24 30 01 00 	movq   $0x1009930,0x130(%rsp)
 1017496:	00 30 99 00 01 
 101749b:	c7 84 24 48 01 00 00 	movl   $0x2,0x148(%rsp)
 10174a2:	02 00 00 00 
 10174a6:	4c 89 bc 24 70 01 00 	mov    %r15,0x170(%rsp)
 10174ad:	00 
 10174ae:	c7 84 24 80 00 00 00 	movl   $0x0,0x80(%rsp)
 10174b5:	00 00 00 00 
 10174b9:	4c 89 7c 24 30       	mov    %r15,0x30(%rsp)
 10174be:	48 c7 84 24 f0 00 00 	movq   $0x1009fd8,0xf0(%rsp)
 10174c5:	00 d8 9f 00 01 
 10174ca:	c7 84 24 08 01 00 00 	movl   $0x2,0x108(%rsp)
 10174d1:	02 00 00 00 
 10174d5:	c7 44 24 70 01 00 00 	movl   $0x1,0x70(%rsp)
 10174dc:	00 
 10174dd:	48 8d 44 24 30       	lea    0x30(%rsp),%rax
 10174e2:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
 10174e7:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
 10174eb:	c5 f8 29 84 24 a0 00 	vmovaps %xmm0,0xa0(%rsp)
 10174f2:	00 00 
 10174f4:	48 c7 84 24 50 01 00 	movq   $0x100a308,0x150(%rsp)
 10174fb:	00 08 a3 00 01 
 1017500:	c7 84 24 68 01 00 00 	movl   $0x2,0x168(%rsp)
 1017507:	02 00 00 00 
 101750b:	48 8d 84 24 a0 00 00 	lea    0xa0(%rsp),%rax
 1017512:	00 
 1017513:	48 89 84 24 58 01 00 	mov    %rax,0x158(%rsp)
 101751a:	00 
 101751b:	4c 89 b4 24 60 01 00 	mov    %r14,0x160(%rsp)
 1017522:	00 
 1017523:	c7 84 24 88 00 00 00 	movl   $0x1,0x88(%rsp)
 101752a:	01 00 00 00 
 101752e:	48 8b 4c 24 20       	mov    0x20(%rsp),%rcx
 1017533:	83 7c 24 68 00       	cmpl   $0x0,0x68(%rsp)
 1017538:	74 63                	je     101759d <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x81d>
 101753a:	48 89 c8             	mov    %rcx,%rax
 101753d:	4c 29 e8             	sub    %r13,%rax
 1017540:	4c 89 ea             	mov    %r13,%rdx
 1017543:	48 29 ca             	sub    %rcx,%rdx
 1017546:	48 83 f8 08          	cmp    $0x8,%rax
 101754a:	0f 92 c0             	setb   %al
 101754d:	48 83 fa 08          	cmp    $0x8,%rdx
 1017551:	0f 92 c2             	setb   %dl
 1017554:	08 c2                	or     %al,%dl
 1017556:	75 20                	jne    1017578 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x7f8>
 1017558:	48 8b 01             	mov    (%rcx),%rax
 101755b:	48 85 c0             	test   %rax,%rax
 101755e:	0f 84 6e 01 00 00    	je     10176d2 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x952>
 1017564:	48 ba 01 00 00 00 00 	movabs $0x5000000000000001,%rdx
 101756b:	00 00 50 
 101756e:	48 85 50 f0          	test   %rdx,-0x10(%rax)
 1017572:	0f 84 5a 01 00 00    	je     10176d2 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x952>
 1017578:	48 8d 54 24 10       	lea    0x10(%rsp),%rdx
 101757d:	be d8 9f 00 01       	mov    $0x1009fd8,%esi
 1017582:	48 8d bb 58 02 00 00 	lea    0x258(%rbx),%rdi
 1017589:	44 8b 44 24 0c       	mov    0xc(%rsp),%r8d
 101758e:	e8 3d 32 01 00       	call   102a7d0 <myl_rc_native_take>
 1017593:	85 c0                	test   %eax,%eax
 1017595:	0f 85 43 01 00 00    	jne    10176de <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x95e>
 101759b:	eb 23                	jmp    10175c0 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x840>
 101759d:	48 8d 54 24 10       	lea    0x10(%rsp),%rdx
 10175a2:	be d8 9f 00 01       	mov    $0x1009fd8,%esi
 10175a7:	48 8d bb 58 02 00 00 	lea    0x258(%rbx),%rdi
 10175ae:	44 8b 44 24 0c       	mov    0xc(%rsp),%r8d
 10175b3:	e8 a8 2c 01 00       	call   102a260 <myl_rc_native_copy>
 10175b8:	85 c0                	test   %eax,%eax
 10175ba:	0f 85 26 01 00 00    	jne    10176e6 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x966>
 10175c0:	48 8b 8b 60 18 00 00 	mov    0x1860(%rbx),%rcx
 10175c7:	48 85 c9             	test   %rcx,%rcx
 10175ca:	0f 84 e9 03 00 00    	je     10179b9 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xc39>
 10175d0:	8b 41 78             	mov    0x78(%rcx),%eax
 10175d3:	c7 41 78 00 00 00 00 	movl   $0x0,0x78(%rcx)
 10175da:	85 c0                	test   %eax,%eax
 10175dc:	4c 8d 64 24 40       	lea    0x40(%rsp),%r12
 10175e1:	74 35                	je     1017618 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x898>
 10175e3:	83 f8 01             	cmp    $0x1,%eax
 10175e6:	75 15                	jne    10175fd <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x87d>
 10175e8:	be 5f 74 00 01       	mov    $0x100745f,%esi
 10175ed:	83 bb c4 02 00 00 00 	cmpl   $0x0,0x2c4(%rbx)
 10175f4:	75 1a                	jne    1017610 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x890>
 10175f6:	b8 01 00 00 00       	mov    $0x1,%eax
 10175fb:	eb 09                	jmp    1017606 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x886>
 10175fd:	83 f8 04             	cmp    $0x4,%eax
 1017600:	0f 83 bb 03 00 00    	jae    10179c1 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xc41>
 1017606:	89 c0                	mov    %eax,%eax
 1017608:	48 8b 34 c5 d0 d2 00 	mov    0x100d2d0(,%rax,8),%rsi
 101760f:	01 
 1017610:	48 89 df             	mov    %rbx,%rdi
 1017613:	e8 98 5f 00 00       	call   101d5b0 <fail>
 1017618:	4c 39 a3 80 3d 00 00 	cmp    %r12,0x3d80(%rbx)
 101761f:	0f 85 94 03 00 00    	jne    10179b9 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xc39>
 1017625:	48 8b 74 24 58       	mov    0x58(%rsp),%rsi
 101762a:	48 8d bb 58 02 00 00 	lea    0x258(%rbx),%rdi
 1017631:	e8 ba fb 00 00       	call   10271f0 <myl_rc_scope_unwind>
 1017636:	4c 8b 74 24 50       	mov    0x50(%rsp),%r14
 101763b:	4d 85 f6             	test   %r14,%r14
 101763e:	74 3a                	je     101767a <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x8fa>
 1017640:	4d 89 f7             	mov    %r14,%r15
 1017643:	49 c1 e7 05          	shl    $0x5,%r15
 1017647:	49 83 c7 e0          	add    $0xffffffffffffffe0,%r15
 101764b:	eb 17                	jmp    1017664 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x8e4>
 101764d:	0f 1f 00             	nopl   (%rax)
 1017650:	4c 01 fe             	add    %r15,%rsi
 1017653:	48 89 df             	mov    %rbx,%rdi
 1017656:	e8 45 55 00 00       	call   101cba0 <myl_qbe_rc_slot_drop>
 101765b:	49 83 c7 e0          	add    $0xffffffffffffffe0,%r15
 101765f:	49 ff ce             	dec    %r14
 1017662:	74 16                	je     101767a <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x8fa>
 1017664:	48 8b 74 24 48       	mov    0x48(%rsp),%rsi
 1017669:	4a 8b 44 3e 10       	mov    0x10(%rsi,%r15,1),%rax
 101766e:	48 85 c0             	test   %rax,%rax
 1017671:	74 dd                	je     1017650 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x8d0>
 1017673:	83 38 00             	cmpl   $0x0,(%rax)
 1017676:	75 d8                	jne    1017650 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x8d0>
 1017678:	eb e1                	jmp    101765b <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x8db>
 101767a:	4c 39 a3 80 3d 00 00 	cmp    %r12,0x3d80(%rbx)
 1017681:	0f 85 32 03 00 00    	jne    10179b9 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xc39>
 1017687:	48 8b 83 60 18 00 00 	mov    0x1860(%rbx),%rax
 101768e:	48 85 c0             	test   %rax,%rax
 1017691:	74 10                	je     10176a3 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x923>
 1017693:	48 8b 40 70          	mov    0x70(%rax),%rax
 1017697:	48 3b 44 24 58       	cmp    0x58(%rsp),%rax
 101769c:	74 12                	je     10176b0 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x930>
 101769e:	e9 16 03 00 00       	jmp    10179b9 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xc39>
 10176a3:	31 c0                	xor    %eax,%eax
 10176a5:	48 3b 44 24 58       	cmp    0x58(%rsp),%rax
 10176aa:	0f 85 09 03 00 00    	jne    10179b9 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xc39>
 10176b0:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
 10176b5:	48 89 83 80 3d 00 00 	mov    %rax,0x3d80(%rbx)
 10176bc:	31 c0                	xor    %eax,%eax
 10176be:	31 d2                	xor    %edx,%edx
 10176c0:	48 81 c4 98 01 00 00 	add    $0x198,%rsp
 10176c7:	5b                   	pop    %rbx
 10176c8:	41 5c                	pop    %r12
 10176ca:	41 5d                	pop    %r13
 10176cc:	41 5e                	pop    %r14
 10176ce:	41 5f                	pop    %r15
 10176d0:	5d                   	pop    %rbp
 10176d1:	c3                   	ret
 10176d2:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
 10176d7:	48 c7 01 00 00 00 00 	movq   $0x0,(%rcx)
 10176de:	c7 44 24 68 00 00 00 	movl   $0x0,0x68(%rsp)
 10176e5:	00 
 10176e6:	48 c7 84 24 30 01 00 	movq   $0x1009fd8,0x130(%rsp)
 10176ed:	00 d8 9f 00 01 
 10176f2:	c7 84 24 48 01 00 00 	movl   $0x2,0x148(%rsp)
 10176f9:	02 00 00 00 
 10176fd:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
 1017702:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
 1017709:	00 
 101770a:	c7 84 24 80 00 00 00 	movl   $0x0,0x80(%rsp)
 1017711:	00 00 00 00 
 1017715:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
 101771a:	48 89 c8             	mov    %rcx,%rax
 101771d:	4c 29 e8             	sub    %r13,%rax
 1017720:	4c 89 ea             	mov    %r13,%rdx
 1017723:	48 29 ca             	sub    %rcx,%rdx
 1017726:	48 83 f8 08          	cmp    $0x8,%rax
 101772a:	0f 92 c0             	setb   %al
 101772d:	48 83 fa 08          	cmp    $0x8,%rdx
 1017731:	0f 92 c2             	setb   %dl
 1017734:	08 c2                	or     %al,%dl
 1017736:	75 18                	jne    1017750 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x9d0>
 1017738:	48 8b 01             	mov    (%rcx),%rax
 101773b:	48 85 c0             	test   %rax,%rax
 101773e:	74 49                	je     1017789 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xa09>
 1017740:	48 ba 01 00 00 00 00 	movabs $0x5000000000000001,%rdx
 1017747:	00 00 50 
 101774a:	48 85 50 f0          	test   %rdx,-0x10(%rax)
 101774e:	74 39                	je     1017789 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xa09>
 1017750:	48 8d 54 24 10       	lea    0x10(%rsp),%rdx
 1017755:	be d8 9f 00 01       	mov    $0x1009fd8,%esi
 101775a:	48 8d bb 58 02 00 00 	lea    0x258(%rbx),%rdi
 1017761:	44 8b 44 24 0c       	mov    0xc(%rsp),%r8d
 1017766:	e8 65 30 01 00       	call   102a7d0 <myl_rc_native_take>
 101776b:	85 c0                	test   %eax,%eax
 101776d:	75 26                	jne    1017795 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xa15>
 101776f:	48 8b 8b 60 18 00 00 	mov    0x1860(%rbx),%rcx
 1017776:	48 85 c9             	test   %rcx,%rcx
 1017779:	4c 8d 64 24 40       	lea    0x40(%rsp),%r12
 101777e:	0f 85 28 01 00 00    	jne    10178ac <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xb2c>
 1017784:	e9 30 02 00 00       	jmp    10179b9 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xc39>
 1017789:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
 101778e:	48 c7 01 00 00 00 00 	movq   $0x0,(%rcx)
 1017795:	c7 44 24 70 00 00 00 	movl   $0x0,0x70(%rsp)
 101779c:	00 
 101779d:	48 c7 84 24 30 01 00 	movq   $0x1009fd8,0x130(%rsp)
 10177a4:	00 d8 9f 00 01 
 10177a9:	c7 84 24 48 01 00 00 	movl   $0x2,0x148(%rsp)
 10177b0:	02 00 00 00 
 10177b4:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
 10177b9:	48 89 84 24 a8 00 00 	mov    %rax,0xa8(%rsp)
 10177c0:	00 
 10177c1:	c7 84 24 80 00 00 00 	movl   $0x0,0x80(%rsp)
 10177c8:	00 00 00 00 
 10177cc:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
 10177d3:	00 
 10177d4:	48 89 84 24 90 00 00 	mov    %rax,0x90(%rsp)
 10177db:	00 
 10177dc:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
 10177e3:	00 
 10177e4:	48 89 84 24 98 00 00 	mov    %rax,0x98(%rsp)
 10177eb:	00 
 10177ec:	48 c7 84 24 d0 00 00 	movq   $0x100a308,0xd0(%rsp)
 10177f3:	00 08 a3 00 01 
 10177f8:	c7 84 24 e8 00 00 00 	movl   $0x2,0xe8(%rsp)
 10177ff:	02 00 00 00 
 1017803:	c7 44 24 68 01 00 00 	movl   $0x1,0x68(%rsp)
 101780a:	00 
 101780b:	4c 89 64 24 20       	mov    %r12,0x20(%rsp)
 1017810:	c7 84 24 88 00 00 00 	movl   $0x0,0x88(%rsp)
 1017817:	00 00 00 00 
 101781b:	4c 89 e0             	mov    %r12,%rax
 101781e:	4c 29 e8             	sub    %r13,%rax
 1017821:	4d 29 e5             	sub    %r12,%r13
 1017824:	48 83 f8 10          	cmp    $0x10,%rax
 1017828:	0f 92 c0             	setb   %al
 101782b:	49 83 fd 10          	cmp    $0x10,%r13
 101782f:	0f 92 c1             	setb   %cl
 1017832:	08 c1                	or     %al,%cl
 1017834:	75 3a                	jne    1017870 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xaf0>
 1017836:	48 8b 84 24 90 00 00 	mov    0x90(%rsp),%rax
 101783d:	00 
 101783e:	48 85 c0             	test   %rax,%rax
 1017841:	74 10                	je     1017853 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xad3>
 1017843:	48 b9 01 00 00 00 00 	movabs $0x5000000000000001,%rcx
 101784a:	00 00 50 
 101784d:	48 85 48 f0          	test   %rcx,-0x10(%rax)
 1017851:	75 1d                	jne    1017870 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xaf0>
 1017853:	48 8b 84 24 98 00 00 	mov    0x98(%rsp),%rax
 101785a:	00 
 101785b:	48 85 c0             	test   %rax,%rax
 101785e:	74 63                	je     10178c3 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xb43>
 1017860:	48 b9 01 00 00 00 00 	movabs $0x5000000000000001,%rcx
 1017867:	00 00 50 
 101786a:	48 85 48 f0          	test   %rcx,-0x10(%rax)
 101786e:	74 53                	je     10178c3 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xb43>
 1017870:	48 8d 54 24 10       	lea    0x10(%rsp),%rdx
 1017875:	48 8d 8c 24 90 00 00 	lea    0x90(%rsp),%rcx
 101787c:	00 
 101787d:	be 08 a3 00 01       	mov    $0x100a308,%esi
 1017882:	48 8d bb 58 02 00 00 	lea    0x258(%rbx),%rdi
 1017889:	44 8b 44 24 0c       	mov    0xc(%rsp),%r8d
 101788e:	e8 3d 2f 01 00       	call   102a7d0 <myl_rc_native_take>
 1017893:	85 c0                	test   %eax,%eax
 1017895:	4c 8d 64 24 40       	lea    0x40(%rsp),%r12
 101789a:	75 48                	jne    10178e4 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xb64>
 101789c:	48 8b 8b 60 18 00 00 	mov    0x1860(%rbx),%rcx
 10178a3:	48 85 c9             	test   %rcx,%rcx
 10178a6:	0f 84 0d 01 00 00    	je     10179b9 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xc39>
 10178ac:	8b 41 78             	mov    0x78(%rcx),%eax
 10178af:	c7 41 78 00 00 00 00 	movl   $0x0,0x78(%rcx)
 10178b6:	85 c0                	test   %eax,%eax
 10178b8:	0f 85 25 fd ff ff    	jne    10175e3 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x863>
 10178be:	e9 55 fd ff ff       	jmp    1017618 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x898>
 10178c3:	c5 f8 28 84 24 a0 00 	vmovaps 0xa0(%rsp),%xmm0
 10178ca:	00 00 
 10178cc:	c5 f8 29 44 24 10    	vmovaps %xmm0,0x10(%rsp)
 10178d2:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
 10178d6:	c5 f8 29 84 24 90 00 	vmovaps %xmm0,0x90(%rsp)
 10178dd:	00 00 
 10178df:	4c 8d 64 24 40       	lea    0x40(%rsp),%r12
 10178e4:	c7 44 24 68 00 00 00 	movl   $0x0,0x68(%rsp)
 10178eb:	00 
 10178ec:	48 c7 84 24 30 01 00 	movq   $0x100a308,0x130(%rsp)
 10178f3:	00 08 a3 00 01 
 10178f8:	c7 84 24 48 01 00 00 	movl   $0x2,0x148(%rsp)
 10178ff:	02 00 00 00 
 1017903:	c7 84 24 80 00 00 00 	movl   $0x0,0x80(%rsp)
 101790a:	00 00 00 00 
 101790e:	4c 39 a3 80 3d 00 00 	cmp    %r12,0x3d80(%rbx)
 1017915:	0f 85 9e 00 00 00    	jne    10179b9 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xc39>
 101791b:	48 8b 74 24 58       	mov    0x58(%rsp),%rsi
 1017920:	48 8d bb 58 02 00 00 	lea    0x258(%rbx),%rdi
 1017927:	e8 c4 f8 00 00       	call   10271f0 <myl_rc_scope_unwind>
 101792c:	4c 8b 74 24 50       	mov    0x50(%rsp),%r14
 1017931:	4d 85 f6             	test   %r14,%r14
 1017934:	74 44                	je     101797a <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xbfa>
 1017936:	4d 89 f7             	mov    %r14,%r15
 1017939:	49 c1 e7 05          	shl    $0x5,%r15
 101793d:	49 83 c7 e0          	add    $0xffffffffffffffe0,%r15
 1017941:	eb 21                	jmp    1017964 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xbe4>
 1017943:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 101794a:	84 00 00 00 00 00 
 1017950:	4c 01 fe             	add    %r15,%rsi
 1017953:	48 89 df             	mov    %rbx,%rdi
 1017956:	e8 45 52 00 00       	call   101cba0 <myl_qbe_rc_slot_drop>
 101795b:	49 83 c7 e0          	add    $0xffffffffffffffe0,%r15
 101795f:	49 ff ce             	dec    %r14
 1017962:	74 16                	je     101797a <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xbfa>
 1017964:	48 8b 74 24 48       	mov    0x48(%rsp),%rsi
 1017969:	4a 8b 44 3e 10       	mov    0x10(%rsi,%r15,1),%rax
 101796e:	48 85 c0             	test   %rax,%rax
 1017971:	74 dd                	je     1017950 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xbd0>
 1017973:	83 38 00             	cmpl   $0x0,(%rax)
 1017976:	75 d8                	jne    1017950 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xbd0>
 1017978:	eb e1                	jmp    101795b <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xbdb>
 101797a:	4c 39 a3 80 3d 00 00 	cmp    %r12,0x3d80(%rbx)
 1017981:	75 36                	jne    10179b9 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xc39>
 1017983:	48 8b 83 60 18 00 00 	mov    0x1860(%rbx),%rax
 101798a:	48 85 c0             	test   %rax,%rax
 101798d:	74 06                	je     1017995 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xc15>
 101798f:	48 8b 40 70          	mov    0x70(%rax),%rax
 1017993:	eb 02                	jmp    1017997 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xc17>
 1017995:	31 c0                	xor    %eax,%eax
 1017997:	48 3b 44 24 58       	cmp    0x58(%rsp),%rax
 101799c:	75 1b                	jne    10179b9 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xc39>
 101799e:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
 10179a3:	48 89 83 80 3d 00 00 	mov    %rax,0x3d80(%rbx)
 10179aa:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
 10179af:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
 10179b4:	e9 07 fd ff ff       	jmp    10176c0 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x940>
 10179b9:	c5 f8 77             	vzeroupper
 10179bc:	e8 f0 b4 00 00       	call   1022eb1 <myl_rc_invariant_failed>
 10179c1:	e8 2a 66 01 00       	call   102dff0 <abort@plt>
 10179c6:	48 89 df             	mov    %rbx,%rdi
 10179c9:	e8 92 62 00 00       	call   101dc60 <myl_qbe_fail_allocation>
 10179ce:	48 89 df             	mov    %rbx,%rdi
 10179d1:	e8 8a 63 00 00       	call   101dd60 <myl_qbe_fail_frame>
 10179d6:	48 89 df             	mov    %rbx,%rdi
 10179d9:	e8 82 62 00 00       	call   101dc60 <myl_qbe_fail_allocation>
 10179de:	be 01 00 00 00       	mov    $0x1,%esi
 10179e3:	b9 01 00 00 00       	mov    $0x1,%ecx
 10179e8:	48 89 df             	mov    %rbx,%rdi
 10179eb:	48 ba 00 00 00 00 00 	movabs $0x8000000000000000,%rdx
 10179f2:	00 00 80 
 10179f5:	c5 f8 77             	vzeroupper
 10179f8:	e8 f3 62 00 00       	call   101dcf0 <myl_qbe_fail_overflow_op>
 10179fd:	be 01 00 00 00       	mov    $0x1,%esi
 1017a02:	b9 01 00 00 00       	mov    $0x1,%ecx
 1017a07:	48 89 df             	mov    %rbx,%rdi
 1017a0a:	e8 e1 62 00 00       	call   101dcf0 <myl_qbe_fail_overflow_op>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
