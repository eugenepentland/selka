
.tmp-rc/profile/gap-allocator-qbe-rc-n12:     file format elf64-x86-64


Disassembly of section .text:

0000000001011a10 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531>:
 1011a10:	f3 0f 1e fa          	endbr64
 1011a14:	55                   	push   %rbp
 1011a15:	48 89 e5             	mov    %rsp,%rbp
 1011a18:	48 81 ec f8 01 00 00 	sub    $0x1f8,%rsp
 1011a1f:	53                   	push   %rbx
 1011a20:	41 54                	push   %r12
 1011a22:	41 55                	push   %r13
 1011a24:	41 56                	push   %r14
 1011a26:	41 57                	push   %r15
 1011a28:	48 8b 47 40          	mov    0x40(%rdi),%rax
 1011a2c:	48 8d 4d e8          	lea    -0x18(%rbp),%rcx
 1011a30:	48 39 c1             	cmp    %rax,%rcx
 1011a33:	0f 82 16 15 00 00    	jb     1012f4f <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x153f>
 1011a39:	48 89 75 90          	mov    %rsi,-0x70(%rbp)
 1011a3d:	48 89 fb             	mov    %rdi,%rbx
 1011a40:	e8 8b 77 00 00       	call   10191d0 <myl_qbe_heap>
 1011a45:	48 89 df             	mov    %rbx,%rdi
 1011a48:	48 89 c3             	mov    %rax,%rbx
 1011a4b:	49 89 fc             	mov    %rdi,%r12
 1011a4e:	e8 bd 9a 00 00       	call   101b510 <myl_qbe_region_mark>
 1011a53:	4c 89 e7             	mov    %r12,%rdi
 1011a56:	49 89 c5             	mov    %rax,%r13
 1011a59:	ba 30 00 00 00       	mov    $0x30,%edx
 1011a5e:	be 00 00 00 00       	mov    $0x0,%esi
 1011a63:	49 89 fc             	mov    %rdi,%r12
 1011a66:	48 8d bd 20 ff ff ff 	lea    -0xe0(%rbp),%rdi
 1011a6d:	e8 ce 6e 01 00       	call   1028940 <compiler_rt.fastMemset>
 1011a72:	4c 89 e7             	mov    %r12,%rdi
 1011a75:	ba c0 00 00 00       	mov    $0xc0,%edx
 1011a7a:	be 00 00 00 00       	mov    $0x0,%esi
 1011a7f:	49 89 fc             	mov    %rdi,%r12
 1011a82:	48 8d bd 60 fe ff ff 	lea    -0x1a0(%rbp),%rdi
 1011a89:	e8 b2 6e 01 00       	call   1028940 <compiler_rt.fastMemset>
 1011a8e:	4c 89 e7             	mov    %r12,%rdi
 1011a91:	48 8d 05 40 27 ff ff 	lea    -0xd8c0(%rip),%rax        # 10041d8 <myl_t_1a91deb3742283487d66c3b500f6effd7ef1170e6d4b4368fe9ec3c3f0354fda>
 1011a98:	48 89 85 60 fe ff ff 	mov    %rax,-0x1a0(%rbp)
 1011a9f:	c7 85 78 fe ff ff 00 	movl   $0x0,-0x188(%rbp)
 1011aa6:	00 00 00 
 1011aa9:	48 8d 45 90          	lea    -0x70(%rbp),%rax
 1011aad:	48 89 85 68 fe ff ff 	mov    %rax,-0x198(%rbp)
 1011ab4:	48 8d 85 20 ff ff ff 	lea    -0xe0(%rbp),%rax
 1011abb:	48 89 85 70 fe ff ff 	mov    %rax,-0x190(%rbp)
 1011ac2:	48 8d 05 7f 28 ff ff 	lea    -0xd781(%rip),%rax        # 1004348 <myl_t_385cfdbc00ec32031699460779c15099b2bba3cad0e440fffb08e10df0acb9e1>
 1011ac9:	48 89 85 80 fe ff ff 	mov    %rax,-0x180(%rbp)
 1011ad0:	c7 85 98 fe ff ff 00 	movl   $0x0,-0x168(%rbp)
 1011ad7:	00 00 00 
 1011ada:	48 8d 85 50 ff ff ff 	lea    -0xb0(%rbp),%rax
 1011ae1:	48 89 85 88 fe ff ff 	mov    %rax,-0x178(%rbp)
 1011ae8:	48 8d 85 20 ff ff ff 	lea    -0xe0(%rbp),%rax
 1011aef:	48 83 c0 08          	add    $0x8,%rax
 1011af3:	48 89 85 90 fe ff ff 	mov    %rax,-0x170(%rbp)
 1011afa:	48 8d 05 47 28 ff ff 	lea    -0xd7b9(%rip),%rax        # 1004348 <myl_t_385cfdbc00ec32031699460779c15099b2bba3cad0e440fffb08e10df0acb9e1>
 1011b01:	48 89 85 a0 fe ff ff 	mov    %rax,-0x160(%rbp)
 1011b08:	c7 85 b8 fe ff ff 00 	movl   $0x0,-0x148(%rbp)
 1011b0f:	00 00 00 
 1011b12:	48 8d 85 60 ff ff ff 	lea    -0xa0(%rbp),%rax
 1011b19:	48 89 85 a8 fe ff ff 	mov    %rax,-0x158(%rbp)
 1011b20:	48 8d 85 20 ff ff ff 	lea    -0xe0(%rbp),%rax
 1011b27:	48 83 c0 10          	add    $0x10,%rax
 1011b2b:	48 89 85 b0 fe ff ff 	mov    %rax,-0x150(%rbp)
 1011b32:	48 8d 05 0f 28 ff ff 	lea    -0xd7f1(%rip),%rax        # 1004348 <myl_t_385cfdbc00ec32031699460779c15099b2bba3cad0e440fffb08e10df0acb9e1>
 1011b39:	48 89 85 c0 fe ff ff 	mov    %rax,-0x140(%rbp)
 1011b40:	c7 85 d8 fe ff ff 00 	movl   $0x0,-0x128(%rbp)
 1011b47:	00 00 00 
 1011b4a:	48 8d 85 70 ff ff ff 	lea    -0x90(%rbp),%rax
 1011b51:	48 89 85 c8 fe ff ff 	mov    %rax,-0x138(%rbp)
 1011b58:	48 8d 85 20 ff ff ff 	lea    -0xe0(%rbp),%rax
 1011b5f:	48 83 c0 18          	add    $0x18,%rax
 1011b63:	48 89 85 d0 fe ff ff 	mov    %rax,-0x130(%rbp)
 1011b6a:	48 8d 05 d7 27 ff ff 	lea    -0xd829(%rip),%rax        # 1004348 <myl_t_385cfdbc00ec32031699460779c15099b2bba3cad0e440fffb08e10df0acb9e1>
 1011b71:	48 89 85 e0 fe ff ff 	mov    %rax,-0x120(%rbp)
 1011b78:	c7 85 f8 fe ff ff 00 	movl   $0x0,-0x108(%rbp)
 1011b7f:	00 00 00 
 1011b82:	48 8d 85 78 ff ff ff 	lea    -0x88(%rbp),%rax
 1011b89:	48 89 85 e8 fe ff ff 	mov    %rax,-0x118(%rbp)
 1011b90:	48 8d 85 20 ff ff ff 	lea    -0xe0(%rbp),%rax
 1011b97:	48 83 c0 20          	add    $0x20,%rax
 1011b9b:	48 89 85 f0 fe ff ff 	mov    %rax,-0x110(%rbp)
 1011ba2:	48 8d 05 9f 27 ff ff 	lea    -0xd861(%rip),%rax        # 1004348 <myl_t_385cfdbc00ec32031699460779c15099b2bba3cad0e440fffb08e10df0acb9e1>
 1011ba9:	48 89 85 00 ff ff ff 	mov    %rax,-0x100(%rbp)
 1011bb0:	c7 85 18 ff ff ff 00 	movl   $0x0,-0xe8(%rbp)
 1011bb7:	00 00 00 
 1011bba:	48 8d 45 88          	lea    -0x78(%rbp),%rax
 1011bbe:	48 89 85 08 ff ff ff 	mov    %rax,-0xf8(%rbp)
 1011bc5:	48 8d 85 20 ff ff ff 	lea    -0xe0(%rbp),%rax
 1011bcc:	49 89 c6             	mov    %rax,%r14
 1011bcf:	49 83 c6 28          	add    $0x28,%r14
 1011bd3:	4c 89 b5 10 ff ff ff 	mov    %r14,-0xf0(%rbp)
 1011bda:	b9 06 00 00 00       	mov    $0x6,%ecx
 1011bdf:	48 8d 95 60 fe ff ff 	lea    -0x1a0(%rbp),%rdx
 1011be6:	48 8d b5 40 fe ff ff 	lea    -0x1c0(%rbp),%rsi
 1011bed:	49 89 fc             	mov    %rdi,%r12
 1011bf0:	e8 0b 6d 00 00       	call   1018900 <myl_qbe_rc_frame_enter>
 1011bf5:	4d 89 e8             	mov    %r13,%r8
 1011bf8:	4c 89 e7             	mov    %r12,%rdi
 1011bfb:	48 8b 55 90          	mov    -0x70(%rbp),%rdx
 1011bff:	48 89 55 98          	mov    %rdx,-0x68(%rbp)
 1011c03:	48 c7 45 a0 00 00 00 	movq   $0x0,-0x60(%rbp)
 1011c0a:	00 
 1011c0b:	48 83 fa 00          	cmp    $0x0,%rdx
 1011c0f:	0f 94 c0             	sete   %al
 1011c12:	48 0f b6 c0          	movzbq %al,%rax
 1011c16:	48 89 45 98          	mov    %rax,-0x68(%rbp)
 1011c1a:	48 8d b5 78 ff ff ff 	lea    -0x88(%rbp),%rsi
 1011c21:	48 8d 8d 50 ff ff ff 	lea    -0xb0(%rbp),%rcx
 1011c28:	48 f7 de             	neg    %rsi
 1011c2b:	48 01 ce             	add    %rcx,%rsi
 1011c2e:	4d 89 c7             	mov    %r8,%r15
 1011c31:	4c 8d 85 50 ff ff ff 	lea    -0xb0(%rbp),%r8
 1011c38:	48 8d 8d 78 ff ff ff 	lea    -0x88(%rbp),%rcx
 1011c3f:	4c 29 c1             	sub    %r8,%rcx
 1011c42:	48 83 fe 10          	cmp    $0x10,%rsi
 1011c46:	41 0f 92 c4          	setb   %r12b
 1011c4a:	45 0f b6 e4          	movzbl %r12b,%r12d
 1011c4e:	44 89 65 f4          	mov    %r12d,-0xc(%rbp)
 1011c52:	48 83 f9 10          	cmp    $0x10,%rcx
 1011c56:	41 0f 92 c5          	setb   %r13b
 1011c5a:	45 0f b6 ed          	movzbl %r13b,%r13d
 1011c5e:	44 89 6d f0          	mov    %r13d,-0x10(%rbp)
 1011c62:	83 f8 00             	cmp    $0x0,%eax
 1011c65:	0f 85 62 0d 00 00    	jne    10129cd <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xfbd>
 1011c6b:	48 89 55 98          	mov    %rdx,-0x68(%rbp)
 1011c6f:	48 c7 45 a0 01 00 00 	movq   $0x1,-0x60(%rbp)
 1011c76:	00 
 1011c77:	48 b8 01 00 00 00 00 	movabs $0x8000000000000001,%rax
 1011c7e:	00 00 80 
 1011c81:	48 39 c2             	cmp    %rax,%rdx
 1011c84:	0f 8c 29 0d 00 00    	jl     10129b3 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xfa3>
 1011c8a:	48 89 d6             	mov    %rdx,%rsi
 1011c8d:	48 83 ee 01          	sub    $0x1,%rsi
 1011c91:	48 89 75 98          	mov    %rsi,-0x68(%rbp)
 1011c95:	49 89 fc             	mov    %rdi,%r12
 1011c98:	e8 73 fd ff ff       	call   1011a10 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531>
 1011c9d:	4c 89 e7             	mov    %r12,%rdi
 1011ca0:	48 89 c1             	mov    %rax,%rcx
 1011ca3:	48 89 d0             	mov    %rdx,%rax
 1011ca6:	48 89 8d 10 fe ff ff 	mov    %rcx,-0x1f0(%rbp)
 1011cad:	48 89 85 18 fe ff ff 	mov    %rax,-0x1e8(%rbp)
 1011cb4:	48 8d 85 10 fe ff ff 	lea    -0x1f0(%rbp),%rax
 1011cbb:	48 89 45 98          	mov    %rax,-0x68(%rbp)
 1011cbf:	48 8b 85 10 fe ff ff 	mov    -0x1f0(%rbp),%rax
 1011cc6:	48 89 85 78 ff ff ff 	mov    %rax,-0x88(%rbp)
 1011ccd:	48 8b 85 18 fe ff ff 	mov    -0x1e8(%rbp),%rax
 1011cd4:	48 89 45 80          	mov    %rax,-0x80(%rbp)
 1011cd8:	48 8d 05 01 b2 01 00 	lea    0x1b201(%rip),%rax        # 102cee0 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 1011cdf:	48 89 85 e0 fe ff ff 	mov    %rax,-0x120(%rbp)
 1011ce6:	c7 85 f8 fe ff ff 02 	movl   $0x2,-0x108(%rbp)
 1011ced:	00 00 00 
 1011cf0:	c7 85 40 ff ff ff 01 	movl   $0x1,-0xc0(%rbp)
 1011cf7:	00 00 00 
 1011cfa:	48 8b 85 78 ff ff ff 	mov    -0x88(%rbp),%rax
 1011d01:	48 89 85 50 ff ff ff 	mov    %rax,-0xb0(%rbp)
 1011d08:	48 8b 45 80          	mov    -0x80(%rbp),%rax
 1011d0c:	48 89 85 58 ff ff ff 	mov    %rax,-0xa8(%rbp)
 1011d13:	48 8d 05 c6 b1 01 00 	lea    0x1b1c6(%rip),%rax        # 102cee0 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 1011d1a:	48 89 85 80 fe ff ff 	mov    %rax,-0x180(%rbp)
 1011d21:	c7 85 98 fe ff ff 02 	movl   $0x2,-0x168(%rbp)
 1011d28:	00 00 00 
 1011d2b:	c7 85 40 ff ff ff 00 	movl   $0x0,-0xc0(%rbp)
 1011d32:	00 00 00 
 1011d35:	c7 85 28 ff ff ff 01 	movl   $0x1,-0xd8(%rbp)
 1011d3c:	00 00 00 
 1011d3f:	48 8d 85 50 ff ff ff 	lea    -0xb0(%rbp),%rax
 1011d46:	48 89 45 98          	mov    %rax,-0x68(%rbp)
 1011d4a:	ba 01 00 00 00       	mov    $0x1,%edx
 1011d4f:	48 8d 35 7a ae 01 00 	lea    0x1ae7a(%rip),%rsi        # 102cbd0 <myl_t_1e414bd82e4b50b54939760a2d591f88da97e2f1c8252dbd7dcbc73438e46afb_body>
 1011d56:	49 89 fc             	mov    %rdi,%r12
 1011d59:	48 89 df             	mov    %rbx,%rdi
 1011d5c:	e8 4f bb 00 00       	call   101d8b0 <myl_native_heap_alloc>
 1011d61:	4c 89 e7             	mov    %r12,%rdi
 1011d64:	49 89 c4             	mov    %rax,%r12
 1011d67:	41 83 fc 00          	cmp    $0x0,%r12d
 1011d6b:	75 0a                	jne    1011d77 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x367>
 1011d6d:	48 89 fb             	mov    %rdi,%rbx
 1011d70:	e8 db 71 00 00       	call   1018f50 <myl_qbe_fail_allocation>
 1011d75:	0f 0b                	ud2
 1011d77:	48 87 fb             	xchg   %rdi,%rbx
 1011d7a:	4c 89 65 88          	mov    %r12,-0x78(%rbp)
 1011d7e:	48 8d 05 bb ae 01 00 	lea    0x1aebb(%rip),%rax        # 102cc40 <myl_t_1e414bd82e4b50b54939760a2d591f88da97e2f1c8252dbd7dcbc73438e46afb>
 1011d85:	48 89 85 00 ff ff ff 	mov    %rax,-0x100(%rbp)
 1011d8c:	c7 85 18 ff ff ff 02 	movl   $0x2,-0xe8(%rbp)
 1011d93:	00 00 00 
 1011d96:	48 8d 45 88          	lea    -0x78(%rbp),%rax
 1011d9a:	48 89 85 08 ff ff ff 	mov    %rax,-0xf8(%rbp)
 1011da1:	4c 89 b5 10 ff ff ff 	mov    %r14,-0xf0(%rbp)
 1011da8:	c7 85 18 ff ff ff 04 	movl   $0x4,-0xe8(%rbp)
 1011daf:	00 00 00 
 1011db2:	c7 85 48 ff ff ff 01 	movl   $0x1,-0xb8(%rbp)
 1011db9:	00 00 00 
 1011dbc:	48 8b 4d 98          	mov    -0x68(%rbp),%rcx
 1011dc0:	48 8d 85 78 ff ff ff 	lea    -0x88(%rbp),%rax
 1011dc7:	48 f7 d8             	neg    %rax
 1011dca:	48 01 c8             	add    %rcx,%rax
 1011dcd:	48 8d 95 78 ff ff ff 	lea    -0x88(%rbp),%rdx
 1011dd4:	48 29 ca             	sub    %rcx,%rdx
 1011dd7:	48 83 f8 10          	cmp    $0x10,%rax
 1011ddb:	0f 92 c0             	setb   %al
 1011dde:	0f b6 c0             	movzbl %al,%eax
 1011de1:	48 83 fa 10          	cmp    $0x10,%rdx
 1011de5:	0f 92 c2             	setb   %dl
 1011de8:	0f b6 d2             	movzbl %dl,%edx
 1011deb:	09 d0                	or     %edx,%eax
 1011ded:	75 79                	jne    1011e68 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x458>
 1011def:	48 8b 01             	mov    (%rcx),%rax
 1011df2:	48 83 f8 00          	cmp    $0x0,%rax
 1011df6:	74 1a                	je     1011e12 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x402>
 1011df8:	48 83 e8 10          	sub    $0x10,%rax
 1011dfc:	48 8b 00             	mov    (%rax),%rax
 1011dff:	48 ba 01 00 00 00 00 	movabs $0x5000000000000001,%rdx
 1011e06:	00 00 50 
 1011e09:	48 21 d0             	and    %rdx,%rax
 1011e0c:	48 83 f8 00          	cmp    $0x0,%rax
 1011e10:	75 56                	jne    1011e68 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x458>
 1011e12:	48 8b 41 08          	mov    0x8(%rcx),%rax
 1011e16:	48 83 f8 00          	cmp    $0x0,%rax
 1011e1a:	74 1a                	je     1011e36 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x426>
 1011e1c:	48 83 e8 10          	sub    $0x10,%rax
 1011e20:	48 8b 00             	mov    (%rax),%rax
 1011e23:	48 ba 01 00 00 00 00 	movabs $0x5000000000000001,%rdx
 1011e2a:	00 00 50 
 1011e2d:	48 21 d0             	and    %rdx,%rax
 1011e30:	48 83 f8 00          	cmp    $0x0,%rax
 1011e34:	75 32                	jne    1011e68 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x458>
 1011e36:	48 8b 01             	mov    (%rcx),%rax
 1011e39:	48 89 85 78 ff ff ff 	mov    %rax,-0x88(%rbp)
 1011e40:	48 8b 41 08          	mov    0x8(%rcx),%rax
 1011e44:	48 89 45 80          	mov    %rax,-0x80(%rbp)
 1011e48:	ba 10 00 00 00       	mov    $0x10,%edx
 1011e4d:	be 00 00 00 00       	mov    $0x0,%esi
 1011e52:	49 89 fd             	mov    %rdi,%r13
 1011e55:	48 89 cf             	mov    %rcx,%rdi
 1011e58:	e8 e3 6a 01 00       	call   1028940 <compiler_rt.fastMemset>
 1011e5d:	4d 89 f8             	mov    %r15,%r8
 1011e60:	4c 89 ef             	mov    %r13,%rdi
 1011e63:	4d 89 c5             	mov    %r8,%r13
 1011e66:	eb 3e                	jmp    1011ea6 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x496>
 1011e68:	4d 89 f8             	mov    %r15,%r8
 1011e6b:	4d 89 c5             	mov    %r8,%r13
 1011e6e:	48 8d 95 78 ff ff ff 	lea    -0x88(%rbp),%rdx
 1011e75:	48 8d 35 64 b0 01 00 	lea    0x1b064(%rip),%rsi        # 102cee0 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 1011e7c:	49 89 ff             	mov    %rdi,%r15
 1011e7f:	e8 1c 67 01 00       	call   10285a0 <myl_rc_native_take>
 1011e84:	4c 89 ff             	mov    %r15,%rdi
 1011e87:	83 f8 00             	cmp    $0x0,%eax
 1011e8a:	75 1a                	jne    1011ea6 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x496>
 1011e8c:	e8 2f f2 00 00       	call   10210c0 <myl_rc_take_failure>
 1011e91:	48 89 df             	mov    %rbx,%rdi
 1011e94:	89 c6                	mov    %eax,%esi
 1011e96:	48 89 fb             	mov    %rdi,%rbx
 1011e99:	e8 72 69 00 00       	call   1018810 <myl_qbe_rc_status>
 1011e9e:	48 89 df             	mov    %rbx,%rdi
 1011ea1:	e9 f8 0f 00 00       	jmp    1012e9e <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x148e>
 1011ea6:	c7 85 28 ff ff ff 00 	movl   $0x0,-0xd8(%rbp)
 1011ead:	00 00 00 
 1011eb0:	48 8d 05 29 b0 01 00 	lea    0x1b029(%rip),%rax        # 102cee0 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 1011eb7:	48 89 85 e0 fe ff ff 	mov    %rax,-0x120(%rbp)
 1011ebe:	c7 85 f8 fe ff ff 02 	movl   $0x2,-0x108(%rbp)
 1011ec5:	00 00 00 
 1011ec8:	c7 85 40 ff ff ff 01 	movl   $0x1,-0xc0(%rbp)
 1011ecf:	00 00 00 
 1011ed2:	48 8b 85 78 ff ff ff 	mov    -0x88(%rbp),%rax
 1011ed9:	49 89 04 24          	mov    %rax,(%r12)
 1011edd:	48 8b 45 80          	mov    -0x80(%rbp),%rax
 1011ee1:	49 89 44 24 08       	mov    %rax,0x8(%r12)
 1011ee6:	c7 85 40 ff ff ff 00 	movl   $0x0,-0xc0(%rbp)
 1011eed:	00 00 00 
 1011ef0:	4c 89 65 98          	mov    %r12,-0x68(%rbp)
 1011ef4:	48 8b 45 98          	mov    -0x68(%rbp),%rax
 1011ef8:	48 89 85 50 ff ff ff 	mov    %rax,-0xb0(%rbp)
 1011eff:	48 8d 05 3a ad 01 00 	lea    0x1ad3a(%rip),%rax        # 102cc40 <myl_t_1e414bd82e4b50b54939760a2d591f88da97e2f1c8252dbd7dcbc73438e46afb>
 1011f06:	48 89 85 80 fe ff ff 	mov    %rax,-0x180(%rbp)
 1011f0d:	c7 85 98 fe ff ff 02 	movl   $0x2,-0x168(%rbp)
 1011f14:	00 00 00 
 1011f17:	c7 85 28 ff ff ff 01 	movl   $0x1,-0xd8(%rbp)
 1011f1e:	00 00 00 
 1011f21:	4c 89 65 98          	mov    %r12,-0x68(%rbp)
 1011f25:	c7 85 48 ff ff ff 00 	movl   $0x0,-0xb8(%rbp)
 1011f2c:	00 00 00 
 1011f2f:	ba 08 00 00 00       	mov    $0x8,%edx
 1011f34:	be 00 00 00 00       	mov    $0x0,%esi
 1011f39:	49 89 fc             	mov    %rdi,%r12
 1011f3c:	48 8d 7d c8          	lea    -0x38(%rbp),%rdi
 1011f40:	e8 fb 69 01 00       	call   1028940 <compiler_rt.fastMemset>
 1011f45:	4c 89 e7             	mov    %r12,%rdi
 1011f48:	48 8d 05 21 af 01 00 	lea    0x1af21(%rip),%rax        # 102ce70 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 1011f4f:	48 89 85 00 ff ff ff 	mov    %rax,-0x100(%rbp)
 1011f56:	c7 85 18 ff ff ff 02 	movl   $0x2,-0xe8(%rbp)
 1011f5d:	00 00 00 
 1011f60:	48 8d 45 c8          	lea    -0x38(%rbp),%rax
 1011f64:	48 89 85 08 ff ff ff 	mov    %rax,-0xf8(%rbp)
 1011f6b:	4c 89 b5 10 ff ff ff 	mov    %r14,-0xf0(%rbp)
 1011f72:	c7 85 48 ff ff ff 01 	movl   $0x1,-0xb8(%rbp)
 1011f79:	00 00 00 
 1011f7c:	48 8d 8d 78 ff ff ff 	lea    -0x88(%rbp),%rcx
 1011f83:	48 8d 45 98          	lea    -0x68(%rbp),%rax
 1011f87:	48 29 c8             	sub    %rcx,%rax
 1011f8a:	48 8d 55 98          	lea    -0x68(%rbp),%rdx
 1011f8e:	48 8d 8d 78 ff ff ff 	lea    -0x88(%rbp),%rcx
 1011f95:	48 29 d1             	sub    %rdx,%rcx
 1011f98:	48 83 f8 08          	cmp    $0x8,%rax
 1011f9c:	0f 92 c0             	setb   %al
 1011f9f:	0f b6 c0             	movzbl %al,%eax
 1011fa2:	48 83 f9 08          	cmp    $0x8,%rcx
 1011fa6:	0f 92 c1             	setb   %cl
 1011fa9:	0f b6 c9             	movzbl %cl,%ecx
 1011fac:	09 c8                	or     %ecx,%eax
 1011fae:	75 53                	jne    1012003 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x5f3>
 1011fb0:	48 8b 45 98          	mov    -0x68(%rbp),%rax
 1011fb4:	48 83 f8 00          	cmp    $0x0,%rax
 1011fb8:	74 1a                	je     1011fd4 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x5c4>
 1011fba:	48 83 e8 10          	sub    $0x10,%rax
 1011fbe:	48 8b 00             	mov    (%rax),%rax
 1011fc1:	48 b9 01 00 00 00 00 	movabs $0x5000000000000001,%rcx
 1011fc8:	00 00 50 
 1011fcb:	48 21 c8             	and    %rcx,%rax
 1011fce:	48 83 f8 00          	cmp    $0x0,%rax
 1011fd2:	75 2f                	jne    1012003 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x5f3>
 1011fd4:	48 8b 45 98          	mov    -0x68(%rbp),%rax
 1011fd8:	48 89 85 78 ff ff ff 	mov    %rax,-0x88(%rbp)
 1011fdf:	ba 08 00 00 00       	mov    $0x8,%edx
 1011fe4:	be 00 00 00 00       	mov    $0x0,%esi
 1011fe9:	49 89 fc             	mov    %rdi,%r12
 1011fec:	48 8d 7d 98          	lea    -0x68(%rbp),%rdi
 1011ff0:	e8 4b 69 01 00       	call   1028940 <compiler_rt.fastMemset>
 1011ff5:	4d 89 e8             	mov    %r13,%r8
 1011ff8:	4c 89 e7             	mov    %r12,%rdi
 1011ffb:	4d 89 c7             	mov    %r8,%r15
 1011ffe:	48 87 df             	xchg   %rbx,%rdi
 1012001:	eb 45                	jmp    1012048 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x638>
 1012003:	4d 89 e8             	mov    %r13,%r8
 1012006:	4d 89 c7             	mov    %r8,%r15
 1012009:	48 8d 4d 98          	lea    -0x68(%rbp),%rcx
 101200d:	48 8d 95 78 ff ff ff 	lea    -0x88(%rbp),%rdx
 1012014:	48 8d 35 25 ac 01 00 	lea    0x1ac25(%rip),%rsi        # 102cc40 <myl_t_1e414bd82e4b50b54939760a2d591f88da97e2f1c8252dbd7dcbc73438e46afb>
 101201b:	49 89 fc             	mov    %rdi,%r12
 101201e:	e8 7d 65 01 00       	call   10285a0 <myl_rc_native_take>
 1012023:	4c 89 e7             	mov    %r12,%rdi
 1012026:	83 f8 00             	cmp    $0x0,%eax
 1012029:	75 1a                	jne    1012045 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x635>
 101202b:	e8 90 f0 00 00       	call   10210c0 <myl_rc_take_failure>
 1012030:	48 89 df             	mov    %rbx,%rdi
 1012033:	89 c6                	mov    %eax,%esi
 1012035:	48 89 fb             	mov    %rdi,%rbx
 1012038:	e8 d3 67 00 00       	call   1018810 <myl_qbe_rc_status>
 101203d:	48 89 df             	mov    %rbx,%rdi
 1012040:	e9 59 0e 00 00       	jmp    1012e9e <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x148e>
 1012045:	48 87 df             	xchg   %rbx,%rdi
 1012048:	c7 85 28 ff ff ff 00 	movl   $0x0,-0xd8(%rbp)
 101204f:	00 00 00 
 1012052:	48 8d 05 e7 ab 01 00 	lea    0x1abe7(%rip),%rax        # 102cc40 <myl_t_1e414bd82e4b50b54939760a2d591f88da97e2f1c8252dbd7dcbc73438e46afb>
 1012059:	48 89 85 e0 fe ff ff 	mov    %rax,-0x120(%rbp)
 1012060:	c7 85 f8 fe ff ff 02 	movl   $0x2,-0x108(%rbp)
 1012067:	00 00 00 
 101206a:	c7 85 40 ff ff ff 01 	movl   $0x1,-0xc0(%rbp)
 1012071:	00 00 00 
 1012074:	48 8b 85 78 ff ff ff 	mov    -0x88(%rbp),%rax
 101207b:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
 101207f:	c7 85 40 ff ff ff 00 	movl   $0x0,-0xc0(%rbp)
 1012086:	00 00 00 
 1012089:	48 8d 45 c8          	lea    -0x38(%rbp),%rax
 101208d:	48 89 45 98          	mov    %rax,-0x68(%rbp)
 1012091:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
 1012095:	48 89 85 50 ff ff ff 	mov    %rax,-0xb0(%rbp)
 101209c:	48 8d 05 cd ad 01 00 	lea    0x1adcd(%rip),%rax        # 102ce70 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 10120a3:	48 89 85 80 fe ff ff 	mov    %rax,-0x180(%rbp)
 10120aa:	c7 85 98 fe ff ff 02 	movl   $0x2,-0x168(%rbp)
 10120b1:	00 00 00 
 10120b4:	c7 85 28 ff ff ff 01 	movl   $0x1,-0xd8(%rbp)
 10120bb:	00 00 00 
 10120be:	48 8d 85 50 ff ff ff 	lea    -0xb0(%rbp),%rax
 10120c5:	48 89 45 98          	mov    %rax,-0x68(%rbp)
 10120c9:	c7 85 48 ff ff ff 00 	movl   $0x0,-0xb8(%rbp)
 10120d0:	00 00 00 
 10120d3:	48 8b 55 90          	mov    -0x70(%rbp),%rdx
 10120d7:	48 89 55 a0          	mov    %rdx,-0x60(%rbp)
 10120db:	48 b8 01 00 00 00 00 	movabs $0x8000000000000001,%rax
 10120e2:	00 00 80 
 10120e5:	48 39 c2             	cmp    %rax,%rdx
 10120e8:	0f 8c ae 08 00 00    	jl     101299c <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xf8c>
 10120ee:	48 89 d6             	mov    %rdx,%rsi
 10120f1:	48 83 ee 01          	sub    $0x1,%rsi
 10120f5:	48 89 75 a0          	mov    %rsi,-0x60(%rbp)
 10120f9:	49 89 fc             	mov    %rdi,%r12
 10120fc:	e8 0f f9 ff ff       	call   1011a10 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531>
 1012101:	4c 89 e7             	mov    %r12,%rdi
 1012104:	48 89 c1             	mov    %rax,%rcx
 1012107:	48 89 d0             	mov    %rdx,%rax
 101210a:	48 89 8d 20 fe ff ff 	mov    %rcx,-0x1e0(%rbp)
 1012111:	48 89 85 28 fe ff ff 	mov    %rax,-0x1d8(%rbp)
 1012118:	48 8d 85 20 fe ff ff 	lea    -0x1e0(%rbp),%rax
 101211f:	48 89 45 a0          	mov    %rax,-0x60(%rbp)
 1012123:	48 8b 85 20 fe ff ff 	mov    -0x1e0(%rbp),%rax
 101212a:	48 89 85 78 ff ff ff 	mov    %rax,-0x88(%rbp)
 1012131:	48 8b 85 28 fe ff ff 	mov    -0x1d8(%rbp),%rax
 1012138:	48 89 45 80          	mov    %rax,-0x80(%rbp)
 101213c:	48 8d 05 9d ad 01 00 	lea    0x1ad9d(%rip),%rax        # 102cee0 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 1012143:	48 89 85 e0 fe ff ff 	mov    %rax,-0x120(%rbp)
 101214a:	c7 85 f8 fe ff ff 02 	movl   $0x2,-0x108(%rbp)
 1012151:	00 00 00 
 1012154:	c7 85 40 ff ff ff 01 	movl   $0x1,-0xc0(%rbp)
 101215b:	00 00 00 
 101215e:	48 8b 85 78 ff ff ff 	mov    -0x88(%rbp),%rax
 1012165:	48 89 85 60 ff ff ff 	mov    %rax,-0xa0(%rbp)
 101216c:	48 8b 45 80          	mov    -0x80(%rbp),%rax
 1012170:	48 89 85 68 ff ff ff 	mov    %rax,-0x98(%rbp)
 1012177:	48 8d 05 62 ad 01 00 	lea    0x1ad62(%rip),%rax        # 102cee0 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 101217e:	48 89 85 a0 fe ff ff 	mov    %rax,-0x160(%rbp)
 1012185:	c7 85 b8 fe ff ff 02 	movl   $0x2,-0x148(%rbp)
 101218c:	00 00 00 
 101218f:	c7 85 40 ff ff ff 00 	movl   $0x0,-0xc0(%rbp)
 1012196:	00 00 00 
 1012199:	c7 85 30 ff ff ff 01 	movl   $0x1,-0xd0(%rbp)
 10121a0:	00 00 00 
 10121a3:	48 8d 85 60 ff ff ff 	lea    -0xa0(%rbp),%rax
 10121aa:	48 89 45 a0          	mov    %rax,-0x60(%rbp)
 10121ae:	ba 01 00 00 00       	mov    $0x1,%edx
 10121b3:	48 8d 35 16 aa 01 00 	lea    0x1aa16(%rip),%rsi        # 102cbd0 <myl_t_1e414bd82e4b50b54939760a2d591f88da97e2f1c8252dbd7dcbc73438e46afb_body>
 10121ba:	49 89 fc             	mov    %rdi,%r12
 10121bd:	48 89 df             	mov    %rbx,%rdi
 10121c0:	e8 eb b6 00 00       	call   101d8b0 <myl_native_heap_alloc>
 10121c5:	4c 89 e7             	mov    %r12,%rdi
 10121c8:	49 89 c5             	mov    %rax,%r13
 10121cb:	41 83 fd 00          	cmp    $0x0,%r13d
 10121cf:	75 0a                	jne    10121db <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x7cb>
 10121d1:	48 89 fb             	mov    %rdi,%rbx
 10121d4:	e8 77 6d 00 00       	call   1018f50 <myl_qbe_fail_allocation>
 10121d9:	0f 0b                	ud2
 10121db:	48 87 fb             	xchg   %rdi,%rbx
 10121de:	4c 89 6d 88          	mov    %r13,-0x78(%rbp)
 10121e2:	48 8d 05 57 aa 01 00 	lea    0x1aa57(%rip),%rax        # 102cc40 <myl_t_1e414bd82e4b50b54939760a2d591f88da97e2f1c8252dbd7dcbc73438e46afb>
 10121e9:	48 89 85 00 ff ff ff 	mov    %rax,-0x100(%rbp)
 10121f0:	c7 85 18 ff ff ff 02 	movl   $0x2,-0xe8(%rbp)
 10121f7:	00 00 00 
 10121fa:	48 8d 45 88          	lea    -0x78(%rbp),%rax
 10121fe:	48 89 85 08 ff ff ff 	mov    %rax,-0xf8(%rbp)
 1012205:	4c 89 b5 10 ff ff ff 	mov    %r14,-0xf0(%rbp)
 101220c:	c7 85 18 ff ff ff 04 	movl   $0x4,-0xe8(%rbp)
 1012213:	00 00 00 
 1012216:	c7 85 48 ff ff ff 01 	movl   $0x1,-0xb8(%rbp)
 101221d:	00 00 00 
 1012220:	48 8b 4d a0          	mov    -0x60(%rbp),%rcx
 1012224:	48 8d 85 78 ff ff ff 	lea    -0x88(%rbp),%rax
 101222b:	48 f7 d8             	neg    %rax
 101222e:	48 01 c8             	add    %rcx,%rax
 1012231:	48 8d 95 78 ff ff ff 	lea    -0x88(%rbp),%rdx
 1012238:	48 29 ca             	sub    %rcx,%rdx
 101223b:	48 83 f8 10          	cmp    $0x10,%rax
 101223f:	0f 92 c0             	setb   %al
 1012242:	0f b6 c0             	movzbl %al,%eax
 1012245:	48 83 fa 10          	cmp    $0x10,%rdx
 1012249:	0f 92 c2             	setb   %dl
 101224c:	0f b6 d2             	movzbl %dl,%edx
 101224f:	09 d0                	or     %edx,%eax
 1012251:	75 7d                	jne    10122d0 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x8c0>
 1012253:	48 8b 01             	mov    (%rcx),%rax
 1012256:	48 83 f8 00          	cmp    $0x0,%rax
 101225a:	74 1a                	je     1012276 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x866>
 101225c:	48 83 e8 10          	sub    $0x10,%rax
 1012260:	48 8b 00             	mov    (%rax),%rax
 1012263:	48 ba 01 00 00 00 00 	movabs $0x5000000000000001,%rdx
 101226a:	00 00 50 
 101226d:	48 21 d0             	and    %rdx,%rax
 1012270:	48 83 f8 00          	cmp    $0x0,%rax
 1012274:	75 5a                	jne    10122d0 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x8c0>
 1012276:	48 8b 41 08          	mov    0x8(%rcx),%rax
 101227a:	48 83 f8 00          	cmp    $0x0,%rax
 101227e:	74 1a                	je     101229a <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x88a>
 1012280:	48 83 e8 10          	sub    $0x10,%rax
 1012284:	48 8b 00             	mov    (%rax),%rax
 1012287:	48 ba 01 00 00 00 00 	movabs $0x5000000000000001,%rdx
 101228e:	00 00 50 
 1012291:	48 21 d0             	and    %rdx,%rax
 1012294:	48 83 f8 00          	cmp    $0x0,%rax
 1012298:	75 36                	jne    10122d0 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x8c0>
 101229a:	48 8b 01             	mov    (%rcx),%rax
 101229d:	48 89 85 78 ff ff ff 	mov    %rax,-0x88(%rbp)
 10122a4:	48 8b 41 08          	mov    0x8(%rcx),%rax
 10122a8:	48 89 45 80          	mov    %rax,-0x80(%rbp)
 10122ac:	ba 10 00 00 00       	mov    $0x10,%edx
 10122b1:	be 00 00 00 00       	mov    $0x0,%esi
 10122b6:	49 89 fc             	mov    %rdi,%r12
 10122b9:	48 89 cf             	mov    %rcx,%rdi
 10122bc:	e8 7f 66 01 00       	call   1028940 <compiler_rt.fastMemset>
 10122c1:	4d 89 f8             	mov    %r15,%r8
 10122c4:	4c 89 e7             	mov    %r12,%rdi
 10122c7:	44 8b 65 f4          	mov    -0xc(%rbp),%r12d
 10122cb:	4d 89 c7             	mov    %r8,%r15
 10122ce:	eb 42                	jmp    1012312 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x902>
 10122d0:	4d 89 f8             	mov    %r15,%r8
 10122d3:	4d 89 c7             	mov    %r8,%r15
 10122d6:	48 8d 95 78 ff ff ff 	lea    -0x88(%rbp),%rdx
 10122dd:	48 8d 35 fc ab 01 00 	lea    0x1abfc(%rip),%rsi        # 102cee0 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 10122e4:	49 89 fc             	mov    %rdi,%r12
 10122e7:	e8 b4 62 01 00       	call   10285a0 <myl_rc_native_take>
 10122ec:	4c 89 e7             	mov    %r12,%rdi
 10122ef:	44 8b 65 f4          	mov    -0xc(%rbp),%r12d
 10122f3:	83 f8 00             	cmp    $0x0,%eax
 10122f6:	75 1a                	jne    1012312 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x902>
 10122f8:	e8 c3 ed 00 00       	call   10210c0 <myl_rc_take_failure>
 10122fd:	48 89 df             	mov    %rbx,%rdi
 1012300:	89 c6                	mov    %eax,%esi
 1012302:	48 89 fb             	mov    %rdi,%rbx
 1012305:	e8 06 65 00 00       	call   1018810 <myl_qbe_rc_status>
 101230a:	48 89 df             	mov    %rbx,%rdi
 101230d:	e9 8c 0b 00 00       	jmp    1012e9e <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x148e>
 1012312:	c7 85 30 ff ff ff 00 	movl   $0x0,-0xd0(%rbp)
 1012319:	00 00 00 
 101231c:	48 8d 05 bd ab 01 00 	lea    0x1abbd(%rip),%rax        # 102cee0 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 1012323:	48 89 85 e0 fe ff ff 	mov    %rax,-0x120(%rbp)
 101232a:	c7 85 f8 fe ff ff 02 	movl   $0x2,-0x108(%rbp)
 1012331:	00 00 00 
 1012334:	c7 85 40 ff ff ff 01 	movl   $0x1,-0xc0(%rbp)
 101233b:	00 00 00 
 101233e:	48 8b 85 78 ff ff ff 	mov    -0x88(%rbp),%rax
 1012345:	49 89 45 00          	mov    %rax,0x0(%r13)
 1012349:	48 8b 45 80          	mov    -0x80(%rbp),%rax
 101234d:	49 89 45 08          	mov    %rax,0x8(%r13)
 1012351:	c7 85 40 ff ff ff 00 	movl   $0x0,-0xc0(%rbp)
 1012358:	00 00 00 
 101235b:	4c 89 6d a0          	mov    %r13,-0x60(%rbp)
 101235f:	48 8b 45 a0          	mov    -0x60(%rbp),%rax
 1012363:	48 89 85 60 ff ff ff 	mov    %rax,-0xa0(%rbp)
 101236a:	48 8d 05 cf a8 01 00 	lea    0x1a8cf(%rip),%rax        # 102cc40 <myl_t_1e414bd82e4b50b54939760a2d591f88da97e2f1c8252dbd7dcbc73438e46afb>
 1012371:	48 89 85 a0 fe ff ff 	mov    %rax,-0x160(%rbp)
 1012378:	c7 85 b8 fe ff ff 02 	movl   $0x2,-0x148(%rbp)
 101237f:	00 00 00 
 1012382:	c7 85 30 ff ff ff 01 	movl   $0x1,-0xd0(%rbp)
 1012389:	00 00 00 
 101238c:	4c 89 6d a0          	mov    %r13,-0x60(%rbp)
 1012390:	c7 85 48 ff ff ff 00 	movl   $0x0,-0xb8(%rbp)
 1012397:	00 00 00 
 101239a:	ba 08 00 00 00       	mov    $0x8,%edx
 101239f:	be 00 00 00 00       	mov    $0x0,%esi
 10123a4:	49 89 fd             	mov    %rdi,%r13
 10123a7:	48 8d 7d d0          	lea    -0x30(%rbp),%rdi
 10123ab:	e8 90 65 01 00       	call   1028940 <compiler_rt.fastMemset>
 10123b0:	4c 89 ef             	mov    %r13,%rdi
 10123b3:	48 8d 05 b6 aa 01 00 	lea    0x1aab6(%rip),%rax        # 102ce70 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 10123ba:	48 89 85 00 ff ff ff 	mov    %rax,-0x100(%rbp)
 10123c1:	c7 85 18 ff ff ff 02 	movl   $0x2,-0xe8(%rbp)
 10123c8:	00 00 00 
 10123cb:	48 8d 45 d0          	lea    -0x30(%rbp),%rax
 10123cf:	48 89 85 08 ff ff ff 	mov    %rax,-0xf8(%rbp)
 10123d6:	4c 89 b5 10 ff ff ff 	mov    %r14,-0xf0(%rbp)
 10123dd:	c7 85 48 ff ff ff 01 	movl   $0x1,-0xb8(%rbp)
 10123e4:	00 00 00 
 10123e7:	48 8d 8d 78 ff ff ff 	lea    -0x88(%rbp),%rcx
 10123ee:	48 8d 45 a0          	lea    -0x60(%rbp),%rax
 10123f2:	48 29 c8             	sub    %rcx,%rax
 10123f5:	48 8d 55 a0          	lea    -0x60(%rbp),%rdx
 10123f9:	48 8d 8d 78 ff ff ff 	lea    -0x88(%rbp),%rcx
 1012400:	48 29 d1             	sub    %rdx,%rcx
 1012403:	48 83 f8 08          	cmp    $0x8,%rax
 1012407:	0f 92 c0             	setb   %al
 101240a:	0f b6 c0             	movzbl %al,%eax
 101240d:	48 83 f9 08          	cmp    $0x8,%rcx
 1012411:	0f 92 c1             	setb   %cl
 1012414:	0f b6 c9             	movzbl %cl,%ecx
 1012417:	09 c8                	or     %ecx,%eax
 1012419:	75 50                	jne    101246b <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xa5b>
 101241b:	48 8b 45 a0          	mov    -0x60(%rbp),%rax
 101241f:	48 83 f8 00          	cmp    $0x0,%rax
 1012423:	74 1a                	je     101243f <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xa2f>
 1012425:	48 83 e8 10          	sub    $0x10,%rax
 1012429:	48 8b 00             	mov    (%rax),%rax
 101242c:	48 b9 01 00 00 00 00 	movabs $0x5000000000000001,%rcx
 1012433:	00 00 50 
 1012436:	48 21 c8             	and    %rcx,%rax
 1012439:	48 83 f8 00          	cmp    $0x0,%rax
 101243d:	75 2c                	jne    101246b <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xa5b>
 101243f:	48 8b 45 a0          	mov    -0x60(%rbp),%rax
 1012443:	48 89 85 78 ff ff ff 	mov    %rax,-0x88(%rbp)
 101244a:	ba 08 00 00 00       	mov    $0x8,%edx
 101244f:	be 00 00 00 00       	mov    $0x0,%esi
 1012454:	49 89 fd             	mov    %rdi,%r13
 1012457:	48 8d 7d a0          	lea    -0x60(%rbp),%rdi
 101245b:	e8 e0 64 01 00       	call   1028940 <compiler_rt.fastMemset>
 1012460:	4d 89 f8             	mov    %r15,%r8
 1012463:	4c 89 ef             	mov    %r13,%rdi
 1012466:	4d 89 c7             	mov    %r8,%r15
 1012469:	eb 42                	jmp    10124ad <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xa9d>
 101246b:	4d 89 f8             	mov    %r15,%r8
 101246e:	4d 89 c7             	mov    %r8,%r15
 1012471:	48 8d 4d a0          	lea    -0x60(%rbp),%rcx
 1012475:	48 8d 95 78 ff ff ff 	lea    -0x88(%rbp),%rdx
 101247c:	48 8d 35 bd a7 01 00 	lea    0x1a7bd(%rip),%rsi        # 102cc40 <myl_t_1e414bd82e4b50b54939760a2d591f88da97e2f1c8252dbd7dcbc73438e46afb>
 1012483:	49 89 fd             	mov    %rdi,%r13
 1012486:	e8 15 61 01 00       	call   10285a0 <myl_rc_native_take>
 101248b:	4c 89 ef             	mov    %r13,%rdi
 101248e:	83 f8 00             	cmp    $0x0,%eax
 1012491:	75 1a                	jne    10124ad <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xa9d>
 1012493:	e8 28 ec 00 00       	call   10210c0 <myl_rc_take_failure>
 1012498:	48 89 df             	mov    %rbx,%rdi
 101249b:	89 c6                	mov    %eax,%esi
 101249d:	48 89 fb             	mov    %rdi,%rbx
 10124a0:	e8 6b 63 00 00       	call   1018810 <myl_qbe_rc_status>
 10124a5:	48 89 df             	mov    %rbx,%rdi
 10124a8:	e9 f1 09 00 00       	jmp    1012e9e <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x148e>
 10124ad:	c7 85 30 ff ff ff 00 	movl   $0x0,-0xd0(%rbp)
 10124b4:	00 00 00 
 10124b7:	48 8d 05 82 a7 01 00 	lea    0x1a782(%rip),%rax        # 102cc40 <myl_t_1e414bd82e4b50b54939760a2d591f88da97e2f1c8252dbd7dcbc73438e46afb>
 10124be:	48 89 85 e0 fe ff ff 	mov    %rax,-0x120(%rbp)
 10124c5:	c7 85 f8 fe ff ff 02 	movl   $0x2,-0x108(%rbp)
 10124cc:	00 00 00 
 10124cf:	c7 85 40 ff ff ff 01 	movl   $0x1,-0xc0(%rbp)
 10124d6:	00 00 00 
 10124d9:	48 8b 85 78 ff ff ff 	mov    -0x88(%rbp),%rax
 10124e0:	48 89 45 d0          	mov    %rax,-0x30(%rbp)
 10124e4:	c7 85 40 ff ff ff 00 	movl   $0x0,-0xc0(%rbp)
 10124eb:	00 00 00 
 10124ee:	48 8d 45 d0          	lea    -0x30(%rbp),%rax
 10124f2:	48 89 45 a0          	mov    %rax,-0x60(%rbp)
 10124f6:	48 8b 45 d0          	mov    -0x30(%rbp),%rax
 10124fa:	48 89 85 60 ff ff ff 	mov    %rax,-0xa0(%rbp)
 1012501:	48 8d 05 68 a9 01 00 	lea    0x1a968(%rip),%rax        # 102ce70 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 1012508:	48 89 85 a0 fe ff ff 	mov    %rax,-0x160(%rbp)
 101250f:	c7 85 b8 fe ff ff 02 	movl   $0x2,-0x148(%rbp)
 1012516:	00 00 00 
 1012519:	c7 85 30 ff ff ff 01 	movl   $0x1,-0xd0(%rbp)
 1012520:	00 00 00 
 1012523:	48 8d 85 60 ff ff ff 	lea    -0xa0(%rbp),%rax
 101252a:	48 89 45 a0          	mov    %rax,-0x60(%rbp)
 101252e:	c7 85 48 ff ff ff 00 	movl   $0x0,-0xb8(%rbp)
 1012535:	00 00 00 
 1012538:	ba 10 00 00 00       	mov    $0x10,%edx
 101253d:	be 00 00 00 00       	mov    $0x0,%esi
 1012542:	49 89 fd             	mov    %rdi,%r13
 1012545:	48 8d 7d d8          	lea    -0x28(%rbp),%rdi
 1012549:	e8 f2 63 01 00       	call   1028940 <compiler_rt.fastMemset>
 101254e:	4d 89 f8             	mov    %r15,%r8
 1012551:	4c 89 ef             	mov    %r13,%rdi
 1012554:	44 8b 6d f0          	mov    -0x10(%rbp),%r13d
 1012558:	48 8d 05 81 a9 01 00 	lea    0x1a981(%rip),%rax        # 102cee0 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 101255f:	48 89 85 00 ff ff ff 	mov    %rax,-0x100(%rbp)
 1012566:	c7 85 18 ff ff ff 02 	movl   $0x2,-0xe8(%rbp)
 101256d:	00 00 00 
 1012570:	48 8d 45 d8          	lea    -0x28(%rbp),%rax
 1012574:	48 89 85 08 ff ff ff 	mov    %rax,-0xf8(%rbp)
 101257b:	4c 89 b5 10 ff ff ff 	mov    %r14,-0xf0(%rbp)
 1012582:	c7 85 48 ff ff ff 01 	movl   $0x1,-0xb8(%rbp)
 1012589:	00 00 00 
 101258c:	48 8b 4d 98          	mov    -0x68(%rbp),%rcx
 1012590:	8b 85 28 ff ff ff    	mov    -0xd8(%rbp),%eax
 1012596:	83 f8 00             	cmp    $0x0,%eax
 1012599:	75 62                	jne    10125fd <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xbed>
 101259b:	4d 89 c7             	mov    %r8,%r15
 101259e:	48 8d 95 78 ff ff ff 	lea    -0x88(%rbp),%rdx
 10125a5:	48 8d 35 c4 a8 01 00 	lea    0x1a8c4(%rip),%rsi        # 102ce70 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 10125ac:	49 89 fe             	mov    %rdi,%r14
 10125af:	e8 4c 5b 01 00       	call   1028100 <myl_rc_native_copy>
 10125b4:	4c 89 f7             	mov    %r14,%rdi
 10125b7:	83 f8 00             	cmp    $0x0,%eax
 10125ba:	75 1a                	jne    10125d6 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xbc6>
 10125bc:	e8 ff ea 00 00       	call   10210c0 <myl_rc_take_failure>
 10125c1:	48 89 df             	mov    %rbx,%rdi
 10125c4:	89 c6                	mov    %eax,%esi
 10125c6:	48 89 fb             	mov    %rdi,%rbx
 10125c9:	e8 42 62 00 00       	call   1018810 <myl_qbe_rc_status>
 10125ce:	48 89 df             	mov    %rbx,%rdi
 10125d1:	e9 c8 08 00 00       	jmp    1012e9e <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x148e>
 10125d6:	48 8d 05 93 a8 01 00 	lea    0x1a893(%rip),%rax        # 102ce70 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 10125dd:	48 89 85 e0 fe ff ff 	mov    %rax,-0x120(%rbp)
 10125e4:	c7 85 f8 fe ff ff 02 	movl   $0x2,-0x108(%rbp)
 10125eb:	00 00 00 
 10125ee:	c7 85 40 ff ff ff 01 	movl   $0x1,-0xc0(%rbp)
 10125f5:	00 00 00 
 10125f8:	e9 e9 00 00 00       	jmp    10126e6 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xcd6>
 10125fd:	4d 89 c7             	mov    %r8,%r15
 1012600:	48 8d 85 78 ff ff ff 	lea    -0x88(%rbp),%rax
 1012607:	48 f7 d8             	neg    %rax
 101260a:	48 01 c8             	add    %rcx,%rax
 101260d:	48 8d 95 78 ff ff ff 	lea    -0x88(%rbp),%rdx
 1012614:	48 29 ca             	sub    %rcx,%rdx
 1012617:	48 83 f8 08          	cmp    $0x8,%rax
 101261b:	0f 92 c0             	setb   %al
 101261e:	0f b6 c0             	movzbl %al,%eax
 1012621:	48 83 fa 08          	cmp    $0x8,%rdx
 1012625:	0f 92 c2             	setb   %dl
 1012628:	0f b6 d2             	movzbl %dl,%edx
 101262b:	09 d0                	or     %edx,%eax
 101262d:	75 4d                	jne    101267c <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xc6c>
 101262f:	48 8b 01             	mov    (%rcx),%rax
 1012632:	48 83 f8 00          	cmp    $0x0,%rax
 1012636:	74 1a                	je     1012652 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xc42>
 1012638:	48 83 e8 10          	sub    $0x10,%rax
 101263c:	48 8b 00             	mov    (%rax),%rax
 101263f:	48 ba 01 00 00 00 00 	movabs $0x5000000000000001,%rdx
 1012646:	00 00 50 
 1012649:	48 21 d0             	and    %rdx,%rax
 101264c:	48 83 f8 00          	cmp    $0x0,%rax
 1012650:	75 2a                	jne    101267c <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xc6c>
 1012652:	48 8b 01             	mov    (%rcx),%rax
 1012655:	48 89 85 78 ff ff ff 	mov    %rax,-0x88(%rbp)
 101265c:	ba 08 00 00 00       	mov    $0x8,%edx
 1012661:	be 00 00 00 00       	mov    $0x0,%esi
 1012666:	49 89 fe             	mov    %rdi,%r14
 1012669:	48 89 cf             	mov    %rcx,%rdi
 101266c:	e8 cf 62 01 00       	call   1028940 <compiler_rt.fastMemset>
 1012671:	4d 89 f8             	mov    %r15,%r8
 1012674:	4c 89 f7             	mov    %r14,%rdi
 1012677:	4d 89 c7             	mov    %r8,%r15
 101267a:	eb 3e                	jmp    10126ba <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xcaa>
 101267c:	4d 89 f8             	mov    %r15,%r8
 101267f:	4d 89 c7             	mov    %r8,%r15
 1012682:	48 8d 95 78 ff ff ff 	lea    -0x88(%rbp),%rdx
 1012689:	48 8d 35 e0 a7 01 00 	lea    0x1a7e0(%rip),%rsi        # 102ce70 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 1012690:	49 89 fe             	mov    %rdi,%r14
 1012693:	e8 08 5f 01 00       	call   10285a0 <myl_rc_native_take>
 1012698:	4c 89 f7             	mov    %r14,%rdi
 101269b:	83 f8 00             	cmp    $0x0,%eax
 101269e:	75 1a                	jne    10126ba <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xcaa>
 10126a0:	e8 1b ea 00 00       	call   10210c0 <myl_rc_take_failure>
 10126a5:	48 89 df             	mov    %rbx,%rdi
 10126a8:	89 c6                	mov    %eax,%esi
 10126aa:	48 89 fb             	mov    %rdi,%rbx
 10126ad:	e8 5e 61 00 00       	call   1018810 <myl_qbe_rc_status>
 10126b2:	48 89 df             	mov    %rbx,%rdi
 10126b5:	e9 e4 07 00 00       	jmp    1012e9e <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x148e>
 10126ba:	c7 85 28 ff ff ff 00 	movl   $0x0,-0xd8(%rbp)
 10126c1:	00 00 00 
 10126c4:	48 8d 05 a5 a7 01 00 	lea    0x1a7a5(%rip),%rax        # 102ce70 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 10126cb:	48 89 85 e0 fe ff ff 	mov    %rax,-0x120(%rbp)
 10126d2:	c7 85 f8 fe ff ff 02 	movl   $0x2,-0x108(%rbp)
 10126d9:	00 00 00 
 10126dc:	c7 85 40 ff ff ff 01 	movl   $0x1,-0xc0(%rbp)
 10126e3:	00 00 00 
 10126e6:	48 8b 85 78 ff ff ff 	mov    -0x88(%rbp),%rax
 10126ed:	48 89 45 d8          	mov    %rax,-0x28(%rbp)
 10126f1:	c7 85 40 ff ff ff 00 	movl   $0x0,-0xc0(%rbp)
 10126f8:	00 00 00 
 10126fb:	48 8b 4d a0          	mov    -0x60(%rbp),%rcx
 10126ff:	48 8d 85 78 ff ff ff 	lea    -0x88(%rbp),%rax
 1012706:	48 f7 d8             	neg    %rax
 1012709:	48 01 c8             	add    %rcx,%rax
 101270c:	48 8d 95 78 ff ff ff 	lea    -0x88(%rbp),%rdx
 1012713:	48 29 ca             	sub    %rcx,%rdx
 1012716:	48 83 f8 08          	cmp    $0x8,%rax
 101271a:	0f 92 c0             	setb   %al
 101271d:	0f b6 c0             	movzbl %al,%eax
 1012720:	48 83 fa 08          	cmp    $0x8,%rdx
 1012724:	0f 92 c2             	setb   %dl
 1012727:	0f b6 d2             	movzbl %dl,%edx
 101272a:	09 d0                	or     %edx,%eax
 101272c:	75 4d                	jne    101277b <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xd6b>
 101272e:	48 8b 01             	mov    (%rcx),%rax
 1012731:	48 83 f8 00          	cmp    $0x0,%rax
 1012735:	74 1a                	je     1012751 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xd41>
 1012737:	48 83 e8 10          	sub    $0x10,%rax
 101273b:	48 8b 00             	mov    (%rax),%rax
 101273e:	48 ba 01 00 00 00 00 	movabs $0x5000000000000001,%rdx
 1012745:	00 00 50 
 1012748:	48 21 d0             	and    %rdx,%rax
 101274b:	48 83 f8 00          	cmp    $0x0,%rax
 101274f:	75 2a                	jne    101277b <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xd6b>
 1012751:	48 8b 01             	mov    (%rcx),%rax
 1012754:	48 89 85 78 ff ff ff 	mov    %rax,-0x88(%rbp)
 101275b:	ba 08 00 00 00       	mov    $0x8,%edx
 1012760:	be 00 00 00 00       	mov    $0x0,%esi
 1012765:	49 89 fe             	mov    %rdi,%r14
 1012768:	48 89 cf             	mov    %rcx,%rdi
 101276b:	e8 d0 61 01 00       	call   1028940 <compiler_rt.fastMemset>
 1012770:	4d 89 f8             	mov    %r15,%r8
 1012773:	4c 89 f7             	mov    %r14,%rdi
 1012776:	48 87 df             	xchg   %rbx,%rdi
 1012779:	eb 44                	jmp    10127bf <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xdaf>
 101277b:	4d 89 f8             	mov    %r15,%r8
 101277e:	4d 89 c7             	mov    %r8,%r15
 1012781:	48 8d 95 78 ff ff ff 	lea    -0x88(%rbp),%rdx
 1012788:	48 8d 35 e1 a6 01 00 	lea    0x1a6e1(%rip),%rsi        # 102ce70 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 101278f:	49 89 fe             	mov    %rdi,%r14
 1012792:	e8 09 5e 01 00       	call   10285a0 <myl_rc_native_take>
 1012797:	4d 89 f8             	mov    %r15,%r8
 101279a:	4c 89 f7             	mov    %r14,%rdi
 101279d:	83 f8 00             	cmp    $0x0,%eax
 10127a0:	75 1a                	jne    10127bc <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xdac>
 10127a2:	e8 19 e9 00 00       	call   10210c0 <myl_rc_take_failure>
 10127a7:	48 89 df             	mov    %rbx,%rdi
 10127aa:	89 c6                	mov    %eax,%esi
 10127ac:	48 89 fb             	mov    %rdi,%rbx
 10127af:	e8 5c 60 00 00       	call   1018810 <myl_qbe_rc_status>
 10127b4:	48 89 df             	mov    %rbx,%rdi
 10127b7:	e9 e2 06 00 00       	jmp    1012e9e <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x148e>
 10127bc:	48 87 df             	xchg   %rbx,%rdi
 10127bf:	c7 85 30 ff ff ff 00 	movl   $0x0,-0xd0(%rbp)
 10127c6:	00 00 00 
 10127c9:	48 8d 05 a0 a6 01 00 	lea    0x1a6a0(%rip),%rax        # 102ce70 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 10127d0:	48 89 85 e0 fe ff ff 	mov    %rax,-0x120(%rbp)
 10127d7:	c7 85 f8 fe ff ff 02 	movl   $0x2,-0x108(%rbp)
 10127de:	00 00 00 
 10127e1:	c7 85 40 ff ff ff 01 	movl   $0x1,-0xc0(%rbp)
 10127e8:	00 00 00 
 10127eb:	48 8b 85 78 ff ff ff 	mov    -0x88(%rbp),%rax
 10127f2:	48 89 45 e0          	mov    %rax,-0x20(%rbp)
 10127f6:	c7 85 40 ff ff ff 00 	movl   $0x0,-0xc0(%rbp)
 10127fd:	00 00 00 
 1012800:	48 8d 45 d8          	lea    -0x28(%rbp),%rax
 1012804:	48 89 45 98          	mov    %rax,-0x68(%rbp)
 1012808:	48 8b 45 d8          	mov    -0x28(%rbp),%rax
 101280c:	48 89 85 50 ff ff ff 	mov    %rax,-0xb0(%rbp)
 1012813:	48 8b 45 e0          	mov    -0x20(%rbp),%rax
 1012817:	48 89 85 58 ff ff ff 	mov    %rax,-0xa8(%rbp)
 101281e:	48 8d 05 bb a6 01 00 	lea    0x1a6bb(%rip),%rax        # 102cee0 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 1012825:	48 89 85 80 fe ff ff 	mov    %rax,-0x180(%rbp)
 101282c:	c7 85 98 fe ff ff 02 	movl   $0x2,-0x168(%rbp)
 1012833:	00 00 00 
 1012836:	c7 85 28 ff ff ff 01 	movl   $0x1,-0xd8(%rbp)
 101283d:	00 00 00 
 1012840:	48 8d 85 50 ff ff ff 	lea    -0xb0(%rbp),%rax
 1012847:	48 89 45 98          	mov    %rax,-0x68(%rbp)
 101284b:	c7 85 48 ff ff ff 00 	movl   $0x0,-0xb8(%rbp)
 1012852:	00 00 00 
 1012855:	44 89 e0             	mov    %r12d,%eax
 1012858:	44 09 e8             	or     %r13d,%eax
 101285b:	0f 85 8f 00 00 00    	jne    10128f0 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xee0>
 1012861:	48 8b 85 50 ff ff ff 	mov    -0xb0(%rbp),%rax
 1012868:	48 83 f8 00          	cmp    $0x0,%rax
 101286c:	74 1a                	je     1012888 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xe78>
 101286e:	48 83 e8 10          	sub    $0x10,%rax
 1012872:	48 8b 00             	mov    (%rax),%rax
 1012875:	48 b9 01 00 00 00 00 	movabs $0x5000000000000001,%rcx
 101287c:	00 00 50 
 101287f:	48 21 c8             	and    %rcx,%rax
 1012882:	48 83 f8 00          	cmp    $0x0,%rax
 1012886:	75 63                	jne    10128eb <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xedb>
 1012888:	48 8b 85 58 ff ff ff 	mov    -0xa8(%rbp),%rax
 101288f:	48 83 f8 00          	cmp    $0x0,%rax
 1012893:	74 1a                	je     10128af <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xe9f>
 1012895:	48 83 e8 10          	sub    $0x10,%rax
 1012899:	48 8b 00             	mov    (%rax),%rax
 101289c:	48 b9 01 00 00 00 00 	movabs $0x5000000000000001,%rcx
 10128a3:	00 00 50 
 10128a6:	48 21 c8             	and    %rcx,%rax
 10128a9:	48 83 f8 00          	cmp    $0x0,%rax
 10128ad:	75 37                	jne    10128e6 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xed6>
 10128af:	48 8b 85 50 ff ff ff 	mov    -0xb0(%rbp),%rax
 10128b6:	48 89 85 78 ff ff ff 	mov    %rax,-0x88(%rbp)
 10128bd:	48 8b 85 58 ff ff ff 	mov    -0xa8(%rbp),%rax
 10128c4:	48 89 45 80          	mov    %rax,-0x80(%rbp)
 10128c8:	ba 10 00 00 00       	mov    $0x10,%edx
 10128cd:	be 00 00 00 00       	mov    $0x0,%esi
 10128d2:	48 89 fb             	mov    %rdi,%rbx
 10128d5:	48 8d bd 50 ff ff ff 	lea    -0xb0(%rbp),%rdi
 10128dc:	e8 5f 60 01 00       	call   1028940 <compiler_rt.fastMemset>
 10128e1:	48 89 df             	mov    %rbx,%rdi
 10128e4:	eb 52                	jmp    1012938 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xf28>
 10128e6:	48 87 fb             	xchg   %rdi,%rbx
 10128e9:	eb 08                	jmp    10128f3 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xee3>
 10128eb:	48 87 fb             	xchg   %rdi,%rbx
 10128ee:	eb 03                	jmp    10128f3 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xee3>
 10128f0:	48 87 fb             	xchg   %rdi,%rbx
 10128f3:	4d 89 c7             	mov    %r8,%r15
 10128f6:	48 8d 8d 50 ff ff ff 	lea    -0xb0(%rbp),%rcx
 10128fd:	48 8d 95 78 ff ff ff 	lea    -0x88(%rbp),%rdx
 1012904:	48 8d 35 d5 a5 01 00 	lea    0x1a5d5(%rip),%rsi        # 102cee0 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 101290b:	49 89 fc             	mov    %rdi,%r12
 101290e:	e8 8d 5c 01 00       	call   10285a0 <myl_rc_native_take>
 1012913:	4c 89 e7             	mov    %r12,%rdi
 1012916:	83 f8 00             	cmp    $0x0,%eax
 1012919:	75 1a                	jne    1012935 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xf25>
 101291b:	e8 a0 e7 00 00       	call   10210c0 <myl_rc_take_failure>
 1012920:	48 89 df             	mov    %rbx,%rdi
 1012923:	89 c6                	mov    %eax,%esi
 1012925:	48 89 fb             	mov    %rdi,%rbx
 1012928:	e8 e3 5e 00 00       	call   1018810 <myl_qbe_rc_status>
 101292d:	48 89 df             	mov    %rbx,%rdi
 1012930:	e9 69 05 00 00       	jmp    1012e9e <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x148e>
 1012935:	48 89 df             	mov    %rbx,%rdi
 1012938:	c7 85 28 ff ff ff 00 	movl   $0x0,-0xd8(%rbp)
 101293f:	00 00 00 
 1012942:	48 8d 05 97 a5 01 00 	lea    0x1a597(%rip),%rax        # 102cee0 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 1012949:	48 89 85 e0 fe ff ff 	mov    %rax,-0x120(%rbp)
 1012950:	c7 85 f8 fe ff ff 02 	movl   $0x2,-0x108(%rbp)
 1012957:	00 00 00 
 101295a:	c7 85 40 ff ff ff 01 	movl   $0x1,-0xc0(%rbp)
 1012961:	00 00 00 
 1012964:	c7 85 40 ff ff ff 00 	movl   $0x0,-0xc0(%rbp)
 101296b:	00 00 00 
 101296e:	48 8d b5 40 fe ff ff 	lea    -0x1c0(%rbp),%rsi
 1012975:	48 89 fb             	mov    %rdi,%rbx
 1012978:	e8 73 61 00 00       	call   1018af0 <myl_qbe_rc_frame_cleanup>
 101297d:	48 89 df             	mov    %rbx,%rdi
 1012980:	48 8d b5 40 fe ff ff 	lea    -0x1c0(%rbp),%rsi
 1012987:	e8 f4 5f 00 00       	call   1018980 <myl_qbe_rc_frame_leave>
 101298c:	48 8b 85 78 ff ff ff 	mov    -0x88(%rbp),%rax
 1012993:	48 8b 55 80          	mov    -0x80(%rbp),%rdx
 1012997:	e9 a8 05 00 00       	jmp    1012f44 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1534>
 101299c:	41 b8 40 00 00 00    	mov    $0x40,%r8d
 10129a2:	b9 01 00 00 00       	mov    $0x1,%ecx
 10129a7:	be 01 00 00 00       	mov    $0x1,%esi
 10129ac:	e8 df 66 00 00       	call   1019090 <myl_qbe_fail_overflow_op>
 10129b1:	0f 0b                	ud2
 10129b3:	41 b8 40 00 00 00    	mov    $0x40,%r8d
 10129b9:	b9 01 00 00 00       	mov    $0x1,%ecx
 10129be:	be 01 00 00 00       	mov    $0x1,%esi
 10129c3:	48 89 fb             	mov    %rdi,%rbx
 10129c6:	e8 c5 66 00 00       	call   1019090 <myl_qbe_fail_overflow_op>
 10129cb:	0f 0b                	ud2
 10129cd:	48 87 fb             	xchg   %rdi,%rbx
 10129d0:	ba 08 00 00 00       	mov    $0x8,%edx
 10129d5:	be 00 00 00 00       	mov    $0x0,%esi
 10129da:	49 89 fd             	mov    %rdi,%r13
 10129dd:	48 8d 7d a8          	lea    -0x58(%rbp),%rdi
 10129e1:	e8 5a 5f 01 00       	call   1028940 <compiler_rt.fastMemset>
 10129e6:	4c 89 ef             	mov    %r13,%rdi
 10129e9:	48 c7 45 a8 00 00 00 	movq   $0x0,-0x58(%rbp)
 10129f0:	00 
 10129f1:	48 8d 45 a8          	lea    -0x58(%rbp),%rax
 10129f5:	48 89 45 98          	mov    %rax,-0x68(%rbp)
 10129f9:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
 10129fd:	48 89 85 50 ff ff ff 	mov    %rax,-0xb0(%rbp)
 1012a04:	48 8d 05 65 a4 01 00 	lea    0x1a465(%rip),%rax        # 102ce70 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 1012a0b:	48 89 85 80 fe ff ff 	mov    %rax,-0x180(%rbp)
 1012a12:	c7 85 98 fe ff ff 02 	movl   $0x2,-0x168(%rbp)
 1012a19:	00 00 00 
 1012a1c:	c7 85 28 ff ff ff 01 	movl   $0x1,-0xd8(%rbp)
 1012a23:	00 00 00 
 1012a26:	48 8d 85 50 ff ff ff 	lea    -0xb0(%rbp),%rax
 1012a2d:	48 89 45 98          	mov    %rax,-0x68(%rbp)
 1012a31:	c7 85 48 ff ff ff 00 	movl   $0x0,-0xb8(%rbp)
 1012a38:	00 00 00 
 1012a3b:	ba 08 00 00 00       	mov    $0x8,%edx
 1012a40:	be 00 00 00 00       	mov    $0x0,%esi
 1012a45:	49 89 fd             	mov    %rdi,%r13
 1012a48:	48 8d 7d b0          	lea    -0x50(%rbp),%rdi
 1012a4c:	e8 ef 5e 01 00       	call   1028940 <compiler_rt.fastMemset>
 1012a51:	4c 89 ef             	mov    %r13,%rdi
 1012a54:	48 c7 45 b0 00 00 00 	movq   $0x0,-0x50(%rbp)
 1012a5b:	00 
 1012a5c:	48 8d 45 b0          	lea    -0x50(%rbp),%rax
 1012a60:	48 89 45 a0          	mov    %rax,-0x60(%rbp)
 1012a64:	48 8b 45 b0          	mov    -0x50(%rbp),%rax
 1012a68:	48 89 85 60 ff ff ff 	mov    %rax,-0xa0(%rbp)
 1012a6f:	48 8d 05 fa a3 01 00 	lea    0x1a3fa(%rip),%rax        # 102ce70 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 1012a76:	48 89 85 a0 fe ff ff 	mov    %rax,-0x160(%rbp)
 1012a7d:	c7 85 b8 fe ff ff 02 	movl   $0x2,-0x148(%rbp)
 1012a84:	00 00 00 
 1012a87:	c7 85 30 ff ff ff 01 	movl   $0x1,-0xd0(%rbp)
 1012a8e:	00 00 00 
 1012a91:	48 8d 85 60 ff ff ff 	lea    -0xa0(%rbp),%rax
 1012a98:	48 89 45 a0          	mov    %rax,-0x60(%rbp)
 1012a9c:	c7 85 48 ff ff ff 00 	movl   $0x0,-0xb8(%rbp)
 1012aa3:	00 00 00 
 1012aa6:	ba 10 00 00 00       	mov    $0x10,%edx
 1012aab:	be 00 00 00 00       	mov    $0x0,%esi
 1012ab0:	49 89 fd             	mov    %rdi,%r13
 1012ab3:	48 8d 7d b8          	lea    -0x48(%rbp),%rdi
 1012ab7:	e8 84 5e 01 00       	call   1028940 <compiler_rt.fastMemset>
 1012abc:	4d 89 f8             	mov    %r15,%r8
 1012abf:	4c 89 ef             	mov    %r13,%rdi
 1012ac2:	44 8b 6d f0          	mov    -0x10(%rbp),%r13d
 1012ac6:	48 8d 05 13 a4 01 00 	lea    0x1a413(%rip),%rax        # 102cee0 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 1012acd:	48 89 85 00 ff ff ff 	mov    %rax,-0x100(%rbp)
 1012ad4:	c7 85 18 ff ff ff 02 	movl   $0x2,-0xe8(%rbp)
 1012adb:	00 00 00 
 1012ade:	48 8d 45 b8          	lea    -0x48(%rbp),%rax
 1012ae2:	48 89 85 08 ff ff ff 	mov    %rax,-0xf8(%rbp)
 1012ae9:	4c 89 b5 10 ff ff ff 	mov    %r14,-0xf0(%rbp)
 1012af0:	c7 85 48 ff ff ff 01 	movl   $0x1,-0xb8(%rbp)
 1012af7:	00 00 00 
 1012afa:	48 8b 4d 98          	mov    -0x68(%rbp),%rcx
 1012afe:	8b 85 28 ff ff ff    	mov    -0xd8(%rbp),%eax
 1012b04:	83 f8 00             	cmp    $0x0,%eax
 1012b07:	75 62                	jne    1012b6b <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x115b>
 1012b09:	4d 89 c7             	mov    %r8,%r15
 1012b0c:	48 8d 95 78 ff ff ff 	lea    -0x88(%rbp),%rdx
 1012b13:	48 8d 35 56 a3 01 00 	lea    0x1a356(%rip),%rsi        # 102ce70 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 1012b1a:	49 89 fe             	mov    %rdi,%r14
 1012b1d:	e8 de 55 01 00       	call   1028100 <myl_rc_native_copy>
 1012b22:	4c 89 f7             	mov    %r14,%rdi
 1012b25:	83 f8 00             	cmp    $0x0,%eax
 1012b28:	75 1a                	jne    1012b44 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1134>
 1012b2a:	e8 91 e5 00 00       	call   10210c0 <myl_rc_take_failure>
 1012b2f:	48 89 df             	mov    %rbx,%rdi
 1012b32:	89 c6                	mov    %eax,%esi
 1012b34:	48 89 fb             	mov    %rdi,%rbx
 1012b37:	e8 d4 5c 00 00       	call   1018810 <myl_qbe_rc_status>
 1012b3c:	48 89 df             	mov    %rbx,%rdi
 1012b3f:	e9 5a 03 00 00       	jmp    1012e9e <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x148e>
 1012b44:	48 8d 05 25 a3 01 00 	lea    0x1a325(%rip),%rax        # 102ce70 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 1012b4b:	48 89 85 e0 fe ff ff 	mov    %rax,-0x120(%rbp)
 1012b52:	c7 85 f8 fe ff ff 02 	movl   $0x2,-0x108(%rbp)
 1012b59:	00 00 00 
 1012b5c:	c7 85 40 ff ff ff 01 	movl   $0x1,-0xc0(%rbp)
 1012b63:	00 00 00 
 1012b66:	e9 e9 00 00 00       	jmp    1012c54 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1244>
 1012b6b:	4d 89 c7             	mov    %r8,%r15
 1012b6e:	48 8d 85 78 ff ff ff 	lea    -0x88(%rbp),%rax
 1012b75:	48 f7 d8             	neg    %rax
 1012b78:	48 01 c8             	add    %rcx,%rax
 1012b7b:	48 8d 95 78 ff ff ff 	lea    -0x88(%rbp),%rdx
 1012b82:	48 29 ca             	sub    %rcx,%rdx
 1012b85:	48 83 f8 08          	cmp    $0x8,%rax
 1012b89:	0f 92 c0             	setb   %al
 1012b8c:	0f b6 c0             	movzbl %al,%eax
 1012b8f:	48 83 fa 08          	cmp    $0x8,%rdx
 1012b93:	0f 92 c2             	setb   %dl
 1012b96:	0f b6 d2             	movzbl %dl,%edx
 1012b99:	09 d0                	or     %edx,%eax
 1012b9b:	75 4d                	jne    1012bea <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x11da>
 1012b9d:	48 8b 01             	mov    (%rcx),%rax
 1012ba0:	48 83 f8 00          	cmp    $0x0,%rax
 1012ba4:	74 1a                	je     1012bc0 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x11b0>
 1012ba6:	48 83 e8 10          	sub    $0x10,%rax
 1012baa:	48 8b 00             	mov    (%rax),%rax
 1012bad:	48 ba 01 00 00 00 00 	movabs $0x5000000000000001,%rdx
 1012bb4:	00 00 50 
 1012bb7:	48 21 d0             	and    %rdx,%rax
 1012bba:	48 83 f8 00          	cmp    $0x0,%rax
 1012bbe:	75 2a                	jne    1012bea <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x11da>
 1012bc0:	48 8b 01             	mov    (%rcx),%rax
 1012bc3:	48 89 85 78 ff ff ff 	mov    %rax,-0x88(%rbp)
 1012bca:	ba 08 00 00 00       	mov    $0x8,%edx
 1012bcf:	be 00 00 00 00       	mov    $0x0,%esi
 1012bd4:	49 89 fe             	mov    %rdi,%r14
 1012bd7:	48 89 cf             	mov    %rcx,%rdi
 1012bda:	e8 61 5d 01 00       	call   1028940 <compiler_rt.fastMemset>
 1012bdf:	4d 89 f8             	mov    %r15,%r8
 1012be2:	4c 89 f7             	mov    %r14,%rdi
 1012be5:	4d 89 c7             	mov    %r8,%r15
 1012be8:	eb 3e                	jmp    1012c28 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1218>
 1012bea:	4d 89 f8             	mov    %r15,%r8
 1012bed:	4d 89 c7             	mov    %r8,%r15
 1012bf0:	48 8d 95 78 ff ff ff 	lea    -0x88(%rbp),%rdx
 1012bf7:	48 8d 35 72 a2 01 00 	lea    0x1a272(%rip),%rsi        # 102ce70 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 1012bfe:	49 89 fe             	mov    %rdi,%r14
 1012c01:	e8 9a 59 01 00       	call   10285a0 <myl_rc_native_take>
 1012c06:	4c 89 f7             	mov    %r14,%rdi
 1012c09:	83 f8 00             	cmp    $0x0,%eax
 1012c0c:	75 1a                	jne    1012c28 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1218>
 1012c0e:	e8 ad e4 00 00       	call   10210c0 <myl_rc_take_failure>
 1012c13:	48 89 df             	mov    %rbx,%rdi
 1012c16:	89 c6                	mov    %eax,%esi
 1012c18:	48 89 fb             	mov    %rdi,%rbx
 1012c1b:	e8 f0 5b 00 00       	call   1018810 <myl_qbe_rc_status>
 1012c20:	48 89 df             	mov    %rbx,%rdi
 1012c23:	e9 76 02 00 00       	jmp    1012e9e <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x148e>
 1012c28:	c7 85 28 ff ff ff 00 	movl   $0x0,-0xd8(%rbp)
 1012c2f:	00 00 00 
 1012c32:	48 8d 05 37 a2 01 00 	lea    0x1a237(%rip),%rax        # 102ce70 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 1012c39:	48 89 85 e0 fe ff ff 	mov    %rax,-0x120(%rbp)
 1012c40:	c7 85 f8 fe ff ff 02 	movl   $0x2,-0x108(%rbp)
 1012c47:	00 00 00 
 1012c4a:	c7 85 40 ff ff ff 01 	movl   $0x1,-0xc0(%rbp)
 1012c51:	00 00 00 
 1012c54:	48 8b 85 78 ff ff ff 	mov    -0x88(%rbp),%rax
 1012c5b:	48 89 45 b8          	mov    %rax,-0x48(%rbp)
 1012c5f:	c7 85 40 ff ff ff 00 	movl   $0x0,-0xc0(%rbp)
 1012c66:	00 00 00 
 1012c69:	48 8b 4d a0          	mov    -0x60(%rbp),%rcx
 1012c6d:	48 8d 85 78 ff ff ff 	lea    -0x88(%rbp),%rax
 1012c74:	48 f7 d8             	neg    %rax
 1012c77:	48 01 c8             	add    %rcx,%rax
 1012c7a:	48 8d 95 78 ff ff ff 	lea    -0x88(%rbp),%rdx
 1012c81:	48 29 ca             	sub    %rcx,%rdx
 1012c84:	48 83 f8 08          	cmp    $0x8,%rax
 1012c88:	0f 92 c0             	setb   %al
 1012c8b:	0f b6 c0             	movzbl %al,%eax
 1012c8e:	48 83 fa 08          	cmp    $0x8,%rdx
 1012c92:	0f 92 c2             	setb   %dl
 1012c95:	0f b6 d2             	movzbl %dl,%edx
 1012c98:	09 d0                	or     %edx,%eax
 1012c9a:	75 4d                	jne    1012ce9 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x12d9>
 1012c9c:	48 8b 01             	mov    (%rcx),%rax
 1012c9f:	48 83 f8 00          	cmp    $0x0,%rax
 1012ca3:	74 1a                	je     1012cbf <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x12af>
 1012ca5:	48 83 e8 10          	sub    $0x10,%rax
 1012ca9:	48 8b 00             	mov    (%rax),%rax
 1012cac:	48 ba 01 00 00 00 00 	movabs $0x5000000000000001,%rdx
 1012cb3:	00 00 50 
 1012cb6:	48 21 d0             	and    %rdx,%rax
 1012cb9:	48 83 f8 00          	cmp    $0x0,%rax
 1012cbd:	75 2a                	jne    1012ce9 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x12d9>
 1012cbf:	48 8b 01             	mov    (%rcx),%rax
 1012cc2:	48 89 85 78 ff ff ff 	mov    %rax,-0x88(%rbp)
 1012cc9:	ba 08 00 00 00       	mov    $0x8,%edx
 1012cce:	be 00 00 00 00       	mov    $0x0,%esi
 1012cd3:	49 89 fe             	mov    %rdi,%r14
 1012cd6:	48 89 cf             	mov    %rcx,%rdi
 1012cd9:	e8 62 5c 01 00       	call   1028940 <compiler_rt.fastMemset>
 1012cde:	4d 89 f8             	mov    %r15,%r8
 1012ce1:	4c 89 f7             	mov    %r14,%rdi
 1012ce4:	48 87 df             	xchg   %rbx,%rdi
 1012ce7:	eb 44                	jmp    1012d2d <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x131d>
 1012ce9:	4d 89 f8             	mov    %r15,%r8
 1012cec:	4d 89 c7             	mov    %r8,%r15
 1012cef:	48 8d 95 78 ff ff ff 	lea    -0x88(%rbp),%rdx
 1012cf6:	48 8d 35 73 a1 01 00 	lea    0x1a173(%rip),%rsi        # 102ce70 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 1012cfd:	49 89 fe             	mov    %rdi,%r14
 1012d00:	e8 9b 58 01 00       	call   10285a0 <myl_rc_native_take>
 1012d05:	4d 89 f8             	mov    %r15,%r8
 1012d08:	4c 89 f7             	mov    %r14,%rdi
 1012d0b:	83 f8 00             	cmp    $0x0,%eax
 1012d0e:	75 1a                	jne    1012d2a <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x131a>
 1012d10:	e8 ab e3 00 00       	call   10210c0 <myl_rc_take_failure>
 1012d15:	48 89 df             	mov    %rbx,%rdi
 1012d18:	89 c6                	mov    %eax,%esi
 1012d1a:	48 89 fb             	mov    %rdi,%rbx
 1012d1d:	e8 ee 5a 00 00       	call   1018810 <myl_qbe_rc_status>
 1012d22:	48 89 df             	mov    %rbx,%rdi
 1012d25:	e9 74 01 00 00       	jmp    1012e9e <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x148e>
 1012d2a:	48 87 df             	xchg   %rbx,%rdi
 1012d2d:	c7 85 30 ff ff ff 00 	movl   $0x0,-0xd0(%rbp)
 1012d34:	00 00 00 
 1012d37:	48 8d 05 32 a1 01 00 	lea    0x1a132(%rip),%rax        # 102ce70 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 1012d3e:	48 89 85 e0 fe ff ff 	mov    %rax,-0x120(%rbp)
 1012d45:	c7 85 f8 fe ff ff 02 	movl   $0x2,-0x108(%rbp)
 1012d4c:	00 00 00 
 1012d4f:	c7 85 40 ff ff ff 01 	movl   $0x1,-0xc0(%rbp)
 1012d56:	00 00 00 
 1012d59:	48 8b 85 78 ff ff ff 	mov    -0x88(%rbp),%rax
 1012d60:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
 1012d64:	c7 85 40 ff ff ff 00 	movl   $0x0,-0xc0(%rbp)
 1012d6b:	00 00 00 
 1012d6e:	48 8d 45 b8          	lea    -0x48(%rbp),%rax
 1012d72:	48 89 45 98          	mov    %rax,-0x68(%rbp)
 1012d76:	48 8b 45 b8          	mov    -0x48(%rbp),%rax
 1012d7a:	48 89 85 50 ff ff ff 	mov    %rax,-0xb0(%rbp)
 1012d81:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
 1012d85:	48 89 85 58 ff ff ff 	mov    %rax,-0xa8(%rbp)
 1012d8c:	48 8d 05 4d a1 01 00 	lea    0x1a14d(%rip),%rax        # 102cee0 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 1012d93:	48 89 85 80 fe ff ff 	mov    %rax,-0x180(%rbp)
 1012d9a:	c7 85 98 fe ff ff 02 	movl   $0x2,-0x168(%rbp)
 1012da1:	00 00 00 
 1012da4:	c7 85 28 ff ff ff 01 	movl   $0x1,-0xd8(%rbp)
 1012dab:	00 00 00 
 1012dae:	48 8d 85 50 ff ff ff 	lea    -0xb0(%rbp),%rax
 1012db5:	48 89 45 98          	mov    %rax,-0x68(%rbp)
 1012db9:	c7 85 48 ff ff ff 00 	movl   $0x0,-0xb8(%rbp)
 1012dc0:	00 00 00 
 1012dc3:	44 89 e0             	mov    %r12d,%eax
 1012dc6:	44 09 e8             	or     %r13d,%eax
 1012dc9:	0f 85 92 00 00 00    	jne    1012e61 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1451>
 1012dcf:	48 8b 85 50 ff ff ff 	mov    -0xb0(%rbp),%rax
 1012dd6:	48 83 f8 00          	cmp    $0x0,%rax
 1012dda:	74 1a                	je     1012df6 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x13e6>
 1012ddc:	48 83 e8 10          	sub    $0x10,%rax
 1012de0:	48 8b 00             	mov    (%rax),%rax
 1012de3:	48 b9 01 00 00 00 00 	movabs $0x5000000000000001,%rcx
 1012dea:	00 00 50 
 1012ded:	48 21 c8             	and    %rcx,%rax
 1012df0:	48 83 f8 00          	cmp    $0x0,%rax
 1012df4:	75 66                	jne    1012e5c <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x144c>
 1012df6:	48 8b 85 58 ff ff ff 	mov    -0xa8(%rbp),%rax
 1012dfd:	48 83 f8 00          	cmp    $0x0,%rax
 1012e01:	74 1a                	je     1012e1d <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x140d>
 1012e03:	48 83 e8 10          	sub    $0x10,%rax
 1012e07:	48 8b 00             	mov    (%rax),%rax
 1012e0a:	48 b9 01 00 00 00 00 	movabs $0x5000000000000001,%rcx
 1012e11:	00 00 50 
 1012e14:	48 21 c8             	and    %rcx,%rax
 1012e17:	48 83 f8 00          	cmp    $0x0,%rax
 1012e1b:	75 3a                	jne    1012e57 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1447>
 1012e1d:	48 8b 85 50 ff ff ff 	mov    -0xb0(%rbp),%rax
 1012e24:	48 89 85 78 ff ff ff 	mov    %rax,-0x88(%rbp)
 1012e2b:	48 8b 85 58 ff ff ff 	mov    -0xa8(%rbp),%rax
 1012e32:	48 89 45 80          	mov    %rax,-0x80(%rbp)
 1012e36:	ba 10 00 00 00       	mov    $0x10,%edx
 1012e3b:	be 00 00 00 00       	mov    $0x0,%esi
 1012e40:	48 89 fb             	mov    %rdi,%rbx
 1012e43:	48 8d bd 50 ff ff ff 	lea    -0xb0(%rbp),%rdi
 1012e4a:	e8 f1 5a 01 00       	call   1028940 <compiler_rt.fastMemset>
 1012e4f:	48 89 df             	mov    %rbx,%rdi
 1012e52:	e9 8e 00 00 00       	jmp    1012ee5 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x14d5>
 1012e57:	48 87 fb             	xchg   %rdi,%rbx
 1012e5a:	eb 08                	jmp    1012e64 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1454>
 1012e5c:	48 87 fb             	xchg   %rdi,%rbx
 1012e5f:	eb 03                	jmp    1012e64 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1454>
 1012e61:	48 87 fb             	xchg   %rdi,%rbx
 1012e64:	48 8d 8d 50 ff ff ff 	lea    -0xb0(%rbp),%rcx
 1012e6b:	48 8d 95 78 ff ff ff 	lea    -0x88(%rbp),%rdx
 1012e72:	48 8d 35 67 a0 01 00 	lea    0x1a067(%rip),%rsi        # 102cee0 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 1012e79:	49 89 fc             	mov    %rdi,%r12
 1012e7c:	e8 1f 57 01 00       	call   10285a0 <myl_rc_native_take>
 1012e81:	4c 89 e7             	mov    %r12,%rdi
 1012e84:	83 f8 00             	cmp    $0x0,%eax
 1012e87:	75 59                	jne    1012ee2 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x14d2>
 1012e89:	e8 32 e2 00 00       	call   10210c0 <myl_rc_take_failure>
 1012e8e:	48 89 df             	mov    %rbx,%rdi
 1012e91:	89 c6                	mov    %eax,%esi
 1012e93:	48 89 fb             	mov    %rdi,%rbx
 1012e96:	e8 75 59 00 00       	call   1018810 <myl_qbe_rc_status>
 1012e9b:	48 89 df             	mov    %rbx,%rdi
 1012e9e:	48 8d b5 40 fe ff ff 	lea    -0x1c0(%rbp),%rsi
 1012ea5:	48 89 fb             	mov    %rdi,%rbx
 1012ea8:	e8 43 5c 00 00       	call   1018af0 <myl_qbe_rc_frame_cleanup>
 1012ead:	48 89 df             	mov    %rbx,%rdi
 1012eb0:	48 8d b5 40 fe ff ff 	lea    -0x1c0(%rbp),%rsi
 1012eb7:	e8 c4 5a 00 00       	call   1018980 <myl_qbe_rc_frame_leave>
 1012ebc:	ba 10 00 00 00       	mov    $0x10,%edx
 1012ec1:	be 00 00 00 00       	mov    $0x0,%esi
 1012ec6:	48 8d bd 30 fe ff ff 	lea    -0x1d0(%rbp),%rdi
 1012ecd:	e8 6e 5a 01 00       	call   1028940 <compiler_rt.fastMemset>
 1012ed2:	48 8b 85 30 fe ff ff 	mov    -0x1d0(%rbp),%rax
 1012ed9:	48 8b 95 38 fe ff ff 	mov    -0x1c8(%rbp),%rdx
 1012ee0:	eb 62                	jmp    1012f44 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1534>
 1012ee2:	48 89 df             	mov    %rbx,%rdi
 1012ee5:	c7 85 28 ff ff ff 00 	movl   $0x0,-0xd8(%rbp)
 1012eec:	00 00 00 
 1012eef:	48 8d 05 ea 9f 01 00 	lea    0x19fea(%rip),%rax        # 102cee0 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 1012ef6:	48 89 85 e0 fe ff ff 	mov    %rax,-0x120(%rbp)
 1012efd:	c7 85 f8 fe ff ff 02 	movl   $0x2,-0x108(%rbp)
 1012f04:	00 00 00 
 1012f07:	c7 85 40 ff ff ff 01 	movl   $0x1,-0xc0(%rbp)
 1012f0e:	00 00 00 
 1012f11:	c7 85 40 ff ff ff 00 	movl   $0x0,-0xc0(%rbp)
 1012f18:	00 00 00 
 1012f1b:	48 8d b5 40 fe ff ff 	lea    -0x1c0(%rbp),%rsi
 1012f22:	48 89 fb             	mov    %rdi,%rbx
 1012f25:	e8 c6 5b 00 00       	call   1018af0 <myl_qbe_rc_frame_cleanup>
 1012f2a:	48 89 df             	mov    %rbx,%rdi
 1012f2d:	48 8d b5 40 fe ff ff 	lea    -0x1c0(%rbp),%rsi
 1012f34:	e8 47 5a 00 00       	call   1018980 <myl_qbe_rc_frame_leave>
 1012f39:	48 8b 85 78 ff ff ff 	mov    -0x88(%rbp),%rax
 1012f40:	48 8b 55 80          	mov    -0x80(%rbp),%rdx
 1012f44:	41 5f                	pop    %r15
 1012f46:	41 5e                	pop    %r14
 1012f48:	41 5d                	pop    %r13
 1012f4a:	41 5c                	pop    %r12
 1012f4c:	5b                   	pop    %rbx
 1012f4d:	c9                   	leave
 1012f4e:	c3                   	ret
 1012f4f:	e8 8c 62 00 00       	call   10191e0 <myl_qbe_fail_frame>
 1012f54:	0f 0b                	ud2

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
