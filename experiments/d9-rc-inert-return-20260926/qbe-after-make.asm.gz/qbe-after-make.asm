
.tmp-rc/profile/inert-return-final-qbe-rc-n12:     file format elf64-x86-64


Disassembly of section .text:

0000000001011930 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531>:
 1011930:	f3 0f 1e fa          	endbr64
 1011934:	55                   	push   %rbp
 1011935:	48 89 e5             	mov    %rsp,%rbp
 1011938:	48 81 ec c8 01 00 00 	sub    $0x1c8,%rsp
 101193f:	53                   	push   %rbx
 1011940:	41 54                	push   %r12
 1011942:	41 55                	push   %r13
 1011944:	41 56                	push   %r14
 1011946:	41 57                	push   %r15
 1011948:	48 8b 47 40          	mov    0x40(%rdi),%rax
 101194c:	48 8d 4d f8          	lea    -0x8(%rbp),%rcx
 1011950:	48 39 c1             	cmp    %rax,%rcx
 1011953:	0f 82 f6 0e 00 00    	jb     101284f <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xf1f>
 1011959:	48 83 fe 00          	cmp    $0x0,%rsi
 101195d:	0f 84 bd 0e 00 00    	je     1012820 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xef0>
 1011963:	48 89 75 c0          	mov    %rsi,-0x40(%rbp)
 1011967:	48 89 fb             	mov    %rdi,%rbx
 101196a:	e8 61 71 00 00       	call   1018ad0 <myl_qbe_heap>
 101196f:	48 89 df             	mov    %rbx,%rdi
 1011972:	48 89 c3             	mov    %rax,%rbx
 1011975:	49 89 fc             	mov    %rdi,%r12
 1011978:	e8 93 94 00 00       	call   101ae10 <myl_qbe_region_mark>
 101197d:	4c 89 e7             	mov    %r12,%rdi
 1011980:	49 89 c7             	mov    %rax,%r15
 1011983:	ba 30 00 00 00       	mov    $0x30,%edx
 1011988:	be 00 00 00 00       	mov    $0x0,%esi
 101198d:	49 89 fc             	mov    %rdi,%r12
 1011990:	48 8d bd 50 ff ff ff 	lea    -0xb0(%rbp),%rdi
 1011997:	e8 a4 68 01 00       	call   1028240 <compiler_rt.fastMemset>
 101199c:	4c 89 e7             	mov    %r12,%rdi
 101199f:	ba c0 00 00 00       	mov    $0xc0,%edx
 10119a4:	be 00 00 00 00       	mov    $0x0,%esi
 10119a9:	49 89 fc             	mov    %rdi,%r12
 10119ac:	48 8d bd 90 fe ff ff 	lea    -0x170(%rbp),%rdi
 10119b3:	e8 88 68 01 00       	call   1028240 <compiler_rt.fastMemset>
 10119b8:	4c 89 e7             	mov    %r12,%rdi
 10119bb:	48 8d 05 36 27 ff ff 	lea    -0xd8ca(%rip),%rax        # 10040f8 <myl_t_1a91deb3742283487d66c3b500f6effd7ef1170e6d4b4368fe9ec3c3f0354fda>
 10119c2:	48 89 85 90 fe ff ff 	mov    %rax,-0x170(%rbp)
 10119c9:	c7 85 a8 fe ff ff 00 	movl   $0x0,-0x158(%rbp)
 10119d0:	00 00 00 
 10119d3:	48 8d 45 c0          	lea    -0x40(%rbp),%rax
 10119d7:	48 89 85 98 fe ff ff 	mov    %rax,-0x168(%rbp)
 10119de:	48 8d 85 50 ff ff ff 	lea    -0xb0(%rbp),%rax
 10119e5:	48 89 85 a0 fe ff ff 	mov    %rax,-0x160(%rbp)
 10119ec:	48 8d 05 75 28 ff ff 	lea    -0xd78b(%rip),%rax        # 1004268 <myl_t_385cfdbc00ec32031699460779c15099b2bba3cad0e440fffb08e10df0acb9e1>
 10119f3:	48 89 85 b0 fe ff ff 	mov    %rax,-0x150(%rbp)
 10119fa:	c7 85 c8 fe ff ff 00 	movl   $0x0,-0x138(%rbp)
 1011a01:	00 00 00 
 1011a04:	48 8d 45 80          	lea    -0x80(%rbp),%rax
 1011a08:	48 89 85 b8 fe ff ff 	mov    %rax,-0x148(%rbp)
 1011a0f:	48 8d 85 50 ff ff ff 	lea    -0xb0(%rbp),%rax
 1011a16:	48 83 c0 08          	add    $0x8,%rax
 1011a1a:	48 89 85 c0 fe ff ff 	mov    %rax,-0x140(%rbp)
 1011a21:	48 8d 05 40 28 ff ff 	lea    -0xd7c0(%rip),%rax        # 1004268 <myl_t_385cfdbc00ec32031699460779c15099b2bba3cad0e440fffb08e10df0acb9e1>
 1011a28:	48 89 85 d0 fe ff ff 	mov    %rax,-0x130(%rbp)
 1011a2f:	c7 85 e8 fe ff ff 00 	movl   $0x0,-0x118(%rbp)
 1011a36:	00 00 00 
 1011a39:	48 8d 45 90          	lea    -0x70(%rbp),%rax
 1011a3d:	48 89 85 d8 fe ff ff 	mov    %rax,-0x128(%rbp)
 1011a44:	48 8d 85 50 ff ff ff 	lea    -0xb0(%rbp),%rax
 1011a4b:	48 83 c0 10          	add    $0x10,%rax
 1011a4f:	48 89 85 e0 fe ff ff 	mov    %rax,-0x120(%rbp)
 1011a56:	48 8d 05 0b 28 ff ff 	lea    -0xd7f5(%rip),%rax        # 1004268 <myl_t_385cfdbc00ec32031699460779c15099b2bba3cad0e440fffb08e10df0acb9e1>
 1011a5d:	48 89 85 f0 fe ff ff 	mov    %rax,-0x110(%rbp)
 1011a64:	c7 85 08 ff ff ff 00 	movl   $0x0,-0xf8(%rbp)
 1011a6b:	00 00 00 
 1011a6e:	48 8d 45 a0          	lea    -0x60(%rbp),%rax
 1011a72:	48 89 85 f8 fe ff ff 	mov    %rax,-0x108(%rbp)
 1011a79:	48 8d 85 50 ff ff ff 	lea    -0xb0(%rbp),%rax
 1011a80:	48 83 c0 18          	add    $0x18,%rax
 1011a84:	48 89 85 00 ff ff ff 	mov    %rax,-0x100(%rbp)
 1011a8b:	48 8d 05 d6 27 ff ff 	lea    -0xd82a(%rip),%rax        # 1004268 <myl_t_385cfdbc00ec32031699460779c15099b2bba3cad0e440fffb08e10df0acb9e1>
 1011a92:	48 89 85 10 ff ff ff 	mov    %rax,-0xf0(%rbp)
 1011a99:	c7 85 28 ff ff ff 00 	movl   $0x0,-0xd8(%rbp)
 1011aa0:	00 00 00 
 1011aa3:	48 8d 45 a8          	lea    -0x58(%rbp),%rax
 1011aa7:	48 89 85 18 ff ff ff 	mov    %rax,-0xe8(%rbp)
 1011aae:	48 8d 85 50 ff ff ff 	lea    -0xb0(%rbp),%rax
 1011ab5:	48 83 c0 20          	add    $0x20,%rax
 1011ab9:	48 89 85 20 ff ff ff 	mov    %rax,-0xe0(%rbp)
 1011ac0:	48 8d 05 a1 27 ff ff 	lea    -0xd85f(%rip),%rax        # 1004268 <myl_t_385cfdbc00ec32031699460779c15099b2bba3cad0e440fffb08e10df0acb9e1>
 1011ac7:	48 89 85 30 ff ff ff 	mov    %rax,-0xd0(%rbp)
 1011ace:	c7 85 48 ff ff ff 00 	movl   $0x0,-0xb8(%rbp)
 1011ad5:	00 00 00 
 1011ad8:	48 8d 45 b8          	lea    -0x48(%rbp),%rax
 1011adc:	48 89 85 38 ff ff ff 	mov    %rax,-0xc8(%rbp)
 1011ae3:	48 8d 85 50 ff ff ff 	lea    -0xb0(%rbp),%rax
 1011aea:	49 89 c4             	mov    %rax,%r12
 1011aed:	49 83 c4 28          	add    $0x28,%r12
 1011af1:	4c 89 a5 40 ff ff ff 	mov    %r12,-0xc0(%rbp)
 1011af8:	b9 06 00 00 00       	mov    $0x6,%ecx
 1011afd:	48 8d 95 90 fe ff ff 	lea    -0x170(%rbp),%rdx
 1011b04:	48 8d b5 70 fe ff ff 	lea    -0x190(%rbp),%rsi
 1011b0b:	49 89 fd             	mov    %rdi,%r13
 1011b0e:	e8 ed 66 00 00       	call   1018200 <myl_qbe_rc_frame_enter>
 1011b13:	4c 89 ef             	mov    %r13,%rdi
 1011b16:	48 8b 55 c0          	mov    -0x40(%rbp),%rdx
 1011b1a:	48 89 55 c8          	mov    %rdx,-0x38(%rbp)
 1011b1e:	48 c7 45 d0 01 00 00 	movq   $0x1,-0x30(%rbp)
 1011b25:	00 
 1011b26:	48 b8 01 00 00 00 00 	movabs $0x8000000000000001,%rax
 1011b2d:	00 00 80 
 1011b30:	48 39 c2             	cmp    %rax,%rdx
 1011b33:	0f 8c d0 0c 00 00    	jl     1012809 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xed9>
 1011b39:	48 89 d6             	mov    %rdx,%rsi
 1011b3c:	48 83 ee 01          	sub    $0x1,%rsi
 1011b40:	48 89 75 c8          	mov    %rsi,-0x38(%rbp)
 1011b44:	49 89 fd             	mov    %rdi,%r13
 1011b47:	e8 e4 fd ff ff       	call   1011930 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531>
 1011b4c:	4c 89 ef             	mov    %r13,%rdi
 1011b4f:	48 89 c1             	mov    %rax,%rcx
 1011b52:	48 89 d0             	mov    %rdx,%rax
 1011b55:	48 89 8d 40 fe ff ff 	mov    %rcx,-0x1c0(%rbp)
 1011b5c:	48 89 85 48 fe ff ff 	mov    %rax,-0x1b8(%rbp)
 1011b63:	48 8d 85 40 fe ff ff 	lea    -0x1c0(%rbp),%rax
 1011b6a:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
 1011b6e:	48 8b 85 40 fe ff ff 	mov    -0x1c0(%rbp),%rax
 1011b75:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
 1011b79:	48 8b 85 48 fe ff ff 	mov    -0x1b8(%rbp),%rax
 1011b80:	48 89 45 b0          	mov    %rax,-0x50(%rbp)
 1011b84:	48 8d 05 55 ac 01 00 	lea    0x1ac55(%rip),%rax        # 102c7e0 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 1011b8b:	48 89 85 10 ff ff ff 	mov    %rax,-0xf0(%rbp)
 1011b92:	c7 85 28 ff ff ff 02 	movl   $0x2,-0xd8(%rbp)
 1011b99:	00 00 00 
 1011b9c:	c7 85 70 ff ff ff 01 	movl   $0x1,-0x90(%rbp)
 1011ba3:	00 00 00 
 1011ba6:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
 1011baa:	48 89 45 80          	mov    %rax,-0x80(%rbp)
 1011bae:	48 8b 45 b0          	mov    -0x50(%rbp),%rax
 1011bb2:	48 89 45 88          	mov    %rax,-0x78(%rbp)
 1011bb6:	48 8d 05 23 ac 01 00 	lea    0x1ac23(%rip),%rax        # 102c7e0 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 1011bbd:	48 89 85 b0 fe ff ff 	mov    %rax,-0x150(%rbp)
 1011bc4:	c7 85 c8 fe ff ff 02 	movl   $0x2,-0x138(%rbp)
 1011bcb:	00 00 00 
 1011bce:	c7 85 70 ff ff ff 00 	movl   $0x0,-0x90(%rbp)
 1011bd5:	00 00 00 
 1011bd8:	c7 85 58 ff ff ff 01 	movl   $0x1,-0xa8(%rbp)
 1011bdf:	00 00 00 
 1011be2:	48 8d 45 80          	lea    -0x80(%rbp),%rax
 1011be6:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
 1011bea:	ba 01 00 00 00       	mov    $0x1,%edx
 1011bef:	48 8d 35 da a8 01 00 	lea    0x1a8da(%rip),%rsi        # 102c4d0 <myl_t_1e414bd82e4b50b54939760a2d591f88da97e2f1c8252dbd7dcbc73438e46afb_body>
 1011bf6:	49 89 fd             	mov    %rdi,%r13
 1011bf9:	48 89 df             	mov    %rbx,%rdi
 1011bfc:	e8 af b5 00 00       	call   101d1b0 <myl_native_heap_alloc>
 1011c01:	4c 89 ef             	mov    %r13,%rdi
 1011c04:	49 89 c5             	mov    %rax,%r13
 1011c07:	41 83 fd 00          	cmp    $0x0,%r13d
 1011c0b:	75 0a                	jne    1011c17 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x2e7>
 1011c0d:	48 89 fb             	mov    %rdi,%rbx
 1011c10:	e8 3b 6c 00 00       	call   1018850 <myl_qbe_fail_allocation>
 1011c15:	0f 0b                	ud2
 1011c17:	48 87 fb             	xchg   %rdi,%rbx
 1011c1a:	4c 89 6d b8          	mov    %r13,-0x48(%rbp)
 1011c1e:	48 8d 05 1b a9 01 00 	lea    0x1a91b(%rip),%rax        # 102c540 <myl_t_1e414bd82e4b50b54939760a2d591f88da97e2f1c8252dbd7dcbc73438e46afb>
 1011c25:	48 89 85 30 ff ff ff 	mov    %rax,-0xd0(%rbp)
 1011c2c:	c7 85 48 ff ff ff 02 	movl   $0x2,-0xb8(%rbp)
 1011c33:	00 00 00 
 1011c36:	48 8d 45 b8          	lea    -0x48(%rbp),%rax
 1011c3a:	48 89 85 38 ff ff ff 	mov    %rax,-0xc8(%rbp)
 1011c41:	4c 89 a5 40 ff ff ff 	mov    %r12,-0xc0(%rbp)
 1011c48:	c7 85 48 ff ff ff 04 	movl   $0x4,-0xb8(%rbp)
 1011c4f:	00 00 00 
 1011c52:	c7 85 78 ff ff ff 01 	movl   $0x1,-0x88(%rbp)
 1011c59:	00 00 00 
 1011c5c:	48 8b 4d c8          	mov    -0x38(%rbp),%rcx
 1011c60:	48 8d 45 a8          	lea    -0x58(%rbp),%rax
 1011c64:	48 f7 d8             	neg    %rax
 1011c67:	48 01 c8             	add    %rcx,%rax
 1011c6a:	48 8d 55 a8          	lea    -0x58(%rbp),%rdx
 1011c6e:	48 29 ca             	sub    %rcx,%rdx
 1011c71:	48 83 f8 10          	cmp    $0x10,%rax
 1011c75:	0f 92 c0             	setb   %al
 1011c78:	0f b6 c0             	movzbl %al,%eax
 1011c7b:	48 83 fa 10          	cmp    $0x10,%rdx
 1011c7f:	0f 92 c2             	setb   %dl
 1011c82:	0f b6 d2             	movzbl %dl,%edx
 1011c85:	09 d0                	or     %edx,%eax
 1011c87:	75 76                	jne    1011cff <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x3cf>
 1011c89:	48 8b 01             	mov    (%rcx),%rax
 1011c8c:	48 83 f8 00          	cmp    $0x0,%rax
 1011c90:	74 1a                	je     1011cac <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x37c>
 1011c92:	48 83 e8 10          	sub    $0x10,%rax
 1011c96:	48 8b 00             	mov    (%rax),%rax
 1011c99:	48 ba 01 00 00 00 00 	movabs $0x5000000000000001,%rdx
 1011ca0:	00 00 50 
 1011ca3:	48 21 d0             	and    %rdx,%rax
 1011ca6:	48 83 f8 00          	cmp    $0x0,%rax
 1011caa:	75 53                	jne    1011cff <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x3cf>
 1011cac:	48 8b 41 08          	mov    0x8(%rcx),%rax
 1011cb0:	48 83 f8 00          	cmp    $0x0,%rax
 1011cb4:	74 1a                	je     1011cd0 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x3a0>
 1011cb6:	48 83 e8 10          	sub    $0x10,%rax
 1011cba:	48 8b 00             	mov    (%rax),%rax
 1011cbd:	48 ba 01 00 00 00 00 	movabs $0x5000000000000001,%rdx
 1011cc4:	00 00 50 
 1011cc7:	48 21 d0             	and    %rdx,%rax
 1011cca:	48 83 f8 00          	cmp    $0x0,%rax
 1011cce:	75 2f                	jne    1011cff <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x3cf>
 1011cd0:	48 8b 01             	mov    (%rcx),%rax
 1011cd3:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
 1011cd7:	48 8b 41 08          	mov    0x8(%rcx),%rax
 1011cdb:	48 89 45 b0          	mov    %rax,-0x50(%rbp)
 1011cdf:	ba 10 00 00 00       	mov    $0x10,%edx
 1011ce4:	be 00 00 00 00       	mov    $0x0,%esi
 1011ce9:	49 89 fe             	mov    %rdi,%r14
 1011cec:	48 89 cf             	mov    %rcx,%rdi
 1011cef:	e8 4c 65 01 00       	call   1028240 <compiler_rt.fastMemset>
 1011cf4:	4d 89 f8             	mov    %r15,%r8
 1011cf7:	4c 89 f7             	mov    %r14,%rdi
 1011cfa:	4d 89 c6             	mov    %r8,%r14
 1011cfd:	eb 3b                	jmp    1011d3a <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x40a>
 1011cff:	4d 89 f8             	mov    %r15,%r8
 1011d02:	4d 89 c6             	mov    %r8,%r14
 1011d05:	48 8d 55 a8          	lea    -0x58(%rbp),%rdx
 1011d09:	48 8d 35 d0 aa 01 00 	lea    0x1aad0(%rip),%rsi        # 102c7e0 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 1011d10:	49 89 ff             	mov    %rdi,%r15
 1011d13:	e8 88 61 01 00       	call   1027ea0 <myl_rc_native_take>
 1011d18:	4c 89 ff             	mov    %r15,%rdi
 1011d1b:	83 f8 00             	cmp    $0x0,%eax
 1011d1e:	75 1a                	jne    1011d3a <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x40a>
 1011d20:	e8 9b ec 00 00       	call   10209c0 <myl_rc_take_failure>
 1011d25:	48 89 df             	mov    %rbx,%rdi
 1011d28:	89 c6                	mov    %eax,%esi
 1011d2a:	48 89 fb             	mov    %rdi,%rbx
 1011d2d:	e8 de 63 00 00       	call   1018110 <myl_qbe_rc_status>
 1011d32:	48 89 df             	mov    %rbx,%rdi
 1011d35:	e9 10 0a 00 00       	jmp    101274a <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xe1a>
 1011d3a:	c7 85 58 ff ff ff 00 	movl   $0x0,-0xa8(%rbp)
 1011d41:	00 00 00 
 1011d44:	48 8d 05 95 aa 01 00 	lea    0x1aa95(%rip),%rax        # 102c7e0 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 1011d4b:	48 89 85 10 ff ff ff 	mov    %rax,-0xf0(%rbp)
 1011d52:	c7 85 28 ff ff ff 02 	movl   $0x2,-0xd8(%rbp)
 1011d59:	00 00 00 
 1011d5c:	c7 85 70 ff ff ff 01 	movl   $0x1,-0x90(%rbp)
 1011d63:	00 00 00 
 1011d66:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
 1011d6a:	49 89 45 00          	mov    %rax,0x0(%r13)
 1011d6e:	48 8b 45 b0          	mov    -0x50(%rbp),%rax
 1011d72:	49 89 45 08          	mov    %rax,0x8(%r13)
 1011d76:	c7 85 70 ff ff ff 00 	movl   $0x0,-0x90(%rbp)
 1011d7d:	00 00 00 
 1011d80:	4c 89 6d c8          	mov    %r13,-0x38(%rbp)
 1011d84:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
 1011d88:	48 89 45 80          	mov    %rax,-0x80(%rbp)
 1011d8c:	48 8d 05 ad a7 01 00 	lea    0x1a7ad(%rip),%rax        # 102c540 <myl_t_1e414bd82e4b50b54939760a2d591f88da97e2f1c8252dbd7dcbc73438e46afb>
 1011d93:	48 89 85 b0 fe ff ff 	mov    %rax,-0x150(%rbp)
 1011d9a:	c7 85 c8 fe ff ff 02 	movl   $0x2,-0x138(%rbp)
 1011da1:	00 00 00 
 1011da4:	c7 85 58 ff ff ff 01 	movl   $0x1,-0xa8(%rbp)
 1011dab:	00 00 00 
 1011dae:	4c 89 6d c8          	mov    %r13,-0x38(%rbp)
 1011db2:	c7 85 78 ff ff ff 00 	movl   $0x0,-0x88(%rbp)
 1011db9:	00 00 00 
 1011dbc:	ba 08 00 00 00       	mov    $0x8,%edx
 1011dc1:	be 00 00 00 00       	mov    $0x0,%esi
 1011dc6:	49 89 fd             	mov    %rdi,%r13
 1011dc9:	48 8d 7d d8          	lea    -0x28(%rbp),%rdi
 1011dcd:	e8 6e 64 01 00       	call   1028240 <compiler_rt.fastMemset>
 1011dd2:	4c 89 ef             	mov    %r13,%rdi
 1011dd5:	48 8d 05 94 a9 01 00 	lea    0x1a994(%rip),%rax        # 102c770 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 1011ddc:	48 89 85 30 ff ff ff 	mov    %rax,-0xd0(%rbp)
 1011de3:	c7 85 48 ff ff ff 02 	movl   $0x2,-0xb8(%rbp)
 1011dea:	00 00 00 
 1011ded:	48 8d 45 d8          	lea    -0x28(%rbp),%rax
 1011df1:	48 89 85 38 ff ff ff 	mov    %rax,-0xc8(%rbp)
 1011df8:	4c 89 a5 40 ff ff ff 	mov    %r12,-0xc0(%rbp)
 1011dff:	c7 85 78 ff ff ff 01 	movl   $0x1,-0x88(%rbp)
 1011e06:	00 00 00 
 1011e09:	48 8d 4d a8          	lea    -0x58(%rbp),%rcx
 1011e0d:	48 8d 45 c8          	lea    -0x38(%rbp),%rax
 1011e11:	48 29 c8             	sub    %rcx,%rax
 1011e14:	48 8d 55 c8          	lea    -0x38(%rbp),%rdx
 1011e18:	48 8d 4d a8          	lea    -0x58(%rbp),%rcx
 1011e1c:	48 29 d1             	sub    %rdx,%rcx
 1011e1f:	48 83 f8 08          	cmp    $0x8,%rax
 1011e23:	0f 92 c0             	setb   %al
 1011e26:	0f b6 c0             	movzbl %al,%eax
 1011e29:	48 83 f9 08          	cmp    $0x8,%rcx
 1011e2d:	0f 92 c1             	setb   %cl
 1011e30:	0f b6 c9             	movzbl %cl,%ecx
 1011e33:	09 c8                	or     %ecx,%eax
 1011e35:	75 50                	jne    1011e87 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x557>
 1011e37:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
 1011e3b:	48 83 f8 00          	cmp    $0x0,%rax
 1011e3f:	74 1a                	je     1011e5b <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x52b>
 1011e41:	48 83 e8 10          	sub    $0x10,%rax
 1011e45:	48 8b 00             	mov    (%rax),%rax
 1011e48:	48 b9 01 00 00 00 00 	movabs $0x5000000000000001,%rcx
 1011e4f:	00 00 50 
 1011e52:	48 21 c8             	and    %rcx,%rax
 1011e55:	48 83 f8 00          	cmp    $0x0,%rax
 1011e59:	75 2c                	jne    1011e87 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x557>
 1011e5b:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
 1011e5f:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
 1011e63:	ba 08 00 00 00       	mov    $0x8,%edx
 1011e68:	be 00 00 00 00       	mov    $0x0,%esi
 1011e6d:	49 89 fd             	mov    %rdi,%r13
 1011e70:	48 8d 7d c8          	lea    -0x38(%rbp),%rdi
 1011e74:	e8 c7 63 01 00       	call   1028240 <compiler_rt.fastMemset>
 1011e79:	4d 89 f0             	mov    %r14,%r8
 1011e7c:	4c 89 ef             	mov    %r13,%rdi
 1011e7f:	4d 89 c7             	mov    %r8,%r15
 1011e82:	48 87 df             	xchg   %rbx,%rdi
 1011e85:	eb 42                	jmp    1011ec9 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x599>
 1011e87:	4d 89 f0             	mov    %r14,%r8
 1011e8a:	4d 89 c7             	mov    %r8,%r15
 1011e8d:	48 8d 4d c8          	lea    -0x38(%rbp),%rcx
 1011e91:	48 8d 55 a8          	lea    -0x58(%rbp),%rdx
 1011e95:	48 8d 35 a4 a6 01 00 	lea    0x1a6a4(%rip),%rsi        # 102c540 <myl_t_1e414bd82e4b50b54939760a2d591f88da97e2f1c8252dbd7dcbc73438e46afb>
 1011e9c:	49 89 fd             	mov    %rdi,%r13
 1011e9f:	e8 fc 5f 01 00       	call   1027ea0 <myl_rc_native_take>
 1011ea4:	4c 89 ef             	mov    %r13,%rdi
 1011ea7:	83 f8 00             	cmp    $0x0,%eax
 1011eaa:	75 1a                	jne    1011ec6 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x596>
 1011eac:	e8 0f eb 00 00       	call   10209c0 <myl_rc_take_failure>
 1011eb1:	48 89 df             	mov    %rbx,%rdi
 1011eb4:	89 c6                	mov    %eax,%esi
 1011eb6:	48 89 fb             	mov    %rdi,%rbx
 1011eb9:	e8 52 62 00 00       	call   1018110 <myl_qbe_rc_status>
 1011ebe:	48 89 df             	mov    %rbx,%rdi
 1011ec1:	e9 84 08 00 00       	jmp    101274a <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xe1a>
 1011ec6:	48 87 df             	xchg   %rbx,%rdi
 1011ec9:	c7 85 58 ff ff ff 00 	movl   $0x0,-0xa8(%rbp)
 1011ed0:	00 00 00 
 1011ed3:	48 8d 05 66 a6 01 00 	lea    0x1a666(%rip),%rax        # 102c540 <myl_t_1e414bd82e4b50b54939760a2d591f88da97e2f1c8252dbd7dcbc73438e46afb>
 1011eda:	48 89 85 10 ff ff ff 	mov    %rax,-0xf0(%rbp)
 1011ee1:	c7 85 28 ff ff ff 02 	movl   $0x2,-0xd8(%rbp)
 1011ee8:	00 00 00 
 1011eeb:	c7 85 70 ff ff ff 01 	movl   $0x1,-0x90(%rbp)
 1011ef2:	00 00 00 
 1011ef5:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
 1011ef9:	48 89 45 d8          	mov    %rax,-0x28(%rbp)
 1011efd:	c7 85 70 ff ff ff 00 	movl   $0x0,-0x90(%rbp)
 1011f04:	00 00 00 
 1011f07:	48 8d 45 d8          	lea    -0x28(%rbp),%rax
 1011f0b:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
 1011f0f:	48 8b 45 d8          	mov    -0x28(%rbp),%rax
 1011f13:	48 89 45 80          	mov    %rax,-0x80(%rbp)
 1011f17:	48 8d 05 52 a8 01 00 	lea    0x1a852(%rip),%rax        # 102c770 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 1011f1e:	48 89 85 b0 fe ff ff 	mov    %rax,-0x150(%rbp)
 1011f25:	c7 85 c8 fe ff ff 02 	movl   $0x2,-0x138(%rbp)
 1011f2c:	00 00 00 
 1011f2f:	c7 85 58 ff ff ff 01 	movl   $0x1,-0xa8(%rbp)
 1011f36:	00 00 00 
 1011f39:	48 8d 45 80          	lea    -0x80(%rbp),%rax
 1011f3d:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
 1011f41:	c7 85 78 ff ff ff 00 	movl   $0x0,-0x88(%rbp)
 1011f48:	00 00 00 
 1011f4b:	48 8b 55 c0          	mov    -0x40(%rbp),%rdx
 1011f4f:	48 89 55 d0          	mov    %rdx,-0x30(%rbp)
 1011f53:	48 b8 01 00 00 00 00 	movabs $0x8000000000000001,%rax
 1011f5a:	00 00 80 
 1011f5d:	48 39 c2             	cmp    %rax,%rdx
 1011f60:	0f 8c 8c 08 00 00    	jl     10127f2 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xec2>
 1011f66:	48 89 d6             	mov    %rdx,%rsi
 1011f69:	48 83 ee 01          	sub    $0x1,%rsi
 1011f6d:	48 89 75 d0          	mov    %rsi,-0x30(%rbp)
 1011f71:	49 89 fd             	mov    %rdi,%r13
 1011f74:	e8 b7 f9 ff ff       	call   1011930 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531>
 1011f79:	4c 89 ef             	mov    %r13,%rdi
 1011f7c:	48 89 c1             	mov    %rax,%rcx
 1011f7f:	48 89 d0             	mov    %rdx,%rax
 1011f82:	48 89 8d 50 fe ff ff 	mov    %rcx,-0x1b0(%rbp)
 1011f89:	48 89 85 58 fe ff ff 	mov    %rax,-0x1a8(%rbp)
 1011f90:	48 8d 85 50 fe ff ff 	lea    -0x1b0(%rbp),%rax
 1011f97:	48 89 45 d0          	mov    %rax,-0x30(%rbp)
 1011f9b:	48 8b 85 50 fe ff ff 	mov    -0x1b0(%rbp),%rax
 1011fa2:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
 1011fa6:	48 8b 85 58 fe ff ff 	mov    -0x1a8(%rbp),%rax
 1011fad:	48 89 45 b0          	mov    %rax,-0x50(%rbp)
 1011fb1:	48 8d 05 28 a8 01 00 	lea    0x1a828(%rip),%rax        # 102c7e0 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 1011fb8:	48 89 85 10 ff ff ff 	mov    %rax,-0xf0(%rbp)
 1011fbf:	c7 85 28 ff ff ff 02 	movl   $0x2,-0xd8(%rbp)
 1011fc6:	00 00 00 
 1011fc9:	c7 85 70 ff ff ff 01 	movl   $0x1,-0x90(%rbp)
 1011fd0:	00 00 00 
 1011fd3:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
 1011fd7:	48 89 45 90          	mov    %rax,-0x70(%rbp)
 1011fdb:	48 8b 45 b0          	mov    -0x50(%rbp),%rax
 1011fdf:	48 89 45 98          	mov    %rax,-0x68(%rbp)
 1011fe3:	48 8d 05 f6 a7 01 00 	lea    0x1a7f6(%rip),%rax        # 102c7e0 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 1011fea:	48 89 85 d0 fe ff ff 	mov    %rax,-0x130(%rbp)
 1011ff1:	c7 85 e8 fe ff ff 02 	movl   $0x2,-0x118(%rbp)
 1011ff8:	00 00 00 
 1011ffb:	c7 85 70 ff ff ff 00 	movl   $0x0,-0x90(%rbp)
 1012002:	00 00 00 
 1012005:	c7 85 60 ff ff ff 01 	movl   $0x1,-0xa0(%rbp)
 101200c:	00 00 00 
 101200f:	48 8d 45 90          	lea    -0x70(%rbp),%rax
 1012013:	48 89 45 d0          	mov    %rax,-0x30(%rbp)
 1012017:	ba 01 00 00 00       	mov    $0x1,%edx
 101201c:	48 8d 35 ad a4 01 00 	lea    0x1a4ad(%rip),%rsi        # 102c4d0 <myl_t_1e414bd82e4b50b54939760a2d591f88da97e2f1c8252dbd7dcbc73438e46afb_body>
 1012023:	49 89 fd             	mov    %rdi,%r13
 1012026:	48 89 df             	mov    %rbx,%rdi
 1012029:	e8 82 b1 00 00       	call   101d1b0 <myl_native_heap_alloc>
 101202e:	4c 89 ef             	mov    %r13,%rdi
 1012031:	49 89 c5             	mov    %rax,%r13
 1012034:	41 83 fd 00          	cmp    $0x0,%r13d
 1012038:	75 0a                	jne    1012044 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x714>
 101203a:	48 89 fb             	mov    %rdi,%rbx
 101203d:	e8 0e 68 00 00       	call   1018850 <myl_qbe_fail_allocation>
 1012042:	0f 0b                	ud2
 1012044:	48 87 fb             	xchg   %rdi,%rbx
 1012047:	4c 89 6d b8          	mov    %r13,-0x48(%rbp)
 101204b:	48 8d 05 ee a4 01 00 	lea    0x1a4ee(%rip),%rax        # 102c540 <myl_t_1e414bd82e4b50b54939760a2d591f88da97e2f1c8252dbd7dcbc73438e46afb>
 1012052:	48 89 85 30 ff ff ff 	mov    %rax,-0xd0(%rbp)
 1012059:	c7 85 48 ff ff ff 02 	movl   $0x2,-0xb8(%rbp)
 1012060:	00 00 00 
 1012063:	48 8d 45 b8          	lea    -0x48(%rbp),%rax
 1012067:	48 89 85 38 ff ff ff 	mov    %rax,-0xc8(%rbp)
 101206e:	4c 89 a5 40 ff ff ff 	mov    %r12,-0xc0(%rbp)
 1012075:	c7 85 48 ff ff ff 04 	movl   $0x4,-0xb8(%rbp)
 101207c:	00 00 00 
 101207f:	c7 85 78 ff ff ff 01 	movl   $0x1,-0x88(%rbp)
 1012086:	00 00 00 
 1012089:	48 8b 4d d0          	mov    -0x30(%rbp),%rcx
 101208d:	48 8d 45 a8          	lea    -0x58(%rbp),%rax
 1012091:	48 f7 d8             	neg    %rax
 1012094:	48 01 c8             	add    %rcx,%rax
 1012097:	48 8d 55 a8          	lea    -0x58(%rbp),%rdx
 101209b:	48 29 ca             	sub    %rcx,%rdx
 101209e:	48 83 f8 10          	cmp    $0x10,%rax
 10120a2:	0f 92 c0             	setb   %al
 10120a5:	0f b6 c0             	movzbl %al,%eax
 10120a8:	48 83 fa 10          	cmp    $0x10,%rdx
 10120ac:	0f 92 c2             	setb   %dl
 10120af:	0f b6 d2             	movzbl %dl,%edx
 10120b2:	09 d0                	or     %edx,%eax
 10120b4:	75 76                	jne    101212c <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x7fc>
 10120b6:	48 8b 01             	mov    (%rcx),%rax
 10120b9:	48 83 f8 00          	cmp    $0x0,%rax
 10120bd:	74 1a                	je     10120d9 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x7a9>
 10120bf:	48 83 e8 10          	sub    $0x10,%rax
 10120c3:	48 8b 00             	mov    (%rax),%rax
 10120c6:	48 ba 01 00 00 00 00 	movabs $0x5000000000000001,%rdx
 10120cd:	00 00 50 
 10120d0:	48 21 d0             	and    %rdx,%rax
 10120d3:	48 83 f8 00          	cmp    $0x0,%rax
 10120d7:	75 53                	jne    101212c <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x7fc>
 10120d9:	48 8b 41 08          	mov    0x8(%rcx),%rax
 10120dd:	48 83 f8 00          	cmp    $0x0,%rax
 10120e1:	74 1a                	je     10120fd <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x7cd>
 10120e3:	48 83 e8 10          	sub    $0x10,%rax
 10120e7:	48 8b 00             	mov    (%rax),%rax
 10120ea:	48 ba 01 00 00 00 00 	movabs $0x5000000000000001,%rdx
 10120f1:	00 00 50 
 10120f4:	48 21 d0             	and    %rdx,%rax
 10120f7:	48 83 f8 00          	cmp    $0x0,%rax
 10120fb:	75 2f                	jne    101212c <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x7fc>
 10120fd:	48 8b 01             	mov    (%rcx),%rax
 1012100:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
 1012104:	48 8b 41 08          	mov    0x8(%rcx),%rax
 1012108:	48 89 45 b0          	mov    %rax,-0x50(%rbp)
 101210c:	ba 10 00 00 00       	mov    $0x10,%edx
 1012111:	be 00 00 00 00       	mov    $0x0,%esi
 1012116:	49 89 fe             	mov    %rdi,%r14
 1012119:	48 89 cf             	mov    %rcx,%rdi
 101211c:	e8 1f 61 01 00       	call   1028240 <compiler_rt.fastMemset>
 1012121:	4d 89 f8             	mov    %r15,%r8
 1012124:	4c 89 f7             	mov    %r14,%rdi
 1012127:	4d 89 c6             	mov    %r8,%r14
 101212a:	eb 3b                	jmp    1012167 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x837>
 101212c:	4d 89 f8             	mov    %r15,%r8
 101212f:	4d 89 c6             	mov    %r8,%r14
 1012132:	48 8d 55 a8          	lea    -0x58(%rbp),%rdx
 1012136:	48 8d 35 a3 a6 01 00 	lea    0x1a6a3(%rip),%rsi        # 102c7e0 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 101213d:	49 89 ff             	mov    %rdi,%r15
 1012140:	e8 5b 5d 01 00       	call   1027ea0 <myl_rc_native_take>
 1012145:	4c 89 ff             	mov    %r15,%rdi
 1012148:	83 f8 00             	cmp    $0x0,%eax
 101214b:	75 1a                	jne    1012167 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x837>
 101214d:	e8 6e e8 00 00       	call   10209c0 <myl_rc_take_failure>
 1012152:	48 89 df             	mov    %rbx,%rdi
 1012155:	89 c6                	mov    %eax,%esi
 1012157:	48 89 fb             	mov    %rdi,%rbx
 101215a:	e8 b1 5f 00 00       	call   1018110 <myl_qbe_rc_status>
 101215f:	48 89 df             	mov    %rbx,%rdi
 1012162:	e9 e3 05 00 00       	jmp    101274a <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xe1a>
 1012167:	c7 85 60 ff ff ff 00 	movl   $0x0,-0xa0(%rbp)
 101216e:	00 00 00 
 1012171:	48 8d 05 68 a6 01 00 	lea    0x1a668(%rip),%rax        # 102c7e0 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 1012178:	48 89 85 10 ff ff ff 	mov    %rax,-0xf0(%rbp)
 101217f:	c7 85 28 ff ff ff 02 	movl   $0x2,-0xd8(%rbp)
 1012186:	00 00 00 
 1012189:	c7 85 70 ff ff ff 01 	movl   $0x1,-0x90(%rbp)
 1012190:	00 00 00 
 1012193:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
 1012197:	49 89 45 00          	mov    %rax,0x0(%r13)
 101219b:	48 8b 45 b0          	mov    -0x50(%rbp),%rax
 101219f:	49 89 45 08          	mov    %rax,0x8(%r13)
 10121a3:	c7 85 70 ff ff ff 00 	movl   $0x0,-0x90(%rbp)
 10121aa:	00 00 00 
 10121ad:	4c 89 6d d0          	mov    %r13,-0x30(%rbp)
 10121b1:	48 8b 45 d0          	mov    -0x30(%rbp),%rax
 10121b5:	48 89 45 90          	mov    %rax,-0x70(%rbp)
 10121b9:	48 8d 05 80 a3 01 00 	lea    0x1a380(%rip),%rax        # 102c540 <myl_t_1e414bd82e4b50b54939760a2d591f88da97e2f1c8252dbd7dcbc73438e46afb>
 10121c0:	48 89 85 d0 fe ff ff 	mov    %rax,-0x130(%rbp)
 10121c7:	c7 85 e8 fe ff ff 02 	movl   $0x2,-0x118(%rbp)
 10121ce:	00 00 00 
 10121d1:	c7 85 60 ff ff ff 01 	movl   $0x1,-0xa0(%rbp)
 10121d8:	00 00 00 
 10121db:	4c 89 6d d0          	mov    %r13,-0x30(%rbp)
 10121df:	c7 85 78 ff ff ff 00 	movl   $0x0,-0x88(%rbp)
 10121e6:	00 00 00 
 10121e9:	ba 08 00 00 00       	mov    $0x8,%edx
 10121ee:	be 00 00 00 00       	mov    $0x0,%esi
 10121f3:	49 89 fd             	mov    %rdi,%r13
 10121f6:	48 8d 7d e0          	lea    -0x20(%rbp),%rdi
 10121fa:	e8 41 60 01 00       	call   1028240 <compiler_rt.fastMemset>
 10121ff:	4c 89 ef             	mov    %r13,%rdi
 1012202:	48 8d 05 67 a5 01 00 	lea    0x1a567(%rip),%rax        # 102c770 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 1012209:	48 89 85 30 ff ff ff 	mov    %rax,-0xd0(%rbp)
 1012210:	c7 85 48 ff ff ff 02 	movl   $0x2,-0xb8(%rbp)
 1012217:	00 00 00 
 101221a:	48 8d 45 e0          	lea    -0x20(%rbp),%rax
 101221e:	48 89 85 38 ff ff ff 	mov    %rax,-0xc8(%rbp)
 1012225:	4c 89 a5 40 ff ff ff 	mov    %r12,-0xc0(%rbp)
 101222c:	c7 85 78 ff ff ff 01 	movl   $0x1,-0x88(%rbp)
 1012233:	00 00 00 
 1012236:	48 8d 4d a8          	lea    -0x58(%rbp),%rcx
 101223a:	48 8d 45 d0          	lea    -0x30(%rbp),%rax
 101223e:	48 29 c8             	sub    %rcx,%rax
 1012241:	48 8d 55 d0          	lea    -0x30(%rbp),%rdx
 1012245:	48 8d 4d a8          	lea    -0x58(%rbp),%rcx
 1012249:	48 29 d1             	sub    %rdx,%rcx
 101224c:	48 83 f8 08          	cmp    $0x8,%rax
 1012250:	0f 92 c0             	setb   %al
 1012253:	0f b6 c0             	movzbl %al,%eax
 1012256:	48 83 f9 08          	cmp    $0x8,%rcx
 101225a:	0f 92 c1             	setb   %cl
 101225d:	0f b6 c9             	movzbl %cl,%ecx
 1012260:	09 c8                	or     %ecx,%eax
 1012262:	75 4d                	jne    10122b1 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x981>
 1012264:	48 8b 45 d0          	mov    -0x30(%rbp),%rax
 1012268:	48 83 f8 00          	cmp    $0x0,%rax
 101226c:	74 1a                	je     1012288 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x958>
 101226e:	48 83 e8 10          	sub    $0x10,%rax
 1012272:	48 8b 00             	mov    (%rax),%rax
 1012275:	48 b9 01 00 00 00 00 	movabs $0x5000000000000001,%rcx
 101227c:	00 00 50 
 101227f:	48 21 c8             	and    %rcx,%rax
 1012282:	48 83 f8 00          	cmp    $0x0,%rax
 1012286:	75 29                	jne    10122b1 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x981>
 1012288:	48 8b 45 d0          	mov    -0x30(%rbp),%rax
 101228c:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
 1012290:	ba 08 00 00 00       	mov    $0x8,%edx
 1012295:	be 00 00 00 00       	mov    $0x0,%esi
 101229a:	49 89 fd             	mov    %rdi,%r13
 101229d:	48 8d 7d d0          	lea    -0x30(%rbp),%rdi
 10122a1:	e8 9a 5f 01 00       	call   1028240 <compiler_rt.fastMemset>
 10122a6:	4d 89 f0             	mov    %r14,%r8
 10122a9:	4c 89 ef             	mov    %r13,%rdi
 10122ac:	4d 89 c6             	mov    %r8,%r14
 10122af:	eb 3f                	jmp    10122f0 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x9c0>
 10122b1:	4d 89 f0             	mov    %r14,%r8
 10122b4:	4d 89 c6             	mov    %r8,%r14
 10122b7:	48 8d 4d d0          	lea    -0x30(%rbp),%rcx
 10122bb:	48 8d 55 a8          	lea    -0x58(%rbp),%rdx
 10122bf:	48 8d 35 7a a2 01 00 	lea    0x1a27a(%rip),%rsi        # 102c540 <myl_t_1e414bd82e4b50b54939760a2d591f88da97e2f1c8252dbd7dcbc73438e46afb>
 10122c6:	49 89 fd             	mov    %rdi,%r13
 10122c9:	e8 d2 5b 01 00       	call   1027ea0 <myl_rc_native_take>
 10122ce:	4c 89 ef             	mov    %r13,%rdi
 10122d1:	83 f8 00             	cmp    $0x0,%eax
 10122d4:	75 1a                	jne    10122f0 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x9c0>
 10122d6:	e8 e5 e6 00 00       	call   10209c0 <myl_rc_take_failure>
 10122db:	48 89 df             	mov    %rbx,%rdi
 10122de:	89 c6                	mov    %eax,%esi
 10122e0:	48 89 fb             	mov    %rdi,%rbx
 10122e3:	e8 28 5e 00 00       	call   1018110 <myl_qbe_rc_status>
 10122e8:	48 89 df             	mov    %rbx,%rdi
 10122eb:	e9 5a 04 00 00       	jmp    101274a <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xe1a>
 10122f0:	c7 85 60 ff ff ff 00 	movl   $0x0,-0xa0(%rbp)
 10122f7:	00 00 00 
 10122fa:	48 8d 05 3f a2 01 00 	lea    0x1a23f(%rip),%rax        # 102c540 <myl_t_1e414bd82e4b50b54939760a2d591f88da97e2f1c8252dbd7dcbc73438e46afb>
 1012301:	48 89 85 10 ff ff ff 	mov    %rax,-0xf0(%rbp)
 1012308:	c7 85 28 ff ff ff 02 	movl   $0x2,-0xd8(%rbp)
 101230f:	00 00 00 
 1012312:	c7 85 70 ff ff ff 01 	movl   $0x1,-0x90(%rbp)
 1012319:	00 00 00 
 101231c:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
 1012320:	48 89 45 e0          	mov    %rax,-0x20(%rbp)
 1012324:	c7 85 70 ff ff ff 00 	movl   $0x0,-0x90(%rbp)
 101232b:	00 00 00 
 101232e:	48 8d 45 e0          	lea    -0x20(%rbp),%rax
 1012332:	48 89 45 d0          	mov    %rax,-0x30(%rbp)
 1012336:	48 8b 45 e0          	mov    -0x20(%rbp),%rax
 101233a:	48 89 45 90          	mov    %rax,-0x70(%rbp)
 101233e:	48 8d 05 2b a4 01 00 	lea    0x1a42b(%rip),%rax        # 102c770 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 1012345:	48 89 85 d0 fe ff ff 	mov    %rax,-0x130(%rbp)
 101234c:	c7 85 e8 fe ff ff 02 	movl   $0x2,-0x118(%rbp)
 1012353:	00 00 00 
 1012356:	c7 85 60 ff ff ff 01 	movl   $0x1,-0xa0(%rbp)
 101235d:	00 00 00 
 1012360:	48 8d 45 90          	lea    -0x70(%rbp),%rax
 1012364:	48 89 45 d0          	mov    %rax,-0x30(%rbp)
 1012368:	c7 85 78 ff ff ff 00 	movl   $0x0,-0x88(%rbp)
 101236f:	00 00 00 
 1012372:	ba 10 00 00 00       	mov    $0x10,%edx
 1012377:	be 00 00 00 00       	mov    $0x0,%esi
 101237c:	49 89 fd             	mov    %rdi,%r13
 101237f:	48 8d 7d e8          	lea    -0x18(%rbp),%rdi
 1012383:	e8 b8 5e 01 00       	call   1028240 <compiler_rt.fastMemset>
 1012388:	4d 89 f0             	mov    %r14,%r8
 101238b:	4c 89 ef             	mov    %r13,%rdi
 101238e:	48 8d 05 4b a4 01 00 	lea    0x1a44b(%rip),%rax        # 102c7e0 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 1012395:	48 89 85 30 ff ff ff 	mov    %rax,-0xd0(%rbp)
 101239c:	c7 85 48 ff ff ff 02 	movl   $0x2,-0xb8(%rbp)
 10123a3:	00 00 00 
 10123a6:	48 8d 45 e8          	lea    -0x18(%rbp),%rax
 10123aa:	48 89 85 38 ff ff ff 	mov    %rax,-0xc8(%rbp)
 10123b1:	4c 89 a5 40 ff ff ff 	mov    %r12,-0xc0(%rbp)
 10123b8:	c7 85 78 ff ff ff 01 	movl   $0x1,-0x88(%rbp)
 10123bf:	00 00 00 
 10123c2:	48 8b 4d c8          	mov    -0x38(%rbp),%rcx
 10123c6:	8b 85 58 ff ff ff    	mov    -0xa8(%rbp),%eax
 10123cc:	83 f8 00             	cmp    $0x0,%eax
 10123cf:	75 5f                	jne    1012430 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xb00>
 10123d1:	4d 89 c5             	mov    %r8,%r13
 10123d4:	48 8d 55 a8          	lea    -0x58(%rbp),%rdx
 10123d8:	48 8d 35 91 a3 01 00 	lea    0x1a391(%rip),%rsi        # 102c770 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 10123df:	49 89 fc             	mov    %rdi,%r12
 10123e2:	e8 19 56 01 00       	call   1027a00 <myl_rc_native_copy>
 10123e7:	4c 89 e7             	mov    %r12,%rdi
 10123ea:	83 f8 00             	cmp    $0x0,%eax
 10123ed:	75 1a                	jne    1012409 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xad9>
 10123ef:	e8 cc e5 00 00       	call   10209c0 <myl_rc_take_failure>
 10123f4:	48 89 df             	mov    %rbx,%rdi
 10123f7:	89 c6                	mov    %eax,%esi
 10123f9:	48 89 fb             	mov    %rdi,%rbx
 10123fc:	e8 0f 5d 00 00       	call   1018110 <myl_qbe_rc_status>
 1012401:	48 89 df             	mov    %rbx,%rdi
 1012404:	e9 41 03 00 00       	jmp    101274a <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xe1a>
 1012409:	48 8d 05 60 a3 01 00 	lea    0x1a360(%rip),%rax        # 102c770 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 1012410:	48 89 85 10 ff ff ff 	mov    %rax,-0xf0(%rbp)
 1012417:	c7 85 28 ff ff ff 02 	movl   $0x2,-0xd8(%rbp)
 101241e:	00 00 00 
 1012421:	c7 85 70 ff ff ff 01 	movl   $0x1,-0x90(%rbp)
 1012428:	00 00 00 
 101242b:	e9 dd 00 00 00       	jmp    101250d <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xbdd>
 1012430:	4d 89 c5             	mov    %r8,%r13
 1012433:	48 8d 45 a8          	lea    -0x58(%rbp),%rax
 1012437:	48 f7 d8             	neg    %rax
 101243a:	48 01 c8             	add    %rcx,%rax
 101243d:	48 8d 55 a8          	lea    -0x58(%rbp),%rdx
 1012441:	48 29 ca             	sub    %rcx,%rdx
 1012444:	48 83 f8 08          	cmp    $0x8,%rax
 1012448:	0f 92 c0             	setb   %al
 101244b:	0f b6 c0             	movzbl %al,%eax
 101244e:	48 83 fa 08          	cmp    $0x8,%rdx
 1012452:	0f 92 c2             	setb   %dl
 1012455:	0f b6 d2             	movzbl %dl,%edx
 1012458:	09 d0                	or     %edx,%eax
 101245a:	75 4a                	jne    10124a6 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xb76>
 101245c:	48 8b 01             	mov    (%rcx),%rax
 101245f:	48 83 f8 00          	cmp    $0x0,%rax
 1012463:	74 1a                	je     101247f <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xb4f>
 1012465:	48 83 e8 10          	sub    $0x10,%rax
 1012469:	48 8b 00             	mov    (%rax),%rax
 101246c:	48 ba 01 00 00 00 00 	movabs $0x5000000000000001,%rdx
 1012473:	00 00 50 
 1012476:	48 21 d0             	and    %rdx,%rax
 1012479:	48 83 f8 00          	cmp    $0x0,%rax
 101247d:	75 27                	jne    10124a6 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xb76>
 101247f:	48 8b 01             	mov    (%rcx),%rax
 1012482:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
 1012486:	ba 08 00 00 00       	mov    $0x8,%edx
 101248b:	be 00 00 00 00       	mov    $0x0,%esi
 1012490:	49 89 fc             	mov    %rdi,%r12
 1012493:	48 89 cf             	mov    %rcx,%rdi
 1012496:	e8 a5 5d 01 00       	call   1028240 <compiler_rt.fastMemset>
 101249b:	4d 89 e8             	mov    %r13,%r8
 101249e:	4c 89 e7             	mov    %r12,%rdi
 10124a1:	4d 89 c5             	mov    %r8,%r13
 10124a4:	eb 3b                	jmp    10124e1 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xbb1>
 10124a6:	4d 89 e8             	mov    %r13,%r8
 10124a9:	4d 89 c5             	mov    %r8,%r13
 10124ac:	48 8d 55 a8          	lea    -0x58(%rbp),%rdx
 10124b0:	48 8d 35 b9 a2 01 00 	lea    0x1a2b9(%rip),%rsi        # 102c770 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 10124b7:	49 89 fc             	mov    %rdi,%r12
 10124ba:	e8 e1 59 01 00       	call   1027ea0 <myl_rc_native_take>
 10124bf:	4c 89 e7             	mov    %r12,%rdi
 10124c2:	83 f8 00             	cmp    $0x0,%eax
 10124c5:	75 1a                	jne    10124e1 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xbb1>
 10124c7:	e8 f4 e4 00 00       	call   10209c0 <myl_rc_take_failure>
 10124cc:	48 89 df             	mov    %rbx,%rdi
 10124cf:	89 c6                	mov    %eax,%esi
 10124d1:	48 89 fb             	mov    %rdi,%rbx
 10124d4:	e8 37 5c 00 00       	call   1018110 <myl_qbe_rc_status>
 10124d9:	48 89 df             	mov    %rbx,%rdi
 10124dc:	e9 69 02 00 00       	jmp    101274a <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xe1a>
 10124e1:	c7 85 58 ff ff ff 00 	movl   $0x0,-0xa8(%rbp)
 10124e8:	00 00 00 
 10124eb:	48 8d 05 7e a2 01 00 	lea    0x1a27e(%rip),%rax        # 102c770 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 10124f2:	48 89 85 10 ff ff ff 	mov    %rax,-0xf0(%rbp)
 10124f9:	c7 85 28 ff ff ff 02 	movl   $0x2,-0xd8(%rbp)
 1012500:	00 00 00 
 1012503:	c7 85 70 ff ff ff 01 	movl   $0x1,-0x90(%rbp)
 101250a:	00 00 00 
 101250d:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
 1012511:	48 89 45 e8          	mov    %rax,-0x18(%rbp)
 1012515:	c7 85 70 ff ff ff 00 	movl   $0x0,-0x90(%rbp)
 101251c:	00 00 00 
 101251f:	48 8b 4d d0          	mov    -0x30(%rbp),%rcx
 1012523:	48 8d 45 a8          	lea    -0x58(%rbp),%rax
 1012527:	48 f7 d8             	neg    %rax
 101252a:	48 01 c8             	add    %rcx,%rax
 101252d:	48 8d 55 a8          	lea    -0x58(%rbp),%rdx
 1012531:	48 29 ca             	sub    %rcx,%rdx
 1012534:	48 83 f8 08          	cmp    $0x8,%rax
 1012538:	0f 92 c0             	setb   %al
 101253b:	0f b6 c0             	movzbl %al,%eax
 101253e:	48 83 fa 08          	cmp    $0x8,%rdx
 1012542:	0f 92 c2             	setb   %dl
 1012545:	0f b6 d2             	movzbl %dl,%edx
 1012548:	09 d0                	or     %edx,%eax
 101254a:	75 4a                	jne    1012596 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xc66>
 101254c:	48 8b 01             	mov    (%rcx),%rax
 101254f:	48 83 f8 00          	cmp    $0x0,%rax
 1012553:	74 1a                	je     101256f <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xc3f>
 1012555:	48 83 e8 10          	sub    $0x10,%rax
 1012559:	48 8b 00             	mov    (%rax),%rax
 101255c:	48 ba 01 00 00 00 00 	movabs $0x5000000000000001,%rdx
 1012563:	00 00 50 
 1012566:	48 21 d0             	and    %rdx,%rax
 1012569:	48 83 f8 00          	cmp    $0x0,%rax
 101256d:	75 27                	jne    1012596 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xc66>
 101256f:	48 8b 01             	mov    (%rcx),%rax
 1012572:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
 1012576:	ba 08 00 00 00       	mov    $0x8,%edx
 101257b:	be 00 00 00 00       	mov    $0x0,%esi
 1012580:	49 89 fc             	mov    %rdi,%r12
 1012583:	48 89 cf             	mov    %rcx,%rdi
 1012586:	e8 b5 5c 01 00       	call   1028240 <compiler_rt.fastMemset>
 101258b:	4d 89 e8             	mov    %r13,%r8
 101258e:	4c 89 e7             	mov    %r12,%rdi
 1012591:	48 87 df             	xchg   %rbx,%rdi
 1012594:	eb 41                	jmp    10125d7 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xca7>
 1012596:	4d 89 e8             	mov    %r13,%r8
 1012599:	4d 89 c5             	mov    %r8,%r13
 101259c:	48 8d 55 a8          	lea    -0x58(%rbp),%rdx
 10125a0:	48 8d 35 c9 a1 01 00 	lea    0x1a1c9(%rip),%rsi        # 102c770 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 10125a7:	49 89 fc             	mov    %rdi,%r12
 10125aa:	e8 f1 58 01 00       	call   1027ea0 <myl_rc_native_take>
 10125af:	4d 89 e8             	mov    %r13,%r8
 10125b2:	4c 89 e7             	mov    %r12,%rdi
 10125b5:	83 f8 00             	cmp    $0x0,%eax
 10125b8:	75 1a                	jne    10125d4 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xca4>
 10125ba:	e8 01 e4 00 00       	call   10209c0 <myl_rc_take_failure>
 10125bf:	48 89 df             	mov    %rbx,%rdi
 10125c2:	89 c6                	mov    %eax,%esi
 10125c4:	48 89 fb             	mov    %rdi,%rbx
 10125c7:	e8 44 5b 00 00       	call   1018110 <myl_qbe_rc_status>
 10125cc:	48 89 df             	mov    %rbx,%rdi
 10125cf:	e9 76 01 00 00       	jmp    101274a <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xe1a>
 10125d4:	48 87 df             	xchg   %rbx,%rdi
 10125d7:	c7 85 60 ff ff ff 00 	movl   $0x0,-0xa0(%rbp)
 10125de:	00 00 00 
 10125e1:	48 8d 05 88 a1 01 00 	lea    0x1a188(%rip),%rax        # 102c770 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 10125e8:	48 89 85 10 ff ff ff 	mov    %rax,-0xf0(%rbp)
 10125ef:	c7 85 28 ff ff ff 02 	movl   $0x2,-0xd8(%rbp)
 10125f6:	00 00 00 
 10125f9:	c7 85 70 ff ff ff 01 	movl   $0x1,-0x90(%rbp)
 1012600:	00 00 00 
 1012603:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
 1012607:	48 89 45 f0          	mov    %rax,-0x10(%rbp)
 101260b:	c7 85 70 ff ff ff 00 	movl   $0x0,-0x90(%rbp)
 1012612:	00 00 00 
 1012615:	48 8d 45 e8          	lea    -0x18(%rbp),%rax
 1012619:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
 101261d:	48 8b 45 e8          	mov    -0x18(%rbp),%rax
 1012621:	48 89 45 80          	mov    %rax,-0x80(%rbp)
 1012625:	48 8b 45 f0          	mov    -0x10(%rbp),%rax
 1012629:	48 89 45 88          	mov    %rax,-0x78(%rbp)
 101262d:	48 8d 05 ac a1 01 00 	lea    0x1a1ac(%rip),%rax        # 102c7e0 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 1012634:	48 89 85 b0 fe ff ff 	mov    %rax,-0x150(%rbp)
 101263b:	c7 85 c8 fe ff ff 02 	movl   $0x2,-0x138(%rbp)
 1012642:	00 00 00 
 1012645:	c7 85 58 ff ff ff 01 	movl   $0x1,-0xa8(%rbp)
 101264c:	00 00 00 
 101264f:	48 8d 45 80          	lea    -0x80(%rbp),%rax
 1012653:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
 1012657:	c7 85 78 ff ff ff 00 	movl   $0x0,-0x88(%rbp)
 101265e:	00 00 00 
 1012661:	48 8d 4d a8          	lea    -0x58(%rbp),%rcx
 1012665:	48 8d 45 80          	lea    -0x80(%rbp),%rax
 1012669:	48 29 c8             	sub    %rcx,%rax
 101266c:	48 8d 55 80          	lea    -0x80(%rbp),%rdx
 1012670:	48 8d 4d a8          	lea    -0x58(%rbp),%rcx
 1012674:	48 29 d1             	sub    %rdx,%rcx
 1012677:	48 83 f8 10          	cmp    $0x10,%rax
 101267b:	0f 92 c0             	setb   %al
 101267e:	0f b6 c0             	movzbl %al,%eax
 1012681:	48 83 f9 10          	cmp    $0x10,%rcx
 1012685:	0f 92 c1             	setb   %cl
 1012688:	0f b6 c9             	movzbl %cl,%ecx
 101268b:	09 c8                	or     %ecx,%eax
 101268d:	0f 85 80 00 00 00    	jne    1012713 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xde3>
 1012693:	48 8b 45 80          	mov    -0x80(%rbp),%rax
 1012697:	48 83 f8 00          	cmp    $0x0,%rax
 101269b:	74 1a                	je     10126b7 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xd87>
 101269d:	48 83 e8 10          	sub    $0x10,%rax
 10126a1:	48 8b 00             	mov    (%rax),%rax
 10126a4:	48 b9 01 00 00 00 00 	movabs $0x5000000000000001,%rcx
 10126ab:	00 00 50 
 10126ae:	48 21 c8             	and    %rcx,%rax
 10126b1:	48 83 f8 00          	cmp    $0x0,%rax
 10126b5:	75 57                	jne    101270e <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xdde>
 10126b7:	48 8b 45 88          	mov    -0x78(%rbp),%rax
 10126bb:	48 83 f8 00          	cmp    $0x0,%rax
 10126bf:	74 1a                	je     10126db <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xdab>
 10126c1:	48 83 e8 10          	sub    $0x10,%rax
 10126c5:	48 8b 00             	mov    (%rax),%rax
 10126c8:	48 b9 01 00 00 00 00 	movabs $0x5000000000000001,%rcx
 10126cf:	00 00 50 
 10126d2:	48 21 c8             	and    %rcx,%rax
 10126d5:	48 83 f8 00          	cmp    $0x0,%rax
 10126d9:	75 2e                	jne    1012709 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xdd9>
 10126db:	48 8b 45 80          	mov    -0x80(%rbp),%rax
 10126df:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
 10126e3:	48 8b 45 88          	mov    -0x78(%rbp),%rax
 10126e7:	48 89 45 b0          	mov    %rax,-0x50(%rbp)
 10126eb:	ba 10 00 00 00       	mov    $0x10,%edx
 10126f0:	be 00 00 00 00       	mov    $0x0,%esi
 10126f5:	48 89 fb             	mov    %rdi,%rbx
 10126f8:	48 8d 7d 80          	lea    -0x80(%rbp),%rdi
 10126fc:	e8 3f 5b 01 00       	call   1028240 <compiler_rt.fastMemset>
 1012701:	48 89 df             	mov    %rbx,%rdi
 1012704:	e9 8b 00 00 00       	jmp    1012794 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xe64>
 1012709:	48 87 fb             	xchg   %rdi,%rbx
 101270c:	eb 08                	jmp    1012716 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xde6>
 101270e:	48 87 fb             	xchg   %rdi,%rbx
 1012711:	eb 03                	jmp    1012716 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xde6>
 1012713:	48 87 fb             	xchg   %rdi,%rbx
 1012716:	48 8d 4d 80          	lea    -0x80(%rbp),%rcx
 101271a:	48 8d 55 a8          	lea    -0x58(%rbp),%rdx
 101271e:	48 8d 35 bb a0 01 00 	lea    0x1a0bb(%rip),%rsi        # 102c7e0 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 1012725:	49 89 fc             	mov    %rdi,%r12
 1012728:	e8 73 57 01 00       	call   1027ea0 <myl_rc_native_take>
 101272d:	4c 89 e7             	mov    %r12,%rdi
 1012730:	83 f8 00             	cmp    $0x0,%eax
 1012733:	75 5c                	jne    1012791 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xe61>
 1012735:	e8 86 e2 00 00       	call   10209c0 <myl_rc_take_failure>
 101273a:	48 89 df             	mov    %rbx,%rdi
 101273d:	89 c6                	mov    %eax,%esi
 101273f:	48 89 fb             	mov    %rdi,%rbx
 1012742:	e8 c9 59 00 00       	call   1018110 <myl_qbe_rc_status>
 1012747:	48 89 df             	mov    %rbx,%rdi
 101274a:	48 8d b5 70 fe ff ff 	lea    -0x190(%rbp),%rsi
 1012751:	48 89 fb             	mov    %rdi,%rbx
 1012754:	e8 97 5c 00 00       	call   10183f0 <myl_qbe_rc_frame_cleanup>
 1012759:	48 89 df             	mov    %rbx,%rdi
 101275c:	48 8d b5 70 fe ff ff 	lea    -0x190(%rbp),%rsi
 1012763:	e8 18 5b 00 00       	call   1018280 <myl_qbe_rc_frame_leave>
 1012768:	ba 10 00 00 00       	mov    $0x10,%edx
 101276d:	be 00 00 00 00       	mov    $0x0,%esi
 1012772:	48 8d bd 60 fe ff ff 	lea    -0x1a0(%rbp),%rdi
 1012779:	e8 c2 5a 01 00       	call   1028240 <compiler_rt.fastMemset>
 101277e:	48 8b 85 60 fe ff ff 	mov    -0x1a0(%rbp),%rax
 1012785:	48 8b 95 68 fe ff ff 	mov    -0x198(%rbp),%rdx
 101278c:	e9 b3 00 00 00       	jmp    1012844 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xf14>
 1012791:	48 89 df             	mov    %rbx,%rdi
 1012794:	c7 85 58 ff ff ff 00 	movl   $0x0,-0xa8(%rbp)
 101279b:	00 00 00 
 101279e:	48 8d 05 3b a0 01 00 	lea    0x1a03b(%rip),%rax        # 102c7e0 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 10127a5:	48 89 85 10 ff ff ff 	mov    %rax,-0xf0(%rbp)
 10127ac:	c7 85 28 ff ff ff 02 	movl   $0x2,-0xd8(%rbp)
 10127b3:	00 00 00 
 10127b6:	c7 85 70 ff ff ff 01 	movl   $0x1,-0x90(%rbp)
 10127bd:	00 00 00 
 10127c0:	c7 85 70 ff ff ff 00 	movl   $0x0,-0x90(%rbp)
 10127c7:	00 00 00 
 10127ca:	48 8d b5 70 fe ff ff 	lea    -0x190(%rbp),%rsi
 10127d1:	48 89 fb             	mov    %rdi,%rbx
 10127d4:	e8 17 5c 00 00       	call   10183f0 <myl_qbe_rc_frame_cleanup>
 10127d9:	48 89 df             	mov    %rbx,%rdi
 10127dc:	48 8d b5 70 fe ff ff 	lea    -0x190(%rbp),%rsi
 10127e3:	e8 98 5a 00 00       	call   1018280 <myl_qbe_rc_frame_leave>
 10127e8:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
 10127ec:	48 8b 55 b0          	mov    -0x50(%rbp),%rdx
 10127f0:	eb 52                	jmp    1012844 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xf14>
 10127f2:	41 b8 40 00 00 00    	mov    $0x40,%r8d
 10127f8:	b9 01 00 00 00       	mov    $0x1,%ecx
 10127fd:	be 01 00 00 00       	mov    $0x1,%esi
 1012802:	e8 89 61 00 00       	call   1018990 <myl_qbe_fail_overflow_op>
 1012807:	0f 0b                	ud2
 1012809:	41 b8 40 00 00 00    	mov    $0x40,%r8d
 101280f:	b9 01 00 00 00       	mov    $0x1,%ecx
 1012814:	be 01 00 00 00       	mov    $0x1,%esi
 1012819:	e8 72 61 00 00       	call   1018990 <myl_qbe_fail_overflow_op>
 101281e:	0f 0b                	ud2
 1012820:	48 c7 85 60 fe ff ff 	movq   $0x0,-0x1a0(%rbp)
 1012827:	00 00 00 00 
 101282b:	48 c7 85 68 fe ff ff 	movq   $0x0,-0x198(%rbp)
 1012832:	00 00 00 00 
 1012836:	48 8b 85 60 fe ff ff 	mov    -0x1a0(%rbp),%rax
 101283d:	48 8b 95 68 fe ff ff 	mov    -0x198(%rbp),%rdx
 1012844:	41 5f                	pop    %r15
 1012846:	41 5e                	pop    %r14
 1012848:	41 5d                	pop    %r13
 101284a:	41 5c                	pop    %r12
 101284c:	5b                   	pop    %rbx
 101284d:	c9                   	leave
 101284e:	c3                   	ret
 101284f:	e8 8c 62 00 00       	call   1018ae0 <myl_qbe_fail_frame>
 1012854:	0f 0b                	ud2

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
