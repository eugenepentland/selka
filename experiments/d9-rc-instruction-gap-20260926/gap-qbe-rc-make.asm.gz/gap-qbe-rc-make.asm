
.tmp-rc/profile/gap-qbe-rc-n12:     file format elf64-x86-64


Disassembly of section .text:

0000000001013680 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531>:
 1013680:	endbr64
 1013684:	push   %rbp
 1013685:	mov    %rsp,%rbp
 1013688:	sub    $0x268,%rsp
 101368f:	push   %rbx
 1013690:	push   %r12
 1013692:	push   %r13
 1013694:	push   %r14
 1013696:	push   %r15
 1013698:	mov    0x40(%rdi),%rax
 101369c:	lea    -0x48(%rbp),%rcx
 10136a0:	cmp    %rax,%rcx
 10136a3:	jb     10155a8 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1f28>
 10136a9:	mov    %rsi,-0xe0(%rbp)
 10136b0:	mov    %rdi,%rbx
 10136b3:	call   101b820 <myl_qbe_heap>
 10136b8:	mov    %rbx,%rdi
 10136bb:	mov    %rax,%r12
 10136be:	mov    $0x30,%edx
 10136c3:	mov    $0x0,%esi
 10136c8:	mov    %rdi,%rbx
 10136cb:	lea    -0x150(%rbp),%rdi
 10136d2:	call   102aee0 <compiler_rt.fastMemset>
 10136d7:	mov    %rbx,%rdi
 10136da:	mov    $0xc0,%edx
 10136df:	mov    $0x0,%esi
 10136e4:	mov    %rdi,%rbx
 10136e7:	lea    -0x210(%rbp),%rdi
 10136ee:	call   102aee0 <compiler_rt.fastMemset>
 10136f3:	mov    %rbx,%rdi
 10136f6:	lea    -0xf375(%rip),%rax        # 1004388 <myl_t_1a91deb3742283487d66c3b500f6effd7ef1170e6d4b4368fe9ec3c3f0354fda>
 10136fd:	mov    %rax,-0x210(%rbp)
 1013704:	lea    -0xe0(%rbp),%rax
 101370b:	mov    %rax,-0x208(%rbp)
 1013712:	lea    -0x150(%rbp),%rax
 1013719:	mov    %rax,-0x200(%rbp)
 1013720:	movl   $0x0,-0x1f8(%rbp)
 101372a:	lea    -0x210(%rbp),%rax
 1013731:	mov    %rax,%rsi
 1013734:	add    $0x20,%rsi
 1013738:	mov    %rsi,-0x38(%rbp)
 101373c:	lea    -0xf24b(%rip),%rax        # 10044f8 <myl_t_385cfdbc00ec32031699460779c15099b2bba3cad0e440fffb08e10df0acb9e1>
 1013743:	mov    %rax,-0x1f0(%rbp)
 101374a:	lea    -0x120(%rbp),%rax
 1013751:	mov    %rax,-0x1e8(%rbp)
 1013758:	lea    -0x150(%rbp),%rax
 101375f:	mov    %rax,%r14
 1013762:	add    $0x8,%r14
 1013766:	mov    %r14,-0x18(%rbp)
 101376a:	mov    %r14,-0x1e0(%rbp)
 1013771:	movl   $0x0,-0x1d8(%rbp)
 101377b:	lea    -0x210(%rbp),%rax
 1013782:	mov    %rax,%rsi
 1013785:	add    $0x40,%rsi
 1013789:	mov    %rsi,-0x40(%rbp)
 101378d:	lea    -0xf29c(%rip),%rax        # 10044f8 <myl_t_385cfdbc00ec32031699460779c15099b2bba3cad0e440fffb08e10df0acb9e1>
 1013794:	mov    %rax,-0x1d0(%rbp)
 101379b:	lea    -0x110(%rbp),%rax
 10137a2:	mov    %rax,-0x1c8(%rbp)
 10137a9:	lea    -0x150(%rbp),%rax
 10137b0:	add    $0x10,%rax
 10137b4:	mov    %rax,-0x28(%rbp)
 10137b8:	mov    %rax,-0x1c0(%rbp)
 10137bf:	movl   $0x0,-0x1b8(%rbp)
 10137c9:	lea    -0xf2d8(%rip),%rax        # 10044f8 <myl_t_385cfdbc00ec32031699460779c15099b2bba3cad0e440fffb08e10df0acb9e1>
 10137d0:	mov    %rax,-0x1b0(%rbp)
 10137d7:	lea    -0x100(%rbp),%rax
 10137de:	mov    %rax,-0x1a8(%rbp)
 10137e5:	lea    -0x150(%rbp),%rax
 10137ec:	add    $0x18,%rax
 10137f0:	mov    %rax,-0x1a0(%rbp)
 10137f7:	movl   $0x0,-0x198(%rbp)
 1013801:	lea    -0xf310(%rip),%rax        # 10044f8 <myl_t_385cfdbc00ec32031699460779c15099b2bba3cad0e440fffb08e10df0acb9e1>
 1013808:	mov    %rax,-0x190(%rbp)
 101380f:	lea    -0xf8(%rbp),%rax
 1013816:	mov    %rax,-0x188(%rbp)
 101381d:	lea    -0x150(%rbp),%rax
 1013824:	mov    %rax,%rbx
 1013827:	add    $0x20,%rbx
 101382b:	mov    %rbx,-0x180(%rbp)
 1013832:	movl   $0x0,-0x178(%rbp)
 101383c:	lea    -0xf34b(%rip),%rax        # 10044f8 <myl_t_385cfdbc00ec32031699460779c15099b2bba3cad0e440fffb08e10df0acb9e1>
 1013843:	mov    %rax,-0x170(%rbp)
 101384a:	lea    -0xe8(%rbp),%rax
 1013851:	mov    %rax,-0x168(%rbp)
 1013858:	lea    -0x150(%rbp),%rax
 101385f:	mov    %rax,%r13
 1013862:	add    $0x28,%r13
 1013866:	mov    %r13,-0x160(%rbp)
 101386d:	movl   $0x0,-0x158(%rbp)
 1013877:	mov    $0x6,%ecx
 101387c:	lea    -0x210(%rbp),%rdx
 1013883:	lea    -0x230(%rbp),%rsi
 101388a:	mov    %rdi,%r15
 101388d:	call   101af50 <myl_qbe_rc_frame_enter>
 1013892:	mov    %r15,%rdi
 1013895:	mov    %rdi,%r15
 1013898:	call   101b5f0 <myl_qbe_root_mark>
 101389d:	mov    %r15,%rdi
 10138a0:	mov    %rax,-0x30(%rbp)
 10138a4:	mov    -0xe0(%rbp),%rdx
 10138ab:	mov    %rdx,-0xd8(%rbp)
 10138b2:	movq   $0x0,-0xd0(%rbp)
 10138bd:	cmp    $0x0,%rdx
 10138c1:	sete   %al
 10138c4:	movzbq %al,%rax
 10138c8:	mov    %rax,-0xd8(%rbp)
 10138cf:	cmp    $0x0,%eax
 10138d2:	jne    1014cd9 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1659>
 10138d8:	mov    %rdx,-0xd8(%rbp)
 10138df:	movq   $0x1,-0xd0(%rbp)
 10138ea:	movabs $0x8000000000000001,%rax
 10138f4:	cmp    %rax,%rdx
 10138f7:	jl     1014cc2 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1642>
 10138fd:	mov    %rdx,%rsi
 1013900:	sub    $0x1,%rsi
 1013904:	mov    %rsi,-0xd8(%rbp)
 101390b:	mov    %rdi,%r15
 101390e:	call   1013680 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531>
 1013913:	mov    %r15,%rdi
 1013916:	mov    %rax,%rcx
 1013919:	mov    %rdx,%rax
 101391c:	mov    %rcx,-0x260(%rbp)
 1013923:	mov    %rax,-0x258(%rbp)
 101392a:	lea    -0x260(%rbp),%rax
 1013931:	mov    %rax,-0xd8(%rbp)
 1013938:	mov    -0x260(%rbp),%rax
 101393f:	mov    %rax,-0xf8(%rbp)
 1013946:	mov    -0x258(%rbp),%rax
 101394d:	mov    %rax,-0xf0(%rbp)
 1013954:	lea    0x1bb25(%rip),%rax        # 102f480 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 101395b:	mov    %rax,-0x190(%rbp)
 1013962:	lea    -0xf8(%rbp),%rax
 1013969:	mov    %rax,-0x188(%rbp)
 1013970:	mov    %rbx,-0x180(%rbp)
 1013977:	movl   $0x2,-0x178(%rbp)
 1013981:	movl   $0x1,-0x130(%rbp)
 101398b:	mov    -0xf8(%rbp),%rax
 1013992:	mov    %rax,-0x120(%rbp)
 1013999:	mov    -0xf0(%rbp),%rax
 10139a0:	mov    %rax,-0x118(%rbp)
 10139a7:	lea    0x1bad2(%rip),%rax        # 102f480 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 10139ae:	mov    %rax,-0x1f0(%rbp)
 10139b5:	lea    -0x120(%rbp),%rax
 10139bc:	mov    %rax,-0x1e8(%rbp)
 10139c3:	mov    %r14,-0x1e0(%rbp)
 10139ca:	movl   $0x2,-0x1d8(%rbp)
 10139d4:	movl   $0x0,-0x130(%rbp)
 10139de:	movl   $0x1,-0x148(%rbp)
 10139e8:	lea    -0x120(%rbp),%rax
 10139ef:	mov    %rax,-0xd8(%rbp)
 10139f6:	mov    0x10(%r12),%rax
 10139fb:	mov    %rax,-0xc8(%rbp)
 1013a02:	lea    -0x120(%rbp),%rax
 1013a09:	mov    %rax,-0xc0(%rbp)
 1013a10:	lea    0x1ba69(%rip),%rax        # 102f480 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 1013a17:	mov    %rax,-0xb8(%rbp)
 1013a1e:	lea    -0xc8(%rbp),%rax
 1013a25:	mov    %rax,0x10(%r12)
 1013a2a:	mov    $0x1,%edx
 1013a2f:	lea    0x1b73a(%rip),%rsi        # 102f170 <myl_t_1e414bd82e4b50b54939760a2d591f88da97e2f1c8252dbd7dcbc73438e46afb_body>
 1013a36:	mov    %rdi,%r14
 1013a39:	mov    %r12,%rdi
 1013a3c:	call   101ff00 <myl_native_heap_alloc>
 1013a41:	mov    %r14,%rdi
 1013a44:	mov    %rax,-0x10(%rbp)
 1013a48:	cmp    $0x0,%eax
 1013a4b:	jne    1013a54 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x3d4>
 1013a4d:	call   101b580 <myl_qbe_fail_allocation>
 1013a52:	ud2
 1013a54:	mov    %rax,-0xe8(%rbp)
 1013a5b:	lea    0x1b77e(%rip),%rax        # 102f1e0 <myl_t_1e414bd82e4b50b54939760a2d591f88da97e2f1c8252dbd7dcbc73438e46afb>
 1013a62:	mov    %rax,-0x170(%rbp)
 1013a69:	lea    -0xe8(%rbp),%rax
 1013a70:	mov    %rax,-0x168(%rbp)
 1013a77:	mov    %r13,-0x160(%rbp)
 1013a7e:	movl   $0x2,-0x158(%rbp)
 1013a88:	movl   $0x4,-0x158(%rbp)
 1013a92:	movl   $0x1,-0x128(%rbp)
 1013a9c:	mov    %rdi,%r14
 1013a9f:	call   101db60 <myl_qbe_region_mark>
 1013aa4:	mov    %r14,%rdi
 1013aa7:	mov    -0xd8(%rbp),%r15
 1013aae:	mov    %rdi,%r14
 1013ab1:	call   101db60 <myl_qbe_region_mark>
 1013ab6:	mov    %r15,%rcx
 1013ab9:	mov    %r14,%rdi
 1013abc:	mov    %rax,%r8
 1013abf:	mov    -0x18(%rbp),%r14
 1013ac3:	lea    -0xf8(%rbp),%rax
 1013aca:	neg    %rax
 1013acd:	add    %rcx,%rax
 1013ad0:	lea    -0xf8(%rbp),%rdx
 1013ad7:	sub    %rcx,%rdx
 1013ada:	cmp    $0x10,%rax
 1013ade:	setb   %al
 1013ae1:	movzbl %al,%eax
 1013ae4:	cmp    $0x10,%rdx
 1013ae8:	setb   %dl
 1013aeb:	movzbl %dl,%edx
 1013aee:	or     %edx,%eax
 1013af0:	jne    1013b78 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x4f8>
 1013af6:	mov    (%rcx),%rax
 1013af9:	cmp    $0x0,%rax
 1013afd:	je     1013b19 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x499>
 1013aff:	sub    $0x10,%rax
 1013b03:	mov    (%rax),%rax
 1013b06:	movabs $0x5000000000000001,%rdx
 1013b10:	and    %rdx,%rax
 1013b13:	cmp    $0x0,%rax
 1013b17:	jne    1013b78 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x4f8>
 1013b19:	mov    0x8(%rcx),%rax
 1013b1d:	cmp    $0x0,%rax
 1013b21:	je     1013b3d <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x4bd>
 1013b23:	sub    $0x10,%rax
 1013b27:	mov    (%rax),%rax
 1013b2a:	movabs $0x5000000000000001,%rdx
 1013b34:	and    %rdx,%rax
 1013b37:	cmp    $0x0,%rax
 1013b3b:	jne    1013b78 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x4f8>
 1013b3d:	mov    (%rcx),%rax
 1013b40:	mov    %rax,-0xf8(%rbp)
 1013b47:	mov    0x8(%rcx),%rax
 1013b4b:	mov    %rax,-0xf0(%rbp)
 1013b52:	mov    $0x10,%edx
 1013b57:	mov    $0x0,%esi
 1013b5c:	mov    %rdi,%r15
 1013b5f:	mov    %rcx,%rdi
 1013b62:	call   102aee0 <compiler_rt.fastMemset>
 1013b67:	mov    %r15,%rdi
 1013b6a:	mov    -0x10(%rbp),%rax
 1013b6e:	mov    -0x30(%rbp),%r15
 1013b72:	mov    -0x38(%rbp),%rsi
 1013b76:	jmp    1013bca <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x54a>
 1013b78:	lea    -0xf8(%rbp),%rdx
 1013b7f:	lea    0x1b8fa(%rip),%rsi        # 102f480 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 1013b86:	mov    %rdi,%r15
 1013b89:	mov    %r12,%rdi
 1013b8c:	call   102ab40 <myl_rc_native_take>
 1013b91:	mov    %r15,%rdi
 1013b94:	mov    %eax,%ecx
 1013b96:	mov    -0x10(%rbp),%rax
 1013b9a:	mov    -0x30(%rbp),%r15
 1013b9e:	mov    -0x38(%rbp),%rsi
 1013ba2:	cmp    $0x0,%ecx
 1013ba5:	jne    1013bca <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x54a>
 1013ba7:	mov    %rdi,%rbx
 1013baa:	mov    %r12,%rdi
 1013bad:	call   1023700 <myl_rc_take_failure>
 1013bb2:	mov    %rbx,%rdi
 1013bb5:	mov    %eax,%esi
 1013bb7:	mov    %rdi,%rbx
 1013bba:	call   101ae60 <myl_qbe_rc_status>
 1013bbf:	mov    %rbx,%rdi
 1013bc2:	mov    %r15,%rbx
 1013bc5:	jmp    10154dd <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1e5d>
 1013bca:	movl   $0x0,-0x148(%rbp)
 1013bd4:	lea    0x1b8a5(%rip),%rcx        # 102f480 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 1013bdb:	mov    %rcx,-0x190(%rbp)
 1013be2:	lea    -0xf8(%rbp),%rcx
 1013be9:	mov    %rcx,-0x188(%rbp)
 1013bf0:	mov    %rbx,-0x180(%rbp)
 1013bf7:	movl   $0x2,-0x178(%rbp)
 1013c01:	movl   $0x1,-0x130(%rbp)
 1013c0b:	mov    -0xf8(%rbp),%rcx
 1013c12:	mov    %rcx,(%rax)
 1013c15:	mov    -0xf0(%rbp),%rcx
 1013c1c:	mov    %rcx,0x8(%rax)
 1013c20:	movl   $0x0,-0x130(%rbp)
 1013c2a:	mov    %rax,-0xd8(%rbp)
 1013c31:	movl   $0x0,-0x128(%rbp)
 1013c3b:	mov    -0xd8(%rbp),%rax
 1013c42:	mov    %rax,-0xf8(%rbp)
 1013c49:	lea    0x1b590(%rip),%rax        # 102f1e0 <myl_t_1e414bd82e4b50b54939760a2d591f88da97e2f1c8252dbd7dcbc73438e46afb>
 1013c50:	mov    %rax,-0x190(%rbp)
 1013c57:	lea    -0xf8(%rbp),%rax
 1013c5e:	mov    %rax,-0x188(%rbp)
 1013c65:	mov    %rbx,-0x180(%rbp)
 1013c6c:	movl   $0x2,-0x178(%rbp)
 1013c76:	movl   $0x1,-0x130(%rbp)
 1013c80:	mov    -0x148(%rbp),%eax
 1013c86:	cmp    $0x0,%eax
 1013c89:	je     1013c9a <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x61a>
 1013c8b:	mov    %rdi,%r15
 1013c8e:	call   101b030 <myl_qbe_rc_slot_drop>
 1013c93:	mov    %r15,%rdi
 1013c96:	mov    -0x30(%rbp),%r15
 1013c9a:	mov    -0xf8(%rbp),%rax
 1013ca1:	mov    %rax,-0x120(%rbp)
 1013ca8:	lea    0x1b531(%rip),%rax        # 102f1e0 <myl_t_1e414bd82e4b50b54939760a2d591f88da97e2f1c8252dbd7dcbc73438e46afb>
 1013caf:	mov    %rax,-0x1f0(%rbp)
 1013cb6:	lea    -0x120(%rbp),%rax
 1013cbd:	mov    %rax,-0x1e8(%rbp)
 1013cc4:	mov    %r14,-0x1e0(%rbp)
 1013ccb:	movl   $0x2,-0x1d8(%rbp)
 1013cd5:	movl   $0x0,-0x130(%rbp)
 1013cdf:	movl   $0x1,-0x148(%rbp)
 1013ce9:	mov    -0x120(%rbp),%rax
 1013cf0:	mov    %rax,-0xd8(%rbp)
 1013cf7:	mov    %r15,0x10(%r12)
 1013cfc:	mov    $0x8,%edx
 1013d01:	mov    $0x0,%esi
 1013d06:	mov    %rdi,%r15
 1013d09:	lea    -0x68(%rbp),%rdi
 1013d0d:	call   102aee0 <compiler_rt.fastMemset>
 1013d12:	mov    %r15,%rdi
 1013d15:	lea    0x1b6f4(%rip),%rax        # 102f410 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 1013d1c:	mov    %rax,-0x170(%rbp)
 1013d23:	lea    -0x68(%rbp),%rax
 1013d27:	mov    %rax,-0x168(%rbp)
 1013d2e:	mov    %r13,-0x160(%rbp)
 1013d35:	movl   $0x2,-0x158(%rbp)
 1013d3f:	movl   $0x1,-0x128(%rbp)
 1013d49:	mov    %rdi,%r15
 1013d4c:	call   101db60 <myl_qbe_region_mark>
 1013d51:	mov    %r15,%rdi
 1013d54:	mov    %rdi,%r15
 1013d57:	call   101db60 <myl_qbe_region_mark>
 1013d5c:	mov    %r15,%rdi
 1013d5f:	mov    %rax,%r8
 1013d62:	lea    -0xf8(%rbp),%rcx
 1013d69:	lea    -0xd8(%rbp),%rax
 1013d70:	sub    %rcx,%rax
 1013d73:	lea    -0xd8(%rbp),%rdx
 1013d7a:	lea    -0xf8(%rbp),%rcx
 1013d81:	sub    %rdx,%rcx
 1013d84:	cmp    $0x8,%rax
 1013d88:	setb   %al
 1013d8b:	movzbl %al,%eax
 1013d8e:	cmp    $0x8,%rcx
 1013d92:	setb   %cl
 1013d95:	movzbl %cl,%ecx
 1013d98:	or     %ecx,%eax
 1013d9a:	jne    1013df3 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x773>
 1013d9c:	mov    -0xd8(%rbp),%rax
 1013da3:	cmp    $0x0,%rax
 1013da7:	je     1013dc3 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x743>
 1013da9:	sub    $0x10,%rax
 1013dad:	mov    (%rax),%rax
 1013db0:	movabs $0x5000000000000001,%rcx
 1013dba:	and    %rcx,%rax
 1013dbd:	cmp    $0x0,%rax
 1013dc1:	jne    1013df3 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x773>
 1013dc3:	mov    -0xd8(%rbp),%rax
 1013dca:	mov    %rax,-0xf8(%rbp)
 1013dd1:	mov    $0x8,%edx
 1013dd6:	mov    $0x0,%esi
 1013ddb:	mov    %rdi,%r15
 1013dde:	lea    -0xd8(%rbp),%rdi
 1013de5:	call   102aee0 <compiler_rt.fastMemset>
 1013dea:	mov    %r15,%rdi
 1013ded:	mov    -0x30(%rbp),%r15
 1013df1:	jmp    1013e42 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x7c2>
 1013df3:	lea    -0xd8(%rbp),%rcx
 1013dfa:	lea    -0xf8(%rbp),%rdx
 1013e01:	lea    0x1b3d8(%rip),%rsi        # 102f1e0 <myl_t_1e414bd82e4b50b54939760a2d591f88da97e2f1c8252dbd7dcbc73438e46afb>
 1013e08:	mov    %rdi,%r15
 1013e0b:	mov    %r12,%rdi
 1013e0e:	call   102ab40 <myl_rc_native_take>
 1013e13:	mov    %r15,%rdi
 1013e16:	mov    -0x30(%rbp),%r15
 1013e1a:	cmp    $0x0,%eax
 1013e1d:	jne    1013e42 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x7c2>
 1013e1f:	mov    %rdi,%rbx
 1013e22:	mov    %r12,%rdi
 1013e25:	call   1023700 <myl_rc_take_failure>
 1013e2a:	mov    %rbx,%rdi
 1013e2d:	mov    %eax,%esi
 1013e2f:	mov    %rdi,%rbx
 1013e32:	call   101ae60 <myl_qbe_rc_status>
 1013e37:	mov    %rbx,%rdi
 1013e3a:	mov    %r15,%rbx
 1013e3d:	jmp    10154dd <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1e5d>
 1013e42:	movl   $0x0,-0x148(%rbp)
 1013e4c:	lea    0x1b38d(%rip),%rax        # 102f1e0 <myl_t_1e414bd82e4b50b54939760a2d591f88da97e2f1c8252dbd7dcbc73438e46afb>
 1013e53:	mov    %rax,-0x190(%rbp)
 1013e5a:	lea    -0xf8(%rbp),%rax
 1013e61:	mov    %rax,-0x188(%rbp)
 1013e68:	mov    %rbx,-0x180(%rbp)
 1013e6f:	movl   $0x2,-0x178(%rbp)
 1013e79:	movl   $0x1,-0x130(%rbp)
 1013e83:	mov    -0xf8(%rbp),%rax
 1013e8a:	mov    %rax,-0x68(%rbp)
 1013e8e:	movl   $0x0,-0x130(%rbp)
 1013e98:	lea    -0x68(%rbp),%rax
 1013e9c:	mov    %rax,-0xd8(%rbp)
 1013ea3:	movl   $0x0,-0x128(%rbp)
 1013ead:	mov    -0x68(%rbp),%rax
 1013eb1:	mov    %rax,-0xf8(%rbp)
 1013eb8:	lea    0x1b551(%rip),%rax        # 102f410 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 1013ebf:	mov    %rax,-0x190(%rbp)
 1013ec6:	lea    -0xf8(%rbp),%rax
 1013ecd:	mov    %rax,-0x188(%rbp)
 1013ed4:	mov    %rbx,-0x180(%rbp)
 1013edb:	movl   $0x2,-0x178(%rbp)
 1013ee5:	movl   $0x1,-0x130(%rbp)
 1013eef:	mov    -0xf8(%rbp),%rax
 1013ef6:	mov    %rax,-0x120(%rbp)
 1013efd:	lea    0x1b50c(%rip),%rax        # 102f410 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 1013f04:	mov    %rax,-0x1f0(%rbp)
 1013f0b:	lea    -0x120(%rbp),%rax
 1013f12:	mov    %rax,-0x1e8(%rbp)
 1013f19:	mov    %r14,-0x1e0(%rbp)
 1013f20:	movl   $0x2,-0x1d8(%rbp)
 1013f2a:	movl   $0x0,-0x130(%rbp)
 1013f34:	movl   $0x1,-0x148(%rbp)
 1013f3e:	lea    -0x120(%rbp),%rax
 1013f45:	mov    %rax,-0xd8(%rbp)
 1013f4c:	mov    -0xe0(%rbp),%rdx
 1013f53:	mov    %rdx,-0xd0(%rbp)
 1013f5a:	movabs $0x8000000000000001,%rax
 1013f64:	cmp    %rax,%rdx
 1013f67:	jl     1014cab <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x162b>
 1013f6d:	mov    %rdx,%rax
 1013f70:	sub    $0x1,%rax
 1013f74:	mov    %rax,-0xd0(%rbp)
 1013f7b:	mov    0x10(%r12),%rax
 1013f80:	mov    %rax,-0xc8(%rbp)
 1013f87:	lea    -0x120(%rbp),%rax
 1013f8e:	mov    %rax,-0xc0(%rbp)
 1013f95:	lea    0x1b474(%rip),%rax        # 102f410 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 1013f9c:	mov    %rax,-0xb8(%rbp)
 1013fa3:	lea    -0xc8(%rbp),%rax
 1013faa:	mov    %rax,0x10(%r12)
 1013faf:	mov    -0xd0(%rbp),%rsi
 1013fb6:	mov    %rdi,%r14
 1013fb9:	call   1013680 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531>
 1013fbe:	mov    %r14,%rdi
 1013fc1:	mov    %rdx,%rcx
 1013fc4:	mov    %rax,%rdx
 1013fc7:	mov    -0x28(%rbp),%rax
 1013fcb:	mov    %rdx,-0x250(%rbp)
 1013fd2:	mov    %rcx,-0x248(%rbp)
 1013fd9:	lea    -0x250(%rbp),%rcx
 1013fe0:	mov    %rcx,-0xd0(%rbp)
 1013fe7:	mov    %r15,0x10(%r12)
 1013fec:	mov    -0xd0(%rbp),%rcx
 1013ff3:	mov    (%rcx),%rdx
 1013ff6:	mov    %rdx,-0xf8(%rbp)
 1013ffd:	mov    0x8(%rcx),%rcx
 1014001:	mov    %rcx,-0xf0(%rbp)
 1014008:	lea    0x1b471(%rip),%rcx        # 102f480 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 101400f:	mov    %rcx,-0x190(%rbp)
 1014016:	lea    -0xf8(%rbp),%rcx
 101401d:	mov    %rcx,-0x188(%rbp)
 1014024:	mov    %rbx,-0x180(%rbp)
 101402b:	movl   $0x2,-0x178(%rbp)
 1014035:	movl   $0x1,-0x130(%rbp)
 101403f:	mov    -0xf8(%rbp),%rcx
 1014046:	mov    %rcx,-0x110(%rbp)
 101404d:	mov    -0xf0(%rbp),%rcx
 1014054:	mov    %rcx,-0x108(%rbp)
 101405b:	lea    0x1b41e(%rip),%rcx        # 102f480 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 1014062:	mov    %rcx,-0x1d0(%rbp)
 1014069:	lea    -0x110(%rbp),%rcx
 1014070:	mov    %rcx,-0x1c8(%rbp)
 1014077:	mov    %rax,-0x1c0(%rbp)
 101407e:	movl   $0x2,-0x1b8(%rbp)
 1014088:	movl   $0x0,-0x130(%rbp)
 1014092:	movl   $0x1,-0x140(%rbp)
 101409c:	lea    -0x110(%rbp),%rax
 10140a3:	mov    %rax,-0xd0(%rbp)
 10140aa:	mov    0x10(%r12),%rcx
 10140af:	mov    -0xd8(%rbp),%rax
 10140b6:	mov    %rcx,-0xc8(%rbp)
 10140bd:	mov    %rax,-0xc0(%rbp)
 10140c4:	lea    0x1b345(%rip),%rax        # 102f410 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 10140cb:	mov    %rax,-0xb8(%rbp)
 10140d2:	lea    -0xc8(%rbp),%rax
 10140d9:	mov    %rax,0x10(%r12)
 10140de:	mov    -0xd0(%rbp),%rax
 10140e5:	lea    -0xc8(%rbp),%rcx
 10140ec:	mov    %rcx,-0xa8(%rbp)
 10140f3:	mov    %rax,-0xa0(%rbp)
 10140fa:	lea    0x1b37f(%rip),%rax        # 102f480 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 1014101:	mov    %rax,-0x98(%rbp)
 1014108:	lea    -0xa8(%rbp),%rax
 101410f:	mov    %rax,0x10(%r12)
 1014114:	mov    $0x1,%edx
 1014119:	lea    0x1b050(%rip),%rsi        # 102f170 <myl_t_1e414bd82e4b50b54939760a2d591f88da97e2f1c8252dbd7dcbc73438e46afb_body>
 1014120:	mov    %rdi,%r14
 1014123:	mov    %r12,%rdi
 1014126:	call   101ff00 <myl_native_heap_alloc>
 101412b:	mov    %r14,%rdi
 101412e:	mov    %rax,%rcx
 1014131:	mov    %rcx,-0x20(%rbp)
 1014135:	cmp    $0x0,%ecx
 1014138:	jne    1014141 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xac1>
 101413a:	call   101b580 <myl_qbe_fail_allocation>
 101413f:	ud2
 1014141:	mov    %rcx,-0xe8(%rbp)
 1014148:	lea    0x1b091(%rip),%rax        # 102f1e0 <myl_t_1e414bd82e4b50b54939760a2d591f88da97e2f1c8252dbd7dcbc73438e46afb>
 101414f:	mov    %rax,-0x170(%rbp)
 1014156:	lea    -0xe8(%rbp),%rax
 101415d:	mov    %rax,-0x168(%rbp)
 1014164:	mov    %r13,-0x160(%rbp)
 101416b:	movl   $0x2,-0x158(%rbp)
 1014175:	movl   $0x4,-0x158(%rbp)
 101417f:	movl   $0x1,-0x128(%rbp)
 1014189:	mov    %rdi,%r14
 101418c:	call   101db60 <myl_qbe_region_mark>
 1014191:	mov    %r14,%rdi
 1014194:	mov    -0xd0(%rbp),%r15
 101419b:	mov    %rdi,%r14
 101419e:	call   101db60 <myl_qbe_region_mark>
 10141a3:	mov    %r15,%rcx
 10141a6:	mov    %r14,%rdi
 10141a9:	mov    %rax,%r8
 10141ac:	mov    -0x18(%rbp),%r14
 10141b0:	lea    -0xf8(%rbp),%rax
 10141b7:	neg    %rax
 10141ba:	add    %rcx,%rax
 10141bd:	lea    -0xf8(%rbp),%rdx
 10141c4:	sub    %rcx,%rdx
 10141c7:	cmp    $0x10,%rax
 10141cb:	setb   %al
 10141ce:	movzbl %al,%eax
 10141d1:	cmp    $0x10,%rdx
 10141d5:	setb   %dl
 10141d8:	movzbl %dl,%edx
 10141db:	or     %edx,%eax
 10141dd:	jne    1014269 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xbe9>
 10141e3:	mov    (%rcx),%rax
 10141e6:	cmp    $0x0,%rax
 10141ea:	je     1014206 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xb86>
 10141ec:	sub    $0x10,%rax
 10141f0:	mov    (%rax),%rax
 10141f3:	movabs $0x5000000000000001,%rdx
 10141fd:	and    %rdx,%rax
 1014200:	cmp    $0x0,%rax
 1014204:	jne    1014269 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xbe9>
 1014206:	mov    0x8(%rcx),%rax
 101420a:	cmp    $0x0,%rax
 101420e:	je     101422a <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xbaa>
 1014210:	sub    $0x10,%rax
 1014214:	mov    (%rax),%rax
 1014217:	movabs $0x5000000000000001,%rdx
 1014221:	and    %rdx,%rax
 1014224:	cmp    $0x0,%rax
 1014228:	jne    1014269 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xbe9>
 101422a:	mov    (%rcx),%rax
 101422d:	mov    %rax,-0xf8(%rbp)
 1014234:	mov    0x8(%rcx),%rax
 1014238:	mov    %rax,-0xf0(%rbp)
 101423f:	mov    $0x10,%edx
 1014244:	mov    $0x0,%esi
 1014249:	mov    %rdi,%r15
 101424c:	mov    %rcx,%rdi
 101424f:	call   102aee0 <compiler_rt.fastMemset>
 1014254:	mov    %r15,%rdi
 1014257:	mov    -0x20(%rbp),%rcx
 101425b:	mov    -0x30(%rbp),%r15
 101425f:	mov    -0x28(%rbp),%rax
 1014263:	mov    -0x40(%rbp),%rsi
 1014267:	jmp    10142bf <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xc3f>
 1014269:	lea    -0xf8(%rbp),%rdx
 1014270:	lea    0x1b209(%rip),%rsi        # 102f480 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 1014277:	mov    %rdi,%r15
 101427a:	mov    %r12,%rdi
 101427d:	call   102ab40 <myl_rc_native_take>
 1014282:	mov    %r15,%rdi
 1014285:	mov    %eax,%edx
 1014287:	mov    -0x20(%rbp),%rcx
 101428b:	mov    -0x30(%rbp),%r15
 101428f:	mov    -0x28(%rbp),%rax
 1014293:	mov    -0x40(%rbp),%rsi
 1014297:	cmp    $0x0,%edx
 101429a:	jne    10142bf <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xc3f>
 101429c:	mov    %rdi,%rbx
 101429f:	mov    %r12,%rdi
 10142a2:	call   1023700 <myl_rc_take_failure>
 10142a7:	mov    %rbx,%rdi
 10142aa:	mov    %eax,%esi
 10142ac:	mov    %rdi,%rbx
 10142af:	call   101ae60 <myl_qbe_rc_status>
 10142b4:	mov    %rbx,%rdi
 10142b7:	mov    %r15,%rbx
 10142ba:	jmp    10154dd <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1e5d>
 10142bf:	movl   $0x0,-0x140(%rbp)
 10142c9:	lea    0x1b1b0(%rip),%rdx        # 102f480 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 10142d0:	mov    %rdx,-0x190(%rbp)
 10142d7:	lea    -0xf8(%rbp),%rdx
 10142de:	mov    %rdx,-0x188(%rbp)
 10142e5:	mov    %rbx,-0x180(%rbp)
 10142ec:	movl   $0x2,-0x178(%rbp)
 10142f6:	movl   $0x1,-0x130(%rbp)
 1014300:	mov    -0xf8(%rbp),%rdx
 1014307:	mov    %rdx,(%rcx)
 101430a:	mov    -0xf0(%rbp),%rdx
 1014311:	mov    %rdx,0x8(%rcx)
 1014315:	movl   $0x0,-0x130(%rbp)
 101431f:	mov    %rcx,-0xd0(%rbp)
 1014326:	movl   $0x0,-0x128(%rbp)
 1014330:	mov    -0xd0(%rbp),%rcx
 1014337:	mov    %rcx,-0xf8(%rbp)
 101433e:	lea    0x1ae9b(%rip),%rcx        # 102f1e0 <myl_t_1e414bd82e4b50b54939760a2d591f88da97e2f1c8252dbd7dcbc73438e46afb>
 1014345:	mov    %rcx,-0x190(%rbp)
 101434c:	lea    -0xf8(%rbp),%rcx
 1014353:	mov    %rcx,-0x188(%rbp)
 101435a:	mov    %rbx,-0x180(%rbp)
 1014361:	movl   $0x2,-0x178(%rbp)
 101436b:	movl   $0x1,-0x130(%rbp)
 1014375:	mov    -0x140(%rbp),%ecx
 101437b:	cmp    $0x0,%ecx
 101437e:	je     1014393 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xd13>
 1014380:	mov    %rdi,%r15
 1014383:	call   101b030 <myl_qbe_rc_slot_drop>
 1014388:	mov    %r15,%rdi
 101438b:	mov    -0x30(%rbp),%r15
 101438f:	mov    -0x28(%rbp),%rax
 1014393:	mov    -0xf8(%rbp),%rcx
 101439a:	mov    %rcx,-0x110(%rbp)
 10143a1:	lea    0x1ae38(%rip),%rcx        # 102f1e0 <myl_t_1e414bd82e4b50b54939760a2d591f88da97e2f1c8252dbd7dcbc73438e46afb>
 10143a8:	mov    %rcx,-0x1d0(%rbp)
 10143af:	lea    -0x110(%rbp),%rcx
 10143b6:	mov    %rcx,-0x1c8(%rbp)
 10143bd:	mov    %rax,-0x1c0(%rbp)
 10143c4:	movl   $0x2,-0x1b8(%rbp)
 10143ce:	movl   $0x0,-0x130(%rbp)
 10143d8:	movl   $0x1,-0x140(%rbp)
 10143e2:	mov    -0x110(%rbp),%rax
 10143e9:	mov    %rax,-0xd0(%rbp)
 10143f0:	mov    %r15,0x10(%r12)
 10143f5:	mov    $0x8,%edx
 10143fa:	mov    $0x0,%esi
 10143ff:	mov    %rdi,%r15
 1014402:	lea    -0x60(%rbp),%rdi
 1014406:	call   102aee0 <compiler_rt.fastMemset>
 101440b:	mov    %r15,%rdi
 101440e:	lea    0x1affb(%rip),%rax        # 102f410 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 1014415:	mov    %rax,-0x170(%rbp)
 101441c:	lea    -0x60(%rbp),%rax
 1014420:	mov    %rax,-0x168(%rbp)
 1014427:	mov    %r13,-0x160(%rbp)
 101442e:	movl   $0x2,-0x158(%rbp)
 1014438:	movl   $0x1,-0x128(%rbp)
 1014442:	mov    %rdi,%r15
 1014445:	call   101db60 <myl_qbe_region_mark>
 101444a:	mov    %r15,%rdi
 101444d:	mov    %rdi,%r15
 1014450:	call   101db60 <myl_qbe_region_mark>
 1014455:	mov    %r15,%rdi
 1014458:	mov    %rax,%r8
 101445b:	lea    -0xf8(%rbp),%rcx
 1014462:	lea    -0xd0(%rbp),%rax
 1014469:	sub    %rcx,%rax
 101446c:	lea    -0xd0(%rbp),%rdx
 1014473:	lea    -0xf8(%rbp),%rcx
 101447a:	sub    %rdx,%rcx
 101447d:	cmp    $0x8,%rax
 1014481:	setb   %al
 1014484:	movzbl %al,%eax
 1014487:	cmp    $0x8,%rcx
 101448b:	setb   %cl
 101448e:	movzbl %cl,%ecx
 1014491:	or     %ecx,%eax
 1014493:	jne    10144ec <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xe6c>
 1014495:	mov    -0xd0(%rbp),%rax
 101449c:	cmp    $0x0,%rax
 10144a0:	je     10144bc <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xe3c>
 10144a2:	sub    $0x10,%rax
 10144a6:	mov    (%rax),%rax
 10144a9:	movabs $0x5000000000000001,%rcx
 10144b3:	and    %rcx,%rax
 10144b6:	cmp    $0x0,%rax
 10144ba:	jne    10144ec <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xe6c>
 10144bc:	mov    -0xd0(%rbp),%rax
 10144c3:	mov    %rax,-0xf8(%rbp)
 10144ca:	mov    $0x8,%edx
 10144cf:	mov    $0x0,%esi
 10144d4:	mov    %rdi,%r15
 10144d7:	lea    -0xd0(%rbp),%rdi
 10144de:	call   102aee0 <compiler_rt.fastMemset>
 10144e3:	mov    %r15,%rdi
 10144e6:	mov    -0x28(%rbp),%rax
 10144ea:	jmp    1014544 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xec4>
 10144ec:	lea    -0xd0(%rbp),%rcx
 10144f3:	lea    -0xf8(%rbp),%rdx
 10144fa:	lea    0x1acdf(%rip),%rsi        # 102f1e0 <myl_t_1e414bd82e4b50b54939760a2d591f88da97e2f1c8252dbd7dcbc73438e46afb>
 1014501:	mov    %rdi,%r15
 1014504:	mov    %r12,%rdi
 1014507:	call   102ab40 <myl_rc_native_take>
 101450c:	mov    %r15,%rdi
 101450f:	mov    %eax,%ecx
 1014511:	mov    -0x30(%rbp),%r15
 1014515:	mov    -0x28(%rbp),%rax
 1014519:	cmp    $0x0,%ecx
 101451c:	jne    1014544 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xec4>
 101451e:	mov    %r15,%r13
 1014521:	mov    %rdi,%rbx
 1014524:	mov    %r12,%rdi
 1014527:	call   1023700 <myl_rc_take_failure>
 101452c:	mov    %rbx,%rdi
 101452f:	mov    %eax,%esi
 1014531:	mov    %rdi,%rbx
 1014534:	call   101ae60 <myl_qbe_rc_status>
 1014539:	mov    %rbx,%rdi
 101453c:	mov    %r13,%rbx
 101453f:	jmp    10154dd <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1e5d>
 1014544:	movl   $0x0,-0x140(%rbp)
 101454e:	lea    0x1ac8b(%rip),%rcx        # 102f1e0 <myl_t_1e414bd82e4b50b54939760a2d591f88da97e2f1c8252dbd7dcbc73438e46afb>
 1014555:	mov    %rcx,-0x190(%rbp)
 101455c:	lea    -0xf8(%rbp),%rcx
 1014563:	mov    %rcx,-0x188(%rbp)
 101456a:	mov    %rbx,-0x180(%rbp)
 1014571:	movl   $0x2,-0x178(%rbp)
 101457b:	movl   $0x1,-0x130(%rbp)
 1014585:	mov    -0xf8(%rbp),%rcx
 101458c:	mov    %rcx,-0x60(%rbp)
 1014590:	movl   $0x0,-0x130(%rbp)
 101459a:	lea    -0x60(%rbp),%rcx
 101459e:	mov    %rcx,-0xd0(%rbp)
 10145a5:	movl   $0x0,-0x128(%rbp)
 10145af:	mov    -0x60(%rbp),%rcx
 10145b3:	mov    %rcx,-0xf8(%rbp)
 10145ba:	lea    0x1ae4f(%rip),%rcx        # 102f410 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 10145c1:	mov    %rcx,-0x190(%rbp)
 10145c8:	lea    -0xf8(%rbp),%rcx
 10145cf:	mov    %rcx,-0x188(%rbp)
 10145d6:	mov    %rbx,-0x180(%rbp)
 10145dd:	movl   $0x2,-0x178(%rbp)
 10145e7:	movl   $0x1,-0x130(%rbp)
 10145f1:	mov    -0xf8(%rbp),%rcx
 10145f8:	mov    %rcx,-0x110(%rbp)
 10145ff:	lea    0x1ae0a(%rip),%rcx        # 102f410 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 1014606:	mov    %rcx,-0x1d0(%rbp)
 101460d:	lea    -0x110(%rbp),%rcx
 1014614:	mov    %rcx,-0x1c8(%rbp)
 101461b:	mov    %rax,-0x1c0(%rbp)
 1014622:	movl   $0x2,-0x1b8(%rbp)
 101462c:	movl   $0x0,-0x130(%rbp)
 1014636:	movl   $0x1,-0x140(%rbp)
 1014640:	lea    -0x110(%rbp),%rax
 1014647:	mov    %rax,-0xd0(%rbp)
 101464e:	mov    0x10(%r12),%rcx
 1014653:	mov    -0xd8(%rbp),%rax
 101465a:	mov    %rcx,-0xc8(%rbp)
 1014661:	mov    %rax,-0xc0(%rbp)
 1014668:	lea    0x1ada1(%rip),%rax        # 102f410 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 101466f:	mov    %rax,-0xb8(%rbp)
 1014676:	lea    -0xc8(%rbp),%rax
 101467d:	mov    %rax,0x10(%r12)
 1014682:	mov    -0xd0(%rbp),%rax
 1014689:	lea    -0xc8(%rbp),%rcx
 1014690:	mov    %rcx,-0xa8(%rbp)
 1014697:	mov    %rax,-0xa0(%rbp)
 101469e:	lea    0x1ad6b(%rip),%rax        # 102f410 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 10146a5:	mov    %rax,-0x98(%rbp)
 10146ac:	lea    -0xa8(%rbp),%rax
 10146b3:	mov    %rax,0x10(%r12)
 10146b8:	mov    $0x10,%edx
 10146bd:	mov    $0x0,%esi
 10146c2:	mov    %rdi,%r15
 10146c5:	lea    -0x58(%rbp),%rdi
 10146c9:	call   102aee0 <compiler_rt.fastMemset>
 10146ce:	mov    %r15,%rdi
 10146d1:	lea    0x1ada8(%rip),%rax        # 102f480 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 10146d8:	mov    %rax,-0x170(%rbp)
 10146df:	lea    -0x58(%rbp),%rax
 10146e3:	mov    %rax,-0x168(%rbp)
 10146ea:	mov    %r13,-0x160(%rbp)
 10146f1:	movl   $0x2,-0x158(%rbp)
 10146fb:	movl   $0x1,-0x128(%rbp)
 1014705:	mov    %rdi,%r13
 1014708:	call   101db60 <myl_qbe_region_mark>
 101470d:	mov    %r13,%rdi
 1014710:	mov    -0xd8(%rbp),%r15
 1014717:	mov    -0x148(%rbp),%eax
 101471d:	cmp    $0x0,%eax
 1014720:	jne    10147be <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x113e>
 1014726:	mov    %rdi,%r13
 1014729:	call   101db60 <myl_qbe_region_mark>
 101472e:	mov    %r15,%rcx
 1014731:	mov    %r13,%rdi
 1014734:	mov    %rax,%r8
 1014737:	mov    -0x30(%rbp),%r13
 101473b:	mov    %rcx,%r15
 101473e:	lea    -0xf8(%rbp),%rdx
 1014745:	lea    0x1acc4(%rip),%rsi        # 102f410 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 101474c:	mov    %rdi,%r15
 101474f:	mov    %r12,%rdi
 1014752:	call   102a6a0 <myl_rc_native_copy>
 1014757:	mov    %r15,%rdi
 101475a:	cmp    $0x0,%eax
 101475d:	jne    1014782 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1102>
 101475f:	mov    %rdi,%rbx
 1014762:	mov    %r12,%rdi
 1014765:	call   1023700 <myl_rc_take_failure>
 101476a:	mov    %rbx,%rdi
 101476d:	mov    %eax,%esi
 101476f:	mov    %rdi,%rbx
 1014772:	call   101ae60 <myl_qbe_rc_status>
 1014777:	mov    %rbx,%rdi
 101477a:	mov    %r13,%rbx
 101477d:	jmp    10154dd <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1e5d>
 1014782:	lea    0x1ac87(%rip),%rax        # 102f410 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 1014789:	mov    %rax,-0x190(%rbp)
 1014790:	lea    -0xf8(%rbp),%rax
 1014797:	mov    %rax,-0x188(%rbp)
 101479e:	mov    %rbx,-0x180(%rbp)
 10147a5:	movl   $0x2,-0x178(%rbp)
 10147af:	movl   $0x1,-0x130(%rbp)
 10147b9:	jmp    10148ce <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x124e>
 10147be:	mov    %rdi,%r13
 10147c1:	call   101db60 <myl_qbe_region_mark>
 10147c6:	mov    %r15,%rcx
 10147c9:	mov    %r13,%rdi
 10147cc:	mov    %rax,%r8
 10147cf:	mov    -0x30(%rbp),%r13
 10147d3:	lea    -0xf8(%rbp),%rax
 10147da:	neg    %rax
 10147dd:	add    %rcx,%rax
 10147e0:	lea    -0xf8(%rbp),%rdx
 10147e7:	sub    %rcx,%rdx
 10147ea:	cmp    $0x8,%rax
 10147ee:	setb   %al
 10147f1:	movzbl %al,%eax
 10147f4:	cmp    $0x8,%rdx
 10147f8:	setb   %dl
 10147fb:	movzbl %dl,%edx
 10147fe:	or     %edx,%eax
 1014800:	jne    1014849 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x11c9>
 1014802:	mov    (%rcx),%rax
 1014805:	cmp    $0x0,%rax
 1014809:	je     1014825 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x11a5>
 101480b:	sub    $0x10,%rax
 101480f:	mov    (%rax),%rax
 1014812:	movabs $0x5000000000000001,%rdx
 101481c:	and    %rdx,%rax
 101481f:	cmp    $0x0,%rax
 1014823:	jne    1014849 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x11c9>
 1014825:	mov    (%rcx),%rax
 1014828:	mov    %rax,-0xf8(%rbp)
 101482f:	mov    $0x8,%edx
 1014834:	mov    $0x0,%esi
 1014839:	mov    %rdi,%r13
 101483c:	mov    %rcx,%rdi
 101483f:	call   102aee0 <compiler_rt.fastMemset>
 1014844:	mov    %r13,%rdi
 1014847:	jmp    101488d <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x120d>
 1014849:	lea    -0xf8(%rbp),%rdx
 1014850:	lea    0x1abb9(%rip),%rsi        # 102f410 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 1014857:	mov    %rdi,%r15
 101485a:	mov    %r12,%rdi
 101485d:	call   102ab40 <myl_rc_native_take>
 1014862:	mov    %r15,%rdi
 1014865:	cmp    $0x0,%eax
 1014868:	jne    101488d <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x120d>
 101486a:	mov    %rdi,%rbx
 101486d:	mov    %r12,%rdi
 1014870:	call   1023700 <myl_rc_take_failure>
 1014875:	mov    %rbx,%rdi
 1014878:	mov    %eax,%esi
 101487a:	mov    %rdi,%rbx
 101487d:	call   101ae60 <myl_qbe_rc_status>
 1014882:	mov    %rbx,%rdi
 1014885:	mov    %r13,%rbx
 1014888:	jmp    10154dd <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1e5d>
 101488d:	movl   $0x0,-0x148(%rbp)
 1014897:	lea    0x1ab72(%rip),%rax        # 102f410 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 101489e:	mov    %rax,-0x190(%rbp)
 10148a5:	lea    -0xf8(%rbp),%rax
 10148ac:	mov    %rax,-0x188(%rbp)
 10148b3:	mov    %rbx,-0x180(%rbp)
 10148ba:	movl   $0x2,-0x178(%rbp)
 10148c4:	movl   $0x1,-0x130(%rbp)
 10148ce:	mov    -0xf8(%rbp),%rax
 10148d5:	mov    %rax,-0x58(%rbp)
 10148d9:	movl   $0x0,-0x130(%rbp)
 10148e3:	mov    -0xd0(%rbp),%r15
 10148ea:	mov    %rdi,%r13
 10148ed:	call   101db60 <myl_qbe_region_mark>
 10148f2:	mov    %r15,%rcx
 10148f5:	mov    %r13,%rdi
 10148f8:	mov    %rax,%r8
 10148fb:	mov    -0x30(%rbp),%r13
 10148ff:	lea    -0xf8(%rbp),%rax
 1014906:	neg    %rax
 1014909:	add    %rcx,%rax
 101490c:	lea    -0xf8(%rbp),%rdx
 1014913:	sub    %rcx,%rdx
 1014916:	cmp    $0x8,%rax
 101491a:	setb   %al
 101491d:	movzbl %al,%eax
 1014920:	cmp    $0x8,%rdx
 1014924:	setb   %dl
 1014927:	movzbl %dl,%edx
 101492a:	or     %edx,%eax
 101492c:	jne    1014980 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1300>
 101492e:	mov    (%rcx),%rax
 1014931:	cmp    $0x0,%rax
 1014935:	je     1014951 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x12d1>
 1014937:	sub    $0x10,%rax
 101493b:	mov    (%rax),%rax
 101493e:	movabs $0x5000000000000001,%rdx
 1014948:	and    %rdx,%rax
 101494b:	cmp    $0x0,%rax
 101494f:	jne    1014980 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1300>
 1014951:	mov    (%rcx),%rax
 1014954:	mov    %rax,-0xf8(%rbp)
 101495b:	mov    $0x8,%edx
 1014960:	mov    $0x0,%esi
 1014965:	mov    %rdi,%r15
 1014968:	mov    %rcx,%rdi
 101496b:	call   102aee0 <compiler_rt.fastMemset>
 1014970:	mov    %r15,%rdi
 1014973:	mov    -0x40(%rbp),%rsi
 1014977:	mov    %rsi,%rax
 101497a:	mov    -0x38(%rbp),%rsi
 101497e:	jmp    10149d1 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1351>
 1014980:	lea    -0xf8(%rbp),%rdx
 1014987:	lea    0x1aa82(%rip),%rsi        # 102f410 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 101498e:	mov    %rdi,%r15
 1014991:	mov    %r12,%rdi
 1014994:	call   102ab40 <myl_rc_native_take>
 1014999:	mov    %r15,%rdi
 101499c:	mov    %eax,%ecx
 101499e:	mov    -0x40(%rbp),%rsi
 10149a2:	mov    %rsi,%rax
 10149a5:	mov    -0x38(%rbp),%rsi
 10149a9:	cmp    $0x0,%ecx
 10149ac:	jne    10149d1 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1351>
 10149ae:	mov    %rdi,%rbx
 10149b1:	mov    %r12,%rdi
 10149b4:	call   1023700 <myl_rc_take_failure>
 10149b9:	mov    %rbx,%rdi
 10149bc:	mov    %eax,%esi
 10149be:	mov    %rdi,%rbx
 10149c1:	call   101ae60 <myl_qbe_rc_status>
 10149c6:	mov    %rbx,%rdi
 10149c9:	mov    %r13,%rbx
 10149cc:	jmp    10154dd <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1e5d>
 10149d1:	movl   $0x0,-0x140(%rbp)
 10149db:	lea    0x1aa2e(%rip),%rcx        # 102f410 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 10149e2:	mov    %rcx,-0x190(%rbp)
 10149e9:	lea    -0xf8(%rbp),%rcx
 10149f0:	mov    %rcx,-0x188(%rbp)
 10149f7:	mov    %rbx,-0x180(%rbp)
 10149fe:	movl   $0x2,-0x178(%rbp)
 1014a08:	movl   $0x1,-0x130(%rbp)
 1014a12:	mov    -0xf8(%rbp),%rcx
 1014a19:	mov    %rcx,-0x50(%rbp)
 1014a1d:	movl   $0x0,-0x130(%rbp)
 1014a27:	lea    -0x58(%rbp),%rcx
 1014a2b:	mov    %rcx,-0xd8(%rbp)
 1014a32:	movl   $0x0,-0x128(%rbp)
 1014a3c:	mov    -0x58(%rbp),%rcx
 1014a40:	mov    %rcx,-0xf8(%rbp)
 1014a47:	mov    -0x50(%rbp),%rcx
 1014a4b:	mov    %rcx,-0xf0(%rbp)
 1014a52:	lea    0x1aa27(%rip),%rcx        # 102f480 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 1014a59:	mov    %rcx,-0x190(%rbp)
 1014a60:	lea    -0xf8(%rbp),%rcx
 1014a67:	mov    %rcx,-0x188(%rbp)
 1014a6e:	mov    %rbx,-0x180(%rbp)
 1014a75:	movl   $0x2,-0x178(%rbp)
 1014a7f:	movl   $0x1,-0x130(%rbp)
 1014a89:	mov    -0x148(%rbp),%ecx
 1014a8f:	cmp    $0x0,%ecx
 1014a92:	jne    1014a99 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1419>
 1014a94:	mov    %rax,%rsi
 1014a97:	jmp    1014aa8 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1428>
 1014a99:	mov    %rdi,%r15
 1014a9c:	call   101b030 <myl_qbe_rc_slot_drop>
 1014aa1:	mov    %r15,%rdi
 1014aa4:	mov    -0x40(%rbp),%rsi
 1014aa8:	mov    -0x140(%rbp),%eax
 1014aae:	cmp    $0x0,%eax
 1014ab1:	je     1014abe <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x143e>
 1014ab3:	mov    %rdi,%r15
 1014ab6:	call   101b030 <myl_qbe_rc_slot_drop>
 1014abb:	mov    %r15,%rdi
 1014abe:	mov    -0xf8(%rbp),%rax
 1014ac5:	mov    %rax,-0x120(%rbp)
 1014acc:	mov    -0xf0(%rbp),%rax
 1014ad3:	mov    %rax,-0x118(%rbp)
 1014ada:	lea    0x1a99f(%rip),%rax        # 102f480 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 1014ae1:	mov    %rax,-0x1f0(%rbp)
 1014ae8:	lea    -0x120(%rbp),%rax
 1014aef:	mov    %rax,-0x1e8(%rbp)
 1014af6:	mov    %r14,-0x1e0(%rbp)
 1014afd:	movl   $0x2,-0x1d8(%rbp)
 1014b07:	movl   $0x0,-0x130(%rbp)
 1014b11:	movl   $0x1,-0x148(%rbp)
 1014b1b:	lea    -0x120(%rbp),%rax
 1014b22:	mov    %rax,-0xd8(%rbp)
 1014b29:	mov    %r13,0x10(%r12)
 1014b2e:	mov    -0xd8(%rbp),%r15
 1014b35:	mov    %rdi,%r14
 1014b38:	call   101db60 <myl_qbe_region_mark>
 1014b3d:	mov    %r15,%rcx
 1014b40:	mov    %r14,%rdi
 1014b43:	mov    %rax,%r8
 1014b46:	lea    -0xf8(%rbp),%rax
 1014b4d:	neg    %rax
 1014b50:	add    %rcx,%rax
 1014b53:	lea    -0xf8(%rbp),%rdx
 1014b5a:	sub    %rcx,%rdx
 1014b5d:	cmp    $0x10,%rax
 1014b61:	setb   %al
 1014b64:	movzbl %al,%eax
 1014b67:	cmp    $0x10,%rdx
 1014b6b:	setb   %dl
 1014b6e:	movzbl %dl,%edx
 1014b71:	or     %edx,%eax
 1014b73:	jne    1014beb <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x156b>
 1014b75:	mov    (%rcx),%rax
 1014b78:	cmp    $0x0,%rax
 1014b7c:	je     1014b98 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1518>
 1014b7e:	sub    $0x10,%rax
 1014b82:	mov    (%rax),%rax
 1014b85:	movabs $0x5000000000000001,%rdx
 1014b8f:	and    %rdx,%rax
 1014b92:	cmp    $0x0,%rax
 1014b96:	jne    1014beb <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x156b>
 1014b98:	mov    0x8(%rcx),%rax
 1014b9c:	cmp    $0x0,%rax
 1014ba0:	je     1014bbc <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x153c>
 1014ba2:	sub    $0x10,%rax
 1014ba6:	mov    (%rax),%rax
 1014ba9:	movabs $0x5000000000000001,%rdx
 1014bb3:	and    %rdx,%rax
 1014bb6:	cmp    $0x0,%rax
 1014bba:	jne    1014beb <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x156b>
 1014bbc:	mov    (%rcx),%rax
 1014bbf:	mov    %rax,-0xf8(%rbp)
 1014bc6:	mov    0x8(%rcx),%rax
 1014bca:	mov    %rax,-0xf0(%rbp)
 1014bd1:	mov    $0x10,%edx
 1014bd6:	mov    $0x0,%esi
 1014bdb:	mov    %rdi,%r12
 1014bde:	mov    %rcx,%rdi
 1014be1:	call   102aee0 <compiler_rt.fastMemset>
 1014be6:	mov    %r12,%rdi
 1014be9:	jmp    1014c2f <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x15af>
 1014beb:	lea    -0xf8(%rbp),%rdx
 1014bf2:	lea    0x1a887(%rip),%rsi        # 102f480 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 1014bf9:	mov    %rdi,%r14
 1014bfc:	mov    %r12,%rdi
 1014bff:	call   102ab40 <myl_rc_native_take>
 1014c04:	mov    %r14,%rdi
 1014c07:	cmp    $0x0,%eax
 1014c0a:	jne    1014c2f <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x15af>
 1014c0c:	mov    %rdi,%rbx
 1014c0f:	mov    %r12,%rdi
 1014c12:	call   1023700 <myl_rc_take_failure>
 1014c17:	mov    %rbx,%rdi
 1014c1a:	mov    %eax,%esi
 1014c1c:	mov    %rdi,%rbx
 1014c1f:	call   101ae60 <myl_qbe_rc_status>
 1014c24:	mov    %rbx,%rdi
 1014c27:	mov    %r13,%rbx
 1014c2a:	jmp    10154dd <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1e5d>
 1014c2f:	movl   $0x0,-0x148(%rbp)
 1014c39:	lea    0x1a840(%rip),%rax        # 102f480 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 1014c40:	mov    %rax,-0x190(%rbp)
 1014c47:	lea    -0xf8(%rbp),%rax
 1014c4e:	mov    %rax,-0x188(%rbp)
 1014c55:	mov    %rbx,-0x180(%rbp)
 1014c5c:	movl   $0x2,-0x178(%rbp)
 1014c66:	movl   $0x1,-0x130(%rbp)
 1014c70:	movl   $0x0,-0x130(%rbp)
 1014c7a:	lea    -0x230(%rbp),%rsi
 1014c81:	mov    %rdi,%rbx
 1014c84:	call   101b140 <myl_qbe_rc_frame_cleanup>
 1014c89:	mov    %rbx,%rdi
 1014c8c:	lea    -0x230(%rbp),%rsi
 1014c93:	call   101afd0 <myl_qbe_rc_frame_leave>
 1014c98:	mov    -0xf8(%rbp),%rax
 1014c9f:	mov    -0xf0(%rbp),%rdx
 1014ca6:	jmp    101559d <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1f1d>
 1014cab:	mov    $0x40,%r8d
 1014cb1:	mov    $0x1,%ecx
 1014cb6:	mov    $0x1,%esi
 1014cbb:	call   101b6e0 <myl_qbe_fail_overflow_op>
 1014cc0:	ud2
 1014cc2:	mov    $0x40,%r8d
 1014cc8:	mov    $0x1,%ecx
 1014ccd:	mov    $0x1,%esi
 1014cd2:	call   101b6e0 <myl_qbe_fail_overflow_op>
 1014cd7:	ud2
 1014cd9:	mov    $0x8,%edx
 1014cde:	mov    $0x0,%esi
 1014ce3:	mov    %rdi,%r15
 1014ce6:	lea    -0x88(%rbp),%rdi
 1014ced:	call   102aee0 <compiler_rt.fastMemset>
 1014cf2:	mov    %r15,%rdi
 1014cf5:	movq   $0x0,-0x88(%rbp)
 1014d00:	lea    0x1a709(%rip),%rax        # 102f410 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 1014d07:	mov    %rax,-0x170(%rbp)
 1014d0e:	lea    -0x88(%rbp),%rax
 1014d15:	mov    %rax,-0x168(%rbp)
 1014d1c:	mov    %r13,-0x160(%rbp)
 1014d23:	movl   $0x2,-0x158(%rbp)
 1014d2d:	movl   $0x1,-0x128(%rbp)
 1014d37:	lea    -0x88(%rbp),%rax
 1014d3e:	mov    %rax,-0xd8(%rbp)
 1014d45:	movl   $0x0,-0x128(%rbp)
 1014d4f:	mov    -0x88(%rbp),%rax
 1014d56:	mov    %rax,-0xf8(%rbp)
 1014d5d:	lea    0x1a6ac(%rip),%rax        # 102f410 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 1014d64:	mov    %rax,-0x190(%rbp)
 1014d6b:	lea    -0xf8(%rbp),%rax
 1014d72:	mov    %rax,-0x188(%rbp)
 1014d79:	mov    %rbx,-0x180(%rbp)
 1014d80:	movl   $0x2,-0x178(%rbp)
 1014d8a:	movl   $0x1,-0x130(%rbp)
 1014d94:	mov    -0xf8(%rbp),%rax
 1014d9b:	mov    %rax,-0x120(%rbp)
 1014da2:	lea    0x1a667(%rip),%rax        # 102f410 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 1014da9:	mov    %rax,-0x1f0(%rbp)
 1014db0:	lea    -0x120(%rbp),%rax
 1014db7:	mov    %rax,-0x1e8(%rbp)
 1014dbe:	mov    %r14,-0x1e0(%rbp)
 1014dc5:	movl   $0x2,-0x1d8(%rbp)
 1014dcf:	movl   $0x0,-0x130(%rbp)
 1014dd9:	movl   $0x1,-0x148(%rbp)
 1014de3:	lea    -0x120(%rbp),%rax
 1014dea:	mov    %rax,-0xd8(%rbp)
 1014df1:	mov    $0x8,%edx
 1014df6:	mov    $0x0,%esi
 1014dfb:	mov    %rdi,%r15
 1014dfe:	lea    -0x80(%rbp),%rdi
 1014e02:	call   102aee0 <compiler_rt.fastMemset>
 1014e07:	mov    %r15,%rdi
 1014e0a:	mov    -0x28(%rbp),%rax
 1014e0e:	movq   $0x0,-0x80(%rbp)
 1014e16:	lea    0x1a5f3(%rip),%rcx        # 102f410 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 1014e1d:	mov    %rcx,-0x170(%rbp)
 1014e24:	lea    -0x80(%rbp),%rcx
 1014e28:	mov    %rcx,-0x168(%rbp)
 1014e2f:	mov    %r13,-0x160(%rbp)
 1014e36:	movl   $0x2,-0x158(%rbp)
 1014e40:	movl   $0x1,-0x128(%rbp)
 1014e4a:	lea    -0x80(%rbp),%rcx
 1014e4e:	mov    %rcx,-0xd0(%rbp)
 1014e55:	movl   $0x0,-0x128(%rbp)
 1014e5f:	mov    -0x80(%rbp),%rcx
 1014e63:	mov    %rcx,-0xf8(%rbp)
 1014e6a:	lea    0x1a59f(%rip),%rcx        # 102f410 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 1014e71:	mov    %rcx,-0x190(%rbp)
 1014e78:	lea    -0xf8(%rbp),%rcx
 1014e7f:	mov    %rcx,-0x188(%rbp)
 1014e86:	mov    %rbx,-0x180(%rbp)
 1014e8d:	movl   $0x2,-0x178(%rbp)
 1014e97:	movl   $0x1,-0x130(%rbp)
 1014ea1:	mov    -0xf8(%rbp),%rcx
 1014ea8:	mov    %rcx,-0x110(%rbp)
 1014eaf:	lea    0x1a55a(%rip),%rcx        # 102f410 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 1014eb6:	mov    %rcx,-0x1d0(%rbp)
 1014ebd:	lea    -0x110(%rbp),%rcx
 1014ec4:	mov    %rcx,-0x1c8(%rbp)
 1014ecb:	mov    %rax,-0x1c0(%rbp)
 1014ed2:	movl   $0x2,-0x1b8(%rbp)
 1014edc:	movl   $0x0,-0x130(%rbp)
 1014ee6:	movl   $0x1,-0x140(%rbp)
 1014ef0:	lea    -0x110(%rbp),%rax
 1014ef7:	mov    %rax,-0xd0(%rbp)
 1014efe:	mov    0x10(%r12),%rcx
 1014f03:	mov    -0xd8(%rbp),%rax
 1014f0a:	mov    %rcx,-0xc8(%rbp)
 1014f11:	mov    %rax,-0xc0(%rbp)
 1014f18:	lea    0x1a4f1(%rip),%rax        # 102f410 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 1014f1f:	mov    %rax,-0xb8(%rbp)
 1014f26:	lea    -0xc8(%rbp),%rax
 1014f2d:	mov    %rax,0x10(%r12)
 1014f32:	mov    -0xd0(%rbp),%rax
 1014f39:	lea    -0xc8(%rbp),%rcx
 1014f40:	mov    %rcx,-0xa8(%rbp)
 1014f47:	mov    %rax,-0xa0(%rbp)
 1014f4e:	lea    0x1a4bb(%rip),%rax        # 102f410 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 1014f55:	mov    %rax,-0x98(%rbp)
 1014f5c:	lea    -0xa8(%rbp),%rax
 1014f63:	mov    %rax,0x10(%r12)
 1014f68:	mov    $0x10,%edx
 1014f6d:	mov    $0x0,%esi
 1014f72:	mov    %rdi,%r15
 1014f75:	lea    -0x78(%rbp),%rdi
 1014f79:	call   102aee0 <compiler_rt.fastMemset>
 1014f7e:	mov    %r15,%rdi
 1014f81:	lea    0x1a4f8(%rip),%rax        # 102f480 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 1014f88:	mov    %rax,-0x170(%rbp)
 1014f8f:	lea    -0x78(%rbp),%rax
 1014f93:	mov    %rax,-0x168(%rbp)
 1014f9a:	mov    %r13,-0x160(%rbp)
 1014fa1:	movl   $0x2,-0x158(%rbp)
 1014fab:	movl   $0x1,-0x128(%rbp)
 1014fb5:	mov    %rdi,%r13
 1014fb8:	call   101db60 <myl_qbe_region_mark>
 1014fbd:	mov    %r13,%rdi
 1014fc0:	mov    -0xd8(%rbp),%r15
 1014fc7:	mov    -0x148(%rbp),%eax
 1014fcd:	cmp    $0x0,%eax
 1014fd0:	jne    101506e <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x19ee>
 1014fd6:	mov    %rdi,%r13
 1014fd9:	call   101db60 <myl_qbe_region_mark>
 1014fde:	mov    %r15,%rcx
 1014fe1:	mov    %r13,%rdi
 1014fe4:	mov    %rax,%r8
 1014fe7:	mov    -0x30(%rbp),%r13
 1014feb:	mov    %rcx,%r15
 1014fee:	lea    -0xf8(%rbp),%rdx
 1014ff5:	lea    0x1a414(%rip),%rsi        # 102f410 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 1014ffc:	mov    %rdi,%r15
 1014fff:	mov    %r12,%rdi
 1015002:	call   102a6a0 <myl_rc_native_copy>
 1015007:	mov    %r15,%rdi
 101500a:	cmp    $0x0,%eax
 101500d:	jne    1015032 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x19b2>
 101500f:	mov    %rdi,%rbx
 1015012:	mov    %r12,%rdi
 1015015:	call   1023700 <myl_rc_take_failure>
 101501a:	mov    %rbx,%rdi
 101501d:	mov    %eax,%esi
 101501f:	mov    %rdi,%rbx
 1015022:	call   101ae60 <myl_qbe_rc_status>
 1015027:	mov    %rbx,%rdi
 101502a:	mov    %r13,%rbx
 101502d:	jmp    10154dd <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1e5d>
 1015032:	lea    0x1a3d7(%rip),%rax        # 102f410 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 1015039:	mov    %rax,-0x190(%rbp)
 1015040:	lea    -0xf8(%rbp),%rax
 1015047:	mov    %rax,-0x188(%rbp)
 101504e:	mov    %rbx,-0x180(%rbp)
 1015055:	movl   $0x2,-0x178(%rbp)
 101505f:	movl   $0x1,-0x130(%rbp)
 1015069:	jmp    101517e <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1afe>
 101506e:	mov    %rdi,%r13
 1015071:	call   101db60 <myl_qbe_region_mark>
 1015076:	mov    %r15,%rcx
 1015079:	mov    %r13,%rdi
 101507c:	mov    %rax,%r8
 101507f:	mov    -0x30(%rbp),%r13
 1015083:	lea    -0xf8(%rbp),%rax
 101508a:	neg    %rax
 101508d:	add    %rcx,%rax
 1015090:	lea    -0xf8(%rbp),%rdx
 1015097:	sub    %rcx,%rdx
 101509a:	cmp    $0x8,%rax
 101509e:	setb   %al
 10150a1:	movzbl %al,%eax
 10150a4:	cmp    $0x8,%rdx
 10150a8:	setb   %dl
 10150ab:	movzbl %dl,%edx
 10150ae:	or     %edx,%eax
 10150b0:	jne    10150f9 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1a79>
 10150b2:	mov    (%rcx),%rax
 10150b5:	cmp    $0x0,%rax
 10150b9:	je     10150d5 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1a55>
 10150bb:	sub    $0x10,%rax
 10150bf:	mov    (%rax),%rax
 10150c2:	movabs $0x5000000000000001,%rdx
 10150cc:	and    %rdx,%rax
 10150cf:	cmp    $0x0,%rax
 10150d3:	jne    10150f9 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1a79>
 10150d5:	mov    (%rcx),%rax
 10150d8:	mov    %rax,-0xf8(%rbp)
 10150df:	mov    $0x8,%edx
 10150e4:	mov    $0x0,%esi
 10150e9:	mov    %rdi,%r13
 10150ec:	mov    %rcx,%rdi
 10150ef:	call   102aee0 <compiler_rt.fastMemset>
 10150f4:	mov    %r13,%rdi
 10150f7:	jmp    101513d <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1abd>
 10150f9:	lea    -0xf8(%rbp),%rdx
 1015100:	lea    0x1a309(%rip),%rsi        # 102f410 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 1015107:	mov    %rdi,%r15
 101510a:	mov    %r12,%rdi
 101510d:	call   102ab40 <myl_rc_native_take>
 1015112:	mov    %r15,%rdi
 1015115:	cmp    $0x0,%eax
 1015118:	jne    101513d <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1abd>
 101511a:	mov    %rdi,%rbx
 101511d:	mov    %r12,%rdi
 1015120:	call   1023700 <myl_rc_take_failure>
 1015125:	mov    %rbx,%rdi
 1015128:	mov    %eax,%esi
 101512a:	mov    %rdi,%rbx
 101512d:	call   101ae60 <myl_qbe_rc_status>
 1015132:	mov    %rbx,%rdi
 1015135:	mov    %r13,%rbx
 1015138:	jmp    10154dd <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1e5d>
 101513d:	movl   $0x0,-0x148(%rbp)
 1015147:	lea    0x1a2c2(%rip),%rax        # 102f410 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 101514e:	mov    %rax,-0x190(%rbp)
 1015155:	lea    -0xf8(%rbp),%rax
 101515c:	mov    %rax,-0x188(%rbp)
 1015163:	mov    %rbx,-0x180(%rbp)
 101516a:	movl   $0x2,-0x178(%rbp)
 1015174:	movl   $0x1,-0x130(%rbp)
 101517e:	mov    -0xf8(%rbp),%rax
 1015185:	mov    %rax,-0x78(%rbp)
 1015189:	movl   $0x0,-0x130(%rbp)
 1015193:	mov    -0xd0(%rbp),%r15
 101519a:	mov    %rdi,%r13
 101519d:	call   101db60 <myl_qbe_region_mark>
 10151a2:	mov    %r15,%rcx
 10151a5:	mov    %r13,%rdi
 10151a8:	mov    %rax,%r8
 10151ab:	mov    -0x30(%rbp),%r13
 10151af:	lea    -0xf8(%rbp),%rax
 10151b6:	neg    %rax
 10151b9:	add    %rcx,%rax
 10151bc:	lea    -0xf8(%rbp),%rdx
 10151c3:	sub    %rcx,%rdx
 10151c6:	cmp    $0x8,%rax
 10151ca:	setb   %al
 10151cd:	movzbl %al,%eax
 10151d0:	cmp    $0x8,%rdx
 10151d4:	setb   %dl
 10151d7:	movzbl %dl,%edx
 10151da:	or     %edx,%eax
 10151dc:	jne    1015230 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1bb0>
 10151de:	mov    (%rcx),%rax
 10151e1:	cmp    $0x0,%rax
 10151e5:	je     1015201 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1b81>
 10151e7:	sub    $0x10,%rax
 10151eb:	mov    (%rax),%rax
 10151ee:	movabs $0x5000000000000001,%rdx
 10151f8:	and    %rdx,%rax
 10151fb:	cmp    $0x0,%rax
 10151ff:	jne    1015230 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1bb0>
 1015201:	mov    (%rcx),%rax
 1015204:	mov    %rax,-0xf8(%rbp)
 101520b:	mov    $0x8,%edx
 1015210:	mov    $0x0,%esi
 1015215:	mov    %rdi,%r15
 1015218:	mov    %rcx,%rdi
 101521b:	call   102aee0 <compiler_rt.fastMemset>
 1015220:	mov    %r15,%rdi
 1015223:	mov    -0x40(%rbp),%rsi
 1015227:	mov    %rsi,%rax
 101522a:	mov    -0x38(%rbp),%rsi
 101522e:	jmp    1015281 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1c01>
 1015230:	lea    -0xf8(%rbp),%rdx
 1015237:	lea    0x1a1d2(%rip),%rsi        # 102f410 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 101523e:	mov    %rdi,%r15
 1015241:	mov    %r12,%rdi
 1015244:	call   102ab40 <myl_rc_native_take>
 1015249:	mov    %r15,%rdi
 101524c:	mov    %eax,%ecx
 101524e:	mov    -0x40(%rbp),%rsi
 1015252:	mov    %rsi,%rax
 1015255:	mov    -0x38(%rbp),%rsi
 1015259:	cmp    $0x0,%ecx
 101525c:	jne    1015281 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1c01>
 101525e:	mov    %rdi,%rbx
 1015261:	mov    %r12,%rdi
 1015264:	call   1023700 <myl_rc_take_failure>
 1015269:	mov    %rbx,%rdi
 101526c:	mov    %eax,%esi
 101526e:	mov    %rdi,%rbx
 1015271:	call   101ae60 <myl_qbe_rc_status>
 1015276:	mov    %rbx,%rdi
 1015279:	mov    %r13,%rbx
 101527c:	jmp    10154dd <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1e5d>
 1015281:	movl   $0x0,-0x140(%rbp)
 101528b:	lea    0x1a17e(%rip),%rcx        # 102f410 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 1015292:	mov    %rcx,-0x190(%rbp)
 1015299:	lea    -0xf8(%rbp),%rcx
 10152a0:	mov    %rcx,-0x188(%rbp)
 10152a7:	mov    %rbx,-0x180(%rbp)
 10152ae:	movl   $0x2,-0x178(%rbp)
 10152b8:	movl   $0x1,-0x130(%rbp)
 10152c2:	mov    -0xf8(%rbp),%rcx
 10152c9:	mov    %rcx,-0x70(%rbp)
 10152cd:	movl   $0x0,-0x130(%rbp)
 10152d7:	lea    -0x78(%rbp),%rcx
 10152db:	mov    %rcx,-0xd8(%rbp)
 10152e2:	movl   $0x0,-0x128(%rbp)
 10152ec:	mov    -0x78(%rbp),%rcx
 10152f0:	mov    %rcx,-0xf8(%rbp)
 10152f7:	mov    -0x70(%rbp),%rcx
 10152fb:	mov    %rcx,-0xf0(%rbp)
 1015302:	lea    0x1a177(%rip),%rcx        # 102f480 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 1015309:	mov    %rcx,-0x190(%rbp)
 1015310:	lea    -0xf8(%rbp),%rcx
 1015317:	mov    %rcx,-0x188(%rbp)
 101531e:	mov    %rbx,-0x180(%rbp)
 1015325:	movl   $0x2,-0x178(%rbp)
 101532f:	movl   $0x1,-0x130(%rbp)
 1015339:	mov    -0x148(%rbp),%ecx
 101533f:	cmp    $0x0,%ecx
 1015342:	jne    1015349 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1cc9>
 1015344:	mov    %rax,%rsi
 1015347:	jmp    1015358 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1cd8>
 1015349:	mov    %rdi,%r15
 101534c:	call   101b030 <myl_qbe_rc_slot_drop>
 1015351:	mov    %r15,%rdi
 1015354:	mov    -0x40(%rbp),%rsi
 1015358:	mov    -0x140(%rbp),%eax
 101535e:	cmp    $0x0,%eax
 1015361:	je     101536e <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1cee>
 1015363:	mov    %rdi,%r15
 1015366:	call   101b030 <myl_qbe_rc_slot_drop>
 101536b:	mov    %r15,%rdi
 101536e:	mov    -0xf8(%rbp),%rax
 1015375:	mov    %rax,-0x120(%rbp)
 101537c:	mov    -0xf0(%rbp),%rax
 1015383:	mov    %rax,-0x118(%rbp)
 101538a:	lea    0x1a0ef(%rip),%rax        # 102f480 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 1015391:	mov    %rax,-0x1f0(%rbp)
 1015398:	lea    -0x120(%rbp),%rax
 101539f:	mov    %rax,-0x1e8(%rbp)
 10153a6:	mov    %r14,-0x1e0(%rbp)
 10153ad:	movl   $0x2,-0x1d8(%rbp)
 10153b7:	movl   $0x0,-0x130(%rbp)
 10153c1:	movl   $0x1,-0x148(%rbp)
 10153cb:	lea    -0x120(%rbp),%rax
 10153d2:	mov    %rax,-0xd8(%rbp)
 10153d9:	mov    %r13,0x10(%r12)
 10153de:	mov    -0xd8(%rbp),%r15
 10153e5:	mov    %rdi,%r14
 10153e8:	call   101db60 <myl_qbe_region_mark>
 10153ed:	mov    %r15,%rcx
 10153f0:	mov    %r14,%rdi
 10153f3:	mov    %rax,%r8
 10153f6:	lea    -0xf8(%rbp),%rax
 10153fd:	neg    %rax
 1015400:	add    %rcx,%rax
 1015403:	lea    -0xf8(%rbp),%rdx
 101540a:	sub    %rcx,%rdx
 101540d:	cmp    $0x10,%rax
 1015411:	setb   %al
 1015414:	movzbl %al,%eax
 1015417:	cmp    $0x10,%rdx
 101541b:	setb   %dl
 101541e:	movzbl %dl,%edx
 1015421:	or     %edx,%eax
 1015423:	jne    101549e <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1e1e>
 1015425:	mov    (%rcx),%rax
 1015428:	cmp    $0x0,%rax
 101542c:	je     1015448 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1dc8>
 101542e:	sub    $0x10,%rax
 1015432:	mov    (%rax),%rax
 1015435:	movabs $0x5000000000000001,%rdx
 101543f:	and    %rdx,%rax
 1015442:	cmp    $0x0,%rax
 1015446:	jne    101549e <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1e1e>
 1015448:	mov    0x8(%rcx),%rax
 101544c:	cmp    $0x0,%rax
 1015450:	je     101546c <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1dec>
 1015452:	sub    $0x10,%rax
 1015456:	mov    (%rax),%rax
 1015459:	movabs $0x5000000000000001,%rdx
 1015463:	and    %rdx,%rax
 1015466:	cmp    $0x0,%rax
 101546a:	jne    101549e <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1e1e>
 101546c:	mov    (%rcx),%rax
 101546f:	mov    %rax,-0xf8(%rbp)
 1015476:	mov    0x8(%rcx),%rax
 101547a:	mov    %rax,-0xf0(%rbp)
 1015481:	mov    $0x10,%edx
 1015486:	mov    $0x0,%esi
 101548b:	mov    %rdi,%r12
 101548e:	mov    %rcx,%rdi
 1015491:	call   102aee0 <compiler_rt.fastMemset>
 1015496:	mov    %r12,%rdi
 1015499:	jmp    1015526 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1ea6>
 101549e:	lea    -0xf8(%rbp),%rdx
 10154a5:	lea    0x19fd4(%rip),%rsi        # 102f480 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 10154ac:	mov    %rdi,%r14
 10154af:	mov    %r12,%rdi
 10154b2:	call   102ab40 <myl_rc_native_take>
 10154b7:	mov    %r14,%rdi
 10154ba:	cmp    $0x0,%eax
 10154bd:	jne    1015526 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1ea6>
 10154bf:	mov    %r13,%rbx
 10154c2:	mov    %rdi,%r13
 10154c5:	mov    %r12,%rdi
 10154c8:	call   1023700 <myl_rc_take_failure>
 10154cd:	mov    %r13,%rdi
 10154d0:	mov    %eax,%esi
 10154d2:	mov    %rdi,%r13
 10154d5:	call   101ae60 <myl_qbe_rc_status>
 10154da:	mov    %r13,%rdi
 10154dd:	lea    -0x230(%rbp),%rsi
 10154e4:	mov    %rdi,%r13
 10154e7:	call   101b140 <myl_qbe_rc_frame_cleanup>
 10154ec:	mov    %r13,%rdi
 10154ef:	lea    -0x230(%rbp),%rsi
 10154f6:	call   101afd0 <myl_qbe_rc_frame_leave>
 10154fb:	mov    %rbx,0x10(%r12)
 1015500:	mov    $0x10,%edx
 1015505:	mov    $0x0,%esi
 101550a:	lea    -0x240(%rbp),%rdi
 1015511:	call   102aee0 <compiler_rt.fastMemset>
 1015516:	mov    -0x240(%rbp),%rax
 101551d:	mov    -0x238(%rbp),%rdx
 1015524:	jmp    101559d <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1f1d>
 1015526:	movl   $0x0,-0x148(%rbp)
 1015530:	lea    0x19f49(%rip),%rax        # 102f480 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 1015537:	mov    %rax,-0x190(%rbp)
 101553e:	lea    -0xf8(%rbp),%rax
 1015545:	mov    %rax,-0x188(%rbp)
 101554c:	mov    %rbx,-0x180(%rbp)
 1015553:	movl   $0x2,-0x178(%rbp)
 101555d:	movl   $0x1,-0x130(%rbp)
 1015567:	movl   $0x0,-0x130(%rbp)
 1015571:	lea    -0x230(%rbp),%rsi
 1015578:	mov    %rdi,%rbx
 101557b:	call   101b140 <myl_qbe_rc_frame_cleanup>
 1015580:	mov    %rbx,%rdi
 1015583:	lea    -0x230(%rbp),%rsi
 101558a:	call   101afd0 <myl_qbe_rc_frame_leave>
 101558f:	mov    -0xf8(%rbp),%rax
 1015596:	mov    -0xf0(%rbp),%rdx
 101559d:	pop    %r15
 101559f:	pop    %r14
 10155a1:	pop    %r13
 10155a3:	pop    %r12
 10155a5:	pop    %rbx
 10155a6:	leave
 10155a7:	ret
 10155a8:	call   101b830 <myl_qbe_fail_frame>
 10155ad:	ud2

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
