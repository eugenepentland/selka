
.tmp-rc/profile/gap-llvm-gc-n12:     file format elf64-x86-64


Disassembly of section .text:

0000000001015c70 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531>:
 1015c70:	push   %r15
 1015c72:	push   %r14
 1015c74:	push   %r13
 1015c76:	push   %r12
 1015c78:	push   %rbx
 1015c79:	sub    $0x70,%rsp
 1015c7d:	mov    %rdi,%rbx
 1015c80:	cmp    %rsp,0x40(%rdi)
 1015c84:	ja     1015e42 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1d2>
 1015c8a:	xor    %eax,%eax
 1015c8c:	mov    $0x0,%edx
 1015c91:	test   %rsi,%rsi
 1015c94:	je     1015e34 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1c4>
 1015c9a:	mov    %rsi,%rax
 1015c9d:	neg    %rax
 1015ca0:	jo     1015e4a <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1da>
 1015ca6:	lea    0x258(%rbx),%r14
 1015cad:	mov    0x268(%rbx),%r15
 1015cb4:	dec    %rsi
 1015cb7:	mov    %rbx,%rdi
 1015cba:	mov    %rsi,%r12
 1015cbd:	call   1015c70 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531>
 1015cc2:	mov    %rax,0x40(%rsp)
 1015cc7:	mov    %rdx,0x48(%rsp)
 1015ccc:	mov    0x768(%rbx),%rax
 1015cd3:	lea    0x20(%rax),%rcx
 1015cd7:	cmp    0x770(%rbx),%rcx
 1015cde:	jbe    1015d25 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xb5>
 1015ce0:	mov    0x268(%rbx),%rax
 1015ce7:	mov    %rax,0x10(%rsp)
 1015cec:	lea    0x40(%rsp),%rax
 1015cf1:	mov    %rax,0x18(%rsp)
 1015cf6:	movq   $0x1009dc8,0x20(%rsp)
 1015cff:	lea    0x10(%rsp),%rax
 1015d04:	mov    %rax,0x268(%rbx)
 1015d0b:	mov    %r14,%rdi
 1015d0e:	call   101ef80 <myl_native_heap_alloc_small>
 1015d13:	test   %rax,%rax
 1015d16:	je     1015e66 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1f6>
 1015d1c:	mov    %r15,0x268(%rbx)
 1015d23:	jmp    1015d48 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xd8>
 1015d25:	mov    %rcx,0x768(%rbx)
 1015d2c:	movq   $0x4,(%rax)
 1015d33:	movq   $0x1009b60,0x8(%rax)
 1015d3b:	vxorps %xmm0,%xmm0,%xmm0
 1015d3f:	vmovups %xmm0,0x10(%rax)
 1015d44:	add    $0x10,%rax
 1015d48:	mov    %r12,%rsi
 1015d4b:	vmovups 0x40(%rsp),%xmm0
 1015d51:	vmovups %xmm0,(%rax)
 1015d55:	mov    %rax,0x8(%rsp)
 1015d5a:	mov    0x268(%rbx),%rax
 1015d61:	mov    %rax,0x10(%rsp)
 1015d66:	lea    0x8(%rsp),%r12
 1015d6b:	mov    %r12,0x18(%rsp)
 1015d70:	movq   $0x1009d38,0x20(%rsp)
 1015d79:	lea    0x10(%rsp),%r13
 1015d7e:	mov    %r13,0x268(%rbx)
 1015d85:	mov    %rbx,%rdi
 1015d88:	call   1015c70 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531>
 1015d8d:	mov    %rax,0x30(%rsp)
 1015d92:	mov    %rdx,0x38(%rsp)
 1015d97:	mov    %r15,0x268(%rbx)
 1015d9e:	mov    0x768(%rbx),%rdx
 1015da5:	lea    0x20(%rdx),%rax
 1015da9:	cmp    0x770(%rbx),%rax
 1015db0:	jbe    1015e02 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x192>
 1015db2:	mov    %r15,0x10(%rsp)
 1015db7:	mov    %r12,0x18(%rsp)
 1015dbc:	movq   $0x1009d38,0x20(%rsp)
 1015dc5:	mov    %r13,0x50(%rsp)
 1015dca:	lea    0x30(%rsp),%rax
 1015dcf:	mov    %rax,0x58(%rsp)
 1015dd4:	movq   $0x1009dc8,0x60(%rsp)
 1015ddd:	lea    0x50(%rsp),%rax
 1015de2:	mov    %rax,0x268(%rbx)
 1015de9:	mov    %r14,%rdi
 1015dec:	call   101ef80 <myl_native_heap_alloc_small>
 1015df1:	test   %rax,%rax
 1015df4:	je     1015e6e <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1fe>
 1015df6:	mov    %rax,%rdx
 1015df9:	mov    %r15,0x268(%rbx)
 1015e00:	jmp    1015e25 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1b5>
 1015e02:	mov    %rax,0x768(%rbx)
 1015e09:	movq   $0x4,(%rdx)
 1015e10:	movq   $0x1009b60,0x8(%rdx)
 1015e18:	vxorps %xmm0,%xmm0,%xmm0
 1015e1c:	vmovups %xmm0,0x10(%rdx)
 1015e21:	add    $0x10,%rdx
 1015e25:	vmovups 0x30(%rsp),%xmm0
 1015e2b:	vmovups %xmm0,(%rdx)
 1015e2f:	mov    0x8(%rsp),%rax
 1015e34:	add    $0x70,%rsp
 1015e38:	pop    %rbx
 1015e39:	pop    %r12
 1015e3b:	pop    %r13
 1015e3d:	pop    %r14
 1015e3f:	pop    %r15
 1015e41:	ret
 1015e42:	mov    %rbx,%rdi
 1015e45:	call   101b960 <myl_qbe_fail_frame>
 1015e4a:	movabs $0x8000000000000000,%rdx
 1015e54:	mov    $0x1,%esi
 1015e59:	mov    $0x1,%ecx
 1015e5e:	mov    %rbx,%rdi
 1015e61:	call   101b8f0 <myl_qbe_fail_overflow_op>
 1015e66:	mov    %rbx,%rdi
 1015e69:	call   101b8b0 <myl_qbe_fail_allocation>
 1015e6e:	mov    %rbx,%rdi
 1015e71:	call   101b8b0 <myl_qbe_fail_allocation>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
