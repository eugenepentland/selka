
.tmp-rc/profile/gap-llvm-rc-n12:     file format elf64-x86-64


Disassembly of section .text:

0000000001016d00 <myl_f_20f65c28671b40937c5bf23acc7c6f37e5a5ec0622e347b57685725df5ba9e50>:
 1016d00:	push   %r15
 1016d02:	push   %r14
 1016d04:	push   %rbx
 1016d05:	sub    $0x20,%rsp
 1016d09:	mov    %rdi,%rbx
 1016d0c:	cmp    %rsp,0x40(%rdi)
 1016d10:	ja     1016d71 <myl_f_20f65c28671b40937c5bf23acc7c6f37e5a5ec0622e347b57685725df5ba9e50+0x71>
 1016d12:	mov    (%rsi),%rcx
 1016d15:	mov    $0x1,%eax
 1016d1a:	test   %rcx,%rcx
 1016d1d:	je     1016d67 <myl_f_20f65c28671b40937c5bf23acc7c6f37e5a5ec0622e347b57685725df5ba9e50+0x67>
 1016d1f:	mov    0x8(%rsi),%r15
 1016d23:	test   %r15,%r15
 1016d26:	je     1016d67 <myl_f_20f65c28671b40937c5bf23acc7c6f37e5a5ec0622e347b57685725df5ba9e50+0x67>
 1016d28:	vmovups (%rcx),%xmm0
 1016d2c:	vmovaps %xmm0,0x10(%rsp)
 1016d32:	lea    0x10(%rsp),%rsi
 1016d37:	mov    %rbx,%rdi
 1016d3a:	call   1016d00 <myl_f_20f65c28671b40937c5bf23acc7c6f37e5a5ec0622e347b57685725df5ba9e50>
 1016d3f:	mov    %rax,%r14
 1016d42:	inc    %r14
 1016d45:	jo     1016d79 <myl_f_20f65c28671b40937c5bf23acc7c6f37e5a5ec0622e347b57685725df5ba9e50+0x79>
 1016d47:	vmovups (%r15),%xmm0
 1016d4c:	vmovaps %xmm0,(%rsp)
 1016d51:	mov    %rsp,%rsi
 1016d54:	mov    %rbx,%rdi
 1016d57:	call   1016d00 <myl_f_20f65c28671b40937c5bf23acc7c6f37e5a5ec0622e347b57685725df5ba9e50>
 1016d5c:	mov    %rax,%rcx
 1016d5f:	mov    %r14,%rax
 1016d62:	add    %rcx,%rax
 1016d65:	jo     1016d8b <myl_f_20f65c28671b40937c5bf23acc7c6f37e5a5ec0622e347b57685725df5ba9e50+0x8b>
 1016d67:	add    $0x20,%rsp
 1016d6b:	pop    %rbx
 1016d6c:	pop    %r14
 1016d6e:	pop    %r15
 1016d70:	ret
 1016d71:	mov    %rbx,%rdi
 1016d74:	call   101fa30 <myl_qbe_fail_frame>
 1016d79:	mov    $0x1,%edx
 1016d7e:	mov    %rbx,%rdi
 1016d81:	xor    %esi,%esi
 1016d83:	mov    %rax,%rcx
 1016d86:	call   101f9c0 <myl_qbe_fail_overflow_op>
 1016d8b:	mov    %rbx,%rdi
 1016d8e:	xor    %esi,%esi
 1016d90:	mov    %r14,%rdx
 1016d93:	call   101f9c0 <myl_qbe_fail_overflow_op>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
