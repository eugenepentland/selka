
.tmp-rc/profile/gap-qbe-rc-n12:     file format elf64-x86-64


Disassembly of section .text:

00000000010134b0 <myl_f_20f65c28671b40937c5bf23acc7c6f37e5a5ec0622e347b57685725df5ba9e50>:
 10134b0:	endbr64
 10134b4:	push   %rbp
 10134b5:	mov    %rsp,%rbp
 10134b8:	sub    $0x40,%rsp
 10134bc:	push   %rbx
 10134bd:	push   %r12
 10134bf:	mov    0x40(%rdi),%rax
 10134c3:	lea    -0x8(%rbp),%rcx
 10134c7:	cmp    %rax,%rcx
 10134ca:	jb     1013670 <myl_f_20f65c28671b40937c5bf23acc7c6f37e5a5ec0622e347b57685725df5ba9e50+0x1c0>
 10134d0:	mov    (%rsi),%rax
 10134d3:	mov    %rax,-0x40(%rbp)
 10134d7:	mov    0x8(%rsi),%rax
 10134db:	mov    %rax,-0x30(%rbp)
 10134df:	mov    -0x40(%rbp),%rax
 10134e3:	cmp    $0x0,%rax
 10134e7:	setne  %cl
 10134ea:	movzbq %cl,%rcx
 10134ee:	cmp    $0x0,%rcx
 10134f2:	sete   %dl
 10134f5:	movzbq %dl,%rdx
 10134f9:	cmp    $0x0,%edx
 10134fc:	jne    101350f <myl_f_20f65c28671b40937c5bf23acc7c6f37e5a5ec0622e347b57685725df5ba9e50+0x5f>
 10134fe:	cmp    $0x1,%rcx
 1013502:	jne    10135d1 <myl_f_20f65c28671b40937c5bf23acc7c6f37e5a5ec0622e347b57685725df5ba9e50+0x121>
 1013508:	mov    $0x0,%edx
 101350d:	jmp    1013514 <myl_f_20f65c28671b40937c5bf23acc7c6f37e5a5ec0622e347b57685725df5ba9e50+0x64>
 101350f:	mov    $0x1,%edx
 1013514:	cmp    $0x0,%edx
 1013517:	jne    1013546 <myl_f_20f65c28671b40937c5bf23acc7c6f37e5a5ec0622e347b57685725df5ba9e50+0x96>
 1013519:	mov    -0x30(%rbp),%rdx
 101351d:	cmp    $0x0,%rdx
 1013521:	setne  %dl
 1013524:	movzbq %dl,%rdx
 1013528:	cmp    $0x0,%rdx
 101352c:	je     101353f <myl_f_20f65c28671b40937c5bf23acc7c6f37e5a5ec0622e347b57685725df5ba9e50+0x8f>
 101352e:	cmp    $0x1,%rdx
 1013532:	jne    10135d1 <myl_f_20f65c28671b40937c5bf23acc7c6f37e5a5ec0622e347b57685725df5ba9e50+0x121>
 1013538:	mov    $0x0,%edx
 101353d:	jmp    101354b <myl_f_20f65c28671b40937c5bf23acc7c6f37e5a5ec0622e347b57685725df5ba9e50+0x9b>
 101353f:	mov    $0x1,%edx
 1013544:	jmp    101354b <myl_f_20f65c28671b40937c5bf23acc7c6f37e5a5ec0622e347b57685725df5ba9e50+0x9b>
 1013546:	mov    $0x1,%edx
 101354b:	cmp    $0x0,%edx
 101354e:	jne    1013666 <myl_f_20f65c28671b40937c5bf23acc7c6f37e5a5ec0622e347b57685725df5ba9e50+0x1b6>
 1013554:	cmp    $0x0,%rcx
 1013558:	je     101365f <myl_f_20f65c28671b40937c5bf23acc7c6f37e5a5ec0622e347b57685725df5ba9e50+0x1af>
 101355e:	cmp    $0x1,%rcx
 1013562:	jne    10135d1 <myl_f_20f65c28671b40937c5bf23acc7c6f37e5a5ec0622e347b57685725df5ba9e50+0x121>
 1013564:	mov    (%rax),%rcx
 1013567:	mov    %rcx,-0x40(%rbp)
 101356b:	mov    0x8(%rax),%rax
 101356f:	mov    %rax,-0x38(%rbp)
 1013573:	mov    -0x40(%rbp),%rax
 1013577:	mov    %rax,-0x28(%rbp)
 101357b:	mov    -0x38(%rbp),%rax
 101357f:	mov    %rax,-0x20(%rbp)
 1013583:	lea    -0x28(%rbp),%rsi
 1013587:	mov    %rdi,%rbx
 101358a:	call   10134b0 <myl_f_20f65c28671b40937c5bf23acc7c6f37e5a5ec0622e347b57685725df5ba9e50>
 101358f:	mov    %rbx,%rdi
 1013592:	mov    %rax,%rcx
 1013595:	mov    %rcx,%rdx
 1013598:	add    $0x1,%rdx
 101359c:	mov    %rdx,%rax
 101359f:	xor    $0x1,%rax
 10135a3:	mov    %rdx,%r12
 10135a6:	xor    %rcx,%rdx
 10135a9:	and    %rdx,%rax
 10135ac:	cmp    $0x0,%rax
 10135b0:	jl     1013648 <myl_f_20f65c28671b40937c5bf23acc7c6f37e5a5ec0622e347b57685725df5ba9e50+0x198>
 10135b6:	mov    -0x30(%rbp),%rax
 10135ba:	cmp    $0x0,%rax
 10135be:	setne  %cl
 10135c1:	movzbq %cl,%rcx
 10135c5:	cmp    $0x0,%rcx
 10135c9:	je     1013641 <myl_f_20f65c28671b40937c5bf23acc7c6f37e5a5ec0622e347b57685725df5ba9e50+0x191>
 10135cb:	cmp    $0x1,%rcx
 10135cf:	je     10135db <myl_f_20f65c28671b40937c5bf23acc7c6f37e5a5ec0622e347b57685725df5ba9e50+0x12b>
 10135d1:	mov    $0x0,%eax
 10135d6:	jmp    101366b <myl_f_20f65c28671b40937c5bf23acc7c6f37e5a5ec0622e347b57685725df5ba9e50+0x1bb>
 10135db:	mov    (%rax),%rcx
 10135de:	mov    %rcx,-0x40(%rbp)
 10135e2:	mov    0x8(%rax),%rax
 10135e6:	mov    %rax,-0x38(%rbp)
 10135ea:	mov    -0x40(%rbp),%rax
 10135ee:	mov    %rax,-0x18(%rbp)
 10135f2:	mov    -0x38(%rbp),%rax
 10135f6:	mov    %rax,-0x10(%rbp)
 10135fa:	lea    -0x18(%rbp),%rsi
 10135fe:	mov    %rdi,%rbx
 1013601:	call   10134b0 <myl_f_20f65c28671b40937c5bf23acc7c6f37e5a5ec0622e347b57685725df5ba9e50>
 1013606:	mov    %r12,%rdx
 1013609:	mov    %rbx,%rdi
 101360c:	mov    %rax,%rcx
 101360f:	mov    %rcx,%rsi
 1013612:	add    %rdx,%rsi
 1013615:	mov    %rdx,%rax
 1013618:	xor    %rsi,%rax
 101361b:	xor    %rcx,%rsi
 101361e:	and    %rsi,%rax
 1013621:	cmp    $0x0,%rax
 1013625:	jl     101362f <myl_f_20f65c28671b40937c5bf23acc7c6f37e5a5ec0622e347b57685725df5ba9e50+0x17f>
 1013627:	mov    %rcx,%rax
 101362a:	add    %rdx,%rax
 101362d:	jmp    101366b <myl_f_20f65c28671b40937c5bf23acc7c6f37e5a5ec0622e347b57685725df5ba9e50+0x1bb>
 101362f:	mov    $0x40,%r8d
 1013635:	mov    $0x0,%esi
 101363a:	call   101b6e0 <myl_qbe_fail_overflow_op>
 101363f:	ud2
 1013641:	call   101b610 <myl_qbe_fail_assert>
 1013646:	ud2
 1013648:	mov    $0x40,%r8d
 101364e:	mov    $0x1,%edx
 1013653:	mov    $0x0,%esi
 1013658:	call   101b6e0 <myl_qbe_fail_overflow_op>
 101365d:	ud2
 101365f:	call   101b610 <myl_qbe_fail_assert>
 1013664:	ud2
 1013666:	mov    $0x1,%eax
 101366b:	pop    %r12
 101366d:	pop    %rbx
 101366e:	leave
 101366f:	ret
 1013670:	call   101b830 <myl_qbe_fail_frame>
 1013675:	ud2

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
