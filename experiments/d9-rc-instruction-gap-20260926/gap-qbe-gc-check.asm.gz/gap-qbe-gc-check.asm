
.tmp-rc/profile/gap-qbe-gc-n12:     file format elf64-x86-64


Disassembly of section .text:

0000000001010a20 <myl_f_20f65c28671b40937c5bf23acc7c6f37e5a5ec0622e347b57685725df5ba9e50>:
 1010a20:	endbr64
 1010a24:	push   %rbp
 1010a25:	mov    %rsp,%rbp
 1010a28:	sub    $0x40,%rsp
 1010a2c:	push   %rbx
 1010a2d:	push   %r12
 1010a2f:	mov    0x40(%rdi),%rax
 1010a33:	lea    -0x8(%rbp),%rcx
 1010a37:	cmp    %rax,%rcx
 1010a3a:	jb     1010be0 <myl_f_20f65c28671b40937c5bf23acc7c6f37e5a5ec0622e347b57685725df5ba9e50+0x1c0>
 1010a40:	mov    (%rsi),%rax
 1010a43:	mov    %rax,-0x40(%rbp)
 1010a47:	mov    0x8(%rsi),%rax
 1010a4b:	mov    %rax,-0x30(%rbp)
 1010a4f:	mov    -0x40(%rbp),%rax
 1010a53:	cmp    $0x0,%rax
 1010a57:	setne  %cl
 1010a5a:	movzbq %cl,%rcx
 1010a5e:	cmp    $0x0,%rcx
 1010a62:	sete   %dl
 1010a65:	movzbq %dl,%rdx
 1010a69:	cmp    $0x0,%edx
 1010a6c:	jne    1010a7f <myl_f_20f65c28671b40937c5bf23acc7c6f37e5a5ec0622e347b57685725df5ba9e50+0x5f>
 1010a6e:	cmp    $0x1,%rcx
 1010a72:	jne    1010b41 <myl_f_20f65c28671b40937c5bf23acc7c6f37e5a5ec0622e347b57685725df5ba9e50+0x121>
 1010a78:	mov    $0x0,%edx
 1010a7d:	jmp    1010a84 <myl_f_20f65c28671b40937c5bf23acc7c6f37e5a5ec0622e347b57685725df5ba9e50+0x64>
 1010a7f:	mov    $0x1,%edx
 1010a84:	cmp    $0x0,%edx
 1010a87:	jne    1010ab6 <myl_f_20f65c28671b40937c5bf23acc7c6f37e5a5ec0622e347b57685725df5ba9e50+0x96>
 1010a89:	mov    -0x30(%rbp),%rdx
 1010a8d:	cmp    $0x0,%rdx
 1010a91:	setne  %dl
 1010a94:	movzbq %dl,%rdx
 1010a98:	cmp    $0x0,%rdx
 1010a9c:	je     1010aaf <myl_f_20f65c28671b40937c5bf23acc7c6f37e5a5ec0622e347b57685725df5ba9e50+0x8f>
 1010a9e:	cmp    $0x1,%rdx
 1010aa2:	jne    1010b41 <myl_f_20f65c28671b40937c5bf23acc7c6f37e5a5ec0622e347b57685725df5ba9e50+0x121>
 1010aa8:	mov    $0x0,%edx
 1010aad:	jmp    1010abb <myl_f_20f65c28671b40937c5bf23acc7c6f37e5a5ec0622e347b57685725df5ba9e50+0x9b>
 1010aaf:	mov    $0x1,%edx
 1010ab4:	jmp    1010abb <myl_f_20f65c28671b40937c5bf23acc7c6f37e5a5ec0622e347b57685725df5ba9e50+0x9b>
 1010ab6:	mov    $0x1,%edx
 1010abb:	cmp    $0x0,%edx
 1010abe:	jne    1010bd6 <myl_f_20f65c28671b40937c5bf23acc7c6f37e5a5ec0622e347b57685725df5ba9e50+0x1b6>
 1010ac4:	cmp    $0x0,%rcx
 1010ac8:	je     1010bcf <myl_f_20f65c28671b40937c5bf23acc7c6f37e5a5ec0622e347b57685725df5ba9e50+0x1af>
 1010ace:	cmp    $0x1,%rcx
 1010ad2:	jne    1010b41 <myl_f_20f65c28671b40937c5bf23acc7c6f37e5a5ec0622e347b57685725df5ba9e50+0x121>
 1010ad4:	mov    (%rax),%rcx
 1010ad7:	mov    %rcx,-0x40(%rbp)
 1010adb:	mov    0x8(%rax),%rax
 1010adf:	mov    %rax,-0x38(%rbp)
 1010ae3:	mov    -0x40(%rbp),%rax
 1010ae7:	mov    %rax,-0x28(%rbp)
 1010aeb:	mov    -0x38(%rbp),%rax
 1010aef:	mov    %rax,-0x20(%rbp)
 1010af3:	lea    -0x28(%rbp),%rsi
 1010af7:	mov    %rdi,%rbx
 1010afa:	call   1010a20 <myl_f_20f65c28671b40937c5bf23acc7c6f37e5a5ec0622e347b57685725df5ba9e50>
 1010aff:	mov    %rbx,%rdi
 1010b02:	mov    %rax,%rcx
 1010b05:	mov    %rcx,%rdx
 1010b08:	add    $0x1,%rdx
 1010b0c:	mov    %rdx,%rax
 1010b0f:	xor    $0x1,%rax
 1010b13:	mov    %rdx,%r12
 1010b16:	xor    %rcx,%rdx
 1010b19:	and    %rdx,%rax
 1010b1c:	cmp    $0x0,%rax
 1010b20:	jl     1010bb8 <myl_f_20f65c28671b40937c5bf23acc7c6f37e5a5ec0622e347b57685725df5ba9e50+0x198>
 1010b26:	mov    -0x30(%rbp),%rax
 1010b2a:	cmp    $0x0,%rax
 1010b2e:	setne  %cl
 1010b31:	movzbq %cl,%rcx
 1010b35:	cmp    $0x0,%rcx
 1010b39:	je     1010bb1 <myl_f_20f65c28671b40937c5bf23acc7c6f37e5a5ec0622e347b57685725df5ba9e50+0x191>
 1010b3b:	cmp    $0x1,%rcx
 1010b3f:	je     1010b4b <myl_f_20f65c28671b40937c5bf23acc7c6f37e5a5ec0622e347b57685725df5ba9e50+0x12b>
 1010b41:	mov    $0x0,%eax
 1010b46:	jmp    1010bdb <myl_f_20f65c28671b40937c5bf23acc7c6f37e5a5ec0622e347b57685725df5ba9e50+0x1bb>
 1010b4b:	mov    (%rax),%rcx
 1010b4e:	mov    %rcx,-0x40(%rbp)
 1010b52:	mov    0x8(%rax),%rax
 1010b56:	mov    %rax,-0x38(%rbp)
 1010b5a:	mov    -0x40(%rbp),%rax
 1010b5e:	mov    %rax,-0x18(%rbp)
 1010b62:	mov    -0x38(%rbp),%rax
 1010b66:	mov    %rax,-0x10(%rbp)
 1010b6a:	lea    -0x18(%rbp),%rsi
 1010b6e:	mov    %rdi,%rbx
 1010b71:	call   1010a20 <myl_f_20f65c28671b40937c5bf23acc7c6f37e5a5ec0622e347b57685725df5ba9e50>
 1010b76:	mov    %r12,%rdx
 1010b79:	mov    %rbx,%rdi
 1010b7c:	mov    %rax,%rcx
 1010b7f:	mov    %rcx,%rsi
 1010b82:	add    %rdx,%rsi
 1010b85:	mov    %rdx,%rax
 1010b88:	xor    %rsi,%rax
 1010b8b:	xor    %rcx,%rsi
 1010b8e:	and    %rsi,%rax
 1010b91:	cmp    $0x0,%rax
 1010b95:	jl     1010b9f <myl_f_20f65c28671b40937c5bf23acc7c6f37e5a5ec0622e347b57685725df5ba9e50+0x17f>
 1010b97:	mov    %rcx,%rax
 1010b9a:	add    %rdx,%rax
 1010b9d:	jmp    1010bdb <myl_f_20f65c28671b40937c5bf23acc7c6f37e5a5ec0622e347b57685725df5ba9e50+0x1bb>
 1010b9f:	mov    $0x40,%r8d
 1010ba5:	mov    $0x0,%esi
 1010baa:	call   10169a0 <myl_qbe_fail_overflow_op>
 1010baf:	ud2
 1010bb1:	call   10168d0 <myl_qbe_fail_assert>
 1010bb6:	ud2
 1010bb8:	mov    $0x40,%r8d
 1010bbe:	mov    $0x1,%edx
 1010bc3:	mov    $0x0,%esi
 1010bc8:	call   10169a0 <myl_qbe_fail_overflow_op>
 1010bcd:	ud2
 1010bcf:	call   10168d0 <myl_qbe_fail_assert>
 1010bd4:	ud2
 1010bd6:	mov    $0x1,%eax
 1010bdb:	pop    %r12
 1010bdd:	pop    %rbx
 1010bde:	leave
 1010bdf:	ret
 1010be0:	call   1016af0 <myl_qbe_fail_frame>
 1010be5:	ud2

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
