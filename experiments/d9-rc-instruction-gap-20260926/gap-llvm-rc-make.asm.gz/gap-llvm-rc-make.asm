
.tmp-rc/profile/gap-llvm-rc-n12:     file format elf64-x86-64


Disassembly of section .text:

0000000001016da0 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531>:
 1016da0:	push   %rbp
 1016da1:	push   %r15
 1016da3:	push   %r14
 1016da5:	push   %r13
 1016da7:	push   %r12
 1016da9:	push   %rbx
 1016daa:	sub    $0x1f8,%rsp
 1016db1:	mov    %rdi,%rbx
 1016db4:	cmp    %rsp,0x40(%rdi)
 1016db8:	ja     10181b3 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1413>
 1016dbe:	mov    %rsi,0x1d8(%rsp)
 1016dc6:	vxorps %xmm0,%xmm0,%xmm0
 1016dca:	vmovups %ymm0,0x20(%rsp)
 1016dd0:	vmovups %ymm0,0x30(%rsp)
 1016dd6:	lea    0x30(%rsp),%rcx
 1016ddb:	vmovups %ymm0,0xb0(%rsp)
 1016de4:	vmovups %ymm0,0xd0(%rsp)
 1016ded:	vmovups %ymm0,0xf0(%rsp)
 1016df6:	vmovups %ymm0,0x110(%rsp)
 1016dff:	vmovups %ymm0,0x130(%rsp)
 1016e08:	movq   $0x0,0x150(%rsp)
 1016e14:	movq   $0x1009850,0x98(%rsp)
 1016e20:	lea    0x1d8(%rsp),%rax
 1016e28:	mov    %rax,0xa0(%rsp)
 1016e30:	lea    0x20(%rsp),%rax
 1016e35:	mov    %rax,0xa8(%rsp)
 1016e3d:	movq   $0x1009be8,0xb8(%rsp)
 1016e49:	lea    0x60(%rsp),%r12
 1016e4e:	mov    %r12,0xc0(%rsp)
 1016e56:	lea    0x28(%rsp),%r14
 1016e5b:	mov    %r14,0xc8(%rsp)
 1016e63:	movq   $0x1009be8,0xd8(%rsp)
 1016e6f:	lea    0x1e0(%rsp),%r13
 1016e77:	mov    %r13,0xe0(%rsp)
 1016e7f:	mov    %rcx,0xe8(%rsp)
 1016e87:	movq   $0x1009be8,0xf8(%rsp)
 1016e93:	lea    0x1f0(%rsp),%rax
 1016e9b:	mov    %rax,0x100(%rsp)
 1016ea3:	lea    0x38(%rsp),%rax
 1016ea8:	mov    %rax,0x108(%rsp)
 1016eb0:	movq   $0x1009be8,0x118(%rsp)
 1016ebc:	mov    %rsp,%rbp
 1016ebf:	mov    %rbp,0x120(%rsp)
 1016ec7:	lea    0x40(%rsp),%r15
 1016ecc:	mov    %r15,0x128(%rsp)
 1016ed4:	movq   $0x1009be8,0x138(%rsp)
 1016ee0:	lea    0x158(%rsp),%rax
 1016ee8:	mov    %rax,0x140(%rsp)
 1016ef0:	lea    0x48(%rsp),%rax
 1016ef5:	mov    %rax,0x148(%rsp)
 1016efd:	test   %rbx,%rbx
 1016f00:	je     10181a6 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1406>
 1016f06:	mov    0x1860(%rbx),%rax
 1016f0d:	test   %rax,%rax
 1016f10:	je     10181a6 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1406>
 1016f16:	mov    0x3d80(%rbx),%rcx
 1016f1d:	mov    0x70(%rax),%rax
 1016f21:	mov    %rcx,0x70(%rsp)
 1016f26:	lea    0x98(%rsp),%rcx
 1016f2e:	mov    %rcx,0x78(%rsp)
 1016f33:	movq   $0x6,0x80(%rsp)
 1016f3f:	mov    %rax,0x88(%rsp)
 1016f47:	lea    0x70(%rsp),%rax
 1016f4c:	mov    %rax,0x3d80(%rbx)
 1016f53:	mov    0x268(%rbx),%rax
 1016f5a:	mov    %rax,0x90(%rsp)
 1016f62:	test   %rsi,%rsi
 1016f65:	je     1017130 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x390>
 1016f6b:	mov    %rsi,0x18(%rsp)
 1016f70:	movq   $0x1,0x58(%rsp)
 1016f79:	mov    %rsi,%rax
 1016f7c:	neg    %rax
 1016f7f:	jo     10181bb <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x141b>
 1016f85:	dec    %rsi
 1016f88:	mov    %rsi,0x18(%rsp)
 1016f8d:	mov    %rbx,%rdi
 1016f90:	vzeroupper
 1016f93:	call   1016da0 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531>
 1016f98:	mov    %rax,(%rsp)
 1016f9c:	mov    %rdx,0x8(%rsp)
 1016fa1:	movq   $0x100a308,0x118(%rsp)
 1016fad:	mov    %rbp,0x120(%rsp)
 1016fb5:	mov    %r15,0x128(%rsp)
 1016fbd:	movl   $0x2,0x130(%rsp)
 1016fc8:	mov    %rax,0x60(%rsp)
 1016fcd:	mov    %rdx,0x68(%rsp)
 1016fd2:	movq   $0x100a308,0xb8(%rsp)
 1016fde:	mov    %r12,0xc0(%rsp)
 1016fe6:	mov    %r14,0xc8(%rsp)
 1016fee:	movl   $0x2,0xd0(%rsp)
 1016ff9:	movl   $0x0,0x40(%rsp)
 1017001:	movl   $0x1,0x28(%rsp)
 1017009:	mov    %r12,0x18(%rsp)
 101700e:	mov    0x268(%rbx),%rax
 1017015:	mov    %rax,0x160(%rsp)
 101701d:	mov    %r12,0x168(%rsp)
 1017025:	movq   $0x100a308,0x170(%rsp)
 1017031:	lea    0x160(%rsp),%rax
 1017039:	mov    %rax,0x268(%rbx)
 1017040:	mov    0x2c8(%rbx),%ecx
 1017046:	mov    $0x10098c0,%esi
 101704b:	mov    $0x1,%edx
 1017050:	lea    0x258(%rbx),%rdi
 1017057:	call   1021b10 <myl_native_heap_alloc_at>
 101705c:	test   %rax,%rax
 101705f:	je     10181da <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x143a>
 1017065:	mov    %rax,%r15
 1017068:	mov    %rax,0x158(%rsp)
 1017070:	movq   $0x1009930,0x138(%rsp)
 101707c:	lea    0x158(%rsp),%rax
 1017084:	mov    %rax,0x140(%rsp)
 101708c:	lea    0x48(%rsp),%rax
 1017091:	mov    %rax,0x148(%rsp)
 1017099:	movl   $0x4,0x150(%rsp)
 10170a4:	movl   $0x1,0x48(%rsp)
 10170ac:	mov    0x18(%rsp),%rcx
 10170b1:	mov    0x2c8(%rbx),%r8d
 10170b8:	mov    %rcx,%rax
 10170bb:	sub    %rbp,%rax
 10170be:	mov    %rbp,%rdx
 10170c1:	sub    %rcx,%rdx
 10170c4:	cmp    $0x10,%rax
 10170c8:	setb   %al
 10170cb:	cmp    $0x10,%rdx
 10170cf:	setb   %dl
 10170d2:	or     %al,%dl
 10170d4:	jne    101710f <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x36f>
 10170d6:	mov    (%rcx),%rax
 10170d9:	test   %rax,%rax
 10170dc:	je     10170ee <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x34e>
 10170de:	movabs $0x5000000000000001,%rdx
 10170e8:	test   %rdx,-0x10(%rax)
 10170ec:	jne    101710f <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x36f>
 10170ee:	mov    0x8(%rcx),%rax
 10170f2:	test   %rax,%rax
 10170f5:	je     1017395 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x5f5>
 10170fb:	movabs $0x5000000000000001,%rdx
 1017105:	test   %rdx,-0x10(%rax)
 1017109:	je     1017395 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x5f5>
 101710f:	mov    %rsp,%rdx
 1017112:	mov    $0x100a308,%esi
 1017117:	lea    0x258(%rbx),%rdi
 101711e:	call   102c1a0 <myl_rc_native_take>
 1017123:	test   %eax,%eax
 1017125:	jne    10173a6 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x606>
 101712b:	jmp    1017f74 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x11d4>
 1017130:	movabs $0x5000000000000001,%rdx
 101713a:	movq   $0x0,0x60(%rsp)
 1017143:	movq   $0x1009fd8,0xb8(%rsp)
 101714f:	mov    %r12,0xc0(%rsp)
 1017157:	mov    %r14,0xc8(%rsp)
 101715f:	movl   $0x2,0xd0(%rsp)
 101716a:	movl   $0x1,0x28(%rsp)
 1017172:	mov    %r12,0x18(%rsp)
 1017177:	movq   $0x0,(%rsp)
 101717f:	movq   $0x1009fd8,0x118(%rsp)
 101718b:	mov    %rbp,0x120(%rsp)
 1017193:	mov    %r15,0x128(%rsp)
 101719b:	movl   $0x2,0x130(%rsp)
 10171a6:	movq   $0x0,0x1e0(%rsp)
 10171b2:	movq   $0x1009fd8,0xd8(%rsp)
 10171be:	mov    %r13,0xe0(%rsp)
 10171c6:	lea    0x30(%rsp),%rax
 10171cb:	mov    %rax,0xe8(%rsp)
 10171d3:	movl   $0x2,0xf0(%rsp)
 10171de:	movl   $0x0,0x40(%rsp)
 10171e6:	movl   $0x1,0x30(%rsp)
 10171ee:	mov    %r13,0x58(%rsp)
 10171f3:	mov    0x268(%rbx),%rax
 10171fa:	mov    %rax,0x160(%rsp)
 1017202:	mov    %r12,0x168(%rsp)
 101720a:	movq   $0x1009fd8,0x170(%rsp)
 1017216:	lea    0x160(%rsp),%rax
 101721e:	mov    %rax,0x1b8(%rsp)
 1017226:	mov    %r13,0x1c0(%rsp)
 101722e:	movq   $0x1009fd8,0x1c8(%rsp)
 101723a:	lea    0x1b8(%rsp),%rax
 1017242:	mov    %rax,0x268(%rbx)
 1017249:	vxorps %xmm0,%xmm0,%xmm0
 101724d:	vmovaps %xmm0,0x190(%rsp)
 1017256:	movq   $0x100a308,0x138(%rsp)
 1017262:	lea    0x190(%rsp),%r15
 101726a:	mov    %r15,0x140(%rsp)
 1017272:	lea    0x48(%rsp),%rax
 1017277:	mov    %rax,0x148(%rsp)
 101727f:	movl   $0x2,0x150(%rsp)
 101728a:	movl   $0x1,0x48(%rsp)
 1017292:	mov    0x2c8(%rbx),%r8d
 1017299:	mov    0x60(%rsp),%rax
 101729e:	test   %rax,%rax
 10172a1:	je     10172e5 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x545>
 10172a3:	test   %rdx,-0x10(%rax)
 10172a7:	je     10172e5 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x545>
 10172a9:	mov    %rdx,%r14
 10172ac:	mov    %rsp,%rdx
 10172af:	lea    0x60(%rsp),%rcx
 10172b4:	mov    $0x1009fd8,%esi
 10172b9:	lea    0x258(%rbx),%rdi
 10172c0:	vzeroupper
 10172c3:	call   102c1a0 <myl_rc_native_take>
 10172c8:	test   %eax,%eax
 10172ca:	je     1017f74 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x11d4>
 10172d0:	mov    (%rsp),%rax
 10172d4:	mov    0x58(%rsp),%r13
 10172d9:	mov    0x2c8(%rbx),%r8d
 10172e0:	mov    %r14,%rdx
 10172e3:	jmp    10172f2 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x552>
 10172e5:	mov    %rax,(%rsp)
 10172e9:	movq   $0x0,0x60(%rsp)
 10172f2:	movl   $0x0,0x28(%rsp)
 10172fa:	movq   $0x1009fd8,0x118(%rsp)
 1017306:	mov    %rbp,0x120(%rsp)
 101730e:	lea    0x40(%rsp),%rcx
 1017313:	mov    %rcx,0x128(%rsp)
 101731b:	movl   $0x2,0x130(%rsp)
 1017326:	mov    %rax,0x190(%rsp)
 101732e:	movl   $0x0,0x40(%rsp)
 1017336:	mov    %r13,%rax
 1017339:	sub    %rbp,%rax
 101733c:	mov    %rbp,%rcx
 101733f:	sub    %r13,%rcx
 1017342:	cmp    $0x8,%rax
 1017346:	setb   %al
 1017349:	cmp    $0x8,%rcx
 101734d:	setb   %cl
 1017350:	or     %al,%cl
 1017352:	jne    101736b <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x5cb>
 1017354:	mov    0x0(%r13),%rax
 1017358:	test   %rax,%rax
 101735b:	je     10177ae <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xa0e>
 1017361:	test   %rdx,-0x10(%rax)
 1017365:	je     10177ae <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xa0e>
 101736b:	mov    %rdx,%r14
 101736e:	mov    %rsp,%rdx
 1017371:	mov    $0x1009fd8,%esi
 1017376:	lea    0x258(%rbx),%rdi
 101737d:	mov    %r13,%rcx
 1017380:	vzeroupper
 1017383:	call   102c1a0 <myl_rc_native_take>
 1017388:	test   %eax,%eax
 101738a:	jne    10177bd <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xa1d>
 1017390:	jmp    1017f74 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x11d4>
 1017395:	vmovups (%rcx),%xmm0
 1017399:	vmovaps %xmm0,(%rsp)
 101739e:	vxorps %xmm0,%xmm0,%xmm0
 10173a2:	vmovups %xmm0,(%rcx)
 10173a6:	movl   $0x0,0x28(%rsp)
 10173ae:	vmovaps (%rsp),%xmm0
 10173b3:	vmovups %xmm0,(%r15)
 10173b8:	mov    %r15,0x18(%rsp)
 10173bd:	movl   $0x0,0x48(%rsp)
 10173c5:	mov    %r15,(%rsp)
 10173c9:	movq   $0x1009930,0x118(%rsp)
 10173d5:	mov    %rbp,0x120(%rsp)
 10173dd:	lea    0x40(%rsp),%rax
 10173e2:	mov    %rax,0x128(%rsp)
 10173ea:	movl   $0x2,0x130(%rsp)
 10173f5:	movl   $0x1,0x40(%rsp)
 10173fd:	cmpl   $0x0,0x28(%rsp)
 1017402:	je     1017418 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x678>
 1017404:	mov    %rbx,%rdi
 1017407:	lea    0xb8(%rsp),%rsi
 101740f:	call   101e890 <myl_qbe_rc_slot_drop>
 1017414:	mov    (%rsp),%r15
 1017418:	mov    %r15,0x60(%rsp)
 101741d:	movq   $0x1009930,0xb8(%rsp)
 1017429:	mov    %r12,0xc0(%rsp)
 1017431:	mov    %r14,0xc8(%rsp)
 1017439:	movl   $0x2,0xd0(%rsp)
 1017444:	movl   $0x0,0x40(%rsp)
 101744c:	movl   $0x1,0x28(%rsp)
 1017454:	mov    %r15,0x18(%rsp)
 1017459:	mov    0x90(%rsp),%rax
 1017461:	mov    %rax,0x268(%rbx)
 1017468:	movq   $0x0,0x1b0(%rsp)
 1017474:	movq   $0x1009fd8,0x138(%rsp)
 1017480:	lea    0x1b0(%rsp),%rax
 1017488:	mov    %rax,0x140(%rsp)
 1017490:	lea    0x48(%rsp),%rax
 1017495:	mov    %rax,0x148(%rsp)
 101749d:	movl   $0x2,0x150(%rsp)
 10174a8:	movl   $0x1,0x48(%rsp)
 10174b0:	test   %r15,%r15
 10174b3:	je     10174f3 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x753>
 10174b5:	movabs $0x5000000000000001,%rax
 10174bf:	test   %rax,-0x10(%r15)
 10174c3:	je     10174f3 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x753>
 10174c5:	mov    0x2c8(%rbx),%r8d
 10174cc:	mov    %rsp,%rdx
 10174cf:	lea    0x18(%rsp),%rcx
 10174d4:	mov    $0x1009930,%esi
 10174d9:	lea    0x258(%rbx),%rdi
 10174e0:	call   102c1a0 <myl_rc_native_take>
 10174e5:	test   %eax,%eax
 10174e7:	je     1017f74 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x11d4>
 10174ed:	mov    (%rsp),%r15
 10174f1:	jmp    10174f7 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x757>
 10174f3:	mov    %r15,(%rsp)
 10174f7:	mov    %r15,0x1b0(%rsp)
 10174ff:	movl   $0x0,0x48(%rsp)
 1017507:	movq   $0x1009fd8,0x118(%rsp)
 1017513:	mov    %rbp,0x120(%rsp)
 101751b:	lea    0x40(%rsp),%r14
 1017520:	mov    %r14,0x128(%rsp)
 1017528:	movl   $0x2,0x130(%rsp)
 1017533:	mov    %r15,0x60(%rsp)
 1017538:	movq   $0x1009fd8,0xb8(%rsp)
 1017544:	mov    %r12,0xc0(%rsp)
 101754c:	lea    0x28(%rsp),%rax
 1017551:	mov    %rax,0xc8(%rsp)
 1017559:	movl   $0x2,0xd0(%rsp)
 1017564:	movl   $0x0,0x40(%rsp)
 101756c:	movl   $0x1,0x28(%rsp)
 1017574:	mov    %r12,0x18(%rsp)
 1017579:	mov    0x1d8(%rsp),%rsi
 1017581:	mov    %rsi,0x58(%rsp)
 1017586:	movabs $0x8000000000000000,%rdx
 1017590:	cmp    %rdx,%rsi
 1017593:	je     10181e2 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1442>
 1017599:	dec    %rsi
 101759c:	mov    %rsi,0x58(%rsp)
 10175a1:	mov    0x268(%rbx),%rax
 10175a8:	mov    %rax,0x160(%rsp)
 10175b0:	mov    %r12,0x168(%rsp)
 10175b8:	movq   $0x1009fd8,0x170(%rsp)
 10175c4:	lea    0x160(%rsp),%r15
 10175cc:	mov    %r15,0x268(%rbx)
 10175d3:	mov    %rbx,%rdi
 10175d6:	call   1016da0 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531>
 10175db:	mov    0x90(%rsp),%rcx
 10175e3:	mov    %rcx,0x268(%rbx)
 10175ea:	mov    %rax,(%rsp)
 10175ee:	mov    %rdx,0x8(%rsp)
 10175f3:	movq   $0x100a308,0x118(%rsp)
 10175ff:	mov    %rbp,0x120(%rsp)
 1017607:	mov    %r14,0x128(%rsp)
 101760f:	movl   $0x2,0x130(%rsp)
 101761a:	mov    %rax,0x1e0(%rsp)
 1017622:	mov    %rdx,0x1e8(%rsp)
 101762a:	movq   $0x100a308,0xd8(%rsp)
 1017636:	mov    %r13,0xe0(%rsp)
 101763e:	lea    0x30(%rsp),%r14
 1017643:	mov    %r14,0xe8(%rsp)
 101764b:	movl   $0x2,0xf0(%rsp)
 1017656:	movl   $0x0,0x40(%rsp)
 101765e:	movl   $0x1,0x30(%rsp)
 1017666:	mov    %r13,0x58(%rsp)
 101766b:	mov    0x268(%rbx),%rax
 1017672:	mov    0x18(%rsp),%rcx
 1017677:	mov    %rax,0x160(%rsp)
 101767f:	mov    %rcx,0x168(%rsp)
 1017687:	movq   $0x1009fd8,0x170(%rsp)
 1017693:	mov    %r15,0x1b8(%rsp)
 101769b:	mov    %r13,0x1c0(%rsp)
 10176a3:	movq   $0x100a308,0x1c8(%rsp)
 10176af:	lea    0x1b8(%rsp),%rax
 10176b7:	mov    %rax,0x268(%rbx)
 10176be:	mov    0x2c8(%rbx),%ecx
 10176c4:	mov    $0x10098c0,%esi
 10176c9:	mov    $0x1,%edx
 10176ce:	lea    0x258(%rbx),%rdi
 10176d5:	call   1021b10 <myl_native_heap_alloc_at>
 10176da:	test   %rax,%rax
 10176dd:	je     10181f4 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1454>
 10176e3:	mov    %rax,%r15
 10176e6:	mov    %rax,0x158(%rsp)
 10176ee:	movq   $0x1009930,0x138(%rsp)
 10176fa:	lea    0x158(%rsp),%rax
 1017702:	mov    %rax,0x140(%rsp)
 101770a:	lea    0x48(%rsp),%rax
 101770f:	mov    %rax,0x148(%rsp)
 1017717:	movl   $0x4,0x150(%rsp)
 1017722:	movl   $0x1,0x48(%rsp)
 101772a:	mov    0x58(%rsp),%rcx
 101772f:	mov    0x2c8(%rbx),%r8d
 1017736:	mov    %rcx,%rax
 1017739:	sub    %rbp,%rax
 101773c:	mov    %rbp,%rdx
 101773f:	sub    %rcx,%rdx
 1017742:	cmp    $0x10,%rax
 1017746:	setb   %al
 1017749:	cmp    $0x10,%rdx
 101774d:	setb   %dl
 1017750:	or     %al,%dl
 1017752:	jne    101778d <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x9ed>
 1017754:	mov    (%rcx),%rax
 1017757:	test   %rax,%rax
 101775a:	je     101776c <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x9cc>
 101775c:	movabs $0x5000000000000001,%rdx
 1017766:	test   %rdx,-0x10(%rax)
 101776a:	jne    101778d <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x9ed>
 101776c:	mov    0x8(%rcx),%rax
 1017770:	test   %rax,%rax
 1017773:	je     1017932 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xb92>
 1017779:	movabs $0x5000000000000001,%rdx
 1017783:	test   %rdx,-0x10(%rax)
 1017787:	je     1017932 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xb92>
 101778d:	mov    %rsp,%rdx
 1017790:	mov    $0x100a308,%esi
 1017795:	lea    0x258(%rbx),%rdi
 101779c:	call   102c1a0 <myl_rc_native_take>
 10177a1:	test   %eax,%eax
 10177a3:	jne    1017943 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xba3>
 10177a9:	jmp    1017f74 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x11d4>
 10177ae:	mov    %rdx,%r14
 10177b1:	mov    %rax,(%rsp)
 10177b5:	movq   $0x0,0x0(%r13)
 10177bd:	movl   $0x0,0x30(%rsp)
 10177c5:	mov    (%rsp),%rax
 10177c9:	mov    %rax,0x198(%rsp)
 10177d1:	mov    %r15,0x18(%rsp)
 10177d6:	movl   $0x0,0x48(%rsp)
 10177de:	mov    0x190(%rsp),%rax
 10177e6:	mov    %rax,(%rsp)
 10177ea:	mov    0x198(%rsp),%rax
 10177f2:	mov    %rax,0x8(%rsp)
 10177f7:	movq   $0x100a308,0x118(%rsp)
 1017803:	mov    %rbp,0x120(%rsp)
 101780b:	lea    0x40(%rsp),%r15
 1017810:	mov    %r15,0x128(%rsp)
 1017818:	movl   $0x2,0x130(%rsp)
 1017823:	movl   $0x1,0x40(%rsp)
 101782b:	cmpl   $0x0,0x28(%rsp)
 1017830:	je     101785c <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xabc>
 1017832:	mov    %rbx,%rdi
 1017835:	lea    0xb8(%rsp),%rsi
 101783d:	vzeroupper
 1017840:	call   101e890 <myl_qbe_rc_slot_drop>
 1017845:	cmpl   $0x0,0x30(%rsp)
 101784a:	je     101785c <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xabc>
 101784c:	mov    %rbx,%rdi
 101784f:	lea    0xd8(%rsp),%rsi
 1017857:	call   101e890 <myl_qbe_rc_slot_drop>
 101785c:	mov    (%rsp),%rax
 1017860:	mov    %rax,0x60(%rsp)
 1017865:	mov    0x8(%rsp),%rax
 101786a:	mov    %rax,0x68(%rsp)
 101786f:	movq   $0x100a308,0xb8(%rsp)
 101787b:	mov    %r12,0xc0(%rsp)
 1017883:	lea    0x28(%rsp),%rax
 1017888:	mov    %rax,0xc8(%rsp)
 1017890:	movl   $0x2,0xd0(%rsp)
 101789b:	movl   $0x0,0x40(%rsp)
 10178a3:	movl   $0x1,0x28(%rsp)
 10178ab:	mov    %r12,0x18(%rsp)
 10178b0:	mov    0x90(%rsp),%rax
 10178b8:	mov    %rax,0x268(%rbx)
 10178bf:	mov    0x2c8(%rbx),%r8d
 10178c6:	mov    %rbp,%rax
 10178c9:	sub    %r12,%rax
 10178cc:	sub    %rbp,%r12
 10178cf:	cmp    $0x10,%r12
 10178d3:	setb   %cl
 10178d6:	cmp    $0x10,%rax
 10178da:	setb   %al
 10178dd:	or     %cl,%al
 10178df:	jne    1017909 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xb69>
 10178e1:	mov    0x60(%rsp),%rax
 10178e6:	test   %rax,%rax
 10178e9:	je     10178f1 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xb51>
 10178eb:	test   %r14,-0x10(%rax)
 10178ef:	jne    1017909 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xb69>
 10178f1:	mov    0x68(%rsp),%rax
 10178f6:	test   %rax,%rax
 10178f9:	je     1017c4b <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xeab>
 10178ff:	test   %r14,-0x10(%rax)
 1017903:	je     1017c4b <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xeab>
 1017909:	mov    %rsp,%rdx
 101790c:	lea    0x60(%rsp),%rcx
 1017911:	mov    $0x100a308,%esi
 1017916:	lea    0x258(%rbx),%rdi
 101791d:	vzeroupper
 1017920:	call   102c1a0 <myl_rc_native_take>
 1017925:	test   %eax,%eax
 1017927:	jne    1017c60 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xec0>
 101792d:	jmp    1017f74 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x11d4>
 1017932:	vmovups (%rcx),%xmm0
 1017936:	vmovaps %xmm0,(%rsp)
 101793b:	vxorps %xmm0,%xmm0,%xmm0
 101793f:	vmovups %xmm0,(%rcx)
 1017943:	movl   $0x0,0x30(%rsp)
 101794b:	vmovaps (%rsp),%xmm0
 1017950:	vmovups %xmm0,(%r15)
 1017955:	mov    %r15,0x58(%rsp)
 101795a:	movl   $0x0,0x48(%rsp)
 1017962:	mov    %r15,(%rsp)
 1017966:	movq   $0x1009930,0x118(%rsp)
 1017972:	mov    %rbp,0x120(%rsp)
 101797a:	lea    0x40(%rsp),%rax
 101797f:	mov    %rax,0x128(%rsp)
 1017987:	movl   $0x2,0x130(%rsp)
 1017992:	movl   $0x1,0x40(%rsp)
 101799a:	cmpl   $0x0,0x30(%rsp)
 101799f:	je     10179b5 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xc15>
 10179a1:	mov    %rbx,%rdi
 10179a4:	lea    0xd8(%rsp),%rsi
 10179ac:	call   101e890 <myl_qbe_rc_slot_drop>
 10179b1:	mov    (%rsp),%r15
 10179b5:	mov    %r15,0x1e0(%rsp)
 10179bd:	movq   $0x1009930,0xd8(%rsp)
 10179c9:	mov    %r13,0xe0(%rsp)
 10179d1:	mov    %r14,0xe8(%rsp)
 10179d9:	movl   $0x2,0xf0(%rsp)
 10179e4:	movl   $0x0,0x40(%rsp)
 10179ec:	movl   $0x1,0x30(%rsp)
 10179f4:	mov    %r15,0x58(%rsp)
 10179f9:	mov    0x90(%rsp),%rax
 1017a01:	mov    %rax,0x268(%rbx)
 1017a08:	movq   $0x0,0x1a8(%rsp)
 1017a14:	movq   $0x1009fd8,0x138(%rsp)
 1017a20:	lea    0x1a8(%rsp),%rax
 1017a28:	mov    %rax,0x140(%rsp)
 1017a30:	lea    0x48(%rsp),%rax
 1017a35:	mov    %rax,0x148(%rsp)
 1017a3d:	movl   $0x2,0x150(%rsp)
 1017a48:	movl   $0x1,0x48(%rsp)
 1017a50:	test   %r15,%r15
 1017a53:	je     1017a93 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xcf3>
 1017a55:	movabs $0x5000000000000001,%rax
 1017a5f:	test   %rax,-0x10(%r15)
 1017a63:	je     1017a93 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xcf3>
 1017a65:	mov    0x2c8(%rbx),%r8d
 1017a6c:	mov    %rsp,%rdx
 1017a6f:	lea    0x58(%rsp),%rcx
 1017a74:	mov    $0x1009930,%esi
 1017a79:	lea    0x258(%rbx),%rdi
 1017a80:	call   102c1a0 <myl_rc_native_take>
 1017a85:	test   %eax,%eax
 1017a87:	je     1017f74 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x11d4>
 1017a8d:	mov    (%rsp),%r15
 1017a91:	jmp    1017a97 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xcf7>
 1017a93:	mov    %r15,(%rsp)
 1017a97:	mov    %r15,0x1a8(%rsp)
 1017a9f:	movq   $0x1009fd8,0x118(%rsp)
 1017aab:	mov    %rbp,0x120(%rsp)
 1017ab3:	lea    0x40(%rsp),%rax
 1017ab8:	mov    %rax,0x128(%rsp)
 1017ac0:	movl   $0x2,0x130(%rsp)
 1017acb:	mov    %r15,0x1e0(%rsp)
 1017ad3:	movq   $0x1009fd8,0xd8(%rsp)
 1017adf:	mov    %r13,0xe0(%rsp)
 1017ae7:	mov    %r14,0xe8(%rsp)
 1017aef:	movl   $0x2,0xf0(%rsp)
 1017afa:	movl   $0x0,0x40(%rsp)
 1017b02:	movl   $0x1,0x30(%rsp)
 1017b0a:	mov    %r13,0x58(%rsp)
 1017b0f:	mov    0x268(%rbx),%rax
 1017b16:	mov    0x18(%rsp),%rcx
 1017b1b:	mov    %rax,0x160(%rsp)
 1017b23:	mov    %rcx,0x168(%rsp)
 1017b2b:	movq   $0x1009fd8,0x170(%rsp)
 1017b37:	lea    0x160(%rsp),%rax
 1017b3f:	mov    %rax,0x1b8(%rsp)
 1017b47:	mov    %r13,0x1c0(%rsp)
 1017b4f:	movq   $0x1009fd8,0x1c8(%rsp)
 1017b5b:	lea    0x1b8(%rsp),%rax
 1017b63:	mov    %rax,0x268(%rbx)
 1017b6a:	vxorps %xmm0,%xmm0,%xmm0
 1017b6e:	vmovaps %xmm0,0x180(%rsp)
 1017b77:	movq   $0x100a308,0x138(%rsp)
 1017b83:	lea    0x180(%rsp),%r14
 1017b8b:	mov    %r14,0x140(%rsp)
 1017b93:	lea    0x48(%rsp),%rax
 1017b98:	mov    %rax,0x148(%rsp)
 1017ba0:	movl   $0x2,0x150(%rsp)
 1017bab:	movl   $0x1,0x48(%rsp)
 1017bb3:	cmpl   $0x0,0x28(%rsp)
 1017bb8:	mov    0x2c8(%rbx),%r8d
 1017bbf:	je     1017c25 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xe85>
 1017bc1:	mov    %rcx,%rax
 1017bc4:	sub    %rbp,%rax
 1017bc7:	mov    %rbp,%rdx
 1017bca:	sub    %rcx,%rdx
 1017bcd:	cmp    $0x8,%rax
 1017bd1:	setb   %al
 1017bd4:	cmp    $0x8,%rdx
 1017bd8:	setb   %dl
 1017bdb:	or     %al,%dl
 1017bdd:	jne    1017bff <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xe5f>
 1017bdf:	mov    (%rcx),%rax
 1017be2:	test   %rax,%rax
 1017be5:	je     1017d3e <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xf9e>
 1017beb:	movabs $0x5000000000000001,%rdx
 1017bf5:	test   %rdx,-0x10(%rax)
 1017bf9:	je     1017d3e <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xf9e>
 1017bff:	mov    %rsp,%rdx
 1017c02:	mov    $0x1009fd8,%esi
 1017c07:	lea    0x258(%rbx),%rdi
 1017c0e:	call   102c1a0 <myl_rc_native_take>
 1017c13:	test   %eax,%eax
 1017c15:	lea    0x40(%rsp),%r15
 1017c1a:	jne    1017d4e <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xfae>
 1017c20:	jmp    1017f74 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x11d4>
 1017c25:	mov    %rsp,%rdx
 1017c28:	mov    $0x1009fd8,%esi
 1017c2d:	lea    0x258(%rbx),%rdi
 1017c34:	call   102bc30 <myl_rc_native_copy>
 1017c39:	test   %eax,%eax
 1017c3b:	lea    0x40(%rsp),%r15
 1017c40:	jne    1017d56 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xfb6>
 1017c46:	jmp    1017f74 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x11d4>
 1017c4b:	vmovaps 0x60(%rsp),%xmm0
 1017c51:	vmovaps %xmm0,(%rsp)
 1017c56:	vxorps %xmm0,%xmm0,%xmm0
 1017c5a:	vmovaps %xmm0,0x60(%rsp)
 1017c60:	movl   $0x0,0x28(%rsp)
 1017c68:	movq   $0x100a308,0x118(%rsp)
 1017c74:	mov    %rbp,0x120(%rsp)
 1017c7c:	mov    %r15,0x128(%rsp)
 1017c84:	movl   $0x2,0x130(%rsp)
 1017c8f:	movl   $0x0,0x40(%rsp)
 1017c97:	lea    0x70(%rsp),%r12
 1017c9c:	cmp    %r12,0x3d80(%rbx)
 1017ca3:	jne    10181a6 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1406>
 1017ca9:	mov    0x88(%rsp),%rsi
 1017cb1:	lea    0x258(%rbx),%rdi
 1017cb8:	vzeroupper
 1017cbb:	call   1028f10 <myl_rc_scope_unwind>
 1017cc0:	mov    0x80(%rsp),%r14
 1017cc8:	test   %r14,%r14
 1017ccb:	je     1017d0a <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xf6a>
 1017ccd:	mov    %r14,%r15
 1017cd0:	shl    $0x5,%r15
 1017cd4:	add    $0xffffffffffffffe0,%r15
 1017cd8:	jmp    1017cf4 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xf54>
 1017cda:	nopw   0x0(%rax,%rax,1)
 1017ce0:	add    %r15,%rsi
 1017ce3:	mov    %rbx,%rdi
 1017ce6:	call   101e890 <myl_qbe_rc_slot_drop>
 1017ceb:	add    $0xffffffffffffffe0,%r15
 1017cef:	dec    %r14
 1017cf2:	je     1017d0a <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xf6a>
 1017cf4:	mov    0x78(%rsp),%rsi
 1017cf9:	mov    0x10(%rsi,%r15,1),%rax
 1017cfe:	test   %rax,%rax
 1017d01:	je     1017ce0 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xf40>
 1017d03:	cmpl   $0x0,(%rax)
 1017d06:	jne    1017ce0 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xf40>
 1017d08:	jmp    1017ceb <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xf4b>
 1017d0a:	cmp    %r12,0x3d80(%rbx)
 1017d11:	jne    10181a6 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1406>
 1017d17:	mov    0x1860(%rbx),%rax
 1017d1e:	test   %rax,%rax
 1017d21:	je     1018173 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x13d3>
 1017d27:	mov    0x70(%rax),%rax
 1017d2b:	cmp    0x88(%rsp),%rax
 1017d33:	je     101817f <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x13df>
 1017d39:	jmp    10181a6 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1406>
 1017d3e:	mov    %rax,(%rsp)
 1017d42:	movq   $0x0,(%rcx)
 1017d49:	lea    0x40(%rsp),%r15
 1017d4e:	movl   $0x0,0x28(%rsp)
 1017d56:	movq   $0x1009fd8,0x118(%rsp)
 1017d62:	mov    %rbp,0x120(%rsp)
 1017d6a:	mov    %r15,0x128(%rsp)
 1017d72:	movl   $0x2,0x130(%rsp)
 1017d7d:	mov    (%rsp),%rax
 1017d81:	mov    %rax,0x180(%rsp)
 1017d89:	movl   $0x0,0x40(%rsp)
 1017d91:	mov    0x58(%rsp),%rcx
 1017d96:	mov    0x2c8(%rbx),%r8d
 1017d9d:	mov    %rcx,%rax
 1017da0:	sub    %rbp,%rax
 1017da3:	mov    %rbp,%rdx
 1017da6:	sub    %rcx,%rdx
 1017da9:	cmp    $0x8,%rax
 1017dad:	setb   %al
 1017db0:	cmp    $0x8,%rdx
 1017db4:	setb   %dl
 1017db7:	or     %al,%dl
 1017db9:	jne    1017dd3 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1033>
 1017dbb:	mov    (%rcx),%rax
 1017dbe:	test   %rax,%rax
 1017dc1:	je     1017df0 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1050>
 1017dc3:	movabs $0x5000000000000001,%rdx
 1017dcd:	test   %rdx,-0x10(%rax)
 1017dd1:	je     1017df0 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1050>
 1017dd3:	mov    %rsp,%rdx
 1017dd6:	mov    $0x1009fd8,%esi
 1017ddb:	lea    0x258(%rbx),%rdi
 1017de2:	call   102c1a0 <myl_rc_native_take>
 1017de7:	test   %eax,%eax
 1017de9:	jne    1017dfb <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x105b>
 1017deb:	jmp    1017f74 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x11d4>
 1017df0:	mov    %rax,(%rsp)
 1017df4:	movq   $0x0,(%rcx)
 1017dfb:	movl   $0x0,0x30(%rsp)
 1017e03:	mov    (%rsp),%rax
 1017e07:	mov    %rax,0x188(%rsp)
 1017e0f:	mov    %r14,0x18(%rsp)
 1017e14:	movl   $0x0,0x48(%rsp)
 1017e1c:	mov    0x180(%rsp),%rax
 1017e24:	mov    %rax,(%rsp)
 1017e28:	mov    0x188(%rsp),%rax
 1017e30:	mov    %rax,0x8(%rsp)
 1017e35:	movq   $0x100a308,0x118(%rsp)
 1017e41:	mov    %rbp,0x120(%rsp)
 1017e49:	mov    %r15,0x128(%rsp)
 1017e51:	movl   $0x2,0x130(%rsp)
 1017e5c:	movl   $0x1,0x40(%rsp)
 1017e64:	cmpl   $0x0,0x28(%rsp)
 1017e69:	je     1017e92 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x10f2>
 1017e6b:	mov    %rbx,%rdi
 1017e6e:	lea    0xb8(%rsp),%rsi
 1017e76:	call   101e890 <myl_qbe_rc_slot_drop>
 1017e7b:	cmpl   $0x0,0x30(%rsp)
 1017e80:	je     1017e92 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x10f2>
 1017e82:	mov    %rbx,%rdi
 1017e85:	lea    0xd8(%rsp),%rsi
 1017e8d:	call   101e890 <myl_qbe_rc_slot_drop>
 1017e92:	mov    (%rsp),%rax
 1017e96:	mov    %rax,0x60(%rsp)
 1017e9b:	mov    0x8(%rsp),%rax
 1017ea0:	mov    %rax,0x68(%rsp)
 1017ea5:	movq   $0x100a308,0xb8(%rsp)
 1017eb1:	mov    %r12,0xc0(%rsp)
 1017eb9:	lea    0x28(%rsp),%rax
 1017ebe:	mov    %rax,0xc8(%rsp)
 1017ec6:	movl   $0x2,0xd0(%rsp)
 1017ed1:	movl   $0x0,0x40(%rsp)
 1017ed9:	movl   $0x1,0x28(%rsp)
 1017ee1:	mov    %r12,0x18(%rsp)
 1017ee6:	mov    0x90(%rsp),%rax
 1017eee:	mov    %rax,0x268(%rbx)
 1017ef5:	mov    0x2c8(%rbx),%r8d
 1017efc:	mov    %rbp,%rax
 1017eff:	sub    %r12,%rax
 1017f02:	sub    %rbp,%r12
 1017f05:	cmp    $0x10,%r12
 1017f09:	setb   %cl
 1017f0c:	cmp    $0x10,%rax
 1017f10:	setb   %al
 1017f13:	or     %cl,%al
 1017f15:	jne    1017f53 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x11b3>
 1017f17:	mov    0x60(%rsp),%rax
 1017f1c:	test   %rax,%rax
 1017f1f:	je     1017f31 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1191>
 1017f21:	movabs $0x5000000000000001,%rcx
 1017f2b:	test   %rcx,-0x10(%rax)
 1017f2f:	jne    1017f53 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x11b3>
 1017f31:	mov    0x68(%rsp),%rax
 1017f36:	test   %rax,%rax
 1017f39:	je     101809a <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x12fa>
 1017f3f:	movabs $0x5000000000000001,%rcx
 1017f49:	test   %rcx,-0x10(%rax)
 1017f4d:	je     101809a <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x12fa>
 1017f53:	mov    %rsp,%rdx
 1017f56:	lea    0x60(%rsp),%rcx
 1017f5b:	mov    $0x100a308,%esi
 1017f60:	lea    0x258(%rbx),%rdi
 1017f67:	call   102c1a0 <myl_rc_native_take>
 1017f6c:	test   %eax,%eax
 1017f6e:	jne    10180af <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x130f>
 1017f74:	mov    0x1860(%rbx),%rcx
 1017f7b:	test   %rcx,%rcx
 1017f7e:	je     10181a6 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1406>
 1017f84:	mov    0x78(%rcx),%eax
 1017f87:	movl   $0x0,0x78(%rcx)
 1017f8e:	test   %eax,%eax
 1017f90:	lea    0x70(%rsp),%r12
 1017f95:	je     1017fcc <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x122c>
 1017f97:	cmp    $0x1,%eax
 1017f9a:	jne    1017fb1 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1211>
 1017f9c:	mov    $0x100745f,%esi
 1017fa1:	cmpl   $0x0,0x2c4(%rbx)
 1017fa8:	jne    1017fc4 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1224>
 1017faa:	mov    $0x1,%eax
 1017faf:	jmp    1017fba <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x121a>
 1017fb1:	cmp    $0x4,%eax
 1017fb4:	jae    10181ae <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x140e>
 1017fba:	mov    %eax,%eax
 1017fbc:	mov    0x100d2d0(,%rax,8),%rsi
 1017fc4:	mov    %rbx,%rdi
 1017fc7:	call   101f280 <fail>
 1017fcc:	cmp    %r12,0x3d80(%rbx)
 1017fd3:	jne    10181a6 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1406>
 1017fd9:	mov    0x88(%rsp),%rsi
 1017fe1:	lea    0x258(%rbx),%rdi
 1017fe8:	call   1028f10 <myl_rc_scope_unwind>
 1017fed:	mov    0x80(%rsp),%r14
 1017ff5:	test   %r14,%r14
 1017ff8:	je     101803a <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x129a>
 1017ffa:	mov    %r14,%r15
 1017ffd:	shl    $0x5,%r15
 1018001:	add    $0xffffffffffffffe0,%r15
 1018005:	jmp    1018024 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1284>
 1018007:	nopw   0x0(%rax,%rax,1)
 1018010:	add    %r15,%rsi
 1018013:	mov    %rbx,%rdi
 1018016:	call   101e890 <myl_qbe_rc_slot_drop>
 101801b:	add    $0xffffffffffffffe0,%r15
 101801f:	dec    %r14
 1018022:	je     101803a <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x129a>
 1018024:	mov    0x78(%rsp),%rsi
 1018029:	mov    0x10(%rsi,%r15,1),%rax
 101802e:	test   %rax,%rax
 1018031:	je     1018010 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1270>
 1018033:	cmpl   $0x0,(%rax)
 1018036:	jne    1018010 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1270>
 1018038:	jmp    101801b <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x127b>
 101803a:	cmp    %r12,0x3d80(%rbx)
 1018041:	jne    10181a6 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1406>
 1018047:	mov    0x1860(%rbx),%rax
 101804e:	test   %rax,%rax
 1018051:	je     1018066 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x12c6>
 1018053:	mov    0x70(%rax),%rax
 1018057:	cmp    0x88(%rsp),%rax
 101805f:	je     1018076 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x12d6>
 1018061:	jmp    10181a6 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1406>
 1018066:	xor    %eax,%eax
 1018068:	cmp    0x88(%rsp),%rax
 1018070:	jne    10181a6 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1406>
 1018076:	mov    0x70(%rsp),%rax
 101807b:	mov    %rax,0x3d80(%rbx)
 1018082:	mov    0x90(%rsp),%rax
 101808a:	mov    %rax,0x268(%rbx)
 1018091:	xor    %eax,%eax
 1018093:	xor    %edx,%edx
 1018095:	jmp    1018194 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x13f4>
 101809a:	vmovaps 0x60(%rsp),%xmm0
 10180a0:	vmovaps %xmm0,(%rsp)
 10180a5:	vxorps %xmm0,%xmm0,%xmm0
 10180a9:	vmovaps %xmm0,0x60(%rsp)
 10180af:	movl   $0x0,0x28(%rsp)
 10180b7:	movq   $0x100a308,0x118(%rsp)
 10180c3:	mov    %rbp,0x120(%rsp)
 10180cb:	mov    %r15,0x128(%rsp)
 10180d3:	movl   $0x2,0x130(%rsp)
 10180de:	movl   $0x0,0x40(%rsp)
 10180e6:	lea    0x70(%rsp),%r12
 10180eb:	cmp    %r12,0x3d80(%rbx)
 10180f2:	jne    10181a6 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1406>
 10180f8:	mov    0x88(%rsp),%rsi
 1018100:	lea    0x258(%rbx),%rdi
 1018107:	call   1028f10 <myl_rc_scope_unwind>
 101810c:	mov    0x80(%rsp),%r14
 1018114:	test   %r14,%r14
 1018117:	je     101815a <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x13ba>
 1018119:	mov    %r14,%r15
 101811c:	shl    $0x5,%r15
 1018120:	add    $0xffffffffffffffe0,%r15
 1018124:	jmp    1018144 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x13a4>
 1018126:	cs nopw 0x0(%rax,%rax,1)
 1018130:	add    %r15,%rsi
 1018133:	mov    %rbx,%rdi
 1018136:	call   101e890 <myl_qbe_rc_slot_drop>
 101813b:	add    $0xffffffffffffffe0,%r15
 101813f:	dec    %r14
 1018142:	je     101815a <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x13ba>
 1018144:	mov    0x78(%rsp),%rsi
 1018149:	mov    0x10(%rsi,%r15,1),%rax
 101814e:	test   %rax,%rax
 1018151:	je     1018130 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1390>
 1018153:	cmpl   $0x0,(%rax)
 1018156:	jne    1018130 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1390>
 1018158:	jmp    101813b <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x139b>
 101815a:	cmp    %r12,0x3d80(%rbx)
 1018161:	jne    10181a6 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1406>
 1018163:	mov    0x1860(%rbx),%rax
 101816a:	test   %rax,%rax
 101816d:	jne    1017d27 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xf87>
 1018173:	xor    %eax,%eax
 1018175:	cmp    0x88(%rsp),%rax
 101817d:	jne    10181a6 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1406>
 101817f:	mov    0x70(%rsp),%rax
 1018184:	mov    %rax,0x3d80(%rbx)
 101818b:	mov    (%rsp),%rax
 101818f:	mov    0x8(%rsp),%rdx
 1018194:	add    $0x1f8,%rsp
 101819b:	pop    %rbx
 101819c:	pop    %r12
 101819e:	pop    %r13
 10181a0:	pop    %r14
 10181a2:	pop    %r15
 10181a4:	pop    %rbp
 10181a5:	ret
 10181a6:	vzeroupper
 10181a9:	call   1024bd1 <myl_rc_invariant_failed>
 10181ae:	call   102f9c0 <abort@plt>
 10181b3:	mov    %rbx,%rdi
 10181b6:	call   101fa30 <myl_qbe_fail_frame>
 10181bb:	mov    $0x1,%esi
 10181c0:	mov    $0x1,%ecx
 10181c5:	mov    %rbx,%rdi
 10181c8:	movabs $0x8000000000000000,%rdx
 10181d2:	vzeroupper
 10181d5:	call   101f9c0 <myl_qbe_fail_overflow_op>
 10181da:	mov    %rbx,%rdi
 10181dd:	call   101f930 <myl_qbe_fail_allocation>
 10181e2:	mov    $0x1,%esi
 10181e7:	mov    $0x1,%ecx
 10181ec:	mov    %rbx,%rdi
 10181ef:	call   101f9c0 <myl_qbe_fail_overflow_op>
 10181f4:	mov    %rbx,%rdi
 10181f7:	call   101f930 <myl_qbe_fail_allocation>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
