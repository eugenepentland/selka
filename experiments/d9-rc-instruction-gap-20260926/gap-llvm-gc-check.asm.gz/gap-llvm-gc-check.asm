
.tmp-rc/profile/gap-llvm-gc-n12:     file format elf64-x86-64


Disassembly of section .text:

0000000001015bd0 <myl_f_20f65c28671b40937c5bf23acc7c6f37e5a5ec0622e347b57685725df5ba9e50>:
 1015bd0:	push   %r15
 1015bd2:	push   %r14
 1015bd4:	push   %rbx
 1015bd5:	sub    $0x20,%rsp
 1015bd9:	mov    %rdi,%rbx
 1015bdc:	cmp    %rsp,0x40(%rdi)
 1015be0:	ja     1015c41 <myl_f_20f65c28671b40937c5bf23acc7c6f37e5a5ec0622e347b57685725df5ba9e50+0x71>
 1015be2:	mov    (%rsi),%rcx
 1015be5:	mov    $0x1,%eax
 1015bea:	test   %rcx,%rcx
 1015bed:	je     1015c37 <myl_f_20f65c28671b40937c5bf23acc7c6f37e5a5ec0622e347b57685725df5ba9e50+0x67>
 1015bef:	mov    0x8(%rsi),%r15
 1015bf3:	test   %r15,%r15
 1015bf6:	je     1015c37 <myl_f_20f65c28671b40937c5bf23acc7c6f37e5a5ec0622e347b57685725df5ba9e50+0x67>
 1015bf8:	vmovups (%rcx),%xmm0
 1015bfc:	vmovaps %xmm0,0x10(%rsp)
 1015c02:	lea    0x10(%rsp),%rsi
 1015c07:	mov    %rbx,%rdi
 1015c0a:	call   1015bd0 <myl_f_20f65c28671b40937c5bf23acc7c6f37e5a5ec0622e347b57685725df5ba9e50>
 1015c0f:	mov    %rax,%r14
 1015c12:	inc    %r14
 1015c15:	jo     1015c49 <myl_f_20f65c28671b40937c5bf23acc7c6f37e5a5ec0622e347b57685725df5ba9e50+0x79>
 1015c17:	vmovups (%r15),%xmm0
 1015c1c:	vmovaps %xmm0,(%rsp)
 1015c21:	mov    %rsp,%rsi
 1015c24:	mov    %rbx,%rdi
 1015c27:	call   1015bd0 <myl_f_20f65c28671b40937c5bf23acc7c6f37e5a5ec0622e347b57685725df5ba9e50>
 1015c2c:	mov    %rax,%rcx
 1015c2f:	mov    %r14,%rax
 1015c32:	add    %rcx,%rax
 1015c35:	jo     1015c5b <myl_f_20f65c28671b40937c5bf23acc7c6f37e5a5ec0622e347b57685725df5ba9e50+0x8b>
 1015c37:	add    $0x20,%rsp
 1015c3b:	pop    %rbx
 1015c3c:	pop    %r14
 1015c3e:	pop    %r15
 1015c40:	ret
 1015c41:	mov    %rbx,%rdi
 1015c44:	call   101b960 <myl_qbe_fail_frame>
 1015c49:	mov    $0x1,%edx
 1015c4e:	mov    %rbx,%rdi
 1015c51:	xor    %esi,%esi
 1015c53:	mov    %rax,%rcx
 1015c56:	call   101b8f0 <myl_qbe_fail_overflow_op>
 1015c5b:	mov    %rbx,%rdi
 1015c5e:	xor    %esi,%esi
 1015c60:	mov    %r14,%rdx
 1015c63:	call   101b8f0 <myl_qbe_fail_overflow_op>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
