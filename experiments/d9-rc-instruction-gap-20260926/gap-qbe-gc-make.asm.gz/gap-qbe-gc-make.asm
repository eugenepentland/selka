
.tmp-rc/profile/gap-qbe-gc-n12:     file format elf64-x86-64


Disassembly of section .text:

0000000001010bf0 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531>:
 1010bf0:	endbr64
 1010bf4:	push   %rbp
 1010bf5:	mov    %rsp,%rbp
 1010bf8:	sub    $0x98,%rsp
 1010bff:	push   %rbx
 1010c00:	push   %r12
 1010c02:	push   %r13
 1010c04:	push   %r14
 1010c06:	push   %r15
 1010c08:	mov    %rsi,%r13
 1010c0b:	mov    0x40(%rdi),%rax
 1010c0f:	lea    -0x8(%rbp),%rcx
 1010c13:	cmp    %rax,%rcx
 1010c16:	jb     1010ecc <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x2dc>
 1010c1c:	mov    %rdi,%rbx
 1010c1f:	call   1016ae0 <myl_qbe_heap>
 1010c24:	mov    %rbx,%rdi
 1010c27:	mov    %rax,%r12
 1010c2a:	mov    %rdi,%rbx
 1010c2d:	call   10168b0 <myl_qbe_root_mark>
 1010c32:	mov    %r13,%rdx
 1010c35:	mov    %rbx,%rdi
 1010c38:	mov    %rax,%r13
 1010c3b:	cmp    $0x0,%rdx
 1010c3f:	sete   %al
 1010c42:	movzbq %al,%rax
 1010c46:	lea    -0x28(%rbp),%rcx
 1010c4a:	mov    %rcx,%rbx
 1010c4d:	add    $0x8,%rbx
 1010c51:	cmp    $0x0,%eax
 1010c54:	jne    1010ea2 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x2b2>
 1010c5a:	movabs $0x8000000000000001,%rax
 1010c64:	cmp    %rax,%rdx
 1010c67:	jl     1010e8b <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x29b>
 1010c6d:	mov    %rdx,%rsi
 1010c70:	sub    $0x1,%rsi
 1010c74:	mov    %rsi,%r15
 1010c77:	mov    %rdi,%r14
 1010c7a:	call   1010bf0 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531>
 1010c7f:	mov    %r15,%rsi
 1010c82:	mov    %r14,%rdi
 1010c85:	mov    %rax,%rcx
 1010c88:	mov    %rdx,%rax
 1010c8b:	mov    %rcx,-0x88(%rbp)
 1010c92:	mov    %rax,-0x80(%rbp)
 1010c96:	mov    0x510(%r12),%rcx
 1010c9e:	mov    0x518(%r12),%rdx
 1010ca6:	mov    %rcx,%rax
 1010ca9:	add    $0x20,%rax
 1010cad:	cmp    %rdx,%rax
 1010cb0:	setbe  %dl
 1010cb3:	movzbq %dl,%rdx
 1010cb7:	cmp    $0x0,%edx
 1010cba:	jne    1010d17 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x127>
 1010cbc:	mov    0x10(%r12),%rax
 1010cc1:	mov    %rax,-0x68(%rbp)
 1010cc5:	lea    -0x88(%rbp),%rax
 1010ccc:	mov    %rax,-0x60(%rbp)
 1010cd0:	lea    0x1bf59(%rip),%rax        # 102cc30 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 1010cd7:	mov    %rax,-0x58(%rbp)
 1010cdb:	lea    -0x68(%rbp),%rax
 1010cdf:	mov    %rax,0x10(%r12)
 1010ce4:	mov    $0x1,%edx
 1010ce9:	mov    %rsi,%r15
 1010cec:	lea    0x1bd7d(%rip),%rsi        # 102ca70 <myl_t_1e414bd82e4b50b54939760a2d591f88da97e2f1c8252dbd7dcbc73438e46afb_body>
 1010cf3:	mov    %rdi,%r14
 1010cf6:	mov    %r12,%rdi
 1010cf9:	call   101b930 <myl_native_heap_alloc_small>
 1010cfe:	mov    %r15,%rsi
 1010d01:	mov    %r14,%rdi
 1010d04:	cmp    $0x0,%eax
 1010d07:	jne    1010d10 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x120>
 1010d09:	call   1016860 <myl_qbe_fail_allocation>
 1010d0e:	ud2
 1010d10:	mov    %r13,0x10(%r12)
 1010d15:	jmp    1010d48 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x158>
 1010d17:	mov    %rax,0x510(%r12)
 1010d1f:	movq   $0x4,(%rcx)
 1010d26:	lea    0x1bd43(%rip),%rax        # 102ca70 <myl_t_1e414bd82e4b50b54939760a2d591f88da97e2f1c8252dbd7dcbc73438e46afb_body>
 1010d2d:	mov    %rax,0x8(%rcx)
 1010d31:	mov    %rcx,%rax
 1010d34:	add    $0x10,%rax
 1010d38:	movq   $0x0,0x10(%rcx)
 1010d40:	movq   $0x0,0x18(%rcx)
 1010d48:	mov    -0x88(%rbp),%rcx
 1010d4f:	mov    %rcx,(%rax)
 1010d52:	mov    -0x80(%rbp),%rcx
 1010d56:	mov    %rcx,0x8(%rax)
 1010d5a:	mov    %rax,-0x10(%rbp)
 1010d5e:	mov    0x10(%r12),%rax
 1010d63:	mov    %rax,-0x68(%rbp)
 1010d67:	lea    -0x10(%rbp),%rax
 1010d6b:	mov    %rax,-0x60(%rbp)
 1010d6f:	lea    0x1be4a(%rip),%rax        # 102cbc0 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 1010d76:	mov    %rax,-0x58(%rbp)
 1010d7a:	lea    -0x68(%rbp),%rax
 1010d7e:	mov    %rax,0x10(%r12)
 1010d83:	mov    %rdi,%r14
 1010d86:	call   1010bf0 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531>
 1010d8b:	mov    %r14,%rdi
 1010d8e:	mov    %rax,%rcx
 1010d91:	mov    %rdx,%rax
 1010d94:	mov    %rcx,-0x78(%rbp)
 1010d98:	mov    %rax,-0x70(%rbp)
 1010d9c:	mov    %r13,0x10(%r12)
 1010da1:	mov    0x510(%r12),%rcx
 1010da9:	mov    0x518(%r12),%rdx
 1010db1:	mov    %rcx,%rax
 1010db4:	add    $0x20,%rax
 1010db8:	cmp    %rdx,%rax
 1010dbb:	jbe    1010e2e <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x23e>
 1010dbd:	mov    %r13,-0x68(%rbp)
 1010dc1:	lea    -0x10(%rbp),%rax
 1010dc5:	mov    %rax,-0x60(%rbp)
 1010dc9:	lea    0x1bdf0(%rip),%rax        # 102cbc0 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 1010dd0:	mov    %rax,-0x58(%rbp)
 1010dd4:	lea    -0x68(%rbp),%rax
 1010dd8:	mov    %rax,0x10(%r12)
 1010ddd:	lea    -0x68(%rbp),%rax
 1010de1:	mov    %rax,-0x48(%rbp)
 1010de5:	lea    -0x78(%rbp),%rax
 1010de9:	mov    %rax,-0x40(%rbp)
 1010ded:	lea    0x1be3c(%rip),%rax        # 102cc30 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 1010df4:	mov    %rax,-0x38(%rbp)
 1010df8:	lea    -0x48(%rbp),%rax
 1010dfc:	mov    %rax,0x10(%r12)
 1010e01:	mov    $0x1,%edx
 1010e06:	lea    0x1bc63(%rip),%rsi        # 102ca70 <myl_t_1e414bd82e4b50b54939760a2d591f88da97e2f1c8252dbd7dcbc73438e46afb_body>
 1010e0d:	mov    %rdi,%r14
 1010e10:	mov    %r12,%rdi
 1010e13:	call   101b930 <myl_native_heap_alloc_small>
 1010e18:	mov    %r14,%rdi
 1010e1b:	cmp    $0x0,%eax
 1010e1e:	jne    1010e27 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x237>
 1010e20:	call   1016860 <myl_qbe_fail_allocation>
 1010e25:	ud2
 1010e27:	mov    %r13,0x10(%r12)
 1010e2c:	jmp    1010e5f <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x26f>
 1010e2e:	mov    %rax,0x510(%r12)
 1010e36:	movq   $0x4,(%rcx)
 1010e3d:	lea    0x1bc2c(%rip),%rax        # 102ca70 <myl_t_1e414bd82e4b50b54939760a2d591f88da97e2f1c8252dbd7dcbc73438e46afb_body>
 1010e44:	mov    %rax,0x8(%rcx)
 1010e48:	mov    %rcx,%rax
 1010e4b:	add    $0x10,%rax
 1010e4f:	movq   $0x0,0x10(%rcx)
 1010e57:	movq   $0x0,0x18(%rcx)
 1010e5f:	mov    -0x78(%rbp),%rcx
 1010e63:	mov    %rcx,(%rax)
 1010e66:	mov    -0x70(%rbp),%rcx
 1010e6a:	mov    %rcx,0x8(%rax)
 1010e6e:	mov    %rax,-0x18(%rbp)
 1010e72:	mov    -0x10(%rbp),%rax
 1010e76:	mov    %rax,-0x28(%rbp)
 1010e7a:	mov    -0x18(%rbp),%rax
 1010e7e:	mov    %rax,(%rbx)
 1010e81:	mov    -0x28(%rbp),%rax
 1010e85:	mov    -0x20(%rbp),%rdx
 1010e89:	jmp    1010ec1 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x2d1>
 1010e8b:	mov    $0x40,%r8d
 1010e91:	mov    $0x1,%ecx
 1010e96:	mov    $0x1,%esi
 1010e9b:	call   10169a0 <myl_qbe_fail_overflow_op>
 1010ea0:	ud2
 1010ea2:	movq   $0x0,-0x28(%rbp)
 1010eaa:	movq   $0x0,-0x18(%rbp)
 1010eb2:	mov    -0x18(%rbp),%rax
 1010eb6:	mov    %rax,(%rbx)
 1010eb9:	mov    -0x28(%rbp),%rax
 1010ebd:	mov    -0x20(%rbp),%rdx
 1010ec1:	pop    %r15
 1010ec3:	pop    %r14
 1010ec5:	pop    %r13
 1010ec7:	pop    %r12
 1010ec9:	pop    %rbx
 1010eca:	leave
 1010ecb:	ret
 1010ecc:	call   1016af0 <myl_qbe_fail_frame>
 1010ed1:	ud2

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
