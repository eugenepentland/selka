
.tmp-mut-argument/joined-flat-measure/lox-qbe-production:     file format elf64-x86-64


Disassembly of section .text:

000000000132a650 <myl_rc_native_loan>:
 132a650:	push   %rbp
 132a651:	mov    %rsp,%rbp
 132a654:	push   %r15
 132a656:	push   %r14
 132a658:	push   %r13
 132a65a:	push   %r12
 132a65c:	push   %rbx
 132a65d:	sub    $0x28,%rsp
 132a661:	mov    %rcx,-0x38(%rbp)
 132a665:	mov    %rdx,%r14
 132a668:	mov    %rsi,%r12
 132a66b:	mov    %rdi,%rbx
 132a66e:	call   1323060 <myl_rc_descriptor_find>
 132a673:	test   %rax,%rax
 132a676:	je     132a737 <myl_rc_native_loan+0xe7>
 132a67c:	mov    %rax,%r13
 132a67f:	mov    %r12,-0x40(%rbp)
 132a683:	cmpl   $0x0,0x7c(%rax)
 132a687:	je     132a6eb <myl_rc_native_loan+0x9b>
 132a689:	mov    0x0(%r13),%rax
 132a68d:	mov    (%rax),%rdx
 132a690:	test   %rdx,%rdx
 132a693:	je     132a6eb <myl_rc_native_loan+0x9b>
 132a695:	test   %rbx,%rbx
 132a698:	mov    -0x38(%rbp),%rcx
 132a69c:	je     132a8bd <myl_rc_native_loan+0x26d>
 132a6a2:	mov    0x1608(%rbx),%rax
 132a6a9:	test   %rax,%rax
 132a6ac:	je     132a8bd <myl_rc_native_loan+0x26d>
 132a6b2:	cmp    %rcx,%r14
 132a6b5:	je     132a8bd <myl_rc_native_loan+0x26d>
 132a6bb:	test   %rcx,%rcx
 132a6be:	je     132a8bd <myl_rc_native_loan+0x26d>
 132a6c4:	test   %r14,%r14
 132a6c7:	je     132a8bd <myl_rc_native_loan+0x26d>
 132a6cd:	cmpq   $0x0,0x58(%rax)
 132a6d2:	jne    132a8bd <myl_rc_native_loan+0x26d>
 132a6d8:	mov    %r14,%rax
 132a6db:	sub    %rcx,%rax
 132a6de:	ja     132a6e6 <myl_rc_native_loan+0x96>
 132a6e0:	mov    %rcx,%rax
 132a6e3:	sub    %r14,%rax
 132a6e6:	cmp    %rdx,%rax
 132a6e9:	jae    132a760 <myl_rc_native_loan+0x110>
 132a6eb:	mov    0x8(%r13),%r15
 132a6ef:	mov    -0x40(%rbp),%r12
 132a6f3:	test   %r15,%r15
 132a6f6:	je     132a74a <myl_rc_native_loan+0xfa>
 132a6f8:	mov    %rbx,%rdi
 132a6fb:	mov    %r12,%rsi
 132a6fe:	call   1324f20 <myl_rc_native_has_unique>
 132a703:	test   %eax,%eax
 132a705:	jne    132a8bd <myl_rc_native_loan+0x26d>
 132a70b:	mov    %rbx,%rdi
 132a70e:	mov    %r15,%rsi
 132a711:	mov    %r14,%rdx
 132a714:	mov    -0x38(%rbp),%rcx
 132a718:	call   1327990 <myl_rc_loan_copy>
 132a71d:	test   %eax,%eax
 132a71f:	je     132a816 <myl_rc_native_loan+0x1c6>
 132a725:	mov    %rbx,%rdi
 132a728:	mov    %eax,%esi
 132a72a:	call   13223d0 <myl_rc_record_failure>
 132a72f:	xor    %r12d,%r12d
 132a732:	jmp    132a81c <myl_rc_native_loan+0x1cc>
 132a737:	mov    %rbx,%rdi
 132a73a:	mov    %r12,%rsi
 132a73d:	call   1329f70 <myl_rc_native_shape>
 132a742:	mov    %rax,%r15
 132a745:	test   %r15,%r15
 132a748:	jne    132a6f8 <myl_rc_native_loan+0xa8>
 132a74a:	mov    (%r12),%rdx
 132a74e:	xor    %r12d,%r12d
 132a751:	mov    %r14,%rdi
 132a754:	xor    %esi,%esi
 132a756:	call   132aea0 <compiler_rt.fastMemset>
 132a75b:	jmp    132a81c <myl_rc_native_loan+0x1cc>
 132a760:	mov    %rbx,-0x30(%rbp)
 132a764:	mov    %r14,%rdi
 132a767:	mov    -0x38(%rbp),%r15
 132a76b:	mov    %r15,%rsi
 132a76e:	call   132b3a0 <compiler_rt.memcpy.memcpyFast>
 132a773:	cmpl   $0x0,0x78(%r13)
 132a778:	je     132a80d <myl_rc_native_loan+0x1bd>
 132a77e:	xor    %eax,%eax
 132a780:	mov    0x38(%r13,%rax,8),%rcx
 132a785:	movq   $0x0,(%r14,%rcx,1)
 132a78d:	inc    %rax
 132a790:	mov    0x78(%r13),%ecx
 132a794:	cmp    %rcx,%rax
 132a797:	jb     132a780 <myl_rc_native_loan+0x130>
 132a799:	test   %ecx,%ecx
 132a79b:	je     132a80d <myl_rc_native_loan+0x1bd>
 132a79d:	xor    %ebx,%ebx
 132a79f:	nop
 132a7a0:	mov    0x38(%r13,%rbx,8),%rax
 132a7a5:	mov    (%r15,%rax,1),%r12
 132a7a9:	test   %r12,%r12
 132a7ac:	je     132a7d8 <myl_rc_native_loan+0x188>
 132a7ae:	mov    -0x8(%r12),%rsi
 132a7b3:	mov    -0x30(%rbp),%rdi
 132a7b7:	call   1323060 <myl_rc_descriptor_find>
 132a7bc:	testb  $0x2,-0x10(%r12)
 132a7c2:	jne    132a7d8 <myl_rc_native_loan+0x188>
 132a7c4:	test   %rax,%rax
 132a7c7:	je     132a8bd <myl_rc_native_loan+0x26d>
 132a7cd:	cmpq   $0x0,0x18(%rax)
 132a7d2:	jne    132a8bd <myl_rc_native_loan+0x26d>
 132a7d8:	movq   $0x0,-0x48(%rbp)
 132a7e0:	mov    -0x30(%rbp),%rdi
 132a7e4:	mov    %r12,%rsi
 132a7e7:	lea    -0x48(%rbp),%rdx
 132a7eb:	call   1322950 <myl_rc_hold_acquire>
 132a7f0:	test   %eax,%eax
 132a7f2:	jne    132a82e <myl_rc_native_loan+0x1de>
 132a7f4:	mov    0x38(%r13,%rbx,8),%rax
 132a7f9:	mov    %r12,(%r14,%rax,1)
 132a7fd:	inc    %rbx
 132a800:	mov    0x78(%r13),%eax
 132a804:	cmp    %rax,%rbx
 132a807:	mov    -0x38(%rbp),%r15
 132a80b:	jb     132a7a0 <myl_rc_native_loan+0x150>
 132a80d:	mov    -0x30(%rbp),%rdi
 132a811:	call   1324bf0 <myl_rc_drain>
 132a816:	mov    $0x1,%r12d
 132a81c:	mov    %r12d,%eax
 132a81f:	add    $0x28,%rsp
 132a823:	pop    %rbx
 132a824:	pop    %r12
 132a826:	pop    %r13
 132a828:	pop    %r14
 132a82a:	pop    %r15
 132a82c:	pop    %rbp
 132a82d:	ret
 132a82e:	mov    %eax,%r15d
 132a831:	mov    -0x30(%rbp),%rax
 132a835:	mov    0x1608(%rax),%rax
 132a83c:	test   %rax,%rax
 132a83f:	je     132a8bd <myl_rc_native_loan+0x26d>
 132a841:	cmpq   $0x0,0x58(%rax)
 132a846:	jne    132a8bd <myl_rc_native_loan+0x26d>
 132a848:	cmpl   $0x0,0x78(%r13)
 132a84d:	mov    -0x30(%rbp),%r12
 132a851:	je     132a885 <myl_rc_native_loan+0x235>
 132a853:	xor    %ebx,%ebx
 132a855:	data16 cs nopw 0x0(%rax,%rax,1)
 132a860:	mov    0x38(%r13,%rbx,8),%rax
 132a865:	mov    (%r14,%rax,1),%rsi
 132a869:	movq   $0x0,(%r14,%rax,1)
 132a871:	mov    %r12,%rdi
 132a874:	call   13229c0 <myl_rc_hold_edge_release>
 132a879:	inc    %rbx
 132a87c:	mov    0x78(%r13),%eax
 132a880:	cmp    %rax,%rbx
 132a883:	jb     132a860 <myl_rc_native_loan+0x210>
 132a885:	mov    0x0(%r13),%rax
 132a889:	mov    (%rax),%rdx
 132a88c:	mov    %r12,%rbx
 132a88f:	xor    %r12d,%r12d
 132a892:	mov    %r14,%rdi
 132a895:	xor    %esi,%esi
 132a897:	call   132aea0 <compiler_rt.fastMemset>
 132a89c:	mov    %rbx,%rdi
 132a89f:	call   1324bf0 <myl_rc_drain>
 132a8a4:	test   %r15d,%r15d
 132a8a7:	js     132a6eb <myl_rc_native_loan+0x9b>
 132a8ad:	mov    %rbx,%rdi
 132a8b0:	mov    %r15d,%esi
 132a8b3:	call   13223d0 <myl_rc_record_failure>
 132a8b8:	jmp    132a81c <myl_rc_native_loan+0x1cc>
 132a8bd:	call   132226e <myl_rc_invariant_failed>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
