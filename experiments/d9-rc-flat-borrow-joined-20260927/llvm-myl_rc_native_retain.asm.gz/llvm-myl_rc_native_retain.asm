
.tmp-mut-argument/joined-flat-measure/lox-llvm-production:     file format elf64-x86-64


Disassembly of section .text:

00000000012972d0 <myl_rc_native_retain>:
 12972d0:	push   %rbp
 12972d1:	mov    %rsp,%rbp
 12972d4:	push   %r15
 12972d6:	push   %r14
 12972d8:	push   %r13
 12972da:	push   %r12
 12972dc:	push   %rbx
 12972dd:	sub    $0x208,%rsp
 12972e4:	mov    %r8d,-0x2c(%rbp)
 12972e8:	mov    %rcx,%r15
 12972eb:	mov    %rdx,%r14
 12972ee:	mov    %rsi,%r12
 12972f1:	mov    %rdi,%rbx
 12972f4:	test   %rdi,%rdi
 12972f7:	je     12973a7 <myl_rc_native_retain+0xd7>
 12972fd:	mov    0x1608(%rbx),%rax
 1297304:	test   %rax,%rax
 1297307:	sete   %cl
 129730a:	test   %r12,%r12
 129730d:	sete   %dl
 1297310:	or     %cl,%dl
 1297312:	jne    12973a7 <myl_rc_native_retain+0xd7>
 1297318:	mov    0x40(%rax),%rcx
 129731c:	test   %rcx,%rcx
 129731f:	je     12973a7 <myl_rc_native_retain+0xd7>
 1297325:	mov    0x30(%rax),%rdx
 1297329:	mov    %r12,%rsi
 129732c:	shr    $0x3,%rsi
 1297330:	mov    %r12,%rdi
 1297333:	shr    $0x21,%rdi
 1297337:	xor    %rsi,%rdi
 129733a:	movabs $0xbf58476d1ce4e5b9,%r8
 1297344:	imul   %rdi,%r8
 1297348:	mov    %r8,%rsi
 129734b:	shr    $0x1b,%rsi
 129734f:	xor    %r8,%rsi
 1297352:	xor    $0x2,%rsi
 1297356:	dec    %rcx
 1297359:	jmp    1297363 <myl_rc_native_retain+0x93>
 129735b:	nopl   0x0(%rax,%rax,1)
 1297360:	inc    %rsi
 1297363:	and    %rcx,%rsi
 1297366:	lea    (%rsi,%rsi,4),%rdi
 129736a:	mov    (%rdx,%rdi,8),%rdi
 129736e:	test   %rdi,%rdi
 1297371:	je     12973a7 <myl_rc_native_retain+0xd7>
 1297373:	cmp    %r12,%rdi
 1297376:	jne    1297360 <myl_rc_native_retain+0x90>
 1297378:	lea    (%rsi,%rsi,4),%rdi
 129737c:	cmpl   $0x2,0x20(%rdx,%rdi,8)
 1297381:	jne    1297360 <myl_rc_native_retain+0x90>
 1297383:	lea    (%rdx,%rdi,8),%rcx
 1297387:	mov    0x8(%rcx),%rcx
 129738b:	test   %rcx,%rcx
 129738e:	je     12973a7 <myl_rc_native_retain+0xd7>
 1297390:	cmpl   $0x0,0x78(%rcx)
 1297394:	jne    12973a1 <myl_rc_native_retain+0xd1>
 1297396:	cmpq   $0x0,0x60(%rax)
 129739b:	je     129767a <myl_rc_native_retain+0x3aa>
 12973a1:	mov    0x8(%rcx),%r13
 12973a5:	jmp    12973b5 <myl_rc_native_retain+0xe5>
 12973a7:	mov    %rbx,%rdi
 12973aa:	mov    %r12,%rsi
 12973ad:	call   1296130 <myl_rc_native_shape>
 12973b2:	mov    %rax,%r13
 12973b5:	test   %r13,%r13
 12973b8:	je     12974de <myl_rc_native_retain+0x20e>
 12973be:	mov    %rbx,%rdi
 12973c1:	mov    %r12,%rsi
 12973c4:	call   1290010 <myl_rc_native_has_unique>
 12973c9:	test   %eax,%eax
 12973cb:	jne    12976e4 <myl_rc_native_retain+0x414>
 12973d1:	mov    (%r12),%rdx
 12973d5:	mov    %r14,%rdi
 12973d8:	xor    %esi,%esi
 12973da:	call   129aa70 <memset@plt>
 12973df:	test   %rbx,%rbx
 12973e2:	je     12976e4 <myl_rc_native_retain+0x414>
 12973e8:	mov    0x1608(%rbx),%rcx
 12973ef:	test   %rcx,%rcx
 12973f2:	je     12976e4 <myl_rc_native_retain+0x414>
 12973f8:	movabs $0xbf58476d1ce4e5b9,%rax
 1297402:	vxorps %xmm0,%xmm0,%xmm0
 1297406:	vmovups %ymm0,-0x90(%rbp)
 129740e:	vmovups %ymm0,-0xb0(%rbp)
 1297416:	vmovups %ymm0,-0xd0(%rbp)
 129741e:	vmovups %ymm0,-0xf0(%rbp)
 1297426:	vmovups %ymm0,-0x110(%rbp)
 129742e:	vmovups %ymm0,-0x130(%rbp)
 1297436:	movq   $0x0,-0x70(%rbp)
 129743e:	mov    %rbx,-0x60(%rbp)
 1297442:	lea    -0x230(%rbp),%rdx
 1297449:	mov    %rdx,-0x58(%rbp)
 129744d:	movq   $0x8,-0x50(%rbp)
 1297455:	vxorps %xmm0,%xmm0,%xmm0
 1297459:	vmovups %xmm0,-0x48(%rbp)
 129745e:	lea    -0x130(%rbp),%rdx
 1297465:	mov    %rdx,-0x38(%rbp)
 1297469:	mov    0x40(%rcx),%rdx
 129746d:	test   %rdx,%rdx
 1297470:	je     12974f4 <myl_rc_native_retain+0x224>
 1297476:	mov    0x30(%rcx),%r9
 129747a:	mov    %r13,%rdi
 129747d:	shr    $0x3,%rdi
 1297481:	mov    %r13,%r8
 1297484:	shr    $0x21,%r8
 1297488:	xor    %rdi,%r8
 129748b:	imul   %rax,%r8
 129748f:	mov    %r8,%rdi
 1297492:	shr    $0x1b,%rdi
 1297496:	xor    %r8,%rdi
 1297499:	xor    $0x1,%rdi
 129749d:	dec    %rdx
 12974a0:	and    %rdx,%rdi
 12974a3:	lea    (%rdi,%rdi,4),%r8
 12974a7:	mov    (%r9,%r8,8),%r8
 12974ab:	xor    %esi,%esi
 12974ad:	jmp    12974be <myl_rc_native_retain+0x1ee>
 12974af:	nop
 12974b0:	inc    %rdi
 12974b3:	and    %rdx,%rdi
 12974b6:	lea    (%rdi,%rdi,4),%r8
 12974ba:	mov    (%r9,%r8,8),%r8
 12974be:	test   %r8,%r8
 12974c1:	je     12974f6 <myl_rc_native_retain+0x226>
 12974c3:	cmp    %r13,%r8
 12974c6:	jne    12974b0 <myl_rc_native_retain+0x1e0>
 12974c8:	lea    (%rdi,%rdi,4),%r8
 12974cc:	cmpl   $0x1,0x20(%r9,%r8,8)
 12974d2:	jne    12974b0 <myl_rc_native_retain+0x1e0>
 12974d4:	lea    (%r9,%r8,8),%rdx
 12974d8:	mov    0x8(%rdx),%rsi
 12974dc:	jmp    12974f6 <myl_rc_native_retain+0x226>
 12974de:	mov    (%r12),%rdx
 12974e2:	xor    %r12d,%r12d
 12974e5:	mov    %r14,%rdi
 12974e8:	xor    %esi,%esi
 12974ea:	call   129aa70 <memset@plt>
 12974ef:	jmp    1297652 <myl_rc_native_retain+0x382>
 12974f4:	xor    %esi,%esi
 12974f6:	mov    0x40(%rcx),%rdx
 12974fa:	test   %rdx,%rdx
 12974fd:	je     12976e4 <myl_rc_native_retain+0x414>
 1297503:	mov    0x30(%rcx),%rcx
 1297507:	mov    %r13,%r8
 129750a:	shr    $0x3,%r8
 129750e:	mov    %r13,%rdi
 1297511:	shr    $0x21,%rdi
 1297515:	xor    %r8,%rdi
 1297518:	imul   %rax,%rdi
 129751c:	mov    %rdi,%rax
 129751f:	shr    $0x1b,%rax
 1297523:	xor    %rdi,%rax
 1297526:	xor    $0x1,%rax
 129752a:	dec    %rdx
 129752d:	jmp    1297533 <myl_rc_native_retain+0x263>
 129752f:	nop
 1297530:	inc    %rax
 1297533:	and    %rdx,%rax
 1297536:	lea    (%rax,%rax,4),%rdi
 129753a:	mov    (%rcx,%rdi,8),%rdi
 129753e:	test   %rdi,%rdi
 1297541:	je     12976e4 <myl_rc_native_retain+0x414>
 1297547:	cmp    %r13,%rdi
 129754a:	jne    1297530 <myl_rc_native_retain+0x260>
 129754c:	lea    (%rax,%rax,4),%rdi
 1297550:	cmpl   $0x1,0x20(%rcx,%rdi,8)
 1297555:	jne    1297530 <myl_rc_native_retain+0x260>
 1297557:	test   %rsi,%rsi
 129755a:	je     12976e4 <myl_rc_native_retain+0x414>
 1297560:	lea    (%rcx,%rdi,8),%rax
 1297564:	mov    0x8(%rax),%rax
 1297568:	test   %rax,%rax
 129756b:	je     12976e4 <myl_rc_native_retain+0x414>
 1297571:	mov    (%rsi),%rcx
 1297574:	cmp    (%rax),%rcx
 1297577:	jne    12976e4 <myl_rc_native_retain+0x414>
 129757d:	cmp    %r14,%r15
 1297580:	je     12976e4 <myl_rc_native_retain+0x414>
 1297586:	mov    %r15,%r12
 1297589:	mov    $0x3,%r15d
 129758f:	mov    -0x2c(%rbp),%eax
 1297592:	cmp    0x70(%rbx),%eax
 1297595:	ja     1297624 <myl_rc_native_retain+0x354>
 129759b:	lea    -0x60(%rbp),%rdi
 129759f:	mov    %rsi,%r15
 12975a2:	vzeroupper
 12975a5:	call   1293370 <prepare_frames>
 12975aa:	mov    %r15,%rsi
 12975ad:	mov    $0x1,%r15d
 12975b3:	test   %eax,%eax
 12975b5:	jne    1297624 <myl_rc_native_retain+0x354>
 12975b7:	mov    $0x1,%r8d
 12975bd:	mov    %rbx,%rdi
 12975c0:	mov    %r14,%rdx
 12975c3:	mov    %r12,%r15
 12975c6:	mov    %r12,%rcx
 12975c9:	mov    %rsi,%r12
 12975cc:	call   12901e0 <myl_rc_value_seed>
 12975d1:	mov    -0x2c(%rbp),%eax
 12975d4:	mov    %eax,-0x40(%rbp)
 12975d7:	lea    -0x60(%rbp),%rdi
 12975db:	mov    $0x1294d80,%r8d
 12975e1:	mov    %r12,%rsi
 12975e4:	mov    %r14,%rdx
 12975e7:	mov    %r15,%rcx
 12975ea:	call   1293530 <visit>
 12975ef:	test   %eax,%eax
 12975f1:	jne    1297600 <myl_rc_native_retain+0x330>
 12975f3:	lea    -0x60(%rbp),%rdi
 12975f7:	call   1294320 <finish_clones>
 12975fc:	test   %eax,%eax
 12975fe:	je     1297667 <myl_rc_native_retain+0x397>
 1297600:	mov    %eax,%r15d
 1297603:	mov    $0x1,%ecx
 1297608:	mov    %rbx,%rdi
 129760b:	mov    %r13,%rsi
 129760e:	mov    %r14,%rdx
 1297611:	call   128f640 <myl_rc_edges_release>
 1297616:	mov    0x0(%r13),%rdx
 129761a:	mov    %r14,%rdi
 129761d:	xor    %esi,%esi
 129761f:	call   129aa70 <memset@plt>
 1297624:	lea    -0x60(%rbp),%rdi
 1297628:	mov    $0x1,%esi
 129762d:	vzeroupper
 1297630:	call   12946c0 <dispose_walk>
 1297635:	mov    0x1608(%rbx),%rax
 129763c:	test   %rax,%rax
 129763f:	je     12976e4 <myl_rc_native_retain+0x414>
 1297645:	xor    %r12d,%r12d
 1297648:	cmpl   $0x0,0x78(%rax)
 129764c:	jne    1297652 <myl_rc_native_retain+0x382>
 129764e:	mov    %r15d,0x78(%rax)
 1297652:	mov    %r12d,%eax
 1297655:	add    $0x208,%rsp
 129765c:	pop    %rbx
 129765d:	pop    %r12
 129765f:	pop    %r13
 1297661:	pop    %r14
 1297663:	pop    %r15
 1297665:	pop    %rbp
 1297666:	ret
 1297667:	lea    -0x60(%rbp),%rdi
 129766b:	xor    %esi,%esi
 129766d:	call   12946c0 <dispose_walk>
 1297672:	mov    $0x1,%r12d
 1297678:	jmp    1297652 <myl_rc_native_retain+0x382>
 129767a:	mov    (%r12),%rdx
 129767e:	test   %rdx,%rdx
 1297681:	je     12973a1 <myl_rc_native_retain+0xd1>
 1297687:	mov    %r14,%rax
 129768a:	sub    %r15,%rax
 129768d:	ja     1297695 <myl_rc_native_retain+0x3c5>
 129768f:	mov    %r15,%rax
 1297692:	sub    %r14,%rax
 1297695:	cmp    %rdx,%rax
 1297698:	jb     12973a1 <myl_rc_native_retain+0xd1>
 129769e:	mov    -0x2c(%rbp),%eax
 12976a1:	cmp    0x70(%rbx),%eax
 12976a4:	jbe    12976ce <myl_rc_native_retain+0x3fe>
 12976a6:	xor    %r12d,%r12d
 12976a9:	mov    %r14,%rdi
 12976ac:	xor    %esi,%esi
 12976ae:	call   129aa70 <memset@plt>
 12976b3:	mov    0x1608(%rbx),%rax
 12976ba:	test   %rax,%rax
 12976bd:	je     12976e4 <myl_rc_native_retain+0x414>
 12976bf:	cmpl   $0x0,0x78(%rax)
 12976c3:	jne    1297652 <myl_rc_native_retain+0x382>
 12976c5:	movl   $0x3,0x78(%rax)
 12976cc:	jmp    1297652 <myl_rc_native_retain+0x382>
 12976ce:	mov    %r14,%rdi
 12976d1:	mov    %r15,%rsi
 12976d4:	call   129aa60 <memcpy@plt>
 12976d9:	mov    $0x1,%r12d
 12976df:	jmp    1297652 <myl_rc_native_retain+0x382>
 12976e4:	vzeroupper
 12976e7:	call   128d50e <myl_rc_invariant_failed>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
