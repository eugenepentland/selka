
.tmp-mut-argument/joined-flat-measure/lox-llvm-production:     file format elf64-x86-64


Disassembly of section .text:

0000000001296c10 <myl_rc_native_loan>:
 1296c10:	push   %rbp
 1296c11:	mov    %rsp,%rbp
 1296c14:	push   %r15
 1296c16:	push   %r14
 1296c18:	push   %r13
 1296c1a:	push   %r12
 1296c1c:	push   %rbx
 1296c1d:	sub    $0x208,%rsp
 1296c24:	mov    %rcx,%r15
 1296c27:	mov    %rdx,%r14
 1296c2a:	mov    %rsi,%r12
 1296c2d:	mov    %rdi,%rbx
 1296c30:	test   %rdi,%rdi
 1296c33:	je     1296d26 <myl_rc_native_loan+0x116>
 1296c39:	mov    0x1608(%rbx),%rax
 1296c40:	test   %rax,%rax
 1296c43:	sete   %cl
 1296c46:	test   %r12,%r12
 1296c49:	sete   %dl
 1296c4c:	or     %cl,%dl
 1296c4e:	jne    1296d26 <myl_rc_native_loan+0x116>
 1296c54:	mov    0x40(%rax),%rcx
 1296c58:	test   %rcx,%rcx
 1296c5b:	je     1296d26 <myl_rc_native_loan+0x116>
 1296c61:	movabs $0xbf58476d1ce4e5b9,%r8
 1296c6b:	mov    0x30(%rax),%rdx
 1296c6f:	mov    %r12,%rsi
 1296c72:	shr    $0x3,%rsi
 1296c76:	mov    %r12,%rdi
 1296c79:	shr    $0x21,%rdi
 1296c7d:	xor    %rsi,%rdi
 1296c80:	imul   %r8,%rdi
 1296c84:	mov    %rdi,%rsi
 1296c87:	shr    $0x1b,%rsi
 1296c8b:	xor    %rdi,%rsi
 1296c8e:	xor    $0x2,%rsi
 1296c92:	dec    %rcx
 1296c95:	jmp    1296ca3 <myl_rc_native_loan+0x93>
 1296c97:	nopw   0x0(%rax,%rax,1)
 1296ca0:	inc    %rsi
 1296ca3:	and    %rcx,%rsi
 1296ca6:	lea    (%rsi,%rsi,4),%rdi
 1296caa:	mov    (%rdx,%rdi,8),%rdi
 1296cae:	test   %rdi,%rdi
 1296cb1:	je     1296d26 <myl_rc_native_loan+0x116>
 1296cb3:	cmp    %r12,%rdi
 1296cb6:	jne    1296ca0 <myl_rc_native_loan+0x90>
 1296cb8:	lea    (%rsi,%rsi,4),%rdi
 1296cbc:	cmpl   $0x2,0x20(%rdx,%rdi,8)
 1296cc1:	jne    1296ca0 <myl_rc_native_loan+0x90>
 1296cc3:	lea    (%rdx,%rdi,8),%rcx
 1296cc7:	mov    0x8(%rcx),%r13
 1296ccb:	test   %r13,%r13
 1296cce:	je     1296d26 <myl_rc_native_loan+0x116>
 1296cd0:	cmpl   $0x0,0x7c(%r13)
 1296cd5:	je     1296d20 <myl_rc_native_loan+0x110>
 1296cd7:	mov    0x0(%r13),%rcx
 1296cdb:	mov    (%rcx),%rdx
 1296cde:	test   %rdx,%rdx
 1296ce1:	je     1296d20 <myl_rc_native_loan+0x110>
 1296ce3:	cmp    %r15,%r14
 1296ce6:	je     12970bc <myl_rc_native_loan+0x4ac>
 1296cec:	test   %r15,%r15
 1296cef:	je     12970bc <myl_rc_native_loan+0x4ac>
 1296cf5:	test   %r14,%r14
 1296cf8:	je     12970bc <myl_rc_native_loan+0x4ac>
 1296cfe:	cmpq   $0x0,0x58(%rax)
 1296d03:	jne    12970bc <myl_rc_native_loan+0x4ac>
 1296d09:	mov    %r14,%rax
 1296d0c:	sub    %r15,%rax
 1296d0f:	ja     1296d17 <myl_rc_native_loan+0x107>
 1296d11:	mov    %r15,%rax
 1296d14:	sub    %r14,%rax
 1296d17:	cmp    %rdx,%rax
 1296d1a:	jae    1296f54 <myl_rc_native_loan+0x344>
 1296d20:	mov    0x8(%r13),%r13
 1296d24:	jmp    1296d34 <myl_rc_native_loan+0x124>
 1296d26:	mov    %rbx,%rdi
 1296d29:	mov    %r12,%rsi
 1296d2c:	call   1296130 <myl_rc_native_shape>
 1296d31:	mov    %rax,%r13
 1296d34:	test   %r13,%r13
 1296d37:	je     1296f1b <myl_rc_native_loan+0x30b>
 1296d3d:	mov    %rbx,%rdi
 1296d40:	mov    %r12,%rsi
 1296d43:	call   1290010 <myl_rc_native_has_unique>
 1296d48:	test   %eax,%eax
 1296d4a:	jne    12970bc <myl_rc_native_loan+0x4ac>
 1296d50:	test   %rbx,%rbx
 1296d53:	je     12970bc <myl_rc_native_loan+0x4ac>
 1296d59:	cmp    %r15,%r14
 1296d5c:	je     12970bc <myl_rc_native_loan+0x4ac>
 1296d62:	test   %r15,%r15
 1296d65:	je     12970bc <myl_rc_native_loan+0x4ac>
 1296d6b:	test   %r14,%r14
 1296d6e:	je     12970bc <myl_rc_native_loan+0x4ac>
 1296d74:	mov    0x1608(%rbx),%rcx
 1296d7b:	test   %rcx,%rcx
 1296d7e:	je     12970bc <myl_rc_native_loan+0x4ac>
 1296d84:	mov    0x40(%rcx),%rax
 1296d88:	test   %rax,%rax
 1296d8b:	je     12970bc <myl_rc_native_loan+0x4ac>
 1296d91:	mov    0x30(%rcx),%rcx
 1296d95:	mov    %r13,%rdx
 1296d98:	shr    $0x3,%rdx
 1296d9c:	mov    %r13,%rsi
 1296d9f:	shr    $0x21,%rsi
 1296da3:	xor    %rdx,%rsi
 1296da6:	movabs $0xbf58476d1ce4e5b9,%rdi
 1296db0:	imul   %rsi,%rdi
 1296db4:	mov    %rdi,%rdx
 1296db7:	shr    $0x1b,%rdx
 1296dbb:	xor    %rdi,%rdx
 1296dbe:	xor    $0x1,%rdx
 1296dc2:	dec    %rax
 1296dc5:	jmp    1296dd3 <myl_rc_native_loan+0x1c3>
 1296dc7:	nopw   0x0(%rax,%rax,1)
 1296dd0:	inc    %rdx
 1296dd3:	and    %rax,%rdx
 1296dd6:	lea    (%rdx,%rdx,4),%rsi
 1296dda:	mov    (%rcx,%rsi,8),%rsi
 1296dde:	test   %rsi,%rsi
 1296de1:	je     12970bc <myl_rc_native_loan+0x4ac>
 1296de7:	cmp    %r13,%rsi
 1296dea:	jne    1296dd0 <myl_rc_native_loan+0x1c0>
 1296dec:	lea    (%rdx,%rdx,4),%rsi
 1296df0:	cmpl   $0x1,0x20(%rcx,%rsi,8)
 1296df5:	jne    1296dd0 <myl_rc_native_loan+0x1c0>
 1296df7:	lea    (%rcx,%rsi,8),%rax
 1296dfb:	mov    0x8(%rax),%r12
 1296dff:	test   %r12,%r12
 1296e02:	je     12970bc <myl_rc_native_loan+0x4ac>
 1296e08:	mov    %r14,%rax
 1296e0b:	mov    (%r12),%rdx
 1296e0f:	sub    %r15,%rax
 1296e12:	ja     1296e1a <myl_rc_native_loan+0x20a>
 1296e14:	mov    %r15,%rax
 1296e17:	sub    %r14,%rax
 1296e1a:	cmp    %rdx,%rax
 1296e1d:	jb     12970bc <myl_rc_native_loan+0x4ac>
 1296e23:	vxorps %xmm0,%xmm0,%xmm0
 1296e27:	vmovups %ymm0,-0x90(%rbp)
 1296e2f:	vmovups %ymm0,-0xb0(%rbp)
 1296e37:	vmovups %ymm0,-0xd0(%rbp)
 1296e3f:	vmovups %ymm0,-0xf0(%rbp)
 1296e47:	vmovups %ymm0,-0x110(%rbp)
 1296e4f:	vmovups %ymm0,-0x130(%rbp)
 1296e57:	movq   $0x0,-0x70(%rbp)
 1296e5f:	mov    %rbx,-0x60(%rbp)
 1296e63:	lea    -0x230(%rbp),%rax
 1296e6a:	mov    %rax,-0x58(%rbp)
 1296e6e:	movq   $0x8,-0x50(%rbp)
 1296e76:	vxorps %xmm0,%xmm0,%xmm0
 1296e7a:	vmovups %xmm0,-0x48(%rbp)
 1296e7f:	lea    -0x130(%rbp),%rax
 1296e86:	mov    %rax,-0x38(%rbp)
 1296e8a:	mov    %r14,%rdi
 1296e8d:	xor    %esi,%esi
 1296e8f:	vzeroupper
 1296e92:	call   129aa70 <memset@plt>
 1296e97:	lea    -0x60(%rbp),%rdi
 1296e9b:	mov    %r12,%rsi
 1296e9e:	call   1293370 <prepare_frames>
 1296ea3:	mov    $0x1,%r13d
 1296ea9:	test   %eax,%eax
 1296eab:	jne    1296ef1 <myl_rc_native_loan+0x2e1>
 1296ead:	mov    $0x1,%r8d
 1296eb3:	mov    %rbx,%rdi
 1296eb6:	mov    %r12,%rsi
 1296eb9:	mov    %r14,%rdx
 1296ebc:	mov    %r15,%rcx
 1296ebf:	call   12901e0 <myl_rc_value_seed>
 1296ec4:	lea    -0x60(%rbp),%rdi
 1296ec8:	mov    $0x1294c30,%r8d
 1296ece:	mov    %r12,%rsi
 1296ed1:	mov    %r14,%rdx
 1296ed4:	mov    %r15,%rcx
 1296ed7:	call   1293530 <visit>
 1296edc:	test   %eax,%eax
 1296ede:	je     1296f41 <myl_rc_native_loan+0x331>
 1296ee0:	mov    %eax,%r13d
 1296ee3:	mov    %rbx,%rdi
 1296ee6:	mov    %r12,%rsi
 1296ee9:	mov    %r14,%rdx
 1296eec:	call   128ff00 <myl_rc_loan_drop>
 1296ef1:	lea    -0x60(%rbp),%rdi
 1296ef5:	xor    %r15d,%r15d
 1296ef8:	xor    %esi,%esi
 1296efa:	call   12946c0 <dispose_walk>
 1296eff:	mov    0x1608(%rbx),%rax
 1296f06:	test   %rax,%rax
 1296f09:	je     12970bc <myl_rc_native_loan+0x4ac>
 1296f0f:	cmpl   $0x0,0x78(%rax)
 1296f13:	jne    1296f2c <myl_rc_native_loan+0x31c>
 1296f15:	mov    %r13d,0x78(%rax)
 1296f19:	jmp    1296f2c <myl_rc_native_loan+0x31c>
 1296f1b:	mov    (%r12),%rdx
 1296f1f:	xor    %r15d,%r15d
 1296f22:	mov    %r14,%rdi
 1296f25:	xor    %esi,%esi
 1296f27:	call   129aa70 <memset@plt>
 1296f2c:	mov    %r15d,%eax
 1296f2f:	add    $0x208,%rsp
 1296f36:	pop    %rbx
 1296f37:	pop    %r12
 1296f39:	pop    %r13
 1296f3b:	pop    %r14
 1296f3d:	pop    %r15
 1296f3f:	pop    %rbp
 1296f40:	ret
 1296f41:	lea    -0x60(%rbp),%rdi
 1296f45:	xor    %esi,%esi
 1296f47:	call   12946c0 <dispose_walk>
 1296f4c:	mov    $0x1,%r15d
 1296f52:	jmp    1296f2c <myl_rc_native_loan+0x31c>
 1296f54:	mov    %r14,%rdi
 1296f57:	mov    %r15,%rsi
 1296f5a:	call   129aa60 <memcpy@plt>
 1296f5f:	cmpl   $0x0,0x78(%r13)
 1296f64:	je     12970c1 <myl_rc_native_loan+0x4b1>
 1296f6a:	xor    %eax,%eax
 1296f6c:	mov    0x38(%r13,%rax,8),%rcx
 1296f71:	movq   $0x0,(%r14,%rcx,1)
 1296f79:	inc    %rax
 1296f7c:	mov    0x78(%r13),%ecx
 1296f80:	cmp    %rcx,%rax
 1296f83:	jb     1296f6c <myl_rc_native_loan+0x35c>
 1296f85:	test   %ecx,%ecx
 1296f87:	je     12970c1 <myl_rc_native_loan+0x4b1>
 1296f8d:	mov    $0x1,%edx
 1296f92:	movabs $0x4000000000000002,%r11
 1296f9c:	xor    %ecx,%ecx
 1296f9e:	jmp    1296fbd <myl_rc_native_loan+0x3ad>
 1296fa0:	test   %r11,%r9
 1296fa3:	je     129705e <myl_rc_native_loan+0x44e>
 1296fa9:	mov    %rsi,(%r14,%r8,1)
 1296fad:	inc    %rcx
 1296fb0:	mov    0x78(%r13),%edx
 1296fb4:	cmp    %rdx,%rcx
 1296fb7:	jae    12970c1 <myl_rc_native_loan+0x4b1>
 1296fbd:	mov    0x38(%r13,%rcx,8),%r8
 1296fc2:	mov    (%r15,%r8,1),%rsi
 1296fc6:	test   %rsi,%rsi
 1296fc9:	je     1296fa9 <myl_rc_native_loan+0x399>
 1296fcb:	mov    -0x8(%rsi),%r9
 1296fcf:	mov    0x1608(%rbx),%rdi
 1296fd6:	test   %rdi,%rdi
 1296fd9:	sete   %al
 1296fdc:	test   %r9,%r9
 1296fdf:	sete   %r10b
 1296fe3:	or     %al,%r10b
 1296fe6:	jne    1297059 <myl_rc_native_loan+0x449>
 1296fe8:	mov    0x40(%rdi),%r10
 1296fec:	test   %r10,%r10
 1296fef:	je     1297059 <myl_rc_native_loan+0x449>
 1296ff1:	mov    %rdi,-0x30(%rbp)
 1296ff5:	mov    0x30(%rdi),%r11
 1296ff9:	mov    %r9,%rax
 1296ffc:	shr    $0x3,%rax
 1297000:	mov    %r9,%rdi
 1297003:	shr    $0x21,%rdi
 1297007:	xor    %rax,%rdi
 129700a:	movabs $0xbf58476d1ce4e5b9,%rax
 1297014:	imul   %rax,%rdi
 1297018:	mov    %rdi,%r12
 129701b:	shr    $0x1b,%r12
 129701f:	xor    %rdi,%r12
 1297022:	xor    $0x2,%r12
 1297026:	dec    %r10
 1297029:	jmp    129702e <myl_rc_native_loan+0x41e>
 129702b:	inc    %r12
 129702e:	and    %r10,%r12
 1297031:	lea    (%r12,%r12,4),%rax
 1297035:	mov    (%r11,%rax,8),%rax
 1297039:	test   %rax,%rax
 129703c:	je     129708d <myl_rc_native_loan+0x47d>
 129703e:	cmp    %r9,%rax
 1297041:	jne    129702b <myl_rc_native_loan+0x41b>
 1297043:	lea    (%r12,%r12,4),%rax
 1297047:	cmpl   $0x2,0x20(%r11,%rax,8)
 129704d:	jne    129702b <myl_rc_native_loan+0x41b>
 129704f:	lea    (%r11,%rax,8),%rax
 1297053:	mov    0x8(%rax),%r10
 1297057:	jmp    1297090 <myl_rc_native_loan+0x480>
 1297059:	xor    %r10d,%r10d
 129705c:	jmp    129709e <myl_rc_native_loan+0x48e>
 129705e:	test   %rdi,%rdi
 1297061:	je     12970bc <myl_rc_native_loan+0x4ac>
 1297063:	test   $0x1,%r9b
 1297067:	jne    12970bc <myl_rc_native_loan+0x4ac>
 1297069:	mov    -0x18(%rsi),%r8
 129706d:	mov    -0x20(%rsi),%rax
 1297071:	or     %r8,%rax
 1297074:	je     12970bc <myl_rc_native_loan+0x4ac>
 1297076:	cmp    $0xffffffffffffffff,%r8
 129707a:	je     12970d4 <myl_rc_native_loan+0x4c4>
 129707c:	inc    %r8
 129707f:	mov    %r8,-0x18(%rsi)
 1297083:	mov    0x38(%r13,%rcx,8),%r8
 1297088:	jmp    1296fa9 <myl_rc_native_loan+0x399>
 129708d:	xor    %r10d,%r10d
 1297090:	movabs $0x4000000000000002,%r11
 129709a:	mov    -0x30(%rbp),%rdi
 129709e:	mov    -0x10(%rsi),%r9
 12970a2:	test   $0x2,%r9b
 12970a6:	jne    1296fa0 <myl_rc_native_loan+0x390>
 12970ac:	test   %r10,%r10
 12970af:	je     12970bc <myl_rc_native_loan+0x4ac>
 12970b1:	cmpq   $0x0,0x18(%r10)
 12970b6:	je     1296fa0 <myl_rc_native_loan+0x390>
 12970bc:	call   128d50e <myl_rc_invariant_failed>
 12970c1:	mov    %rbx,%rdi
 12970c4:	call   128fb60 <myl_rc_drain>
 12970c9:	mov    $0x1,%r15d
 12970cf:	jmp    1296f2c <myl_rc_native_loan+0x31c>
 12970d4:	cmpq   $0x0,0x58(%rdi)
 12970d9:	jne    12970bc <myl_rc_native_loan+0x4ac>
 12970db:	test   %edx,%edx
 12970dd:	je     129716c <myl_rc_native_loan+0x55c>
 12970e3:	xor    %ecx,%ecx
 12970e5:	jmp    12970f3 <myl_rc_native_loan+0x4e3>
 12970e7:	inc    %rcx
 12970ea:	mov    0x78(%r13),%eax
 12970ee:	cmp    %rax,%rcx
 12970f1:	jae    129716c <myl_rc_native_loan+0x55c>
 12970f3:	mov    0x38(%r13,%rcx,8),%rax
 12970f8:	mov    (%r14,%rax,1),%rdx
 12970fc:	movq   $0x0,(%r14,%rax,1)
 1297104:	test   %rdx,%rdx
 1297107:	je     12970e7 <myl_rc_native_loan+0x4d7>
 1297109:	mov    -0x10(%rdx),%rsi
 129710d:	test   %r11,%rsi
 1297110:	jne    12970e7 <myl_rc_native_loan+0x4d7>
 1297112:	mov    0x1608(%rbx),%rdi
 1297119:	test   %rdi,%rdi
 129711c:	je     12970bc <myl_rc_native_loan+0x4ac>
 129711e:	test   $0x1,%sil
 1297122:	jne    12970bc <myl_rc_native_loan+0x4ac>
 1297124:	cmpq   $0x0,-0x20(%rdx)
 1297129:	mov    -0x18(%rdx),%r8
 129712d:	je     129713d <myl_rc_native_loan+0x52d>
 129712f:	test   %r8,%r8
 1297132:	je     12970bc <myl_rc_native_loan+0x4ac>
 1297134:	dec    %r8
 1297137:	mov    %r8,-0x18(%rdx)
 129713b:	jmp    12970e7 <myl_rc_native_loan+0x4d7>
 129713d:	test   %r8,%r8
 1297140:	je     12970bc <myl_rc_native_loan+0x4ac>
 1297146:	dec    %r8
 1297149:	mov    %r8,-0x18(%rdx)
 129714d:	jne    12970e7 <myl_rc_native_loan+0x4d7>
 129714f:	lea    -0x20(%rdx),%rax
 1297153:	or     $0x1,%rsi
 1297157:	mov    %rsi,-0x10(%rdx)
 129715b:	mov    0x60(%rdi),%rsi
 129715f:	mov    %rsi,-0x20(%rdx)
 1297163:	mov    %rax,0x60(%rdi)
 1297167:	jmp    12970e7 <myl_rc_native_loan+0x4d7>
 129716c:	mov    0x0(%r13),%rax
 1297170:	mov    (%rax),%rdx
 1297173:	xor    %r15d,%r15d
 1297176:	mov    %r14,%rdi
 1297179:	xor    %esi,%esi
 129717b:	call   129aa70 <memset@plt>
 1297180:	mov    %rbx,%rdi
 1297183:	call   128fb60 <myl_rc_drain>
 1297188:	mov    0x1608(%rbx),%rax
 129718f:	test   %rax,%rax
 1297192:	je     12970bc <myl_rc_native_loan+0x4ac>
 1297198:	cmpl   $0x0,0x78(%rax)
 129719c:	jne    1296f2c <myl_rc_native_loan+0x31c>
 12971a2:	movl   $0x2,0x78(%rax)
 12971a9:	jmp    1296f2c <myl_rc_native_loan+0x31c>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
