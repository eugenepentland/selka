
.tmp-mut-argument/joined-flat-measure/lox-qbe-production:     file format elf64-x86-64


Disassembly of section .text:

0000000001328130 <myl_rc_value_retain_many>:
 1328130:	push   %rbp
 1328131:	mov    %rsp,%rbp
 1328134:	mov    $0x1,%r8d
 132813a:	pop    %rbp
 132813b:	jmp    1327ec0 <copy_many>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
