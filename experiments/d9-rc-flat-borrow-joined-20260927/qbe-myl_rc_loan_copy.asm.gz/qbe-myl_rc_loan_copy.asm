
.tmp-mut-argument/joined-flat-measure/lox-qbe-production:     file format elf64-x86-64


Disassembly of section .text:

0000000001327990 <myl_rc_loan_copy>:
 1327990:	push   %rbp
 1327991:	mov    %rsp,%rbp
 1327994:	push   %r15
 1327996:	push   %r14
 1327998:	push   %r13
 132799a:	push   %r12
 132799c:	push   %rbx
 132799d:	sub    $0x1f8,%rsp
 13279a4:	test   %rdi,%rdi
 13279a7:	je     1327b03 <myl_rc_loan_copy+0x173>
 13279ad:	mov    %rcx,%r15
 13279b0:	mov    %rdx,%rbx
 13279b3:	cmp    %rcx,%rdx
 13279b6:	je     1327b03 <myl_rc_loan_copy+0x173>
 13279bc:	test   %r15,%r15
 13279bf:	je     1327b03 <myl_rc_loan_copy+0x173>
 13279c5:	test   %rbx,%rbx
 13279c8:	je     1327b03 <myl_rc_loan_copy+0x173>
 13279ce:	mov    %rdi,%r14
 13279d1:	cmpq   $0x0,0x1608(%rdi)
 13279d9:	je     1327b03 <myl_rc_loan_copy+0x173>
 13279df:	mov    %r14,%rdi
 13279e2:	call   1323bf0 <myl_rc_shape_resolve>
 13279e7:	test   %rax,%rax
 13279ea:	je     1327b03 <myl_rc_loan_copy+0x173>
 13279f0:	mov    %rax,%r12
 13279f3:	mov    %rbx,%rax
 13279f6:	mov    (%r12),%rdx
 13279fa:	sub    %r15,%rax
 13279fd:	ja     1327a05 <myl_rc_loan_copy+0x75>
 13279ff:	mov    %r15,%rax
 1327a02:	sub    %rbx,%rax
 1327a05:	cmp    %rdx,%rax
 1327a08:	jb     1327b03 <myl_rc_loan_copy+0x173>
 1327a0e:	vxorps %xmm0,%xmm0,%xmm0
 1327a12:	vmovups %ymm0,-0x80(%rbp)
 1327a17:	vmovups %ymm0,-0xa0(%rbp)
 1327a1f:	vmovups %ymm0,-0xc0(%rbp)
 1327a27:	vmovups %ymm0,-0xe0(%rbp)
 1327a2f:	vmovups %ymm0,-0x100(%rbp)
 1327a37:	vmovups %ymm0,-0x120(%rbp)
 1327a3f:	movq   $0x0,-0x60(%rbp)
 1327a47:	mov    %r14,-0x58(%rbp)
 1327a4b:	lea    -0x220(%rbp),%rax
 1327a52:	mov    %rax,-0x50(%rbp)
 1327a56:	movq   $0x8,-0x48(%rbp)
 1327a5e:	vxorps %xmm0,%xmm0,%xmm0
 1327a62:	vmovups %xmm0,-0x40(%rbp)
 1327a67:	lea    -0x120(%rbp),%rax
 1327a6e:	mov    %rax,-0x30(%rbp)
 1327a72:	mov    %rbx,%rdi
 1327a75:	xor    %esi,%esi
 1327a77:	vzeroupper
 1327a7a:	call   132aea0 <compiler_rt.fastMemset>
 1327a7f:	lea    -0x58(%rbp),%rdi
 1327a83:	mov    %r12,%rsi
 1327a86:	call   1327b10 <prepare_frames>
 1327a8b:	mov    $0x1,%r13d
 1327a91:	test   %eax,%eax
 1327a93:	jne    1327ae3 <myl_rc_loan_copy+0x153>
 1327a95:	mov    $0x1,%r8d
 1327a9b:	mov    %r14,%rdi
 1327a9e:	mov    %r12,%rsi
 1327aa1:	mov    %rbx,%rdx
 1327aa4:	mov    %r15,%rcx
 1327aa7:	call   13250a0 <myl_rc_value_seed>
 1327aac:	lea    0x2cd(%rip),%r8        # 1327d80 <loan_pointer>
 1327ab3:	lea    -0x58(%rbp),%rdi
 1327ab7:	mov    %r12,%rsi
 1327aba:	mov    %rbx,%rdx
 1327abd:	mov    %r15,%rcx
 1327ac0:	call   1327bb0 <visit>
 1327ac5:	mov    $0x0,%r13d
 1327acb:	test   %eax,%eax
 1327acd:	je     1327ae3 <myl_rc_loan_copy+0x153>
 1327acf:	mov    %eax,%r15d
 1327ad2:	mov    %r14,%rdi
 1327ad5:	mov    %r12,%rsi
 1327ad8:	mov    %rbx,%rdx
 1327adb:	call   1324e60 <myl_rc_loan_drop>
 1327ae0:	mov    %r15d,%r13d
 1327ae3:	lea    -0x58(%rbp),%rdi
 1327ae7:	xor    %esi,%esi
 1327ae9:	call   1327df0 <dispose_walk>
 1327aee:	mov    %r13d,%eax
 1327af1:	add    $0x1f8,%rsp
 1327af8:	pop    %rbx
 1327af9:	pop    %r12
 1327afb:	pop    %r13
 1327afd:	pop    %r14
 1327aff:	pop    %r15
 1327b01:	pop    %rbp
 1327b02:	ret
 1327b03:	call   132226e <myl_rc_invariant_failed>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
