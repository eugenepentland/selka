
.tmp-mut-argument/joined-flat-measure/lox-qbe-production:     file format elf64-x86-64


Disassembly of section .text:

000000000132ab00 <myl_rc_native_retain>:
 132ab00:	push   %rbp
 132ab01:	mov    %rsp,%rbp
 132ab04:	push   %r15
 132ab06:	push   %r14
 132ab08:	push   %r13
 132ab0a:	push   %r12
 132ab0c:	push   %rbx
 132ab0d:	sub    $0x48,%rsp
 132ab11:	mov    %r8d,%r12d
 132ab14:	mov    %rcx,%r15
 132ab17:	mov    %rdx,%r14
 132ab1a:	mov    %rsi,%r13
 132ab1d:	mov    %rdi,%rbx
 132ab20:	call   1323060 <myl_rc_descriptor_find>
 132ab25:	test   %rax,%rax
 132ab28:	mov    %r15,-0x30(%rbp)
 132ab2c:	je     132abd4 <myl_rc_native_retain+0xd4>
 132ab32:	cmpl   $0x0,0x78(%rax)
 132ab36:	jne    132ab4a <myl_rc_native_retain+0x4a>
 132ab38:	mov    0x1608(%rbx),%rcx
 132ab3f:	cmpq   $0x0,0x60(%rcx)
 132ab44:	je     132abfe <myl_rc_native_retain+0xfe>
 132ab4a:	mov    0x8(%rax),%r15
 132ab4e:	test   %r15,%r15
 132ab51:	je     132abeb <myl_rc_native_retain+0xeb>
 132ab57:	mov    %rbx,%rdi
 132ab5a:	mov    %r13,%rsi
 132ab5d:	call   1324f20 <myl_rc_native_has_unique>
 132ab62:	test   %eax,%eax
 132ab64:	jne    132ac62 <myl_rc_native_retain+0x162>
 132ab6a:	mov    0x0(%r13),%rdx
 132ab6e:	xor    %r13d,%r13d
 132ab71:	mov    %r14,%rdi
 132ab74:	xor    %esi,%esi
 132ab76:	call   132aea0 <compiler_rt.fastMemset>
 132ab7b:	mov    %r15,-0x50(%rbp)
 132ab7f:	mov    %r14,-0x48(%rbp)
 132ab83:	movq   $0x0,-0x40(%rbp)
 132ab8b:	mov    %r12d,-0x38(%rbp)
 132ab8f:	movl   $0x0,-0x34(%rbp)
 132ab96:	mov    %r15,-0x70(%rbp)
 132ab9a:	mov    -0x30(%rbp),%rax
 132ab9e:	mov    %rax,-0x68(%rbp)
 132aba2:	vxorps %xmm0,%xmm0,%xmm0
 132aba6:	vmovups %xmm0,-0x60(%rbp)
 132abab:	lea    -0x50(%rbp),%rsi
 132abaf:	lea    -0x70(%rbp),%rdx
 132abb3:	mov    $0x1,%ecx
 132abb8:	mov    %rbx,%rdi
 132abbb:	call   1328130 <myl_rc_value_retain_many>
 132abc0:	test   %eax,%eax
 132abc2:	je     132ac4a <myl_rc_native_retain+0x14a>
 132abc8:	mov    %rbx,%rdi
 132abcb:	mov    %eax,%esi
 132abcd:	call   13223d0 <myl_rc_record_failure>
 132abd2:	jmp    132ac50 <myl_rc_native_retain+0x150>
 132abd4:	mov    %rbx,%rdi
 132abd7:	mov    %r13,%rsi
 132abda:	call   1329f70 <myl_rc_native_shape>
 132abdf:	mov    %rax,%r15
 132abe2:	test   %r15,%r15
 132abe5:	jne    132ab57 <myl_rc_native_retain+0x57>
 132abeb:	mov    0x0(%r13),%rdx
 132abef:	xor    %r13d,%r13d
 132abf2:	mov    %r14,%rdi
 132abf5:	xor    %esi,%esi
 132abf7:	call   132aea0 <compiler_rt.fastMemset>
 132abfc:	jmp    132ac50 <myl_rc_native_retain+0x150>
 132abfe:	mov    0x0(%r13),%rdx
 132ac02:	test   %rdx,%rdx
 132ac05:	je     132ab4a <myl_rc_native_retain+0x4a>
 132ac0b:	mov    %r14,%rcx
 132ac0e:	sub    %r15,%rcx
 132ac11:	ja     132ac19 <myl_rc_native_retain+0x119>
 132ac13:	mov    %r15,%rcx
 132ac16:	sub    %r14,%rcx
 132ac19:	cmp    %rdx,%rcx
 132ac1c:	jb     132ab4a <myl_rc_native_retain+0x4a>
 132ac22:	cmp    0x70(%rbx),%r12d
 132ac26:	jbe    132ac3f <myl_rc_native_retain+0x13f>
 132ac28:	xor    %r13d,%r13d
 132ac2b:	mov    %r14,%rdi
 132ac2e:	xor    %esi,%esi
 132ac30:	call   132aea0 <compiler_rt.fastMemset>
 132ac35:	mov    %rbx,%rdi
 132ac38:	mov    $0x3,%esi
 132ac3d:	jmp    132abcd <myl_rc_native_retain+0xcd>
 132ac3f:	mov    %r14,%rdi
 132ac42:	mov    %r15,%rsi
 132ac45:	call   132b3a0 <compiler_rt.memcpy.memcpyFast>
 132ac4a:	mov    $0x1,%r13d
 132ac50:	mov    %r13d,%eax
 132ac53:	add    $0x48,%rsp
 132ac57:	pop    %rbx
 132ac58:	pop    %r12
 132ac5a:	pop    %r13
 132ac5c:	pop    %r14
 132ac5e:	pop    %r15
 132ac60:	pop    %rbp
 132ac61:	ret
 132ac62:	call   132226e <myl_rc_invariant_failed>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
