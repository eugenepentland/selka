from pathlib import Path
import hashlib,json,os,subprocess,datetime
root=Path.cwd();out=root/'.mylang-cache/goal110-index-forward-rf/native-checks/active'; out.mkdir(exist_ok=True); parent=out.parent; report={'schema':'mylang-index-update-active-native-v1','diagnostic_only':False,'timing':False,'comparisons':[],'compute':[]}
digest=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
control_root=Path('/home/epentland/ai/canopy/mylang-worktrees/goal110-g4-rf-20261004');control=control_root/'zig-out/bin/mylang';candidate=root/'zig-out/bin/mylang';qbe=control_root/'zig-out/bin/qbe'
assert digest(control)=='6d284b91b0ca95b566f38ea5a2e6d914b56d9c0c75694310773065d3cc0f5e4f'
assert digest(qbe)=='68a4618e939eefc428772342fd4bd78286ef04d1fb673fbecd0f2708a8e19001'
(out/'bin').mkdir(exist_ok=True);report['compilers']={arm:{'path':str(p),'sha256':digest(p)} for arm,p in [('before',control),('after',candidate)]};report['qbe']={'path':str(qbe),'sha256':digest(qbe)}
preflight=Path('/home/epentland/ai/canopy/mylang-worktrees/goal110-index-forward-20261004/.mylang-cache/goal110-index-update/static/final-checks/passed-preflight.json');bound=json.loads(preflight.read_text())
import sys
sys.path.insert(0,str(root/'benchmarks/runtime'));from build_compiler import validate_receipt
rf_path=root/'.mylang-cache/goal110-index-forward-rf/compiler-receipt.json';rf=json.loads(rf_path.read_text());validate_receipt(rf,candidate,artifacts=True);assert rf['source_revision']=='14ffa2c0f385a11e5216bbdec5bdff429f9f981b' and rf['compiler_optimize']=='ReleaseFast'
report['official_compiler_receipt']={'path':str(rf_path),'sha256':digest(rf_path)}
for row in bound['source_files']:assert digest(root/row['path'])==row['sha256']
report['source_binding']={'path':str(preflight),'sha256':digest(preflight)}
(out/'active-before-invocation.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'compilers':report['compilers'],'source_binding':report['source_binding']}),flush=True)
environment=dict(os.environ);environment['ZIG_GLOBAL_CACHE_DIR']=str(out/'zig-global');environment['ZIG_LOCAL_CACHE_DIR']=str(out/'zig-local');environment['TMPDIR']=str(root/'.mylang-cache/goal110-index-forward-rf/tmp')
def build(case,arm,compiler,input_path,mode,backend):
 executable=out/'bin'/f'{case}-{arm}-{backend}';cache=out/'build-cache'/f'{arm}-{backend}'
 cmd=[str(compiler),'build',str(input_path),'-o',str(executable),'--mode','ReleaseFast','--backend',backend,'--cache-dir='+str(cache),'--no-cache','--report',mode]
 if backend=='qbe':cmd+=['--qbe',str(qbe)]
 else:cmd+=['--llvm-opt','3','--lto=full']
 result=subprocess.run(cmd,cwd=root,env=environment,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 prefix=out/f'{case}-{arm}-{backend}-build';prefix.with_suffix('.stdout').write_bytes(result.stdout);prefix.with_suffix('.stderr').write_bytes(result.stderr)
 assert result.returncode==0,(case,arm,backend,result.stderr.decode())
 return {'command':cmd,'path':str(executable),'sha256':digest(executable),'source_sha256':digest(input_path)}

fixture=parent/'counted_index_update.my'
command=[str(candidate),'emit-qbe',str(fixture),'--rc-runtime','--drop-step-checks','--drop-frame-checks','--native-variants=qbe-v2','--no-cache']
res=subprocess.run(command,cwd=root,env=environment,capture_output=True);(out/'active-emitted.json').write_bytes(res.stdout);(out/'active-emitted.stderr').write_bytes(res.stderr);assert res.returncode==0,res.stderr.decode()
emitted=json.loads(res.stdout);checksum=next(f for f in emitted['functions'] if f['name']=='checksum_update');assert checksum['il'].count('# RC-INDEX-UPDATE-1')==3
report['emitted_fixture']={'argv':command,'path':str(out/'active-emitted.json'),'sha256':digest(out/'active-emitted.json'),'fixture_sha256':digest(fixture),'checksum_marker_count':3}
(out/'active-before-native-invocation.json').write_text(json.dumps(report,indent=2)+'\n')
unit=(root/'src/qbe_rc_index_update_test.zig').read_text()
fragment=unit.split('"refused_detach.my",',1)[1].split('\n    );',1)[0]
def lines(v):return '\n'.join(l.split('\\\\',1)[1] for l in v.splitlines() if l.strip().startswith('\\\\'))
memory_source=out/'memory_refusal.my';memory_source.write_text(lines(fragment)+'\n')
cases=[]
for index in [-2,-1,0,1]:
 initial=7 if index in [-2,0] else 11
 for delta in [-10,3]:
  for shared in [False,True]:
   cases.append((["shared" if shared else "unique",str(index),str(delta)],initial+delta+(initial*100 if shared else 0),None))
   next_=(initial+delta)%1000003
   cases.append((["checksum_shared" if shared else "checksum",str(index),str(delta)],47-initial+2*next_+(initial*100 if shared else 0),None))
for divisor in [-5,-3,3,5]:
 for shared in [False,True]:cases.append((["modulo_shared" if shared else "modulo","-1",str(divisor)],12%divisor+(1100 if shared else 0),None))
for divisor,value in [(-3,-4),(3,3)]:cases.append((["quotient","-1",str(divisor)],value,None))
cases += [(["quotient","0","1"],-(1<<63),None),(["quotient","0","-1"],None,'R_OVERFLOW'),(["modulo_shared","-1","0"],None,'R_DIVISION_BY_ZERO'),(["shared","0",str((1<<63)-1)],None,'R_OVERFLOW')]
for name in ['shared','provenance','checksum_shared']:
 for index in [-3,2,-(1<<63),(1<<63)-1]:cases.append(([name,str(index),'3'],None,'R_LIST_BOUNDS'))
for name,value in [('alias',710),('rebound',10),('resized',10),('callback',7),('distinct',10),('changed',10),('managed_prefix',21),('shared_read',46)]:cases.append(([name,'0' if name not in ['managed_prefix','shared_read'] else '-1','3'],value,None))
cases += [(['repeat',str(-(1<<63)),'0'],18,None),(['repeat','-1','3'],67,None)]
report['cases']=[];report['comparisons']=[]
for backend in ['qbe','llvm']:
 artifacts={arm:build('active',arm,compiler,parent/'counted_index_update.my','--rc-runtime',backend) for arm,compiler in [('before',control),('after',candidate)]}
 metadata=json.loads(Path(artifacts['after']['path']+'.qbe-manifest.json').read_text());assert metadata['backend']==backend
 assert set(f['symbol'] for f in metadata['functions']).issubset(set(f['symbol'] for f in emitted['functions']))
 for number,(args,expected,code) in enumerate(cases):
  row={'backend':backend,'number':number,'args':args,'expected':expected,'expected_code':code,'arms':{}}
  for arm,artifact in artifacts.items():
   run_env=dict(environment);run_env['MYLANG_OPTIONS']='--print-result';run_env['MYLANG_MEMORY_LIMIT']='536870912'
   command=[artifact['path'],*args];res=subprocess.run(command,cwd=root,env=run_env,capture_output=True)
   if code is None:assert res.returncode==(expected&255) and res.stdout==f'41\n{expected}\n'.encode() and res.stderr==b'',(backend,args,arm,res.returncode,res.stdout,res.stderr)
   else:assert res.returncode!=0 and res.stdout==b'41\n' and code.encode() in res.stderr,(backend,args,arm,res.returncode,res.stdout,res.stderr)
   prefix=out/f'active-{backend}-{number:03}-{arm}';prefix.with_suffix('.stdout').write_bytes(res.stdout);prefix.with_suffix('.stderr').write_bytes(res.stderr)
   row['arms'][arm]={'artifact':artifact,'command':command,'returncode':res.returncode,'stdout_path':str(prefix.with_suffix('.stdout')),'stdout_sha256':digest(prefix.with_suffix('.stdout')),'stderr_path':str(prefix.with_suffix('.stderr')),'stderr_sha256':digest(prefix.with_suffix('.stderr'))}
  assert all(row['arms']['before'][key]==row['arms']['after'][key] for key in ['returncode','stdout_sha256','stderr_sha256']),row
  row['full_raw_identical']=True;report['comparisons'].append(row)
 (out/'active-receipt.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'backend':backend,'oracle_cases':len(cases),'paired_calls':len(cases)*2,'status':'pass'}),flush=True)
 memory_artifacts={arm:build('memory',arm,compiler,memory_source,'--rc-runtime',backend) for arm,compiler in [('before',control),('after',candidate)]}
 memory={'backend':backend,'kind':'memory_refusal','arms':{}}
 for arm,artifact in memory_artifacts.items():
  run_env=dict(environment);run_env['MYLANG_MEMORY_LIMIT']=str(1<<20);run_env['MYLANG_OPTIONS']='--print-result'
  res=subprocess.run([artifact['path']],cwd=root,env=run_env,capture_output=True);assert res.returncode!=0 and res.stdout==b'41\n' and b'R_MEMORY_BUDGET' in res.stderr,(backend,arm,res.stdout,res.stderr)
  prefix=out/f'memory-{backend}-{arm}-run';prefix.with_suffix('.stdout').write_bytes(res.stdout);prefix.with_suffix('.stderr').write_bytes(res.stderr)
  memory['arms'][arm]={'artifact':artifact,'returncode':res.returncode,'stdout_sha256':digest(prefix.with_suffix('.stdout')),'stderr_sha256':digest(prefix.with_suffix('.stderr')),'stdout_path':str(prefix.with_suffix('.stdout')),'stderr_path':str(prefix.with_suffix('.stderr'))}
 assert all(memory['arms']['before'][key]==memory['arms']['after'][key] for key in ['returncode','stdout_sha256','stderr_sha256']);report['comparisons'].append(memory)
 (out/'active-receipt.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'backend':backend,'memory_refusal':'pass'}),flush=True)
for arm,p in [('before',control),('after',candidate)]:assert digest(p)==report['compilers'][arm]['sha256']
report['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();(out/'active-receipt.json').write_text(json.dumps(report,indent=2)+'\n')

report['gc_comparisons']=[]
for backend in ['qbe','llvm']:
 artifacts={arm:build('gc',arm,compiler,parent/'counted_index_update.my','--gc-runtime',backend) for arm,compiler in [('before',control),('after',candidate)]}
 for number,(args,expected) in enumerate([(['shared','-1','3'],1114),(['unique','0','-10'],-3),(['checksum_shared','-1','3'],1164),(['managed_prefix','-1','3'],21)]):
  row={'backend':backend,'args':args,'expected':expected,'arms':{}}
  for arm,artifact in artifacts.items():
   run_env=dict(environment);run_env['MYLANG_OPTIONS']='--print-result --gc-stress';res=subprocess.run([artifact['path'],*args],cwd=root,env=run_env,capture_output=True)
   assert res.returncode==(expected&255) and res.stdout==f'41\n{expected}\n'.encode() and res.stderr==b'',(backend,args,arm,res.returncode,res.stdout,res.stderr)
   prefix=out/f'gc-{backend}-{number}-{arm}-run';prefix.with_suffix('.stdout').write_bytes(res.stdout);prefix.with_suffix('.stderr').write_bytes(res.stderr)
   row['arms'][arm]={'artifact':artifact,'returncode':res.returncode,'stdout_sha256':digest(prefix.with_suffix('.stdout')),'stderr_sha256':digest(prefix.with_suffix('.stderr')),'stdout_path':str(prefix.with_suffix('.stdout')),'stderr_path':str(prefix.with_suffix('.stderr'))}
  assert all(row['arms']['before'][key]==row['arms']['after'][key] for key in ['returncode','stdout_sha256','stderr_sha256']);report['gc_comparisons'].append(row)
 (out/'active-receipt.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'backend':backend,'gc_stress_pairs':4,'status':'pass'}),flush=True)
report['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();(out/'active-receipt.json').write_text(json.dumps(report,indent=2)+'\n')
