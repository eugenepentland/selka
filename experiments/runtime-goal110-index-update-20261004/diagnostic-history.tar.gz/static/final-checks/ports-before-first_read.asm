 1025c25:	mov    (%rdi),%rdx
 1025c28:	mov    %r15,%rsi
 1025c2b:	cmp    %rdx,%r15
 1025c2e:	jb     1025c5a <myl_f_b5d931620df636deef979a0d59c3f9f39f360f8d212025d8bcb427e874f639a5+0x23fa>
 1025c30:	movq   $0x0,-0x30(%rbp)
 1025c38:	mov    %r15,%rsi
 1025c3b:	test   %r15,%r15
 1025c3e:	jns    1025c51 <myl_f_b5d931620df636deef979a0d59c3f9f39f360f8d212025d8bcb427e874f639a5+0x23f1>
 1025c40:	test   %rdx,%rdx
 1025c43:	js     1027916 <myl_f_b5d931620df636deef979a0d59c3f9f39f360f8d212025d8bcb427e874f639a5+0x40b6>
 1025c49:	mov    %r15,-0x30(%rbp)
 1025c4d:	lea    (%rdx,%r15,1),%rsi
 1025c51:	cmp    %rdx,%rsi
 1025c54:	jae    1027882 <myl_f_b5d931620df636deef979a0d59c3f9f39f360f8d212025d8bcb427e874f639a5+0x4022>
 1025c5a:	mov    0x20(%rdi),%rax
 1025c5e:	mov    (%rax,%rsi,8),%rax
