 1025d6b:	movq   $0x0,-0x30(%rbp)
 1025d73:	mov    (%rdi),%rdx
 1025d76:	mov    %r15,%rsi
 1025d79:	test   %r15,%r15
 1025d7c:	jns    1025d8b <myl_f_b5d931620df636deef979a0d59c3f9f39f360f8d212025d8bcb427e874f639a5+0x252b>
 1025d7e:	test   %rdx,%rdx
 1025d81:	js     10278f2 <myl_f_b5d931620df636deef979a0d59c3f9f39f360f8d212025d8bcb427e874f639a5+0x4092>
 1025d87:	lea    (%rdx,%r15,1),%rsi
 1025d8b:	add    %rbx,%r13
 1025d8e:	mov    %r13,%rax
 1025d91:	shr    $0x3f,%rax
 1025d95:	sar    $0x13,%r13
 1025d99:	add    %rax,%r13
 1025d9c:	imul   $0xf4243,%r13,%rax
 1025da3:	sub    %rax,%rbx
 1025da6:	mov    %rbx,%rcx
 1025da9:	sar    $0x3f,%rcx
 1025dad:	and    $0xf4243,%ecx
 1025db3:	add    %rbx,%rcx
 1025db6:	mov    %rcx,-0x30(%rbp)
 1025dba:	cmp    %rdx,%rsi
 1025dbd:	jae    102777b <myl_f_b5d931620df636deef979a0d59c3f9f39f360f8d212025d8bcb427e874f639a5+0x3f1b>
 1025dc3:	mov    0x20(%rdi),%rax
 1025dc7:	mov    %rcx,(%rax,%rsi,8)
