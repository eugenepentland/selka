 1026867:	mov    (%rsi),%rdx
 102686a:	cmp    %rdx,%rbx
 102686d:	jb     1026889 <myl_f_b5d931620df636deef979a0d59c3f9f39f360f8d212025d8bcb427e874f639a5+0x3079>
 102686f:	test   %rbx,%rbx
 1026872:	jns    1026880 <myl_f_b5d931620df636deef979a0d59c3f9f39f360f8d212025d8bcb427e874f639a5+0x3070>
 1026874:	test   %rdx,%rdx
 1026877:	js     102771c <myl_f_b5d931620df636deef979a0d59c3f9f39f360f8d212025d8bcb427e874f639a5+0x3f0c>
 102687d:	add    %rdx,%rbx
 1026880:	cmp    %rdx,%rbx
 1026883:	jae    10276a2 <myl_f_b5d931620df636deef979a0d59c3f9f39f360f8d212025d8bcb427e874f639a5+0x3e92>
 1026889:	mov    0x20(%rsi),%rax
 102688d:	mov    (%rax,%rbx,8),%rax
