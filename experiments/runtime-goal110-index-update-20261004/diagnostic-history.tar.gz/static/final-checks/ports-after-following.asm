 102678d:	add    %r15,%rcx
