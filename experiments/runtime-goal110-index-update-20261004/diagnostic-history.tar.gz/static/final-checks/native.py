from pathlib import Path
import hashlib,json,os,subprocess,datetime
root=Path.cwd();out=root/'.mylang-cache/goal110-index-update/static/final-checks'; report={'schema':'mylang-index-update-static-native-v1','diagnostic_only':True,'timing':False,'comparisons':[],'compute':[]}
digest=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
control_root=Path('/home/epentland/ai/canopy/mylang-worktrees/goal110-g4-rf-20261004');control=control_root/'zig-out/bin/mylang';candidate=out/'focus-final';qbe=control_root/'zig-out/bin/qbe'
assert digest(control)=='6d284b91b0ca95b566f38ea5a2e6d914b56d9c0c75694310773065d3cc0f5e4f'
assert digest(qbe)=='68a4618e939eefc428772342fd4bd78286ef04d1fb673fbecd0f2708a8e19001'
(out/'bin').mkdir(exist_ok=True);report['compilers']={arm:{'path':str(p),'sha256':digest(p)} for arm,p in [('before',control),('after',candidate)]};report['qbe']={'path':str(qbe),'sha256':digest(qbe)}
preflight=out/'passed-preflight.json';bound=json.loads(preflight.read_text())
assert report['compilers']['after']['sha256']==bound['tools']['after']['sha256']
for row in bound['source_files']:assert digest(root/row['path'])==row['sha256']
report['source_binding']={'path':str(preflight),'sha256':digest(preflight)}
(out/'native-before-invocation.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'compilers':report['compilers'],'source_binding':report['source_binding']}),flush=True)
environment=dict(os.environ);environment['ZIG_GLOBAL_CACHE_DIR']=str(out/'zig-global');environment['ZIG_LOCAL_CACHE_DIR']=str(out/'zig-local');environment['TMPDIR']=str(root/'.mylang-cache/goal110-index-update/tmp')
def build(case,arm,compiler,input_path,mode,backend):
 executable=out/'bin'/f'{case}-{arm}-{backend}';cache=out/'build-cache'/f'{arm}-{backend}'
 cmd=[str(compiler),'build',str(input_path),'-o',str(executable),'--mode','ReleaseFast','--backend',backend,'--cache-dir='+str(cache),'--no-cache','--report',mode]
 if backend=='qbe':cmd+=['--qbe',str(qbe)]
 else:cmd+=['--llvm-opt','3','--lto=full']
 result=subprocess.run(cmd,cwd=root,env=environment,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 prefix=out/f'{case}-{arm}-{backend}-build';prefix.with_suffix('.stdout').write_bytes(result.stdout);prefix.with_suffix('.stderr').write_bytes(result.stderr)
 assert result.returncode==0,(case,arm,backend,result.stderr.decode())
 return {'command':cmd,'path':str(executable),'sha256':digest(executable),'source_sha256':digest(input_path)}
for backend in ['qbe','llvm']:
 for mode,flag in [('stats','--rc-runtime=stats'),('sites','--rc-runtime=sites')]:
  row={'case':mode,'backend':backend,'arms':{}}
  for arm,compiler in [('before',control),('after',candidate)]:
   artifact=build('counted-'+mode,arm,compiler,out/'counted_index_update.my',flag,backend)
   run_env=dict(environment);run_env['MYLANG_OPTIONS']='--print-result';run_env['MYLANG_MEMORY_LIMIT']='536870912'
   command=[artifact['path'],'shared','-1','3'];result=subprocess.run(command,cwd=root,env=run_env,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
   assert result.returncode==90 and result.stdout==b'41\n1114\n',(mode,arm,backend,result.returncode,result.stdout,result.stderr)
   assert result.stderr.startswith(b'MYLANG_RC_COUNTS {')
   prefix=out/f'counted-{mode}-{arm}-{backend}-run';prefix.with_suffix('.stdout').write_bytes(result.stdout);prefix.with_suffix('.stderr').write_bytes(result.stderr)
   row['arms'][arm]={'artifact':artifact,'command':command,'returncode':result.returncode,'stdout':result.stdout.decode(),'stderr':result.stderr.decode()}
  assert {k:v for k,v in row['arms']['before'].items() if k in ['returncode','stdout','stderr']}=={k:v for k,v in row['arms']['after'].items() if k in ['returncode','stdout','stderr']}
  row['full_raw_outcomes_identical']=True;report['comparisons'].append(row)
  (out/'native-receipt.json').write_text(json.dumps(report,indent=2)+'\n')
  print(json.dumps({'case':mode,'backend':backend,'full_raw_identical':True}),flush=True)
for arm,p in [('before',control),('after',candidate)]:assert digest(p)==report['compilers'][arm]['sha256']
report['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();(out/'native-receipt.json').write_text(json.dumps(report,indent=2)+'\n')
