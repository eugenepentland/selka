 1025ca1:	test   %rdi,%rdi
 1025ca4:	je     1025d69 <myl_f_b5d931620df636deef979a0d59c3f9f39f360f8d212025d8bcb427e874f639a5+0x2509>
 1025caa:	movabs $0x6000000000000002,%rax
 1025cb4:	test   %rax,-0x10(%rdi)
 1025cb8:	jne    1025cc5 <myl_f_b5d931620df636deef979a0d59c3f9f39f360f8d212025d8bcb427e874f639a5+0x2465>
 1025cba:	cmpq   $0x2,-0x20(%rdi)
 1025cbf:	jb     1025d6b <myl_f_b5d931620df636deef979a0d59c3f9f39f360f8d212025d8bcb427e874f639a5+0x250b>
 1025cc5:	mov    $0x100a710,%esi
 1025cca:	mov    -0x38(%rbp),%rdi
 1025cce:	lea    -0xd0(%rbp),%rdx
 1025cd5:	lea    -0x160(%rbp),%rcx
 1025cdc:	call   102b990 <myl_qbe_rc_unique_local>
 1025ce1:	test   %eax,%eax
 1025ce3:	je     10273cd <myl_f_b5d931620df636deef979a0d59c3f9f39f360f8d212025d8bcb427e874f639a5+0x3b6d>
 1025ce9:	mov    -0xd0(%rbp),%r9
 1025cf0:	mov    %r9,%r10
 1025cf3:	mov    %r9,%rdi
 1025cf6:	mov    -0x40(%rbp),%r8
 1025cfa:	jmp    1025d6b <myl_f_b5d931620df636deef979a0d59c3f9f39f360f8d212025d8bcb427e874f639a5+0x250b>
