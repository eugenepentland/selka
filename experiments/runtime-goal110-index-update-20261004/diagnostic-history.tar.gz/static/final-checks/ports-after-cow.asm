 10268bc:	test   %rsi,%rsi
 10268bf:	je     1026758 <myl_f_b5d931620df636deef979a0d59c3f9f39f360f8d212025d8bcb427e874f639a5+0x2f48>
 10268c5:	movabs $0x6000000000000002,%rax
 10268cf:	test   %rax,-0x10(%rsi)
 10268d3:	jne    10268e0 <myl_f_b5d931620df636deef979a0d59c3f9f39f360f8d212025d8bcb427e874f639a5+0x30d0>
 10268d5:	cmpq   $0x2,-0x20(%rsi)
 10268da:	jb     102675a <myl_f_b5d931620df636deef979a0d59c3f9f39f360f8d212025d8bcb427e874f639a5+0x2f4a>
 10268e0:	mov    $0x100a710,%esi
 10268e5:	mov    %r14,%rdi
 10268e8:	lea    -0xc8(%rbp),%rdx
 10268ef:	lea    -0x160(%rbp),%rcx
 10268f6:	call   102b770 <myl_qbe_rc_unique_local>
 10268fb:	test   %eax,%eax
 10268fd:	je     1026fdc <myl_f_b5d931620df636deef979a0d59c3f9f39f360f8d212025d8bcb427e874f639a5+0x37cc>
 1026903:	mov    -0xc8(%rbp),%r9
 102690a:	mov    %r9,%r11
 102690d:	mov    %r9,%rsi
 1026910:	jmp    102675a <myl_f_b5d931620df636deef979a0d59c3f9f39f360f8d212025d8bcb427e874f639a5+0x2f4a>
