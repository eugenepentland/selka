from pathlib import Path
import json,hashlib,subprocess,os,struct,re
r=Path.cwd();o=r/'.mylang-cache/goal110-index-update/static/final-checks';h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
pre=o/'passed-preflight.json';b=json.loads(pre.read_text());candidate=Path(b['tools']['after']['path']);assert h(candidate)==b['tools']['after']['sha256']
for row in b['source_files']:assert h(r/row['path'])==row['sha256']
manifest=Path('/home/epentland/ai/canopy/mylang-worktrees/goal110-g4-rf-20261004/.mylang-cache/goal110-g4-rf/runner/manifest.json');m=json.loads(manifest.read_text());control=Path(m['identity']['binary_paths']['legacy/my-llvm']);assert h(control)==m['binary_hashes']['legacy/my-llvm']
cmd=m['identity']['actual_build_commands']['legacy/my-llvm'][2:];cmd[0]=str(candidate);original_source=Path(cmd[2]);cmd[2]=str(r/'benchmarks/runtime/ports/main.my');assert h(original_source)==h(Path(cmd[2]));cmd[cmd.index('-o')+1]=str(o/'bin/ports-diagnostic-llvm');cmd[cmd.index('--cache-dir')+1]=str(o/'ports-cache');clock=Path(cmd[cmd.index('--link')+1]);assert h(clock)==m['binary_hashes']['native_clock.o'];cmd+=['--no-cache','--report']
report={'schema':'mylang-index-update-ports-code-v1','diagnostic_only':True,'timing':False,'source_binding':{'path':str(pre),'sha256':h(pre)},'compiler':b['tools']['after'],'control_manifest':{'path':str(manifest),'sha256':h(manifest)},'control':{'path':str(control),'sha256':h(control)},'clock':{'path':str(clock),'sha256':h(clock)},'argv':cmd}
assert json.loads((o/'ports-before-invocation.json').read_text())==report
(o/'ports-postprocess-before.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'compiler':report['compiler'],'source_binding':report['source_binding'],'argv':cmd}),flush=True)
env=dict(os.environ);env['ZIG_GLOBAL_CACHE_DIR']=str(o/'zig-global');env['ZIG_LOCAL_CACHE_DIR']=str(o/'zig-local');env['TMPDIR']=str(r/'.mylang-cache/goal110-index-update/tmp')
assert (o/'ports-build.stderr').read_bytes()==b''
after=Path(cmd[cmd.index('-o')+1]);report['candidate']={'path':str(after),'sha256':h(after)}
metadata=Path(str(after)+'.qbe-manifest.json');native=json.loads(metadata.read_text());assert native['backend']=='llvm' and native['optimization']=='3' and native['lto'] and not native['thin_lto']
frontend=o/'ports-qbe-v2-after.json';q=json.loads(frontend.read_text());entry=next(f for f in q['functions'] if f['name']=='main::main');compiled=next(f for f in native['functions'] if f['name']=='main::main');assert entry['symbol']==compiled['symbol']
assert entry['il'].count('# RC-INDEX-UPDATE-1')==4 and '# RC-INDEX-UPDATE-1 value 92 write 849 pc 866' in entry['il'];report['native_manifest']={'path':str(metadata),'sha256':h(metadata),'backend':native['backend'],'optimization':native['optimization'],'lto':native['lto']};report['frontend_manifest']={'path':str(frontend),'sha256':h(frontend),'marker_count':4}
symbol=re.search(r'function\s+l\s+\$([^ (]+)\(',entry['il']).group(1)
for arm,p in [('before',control),('after',after)]:
 nm=subprocess.check_output(['nm','-S','--defined-only',str(p)],text=True);(o/f'ports-{arm}.nm').write_text(nm)
 matches=[l for l in nm.splitlines() if l.split()[-1]==symbol];assert len(matches)==1,(symbol,matches)
 fields=matches[0].split();report.setdefault('entry',{})[arm]={'symbol':symbol,'address':int(fields[0],16),'size':int(fields[1],16)}
 asm=subprocess.check_output(['objdump','-d','--no-show-raw-insn','--disassemble='+symbol,str(p)],text=True);(o/f'ports-{arm}-entry.asm').write_text(asm)
 data=p.read_bytes();shoff=struct.unpack_from('<Q',data,40)[0];ents,count,names=struct.unpack_from('<HHH',data,58);headers=[struct.unpack_from('<IIQQQQIIQQ',data,shoff+i*ents) for i in range(count)];stringh=headers[names];strings=data[stringh[4]:stringh[4]+stringh[5]]
 for header in headers:
  end=strings.find(b'\0',header[0]);name=strings[header[0]:end]
  if name==b'.text':report.setdefault('text',{})[arm]={'size':header[5],'sha256':hashlib.sha256(data[header[4]:header[4]+header[5]]).hexdigest()}
 assert h(p)==(report['control'] if arm=='before' else report['candidate'])['sha256']
assert h(candidate)==report['compiler']['sha256'];(o/'ports-code-receipt.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'entry':report['entry'],'text':report['text']}),flush=True)
