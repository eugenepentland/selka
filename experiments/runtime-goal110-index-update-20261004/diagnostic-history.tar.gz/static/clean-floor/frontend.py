from pathlib import Path
import hashlib,json,subprocess,re
root=Path.cwd();out=root/'.mylang-cache/goal110-index-update/static/clean-floor'
digest=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
control_receipt=Path('/home/epentland/ai/canopy/mylang-worktrees/goal110-g4-rf-20261004/.mylang-cache/goal110-g4-rf/compiler-receipt.json')
assert digest(control_receipt)=='b468bff09a8834b47bdd75ab413966d763a884f7da373441a91f98b672c07336'
receipt=json.loads(control_receipt.read_text()); control=Path(receipt['compiler_path']); candidate=out/'focus-clean-floor'
assert digest(control)==receipt['compiler_sha256']
unit=(root/'src/qbe_rc_index_update_test.zig').read_text()
def multiline(block):
 return '\n'.join(line.split('\\\\',1)[1] for line in block.splitlines() if line.strip().startswith('\\\\'))
functions=multiline(unit.split('const functions =',1)[1].split('\n;',1)[0])
main=multiline(unit.split('const native_source = functions ++',1)[1].split('\n;',1)[0])
fixture=out/'counted_index_update.my';fixture.write_text(functions+'\n'+main+'\n')
report={'schema':'mylang-index-update-static-frontend-v1','diagnostic_only':True,'source_base':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'control_receipt':{'path':str(control_receipt),'sha256':digest(control_receipt)},'compilers':{'control':{'path':str(control),'sha256':digest(control),'host_mode':'ReleaseFast'},'candidate':{'path':str(candidate),'sha256':digest(candidate),'host_mode':'Debug','uncommitted':True}},'files':[],'cases':[]}
for name in ['SPEC.md','src/qbe.zig','src/qbe_managed.zig','src/qbe_positive_index.zig','src/qbe_rc_index_update.zig','src/qbe_rc_index_update_test.zig','src/root_test.zig']:
 data=(root/name).read_bytes();target=out/'source'/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data);report['files'].append({'path':name,'sha256':digest(target)})
cases=[(f'counted-{mode}',fixture,flag,[]) for mode,flag in [('stats','--rc-runtime=stats'),('sites','--rc-runtime=sites')]]
compute=root/'benchmarks/runtime/ports/main.my'
cases += [('ports-original',compute,'--rc-runtime',[]),('ports-qbe-v2',compute,'--rc-runtime',['--native-variants=qbe-v2'])]
for case,input_path,mode,extra in cases:
 row={'case':case,'source':{'path':str(input_path),'sha256':digest(input_path)},'outputs':{}}
 for arm,compiler in [('before',control),('after',candidate)]:
  command='emit-project-qbe' if case.startswith('ports-') else 'emit-qbe'
  cmd=[str(compiler),command,str(input_path),mode,'--drop-step-checks','--drop-frame-checks','--no-cache',*extra]
  result=subprocess.run(cmd,cwd=root,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
  (out/f'{case}-{arm}.json').write_bytes(result.stdout);(out/f'{case}-{arm}.stderr').write_bytes(result.stderr)
  assert result.returncode==0,(case,arm,result.stderr.decode())
  manifest=json.loads(result.stdout);main_body=next(f['il'] for f in manifest['functions'] if f['name'] in ['main','main.main','main::main'])
  (out/f'{case}-{arm}-main.ssa').write_text(main_body)
  markers=[];pc=None
  for line in main_body.splitlines():
   match=re.match(r'^@i(\d+)\b',line)
   if match:pc=int(match.group(1))
   if '# RC-INDEX-UPDATE-1' in line:markers.append({'pc':pc,'text':line.strip()})
  row['outputs'][arm]={'command':cmd,'manifest_sha256':digest(out/f'{case}-{arm}.json'),'main_ssa_sha256':digest(out/f'{case}-{arm}-main.ssa'),'marker_count':main_body.count('# RC-INDEX-UPDATE-1'),'markers':markers}
 row['byte_identical_manifest']=(out/f'{case}-before.json').read_bytes()==(out/f'{case}-after.json').read_bytes()
 if case.startswith('counted'):
  assert row['byte_identical_manifest'],case
 else:
  assert row['outputs']['before']['marker_count']==0
 report['cases'].append(row)
 print(json.dumps({'case':case,'identical':row['byte_identical_manifest'],'markers':row['outputs']['after']['markers']}),flush=True)
assert digest(control)==report['compilers']['control']['sha256']
assert digest(candidate)==report['compilers']['candidate']['sha256']
(out/'frontend-receipt.json').write_text(json.dumps(report,indent=2)+'\n')
