from pathlib import Path
import json,hashlib,subprocess
r=Path.cwd();o=r/'.mylang-cache/goal110-index-update/static/validated-refusal';source=r/'.mylang-cache/goal110-index-update/static/actual-refusal-stage/source'
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
compilers={'before':Path('/home/epentland/ai/canopy/mylang-worktrees/goal110-g4-rf-20261004/zig-out/bin/mylang'),'after':o/'focus-diagnostic'}
assert h(compilers['before'])=='6d284b91b0ca95b566f38ea5a2e6d914b56d9c0c75694310773065d3cc0f5e4f'
files=[]
for p in sorted(source.rglob('*')):
 if not p.is_file():continue
 n=str(p.relative_to(source));assert h(r/n)==h(p);files.append({'path':n,'sha256':h(p)})
receipt={'schema':'mylang-index-update-diagnostic-preflight-v1','diagnostic_only':True,'source_files':files,'tools':{a:{'path':str(p.resolve()),'sha256':h(p)} for a,p in compilers.items()},'compiled_unit_receipt':'refusal-focus-02.log/exit0','invocations':[]}
(o/'before-invocation.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'tools':receipt['tools'],'source_binding':str(o/'before-invocation.json')}),flush=True)
fixture=r/'.mylang-cache/goal110-index-update/static/actual-refusal-stage/counted_index_update.my'
for a,p in compilers.items():
 cmd=[str(p),'emit-qbe',str(fixture),'--rc-runtime','--drop-step-checks','--drop-frame-checks','--no-cache'];res=subprocess.run(cmd,cwd=r,capture_output=True);(o/f'preflight-{a}.json').write_bytes(res.stdout);(o/f'preflight-{a}.stderr').write_bytes(res.stderr);assert res.returncode==0
 il=''.join(f['il'] for f in json.loads(res.stdout)['functions']);count=il.count('# RC-INDEX-UPDATE-1');diagnostics=il.count('PREPRODUCTION-INDEX-REFUSAL');assert (count==0 and diagnostics==0) if a=='before' else (count>0 and diagnostics>0)
 receipt['invocations'].append({'argv':cmd,'returncode':0,'marker_count':count,'diagnostic_count':diagnostics,'manifest_sha256':h(o/f'preflight-{a}.json')});print(json.dumps(receipt['invocations'][-1]),flush=True)
(o/'passed-preflight.json').write_text(json.dumps(receipt,indent=2)+'\n')
exec((o/'frontend.py').read_text())
