from pathlib import Path
import subprocess,os,json,re
r=Path.cwd();o=r/'.mylang-cache/goal110-index-update/logs'
groups=[('proof',['reuses','emitter','following','preserves accounted','emission','audits']),('native-a',['executes positive','preserves first','keeps floor']),('native-b',['forwards checksum','preserves zero','preserves actual','executes refused','leaves COW'])]
rows=[]
for group,filters in groups:
 filters=['RC index update '+x for x in filters]
 if group=='proof':filters+=['RC nonheld','RC inert']
 cmd=['scripts/build-slot.sh','build','env','ZIG_GLOBAL_CACHE_DIR='+str(r/'.mylang-cache/goal110-index-update/zig-global'),'TMPDIR='+str(r/'.mylang-cache/goal110-index-update/tmp'),'/home/epentland/.local/bin/zig','build','test-units','-Doptimize=Debug',*['-Dtest-filter='+x for x in filters],'--prefix','zig-out/index-prefix-final','--cache-dir','.mylang-cache/goal110-index-update/zig-local','-j2']
 log=o/('focused-10-'+group+'.log')
 with log.open('wb') as f:res=subprocess.run(cmd,cwd=r,stdout=f,stderr=subprocess.STDOUT)
 (o/('focused-10-'+group+'.exit')).write_text(str(res.returncode)+'\n')
 output=log.read_text();match=re.search(r'guardian/test: RESULT (.*)',output);assert match,(group,output[-2000:]);result=json.loads(match.group(1))
 rows.append({'group':group,'argv':cmd,'exit':res.returncode,'result':result,'resource_error':'error: memory usage peaked' in output});(o/'focused-10-summary.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(rows[-1]),flush=True)
 assert res.returncode==0 and result['failed']==0 and not rows[-1]['resource_error'],group
