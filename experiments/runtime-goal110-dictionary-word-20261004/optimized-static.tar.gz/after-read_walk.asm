
/home/epentland/ai/canopy/mylang-worktrees/goal110-dict-word-integrated-20261004/.mylang-cache/goal110-dict-word-debug/runner/bin/collections-my-llvm:     file format elf64-x86-64


Disassembly of section .text:

000000000105d520 <read_walk>:
 105d520:	push   %rbp
 105d521:	mov    %rsp,%rbp
 105d524:	push   %r15
 105d526:	push   %r14
 105d528:	push   %r12
 105d52a:	push   %rbx
 105d52b:	sub    $0x10,%rsp
 105d52f:	mov    %rdx,%r14
 105d532:	mov    %rdi,%rbx
 105d535:	mov    0x24(%rdi),%r12d
 105d539:	cmp    $0x2,%r12d
 105d53d:	je     105d54f <read_walk+0x2f>
 105d53f:	cmp    $0x1,%r12d
 105d543:	je     105d54a <read_walk+0x2a>
 105d545:	test   %r12d,%r12d
 105d548:	jne    105d580 <read_walk+0x60>
 105d54a:	mov    (%rsi),%r15
 105d54d:	jmp    105d5be <read_walk+0x9e>
 105d54f:	mov    0x8(%rbx),%rax
 105d553:	mov    (%rax),%rax
 105d556:	movq   $0x0,-0x28(%rbp)
 105d55e:	popcnt %rax,%rcx
 105d563:	cmp    $0x1,%ecx
 105d566:	jne    105d59e <read_walk+0x7e>
 105d568:	tzcnt  %rax,%rcx
 105d56d:	cmp    $0x3,%rcx
 105d571:	ja     105d59e <read_walk+0x7e>
 105d573:	jmp    *0x100b438(,%rcx,8)
 105d57a:	movzbl (%rsi),%r15d
 105d57e:	jmp    105d5be <read_walk+0x9e>
 105d580:	mov    %rbx,%rdi
 105d583:	call   105c8f0 <probe_any>
 105d588:	movl   $0x0,0xf8(%rbx)
 105d592:	cmp    $0xffffffffffffffff,%rax
 105d596:	jne    105d67d <read_walk+0x15d>
 105d59c:	jmp    105d5d0 <read_walk+0xb0>
 105d59e:	cmp    $0x8,%rax
 105d5a2:	mov    $0x8,%edx
 105d5a7:	cmovb  %rax,%rdx
 105d5ab:	lea    -0x28(%rbp),%rdi
 105d5af:	mov    %rsi,%r15
 105d5b2:	call   10712f0 <memcpy@plt>
 105d5b7:	mov    %r15,%rsi
 105d5ba:	mov    -0x28(%rbp),%r15
 105d5be:	cmpl   $0x2,0xf8(%rbx)
 105d5c5:	jne    105d5d7 <read_walk+0xb7>
 105d5c7:	cmp    0xe0(%rbx),%r15
 105d5ce:	jne    105d5d7 <read_walk+0xb7>
 105d5d0:	xor    %eax,%eax
 105d5d2:	jmp    105d6b2 <read_walk+0x192>
 105d5d7:	mov    0xd8(%rbx),%rdi
 105d5de:	test   %rdi,%rdi
 105d5e1:	je     105d657 <read_walk+0x137>
 105d5e3:	cmp    $0x1,%r12d
 105d5e7:	je     105d6bf <read_walk+0x19f>
 105d5ed:	test   %r12d,%r12d
 105d5f0:	jne    105d73f <read_walk+0x21f>
 105d5f6:	mov    (%rsi),%rsi
 105d5f9:	mov    %rbx,%rdi
 105d5fc:	call   105ca10 <probe_text>
 105d601:	cmp    $0xffffffffffffffff,%rax
 105d605:	jne    105d665 <read_walk+0x145>
 105d607:	cmpl   $0x0,0x24(%rbx)
 105d60b:	je     105d759 <read_walk+0x239>
 105d611:	mov    %edx,%eax
 105d613:	cmp    $0xffffffff,%eax
 105d616:	je     105d759 <read_walk+0x239>
 105d61c:	mov    %r15,0xe0(%rbx)
 105d623:	movq   $0x0,0xe8(%rbx)
 105d62e:	mov    %rdx,0xf0(%rbx)
 105d635:	movl   $0x2,0xf8(%rbx)
 105d63f:	vxorps %xmm0,%xmm0,%xmm0
 105d643:	vmovups %xmm0,0xfc(%rbx)
 105d64b:	vmovups %xmm0,0x108(%rbx)
 105d653:	xor    %eax,%eax
 105d655:	jmp    105d6b2 <read_walk+0x192>
 105d657:	mov    %rbx,%rdi
 105d65a:	call   105c8f0 <probe_any>
 105d65f:	cmp    $0xffffffffffffffff,%rax
 105d663:	je     105d607 <read_walk+0xe7>
 105d665:	mov    %r15,0xe0(%rbx)
 105d66c:	mov    %rax,0xe8(%rbx)
 105d673:	movl   $0x1,0xf8(%rbx)
 105d67d:	imul   0x30(%rbx),%rax
 105d682:	mov    (%rbx),%rcx
 105d685:	add    0x20(%rcx),%rax
 105d689:	mov    0x10(%rbx),%rcx
 105d68d:	add    0x18(%rbx),%rax
 105d691:	mov    (%rcx),%rdx
 105d694:	cmp    $0x8,%rdx
 105d698:	jne    105d6a2 <read_walk+0x182>
 105d69a:	mov    (%rax),%rax
 105d69d:	mov    %rax,(%r14)
 105d6a0:	jmp    105d6ad <read_walk+0x18d>
 105d6a2:	mov    %r14,%rdi
 105d6a5:	mov    %rax,%rsi
 105d6a8:	call   1071320 <memmove@plt>
 105d6ad:	mov    $0x1,%eax
 105d6b2:	add    $0x10,%rsp
 105d6b6:	pop    %rbx
 105d6b7:	pop    %r12
 105d6b9:	pop    %r14
 105d6bb:	pop    %r15
 105d6bd:	pop    %rbp
 105d6be:	ret
 105d6bf:	movabs $0x9e3779b97f4a7c15,%rdx
 105d6c9:	xor    %r15,%rdx
 105d6cc:	movabs $0xbf58476d1ce4e5b9,%rax
 105d6d6:	mulx   %rax,%rax,%rcx
 105d6db:	xor    %rax,%rcx
 105d6de:	mov    %rcx,%rdx
 105d6e1:	shr    $0x20,%rdx
 105d6e5:	xor    %rcx,%rdx
 105d6e8:	mov    0xd0(%rbx),%rsi
 105d6ef:	dec    %rdi
 105d6f2:	mov    %edi,%ecx
 105d6f4:	and    %edx,%ecx
 105d6f6:	mov    (%rsi,%rcx,8),%rax
 105d6fa:	test   %rax,%rax
 105d6fd:	je     105d789 <read_walk+0x269>
 105d703:	mov    (%rbx),%r9
 105d706:	mov    0x30(%rbx),%r8
 105d70a:	mov    0x20(%r9),%r9
 105d70e:	jmp    105d71f <read_walk+0x1ff>
 105d710:	inc    %rcx
 105d713:	and    %rdi,%rcx
 105d716:	mov    (%rsi,%rcx,8),%rax
 105d71a:	test   %rax,%rax
 105d71d:	je     105d76a <read_walk+0x24a>
 105d71f:	mov    %rax,%r10
 105d722:	shr    $0x20,%r10
 105d726:	cmp    %r10d,%edx
 105d729:	jne    105d710 <read_walk+0x1f0>
 105d72b:	mov    %eax,%eax
 105d72d:	dec    %rax
 105d730:	mov    %rax,%r10
 105d733:	imul   %r8,%r10
 105d737:	cmp    %r15,(%r9,%r10,1)
 105d73b:	jne    105d710 <read_walk+0x1f0>
 105d73d:	jmp    105d771 <read_walk+0x251>
 105d73f:	mov    %rbx,%rdi
 105d742:	mov    %r15,%rsi
 105d745:	call   105cbb0 <probe_scalar>
 105d74a:	cmp    $0xffffffffffffffff,%rax
 105d74e:	jne    105d665 <read_walk+0x145>
 105d754:	jmp    105d607 <read_walk+0xe7>
 105d759:	movl   $0x0,0xf8(%rbx)
 105d763:	xor    %eax,%eax
 105d765:	jmp    105d6b2 <read_walk+0x192>
 105d76a:	mov    $0xffffffffffffffff,%rax
 105d771:	mov    %ecx,%ecx
 105d773:	shl    $0x20,%rdx
 105d777:	or     %rcx,%rdx
 105d77a:	cmp    $0xffffffffffffffff,%rax
 105d77e:	jne    105d665 <read_walk+0x145>
 105d784:	jmp    105d607 <read_walk+0xe7>
 105d789:	mov    $0xffffffffffffffff,%rax
 105d790:	shl    $0x20,%rdx
 105d794:	or     %rcx,%rdx
 105d797:	cmp    $0xffffffffffffffff,%rax
 105d79b:	jne    105d665 <read_walk+0x145>
 105d7a1:	jmp    105d607 <read_walk+0xe7>
 105d7a6:	mov    (%rsi),%r15d
 105d7a9:	jmp    105d5be <read_walk+0x9e>
 105d7ae:	movzwl (%rsi),%r15d
 105d7b2:	jmp    105d5be <read_walk+0x9e>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
