
/home/epentland/ai/canopy/mylang-worktrees/goal110-integrated-20261004/.mylang-cache/goal110-integrated-debug/runner/bin/collections-my-llvm:     file format elf64-x86-64


Disassembly of section .text:

000000000105d250 <myl_native_dictionary_read>:
 105d250:	push   %rbp
 105d251:	mov    %rsp,%rbp
 105d254:	push   %r15
 105d256:	push   %r14
 105d258:	push   %r13
 105d25a:	push   %r12
 105d25c:	push   %rbx
 105d25d:	push   %rax
 105d25e:	cmpl   $0x1,0xf8(%rdi)
 105d265:	jne    105d4db <myl_native_dictionary_read+0x28b>
 105d26b:	mov    0x24(%rdi),%r15d
 105d26f:	cmp    $0x2,%r15d
 105d273:	je     105d289 <myl_native_dictionary_read+0x39>
 105d275:	cmp    $0x1,%r15d
 105d279:	je     105d284 <myl_native_dictionary_read+0x34>
 105d27b:	test   %r15d,%r15d
 105d27e:	jne    105d4db <myl_native_dictionary_read+0x28b>
 105d284:	mov    (%rsi),%r14
 105d287:	jmp    105d2ec <myl_native_dictionary_read+0x9c>
 105d289:	mov    0x8(%rdi),%rax
 105d28d:	mov    (%rax),%rcx
 105d290:	movq   $0x0,-0x30(%rbp)
 105d298:	popcnt %rcx,%rax
 105d29d:	cmp    $0x1,%eax
 105d2a0:	jne    105d2ba <myl_native_dictionary_read+0x6a>
 105d2a2:	tzcnt  %rcx,%rax
 105d2a7:	cmp    $0x3,%rax
 105d2ab:	ja     105d2ba <myl_native_dictionary_read+0x6a>
 105d2ad:	jmp    *0x100b3f8(,%rax,8)
 105d2b4:	movzbl (%rsi),%r14d
 105d2b8:	jmp    105d2ec <myl_native_dictionary_read+0x9c>
 105d2ba:	cmp    $0x8,%rcx
 105d2be:	mov    $0x8,%eax
 105d2c3:	cmovb  %rcx,%rax
 105d2c7:	lea    -0x30(%rbp),%rcx
 105d2cb:	mov    %rdi,%r14
 105d2ce:	mov    %rcx,%rdi
 105d2d1:	mov    %rsi,%rbx
 105d2d4:	mov    %rdx,%r12
 105d2d7:	mov    %rax,%rdx
 105d2da:	call   1071110 <memcpy@plt>
 105d2df:	mov    %rbx,%rsi
 105d2e2:	mov    %r14,%rdi
 105d2e5:	mov    %r12,%rdx
 105d2e8:	mov    -0x30(%rbp),%r14
 105d2ec:	cmp    0xe0(%rdi),%r14
 105d2f3:	jne    105d4db <myl_native_dictionary_read+0x28b>
 105d2f9:	mov    (%rdi),%rcx
 105d2fc:	mov    0xe8(%rdi),%rax
 105d303:	cmp    (%rcx),%rax
 105d306:	jae    105d4db <myl_native_dictionary_read+0x28b>
 105d30c:	mov    0x30(%rdi),%rbx
 105d310:	imul   %rax,%rbx
 105d314:	add    0x20(%rcx),%rbx
 105d318:	cmp    $0x2,%r15d
 105d31c:	je     105d32c <myl_native_dictionary_read+0xdc>
 105d31e:	cmp    $0x1,%r15d
 105d322:	jne    105d35c <myl_native_dictionary_read+0x10c>
 105d324:	mov    (%rbx),%rax
 105d327:	jmp    105d3b0 <myl_native_dictionary_read+0x160>
 105d32c:	mov    0x8(%rdi),%rax
 105d330:	mov    (%rax),%rcx
 105d333:	movq   $0x0,-0x30(%rbp)
 105d33b:	popcnt %rcx,%rax
 105d340:	cmp    $0x1,%eax
 105d343:	jne    105d37b <myl_native_dictionary_read+0x12b>
 105d345:	tzcnt  %rcx,%rax
 105d34a:	cmp    $0x3,%rax
 105d34e:	ja     105d37b <myl_native_dictionary_read+0x12b>
 105d350:	jmp    *0x100b418(,%rax,8)
 105d357:	movzbl (%rbx),%eax
 105d35a:	jmp    105d3b0 <myl_native_dictionary_read+0x160>
 105d35c:	mov    (%rbx),%rcx
 105d35f:	mov    (%rsi),%r10
 105d362:	cmp    %r10,%rcx
 105d365:	je     105d3b9 <myl_native_dictionary_read+0x169>
 105d367:	testb  $0x4,0x10(%r10)
 105d36c:	jne    105d405 <myl_native_dictionary_read+0x1b5>
 105d372:	lea    0x18(%r10),%r8
 105d376:	jmp    105d414 <myl_native_dictionary_read+0x1c4>
 105d37b:	cmp    $0x8,%rcx
 105d37f:	mov    $0x8,%eax
 105d384:	cmovb  %rcx,%rax
 105d388:	lea    -0x30(%rbp),%rcx
 105d38c:	mov    %rdi,%r15
 105d38f:	mov    %rcx,%rdi
 105d392:	mov    %rsi,%r12
 105d395:	mov    %rbx,%rsi
 105d398:	mov    %rdx,%r13
 105d39b:	mov    %rax,%rdx
 105d39e:	call   1071110 <memcpy@plt>
 105d3a3:	mov    %r12,%rsi
 105d3a6:	mov    %r15,%rdi
 105d3a9:	mov    %r13,%rdx
 105d3ac:	mov    -0x30(%rbp),%rax
 105d3b0:	cmp    %r14,%rax
 105d3b3:	jne    105d4db <myl_native_dictionary_read+0x28b>
 105d3b9:	add    0x18(%rdi),%rbx
 105d3bd:	mov    0x10(%rdi),%rax
 105d3c1:	mov    (%rax),%rax
 105d3c4:	cmp    $0x8,%rax
 105d3c8:	jne    105d3d2 <myl_native_dictionary_read+0x182>
 105d3ca:	mov    (%rbx),%rax
 105d3cd:	mov    %rax,(%rdx)
 105d3d0:	jmp    105d3e0 <myl_native_dictionary_read+0x190>
 105d3d2:	mov    %rdx,%rdi
 105d3d5:	mov    %rbx,%rsi
 105d3d8:	mov    %rax,%rdx
 105d3db:	call   1071140 <memmove@plt>
 105d3e0:	mov    $0x1,%eax
 105d3e5:	add    $0x8,%rsp
 105d3e9:	pop    %rbx
 105d3ea:	pop    %r12
 105d3ec:	pop    %r13
 105d3ee:	pop    %r14
 105d3f0:	pop    %r15
 105d3f2:	pop    %rbp
 105d3f3:	ret
 105d3f4:	mov    (%rsi),%r14d
 105d3f7:	jmp    105d2ec <myl_native_dictionary_read+0x9c>
 105d3fc:	movzwl (%rsi),%r14d
 105d400:	jmp    105d2ec <myl_native_dictionary_read+0x9c>
 105d405:	mov    0x18(%r10),%r8
 105d409:	mov    0x14(%r10),%r9d
 105d40d:	add    %r9,%r8
 105d410:	add    $0x18,%r8
 105d414:	mov    0x8(%rcx),%r9
 105d418:	cmp    0x8(%r10),%r9
 105d41c:	jne    105d4db <myl_native_dictionary_read+0x28b>
 105d422:	cmp    $0x8,%r9
 105d426:	jb     105d447 <myl_native_dictionary_read+0x1f7>
 105d428:	xor    %r10d,%r10d
 105d42b:	lea    0x8(%r10),%r11
 105d42f:	cmp    %r9,%r11
 105d432:	jae    105d472 <myl_native_dictionary_read+0x222>
 105d434:	mov    0x18(%rcx,%r10,1),%r14
 105d439:	cmp    (%r8,%r10,1),%r14
 105d43d:	mov    %r11,%r10
 105d440:	je     105d42b <myl_native_dictionary_read+0x1db>
 105d442:	jmp    105d4db <myl_native_dictionary_read+0x28b>
 105d447:	cmp    $0x3,%r9
 105d44b:	jbe    105d48f <myl_native_dictionary_read+0x23f>
 105d44d:	mov    0x18(%rcx),%r10d
 105d451:	mov    -0x4(%r8,%r9,1),%r11d
 105d456:	xor    (%r8),%r10d
 105d459:	xor    0x14(%rcx,%r9,1),%r11d
 105d45e:	or     %r10d,%r11d
 105d461:	jmp    105d47c <myl_native_dictionary_read+0x22c>
 105d463:	mov    (%rbx),%eax
 105d465:	jmp    105d3b0 <myl_native_dictionary_read+0x160>
 105d46a:	movzwl (%rbx),%eax
 105d46d:	jmp    105d3b0 <myl_native_dictionary_read+0x160>
 105d472:	mov    0x10(%rcx,%r9,1),%rcx
 105d477:	cmp    -0x8(%r8,%r9,1),%rcx
 105d47c:	sete   %cl
 105d47f:	cmp    $0xffffffffffffffff,%rax
 105d483:	je     105d4db <myl_native_dictionary_read+0x28b>
 105d485:	test   %cl,%cl
 105d487:	jne    105d3b9 <myl_native_dictionary_read+0x169>
 105d48d:	jmp    105d4db <myl_native_dictionary_read+0x28b>
 105d48f:	test   %r9,%r9
 105d492:	je     105d3b9 <myl_native_dictionary_read+0x169>
 105d498:	movzbl 0x18(%rcx),%r10d
 105d49d:	cmp    (%r8),%r10b
 105d4a0:	jne    105d4db <myl_native_dictionary_read+0x28b>
 105d4a2:	cmp    $0x1,%r9
 105d4a6:	je     105d3b9 <myl_native_dictionary_read+0x169>
 105d4ac:	movzbl 0x19(%rcx),%r10d
 105d4b1:	cmp    0x1(%r8),%r10b
 105d4b5:	jne    105d4db <myl_native_dictionary_read+0x28b>
 105d4b7:	cmp    $0x2,%r9
 105d4bb:	je     105d3b9 <myl_native_dictionary_read+0x169>
 105d4c1:	movzbl 0x1a(%rcx),%ecx
 105d4c5:	cmp    0x2(%r8),%cl
 105d4c9:	setne  %cl
 105d4cc:	cmp    $0xffffffffffffffff,%rax
 105d4d0:	sete   %al
 105d4d3:	or     %cl,%al
 105d4d5:	je     105d3b9 <myl_native_dictionary_read+0x169>
 105d4db:	add    $0x8,%rsp
 105d4df:	pop    %rbx
 105d4e0:	pop    %r12
 105d4e2:	pop    %r13
 105d4e4:	pop    %r14
 105d4e6:	pop    %r15
 105d4e8:	pop    %rbp
 105d4e9:	jmp    105d4f0 <read_walk>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
