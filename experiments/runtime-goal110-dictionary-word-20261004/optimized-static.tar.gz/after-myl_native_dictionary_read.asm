
/home/epentland/ai/canopy/mylang-worktrees/goal110-dict-word-integrated-20261004/.mylang-cache/goal110-dict-word-debug/runner/bin/collections-my-llvm:     file format elf64-x86-64


Disassembly of section .text:

000000000105d280 <myl_native_dictionary_read>:
 105d280:	push   %rbp
 105d281:	mov    %rsp,%rbp
 105d284:	push   %r15
 105d286:	push   %r14
 105d288:	push   %r13
 105d28a:	push   %r12
 105d28c:	push   %rbx
 105d28d:	push   %rax
 105d28e:	cmpl   $0x1,0xf8(%rdi)
 105d295:	jne    105d50b <myl_native_dictionary_read+0x28b>
 105d29b:	mov    0x24(%rdi),%r15d
 105d29f:	cmp    $0x2,%r15d
 105d2a3:	je     105d2b9 <myl_native_dictionary_read+0x39>
 105d2a5:	cmp    $0x1,%r15d
 105d2a9:	je     105d2b4 <myl_native_dictionary_read+0x34>
 105d2ab:	test   %r15d,%r15d
 105d2ae:	jne    105d50b <myl_native_dictionary_read+0x28b>
 105d2b4:	mov    (%rsi),%r14
 105d2b7:	jmp    105d31c <myl_native_dictionary_read+0x9c>
 105d2b9:	mov    0x8(%rdi),%rax
 105d2bd:	mov    (%rax),%rcx
 105d2c0:	movq   $0x0,-0x30(%rbp)
 105d2c8:	popcnt %rcx,%rax
 105d2cd:	cmp    $0x1,%eax
 105d2d0:	jne    105d2ea <myl_native_dictionary_read+0x6a>
 105d2d2:	tzcnt  %rcx,%rax
 105d2d7:	cmp    $0x3,%rax
 105d2db:	ja     105d2ea <myl_native_dictionary_read+0x6a>
 105d2dd:	jmp    *0x100b3f8(,%rax,8)
 105d2e4:	movzbl (%rsi),%r14d
 105d2e8:	jmp    105d31c <myl_native_dictionary_read+0x9c>
 105d2ea:	cmp    $0x8,%rcx
 105d2ee:	mov    $0x8,%eax
 105d2f3:	cmovb  %rcx,%rax
 105d2f7:	lea    -0x30(%rbp),%rcx
 105d2fb:	mov    %rdi,%r14
 105d2fe:	mov    %rcx,%rdi
 105d301:	mov    %rsi,%rbx
 105d304:	mov    %rdx,%r12
 105d307:	mov    %rax,%rdx
 105d30a:	call   10712f0 <memcpy@plt>
 105d30f:	mov    %rbx,%rsi
 105d312:	mov    %r14,%rdi
 105d315:	mov    %r12,%rdx
 105d318:	mov    -0x30(%rbp),%r14
 105d31c:	cmp    0xe0(%rdi),%r14
 105d323:	jne    105d50b <myl_native_dictionary_read+0x28b>
 105d329:	mov    (%rdi),%rcx
 105d32c:	mov    0xe8(%rdi),%rax
 105d333:	cmp    (%rcx),%rax
 105d336:	jae    105d50b <myl_native_dictionary_read+0x28b>
 105d33c:	mov    0x30(%rdi),%rbx
 105d340:	imul   %rax,%rbx
 105d344:	add    0x20(%rcx),%rbx
 105d348:	cmp    $0x2,%r15d
 105d34c:	je     105d35c <myl_native_dictionary_read+0xdc>
 105d34e:	cmp    $0x1,%r15d
 105d352:	jne    105d38c <myl_native_dictionary_read+0x10c>
 105d354:	mov    (%rbx),%rax
 105d357:	jmp    105d3e0 <myl_native_dictionary_read+0x160>
 105d35c:	mov    0x8(%rdi),%rax
 105d360:	mov    (%rax),%rcx
 105d363:	movq   $0x0,-0x30(%rbp)
 105d36b:	popcnt %rcx,%rax
 105d370:	cmp    $0x1,%eax
 105d373:	jne    105d3ab <myl_native_dictionary_read+0x12b>
 105d375:	tzcnt  %rcx,%rax
 105d37a:	cmp    $0x3,%rax
 105d37e:	ja     105d3ab <myl_native_dictionary_read+0x12b>
 105d380:	jmp    *0x100b418(,%rax,8)
 105d387:	movzbl (%rbx),%eax
 105d38a:	jmp    105d3e0 <myl_native_dictionary_read+0x160>
 105d38c:	mov    (%rbx),%rcx
 105d38f:	mov    (%rsi),%r10
 105d392:	cmp    %r10,%rcx
 105d395:	je     105d3e9 <myl_native_dictionary_read+0x169>
 105d397:	testb  $0x4,0x10(%r10)
 105d39c:	jne    105d435 <myl_native_dictionary_read+0x1b5>
 105d3a2:	lea    0x18(%r10),%r8
 105d3a6:	jmp    105d444 <myl_native_dictionary_read+0x1c4>
 105d3ab:	cmp    $0x8,%rcx
 105d3af:	mov    $0x8,%eax
 105d3b4:	cmovb  %rcx,%rax
 105d3b8:	lea    -0x30(%rbp),%rcx
 105d3bc:	mov    %rdi,%r15
 105d3bf:	mov    %rcx,%rdi
 105d3c2:	mov    %rsi,%r12
 105d3c5:	mov    %rbx,%rsi
 105d3c8:	mov    %rdx,%r13
 105d3cb:	mov    %rax,%rdx
 105d3ce:	call   10712f0 <memcpy@plt>
 105d3d3:	mov    %r12,%rsi
 105d3d6:	mov    %r15,%rdi
 105d3d9:	mov    %r13,%rdx
 105d3dc:	mov    -0x30(%rbp),%rax
 105d3e0:	cmp    %r14,%rax
 105d3e3:	jne    105d50b <myl_native_dictionary_read+0x28b>
 105d3e9:	add    0x18(%rdi),%rbx
 105d3ed:	mov    0x10(%rdi),%rax
 105d3f1:	mov    (%rax),%rax
 105d3f4:	cmp    $0x8,%rax
 105d3f8:	jne    105d402 <myl_native_dictionary_read+0x182>
 105d3fa:	mov    (%rbx),%rax
 105d3fd:	mov    %rax,(%rdx)
 105d400:	jmp    105d410 <myl_native_dictionary_read+0x190>
 105d402:	mov    %rdx,%rdi
 105d405:	mov    %rbx,%rsi
 105d408:	mov    %rax,%rdx
 105d40b:	call   1071320 <memmove@plt>
 105d410:	mov    $0x1,%eax
 105d415:	add    $0x8,%rsp
 105d419:	pop    %rbx
 105d41a:	pop    %r12
 105d41c:	pop    %r13
 105d41e:	pop    %r14
 105d420:	pop    %r15
 105d422:	pop    %rbp
 105d423:	ret
 105d424:	mov    (%rsi),%r14d
 105d427:	jmp    105d31c <myl_native_dictionary_read+0x9c>
 105d42c:	movzwl (%rsi),%r14d
 105d430:	jmp    105d31c <myl_native_dictionary_read+0x9c>
 105d435:	mov    0x18(%r10),%r8
 105d439:	mov    0x14(%r10),%r9d
 105d43d:	add    %r9,%r8
 105d440:	add    $0x18,%r8
 105d444:	mov    0x8(%rcx),%r9
 105d448:	cmp    0x8(%r10),%r9
 105d44c:	jne    105d50b <myl_native_dictionary_read+0x28b>
 105d452:	cmp    $0x8,%r9
 105d456:	jb     105d477 <myl_native_dictionary_read+0x1f7>
 105d458:	xor    %r10d,%r10d
 105d45b:	lea    0x8(%r10),%r11
 105d45f:	cmp    %r9,%r11
 105d462:	jae    105d4a2 <myl_native_dictionary_read+0x222>
 105d464:	mov    0x18(%rcx,%r10,1),%r14
 105d469:	cmp    (%r8,%r10,1),%r14
 105d46d:	mov    %r11,%r10
 105d470:	je     105d45b <myl_native_dictionary_read+0x1db>
 105d472:	jmp    105d50b <myl_native_dictionary_read+0x28b>
 105d477:	cmp    $0x3,%r9
 105d47b:	jbe    105d4bf <myl_native_dictionary_read+0x23f>
 105d47d:	mov    0x18(%rcx),%r10d
 105d481:	mov    -0x4(%r8,%r9,1),%r11d
 105d486:	xor    (%r8),%r10d
 105d489:	xor    0x14(%rcx,%r9,1),%r11d
 105d48e:	or     %r10d,%r11d
 105d491:	jmp    105d4ac <myl_native_dictionary_read+0x22c>
 105d493:	mov    (%rbx),%eax
 105d495:	jmp    105d3e0 <myl_native_dictionary_read+0x160>
 105d49a:	movzwl (%rbx),%eax
 105d49d:	jmp    105d3e0 <myl_native_dictionary_read+0x160>
 105d4a2:	mov    0x10(%rcx,%r9,1),%rcx
 105d4a7:	cmp    -0x8(%r8,%r9,1),%rcx
 105d4ac:	sete   %cl
 105d4af:	cmp    $0xffffffffffffffff,%rax
 105d4b3:	je     105d50b <myl_native_dictionary_read+0x28b>
 105d4b5:	test   %cl,%cl
 105d4b7:	jne    105d3e9 <myl_native_dictionary_read+0x169>
 105d4bd:	jmp    105d50b <myl_native_dictionary_read+0x28b>
 105d4bf:	test   %r9,%r9
 105d4c2:	je     105d3e9 <myl_native_dictionary_read+0x169>
 105d4c8:	movzbl 0x18(%rcx),%r10d
 105d4cd:	cmp    (%r8),%r10b
 105d4d0:	jne    105d50b <myl_native_dictionary_read+0x28b>
 105d4d2:	cmp    $0x1,%r9
 105d4d6:	je     105d3e9 <myl_native_dictionary_read+0x169>
 105d4dc:	movzbl 0x19(%rcx),%r10d
 105d4e1:	cmp    0x1(%r8),%r10b
 105d4e5:	jne    105d50b <myl_native_dictionary_read+0x28b>
 105d4e7:	cmp    $0x2,%r9
 105d4eb:	je     105d3e9 <myl_native_dictionary_read+0x169>
 105d4f1:	movzbl 0x1a(%rcx),%ecx
 105d4f5:	cmp    0x2(%r8),%cl
 105d4f9:	setne  %cl
 105d4fc:	cmp    $0xffffffffffffffff,%rax
 105d500:	sete   %al
 105d503:	or     %cl,%al
 105d505:	je     105d3e9 <myl_native_dictionary_read+0x169>
 105d50b:	add    $0x8,%rsp
 105d50f:	pop    %rbx
 105d510:	pop    %r12
 105d512:	pop    %r13
 105d514:	pop    %r14
 105d516:	pop    %r15
 105d518:	pop    %rbp
 105d519:	jmp    105d520 <read_walk>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
