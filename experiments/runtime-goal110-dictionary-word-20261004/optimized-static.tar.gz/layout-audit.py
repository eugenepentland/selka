#!/usr/bin/env python3
"""Read-only instruction/layout comparison; does not run guests or alter ELF files."""
import bisect, datetime, difflib, hashlib, json, re, subprocess
from pathlib import Path

root=Path.cwd(); out=root/'.mylang-cache/goal110-dict-word/static/layout'
out.mkdir(exist_ok=True)
paths={'before':Path('/home/epentland/ai/canopy/mylang-worktrees/goal110-integrated-20261004/.mylang-cache/goal110-integrated-debug/runner/manifest.json'),'after':root/'.mylang-cache/goal110-dict-word-debug/runner/manifest.json'}
def h(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def bound(p): return {'path':str(Path(p).resolve()),'sha256':h(p)}
report={'schema':'mylang-dictionary-word-layout-audit-v1','read_only':True,'timing':False,'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'driver':bound(__file__),'manifests':{k:bound(p) for k,p in paths.items()},'backends':{}}
for backend in ['llvm','qbe']:
 arms={}
 for arm,p in paths.items():
  manifest=json.loads(p.read_text());binary=Path(manifest['identity']['binary_paths']['collections/my-'+backend]);assert h(binary)==manifest['binary_hashes']['collections/my-'+backend]
  side=json.loads(Path(str(binary)+'.qbe-manifest.json').read_text())
  llvm=Path(manifest['identity']['binary_paths']['collections/my-llvm']);llvm_side=json.loads(Path(str(llvm)+'.qbe-manifest.json').read_text())
  symbol=next(f['symbol'] for f in llvm_side['functions'] if f['name']=='main::batch_result')
  nm=subprocess.check_output(['nm','-S','--defined-only','--numeric-sort',str(binary)],text=True)
  syms={line.split()[-1]:(int(line.split()[0],16),int(line.split()[1],16),line.split()[2]) for line in nm.splitlines() if len(line.split())==4}
  occupied=sorted((a,n,size) for n,(a,size,t) in syms.items() if size>0);starts=[x[0] for x in occupied]
  asm=subprocess.check_output(['objdump','-d','--no-show-raw-insn',str(binary)],text=True);saved=out/(arm+'-'+backend+'.asm');saved.write_text(asm)
  functions={};current=None
  def normalize(line):
   ins=re.match(r'^\s*([0-9a-f]+):\s+(.*)$',line)
   if not ins:return None
   text=ins[2]
   text=re.sub(r'\b[0-9a-f]+ <([^>]+)>',r'<\1>',text)
   text=re.sub(r'-?0x[0-9a-f]+\(%rip\)',r'(%rip)',text)
   def immediate(m):
    value=int(m[1],16);i=bisect.bisect_right(starts,value)-1
    if i>=0:
     a,n,size=occupied[i]
     if value<a+size:return '$<'+n+('+'+hex(value-a) if value!=a else '')+'>'
    return m[0]
   text=re.sub(r'\$0x([0-9a-f]+)',immediate,text)
   return text
  for line in asm.splitlines():
   match=re.match(r'^([0-9a-f]+) <([^>]+)>:$',line)
   if match:current=match[2];functions[current]=[]
   elif current:
    ins=normalize(line)
    if ins is not None:functions[current].append(ins)
  arms[arm]={'binary':bound(binary),'sidecar':bound(str(binary)+'.qbe-manifest.json'),'assembly':bound(saved),'symbols':syms,'instructions':functions,'batch_symbol':symbol}
 b,a=arms['before'],arms['after'];assert b['batch_symbol']==a['batch_symbol'];symbol=b['batch_symbol']
 changed=[]
 for name in sorted(set(b['instructions'])&set(a['instructions'])):
  if b['instructions'][name]!=a['instructions'][name]:
   delta=list(difflib.unified_diff(b['instructions'][name],a['instructions'][name],fromfile='before/'+name,tofile='after/'+name,n=2));f=out/(backend+'-'+name+'.diff');f.write_text('\n'.join(delta)+'\n');changed.append({'symbol':name,'diff':bound(f),'before':b['symbols'].get(name),'after':a['symbols'].get(name),'instruction_count':[len(x['instructions'][name]) for x in [b,a]]})
 normalized_a=[x.replace('<myl_native_dictionary_read_word>','<myl_native_dictionary_read>') for x in a['instructions'][symbol]]
 clone=None
 if backend=='llvm':
  old='myl_rc_owner_take.421';new='myl_rc_owner_take.423'
  clone={'before':old,'after':new,'equal_after_clone_symbol_rename':[x.replace(old,'OWNER_CLONE') for x in b['instructions'][old]]==[x.replace(new,'OWNER_CLONE') for x in a['instructions'][new]]}
  assert clone['equal_after_clone_symbol_rename']
 report['backends'][backend]={'artifacts':{k:{key:v for key,v in arm.items() if key not in ['symbols','instructions']} for k,arm in arms.items()},'batch':{'symbol':symbol,'before_symbol':b['symbols'][symbol],'after_symbol':a['symbols'][symbol],'instruction_count':[len(x['instructions'][symbol]) for x in [b,a]],'equal_after_two_callee_substitutions':b['instructions'][symbol]==normalized_a,'before_calls':[x for x in b['instructions'][symbol] if x.startswith('call')],'after_calls':[x for x in a['instructions'][symbol] if x.startswith('call')]},'clone_identity':clone,'changed_functions':changed,'added_functions':sorted(set(a['instructions'])-set(b['instructions'])),'removed_functions':sorted(set(b['instructions'])-set(a['instructions'])),'existing_functions':len(set(b['instructions'])&set(a['instructions']))}
report.update(status='complete',finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());p=out/'report.json';p.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'report':bound(p),'backends':{k:{'batch_equal_after_two_callee_substitutions':v['batch']['equal_after_two_callee_substitutions'],'changed_functions':[x['symbol'] for x in v['changed_functions']],'added_functions':v['added_functions'],'removed_functions':v['removed_functions'],'existing_functions':v['existing_functions']} for k,v in report['backends'].items()}},indent=2))
