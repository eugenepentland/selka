#!/usr/bin/env python3
"""Read-only frozen-port IR, helper machine code and control ELF inspection."""
import datetime,hashlib,json,re,struct,subprocess
from pathlib import Path
root=Path.cwd();work=root/'.mylang-cache/goal110-dict-word-debug';out=root/'.mylang-cache/goal110-dict-word/static'
paths={'before':Path('/home/epentland/ai/canopy/mylang-worktrees/goal110-integrated-20261004/.mylang-cache/goal110-integrated-debug/runner/manifest.json'),'after':work/'runner/manifest.json'}
def artifact(p):
 p=Path(p).resolve(strict=True);return {'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
def elf(p):
 d=Path(p).read_bytes();assert d[:6]==b'\x7fELF\x02\x01';offset=struct.unpack_from('<Q',d,40)[0];ent,count,idx=struct.unpack_from('<HHH',d,58)
 sh=[struct.unpack_from('<IIQQQQIIQQ',d,offset+i*ent) for i in range(count)];strings=d[sh[idx][4]:sh[idx][4]+sh[idx][5]];sections={}
 for x in sh:
  if x[2]&2:
   name=strings[x[0]:strings.index(b'\0',x[0])].decode();sections[name]={'type':x[1],'flags':x[2],'address':x[3],'size':x[5],'alignment':x[8],'bytes_sha256':None if x[1]==8 else hashlib.sha256(d[x[4]:x[4]+x[5]]).hexdigest()}
 phoff=struct.unpack_from('<Q',d,32)[0];phent,phcount=struct.unpack_from('<HH',d,54);headers=[struct.unpack_from('<IIQQQQQQ',d,phoff+i*phent) for i in range(phcount)]
 ph=[{'header':list(x),'load_sha256':hashlib.sha256(d[x[2]:x[2]+x[5]]).hexdigest() if x[0]==1 else None} for x in headers]
 return sections,ph
ms={k:json.loads(p.read_text()) for k,p in paths.items()};assert artifact(paths['before'])['sha256']=='a64af04cdb495d00c49d562789fcb6341349bf3f411d7783ba7400ba4cbe92ce'
report={'schema':'mylang-dictionary-word-static-code-v1','timing':False,'read_only':True,'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'driver':artifact(__file__),'manifests':{k:artifact(p) for k,p in paths.items()},'sources':{k:m['identity']['source_revision'] for k,m in ms.items()},'frontend':{},'code':{},'controls':[]}
for arm,m in ms.items():
 for name,p in m['identity']['binary_paths'].items():assert artifact(p)['sha256']==m['binary_hashes'][name]
(out/'code-before.json').write_text(json.dumps(report,indent=2)+'\n')
for arm in ms:
 p=out/(arm+'-collections.json');r=json.loads(p.read_text());fn=next(f for f in r['functions'] if f['name']=='main::batch_result');ssa=out/(arm+'-batch_result.ssa');ssa.write_text(fn['il'])
 report['frontend'][arm]={'manifest':artifact(p),'body':artifact(ssa),'word_calls':fn['il'].count('call $myl_native_dictionary_read_word('),'ordinary_calls':fn['il'].count('call $myl_native_dictionary_read(')}
assert report['frontend']['before']['word_calls']==0 and report['frontend']['after']['word_calls']==2
before=json.loads((out/'before-collections.json').read_text());after=json.loads((out/'after-collections.json').read_text())
assert len(before['functions'])==len(after['functions'])
changes=[]
for a,b in zip(before['functions'],after['functions']):
 assert a['name']==b['name']
 if a['il']!=b['il']:
  assert a['il'].replace('call $myl_native_dictionary_read(','call $myl_native_dictionary_read_word(')==b['il'],a['name'];changes.append(a['name'])
report['frontend_change']='Exact whole-function IL difference is only the two generic→word callee substitutions.';report['frontend_changed_functions']=changes
for arm,m in ms.items():
 binary=Path(m['identity']['binary_paths']['collections/my-llvm']);side=Path(str(binary)+'.qbe-manifest.json');policy=json.loads(side.read_text());assert policy['backend']=='llvm' and policy['optimization']=='3' and policy['lto'] is True and policy['thin_lto'] is False
 nm=subprocess.check_output(['nm','-S','--defined-only',str(binary)],text=True);syms={line.split()[-1]:(int(line.split()[0],16),int(line.split()[1],16)) for line in nm.splitlines() if len(line.split())==4}
 data={'binary':artifact(binary),'sidecar':artifact(side),'policy':{k:policy[k] for k in ['backend','optimization','lto','thin_lto']},'functions':{}}
 names=['myl_native_dictionary_read','read_walk','myl_native_dictionary_read_word']
 for f in policy['functions']:
  if f['name']=='main::batch_result':names.append(f['symbol']);data['batch_symbol']=f['symbol']
 for symbol in names:
  if symbol not in syms:continue
  address,size=syms[symbol];command=['objdump','-d','--no-show-raw-insn','--disassemble='+symbol,str(binary)];asm=subprocess.check_output(command,text=True);p=out/(arm+'-'+symbol+'.asm');p.write_text(asm)
  data['functions'][symbol]={'address':hex(address),'bytes':size,'assembly':artifact(p),'command':command,'calls':re.findall(r'\bcall\s+[^\n]*',asm),'generic_read_calls':len(re.findall(r'\bcall\s+[^\n]*<myl_native_dictionary_read>',asm)),'word_read_calls':len(re.findall(r'\bcall\s+[^\n]*<myl_native_dictionary_read_word>',asm))}
 report['code'][arm]=data
assert 'myl_native_dictionary_read_word' not in report['code']['before']['functions'];word=report['code']['after']['functions']['myl_native_dictionary_read_word'];assert word['calls']==[]
for group in ['legacy','compute','collections','text']:
 for arm in ['my-llvm','my-qbe']:
  name=group+'/'+arm;row={'name':name,'artifacts':{}}
  for label,m in ms.items():
   p=Path(m['identity']['binary_paths'][name]);sections,ph=elf(p);row['artifacts'][label]={'binary':artifact(p),'sections':sections,'program_headers':ph}
  b,a=[row['artifacts'][x] for x in ['before','after']];row['allocated_sections_identical']=b['sections']==a['sections'];row['text_identical']=b['sections']['.text']==a['sections']['.text'];row['program_headers_identical']=[x['header'] for x in b['program_headers']]==[x['header'] for x in a['program_headers']]
  row['executable_loads_identical']=[x for x in b['program_headers'] if x['header'][0]==1 and x['header'][1]&1]==[x for x in a['program_headers'] if x['header'][0]==1 and x['header'][1]&1]
  row['different_allocated_sections']=[x for x in sorted(set(b['sections'])|set(a['sections'])) if b['sections'].get(x)!=a['sections'].get(x)];report['controls'].append(row)
for arm,m in ms.items():
 assert artifact(paths[arm])==report['manifests'][arm]
 for name,p in m['identity']['binary_paths'].items():assert artifact(p)['sha256']==m['binary_hashes'][name]
assert artifact(__file__)==report['driver'];report.update(status='passed',finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());(out/'code-proof.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'frontend':report['frontend'],'function_sizes':{k:{n:f['bytes'] for n,f in v['functions'].items()} for k,v in report['code'].items()},'controls':[{k:v for k,v in r.items() if k!='artifacts'} for r in report['controls']]},indent=2))
