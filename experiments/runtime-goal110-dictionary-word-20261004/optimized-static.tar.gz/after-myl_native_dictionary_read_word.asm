
/home/epentland/ai/canopy/mylang-worktrees/goal110-dict-word-integrated-20261004/.mylang-cache/goal110-dict-word-debug/runner/bin/collections-my-llvm:     file format elf64-x86-64


Disassembly of section .text:

000000000105d7c0 <myl_native_dictionary_read_word>:
 105d7c0:	push   %rbp
 105d7c1:	mov    %rsp,%rbp
 105d7c4:	push   %r15
 105d7c6:	push   %r14
 105d7c8:	push   %rbx
 105d7c9:	cmpl   $0x1,0x24(%rdi)
 105d7cd:	jne    105d89e <myl_native_dictionary_read_word+0xde>
 105d7d3:	mov    0x10(%rdi),%rax
 105d7d7:	cmpw   $0x0,0x30(%rax)
 105d7dc:	jne    105d89e <myl_native_dictionary_read_word+0xde>
 105d7e2:	cmpq   $0x8,(%rax)
 105d7e6:	jne    105d89e <myl_native_dictionary_read_word+0xde>
 105d7ec:	mov    (%rsi),%rcx
 105d7ef:	mov    0xf8(%rdi),%eax
 105d7f5:	cmp    $0x2,%eax
 105d7f8:	je     105d82b <myl_native_dictionary_read_word+0x6b>
 105d7fa:	cmp    $0x1,%eax
 105d7fd:	jne    105d83a <myl_native_dictionary_read_word+0x7a>
 105d7ff:	cmp    %rcx,0xe0(%rdi)
 105d806:	jne    105d83a <myl_native_dictionary_read_word+0x7a>
 105d808:	mov    (%rdi),%rax
 105d80b:	mov    0xe8(%rdi),%rbx
 105d812:	cmp    (%rax),%rbx
 105d815:	jae    105d83a <myl_native_dictionary_read_word+0x7a>
 105d817:	mov    0x20(%rax),%r9
 105d81b:	imul   0x30(%rdi),%rbx
 105d820:	cmp    %rcx,(%r9,%rbx,1)
 105d824:	jne    105d83a <myl_native_dictionary_read_word+0x7a>
 105d826:	jmp    105d8fb <myl_native_dictionary_read_word+0x13b>
 105d82b:	xor    %eax,%eax
 105d82d:	cmp    %rcx,0xe0(%rdi)
 105d834:	je     105d963 <myl_native_dictionary_read_word+0x1a3>
 105d83a:	mov    0xd8(%rdi),%r8
 105d841:	test   %r8,%r8
 105d844:	je     105d89e <myl_native_dictionary_read_word+0xde>
 105d846:	mov    %rdx,%rbx
 105d849:	movabs $0x9e3779b97f4a7c15,%rdx
 105d853:	xor    %rcx,%rdx
 105d856:	movabs $0xbf58476d1ce4e5b9,%rax
 105d860:	mulx   %rax,%rax,%rdx
 105d865:	xor    %rax,%rdx
 105d868:	mov    %rdx,%rax
 105d86b:	shr    $0x20,%rax
 105d86f:	xor    %rdx,%rax
 105d872:	mov    0xd0(%rdi),%r10
 105d879:	dec    %r8
 105d87c:	mov    %r8d,%esi
 105d87f:	and    %eax,%esi
 105d881:	mov    (%r10,%rsi,8),%r14
 105d885:	test   %r14,%r14
 105d888:	je     105d912 <myl_native_dictionary_read_word+0x152>
 105d88e:	mov    (%rdi),%rdx
 105d891:	mov    0x30(%rdi),%r11
 105d895:	mov    0x20(%rdx),%r9
 105d899:	mov    %rbx,%rdx
 105d89c:	jmp    105d8bf <myl_native_dictionary_read_word+0xff>
 105d89e:	pop    %rbx
 105d89f:	pop    %r14
 105d8a1:	pop    %r15
 105d8a3:	pop    %rbp
 105d8a4:	jmp    105d280 <myl_native_dictionary_read>
 105d8a9:	nopl   0x0(%rax)
 105d8b0:	inc    %rsi
 105d8b3:	and    %r8,%rsi
 105d8b6:	mov    (%r10,%rsi,8),%r14
 105d8ba:	test   %r14,%r14
 105d8bd:	je     105d910 <myl_native_dictionary_read_word+0x150>
 105d8bf:	mov    %r14,%rbx
 105d8c2:	shr    $0x20,%rbx
 105d8c6:	cmp    %ebx,%eax
 105d8c8:	jne    105d8b0 <myl_native_dictionary_read_word+0xf0>
 105d8ca:	mov    %r14d,%r15d
 105d8cd:	lea    -0x1(%r15),%r14
 105d8d1:	mov    %r14,%rbx
 105d8d4:	imul   %r11,%rbx
 105d8d8:	cmp    %rcx,(%r9,%rbx,1)
 105d8dc:	jne    105d8b0 <myl_native_dictionary_read_word+0xf0>
 105d8de:	test   %r15,%r15
 105d8e1:	je     105d910 <myl_native_dictionary_read_word+0x150>
 105d8e3:	mov    %rcx,0xe0(%rdi)
 105d8ea:	mov    %r14,0xe8(%rdi)
 105d8f1:	movl   $0x1,0xf8(%rdi)
 105d8fb:	add    %r9,%rbx
 105d8fe:	mov    0x18(%rdi),%rax
 105d902:	mov    (%rax,%rbx,1),%rax
 105d906:	mov    %rax,(%rdx)
 105d909:	mov    $0x1,%eax
 105d90e:	jmp    105d963 <myl_native_dictionary_read_word+0x1a3>
 105d910:	mov    %esi,%esi
 105d912:	shl    $0x20,%rax
 105d916:	or     %rsi,%rax
 105d919:	cmp    $0xffffffff,%esi
 105d91c:	jne    105d92a <myl_native_dictionary_read_word+0x16a>
 105d91e:	movl   $0x0,0xf8(%rdi)
 105d928:	jmp    105d961 <myl_native_dictionary_read_word+0x1a1>
 105d92a:	mov    %rcx,0xe0(%rdi)
 105d931:	movq   $0x0,0xe8(%rdi)
 105d93c:	mov    %rax,0xf0(%rdi)
 105d943:	movl   $0x2,0xf8(%rdi)
 105d94d:	vxorps %xmm0,%xmm0,%xmm0
 105d951:	vmovups %xmm0,0xfc(%rdi)
 105d959:	vmovups %xmm0,0x108(%rdi)
 105d961:	xor    %eax,%eax
 105d963:	pop    %rbx
 105d964:	pop    %r14
 105d966:	pop    %r15
 105d968:	pop    %rbp
 105d969:	ret

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
