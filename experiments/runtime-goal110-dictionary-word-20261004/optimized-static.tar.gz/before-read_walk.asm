
/home/epentland/ai/canopy/mylang-worktrees/goal110-integrated-20261004/.mylang-cache/goal110-integrated-debug/runner/bin/collections-my-llvm:     file format elf64-x86-64


Disassembly of section .text:

000000000105d4f0 <read_walk>:
 105d4f0:	push   %rbp
 105d4f1:	mov    %rsp,%rbp
 105d4f4:	push   %r15
 105d4f6:	push   %r14
 105d4f8:	push   %r12
 105d4fa:	push   %rbx
 105d4fb:	sub    $0x10,%rsp
 105d4ff:	mov    %rdx,%r14
 105d502:	mov    %rdi,%rbx
 105d505:	mov    0x24(%rdi),%r12d
 105d509:	cmp    $0x2,%r12d
 105d50d:	je     105d51f <read_walk+0x2f>
 105d50f:	cmp    $0x1,%r12d
 105d513:	je     105d51a <read_walk+0x2a>
 105d515:	test   %r12d,%r12d
 105d518:	jne    105d550 <read_walk+0x60>
 105d51a:	mov    (%rsi),%r15
 105d51d:	jmp    105d58e <read_walk+0x9e>
 105d51f:	mov    0x8(%rbx),%rax
 105d523:	mov    (%rax),%rax
 105d526:	movq   $0x0,-0x28(%rbp)
 105d52e:	popcnt %rax,%rcx
 105d533:	cmp    $0x1,%ecx
 105d536:	jne    105d56e <read_walk+0x7e>
 105d538:	tzcnt  %rax,%rcx
 105d53d:	cmp    $0x3,%rcx
 105d541:	ja     105d56e <read_walk+0x7e>
 105d543:	jmp    *0x100b438(,%rcx,8)
 105d54a:	movzbl (%rsi),%r15d
 105d54e:	jmp    105d58e <read_walk+0x9e>
 105d550:	mov    %rbx,%rdi
 105d553:	call   105c8c0 <probe_any>
 105d558:	movl   $0x0,0xf8(%rbx)
 105d562:	cmp    $0xffffffffffffffff,%rax
 105d566:	jne    105d64d <read_walk+0x15d>
 105d56c:	jmp    105d5a0 <read_walk+0xb0>
 105d56e:	cmp    $0x8,%rax
 105d572:	mov    $0x8,%edx
 105d577:	cmovb  %rax,%rdx
 105d57b:	lea    -0x28(%rbp),%rdi
 105d57f:	mov    %rsi,%r15
 105d582:	call   1071110 <memcpy@plt>
 105d587:	mov    %r15,%rsi
 105d58a:	mov    -0x28(%rbp),%r15
 105d58e:	cmpl   $0x2,0xf8(%rbx)
 105d595:	jne    105d5a7 <read_walk+0xb7>
 105d597:	cmp    0xe0(%rbx),%r15
 105d59e:	jne    105d5a7 <read_walk+0xb7>
 105d5a0:	xor    %eax,%eax
 105d5a2:	jmp    105d682 <read_walk+0x192>
 105d5a7:	mov    0xd8(%rbx),%rdi
 105d5ae:	test   %rdi,%rdi
 105d5b1:	je     105d627 <read_walk+0x137>
 105d5b3:	cmp    $0x1,%r12d
 105d5b7:	je     105d68f <read_walk+0x19f>
 105d5bd:	test   %r12d,%r12d
 105d5c0:	jne    105d70f <read_walk+0x21f>
 105d5c6:	mov    (%rsi),%rsi
 105d5c9:	mov    %rbx,%rdi
 105d5cc:	call   105c9e0 <probe_text>
 105d5d1:	cmp    $0xffffffffffffffff,%rax
 105d5d5:	jne    105d635 <read_walk+0x145>
 105d5d7:	cmpl   $0x0,0x24(%rbx)
 105d5db:	je     105d729 <read_walk+0x239>
 105d5e1:	mov    %edx,%eax
 105d5e3:	cmp    $0xffffffff,%eax
 105d5e6:	je     105d729 <read_walk+0x239>
 105d5ec:	mov    %r15,0xe0(%rbx)
 105d5f3:	movq   $0x0,0xe8(%rbx)
 105d5fe:	mov    %rdx,0xf0(%rbx)
 105d605:	movl   $0x2,0xf8(%rbx)
 105d60f:	vxorps %xmm0,%xmm0,%xmm0
 105d613:	vmovups %xmm0,0xfc(%rbx)
 105d61b:	vmovups %xmm0,0x108(%rbx)
 105d623:	xor    %eax,%eax
 105d625:	jmp    105d682 <read_walk+0x192>
 105d627:	mov    %rbx,%rdi
 105d62a:	call   105c8c0 <probe_any>
 105d62f:	cmp    $0xffffffffffffffff,%rax
 105d633:	je     105d5d7 <read_walk+0xe7>
 105d635:	mov    %r15,0xe0(%rbx)
 105d63c:	mov    %rax,0xe8(%rbx)
 105d643:	movl   $0x1,0xf8(%rbx)
 105d64d:	imul   0x30(%rbx),%rax
 105d652:	mov    (%rbx),%rcx
 105d655:	add    0x20(%rcx),%rax
 105d659:	mov    0x10(%rbx),%rcx
 105d65d:	add    0x18(%rbx),%rax
 105d661:	mov    (%rcx),%rdx
 105d664:	cmp    $0x8,%rdx
 105d668:	jne    105d672 <read_walk+0x182>
 105d66a:	mov    (%rax),%rax
 105d66d:	mov    %rax,(%r14)
 105d670:	jmp    105d67d <read_walk+0x18d>
 105d672:	mov    %r14,%rdi
 105d675:	mov    %rax,%rsi
 105d678:	call   1071140 <memmove@plt>
 105d67d:	mov    $0x1,%eax
 105d682:	add    $0x10,%rsp
 105d686:	pop    %rbx
 105d687:	pop    %r12
 105d689:	pop    %r14
 105d68b:	pop    %r15
 105d68d:	pop    %rbp
 105d68e:	ret
 105d68f:	movabs $0x9e3779b97f4a7c15,%rdx
 105d699:	xor    %r15,%rdx
 105d69c:	movabs $0xbf58476d1ce4e5b9,%rax
 105d6a6:	mulx   %rax,%rax,%rcx
 105d6ab:	xor    %rax,%rcx
 105d6ae:	mov    %rcx,%rdx
 105d6b1:	shr    $0x20,%rdx
 105d6b5:	xor    %rcx,%rdx
 105d6b8:	mov    0xd0(%rbx),%rsi
 105d6bf:	dec    %rdi
 105d6c2:	mov    %edi,%ecx
 105d6c4:	and    %edx,%ecx
 105d6c6:	mov    (%rsi,%rcx,8),%rax
 105d6ca:	test   %rax,%rax
 105d6cd:	je     105d759 <read_walk+0x269>
 105d6d3:	mov    (%rbx),%r9
 105d6d6:	mov    0x30(%rbx),%r8
 105d6da:	mov    0x20(%r9),%r9
 105d6de:	jmp    105d6ef <read_walk+0x1ff>
 105d6e0:	inc    %rcx
 105d6e3:	and    %rdi,%rcx
 105d6e6:	mov    (%rsi,%rcx,8),%rax
 105d6ea:	test   %rax,%rax
 105d6ed:	je     105d73a <read_walk+0x24a>
 105d6ef:	mov    %rax,%r10
 105d6f2:	shr    $0x20,%r10
 105d6f6:	cmp    %r10d,%edx
 105d6f9:	jne    105d6e0 <read_walk+0x1f0>
 105d6fb:	mov    %eax,%eax
 105d6fd:	dec    %rax
 105d700:	mov    %rax,%r10
 105d703:	imul   %r8,%r10
 105d707:	cmp    %r15,(%r9,%r10,1)
 105d70b:	jne    105d6e0 <read_walk+0x1f0>
 105d70d:	jmp    105d741 <read_walk+0x251>
 105d70f:	mov    %rbx,%rdi
 105d712:	mov    %r15,%rsi
 105d715:	call   105cb80 <probe_scalar>
 105d71a:	cmp    $0xffffffffffffffff,%rax
 105d71e:	jne    105d635 <read_walk+0x145>
 105d724:	jmp    105d5d7 <read_walk+0xe7>
 105d729:	movl   $0x0,0xf8(%rbx)
 105d733:	xor    %eax,%eax
 105d735:	jmp    105d682 <read_walk+0x192>
 105d73a:	mov    $0xffffffffffffffff,%rax
 105d741:	mov    %ecx,%ecx
 105d743:	shl    $0x20,%rdx
 105d747:	or     %rcx,%rdx
 105d74a:	cmp    $0xffffffffffffffff,%rax
 105d74e:	jne    105d635 <read_walk+0x145>
 105d754:	jmp    105d5d7 <read_walk+0xe7>
 105d759:	mov    $0xffffffffffffffff,%rax
 105d760:	shl    $0x20,%rdx
 105d764:	or     %rcx,%rdx
 105d767:	cmp    $0xffffffffffffffff,%rax
 105d76b:	jne    105d635 <read_walk+0x145>
 105d771:	jmp    105d5d7 <read_walk+0xe7>
 105d776:	mov    (%rsi),%r15d
 105d779:	jmp    105d58e <read_walk+0x9e>
 105d77e:	movzwl (%rsi),%r15d
 105d782:	jmp    105d58e <read_walk+0x9e>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
