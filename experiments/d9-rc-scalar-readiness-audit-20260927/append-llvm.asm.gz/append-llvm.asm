
.tmp-mut-argument/type-facts/controls/parity-micro-list_append_sum-after-llvm-production:     file format elf64-x86-64


Disassembly of section .text:

000000000100a050 <entry_run>:
 100a050:	push   %rbp
 100a051:	mov    %rsp,%rbp
 100a054:	push   %r15
 100a056:	push   %r14
 100a058:	push   %r13
 100a05a:	push   %r12
 100a05c:	push   %rbx
 100a05d:	sub    $0x178,%rsp
 100a064:	mov    %rdi,%rbx
 100a067:	cmpq   $0x0,0x38a0(%rdi)
 100a06f:	je     100a081 <entry_run+0x31>
 100a071:	cmpq   $0x0,0x20(%rbx)
 100a076:	jne    100b415 <entry_run+0x13c5>
 100a07c:	jmp    100a191 <entry_run+0x141>
 100a081:	mov    $0x1,%edi
 100a086:	mov    $0x40,%esi
 100a08b:	call   101bbf0 <calloc@plt>
 100a090:	test   %rax,%rax
 100a093:	je     100a160 <entry_run+0x110>
 100a099:	mov    %rax,0x38a0(%rbx)
 100a0a0:	mov    0x3870(%rbx),%rcx
 100a0a7:	lea    0xa0(%rcx),%rdx
 100a0ae:	test   %rcx,%rcx
 100a0b1:	mov    $0x1002d48,%ecx
 100a0b6:	cmovne %rdx,%rcx
 100a0ba:	mov    %rcx,(%rax)
 100a0bd:	cmpq   $0x0,0x8(%rcx)
 100a0c2:	je     100a0ce <entry_run+0x7e>
 100a0c4:	cmpq   $0x0,(%rcx)
 100a0c8:	je     100a167 <entry_run+0x117>
 100a0ce:	mov    0x10(%rcx),%rdx
 100a0d2:	test   %rdx,%rdx
 100a0d5:	mov    $0x2710,%esi
 100a0da:	cmovne %rdx,%rsi
 100a0de:	mov    %rsi,0x18(%rax)
 100a0e2:	mov    0x18(%rcx),%rdx
 100a0e6:	test   %rdx,%rdx
 100a0e9:	mov    $0xf4240,%esi
 100a0ee:	cmovne %rdx,%rsi
 100a0f2:	mov    %rsi,0x10(%rax)
 100a0f6:	mov    0x20(%rcx),%rdx
 100a0fa:	test   %rdx,%rdx
 100a0fd:	mov    $0x10000,%edi
 100a102:	cmovne %rdx,%rdi
 100a106:	mov    %rdi,0x20(%rax)
 100a10a:	mov    0x28(%rcx),%rsi
 100a10e:	test   %rsi,%rsi
 100a111:	mov    $0x40,%edx
 100a116:	cmovne %rsi,%rdx
 100a11a:	mov    %rdx,0x28(%rax)
 100a11e:	mov    0x30(%rcx),%r8
 100a122:	test   %r8,%r8
 100a125:	mov    $0x100000,%esi
 100a12a:	cmovne %r8,%rsi
 100a12e:	mov    %rsi,0x30(%rax)
 100a132:	cmp    $0x186a0,%rdi
 100a139:	ja     100a159 <entry_run+0x109>
 100a13b:	cmp    $0x81,%rdx
 100a142:	setae  %dl
 100a145:	cmp    $0x4000001,%rsi
 100a14c:	setae  %sil
 100a150:	or     %dl,%sil
 100a153:	cmp    $0x1,%sil
 100a157:	jne    100a16e <entry_run+0x11e>
 100a159:	mov    $0x1002eda,%esi
 100a15e:	jmp    100a17e <entry_run+0x12e>
 100a160:	mov    $0x1002d82,%esi
 100a165:	jmp    100a17e <entry_run+0x12e>
 100a167:	mov    $0x100302b,%esi
 100a16c:	jmp    100a17e <entry_run+0x12e>
 100a16e:	cmpq   $0x0,0x8(%rcx)
 100a173:	je     100aacf <entry_run+0xa7f>
 100a179:	mov    $0x1003017,%esi
 100a17e:	mov    %rbx,%rdi
 100a181:	call   100bd10 <fail>
 100a186:	cmpq   $0x0,0x20(%rbx)
 100a18b:	jne    100b415 <entry_run+0x13c5>
 100a191:	movq   $0x0,-0x178(%rbp)
 100a19c:	movq   $0x0,-0x40(%rbp)
 100a1a4:	movq   $0x0,-0xa8(%rbp)
 100a1af:	mov    0x2c8(%rbx),%r12d
 100a1b6:	vxorps %xmm0,%xmm0,%xmm0
 100a1ba:	vmovups %ymm0,-0x60(%rbp)
 100a1bf:	vmovups %ymm0,-0x70(%rbp)
 100a1c4:	lea    -0x60(%rbp),%rax
 100a1c8:	movq   $0x1001ab8,-0x168(%rbp)
 100a1d3:	movl   $0x2,-0x150(%rbp)
 100a1dd:	lea    -0x178(%rbp),%r15
 100a1e4:	mov    %r15,-0x160(%rbp)
 100a1eb:	lea    -0x70(%rbp),%r13
 100a1ef:	mov    %r13,-0x158(%rbp)
 100a1f6:	movq   $0x1001ab8,-0x148(%rbp)
 100a201:	movl   $0x2,-0x130(%rbp)
 100a20b:	lea    -0x40(%rbp),%rcx
 100a20f:	mov    %rcx,-0x140(%rbp)
 100a216:	lea    -0x68(%rbp),%rcx
 100a21a:	mov    %rcx,-0x138(%rbp)
 100a221:	movq   $0x1001ab8,-0x128(%rbp)
 100a22c:	movl   $0x2,-0x110(%rbp)
 100a236:	lea    -0xa8(%rbp),%rcx
 100a23d:	mov    %rcx,-0x120(%rbp)
 100a244:	mov    %rax,-0x118(%rbp)
 100a24b:	movq   $0x1001c78,-0x108(%rbp)
 100a256:	movl   $0x0,-0xf0(%rbp)
 100a260:	lea    -0x78(%rbp),%rax
 100a264:	mov    %rax,-0x100(%rbp)
 100a26b:	lea    -0x58(%rbp),%rax
 100a26f:	mov    %rax,-0xf8(%rbp)
 100a276:	movq   $0x1001c78,-0xe8(%rbp)
 100a281:	movl   $0x0,-0xd0(%rbp)
 100a28b:	lea    -0x38(%rbp),%rax
 100a28f:	mov    %rax,-0xe0(%rbp)
 100a296:	lea    -0x50(%rbp),%rax
 100a29a:	mov    %rax,-0xd8(%rbp)
 100a2a1:	movq   $0x1001c78,-0xc8(%rbp)
 100a2ac:	movl   $0x0,-0xb0(%rbp)
 100a2b6:	lea    -0x198(%rbp),%rax
 100a2bd:	mov    %rax,-0xc0(%rbp)
 100a2c4:	lea    -0x48(%rbp),%rax
 100a2c8:	mov    %rax,-0xb8(%rbp)
 100a2cf:	mov    0x1860(%rbx),%rax
 100a2d6:	test   %rax,%rax
 100a2d9:	je     100b49f <entry_run+0x144f>
 100a2df:	mov    0x3d80(%rbx),%rcx
 100a2e6:	mov    0x70(%rax),%rax
 100a2ea:	mov    %rcx,-0x98(%rbp)
 100a2f1:	lea    -0x168(%rbp),%rcx
 100a2f8:	mov    %rcx,-0x90(%rbp)
 100a2ff:	movq   $0x6,-0x88(%rbp)
 100a30a:	mov    %rax,-0x80(%rbp)
 100a30e:	lea    -0x98(%rbp),%rax
 100a315:	mov    %rax,0x3d80(%rbx)
 100a31c:	cmpq   $0xffffffffffffffff,0x10(%rbx)
 100a321:	je     100a358 <entry_run+0x308>
 100a323:	movl   $0x1,0x38e0(%rbx)
 100a32d:	vmovups %ymm0,0x38e4(%rbx)
 100a335:	vmovups %ymm0,0x38f0(%rbx)
 100a33d:	movq   $0x100311a,0x3910(%rbx)
 100a348:	mov    $0x100356d,%esi
 100a34d:	mov    %rbx,%rdi
 100a350:	vzeroupper
 100a353:	call   100bd10 <fail>
 100a358:	cmpq   $0xffffffffffffffff,0x38(%rbx)
 100a35d:	je     100a39f <entry_run+0x34f>
 100a35f:	cmpq   $0x0,0x20(%rbx)
 100a364:	jne    100a38f <entry_run+0x33f>
 100a366:	movl   $0x1,0x38e0(%rbx)
 100a370:	vxorps %xmm0,%xmm0,%xmm0
 100a374:	vmovups %ymm0,0x38e4(%rbx)
 100a37c:	vmovups %ymm0,0x38f0(%rbx)
 100a384:	movq   $0x1003163,0x3910(%rbx)
 100a38f:	mov    $0x1003582,%esi
 100a394:	mov    %rbx,%rdi
 100a397:	vzeroupper
 100a39a:	call   100bd10 <fail>
 100a39f:	movq   $0x0,-0x30(%rbp)
 100a3a7:	cmpq   $0x0,0x1860(%rbx)
 100a3af:	je     100b4be <entry_run+0x146e>
 100a3b5:	lea    0x258(%rbx),%rdi
 100a3bc:	mov    0x2c8(%rbx),%ecx
 100a3c2:	mov    $0x1001a48,%esi
 100a3c7:	xor    %edx,%edx
 100a3c9:	vzeroupper
 100a3cc:	call   100f890 <rc_list_new>
 100a3d1:	test   %rax,%rax
 100a3d4:	je     100b4be <entry_run+0x146e>
 100a3da:	movabs $0x5000000000000001,%r14
 100a3e4:	mov    %rax,-0x38(%rbp)
 100a3e8:	movq   $0x1001ab8,-0xe8(%rbp)
 100a3f3:	movl   $0x2,-0xd0(%rbp)
 100a3fd:	mov    %rax,-0x78(%rbp)
 100a401:	movq   $0x1001ab8,-0x108(%rbp)
 100a40c:	movl   $0x2,-0xf0(%rbp)
 100a416:	movl   $0x0,-0x50(%rbp)
 100a41d:	movl   $0x1,-0x58(%rbp)
 100a424:	mov    %rax,-0x30(%rbp)
 100a428:	test   %r14,-0x10(%rax)
 100a42c:	je     100a47e <entry_run+0x42e>
 100a42e:	lea    -0x38(%rbp),%rsi
 100a432:	lea    -0x30(%rbp),%rdx
 100a436:	lea    0x258(%rbx),%rdi
 100a43d:	mov    %r12d,%ecx
 100a440:	call   1017e00 <myl_rc_native_take>
 100a445:	test   %eax,%eax
 100a447:	jne    100a486 <entry_run+0x436>
 100a449:	mov    0x1860(%rbx),%rcx
 100a450:	test   %rcx,%rcx
 100a453:	je     100b49f <entry_run+0x144f>
 100a459:	mov    0x78(%rcx),%eax
 100a45c:	movl   $0x0,0x78(%rcx)
 100a463:	test   %eax,%eax
 100a465:	lea    -0x98(%rbp),%r12
 100a46c:	lea    0x258(%rbx),%r15
 100a473:	jne    100a827 <entry_run+0x7d7>
 100a479:	jmp    100b374 <entry_run+0x1324>
 100a47e:	movq   $0x0,-0x30(%rbp)
 100a486:	movl   $0x0,-0x58(%rbp)
 100a48d:	movq   $0x1001ab8,-0xe8(%rbp)
 100a498:	movl   $0x2,-0xd0(%rbp)
 100a4a2:	movl   $0x1,-0x50(%rbp)
 100a4a9:	cmpl   $0x0,-0x70(%rbp)
 100a4ad:	je     100a4c6 <entry_run+0x476>
 100a4af:	lea    -0x168(%rbp),%rsi
 100a4b6:	mov    %rbx,%rdi
 100a4b9:	call   100b4e0 <myl_qbe_rc_slot_drop>
 100a4be:	mov    -0xd0(%rbp),%ecx
 100a4c4:	jmp    100a4cb <entry_run+0x47b>
 100a4c6:	mov    $0x2,%ecx
 100a4cb:	mov    -0x38(%rbp),%rax
 100a4cf:	mov    %rax,-0x178(%rbp)
 100a4d6:	movl   $0x0,-0x50(%rbp)
 100a4dd:	movq   $0x1001ab8,-0x168(%rbp)
 100a4e8:	mov    %r15,-0x160(%rbp)
 100a4ef:	mov    %r13,-0x158(%rbp)
 100a4f6:	mov    %ecx,-0x150(%rbp)
 100a4fc:	movl   $0x1,-0x70(%rbp)
 100a503:	cmp    $0x8,%ecx
 100a506:	jne    100a5de <entry_run+0x58e>
 100a50c:	movq   $0x0,-0x38(%rbp)
 100a514:	test   %rax,%rax
 100a517:	lea    0x258(%rbx),%r15
 100a51e:	lea    -0x38(%rbp),%rsi
 100a522:	je     100a570 <entry_run+0x520>
 100a524:	mov    -0x10(%rax),%rcx
 100a528:	movabs $0x4000000000000002,%rdx
 100a532:	test   %rdx,%rcx
 100a535:	jne    100a570 <entry_run+0x520>
 100a537:	cmpq   $0x0,0x1860(%rbx)
 100a53f:	je     100b49f <entry_run+0x144f>
 100a545:	test   $0x1,%cl
 100a548:	jne    100b49f <entry_run+0x144f>
 100a54e:	mov    -0x18(%rax),%rcx
 100a552:	mov    -0x20(%rax),%rdx
 100a556:	or     %rcx,%rdx
 100a559:	je     100b49f <entry_run+0x144f>
 100a55f:	cmp    $0xffffffffffffffff,%rcx
 100a563:	je     100b479 <entry_run+0x1429>
 100a569:	inc    %rcx
 100a56c:	mov    %rcx,-0x18(%rax)
 100a570:	mov    %rax,-0x38(%rbp)
 100a574:	movq   $0x1001ab8,-0xe8(%rbp)
 100a57f:	mov    %rsi,-0xe0(%rbp)
 100a586:	lea    -0x50(%rbp),%rcx
 100a58a:	mov    %rcx,-0xd8(%rbp)
 100a591:	movl   $0x8,-0xd0(%rbp)
 100a59b:	mov    %rax,-0x78(%rbp)
 100a59f:	movq   $0x1001ab8,-0x108(%rbp)
 100a5aa:	lea    -0x78(%rbp),%rcx
 100a5ae:	mov    %rcx,-0x100(%rbp)
 100a5b5:	lea    -0x58(%rbp),%rcx
 100a5b9:	mov    %rcx,-0xf8(%rbp)
 100a5c0:	movl   $0x8,-0xf0(%rbp)
 100a5ca:	movl   $0x1,-0x58(%rbp)
 100a5d1:	movl   $0x0,-0x50(%rbp)
 100a5d8:	mov    %rax,-0x30(%rbp)
 100a5dc:	jmp    100a631 <entry_run+0x5e1>
 100a5de:	mov    -0x58(%rbp),%ecx
 100a5e1:	testb  $0x18,-0xf0(%rbp)
 100a5e8:	mov    %rax,-0x30(%rbp)
 100a5ec:	lea    0x258(%rbx),%r15
 100a5f3:	jne    100a631 <entry_run+0x5e1>
 100a5f5:	and    $0x1,%ecx
 100a5f8:	je     100a631 <entry_run+0x5e1>
 100a5fa:	test   %rax,%rax
 100a5fd:	je     100a9ef <entry_run+0x99f>
 100a603:	test   %r14,-0x10(%rax)
 100a607:	je     100a9ef <entry_run+0x99f>
 100a60d:	lea    -0x38(%rbp),%rsi
 100a611:	lea    -0x30(%rbp),%rdx
 100a615:	mov    %r15,%rdi
 100a618:	mov    %r12d,%ecx
 100a61b:	call   1017e00 <myl_rc_native_take>
 100a620:	test   %eax,%eax
 100a622:	lea    -0x68(%rbp),%r12
 100a626:	jne    100a9ff <entry_run+0x9af>
 100a62c:	jmp    100a7fe <entry_run+0x7ae>
 100a631:	lea    -0x38(%rbp),%rdx
 100a635:	lea    -0x30(%rbp),%rcx
 100a639:	mov    $0x1001ab8,%esi
 100a63e:	mov    %r15,%rdi
 100a641:	mov    %r12d,%r8d
 100a644:	call   1018220 <myl_rc_native_retain>
 100a649:	test   %eax,%eax
 100a64b:	je     100a7fe <entry_run+0x7ae>
 100a651:	movq   $0x1001ab8,-0xe8(%rbp)
 100a65c:	movl   $0x2,-0xd0(%rbp)
 100a666:	movl   $0x1,-0x50(%rbp)
 100a66d:	cmpl   $0x0,-0x58(%rbp)
 100a671:	lea    -0x68(%rbp),%r12
 100a675:	je     100a686 <entry_run+0x636>
 100a677:	mov    %rbx,%rdi
 100a67a:	lea    -0x108(%rbp),%rsi
 100a681:	call   100b4e0 <myl_qbe_rc_slot_drop>
 100a686:	cmpl   $0x0,-0x68(%rbp)
 100a68a:	lea    -0x40(%rbp),%r14
 100a68e:	je     100a69f <entry_run+0x64f>
 100a690:	lea    -0x148(%rbp),%rsi
 100a697:	mov    %rbx,%rdi
 100a69a:	call   100b4e0 <myl_qbe_rc_slot_drop>
 100a69f:	mov    -0x38(%rbp),%rax
 100a6a3:	mov    %rax,-0x40(%rbp)
 100a6a7:	movl   $0x0,-0x50(%rbp)
 100a6ae:	movq   $0x1001ab8,-0x148(%rbp)
 100a6b9:	mov    %r14,-0x140(%rbp)
 100a6c0:	mov    %r12,-0x138(%rbp)
 100a6c7:	mov    -0xd0(%rbp),%eax
 100a6cd:	mov    %eax,-0x130(%rbp)
 100a6d3:	movl   $0x1,-0x68(%rbp)
 100a6da:	cmpl   $0x0,-0x70(%rbp)
 100a6de:	je     100a6ef <entry_run+0x69f>
 100a6e0:	lea    -0x168(%rbp),%rsi
 100a6e7:	mov    %rbx,%rdi
 100a6ea:	call   100b4e0 <myl_qbe_rc_slot_drop>
 100a6ef:	movq   $0xf42400,-0x30(%rbp)
 100a6f7:	movq   $0x1001ab8,-0x148(%rbp)
 100a702:	movl   $0x2,-0x130(%rbp)
 100a70c:	mov    %r14,-0x140(%rbp)
 100a713:	mov    %r12,-0x138(%rbp)
 100a71a:	mov    0x1860(%rbx),%rcx
 100a721:	test   %rcx,%rcx
 100a724:	je     100b49f <entry_run+0x144f>
 100a72a:	mov    0x40(%rcx),%rax
 100a72e:	test   %rax,%rax
 100a731:	je     100b49f <entry_run+0x144f>
 100a737:	movabs $0xbf58476d1ce4e5b9,%r12
 100a741:	mov    0x30(%rcx),%rcx
 100a745:	mov    $0x1001ab8,%esi
 100a74a:	mov    $0x1001ab8,%edx
 100a74f:	shr    $0x3,%rdx
 100a753:	shr    $0x21,%rsi
 100a757:	xor    %rdx,%rsi
 100a75a:	imul   %r12,%rsi
 100a75e:	mov    %rsi,%rdx
 100a761:	shr    $0x1b,%rdx
 100a765:	xor    %rsi,%rdx
 100a768:	xor    $0x2,%rdx
 100a76c:	dec    %rax
 100a76f:	jmp    100a783 <entry_run+0x733>
 100a771:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 100a780:	inc    %rdx
 100a783:	and    %rax,%rdx
 100a786:	lea    (%rdx,%rdx,4),%rsi
 100a78a:	mov    (%rcx,%rsi,8),%rsi
 100a78e:	test   %rsi,%rsi
 100a791:	je     100b49f <entry_run+0x144f>
 100a797:	cmp    $0x1001ab8,%rsi
 100a79e:	jne    100a780 <entry_run+0x730>
 100a7a0:	lea    (%rdx,%rdx,4),%rsi
 100a7a4:	cmpl   $0x2,0x20(%rcx,%rsi,8)
 100a7a9:	jne    100a780 <entry_run+0x730>
 100a7ab:	lea    (%rcx,%rsi,8),%rdx
 100a7af:	mov    0x8(%rdx),%rdx
 100a7b3:	test   %rdx,%rdx
 100a7b6:	je     100b49f <entry_run+0x144f>
 100a7bc:	mov    0x8(%rdx),%rsi
 100a7c0:	cmpl   $0x1,0x8(%rsi)
 100a7c4:	jne    100b49f <entry_run+0x144f>
 100a7ca:	movabs $0x4000000000000002,%r14
 100a7d4:	mov    -0x40(%rbp),%r13
 100a7d8:	test   %r13,%r13
 100a7db:	je     100a847 <entry_run+0x7f7>
 100a7dd:	mov    -0x10(%r13),%rdi
 100a7e1:	lea    -0x2(%r14),%r8
 100a7e5:	mov    %rdi,%r9
 100a7e8:	shr    $0x28,%r9
 100a7ec:	and    $0xfffff,%r9d
 100a7f3:	xor    %edx,%edx
 100a7f5:	test   %r8,%rdi
 100a7f8:	cmovne %r9d,%edx
 100a7fc:	jmp    100a849 <entry_run+0x7f9>
 100a7fe:	mov    0x1860(%rbx),%rcx
 100a805:	test   %rcx,%rcx
 100a808:	je     100b49f <entry_run+0x144f>
 100a80e:	mov    0x78(%rcx),%eax
 100a811:	movl   $0x0,0x78(%rcx)
 100a818:	test   %eax,%eax
 100a81a:	lea    -0x98(%rbp),%r12
 100a821:	je     100b374 <entry_run+0x1324>
 100a827:	cmp    $0x1,%eax
 100a82a:	jne    100a9e1 <entry_run+0x991>
 100a830:	mov    $0x10034a2,%esi
 100a835:	cmpl   $0x0,0x2c4(%rbx)
 100a83c:	jne    100b36c <entry_run+0x131c>
 100a842:	jmp    100b35d <entry_run+0x130d>
 100a847:	xor    %edx,%edx
 100a849:	mov    %rsi,%rdi
 100a84c:	shr    $0x3,%rdi
 100a850:	mov    %rsi,%r8
 100a853:	shr    $0x21,%r8
 100a857:	xor    %rdi,%r8
 100a85a:	imul   %r12,%r8
 100a85e:	mov    %r8,%rdi
 100a861:	shr    $0x1b,%rdi
 100a865:	xor    %r8,%rdi
 100a868:	xor    $0x1,%rdi
 100a86c:	and    %rax,%rdi
 100a86f:	cmpl   $0x0,-0x68(%rbp)
 100a873:	lea    (%rdi,%rdi,4),%r8
 100a877:	mov    (%rcx,%r8,8),%r8
 100a87b:	jne    100a89e <entry_run+0x84e>
 100a87d:	jmp    100a94e <entry_run+0x8fe>
 100a882:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 100a890:	inc    %rdi
 100a893:	and    %rax,%rdi
 100a896:	lea    (%rdi,%rdi,4),%r8
 100a89a:	mov    (%rcx,%r8,8),%r8
 100a89e:	test   %r8,%r8
 100a8a1:	je     100b49f <entry_run+0x144f>
 100a8a7:	cmp    %rsi,%r8
 100a8aa:	jne    100a890 <entry_run+0x840>
 100a8ac:	lea    (%rdi,%rdi,4),%r8
 100a8b0:	cmpl   $0x1,0x20(%rcx,%r8,8)
 100a8b6:	jne    100a890 <entry_run+0x840>
 100a8b8:	lea    (%rcx,%r8,8),%rax
 100a8bc:	cmpq   $0x0,0x8(%rax)
 100a8c1:	je     100b49f <entry_run+0x144f>
 100a8c7:	cmpq   $0x8,(%rsi)
 100a8cb:	jne    100b49f <entry_run+0x144f>
 100a8d1:	test   %r13,%r13
 100a8d4:	je     100ab27 <entry_run+0xad7>
 100a8da:	mov    -0x10(%r13),%rax
 100a8de:	movabs $0x2000000000000002,%rcx
 100a8e8:	test   %rcx,%rax
 100a8eb:	je     100aa35 <entry_run+0x9e5>
 100a8f1:	movq   $0x0,-0x190(%rbp)
 100a8fc:	lea    -0x190(%rbp),%rcx
 100a903:	mov    %r15,%rdi
 100a906:	mov    %r13,%rsi
 100a909:	call   1016ca0 <clone_payload>
 100a90e:	test   %eax,%eax
 100a910:	je     100aa66 <entry_run+0xa16>
 100a916:	cmp    $0x1,%eax
 100a919:	je     100b348 <entry_run+0x12f8>
 100a91f:	cmp    $0x4,%eax
 100a922:	lea    -0x98(%rbp),%r12
 100a929:	jb     100b362 <entry_run+0x1312>
 100a92f:	jmp    100a9ea <entry_run+0x99a>
 100a934:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 100a940:	inc    %rdi
 100a943:	and    %rax,%rdi
 100a946:	lea    (%rdi,%rdi,4),%r8
 100a94a:	mov    (%rcx,%r8,8),%r8
 100a94e:	test   %r8,%r8
 100a951:	je     100b49f <entry_run+0x144f>
 100a957:	cmp    %rsi,%r8
 100a95a:	jne    100a940 <entry_run+0x8f0>
 100a95c:	lea    (%rdi,%rdi,4),%r8
 100a960:	cmpl   $0x1,0x20(%rcx,%r8,8)
 100a966:	jne    100a940 <entry_run+0x8f0>
 100a968:	lea    (%rcx,%r8,8),%rax
 100a96c:	cmpq   $0x0,0x8(%rax)
 100a971:	je     100b49f <entry_run+0x144f>
 100a977:	cmpq   $0x8,(%rsi)
 100a97b:	jne    100b49f <entry_run+0x144f>
 100a981:	test   %r13,%r13
 100a984:	je     100ab27 <entry_run+0xad7>
 100a98a:	mov    -0x10(%r13),%rax
 100a98e:	movabs $0x2000000000000002,%rcx
 100a998:	test   %rcx,%rax
 100a99b:	je     100aae6 <entry_run+0xa96>
 100a9a1:	movq   $0x0,-0x190(%rbp)
 100a9ac:	lea    -0x190(%rbp),%rcx
 100a9b3:	mov    %r15,%rdi
 100a9b6:	mov    %r13,%rsi
 100a9b9:	call   1016ca0 <clone_payload>
 100a9be:	xor    %ecx,%ecx
 100a9c0:	test   %eax,%eax
 100a9c2:	jne    100a9cb <entry_run+0x97b>
 100a9c4:	mov    -0x190(%rbp),%rcx
 100a9cb:	jne    100ab16 <entry_run+0xac6>
 100a9d1:	mov    %rcx,-0x40(%rbp)
 100a9d5:	movl   $0x1,-0x68(%rbp)
 100a9dc:	jmp    100ab27 <entry_run+0xad7>
 100a9e1:	cmp    $0x4,%eax
 100a9e4:	jb     100b362 <entry_run+0x1312>
 100a9ea:	call   101bd20 <abort@plt>
 100a9ef:	mov    %rax,-0x38(%rbp)
 100a9f3:	movq   $0x0,-0x30(%rbp)
 100a9fb:	lea    -0x68(%rbp),%r12
 100a9ff:	movl   $0x0,-0x58(%rbp)
 100aa06:	movq   $0x1001ab8,-0xe8(%rbp)
 100aa11:	movl   $0x2,-0xd0(%rbp)
 100aa1b:	movl   $0x1,-0x50(%rbp)
 100aa22:	cmpl   $0x0,-0x68(%rbp)
 100aa26:	lea    -0x40(%rbp),%r14
 100aa2a:	jne    100a690 <entry_run+0x640>
 100aa30:	jmp    100a69f <entry_run+0x64f>
 100aa35:	lea    -0x2(%r14),%rcx
 100aa39:	test   %rcx,%rax
 100aa3c:	jne    100ab27 <entry_run+0xad7>
 100aa42:	test   $0x1,%al
 100aa44:	jne    100b49f <entry_run+0x144f>
 100aa4a:	mov    -0x20(%r13),%rax
 100aa4e:	cmp    $0x1,%rax
 100aa52:	je     100ab27 <entry_run+0xad7>
 100aa58:	test   %rax,%rax
 100aa5b:	je     100ab0a <entry_run+0xaba>
 100aa61:	jmp    100a8f1 <entry_run+0x8a1>
 100aa66:	mov    -0x190(%rbp),%rax
 100aa6d:	mov    %rax,-0x40(%rbp)
 100aa71:	mov    -0x10(%r13),%rax
 100aa75:	test   %r14,%rax
 100aa78:	jne    100aac5 <entry_run+0xa75>
 100aa7a:	mov    0x1860(%rbx),%rcx
 100aa81:	test   %rcx,%rcx
 100aa84:	je     100b49f <entry_run+0x144f>
 100aa8a:	test   $0x1,%al
 100aa8c:	jne    100b49f <entry_run+0x144f>
 100aa92:	lea    -0x20(%r13),%rdx
 100aa96:	mov    (%rdx),%rsi
 100aa99:	test   %rsi,%rsi
 100aa9c:	je     100b49f <entry_run+0x144f>
 100aaa2:	dec    %rsi
 100aaa5:	mov    %rsi,(%rdx)
 100aaa8:	jne    100aac5 <entry_run+0xa75>
 100aaaa:	cmpq   $0x0,-0x18(%r13)
 100aaaf:	jne    100aac5 <entry_run+0xa75>
 100aab1:	or     $0x1,%rax
 100aab5:	mov    %rax,-0x10(%r13)
 100aab9:	mov    0x60(%rcx),%rax
 100aabd:	mov    %rax,-0x20(%r13)
 100aac1:	mov    %rdx,0x60(%rcx)
 100aac5:	mov    %r15,%rdi
 100aac8:	call   1012cf0 <myl_rc_drain>
 100aacd:	jmp    100ab27 <entry_run+0xad7>
 100aacf:	movl   $0x1,0x38(%rax)
 100aad6:	cmpq   $0x0,0x20(%rbx)
 100aadb:	jne    100b415 <entry_run+0x13c5>
 100aae1:	jmp    100a191 <entry_run+0x141>
 100aae6:	lea    -0x2(%r14),%rcx
 100aaea:	test   %rcx,%rax
 100aaed:	jne    100ab27 <entry_run+0xad7>
 100aaef:	test   $0x1,%al
 100aaf1:	jne    100b49f <entry_run+0x144f>
 100aaf7:	mov    -0x20(%r13),%rax
 100aafb:	cmp    $0x1,%rax
 100aaff:	je     100ab27 <entry_run+0xad7>
 100ab01:	test   %rax,%rax
 100ab04:	jne    100a9a1 <entry_run+0x951>
 100ab0a:	cmpq   $0x0,-0x18(%r13)
 100ab0f:	jne    100ab27 <entry_run+0xad7>
 100ab11:	jmp    100b49f <entry_run+0x144f>
 100ab16:	cmp    $0x1,%eax
 100ab19:	je     100b348 <entry_run+0x12f8>
 100ab1f:	test   %eax,%eax
 100ab21:	jne    100b48a <entry_run+0x143a>
 100ab27:	lea    -0x30(%rbp),%r13
 100ab2b:	xor    %r14d,%r14d
 100ab2e:	xchg   %ax,%ax
 100ab30:	mov    %r14,-0x30(%rbp)
 100ab34:	mov    -0x40(%rbp),%rsi
 100ab38:	mov    (%rsi),%rcx
 100ab3b:	mov    0x10(%rsi),%rax
 100ab3f:	cmp    0x8(%rsi),%rcx
 100ab43:	setae  %dl
 100ab46:	cmp    $0xffffffffffffffff,%rax
 100ab4a:	sete   %dil
 100ab4e:	or     %dl,%dil
 100ab51:	jne    100ab70 <entry_run+0xb20>
 100ab53:	mov    0x1860(%rbx),%rdi
 100ab5a:	test   %rdi,%rdi
 100ab5d:	je     100ab70 <entry_run+0xb20>
 100ab5f:	cmpq   $0x0,0x60(%rdi)
 100ab64:	je     100aba8 <entry_run+0xb58>
 100ab66:	cs nopw 0x0(%rax,%rax,1)
 100ab70:	mov    (%rsi),%rdx
 100ab73:	mov    %r15,%rdi
 100ab76:	mov    %r13,%rcx
 100ab79:	call   100ff60 <rc_list_insert_at>
 100ab7e:	test   %eax,%eax
 100ab80:	je     100b4a7 <entry_run+0x1457>
 100ab86:	xor    %eax,%eax
 100ab88:	cmp    $0xf423ff,%r14
 100ab8f:	lea    0x1(%r14),%r14
 100ab93:	setb   %al
 100ab96:	mov    %rax,-0x30(%rbp)
 100ab9a:	cmp    $0xf42400,%r14
 100aba1:	jne    100ab30 <entry_run+0xae0>
 100aba3:	jmp    100acc8 <entry_run+0xc78>
 100aba8:	mov    0x18(%rsi),%rdx
 100abac:	test   %rdx,%rdx
 100abaf:	je     100ab70 <entry_run+0xb20>
 100abb1:	mov    0x30(%rdx),%r8d
 100abb5:	cmp    $0x7,%r8d
 100abb9:	je     100abc0 <entry_run+0xb70>
 100abbb:	test   %r8d,%r8d
 100abbe:	jne    100ab70 <entry_run+0xb20>
 100abc0:	mov    (%rdx),%r8
 100abc3:	popcnt %r8,%r9
 100abc8:	cmp    $0x1,%r9d
 100abcc:	setne  %r9b
 100abd0:	test   $0xf,%r8b
 100abd4:	sete   %r8b
 100abd8:	or     %r9b,%r8b
 100abdb:	jne    100ab70 <entry_run+0xb20>
 100abdd:	mov    0x40(%rdi),%r8
 100abe1:	test   %r8,%r8
 100abe4:	je     100ab70 <entry_run+0xb20>
 100abe6:	mov    0x30(%rdi),%rdi
 100abea:	mov    0x24(%rdi),%r9d
 100abee:	test   %r9,%r9
 100abf1:	sete   %r10b
 100abf5:	cmp    %r9,%r8
 100abf8:	setb   %r11b
 100abfc:	or     %r10b,%r11b
 100abff:	jne    100ac19 <entry_run+0xbc9>
 100ac01:	dec    %r9d
 100ac04:	lea    (%r9,%r9,4),%r10
 100ac08:	cmp    %rdx,(%rdi,%r10,8)
 100ac0c:	jne    100ac19 <entry_run+0xbc9>
 100ac0e:	lea    (%rdi,%r10,8),%r10
 100ac12:	cmpl   $0x2,0x20(%r10)
 100ac17:	je     100ac92 <entry_run+0xc42>
 100ac19:	mov    %rdx,%r9
 100ac1c:	shr    $0x3,%r9
 100ac20:	mov    %rdx,%r10
 100ac23:	shr    $0x21,%r10
 100ac27:	xor    %r9,%r10
 100ac2a:	imul   %r12,%r10
 100ac2e:	mov    %r10,%r9
 100ac31:	shr    $0x1b,%r9
 100ac35:	xor    %r10,%r9
 100ac38:	xor    $0x2,%r9
 100ac3c:	dec    %r8
 100ac3f:	jmp    100ac53 <entry_run+0xc03>
 100ac41:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 100ac50:	inc    %r9
 100ac53:	and    %r8,%r9
 100ac56:	lea    (%r9,%r9,4),%r10
 100ac5a:	mov    (%rdi,%r10,8),%r10
 100ac5e:	test   %r10,%r10
 100ac61:	je     100ab70 <entry_run+0xb20>
 100ac67:	cmp    %rdx,%r10
 100ac6a:	jne    100ac50 <entry_run+0xc00>
 100ac6c:	lea    (%r9,%r9,4),%r10
 100ac70:	cmpl   $0x2,0x20(%rdi,%r10,8)
 100ac76:	jne    100ac50 <entry_run+0xc00>
 100ac78:	lea    0x1(%r9),%edx
 100ac7c:	mov    $0xffffffff,%r8d
 100ac82:	cmp    %r8,%r9
 100ac85:	mov    $0x0,%r8d
 100ac8b:	cmovae %r8d,%edx
 100ac8f:	mov    %edx,0x24(%rdi)
 100ac92:	lea    (%r9,%r9,4),%rdx
 100ac96:	mov    0x8(%rdi,%rdx,8),%rdx
 100ac9b:	test   %rdx,%rdx
 100ac9e:	je     100ab70 <entry_run+0xb20>
 100aca4:	cmpl   $0x0,0x78(%rdx)
 100aca8:	jne    100ab70 <entry_run+0xb20>
 100acae:	mov    0x20(%rsi),%rdx
 100acb2:	mov    %r14,(%rdx,%rcx,8)
 100acb6:	inc    %rcx
 100acb9:	mov    %rcx,(%rsi)
 100acbc:	inc    %rax
 100acbf:	mov    %rax,0x10(%rsi)
 100acc3:	jmp    100ab86 <entry_run+0xb36>
 100acc8:	movq   $0x0,-0x30(%rbp)
 100acd0:	mov    -0x40(%rbp),%rax
 100acd4:	cmpl   $0x8,-0x130(%rbp)
 100acdb:	jne    100adc8 <entry_run+0xd78>
 100ace1:	mov    -0x68(%rbp),%ecx
 100ace4:	and    $0x1,%ecx
 100ace7:	je     100adc8 <entry_run+0xd78>
 100aced:	movq   $0x0,-0x38(%rbp)
 100acf5:	test   %rax,%rax
 100acf8:	lea    -0x98(%rbp),%r12
 100acff:	lea    -0x38(%rbp),%r14
 100ad03:	je     100ad51 <entry_run+0xd01>
 100ad05:	mov    -0x10(%rax),%rcx
 100ad09:	movabs $0x4000000000000002,%rdx
 100ad13:	test   %rdx,%rcx
 100ad16:	jne    100ad51 <entry_run+0xd01>
 100ad18:	cmpq   $0x0,0x1860(%rbx)
 100ad20:	je     100b49f <entry_run+0x144f>
 100ad26:	test   $0x1,%cl
 100ad29:	jne    100b49f <entry_run+0x144f>
 100ad2f:	mov    -0x18(%rax),%rcx
 100ad33:	mov    -0x20(%rax),%rdx
 100ad37:	or     %rcx,%rdx
 100ad3a:	je     100b49f <entry_run+0x144f>
 100ad40:	cmp    $0xffffffffffffffff,%rcx
 100ad44:	je     100b429 <entry_run+0x13d9>
 100ad4a:	inc    %rcx
 100ad4d:	mov    %rcx,-0x18(%rax)
 100ad51:	movq   $0x1001ab8,-0xe8(%rbp)
 100ad5c:	mov    %r14,-0xe0(%rbp)
 100ad63:	lea    -0x50(%rbp),%rcx
 100ad67:	mov    %rcx,-0xd8(%rbp)
 100ad6e:	movl   $0x8,-0xd0(%rbp)
 100ad78:	mov    %rax,-0x78(%rbp)
 100ad7c:	movq   $0x1001ab8,-0x108(%rbp)
 100ad87:	lea    -0x78(%rbp),%rcx
 100ad8b:	mov    %rcx,-0x100(%rbp)
 100ad92:	lea    -0x58(%rbp),%rcx
 100ad96:	mov    %rcx,-0xf8(%rbp)
 100ad9d:	movl   $0x8,-0xf0(%rbp)
 100ada7:	movl   $0x1,-0x58(%rbp)
 100adae:	movl   $0x0,-0x50(%rbp)
 100adb5:	mov    %rax,-0x30(%rbp)
 100adb9:	movq   $0x0,-0x38(%rbp)
 100adc1:	test   %rax,%rax
 100adc4:	jne    100ade4 <entry_run+0xd94>
 100adc6:	jmp    100ae30 <entry_run+0xde0>
 100adc8:	lea    -0x98(%rbp),%r12
 100adcf:	lea    -0x38(%rbp),%r14
 100add3:	mov    %rax,-0x30(%rbp)
 100add7:	movq   $0x0,-0x38(%rbp)
 100addf:	test   %rax,%rax
 100ade2:	je     100ae30 <entry_run+0xde0>
 100ade4:	mov    -0x10(%rax),%rcx
 100ade8:	movabs $0x4000000000000002,%rdx
 100adf2:	test   %rdx,%rcx
 100adf5:	jne    100ae30 <entry_run+0xde0>
 100adf7:	cmpq   $0x0,0x1860(%rbx)
 100adff:	je     100b49f <entry_run+0x144f>
 100ae05:	test   $0x1,%cl
 100ae08:	jne    100b49f <entry_run+0x144f>
 100ae0e:	mov    -0x18(%rax),%rcx
 100ae12:	mov    -0x20(%rax),%rdx
 100ae16:	or     %rcx,%rdx
 100ae19:	je     100b49f <entry_run+0x144f>
 100ae1f:	cmp    $0xffffffffffffffff,%rcx
 100ae23:	je     100b429 <entry_run+0x13d9>
 100ae29:	inc    %rcx
 100ae2c:	mov    %rcx,-0x18(%rax)
 100ae30:	mov    %rax,-0x38(%rbp)
 100ae34:	movq   $0x1001ab8,-0xe8(%rbp)
 100ae3f:	mov    %r14,-0xe0(%rbp)
 100ae46:	lea    -0x50(%rbp),%rcx
 100ae4a:	mov    %rcx,-0xd8(%rbp)
 100ae51:	movl   $0x8,-0xd0(%rbp)
 100ae5b:	movl   $0x1,-0x50(%rbp)
 100ae62:	cmpl   $0x0,-0x58(%rbp)
 100ae66:	je     100ae7b <entry_run+0xe2b>
 100ae68:	mov    %rbx,%rdi
 100ae6b:	lea    -0x108(%rbp),%rsi
 100ae72:	call   100b4e0 <myl_qbe_rc_slot_drop>
 100ae77:	mov    -0x38(%rbp),%rax
 100ae7b:	mov    %rax,-0x78(%rbp)
 100ae7f:	movq   $0x1001ab8,-0x108(%rbp)
 100ae8a:	lea    -0x78(%rbp),%rcx
 100ae8e:	mov    %rcx,-0x100(%rbp)
 100ae95:	lea    -0x58(%rbp),%rcx
 100ae99:	mov    %rcx,-0xf8(%rbp)
 100aea0:	movl   $0x8,-0xf0(%rbp)
 100aeaa:	mov    %rax,-0x30(%rbp)
 100aeae:	movq   $0x1001ab8,-0xe8(%rbp)
 100aeb9:	mov    %r14,-0xe0(%rbp)
 100aec0:	lea    -0x50(%rbp),%rcx
 100aec4:	mov    %rcx,-0xd8(%rbp)
 100aecb:	movl   $0x8,-0xd0(%rbp)
 100aed5:	movl   $0x1,-0x50(%rbp)
 100aedc:	movl   $0x0,-0x58(%rbp)
 100aee3:	cmpl   $0x0,-0x60(%rbp)
 100aee7:	je     100aefc <entry_run+0xeac>
 100aee9:	mov    %rbx,%rdi
 100aeec:	lea    -0x128(%rbp),%rsi
 100aef3:	call   100b4e0 <myl_qbe_rc_slot_drop>
 100aef8:	mov    -0x38(%rbp),%rax
 100aefc:	mov    %rax,-0xa8(%rbp)
 100af03:	movq   $0x1001ab8,-0x128(%rbp)
 100af0e:	lea    -0xa8(%rbp),%rcx
 100af15:	mov    %rcx,-0x120(%rbp)
 100af1c:	lea    -0x60(%rbp),%rcx
 100af20:	mov    %rcx,-0x118(%rbp)
 100af27:	movl   $0x8,-0x110(%rbp)
 100af31:	movl   $0x1,-0x60(%rbp)
 100af38:	movl   $0x0,-0x50(%rbp)
 100af3f:	mov    (%rax),%rsi
 100af42:	mov    %rsi,-0x30(%rbp)
 100af46:	test   %rsi,%rsi
 100af49:	js     100b4c9 <entry_run+0x1479>
 100af4f:	je     100af7a <entry_run+0xf2a>
 100af51:	mov    0x20(%rax),%rcx
 100af55:	xor    %eax,%eax
 100af57:	xor    %edi,%edi
 100af59:	xor    %r14d,%r14d
 100af5c:	nopl   0x0(%rax)
 100af60:	mov    (%rcx,%rdi,8),%rdx
 100af64:	add    %rdx,%r14
 100af67:	jo     100b4af <entry_run+0x145f>
 100af6d:	inc    %rdi
 100af70:	mov    %r14,%rax
 100af73:	cmp    %rdi,%rsi
 100af76:	jne    100af60 <entry_run+0xf10>
 100af78:	jmp    100af7d <entry_run+0xf2d>
 100af7a:	xor    %r14d,%r14d
 100af7d:	movq   $0x1,-0x30(%rbp)
 100af85:	mov    $0x1,%edi
 100af8a:	mov    $0x20,%esi
 100af8f:	call   101bbf0 <calloc@plt>
 100af94:	mov    %rax,-0xa0(%rbp)
 100af9b:	test   %rax,%rax
 100af9e:	jne    100afa8 <entry_run+0xf58>
 100afa0:	mov    %rbx,%rdi
 100afa3:	call   100c3c0 <myl_qbe_fail_allocation>
 100afa8:	lea    -0x190(%rbp),%rdi
 100afaf:	mov    $0x18,%esi
 100afb4:	mov    $0x1003272,%edx
 100afb9:	mov    %r14,%rcx
 100afbc:	xor    %eax,%eax
 100afbe:	call   101bd30 <snprintf@plt>
 100afc3:	test   %eax,%eax
 100afc5:	jle    100b1cf <entry_run+0x117f>
 100afcb:	mov    %eax,%r13d
 100afce:	mov    $0x40,%edi
 100afd3:	cmp    $0x41,%eax
 100afd6:	jb     100b171 <entry_run+0x1121>
 100afdc:	mov    $0x80,%edi
 100afe1:	cmp    $0x81,%r13d
 100afe8:	jb     100b171 <entry_run+0x1121>
 100afee:	mov    $0x100,%edi
 100aff3:	cmp    $0x101,%r13d
 100affa:	jb     100b171 <entry_run+0x1121>
 100b000:	mov    $0x200,%edi
 100b005:	cmp    $0x201,%r13d
 100b00c:	jb     100b171 <entry_run+0x1121>
 100b012:	mov    $0x400,%edi
 100b017:	cmp    $0x401,%r13d
 100b01e:	jb     100b171 <entry_run+0x1121>
 100b024:	mov    $0x800,%edi
 100b029:	cmp    $0x801,%r13d
 100b030:	jb     100b171 <entry_run+0x1121>
 100b036:	mov    $0x1000,%edi
 100b03b:	cmp    $0x1001,%r13d
 100b042:	jb     100b171 <entry_run+0x1121>
 100b048:	mov    $0x2000,%edi
 100b04d:	cmp    $0x2001,%r13d
 100b054:	jb     100b171 <entry_run+0x1121>
 100b05a:	mov    $0x4000,%edi
 100b05f:	cmp    $0x4001,%r13d
 100b066:	jb     100b171 <entry_run+0x1121>
 100b06c:	mov    $0x8000,%edi
 100b071:	cmp    $0x8001,%r13d
 100b078:	jb     100b171 <entry_run+0x1121>
 100b07e:	mov    $0x10000,%edi
 100b083:	cmp    $0x10001,%r13d
 100b08a:	jb     100b171 <entry_run+0x1121>
 100b090:	mov    $0x20000,%edi
 100b095:	cmp    $0x20001,%r13d
 100b09c:	jb     100b171 <entry_run+0x1121>
 100b0a2:	mov    $0x40000,%edi
 100b0a7:	cmp    $0x40001,%r13d
 100b0ae:	jb     100b171 <entry_run+0x1121>
 100b0b4:	mov    $0x80000,%edi
 100b0b9:	cmp    $0x80001,%r13d
 100b0c0:	jb     100b171 <entry_run+0x1121>
 100b0c6:	mov    $0x100000,%edi
 100b0cb:	cmp    $0x100001,%r13d
 100b0d2:	jb     100b171 <entry_run+0x1121>
 100b0d8:	mov    $0x200000,%edi
 100b0dd:	cmp    $0x200001,%r13d
 100b0e4:	jb     100b171 <entry_run+0x1121>
 100b0ea:	mov    $0x400000,%edi
 100b0ef:	cmp    $0x400001,%r13d
 100b0f6:	jb     100b171 <entry_run+0x1121>
 100b0f8:	mov    $0x800000,%edi
 100b0fd:	cmp    $0x800001,%r13d
 100b104:	jb     100b171 <entry_run+0x1121>
 100b106:	mov    $0x1000000,%edi
 100b10b:	cmp    $0x1000001,%r13d
 100b112:	jb     100b171 <entry_run+0x1121>
 100b114:	mov    $0x2000000,%edi
 100b119:	cmp    $0x2000001,%r13d
 100b120:	jb     100b171 <entry_run+0x1121>
 100b122:	mov    $0x4000000,%edi
 100b127:	cmp    $0x4000001,%r13d
 100b12e:	jb     100b171 <entry_run+0x1121>
 100b130:	mov    $0x8000000,%edi
 100b135:	cmp    $0x8000001,%r13d
 100b13c:	jb     100b171 <entry_run+0x1121>
 100b13e:	mov    $0x10000000,%edi
 100b143:	cmp    $0x10000001,%r13d
 100b14a:	jb     100b171 <entry_run+0x1121>
 100b14c:	mov    $0x20000000,%edi
 100b151:	cmp    $0x20000001,%r13d
 100b158:	jb     100b171 <entry_run+0x1121>
 100b15a:	xor    %edi,%edi
 100b15c:	cmp    $0x40000001,%r13d
 100b163:	setae  %dil
 100b167:	shl    $0x1e,%edi
 100b16a:	add    $0x40000000,%rdi
 100b171:	mov    %rdi,%r12
 100b174:	call   101bbe0 <malloc@plt>
 100b179:	test   %rax,%rax
 100b17c:	je     100b246 <entry_run+0x11f6>
 100b182:	mov    %rax,%r14
 100b185:	mov    %r13d,%r13d
 100b188:	mov    -0xa0(%rbp),%r15
 100b18f:	mov    %rax,(%r15)
 100b192:	mov    %r12,0x10(%r15)
 100b196:	lea    -0x190(%rbp),%rsi
 100b19d:	mov    %rax,%rdi
 100b1a0:	mov    %r13,%rdx
 100b1a3:	call   101bc00 <memcpy@plt>
 100b1a8:	lea    0x8(%r15),%rax
 100b1ac:	mov    %r13,0x8(%r15)
 100b1b0:	add    $0x18,%r15
 100b1b4:	cmp    %r13,%r12
 100b1b7:	jne    100b21a <entry_run+0x11ca>
 100b1b9:	mov    %r12,%rsi
 100b1bc:	mov    %rax,-0x170(%rbp)
 100b1c3:	add    %r12,%rsi
 100b1c6:	mov    -0xa0(%rbp),%r13
 100b1cd:	jmp    100b1f0 <entry_run+0x11a0>
 100b1cf:	mov    -0xa0(%rbp),%r13
 100b1d6:	lea    0x18(%r13),%r15
 100b1da:	mov    %r13,%rax
 100b1dd:	add    $0x8,%rax
 100b1e1:	mov    %rax,-0x170(%rbp)
 100b1e8:	mov    $0x40,%esi
 100b1ed:	xor    %r14d,%r14d
 100b1f0:	mov    %r14,%rdi
 100b1f3:	mov    %rsi,%r12
 100b1f6:	call   101bd40 <realloc@plt>
 100b1fb:	test   %rax,%rax
 100b1fe:	je     100b32a <entry_run+0x12da>
 100b204:	mov    %rax,%r14
 100b207:	mov    %rax,0x0(%r13)
 100b20b:	mov    %r12,0x10(%r13)
 100b20f:	mov    0x8(%r13),%r13
 100b213:	mov    -0x170(%rbp),%rax
 100b21a:	movb   $0xa,(%r14,%r13,1)
 100b21f:	incq   (%rax)
 100b222:	mov    -0xa0(%rbp),%r13
 100b229:	cmpl   $0x0,0x1c(%r13)
 100b22e:	lea    -0x98(%rbp),%r12
 100b235:	je     100b26a <entry_run+0x121a>
 100b237:	mov    $0x1002f32,%esi
 100b23c:	mov    %rbx,%rdi
 100b23f:	call   100bd10 <fail>
 100b244:	jmp    100b27c <entry_run+0x122c>
 100b246:	mov    -0xa0(%rbp),%r13
 100b24d:	mov    %r13,%r15
 100b250:	add    $0x18,%r15
 100b254:	movl   $0x1,0x18(%r13)
 100b25c:	cmpl   $0x0,0x1c(%r13)
 100b261:	lea    -0x98(%rbp),%r12
 100b268:	jne    100b237 <entry_run+0x11e7>
 100b26a:	cmpl   $0x0,(%r15)
 100b26e:	je     100b433 <entry_run+0x13e3>
 100b274:	mov    %rbx,%rdi
 100b277:	call   100c3c0 <myl_qbe_fail_allocation>
 100b27c:	mov    0x0(%r13),%rdi
 100b280:	call   101bc50 <free@plt>
 100b285:	mov    %r13,%rdi
 100b288:	call   101bc50 <free@plt>
 100b28d:	movq   $0x0,-0x30(%rbp)
 100b295:	cmp    %r12,0x3d80(%rbx)
 100b29c:	lea    0x258(%rbx),%rdi
 100b2a3:	jne    100b49f <entry_run+0x144f>
 100b2a9:	mov    -0x80(%rbp),%rsi
 100b2ad:	call   1014cc0 <myl_rc_scope_unwind>
 100b2b2:	mov    -0x88(%rbp),%r14
 100b2b9:	test   %r14,%r14
 100b2bc:	je     100b2fc <entry_run+0x12ac>
 100b2be:	mov    %r14,%r15
 100b2c1:	shl    $0x5,%r15
 100b2c5:	add    $0xffffffffffffffe0,%r15
 100b2c9:	jmp    100b2e4 <entry_run+0x1294>
 100b2cb:	nopl   0x0(%rax,%rax,1)
 100b2d0:	add    %r15,%rsi
 100b2d3:	mov    %rbx,%rdi
 100b2d6:	call   100b4e0 <myl_qbe_rc_slot_drop>
 100b2db:	add    $0xffffffffffffffe0,%r15
 100b2df:	dec    %r14
 100b2e2:	je     100b2fc <entry_run+0x12ac>
 100b2e4:	mov    -0x90(%rbp),%rsi
 100b2eb:	mov    0x10(%rsi,%r15,1),%rax
 100b2f0:	test   %rax,%rax
 100b2f3:	je     100b2d0 <entry_run+0x1280>
 100b2f5:	cmpl   $0x0,(%rax)
 100b2f8:	jne    100b2d0 <entry_run+0x1280>
 100b2fa:	jmp    100b2db <entry_run+0x128b>
 100b2fc:	cmp    %r12,0x3d80(%rbx)
 100b303:	jne    100b49f <entry_run+0x144f>
 100b309:	mov    0x1860(%rbx),%rax
 100b310:	test   %rax,%rax
 100b313:	jne    100b3f9 <entry_run+0x13a9>
 100b319:	xor    %eax,%eax
 100b31b:	cmp    -0x80(%rbp),%rax
 100b31f:	je     100b407 <entry_run+0x13b7>
 100b325:	jmp    100b49f <entry_run+0x144f>
 100b32a:	movl   $0x1,(%r15)
 100b331:	cmpl   $0x0,0x1c(%r13)
 100b336:	lea    -0x98(%rbp),%r12
 100b33d:	jne    100b237 <entry_run+0x11e7>
 100b343:	jmp    100b26a <entry_run+0x121a>
 100b348:	mov    $0x10034a2,%esi
 100b34d:	cmpl   $0x0,0x2c4(%rbx)
 100b354:	lea    -0x98(%rbp),%r12
 100b35b:	jne    100b36c <entry_run+0x131c>
 100b35d:	mov    $0x1,%eax
 100b362:	mov    %eax,%eax
 100b364:	mov    0x1004940(,%rax,8),%rsi
 100b36c:	mov    %rbx,%rdi
 100b36f:	call   100bd10 <fail>
 100b374:	cmp    %r12,0x3d80(%rbx)
 100b37b:	jne    100b49f <entry_run+0x144f>
 100b381:	mov    -0x80(%rbp),%rsi
 100b385:	mov    %r15,%rdi
 100b388:	call   1014cc0 <myl_rc_scope_unwind>
 100b38d:	mov    -0x88(%rbp),%r14
 100b394:	test   %r14,%r14
 100b397:	je     100b3dc <entry_run+0x138c>
 100b399:	mov    %r14,%r15
 100b39c:	shl    $0x5,%r15
 100b3a0:	add    $0xffffffffffffffe0,%r15
 100b3a4:	jmp    100b3c4 <entry_run+0x1374>
 100b3a6:	cs nopw 0x0(%rax,%rax,1)
 100b3b0:	add    %r15,%rsi
 100b3b3:	mov    %rbx,%rdi
 100b3b6:	call   100b4e0 <myl_qbe_rc_slot_drop>
 100b3bb:	add    $0xffffffffffffffe0,%r15
 100b3bf:	dec    %r14
 100b3c2:	je     100b3dc <entry_run+0x138c>
 100b3c4:	mov    -0x90(%rbp),%rsi
 100b3cb:	mov    0x10(%rsi,%r15,1),%rax
 100b3d0:	test   %rax,%rax
 100b3d3:	je     100b3b0 <entry_run+0x1360>
 100b3d5:	cmpl   $0x0,(%rax)
 100b3d8:	jne    100b3b0 <entry_run+0x1360>
 100b3da:	jmp    100b3bb <entry_run+0x136b>
 100b3dc:	cmp    %r12,0x3d80(%rbx)
 100b3e3:	jne    100b49f <entry_run+0x144f>
 100b3e9:	mov    0x1860(%rbx),%rax
 100b3f0:	test   %rax,%rax
 100b3f3:	je     100b319 <entry_run+0x12c9>
 100b3f9:	mov    0x70(%rax),%rax
 100b3fd:	cmp    -0x80(%rbp),%rax
 100b401:	jne    100b49f <entry_run+0x144f>
 100b407:	mov    -0x98(%rbp),%rax
 100b40e:	mov    %rax,0x3d80(%rbx)
 100b415:	xor    %eax,%eax
 100b417:	add    $0x178,%rsp
 100b41e:	pop    %rbx
 100b41f:	pop    %r12
 100b421:	pop    %r13
 100b423:	pop    %r14
 100b425:	pop    %r15
 100b427:	pop    %rbp
 100b428:	ret
 100b429:	mov    $0x100346f,%esi
 100b42e:	jmp    100b36c <entry_run+0x131c>
 100b433:	mov    0x11e16(%rip),%rax        # 101d250 <stdout@GLIBC_2.2.5>
 100b43a:	mov    (%rax),%r14
 100b43d:	mov    0x8(%r13),%r15
 100b441:	test   %r15,%r15
 100b444:	je     100b45f <entry_run+0x140f>
 100b446:	mov    0x0(%r13),%rdi
 100b44a:	mov    $0x1,%esi
 100b44f:	mov    %r15,%rdx
 100b452:	mov    %r14,%rcx
 100b455:	call   101bcb0 <fwrite@plt>
 100b45a:	cmp    %r15,%rax
 100b45d:	jne    100b46f <entry_run+0x141f>
 100b45f:	mov    %r14,%rdi
 100b462:	call   101bd50 <fflush@plt>
 100b467:	test   %eax,%eax
 100b469:	je     100b27c <entry_run+0x122c>
 100b46f:	mov    $0x1003432,%esi
 100b474:	jmp    100b23c <entry_run+0x11ec>
 100b479:	mov    $0x100346f,%esi
 100b47e:	lea    -0x98(%rbp),%r12
 100b485:	jmp    100b36c <entry_run+0x131c>
 100b48a:	cmp    $0x4,%eax
 100b48d:	jae    100a9ea <entry_run+0x99a>
 100b493:	lea    -0x98(%rbp),%r12
 100b49a:	jmp    100b362 <entry_run+0x1312>
 100b49f:	vzeroupper
 100b4a2:	call   1010814 <myl_rc_invariant_failed>
 100b4a7:	mov    %rbx,%rdi
 100b4aa:	call   100c3c0 <myl_qbe_fail_allocation>
 100b4af:	mov    %rax,-0x30(%rbp)
 100b4b3:	mov    %rbx,%rdi
 100b4b6:	mov    %rax,%rsi
 100b4b9:	call   100c450 <myl_qbe_fail_overflow_op>
 100b4be:	mov    %rbx,%rdi
 100b4c1:	vzeroupper
 100b4c4:	call   100c3c0 <myl_qbe_fail_allocation>
 100b4c9:	mov    %rbx,%rdi
 100b4cc:	call   100c4b0 <myl_qbe_fail_cast>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
