
.tmp-mut-argument/type-facts/controls/parity-micro-list_append_sum-after-qbe-production:     file format elf64-x86-64


Disassembly of section .text:

000000000100ec30 <myl_rc_list_plain_ready>:
 100ec30:	xor    %eax,%eax
 100ec32:	test   %rdi,%rdi
 100ec35:	je     100ec99 <myl_rc_list_plain_ready+0x69>
 100ec37:	mov    0x1608(%rdi),%rcx
 100ec3e:	test   %rcx,%rcx
 100ec41:	je     100ec99 <myl_rc_list_plain_ready+0x69>
 100ec43:	test   %rsi,%rsi
 100ec46:	je     100ec99 <myl_rc_list_plain_ready+0x69>
 100ec48:	push   %rbp
 100ec49:	mov    %rsp,%rbp
 100ec4c:	cmpq   $0x0,0x60(%rcx)
 100ec51:	jne    100ec98 <myl_rc_list_plain_ready+0x68>
 100ec53:	mov    0x18(%rsi),%rsi
 100ec57:	test   %rsi,%rsi
 100ec5a:	je     100ec98 <myl_rc_list_plain_ready+0x68>
 100ec5c:	mov    0x30(%rsi),%ecx
 100ec5f:	cmp    $0x7,%ecx
 100ec62:	je     100ec68 <myl_rc_list_plain_ready+0x38>
 100ec64:	test   %ecx,%ecx
 100ec66:	jne    100ec98 <myl_rc_list_plain_ready+0x68>
 100ec68:	mov    (%rsi),%rcx
 100ec6b:	popcnt %rcx,%rdx
 100ec70:	cmp    $0x1,%edx
 100ec73:	setne  %dl
 100ec76:	test   $0xf,%cl
 100ec79:	sete   %cl
 100ec7c:	or     %dl,%cl
 100ec7e:	jne    100ec98 <myl_rc_list_plain_ready+0x68>
 100ec80:	call   1010d10 <myl_rc_descriptor_repeat>
 100ec85:	mov    %rax,%rcx
 100ec88:	xor    %eax,%eax
 100ec8a:	test   %rcx,%rcx
 100ec8d:	je     100ec98 <myl_rc_list_plain_ready+0x68>
 100ec8f:	xor    %eax,%eax
 100ec91:	cmpl   $0x0,0x78(%rcx)
 100ec95:	sete   %al
 100ec98:	pop    %rbp
 100ec99:	ret

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
