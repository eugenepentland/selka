
.tmp-mut-argument/type-facts/controls/parity-micro-list_append_sum-after-qbe-production:     file format elf64-x86-64


Disassembly of section .text:

0000000001010d10 <myl_rc_descriptor_repeat>:
 1010d10:	test   %rdi,%rdi
 1010d13:	je     1010e02 <myl_rc_descriptor_repeat+0xf2>
 1010d19:	mov    0x1608(%rdi),%rax
 1010d20:	test   %rax,%rax
 1010d23:	sete   %cl
 1010d26:	test   %rsi,%rsi
 1010d29:	sete   %dl
 1010d2c:	or     %cl,%dl
 1010d2e:	jne    1010e02 <myl_rc_descriptor_repeat+0xf2>
 1010d34:	push   %rbp
 1010d35:	mov    %rsp,%rbp
 1010d38:	mov    0x40(%rax),%rdx
 1010d3c:	test   %rdx,%rdx
 1010d3f:	je     1010e05 <myl_rc_descriptor_repeat+0xf5>
 1010d45:	mov    0x30(%rax),%rcx
 1010d49:	mov    0x24(%rcx),%edi
 1010d4c:	test   %rdi,%rdi
 1010d4f:	sete   %al
 1010d52:	cmp    %rdi,%rdx
 1010d55:	setb   %r8b
 1010d59:	or     %al,%r8b
 1010d5c:	jne    1010d78 <myl_rc_descriptor_repeat+0x68>
 1010d5e:	dec    %edi
 1010d60:	lea    (%rdi,%rdi,4),%rax
 1010d64:	cmp    %rsi,(%rcx,%rax,8)
 1010d68:	jne    1010d78 <myl_rc_descriptor_repeat+0x68>
 1010d6a:	lea    (%rcx,%rax,8),%rax
 1010d6e:	cmpl   $0x2,0x20(%rax)
 1010d72:	je     1010df7 <myl_rc_descriptor_repeat+0xe7>
 1010d78:	mov    %rsi,%rax
 1010d7b:	shr    $0x3,%rax
 1010d7f:	mov    %rsi,%rdi
 1010d82:	shr    $0x21,%rdi
 1010d86:	xor    %rax,%rdi
 1010d89:	movabs $0xbf58476d1ce4e5b9,%rax
 1010d93:	imul   %rdi,%rax
 1010d97:	mov    %rax,%rdi
 1010d9a:	shr    $0x1b,%rdi
 1010d9e:	xor    %rax,%rdi
 1010da1:	xor    $0x2,%rdi
 1010da5:	dec    %rdx
 1010da8:	and    %rdx,%rdi
 1010dab:	lea    (%rdi,%rdi,4),%rax
 1010daf:	mov    (%rcx,%rax,8),%r8
 1010db3:	xor    %eax,%eax
 1010db5:	jmp    1010dce <myl_rc_descriptor_repeat+0xbe>
 1010db7:	nopw   0x0(%rax,%rax,1)
 1010dc0:	inc    %rdi
 1010dc3:	and    %rdx,%rdi
 1010dc6:	lea    (%rdi,%rdi,4),%r8
 1010dca:	mov    (%rcx,%r8,8),%r8
 1010dce:	test   %r8,%r8
 1010dd1:	je     1010e00 <myl_rc_descriptor_repeat+0xf0>
 1010dd3:	cmp    %rsi,%r8
 1010dd6:	jne    1010dc0 <myl_rc_descriptor_repeat+0xb0>
 1010dd8:	lea    (%rdi,%rdi,4),%r8
 1010ddc:	cmpl   $0x2,0x20(%rcx,%r8,8)
 1010de2:	jne    1010dc0 <myl_rc_descriptor_repeat+0xb0>
 1010de4:	lea    0x1(%rdi),%eax
 1010de7:	xor    %edx,%edx
 1010de9:	mov    $0xffffffff,%esi
 1010dee:	cmp    %rsi,%rdi
 1010df1:	cmovb  %eax,%edx
 1010df4:	mov    %edx,0x24(%rcx)
 1010df7:	lea    (%rdi,%rdi,4),%rax
 1010dfb:	mov    0x8(%rcx,%rax,8),%rax
 1010e00:	pop    %rbp
 1010e01:	ret
 1010e02:	xor    %eax,%eax
 1010e04:	ret
 1010e05:	xor    %eax,%eax
 1010e07:	pop    %rbp
 1010e08:	ret

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
