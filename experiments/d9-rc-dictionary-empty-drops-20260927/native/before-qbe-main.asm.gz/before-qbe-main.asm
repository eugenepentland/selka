
/home/epentland/ai/canopy/mylang-worktrees/d9-rc-compiler-astra/.tmp-rc/dict-empty/before-qbe-rc:     file format elf64-x86-64


Disassembly of section .text:

000000000100efe0 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605>:
 100efe0:	f3 0f 1e fa          	endbr64
 100efe4:	55                   	push   %rbp
 100efe5:	48 89 e5             	mov    %rsp,%rbp
 100efe8:	48 81 ec f8 03 00 00 	sub    $0x3f8,%rsp
 100efef:	53                   	push   %rbx
 100eff0:	41 54                	push   %r12
 100eff2:	41 55                	push   %r13
 100eff4:	41 56                	push   %r14
 100eff6:	41 57                	push   %r15
 100eff8:	48 89 b5 30 ff ff ff 	mov    %rsi,-0xd0(%rbp)
 100efff:	ba 20 00 00 00       	mov    $0x20,%edx
 100f004:	be 00 00 00 00       	mov    $0x0,%esi
 100f009:	48 89 fb             	mov    %rdi,%rbx
 100f00c:	48 8d bd 68 fe ff ff 	lea    -0x198(%rbp),%rdi
 100f013:	e8 78 d4 01 00       	call   102c490 <compiler_rt.fastMemset>
 100f018:	48 89 df             	mov    %rbx,%rdi
 100f01b:	ba 20 00 00 00       	mov    $0x20,%edx
 100f020:	be 00 00 00 00       	mov    $0x0,%esi
 100f025:	48 89 fb             	mov    %rdi,%rbx
 100f028:	48 8d bd 88 fe ff ff 	lea    -0x178(%rbp),%rdi
 100f02f:	e8 5c d4 01 00       	call   102c490 <compiler_rt.fastMemset>
 100f034:	48 89 df             	mov    %rbx,%rdi
 100f037:	ba 20 00 00 00       	mov    $0x20,%edx
 100f03c:	be 00 00 00 00       	mov    $0x0,%esi
 100f041:	48 89 fb             	mov    %rdi,%rbx
 100f044:	48 8d bd a8 fe ff ff 	lea    -0x158(%rbp),%rdi
 100f04b:	e8 40 d4 01 00       	call   102c490 <compiler_rt.fastMemset>
 100f050:	48 89 df             	mov    %rbx,%rdi
 100f053:	48 c7 85 c8 fe ff ff 	movq   $0x0,-0x138(%rbp)
 100f05a:	00 00 00 00 
 100f05e:	48 c7 85 d0 fe ff ff 	movq   $0x0,-0x130(%rbp)
 100f065:	00 00 00 00 
 100f069:	48 c7 85 d8 fe ff ff 	movq   $0x0,-0x128(%rbp)
 100f070:	00 00 00 00 
 100f074:	48 c7 85 e0 fe ff ff 	movq   $0x0,-0x120(%rbp)
 100f07b:	00 00 00 00 
 100f07f:	48 c7 85 e8 fe ff ff 	movq   $0x0,-0x118(%rbp)
 100f086:	00 00 00 00 
 100f08a:	48 c7 85 f0 fe ff ff 	movq   $0x0,-0x110(%rbp)
 100f091:	00 00 00 00 
 100f095:	48 c7 85 f8 fe ff ff 	movq   $0x0,-0x108(%rbp)
 100f09c:	00 00 00 00 
 100f0a0:	48 c7 85 00 ff ff ff 	movq   $0x0,-0x100(%rbp)
 100f0a7:	00 00 00 00 
 100f0ab:	48 89 fb             	mov    %rdi,%rbx
 100f0ae:	e8 0d 81 00 00       	call   10171c0 <myl_qbe_heap>
 100f0b3:	48 89 df             	mov    %rbx,%rdi
 100f0b6:	48 89 c3             	mov    %rax,%rbx
 100f0b9:	49 89 fc             	mov    %rdi,%r12
 100f0bc:	e8 bf 9c 00 00       	call   1018d80 <myl_qbe_region_mark>
 100f0c1:	4c 89 e7             	mov    %r12,%rdi
 100f0c4:	48 89 45 e0          	mov    %rax,-0x20(%rbp)
 100f0c8:	ba 68 00 00 00       	mov    $0x68,%edx
 100f0cd:	be 00 00 00 00       	mov    $0x0,%esi
 100f0d2:	49 89 fc             	mov    %rdi,%r12
 100f0d5:	48 8d bd d8 fd ff ff 	lea    -0x228(%rbp),%rdi
 100f0dc:	e8 af d3 01 00       	call   102c490 <compiler_rt.fastMemset>
 100f0e1:	4c 89 e7             	mov    %r12,%rdi
 100f0e4:	48 8d 05 25 fe 01 00 	lea    0x1fe25(%rip),%rax        # 102ef10 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b>
 100f0eb:	48 89 85 38 fc ff ff 	mov    %rax,-0x3c8(%rbp)
 100f0f2:	c7 85 50 fc ff ff 02 	movl   $0x2,-0x3b0(%rbp)
 100f0f9:	00 00 00 
 100f0fc:	48 8d 85 c8 fe ff ff 	lea    -0x138(%rbp),%rax
 100f103:	48 89 85 40 fc ff ff 	mov    %rax,-0x3c0(%rbp)
 100f10a:	48 8d 85 d8 fd ff ff 	lea    -0x228(%rbp),%rax
 100f111:	48 89 85 48 fc ff ff 	mov    %rax,-0x3b8(%rbp)
 100f118:	48 8d 85 38 fc ff ff 	lea    -0x3c8(%rbp),%rax
 100f11f:	48 89 c6             	mov    %rax,%rsi
 100f122:	48 83 c6 20          	add    $0x20,%rsi
 100f126:	48 89 75 f0          	mov    %rsi,-0x10(%rbp)
 100f12a:	48 8d 05 df fd 01 00 	lea    0x1fddf(%rip),%rax        # 102ef10 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b>
 100f131:	48 89 85 58 fc ff ff 	mov    %rax,-0x3a8(%rbp)
 100f138:	c7 85 70 fc ff ff 02 	movl   $0x2,-0x390(%rbp)
 100f13f:	00 00 00 
 100f142:	48 8d 85 d0 fe ff ff 	lea    -0x130(%rbp),%rax
 100f149:	48 89 85 60 fc ff ff 	mov    %rax,-0x3a0(%rbp)
 100f150:	48 8d 85 d8 fd ff ff 	lea    -0x228(%rbp),%rax
 100f157:	49 89 c6             	mov    %rax,%r14
 100f15a:	49 83 c6 08          	add    $0x8,%r14
 100f15e:	4c 89 b5 68 fc ff ff 	mov    %r14,-0x398(%rbp)
 100f165:	48 8d 85 38 fc ff ff 	lea    -0x3c8(%rbp),%rax
 100f16c:	48 89 c6             	mov    %rax,%rsi
 100f16f:	48 83 c6 40          	add    $0x40,%rsi
 100f173:	48 89 75 c8          	mov    %rsi,-0x38(%rbp)
 100f177:	48 8d 05 e2 fe 01 00 	lea    0x1fee2(%rip),%rax        # 102f060 <myl_t_db6bd58975531b7368ca22b8af460e2a11856412c594a38caca68120ceaa09fc>
 100f17e:	48 89 85 78 fc ff ff 	mov    %rax,-0x388(%rbp)
 100f185:	c7 85 90 fc ff ff 02 	movl   $0x2,-0x370(%rbp)
 100f18c:	00 00 00 
 100f18f:	48 8d 85 d8 fe ff ff 	lea    -0x128(%rbp),%rax
 100f196:	48 89 85 80 fc ff ff 	mov    %rax,-0x380(%rbp)
 100f19d:	48 8d 85 d8 fd ff ff 	lea    -0x228(%rbp),%rax
 100f1a4:	48 89 c1             	mov    %rax,%rcx
 100f1a7:	48 83 c1 10          	add    $0x10,%rcx
 100f1ab:	48 89 4d d0          	mov    %rcx,-0x30(%rbp)
 100f1af:	48 89 8d 88 fc ff ff 	mov    %rcx,-0x378(%rbp)
 100f1b6:	48 8d 85 38 fc ff ff 	lea    -0x3c8(%rbp),%rax
 100f1bd:	49 89 c4             	mov    %rax,%r12
 100f1c0:	49 83 c4 60          	add    $0x60,%r12
 100f1c4:	4c 89 65 c0          	mov    %r12,-0x40(%rbp)
 100f1c8:	48 8d 05 41 fd 01 00 	lea    0x1fd41(%rip),%rax        # 102ef10 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b>
 100f1cf:	48 89 85 98 fc ff ff 	mov    %rax,-0x368(%rbp)
 100f1d6:	c7 85 b0 fc ff ff 02 	movl   $0x2,-0x350(%rbp)
 100f1dd:	00 00 00 
 100f1e0:	48 8d 85 e0 fe ff ff 	lea    -0x120(%rbp),%rax
 100f1e7:	48 89 85 a0 fc ff ff 	mov    %rax,-0x360(%rbp)
 100f1ee:	48 8d 85 d8 fd ff ff 	lea    -0x228(%rbp),%rax
 100f1f5:	48 83 c0 18          	add    $0x18,%rax
 100f1f9:	48 89 85 a8 fc ff ff 	mov    %rax,-0x358(%rbp)
 100f200:	48 8d 05 99 fc 01 00 	lea    0x1fc99(%rip),%rax        # 102eea0 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a>
 100f207:	48 89 85 b8 fc ff ff 	mov    %rax,-0x348(%rbp)
 100f20e:	c7 85 d0 fc ff ff 02 	movl   $0x2,-0x330(%rbp)
 100f215:	00 00 00 
 100f218:	48 8d 85 e8 fe ff ff 	lea    -0x118(%rbp),%rax
 100f21f:	48 89 85 c0 fc ff ff 	mov    %rax,-0x340(%rbp)
 100f226:	48 8d 85 d8 fd ff ff 	lea    -0x228(%rbp),%rax
 100f22d:	48 83 c0 20          	add    $0x20,%rax
 100f231:	48 89 85 c8 fc ff ff 	mov    %rax,-0x338(%rbp)
 100f238:	48 8d 85 38 fc ff ff 	lea    -0x3c8(%rbp),%rax
 100f23f:	48 05 a0 00 00 00    	add    $0xa0,%rax
 100f245:	48 89 45 b8          	mov    %rax,-0x48(%rbp)
 100f249:	48 8d 05 10 fe 01 00 	lea    0x1fe10(%rip),%rax        # 102f060 <myl_t_db6bd58975531b7368ca22b8af460e2a11856412c594a38caca68120ceaa09fc>
 100f250:	48 89 85 d8 fc ff ff 	mov    %rax,-0x328(%rbp)
 100f257:	c7 85 f0 fc ff ff 02 	movl   $0x2,-0x310(%rbp)
 100f25e:	00 00 00 
 100f261:	48 8d 85 f0 fe ff ff 	lea    -0x110(%rbp),%rax
 100f268:	48 89 85 e0 fc ff ff 	mov    %rax,-0x320(%rbp)
 100f26f:	48 8d 85 d8 fd ff ff 	lea    -0x228(%rbp),%rax
 100f276:	48 83 c0 28          	add    $0x28,%rax
 100f27a:	48 89 85 e8 fc ff ff 	mov    %rax,-0x318(%rbp)
 100f281:	48 8d 85 38 fc ff ff 	lea    -0x3c8(%rbp),%rax
 100f288:	48 89 c6             	mov    %rax,%rsi
 100f28b:	48 81 c6 c0 00 00 00 	add    $0xc0,%rsi
 100f292:	48 89 75 a0          	mov    %rsi,-0x60(%rbp)
 100f296:	48 8d 05 73 fc 01 00 	lea    0x1fc73(%rip),%rax        # 102ef10 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b>
 100f29d:	48 89 85 f8 fc ff ff 	mov    %rax,-0x308(%rbp)
 100f2a4:	c7 85 10 fd ff ff 02 	movl   $0x2,-0x2f0(%rbp)
 100f2ab:	00 00 00 
 100f2ae:	48 8d 85 f8 fe ff ff 	lea    -0x108(%rbp),%rax
 100f2b5:	48 89 85 00 fd ff ff 	mov    %rax,-0x300(%rbp)
 100f2bc:	48 8d 85 d8 fd ff ff 	lea    -0x228(%rbp),%rax
 100f2c3:	49 89 c4             	mov    %rax,%r12
 100f2c6:	49 83 c4 30          	add    $0x30,%r12
 100f2ca:	4c 89 65 98          	mov    %r12,-0x68(%rbp)
 100f2ce:	4c 89 a5 08 fd ff ff 	mov    %r12,-0x2f8(%rbp)
 100f2d5:	48 8d 85 38 fc ff ff 	lea    -0x3c8(%rbp),%rax
 100f2dc:	48 89 c6             	mov    %rax,%rsi
 100f2df:	48 81 c6 e0 00 00 00 	add    $0xe0,%rsi
 100f2e6:	48 89 b5 40 ff ff ff 	mov    %rsi,-0xc0(%rbp)
 100f2ed:	48 8d 05 ac fb 01 00 	lea    0x1fbac(%rip),%rax        # 102eea0 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a>
 100f2f4:	48 89 85 18 fd ff ff 	mov    %rax,-0x2e8(%rbp)
 100f2fb:	c7 85 30 fd ff ff 02 	movl   $0x2,-0x2d0(%rbp)
 100f302:	00 00 00 
 100f305:	48 8d 85 00 ff ff ff 	lea    -0x100(%rbp),%rax
 100f30c:	48 89 85 20 fd ff ff 	mov    %rax,-0x2e0(%rbp)
 100f313:	48 8d 85 d8 fd ff ff 	lea    -0x228(%rbp),%rax
 100f31a:	49 89 c2             	mov    %rax,%r10
 100f31d:	49 83 c2 38          	add    $0x38,%r10
 100f321:	4c 89 95 58 ff ff ff 	mov    %r10,-0xa8(%rbp)
 100f328:	4c 89 95 28 fd ff ff 	mov    %r10,-0x2d8(%rbp)
 100f32f:	48 8d 85 38 fc ff ff 	lea    -0x3c8(%rbp),%rax
 100f336:	49 89 c5             	mov    %rax,%r13
 100f339:	49 81 c5 00 01 00 00 	add    $0x100,%r13
 100f340:	48 8d 05 71 49 ff ff 	lea    -0xb68f(%rip),%rax        # 1003cb8 <myl_t_385cfdbc00ec32031699460779c15099b2bba3cad0e440fffb08e10df0acb9e1>
 100f347:	48 89 85 38 fd ff ff 	mov    %rax,-0x2c8(%rbp)
 100f34e:	c7 85 50 fd ff ff 00 	movl   $0x0,-0x2b0(%rbp)
 100f355:	00 00 00 
 100f358:	48 8d 85 40 fe ff ff 	lea    -0x1c0(%rbp),%rax
 100f35f:	48 89 85 40 fd ff ff 	mov    %rax,-0x2c0(%rbp)
 100f366:	48 8d 85 d8 fd ff ff 	lea    -0x228(%rbp),%rax
 100f36d:	49 89 c7             	mov    %rax,%r15
 100f370:	49 83 c7 40          	add    $0x40,%r15
 100f374:	4c 89 7d b0          	mov    %r15,-0x50(%rbp)
 100f378:	4c 89 bd 48 fd ff ff 	mov    %r15,-0x2b8(%rbp)
 100f37f:	48 8d 85 38 fc ff ff 	lea    -0x3c8(%rbp),%rax
 100f386:	49 89 c0             	mov    %rax,%r8
 100f389:	49 81 c0 20 01 00 00 	add    $0x120,%r8
 100f390:	4c 89 85 48 ff ff ff 	mov    %r8,-0xb8(%rbp)
 100f397:	48 8d 05 1a 49 ff ff 	lea    -0xb6e6(%rip),%rax        # 1003cb8 <myl_t_385cfdbc00ec32031699460779c15099b2bba3cad0e440fffb08e10df0acb9e1>
 100f39e:	48 89 85 58 fd ff ff 	mov    %rax,-0x2a8(%rbp)
 100f3a5:	c7 85 70 fd ff ff 00 	movl   $0x0,-0x290(%rbp)
 100f3ac:	00 00 00 
 100f3af:	48 8d 85 48 fe ff ff 	lea    -0x1b8(%rbp),%rax
 100f3b6:	48 89 85 60 fd ff ff 	mov    %rax,-0x2a0(%rbp)
 100f3bd:	48 8d 85 d8 fd ff ff 	lea    -0x228(%rbp),%rax
 100f3c4:	48 83 c0 48          	add    $0x48,%rax
 100f3c8:	48 89 85 68 fd ff ff 	mov    %rax,-0x298(%rbp)
 100f3cf:	48 8d 85 38 fc ff ff 	lea    -0x3c8(%rbp),%rax
 100f3d6:	49 89 c1             	mov    %rax,%r9
 100f3d9:	49 81 c1 40 01 00 00 	add    $0x140,%r9
 100f3e0:	4c 89 8d 50 ff ff ff 	mov    %r9,-0xb0(%rbp)
 100f3e7:	48 8d 05 ca 48 ff ff 	lea    -0xb736(%rip),%rax        # 1003cb8 <myl_t_385cfdbc00ec32031699460779c15099b2bba3cad0e440fffb08e10df0acb9e1>
 100f3ee:	48 89 85 78 fd ff ff 	mov    %rax,-0x288(%rbp)
 100f3f5:	c7 85 90 fd ff ff 00 	movl   $0x0,-0x270(%rbp)
 100f3fc:	00 00 00 
 100f3ff:	48 8d 85 50 fe ff ff 	lea    -0x1b0(%rbp),%rax
 100f406:	48 89 85 80 fd ff ff 	mov    %rax,-0x280(%rbp)
 100f40d:	48 8d 85 d8 fd ff ff 	lea    -0x228(%rbp),%rax
 100f414:	48 83 c0 50          	add    $0x50,%rax
 100f418:	48 89 85 88 fd ff ff 	mov    %rax,-0x278(%rbp)
 100f41f:	48 8d 05 92 48 ff ff 	lea    -0xb76e(%rip),%rax        # 1003cb8 <myl_t_385cfdbc00ec32031699460779c15099b2bba3cad0e440fffb08e10df0acb9e1>
 100f426:	48 89 85 98 fd ff ff 	mov    %rax,-0x268(%rbp)
 100f42d:	c7 85 b0 fd ff ff 00 	movl   $0x0,-0x250(%rbp)
 100f434:	00 00 00 
 100f437:	48 8d 85 58 fe ff ff 	lea    -0x1a8(%rbp),%rax
 100f43e:	48 89 85 a0 fd ff ff 	mov    %rax,-0x260(%rbp)
 100f445:	48 8d 85 d8 fd ff ff 	lea    -0x228(%rbp),%rax
 100f44c:	49 89 c4             	mov    %rax,%r12
 100f44f:	49 83 c4 58          	add    $0x58,%r12
 100f453:	4c 89 65 a8          	mov    %r12,-0x58(%rbp)
 100f457:	4c 89 a5 a8 fd ff ff 	mov    %r12,-0x258(%rbp)
 100f45e:	48 8d 05 53 48 ff ff 	lea    -0xb7ad(%rip),%rax        # 1003cb8 <myl_t_385cfdbc00ec32031699460779c15099b2bba3cad0e440fffb08e10df0acb9e1>
 100f465:	48 89 85 b8 fd ff ff 	mov    %rax,-0x248(%rbp)
 100f46c:	c7 85 d0 fd ff ff 00 	movl   $0x0,-0x230(%rbp)
 100f473:	00 00 00 
 100f476:	48 8d 85 60 fe ff ff 	lea    -0x1a0(%rbp),%rax
 100f47d:	48 89 85 c0 fd ff ff 	mov    %rax,-0x240(%rbp)
 100f484:	48 8d 85 d8 fd ff ff 	lea    -0x228(%rbp),%rax
 100f48b:	48 89 c2             	mov    %rax,%rdx
 100f48e:	48 83 c2 60          	add    $0x60,%rdx
 100f492:	48 89 55 d8          	mov    %rdx,-0x28(%rbp)
 100f496:	48 89 95 c8 fd ff ff 	mov    %rdx,-0x238(%rbp)
 100f49d:	b9 0d 00 00 00       	mov    $0xd,%ecx
 100f4a2:	48 8d 95 38 fc ff ff 	lea    -0x3c8(%rbp),%rdx
 100f4a9:	48 8d b5 18 fc ff ff 	lea    -0x3e8(%rbp),%rsi
 100f4b0:	49 89 ff             	mov    %rdi,%r15
 100f4b3:	e8 d8 73 00 00       	call   1016890 <myl_qbe_rc_frame_enter>
 100f4b8:	4c 89 ff             	mov    %r15,%rdi
 100f4bb:	49 89 ff             	mov    %rdi,%r15
 100f4be:	e8 0d 7d 00 00       	call   10171d0 <myl_qbe_require_step_accounting>
 100f4c3:	4c 89 ff             	mov    %r15,%rdi
 100f4c6:	49 89 ff             	mov    %rdi,%r15
 100f4c9:	e8 62 7d 00 00       	call   1017230 <myl_qbe_require_frame_accounting>
 100f4ce:	4c 89 ff             	mov    %r15,%rdi
 100f4d1:	48 c7 85 08 ff ff ff 	movq   $0x0,-0xf8(%rbp)
 100f4d8:	00 00 00 00 
 100f4dc:	ba 00 00 00 00       	mov    $0x0,%edx
 100f4e1:	48 8d 35 b8 f9 01 00 	lea    0x1f9b8(%rip),%rsi        # 102eea0 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a>
 100f4e8:	49 89 ff             	mov    %rdi,%r15
 100f4eb:	48 89 df             	mov    %rbx,%rdi
 100f4ee:	e8 9d e2 00 00       	call   101d790 <myl_native_list_new>
 100f4f3:	4c 89 ff             	mov    %r15,%rdi
 100f4f6:	4c 8b 45 e0          	mov    -0x20(%rbp),%r8
 100f4fa:	83 f8 00             	cmp    $0x0,%eax
 100f4fd:	75 0a                	jne    100f509 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x529>
 100f4ff:	48 89 fb             	mov    %rdi,%rbx
 100f502:	e8 f9 79 00 00       	call   1016f00 <myl_qbe_fail_allocation>
 100f507:	0f 0b                	ud2
 100f509:	48 87 fb             	xchg   %rdi,%rbx
 100f50c:	48 89 85 08 ff ff ff 	mov    %rax,-0xf8(%rbp)
 100f513:	48 8b 8d 08 ff ff ff 	mov    -0xf8(%rbp),%rcx
 100f51a:	48 89 8d 58 fe ff ff 	mov    %rcx,-0x1a8(%rbp)
 100f521:	48 8d 0d e8 f9 01 00 	lea    0x1f9e8(%rip),%rcx        # 102ef10 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b>
 100f528:	48 89 8d 98 fd ff ff 	mov    %rcx,-0x268(%rbp)
 100f52f:	c7 85 b0 fd ff ff 02 	movl   $0x2,-0x250(%rbp)
 100f536:	00 00 00 
 100f539:	c7 85 30 fe ff ff 01 	movl   $0x1,-0x1d0(%rbp)
 100f540:	00 00 00 
 100f543:	48 8b 8d 58 fe ff ff 	mov    -0x1a8(%rbp),%rcx
 100f54a:	48 89 8d 40 fe ff ff 	mov    %rcx,-0x1c0(%rbp)
 100f551:	48 8d 0d b8 f9 01 00 	lea    0x1f9b8(%rip),%rcx        # 102ef10 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b>
 100f558:	48 89 8d 38 fd ff ff 	mov    %rcx,-0x2c8(%rbp)
 100f55f:	c7 85 50 fd ff ff 02 	movl   $0x2,-0x2b0(%rbp)
 100f566:	00 00 00 
 100f569:	c7 85 50 fd ff ff 02 	movl   $0x2,-0x2b0(%rbp)
 100f570:	00 00 00 
 100f573:	c7 85 30 fe ff ff 00 	movl   $0x0,-0x1d0(%rbp)
 100f57a:	00 00 00 
 100f57d:	c7 85 18 fe ff ff 01 	movl   $0x1,-0x1e8(%rbp)
 100f584:	00 00 00 
 100f587:	48 89 85 08 ff ff ff 	mov    %rax,-0xf8(%rbp)
 100f58e:	48 8d 95 58 fe ff ff 	lea    -0x1a8(%rbp),%rdx
 100f595:	48 8d 8d 08 ff ff ff 	lea    -0xf8(%rbp),%rcx
 100f59c:	48 29 d1             	sub    %rdx,%rcx
 100f59f:	48 8d b5 08 ff ff ff 	lea    -0xf8(%rbp),%rsi
 100f5a6:	48 8d 95 58 fe ff ff 	lea    -0x1a8(%rbp),%rdx
 100f5ad:	48 29 f2             	sub    %rsi,%rdx
 100f5b0:	48 83 f9 08          	cmp    $0x8,%rcx
 100f5b4:	0f 92 c1             	setb   %cl
 100f5b7:	0f b6 c9             	movzbl %cl,%ecx
 100f5ba:	89 4d e8             	mov    %ecx,-0x18(%rbp)
 100f5bd:	48 83 fa 08          	cmp    $0x8,%rdx
 100f5c1:	0f 92 c2             	setb   %dl
 100f5c4:	0f b6 d2             	movzbl %dl,%edx
 100f5c7:	89 55 ec             	mov    %edx,-0x14(%rbp)
 100f5ca:	09 d1                	or     %edx,%ecx
 100f5cc:	75 5a                	jne    100f628 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x648>
 100f5ce:	48 83 f8 00          	cmp    $0x0,%rax
 100f5d2:	74 1a                	je     100f5ee <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x60e>
 100f5d4:	48 83 e8 10          	sub    $0x10,%rax
 100f5d8:	48 8b 00             	mov    (%rax),%rax
 100f5db:	48 b9 01 00 00 00 00 	movabs $0x5000000000000001,%rcx
 100f5e2:	00 00 50 
 100f5e5:	48 21 c8             	and    %rcx,%rax
 100f5e8:	48 83 f8 00          	cmp    $0x0,%rax
 100f5ec:	75 3a                	jne    100f628 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x648>
 100f5ee:	48 8b 85 08 ff ff ff 	mov    -0xf8(%rbp),%rax
 100f5f5:	48 89 85 58 fe ff ff 	mov    %rax,-0x1a8(%rbp)
 100f5fc:	ba 08 00 00 00       	mov    $0x8,%edx
 100f601:	be 00 00 00 00       	mov    $0x0,%esi
 100f606:	49 89 ff             	mov    %rdi,%r15
 100f609:	48 8d bd 08 ff ff ff 	lea    -0xf8(%rbp),%rdi
 100f610:	e8 7b ce 01 00       	call   102c490 <compiler_rt.fastMemset>
 100f615:	4c 89 ff             	mov    %r15,%rdi
 100f618:	8b 55 ec             	mov    -0x14(%rbp),%edx
 100f61b:	8b 4d e8             	mov    -0x18(%rbp),%ecx
 100f61e:	48 8b 75 f0          	mov    -0x10(%rbp),%rsi
 100f622:	4c 8b 45 e0          	mov    -0x20(%rbp),%r8
 100f626:	eb 4d                	jmp    100f675 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x695>
 100f628:	48 8d 8d 08 ff ff ff 	lea    -0xf8(%rbp),%rcx
 100f62f:	48 8d 95 58 fe ff ff 	lea    -0x1a8(%rbp),%rdx
 100f636:	48 8d 35 d3 f8 01 00 	lea    0x1f8d3(%rip),%rsi        # 102ef10 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b>
 100f63d:	49 89 ff             	mov    %rdi,%r15
 100f640:	e8 ab c2 01 00       	call   102b8f0 <myl_rc_native_take>
 100f645:	4c 89 ff             	mov    %r15,%rdi
 100f648:	8b 55 ec             	mov    -0x14(%rbp),%edx
 100f64b:	8b 4d e8             	mov    -0x18(%rbp),%ecx
 100f64e:	48 8b 75 f0          	mov    -0x10(%rbp),%rsi
 100f652:	4c 8b 45 e0          	mov    -0x20(%rbp),%r8
 100f656:	83 f8 00             	cmp    $0x0,%eax
 100f659:	75 1a                	jne    100f675 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x695>
 100f65b:	e8 b0 42 01 00       	call   1023910 <myl_rc_take_failure>
 100f660:	48 89 df             	mov    %rbx,%rdi
 100f663:	89 c6                	mov    %eax,%esi
 100f665:	48 89 fb             	mov    %rdi,%rbx
 100f668:	e8 33 71 00 00       	call   10167a0 <myl_qbe_rc_status>
 100f66d:	48 89 df             	mov    %rbx,%rdi
 100f670:	e9 4b 18 00 00       	jmp    1010ec0 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1ee0>
 100f675:	c7 85 18 fe ff ff 00 	movl   $0x0,-0x1e8(%rbp)
 100f67c:	00 00 00 
 100f67f:	48 8d 05 8a f8 01 00 	lea    0x1f88a(%rip),%rax        # 102ef10 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b>
 100f686:	48 89 85 98 fd ff ff 	mov    %rax,-0x268(%rbp)
 100f68d:	c7 85 b0 fd ff ff 02 	movl   $0x2,-0x250(%rbp)
 100f694:	00 00 00 
 100f697:	c7 85 30 fe ff ff 01 	movl   $0x1,-0x1d0(%rbp)
 100f69e:	00 00 00 
 100f6a1:	8b 85 d8 fd ff ff    	mov    -0x228(%rbp),%eax
 100f6a7:	83 f8 00             	cmp    $0x0,%eax
 100f6aa:	74 23                	je     100f6cf <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x6ef>
 100f6ac:	48 8d b5 38 fc ff ff 	lea    -0x3c8(%rbp),%rsi
 100f6b3:	49 89 ff             	mov    %rdi,%r15
 100f6b6:	48 89 df             	mov    %rbx,%rdi
 100f6b9:	e8 b2 72 00 00       	call   1016970 <myl_qbe_rc_slot_drop>
 100f6be:	4c 89 ff             	mov    %r15,%rdi
 100f6c1:	8b 55 ec             	mov    -0x14(%rbp),%edx
 100f6c4:	8b 4d e8             	mov    -0x18(%rbp),%ecx
 100f6c7:	48 8b 75 f0          	mov    -0x10(%rbp),%rsi
 100f6cb:	4c 8b 45 e0          	mov    -0x20(%rbp),%r8
 100f6cf:	48 8b 85 58 fe ff ff 	mov    -0x1a8(%rbp),%rax
 100f6d6:	48 89 85 c8 fe ff ff 	mov    %rax,-0x138(%rbp)
 100f6dd:	c7 85 30 fe ff ff 00 	movl   $0x0,-0x1d0(%rbp)
 100f6e4:	00 00 00 
 100f6e7:	48 8d 05 22 f8 01 00 	lea    0x1f822(%rip),%rax        # 102ef10 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b>
 100f6ee:	48 89 85 38 fc ff ff 	mov    %rax,-0x3c8(%rbp)
 100f6f5:	c7 85 50 fc ff ff 02 	movl   $0x2,-0x3b0(%rbp)
 100f6fc:	00 00 00 
 100f6ff:	48 8d 85 c8 fe ff ff 	lea    -0x138(%rbp),%rax
 100f706:	48 89 85 40 fc ff ff 	mov    %rax,-0x3c0(%rbp)
 100f70d:	48 8d 85 d8 fd ff ff 	lea    -0x228(%rbp),%rax
 100f714:	48 89 85 48 fc ff ff 	mov    %rax,-0x3b8(%rbp)
 100f71b:	8b 85 b0 fd ff ff    	mov    -0x250(%rbp),%eax
 100f721:	89 85 50 fc ff ff    	mov    %eax,-0x3b0(%rbp)
 100f727:	c7 85 d8 fd ff ff 01 	movl   $0x1,-0x228(%rbp)
 100f72e:	00 00 00 
 100f731:	41 89 c1             	mov    %eax,%r9d
 100f734:	48 8b 85 c8 fe ff ff 	mov    -0x138(%rbp),%rax
 100f73b:	41 83 f9 08          	cmp    $0x8,%r9d
 100f73f:	74 0c                	je     100f74d <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x76d>
 100f741:	48 89 85 08 ff ff ff 	mov    %rax,-0xf8(%rbp)
 100f748:	e9 f0 00 00 00       	jmp    100f83d <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x85d>
 100f74d:	48 c7 85 58 fe ff ff 	movq   $0x0,-0x1a8(%rbp)
 100f754:	00 00 00 00 
 100f758:	48 8d 95 58 fe ff ff 	lea    -0x1a8(%rbp),%rdx
 100f75f:	48 89 c6             	mov    %rax,%rsi
 100f762:	49 89 ff             	mov    %rdi,%r15
 100f765:	e8 f6 46 01 00       	call   1023e60 <myl_rc_hold_acquire>
 100f76a:	4c 89 ff             	mov    %r15,%rdi
 100f76d:	89 c6                	mov    %eax,%esi
 100f76f:	49 89 ff             	mov    %rdi,%r15
 100f772:	48 89 df             	mov    %rbx,%rdi
 100f775:	e8 26 70 00 00       	call   10167a0 <myl_qbe_rc_status>
 100f77a:	4c 89 ff             	mov    %r15,%rdi
 100f77d:	8b 55 ec             	mov    -0x14(%rbp),%edx
 100f780:	8b 4d e8             	mov    -0x18(%rbp),%ecx
 100f783:	4c 8b 7d b0          	mov    -0x50(%rbp),%r15
 100f787:	48 8b 75 f0          	mov    -0x10(%rbp),%rsi
 100f78b:	4c 8b 45 e0          	mov    -0x20(%rbp),%r8
 100f78f:	83 f8 00             	cmp    $0x0,%eax
 100f792:	75 08                	jne    100f79c <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x7bc>
 100f794:	48 89 df             	mov    %rbx,%rdi
 100f797:	e9 24 17 00 00       	jmp    1010ec0 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1ee0>
 100f79c:	48 8d 05 6d f7 01 00 	lea    0x1f76d(%rip),%rax        # 102ef10 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b>
 100f7a3:	48 89 85 98 fd ff ff 	mov    %rax,-0x268(%rbp)
 100f7aa:	c7 85 b0 fd ff ff 02 	movl   $0x2,-0x250(%rbp)
 100f7b1:	00 00 00 
 100f7b4:	48 8d 85 58 fe ff ff 	lea    -0x1a8(%rbp),%rax
 100f7bb:	48 89 85 a0 fd ff ff 	mov    %rax,-0x260(%rbp)
 100f7c2:	4c 89 a5 a8 fd ff ff 	mov    %r12,-0x258(%rbp)
 100f7c9:	c7 85 b0 fd ff ff 08 	movl   $0x8,-0x250(%rbp)
 100f7d0:	00 00 00 
 100f7d3:	c7 85 30 fe ff ff 01 	movl   $0x1,-0x1d0(%rbp)
 100f7da:	00 00 00 
 100f7dd:	48 8b 85 58 fe ff ff 	mov    -0x1a8(%rbp),%rax
 100f7e4:	48 89 85 40 fe ff ff 	mov    %rax,-0x1c0(%rbp)
 100f7eb:	4c 8d 0d 1e f7 01 00 	lea    0x1f71e(%rip),%r9        # 102ef10 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b>
 100f7f2:	4c 89 8d 38 fd ff ff 	mov    %r9,-0x2c8(%rbp)
 100f7f9:	c7 85 50 fd ff ff 02 	movl   $0x2,-0x2b0(%rbp)
 100f800:	00 00 00 
 100f803:	4c 8d 8d 40 fe ff ff 	lea    -0x1c0(%rbp),%r9
 100f80a:	4c 89 8d 40 fd ff ff 	mov    %r9,-0x2c0(%rbp)
 100f811:	4c 89 bd 48 fd ff ff 	mov    %r15,-0x2b8(%rbp)
 100f818:	c7 85 50 fd ff ff 08 	movl   $0x8,-0x2b0(%rbp)
 100f81f:	00 00 00 
 100f822:	c7 85 18 fe ff ff 01 	movl   $0x1,-0x1e8(%rbp)
 100f829:	00 00 00 
 100f82c:	c7 85 30 fe ff ff 00 	movl   $0x0,-0x1d0(%rbp)
 100f833:	00 00 00 
 100f836:	48 89 85 08 ff ff ff 	mov    %rax,-0xf8(%rbp)
 100f83d:	44 8b 8d 18 fe ff ff 	mov    -0x1e8(%rbp),%r9d
 100f844:	44 8b 95 50 fd ff ff 	mov    -0x2b0(%rbp),%r10d
 100f84b:	41 83 e2 18          	and    $0x18,%r10d
 100f84f:	41 83 fa 00          	cmp    $0x0,%r10d
 100f853:	41 0f 94 c2          	sete   %r10b
 100f857:	45 0f b6 d2          	movzbl %r10b,%r10d
 100f85b:	45 85 ca             	test   %r9d,%r10d
 100f85e:	0f 85 91 00 00 00    	jne    100f8f5 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x915>
 100f864:	48 8d 8d 08 ff ff ff 	lea    -0xf8(%rbp),%rcx
 100f86b:	48 8d 95 58 fe ff ff 	lea    -0x1a8(%rbp),%rdx
 100f872:	49 89 f7             	mov    %rsi,%r15
 100f875:	48 8d 35 94 f6 01 00 	lea    0x1f694(%rip),%rsi        # 102ef10 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b>
 100f87c:	49 89 fc             	mov    %rdi,%r12
 100f87f:	e8 ec c6 01 00       	call   102bf70 <myl_rc_native_retain>
 100f884:	4c 89 fe             	mov    %r15,%rsi
 100f887:	4c 89 e7             	mov    %r12,%rdi
 100f88a:	83 f8 00             	cmp    $0x0,%eax
 100f88d:	75 1a                	jne    100f8a9 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x8c9>
 100f88f:	e8 7c 40 01 00       	call   1023910 <myl_rc_take_failure>
 100f894:	48 89 df             	mov    %rbx,%rdi
 100f897:	89 c6                	mov    %eax,%esi
 100f899:	48 89 fb             	mov    %rdi,%rbx
 100f89c:	e8 ff 6e 00 00       	call   10167a0 <myl_qbe_rc_status>
 100f8a1:	48 89 df             	mov    %rbx,%rdi
 100f8a4:	e9 17 16 00 00       	jmp    1010ec0 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1ee0>
 100f8a9:	48 8d 05 60 f6 01 00 	lea    0x1f660(%rip),%rax        # 102ef10 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b>
 100f8b0:	48 89 85 98 fd ff ff 	mov    %rax,-0x268(%rbp)
 100f8b7:	c7 85 b0 fd ff ff 02 	movl   $0x2,-0x250(%rbp)
 100f8be:	00 00 00 
 100f8c1:	c7 85 30 fe ff ff 01 	movl   $0x1,-0x1d0(%rbp)
 100f8c8:	00 00 00 
 100f8cb:	8b 85 18 fe ff ff    	mov    -0x1e8(%rbp),%eax
 100f8d1:	83 f8 00             	cmp    $0x0,%eax
 100f8d4:	74 17                	je     100f8ed <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x90d>
 100f8d6:	49 89 f7             	mov    %rsi,%r15
 100f8d9:	4c 89 ee             	mov    %r13,%rsi
 100f8dc:	49 89 fc             	mov    %rdi,%r12
 100f8df:	48 89 df             	mov    %rbx,%rdi
 100f8e2:	e8 89 70 00 00       	call   1016970 <myl_qbe_rc_slot_drop>
 100f8e7:	4c 89 fe             	mov    %r15,%rsi
 100f8ea:	4c 89 e7             	mov    %r12,%rdi
 100f8ed:	48 87 df             	xchg   %rbx,%rdi
 100f8f0:	e9 d0 00 00 00       	jmp    100f9c5 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x9e5>
 100f8f5:	09 d1                	or     %edx,%ecx
 100f8f7:	75 55                	jne    100f94e <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x96e>
 100f8f9:	48 83 f8 00          	cmp    $0x0,%rax
 100f8fd:	74 1a                	je     100f919 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x939>
 100f8ff:	48 83 e8 10          	sub    $0x10,%rax
 100f903:	48 8b 00             	mov    (%rax),%rax
 100f906:	48 b9 01 00 00 00 00 	movabs $0x5000000000000001,%rcx
 100f90d:	00 00 50 
 100f910:	48 21 c8             	and    %rcx,%rax
 100f913:	48 83 f8 00          	cmp    $0x0,%rax
 100f917:	75 35                	jne    100f94e <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x96e>
 100f919:	48 8b 85 08 ff ff ff 	mov    -0xf8(%rbp),%rax
 100f920:	48 89 85 58 fe ff ff 	mov    %rax,-0x1a8(%rbp)
 100f927:	ba 08 00 00 00       	mov    $0x8,%edx
 100f92c:	49 89 f7             	mov    %rsi,%r15
 100f92f:	be 00 00 00 00       	mov    $0x0,%esi
 100f934:	49 89 fc             	mov    %rdi,%r12
 100f937:	48 8d bd 08 ff ff ff 	lea    -0xf8(%rbp),%rdi
 100f93e:	e8 4d cb 01 00       	call   102c490 <compiler_rt.fastMemset>
 100f943:	4c 89 fe             	mov    %r15,%rsi
 100f946:	4c 89 e7             	mov    %r12,%rdi
 100f949:	48 87 df             	xchg   %rbx,%rdi
 100f94c:	eb 4b                	jmp    100f999 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x9b9>
 100f94e:	4d 89 c7             	mov    %r8,%r15
 100f951:	48 8d 8d 08 ff ff ff 	lea    -0xf8(%rbp),%rcx
 100f958:	48 8d 95 58 fe ff ff 	lea    -0x1a8(%rbp),%rdx
 100f95f:	49 89 f7             	mov    %rsi,%r15
 100f962:	48 8d 35 a7 f5 01 00 	lea    0x1f5a7(%rip),%rsi        # 102ef10 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b>
 100f969:	49 89 fc             	mov    %rdi,%r12
 100f96c:	e8 7f bf 01 00       	call   102b8f0 <myl_rc_native_take>
 100f971:	4c 89 fe             	mov    %r15,%rsi
 100f974:	4c 89 e7             	mov    %r12,%rdi
 100f977:	83 f8 00             	cmp    $0x0,%eax
 100f97a:	75 1a                	jne    100f996 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x9b6>
 100f97c:	e8 8f 3f 01 00       	call   1023910 <myl_rc_take_failure>
 100f981:	48 89 df             	mov    %rbx,%rdi
 100f984:	89 c6                	mov    %eax,%esi
 100f986:	48 89 fb             	mov    %rdi,%rbx
 100f989:	e8 12 6e 00 00       	call   10167a0 <myl_qbe_rc_status>
 100f98e:	48 89 df             	mov    %rbx,%rdi
 100f991:	e9 2a 15 00 00       	jmp    1010ec0 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1ee0>
 100f996:	48 87 df             	xchg   %rbx,%rdi
 100f999:	c7 85 18 fe ff ff 00 	movl   $0x0,-0x1e8(%rbp)
 100f9a0:	00 00 00 
 100f9a3:	48 8d 05 66 f5 01 00 	lea    0x1f566(%rip),%rax        # 102ef10 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b>
 100f9aa:	48 89 85 98 fd ff ff 	mov    %rax,-0x268(%rbp)
 100f9b1:	c7 85 b0 fd ff ff 02 	movl   $0x2,-0x250(%rbp)
 100f9b8:	00 00 00 
 100f9bb:	c7 85 30 fe ff ff 01 	movl   $0x1,-0x1d0(%rbp)
 100f9c2:	00 00 00 
 100f9c5:	8b 85 e0 fd ff ff    	mov    -0x220(%rbp),%eax
 100f9cb:	83 f8 00             	cmp    $0x0,%eax
 100f9ce:	74 0b                	je     100f9db <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x9fb>
 100f9d0:	49 89 fc             	mov    %rdi,%r12
 100f9d3:	e8 98 6f 00 00       	call   1016970 <myl_qbe_rc_slot_drop>
 100f9d8:	4c 89 e7             	mov    %r12,%rdi
 100f9db:	48 8b 85 58 fe ff ff 	mov    -0x1a8(%rbp),%rax
 100f9e2:	48 89 85 d0 fe ff ff 	mov    %rax,-0x130(%rbp)
 100f9e9:	c7 85 30 fe ff ff 00 	movl   $0x0,-0x1d0(%rbp)
 100f9f0:	00 00 00 
 100f9f3:	48 8d 05 16 f5 01 00 	lea    0x1f516(%rip),%rax        # 102ef10 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b>
 100f9fa:	48 89 85 58 fc ff ff 	mov    %rax,-0x3a8(%rbp)
 100fa01:	c7 85 70 fc ff ff 02 	movl   $0x2,-0x390(%rbp)
 100fa08:	00 00 00 
 100fa0b:	48 8d 85 d0 fe ff ff 	lea    -0x130(%rbp),%rax
 100fa12:	48 89 85 60 fc ff ff 	mov    %rax,-0x3a0(%rbp)
 100fa19:	4c 89 b5 68 fc ff ff 	mov    %r14,-0x398(%rbp)
 100fa20:	8b 85 b0 fd ff ff    	mov    -0x250(%rbp),%eax
 100fa26:	89 85 70 fc ff ff    	mov    %eax,-0x390(%rbp)
 100fa2c:	c7 85 e0 fd ff ff 01 	movl   $0x1,-0x220(%rbp)
 100fa33:	00 00 00 
 100fa36:	8b 85 d8 fd ff ff    	mov    -0x228(%rbp),%eax
 100fa3c:	83 f8 00             	cmp    $0x0,%eax
 100fa3f:	74 12                	je     100fa53 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xa73>
 100fa41:	48 8d b5 38 fc ff ff 	lea    -0x3c8(%rbp),%rsi
 100fa48:	49 89 fc             	mov    %rdi,%r12
 100fa4b:	e8 20 6f 00 00       	call   1016970 <myl_qbe_rc_slot_drop>
 100fa50:	4c 89 e7             	mov    %r12,%rdi
 100fa53:	48 c7 85 08 ff ff ff 	movq   $0x0,-0xf8(%rbp)
 100fa5a:	00 00 00 00 
 100fa5e:	48 c7 85 08 ff ff ff 	movq   $0x3e8,-0xf8(%rbp)
 100fa65:	e8 03 00 00 
 100fa69:	41 bc 00 00 00 00    	mov    $0x0,%r12d
 100fa6f:	90                   	nop
 100fa70:	4c 89 a5 08 ff ff ff 	mov    %r12,-0xf8(%rbp)
 100fa77:	48 c7 85 10 ff ff ff 	movq   $0x3e8,-0xf0(%rbp)
 100fa7e:	e8 03 00 00 
 100fa82:	49 81 fc e8 03 00 00 	cmp    $0x3e8,%r12
 100fa89:	0f 9c c0             	setl   %al
 100fa8c:	48 0f b6 c0          	movzbq %al,%rax
 100fa90:	48 89 85 08 ff ff ff 	mov    %rax,-0xf8(%rbp)
 100fa97:	0f 8d 43 03 00 00    	jge    100fde0 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xe00>
 100fa9d:	48 c7 85 08 ff ff ff 	movq   $0x6b,-0xf8(%rbp)
 100faa4:	6b 00 00 00 
 100faa8:	48 c7 85 10 ff ff ff 	movq   $0x65,-0xf0(%rbp)
 100faaf:	65 00 00 00 
 100fab3:	48 c7 85 18 ff ff ff 	movq   $0x79,-0xe8(%rbp)
 100faba:	79 00 00 00 
 100fabe:	48 8b 05 63 fc 01 00 	mov    0x1fc63(%rip),%rax        # 102f728 <myl_lit_7c9ad5bce17f8d7309d981a8c987a567b0a2e56945e29fb3b883a7b4446dd143>
 100fac5:	48 89 85 08 ff ff ff 	mov    %rax,-0xf8(%rbp)
 100facc:	48 8b 8d 08 ff ff ff 	mov    -0xf8(%rbp),%rcx
 100fad3:	48 89 8d 58 fe ff ff 	mov    %rcx,-0x1a8(%rbp)
 100fada:	48 8d 0d bf f3 01 00 	lea    0x1f3bf(%rip),%rcx        # 102eea0 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a>
 100fae1:	48 89 8d 98 fd ff ff 	mov    %rcx,-0x268(%rbp)
 100fae8:	c7 85 b0 fd ff ff 02 	movl   $0x2,-0x250(%rbp)
 100faef:	00 00 00 
 100faf2:	c7 85 30 fe ff ff 01 	movl   $0x1,-0x1d0(%rbp)
 100faf9:	00 00 00 
 100fafc:	48 8b 8d 58 fe ff ff 	mov    -0x1a8(%rbp),%rcx
 100fb03:	48 89 8d 40 fe ff ff 	mov    %rcx,-0x1c0(%rbp)
 100fb0a:	48 8d 0d 8f f3 01 00 	lea    0x1f38f(%rip),%rcx        # 102eea0 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a>
 100fb11:	48 89 8d 38 fd ff ff 	mov    %rcx,-0x2c8(%rbp)
 100fb18:	c7 85 50 fd ff ff 02 	movl   $0x2,-0x2b0(%rbp)
 100fb1f:	00 00 00 
 100fb22:	c7 85 50 fd ff ff 02 	movl   $0x2,-0x2b0(%rbp)
 100fb29:	00 00 00 
 100fb2c:	c7 85 30 fe ff ff 00 	movl   $0x0,-0x1d0(%rbp)
 100fb33:	00 00 00 
 100fb36:	c7 85 18 fe ff ff 01 	movl   $0x1,-0x1e8(%rbp)
 100fb3d:	00 00 00 
 100fb40:	48 89 85 08 ff ff ff 	mov    %rax,-0xf8(%rbp)
 100fb47:	4c 89 a5 10 ff ff ff 	mov    %r12,-0xf0(%rbp)
 100fb4e:	ba 00 00 00 00       	mov    $0x0,%edx
 100fb53:	4c 89 e6             	mov    %r12,%rsi
 100fb56:	49 89 ff             	mov    %rdi,%r15
 100fb59:	48 89 df             	mov    %rbx,%rdi
 100fb5c:	e8 6f 15 00 00       	call   10110d0 <myl_native_text_scalar>
 100fb61:	4c 89 ff             	mov    %r15,%rdi
 100fb64:	48 89 c2             	mov    %rax,%rdx
 100fb67:	83 fa 00             	cmp    $0x0,%edx
 100fb6a:	0f 84 69 02 00 00    	je     100fdd9 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xdf9>
 100fb70:	48 89 95 10 ff ff ff 	mov    %rdx,-0xf0(%rbp)
 100fb77:	48 8b 85 10 ff ff ff 	mov    -0xf0(%rbp),%rax
 100fb7e:	48 89 85 58 fe ff ff 	mov    %rax,-0x1a8(%rbp)
 100fb85:	48 8d 05 14 f3 01 00 	lea    0x1f314(%rip),%rax        # 102eea0 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a>
 100fb8c:	48 89 85 98 fd ff ff 	mov    %rax,-0x268(%rbp)
 100fb93:	c7 85 b0 fd ff ff 02 	movl   $0x2,-0x250(%rbp)
 100fb9a:	00 00 00 
 100fb9d:	c7 85 30 fe ff ff 01 	movl   $0x1,-0x1d0(%rbp)
 100fba4:	00 00 00 
 100fba7:	48 8b 85 58 fe ff ff 	mov    -0x1a8(%rbp),%rax
 100fbae:	48 89 85 48 fe ff ff 	mov    %rax,-0x1b8(%rbp)
 100fbb5:	48 8d 05 e4 f2 01 00 	lea    0x1f2e4(%rip),%rax        # 102eea0 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a>
 100fbbc:	48 89 85 58 fd ff ff 	mov    %rax,-0x2a8(%rbp)
 100fbc3:	c7 85 70 fd ff ff 02 	movl   $0x2,-0x290(%rbp)
 100fbca:	00 00 00 
 100fbcd:	c7 85 70 fd ff ff 02 	movl   $0x2,-0x290(%rbp)
 100fbd4:	00 00 00 
 100fbd7:	c7 85 30 fe ff ff 00 	movl   $0x0,-0x1d0(%rbp)
 100fbde:	00 00 00 
 100fbe1:	c7 85 20 fe ff ff 01 	movl   $0x1,-0x1e0(%rbp)
 100fbe8:	00 00 00 
 100fbeb:	48 89 95 10 ff ff ff 	mov    %rdx,-0xf0(%rbp)
 100fbf2:	48 8b b5 08 ff ff ff 	mov    -0xf8(%rbp),%rsi
 100fbf9:	49 89 ff             	mov    %rdi,%r15
 100fbfc:	48 89 df             	mov    %rbx,%rdi
 100fbff:	e8 1c ec 00 00       	call   101e820 <myl_native_text_concat>
 100fc04:	4c 89 ff             	mov    %r15,%rdi
 100fc07:	4c 8b 85 48 ff ff ff 	mov    -0xb8(%rbp),%r8
 100fc0e:	83 f8 00             	cmp    $0x0,%eax
 100fc11:	0f 84 bb 01 00 00    	je     100fdd2 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xdf2>
 100fc17:	48 89 85 08 ff ff ff 	mov    %rax,-0xf8(%rbp)
 100fc1e:	48 8b 85 08 ff ff ff 	mov    -0xf8(%rbp),%rax
 100fc25:	48 89 85 58 fe ff ff 	mov    %rax,-0x1a8(%rbp)
 100fc2c:	48 8d 05 6d f2 01 00 	lea    0x1f26d(%rip),%rax        # 102eea0 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a>
 100fc33:	48 89 85 98 fd ff ff 	mov    %rax,-0x268(%rbp)
 100fc3a:	c7 85 b0 fd ff ff 02 	movl   $0x2,-0x250(%rbp)
 100fc41:	00 00 00 
 100fc44:	c7 85 30 fe ff ff 01 	movl   $0x1,-0x1d0(%rbp)
 100fc4b:	00 00 00 
 100fc4e:	8b 85 18 fe ff ff    	mov    -0x1e8(%rbp),%eax
 100fc54:	83 f8 00             	cmp    $0x0,%eax
 100fc57:	74 15                	je     100fc6e <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xc8e>
 100fc59:	4c 89 ee             	mov    %r13,%rsi
 100fc5c:	49 89 ff             	mov    %rdi,%r15
 100fc5f:	e8 0c 6d 00 00       	call   1016970 <myl_qbe_rc_slot_drop>
 100fc64:	4c 89 ff             	mov    %r15,%rdi
 100fc67:	4c 8b 85 48 ff ff ff 	mov    -0xb8(%rbp),%r8
 100fc6e:	8b 85 20 fe ff ff    	mov    -0x1e0(%rbp),%eax
 100fc74:	83 f8 00             	cmp    $0x0,%eax
 100fc77:	74 0e                	je     100fc87 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xca7>
 100fc79:	4c 89 c6             	mov    %r8,%rsi
 100fc7c:	49 89 ff             	mov    %rdi,%r15
 100fc7f:	e8 ec 6c 00 00       	call   1016970 <myl_qbe_rc_slot_drop>
 100fc84:	4c 89 ff             	mov    %r15,%rdi
 100fc87:	48 8b 85 58 fe ff ff 	mov    -0x1a8(%rbp),%rax
 100fc8e:	48 89 85 40 fe ff ff 	mov    %rax,-0x1c0(%rbp)
 100fc95:	48 8d 05 04 f2 01 00 	lea    0x1f204(%rip),%rax        # 102eea0 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a>
 100fc9c:	48 89 85 38 fd ff ff 	mov    %rax,-0x2c8(%rbp)
 100fca3:	c7 85 50 fd ff ff 02 	movl   $0x2,-0x2b0(%rbp)
 100fcaa:	00 00 00 
 100fcad:	8b 85 b0 fd ff ff    	mov    -0x250(%rbp),%eax
 100fcb3:	89 85 50 fd ff ff    	mov    %eax,-0x2b0(%rbp)
 100fcb9:	c7 85 30 fe ff ff 00 	movl   $0x0,-0x1d0(%rbp)
 100fcc0:	00 00 00 
 100fcc3:	c7 85 18 fe ff ff 01 	movl   $0x1,-0x1e8(%rbp)
 100fcca:	00 00 00 
 100fccd:	48 8b 85 40 fe ff ff 	mov    -0x1c0(%rbp),%rax
 100fcd4:	48 89 85 08 ff ff ff 	mov    %rax,-0xf8(%rbp)
 100fcdb:	48 8d 05 2e f2 01 00 	lea    0x1f22e(%rip),%rax        # 102ef10 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b>
 100fce2:	48 89 85 58 fc ff ff 	mov    %rax,-0x3a8(%rbp)
 100fce9:	c7 85 70 fc ff ff 02 	movl   $0x2,-0x390(%rbp)
 100fcf0:	00 00 00 
 100fcf3:	48 8d 85 d0 fe ff ff 	lea    -0x130(%rbp),%rax
 100fcfa:	48 89 85 60 fc ff ff 	mov    %rax,-0x3a0(%rbp)
 100fd01:	4c 89 b5 68 fc ff ff 	mov    %r14,-0x398(%rbp)
 100fd08:	4c 89 f1             	mov    %r14,%rcx
 100fd0b:	48 8d 95 d0 fe ff ff 	lea    -0x130(%rbp),%rdx
 100fd12:	48 8d 35 f7 f1 01 00 	lea    0x1f1f7(%rip),%rsi        # 102ef10 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b>
 100fd19:	49 89 ff             	mov    %rdi,%r15
 100fd1c:	e8 cf 6f 00 00       	call   1016cf0 <myl_qbe_rc_unique_local>
 100fd21:	4c 89 ff             	mov    %r15,%rdi
 100fd24:	83 f8 00             	cmp    $0x0,%eax
 100fd27:	0f 84 93 11 00 00    	je     1010ec0 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1ee0>
 100fd2d:	48 8b b5 d0 fe ff ff 	mov    -0x130(%rbp),%rsi
 100fd34:	48 8d 95 08 ff ff ff 	lea    -0xf8(%rbp),%rdx
 100fd3b:	49 89 ff             	mov    %rdi,%r15
 100fd3e:	48 89 df             	mov    %rbx,%rdi
 100fd41:	e8 fa de 00 00       	call   101dc40 <myl_rc_list_append>
 100fd46:	4c 89 ff             	mov    %r15,%rdi
 100fd49:	4c 8b 85 48 ff ff ff 	mov    -0xb8(%rbp),%r8
 100fd50:	83 f8 00             	cmp    $0x0,%eax
 100fd53:	74 76                	je     100fdcb <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xdeb>
 100fd55:	48 c7 85 08 ff ff ff 	movq   $0x0,-0xf8(%rbp)
 100fd5c:	00 00 00 00 
 100fd60:	8b 85 18 fe ff ff    	mov    -0x1e8(%rbp),%eax
 100fd66:	83 f8 00             	cmp    $0x0,%eax
 100fd69:	74 15                	je     100fd80 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xda0>
 100fd6b:	4c 89 ee             	mov    %r13,%rsi
 100fd6e:	49 89 ff             	mov    %rdi,%r15
 100fd71:	e8 fa 6b 00 00       	call   1016970 <myl_qbe_rc_slot_drop>
 100fd76:	4c 89 ff             	mov    %r15,%rdi
 100fd79:	4c 8b 85 48 ff ff ff 	mov    -0xb8(%rbp),%r8
 100fd80:	4c 89 a5 08 ff ff ff 	mov    %r12,-0xf8(%rbp)
 100fd87:	48 c7 85 10 ff ff ff 	movq   $0x1,-0xf0(%rbp)
 100fd8e:	01 00 00 00 
 100fd92:	48 b8 fe ff ff ff ff 	movabs $0x7ffffffffffffffe,%rax
 100fd99:	ff ff 7f 
 100fd9c:	49 39 c4             	cmp    %rax,%r12
 100fd9f:	7f 10                	jg     100fdb1 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xdd1>
 100fda1:	49 83 c4 01          	add    $0x1,%r12
 100fda5:	4c 89 a5 08 ff ff ff 	mov    %r12,-0xf8(%rbp)
 100fdac:	e9 bf fc ff ff       	jmp    100fa70 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xa90>
 100fdb1:	4c 89 e2             	mov    %r12,%rdx
 100fdb4:	41 b8 40 00 00 00    	mov    $0x40,%r8d
 100fdba:	b9 01 00 00 00       	mov    $0x1,%ecx
 100fdbf:	be 00 00 00 00       	mov    $0x0,%esi
 100fdc4:	e8 37 72 00 00       	call   1017000 <myl_qbe_fail_overflow_op>
 100fdc9:	0f 0b                	ud2
 100fdcb:	e8 30 71 00 00       	call   1016f00 <myl_qbe_fail_allocation>
 100fdd0:	0f 0b                	ud2
 100fdd2:	e8 29 71 00 00       	call   1016f00 <myl_qbe_fail_allocation>
 100fdd7:	0f 0b                	ud2
 100fdd9:	e8 22 71 00 00       	call   1016f00 <myl_qbe_fail_allocation>
 100fdde:	0f 0b                	ud2
 100fde0:	4c 8b 75 c0          	mov    -0x40(%rbp),%r14
 100fde4:	4c 8b 7d e0          	mov    -0x20(%rbp),%r15
 100fde8:	b9 01 00 00 00       	mov    $0x1,%ecx
 100fded:	48 8d 15 74 3d ff ff 	lea    -0xc28c(%rip),%rdx        # 1003b68 <myl_t_1a91deb3742283487d66c3b500f6effd7ef1170e6d4b4368fe9ec3c3f0354fda>
 100fdf4:	48 8d 35 a5 f0 01 00 	lea    0x1f0a5(%rip),%rsi        # 102eea0 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a>
 100fdfb:	49 89 fc             	mov    %rdi,%r12
 100fdfe:	48 89 df             	mov    %rbx,%rdi
 100fe01:	e8 da eb 00 00       	call   101e9e0 <myl_native_dictionary_new>
 100fe06:	4d 89 f8             	mov    %r15,%r8
 100fe09:	4c 89 e7             	mov    %r12,%rdi
 100fe0c:	48 8b 55 d8          	mov    -0x28(%rbp),%rdx
 100fe10:	48 8b 4d d0          	mov    -0x30(%rbp),%rcx
 100fe14:	83 f8 00             	cmp    $0x0,%eax
 100fe17:	75 0a                	jne    100fe23 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xe43>
 100fe19:	48 89 fb             	mov    %rdi,%rbx
 100fe1c:	e8 df 70 00 00       	call   1016f00 <myl_qbe_fail_allocation>
 100fe21:	0f 0b                	ud2
 100fe23:	48 87 fb             	xchg   %rdi,%rbx
 100fe26:	48 89 85 60 fe ff ff 	mov    %rax,-0x1a0(%rbp)
 100fe2d:	48 8d 35 2c f2 01 00 	lea    0x1f22c(%rip),%rsi        # 102f060 <myl_t_db6bd58975531b7368ca22b8af460e2a11856412c594a38caca68120ceaa09fc>
 100fe34:	48 89 b5 b8 fd ff ff 	mov    %rsi,-0x248(%rbp)
 100fe3b:	c7 85 d0 fd ff ff 02 	movl   $0x2,-0x230(%rbp)
 100fe42:	00 00 00 
 100fe45:	48 8d b5 60 fe ff ff 	lea    -0x1a0(%rbp),%rsi
 100fe4c:	48 89 b5 c0 fd ff ff 	mov    %rsi,-0x240(%rbp)
 100fe53:	48 89 95 c8 fd ff ff 	mov    %rdx,-0x238(%rbp)
 100fe5a:	c7 85 d0 fd ff ff 04 	movl   $0x4,-0x230(%rbp)
 100fe61:	00 00 00 
 100fe64:	c7 85 38 fe ff ff 01 	movl   $0x1,-0x1c8(%rbp)
 100fe6b:	00 00 00 
 100fe6e:	c7 85 38 fe ff ff 00 	movl   $0x0,-0x1c8(%rbp)
 100fe75:	00 00 00 
 100fe78:	48 89 85 08 ff ff ff 	mov    %rax,-0xf8(%rbp)
 100fe7f:	48 8b 95 08 ff ff ff 	mov    -0xf8(%rbp),%rdx
 100fe86:	48 89 95 58 fe ff ff 	mov    %rdx,-0x1a8(%rbp)
 100fe8d:	48 8d 15 cc f1 01 00 	lea    0x1f1cc(%rip),%rdx        # 102f060 <myl_t_db6bd58975531b7368ca22b8af460e2a11856412c594a38caca68120ceaa09fc>
 100fe94:	48 89 95 98 fd ff ff 	mov    %rdx,-0x268(%rbp)
 100fe9b:	c7 85 b0 fd ff ff 02 	movl   $0x2,-0x250(%rbp)
 100fea2:	00 00 00 
 100fea5:	c7 85 30 fe ff ff 01 	movl   $0x1,-0x1d0(%rbp)
 100feac:	00 00 00 
 100feaf:	48 8b 95 58 fe ff ff 	mov    -0x1a8(%rbp),%rdx
 100feb6:	48 89 95 40 fe ff ff 	mov    %rdx,-0x1c0(%rbp)
 100febd:	48 8d 15 9c f1 01 00 	lea    0x1f19c(%rip),%rdx        # 102f060 <myl_t_db6bd58975531b7368ca22b8af460e2a11856412c594a38caca68120ceaa09fc>
 100fec4:	48 89 95 38 fd ff ff 	mov    %rdx,-0x2c8(%rbp)
 100fecb:	c7 85 50 fd ff ff 02 	movl   $0x2,-0x2b0(%rbp)
 100fed2:	00 00 00 
 100fed5:	c7 85 50 fd ff ff 02 	movl   $0x2,-0x2b0(%rbp)
 100fedc:	00 00 00 
 100fedf:	c7 85 30 fe ff ff 00 	movl   $0x0,-0x1d0(%rbp)
 100fee6:	00 00 00 
 100fee9:	c7 85 18 fe ff ff 01 	movl   $0x1,-0x1e8(%rbp)
 100fef0:	00 00 00 
 100fef3:	48 89 85 08 ff ff ff 	mov    %rax,-0xf8(%rbp)
 100fefa:	48 83 f8 00          	cmp    $0x0,%rax
 100fefe:	75 05                	jne    100ff05 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xf25>
 100ff00:	49 89 cf             	mov    %rcx,%r15
 100ff03:	eb 1d                	jmp    100ff22 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xf42>
 100ff05:	48 83 e8 10          	sub    $0x10,%rax
 100ff09:	48 8b 00             	mov    (%rax),%rax
 100ff0c:	49 89 cf             	mov    %rcx,%r15
 100ff0f:	48 b9 01 00 00 00 00 	movabs $0x5000000000000001,%rcx
 100ff16:	00 00 50 
 100ff19:	48 21 c8             	and    %rcx,%rax
 100ff1c:	48 83 f8 00          	cmp    $0x0,%rax
 100ff20:	75 39                	jne    100ff5b <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xf7b>
 100ff22:	48 8b 85 08 ff ff ff 	mov    -0xf8(%rbp),%rax
 100ff29:	48 89 85 58 fe ff ff 	mov    %rax,-0x1a8(%rbp)
 100ff30:	ba 08 00 00 00       	mov    $0x8,%edx
 100ff35:	be 00 00 00 00       	mov    $0x0,%esi
 100ff3a:	49 89 fc             	mov    %rdi,%r12
 100ff3d:	48 8d bd 08 ff ff ff 	lea    -0xf8(%rbp),%rdi
 100ff44:	e8 47 c5 01 00       	call   102c490 <compiler_rt.fastMemset>
 100ff49:	4c 89 f9             	mov    %r15,%rcx
 100ff4c:	4c 89 e7             	mov    %r12,%rdi
 100ff4f:	48 8b 75 c8          	mov    -0x38(%rbp),%rsi
 100ff53:	49 89 cf             	mov    %rcx,%r15
 100ff56:	48 87 df             	xchg   %rbx,%rdi
 100ff59:	eb 4c                	jmp    100ffa7 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xfc7>
 100ff5b:	4c 89 f9             	mov    %r15,%rcx
 100ff5e:	49 89 cf             	mov    %rcx,%r15
 100ff61:	48 8d 8d 08 ff ff ff 	lea    -0xf8(%rbp),%rcx
 100ff68:	48 8d 95 58 fe ff ff 	lea    -0x1a8(%rbp),%rdx
 100ff6f:	48 8d 35 ea f0 01 00 	lea    0x1f0ea(%rip),%rsi        # 102f060 <myl_t_db6bd58975531b7368ca22b8af460e2a11856412c594a38caca68120ceaa09fc>
 100ff76:	49 89 fc             	mov    %rdi,%r12
 100ff79:	e8 72 b9 01 00       	call   102b8f0 <myl_rc_native_take>
 100ff7e:	4c 89 e7             	mov    %r12,%rdi
 100ff81:	48 8b 75 c8          	mov    -0x38(%rbp),%rsi
 100ff85:	83 f8 00             	cmp    $0x0,%eax
 100ff88:	75 1a                	jne    100ffa4 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xfc4>
 100ff8a:	e8 81 39 01 00       	call   1023910 <myl_rc_take_failure>
 100ff8f:	48 89 df             	mov    %rbx,%rdi
 100ff92:	89 c6                	mov    %eax,%esi
 100ff94:	48 89 fb             	mov    %rdi,%rbx
 100ff97:	e8 04 68 00 00       	call   10167a0 <myl_qbe_rc_status>
 100ff9c:	48 89 df             	mov    %rbx,%rdi
 100ff9f:	e9 1c 0f 00 00       	jmp    1010ec0 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1ee0>
 100ffa4:	48 87 df             	xchg   %rbx,%rdi
 100ffa7:	c7 85 18 fe ff ff 00 	movl   $0x0,-0x1e8(%rbp)
 100ffae:	00 00 00 
 100ffb1:	48 8d 05 a8 f0 01 00 	lea    0x1f0a8(%rip),%rax        # 102f060 <myl_t_db6bd58975531b7368ca22b8af460e2a11856412c594a38caca68120ceaa09fc>
 100ffb8:	48 89 85 98 fd ff ff 	mov    %rax,-0x268(%rbp)
 100ffbf:	c7 85 b0 fd ff ff 02 	movl   $0x2,-0x250(%rbp)
 100ffc6:	00 00 00 
 100ffc9:	c7 85 30 fe ff ff 01 	movl   $0x1,-0x1d0(%rbp)
 100ffd0:	00 00 00 
 100ffd3:	8b 85 e8 fd ff ff    	mov    -0x218(%rbp),%eax
 100ffd9:	83 f8 00             	cmp    $0x0,%eax
 100ffdc:	75 05                	jne    100ffe3 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1003>
 100ffde:	4c 89 f9             	mov    %r15,%rcx
 100ffe1:	eb 0e                	jmp    100fff1 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1011>
 100ffe3:	49 89 fc             	mov    %rdi,%r12
 100ffe6:	e8 85 69 00 00       	call   1016970 <myl_qbe_rc_slot_drop>
 100ffeb:	4c 89 f9             	mov    %r15,%rcx
 100ffee:	4c 89 e7             	mov    %r12,%rdi
 100fff1:	48 8b 85 58 fe ff ff 	mov    -0x1a8(%rbp),%rax
 100fff8:	48 89 85 d8 fe ff ff 	mov    %rax,-0x128(%rbp)
 100ffff:	c7 85 30 fe ff ff 00 	movl   $0x0,-0x1d0(%rbp)
 1010006:	00 00 00 
 1010009:	48 8d 05 50 f0 01 00 	lea    0x1f050(%rip),%rax        # 102f060 <myl_t_db6bd58975531b7368ca22b8af460e2a11856412c594a38caca68120ceaa09fc>
 1010010:	48 89 85 78 fc ff ff 	mov    %rax,-0x388(%rbp)
 1010017:	c7 85 90 fc ff ff 02 	movl   $0x2,-0x370(%rbp)
 101001e:	00 00 00 
 1010021:	48 8d 85 d8 fe ff ff 	lea    -0x128(%rbp),%rax
 1010028:	48 89 85 80 fc ff ff 	mov    %rax,-0x380(%rbp)
 101002f:	48 89 8d 88 fc ff ff 	mov    %rcx,-0x378(%rbp)
 1010036:	8b 85 b0 fd ff ff    	mov    -0x250(%rbp),%eax
 101003c:	89 85 90 fc ff ff    	mov    %eax,-0x370(%rbp)
 1010042:	c7 85 e8 fd ff ff 01 	movl   $0x1,-0x218(%rbp)
 1010049:	00 00 00 
 101004c:	48 c7 85 08 ff ff ff 	movq   $0x0,-0xf8(%rbp)
 1010053:	00 00 00 00 
 1010057:	48 c7 85 08 ff ff ff 	movq   $0x1e8480,-0xf8(%rbp)
 101005e:	80 84 1e 00 
 1010062:	48 8d 05 f7 ef 01 00 	lea    0x1eff7(%rip),%rax        # 102f060 <myl_t_db6bd58975531b7368ca22b8af460e2a11856412c594a38caca68120ceaa09fc>
 1010069:	48 89 85 78 fc ff ff 	mov    %rax,-0x388(%rbp)
 1010070:	c7 85 90 fc ff ff 02 	movl   $0x2,-0x370(%rbp)
 1010077:	00 00 00 
 101007a:	48 8d 85 d8 fe ff ff 	lea    -0x128(%rbp),%rax
 1010081:	48 89 85 80 fc ff ff 	mov    %rax,-0x380(%rbp)
 1010088:	48 89 8d 88 fc ff ff 	mov    %rcx,-0x378(%rbp)
 101008f:	48 8d 95 d8 fe ff ff 	lea    -0x128(%rbp),%rdx
 1010096:	48 8d 35 c3 ef 01 00 	lea    0x1efc3(%rip),%rsi        # 102f060 <myl_t_db6bd58975531b7368ca22b8af460e2a11856412c594a38caca68120ceaa09fc>
 101009d:	49 89 fc             	mov    %rdi,%r12
 10100a0:	e8 4b 6c 00 00       	call   1016cf0 <myl_qbe_rc_unique_local>
 10100a5:	4c 89 e7             	mov    %r12,%rdi
 10100a8:	83 f8 00             	cmp    $0x0,%eax
 10100ab:	0f 84 0f 0e 00 00    	je     1010ec0 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1ee0>
 10100b1:	41 bc 00 00 00 00    	mov    $0x0,%r12d
 10100b7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
 10100be:	00 00 
 10100c0:	4c 89 a5 08 ff ff ff 	mov    %r12,-0xf8(%rbp)
 10100c7:	48 c7 85 10 ff ff ff 	movq   $0x1e8480,-0xf0(%rbp)
 10100ce:	80 84 1e 00 
 10100d2:	49 81 fc 80 84 1e 00 	cmp    $0x1e8480,%r12
 10100d9:	0f 9c c0             	setl   %al
 10100dc:	48 0f b6 c0          	movzbq %al,%rax
 10100e0:	48 89 85 08 ff ff ff 	mov    %rax,-0xf8(%rbp)
 10100e7:	0f 8d 03 04 00 00    	jge    10104f0 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1510>
 10100ed:	48 8b b5 d0 fe ff ff 	mov    -0x130(%rbp),%rsi
 10100f4:	48 89 b5 08 ff ff ff 	mov    %rsi,-0xf8(%rbp)
 10100fb:	48 89 b5 e0 fe ff ff 	mov    %rsi,-0x120(%rbp)
 1010102:	4c 89 a5 08 ff ff ff 	mov    %r12,-0xf8(%rbp)
 1010109:	48 c7 85 10 ff ff ff 	movq   $0x1eef,-0xf0(%rbp)
 1010110:	ef 1e 00 00 
 1010114:	49 69 c4 ef 1e 00 00 	imul   $0x1eef,%r12,%rax
 101011b:	b9 ff ff ff ff       	mov    $0xffffffff,%ecx
 1010120:	4d 89 e1             	mov    %r12,%r9
 1010123:	49 21 c9             	and    %rcx,%r9
 1010126:	4d 89 e0             	mov    %r12,%r8
 1010129:	49 c1 e8 20          	shr    $0x20,%r8
 101012d:	49 69 c9 ef 1e 00 00 	imul   $0x1eef,%r9,%rcx
 1010134:	48 c1 e9 20          	shr    $0x20,%rcx
 1010138:	49 69 d0 ef 1e 00 00 	imul   $0x1eef,%r8,%rdx
 101013f:	48 01 ca             	add    %rcx,%rdx
 1010142:	b9 ff ff ff ff       	mov    $0xffffffff,%ecx
 1010147:	48 21 d1             	and    %rdx,%rcx
 101014a:	48 c1 ea 20          	shr    $0x20,%rdx
 101014e:	4d 6b c9 00          	imul   $0x0,%r9,%r9
 1010152:	4c 01 c9             	add    %r9,%rcx
 1010155:	48 c1 e9 20          	shr    $0x20,%rcx
 1010159:	4d 6b c0 00          	imul   $0x0,%r8,%r8
 101015d:	4c 01 c2             	add    %r8,%rdx
 1010160:	48 01 d1             	add    %rdx,%rcx
 1010163:	49 83 fc 00          	cmp    $0x0,%r12
 1010167:	0f 9c c2             	setl   %dl
 101016a:	48 0f b6 d2          	movzbq %dl,%rdx
 101016e:	48 f7 da             	neg    %rdx
 1010171:	49 89 d0             	mov    %rdx,%r8
 1010174:	49 81 e0 ef 1e 00 00 	and    $0x1eef,%r8
 101017b:	4c 89 e2             	mov    %r12,%rdx
 101017e:	48 83 e2 00          	and    $0x0,%rdx
 1010182:	4c 29 c1             	sub    %r8,%rcx
 1010185:	48 29 d1             	sub    %rdx,%rcx
 1010188:	48 89 c2             	mov    %rax,%rdx
 101018b:	48 c1 fa 3f          	sar    $0x3f,%rdx
 101018f:	48 39 ca             	cmp    %rcx,%rdx
 1010192:	0f 85 3e 03 00 00    	jne    10104d6 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x14f6>
 1010198:	48 89 85 08 ff ff ff 	mov    %rax,-0xf8(%rbp)
 101019f:	48 c7 85 10 ff ff ff 	movq   $0x3e8,-0xf0(%rbp)
 10101a6:	e8 03 00 00 
 10101aa:	48 b9 00 00 00 00 00 	movabs $0x8000000000000000,%rcx
 10101b1:	00 00 80 
 10101b4:	48 39 c8             	cmp    %rcx,%rax
 10101b7:	0f 94 c1             	sete   %cl
 10101ba:	48 0f b6 c9          	movzbq %cl,%rcx
 10101be:	48 83 e1 00          	and    $0x0,%rcx
 10101c2:	48 f7 d9             	neg    %rcx
 10101c5:	48 81 e1 e9 03 00 00 	and    $0x3e9,%rcx
 10101cc:	49 89 c8             	mov    %rcx,%r8
 10101cf:	49 81 f0 e8 03 00 00 	xor    $0x3e8,%r8
 10101d6:	48 99                	cqto
 10101d8:	49 f7 f8             	idiv   %r8
 10101db:	48 89 d1             	mov    %rdx,%rcx
 10101de:	48 83 f9 00          	cmp    $0x0,%rcx
 10101e2:	0f 95 c0             	setne  %al
 10101e5:	48 0f b6 c0          	movzbq %al,%rax
 10101e9:	4c 89 c2             	mov    %r8,%rdx
 10101ec:	48 31 ca             	xor    %rcx,%rdx
 10101ef:	48 83 fa 00          	cmp    $0x0,%rdx
 10101f3:	0f 9c c2             	setl   %dl
 10101f6:	48 0f b6 d2          	movzbq %dl,%rdx
 10101fa:	48 21 d0             	and    %rdx,%rax
 10101fd:	48 f7 d8             	neg    %rax
 1010200:	4c 21 c0             	and    %r8,%rax
 1010203:	48 01 c1             	add    %rax,%rcx
 1010206:	48 89 8d 08 ff ff ff 	mov    %rcx,-0xf8(%rbp)
 101020d:	48 89 8d 08 ff ff ff 	mov    %rcx,-0xf8(%rbp)
 1010214:	48 c7 85 10 ff ff ff 	movq   $0x0,-0xf0(%rbp)
 101021b:	00 00 00 00 
 101021f:	48 83 f9 00          	cmp    $0x0,%rcx
 1010223:	0f 9c c0             	setl   %al
 1010226:	48 0f b6 c0          	movzbq %al,%rax
 101022a:	48 89 85 08 ff ff ff 	mov    %rax,-0xf8(%rbp)
 1010231:	7d 51                	jge    1010284 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x12a4>
 1010233:	4c 8b 0e             	mov    (%rsi),%r9
 1010236:	4c 89 8d 08 ff ff ff 	mov    %r9,-0xf8(%rbp)
 101023d:	48 b8 ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rax
 1010244:	ff ff 7f 
 1010247:	49 39 c1             	cmp    %rax,%r9
 101024a:	0f 87 77 02 00 00    	ja     10104c7 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x14e7>
 1010250:	4c 89 8d 08 ff ff ff 	mov    %r9,-0xf8(%rbp)
 1010257:	48 89 8d 10 ff ff ff 	mov    %rcx,-0xf0(%rbp)
 101025e:	48 89 c8             	mov    %rcx,%rax
 1010261:	4c 01 c9             	add    %r9,%rcx
 1010264:	4c 89 ca             	mov    %r9,%rdx
 1010267:	48 31 ca             	xor    %rcx,%rdx
 101026a:	49 89 c0             	mov    %rax,%r8
 101026d:	49 31 c8             	xor    %rcx,%r8
 1010270:	4c 21 c2             	and    %r8,%rdx
 1010273:	48 83 fa 00          	cmp    $0x0,%rdx
 1010277:	0f 8c 2f 02 00 00    	jl     10104ac <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x14cc>
 101027d:	48 89 8d 08 ff ff ff 	mov    %rcx,-0xf8(%rbp)
 1010284:	48 89 8d 08 ff ff ff 	mov    %rcx,-0xf8(%rbp)
 101028b:	48 8b 06             	mov    (%rsi),%rax
 101028e:	48 39 c1             	cmp    %rax,%rcx
 1010291:	0f 83 08 02 00 00    	jae    101049f <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x14bf>
 1010297:	48 8b 46 20          	mov    0x20(%rsi),%rax
 101029b:	48 8b 04 c8          	mov    (%rax,%rcx,8),%rax
 101029f:	48 89 85 08 ff ff ff 	mov    %rax,-0xf8(%rbp)
 10102a6:	48 89 85 e8 fe ff ff 	mov    %rax,-0x118(%rbp)
 10102ad:	8b 85 f0 fd ff ff    	mov    -0x210(%rbp),%eax
 10102b3:	83 f8 00             	cmp    $0x0,%eax
 10102b6:	74 0e                	je     10102c6 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x12e6>
 10102b8:	4c 89 f6             	mov    %r14,%rsi
 10102bb:	49 89 ff             	mov    %rdi,%r15
 10102be:	e8 ad 66 00 00       	call   1016970 <myl_qbe_rc_slot_drop>
 10102c3:	4c 89 ff             	mov    %r15,%rdi
 10102c6:	48 8b 85 e8 fe ff ff 	mov    -0x118(%rbp),%rax
 10102cd:	48 89 85 08 ff ff ff 	mov    %rax,-0xf8(%rbp)
 10102d4:	48 c7 85 10 ff ff ff 	movq   $0x0,-0xf0(%rbp)
 10102db:	00 00 00 00 
 10102df:	49 89 ff             	mov    %rdi,%r15
 10102e2:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
 10102e9:	48 8d 95 28 ff ff ff 	lea    -0xd8(%rbp),%rdx
 10102f0:	48 8d b5 08 ff ff ff 	lea    -0xf8(%rbp),%rsi
 10102f7:	e8 f4 eb 00 00       	call   101eef0 <myl_native_dictionary_read>
 10102fc:	4c 89 ff             	mov    %r15,%rdi
 10102ff:	89 c1                	mov    %eax,%ecx
 1010301:	48 8b 45 b8          	mov    -0x48(%rbp),%rax
 1010305:	83 f9 00             	cmp    $0x0,%ecx
 1010308:	75 10                	jne    101031a <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x133a>
 101030a:	48 8b 8d 10 ff ff ff 	mov    -0xf0(%rbp),%rcx
 1010311:	48 89 8d 08 ff ff ff 	mov    %rcx,-0xf8(%rbp)
 1010318:	eb 0e                	jmp    1010328 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1348>
 101031a:	48 8b 8d 28 ff ff ff 	mov    -0xd8(%rbp),%rcx
 1010321:	48 89 8d 08 ff ff ff 	mov    %rcx,-0xf8(%rbp)
 1010328:	8b 8d 18 fe ff ff    	mov    -0x1e8(%rbp),%ecx
 101032e:	83 f9 00             	cmp    $0x0,%ecx
 1010331:	74 12                	je     1010345 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1365>
 1010333:	4c 89 ee             	mov    %r13,%rsi
 1010336:	49 89 ff             	mov    %rdi,%r15
 1010339:	e8 32 66 00 00       	call   1016970 <myl_qbe_rc_slot_drop>
 101033e:	4c 89 ff             	mov    %r15,%rdi
 1010341:	48 8b 45 b8          	mov    -0x48(%rbp),%rax
 1010345:	48 c7 85 10 ff ff ff 	movq   $0x1,-0xf0(%rbp)
 101034c:	01 00 00 00 
 1010350:	48 8b 95 08 ff ff ff 	mov    -0xf8(%rbp),%rdx
 1010357:	48 b9 fe ff ff ff ff 	movabs $0x7ffffffffffffffe,%rcx
 101035e:	ff ff 7f 
 1010361:	48 39 ca             	cmp    %rcx,%rdx
 1010364:	0f 8f 1e 01 00 00    	jg     1010488 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x14a8>
 101036a:	49 89 d7             	mov    %rdx,%r15
 101036d:	49 83 c7 01          	add    $0x1,%r15
 1010371:	4c 89 bd 08 ff ff ff 	mov    %r15,-0xf8(%rbp)
 1010378:	48 8b 8d d8 fe ff ff 	mov    -0x128(%rbp),%rcx
 101037f:	48 89 8d 08 ff ff ff 	mov    %rcx,-0xf8(%rbp)
 1010386:	8b 8d 18 fe ff ff    	mov    -0x1e8(%rbp),%ecx
 101038c:	83 f9 00             	cmp    $0x0,%ecx
 101038f:	74 16                	je     10103a7 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x13c7>
 1010391:	4c 89 ee             	mov    %r13,%rsi
 1010394:	49 89 fe             	mov    %rdi,%r14
 1010397:	e8 d4 65 00 00       	call   1016970 <myl_qbe_rc_slot_drop>
 101039c:	4c 89 f7             	mov    %r14,%rdi
 101039f:	48 8b 45 b8          	mov    -0x48(%rbp),%rax
 10103a3:	4c 8b 75 c0          	mov    -0x40(%rbp),%r14
 10103a7:	8b 8d 00 fe ff ff    	mov    -0x200(%rbp),%ecx
 10103ad:	83 f9 00             	cmp    $0x0,%ecx
 10103b0:	74 12                	je     10103c4 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x13e4>
 10103b2:	48 89 c6             	mov    %rax,%rsi
 10103b5:	49 89 fe             	mov    %rdi,%r14
 10103b8:	e8 b3 65 00 00       	call   1016970 <myl_qbe_rc_slot_drop>
 10103bd:	4c 89 f7             	mov    %r14,%rdi
 10103c0:	4c 8b 75 c0          	mov    -0x40(%rbp),%r14
 10103c4:	48 8b b5 d8 fe ff ff 	mov    -0x128(%rbp),%rsi
 10103cb:	48 89 b5 f0 fe ff ff 	mov    %rsi,-0x110(%rbp)
 10103d2:	48 8b 85 e8 fe ff ff 	mov    -0x118(%rbp),%rax
 10103d9:	48 89 85 08 ff ff ff 	mov    %rax,-0xf8(%rbp)
 10103e0:	4c 89 bd 10 ff ff ff 	mov    %r15,-0xf0(%rbp)
 10103e7:	48 8d 8d 10 ff ff ff 	lea    -0xf0(%rbp),%rcx
 10103ee:	48 8d 95 08 ff ff ff 	lea    -0xf8(%rbp),%rdx
 10103f5:	49 89 ff             	mov    %rdi,%r15
 10103f8:	48 89 df             	mov    %rbx,%rdi
 10103fb:	e8 70 f0 00 00       	call   101f470 <myl_native_dictionary_write>
 1010400:	4c 89 ff             	mov    %r15,%rdi
 1010403:	89 c1                	mov    %eax,%ecx
 1010405:	48 8b 45 b8          	mov    -0x48(%rbp),%rax
 1010409:	83 f9 00             	cmp    $0x0,%ecx
 101040c:	74 73                	je     1010481 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x14a1>
 101040e:	48 c7 85 08 ff ff ff 	movq   $0x0,-0xf8(%rbp)
 1010415:	00 00 00 00 
 1010419:	8b 8d 18 fe ff ff    	mov    -0x1e8(%rbp),%ecx
 101041f:	83 f9 00             	cmp    $0x0,%ecx
 1010422:	74 12                	je     1010436 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1456>
 1010424:	4c 89 ee             	mov    %r13,%rsi
 1010427:	49 89 ff             	mov    %rdi,%r15
 101042a:	e8 41 65 00 00       	call   1016970 <myl_qbe_rc_slot_drop>
 101042f:	4c 89 ff             	mov    %r15,%rdi
 1010432:	48 8b 45 b8          	mov    -0x48(%rbp),%rax
 1010436:	4c 89 a5 08 ff ff ff 	mov    %r12,-0xf8(%rbp)
 101043d:	48 c7 85 10 ff ff ff 	movq   $0x1,-0xf0(%rbp)
 1010444:	01 00 00 00 
 1010448:	48 b9 fe ff ff ff ff 	movabs $0x7ffffffffffffffe,%rcx
 101044f:	ff ff 7f 
 1010452:	49 39 cc             	cmp    %rcx,%r12
 1010455:	7f 10                	jg     1010467 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1487>
 1010457:	49 83 c4 01          	add    $0x1,%r12
 101045b:	4c 89 a5 08 ff ff ff 	mov    %r12,-0xf8(%rbp)
 1010462:	e9 59 fc ff ff       	jmp    10100c0 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x10e0>
 1010467:	4c 89 e2             	mov    %r12,%rdx
 101046a:	41 b8 40 00 00 00    	mov    $0x40,%r8d
 1010470:	b9 01 00 00 00       	mov    $0x1,%ecx
 1010475:	be 00 00 00 00       	mov    $0x0,%esi
 101047a:	e8 81 6b 00 00       	call   1017000 <myl_qbe_fail_overflow_op>
 101047f:	0f 0b                	ud2
 1010481:	e8 7a 6a 00 00       	call   1016f00 <myl_qbe_fail_allocation>
 1010486:	0f 0b                	ud2
 1010488:	41 b8 40 00 00 00    	mov    $0x40,%r8d
 101048e:	b9 01 00 00 00       	mov    $0x1,%ecx
 1010493:	be 00 00 00 00       	mov    $0x0,%esi
 1010498:	e8 63 6b 00 00       	call   1017000 <myl_qbe_fail_overflow_op>
 101049d:	0f 0b                	ud2
 101049f:	48 89 c2             	mov    %rax,%rdx
 10104a2:	48 89 ce             	mov    %rcx,%rsi
 10104a5:	e8 e6 6a 00 00       	call   1016f90 <myl_qbe_fail_normalized_index_bounds>
 10104aa:	0f 0b                	ud2
 10104ac:	48 89 c1             	mov    %rax,%rcx
 10104af:	4c 89 ce             	mov    %r9,%rsi
 10104b2:	41 b8 40 00 00 00    	mov    $0x40,%r8d
 10104b8:	48 89 f2             	mov    %rsi,%rdx
 10104bb:	be 00 00 00 00       	mov    $0x0,%esi
 10104c0:	e8 3b 6b 00 00       	call   1017000 <myl_qbe_fail_overflow_op>
 10104c5:	0f 0b                	ud2
 10104c7:	4c 89 ce             	mov    %r9,%rsi
 10104ca:	ba 40 01 00 00       	mov    $0x140,%edx
 10104cf:	e8 6c 6c 00 00       	call   1017140 <myl_qbe_fail_cast>
 10104d4:	0f 0b                	ud2
 10104d6:	4c 89 e2             	mov    %r12,%rdx
 10104d9:	41 b8 40 00 00 00    	mov    $0x40,%r8d
 10104df:	b9 ef 1e 00 00       	mov    $0x1eef,%ecx
 10104e4:	be 02 00 00 00       	mov    $0x2,%esi
 10104e9:	e8 12 6b 00 00       	call   1017000 <myl_qbe_fail_overflow_op>
 10104ee:	0f 0b                	ud2
 10104f0:	4c 8b 75 a8          	mov    -0x58(%rbp),%r14
 10104f4:	4c 8b 7d b0          	mov    -0x50(%rbp),%r15
 10104f8:	48 c7 85 08 ff ff ff 	movq   $0x0,-0xf8(%rbp)
 10104ff:	00 00 00 00 
 1010503:	48 8b b5 d0 fe ff ff 	mov    -0x130(%rbp),%rsi
 101050a:	8b 85 70 fc ff ff    	mov    -0x390(%rbp),%eax
 1010510:	83 f8 08             	cmp    $0x8,%eax
 1010513:	0f 94 c0             	sete   %al
 1010516:	0f b6 c0             	movzbl %al,%eax
 1010519:	8b 8d e0 fd ff ff    	mov    -0x220(%rbp),%ecx
 101051f:	85 c1                	test   %eax,%ecx
 1010521:	75 0c                	jne    101052f <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x154f>
 1010523:	48 89 b5 08 ff ff ff 	mov    %rsi,-0xf8(%rbp)
 101052a:	e9 d7 00 00 00       	jmp    1010606 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1626>
 101052f:	48 c7 85 58 fe ff ff 	movq   $0x0,-0x1a8(%rbp)
 1010536:	00 00 00 00 
 101053a:	48 8d 95 58 fe ff ff 	lea    -0x1a8(%rbp),%rdx
 1010541:	49 89 fc             	mov    %rdi,%r12
 1010544:	48 89 df             	mov    %rbx,%rdi
 1010547:	e8 14 39 01 00       	call   1023e60 <myl_rc_hold_acquire>
 101054c:	4c 89 e7             	mov    %r12,%rdi
 101054f:	89 c6                	mov    %eax,%esi
 1010551:	49 89 fc             	mov    %rdi,%r12
 1010554:	e8 47 62 00 00       	call   10167a0 <myl_qbe_rc_status>
 1010559:	4c 89 e7             	mov    %r12,%rdi
 101055c:	83 f8 00             	cmp    $0x0,%eax
 101055f:	0f 84 5b 09 00 00    	je     1010ec0 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1ee0>
 1010565:	48 8d 05 a4 e9 01 00 	lea    0x1e9a4(%rip),%rax        # 102ef10 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b>
 101056c:	48 89 85 98 fd ff ff 	mov    %rax,-0x268(%rbp)
 1010573:	c7 85 b0 fd ff ff 02 	movl   $0x2,-0x250(%rbp)
 101057a:	00 00 00 
 101057d:	48 8d 85 58 fe ff ff 	lea    -0x1a8(%rbp),%rax
 1010584:	48 89 85 a0 fd ff ff 	mov    %rax,-0x260(%rbp)
 101058b:	4c 89 b5 a8 fd ff ff 	mov    %r14,-0x258(%rbp)
 1010592:	c7 85 b0 fd ff ff 08 	movl   $0x8,-0x250(%rbp)
 1010599:	00 00 00 
 101059c:	c7 85 30 fe ff ff 01 	movl   $0x1,-0x1d0(%rbp)
 10105a3:	00 00 00 
 10105a6:	48 8b b5 58 fe ff ff 	mov    -0x1a8(%rbp),%rsi
 10105ad:	48 89 b5 40 fe ff ff 	mov    %rsi,-0x1c0(%rbp)
 10105b4:	48 8d 05 55 e9 01 00 	lea    0x1e955(%rip),%rax        # 102ef10 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b>
 10105bb:	48 89 85 38 fd ff ff 	mov    %rax,-0x2c8(%rbp)
 10105c2:	c7 85 50 fd ff ff 02 	movl   $0x2,-0x2b0(%rbp)
 10105c9:	00 00 00 
 10105cc:	48 8d 85 40 fe ff ff 	lea    -0x1c0(%rbp),%rax
 10105d3:	48 89 85 40 fd ff ff 	mov    %rax,-0x2c0(%rbp)
 10105da:	4c 89 bd 48 fd ff ff 	mov    %r15,-0x2b8(%rbp)
 10105e1:	c7 85 50 fd ff ff 08 	movl   $0x8,-0x2b0(%rbp)
 10105e8:	00 00 00 
 10105eb:	c7 85 18 fe ff ff 01 	movl   $0x1,-0x1e8(%rbp)
 10105f2:	00 00 00 
 10105f5:	c7 85 30 fe ff ff 00 	movl   $0x0,-0x1d0(%rbp)
 10105fc:	00 00 00 
 10105ff:	48 89 b5 08 ff ff ff 	mov    %rsi,-0xf8(%rbp)
 1010606:	48 c7 85 58 fe ff ff 	movq   $0x0,-0x1a8(%rbp)
 101060d:	00 00 00 00 
 1010611:	48 8d 95 58 fe ff ff 	lea    -0x1a8(%rbp),%rdx
 1010618:	49 89 fc             	mov    %rdi,%r12
 101061b:	48 89 df             	mov    %rbx,%rdi
 101061e:	e8 3d 38 01 00       	call   1023e60 <myl_rc_hold_acquire>
 1010623:	4c 89 e7             	mov    %r12,%rdi
 1010626:	89 c6                	mov    %eax,%esi
 1010628:	49 89 fc             	mov    %rdi,%r12
 101062b:	e8 70 61 00 00       	call   10167a0 <myl_qbe_rc_status>
 1010630:	4c 89 e7             	mov    %r12,%rdi
 1010633:	4c 8b 65 98          	mov    -0x68(%rbp),%r12
 1010637:	48 8b 75 a0          	mov    -0x60(%rbp),%rsi
 101063b:	83 f8 00             	cmp    $0x0,%eax
 101063e:	0f 84 7c 08 00 00    	je     1010ec0 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1ee0>
 1010644:	48 8d 05 c5 e8 01 00 	lea    0x1e8c5(%rip),%rax        # 102ef10 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b>
 101064b:	48 89 85 98 fd ff ff 	mov    %rax,-0x268(%rbp)
 1010652:	c7 85 b0 fd ff ff 02 	movl   $0x2,-0x250(%rbp)
 1010659:	00 00 00 
 101065c:	48 8d 85 58 fe ff ff 	lea    -0x1a8(%rbp),%rax
 1010663:	48 89 85 a0 fd ff ff 	mov    %rax,-0x260(%rbp)
 101066a:	4c 89 b5 a8 fd ff ff 	mov    %r14,-0x258(%rbp)
 1010671:	c7 85 b0 fd ff ff 08 	movl   $0x8,-0x250(%rbp)
 1010678:	00 00 00 
 101067b:	c7 85 30 fe ff ff 01 	movl   $0x1,-0x1d0(%rbp)
 1010682:	00 00 00 
 1010685:	8b 85 18 fe ff ff    	mov    -0x1e8(%rbp),%eax
 101068b:	83 f8 00             	cmp    $0x0,%eax
 101068e:	74 16                	je     10106a6 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x16c6>
 1010690:	4c 89 ee             	mov    %r13,%rsi
 1010693:	49 89 fc             	mov    %rdi,%r12
 1010696:	e8 d5 62 00 00       	call   1016970 <myl_qbe_rc_slot_drop>
 101069b:	4c 89 e7             	mov    %r12,%rdi
 101069e:	4c 8b 65 98          	mov    -0x68(%rbp),%r12
 10106a2:	48 8b 75 a0          	mov    -0x60(%rbp),%rsi
 10106a6:	48 8b 85 58 fe ff ff 	mov    -0x1a8(%rbp),%rax
 10106ad:	48 89 85 40 fe ff ff 	mov    %rax,-0x1c0(%rbp)
 10106b4:	48 8d 0d 55 e8 01 00 	lea    0x1e855(%rip),%rcx        # 102ef10 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b>
 10106bb:	48 89 8d 38 fd ff ff 	mov    %rcx,-0x2c8(%rbp)
 10106c2:	c7 85 50 fd ff ff 02 	movl   $0x2,-0x2b0(%rbp)
 10106c9:	00 00 00 
 10106cc:	48 8d 8d 40 fe ff ff 	lea    -0x1c0(%rbp),%rcx
 10106d3:	48 89 8d 40 fd ff ff 	mov    %rcx,-0x2c0(%rbp)
 10106da:	4c 89 bd 48 fd ff ff 	mov    %r15,-0x2b8(%rbp)
 10106e1:	c7 85 50 fd ff ff 08 	movl   $0x8,-0x2b0(%rbp)
 10106e8:	00 00 00 
 10106eb:	c7 85 18 fe ff ff 01 	movl   $0x1,-0x1e8(%rbp)
 10106f2:	00 00 00 
 10106f5:	c7 85 30 fe ff ff 00 	movl   $0x0,-0x1d0(%rbp)
 10106fc:	00 00 00 
 10106ff:	48 89 85 08 ff ff ff 	mov    %rax,-0xf8(%rbp)
 1010706:	48 89 85 58 fe ff ff 	mov    %rax,-0x1a8(%rbp)
 101070d:	48 8d 05 fc e7 01 00 	lea    0x1e7fc(%rip),%rax        # 102ef10 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b>
 1010714:	48 89 85 98 fd ff ff 	mov    %rax,-0x268(%rbp)
 101071b:	c7 85 b0 fd ff ff 02 	movl   $0x2,-0x250(%rbp)
 1010722:	00 00 00 
 1010725:	48 8d 85 58 fe ff ff 	lea    -0x1a8(%rbp),%rax
 101072c:	48 89 85 a0 fd ff ff 	mov    %rax,-0x260(%rbp)
 1010733:	4c 89 b5 a8 fd ff ff 	mov    %r14,-0x258(%rbp)
 101073a:	c7 85 b0 fd ff ff 08 	movl   $0x8,-0x250(%rbp)
 1010741:	00 00 00 
 1010744:	c7 85 30 fe ff ff 01 	movl   $0x1,-0x1d0(%rbp)
 101074b:	00 00 00 
 101074e:	c7 85 18 fe ff ff 00 	movl   $0x0,-0x1e8(%rbp)
 1010755:	00 00 00 
 1010758:	8b 85 08 fe ff ff    	mov    -0x1f8(%rbp),%eax
 101075e:	83 f8 00             	cmp    $0x0,%eax
 1010761:	74 0b                	je     101076e <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x178e>
 1010763:	49 89 fe             	mov    %rdi,%r14
 1010766:	e8 05 62 00 00       	call   1016970 <myl_qbe_rc_slot_drop>
 101076b:	4c 89 f7             	mov    %r14,%rdi
 101076e:	48 8b 85 58 fe ff ff 	mov    -0x1a8(%rbp),%rax
 1010775:	48 89 85 f8 fe ff ff 	mov    %rax,-0x108(%rbp)
 101077c:	48 8d 0d 8d e7 01 00 	lea    0x1e78d(%rip),%rcx        # 102ef10 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b>
 1010783:	48 89 8d f8 fc ff ff 	mov    %rcx,-0x308(%rbp)
 101078a:	c7 85 10 fd ff ff 02 	movl   $0x2,-0x2f0(%rbp)
 1010791:	00 00 00 
 1010794:	48 8d 8d f8 fe ff ff 	lea    -0x108(%rbp),%rcx
 101079b:	48 89 8d 00 fd ff ff 	mov    %rcx,-0x300(%rbp)
 10107a2:	4c 89 a5 08 fd ff ff 	mov    %r12,-0x2f8(%rbp)
 10107a9:	c7 85 10 fd ff ff 08 	movl   $0x8,-0x2f0(%rbp)
 10107b0:	00 00 00 
 10107b3:	c7 85 08 fe ff ff 01 	movl   $0x1,-0x1f8(%rbp)
 10107ba:	00 00 00 
 10107bd:	c7 85 30 fe ff ff 00 	movl   $0x0,-0x1d0(%rbp)
 10107c4:	00 00 00 
 10107c7:	48 c7 85 08 ff ff ff 	movq   $0x0,-0xf8(%rbp)
 10107ce:	00 00 00 00 
 10107d2:	48 8b 30             	mov    (%rax),%rsi
 10107d5:	48 89 b5 08 ff ff ff 	mov    %rsi,-0xf8(%rbp)
 10107dc:	48 b9 ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rcx
 10107e3:	ff ff 7f 
 10107e6:	48 39 ce             	cmp    %rcx,%rsi
 10107e9:	0f 87 c5 06 00 00    	ja     1010eb4 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1ed4>
 10107ef:	48 89 b5 08 ff ff ff 	mov    %rsi,-0xf8(%rbp)
 10107f6:	49 89 f4             	mov    %rsi,%r12
 10107f9:	48 c7 45 90 00 00 00 	movq   $0x0,-0x70(%rbp)
 1010800:	00 
 1010801:	41 be 00 00 00 00    	mov    $0x0,%r14d
 1010807:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
 101080e:	00 00 
 1010810:	4c 89 b5 08 ff ff ff 	mov    %r14,-0xf8(%rbp)
 1010817:	4c 89 a5 10 ff ff ff 	mov    %r12,-0xf0(%rbp)
 101081e:	4d 39 e6             	cmp    %r12,%r14
 1010821:	0f 9c c1             	setl   %cl
 1010824:	48 0f b6 c9          	movzbq %cl,%rcx
 1010828:	48 89 8d 08 ff ff ff 	mov    %rcx,-0xf8(%rbp)
 101082f:	0f 8d cd 05 00 00    	jge    1010e02 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1e22>
 1010835:	4c 89 a5 08 ff ff ff 	mov    %r12,-0xf8(%rbp)
 101083c:	48 8b 08             	mov    (%rax),%rcx
 101083f:	49 39 cc             	cmp    %rcx,%r12
 1010842:	0f 85 b3 05 00 00    	jne    1010dfb <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1e1b>
 1010848:	48 c7 85 08 ff ff ff 	movq   $0x0,-0xf8(%rbp)
 101084f:	00 00 00 00 
 1010853:	4c 89 b5 08 ff ff ff 	mov    %r14,-0xf8(%rbp)
 101085a:	48 8b 08             	mov    (%rax),%rcx
 101085d:	49 39 ce             	cmp    %rcx,%r14
 1010860:	0f 83 88 05 00 00    	jae    1010dee <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1e0e>
 1010866:	48 8b 40 20          	mov    0x20(%rax),%rax
 101086a:	4a 8b 04 f0          	mov    (%rax,%r14,8),%rax
 101086e:	48 89 85 08 ff ff ff 	mov    %rax,-0xf8(%rbp)
 1010875:	48 8d 8d 08 ff ff ff 	lea    -0xf8(%rbp),%rcx
 101087c:	48 8d 95 58 fe ff ff 	lea    -0x1a8(%rbp),%rdx
 1010883:	48 8d 35 16 e6 01 00 	lea    0x1e616(%rip),%rsi        # 102eea0 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a>
 101088a:	49 89 ff             	mov    %rdi,%r15
 101088d:	48 89 df             	mov    %rbx,%rdi
 1010890:	e8 2b b3 01 00       	call   102bbc0 <myl_rc_native_loan>
 1010895:	4c 89 ff             	mov    %r15,%rdi
 1010898:	83 f8 00             	cmp    $0x0,%eax
 101089b:	0f 84 30 05 00 00    	je     1010dd1 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1df1>
 10108a1:	48 8d 05 f8 e5 01 00 	lea    0x1e5f8(%rip),%rax        # 102eea0 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a>
 10108a8:	48 89 85 98 fd ff ff 	mov    %rax,-0x268(%rbp)
 10108af:	c7 85 b0 fd ff ff 02 	movl   $0x2,-0x250(%rbp)
 10108b6:	00 00 00 
 10108b9:	c7 85 b0 fd ff ff 10 	movl   $0x10,-0x250(%rbp)
 10108c0:	00 00 00 
 10108c3:	c7 85 30 fe ff ff 01 	movl   $0x1,-0x1d0(%rbp)
 10108ca:	00 00 00 
 10108cd:	48 8b 85 58 fe ff ff 	mov    -0x1a8(%rbp),%rax
 10108d4:	48 89 85 40 fe ff ff 	mov    %rax,-0x1c0(%rbp)
 10108db:	48 8d 05 be e5 01 00 	lea    0x1e5be(%rip),%rax        # 102eea0 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a>
 10108e2:	48 89 85 38 fd ff ff 	mov    %rax,-0x2c8(%rbp)
 10108e9:	c7 85 50 fd ff ff 02 	movl   $0x2,-0x2b0(%rbp)
 10108f0:	00 00 00 
 10108f3:	c7 85 50 fd ff ff 10 	movl   $0x10,-0x2b0(%rbp)
 10108fa:	00 00 00 
 10108fd:	c7 85 30 fe ff ff 00 	movl   $0x0,-0x1d0(%rbp)
 1010904:	00 00 00 
 1010907:	c7 85 18 fe ff ff 01 	movl   $0x1,-0x1e8(%rbp)
 101090e:	00 00 00 
 1010911:	48 8b 85 40 fe ff ff 	mov    -0x1c0(%rbp),%rax
 1010918:	48 89 85 08 ff ff ff 	mov    %rax,-0xf8(%rbp)
 101091f:	48 8d 8d 08 ff ff ff 	lea    -0xf8(%rbp),%rcx
 1010926:	48 8d 95 58 fe ff ff 	lea    -0x1a8(%rbp),%rdx
 101092d:	48 8d 35 6c e5 01 00 	lea    0x1e56c(%rip),%rsi        # 102eea0 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a>
 1010934:	49 89 ff             	mov    %rdi,%r15
 1010937:	48 89 df             	mov    %rbx,%rdi
 101093a:	e8 81 b2 01 00       	call   102bbc0 <myl_rc_native_loan>
 101093f:	4c 89 ff             	mov    %r15,%rdi
 1010942:	48 8b 4d 90          	mov    -0x70(%rbp),%rcx
 1010946:	4c 8b 95 58 ff ff ff 	mov    -0xa8(%rbp),%r10
 101094d:	48 8b b5 40 ff ff ff 	mov    -0xc0(%rbp),%rsi
 1010954:	83 f8 00             	cmp    $0x0,%eax
 1010957:	0f 84 57 04 00 00    	je     1010db4 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1dd4>
 101095d:	48 8d 05 3c e5 01 00 	lea    0x1e53c(%rip),%rax        # 102eea0 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a>
 1010964:	48 89 85 98 fd ff ff 	mov    %rax,-0x268(%rbp)
 101096b:	c7 85 b0 fd ff ff 02 	movl   $0x2,-0x250(%rbp)
 1010972:	00 00 00 
 1010975:	c7 85 b0 fd ff ff 10 	movl   $0x10,-0x250(%rbp)
 101097c:	00 00 00 
 101097f:	c7 85 30 fe ff ff 01 	movl   $0x1,-0x1d0(%rbp)
 1010986:	00 00 00 
 1010989:	8b 85 18 fe ff ff    	mov    -0x1e8(%rbp),%eax
 101098f:	83 f8 00             	cmp    $0x0,%eax
 1010992:	74 20                	je     10109b4 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x19d4>
 1010994:	4c 89 ee             	mov    %r13,%rsi
 1010997:	49 89 ff             	mov    %rdi,%r15
 101099a:	e8 d1 5f 00 00       	call   1016970 <myl_qbe_rc_slot_drop>
 101099f:	4c 89 ff             	mov    %r15,%rdi
 10109a2:	48 8b 4d 90          	mov    -0x70(%rbp),%rcx
 10109a6:	4c 8b 95 58 ff ff ff 	mov    -0xa8(%rbp),%r10
 10109ad:	48 8b b5 40 ff ff ff 	mov    -0xc0(%rbp),%rsi
 10109b4:	8b 85 10 fe ff ff    	mov    -0x1f0(%rbp),%eax
 10109ba:	83 f8 00             	cmp    $0x0,%eax
 10109bd:	74 16                	je     10109d5 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x19f5>
 10109bf:	49 89 ff             	mov    %rdi,%r15
 10109c2:	e8 a9 5f 00 00       	call   1016970 <myl_qbe_rc_slot_drop>
 10109c7:	4c 89 ff             	mov    %r15,%rdi
 10109ca:	48 8b 4d 90          	mov    -0x70(%rbp),%rcx
 10109ce:	4c 8b 95 58 ff ff ff 	mov    -0xa8(%rbp),%r10
 10109d5:	48 8b 85 58 fe ff ff 	mov    -0x1a8(%rbp),%rax
 10109dc:	48 89 85 00 ff ff ff 	mov    %rax,-0x100(%rbp)
 10109e3:	c7 85 30 fe ff ff 00 	movl   $0x0,-0x1d0(%rbp)
 10109ea:	00 00 00 
 10109ed:	48 8d 05 ac e4 01 00 	lea    0x1e4ac(%rip),%rax        # 102eea0 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a>
 10109f4:	48 89 85 18 fd ff ff 	mov    %rax,-0x2e8(%rbp)
 10109fb:	c7 85 30 fd ff ff 02 	movl   $0x2,-0x2d0(%rbp)
 1010a02:	00 00 00 
 1010a05:	48 8d 85 00 ff ff ff 	lea    -0x100(%rbp),%rax
 1010a0c:	48 89 85 20 fd ff ff 	mov    %rax,-0x2e0(%rbp)
 1010a13:	4c 89 95 28 fd ff ff 	mov    %r10,-0x2d8(%rbp)
 1010a1a:	8b 85 b0 fd ff ff    	mov    -0x250(%rbp),%eax
 1010a20:	89 85 30 fd ff ff    	mov    %eax,-0x2d0(%rbp)
 1010a26:	c7 85 10 fe ff ff 01 	movl   $0x1,-0x1f0(%rbp)
 1010a2d:	00 00 00 
 1010a30:	48 89 8d 08 ff ff ff 	mov    %rcx,-0xf8(%rbp)
 1010a37:	49 89 ff             	mov    %rdi,%r15
 1010a3a:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
 1010a41:	48 89 bd 10 ff ff ff 	mov    %rdi,-0xf0(%rbp)
 1010a48:	48 8b 85 00 ff ff ff 	mov    -0x100(%rbp),%rax
 1010a4f:	48 89 85 18 ff ff ff 	mov    %rax,-0xe8(%rbp)
 1010a56:	48 8d 95 20 ff ff ff 	lea    -0xe0(%rbp),%rdx
 1010a5d:	48 8d b5 18 ff ff ff 	lea    -0xe8(%rbp),%rsi
 1010a64:	e8 87 e4 00 00       	call   101eef0 <myl_native_dictionary_read>
 1010a69:	4c 89 ff             	mov    %r15,%rdi
 1010a6c:	4c 8b 8d 50 ff ff ff 	mov    -0xb0(%rbp),%r9
 1010a73:	4c 8b 85 48 ff ff ff 	mov    -0xb8(%rbp),%r8
 1010a7a:	48 8b b5 40 ff ff ff 	mov    -0xc0(%rbp),%rsi
 1010a81:	83 f8 00             	cmp    $0x0,%eax
 1010a84:	0f 84 20 03 00 00    	je     1010daa <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1dca>
 1010a8a:	48 8b 85 20 ff ff ff 	mov    -0xe0(%rbp),%rax
 1010a91:	48 89 85 10 ff ff ff 	mov    %rax,-0xf0(%rbp)
 1010a98:	8b 85 20 fe ff ff    	mov    -0x1e0(%rbp),%eax
 1010a9e:	83 f8 00             	cmp    $0x0,%eax
 1010aa1:	74 1c                	je     1010abf <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1adf>
 1010aa3:	4c 89 c6             	mov    %r8,%rsi
 1010aa6:	49 89 ff             	mov    %rdi,%r15
 1010aa9:	e8 c2 5e 00 00       	call   1016970 <myl_qbe_rc_slot_drop>
 1010aae:	4c 89 ff             	mov    %r15,%rdi
 1010ab1:	4c 8b 8d 50 ff ff ff 	mov    -0xb0(%rbp),%r9
 1010ab8:	48 8b b5 40 ff ff ff 	mov    -0xc0(%rbp),%rsi
 1010abf:	8b 85 28 fe ff ff    	mov    -0x1d8(%rbp),%eax
 1010ac5:	83 f8 00             	cmp    $0x0,%eax
 1010ac8:	74 1c                	je     1010ae6 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1b06>
 1010aca:	4c 89 ce             	mov    %r9,%rsi
 1010acd:	49 89 ff             	mov    %rdi,%r15
 1010ad0:	e8 9b 5e 00 00       	call   1016970 <myl_qbe_rc_slot_drop>
 1010ad5:	4c 89 ff             	mov    %r15,%rdi
 1010ad8:	4c 8b 8d 50 ff ff ff 	mov    -0xb0(%rbp),%r9
 1010adf:	48 8b b5 40 ff ff ff 	mov    -0xc0(%rbp),%rsi
 1010ae6:	48 8b 85 00 ff ff ff 	mov    -0x100(%rbp),%rax
 1010aed:	48 89 85 18 ff ff ff 	mov    %rax,-0xe8(%rbp)
 1010af4:	48 8b 00             	mov    (%rax),%rax
 1010af7:	48 89 85 18 ff ff ff 	mov    %rax,-0xe8(%rbp)
 1010afe:	8b 85 28 fe ff ff    	mov    -0x1d8(%rbp),%eax
 1010b04:	83 f8 00             	cmp    $0x0,%eax
 1010b07:	74 15                	je     1010b1e <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1b3e>
 1010b09:	4c 89 ce             	mov    %r9,%rsi
 1010b0c:	49 89 ff             	mov    %rdi,%r15
 1010b0f:	e8 5c 5e 00 00       	call   1016970 <myl_qbe_rc_slot_drop>
 1010b14:	4c 89 ff             	mov    %r15,%rdi
 1010b17:	48 8b b5 40 ff ff ff 	mov    -0xc0(%rbp),%rsi
 1010b1e:	48 8b 85 18 ff ff ff 	mov    -0xe8(%rbp),%rax
 1010b25:	48 8b 95 10 ff ff ff 	mov    -0xf0(%rbp),%rdx
 1010b2c:	48 89 c1             	mov    %rax,%rcx
 1010b2f:	48 0f af ca          	imul   %rdx,%rcx
 1010b33:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
 1010b39:	49 89 d1             	mov    %rdx,%r9
 1010b3c:	4d 21 c1             	and    %r8,%r9
 1010b3f:	49 89 d2             	mov    %rdx,%r10
 1010b42:	49 c1 ea 20          	shr    $0x20,%r10
 1010b46:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
 1010b4c:	49 89 c3             	mov    %rax,%r11
 1010b4f:	4d 21 c3             	and    %r8,%r11
 1010b52:	49 89 c7             	mov    %rax,%r15
 1010b55:	49 c1 ef 20          	shr    $0x20,%r15
 1010b59:	4d 89 c8             	mov    %r9,%r8
 1010b5c:	4d 0f af c3          	imul   %r11,%r8
 1010b60:	49 c1 e8 20          	shr    $0x20,%r8
 1010b64:	4d 0f af da          	imul   %r10,%r11
 1010b68:	4d 01 d8             	add    %r11,%r8
 1010b6b:	41 bb ff ff ff ff    	mov    $0xffffffff,%r11d
 1010b71:	4c 89 5d 88          	mov    %r11,-0x78(%rbp)
 1010b75:	4d 89 c3             	mov    %r8,%r11
 1010b78:	4c 23 5d 88          	and    -0x78(%rbp),%r11
 1010b7c:	4c 89 9d 78 ff ff ff 	mov    %r11,-0x88(%rbp)
 1010b83:	4d 89 c3             	mov    %r8,%r11
 1010b86:	49 c1 eb 20          	shr    $0x20,%r11
 1010b8a:	4c 89 9d 68 ff ff ff 	mov    %r11,-0x98(%rbp)
 1010b91:	4c 8b 85 48 ff ff ff 	mov    -0xb8(%rbp),%r8
 1010b98:	4d 0f af cf          	imul   %r15,%r9
 1010b9c:	4c 89 4d 80          	mov    %r9,-0x80(%rbp)
 1010ba0:	4c 8b 8d 50 ff ff ff 	mov    -0xb0(%rbp),%r9
 1010ba7:	4c 8b 9d 78 ff ff ff 	mov    -0x88(%rbp),%r11
 1010bae:	4c 03 5d 80          	add    -0x80(%rbp),%r11
 1010bb2:	4c 89 9d 70 ff ff ff 	mov    %r11,-0x90(%rbp)
 1010bb9:	4c 8b 9d 70 ff ff ff 	mov    -0x90(%rbp),%r11
 1010bc0:	49 c1 eb 20          	shr    $0x20,%r11
 1010bc4:	4c 89 9d 60 ff ff ff 	mov    %r11,-0xa0(%rbp)
 1010bcb:	4c 8b 9d 68 ff ff ff 	mov    -0x98(%rbp),%r11
 1010bd2:	4d 0f af fa          	imul   %r10,%r15
 1010bd6:	4c 8b 95 60 ff ff ff 	mov    -0xa0(%rbp),%r10
 1010bdd:	4d 01 fb             	add    %r15,%r11
 1010be0:	4d 01 da             	add    %r11,%r10
 1010be3:	48 83 fa 00          	cmp    $0x0,%rdx
 1010be7:	41 0f 9c c3          	setl   %r11b
 1010beb:	4d 0f b6 db          	movzbq %r11b,%r11
 1010bef:	48 83 f8 00          	cmp    $0x0,%rax
 1010bf3:	41 0f 9c c7          	setl   %r15b
 1010bf7:	4d 0f b6 ff          	movzbq %r15b,%r15
 1010bfb:	49 f7 db             	neg    %r11
 1010bfe:	49 f7 df             	neg    %r15
 1010c01:	49 21 c3             	and    %rax,%r11
 1010c04:	49 21 d7             	and    %rdx,%r15
 1010c07:	49 f7 db             	neg    %r11
 1010c0a:	4d 01 d3             	add    %r10,%r11
 1010c0d:	4c 8b 95 58 ff ff ff 	mov    -0xa8(%rbp),%r10
 1010c14:	4d 29 fb             	sub    %r15,%r11
 1010c17:	49 89 cf             	mov    %rcx,%r15
 1010c1a:	49 c1 ff 3f          	sar    $0x3f,%r15
 1010c1e:	4d 39 df             	cmp    %r11,%r15
 1010c21:	0f 85 6e 01 00 00    	jne    1010d95 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1db5>
 1010c27:	48 89 8d 10 ff ff ff 	mov    %rcx,-0xf0(%rbp)
 1010c2e:	48 8b 95 08 ff ff ff 	mov    -0xf8(%rbp),%rdx
 1010c35:	48 89 c8             	mov    %rcx,%rax
 1010c38:	48 01 d0             	add    %rdx,%rax
 1010c3b:	49 89 d3             	mov    %rdx,%r11
 1010c3e:	49 31 c3             	xor    %rax,%r11
 1010c41:	49 89 cf             	mov    %rcx,%r15
 1010c44:	49 31 c7             	xor    %rax,%r15
 1010c47:	4d 21 fb             	and    %r15,%r11
 1010c4a:	49 83 fb 00          	cmp    $0x0,%r11
 1010c4e:	0f 8c 2f 01 00 00    	jl     1010d83 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1da3>
 1010c54:	48 89 85 08 ff ff ff 	mov    %rax,-0xf8(%rbp)
 1010c5b:	48 c7 85 10 ff ff ff 	movq   $0xf4243,-0xf0(%rbp)
 1010c62:	43 42 0f 00 
 1010c66:	48 b9 00 00 00 00 00 	movabs $0x8000000000000000,%rcx
 1010c6d:	00 00 80 
 1010c70:	48 39 c8             	cmp    %rcx,%rax
 1010c73:	0f 94 c1             	sete   %cl
 1010c76:	48 0f b6 c9          	movzbq %cl,%rcx
 1010c7a:	48 83 e1 00          	and    $0x0,%rcx
 1010c7e:	48 f7 d9             	neg    %rcx
 1010c81:	48 81 e1 42 42 0f 00 	and    $0xf4242,%rcx
 1010c88:	49 89 cb             	mov    %rcx,%r11
 1010c8b:	49 81 f3 43 42 0f 00 	xor    $0xf4243,%r11
 1010c92:	48 99                	cqto
 1010c94:	49 f7 fb             	idiv   %r11
 1010c97:	48 89 d1             	mov    %rdx,%rcx
 1010c9a:	48 83 f9 00          	cmp    $0x0,%rcx
 1010c9e:	0f 95 c0             	setne  %al
 1010ca1:	48 0f b6 c0          	movzbq %al,%rax
 1010ca5:	4c 89 da             	mov    %r11,%rdx
 1010ca8:	48 31 ca             	xor    %rcx,%rdx
 1010cab:	48 83 fa 00          	cmp    $0x0,%rdx
 1010caf:	0f 9c c2             	setl   %dl
 1010cb2:	48 0f b6 d2          	movzbq %dl,%rdx
 1010cb6:	48 21 d0             	and    %rdx,%rax
 1010cb9:	48 f7 d8             	neg    %rax
 1010cbc:	4c 21 d8             	and    %r11,%rax
 1010cbf:	48 01 c1             	add    %rax,%rcx
 1010cc2:	48 89 8d 38 ff ff ff 	mov    %rcx,-0xc8(%rbp)
 1010cc9:	48 89 8d 08 ff ff ff 	mov    %rcx,-0xf8(%rbp)
 1010cd0:	8b 85 10 fe ff ff    	mov    -0x1f0(%rbp),%eax
 1010cd6:	83 f8 00             	cmp    $0x0,%eax
 1010cd9:	74 2e                	je     1010d09 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1d29>
 1010cdb:	49 89 ff             	mov    %rdi,%r15
 1010cde:	e8 8d 5c 00 00       	call   1016970 <myl_qbe_rc_slot_drop>
 1010ce3:	4c 89 ff             	mov    %r15,%rdi
 1010ce6:	48 8b 8d 38 ff ff ff 	mov    -0xc8(%rbp),%rcx
 1010ced:	4c 8b 8d 50 ff ff ff 	mov    -0xb0(%rbp),%r9
 1010cf4:	4c 8b 85 48 ff ff ff 	mov    -0xb8(%rbp),%r8
 1010cfb:	4c 8b 95 58 ff ff ff 	mov    -0xa8(%rbp),%r10
 1010d02:	48 8b b5 40 ff ff ff 	mov    -0xc0(%rbp),%rsi
 1010d09:	4c 89 a5 08 ff ff ff 	mov    %r12,-0xf8(%rbp)
 1010d10:	48 8b 85 f8 fe ff ff 	mov    -0x108(%rbp),%rax
 1010d17:	48 8b 10             	mov    (%rax),%rdx
 1010d1a:	49 39 d4             	cmp    %rdx,%r12
 1010d1d:	75 5d                	jne    1010d7c <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1d9c>
 1010d1f:	48 c7 85 08 ff ff ff 	movq   $0x0,-0xf8(%rbp)
 1010d26:	00 00 00 00 
 1010d2a:	4c 89 b5 08 ff ff ff 	mov    %r14,-0xf8(%rbp)
 1010d31:	48 c7 85 10 ff ff ff 	movq   $0x1,-0xf0(%rbp)
 1010d38:	01 00 00 00 
 1010d3c:	48 ba fe ff ff ff ff 	movabs $0x7ffffffffffffffe,%rdx
 1010d43:	ff ff 7f 
 1010d46:	49 39 d6             	cmp    %rdx,%r14
 1010d49:	7f 14                	jg     1010d5f <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1d7f>
 1010d4b:	49 83 c6 01          	add    $0x1,%r14
 1010d4f:	4c 89 b5 08 ff ff ff 	mov    %r14,-0xf8(%rbp)
 1010d56:	48 89 4d 90          	mov    %rcx,-0x70(%rbp)
 1010d5a:	e9 b1 fa ff ff       	jmp    1010810 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1830>
 1010d5f:	4c 89 f6             	mov    %r14,%rsi
 1010d62:	41 b8 40 00 00 00    	mov    $0x40,%r8d
 1010d68:	b9 01 00 00 00       	mov    $0x1,%ecx
 1010d6d:	48 89 f2             	mov    %rsi,%rdx
 1010d70:	be 00 00 00 00       	mov    $0x0,%esi
 1010d75:	e8 86 62 00 00       	call   1017000 <myl_qbe_fail_overflow_op>
 1010d7a:	0f 0b                	ud2
 1010d7c:	e8 ff 61 00 00       	call   1016f80 <myl_qbe_fail_iteration>
 1010d81:	0f 0b                	ud2
 1010d83:	41 b8 40 00 00 00    	mov    $0x40,%r8d
 1010d89:	be 00 00 00 00       	mov    $0x0,%esi
 1010d8e:	e8 6d 62 00 00       	call   1017000 <myl_qbe_fail_overflow_op>
 1010d93:	0f 0b                	ud2
 1010d95:	48 89 c1             	mov    %rax,%rcx
 1010d98:	41 b8 40 00 00 00    	mov    $0x40,%r8d
 1010d9e:	be 02 00 00 00       	mov    $0x2,%esi
 1010da3:	e8 58 62 00 00       	call   1017000 <myl_qbe_fail_overflow_op>
 1010da8:	0f 0b                	ud2
 1010daa:	48 89 fb             	mov    %rdi,%rbx
 1010dad:	e8 be 61 00 00       	call   1016f70 <myl_qbe_fail_missing_key>
 1010db2:	0f 0b                	ud2
 1010db4:	48 87 fb             	xchg   %rdi,%rbx
 1010db7:	e8 54 2b 01 00       	call   1023910 <myl_rc_take_failure>
 1010dbc:	48 89 df             	mov    %rbx,%rdi
 1010dbf:	89 c6                	mov    %eax,%esi
 1010dc1:	48 89 fb             	mov    %rdi,%rbx
 1010dc4:	e8 d7 59 00 00       	call   10167a0 <myl_qbe_rc_status>
 1010dc9:	48 89 df             	mov    %rbx,%rdi
 1010dcc:	e9 ef 00 00 00       	jmp    1010ec0 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1ee0>
 1010dd1:	48 87 fb             	xchg   %rdi,%rbx
 1010dd4:	e8 37 2b 01 00       	call   1023910 <myl_rc_take_failure>
 1010dd9:	48 89 df             	mov    %rbx,%rdi
 1010ddc:	89 c6                	mov    %eax,%esi
 1010dde:	48 89 fb             	mov    %rdi,%rbx
 1010de1:	e8 ba 59 00 00       	call   10167a0 <myl_qbe_rc_status>
 1010de6:	48 89 df             	mov    %rbx,%rdi
 1010de9:	e9 d2 00 00 00       	jmp    1010ec0 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1ee0>
 1010dee:	48 89 ca             	mov    %rcx,%rdx
 1010df1:	4c 89 f6             	mov    %r14,%rsi
 1010df4:	e8 97 61 00 00       	call   1016f90 <myl_qbe_fail_normalized_index_bounds>
 1010df9:	0f 0b                	ud2
 1010dfb:	e8 80 61 00 00       	call   1016f80 <myl_qbe_fail_iteration>
 1010e00:	0f 0b                	ud2
 1010e02:	48 8b 4d 90          	mov    -0x70(%rbp),%rcx
 1010e06:	4c 8b a5 30 ff ff ff 	mov    -0xd0(%rbp),%r12
 1010e0d:	4c 89 a5 08 ff ff ff 	mov    %r12,-0xf8(%rbp)
 1010e14:	48 89 8d 10 ff ff ff 	mov    %rcx,-0xf0(%rbp)
 1010e1b:	4c 89 e6             	mov    %r12,%rsi
 1010e1e:	48 89 fb             	mov    %rdi,%rbx
 1010e21:	e8 1a 80 00 00       	call   1018e40 <myl_qbe_stream_begin>
 1010e26:	4c 89 e2             	mov    %r12,%rdx
 1010e29:	48 89 df             	mov    %rbx,%rdi
 1010e2c:	48 89 c6             	mov    %rax,%rsi
 1010e2f:	49 89 d5             	mov    %rdx,%r13
 1010e32:	ba 00 00 00 00       	mov    $0x0,%edx
 1010e37:	49 89 f4             	mov    %rsi,%r12
 1010e3a:	48 8d b5 10 ff ff ff 	lea    -0xf0(%rbp),%rsi
 1010e41:	48 89 fb             	mov    %rdi,%rbx
 1010e44:	4c 89 e7             	mov    %r12,%rdi
 1010e47:	e8 a4 00 00 00       	call   1010ef0 <myl_r_1a91deb3742283487d66c3b500f6effd7ef1170e6d4b4368fe9ec3c3f0354fda>
 1010e4c:	4c 89 e6             	mov    %r12,%rsi
 1010e4f:	48 89 df             	mov    %rbx,%rdi
 1010e52:	49 89 f4             	mov    %rsi,%r12
 1010e55:	be 0a 00 00 00       	mov    $0xa,%esi
 1010e5a:	48 89 fb             	mov    %rdi,%rbx
 1010e5d:	4c 89 e7             	mov    %r12,%rdi
 1010e60:	e8 2b 7f 00 00       	call   1018d90 <myl_qbe_print_byte>
 1010e65:	4c 89 ea             	mov    %r13,%rdx
 1010e68:	4c 89 e6             	mov    %r12,%rsi
 1010e6b:	48 89 df             	mov    %rbx,%rdi
 1010e6e:	48 89 fb             	mov    %rdi,%rbx
 1010e71:	e8 0a 80 00 00       	call   1018e80 <myl_qbe_stream_finish>
 1010e76:	48 89 df             	mov    %rbx,%rdi
 1010e79:	48 c7 85 08 ff ff ff 	movq   $0x0,-0xf8(%rbp)
 1010e80:	00 00 00 00 
 1010e84:	48 c7 85 08 ff ff ff 	movq   $0x0,-0xf8(%rbp)
 1010e8b:	00 00 00 00 
 1010e8f:	48 8d b5 18 fc ff ff 	lea    -0x3e8(%rbp),%rsi
 1010e96:	48 89 fb             	mov    %rdi,%rbx
 1010e99:	e8 02 5c 00 00       	call   1016aa0 <myl_qbe_rc_frame_cleanup>
 1010e9e:	48 89 df             	mov    %rbx,%rdi
 1010ea1:	48 8d b5 18 fc ff ff 	lea    -0x3e8(%rbp),%rsi
 1010ea8:	e8 63 5a 00 00       	call   1016910 <myl_qbe_rc_frame_leave>
 1010ead:	b8 00 00 00 00       	mov    $0x0,%eax
 1010eb2:	eb 2f                	jmp    1010ee3 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1f03>
 1010eb4:	ba 40 01 00 00       	mov    $0x140,%edx
 1010eb9:	e8 82 62 00 00       	call   1017140 <myl_qbe_fail_cast>
 1010ebe:	0f 0b                	ud2
 1010ec0:	48 8d b5 18 fc ff ff 	lea    -0x3e8(%rbp),%rsi
 1010ec7:	48 89 fb             	mov    %rdi,%rbx
 1010eca:	e8 d1 5b 00 00       	call   1016aa0 <myl_qbe_rc_frame_cleanup>
 1010ecf:	48 89 df             	mov    %rbx,%rdi
 1010ed2:	48 8d b5 18 fc ff ff 	lea    -0x3e8(%rbp),%rsi
 1010ed9:	e8 32 5a 00 00       	call   1016910 <myl_qbe_rc_frame_leave>
 1010ede:	b8 00 00 00 00       	mov    $0x0,%eax
 1010ee3:	41 5f                	pop    %r15
 1010ee5:	41 5e                	pop    %r14
 1010ee7:	41 5d                	pop    %r13
 1010ee9:	41 5c                	pop    %r12
 1010eeb:	5b                   	pop    %rbx
 1010eec:	c9                   	leave
 1010eed:	c3                   	ret

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
