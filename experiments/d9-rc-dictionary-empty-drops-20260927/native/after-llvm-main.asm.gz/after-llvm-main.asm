
.tmp-rc/dict-empty/after-llvm-rc:     file format elf64-x86-64


Disassembly of section .text:

00000000010184b0 <entry_run>:
 10184b0:	55                   	push   %rbp
 10184b1:	48 89 e5             	mov    %rsp,%rbp
 10184b4:	41 57                	push   %r15
 10184b6:	41 56                	push   %r14
 10184b8:	41 55                	push   %r13
 10184ba:	41 54                	push   %r12
 10184bc:	53                   	push   %rbx
 10184bd:	48 81 ec a8 03 00 00 	sub    $0x3a8,%rsp
 10184c4:	48 89 fb             	mov    %rdi,%rbx
 10184c7:	48 83 bf a0 38 00 00 	cmpq   $0x0,0x38a0(%rdi)
 10184ce:	00 
 10184cf:	74 10                	je     10184e1 <entry_run+0x31>
 10184d1:	48 83 7b 20 00       	cmpq   $0x0,0x20(%rbx)
 10184d6:	0f 85 c0 25 00 00    	jne    101aa9c <entry_run+0x25ec>
 10184dc:	e9 10 01 00 00       	jmp    10185f1 <entry_run+0x141>
 10184e1:	bf 01 00 00 00       	mov    $0x1,%edi
 10184e6:	be 40 00 00 00       	mov    $0x40,%esi
 10184eb:	e8 c0 9b 01 00       	call   10320b0 <calloc@plt>
 10184f0:	48 85 c0             	test   %rax,%rax
 10184f3:	0f 84 c7 00 00 00    	je     10185c0 <entry_run+0x110>
 10184f9:	48 89 83 a0 38 00 00 	mov    %rax,0x38a0(%rbx)
 1018500:	48 8b 8b 70 38 00 00 	mov    0x3870(%rbx),%rcx
 1018507:	48 8d 91 a0 00 00 00 	lea    0xa0(%rcx),%rdx
 101850e:	48 85 c9             	test   %rcx,%rcx
 1018511:	b9 c0 b2 00 01       	mov    $0x100b2c0,%ecx
 1018516:	48 0f 45 ca          	cmovne %rdx,%rcx
 101851a:	48 89 08             	mov    %rcx,(%rax)
 101851d:	48 83 79 08 00       	cmpq   $0x0,0x8(%rcx)
 1018522:	74 0a                	je     101852e <entry_run+0x7e>
 1018524:	48 83 39 00          	cmpq   $0x0,(%rcx)
 1018528:	0f 84 99 00 00 00    	je     10185c7 <entry_run+0x117>
 101852e:	48 8b 51 10          	mov    0x10(%rcx),%rdx
 1018532:	48 85 d2             	test   %rdx,%rdx
 1018535:	be 10 27 00 00       	mov    $0x2710,%esi
 101853a:	48 0f 45 f2          	cmovne %rdx,%rsi
 101853e:	48 89 70 18          	mov    %rsi,0x18(%rax)
 1018542:	48 8b 51 18          	mov    0x18(%rcx),%rdx
 1018546:	48 85 d2             	test   %rdx,%rdx
 1018549:	be 40 42 0f 00       	mov    $0xf4240,%esi
 101854e:	48 0f 45 f2          	cmovne %rdx,%rsi
 1018552:	48 89 70 10          	mov    %rsi,0x10(%rax)
 1018556:	48 8b 51 20          	mov    0x20(%rcx),%rdx
 101855a:	48 85 d2             	test   %rdx,%rdx
 101855d:	bf 00 00 01 00       	mov    $0x10000,%edi
 1018562:	48 0f 45 fa          	cmovne %rdx,%rdi
 1018566:	48 89 78 20          	mov    %rdi,0x20(%rax)
 101856a:	48 8b 71 28          	mov    0x28(%rcx),%rsi
 101856e:	48 85 f6             	test   %rsi,%rsi
 1018571:	ba 40 00 00 00       	mov    $0x40,%edx
 1018576:	48 0f 45 d6          	cmovne %rsi,%rdx
 101857a:	48 89 50 28          	mov    %rdx,0x28(%rax)
 101857e:	4c 8b 41 30          	mov    0x30(%rcx),%r8
 1018582:	4d 85 c0             	test   %r8,%r8
 1018585:	be 00 00 10 00       	mov    $0x100000,%esi
 101858a:	49 0f 45 f0          	cmovne %r8,%rsi
 101858e:	48 89 70 30          	mov    %rsi,0x30(%rax)
 1018592:	48 81 ff a0 86 01 00 	cmp    $0x186a0,%rdi
 1018599:	77 1e                	ja     10185b9 <entry_run+0x109>
 101859b:	48 81 fa 81 00 00 00 	cmp    $0x81,%rdx
 10185a2:	0f 93 c2             	setae  %dl
 10185a5:	48 81 fe 01 00 00 04 	cmp    $0x4000001,%rsi
 10185ac:	40 0f 93 c6          	setae  %sil
 10185b0:	40 08 d6             	or     %dl,%sil
 10185b3:	40 80 fe 01          	cmp    $0x1,%sil
 10185b7:	75 15                	jne    10185ce <entry_run+0x11e>
 10185b9:	be 4f 6e 00 01       	mov    $0x1006e4f,%esi
 10185be:	eb 1e                	jmp    10185de <entry_run+0x12e>
 10185c0:	be fa 6c 00 01       	mov    $0x1006cfa,%esi
 10185c5:	eb 17                	jmp    10185de <entry_run+0x12e>
 10185c7:	be a0 6f 00 01       	mov    $0x1006fa0,%esi
 10185cc:	eb 10                	jmp    10185de <entry_run+0x12e>
 10185ce:	48 83 79 08 00       	cmpq   $0x0,0x8(%rcx)
 10185d3:	0f 84 5c 20 00 00    	je     101a635 <entry_run+0x2185>
 10185d9:	be 8c 6f 00 01       	mov    $0x1006f8c,%esi
 10185de:	48 89 df             	mov    %rbx,%rdi
 10185e1:	e8 5a 2f 00 00       	call   101b540 <fail>
 10185e6:	48 83 7b 20 00       	cmpq   $0x0,0x20(%rbx)
 10185eb:	0f 85 ab 24 00 00    	jne    101aa9c <entry_run+0x25ec>
 10185f1:	48 c7 85 18 fd ff ff 	movq   $0x0,-0x2e8(%rbp)
 10185f8:	00 00 00 00 
 10185fc:	48 c7 45 a0 00 00 00 	movq   $0x0,-0x60(%rbp)
 1018603:	00 
 1018604:	48 c7 45 98 00 00 00 	movq   $0x0,-0x68(%rbp)
 101860b:	00 
 101860c:	48 c7 85 20 fd ff ff 	movq   $0x0,-0x2e0(%rbp)
 1018613:	00 00 00 00 
 1018617:	48 c7 85 e8 fe ff ff 	movq   $0x0,-0x118(%rbp)
 101861e:	00 00 00 00 
 1018622:	48 c7 85 28 fd ff ff 	movq   $0x0,-0x2d8(%rbp)
 1018629:	00 00 00 00 
 101862d:	48 c7 85 10 ff ff ff 	movq   $0x0,-0xf0(%rbp)
 1018634:	00 00 00 00 
 1018638:	48 c7 85 18 ff ff ff 	movq   $0x0,-0xe8(%rbp)
 101863f:	00 00 00 00 
 1018643:	8b 83 c8 02 00 00    	mov    0x2c8(%rbx),%eax
 1018649:	89 45 b8             	mov    %eax,-0x48(%rbp)
 101864c:	48 8d 95 70 ff ff ff 	lea    -0x90(%rbp),%rdx
 1018653:	48 8d 85 50 ff ff ff 	lea    -0xb0(%rbp),%rax
 101865a:	48 c7 85 30 fd ff ff 	movq   $0x1009fd0,-0x2d0(%rbp)
 1018661:	d0 9f 00 01 
 1018665:	c7 85 48 fd ff ff 02 	movl   $0x2,-0x2b8(%rbp)
 101866c:	00 00 00 
 101866f:	4c 8d b5 18 fd ff ff 	lea    -0x2e8(%rbp),%r14
 1018676:	4c 89 b5 38 fd ff ff 	mov    %r14,-0x2c8(%rbp)
 101867d:	4c 8d a5 30 ff ff ff 	lea    -0xd0(%rbp),%r12
 1018684:	4c 89 a5 40 fd ff ff 	mov    %r12,-0x2c0(%rbp)
 101868b:	48 c7 85 50 fd ff ff 	movq   $0x1009fd0,-0x2b0(%rbp)
 1018692:	d0 9f 00 01 
 1018696:	c7 85 68 fd ff ff 02 	movl   $0x2,-0x298(%rbp)
 101869d:	00 00 00 
 10186a0:	48 8d 4d a0          	lea    -0x60(%rbp),%rcx
 10186a4:	48 89 8d 58 fd ff ff 	mov    %rcx,-0x2a8(%rbp)
 10186ab:	48 8d 8d 38 ff ff ff 	lea    -0xc8(%rbp),%rcx
 10186b2:	48 89 8d 60 fd ff ff 	mov    %rcx,-0x2a0(%rbp)
 10186b9:	48 c7 85 70 fd ff ff 	movq   $0x100a7b0,-0x290(%rbp)
 10186c0:	b0 a7 00 01 
 10186c4:	c7 85 88 fd ff ff 02 	movl   $0x2,-0x278(%rbp)
 10186cb:	00 00 00 
 10186ce:	48 8d 4d 98          	lea    -0x68(%rbp),%rcx
 10186d2:	48 89 8d 78 fd ff ff 	mov    %rcx,-0x288(%rbp)
 10186d9:	48 8d 8d 40 ff ff ff 	lea    -0xc0(%rbp),%rcx
 10186e0:	48 89 8d 80 fd ff ff 	mov    %rcx,-0x280(%rbp)
 10186e7:	48 c7 85 90 fd ff ff 	movq   $0x1009fd0,-0x270(%rbp)
 10186ee:	d0 9f 00 01 
 10186f2:	c7 85 a8 fd ff ff 02 	movl   $0x2,-0x258(%rbp)
 10186f9:	00 00 00 
 10186fc:	48 8d 8d 20 fd ff ff 	lea    -0x2e0(%rbp),%rcx
 1018703:	48 89 8d 98 fd ff ff 	mov    %rcx,-0x268(%rbp)
 101870a:	48 8d 8d 48 ff ff ff 	lea    -0xb8(%rbp),%rcx
 1018711:	48 89 8d a0 fd ff ff 	mov    %rcx,-0x260(%rbp)
 1018718:	48 c7 85 b0 fd ff ff 	movq   $0x1009f60,-0x250(%rbp)
 101871f:	60 9f 00 01 
 1018723:	c7 85 c8 fd ff ff 02 	movl   $0x2,-0x238(%rbp)
 101872a:	00 00 00 
 101872d:	48 8d 8d e8 fe ff ff 	lea    -0x118(%rbp),%rcx
 1018734:	48 89 8d b8 fd ff ff 	mov    %rcx,-0x248(%rbp)
 101873b:	48 89 85 c0 fd ff ff 	mov    %rax,-0x240(%rbp)
 1018742:	48 c7 85 d0 fd ff ff 	movq   $0x100a7b0,-0x230(%rbp)
 1018749:	b0 a7 00 01 
 101874d:	c7 85 e8 fd ff ff 02 	movl   $0x2,-0x218(%rbp)
 1018754:	00 00 00 
 1018757:	48 8d 85 28 fd ff ff 	lea    -0x2d8(%rbp),%rax
 101875e:	48 89 85 d8 fd ff ff 	mov    %rax,-0x228(%rbp)
 1018765:	48 8d 85 58 ff ff ff 	lea    -0xa8(%rbp),%rax
 101876c:	48 89 85 e0 fd ff ff 	mov    %rax,-0x220(%rbp)
 1018773:	48 c7 85 f0 fd ff ff 	movq   $0x1009fd0,-0x210(%rbp)
 101877a:	d0 9f 00 01 
 101877e:	c7 85 08 fe ff ff 02 	movl   $0x2,-0x1f8(%rbp)
 1018785:	00 00 00 
 1018788:	48 8d 85 10 ff ff ff 	lea    -0xf0(%rbp),%rax
 101878f:	48 89 85 f8 fd ff ff 	mov    %rax,-0x208(%rbp)
 1018796:	48 8d 85 60 ff ff ff 	lea    -0xa0(%rbp),%rax
 101879d:	48 89 85 00 fe ff ff 	mov    %rax,-0x200(%rbp)
 10187a4:	48 c7 85 10 fe ff ff 	movq   $0x1009f60,-0x1f0(%rbp)
 10187ab:	60 9f 00 01 
 10187af:	c7 85 28 fe ff ff 02 	movl   $0x2,-0x1d8(%rbp)
 10187b6:	00 00 00 
 10187b9:	48 8d 85 18 ff ff ff 	lea    -0xe8(%rbp),%rax
 10187c0:	48 89 85 18 fe ff ff 	mov    %rax,-0x1e8(%rbp)
 10187c7:	48 8d 85 68 ff ff ff 	lea    -0x98(%rbp),%rax
 10187ce:	48 89 85 20 fe ff ff 	mov    %rax,-0x1e0(%rbp)
 10187d5:	48 c7 85 30 fe ff ff 	movq   $0x100a190,-0x1d0(%rbp)
 10187dc:	90 a1 00 01 
 10187e0:	c7 85 48 fe ff ff 00 	movl   $0x0,-0x1b8(%rbp)
 10187e7:	00 00 00 
 10187ea:	48 8d 45 a8          	lea    -0x58(%rbp),%rax
 10187ee:	48 89 85 38 fe ff ff 	mov    %rax,-0x1c8(%rbp)
 10187f5:	48 89 95 40 fe ff ff 	mov    %rdx,-0x1c0(%rbp)
 10187fc:	48 c7 85 50 fe ff ff 	movq   $0x100a190,-0x1b0(%rbp)
 1018803:	90 a1 00 01 
 1018807:	c7 85 68 fe ff ff 00 	movl   $0x0,-0x198(%rbp)
 101880e:	00 00 00 
 1018811:	48 8d 85 c8 fc ff ff 	lea    -0x338(%rbp),%rax
 1018818:	48 89 85 58 fe ff ff 	mov    %rax,-0x1a8(%rbp)
 101881f:	48 8d 85 78 ff ff ff 	lea    -0x88(%rbp),%rax
 1018826:	48 89 85 60 fe ff ff 	mov    %rax,-0x1a0(%rbp)
 101882d:	48 c7 85 70 fe ff ff 	movq   $0x100a190,-0x190(%rbp)
 1018834:	90 a1 00 01 
 1018838:	c7 85 88 fe ff ff 00 	movl   $0x0,-0x178(%rbp)
 101883f:	00 00 00 
 1018842:	48 8d 85 38 fc ff ff 	lea    -0x3c8(%rbp),%rax
 1018849:	48 89 85 78 fe ff ff 	mov    %rax,-0x188(%rbp)
 1018850:	48 8d 45 80          	lea    -0x80(%rbp),%rax
 1018854:	48 89 85 80 fe ff ff 	mov    %rax,-0x180(%rbp)
 101885b:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
 101885f:	c5 fc 11 85 70 ff ff 	vmovups %ymm0,-0x90(%rbp)
 1018866:	ff 
 1018867:	c5 fc 11 85 50 ff ff 	vmovups %ymm0,-0xb0(%rbp)
 101886e:	ff 
 101886f:	c5 fc 11 85 30 ff ff 	vmovups %ymm0,-0xd0(%rbp)
 1018876:	ff 
 1018877:	48 c7 45 90 00 00 00 	movq   $0x0,-0x70(%rbp)
 101887e:	00 
 101887f:	48 c7 85 90 fe ff ff 	movq   $0x100a190,-0x170(%rbp)
 1018886:	90 a1 00 01 
 101888a:	c7 85 a8 fe ff ff 00 	movl   $0x0,-0x158(%rbp)
 1018891:	00 00 00 
 1018894:	48 8d 45 c8          	lea    -0x38(%rbp),%rax
 1018898:	48 89 85 98 fe ff ff 	mov    %rax,-0x168(%rbp)
 101889f:	48 8d 45 88          	lea    -0x78(%rbp),%rax
 10188a3:	48 89 85 a0 fe ff ff 	mov    %rax,-0x160(%rbp)
 10188aa:	48 c7 85 b0 fe ff ff 	movq   $0x100a190,-0x150(%rbp)
 10188b1:	90 a1 00 01 
 10188b5:	c7 85 c8 fe ff ff 00 	movl   $0x0,-0x138(%rbp)
 10188bc:	00 00 00 
 10188bf:	48 8d 85 10 fd ff ff 	lea    -0x2f0(%rbp),%rax
 10188c6:	48 89 85 b8 fe ff ff 	mov    %rax,-0x148(%rbp)
 10188cd:	48 8d 45 90          	lea    -0x70(%rbp),%rax
 10188d1:	48 89 85 c0 fe ff ff 	mov    %rax,-0x140(%rbp)
 10188d8:	48 8b 83 60 18 00 00 	mov    0x1860(%rbx),%rax
 10188df:	48 85 c0             	test   %rax,%rax
 10188e2:	0f 84 d3 21 00 00    	je     101aabb <entry_run+0x260b>
 10188e8:	48 8b 8b 80 3d 00 00 	mov    0x3d80(%rbx),%rcx
 10188ef:	48 8b 40 70          	mov    0x70(%rax),%rax
 10188f3:	48 89 8d f0 fe ff ff 	mov    %rcx,-0x110(%rbp)
 10188fa:	48 8d 8d 30 fd ff ff 	lea    -0x2d0(%rbp),%rcx
 1018901:	48 89 8d f8 fe ff ff 	mov    %rcx,-0x108(%rbp)
 1018908:	48 c7 85 00 ff ff ff 	movq   $0xd,-0x100(%rbp)
 101890f:	0d 00 00 00 
 1018913:	48 89 85 08 ff ff ff 	mov    %rax,-0xf8(%rbp)
 101891a:	48 8d 85 f0 fe ff ff 	lea    -0x110(%rbp),%rax
 1018921:	48 89 83 80 3d 00 00 	mov    %rax,0x3d80(%rbx)
 1018928:	48 83 7b 10 ff       	cmpq   $0xffffffffffffffff,0x10(%rbx)
 101892d:	74 3c                	je     101896b <entry_run+0x4bb>
 101892f:	48 83 7b 20 00       	cmpq   $0x0,0x20(%rbx)
 1018934:	75 25                	jne    101895b <entry_run+0x4ab>
 1018936:	c7 83 e0 38 00 00 01 	movl   $0x1,0x38e0(%rbx)
 101893d:	00 00 00 
 1018940:	c5 fc 11 83 e4 38 00 	vmovups %ymm0,0x38e4(%rbx)
 1018947:	00 
 1018948:	c5 fc 11 83 f0 38 00 	vmovups %ymm0,0x38f0(%rbx)
 101894f:	00 
 1018950:	48 c7 83 10 39 00 00 	movq   $0x1007097,0x3910(%rbx)
 1018957:	97 70 00 01 
 101895b:	be 39 75 00 01       	mov    $0x1007539,%esi
 1018960:	48 89 df             	mov    %rbx,%rdi
 1018963:	c5 f8 77             	vzeroupper
 1018966:	e8 d5 2b 00 00       	call   101b540 <fail>
 101896b:	4c 8d ab 58 02 00 00 	lea    0x258(%rbx),%r13
 1018972:	48 83 7b 38 ff       	cmpq   $0xffffffffffffffff,0x38(%rbx)
 1018977:	74 40                	je     10189b9 <entry_run+0x509>
 1018979:	48 83 7b 20 00       	cmpq   $0x0,0x20(%rbx)
 101897e:	75 29                	jne    10189a9 <entry_run+0x4f9>
 1018980:	c7 83 e0 38 00 00 01 	movl   $0x1,0x38e0(%rbx)
 1018987:	00 00 00 
 101898a:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
 101898e:	c5 fc 11 83 e4 38 00 	vmovups %ymm0,0x38e4(%rbx)
 1018995:	00 
 1018996:	c5 fc 11 83 f0 38 00 	vmovups %ymm0,0x38f0(%rbx)
 101899d:	00 
 101899e:	48 c7 83 10 39 00 00 	movq   $0x10070e0,0x3910(%rbx)
 10189a5:	e0 70 00 01 
 10189a9:	be 4e 75 00 01       	mov    $0x100754e,%esi
 10189ae:	48 89 df             	mov    %rbx,%rdi
 10189b1:	c5 f8 77             	vzeroupper
 10189b4:	e8 87 2b 00 00       	call   101b540 <fail>
 10189b9:	48 c7 45 d0 00 00 00 	movq   $0x0,-0x30(%rbp)
 10189c0:	00 
 10189c1:	be 60 9f 00 01       	mov    $0x1009f60,%esi
 10189c6:	4c 89 ef             	mov    %r13,%rdi
 10189c9:	c5 f8 77             	vzeroupper
 10189cc:	e8 bf 6c 00 00       	call   101f690 <myl_native_list_new>
 10189d1:	48 85 c0             	test   %rax,%rax
 10189d4:	0f 84 27 21 00 00    	je     101ab01 <entry_run+0x2651>
 10189da:	48 b9 01 00 00 00 00 	movabs $0x5000000000000001,%rcx
 10189e1:	00 00 50 
 10189e4:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
 10189e8:	48 c7 85 90 fe ff ff 	movq   $0x1009fd0,-0x170(%rbp)
 10189ef:	d0 9f 00 01 
 10189f3:	c7 85 a8 fe ff ff 02 	movl   $0x2,-0x158(%rbp)
 10189fa:	00 00 00 
 10189fd:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
 1018a01:	48 c7 85 30 fe ff ff 	movq   $0x1009fd0,-0x1d0(%rbp)
 1018a08:	d0 9f 00 01 
 1018a0c:	c7 85 48 fe ff ff 02 	movl   $0x2,-0x1b8(%rbp)
 1018a13:	00 00 00 
 1018a16:	c7 45 88 00 00 00 00 	movl   $0x0,-0x78(%rbp)
 1018a1d:	c7 85 70 ff ff ff 01 	movl   $0x1,-0x90(%rbp)
 1018a24:	00 00 00 
 1018a27:	48 89 45 d0          	mov    %rax,-0x30(%rbp)
 1018a2b:	48 85 48 f0          	test   %rcx,-0x10(%rax)
 1018a2f:	74 22                	je     1018a53 <entry_run+0x5a3>
 1018a31:	48 8d 55 c8          	lea    -0x38(%rbp),%rdx
 1018a35:	48 8d 4d d0          	lea    -0x30(%rbp),%rcx
 1018a39:	be d0 9f 00 01       	mov    $0x1009fd0,%esi
 1018a3e:	4c 89 ef             	mov    %r13,%rdi
 1018a41:	44 8b 45 b8          	mov    -0x48(%rbp),%r8d
 1018a45:	e8 76 51 01 00       	call   102dbc0 <myl_rc_native_take>
 1018a4a:	85 c0                	test   %eax,%eax
 1018a4c:	75 0d                	jne    1018a5b <entry_run+0x5ab>
 1018a4e:	e9 d9 07 00 00       	jmp    101922c <entry_run+0xd7c>
 1018a53:	48 c7 45 d0 00 00 00 	movq   $0x0,-0x30(%rbp)
 1018a5a:	00 
 1018a5b:	c7 85 70 ff ff ff 00 	movl   $0x0,-0x90(%rbp)
 1018a62:	00 00 00 
 1018a65:	48 c7 85 90 fe ff ff 	movq   $0x1009fd0,-0x170(%rbp)
 1018a6c:	d0 9f 00 01 
 1018a70:	c7 85 a8 fe ff ff 02 	movl   $0x2,-0x158(%rbp)
 1018a77:	00 00 00 
 1018a7a:	c7 45 88 01 00 00 00 	movl   $0x1,-0x78(%rbp)
 1018a81:	83 bd 30 ff ff ff 00 	cmpl   $0x0,-0xd0(%rbp)
 1018a88:	74 17                	je     1018aa1 <entry_run+0x5f1>
 1018a8a:	48 8d b5 30 fd ff ff 	lea    -0x2d0(%rbp),%rsi
 1018a91:	48 89 df             	mov    %rbx,%rdi
 1018a94:	e8 17 21 00 00       	call   101abb0 <myl_qbe_rc_slot_drop>
 1018a99:	8b 8d a8 fe ff ff    	mov    -0x158(%rbp),%ecx
 1018a9f:	eb 05                	jmp    1018aa6 <entry_run+0x5f6>
 1018aa1:	b9 02 00 00 00       	mov    $0x2,%ecx
 1018aa6:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
 1018aaa:	48 89 85 18 fd ff ff 	mov    %rax,-0x2e8(%rbp)
 1018ab1:	c7 45 88 00 00 00 00 	movl   $0x0,-0x78(%rbp)
 1018ab8:	48 c7 85 30 fd ff ff 	movq   $0x1009fd0,-0x2d0(%rbp)
 1018abf:	d0 9f 00 01 
 1018ac3:	4c 89 b5 38 fd ff ff 	mov    %r14,-0x2c8(%rbp)
 1018aca:	4c 89 a5 40 fd ff ff 	mov    %r12,-0x2c0(%rbp)
 1018ad1:	89 8d 48 fd ff ff    	mov    %ecx,-0x2b8(%rbp)
 1018ad7:	c7 85 30 ff ff ff 01 	movl   $0x1,-0xd0(%rbp)
 1018ade:	00 00 00 
 1018ae1:	83 f9 08             	cmp    $0x8,%ecx
 1018ae4:	0f 85 d1 00 00 00    	jne    1018bbb <entry_run+0x70b>
 1018aea:	48 c7 45 c8 00 00 00 	movq   $0x0,-0x38(%rbp)
 1018af1:	00 
 1018af2:	48 85 c0             	test   %rax,%rax
 1018af5:	74 4c                	je     1018b43 <entry_run+0x693>
 1018af7:	48 8b 48 f0          	mov    -0x10(%rax),%rcx
 1018afb:	48 ba 02 00 00 00 00 	movabs $0x4000000000000002,%rdx
 1018b02:	00 00 40 
 1018b05:	48 85 d1             	test   %rdx,%rcx
 1018b08:	75 39                	jne    1018b43 <entry_run+0x693>
 1018b0a:	48 83 bb 60 18 00 00 	cmpq   $0x0,0x1860(%rbx)
 1018b11:	00 
 1018b12:	0f 84 a3 1f 00 00    	je     101aabb <entry_run+0x260b>
 1018b18:	f6 c1 01             	test   $0x1,%cl
 1018b1b:	0f 85 9a 1f 00 00    	jne    101aabb <entry_run+0x260b>
 1018b21:	48 8b 48 e8          	mov    -0x18(%rax),%rcx
 1018b25:	48 8b 50 e0          	mov    -0x20(%rax),%rdx
 1018b29:	48 09 ca             	or     %rcx,%rdx
 1018b2c:	0f 84 89 1f 00 00    	je     101aabb <entry_run+0x260b>
 1018b32:	48 83 f9 ff          	cmp    $0xffffffffffffffff,%rcx
 1018b36:	0f 84 ef 1a 00 00    	je     101a62b <entry_run+0x217b>
 1018b3c:	48 ff c1             	inc    %rcx
 1018b3f:	48 89 48 e8          	mov    %rcx,-0x18(%rax)
 1018b43:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
 1018b47:	48 c7 85 90 fe ff ff 	movq   $0x1009fd0,-0x170(%rbp)
 1018b4e:	d0 9f 00 01 
 1018b52:	48 8d 4d c8          	lea    -0x38(%rbp),%rcx
 1018b56:	48 89 8d 98 fe ff ff 	mov    %rcx,-0x168(%rbp)
 1018b5d:	48 8d 4d 88          	lea    -0x78(%rbp),%rcx
 1018b61:	48 89 8d a0 fe ff ff 	mov    %rcx,-0x160(%rbp)
 1018b68:	c7 85 a8 fe ff ff 08 	movl   $0x8,-0x158(%rbp)
 1018b6f:	00 00 00 
 1018b72:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
 1018b76:	48 c7 85 30 fe ff ff 	movq   $0x1009fd0,-0x1d0(%rbp)
 1018b7d:	d0 9f 00 01 
 1018b81:	48 8d 4d a8          	lea    -0x58(%rbp),%rcx
 1018b85:	48 89 8d 38 fe ff ff 	mov    %rcx,-0x1c8(%rbp)
 1018b8c:	48 8d 8d 70 ff ff ff 	lea    -0x90(%rbp),%rcx
 1018b93:	48 89 8d 40 fe ff ff 	mov    %rcx,-0x1c0(%rbp)
 1018b9a:	c7 85 48 fe ff ff 08 	movl   $0x8,-0x1b8(%rbp)
 1018ba1:	00 00 00 
 1018ba4:	c7 85 70 ff ff ff 01 	movl   $0x1,-0x90(%rbp)
 1018bab:	00 00 00 
 1018bae:	c7 45 88 00 00 00 00 	movl   $0x0,-0x78(%rbp)
 1018bb5:	48 89 45 d0          	mov    %rax,-0x30(%rbp)
 1018bb9:	eb 5b                	jmp    1018c16 <entry_run+0x766>
 1018bbb:	8b 8d 70 ff ff ff    	mov    -0x90(%rbp),%ecx
 1018bc1:	f6 85 48 fe ff ff 18 	testb  $0x18,-0x1b8(%rbp)
 1018bc8:	48 89 45 d0          	mov    %rax,-0x30(%rbp)
 1018bcc:	75 48                	jne    1018c16 <entry_run+0x766>
 1018bce:	83 e1 01             	and    $0x1,%ecx
 1018bd1:	74 43                	je     1018c16 <entry_run+0x766>
 1018bd3:	48 85 c0             	test   %rax,%rax
 1018bd6:	0f 84 14 07 00 00    	je     10192f0 <entry_run+0xe40>
 1018bdc:	48 b9 01 00 00 00 00 	movabs $0x5000000000000001,%rcx
 1018be3:	00 00 50 
 1018be6:	48 85 48 f0          	test   %rcx,-0x10(%rax)
 1018bea:	0f 84 00 07 00 00    	je     10192f0 <entry_run+0xe40>
 1018bf0:	48 8d 55 c8          	lea    -0x38(%rbp),%rdx
 1018bf4:	48 8d 4d d0          	lea    -0x30(%rbp),%rcx
 1018bf8:	be d0 9f 00 01       	mov    $0x1009fd0,%esi
 1018bfd:	4c 89 ef             	mov    %r13,%rdi
 1018c00:	44 8b 45 b8          	mov    -0x48(%rbp),%r8d
 1018c04:	e8 b7 4f 01 00       	call   102dbc0 <myl_rc_native_take>
 1018c09:	85 c0                	test   %eax,%eax
 1018c0b:	0f 85 eb 06 00 00    	jne    10192fc <entry_run+0xe4c>
 1018c11:	e9 16 06 00 00       	jmp    101922c <entry_run+0xd7c>
 1018c16:	48 8d 55 c8          	lea    -0x38(%rbp),%rdx
 1018c1a:	48 8d 4d d0          	lea    -0x30(%rbp),%rcx
 1018c1e:	be d0 9f 00 01       	mov    $0x1009fd0,%esi
 1018c23:	4c 89 ef             	mov    %r13,%rdi
 1018c26:	44 8b 45 b8          	mov    -0x48(%rbp),%r8d
 1018c2a:	e8 81 5c 01 00       	call   102e8b0 <myl_rc_native_retain>
 1018c2f:	85 c0                	test   %eax,%eax
 1018c31:	0f 84 f5 05 00 00    	je     101922c <entry_run+0xd7c>
 1018c37:	48 c7 85 90 fe ff ff 	movq   $0x1009fd0,-0x170(%rbp)
 1018c3e:	d0 9f 00 01 
 1018c42:	c7 85 a8 fe ff ff 02 	movl   $0x2,-0x158(%rbp)
 1018c49:	00 00 00 
 1018c4c:	c7 45 88 01 00 00 00 	movl   $0x1,-0x78(%rbp)
 1018c53:	83 bd 70 ff ff ff 00 	cmpl   $0x0,-0x90(%rbp)
 1018c5a:	74 0f                	je     1018c6b <entry_run+0x7bb>
 1018c5c:	48 89 df             	mov    %rbx,%rdi
 1018c5f:	48 8d b5 30 fe ff ff 	lea    -0x1d0(%rbp),%rsi
 1018c66:	e8 45 1f 00 00       	call   101abb0 <myl_qbe_rc_slot_drop>
 1018c6b:	83 bd 38 ff ff ff 00 	cmpl   $0x0,-0xc8(%rbp)
 1018c72:	74 0f                	je     1018c83 <entry_run+0x7d3>
 1018c74:	48 8d b5 50 fd ff ff 	lea    -0x2b0(%rbp),%rsi
 1018c7b:	48 89 df             	mov    %rbx,%rdi
 1018c7e:	e8 2d 1f 00 00       	call   101abb0 <myl_qbe_rc_slot_drop>
 1018c83:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
 1018c87:	48 89 45 a0          	mov    %rax,-0x60(%rbp)
 1018c8b:	c7 45 88 00 00 00 00 	movl   $0x0,-0x78(%rbp)
 1018c92:	48 c7 85 50 fd ff ff 	movq   $0x1009fd0,-0x2b0(%rbp)
 1018c99:	d0 9f 00 01 
 1018c9d:	48 8d 45 a0          	lea    -0x60(%rbp),%rax
 1018ca1:	48 89 85 58 fd ff ff 	mov    %rax,-0x2a8(%rbp)
 1018ca8:	48 8d 85 38 ff ff ff 	lea    -0xc8(%rbp),%rax
 1018caf:	48 89 85 60 fd ff ff 	mov    %rax,-0x2a0(%rbp)
 1018cb6:	8b 85 a8 fe ff ff    	mov    -0x158(%rbp),%eax
 1018cbc:	89 85 68 fd ff ff    	mov    %eax,-0x298(%rbp)
 1018cc2:	c7 85 38 ff ff ff 01 	movl   $0x1,-0xc8(%rbp)
 1018cc9:	00 00 00 
 1018ccc:	83 bd 30 ff ff ff 00 	cmpl   $0x0,-0xd0(%rbp)
 1018cd3:	74 0f                	je     1018ce4 <entry_run+0x834>
 1018cd5:	48 8d b5 30 fd ff ff 	lea    -0x2d0(%rbp),%rsi
 1018cdc:	48 89 df             	mov    %rbx,%rdi
 1018cdf:	e8 cc 1e 00 00       	call   101abb0 <myl_qbe_rc_slot_drop>
 1018ce4:	48 c7 45 c0 e8 03 00 	movq   $0x3e8,-0x40(%rbp)
 1018ceb:	00 
 1018cec:	45 31 e4             	xor    %r12d,%r12d
 1018cef:	eb 39                	jmp    1018d2a <entry_run+0x87a>
 1018cf1:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1018cf8:	0f 1f 84 00 00 00 00 
 1018cff:	00 
 1018d00:	31 c0                	xor    %eax,%eax
 1018d02:	49 81 fc e7 03 00 00 	cmp    $0x3e7,%r12
 1018d09:	4d 8d 64 24 01       	lea    0x1(%r12),%r12
 1018d0e:	48 c7 45 c0 e8 03 00 	movq   $0x3e8,-0x40(%rbp)
 1018d15:	00 
 1018d16:	0f 92 c0             	setb   %al
 1018d19:	48 89 45 d0          	mov    %rax,-0x30(%rbp)
 1018d1d:	49 81 fc e8 03 00 00 	cmp    $0x3e8,%r12
 1018d24:	0f 84 2a 04 00 00    	je     1019154 <entry_run+0xca4>
 1018d2a:	48 c7 85 20 ff ff ff 	movq   $0x79,-0xe0(%rbp)
 1018d31:	79 00 00 00 
 1018d35:	48 c7 45 c8 d8 59 03 	movq   $0x10359d8,-0x38(%rbp)
 1018d3c:	01 
 1018d3d:	48 c7 85 90 fe ff ff 	movq   $0x1009f60,-0x170(%rbp)
 1018d44:	60 9f 00 01 
 1018d48:	c7 85 a8 fe ff ff 02 	movl   $0x2,-0x158(%rbp)
 1018d4f:	00 00 00 
 1018d52:	48 c7 45 a8 d8 59 03 	movq   $0x10359d8,-0x58(%rbp)
 1018d59:	01 
 1018d5a:	48 c7 85 30 fe ff ff 	movq   $0x1009f60,-0x1d0(%rbp)
 1018d61:	60 9f 00 01 
 1018d65:	c7 85 48 fe ff ff 02 	movl   $0x2,-0x1b8(%rbp)
 1018d6c:	00 00 00 
 1018d6f:	c7 45 88 00 00 00 00 	movl   $0x0,-0x78(%rbp)
 1018d76:	c7 85 70 ff ff ff 01 	movl   $0x1,-0x90(%rbp)
 1018d7d:	00 00 00 
 1018d80:	48 c7 45 d0 d8 59 03 	movq   $0x10359d8,-0x30(%rbp)
 1018d87:	01 
 1018d88:	4c 89 ef             	mov    %r13,%rdi
 1018d8b:	4c 89 e6             	mov    %r12,%rsi
 1018d8e:	31 d2                	xor    %edx,%edx
 1018d90:	e8 db 7e ff ff       	call   1010c70 <myl_native_text_scalar>
 1018d95:	48 85 c0             	test   %rax,%rax
 1018d98:	0f 84 32 1d 00 00    	je     101aad0 <entry_run+0x2620>
 1018d9e:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
 1018da2:	48 c7 85 90 fe ff ff 	movq   $0x1009f60,-0x170(%rbp)
 1018da9:	60 9f 00 01 
 1018dad:	c7 85 a8 fe ff ff 02 	movl   $0x2,-0x158(%rbp)
 1018db4:	00 00 00 
 1018db7:	48 89 85 c8 fc ff ff 	mov    %rax,-0x338(%rbp)
 1018dbe:	48 c7 85 50 fe ff ff 	movq   $0x1009f60,-0x1b0(%rbp)
 1018dc5:	60 9f 00 01 
 1018dc9:	c7 85 68 fe ff ff 02 	movl   $0x2,-0x198(%rbp)
 1018dd0:	00 00 00 
 1018dd3:	c7 45 88 00 00 00 00 	movl   $0x0,-0x78(%rbp)
 1018dda:	c7 85 78 ff ff ff 01 	movl   $0x1,-0x88(%rbp)
 1018de1:	00 00 00 
 1018de4:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
 1018de8:	48 8b 4d d0          	mov    -0x30(%rbp),%rcx
 1018dec:	48 89 8d d8 fe ff ff 	mov    %rcx,-0x128(%rbp)
 1018df3:	48 89 85 e0 fe ff ff 	mov    %rax,-0x120(%rbp)
 1018dfa:	4c 8b 71 08          	mov    0x8(%rcx),%r14
 1018dfe:	4c 03 70 08          	add    0x8(%rax),%r14
 1018e02:	0f 82 c0 1c 00 00    	jb     101aac8 <entry_run+0x2618>
 1018e08:	48 8b 83 68 02 00 00 	mov    0x268(%rbx),%rax
 1018e0f:	48 89 85 40 fc ff ff 	mov    %rax,-0x3c0(%rbp)
 1018e16:	48 8d 85 d8 fe ff ff 	lea    -0x128(%rbp),%rax
 1018e1d:	48 89 85 48 fc ff ff 	mov    %rax,-0x3b8(%rbp)
 1018e24:	48 c7 85 50 fc ff ff 	movq   $0x100c360,-0x3b0(%rbp)
 1018e2b:	60 c3 00 01 
 1018e2f:	48 8d 85 40 fc ff ff 	lea    -0x3c0(%rbp),%rax
 1018e36:	48 89 85 f0 fc ff ff 	mov    %rax,-0x310(%rbp)
 1018e3d:	48 8d 85 e0 fe ff ff 	lea    -0x120(%rbp),%rax
 1018e44:	48 89 85 f8 fc ff ff 	mov    %rax,-0x308(%rbp)
 1018e4b:	48 c7 85 00 fd ff ff 	movq   $0x100c360,-0x300(%rbp)
 1018e52:	60 c3 00 01 
 1018e56:	48 8d 85 f0 fc ff ff 	lea    -0x310(%rbp),%rax
 1018e5d:	48 89 83 68 02 00 00 	mov    %rax,0x268(%rbx)
 1018e64:	49 83 fe e7          	cmp    $0xffffffffffffffe7,%r14
 1018e68:	0f 87 d2 00 00 00    	ja     1018f40 <entry_run+0xa90>
 1018e6e:	48 83 bb 60 18 00 00 	cmpq   $0x0,0x1860(%rbx)
 1018e75:	00 
 1018e76:	0f 84 c4 00 00 00    	je     1018f40 <entry_run+0xa90>
 1018e7c:	8b 83 c8 02 00 00    	mov    0x2c8(%rbx),%eax
 1018e82:	49 8d 4e 18          	lea    0x18(%r14),%rcx
 1018e86:	48 c7 85 d0 fe ff ff 	movq   $0x0,-0x130(%rbp)
 1018e8d:	00 00 00 00 
 1018e91:	48 c7 85 d8 fc ff ff 	movq   $0x100c898,-0x328(%rbp)
 1018e98:	98 c8 00 01 
 1018e9c:	48 89 8d e0 fc ff ff 	mov    %rcx,-0x320(%rbp)
 1018ea3:	89 85 e8 fc ff ff    	mov    %eax,-0x318(%rbp)
 1018ea9:	c7 85 ec fc ff ff 00 	movl   $0x0,-0x314(%rbp)
 1018eb0:	00 00 00 
 1018eb3:	4c 89 ef             	mov    %r13,%rdi
 1018eb6:	48 8d b5 d8 fc ff ff 	lea    -0x328(%rbp),%rsi
 1018ebd:	48 8d 95 d0 fe ff ff 	lea    -0x130(%rbp),%rdx
 1018ec4:	e8 77 cf 00 00       	call   1025e40 <myl_rc_new>
 1018ec9:	85 c0                	test   %eax,%eax
 1018ecb:	74 16                	je     1018ee3 <entry_run+0xa33>
 1018ecd:	48 8b 8b 60 18 00 00 	mov    0x1860(%rbx),%rcx
 1018ed4:	48 85 c9             	test   %rcx,%rcx
 1018ed7:	0f 84 de 1b 00 00    	je     101aabb <entry_run+0x260b>
 1018edd:	83 79 78 00          	cmpl   $0x0,0x78(%rcx)
 1018ee1:	74 40                	je     1018f23 <entry_run+0xa73>
 1018ee3:	4c 8b bd d0 fe ff ff 	mov    -0x130(%rbp),%r15
 1018eea:	4d 85 ff             	test   %r15,%r15
 1018eed:	74 51                	je     1018f40 <entry_run+0xa90>
 1018eef:	49 c7 07 00 00 00 00 	movq   $0x0,(%r15)
 1018ef6:	4d 89 77 08          	mov    %r14,0x8(%r15)
 1018efa:	49 c7 47 10 00 00 00 	movq   $0x0,0x10(%r15)
 1018f01:	00 
 1018f02:	4d 8d 77 18          	lea    0x18(%r15),%r14
 1018f06:	4c 8b ad d8 fe ff ff 	mov    -0x128(%rbp),%r13
 1018f0d:	49 8b 55 08          	mov    0x8(%r13),%rdx
 1018f11:	48 85 d2             	test   %rdx,%rdx
 1018f14:	74 7a                	je     1018f90 <entry_run+0xae0>
 1018f16:	41 f6 45 10 04       	testb  $0x4,0x10(%r13)
 1018f1b:	75 5b                	jne    1018f78 <entry_run+0xac8>
 1018f1d:	49 8d 75 18          	lea    0x18(%r13),%rsi
 1018f21:	eb 65                	jmp    1018f88 <entry_run+0xad8>
 1018f23:	89 41 78             	mov    %eax,0x78(%rcx)
 1018f26:	4c 8b bd d0 fe ff ff 	mov    -0x130(%rbp),%r15
 1018f2d:	4d 85 ff             	test   %r15,%r15
 1018f30:	75 bd                	jne    1018eef <entry_run+0xa3f>
 1018f32:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1018f39:	1f 84 00 00 00 00 00 
 1018f40:	45 31 ff             	xor    %r15d,%r15d
 1018f43:	48 8b 83 68 02 00 00 	mov    0x268(%rbx),%rax
 1018f4a:	48 8d 8d f0 fc ff ff 	lea    -0x310(%rbp),%rcx
 1018f51:	48 39 c8             	cmp    %rcx,%rax
 1018f54:	0f 84 b6 00 00 00    	je     1019010 <entry_run+0xb60>
 1018f5a:	48 8d 8d 40 fc ff ff 	lea    -0x3c0(%rbp),%rcx
 1018f61:	48 39 c8             	cmp    %rcx,%rax
 1018f64:	0f 84 c4 00 00 00    	je     101902e <entry_run+0xb7e>
 1018f6a:	4d 85 ff             	test   %r15,%r15
 1018f6d:	0f 85 d2 00 00 00    	jne    1019045 <entry_run+0xb95>
 1018f73:	e9 50 1b 00 00       	jmp    101aac8 <entry_run+0x2618>
 1018f78:	49 8b 45 18          	mov    0x18(%r13),%rax
 1018f7c:	41 8b 4d 14          	mov    0x14(%r13),%ecx
 1018f80:	48 8d 34 08          	lea    (%rax,%rcx,1),%rsi
 1018f84:	48 83 c6 18          	add    $0x18,%rsi
 1018f88:	4c 89 f7             	mov    %r14,%rdi
 1018f8b:	e8 d0 90 01 00       	call   1032060 <memcpy@plt>
 1018f90:	48 8b b5 e0 fe ff ff 	mov    -0x120(%rbp),%rsi
 1018f97:	48 8b 56 08          	mov    0x8(%rsi),%rdx
 1018f9b:	48 85 d2             	test   %rdx,%rdx
 1018f9e:	74 35                	je     1018fd5 <entry_run+0xb25>
 1018fa0:	f6 46 10 04          	testb  $0x4,0x10(%rsi)
 1018fa4:	75 06                	jne    1018fac <entry_run+0xafc>
 1018fa6:	48 83 c6 18          	add    $0x18,%rsi
 1018faa:	eb 0f                	jmp    1018fbb <entry_run+0xb0b>
 1018fac:	48 8b 46 18          	mov    0x18(%rsi),%rax
 1018fb0:	8b 4e 14             	mov    0x14(%rsi),%ecx
 1018fb3:	48 8d 34 08          	lea    (%rax,%rcx,1),%rsi
 1018fb7:	48 83 c6 18          	add    $0x18,%rsi
 1018fbb:	4d 03 75 08          	add    0x8(%r13),%r14
 1018fbf:	4c 89 f7             	mov    %r14,%rdi
 1018fc2:	e8 99 90 01 00       	call   1032060 <memcpy@plt>
 1018fc7:	4c 8b ad d8 fe ff ff 	mov    -0x128(%rbp),%r13
 1018fce:	48 8b b5 e0 fe ff ff 	mov    -0x120(%rbp),%rsi
 1018fd5:	48 8b 06             	mov    (%rsi),%rax
 1018fd8:	49 03 45 00          	add    0x0(%r13),%rax
 1018fdc:	41 8b 4d 10          	mov    0x10(%r13),%ecx
 1018fe0:	23 4e 10             	and    0x10(%rsi),%ecx
 1018fe3:	83 e1 01             	and    $0x1,%ecx
 1018fe6:	49 89 07             	mov    %rax,(%r15)
 1018fe9:	41 89 4f 10          	mov    %ecx,0x10(%r15)
 1018fed:	4c 8d ab 58 02 00 00 	lea    0x258(%rbx),%r13
 1018ff4:	48 8b 83 68 02 00 00 	mov    0x268(%rbx),%rax
 1018ffb:	48 8d 8d f0 fc ff ff 	lea    -0x310(%rbp),%rcx
 1019002:	48 39 c8             	cmp    %rcx,%rax
 1019005:	0f 85 4f ff ff ff    	jne    1018f5a <entry_run+0xaaa>
 101900b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
 1019010:	48 8b 85 f0 fc ff ff 	mov    -0x310(%rbp),%rax
 1019017:	48 89 83 68 02 00 00 	mov    %rax,0x268(%rbx)
 101901e:	48 8d 8d 40 fc ff ff 	lea    -0x3c0(%rbp),%rcx
 1019025:	48 39 c8             	cmp    %rcx,%rax
 1019028:	0f 85 3c ff ff ff    	jne    1018f6a <entry_run+0xaba>
 101902e:	48 8b 85 40 fc ff ff 	mov    -0x3c0(%rbp),%rax
 1019035:	48 89 83 68 02 00 00 	mov    %rax,0x268(%rbx)
 101903c:	4d 85 ff             	test   %r15,%r15
 101903f:	0f 84 83 1a 00 00    	je     101aac8 <entry_run+0x2618>
 1019045:	4c 89 7d d0          	mov    %r15,-0x30(%rbp)
 1019049:	4c 89 7d c8          	mov    %r15,-0x38(%rbp)
 101904d:	48 c7 85 90 fe ff ff 	movq   $0x1009f60,-0x170(%rbp)
 1019054:	60 9f 00 01 
 1019058:	c7 85 a8 fe ff ff 02 	movl   $0x2,-0x158(%rbp)
 101905f:	00 00 00 
 1019062:	c7 45 88 01 00 00 00 	movl   $0x1,-0x78(%rbp)
 1019069:	83 bd 70 ff ff ff 00 	cmpl   $0x0,-0x90(%rbp)
 1019070:	74 0f                	je     1019081 <entry_run+0xbd1>
 1019072:	48 89 df             	mov    %rbx,%rdi
 1019075:	48 8d b5 30 fe ff ff 	lea    -0x1d0(%rbp),%rsi
 101907c:	e8 2f 1b 00 00       	call   101abb0 <myl_qbe_rc_slot_drop>
 1019081:	83 bd 78 ff ff ff 00 	cmpl   $0x0,-0x88(%rbp)
 1019088:	74 0f                	je     1019099 <entry_run+0xbe9>
 101908a:	48 89 df             	mov    %rbx,%rdi
 101908d:	48 8d b5 50 fe ff ff 	lea    -0x1b0(%rbp),%rsi
 1019094:	e8 17 1b 00 00       	call   101abb0 <myl_qbe_rc_slot_drop>
 1019099:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
 101909d:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
 10190a1:	48 c7 85 30 fe ff ff 	movq   $0x1009f60,-0x1d0(%rbp)
 10190a8:	60 9f 00 01 
 10190ac:	8b 8d a8 fe ff ff    	mov    -0x158(%rbp),%ecx
 10190b2:	89 8d 48 fe ff ff    	mov    %ecx,-0x1b8(%rbp)
 10190b8:	c7 45 88 00 00 00 00 	movl   $0x0,-0x78(%rbp)
 10190bf:	c7 85 70 ff ff ff 01 	movl   $0x1,-0x90(%rbp)
 10190c6:	00 00 00 
 10190c9:	48 89 45 d0          	mov    %rax,-0x30(%rbp)
 10190cd:	48 c7 85 50 fd ff ff 	movq   $0x1009fd0,-0x2b0(%rbp)
 10190d4:	d0 9f 00 01 
 10190d8:	c7 85 68 fd ff ff 02 	movl   $0x2,-0x298(%rbp)
 10190df:	00 00 00 
 10190e2:	48 8d 55 a0          	lea    -0x60(%rbp),%rdx
 10190e6:	48 89 95 58 fd ff ff 	mov    %rdx,-0x2a8(%rbp)
 10190ed:	48 8d 8d 38 ff ff ff 	lea    -0xc8(%rbp),%rcx
 10190f4:	48 89 8d 60 fd ff ff 	mov    %rcx,-0x2a0(%rbp)
 10190fb:	be d0 9f 00 01       	mov    $0x1009fd0,%esi
 1019100:	48 89 df             	mov    %rbx,%rdi
 1019103:	e8 68 20 00 00       	call   101b170 <myl_qbe_rc_unique_local>
 1019108:	85 c0                	test   %eax,%eax
 101910a:	0f 84 69 01 00 00    	je     1019279 <entry_run+0xdc9>
 1019110:	48 8b 75 a0          	mov    -0x60(%rbp),%rsi
 1019114:	48 8b 16             	mov    (%rsi),%rdx
 1019117:	4c 89 ef             	mov    %r13,%rdi
 101911a:	48 8d 4d d0          	lea    -0x30(%rbp),%rcx
 101911e:	e8 0d 6d 00 00       	call   101fe30 <rc_list_insert_at>
 1019123:	85 c0                	test   %eax,%eax
 1019125:	0f 84 ad 19 00 00    	je     101aad8 <entry_run+0x2628>
 101912b:	48 c7 45 d0 00 00 00 	movq   $0x0,-0x30(%rbp)
 1019132:	00 
 1019133:	83 bd 70 ff ff ff 00 	cmpl   $0x0,-0x90(%rbp)
 101913a:	0f 84 c0 fb ff ff    	je     1018d00 <entry_run+0x850>
 1019140:	48 89 df             	mov    %rbx,%rdi
 1019143:	48 8d b5 30 fe ff ff 	lea    -0x1d0(%rbp),%rsi
 101914a:	e8 61 1a 00 00       	call   101abb0 <myl_qbe_rc_slot_drop>
 101914f:	e9 ac fb ff ff       	jmp    1018d00 <entry_run+0x850>
 1019154:	be 60 9f 00 01       	mov    $0x1009f60,%esi
 1019159:	ba f0 9e 00 01       	mov    $0x1009ef0,%edx
 101915e:	4c 89 ef             	mov    %r13,%rdi
 1019161:	b9 01 00 00 00       	mov    $0x1,%ecx
 1019166:	e8 25 76 00 00       	call   1020790 <myl_native_dictionary_new>
 101916b:	48 85 c0             	test   %rax,%rax
 101916e:	0f 84 bf 19 00 00    	je     101ab33 <entry_run+0x2683>
 1019174:	48 89 85 10 fd ff ff 	mov    %rax,-0x2f0(%rbp)
 101917b:	48 c7 85 b0 fe ff ff 	movq   $0x100a7b0,-0x150(%rbp)
 1019182:	b0 a7 00 01 
 1019186:	48 8d 8d 10 fd ff ff 	lea    -0x2f0(%rbp),%rcx
 101918d:	48 89 8d b8 fe ff ff 	mov    %rcx,-0x148(%rbp)
 1019194:	48 8d 4d 90          	lea    -0x70(%rbp),%rcx
 1019198:	48 89 8d c0 fe ff ff 	mov    %rcx,-0x140(%rbp)
 101919f:	c7 85 c8 fe ff ff 04 	movl   $0x4,-0x138(%rbp)
 10191a6:	00 00 00 
 10191a9:	c7 45 90 00 00 00 00 	movl   $0x0,-0x70(%rbp)
 10191b0:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
 10191b4:	48 c7 85 90 fe ff ff 	movq   $0x100a7b0,-0x170(%rbp)
 10191bb:	b0 a7 00 01 
 10191bf:	c7 85 a8 fe ff ff 02 	movl   $0x2,-0x158(%rbp)
 10191c6:	00 00 00 
 10191c9:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
 10191cd:	48 c7 85 30 fe ff ff 	movq   $0x100a7b0,-0x1d0(%rbp)
 10191d4:	b0 a7 00 01 
 10191d8:	c7 85 48 fe ff ff 02 	movl   $0x2,-0x1b8(%rbp)
 10191df:	00 00 00 
 10191e2:	c7 45 88 00 00 00 00 	movl   $0x0,-0x78(%rbp)
 10191e9:	c7 85 70 ff ff ff 01 	movl   $0x1,-0x90(%rbp)
 10191f0:	00 00 00 
 10191f3:	48 89 45 d0          	mov    %rax,-0x30(%rbp)
 10191f7:	48 b9 01 00 00 00 00 	movabs $0x5000000000000001,%rcx
 10191fe:	00 00 50 
 1019201:	48 85 48 f0          	test   %rcx,-0x10(%rax)
 1019205:	0f 84 29 01 00 00    	je     1019334 <entry_run+0xe84>
 101920b:	48 8d 55 c8          	lea    -0x38(%rbp),%rdx
 101920f:	48 8d 4d d0          	lea    -0x30(%rbp),%rcx
 1019213:	be b0 a7 00 01       	mov    $0x100a7b0,%esi
 1019218:	4c 89 ef             	mov    %r13,%rdi
 101921b:	44 8b 45 b8          	mov    -0x48(%rbp),%r8d
 101921f:	e8 9c 49 01 00       	call   102dbc0 <myl_rc_native_take>
 1019224:	85 c0                	test   %eax,%eax
 1019226:	0f 85 10 01 00 00    	jne    101933c <entry_run+0xe8c>
 101922c:	48 8b 8b 60 18 00 00 	mov    0x1860(%rbx),%rcx
 1019233:	48 85 c9             	test   %rcx,%rcx
 1019236:	0f 84 7f 18 00 00    	je     101aabb <entry_run+0x260b>
 101923c:	8b 41 78             	mov    0x78(%rcx),%eax
 101923f:	c7 41 78 00 00 00 00 	movl   $0x0,0x78(%rcx)
 1019246:	48 85 c0             	test   %rax,%rax
 1019249:	74 2e                	je     1019279 <entry_run+0xdc9>
 101924b:	83 f8 01             	cmp    $0x1,%eax
 101924e:	75 10                	jne    1019260 <entry_run+0xdb0>
 1019250:	be 46 74 00 01       	mov    $0x1007446,%esi
 1019255:	83 bb c4 02 00 00 00 	cmpl   $0x0,0x2c4(%rbx)
 101925c:	75 13                	jne    1019271 <entry_run+0xdc1>
 101925e:	eb 09                	jmp    1019269 <entry_run+0xdb9>
 1019260:	83 f8 04             	cmp    $0x4,%eax
 1019263:	0f 83 5a 18 00 00    	jae    101aac3 <entry_run+0x2613>
 1019269:	48 8b 34 c5 48 c7 00 	mov    0x100c748(,%rax,8),%rsi
 1019270:	01 
 1019271:	48 89 df             	mov    %rbx,%rdi
 1019274:	e8 c7 22 00 00       	call   101b540 <fail>
 1019279:	4c 8d a5 f0 fe ff ff 	lea    -0x110(%rbp),%r12
 1019280:	4c 39 a3 80 3d 00 00 	cmp    %r12,0x3d80(%rbx)
 1019287:	0f 85 2e 18 00 00    	jne    101aabb <entry_run+0x260b>
 101928d:	48 8b b5 08 ff ff ff 	mov    -0xf8(%rbp),%rsi
 1019294:	4c 89 ef             	mov    %r13,%rdi
 1019297:	e8 c4 0f 01 00       	call   102a260 <myl_rc_scope_unwind>
 101929c:	4c 8b b5 00 ff ff ff 	mov    -0x100(%rbp),%r14
 10192a3:	4d 85 f6             	test   %r14,%r14
 10192a6:	0f 84 c0 17 00 00    	je     101aa6c <entry_run+0x25bc>
 10192ac:	4d 89 f7             	mov    %r14,%r15
 10192af:	49 c1 e7 05          	shl    $0x5,%r15
 10192b3:	49 83 c7 e0          	add    $0xffffffffffffffe0,%r15
 10192b7:	eb 1f                	jmp    10192d8 <entry_run+0xe28>
 10192b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
 10192c0:	4c 01 fe             	add    %r15,%rsi
 10192c3:	48 89 df             	mov    %rbx,%rdi
 10192c6:	e8 e5 18 00 00       	call   101abb0 <myl_qbe_rc_slot_drop>
 10192cb:	49 83 c7 e0          	add    $0xffffffffffffffe0,%r15
 10192cf:	49 ff ce             	dec    %r14
 10192d2:	0f 84 94 17 00 00    	je     101aa6c <entry_run+0x25bc>
 10192d8:	48 8b b5 f8 fe ff ff 	mov    -0x108(%rbp),%rsi
 10192df:	4a 8b 44 3e 10       	mov    0x10(%rsi,%r15,1),%rax
 10192e4:	48 85 c0             	test   %rax,%rax
 10192e7:	74 d7                	je     10192c0 <entry_run+0xe10>
 10192e9:	83 38 00             	cmpl   $0x0,(%rax)
 10192ec:	75 d2                	jne    10192c0 <entry_run+0xe10>
 10192ee:	eb db                	jmp    10192cb <entry_run+0xe1b>
 10192f0:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
 10192f4:	48 c7 45 d0 00 00 00 	movq   $0x0,-0x30(%rbp)
 10192fb:	00 
 10192fc:	c7 85 70 ff ff ff 00 	movl   $0x0,-0x90(%rbp)
 1019303:	00 00 00 
 1019306:	48 c7 85 90 fe ff ff 	movq   $0x1009fd0,-0x170(%rbp)
 101930d:	d0 9f 00 01 
 1019311:	c7 85 a8 fe ff ff 02 	movl   $0x2,-0x158(%rbp)
 1019318:	00 00 00 
 101931b:	c7 45 88 01 00 00 00 	movl   $0x1,-0x78(%rbp)
 1019322:	83 bd 38 ff ff ff 00 	cmpl   $0x0,-0xc8(%rbp)
 1019329:	0f 85 45 f9 ff ff    	jne    1018c74 <entry_run+0x7c4>
 101932f:	e9 4f f9 ff ff       	jmp    1018c83 <entry_run+0x7d3>
 1019334:	48 c7 45 d0 00 00 00 	movq   $0x0,-0x30(%rbp)
 101933b:	00 
 101933c:	c7 85 70 ff ff ff 00 	movl   $0x0,-0x90(%rbp)
 1019343:	00 00 00 
 1019346:	48 c7 85 90 fe ff ff 	movq   $0x100a7b0,-0x170(%rbp)
 101934d:	b0 a7 00 01 
 1019351:	c7 85 a8 fe ff ff 02 	movl   $0x2,-0x158(%rbp)
 1019358:	00 00 00 
 101935b:	c7 45 88 01 00 00 00 	movl   $0x1,-0x78(%rbp)
 1019362:	83 bd 40 ff ff ff 00 	cmpl   $0x0,-0xc0(%rbp)
 1019369:	74 0f                	je     101937a <entry_run+0xeca>
 101936b:	48 89 df             	mov    %rbx,%rdi
 101936e:	48 8d b5 70 fd ff ff 	lea    -0x290(%rbp),%rsi
 1019375:	e8 36 18 00 00       	call   101abb0 <myl_qbe_rc_slot_drop>
 101937a:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
 101937e:	48 89 45 98          	mov    %rax,-0x68(%rbp)
 1019382:	c7 45 88 00 00 00 00 	movl   $0x0,-0x78(%rbp)
 1019389:	c7 85 40 ff ff ff 01 	movl   $0x1,-0xc0(%rbp)
 1019390:	00 00 00 
 1019393:	48 c7 45 d0 80 84 1e 	movq   $0x1e8480,-0x30(%rbp)
 101939a:	00 
 101939b:	48 c7 85 70 fd ff ff 	movq   $0x100a7b0,-0x290(%rbp)
 10193a2:	b0 a7 00 01 
 10193a6:	c7 85 88 fd ff ff 02 	movl   $0x2,-0x278(%rbp)
 10193ad:	00 00 00 
 10193b0:	48 8d 55 98          	lea    -0x68(%rbp),%rdx
 10193b4:	48 89 95 78 fd ff ff 	mov    %rdx,-0x288(%rbp)
 10193bb:	48 8d 8d 40 ff ff ff 	lea    -0xc0(%rbp),%rcx
 10193c2:	48 89 8d 80 fd ff ff 	mov    %rcx,-0x280(%rbp)
 10193c9:	be b0 a7 00 01       	mov    $0x100a7b0,%esi
 10193ce:	48 89 df             	mov    %rbx,%rdi
 10193d1:	e8 9a 1d 00 00       	call   101b170 <myl_qbe_rc_unique_local>
 10193d6:	85 c0                	test   %eax,%eax
 10193d8:	0f 84 9b fe ff ff    	je     1019279 <entry_run+0xdc9>
 10193de:	45 31 ff             	xor    %r15d,%r15d
 10193e1:	eb 52                	jmp    1019435 <entry_run+0xf85>
 10193e3:	4d 89 f7             	mov    %r14,%r15
 10193e6:	48 8d bb 58 02 00 00 	lea    0x258(%rbx),%rdi
 10193ed:	4c 89 ee             	mov    %r13,%rsi
 10193f0:	48 8d 55 d0          	lea    -0x30(%rbp),%rdx
 10193f4:	48 8d 4d c0          	lea    -0x40(%rbp),%rcx
 10193f8:	e8 c3 b6 00 00       	call   1024ac0 <write_walk>
 10193fd:	85 c0                	test   %eax,%eax
 10193ff:	4c 8d ab 58 02 00 00 	lea    0x258(%rbx),%r13
 1019406:	0f 84 3c 17 00 00    	je     101ab48 <entry_run+0x2698>
 101940c:	31 c0                	xor    %eax,%eax
 101940e:	49 81 ff 7f 84 1e 00 	cmp    $0x1e847f,%r15
 1019415:	4d 8d 7f 01          	lea    0x1(%r15),%r15
 1019419:	48 c7 45 c0 80 84 1e 	movq   $0x1e8480,-0x40(%rbp)
 1019420:	00 
 1019421:	0f 92 c0             	setb   %al
 1019424:	48 89 45 d0          	mov    %rax,-0x30(%rbp)
 1019428:	49 81 ff 80 84 1e 00 	cmp    $0x1e8480,%r15
 101942f:	0f 84 99 0c 00 00    	je     101a0ce <entry_run+0x1c1e>
 1019435:	48 8b 45 a0          	mov    -0x60(%rbp),%rax
 1019439:	48 89 85 20 fd ff ff 	mov    %rax,-0x2e0(%rbp)
 1019440:	49 69 f7 ef 1e 00 00 	imul   $0x1eef,%r15,%rsi
 1019447:	48 89 f2             	mov    %rsi,%rdx
 101944a:	48 c1 ea 03          	shr    $0x3,%rdx
 101944e:	48 b9 cf f7 53 e3 a5 	movabs $0x20c49ba5e353f7cf,%rcx
 1019455:	9b c4 20 
 1019458:	c4 e2 f3 f6 c9       	mulx   %rcx,%rcx,%rcx
 101945d:	48 c1 e9 04          	shr    $0x4,%rcx
 1019461:	48 69 c9 e8 03 00 00 	imul   $0x3e8,%rcx,%rcx
 1019468:	48 29 ce             	sub    %rcx,%rsi
 101946b:	48 c7 45 c0 00 00 00 	movq   $0x0,-0x40(%rbp)
 1019472:	00 
 1019473:	48 89 75 d0          	mov    %rsi,-0x30(%rbp)
 1019477:	48 8b 10             	mov    (%rax),%rdx
 101947a:	48 39 d6             	cmp    %rdx,%rsi
 101947d:	0f 83 5d 16 00 00    	jae    101aae0 <entry_run+0x2630>
 1019483:	48 8b 40 20          	mov    0x20(%rax),%rax
 1019487:	48 8b 04 f0          	mov    (%rax,%rsi,8),%rax
 101948b:	48 89 85 e8 fe ff ff 	mov    %rax,-0x118(%rbp)
 1019492:	48 89 45 d0          	mov    %rax,-0x30(%rbp)
 1019496:	48 c7 45 c0 00 00 00 	movq   $0x0,-0x40(%rbp)
 101949d:	00 
 101949e:	48 8b 7d 98          	mov    -0x68(%rbp),%rdi
 10194a2:	48 8d 75 d0          	lea    -0x30(%rbp),%rsi
 10194a6:	4c 8d b5 d0 fe ff ff 	lea    -0x130(%rbp),%r14
 10194ad:	4c 89 f2             	mov    %r14,%rdx
 10194b0:	e8 2b 98 00 00       	call   1022ce0 <myl_native_dictionary_read>
 10194b5:	85 c0                	test   %eax,%eax
 10194b7:	48 8d 4d c0          	lea    -0x40(%rbp),%rcx
 10194bb:	4c 0f 44 f1          	cmove  %rcx,%r14
 10194bf:	4d 8b 26             	mov    (%r14),%r12
 10194c2:	4c 89 65 d0          	mov    %r12,-0x30(%rbp)
 10194c6:	48 c7 45 c0 01 00 00 	movq   $0x1,-0x40(%rbp)
 10194cd:	00 
 10194ce:	48 b8 ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rax
 10194d5:	ff ff 7f 
 10194d8:	49 39 c4             	cmp    %rax,%r12
 10194db:	0f 84 07 16 00 00    	je     101aae8 <entry_run+0x2638>
 10194e1:	49 ff c4             	inc    %r12
 10194e4:	4c 8b 6d 98          	mov    -0x68(%rbp),%r13
 10194e8:	4c 89 ad 28 fd ff ff 	mov    %r13,-0x2d8(%rbp)
 10194ef:	4c 8b 8d e8 fe ff ff 	mov    -0x118(%rbp),%r9
 10194f6:	4c 89 4d d0          	mov    %r9,-0x30(%rbp)
 10194fa:	4c 89 65 c0          	mov    %r12,-0x40(%rbp)
 10194fe:	48 83 bb 60 18 00 00 	cmpq   $0x0,0x1860(%rbx)
 1019505:	00 
 1019506:	45 8b b5 f8 00 00 00 	mov    0xf8(%r13),%r14d
 101950d:	74 71                	je     1019580 <entry_run+0x10d0>
 101950f:	4c 89 7d b8          	mov    %r15,-0x48(%rbp)
 1019513:	45 8b 65 24          	mov    0x24(%r13),%r12d
 1019517:	41 83 fe 01          	cmp    $0x1,%r14d
 101951b:	0f 85 6f 02 00 00    	jne    1019790 <entry_run+0x12e0>
 1019521:	4c 89 c9             	mov    %r9,%rcx
 1019524:	41 83 fc 02          	cmp    $0x2,%r12d
 1019528:	0f 82 e2 00 00 00    	jb     1019610 <entry_run+0x1160>
 101952e:	0f 85 ac 02 00 00    	jne    10197e0 <entry_run+0x1330>
 1019534:	49 8b 45 08          	mov    0x8(%r13),%rax
 1019538:	48 8b 10             	mov    (%rax),%rdx
 101953b:	48 c7 85 40 fc ff ff 	movq   $0x0,-0x3c0(%rbp)
 1019542:	00 00 00 00 
 1019546:	f3 48 0f b8 c2       	popcnt %rdx,%rax
 101954b:	83 f8 01             	cmp    $0x1,%eax
 101954e:	0f 85 92 00 00 00    	jne    10195e6 <entry_run+0x1136>
 1019554:	f3 48 0f bc c2       	tzcnt  %rdx,%rax
 1019559:	48 83 f8 03          	cmp    $0x3,%rax
 101955d:	0f 87 83 00 00 00    	ja     10195e6 <entry_run+0x1136>
 1019563:	4c 89 c9             	mov    %r9,%rcx
 1019566:	ff 24 c5 38 96 00 01 	jmp    *0x1009638(,%rax,8)
 101956d:	41 0f b6 c9          	movzbl %r9b,%ecx
 1019571:	e9 9a 00 00 00       	jmp    1019610 <entry_run+0x1160>
 1019576:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
 101957d:	00 00 00 
 1019580:	41 83 fe 01          	cmp    $0x1,%r14d
 1019584:	0f 85 5c fe ff ff    	jne    10193e6 <entry_run+0xf36>
 101958a:	4d 89 fe             	mov    %r15,%r14
 101958d:	45 8b 7d 24          	mov    0x24(%r13),%r15d
 1019591:	4c 89 cf             	mov    %r9,%rdi
 1019594:	41 83 ff 02          	cmp    $0x2,%r15d
 1019598:	0f 82 ed 00 00 00    	jb     101968b <entry_run+0x11db>
 101959e:	0f 85 3f fe ff ff    	jne    10193e3 <entry_run+0xf33>
 10195a4:	49 8b 45 08          	mov    0x8(%r13),%rax
 10195a8:	48 8b 10             	mov    (%rax),%rdx
 10195ab:	48 c7 85 40 fc ff ff 	movq   $0x0,-0x3c0(%rbp)
 10195b2:	00 00 00 00 
 10195b6:	f3 48 0f b8 c2       	popcnt %rdx,%rax
 10195bb:	83 f8 01             	cmp    $0x1,%eax
 10195be:	0f 85 95 00 00 00    	jne    1019659 <entry_run+0x11a9>
 10195c4:	f3 48 0f bc c2       	tzcnt  %rdx,%rax
 10195c9:	48 83 f8 03          	cmp    $0x3,%rax
 10195cd:	0f 87 86 00 00 00    	ja     1019659 <entry_run+0x11a9>
 10195d3:	4c 89 cf             	mov    %r9,%rdi
 10195d6:	ff 24 c5 98 96 00 01 	jmp    *0x1009698(,%rax,8)
 10195dd:	41 0f b6 f9          	movzbl %r9b,%edi
 10195e1:	e9 a5 00 00 00       	jmp    101968b <entry_run+0x11db>
 10195e6:	48 83 fa 08          	cmp    $0x8,%rdx
 10195ea:	b8 08 00 00 00       	mov    $0x8,%eax
 10195ef:	48 0f 43 d0          	cmovae %rax,%rdx
 10195f3:	48 8d bd 40 fc ff ff 	lea    -0x3c0(%rbp),%rdi
 10195fa:	48 8d 75 d0          	lea    -0x30(%rbp),%rsi
 10195fe:	4d 89 cf             	mov    %r9,%r15
 1019601:	e8 5a 8a 01 00       	call   1032060 <memcpy@plt>
 1019606:	4d 89 f9             	mov    %r15,%r9
 1019609:	48 8b 8d 40 fc ff ff 	mov    -0x3c0(%rbp),%rcx
 1019610:	49 3b 8d e0 00 00 00 	cmp    0xe0(%r13),%rcx
 1019617:	0f 85 73 01 00 00    	jne    1019790 <entry_run+0x12e0>
 101961d:	49 8b 45 00          	mov    0x0(%r13),%rax
 1019621:	4d 8b bd e8 00 00 00 	mov    0xe8(%r13),%r15
 1019628:	4c 3b 38             	cmp    (%rax),%r15
 101962b:	0f 83 5f 01 00 00    	jae    1019790 <entry_run+0x12e0>
 1019631:	49 8b 75 30          	mov    0x30(%r13),%rsi
 1019635:	49 0f af f7          	imul   %r15,%rsi
 1019639:	48 03 70 20          	add    0x20(%rax),%rsi
 101963d:	41 83 fc 02          	cmp    $0x2,%r12d
 1019641:	0f 84 ae 00 00 00    	je     10196f5 <entry_run+0x1245>
 1019647:	41 83 fc 01          	cmp    $0x1,%r12d
 101964b:	0f 85 d7 00 00 00    	jne    1019728 <entry_run+0x1278>
 1019651:	48 8b 06             	mov    (%rsi),%rax
 1019654:	e9 2b 01 00 00       	jmp    1019784 <entry_run+0x12d4>
 1019659:	48 83 fa 08          	cmp    $0x8,%rdx
 101965d:	b8 08 00 00 00       	mov    $0x8,%eax
 1019662:	48 0f 43 d0          	cmovae %rax,%rdx
 1019666:	48 8d bd 40 fc ff ff 	lea    -0x3c0(%rbp),%rdi
 101966d:	48 8d 75 d0          	lea    -0x30(%rbp),%rsi
 1019671:	4c 89 8d 28 ff ff ff 	mov    %r9,-0xd8(%rbp)
 1019678:	e8 e3 89 01 00       	call   1032060 <memcpy@plt>
 101967d:	4c 8b 8d 28 ff ff ff 	mov    -0xd8(%rbp),%r9
 1019684:	48 8b bd 40 fc ff ff 	mov    -0x3c0(%rbp),%rdi
 101968b:	49 3b bd e0 00 00 00 	cmp    0xe0(%r13),%rdi
 1019692:	0f 85 4b fd ff ff    	jne    10193e3 <entry_run+0xf33>
 1019698:	49 8b 45 00          	mov    0x0(%r13),%rax
 101969c:	4d 8b 95 e8 00 00 00 	mov    0xe8(%r13),%r10
 10196a3:	4c 3b 10             	cmp    (%rax),%r10
 10196a6:	0f 83 37 fd ff ff    	jae    10193e3 <entry_run+0xf33>
 10196ac:	4d 0f af 55 30       	imul   0x30(%r13),%r10
 10196b1:	4c 03 50 20          	add    0x20(%rax),%r10
 10196b5:	41 83 ff 02          	cmp    $0x2,%r15d
 10196b9:	0f 84 e0 06 00 00    	je     1019d9f <entry_run+0x18ef>
 10196bf:	41 83 ff 01          	cmp    $0x1,%r15d
 10196c3:	0f 84 ce 06 00 00    	je     1019d97 <entry_run+0x18e7>
 10196c9:	45 85 ff             	test   %r15d,%r15d
 10196cc:	0f 85 0b 07 00 00    	jne    1019ddd <entry_run+0x192d>
 10196d2:	49 8b 02             	mov    (%r10),%rax
 10196d5:	4c 39 c8             	cmp    %r9,%rax
 10196d8:	4d 89 f7             	mov    %r14,%r15
 10196db:	0f 84 97 09 00 00    	je     101a078 <entry_run+0x1bc8>
 10196e1:	41 f6 41 10 04       	testb  $0x4,0x10(%r9)
 10196e6:	0f 85 e2 07 00 00    	jne    1019ece <entry_run+0x1a1e>
 10196ec:	49 8d 49 18          	lea    0x18(%r9),%rcx
 10196f0:	e9 e8 07 00 00       	jmp    1019edd <entry_run+0x1a2d>
 10196f5:	49 8b 45 08          	mov    0x8(%r13),%rax
 10196f9:	48 8b 10             	mov    (%rax),%rdx
 10196fc:	48 c7 85 40 fc ff ff 	movq   $0x0,-0x3c0(%rbp)
 1019703:	00 00 00 00 
 1019707:	f3 48 0f b8 c2       	popcnt %rdx,%rax
 101970c:	83 f8 01             	cmp    $0x1,%eax
 101970f:	75 37                	jne    1019748 <entry_run+0x1298>
 1019711:	f3 48 0f bc c2       	tzcnt  %rdx,%rax
 1019716:	48 83 f8 03          	cmp    $0x3,%rax
 101971a:	77 2c                	ja     1019748 <entry_run+0x1298>
 101971c:	ff 24 c5 58 96 00 01 	jmp    *0x1009658(,%rax,8)
 1019723:	0f b6 06             	movzbl (%rsi),%eax
 1019726:	eb 5c                	jmp    1019784 <entry_run+0x12d4>
 1019728:	48 8b 06             	mov    (%rsi),%rax
 101972b:	4c 39 c8             	cmp    %r9,%rax
 101972e:	0f 84 f5 01 00 00    	je     1019929 <entry_run+0x1479>
 1019734:	41 f6 41 10 04       	testb  $0x4,0x10(%r9)
 1019739:	0f 85 bb 06 00 00    	jne    1019dfa <entry_run+0x194a>
 101973f:	49 8d 49 18          	lea    0x18(%r9),%rcx
 1019743:	e9 c1 06 00 00       	jmp    1019e09 <entry_run+0x1959>
 1019748:	48 83 fa 08          	cmp    $0x8,%rdx
 101974c:	b8 08 00 00 00       	mov    $0x8,%eax
 1019751:	48 0f 43 d0          	cmovae %rax,%rdx
 1019755:	48 8d bd 40 fc ff ff 	lea    -0x3c0(%rbp),%rdi
 101975c:	4c 89 8d 28 ff ff ff 	mov    %r9,-0xd8(%rbp)
 1019763:	48 89 8d d0 fc ff ff 	mov    %rcx,-0x330(%rbp)
 101976a:	e8 f1 88 01 00       	call   1032060 <memcpy@plt>
 101976f:	48 8b 8d d0 fc ff ff 	mov    -0x330(%rbp),%rcx
 1019776:	4c 8b 8d 28 ff ff ff 	mov    -0xd8(%rbp),%r9
 101977d:	48 8b 85 40 fc ff ff 	mov    -0x3c0(%rbp),%rax
 1019784:	48 39 c8             	cmp    %rcx,%rax
 1019787:	0f 84 9c 01 00 00    	je     1019929 <entry_run+0x1479>
 101978d:	0f 1f 00             	nopl   (%rax)
 1019790:	4c 89 ce             	mov    %r9,%rsi
 1019793:	41 83 fc 02          	cmp    $0x2,%r12d
 1019797:	0f 82 9c 00 00 00    	jb     1019839 <entry_run+0x1389>
 101979d:	75 41                	jne    10197e0 <entry_run+0x1330>
 101979f:	49 8b 45 08          	mov    0x8(%r13),%rax
 10197a3:	48 8b 10             	mov    (%rax),%rdx
 10197a6:	48 c7 85 40 fc ff ff 	movq   $0x0,-0x3c0(%rbp)
 10197ad:	00 00 00 00 
 10197b1:	f3 48 0f b8 c2       	popcnt %rdx,%rax
 10197b6:	83 f8 01             	cmp    $0x1,%eax
 10197b9:	75 4e                	jne    1019809 <entry_run+0x1359>
 10197bb:	f3 48 0f bc c2       	tzcnt  %rdx,%rax
 10197c0:	48 83 f8 03          	cmp    $0x3,%rax
 10197c4:	77 43                	ja     1019809 <entry_run+0x1359>
 10197c6:	4c 89 ce             	mov    %r9,%rsi
 10197c9:	ff 24 c5 78 96 00 01 	jmp    *0x1009678(,%rax,8)
 10197d0:	41 0f b6 f1          	movzbl %r9b,%esi
 10197d4:	eb 5d                	jmp    1019833 <entry_run+0x1383>
 10197d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
 10197dd:	00 00 00 
 10197e0:	4c 89 ef             	mov    %r13,%rdi
 10197e3:	48 8d 75 d0          	lea    -0x30(%rbp),%rsi
 10197e7:	e8 54 9a 00 00       	call   1023240 <probe_any>
 10197ec:	49 89 c7             	mov    %rax,%r15
 10197ef:	41 c7 85 f8 00 00 00 	movl   $0x0,0xf8(%r13)
 10197f6:	00 00 00 00 
 10197fa:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
 10197fe:	0f 85 25 01 00 00    	jne    1019929 <entry_run+0x1479>
 1019804:	e9 17 05 00 00       	jmp    1019d20 <entry_run+0x1870>
 1019809:	48 83 fa 08          	cmp    $0x8,%rdx
 101980d:	b8 08 00 00 00       	mov    $0x8,%eax
 1019812:	48 0f 43 d0          	cmovae %rax,%rdx
 1019816:	48 8d bd 40 fc ff ff 	lea    -0x3c0(%rbp),%rdi
 101981d:	48 8d 75 d0          	lea    -0x30(%rbp),%rsi
 1019821:	4d 89 cf             	mov    %r9,%r15
 1019824:	e8 37 88 01 00       	call   1032060 <memcpy@plt>
 1019829:	4d 89 f9             	mov    %r15,%r9
 101982c:	48 8b b5 40 fc ff ff 	mov    -0x3c0(%rbp),%rsi
 1019833:	41 bc 02 00 00 00    	mov    $0x2,%r12d
 1019839:	41 83 fe 02          	cmp    $0x2,%r14d
 101983d:	75 0d                	jne    101984c <entry_run+0x139c>
 101983f:	49 3b b5 e0 00 00 00 	cmp    0xe0(%r13),%rsi
 1019846:	0f 84 d4 04 00 00    	je     1019d20 <entry_run+0x1870>
 101984c:	49 8b 8d d8 00 00 00 	mov    0xd8(%r13),%rcx
 1019853:	48 85 c9             	test   %rcx,%rcx
 1019856:	74 7f                	je     10198d7 <entry_run+0x1427>
 1019858:	41 83 fc 01          	cmp    $0x1,%r12d
 101985c:	0f 84 08 04 00 00    	je     1019c6a <entry_run+0x17ba>
 1019862:	45 85 e4             	test   %r12d,%r12d
 1019865:	0f 85 85 04 00 00    	jne    1019cf0 <entry_run+0x1840>
 101986b:	49 89 f6             	mov    %rsi,%r14
 101986e:	4c 89 ef             	mov    %r13,%rdi
 1019871:	4c 89 ce             	mov    %r9,%rsi
 1019874:	e8 e7 9a 00 00       	call   1023360 <probe_text>
 1019879:	49 89 c7             	mov    %rax,%r15
 101987c:	49 83 ff ff          	cmp    $0xffffffffffffffff,%r15
 1019880:	75 6d                	jne    10198ef <entry_run+0x143f>
 1019882:	41 83 7d 24 00       	cmpl   $0x0,0x24(%r13)
 1019887:	0f 84 80 04 00 00    	je     1019d0d <entry_run+0x185d>
 101988d:	89 d0                	mov    %edx,%eax
 101988f:	83 f8 ff             	cmp    $0xffffffff,%eax
 1019892:	0f 84 75 04 00 00    	je     1019d0d <entry_run+0x185d>
 1019898:	4d 89 b5 e0 00 00 00 	mov    %r14,0xe0(%r13)
 101989f:	49 c7 85 e8 00 00 00 	movq   $0x0,0xe8(%r13)
 10198a6:	00 00 00 00 
 10198aa:	49 89 95 f0 00 00 00 	mov    %rdx,0xf0(%r13)
 10198b1:	41 c7 85 f8 00 00 00 	movl   $0x2,0xf8(%r13)
 10198b8:	02 00 00 00 
 10198bc:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
 10198c0:	c4 c1 78 11 85 fc 00 	vmovups %xmm0,0xfc(%r13)
 10198c7:	00 00 
 10198c9:	c4 c1 78 11 85 08 01 	vmovups %xmm0,0x108(%r13)
 10198d0:	00 00 
 10198d2:	e9 49 04 00 00       	jmp    1019d20 <entry_run+0x1870>
 10198d7:	49 89 f6             	mov    %rsi,%r14
 10198da:	4c 89 ef             	mov    %r13,%rdi
 10198dd:	48 8d 75 d0          	lea    -0x30(%rbp),%rsi
 10198e1:	e8 5a 99 00 00       	call   1023240 <probe_any>
 10198e6:	49 89 c7             	mov    %rax,%r15
 10198e9:	49 83 ff ff          	cmp    $0xffffffffffffffff,%r15
 10198ed:	74 93                	je     1019882 <entry_run+0x13d2>
 10198ef:	4d 89 b5 e0 00 00 00 	mov    %r14,0xe0(%r13)
 10198f6:	4d 89 bd e8 00 00 00 	mov    %r15,0xe8(%r13)
 10198fd:	49 c7 85 f0 00 00 00 	movq   $0x0,0xf0(%r13)
 1019904:	00 00 00 00 
 1019908:	41 c7 85 f8 00 00 00 	movl   $0x1,0xf8(%r13)
 101990f:	01 00 00 00 
 1019913:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
 1019917:	c4 c1 78 11 85 fc 00 	vmovups %xmm0,0xfc(%r13)
 101991e:	00 00 
 1019920:	c4 c1 78 11 85 08 01 	vmovups %xmm0,0x108(%r13)
 1019927:	00 00 
 1019929:	49 8b 45 f0          	mov    -0x10(%r13),%rax
 101992d:	49 8b 4d 00          	mov    0x0(%r13),%rcx
 1019931:	4d 0f af 7d 30       	imul   0x30(%r13),%r15
 1019936:	4c 03 79 20          	add    0x20(%rcx),%r15
 101993a:	4d 03 7d 18          	add    0x18(%r13),%r15
 101993e:	48 b9 02 00 00 00 00 	movabs $0x4000000000000002,%rcx
 1019945:	00 00 40 
 1019948:	48 83 c1 fe          	add    $0xfffffffffffffffe,%rcx
 101994c:	49 89 c4             	mov    %rax,%r12
 101994f:	49 c1 ec 28          	shr    $0x28,%r12
 1019953:	41 81 e4 ff ff 0f 00 	and    $0xfffff,%r12d
 101995a:	48 85 c8             	test   %rcx,%rax
 101995d:	b8 00 00 00 00       	mov    $0x0,%eax
 1019962:	44 0f 44 e0          	cmove  %eax,%r12d
 1019966:	48 8d 45 c0          	lea    -0x40(%rbp),%rax
 101996a:	49 39 c7             	cmp    %rax,%r15
 101996d:	74 17                	je     1019986 <entry_run+0x14d6>
 101996f:	4d 8b 75 10          	mov    0x10(%r13),%r14
 1019973:	41 83 7e 30 00       	cmpl   $0x0,0x30(%r14)
 1019978:	74 1c                	je     1019996 <entry_run+0x14e6>
 101997a:	48 8b 83 60 18 00 00 	mov    0x1860(%rbx),%rax
 1019981:	e9 cc 00 00 00       	jmp    1019a52 <entry_run+0x15a2>
 1019986:	4c 8d ab 58 02 00 00 	lea    0x258(%rbx),%r13
 101998d:	4c 8b 7d b8          	mov    -0x48(%rbp),%r15
 1019991:	e9 76 fa ff ff       	jmp    101940c <entry_run+0xf5c>
 1019996:	49 83 3e 08          	cmpq   $0x8,(%r14)
 101999a:	48 8b 83 60 18 00 00 	mov    0x1860(%rbx),%rax
 10199a1:	0f 85 ab 00 00 00    	jne    1019a52 <entry_run+0x15a2>
 10199a7:	48 85 c0             	test   %rax,%rax
 10199aa:	4c 8d ab 58 02 00 00 	lea    0x258(%rbx),%r13
 10199b1:	0f 84 49 01 00 00    	je     1019b00 <entry_run+0x1650>
 10199b7:	48 8b 48 40          	mov    0x40(%rax),%rcx
 10199bb:	48 85 c9             	test   %rcx,%rcx
 10199be:	0f 84 95 00 00 00    	je     1019a59 <entry_run+0x15a9>
 10199c4:	48 8b 50 30          	mov    0x30(%rax),%rdx
 10199c8:	4c 89 f6             	mov    %r14,%rsi
 10199cb:	48 c1 ee 03          	shr    $0x3,%rsi
 10199cf:	4c 89 f7             	mov    %r14,%rdi
 10199d2:	48 c1 ef 21          	shr    $0x21,%rdi
 10199d6:	48 31 f7             	xor    %rsi,%rdi
 10199d9:	48 be b9 e5 e4 1c 6d 	movabs $0xbf58476d1ce4e5b9,%rsi
 10199e0:	47 58 bf 
 10199e3:	48 0f af fe          	imul   %rsi,%rdi
 10199e7:	48 89 fe             	mov    %rdi,%rsi
 10199ea:	48 c1 ee 1b          	shr    $0x1b,%rsi
 10199ee:	48 31 fe             	xor    %rdi,%rsi
 10199f1:	48 83 f6 02          	xor    $0x2,%rsi
 10199f5:	48 ff c9             	dec    %rcx
 10199f8:	eb 09                	jmp    1019a03 <entry_run+0x1553>
 10199fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
 1019a00:	48 ff c6             	inc    %rsi
 1019a03:	48 21 ce             	and    %rcx,%rsi
 1019a06:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
 1019a0a:	48 8b 3c fa          	mov    (%rdx,%rdi,8),%rdi
 1019a0e:	48 85 ff             	test   %rdi,%rdi
 1019a11:	74 46                	je     1019a59 <entry_run+0x15a9>
 1019a13:	4c 39 f7             	cmp    %r14,%rdi
 1019a16:	75 e8                	jne    1019a00 <entry_run+0x1550>
 1019a18:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
 1019a1c:	83 7c fa 20 02       	cmpl   $0x2,0x20(%rdx,%rdi,8)
 1019a21:	75 dd                	jne    1019a00 <entry_run+0x1550>
 1019a23:	48 8d 0c fa          	lea    (%rdx,%rdi,8),%rcx
 1019a27:	48 8b 49 08          	mov    0x8(%rcx),%rcx
 1019a2b:	48 85 c9             	test   %rcx,%rcx
 1019a2e:	74 29                	je     1019a59 <entry_run+0x15a9>
 1019a30:	83 79 78 00          	cmpl   $0x0,0x78(%rcx)
 1019a34:	75 23                	jne    1019a59 <entry_run+0x15a9>
 1019a36:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
 1019a3b:	75 1c                	jne    1019a59 <entry_run+0x15a9>
 1019a3d:	44 3b a3 c8 02 00 00 	cmp    0x2c8(%rbx),%r12d
 1019a44:	77 13                	ja     1019a59 <entry_run+0x15a9>
 1019a46:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
 1019a4a:	49 89 07             	mov    %rax,(%r15)
 1019a4d:	e9 3b ff ff ff       	jmp    101998d <entry_run+0x14dd>
 1019a52:	4c 8d ab 58 02 00 00 	lea    0x258(%rbx),%r13
 1019a59:	48 85 c0             	test   %rax,%rax
 1019a5c:	0f 94 c1             	sete   %cl
 1019a5f:	4d 85 f6             	test   %r14,%r14
 1019a62:	0f 94 c2             	sete   %dl
 1019a65:	08 ca                	or     %cl,%dl
 1019a67:	0f 85 93 00 00 00    	jne    1019b00 <entry_run+0x1650>
 1019a6d:	48 8b 48 40          	mov    0x40(%rax),%rcx
 1019a71:	48 85 c9             	test   %rcx,%rcx
 1019a74:	0f 84 86 00 00 00    	je     1019b00 <entry_run+0x1650>
 1019a7a:	48 8b 50 30          	mov    0x30(%rax),%rdx
 1019a7e:	4c 89 f6             	mov    %r14,%rsi
 1019a81:	48 c1 ee 03          	shr    $0x3,%rsi
 1019a85:	4c 89 f7             	mov    %r14,%rdi
 1019a88:	48 c1 ef 21          	shr    $0x21,%rdi
 1019a8c:	48 31 f7             	xor    %rsi,%rdi
 1019a8f:	48 be b9 e5 e4 1c 6d 	movabs $0xbf58476d1ce4e5b9,%rsi
 1019a96:	47 58 bf 
 1019a99:	48 0f af fe          	imul   %rsi,%rdi
 1019a9d:	48 89 fe             	mov    %rdi,%rsi
 1019aa0:	48 c1 ee 1b          	shr    $0x1b,%rsi
 1019aa4:	48 31 fe             	xor    %rdi,%rsi
 1019aa7:	48 83 f6 02          	xor    $0x2,%rsi
 1019aab:	48 ff c9             	dec    %rcx
 1019aae:	eb 03                	jmp    1019ab3 <entry_run+0x1603>
 1019ab0:	48 ff c6             	inc    %rsi
 1019ab3:	48 21 ce             	and    %rcx,%rsi
 1019ab6:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
 1019aba:	48 8b 3c fa          	mov    (%rdx,%rdi,8),%rdi
 1019abe:	48 85 ff             	test   %rdi,%rdi
 1019ac1:	74 3d                	je     1019b00 <entry_run+0x1650>
 1019ac3:	4c 39 f7             	cmp    %r14,%rdi
 1019ac6:	75 e8                	jne    1019ab0 <entry_run+0x1600>
 1019ac8:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
 1019acc:	83 7c fa 20 02       	cmpl   $0x2,0x20(%rdx,%rdi,8)
 1019ad1:	75 dd                	jne    1019ab0 <entry_run+0x1600>
 1019ad3:	48 8d 0c fa          	lea    (%rdx,%rdi,8),%rcx
 1019ad7:	48 8b 49 08          	mov    0x8(%rcx),%rcx
 1019adb:	48 85 c9             	test   %rcx,%rcx
 1019ade:	74 20                	je     1019b00 <entry_run+0x1650>
 1019ae0:	83 79 78 00          	cmpl   $0x0,0x78(%rcx)
 1019ae4:	75 1a                	jne    1019b00 <entry_run+0x1650>
 1019ae6:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
 1019aeb:	0f 84 d6 04 00 00    	je     1019fc7 <entry_run+0x1b17>
 1019af1:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1019af8:	0f 1f 84 00 00 00 00 
 1019aff:	00 
 1019b00:	49 8b 06             	mov    (%r14),%rax
 1019b03:	4c 8d ad 40 fc ff ff 	lea    -0x3c0(%rbp),%r13
 1019b0a:	48 3d 81 00 00 00    	cmp    $0x81,%rax
 1019b10:	72 6f                	jb     1019b81 <entry_run+0x16d1>
 1019b12:	48 c7 85 d8 fc ff ff 	movq   $0x0,-0x328(%rbp)
 1019b19:	00 00 00 00 
 1019b1d:	48 c7 85 f0 fc ff ff 	movq   $0x100c898,-0x310(%rbp)
 1019b24:	98 c8 00 01 
 1019b28:	48 89 85 f8 fc ff ff 	mov    %rax,-0x308(%rbp)
 1019b2f:	48 c7 85 00 fd ff ff 	movq   $0x0,-0x300(%rbp)
 1019b36:	00 00 00 00 
 1019b3a:	48 8d bb 58 02 00 00 	lea    0x258(%rbx),%rdi
 1019b41:	48 8d b5 f0 fc ff ff 	lea    -0x310(%rbp),%rsi
 1019b48:	48 8d 95 d8 fc ff ff 	lea    -0x328(%rbp),%rdx
 1019b4f:	e8 ec c2 00 00       	call   1025e40 <myl_rc_new>
 1019b54:	85 c0                	test   %eax,%eax
 1019b56:	74 19                	je     1019b71 <entry_run+0x16c1>
 1019b58:	48 8b 8b 60 18 00 00 	mov    0x1860(%rbx),%rcx
 1019b5f:	48 85 c9             	test   %rcx,%rcx
 1019b62:	0f 84 53 0f 00 00    	je     101aabb <entry_run+0x260b>
 1019b68:	83 79 78 00          	cmpl   $0x0,0x78(%rcx)
 1019b6c:	75 03                	jne    1019b71 <entry_run+0x16c1>
 1019b6e:	89 41 78             	mov    %eax,0x78(%rcx)
 1019b71:	4c 8b ad d8 fc ff ff 	mov    -0x328(%rbp),%r13
 1019b78:	4d 85 ed             	test   %r13,%r13
 1019b7b:	0f 84 bf 01 00 00    	je     1019d40 <entry_run+0x1890>
 1019b81:	48 8d bb 58 02 00 00 	lea    0x258(%rbx),%rdi
 1019b88:	4c 89 f6             	mov    %r14,%rsi
 1019b8b:	4c 89 ea             	mov    %r13,%rdx
 1019b8e:	48 8d 4d c0          	lea    -0x40(%rbp),%rcx
 1019b92:	45 89 e0             	mov    %r12d,%r8d
 1019b95:	e8 16 4d 01 00       	call   102e8b0 <myl_rc_native_retain>
 1019b9a:	85 c0                	test   %eax,%eax
 1019b9c:	74 43                	je     1019be1 <entry_run+0x1731>
 1019b9e:	41 89 c4             	mov    %eax,%r12d
 1019ba1:	49 83 3e 00          	cmpq   $0x0,(%r14)
 1019ba5:	74 25                	je     1019bcc <entry_run+0x171c>
 1019ba7:	31 c0                	xor    %eax,%eax
 1019ba9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
 1019bb0:	41 0f b6 0c 07       	movzbl (%r15,%rax,1),%ecx
 1019bb5:	41 0f b6 54 05 00    	movzbl 0x0(%r13,%rax,1),%edx
 1019bbb:	41 88 14 07          	mov    %dl,(%r15,%rax,1)
 1019bbf:	41 88 4c 05 00       	mov    %cl,0x0(%r13,%rax,1)
 1019bc4:	48 ff c0             	inc    %rax
 1019bc7:	49 3b 06             	cmp    (%r14),%rax
 1019bca:	72 e4                	jb     1019bb0 <entry_run+0x1700>
 1019bcc:	48 8d bb 58 02 00 00 	lea    0x258(%rbx),%rdi
 1019bd3:	4c 89 f6             	mov    %r14,%rsi
 1019bd6:	4c 89 ea             	mov    %r13,%rdx
 1019bd9:	e8 52 45 01 00       	call   102e130 <myl_rc_native_drop>
 1019bde:	44 89 e0             	mov    %r12d,%eax
 1019be1:	48 8d 8d 40 fc ff ff 	lea    -0x3c0(%rbp),%rcx
 1019be8:	49 39 cd             	cmp    %rcx,%r13
 1019beb:	4c 8b 7d b8          	mov    -0x48(%rbp),%r15
 1019bef:	0f 84 08 f8 ff ff    	je     10193fd <entry_run+0xf4d>
 1019bf5:	41 89 c6             	mov    %eax,%r14d
 1019bf8:	49 8b 45 f0          	mov    -0x10(%r13),%rax
 1019bfc:	48 b9 02 00 00 00 00 	movabs $0x4000000000000002,%rcx
 1019c03:	00 00 40 
 1019c06:	48 85 c8             	test   %rcx,%rax
 1019c09:	75 4b                	jne    1019c56 <entry_run+0x17a6>
 1019c0b:	48 8b 8b 60 18 00 00 	mov    0x1860(%rbx),%rcx
 1019c12:	48 85 c9             	test   %rcx,%rcx
 1019c15:	0f 84 a0 0e 00 00    	je     101aabb <entry_run+0x260b>
 1019c1b:	a8 01                	test   $0x1,%al
 1019c1d:	0f 85 98 0e 00 00    	jne    101aabb <entry_run+0x260b>
 1019c23:	49 8d 55 e0          	lea    -0x20(%r13),%rdx
 1019c27:	48 8b 32             	mov    (%rdx),%rsi
 1019c2a:	48 85 f6             	test   %rsi,%rsi
 1019c2d:	0f 84 88 0e 00 00    	je     101aabb <entry_run+0x260b>
 1019c33:	48 ff ce             	dec    %rsi
 1019c36:	48 89 32             	mov    %rsi,(%rdx)
 1019c39:	75 1b                	jne    1019c56 <entry_run+0x17a6>
 1019c3b:	49 83 7d e8 00       	cmpq   $0x0,-0x18(%r13)
 1019c40:	75 14                	jne    1019c56 <entry_run+0x17a6>
 1019c42:	48 83 c8 01          	or     $0x1,%rax
 1019c46:	49 89 45 f0          	mov    %rax,-0x10(%r13)
 1019c4a:	48 8b 41 60          	mov    0x60(%rcx),%rax
 1019c4e:	49 89 45 e0          	mov    %rax,-0x20(%r13)
 1019c52:	48 89 51 60          	mov    %rdx,0x60(%rcx)
 1019c56:	48 8d bb 58 02 00 00 	lea    0x258(%rbx),%rdi
 1019c5d:	e8 1e e5 00 00       	call   1028180 <myl_rc_drain>
 1019c62:	44 89 f0             	mov    %r14d,%eax
 1019c65:	e9 93 f7 ff ff       	jmp    10193fd <entry_run+0xf4d>
 1019c6a:	48 89 f2             	mov    %rsi,%rdx
 1019c6d:	48 b8 15 7c 4a 7f b9 	movabs $0x9e3779b97f4a7c15,%rax
 1019c74:	79 37 9e 
 1019c77:	48 31 c2             	xor    %rax,%rdx
 1019c7a:	48 b8 b9 e5 e4 1c 6d 	movabs $0xbf58476d1ce4e5b9,%rax
 1019c81:	47 58 bf 
 1019c84:	c4 e2 fb f6 f8       	mulx   %rax,%rax,%rdi
 1019c89:	48 31 c7             	xor    %rax,%rdi
 1019c8c:	48 89 fa             	mov    %rdi,%rdx
 1019c8f:	48 c1 ea 20          	shr    $0x20,%rdx
 1019c93:	48 31 fa             	xor    %rdi,%rdx
 1019c96:	4d 8b 9d d0 00 00 00 	mov    0xd0(%r13),%r11
 1019c9d:	48 ff c9             	dec    %rcx
 1019ca0:	89 c8                	mov    %ecx,%eax
 1019ca2:	21 d0                	and    %edx,%eax
 1019ca4:	4d 8b 0c c3          	mov    (%r11,%rax,8),%r9
 1019ca8:	4d 85 c9             	test   %r9,%r9
 1019cab:	0f 84 b5 00 00 00    	je     1019d66 <entry_run+0x18b6>
 1019cb1:	4d 8b 45 00          	mov    0x0(%r13),%r8
 1019cb5:	49 8b 7d 30          	mov    0x30(%r13),%rdi
 1019cb9:	4d 8b 40 20          	mov    0x20(%r8),%r8
 1019cbd:	eb 10                	jmp    1019ccf <entry_run+0x181f>
 1019cbf:	90                   	nop
 1019cc0:	48 ff c0             	inc    %rax
 1019cc3:	48 21 c8             	and    %rcx,%rax
 1019cc6:	4d 8b 0c c3          	mov    (%r11,%rax,8),%r9
 1019cca:	4d 85 c9             	test   %r9,%r9
 1019ccd:	74 75                	je     1019d44 <entry_run+0x1894>
 1019ccf:	4d 89 ca             	mov    %r9,%r10
 1019cd2:	49 c1 ea 20          	shr    $0x20,%r10
 1019cd6:	44 39 d2             	cmp    %r10d,%edx
 1019cd9:	75 e5                	jne    1019cc0 <entry_run+0x1810>
 1019cdb:	45 89 cf             	mov    %r9d,%r15d
 1019cde:	49 ff cf             	dec    %r15
 1019ce1:	4d 89 f9             	mov    %r15,%r9
 1019ce4:	4c 0f af cf          	imul   %rdi,%r9
 1019ce8:	4b 39 34 08          	cmp    %rsi,(%r8,%r9,1)
 1019cec:	75 d2                	jne    1019cc0 <entry_run+0x1810>
 1019cee:	eb 5b                	jmp    1019d4b <entry_run+0x189b>
 1019cf0:	4c 89 ef             	mov    %r13,%rdi
 1019cf3:	49 89 f6             	mov    %rsi,%r14
 1019cf6:	e8 05 98 00 00       	call   1023500 <probe_scalar>
 1019cfb:	49 89 c7             	mov    %rax,%r15
 1019cfe:	49 83 ff ff          	cmp    $0xffffffffffffffff,%r15
 1019d02:	0f 85 e7 fb ff ff    	jne    10198ef <entry_run+0x143f>
 1019d08:	e9 75 fb ff ff       	jmp    1019882 <entry_run+0x13d2>
 1019d0d:	41 c7 85 f8 00 00 00 	movl   $0x0,0xf8(%r13)
 1019d14:	00 00 00 00 
 1019d18:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
 1019d1f:	00 
 1019d20:	48 8d bb 58 02 00 00 	lea    0x258(%rbx),%rdi
 1019d27:	4c 89 ee             	mov    %r13,%rsi
 1019d2a:	48 8d 55 d0          	lea    -0x30(%rbp),%rdx
 1019d2e:	48 8d 4d c0          	lea    -0x40(%rbp),%rcx
 1019d32:	e8 49 75 00 00       	call   1021280 <rc_insert_result>
 1019d37:	4c 8b 7d b8          	mov    -0x48(%rbp),%r15
 1019d3b:	e9 bd f6 ff ff       	jmp    10193fd <entry_run+0xf4d>
 1019d40:	31 c0                	xor    %eax,%eax
 1019d42:	eb f3                	jmp    1019d37 <entry_run+0x1887>
 1019d44:	49 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%r15
 1019d4b:	49 89 f6             	mov    %rsi,%r14
 1019d4e:	89 c0                	mov    %eax,%eax
 1019d50:	48 c1 e2 20          	shl    $0x20,%rdx
 1019d54:	48 09 c2             	or     %rax,%rdx
 1019d57:	49 83 ff ff          	cmp    $0xffffffffffffffff,%r15
 1019d5b:	0f 85 8e fb ff ff    	jne    10198ef <entry_run+0x143f>
 1019d61:	e9 1c fb ff ff       	jmp    1019882 <entry_run+0x13d2>
 1019d66:	49 89 f6             	mov    %rsi,%r14
 1019d69:	49 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%r15
 1019d70:	48 c1 e2 20          	shl    $0x20,%rdx
 1019d74:	48 09 c2             	or     %rax,%rdx
 1019d77:	49 83 ff ff          	cmp    $0xffffffffffffffff,%r15
 1019d7b:	0f 85 6e fb ff ff    	jne    10198ef <entry_run+0x143f>
 1019d81:	e9 fc fa ff ff       	jmp    1019882 <entry_run+0x13d2>
 1019d86:	41 0f b7 f1          	movzwl %r9w,%esi
 1019d8a:	e9 a4 fa ff ff       	jmp    1019833 <entry_run+0x1383>
 1019d8f:	44 89 ce             	mov    %r9d,%esi
 1019d92:	e9 9c fa ff ff       	jmp    1019833 <entry_run+0x1383>
 1019d97:	49 8b 02             	mov    (%r10),%rax
 1019d9a:	e9 da 00 00 00       	jmp    1019e79 <entry_run+0x19c9>
 1019d9f:	49 8b 45 08          	mov    0x8(%r13),%rax
 1019da3:	48 8b 10             	mov    (%rax),%rdx
 1019da6:	48 c7 85 40 fc ff ff 	movq   $0x0,-0x3c0(%rbp)
 1019dad:	00 00 00 00 
 1019db1:	f3 48 0f b8 c2       	popcnt %rdx,%rax
 1019db6:	83 f8 01             	cmp    $0x1,%eax
 1019db9:	0f 85 89 00 00 00    	jne    1019e48 <entry_run+0x1998>
 1019dbf:	f3 48 0f bc c2       	tzcnt  %rdx,%rax
 1019dc4:	48 83 f8 03          	cmp    $0x3,%rax
 1019dc8:	77 7e                	ja     1019e48 <entry_run+0x1998>
 1019dca:	4d 89 f7             	mov    %r14,%r15
 1019dcd:	ff 24 c5 b8 96 00 01 	jmp    *0x10096b8(,%rax,8)
 1019dd4:	41 0f b6 02          	movzbl (%r10),%eax
 1019dd8:	e9 9f 00 00 00       	jmp    1019e7c <entry_run+0x19cc>
 1019ddd:	4d 89 f7             	mov    %r14,%r15
 1019de0:	48 8b 45 b0          	mov    -0x50(%rbp),%rax
 1019de4:	e9 93 00 00 00       	jmp    1019e7c <entry_run+0x19cc>
 1019de9:	41 0f b7 c9          	movzwl %r9w,%ecx
 1019ded:	e9 1e f8 ff ff       	jmp    1019610 <entry_run+0x1160>
 1019df2:	44 89 c9             	mov    %r9d,%ecx
 1019df5:	e9 16 f8 ff ff       	jmp    1019610 <entry_run+0x1160>
 1019dfa:	49 8b 49 18          	mov    0x18(%r9),%rcx
 1019dfe:	41 8b 51 14          	mov    0x14(%r9),%edx
 1019e02:	48 01 d1             	add    %rdx,%rcx
 1019e05:	48 83 c1 18          	add    $0x18,%rcx
 1019e09:	48 8b 50 08          	mov    0x8(%rax),%rdx
 1019e0d:	45 31 e4             	xor    %r12d,%r12d
 1019e10:	49 3b 51 08          	cmp    0x8(%r9),%rdx
 1019e14:	0f 85 ac 00 00 00    	jne    1019ec6 <entry_run+0x1a16>
 1019e1a:	48 83 fa 08          	cmp    $0x8,%rdx
 1019e1e:	72 7f                	jb     1019e9f <entry_run+0x19ef>
 1019e20:	31 f6                	xor    %esi,%esi
 1019e22:	48 8d 7e 08          	lea    0x8(%rsi),%rdi
 1019e26:	48 39 d7             	cmp    %rdx,%rdi
 1019e29:	0f 83 f7 00 00 00    	jae    1019f26 <entry_run+0x1a76>
 1019e2f:	4c 8b 44 30 18       	mov    0x18(%rax,%rsi,1),%r8
 1019e34:	45 31 e4             	xor    %r12d,%r12d
 1019e37:	4c 3b 04 31          	cmp    (%rcx,%rsi,1),%r8
 1019e3b:	48 89 fe             	mov    %rdi,%rsi
 1019e3e:	74 e2                	je     1019e22 <entry_run+0x1972>
 1019e40:	4c 89 ce             	mov    %r9,%rsi
 1019e43:	e9 f1 f9 ff ff       	jmp    1019839 <entry_run+0x1389>
 1019e48:	48 83 fa 08          	cmp    $0x8,%rdx
 1019e4c:	b8 08 00 00 00       	mov    $0x8,%eax
 1019e51:	48 0f 43 d0          	cmovae %rax,%rdx
 1019e55:	48 89 7d b8          	mov    %rdi,-0x48(%rbp)
 1019e59:	48 8d bd 40 fc ff ff 	lea    -0x3c0(%rbp),%rdi
 1019e60:	4c 89 d6             	mov    %r10,%rsi
 1019e63:	4d 89 d7             	mov    %r10,%r15
 1019e66:	e8 f5 81 01 00       	call   1032060 <memcpy@plt>
 1019e6b:	48 8b 7d b8          	mov    -0x48(%rbp),%rdi
 1019e6f:	4d 89 fa             	mov    %r15,%r10
 1019e72:	48 8b 85 40 fc ff ff 	mov    -0x3c0(%rbp),%rax
 1019e79:	4d 89 f7             	mov    %r14,%r15
 1019e7c:	48 89 45 b0          	mov    %rax,-0x50(%rbp)
 1019e80:	48 39 f8             	cmp    %rdi,%rax
 1019e83:	0f 85 5d f5 ff ff    	jne    10193e6 <entry_run+0xf36>
 1019e89:	e9 ee 01 00 00       	jmp    101a07c <entry_run+0x1bcc>
 1019e8e:	41 0f b7 f9          	movzwl %r9w,%edi
 1019e92:	e9 f4 f7 ff ff       	jmp    101968b <entry_run+0x11db>
 1019e97:	44 89 cf             	mov    %r9d,%edi
 1019e9a:	e9 ec f7 ff ff       	jmp    101968b <entry_run+0x11db>
 1019e9f:	48 83 fa 03          	cmp    $0x3,%rdx
 1019ea3:	0f 86 98 00 00 00    	jbe    1019f41 <entry_run+0x1a91>
 1019ea9:	8b 70 18             	mov    0x18(%rax),%esi
 1019eac:	3b 31                	cmp    (%rcx),%esi
 1019eae:	75 16                	jne    1019ec6 <entry_run+0x1a16>
 1019eb0:	8b 4c 11 fc          	mov    -0x4(%rcx,%rdx,1),%ecx
 1019eb4:	4c 89 ce             	mov    %r9,%rsi
 1019eb7:	39 4c 10 14          	cmp    %ecx,0x14(%rax,%rdx,1)
 1019ebb:	0f 84 68 fa ff ff    	je     1019929 <entry_run+0x1479>
 1019ec1:	e9 86 f9 ff ff       	jmp    101984c <entry_run+0x139c>
 1019ec6:	4c 89 ce             	mov    %r9,%rsi
 1019ec9:	e9 7e f9 ff ff       	jmp    101984c <entry_run+0x139c>
 1019ece:	49 8b 49 18          	mov    0x18(%r9),%rcx
 1019ed2:	41 8b 51 14          	mov    0x14(%r9),%edx
 1019ed6:	48 01 d1             	add    %rdx,%rcx
 1019ed9:	48 83 c1 18          	add    $0x18,%rcx
 1019edd:	48 8b 50 08          	mov    0x8(%rax),%rdx
 1019ee1:	49 3b 51 08          	cmp    0x8(%r9),%rdx
 1019ee5:	0f 85 fb f4 ff ff    	jne    10193e6 <entry_run+0xf36>
 1019eeb:	48 83 fa 08          	cmp    $0x8,%rdx
 1019eef:	0f 82 a6 00 00 00    	jb     1019f9b <entry_run+0x1aeb>
 1019ef5:	31 f6                	xor    %esi,%esi
 1019ef7:	48 8d 7e 08          	lea    0x8(%rsi),%rdi
 1019efb:	48 39 d7             	cmp    %rdx,%rdi
 1019efe:	0f 83 0e 01 00 00    	jae    101a012 <entry_run+0x1b62>
 1019f04:	4c 8b 44 30 18       	mov    0x18(%rax,%rsi,1),%r8
 1019f09:	4c 3b 04 31          	cmp    (%rcx,%rsi,1),%r8
 1019f0d:	48 89 fe             	mov    %rdi,%rsi
 1019f10:	74 e5                	je     1019ef7 <entry_run+0x1a47>
 1019f12:	e9 cf f4 ff ff       	jmp    10193e6 <entry_run+0xf36>
 1019f17:	8b 06                	mov    (%rsi),%eax
 1019f19:	e9 66 f8 ff ff       	jmp    1019784 <entry_run+0x12d4>
 1019f1e:	0f b7 06             	movzwl (%rsi),%eax
 1019f21:	e9 5e f8 ff ff       	jmp    1019784 <entry_run+0x12d4>
 1019f26:	48 8b 44 10 10       	mov    0x10(%rax,%rdx,1),%rax
 1019f2b:	45 31 e4             	xor    %r12d,%r12d
 1019f2e:	4c 89 ce             	mov    %r9,%rsi
 1019f31:	48 3b 44 11 f8       	cmp    -0x8(%rcx,%rdx,1),%rax
 1019f36:	0f 85 fd f8 ff ff    	jne    1019839 <entry_run+0x1389>
 1019f3c:	e9 e8 f9 ff ff       	jmp    1019929 <entry_run+0x1479>
 1019f41:	48 85 d2             	test   %rdx,%rdx
 1019f44:	0f 84 df f9 ff ff    	je     1019929 <entry_run+0x1479>
 1019f4a:	0f b6 70 18          	movzbl 0x18(%rax),%esi
 1019f4e:	40 3a 31             	cmp    (%rcx),%sil
 1019f51:	41 0f 94 c2          	sete   %r10b
 1019f55:	40 0f 95 c7          	setne  %dil
 1019f59:	48 83 fa 01          	cmp    $0x1,%rdx
 1019f5d:	41 0f 94 c0          	sete   %r8b
 1019f61:	41 08 f8             	or     %dil,%r8b
 1019f64:	0f 85 97 00 00 00    	jne    101a001 <entry_run+0x1b51>
 1019f6a:	0f b6 70 19          	movzbl 0x19(%rax),%esi
 1019f6e:	40 3a 71 01          	cmp    0x1(%rcx),%sil
 1019f72:	41 0f 94 c2          	sete   %r10b
 1019f76:	40 0f 95 c7          	setne  %dil
 1019f7a:	48 83 fa 02          	cmp    $0x2,%rdx
 1019f7e:	0f 94 c2             	sete   %dl
 1019f81:	40 08 fa             	or     %dil,%dl
 1019f84:	75 7b                	jne    101a001 <entry_run+0x1b51>
 1019f86:	0f b6 40 1a          	movzbl 0x1a(%rax),%eax
 1019f8a:	4c 89 ce             	mov    %r9,%rsi
 1019f8d:	3a 41 02             	cmp    0x2(%rcx),%al
 1019f90:	0f 85 b6 f8 ff ff    	jne    101984c <entry_run+0x139c>
 1019f96:	e9 8e f9 ff ff       	jmp    1019929 <entry_run+0x1479>
 1019f9b:	48 83 fa 03          	cmp    $0x3,%rdx
 1019f9f:	0f 86 83 00 00 00    	jbe    101a028 <entry_run+0x1b78>
 1019fa5:	8b 70 18             	mov    0x18(%rax),%esi
 1019fa8:	3b 31                	cmp    (%rcx),%esi
 1019faa:	0f 85 36 f4 ff ff    	jne    10193e6 <entry_run+0xf36>
 1019fb0:	8b 4c 11 fc          	mov    -0x4(%rcx,%rdx,1),%ecx
 1019fb4:	48 8b 7d b0          	mov    -0x50(%rbp),%rdi
 1019fb8:	39 4c 10 14          	cmp    %ecx,0x14(%rax,%rdx,1)
 1019fbc:	0f 84 ba 00 00 00    	je     101a07c <entry_run+0x1bcc>
 1019fc2:	e9 1f f4 ff ff       	jmp    10193e6 <entry_run+0xf36>
 1019fc7:	44 3b a3 c8 02 00 00 	cmp    0x2c8(%rbx),%r12d
 1019fce:	0f 87 67 0b 00 00    	ja     101ab3b <entry_run+0x268b>
 1019fd4:	49 8b 16             	mov    (%r14),%rdx
 1019fd7:	4c 89 ff             	mov    %r15,%rdi
 1019fda:	48 8d 75 c0          	lea    -0x40(%rbp),%rsi
 1019fde:	e8 ed 81 01 00       	call   10321d0 <memmove@plt>
 1019fe3:	e9 a5 f9 ff ff       	jmp    101998d <entry_run+0x14dd>
 1019fe8:	41 8b 02             	mov    (%r10),%eax
 1019feb:	e9 8c fe ff ff       	jmp    1019e7c <entry_run+0x19cc>
 1019ff0:	49 8b 02             	mov    (%r10),%rax
 1019ff3:	e9 84 fe ff ff       	jmp    1019e7c <entry_run+0x19cc>
 1019ff8:	41 0f b7 02          	movzwl (%r10),%eax
 1019ffc:	e9 7b fe ff ff       	jmp    1019e7c <entry_run+0x19cc>
 101a001:	4c 89 ce             	mov    %r9,%rsi
 101a004:	45 84 d2             	test   %r10b,%r10b
 101a007:	0f 84 3f f8 ff ff    	je     101984c <entry_run+0x139c>
 101a00d:	e9 17 f9 ff ff       	jmp    1019929 <entry_run+0x1479>
 101a012:	48 8b 44 10 10       	mov    0x10(%rax,%rdx,1),%rax
 101a017:	48 8b 7d b0          	mov    -0x50(%rbp),%rdi
 101a01b:	48 3b 44 11 f8       	cmp    -0x8(%rcx,%rdx,1),%rax
 101a020:	0f 85 c0 f3 ff ff    	jne    10193e6 <entry_run+0xf36>
 101a026:	eb 54                	jmp    101a07c <entry_run+0x1bcc>
 101a028:	48 85 d2             	test   %rdx,%rdx
 101a02b:	74 4b                	je     101a078 <entry_run+0x1bc8>
 101a02d:	0f b6 70 18          	movzbl 0x18(%rax),%esi
 101a031:	40 3a 31             	cmp    (%rcx),%sil
 101a034:	40 0f 94 c6          	sete   %sil
 101a038:	40 0f 95 c7          	setne  %dil
 101a03c:	48 83 fa 01          	cmp    $0x1,%rdx
 101a040:	41 0f 94 c0          	sete   %r8b
 101a044:	41 08 f8             	or     %dil,%r8b
 101a047:	75 76                	jne    101a0bf <entry_run+0x1c0f>
 101a049:	0f b6 70 19          	movzbl 0x19(%rax),%esi
 101a04d:	40 3a 71 01          	cmp    0x1(%rcx),%sil
 101a051:	40 0f 94 c6          	sete   %sil
 101a055:	40 0f 95 c7          	setne  %dil
 101a059:	48 83 fa 02          	cmp    $0x2,%rdx
 101a05d:	0f 94 c2             	sete   %dl
 101a060:	40 08 fa             	or     %dil,%dl
 101a063:	75 5a                	jne    101a0bf <entry_run+0x1c0f>
 101a065:	0f b6 40 1a          	movzbl 0x1a(%rax),%eax
 101a069:	48 8b 7d b0          	mov    -0x50(%rbp),%rdi
 101a06d:	3a 41 02             	cmp    0x2(%rcx),%al
 101a070:	0f 85 70 f3 ff ff    	jne    10193e6 <entry_run+0xf36>
 101a076:	eb 04                	jmp    101a07c <entry_run+0x1bcc>
 101a078:	48 8b 7d b0          	mov    -0x50(%rbp),%rdi
 101a07c:	4d 03 55 18          	add    0x18(%r13),%r10
 101a080:	49 8b 45 10          	mov    0x10(%r13),%rax
 101a084:	48 8b 10             	mov    (%rax),%rdx
 101a087:	48 83 fa 08          	cmp    $0x8,%rdx
 101a08b:	75 13                	jne    101a0a0 <entry_run+0x1bf0>
 101a08d:	4d 89 22             	mov    %r12,(%r10)
 101a090:	48 89 7d b0          	mov    %rdi,-0x50(%rbp)
 101a094:	4c 8d ab 58 02 00 00 	lea    0x258(%rbx),%r13
 101a09b:	e9 6c f3 ff ff       	jmp    101940c <entry_run+0xf5c>
 101a0a0:	49 89 fe             	mov    %rdi,%r14
 101a0a3:	4c 89 d7             	mov    %r10,%rdi
 101a0a6:	48 8d 75 c0          	lea    -0x40(%rbp),%rsi
 101a0aa:	e8 21 81 01 00       	call   10321d0 <memmove@plt>
 101a0af:	4c 89 75 b0          	mov    %r14,-0x50(%rbp)
 101a0b3:	4c 8d ab 58 02 00 00 	lea    0x258(%rbx),%r13
 101a0ba:	e9 4d f3 ff ff       	jmp    101940c <entry_run+0xf5c>
 101a0bf:	48 8b 7d b0          	mov    -0x50(%rbp),%rdi
 101a0c3:	40 84 f6             	test   %sil,%sil
 101a0c6:	0f 84 1a f3 ff ff    	je     10193e6 <entry_run+0xf36>
 101a0cc:	eb ae                	jmp    101a07c <entry_run+0x1bcc>
 101a0ce:	48 c7 45 d0 00 00 00 	movq   $0x0,-0x30(%rbp)
 101a0d5:	00 
 101a0d6:	48 8b 45 a0          	mov    -0x60(%rbp),%rax
 101a0da:	83 bd 68 fd ff ff 08 	cmpl   $0x8,-0x298(%rbp)
 101a0e1:	0f 85 d6 00 00 00    	jne    101a1bd <entry_run+0x1d0d>
 101a0e7:	8b 8d 38 ff ff ff    	mov    -0xc8(%rbp),%ecx
 101a0ed:	83 e1 01             	and    $0x1,%ecx
 101a0f0:	0f 84 c7 00 00 00    	je     101a1bd <entry_run+0x1d0d>
 101a0f6:	48 c7 45 c8 00 00 00 	movq   $0x0,-0x38(%rbp)
 101a0fd:	00 
 101a0fe:	48 85 c0             	test   %rax,%rax
 101a101:	74 4c                	je     101a14f <entry_run+0x1c9f>
 101a103:	48 8b 48 f0          	mov    -0x10(%rax),%rcx
 101a107:	48 ba 02 00 00 00 00 	movabs $0x4000000000000002,%rdx
 101a10e:	00 00 40 
 101a111:	48 85 d1             	test   %rdx,%rcx
 101a114:	75 39                	jne    101a14f <entry_run+0x1c9f>
 101a116:	48 83 bb 60 18 00 00 	cmpq   $0x0,0x1860(%rbx)
 101a11d:	00 
 101a11e:	0f 84 97 09 00 00    	je     101aabb <entry_run+0x260b>
 101a124:	f6 c1 01             	test   $0x1,%cl
 101a127:	0f 85 8e 09 00 00    	jne    101aabb <entry_run+0x260b>
 101a12d:	48 8b 48 e8          	mov    -0x18(%rax),%rcx
 101a131:	48 8b 50 e0          	mov    -0x20(%rax),%rdx
 101a135:	48 09 ca             	or     %rcx,%rdx
 101a138:	0f 84 7d 09 00 00    	je     101aabb <entry_run+0x260b>
 101a13e:	48 83 f9 ff          	cmp    $0xffffffffffffffff,%rcx
 101a142:	0f 84 e3 04 00 00    	je     101a62b <entry_run+0x217b>
 101a148:	48 ff c1             	inc    %rcx
 101a14b:	48 89 48 e8          	mov    %rcx,-0x18(%rax)
 101a14f:	48 c7 85 90 fe ff ff 	movq   $0x1009fd0,-0x170(%rbp)
 101a156:	d0 9f 00 01 
 101a15a:	48 8d 4d c8          	lea    -0x38(%rbp),%rcx
 101a15e:	48 89 8d 98 fe ff ff 	mov    %rcx,-0x168(%rbp)
 101a165:	48 8d 4d 88          	lea    -0x78(%rbp),%rcx
 101a169:	48 89 8d a0 fe ff ff 	mov    %rcx,-0x160(%rbp)
 101a170:	c7 85 a8 fe ff ff 08 	movl   $0x8,-0x158(%rbp)
 101a177:	00 00 00 
 101a17a:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
 101a17e:	48 c7 85 30 fe ff ff 	movq   $0x1009fd0,-0x1d0(%rbp)
 101a185:	d0 9f 00 01 
 101a189:	48 8d 4d a8          	lea    -0x58(%rbp),%rcx
 101a18d:	48 89 8d 38 fe ff ff 	mov    %rcx,-0x1c8(%rbp)
 101a194:	48 8d 8d 70 ff ff ff 	lea    -0x90(%rbp),%rcx
 101a19b:	48 89 8d 40 fe ff ff 	mov    %rcx,-0x1c0(%rbp)
 101a1a2:	c7 85 48 fe ff ff 08 	movl   $0x8,-0x1b8(%rbp)
 101a1a9:	00 00 00 
 101a1ac:	c7 85 70 ff ff ff 01 	movl   $0x1,-0x90(%rbp)
 101a1b3:	00 00 00 
 101a1b6:	c7 45 88 00 00 00 00 	movl   $0x0,-0x78(%rbp)
 101a1bd:	48 89 45 d0          	mov    %rax,-0x30(%rbp)
 101a1c1:	48 c7 45 c8 00 00 00 	movq   $0x0,-0x38(%rbp)
 101a1c8:	00 
 101a1c9:	48 85 c0             	test   %rax,%rax
 101a1cc:	74 4c                	je     101a21a <entry_run+0x1d6a>
 101a1ce:	48 8b 48 f0          	mov    -0x10(%rax),%rcx
 101a1d2:	48 ba 02 00 00 00 00 	movabs $0x4000000000000002,%rdx
 101a1d9:	00 00 40 
 101a1dc:	48 85 d1             	test   %rdx,%rcx
 101a1df:	75 39                	jne    101a21a <entry_run+0x1d6a>
 101a1e1:	48 83 bb 60 18 00 00 	cmpq   $0x0,0x1860(%rbx)
 101a1e8:	00 
 101a1e9:	0f 84 cc 08 00 00    	je     101aabb <entry_run+0x260b>
 101a1ef:	f6 c1 01             	test   $0x1,%cl
 101a1f2:	0f 85 c3 08 00 00    	jne    101aabb <entry_run+0x260b>
 101a1f8:	48 8b 48 e8          	mov    -0x18(%rax),%rcx
 101a1fc:	48 8b 50 e0          	mov    -0x20(%rax),%rdx
 101a200:	48 09 ca             	or     %rcx,%rdx
 101a203:	0f 84 b2 08 00 00    	je     101aabb <entry_run+0x260b>
 101a209:	48 83 f9 ff          	cmp    $0xffffffffffffffff,%rcx
 101a20d:	0f 84 18 04 00 00    	je     101a62b <entry_run+0x217b>
 101a213:	48 ff c1             	inc    %rcx
 101a216:	48 89 48 e8          	mov    %rcx,-0x18(%rax)
 101a21a:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
 101a21e:	48 c7 85 90 fe ff ff 	movq   $0x1009fd0,-0x170(%rbp)
 101a225:	d0 9f 00 01 
 101a229:	48 8d 4d c8          	lea    -0x38(%rbp),%rcx
 101a22d:	48 89 8d 98 fe ff ff 	mov    %rcx,-0x168(%rbp)
 101a234:	48 8d 4d 88          	lea    -0x78(%rbp),%rcx
 101a238:	48 89 8d a0 fe ff ff 	mov    %rcx,-0x160(%rbp)
 101a23f:	c7 85 a8 fe ff ff 08 	movl   $0x8,-0x158(%rbp)
 101a246:	00 00 00 
 101a249:	c7 45 88 01 00 00 00 	movl   $0x1,-0x78(%rbp)
 101a250:	83 bd 70 ff ff ff 00 	cmpl   $0x0,-0x90(%rbp)
 101a257:	74 13                	je     101a26c <entry_run+0x1dbc>
 101a259:	48 89 df             	mov    %rbx,%rdi
 101a25c:	48 8d b5 30 fe ff ff 	lea    -0x1d0(%rbp),%rsi
 101a263:	e8 48 09 00 00       	call   101abb0 <myl_qbe_rc_slot_drop>
 101a268:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
 101a26c:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
 101a270:	48 c7 85 30 fe ff ff 	movq   $0x1009fd0,-0x1d0(%rbp)
 101a277:	d0 9f 00 01 
 101a27b:	48 8d 4d a8          	lea    -0x58(%rbp),%rcx
 101a27f:	48 89 8d 38 fe ff ff 	mov    %rcx,-0x1c8(%rbp)
 101a286:	48 8d 8d 70 ff ff ff 	lea    -0x90(%rbp),%rcx
 101a28d:	48 89 8d 40 fe ff ff 	mov    %rcx,-0x1c0(%rbp)
 101a294:	c7 85 48 fe ff ff 08 	movl   $0x8,-0x1b8(%rbp)
 101a29b:	00 00 00 
 101a29e:	48 89 45 d0          	mov    %rax,-0x30(%rbp)
 101a2a2:	48 c7 85 90 fe ff ff 	movq   $0x1009fd0,-0x170(%rbp)
 101a2a9:	d0 9f 00 01 
 101a2ad:	48 8d 4d c8          	lea    -0x38(%rbp),%rcx
 101a2b1:	48 89 8d 98 fe ff ff 	mov    %rcx,-0x168(%rbp)
 101a2b8:	48 8d 4d 88          	lea    -0x78(%rbp),%rcx
 101a2bc:	48 89 8d a0 fe ff ff 	mov    %rcx,-0x160(%rbp)
 101a2c3:	c7 85 a8 fe ff ff 08 	movl   $0x8,-0x158(%rbp)
 101a2ca:	00 00 00 
 101a2cd:	c7 45 88 01 00 00 00 	movl   $0x1,-0x78(%rbp)
 101a2d4:	c7 85 70 ff ff ff 00 	movl   $0x0,-0x90(%rbp)
 101a2db:	00 00 00 
 101a2de:	83 bd 60 ff ff ff 00 	cmpl   $0x0,-0xa0(%rbp)
 101a2e5:	4c 8d b5 10 ff ff ff 	lea    -0xf0(%rbp),%r14
 101a2ec:	4c 8d bd 60 ff ff ff 	lea    -0xa0(%rbp),%r15
 101a2f3:	74 13                	je     101a308 <entry_run+0x1e58>
 101a2f5:	48 89 df             	mov    %rbx,%rdi
 101a2f8:	48 8d b5 f0 fd ff ff 	lea    -0x210(%rbp),%rsi
 101a2ff:	e8 ac 08 00 00       	call   101abb0 <myl_qbe_rc_slot_drop>
 101a304:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
 101a308:	48 89 85 10 ff ff ff 	mov    %rax,-0xf0(%rbp)
 101a30f:	48 c7 85 f0 fd ff ff 	movq   $0x1009fd0,-0x210(%rbp)
 101a316:	d0 9f 00 01 
 101a31a:	4c 89 b5 f8 fd ff ff 	mov    %r14,-0x208(%rbp)
 101a321:	4c 89 bd 00 fe ff ff 	mov    %r15,-0x200(%rbp)
 101a328:	c7 85 08 fe ff ff 08 	movl   $0x8,-0x1f8(%rbp)
 101a32f:	00 00 00 
 101a332:	c7 85 60 ff ff ff 01 	movl   $0x1,-0xa0(%rbp)
 101a339:	00 00 00 
 101a33c:	c7 45 88 00 00 00 00 	movl   $0x0,-0x78(%rbp)
 101a343:	48 8b 10             	mov    (%rax),%rdx
 101a346:	48 89 55 d0          	mov    %rdx,-0x30(%rbp)
 101a34a:	48 85 d2             	test   %rdx,%rdx
 101a34d:	0f 88 fd 07 00 00    	js     101ab50 <entry_run+0x26a0>
 101a353:	48 89 55 c0          	mov    %rdx,-0x40(%rbp)
 101a357:	0f 84 ef 02 00 00    	je     101a64c <entry_run+0x219c>
 101a35d:	48 89 d1             	mov    %rdx,%rcx
 101a360:	48 f7 d9             	neg    %rcx
 101a363:	48 89 8d 28 ff ff ff 	mov    %rcx,-0xd8(%rbp)
 101a36a:	41 bc 01 00 00 00    	mov    $0x1,%r12d
 101a370:	45 31 ed             	xor    %r13d,%r13d
 101a373:	48 8d 75 c8          	lea    -0x38(%rbp),%rsi
 101a377:	4c 8d 75 d0          	lea    -0x30(%rbp),%r14
 101a37b:	48 89 55 b0          	mov    %rdx,-0x50(%rbp)
 101a37f:	90                   	nop
 101a380:	4c 89 6d b8          	mov    %r13,-0x48(%rbp)
 101a384:	48 8b 40 20          	mov    0x20(%rax),%rax
 101a388:	4d 89 e5             	mov    %r12,%r13
 101a38b:	4a 8b 44 e0 f8       	mov    -0x8(%rax,%r12,8),%rax
 101a390:	48 89 45 d0          	mov    %rax,-0x30(%rbp)
 101a394:	4c 8d bb 58 02 00 00 	lea    0x258(%rbx),%r15
 101a39b:	4c 89 ff             	mov    %r15,%rdi
 101a39e:	4c 89 f2             	mov    %r14,%rdx
 101a3a1:	4d 89 f4             	mov    %r14,%r12
 101a3a4:	49 89 f6             	mov    %rsi,%r14
 101a3a7:	e8 44 3f 01 00       	call   102e2f0 <myl_rc_native_loan>
 101a3ac:	85 c0                	test   %eax,%eax
 101a3ae:	0f 84 14 05 00 00    	je     101a8c8 <entry_run+0x2418>
 101a3b4:	48 c7 85 90 fe ff ff 	movq   $0x1009f60,-0x170(%rbp)
 101a3bb:	60 9f 00 01 
 101a3bf:	c7 85 a8 fe ff ff 10 	movl   $0x10,-0x158(%rbp)
 101a3c6:	00 00 00 
 101a3c9:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
 101a3cd:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
 101a3d1:	48 c7 85 30 fe ff ff 	movq   $0x1009f60,-0x1d0(%rbp)
 101a3d8:	60 9f 00 01 
 101a3dc:	c7 85 48 fe ff ff 10 	movl   $0x10,-0x1b8(%rbp)
 101a3e3:	00 00 00 
 101a3e6:	c7 45 88 00 00 00 00 	movl   $0x0,-0x78(%rbp)
 101a3ed:	c7 85 70 ff ff ff 01 	movl   $0x1,-0x90(%rbp)
 101a3f4:	00 00 00 
 101a3f7:	48 89 45 d0          	mov    %rax,-0x30(%rbp)
 101a3fb:	4c 89 ff             	mov    %r15,%rdi
 101a3fe:	4d 89 f7             	mov    %r14,%r15
 101a401:	4c 89 f6             	mov    %r14,%rsi
 101a404:	4c 89 e2             	mov    %r12,%rdx
 101a407:	e8 e4 3e 01 00       	call   102e2f0 <myl_rc_native_loan>
 101a40c:	85 c0                	test   %eax,%eax
 101a40e:	0f 84 e2 04 00 00    	je     101a8f6 <entry_run+0x2446>
 101a414:	4d 89 e6             	mov    %r12,%r14
 101a417:	48 c7 85 90 fe ff ff 	movq   $0x1009f60,-0x170(%rbp)
 101a41e:	60 9f 00 01 
 101a422:	c7 85 a8 fe ff ff 10 	movl   $0x10,-0x158(%rbp)
 101a429:	00 00 00 
 101a42c:	c7 45 88 01 00 00 00 	movl   $0x1,-0x78(%rbp)
 101a433:	83 bd 70 ff ff ff 00 	cmpl   $0x0,-0x90(%rbp)
 101a43a:	74 0f                	je     101a44b <entry_run+0x1f9b>
 101a43c:	48 89 df             	mov    %rbx,%rdi
 101a43f:	48 8d b5 30 fe ff ff 	lea    -0x1d0(%rbp),%rsi
 101a446:	e8 65 07 00 00       	call   101abb0 <myl_qbe_rc_slot_drop>
 101a44b:	83 bd 68 ff ff ff 00 	cmpl   $0x0,-0x98(%rbp)
 101a452:	4d 89 ec             	mov    %r13,%r12
 101a455:	74 0f                	je     101a466 <entry_run+0x1fb6>
 101a457:	48 89 df             	mov    %rbx,%rdi
 101a45a:	48 8d b5 10 fe ff ff 	lea    -0x1f0(%rbp),%rsi
 101a461:	e8 4a 07 00 00       	call   101abb0 <myl_qbe_rc_slot_drop>
 101a466:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
 101a46a:	48 89 85 18 ff ff ff 	mov    %rax,-0xe8(%rbp)
 101a471:	c7 45 88 00 00 00 00 	movl   $0x0,-0x78(%rbp)
 101a478:	48 c7 85 10 fe ff ff 	movq   $0x1009f60,-0x1f0(%rbp)
 101a47f:	60 9f 00 01 
 101a483:	48 8d 8d 18 ff ff ff 	lea    -0xe8(%rbp),%rcx
 101a48a:	48 89 8d 18 fe ff ff 	mov    %rcx,-0x1e8(%rbp)
 101a491:	48 8d 8d 68 ff ff ff 	lea    -0x98(%rbp),%rcx
 101a498:	48 89 8d 20 fe ff ff 	mov    %rcx,-0x1e0(%rbp)
 101a49f:	8b 8d a8 fe ff ff    	mov    -0x158(%rbp),%ecx
 101a4a5:	89 8d 28 fe ff ff    	mov    %ecx,-0x1d8(%rbp)
 101a4ab:	c7 85 68 ff ff ff 01 	movl   $0x1,-0x98(%rbp)
 101a4b2:	00 00 00 
 101a4b5:	48 8b 4d b8          	mov    -0x48(%rbp),%rcx
 101a4b9:	48 89 4d d0          	mov    %rcx,-0x30(%rbp)
 101a4bd:	48 8b 7d 98          	mov    -0x68(%rbp),%rdi
 101a4c1:	48 89 7d c0          	mov    %rdi,-0x40(%rbp)
 101a4c5:	48 89 85 20 ff ff ff 	mov    %rax,-0xe0(%rbp)
 101a4cc:	48 8d b5 20 ff ff ff 	lea    -0xe0(%rbp),%rsi
 101a4d3:	48 8d 95 f0 fc ff ff 	lea    -0x310(%rbp),%rdx
 101a4da:	e8 01 88 00 00       	call   1022ce0 <myl_native_dictionary_read>
 101a4df:	85 c0                	test   %eax,%eax
 101a4e1:	0f 84 22 06 00 00    	je     101ab09 <entry_run+0x2659>
 101a4e7:	48 8b 85 f0 fc ff ff 	mov    -0x310(%rbp),%rax
 101a4ee:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
 101a4f2:	83 bd 78 ff ff ff 00 	cmpl   $0x0,-0x88(%rbp)
 101a4f9:	74 0f                	je     101a50a <entry_run+0x205a>
 101a4fb:	48 89 df             	mov    %rbx,%rdi
 101a4fe:	48 8d b5 50 fe ff ff 	lea    -0x1b0(%rbp),%rsi
 101a505:	e8 a6 06 00 00       	call   101abb0 <myl_qbe_rc_slot_drop>
 101a50a:	83 7d 80 00          	cmpl   $0x0,-0x80(%rbp)
 101a50e:	74 3e                	je     101a54e <entry_run+0x209e>
 101a510:	48 89 df             	mov    %rbx,%rdi
 101a513:	48 8d b5 70 fe ff ff 	lea    -0x190(%rbp),%rsi
 101a51a:	e8 91 06 00 00       	call   101abb0 <myl_qbe_rc_slot_drop>
 101a51f:	48 8b 85 18 ff ff ff 	mov    -0xe8(%rbp),%rax
 101a526:	48 8b 08             	mov    (%rax),%rcx
 101a529:	48 89 8d 20 ff ff ff 	mov    %rcx,-0xe0(%rbp)
 101a530:	83 7d 80 00          	cmpl   $0x0,-0x80(%rbp)
 101a534:	74 29                	je     101a55f <entry_run+0x20af>
 101a536:	48 89 df             	mov    %rbx,%rdi
 101a539:	48 8d b5 70 fe ff ff 	lea    -0x190(%rbp),%rsi
 101a540:	e8 6b 06 00 00       	call   101abb0 <myl_qbe_rc_slot_drop>
 101a545:	48 8b 8d 20 ff ff ff 	mov    -0xe0(%rbp),%rcx
 101a54c:	eb 11                	jmp    101a55f <entry_run+0x20af>
 101a54e:	48 8b 85 18 ff ff ff 	mov    -0xe8(%rbp),%rax
 101a555:	48 8b 08             	mov    (%rax),%rcx
 101a558:	48 89 8d 20 ff ff ff 	mov    %rcx,-0xe0(%rbp)
 101a55f:	48 8b 55 c0          	mov    -0x40(%rbp),%rdx
 101a563:	48 89 d0             	mov    %rdx,%rax
 101a566:	48 0f af c1          	imul   %rcx,%rax
 101a56a:	0f 80 a1 05 00 00    	jo     101ab11 <entry_run+0x2661>
 101a570:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
 101a574:	48 8b 55 d0          	mov    -0x30(%rbp),%rdx
 101a578:	48 89 d1             	mov    %rdx,%rcx
 101a57b:	48 01 c1             	add    %rax,%rcx
 101a57e:	0f 80 9a 05 00 00    	jo     101ab1e <entry_run+0x266e>
 101a584:	48 89 c8             	mov    %rcx,%rax
 101a587:	48 ba 35 ce 5a 4e a2 	movabs $0x8637a2a24e5ace35,%rdx
 101a58e:	a2 37 86 
 101a591:	48 f7 ea             	imul   %rdx
 101a594:	48 c7 45 c0 43 42 0f 	movq   $0xf4243,-0x40(%rbp)
 101a59b:	00 
 101a59c:	48 01 ca             	add    %rcx,%rdx
 101a59f:	48 89 d0             	mov    %rdx,%rax
 101a5a2:	48 c1 e8 3f          	shr    $0x3f,%rax
 101a5a6:	48 c1 fa 13          	sar    $0x13,%rdx
 101a5aa:	48 01 c2             	add    %rax,%rdx
 101a5ad:	48 69 c2 43 42 0f 00 	imul   $0xf4243,%rdx,%rax
 101a5b4:	48 29 c1             	sub    %rax,%rcx
 101a5b7:	49 89 cd             	mov    %rcx,%r13
 101a5ba:	49 c1 fd 3f          	sar    $0x3f,%r13
 101a5be:	41 81 e5 43 42 0f 00 	and    $0xf4243,%r13d
 101a5c5:	49 01 cd             	add    %rcx,%r13
 101a5c8:	4c 89 6d d0          	mov    %r13,-0x30(%rbp)
 101a5cc:	83 bd 68 ff ff ff 00 	cmpl   $0x0,-0x98(%rbp)
 101a5d3:	74 0f                	je     101a5e4 <entry_run+0x2134>
 101a5d5:	48 89 df             	mov    %rbx,%rdi
 101a5d8:	48 8d b5 10 fe ff ff 	lea    -0x1f0(%rbp),%rsi
 101a5df:	e8 cc 05 00 00       	call   101abb0 <myl_qbe_rc_slot_drop>
 101a5e4:	48 8b 55 b0          	mov    -0x50(%rbp),%rdx
 101a5e8:	48 89 55 d0          	mov    %rdx,-0x30(%rbp)
 101a5ec:	48 8b 85 10 ff ff ff 	mov    -0xf0(%rbp),%rax
 101a5f3:	48 39 10             	cmp    %rdx,(%rax)
 101a5f6:	0f 85 2f 05 00 00    	jne    101ab2b <entry_run+0x267b>
 101a5fc:	48 89 55 c0          	mov    %rdx,-0x40(%rbp)
 101a600:	31 c9                	xor    %ecx,%ecx
 101a602:	49 39 d4             	cmp    %rdx,%r12
 101a605:	0f 9c c1             	setl   %cl
 101a608:	48 89 4d d0          	mov    %rcx,-0x30(%rbp)
 101a60c:	48 8b 8d 28 ff ff ff 	mov    -0xd8(%rbp),%rcx
 101a613:	4c 01 e1             	add    %r12,%rcx
 101a616:	48 ff c1             	inc    %rcx
 101a619:	49 ff c4             	inc    %r12
 101a61c:	48 83 f9 01          	cmp    $0x1,%rcx
 101a620:	4c 89 fe             	mov    %r15,%rsi
 101a623:	0f 85 57 fd ff ff    	jne    101a380 <entry_run+0x1ed0>
 101a629:	eb 24                	jmp    101a64f <entry_run+0x219f>
 101a62b:	be 13 74 00 01       	mov    $0x1007413,%esi
 101a630:	e9 3c ec ff ff       	jmp    1019271 <entry_run+0xdc1>
 101a635:	c7 40 38 01 00 00 00 	movl   $0x1,0x38(%rax)
 101a63c:	48 83 7b 20 00       	cmpq   $0x0,0x20(%rbx)
 101a641:	0f 85 55 04 00 00    	jne    101aa9c <entry_run+0x25ec>
 101a647:	e9 a5 df ff ff       	jmp    10185f1 <entry_run+0x141>
 101a64c:	45 31 ed             	xor    %r13d,%r13d
 101a64f:	48 c7 45 d0 01 00 00 	movq   $0x1,-0x30(%rbp)
 101a656:	00 
 101a657:	4c 89 6d c0          	mov    %r13,-0x40(%rbp)
 101a65b:	bf 01 00 00 00       	mov    $0x1,%edi
 101a660:	be 20 00 00 00       	mov    $0x20,%esi
 101a665:	e8 46 7a 01 00       	call   10320b0 <calloc@plt>
 101a66a:	49 89 c7             	mov    %rax,%r15
 101a66d:	48 85 c0             	test   %rax,%rax
 101a670:	75 0c                	jne    101a67e <entry_run+0x21ce>
 101a672:	48 89 df             	mov    %rbx,%rdi
 101a675:	e8 76 15 00 00       	call   101bbf0 <myl_qbe_fail_allocation>
 101a67a:	4c 8b 6d c0          	mov    -0x40(%rbp),%r13
 101a67e:	48 8d bd 40 fc ff ff 	lea    -0x3c0(%rbp),%rdi
 101a685:	be 18 00 00 00       	mov    $0x18,%esi
 101a68a:	ba 04 72 00 01       	mov    $0x1007204,%edx
 101a68f:	4c 89 e9             	mov    %r13,%rcx
 101a692:	31 c0                	xor    %eax,%eax
 101a694:	e8 47 7b 01 00       	call   10321e0 <snprintf@plt>
 101a699:	85 c0                	test   %eax,%eax
 101a69b:	0f 8e fb 01 00 00    	jle    101a89c <entry_run+0x23ec>
 101a6a1:	41 89 c4             	mov    %eax,%r12d
 101a6a4:	bf 40 00 00 00       	mov    $0x40,%edi
 101a6a9:	83 f8 41             	cmp    $0x41,%eax
 101a6ac:	0f 82 95 01 00 00    	jb     101a847 <entry_run+0x2397>
 101a6b2:	bf 80 00 00 00       	mov    $0x80,%edi
 101a6b7:	41 81 fc 81 00 00 00 	cmp    $0x81,%r12d
 101a6be:	0f 82 83 01 00 00    	jb     101a847 <entry_run+0x2397>
 101a6c4:	bf 00 01 00 00       	mov    $0x100,%edi
 101a6c9:	41 81 fc 01 01 00 00 	cmp    $0x101,%r12d
 101a6d0:	0f 82 71 01 00 00    	jb     101a847 <entry_run+0x2397>
 101a6d6:	bf 00 02 00 00       	mov    $0x200,%edi
 101a6db:	41 81 fc 01 02 00 00 	cmp    $0x201,%r12d
 101a6e2:	0f 82 5f 01 00 00    	jb     101a847 <entry_run+0x2397>
 101a6e8:	bf 00 04 00 00       	mov    $0x400,%edi
 101a6ed:	41 81 fc 01 04 00 00 	cmp    $0x401,%r12d
 101a6f4:	0f 82 4d 01 00 00    	jb     101a847 <entry_run+0x2397>
 101a6fa:	bf 00 08 00 00       	mov    $0x800,%edi
 101a6ff:	41 81 fc 01 08 00 00 	cmp    $0x801,%r12d
 101a706:	0f 82 3b 01 00 00    	jb     101a847 <entry_run+0x2397>
 101a70c:	bf 00 10 00 00       	mov    $0x1000,%edi
 101a711:	41 81 fc 01 10 00 00 	cmp    $0x1001,%r12d
 101a718:	0f 82 29 01 00 00    	jb     101a847 <entry_run+0x2397>
 101a71e:	bf 00 20 00 00       	mov    $0x2000,%edi
 101a723:	41 81 fc 01 20 00 00 	cmp    $0x2001,%r12d
 101a72a:	0f 82 17 01 00 00    	jb     101a847 <entry_run+0x2397>
 101a730:	bf 00 40 00 00       	mov    $0x4000,%edi
 101a735:	41 81 fc 01 40 00 00 	cmp    $0x4001,%r12d
 101a73c:	0f 82 05 01 00 00    	jb     101a847 <entry_run+0x2397>
 101a742:	bf 00 80 00 00       	mov    $0x8000,%edi
 101a747:	41 81 fc 01 80 00 00 	cmp    $0x8001,%r12d
 101a74e:	0f 82 f3 00 00 00    	jb     101a847 <entry_run+0x2397>
 101a754:	bf 00 00 01 00       	mov    $0x10000,%edi
 101a759:	41 81 fc 01 00 01 00 	cmp    $0x10001,%r12d
 101a760:	0f 82 e1 00 00 00    	jb     101a847 <entry_run+0x2397>
 101a766:	bf 00 00 02 00       	mov    $0x20000,%edi
 101a76b:	41 81 fc 01 00 02 00 	cmp    $0x20001,%r12d
 101a772:	0f 82 cf 00 00 00    	jb     101a847 <entry_run+0x2397>
 101a778:	bf 00 00 04 00       	mov    $0x40000,%edi
 101a77d:	41 81 fc 01 00 04 00 	cmp    $0x40001,%r12d
 101a784:	0f 82 bd 00 00 00    	jb     101a847 <entry_run+0x2397>
 101a78a:	bf 00 00 08 00       	mov    $0x80000,%edi
 101a78f:	41 81 fc 01 00 08 00 	cmp    $0x80001,%r12d
 101a796:	0f 82 ab 00 00 00    	jb     101a847 <entry_run+0x2397>
 101a79c:	bf 00 00 10 00       	mov    $0x100000,%edi
 101a7a1:	41 81 fc 01 00 10 00 	cmp    $0x100001,%r12d
 101a7a8:	0f 82 99 00 00 00    	jb     101a847 <entry_run+0x2397>
 101a7ae:	bf 00 00 20 00       	mov    $0x200000,%edi
 101a7b3:	41 81 fc 01 00 20 00 	cmp    $0x200001,%r12d
 101a7ba:	0f 82 87 00 00 00    	jb     101a847 <entry_run+0x2397>
 101a7c0:	bf 00 00 40 00       	mov    $0x400000,%edi
 101a7c5:	41 81 fc 01 00 40 00 	cmp    $0x400001,%r12d
 101a7cc:	72 79                	jb     101a847 <entry_run+0x2397>
 101a7ce:	bf 00 00 80 00       	mov    $0x800000,%edi
 101a7d3:	41 81 fc 01 00 80 00 	cmp    $0x800001,%r12d
 101a7da:	72 6b                	jb     101a847 <entry_run+0x2397>
 101a7dc:	bf 00 00 00 01       	mov    $0x1000000,%edi
 101a7e1:	41 81 fc 01 00 00 01 	cmp    $0x1000001,%r12d
 101a7e8:	72 5d                	jb     101a847 <entry_run+0x2397>
 101a7ea:	bf 00 00 00 02       	mov    $0x2000000,%edi
 101a7ef:	41 81 fc 01 00 00 02 	cmp    $0x2000001,%r12d
 101a7f6:	72 4f                	jb     101a847 <entry_run+0x2397>
 101a7f8:	bf 00 00 00 04       	mov    $0x4000000,%edi
 101a7fd:	41 81 fc 01 00 00 04 	cmp    $0x4000001,%r12d
 101a804:	72 41                	jb     101a847 <entry_run+0x2397>
 101a806:	bf 00 00 00 08       	mov    $0x8000000,%edi
 101a80b:	41 81 fc 01 00 00 08 	cmp    $0x8000001,%r12d
 101a812:	72 33                	jb     101a847 <entry_run+0x2397>
 101a814:	bf 00 00 00 10       	mov    $0x10000000,%edi
 101a819:	41 81 fc 01 00 00 10 	cmp    $0x10000001,%r12d
 101a820:	72 25                	jb     101a847 <entry_run+0x2397>
 101a822:	bf 00 00 00 20       	mov    $0x20000000,%edi
 101a827:	41 81 fc 01 00 00 20 	cmp    $0x20000001,%r12d
 101a82e:	72 17                	jb     101a847 <entry_run+0x2397>
 101a830:	31 ff                	xor    %edi,%edi
 101a832:	41 81 fc 01 00 00 40 	cmp    $0x40000001,%r12d
 101a839:	40 0f 93 c7          	setae  %dil
 101a83d:	c1 e7 1e             	shl    $0x1e,%edi
 101a840:	48 81 c7 00 00 00 40 	add    $0x40000000,%rdi
 101a847:	49 89 fe             	mov    %rdi,%r14
 101a84a:	e8 51 78 01 00       	call   10320a0 <malloc@plt>
 101a84f:	48 85 c0             	test   %rax,%rax
 101a852:	0f 84 cc 00 00 00    	je     101a924 <entry_run+0x2474>
 101a858:	45 89 e4             	mov    %r12d,%r12d
 101a85b:	49 89 07             	mov    %rax,(%r15)
 101a85e:	4d 89 77 10          	mov    %r14,0x10(%r15)
 101a862:	48 8d b5 40 fc ff ff 	lea    -0x3c0(%rbp),%rsi
 101a869:	48 89 45 b8          	mov    %rax,-0x48(%rbp)
 101a86d:	48 89 c7             	mov    %rax,%rdi
 101a870:	4c 89 e2             	mov    %r12,%rdx
 101a873:	e8 e8 77 01 00       	call   1032060 <memcpy@plt>
 101a878:	4c 89 f6             	mov    %r14,%rsi
 101a87b:	4d 8d 77 08          	lea    0x8(%r15),%r14
 101a87f:	4d 89 67 08          	mov    %r12,0x8(%r15)
 101a883:	4d 89 fd             	mov    %r15,%r13
 101a886:	49 83 c5 18          	add    $0x18,%r13
 101a88a:	4c 39 e6             	cmp    %r12,%rsi
 101a88d:	0f 85 ac 00 00 00    	jne    101a93f <entry_run+0x248f>
 101a893:	48 01 f6             	add    %rsi,%rsi
 101a896:	48 8b 7d b8          	mov    -0x48(%rbp),%rdi
 101a89a:	eb 12                	jmp    101a8ae <entry_run+0x23fe>
 101a89c:	4d 8d 6f 18          	lea    0x18(%r15),%r13
 101a8a0:	4d 89 fe             	mov    %r15,%r14
 101a8a3:	49 83 c6 08          	add    $0x8,%r14
 101a8a7:	be 40 00 00 00       	mov    $0x40,%esi
 101a8ac:	31 ff                	xor    %edi,%edi
 101a8ae:	49 89 f4             	mov    %rsi,%r12
 101a8b1:	e8 3a 79 01 00       	call   10321f0 <realloc@plt>
 101a8b6:	48 85 c0             	test   %rax,%rax
 101a8b9:	74 7a                	je     101a935 <entry_run+0x2485>
 101a8bb:	49 89 07             	mov    %rax,(%r15)
 101a8be:	4d 89 67 10          	mov    %r12,0x10(%r15)
 101a8c2:	4d 8b 67 08          	mov    0x8(%r15),%r12
 101a8c6:	eb 7b                	jmp    101a943 <entry_run+0x2493>
 101a8c8:	48 8b 83 60 18 00 00 	mov    0x1860(%rbx),%rax
 101a8cf:	48 85 c0             	test   %rax,%rax
 101a8d2:	0f 84 e3 01 00 00    	je     101aabb <entry_run+0x260b>
 101a8d8:	8b 70 78             	mov    0x78(%rax),%esi
 101a8db:	c7 40 78 00 00 00 00 	movl   $0x0,0x78(%rax)
 101a8e2:	48 89 df             	mov    %rbx,%rdi
 101a8e5:	e8 76 02 00 00       	call   101ab60 <myl_qbe_rc_status>
 101a8ea:	4c 8d ab 58 02 00 00 	lea    0x258(%rbx),%r13
 101a8f1:	e9 83 e9 ff ff       	jmp    1019279 <entry_run+0xdc9>
 101a8f6:	48 8b 83 60 18 00 00 	mov    0x1860(%rbx),%rax
 101a8fd:	48 85 c0             	test   %rax,%rax
 101a900:	0f 84 b5 01 00 00    	je     101aabb <entry_run+0x260b>
 101a906:	8b 70 78             	mov    0x78(%rax),%esi
 101a909:	c7 40 78 00 00 00 00 	movl   $0x0,0x78(%rax)
 101a910:	48 89 df             	mov    %rbx,%rdi
 101a913:	e8 48 02 00 00       	call   101ab60 <myl_qbe_rc_status>
 101a918:	4c 8d ab 58 02 00 00 	lea    0x258(%rbx),%r13
 101a91f:	e9 55 e9 ff ff       	jmp    1019279 <entry_run+0xdc9>
 101a924:	4d 89 fd             	mov    %r15,%r13
 101a927:	49 83 c5 18          	add    $0x18,%r13
 101a92b:	41 c7 47 18 01 00 00 	movl   $0x1,0x18(%r15)
 101a932:	00 
 101a933:	eb 16                	jmp    101a94b <entry_run+0x249b>
 101a935:	41 c7 45 00 01 00 00 	movl   $0x1,0x0(%r13)
 101a93c:	00 
 101a93d:	eb 0c                	jmp    101a94b <entry_run+0x249b>
 101a93f:	48 8b 45 b8          	mov    -0x48(%rbp),%rax
 101a943:	42 c6 04 20 0a       	movb   $0xa,(%rax,%r12,1)
 101a948:	49 ff 06             	incq   (%r14)
 101a94b:	41 83 7f 1c 00       	cmpl   $0x0,0x1c(%r15)
 101a950:	4c 8d a5 f0 fe ff ff 	lea    -0x110(%rbp),%r12
 101a957:	74 19                	je     101a972 <entry_run+0x24c2>
 101a959:	be a7 6e 00 01       	mov    $0x1006ea7,%esi
 101a95e:	48 89 df             	mov    %rbx,%rdi
 101a961:	e8 da 0b 00 00       	call   101b540 <fail>
 101a966:	4c 8d ab 58 02 00 00 	lea    0x258(%rbx),%r13
 101a96d:	e9 80 00 00 00       	jmp    101a9f2 <entry_run+0x2542>
 101a972:	41 83 7d 00 00       	cmpl   $0x0,0x0(%r13)
 101a977:	74 11                	je     101a98a <entry_run+0x24da>
 101a979:	48 89 df             	mov    %rbx,%rdi
 101a97c:	e8 6f 12 00 00       	call   101bbf0 <myl_qbe_fail_allocation>
 101a981:	4c 8d ab 58 02 00 00 	lea    0x258(%rbx),%r13
 101a988:	eb 68                	jmp    101a9f2 <entry_run+0x2542>
 101a98a:	48 8b 05 1f 9a 01 00 	mov    0x19a1f(%rip),%rax        # 10343b0 <stdout@GLIBC_2.2.5>
 101a991:	4c 8b 30             	mov    (%rax),%r14
 101a994:	4d 8b 67 08          	mov    0x8(%r15),%r12
 101a998:	4d 85 e4             	test   %r12,%r12
 101a99b:	4c 8d ab 58 02 00 00 	lea    0x258(%rbx),%r13
 101a9a2:	74 18                	je     101a9bc <entry_run+0x250c>
 101a9a4:	49 8b 3f             	mov    (%r15),%rdi
 101a9a7:	be 01 00 00 00       	mov    $0x1,%esi
 101a9ac:	4c 89 e2             	mov    %r12,%rdx
 101a9af:	4c 89 f1             	mov    %r14,%rcx
 101a9b2:	e8 a9 77 01 00       	call   1032160 <fwrite@plt>
 101a9b7:	4c 39 e0             	cmp    %r12,%rax
 101a9ba:	75 22                	jne    101a9de <entry_run+0x252e>
 101a9bc:	4c 89 f7             	mov    %r14,%rdi
 101a9bf:	e8 3c 78 01 00       	call   1032200 <fflush@plt>
 101a9c4:	85 c0                	test   %eax,%eax
 101a9c6:	4c 8d a5 f0 fe ff ff 	lea    -0x110(%rbp),%r12
 101a9cd:	74 23                	je     101a9f2 <entry_run+0x2542>
 101a9cf:	be d6 73 00 01       	mov    $0x10073d6,%esi
 101a9d4:	48 89 df             	mov    %rbx,%rdi
 101a9d7:	e8 64 0b 00 00       	call   101b540 <fail>
 101a9dc:	eb 14                	jmp    101a9f2 <entry_run+0x2542>
 101a9de:	be d6 73 00 01       	mov    $0x10073d6,%esi
 101a9e3:	48 89 df             	mov    %rbx,%rdi
 101a9e6:	e8 55 0b 00 00       	call   101b540 <fail>
 101a9eb:	4c 8d a5 f0 fe ff ff 	lea    -0x110(%rbp),%r12
 101a9f2:	49 8b 3f             	mov    (%r15),%rdi
 101a9f5:	e8 06 77 01 00       	call   1032100 <free@plt>
 101a9fa:	4c 89 ff             	mov    %r15,%rdi
 101a9fd:	e8 fe 76 01 00       	call   1032100 <free@plt>
 101aa02:	48 c7 45 d0 00 00 00 	movq   $0x0,-0x30(%rbp)
 101aa09:	00 
 101aa0a:	4c 39 a3 80 3d 00 00 	cmp    %r12,0x3d80(%rbx)
 101aa11:	0f 85 a4 00 00 00    	jne    101aabb <entry_run+0x260b>
 101aa17:	48 8b b5 08 ff ff ff 	mov    -0xf8(%rbp),%rsi
 101aa1e:	4c 89 ef             	mov    %r13,%rdi
 101aa21:	e8 3a f8 00 00       	call   102a260 <myl_rc_scope_unwind>
 101aa26:	4c 8b b5 00 ff ff ff 	mov    -0x100(%rbp),%r14
 101aa2d:	4d 85 f6             	test   %r14,%r14
 101aa30:	74 3a                	je     101aa6c <entry_run+0x25bc>
 101aa32:	4d 89 f7             	mov    %r14,%r15
 101aa35:	49 c1 e7 05          	shl    $0x5,%r15
 101aa39:	49 83 c7 e0          	add    $0xffffffffffffffe0,%r15
 101aa3d:	eb 15                	jmp    101aa54 <entry_run+0x25a4>
 101aa3f:	90                   	nop
 101aa40:	4c 01 fe             	add    %r15,%rsi
 101aa43:	48 89 df             	mov    %rbx,%rdi
 101aa46:	e8 65 01 00 00       	call   101abb0 <myl_qbe_rc_slot_drop>
 101aa4b:	49 83 c7 e0          	add    $0xffffffffffffffe0,%r15
 101aa4f:	49 ff ce             	dec    %r14
 101aa52:	74 18                	je     101aa6c <entry_run+0x25bc>
 101aa54:	48 8b b5 f8 fe ff ff 	mov    -0x108(%rbp),%rsi
 101aa5b:	4a 8b 44 3e 10       	mov    0x10(%rsi,%r15,1),%rax
 101aa60:	48 85 c0             	test   %rax,%rax
 101aa63:	74 db                	je     101aa40 <entry_run+0x2590>
 101aa65:	83 38 00             	cmpl   $0x0,(%rax)
 101aa68:	75 d6                	jne    101aa40 <entry_run+0x2590>
 101aa6a:	eb df                	jmp    101aa4b <entry_run+0x259b>
 101aa6c:	4c 39 a3 80 3d 00 00 	cmp    %r12,0x3d80(%rbx)
 101aa73:	75 46                	jne    101aabb <entry_run+0x260b>
 101aa75:	48 8b 83 60 18 00 00 	mov    0x1860(%rbx),%rax
 101aa7c:	48 85 c0             	test   %rax,%rax
 101aa7f:	74 2f                	je     101aab0 <entry_run+0x2600>
 101aa81:	48 8b 40 70          	mov    0x70(%rax),%rax
 101aa85:	48 3b 85 08 ff ff ff 	cmp    -0xf8(%rbp),%rax
 101aa8c:	75 2d                	jne    101aabb <entry_run+0x260b>
 101aa8e:	48 8b 85 f0 fe ff ff 	mov    -0x110(%rbp),%rax
 101aa95:	48 89 83 80 3d 00 00 	mov    %rax,0x3d80(%rbx)
 101aa9c:	31 c0                	xor    %eax,%eax
 101aa9e:	48 81 c4 a8 03 00 00 	add    $0x3a8,%rsp
 101aaa5:	5b                   	pop    %rbx
 101aaa6:	41 5c                	pop    %r12
 101aaa8:	41 5d                	pop    %r13
 101aaaa:	41 5e                	pop    %r14
 101aaac:	41 5f                	pop    %r15
 101aaae:	5d                   	pop    %rbp
 101aaaf:	c3                   	ret
 101aab0:	31 c0                	xor    %eax,%eax
 101aab2:	48 3b 85 08 ff ff ff 	cmp    -0xf8(%rbp),%rax
 101aab9:	74 d3                	je     101aa8e <entry_run+0x25de>
 101aabb:	c5 f8 77             	vzeroupper
 101aabe:	e8 5e b1 00 00       	call   1025c21 <myl_rc_invariant_failed>
 101aac3:	e8 48 77 01 00       	call   1032210 <abort@plt>
 101aac8:	48 89 df             	mov    %rbx,%rdi
 101aacb:	e8 20 11 00 00       	call   101bbf0 <myl_qbe_fail_allocation>
 101aad0:	48 89 df             	mov    %rbx,%rdi
 101aad3:	e8 18 11 00 00       	call   101bbf0 <myl_qbe_fail_allocation>
 101aad8:	48 89 df             	mov    %rbx,%rdi
 101aadb:	e8 10 11 00 00       	call   101bbf0 <myl_qbe_fail_allocation>
 101aae0:	48 89 df             	mov    %rbx,%rdi
 101aae3:	e8 b8 11 00 00       	call   101bca0 <myl_qbe_fail_normalized_index_bounds>
 101aae8:	b9 01 00 00 00       	mov    $0x1,%ecx
 101aaed:	48 89 df             	mov    %rbx,%rdi
 101aaf0:	31 f6                	xor    %esi,%esi
 101aaf2:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
 101aaf9:	ff ff 7f 
 101aafc:	e8 ff 11 00 00       	call   101bd00 <myl_qbe_fail_overflow_op>
 101ab01:	48 89 df             	mov    %rbx,%rdi
 101ab04:	e8 e7 10 00 00       	call   101bbf0 <myl_qbe_fail_allocation>
 101ab09:	48 89 df             	mov    %rbx,%rdi
 101ab0c:	e8 6f 11 00 00       	call   101bc80 <myl_qbe_fail_missing_key>
 101ab11:	be 02 00 00 00       	mov    $0x2,%esi
 101ab16:	48 89 df             	mov    %rbx,%rdi
 101ab19:	e8 e2 11 00 00       	call   101bd00 <myl_qbe_fail_overflow_op>
 101ab1e:	48 89 df             	mov    %rbx,%rdi
 101ab21:	31 f6                	xor    %esi,%esi
 101ab23:	48 89 c1             	mov    %rax,%rcx
 101ab26:	e8 d5 11 00 00       	call   101bd00 <myl_qbe_fail_overflow_op>
 101ab2b:	48 89 df             	mov    %rbx,%rdi
 101ab2e:	e8 5d 11 00 00       	call   101bc90 <myl_qbe_fail_iteration>
 101ab33:	48 89 df             	mov    %rbx,%rdi
 101ab36:	e8 b5 10 00 00       	call   101bbf0 <myl_qbe_fail_allocation>
 101ab3b:	83 78 78 00          	cmpl   $0x0,0x78(%rax)
 101ab3f:	75 07                	jne    101ab48 <entry_run+0x2698>
 101ab41:	c7 40 78 03 00 00 00 	movl   $0x3,0x78(%rax)
 101ab48:	48 89 df             	mov    %rbx,%rdi
 101ab4b:	e8 a0 10 00 00       	call   101bbf0 <myl_qbe_fail_allocation>
 101ab50:	48 89 df             	mov    %rbx,%rdi
 101ab53:	48 89 d6             	mov    %rdx,%rsi
 101ab56:	e8 05 12 00 00       	call   101bd60 <myl_qbe_fail_cast>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
