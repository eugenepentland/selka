
/home/epentland/ai/canopy/mylang-worktrees/d9-rc-compiler-astra/.tmp-rc/dict-empty/after-qbe-rc:     file format elf64-x86-64


Disassembly of section .text:

000000000100efa0 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605>:
 100efa0:	f3 0f 1e fa          	endbr64
 100efa4:	55                   	push   %rbp
 100efa5:	48 89 e5             	mov    %rsp,%rbp
 100efa8:	48 81 ec e8 03 00 00 	sub    $0x3e8,%rsp
 100efaf:	53                   	push   %rbx
 100efb0:	41 54                	push   %r12
 100efb2:	41 55                	push   %r13
 100efb4:	41 56                	push   %r14
 100efb6:	41 57                	push   %r15
 100efb8:	48 89 b5 40 ff ff ff 	mov    %rsi,-0xc0(%rbp)
 100efbf:	ba 20 00 00 00       	mov    $0x20,%edx
 100efc4:	be 00 00 00 00       	mov    $0x0,%esi
 100efc9:	48 89 fb             	mov    %rdi,%rbx
 100efcc:	48 8d bd 78 fe ff ff 	lea    -0x188(%rbp),%rdi
 100efd3:	e8 a8 d3 01 00       	call   102c380 <compiler_rt.fastMemset>
 100efd8:	48 89 df             	mov    %rbx,%rdi
 100efdb:	ba 20 00 00 00       	mov    $0x20,%edx
 100efe0:	be 00 00 00 00       	mov    $0x0,%esi
 100efe5:	48 89 fb             	mov    %rdi,%rbx
 100efe8:	48 8d bd 98 fe ff ff 	lea    -0x168(%rbp),%rdi
 100efef:	e8 8c d3 01 00       	call   102c380 <compiler_rt.fastMemset>
 100eff4:	48 89 df             	mov    %rbx,%rdi
 100eff7:	ba 20 00 00 00       	mov    $0x20,%edx
 100effc:	be 00 00 00 00       	mov    $0x0,%esi
 100f001:	48 89 fb             	mov    %rdi,%rbx
 100f004:	48 8d bd b8 fe ff ff 	lea    -0x148(%rbp),%rdi
 100f00b:	e8 70 d3 01 00       	call   102c380 <compiler_rt.fastMemset>
 100f010:	48 89 df             	mov    %rbx,%rdi
 100f013:	48 c7 85 d8 fe ff ff 	movq   $0x0,-0x128(%rbp)
 100f01a:	00 00 00 00 
 100f01e:	48 c7 85 e0 fe ff ff 	movq   $0x0,-0x120(%rbp)
 100f025:	00 00 00 00 
 100f029:	48 c7 85 e8 fe ff ff 	movq   $0x0,-0x118(%rbp)
 100f030:	00 00 00 00 
 100f034:	48 c7 85 f0 fe ff ff 	movq   $0x0,-0x110(%rbp)
 100f03b:	00 00 00 00 
 100f03f:	48 c7 85 f8 fe ff ff 	movq   $0x0,-0x108(%rbp)
 100f046:	00 00 00 00 
 100f04a:	48 c7 85 00 ff ff ff 	movq   $0x0,-0x100(%rbp)
 100f051:	00 00 00 00 
 100f055:	48 c7 85 08 ff ff ff 	movq   $0x0,-0xf8(%rbp)
 100f05c:	00 00 00 00 
 100f060:	48 c7 85 10 ff ff ff 	movq   $0x0,-0xf0(%rbp)
 100f067:	00 00 00 00 
 100f06b:	48 89 fb             	mov    %rdi,%rbx
 100f06e:	e8 3d 80 00 00       	call   10170b0 <myl_qbe_heap>
 100f073:	48 89 df             	mov    %rbx,%rdi
 100f076:	48 89 c3             	mov    %rax,%rbx
 100f079:	49 89 fc             	mov    %rdi,%r12
 100f07c:	e8 ef 9b 00 00       	call   1018c70 <myl_qbe_region_mark>
 100f081:	4c 89 e7             	mov    %r12,%rdi
 100f084:	48 89 45 e0          	mov    %rax,-0x20(%rbp)
 100f088:	ba 68 00 00 00       	mov    $0x68,%edx
 100f08d:	be 00 00 00 00       	mov    $0x0,%esi
 100f092:	49 89 fc             	mov    %rdi,%r12
 100f095:	48 8d bd e8 fd ff ff 	lea    -0x218(%rbp),%rdi
 100f09c:	e8 df d2 01 00       	call   102c380 <compiler_rt.fastMemset>
 100f0a1:	4c 89 e7             	mov    %r12,%rdi
 100f0a4:	48 8d 05 55 fd 01 00 	lea    0x1fd55(%rip),%rax        # 102ee00 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b>
 100f0ab:	48 89 85 48 fc ff ff 	mov    %rax,-0x3b8(%rbp)
 100f0b2:	c7 85 60 fc ff ff 02 	movl   $0x2,-0x3a0(%rbp)
 100f0b9:	00 00 00 
 100f0bc:	48 8d 85 d8 fe ff ff 	lea    -0x128(%rbp),%rax
 100f0c3:	48 89 85 50 fc ff ff 	mov    %rax,-0x3b0(%rbp)
 100f0ca:	48 8d 85 e8 fd ff ff 	lea    -0x218(%rbp),%rax
 100f0d1:	48 89 85 58 fc ff ff 	mov    %rax,-0x3a8(%rbp)
 100f0d8:	48 8d 85 48 fc ff ff 	lea    -0x3b8(%rbp),%rax
 100f0df:	48 89 c6             	mov    %rax,%rsi
 100f0e2:	48 83 c6 20          	add    $0x20,%rsi
 100f0e6:	48 89 75 f0          	mov    %rsi,-0x10(%rbp)
 100f0ea:	48 8d 05 0f fd 01 00 	lea    0x1fd0f(%rip),%rax        # 102ee00 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b>
 100f0f1:	48 89 85 68 fc ff ff 	mov    %rax,-0x398(%rbp)
 100f0f8:	c7 85 80 fc ff ff 02 	movl   $0x2,-0x380(%rbp)
 100f0ff:	00 00 00 
 100f102:	48 8d 85 e0 fe ff ff 	lea    -0x120(%rbp),%rax
 100f109:	48 89 85 70 fc ff ff 	mov    %rax,-0x390(%rbp)
 100f110:	48 8d 85 e8 fd ff ff 	lea    -0x218(%rbp),%rax
 100f117:	49 89 c6             	mov    %rax,%r14
 100f11a:	49 83 c6 08          	add    $0x8,%r14
 100f11e:	4c 89 b5 78 fc ff ff 	mov    %r14,-0x388(%rbp)
 100f125:	48 8d 85 48 fc ff ff 	lea    -0x3b8(%rbp),%rax
 100f12c:	48 89 c6             	mov    %rax,%rsi
 100f12f:	48 83 c6 40          	add    $0x40,%rsi
 100f133:	48 89 75 c8          	mov    %rsi,-0x38(%rbp)
 100f137:	48 8d 05 12 fe 01 00 	lea    0x1fe12(%rip),%rax        # 102ef50 <myl_t_db6bd58975531b7368ca22b8af460e2a11856412c594a38caca68120ceaa09fc>
 100f13e:	48 89 85 88 fc ff ff 	mov    %rax,-0x378(%rbp)
 100f145:	c7 85 a0 fc ff ff 02 	movl   $0x2,-0x360(%rbp)
 100f14c:	00 00 00 
 100f14f:	48 8d 85 e8 fe ff ff 	lea    -0x118(%rbp),%rax
 100f156:	48 89 85 90 fc ff ff 	mov    %rax,-0x370(%rbp)
 100f15d:	48 8d 85 e8 fd ff ff 	lea    -0x218(%rbp),%rax
 100f164:	48 89 c1             	mov    %rax,%rcx
 100f167:	48 83 c1 10          	add    $0x10,%rcx
 100f16b:	48 89 4d d0          	mov    %rcx,-0x30(%rbp)
 100f16f:	48 89 8d 98 fc ff ff 	mov    %rcx,-0x368(%rbp)
 100f176:	48 8d 05 83 fc 01 00 	lea    0x1fc83(%rip),%rax        # 102ee00 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b>
 100f17d:	48 89 85 a8 fc ff ff 	mov    %rax,-0x358(%rbp)
 100f184:	c7 85 c0 fc ff ff 02 	movl   $0x2,-0x340(%rbp)
 100f18b:	00 00 00 
 100f18e:	48 8d 85 f0 fe ff ff 	lea    -0x110(%rbp),%rax
 100f195:	48 89 85 b0 fc ff ff 	mov    %rax,-0x350(%rbp)
 100f19c:	48 8d 85 e8 fd ff ff 	lea    -0x218(%rbp),%rax
 100f1a3:	48 83 c0 18          	add    $0x18,%rax
 100f1a7:	48 89 85 b8 fc ff ff 	mov    %rax,-0x348(%rbp)
 100f1ae:	48 8d 05 db fb 01 00 	lea    0x1fbdb(%rip),%rax        # 102ed90 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a>
 100f1b5:	48 89 85 c8 fc ff ff 	mov    %rax,-0x338(%rbp)
 100f1bc:	c7 85 e0 fc ff ff 02 	movl   $0x2,-0x320(%rbp)
 100f1c3:	00 00 00 
 100f1c6:	48 8d 85 f8 fe ff ff 	lea    -0x108(%rbp),%rax
 100f1cd:	48 89 85 d0 fc ff ff 	mov    %rax,-0x330(%rbp)
 100f1d4:	48 8d 85 e8 fd ff ff 	lea    -0x218(%rbp),%rax
 100f1db:	48 83 c0 20          	add    $0x20,%rax
 100f1df:	48 89 85 d8 fc ff ff 	mov    %rax,-0x328(%rbp)
 100f1e6:	48 8d 05 63 fd 01 00 	lea    0x1fd63(%rip),%rax        # 102ef50 <myl_t_db6bd58975531b7368ca22b8af460e2a11856412c594a38caca68120ceaa09fc>
 100f1ed:	48 89 85 e8 fc ff ff 	mov    %rax,-0x318(%rbp)
 100f1f4:	c7 85 00 fd ff ff 02 	movl   $0x2,-0x300(%rbp)
 100f1fb:	00 00 00 
 100f1fe:	48 8d 85 00 ff ff ff 	lea    -0x100(%rbp),%rax
 100f205:	48 89 85 f0 fc ff ff 	mov    %rax,-0x310(%rbp)
 100f20c:	48 8d 85 e8 fd ff ff 	lea    -0x218(%rbp),%rax
 100f213:	48 83 c0 28          	add    $0x28,%rax
 100f217:	48 89 85 f8 fc ff ff 	mov    %rax,-0x308(%rbp)
 100f21e:	48 8d 85 48 fc ff ff 	lea    -0x3b8(%rbp),%rax
 100f225:	48 89 c6             	mov    %rax,%rsi
 100f228:	48 81 c6 c0 00 00 00 	add    $0xc0,%rsi
 100f22f:	48 89 75 b0          	mov    %rsi,-0x50(%rbp)
 100f233:	48 8d 05 c6 fb 01 00 	lea    0x1fbc6(%rip),%rax        # 102ee00 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b>
 100f23a:	48 89 85 08 fd ff ff 	mov    %rax,-0x2f8(%rbp)
 100f241:	c7 85 20 fd ff ff 02 	movl   $0x2,-0x2e0(%rbp)
 100f248:	00 00 00 
 100f24b:	48 8d 85 08 ff ff ff 	lea    -0xf8(%rbp),%rax
 100f252:	48 89 85 10 fd ff ff 	mov    %rax,-0x2f0(%rbp)
 100f259:	48 8d 85 e8 fd ff ff 	lea    -0x218(%rbp),%rax
 100f260:	49 89 c4             	mov    %rax,%r12
 100f263:	49 83 c4 30          	add    $0x30,%r12
 100f267:	4c 89 65 a8          	mov    %r12,-0x58(%rbp)
 100f26b:	4c 89 a5 18 fd ff ff 	mov    %r12,-0x2e8(%rbp)
 100f272:	48 8d 85 48 fc ff ff 	lea    -0x3b8(%rbp),%rax
 100f279:	49 89 c7             	mov    %rax,%r15
 100f27c:	49 81 c7 e0 00 00 00 	add    $0xe0,%r15
 100f283:	4c 89 bd 50 ff ff ff 	mov    %r15,-0xb0(%rbp)
 100f28a:	48 8d 05 ff fa 01 00 	lea    0x1faff(%rip),%rax        # 102ed90 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a>
 100f291:	48 89 85 28 fd ff ff 	mov    %rax,-0x2d8(%rbp)
 100f298:	c7 85 40 fd ff ff 02 	movl   $0x2,-0x2c0(%rbp)
 100f29f:	00 00 00 
 100f2a2:	48 8d 85 10 ff ff ff 	lea    -0xf0(%rbp),%rax
 100f2a9:	48 89 85 30 fd ff ff 	mov    %rax,-0x2d0(%rbp)
 100f2b0:	48 8d 85 e8 fd ff ff 	lea    -0x218(%rbp),%rax
 100f2b7:	49 89 c1             	mov    %rax,%r9
 100f2ba:	49 83 c1 38          	add    $0x38,%r9
 100f2be:	4c 89 8d 68 ff ff ff 	mov    %r9,-0x98(%rbp)
 100f2c5:	4c 89 8d 38 fd ff ff 	mov    %r9,-0x2c8(%rbp)
 100f2cc:	48 8d 85 48 fc ff ff 	lea    -0x3b8(%rbp),%rax
 100f2d3:	49 89 c5             	mov    %rax,%r13
 100f2d6:	49 81 c5 00 01 00 00 	add    $0x100,%r13
 100f2dd:	48 8d 05 94 49 ff ff 	lea    -0xb66c(%rip),%rax        # 1003c78 <myl_t_385cfdbc00ec32031699460779c15099b2bba3cad0e440fffb08e10df0acb9e1>
 100f2e4:	48 89 85 48 fd ff ff 	mov    %rax,-0x2b8(%rbp)
 100f2eb:	c7 85 60 fd ff ff 00 	movl   $0x0,-0x2a0(%rbp)
 100f2f2:	00 00 00 
 100f2f5:	48 8d 85 50 fe ff ff 	lea    -0x1b0(%rbp),%rax
 100f2fc:	48 89 85 50 fd ff ff 	mov    %rax,-0x2b0(%rbp)
 100f303:	48 8d 85 e8 fd ff ff 	lea    -0x218(%rbp),%rax
 100f30a:	49 89 c7             	mov    %rax,%r15
 100f30d:	49 83 c7 40          	add    $0x40,%r15
 100f311:	4c 89 7d c0          	mov    %r15,-0x40(%rbp)
 100f315:	4c 89 bd 58 fd ff ff 	mov    %r15,-0x2a8(%rbp)
 100f31c:	48 8d 85 48 fc ff ff 	lea    -0x3b8(%rbp),%rax
 100f323:	48 89 c6             	mov    %rax,%rsi
 100f326:	48 81 c6 20 01 00 00 	add    $0x120,%rsi
 100f32d:	48 89 b5 58 ff ff ff 	mov    %rsi,-0xa8(%rbp)
 100f334:	48 8d 05 3d 49 ff ff 	lea    -0xb6c3(%rip),%rax        # 1003c78 <myl_t_385cfdbc00ec32031699460779c15099b2bba3cad0e440fffb08e10df0acb9e1>
 100f33b:	48 89 85 68 fd ff ff 	mov    %rax,-0x298(%rbp)
 100f342:	c7 85 80 fd ff ff 00 	movl   $0x0,-0x280(%rbp)
 100f349:	00 00 00 
 100f34c:	48 8d 85 58 fe ff ff 	lea    -0x1a8(%rbp),%rax
 100f353:	48 89 85 70 fd ff ff 	mov    %rax,-0x290(%rbp)
 100f35a:	48 8d 85 e8 fd ff ff 	lea    -0x218(%rbp),%rax
 100f361:	48 83 c0 48          	add    $0x48,%rax
 100f365:	48 89 85 78 fd ff ff 	mov    %rax,-0x288(%rbp)
 100f36c:	48 8d 85 48 fc ff ff 	lea    -0x3b8(%rbp),%rax
 100f373:	49 89 c0             	mov    %rax,%r8
 100f376:	49 81 c0 40 01 00 00 	add    $0x140,%r8
 100f37d:	4c 89 85 60 ff ff ff 	mov    %r8,-0xa0(%rbp)
 100f384:	48 8d 05 ed 48 ff ff 	lea    -0xb713(%rip),%rax        # 1003c78 <myl_t_385cfdbc00ec32031699460779c15099b2bba3cad0e440fffb08e10df0acb9e1>
 100f38b:	48 89 85 88 fd ff ff 	mov    %rax,-0x278(%rbp)
 100f392:	c7 85 a0 fd ff ff 00 	movl   $0x0,-0x260(%rbp)
 100f399:	00 00 00 
 100f39c:	48 8d 85 60 fe ff ff 	lea    -0x1a0(%rbp),%rax
 100f3a3:	48 89 85 90 fd ff ff 	mov    %rax,-0x270(%rbp)
 100f3aa:	48 8d 85 e8 fd ff ff 	lea    -0x218(%rbp),%rax
 100f3b1:	48 83 c0 50          	add    $0x50,%rax
 100f3b5:	48 89 85 98 fd ff ff 	mov    %rax,-0x268(%rbp)
 100f3bc:	48 8d 05 b5 48 ff ff 	lea    -0xb74b(%rip),%rax        # 1003c78 <myl_t_385cfdbc00ec32031699460779c15099b2bba3cad0e440fffb08e10df0acb9e1>
 100f3c3:	48 89 85 a8 fd ff ff 	mov    %rax,-0x258(%rbp)
 100f3ca:	c7 85 c0 fd ff ff 00 	movl   $0x0,-0x240(%rbp)
 100f3d1:	00 00 00 
 100f3d4:	48 8d 85 68 fe ff ff 	lea    -0x198(%rbp),%rax
 100f3db:	48 89 85 b0 fd ff ff 	mov    %rax,-0x250(%rbp)
 100f3e2:	48 8d 85 e8 fd ff ff 	lea    -0x218(%rbp),%rax
 100f3e9:	49 89 c4             	mov    %rax,%r12
 100f3ec:	49 83 c4 58          	add    $0x58,%r12
 100f3f0:	4c 89 65 b8          	mov    %r12,-0x48(%rbp)
 100f3f4:	4c 89 a5 b8 fd ff ff 	mov    %r12,-0x248(%rbp)
 100f3fb:	48 8d 05 76 48 ff ff 	lea    -0xb78a(%rip),%rax        # 1003c78 <myl_t_385cfdbc00ec32031699460779c15099b2bba3cad0e440fffb08e10df0acb9e1>
 100f402:	48 89 85 c8 fd ff ff 	mov    %rax,-0x238(%rbp)
 100f409:	c7 85 e0 fd ff ff 00 	movl   $0x0,-0x220(%rbp)
 100f410:	00 00 00 
 100f413:	48 8d 85 70 fe ff ff 	lea    -0x190(%rbp),%rax
 100f41a:	48 89 85 d0 fd ff ff 	mov    %rax,-0x230(%rbp)
 100f421:	48 8d 85 e8 fd ff ff 	lea    -0x218(%rbp),%rax
 100f428:	48 89 c2             	mov    %rax,%rdx
 100f42b:	48 83 c2 60          	add    $0x60,%rdx
 100f42f:	48 89 55 d8          	mov    %rdx,-0x28(%rbp)
 100f433:	48 89 95 d8 fd ff ff 	mov    %rdx,-0x228(%rbp)
 100f43a:	b9 0d 00 00 00       	mov    $0xd,%ecx
 100f43f:	48 8d 95 48 fc ff ff 	lea    -0x3b8(%rbp),%rdx
 100f446:	48 8d b5 28 fc ff ff 	lea    -0x3d8(%rbp),%rsi
 100f44d:	49 89 ff             	mov    %rdi,%r15
 100f450:	e8 2b 73 00 00       	call   1016780 <myl_qbe_rc_frame_enter>
 100f455:	4c 89 ff             	mov    %r15,%rdi
 100f458:	49 89 ff             	mov    %rdi,%r15
 100f45b:	e8 60 7c 00 00       	call   10170c0 <myl_qbe_require_step_accounting>
 100f460:	4c 89 ff             	mov    %r15,%rdi
 100f463:	49 89 ff             	mov    %rdi,%r15
 100f466:	e8 b5 7c 00 00       	call   1017120 <myl_qbe_require_frame_accounting>
 100f46b:	4c 89 ff             	mov    %r15,%rdi
 100f46e:	48 c7 85 18 ff ff ff 	movq   $0x0,-0xe8(%rbp)
 100f475:	00 00 00 00 
 100f479:	ba 00 00 00 00       	mov    $0x0,%edx
 100f47e:	48 8d 35 0b f9 01 00 	lea    0x1f90b(%rip),%rsi        # 102ed90 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a>
 100f485:	49 89 ff             	mov    %rdi,%r15
 100f488:	48 89 df             	mov    %rbx,%rdi
 100f48b:	e8 f0 e1 00 00       	call   101d680 <myl_native_list_new>
 100f490:	4c 89 ff             	mov    %r15,%rdi
 100f493:	4c 8b 45 e0          	mov    -0x20(%rbp),%r8
 100f497:	83 f8 00             	cmp    $0x0,%eax
 100f49a:	75 0a                	jne    100f4a6 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x506>
 100f49c:	48 89 fb             	mov    %rdi,%rbx
 100f49f:	e8 4c 79 00 00       	call   1016df0 <myl_qbe_fail_allocation>
 100f4a4:	0f 0b                	ud2
 100f4a6:	48 87 fb             	xchg   %rdi,%rbx
 100f4a9:	48 89 85 18 ff ff ff 	mov    %rax,-0xe8(%rbp)
 100f4b0:	48 8b 8d 18 ff ff ff 	mov    -0xe8(%rbp),%rcx
 100f4b7:	48 89 8d 68 fe ff ff 	mov    %rcx,-0x198(%rbp)
 100f4be:	48 8d 0d 3b f9 01 00 	lea    0x1f93b(%rip),%rcx        # 102ee00 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b>
 100f4c5:	48 89 8d a8 fd ff ff 	mov    %rcx,-0x258(%rbp)
 100f4cc:	c7 85 c0 fd ff ff 02 	movl   $0x2,-0x240(%rbp)
 100f4d3:	00 00 00 
 100f4d6:	c7 85 40 fe ff ff 01 	movl   $0x1,-0x1c0(%rbp)
 100f4dd:	00 00 00 
 100f4e0:	48 8b 8d 68 fe ff ff 	mov    -0x198(%rbp),%rcx
 100f4e7:	48 89 8d 50 fe ff ff 	mov    %rcx,-0x1b0(%rbp)
 100f4ee:	48 8d 0d 0b f9 01 00 	lea    0x1f90b(%rip),%rcx        # 102ee00 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b>
 100f4f5:	48 89 8d 48 fd ff ff 	mov    %rcx,-0x2b8(%rbp)
 100f4fc:	c7 85 60 fd ff ff 02 	movl   $0x2,-0x2a0(%rbp)
 100f503:	00 00 00 
 100f506:	c7 85 60 fd ff ff 02 	movl   $0x2,-0x2a0(%rbp)
 100f50d:	00 00 00 
 100f510:	c7 85 40 fe ff ff 00 	movl   $0x0,-0x1c0(%rbp)
 100f517:	00 00 00 
 100f51a:	c7 85 28 fe ff ff 01 	movl   $0x1,-0x1d8(%rbp)
 100f521:	00 00 00 
 100f524:	48 89 85 18 ff ff ff 	mov    %rax,-0xe8(%rbp)
 100f52b:	48 8d 95 68 fe ff ff 	lea    -0x198(%rbp),%rdx
 100f532:	48 8d 8d 18 ff ff ff 	lea    -0xe8(%rbp),%rcx
 100f539:	48 29 d1             	sub    %rdx,%rcx
 100f53c:	48 8d b5 18 ff ff ff 	lea    -0xe8(%rbp),%rsi
 100f543:	48 8d 95 68 fe ff ff 	lea    -0x198(%rbp),%rdx
 100f54a:	48 29 f2             	sub    %rsi,%rdx
 100f54d:	48 83 f9 08          	cmp    $0x8,%rcx
 100f551:	0f 92 c1             	setb   %cl
 100f554:	0f b6 c9             	movzbl %cl,%ecx
 100f557:	89 4d e8             	mov    %ecx,-0x18(%rbp)
 100f55a:	48 83 fa 08          	cmp    $0x8,%rdx
 100f55e:	0f 92 c2             	setb   %dl
 100f561:	0f b6 d2             	movzbl %dl,%edx
 100f564:	89 55 ec             	mov    %edx,-0x14(%rbp)
 100f567:	09 d1                	or     %edx,%ecx
 100f569:	75 5a                	jne    100f5c5 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x625>
 100f56b:	48 83 f8 00          	cmp    $0x0,%rax
 100f56f:	74 1a                	je     100f58b <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x5eb>
 100f571:	48 83 e8 10          	sub    $0x10,%rax
 100f575:	48 8b 00             	mov    (%rax),%rax
 100f578:	48 b9 01 00 00 00 00 	movabs $0x5000000000000001,%rcx
 100f57f:	00 00 50 
 100f582:	48 21 c8             	and    %rcx,%rax
 100f585:	48 83 f8 00          	cmp    $0x0,%rax
 100f589:	75 3a                	jne    100f5c5 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x625>
 100f58b:	48 8b 85 18 ff ff ff 	mov    -0xe8(%rbp),%rax
 100f592:	48 89 85 68 fe ff ff 	mov    %rax,-0x198(%rbp)
 100f599:	ba 08 00 00 00       	mov    $0x8,%edx
 100f59e:	be 00 00 00 00       	mov    $0x0,%esi
 100f5a3:	49 89 ff             	mov    %rdi,%r15
 100f5a6:	48 8d bd 18 ff ff ff 	lea    -0xe8(%rbp),%rdi
 100f5ad:	e8 ce cd 01 00       	call   102c380 <compiler_rt.fastMemset>
 100f5b2:	4c 89 ff             	mov    %r15,%rdi
 100f5b5:	8b 55 ec             	mov    -0x14(%rbp),%edx
 100f5b8:	8b 4d e8             	mov    -0x18(%rbp),%ecx
 100f5bb:	48 8b 75 f0          	mov    -0x10(%rbp),%rsi
 100f5bf:	4c 8b 45 e0          	mov    -0x20(%rbp),%r8
 100f5c3:	eb 4d                	jmp    100f612 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x672>
 100f5c5:	48 8d 8d 18 ff ff ff 	lea    -0xe8(%rbp),%rcx
 100f5cc:	48 8d 95 68 fe ff ff 	lea    -0x198(%rbp),%rdx
 100f5d3:	48 8d 35 26 f8 01 00 	lea    0x1f826(%rip),%rsi        # 102ee00 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b>
 100f5da:	49 89 ff             	mov    %rdi,%r15
 100f5dd:	e8 fe c1 01 00       	call   102b7e0 <myl_rc_native_take>
 100f5e2:	4c 89 ff             	mov    %r15,%rdi
 100f5e5:	8b 55 ec             	mov    -0x14(%rbp),%edx
 100f5e8:	8b 4d e8             	mov    -0x18(%rbp),%ecx
 100f5eb:	48 8b 75 f0          	mov    -0x10(%rbp),%rsi
 100f5ef:	4c 8b 45 e0          	mov    -0x20(%rbp),%r8
 100f5f3:	83 f8 00             	cmp    $0x0,%eax
 100f5f6:	75 1a                	jne    100f612 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x672>
 100f5f8:	e8 03 42 01 00       	call   1023800 <myl_rc_take_failure>
 100f5fd:	48 89 df             	mov    %rbx,%rdi
 100f600:	89 c6                	mov    %eax,%esi
 100f602:	48 89 fb             	mov    %rdi,%rbx
 100f605:	e8 86 70 00 00       	call   1016690 <myl_qbe_rc_status>
 100f60a:	48 89 df             	mov    %rbx,%rdi
 100f60d:	e9 93 17 00 00       	jmp    1010da5 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1e05>
 100f612:	c7 85 28 fe ff ff 00 	movl   $0x0,-0x1d8(%rbp)
 100f619:	00 00 00 
 100f61c:	48 8d 05 dd f7 01 00 	lea    0x1f7dd(%rip),%rax        # 102ee00 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b>
 100f623:	48 89 85 a8 fd ff ff 	mov    %rax,-0x258(%rbp)
 100f62a:	c7 85 c0 fd ff ff 02 	movl   $0x2,-0x240(%rbp)
 100f631:	00 00 00 
 100f634:	c7 85 40 fe ff ff 01 	movl   $0x1,-0x1c0(%rbp)
 100f63b:	00 00 00 
 100f63e:	8b 85 e8 fd ff ff    	mov    -0x218(%rbp),%eax
 100f644:	83 f8 00             	cmp    $0x0,%eax
 100f647:	74 23                	je     100f66c <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x6cc>
 100f649:	48 8d b5 48 fc ff ff 	lea    -0x3b8(%rbp),%rsi
 100f650:	49 89 ff             	mov    %rdi,%r15
 100f653:	48 89 df             	mov    %rbx,%rdi
 100f656:	e8 05 72 00 00       	call   1016860 <myl_qbe_rc_slot_drop>
 100f65b:	4c 89 ff             	mov    %r15,%rdi
 100f65e:	8b 55 ec             	mov    -0x14(%rbp),%edx
 100f661:	8b 4d e8             	mov    -0x18(%rbp),%ecx
 100f664:	48 8b 75 f0          	mov    -0x10(%rbp),%rsi
 100f668:	4c 8b 45 e0          	mov    -0x20(%rbp),%r8
 100f66c:	48 8b 85 68 fe ff ff 	mov    -0x198(%rbp),%rax
 100f673:	48 89 85 d8 fe ff ff 	mov    %rax,-0x128(%rbp)
 100f67a:	c7 85 40 fe ff ff 00 	movl   $0x0,-0x1c0(%rbp)
 100f681:	00 00 00 
 100f684:	48 8d 05 75 f7 01 00 	lea    0x1f775(%rip),%rax        # 102ee00 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b>
 100f68b:	48 89 85 48 fc ff ff 	mov    %rax,-0x3b8(%rbp)
 100f692:	c7 85 60 fc ff ff 02 	movl   $0x2,-0x3a0(%rbp)
 100f699:	00 00 00 
 100f69c:	48 8d 85 d8 fe ff ff 	lea    -0x128(%rbp),%rax
 100f6a3:	48 89 85 50 fc ff ff 	mov    %rax,-0x3b0(%rbp)
 100f6aa:	48 8d 85 e8 fd ff ff 	lea    -0x218(%rbp),%rax
 100f6b1:	48 89 85 58 fc ff ff 	mov    %rax,-0x3a8(%rbp)
 100f6b8:	8b 85 c0 fd ff ff    	mov    -0x240(%rbp),%eax
 100f6be:	89 85 60 fc ff ff    	mov    %eax,-0x3a0(%rbp)
 100f6c4:	c7 85 e8 fd ff ff 01 	movl   $0x1,-0x218(%rbp)
 100f6cb:	00 00 00 
 100f6ce:	41 89 c1             	mov    %eax,%r9d
 100f6d1:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
 100f6d8:	41 83 f9 08          	cmp    $0x8,%r9d
 100f6dc:	74 0c                	je     100f6ea <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x74a>
 100f6de:	48 89 85 18 ff ff ff 	mov    %rax,-0xe8(%rbp)
 100f6e5:	e9 f0 00 00 00       	jmp    100f7da <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x83a>
 100f6ea:	48 c7 85 68 fe ff ff 	movq   $0x0,-0x198(%rbp)
 100f6f1:	00 00 00 00 
 100f6f5:	48 8d 95 68 fe ff ff 	lea    -0x198(%rbp),%rdx
 100f6fc:	48 89 c6             	mov    %rax,%rsi
 100f6ff:	49 89 ff             	mov    %rdi,%r15
 100f702:	e8 49 46 01 00       	call   1023d50 <myl_rc_hold_acquire>
 100f707:	4c 89 ff             	mov    %r15,%rdi
 100f70a:	89 c6                	mov    %eax,%esi
 100f70c:	49 89 ff             	mov    %rdi,%r15
 100f70f:	48 89 df             	mov    %rbx,%rdi
 100f712:	e8 79 6f 00 00       	call   1016690 <myl_qbe_rc_status>
 100f717:	4c 89 ff             	mov    %r15,%rdi
 100f71a:	8b 55 ec             	mov    -0x14(%rbp),%edx
 100f71d:	8b 4d e8             	mov    -0x18(%rbp),%ecx
 100f720:	4c 8b 7d c0          	mov    -0x40(%rbp),%r15
 100f724:	48 8b 75 f0          	mov    -0x10(%rbp),%rsi
 100f728:	4c 8b 45 e0          	mov    -0x20(%rbp),%r8
 100f72c:	83 f8 00             	cmp    $0x0,%eax
 100f72f:	75 08                	jne    100f739 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x799>
 100f731:	48 89 df             	mov    %rbx,%rdi
 100f734:	e9 6c 16 00 00       	jmp    1010da5 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1e05>
 100f739:	48 8d 05 c0 f6 01 00 	lea    0x1f6c0(%rip),%rax        # 102ee00 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b>
 100f740:	48 89 85 a8 fd ff ff 	mov    %rax,-0x258(%rbp)
 100f747:	c7 85 c0 fd ff ff 02 	movl   $0x2,-0x240(%rbp)
 100f74e:	00 00 00 
 100f751:	48 8d 85 68 fe ff ff 	lea    -0x198(%rbp),%rax
 100f758:	48 89 85 b0 fd ff ff 	mov    %rax,-0x250(%rbp)
 100f75f:	4c 89 a5 b8 fd ff ff 	mov    %r12,-0x248(%rbp)
 100f766:	c7 85 c0 fd ff ff 08 	movl   $0x8,-0x240(%rbp)
 100f76d:	00 00 00 
 100f770:	c7 85 40 fe ff ff 01 	movl   $0x1,-0x1c0(%rbp)
 100f777:	00 00 00 
 100f77a:	48 8b 85 68 fe ff ff 	mov    -0x198(%rbp),%rax
 100f781:	48 89 85 50 fe ff ff 	mov    %rax,-0x1b0(%rbp)
 100f788:	4c 8d 0d 71 f6 01 00 	lea    0x1f671(%rip),%r9        # 102ee00 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b>
 100f78f:	4c 89 8d 48 fd ff ff 	mov    %r9,-0x2b8(%rbp)
 100f796:	c7 85 60 fd ff ff 02 	movl   $0x2,-0x2a0(%rbp)
 100f79d:	00 00 00 
 100f7a0:	4c 8d 8d 50 fe ff ff 	lea    -0x1b0(%rbp),%r9
 100f7a7:	4c 89 8d 50 fd ff ff 	mov    %r9,-0x2b0(%rbp)
 100f7ae:	4c 89 bd 58 fd ff ff 	mov    %r15,-0x2a8(%rbp)
 100f7b5:	c7 85 60 fd ff ff 08 	movl   $0x8,-0x2a0(%rbp)
 100f7bc:	00 00 00 
 100f7bf:	c7 85 28 fe ff ff 01 	movl   $0x1,-0x1d8(%rbp)
 100f7c6:	00 00 00 
 100f7c9:	c7 85 40 fe ff ff 00 	movl   $0x0,-0x1c0(%rbp)
 100f7d0:	00 00 00 
 100f7d3:	48 89 85 18 ff ff ff 	mov    %rax,-0xe8(%rbp)
 100f7da:	44 8b 8d 28 fe ff ff 	mov    -0x1d8(%rbp),%r9d
 100f7e1:	44 8b 95 60 fd ff ff 	mov    -0x2a0(%rbp),%r10d
 100f7e8:	41 83 e2 18          	and    $0x18,%r10d
 100f7ec:	41 83 fa 00          	cmp    $0x0,%r10d
 100f7f0:	41 0f 94 c2          	sete   %r10b
 100f7f4:	45 0f b6 d2          	movzbl %r10b,%r10d
 100f7f8:	45 85 ca             	test   %r9d,%r10d
 100f7fb:	0f 85 91 00 00 00    	jne    100f892 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x8f2>
 100f801:	48 8d 8d 18 ff ff ff 	lea    -0xe8(%rbp),%rcx
 100f808:	48 8d 95 68 fe ff ff 	lea    -0x198(%rbp),%rdx
 100f80f:	49 89 f7             	mov    %rsi,%r15
 100f812:	48 8d 35 e7 f5 01 00 	lea    0x1f5e7(%rip),%rsi        # 102ee00 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b>
 100f819:	49 89 fc             	mov    %rdi,%r12
 100f81c:	e8 3f c6 01 00       	call   102be60 <myl_rc_native_retain>
 100f821:	4c 89 fe             	mov    %r15,%rsi
 100f824:	4c 89 e7             	mov    %r12,%rdi
 100f827:	83 f8 00             	cmp    $0x0,%eax
 100f82a:	75 1a                	jne    100f846 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x8a6>
 100f82c:	e8 cf 3f 01 00       	call   1023800 <myl_rc_take_failure>
 100f831:	48 89 df             	mov    %rbx,%rdi
 100f834:	89 c6                	mov    %eax,%esi
 100f836:	48 89 fb             	mov    %rdi,%rbx
 100f839:	e8 52 6e 00 00       	call   1016690 <myl_qbe_rc_status>
 100f83e:	48 89 df             	mov    %rbx,%rdi
 100f841:	e9 5f 15 00 00       	jmp    1010da5 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1e05>
 100f846:	48 8d 05 b3 f5 01 00 	lea    0x1f5b3(%rip),%rax        # 102ee00 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b>
 100f84d:	48 89 85 a8 fd ff ff 	mov    %rax,-0x258(%rbp)
 100f854:	c7 85 c0 fd ff ff 02 	movl   $0x2,-0x240(%rbp)
 100f85b:	00 00 00 
 100f85e:	c7 85 40 fe ff ff 01 	movl   $0x1,-0x1c0(%rbp)
 100f865:	00 00 00 
 100f868:	8b 85 28 fe ff ff    	mov    -0x1d8(%rbp),%eax
 100f86e:	83 f8 00             	cmp    $0x0,%eax
 100f871:	74 17                	je     100f88a <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x8ea>
 100f873:	49 89 f7             	mov    %rsi,%r15
 100f876:	4c 89 ee             	mov    %r13,%rsi
 100f879:	49 89 fc             	mov    %rdi,%r12
 100f87c:	48 89 df             	mov    %rbx,%rdi
 100f87f:	e8 dc 6f 00 00       	call   1016860 <myl_qbe_rc_slot_drop>
 100f884:	4c 89 fe             	mov    %r15,%rsi
 100f887:	4c 89 e7             	mov    %r12,%rdi
 100f88a:	48 87 df             	xchg   %rbx,%rdi
 100f88d:	e9 cd 00 00 00       	jmp    100f95f <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x9bf>
 100f892:	09 d1                	or     %edx,%ecx
 100f894:	75 55                	jne    100f8eb <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x94b>
 100f896:	48 83 f8 00          	cmp    $0x0,%rax
 100f89a:	74 1a                	je     100f8b6 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x916>
 100f89c:	48 83 e8 10          	sub    $0x10,%rax
 100f8a0:	48 8b 00             	mov    (%rax),%rax
 100f8a3:	48 b9 01 00 00 00 00 	movabs $0x5000000000000001,%rcx
 100f8aa:	00 00 50 
 100f8ad:	48 21 c8             	and    %rcx,%rax
 100f8b0:	48 83 f8 00          	cmp    $0x0,%rax
 100f8b4:	75 35                	jne    100f8eb <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x94b>
 100f8b6:	48 8b 85 18 ff ff ff 	mov    -0xe8(%rbp),%rax
 100f8bd:	48 89 85 68 fe ff ff 	mov    %rax,-0x198(%rbp)
 100f8c4:	ba 08 00 00 00       	mov    $0x8,%edx
 100f8c9:	49 89 f7             	mov    %rsi,%r15
 100f8cc:	be 00 00 00 00       	mov    $0x0,%esi
 100f8d1:	49 89 fc             	mov    %rdi,%r12
 100f8d4:	48 8d bd 18 ff ff ff 	lea    -0xe8(%rbp),%rdi
 100f8db:	e8 a0 ca 01 00       	call   102c380 <compiler_rt.fastMemset>
 100f8e0:	4c 89 fe             	mov    %r15,%rsi
 100f8e3:	4c 89 e7             	mov    %r12,%rdi
 100f8e6:	48 87 df             	xchg   %rbx,%rdi
 100f8e9:	eb 48                	jmp    100f933 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x993>
 100f8eb:	48 8d 8d 18 ff ff ff 	lea    -0xe8(%rbp),%rcx
 100f8f2:	48 8d 95 68 fe ff ff 	lea    -0x198(%rbp),%rdx
 100f8f9:	49 89 f7             	mov    %rsi,%r15
 100f8fc:	48 8d 35 fd f4 01 00 	lea    0x1f4fd(%rip),%rsi        # 102ee00 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b>
 100f903:	49 89 fc             	mov    %rdi,%r12
 100f906:	e8 d5 be 01 00       	call   102b7e0 <myl_rc_native_take>
 100f90b:	4c 89 fe             	mov    %r15,%rsi
 100f90e:	4c 89 e7             	mov    %r12,%rdi
 100f911:	83 f8 00             	cmp    $0x0,%eax
 100f914:	75 1a                	jne    100f930 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x990>
 100f916:	e8 e5 3e 01 00       	call   1023800 <myl_rc_take_failure>
 100f91b:	48 89 df             	mov    %rbx,%rdi
 100f91e:	89 c6                	mov    %eax,%esi
 100f920:	48 89 fb             	mov    %rdi,%rbx
 100f923:	e8 68 6d 00 00       	call   1016690 <myl_qbe_rc_status>
 100f928:	48 89 df             	mov    %rbx,%rdi
 100f92b:	e9 75 14 00 00       	jmp    1010da5 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1e05>
 100f930:	48 87 df             	xchg   %rbx,%rdi
 100f933:	c7 85 28 fe ff ff 00 	movl   $0x0,-0x1d8(%rbp)
 100f93a:	00 00 00 
 100f93d:	48 8d 05 bc f4 01 00 	lea    0x1f4bc(%rip),%rax        # 102ee00 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b>
 100f944:	48 89 85 a8 fd ff ff 	mov    %rax,-0x258(%rbp)
 100f94b:	c7 85 c0 fd ff ff 02 	movl   $0x2,-0x240(%rbp)
 100f952:	00 00 00 
 100f955:	c7 85 40 fe ff ff 01 	movl   $0x1,-0x1c0(%rbp)
 100f95c:	00 00 00 
 100f95f:	8b 85 f0 fd ff ff    	mov    -0x210(%rbp),%eax
 100f965:	83 f8 00             	cmp    $0x0,%eax
 100f968:	74 0b                	je     100f975 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x9d5>
 100f96a:	49 89 fc             	mov    %rdi,%r12
 100f96d:	e8 ee 6e 00 00       	call   1016860 <myl_qbe_rc_slot_drop>
 100f972:	4c 89 e7             	mov    %r12,%rdi
 100f975:	48 8b 85 68 fe ff ff 	mov    -0x198(%rbp),%rax
 100f97c:	48 89 85 e0 fe ff ff 	mov    %rax,-0x120(%rbp)
 100f983:	c7 85 40 fe ff ff 00 	movl   $0x0,-0x1c0(%rbp)
 100f98a:	00 00 00 
 100f98d:	48 8d 05 6c f4 01 00 	lea    0x1f46c(%rip),%rax        # 102ee00 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b>
 100f994:	48 89 85 68 fc ff ff 	mov    %rax,-0x398(%rbp)
 100f99b:	c7 85 80 fc ff ff 02 	movl   $0x2,-0x380(%rbp)
 100f9a2:	00 00 00 
 100f9a5:	48 8d 85 e0 fe ff ff 	lea    -0x120(%rbp),%rax
 100f9ac:	48 89 85 70 fc ff ff 	mov    %rax,-0x390(%rbp)
 100f9b3:	4c 89 b5 78 fc ff ff 	mov    %r14,-0x388(%rbp)
 100f9ba:	8b 85 c0 fd ff ff    	mov    -0x240(%rbp),%eax
 100f9c0:	89 85 80 fc ff ff    	mov    %eax,-0x380(%rbp)
 100f9c6:	c7 85 f0 fd ff ff 01 	movl   $0x1,-0x210(%rbp)
 100f9cd:	00 00 00 
 100f9d0:	8b 85 e8 fd ff ff    	mov    -0x218(%rbp),%eax
 100f9d6:	83 f8 00             	cmp    $0x0,%eax
 100f9d9:	74 12                	je     100f9ed <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xa4d>
 100f9db:	48 8d b5 48 fc ff ff 	lea    -0x3b8(%rbp),%rsi
 100f9e2:	49 89 fc             	mov    %rdi,%r12
 100f9e5:	e8 76 6e 00 00       	call   1016860 <myl_qbe_rc_slot_drop>
 100f9ea:	4c 89 e7             	mov    %r12,%rdi
 100f9ed:	48 c7 85 18 ff ff ff 	movq   $0x0,-0xe8(%rbp)
 100f9f4:	00 00 00 00 
 100f9f8:	48 c7 85 18 ff ff ff 	movq   $0x3e8,-0xe8(%rbp)
 100f9ff:	e8 03 00 00 
 100fa03:	41 bc 00 00 00 00    	mov    $0x0,%r12d
 100fa09:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
 100fa10:	4c 89 a5 18 ff ff ff 	mov    %r12,-0xe8(%rbp)
 100fa17:	48 c7 85 20 ff ff ff 	movq   $0x3e8,-0xe0(%rbp)
 100fa1e:	e8 03 00 00 
 100fa22:	49 81 fc e8 03 00 00 	cmp    $0x3e8,%r12
 100fa29:	0f 9c c0             	setl   %al
 100fa2c:	48 0f b6 c0          	movzbq %al,%rax
 100fa30:	48 89 85 18 ff ff ff 	mov    %rax,-0xe8(%rbp)
 100fa37:	0f 8d 40 03 00 00    	jge    100fd7d <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xddd>
 100fa3d:	48 c7 85 18 ff ff ff 	movq   $0x6b,-0xe8(%rbp)
 100fa44:	6b 00 00 00 
 100fa48:	48 c7 85 20 ff ff ff 	movq   $0x65,-0xe0(%rbp)
 100fa4f:	65 00 00 00 
 100fa53:	48 c7 85 28 ff ff ff 	movq   $0x79,-0xd8(%rbp)
 100fa5a:	79 00 00 00 
 100fa5e:	48 8b 05 b3 fb 01 00 	mov    0x1fbb3(%rip),%rax        # 102f618 <myl_lit_7c9ad5bce17f8d7309d981a8c987a567b0a2e56945e29fb3b883a7b4446dd143>
 100fa65:	48 89 85 18 ff ff ff 	mov    %rax,-0xe8(%rbp)
 100fa6c:	48 8b 8d 18 ff ff ff 	mov    -0xe8(%rbp),%rcx
 100fa73:	48 89 8d 68 fe ff ff 	mov    %rcx,-0x198(%rbp)
 100fa7a:	48 8d 0d 0f f3 01 00 	lea    0x1f30f(%rip),%rcx        # 102ed90 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a>
 100fa81:	48 89 8d a8 fd ff ff 	mov    %rcx,-0x258(%rbp)
 100fa88:	c7 85 c0 fd ff ff 02 	movl   $0x2,-0x240(%rbp)
 100fa8f:	00 00 00 
 100fa92:	c7 85 40 fe ff ff 01 	movl   $0x1,-0x1c0(%rbp)
 100fa99:	00 00 00 
 100fa9c:	48 8b 8d 68 fe ff ff 	mov    -0x198(%rbp),%rcx
 100faa3:	48 89 8d 50 fe ff ff 	mov    %rcx,-0x1b0(%rbp)
 100faaa:	48 8d 0d df f2 01 00 	lea    0x1f2df(%rip),%rcx        # 102ed90 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a>
 100fab1:	48 89 8d 48 fd ff ff 	mov    %rcx,-0x2b8(%rbp)
 100fab8:	c7 85 60 fd ff ff 02 	movl   $0x2,-0x2a0(%rbp)
 100fabf:	00 00 00 
 100fac2:	c7 85 60 fd ff ff 02 	movl   $0x2,-0x2a0(%rbp)
 100fac9:	00 00 00 
 100facc:	c7 85 40 fe ff ff 00 	movl   $0x0,-0x1c0(%rbp)
 100fad3:	00 00 00 
 100fad6:	c7 85 28 fe ff ff 01 	movl   $0x1,-0x1d8(%rbp)
 100fadd:	00 00 00 
 100fae0:	48 89 85 18 ff ff ff 	mov    %rax,-0xe8(%rbp)
 100fae7:	4c 89 a5 20 ff ff ff 	mov    %r12,-0xe0(%rbp)
 100faee:	ba 00 00 00 00       	mov    $0x0,%edx
 100faf3:	4c 89 e6             	mov    %r12,%rsi
 100faf6:	49 89 ff             	mov    %rdi,%r15
 100faf9:	48 89 df             	mov    %rbx,%rdi
 100fafc:	e8 bf 14 00 00       	call   1010fc0 <myl_native_text_scalar>
 100fb01:	4c 89 ff             	mov    %r15,%rdi
 100fb04:	48 89 c2             	mov    %rax,%rdx
 100fb07:	83 fa 00             	cmp    $0x0,%edx
 100fb0a:	0f 84 66 02 00 00    	je     100fd76 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xdd6>
 100fb10:	48 89 95 20 ff ff ff 	mov    %rdx,-0xe0(%rbp)
 100fb17:	48 8b 85 20 ff ff ff 	mov    -0xe0(%rbp),%rax
 100fb1e:	48 89 85 68 fe ff ff 	mov    %rax,-0x198(%rbp)
 100fb25:	48 8d 05 64 f2 01 00 	lea    0x1f264(%rip),%rax        # 102ed90 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a>
 100fb2c:	48 89 85 a8 fd ff ff 	mov    %rax,-0x258(%rbp)
 100fb33:	c7 85 c0 fd ff ff 02 	movl   $0x2,-0x240(%rbp)
 100fb3a:	00 00 00 
 100fb3d:	c7 85 40 fe ff ff 01 	movl   $0x1,-0x1c0(%rbp)
 100fb44:	00 00 00 
 100fb47:	48 8b 85 68 fe ff ff 	mov    -0x198(%rbp),%rax
 100fb4e:	48 89 85 58 fe ff ff 	mov    %rax,-0x1a8(%rbp)
 100fb55:	48 8d 05 34 f2 01 00 	lea    0x1f234(%rip),%rax        # 102ed90 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a>
 100fb5c:	48 89 85 68 fd ff ff 	mov    %rax,-0x298(%rbp)
 100fb63:	c7 85 80 fd ff ff 02 	movl   $0x2,-0x280(%rbp)
 100fb6a:	00 00 00 
 100fb6d:	c7 85 80 fd ff ff 02 	movl   $0x2,-0x280(%rbp)
 100fb74:	00 00 00 
 100fb77:	c7 85 40 fe ff ff 00 	movl   $0x0,-0x1c0(%rbp)
 100fb7e:	00 00 00 
 100fb81:	c7 85 30 fe ff ff 01 	movl   $0x1,-0x1d0(%rbp)
 100fb88:	00 00 00 
 100fb8b:	48 89 95 20 ff ff ff 	mov    %rdx,-0xe0(%rbp)
 100fb92:	48 8b b5 18 ff ff ff 	mov    -0xe8(%rbp),%rsi
 100fb99:	49 89 ff             	mov    %rdi,%r15
 100fb9c:	48 89 df             	mov    %rbx,%rdi
 100fb9f:	e8 6c eb 00 00       	call   101e710 <myl_native_text_concat>
 100fba4:	4c 89 ff             	mov    %r15,%rdi
 100fba7:	48 8b b5 58 ff ff ff 	mov    -0xa8(%rbp),%rsi
 100fbae:	83 f8 00             	cmp    $0x0,%eax
 100fbb1:	0f 84 b8 01 00 00    	je     100fd6f <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xdcf>
 100fbb7:	48 89 85 18 ff ff ff 	mov    %rax,-0xe8(%rbp)
 100fbbe:	48 8b 85 18 ff ff ff 	mov    -0xe8(%rbp),%rax
 100fbc5:	48 89 85 68 fe ff ff 	mov    %rax,-0x198(%rbp)
 100fbcc:	48 8d 05 bd f1 01 00 	lea    0x1f1bd(%rip),%rax        # 102ed90 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a>
 100fbd3:	48 89 85 a8 fd ff ff 	mov    %rax,-0x258(%rbp)
 100fbda:	c7 85 c0 fd ff ff 02 	movl   $0x2,-0x240(%rbp)
 100fbe1:	00 00 00 
 100fbe4:	c7 85 40 fe ff ff 01 	movl   $0x1,-0x1c0(%rbp)
 100fbeb:	00 00 00 
 100fbee:	8b 85 28 fe ff ff    	mov    -0x1d8(%rbp),%eax
 100fbf4:	83 f8 00             	cmp    $0x0,%eax
 100fbf7:	74 15                	je     100fc0e <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xc6e>
 100fbf9:	4c 89 ee             	mov    %r13,%rsi
 100fbfc:	49 89 ff             	mov    %rdi,%r15
 100fbff:	e8 5c 6c 00 00       	call   1016860 <myl_qbe_rc_slot_drop>
 100fc04:	4c 89 ff             	mov    %r15,%rdi
 100fc07:	48 8b b5 58 ff ff ff 	mov    -0xa8(%rbp),%rsi
 100fc0e:	8b 85 30 fe ff ff    	mov    -0x1d0(%rbp),%eax
 100fc14:	83 f8 00             	cmp    $0x0,%eax
 100fc17:	74 0b                	je     100fc24 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xc84>
 100fc19:	49 89 ff             	mov    %rdi,%r15
 100fc1c:	e8 3f 6c 00 00       	call   1016860 <myl_qbe_rc_slot_drop>
 100fc21:	4c 89 ff             	mov    %r15,%rdi
 100fc24:	48 8b 85 68 fe ff ff 	mov    -0x198(%rbp),%rax
 100fc2b:	48 89 85 50 fe ff ff 	mov    %rax,-0x1b0(%rbp)
 100fc32:	48 8d 05 57 f1 01 00 	lea    0x1f157(%rip),%rax        # 102ed90 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a>
 100fc39:	48 89 85 48 fd ff ff 	mov    %rax,-0x2b8(%rbp)
 100fc40:	c7 85 60 fd ff ff 02 	movl   $0x2,-0x2a0(%rbp)
 100fc47:	00 00 00 
 100fc4a:	8b 85 c0 fd ff ff    	mov    -0x240(%rbp),%eax
 100fc50:	89 85 60 fd ff ff    	mov    %eax,-0x2a0(%rbp)
 100fc56:	c7 85 40 fe ff ff 00 	movl   $0x0,-0x1c0(%rbp)
 100fc5d:	00 00 00 
 100fc60:	c7 85 28 fe ff ff 01 	movl   $0x1,-0x1d8(%rbp)
 100fc67:	00 00 00 
 100fc6a:	48 8b 85 50 fe ff ff 	mov    -0x1b0(%rbp),%rax
 100fc71:	48 89 85 18 ff ff ff 	mov    %rax,-0xe8(%rbp)
 100fc78:	48 8d 05 81 f1 01 00 	lea    0x1f181(%rip),%rax        # 102ee00 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b>
 100fc7f:	48 89 85 68 fc ff ff 	mov    %rax,-0x398(%rbp)
 100fc86:	c7 85 80 fc ff ff 02 	movl   $0x2,-0x380(%rbp)
 100fc8d:	00 00 00 
 100fc90:	48 8d 85 e0 fe ff ff 	lea    -0x120(%rbp),%rax
 100fc97:	48 89 85 70 fc ff ff 	mov    %rax,-0x390(%rbp)
 100fc9e:	4c 89 b5 78 fc ff ff 	mov    %r14,-0x388(%rbp)
 100fca5:	4c 89 f1             	mov    %r14,%rcx
 100fca8:	48 8d 95 e0 fe ff ff 	lea    -0x120(%rbp),%rdx
 100fcaf:	48 8d 35 4a f1 01 00 	lea    0x1f14a(%rip),%rsi        # 102ee00 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b>
 100fcb6:	49 89 ff             	mov    %rdi,%r15
 100fcb9:	e8 22 6f 00 00       	call   1016be0 <myl_qbe_rc_unique_local>
 100fcbe:	4c 89 ff             	mov    %r15,%rdi
 100fcc1:	83 f8 00             	cmp    $0x0,%eax
 100fcc4:	0f 84 db 10 00 00    	je     1010da5 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1e05>
 100fcca:	48 8b b5 e0 fe ff ff 	mov    -0x120(%rbp),%rsi
 100fcd1:	48 8d 95 18 ff ff ff 	lea    -0xe8(%rbp),%rdx
 100fcd8:	49 89 ff             	mov    %rdi,%r15
 100fcdb:	48 89 df             	mov    %rbx,%rdi
 100fcde:	e8 4d de 00 00       	call   101db30 <myl_rc_list_append>
 100fce3:	4c 89 ff             	mov    %r15,%rdi
 100fce6:	48 8b b5 58 ff ff ff 	mov    -0xa8(%rbp),%rsi
 100fced:	83 f8 00             	cmp    $0x0,%eax
 100fcf0:	74 76                	je     100fd68 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xdc8>
 100fcf2:	48 c7 85 18 ff ff ff 	movq   $0x0,-0xe8(%rbp)
 100fcf9:	00 00 00 00 
 100fcfd:	8b 85 28 fe ff ff    	mov    -0x1d8(%rbp),%eax
 100fd03:	83 f8 00             	cmp    $0x0,%eax
 100fd06:	74 15                	je     100fd1d <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xd7d>
 100fd08:	4c 89 ee             	mov    %r13,%rsi
 100fd0b:	49 89 ff             	mov    %rdi,%r15
 100fd0e:	e8 4d 6b 00 00       	call   1016860 <myl_qbe_rc_slot_drop>
 100fd13:	4c 89 ff             	mov    %r15,%rdi
 100fd16:	48 8b b5 58 ff ff ff 	mov    -0xa8(%rbp),%rsi
 100fd1d:	4c 89 a5 18 ff ff ff 	mov    %r12,-0xe8(%rbp)
 100fd24:	48 c7 85 20 ff ff ff 	movq   $0x1,-0xe0(%rbp)
 100fd2b:	01 00 00 00 
 100fd2f:	48 b8 fe ff ff ff ff 	movabs $0x7ffffffffffffffe,%rax
 100fd36:	ff ff 7f 
 100fd39:	49 39 c4             	cmp    %rax,%r12
 100fd3c:	7f 10                	jg     100fd4e <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xdae>
 100fd3e:	49 83 c4 01          	add    $0x1,%r12
 100fd42:	4c 89 a5 18 ff ff ff 	mov    %r12,-0xe8(%rbp)
 100fd49:	e9 c2 fc ff ff       	jmp    100fa10 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xa70>
 100fd4e:	4c 89 e2             	mov    %r12,%rdx
 100fd51:	41 b8 40 00 00 00    	mov    $0x40,%r8d
 100fd57:	b9 01 00 00 00       	mov    $0x1,%ecx
 100fd5c:	be 00 00 00 00       	mov    $0x0,%esi
 100fd61:	e8 8a 71 00 00       	call   1016ef0 <myl_qbe_fail_overflow_op>
 100fd66:	0f 0b                	ud2
 100fd68:	e8 83 70 00 00       	call   1016df0 <myl_qbe_fail_allocation>
 100fd6d:	0f 0b                	ud2
 100fd6f:	e8 7c 70 00 00       	call   1016df0 <myl_qbe_fail_allocation>
 100fd74:	0f 0b                	ud2
 100fd76:	e8 75 70 00 00       	call   1016df0 <myl_qbe_fail_allocation>
 100fd7b:	0f 0b                	ud2
 100fd7d:	4c 8b bd 50 ff ff ff 	mov    -0xb0(%rbp),%r15
 100fd84:	4c 8b 75 e0          	mov    -0x20(%rbp),%r14
 100fd88:	b9 01 00 00 00       	mov    $0x1,%ecx
 100fd8d:	48 8d 15 94 3d ff ff 	lea    -0xc26c(%rip),%rdx        # 1003b28 <myl_t_1a91deb3742283487d66c3b500f6effd7ef1170e6d4b4368fe9ec3c3f0354fda>
 100fd94:	48 8d 35 f5 ef 01 00 	lea    0x1eff5(%rip),%rsi        # 102ed90 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a>
 100fd9b:	49 89 fc             	mov    %rdi,%r12
 100fd9e:	48 89 df             	mov    %rbx,%rdi
 100fda1:	e8 2a eb 00 00       	call   101e8d0 <myl_native_dictionary_new>
 100fda6:	4d 89 f0             	mov    %r14,%r8
 100fda9:	4c 89 e7             	mov    %r12,%rdi
 100fdac:	48 8b 55 d8          	mov    -0x28(%rbp),%rdx
 100fdb0:	48 8b 4d d0          	mov    -0x30(%rbp),%rcx
 100fdb4:	83 f8 00             	cmp    $0x0,%eax
 100fdb7:	75 0a                	jne    100fdc3 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xe23>
 100fdb9:	48 89 fb             	mov    %rdi,%rbx
 100fdbc:	e8 2f 70 00 00       	call   1016df0 <myl_qbe_fail_allocation>
 100fdc1:	0f 0b                	ud2
 100fdc3:	48 87 fb             	xchg   %rdi,%rbx
 100fdc6:	48 89 85 70 fe ff ff 	mov    %rax,-0x190(%rbp)
 100fdcd:	48 8d 35 7c f1 01 00 	lea    0x1f17c(%rip),%rsi        # 102ef50 <myl_t_db6bd58975531b7368ca22b8af460e2a11856412c594a38caca68120ceaa09fc>
 100fdd4:	48 89 b5 c8 fd ff ff 	mov    %rsi,-0x238(%rbp)
 100fddb:	c7 85 e0 fd ff ff 02 	movl   $0x2,-0x220(%rbp)
 100fde2:	00 00 00 
 100fde5:	48 8d b5 70 fe ff ff 	lea    -0x190(%rbp),%rsi
 100fdec:	48 89 b5 d0 fd ff ff 	mov    %rsi,-0x230(%rbp)
 100fdf3:	48 89 95 d8 fd ff ff 	mov    %rdx,-0x228(%rbp)
 100fdfa:	c7 85 e0 fd ff ff 04 	movl   $0x4,-0x220(%rbp)
 100fe01:	00 00 00 
 100fe04:	c7 85 48 fe ff ff 01 	movl   $0x1,-0x1b8(%rbp)
 100fe0b:	00 00 00 
 100fe0e:	c7 85 48 fe ff ff 00 	movl   $0x0,-0x1b8(%rbp)
 100fe15:	00 00 00 
 100fe18:	48 89 85 18 ff ff ff 	mov    %rax,-0xe8(%rbp)
 100fe1f:	48 8b 95 18 ff ff ff 	mov    -0xe8(%rbp),%rdx
 100fe26:	48 89 95 68 fe ff ff 	mov    %rdx,-0x198(%rbp)
 100fe2d:	48 8d 15 1c f1 01 00 	lea    0x1f11c(%rip),%rdx        # 102ef50 <myl_t_db6bd58975531b7368ca22b8af460e2a11856412c594a38caca68120ceaa09fc>
 100fe34:	48 89 95 a8 fd ff ff 	mov    %rdx,-0x258(%rbp)
 100fe3b:	c7 85 c0 fd ff ff 02 	movl   $0x2,-0x240(%rbp)
 100fe42:	00 00 00 
 100fe45:	c7 85 40 fe ff ff 01 	movl   $0x1,-0x1c0(%rbp)
 100fe4c:	00 00 00 
 100fe4f:	48 8b 95 68 fe ff ff 	mov    -0x198(%rbp),%rdx
 100fe56:	48 89 95 50 fe ff ff 	mov    %rdx,-0x1b0(%rbp)
 100fe5d:	48 8d 15 ec f0 01 00 	lea    0x1f0ec(%rip),%rdx        # 102ef50 <myl_t_db6bd58975531b7368ca22b8af460e2a11856412c594a38caca68120ceaa09fc>
 100fe64:	48 89 95 48 fd ff ff 	mov    %rdx,-0x2b8(%rbp)
 100fe6b:	c7 85 60 fd ff ff 02 	movl   $0x2,-0x2a0(%rbp)
 100fe72:	00 00 00 
 100fe75:	c7 85 60 fd ff ff 02 	movl   $0x2,-0x2a0(%rbp)
 100fe7c:	00 00 00 
 100fe7f:	c7 85 40 fe ff ff 00 	movl   $0x0,-0x1c0(%rbp)
 100fe86:	00 00 00 
 100fe89:	c7 85 28 fe ff ff 01 	movl   $0x1,-0x1d8(%rbp)
 100fe90:	00 00 00 
 100fe93:	48 89 85 18 ff ff ff 	mov    %rax,-0xe8(%rbp)
 100fe9a:	48 83 f8 00          	cmp    $0x0,%rax
 100fe9e:	75 05                	jne    100fea5 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xf05>
 100fea0:	49 89 ce             	mov    %rcx,%r14
 100fea3:	eb 1d                	jmp    100fec2 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xf22>
 100fea5:	48 83 e8 10          	sub    $0x10,%rax
 100fea9:	48 8b 00             	mov    (%rax),%rax
 100feac:	49 89 ce             	mov    %rcx,%r14
 100feaf:	48 b9 01 00 00 00 00 	movabs $0x5000000000000001,%rcx
 100feb6:	00 00 50 
 100feb9:	48 21 c8             	and    %rcx,%rax
 100febc:	48 83 f8 00          	cmp    $0x0,%rax
 100fec0:	75 39                	jne    100fefb <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xf5b>
 100fec2:	48 8b 85 18 ff ff ff 	mov    -0xe8(%rbp),%rax
 100fec9:	48 89 85 68 fe ff ff 	mov    %rax,-0x198(%rbp)
 100fed0:	ba 08 00 00 00       	mov    $0x8,%edx
 100fed5:	be 00 00 00 00       	mov    $0x0,%esi
 100feda:	49 89 fc             	mov    %rdi,%r12
 100fedd:	48 8d bd 18 ff ff ff 	lea    -0xe8(%rbp),%rdi
 100fee4:	e8 97 c4 01 00       	call   102c380 <compiler_rt.fastMemset>
 100fee9:	4c 89 f1             	mov    %r14,%rcx
 100feec:	4c 89 e7             	mov    %r12,%rdi
 100feef:	48 8b 75 c8          	mov    -0x38(%rbp),%rsi
 100fef3:	49 89 ce             	mov    %rcx,%r14
 100fef6:	48 87 df             	xchg   %rbx,%rdi
 100fef9:	eb 4c                	jmp    100ff47 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xfa7>
 100fefb:	4c 89 f1             	mov    %r14,%rcx
 100fefe:	49 89 ce             	mov    %rcx,%r14
 100ff01:	48 8d 8d 18 ff ff ff 	lea    -0xe8(%rbp),%rcx
 100ff08:	48 8d 95 68 fe ff ff 	lea    -0x198(%rbp),%rdx
 100ff0f:	48 8d 35 3a f0 01 00 	lea    0x1f03a(%rip),%rsi        # 102ef50 <myl_t_db6bd58975531b7368ca22b8af460e2a11856412c594a38caca68120ceaa09fc>
 100ff16:	49 89 fc             	mov    %rdi,%r12
 100ff19:	e8 c2 b8 01 00       	call   102b7e0 <myl_rc_native_take>
 100ff1e:	4c 89 e7             	mov    %r12,%rdi
 100ff21:	48 8b 75 c8          	mov    -0x38(%rbp),%rsi
 100ff25:	83 f8 00             	cmp    $0x0,%eax
 100ff28:	75 1a                	jne    100ff44 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xfa4>
 100ff2a:	e8 d1 38 01 00       	call   1023800 <myl_rc_take_failure>
 100ff2f:	48 89 df             	mov    %rbx,%rdi
 100ff32:	89 c6                	mov    %eax,%esi
 100ff34:	48 89 fb             	mov    %rdi,%rbx
 100ff37:	e8 54 67 00 00       	call   1016690 <myl_qbe_rc_status>
 100ff3c:	48 89 df             	mov    %rbx,%rdi
 100ff3f:	e9 61 0e 00 00       	jmp    1010da5 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1e05>
 100ff44:	48 87 df             	xchg   %rbx,%rdi
 100ff47:	c7 85 28 fe ff ff 00 	movl   $0x0,-0x1d8(%rbp)
 100ff4e:	00 00 00 
 100ff51:	48 8d 05 f8 ef 01 00 	lea    0x1eff8(%rip),%rax        # 102ef50 <myl_t_db6bd58975531b7368ca22b8af460e2a11856412c594a38caca68120ceaa09fc>
 100ff58:	48 89 85 a8 fd ff ff 	mov    %rax,-0x258(%rbp)
 100ff5f:	c7 85 c0 fd ff ff 02 	movl   $0x2,-0x240(%rbp)
 100ff66:	00 00 00 
 100ff69:	c7 85 40 fe ff ff 01 	movl   $0x1,-0x1c0(%rbp)
 100ff70:	00 00 00 
 100ff73:	8b 85 f8 fd ff ff    	mov    -0x208(%rbp),%eax
 100ff79:	83 f8 00             	cmp    $0x0,%eax
 100ff7c:	75 05                	jne    100ff83 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xfe3>
 100ff7e:	4c 89 f1             	mov    %r14,%rcx
 100ff81:	eb 0e                	jmp    100ff91 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xff1>
 100ff83:	49 89 fc             	mov    %rdi,%r12
 100ff86:	e8 d5 68 00 00       	call   1016860 <myl_qbe_rc_slot_drop>
 100ff8b:	4c 89 f1             	mov    %r14,%rcx
 100ff8e:	4c 89 e7             	mov    %r12,%rdi
 100ff91:	48 8b 85 68 fe ff ff 	mov    -0x198(%rbp),%rax
 100ff98:	48 89 85 e8 fe ff ff 	mov    %rax,-0x118(%rbp)
 100ff9f:	c7 85 40 fe ff ff 00 	movl   $0x0,-0x1c0(%rbp)
 100ffa6:	00 00 00 
 100ffa9:	48 8d 05 a0 ef 01 00 	lea    0x1efa0(%rip),%rax        # 102ef50 <myl_t_db6bd58975531b7368ca22b8af460e2a11856412c594a38caca68120ceaa09fc>
 100ffb0:	48 89 85 88 fc ff ff 	mov    %rax,-0x378(%rbp)
 100ffb7:	c7 85 a0 fc ff ff 02 	movl   $0x2,-0x360(%rbp)
 100ffbe:	00 00 00 
 100ffc1:	48 8d 85 e8 fe ff ff 	lea    -0x118(%rbp),%rax
 100ffc8:	48 89 85 90 fc ff ff 	mov    %rax,-0x370(%rbp)
 100ffcf:	48 89 8d 98 fc ff ff 	mov    %rcx,-0x368(%rbp)
 100ffd6:	8b 85 c0 fd ff ff    	mov    -0x240(%rbp),%eax
 100ffdc:	89 85 a0 fc ff ff    	mov    %eax,-0x360(%rbp)
 100ffe2:	c7 85 f8 fd ff ff 01 	movl   $0x1,-0x208(%rbp)
 100ffe9:	00 00 00 
 100ffec:	48 c7 85 18 ff ff ff 	movq   $0x0,-0xe8(%rbp)
 100fff3:	00 00 00 00 
 100fff7:	48 c7 85 18 ff ff ff 	movq   $0x1e8480,-0xe8(%rbp)
 100fffe:	80 84 1e 00 
 1010002:	48 8d 05 47 ef 01 00 	lea    0x1ef47(%rip),%rax        # 102ef50 <myl_t_db6bd58975531b7368ca22b8af460e2a11856412c594a38caca68120ceaa09fc>
 1010009:	48 89 85 88 fc ff ff 	mov    %rax,-0x378(%rbp)
 1010010:	c7 85 a0 fc ff ff 02 	movl   $0x2,-0x360(%rbp)
 1010017:	00 00 00 
 101001a:	48 8d 85 e8 fe ff ff 	lea    -0x118(%rbp),%rax
 1010021:	48 89 85 90 fc ff ff 	mov    %rax,-0x370(%rbp)
 1010028:	48 89 8d 98 fc ff ff 	mov    %rcx,-0x368(%rbp)
 101002f:	48 8d 95 e8 fe ff ff 	lea    -0x118(%rbp),%rdx
 1010036:	48 8d 35 13 ef 01 00 	lea    0x1ef13(%rip),%rsi        # 102ef50 <myl_t_db6bd58975531b7368ca22b8af460e2a11856412c594a38caca68120ceaa09fc>
 101003d:	49 89 fc             	mov    %rdi,%r12
 1010040:	e8 9b 6b 00 00       	call   1016be0 <myl_qbe_rc_unique_local>
 1010045:	4c 89 e7             	mov    %r12,%rdi
 1010048:	83 f8 00             	cmp    $0x0,%eax
 101004b:	0f 84 54 0d 00 00    	je     1010da5 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1e05>
 1010051:	41 bc 00 00 00 00    	mov    $0x0,%r12d
 1010057:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
 101005e:	00 00 
 1010060:	4c 89 a5 18 ff ff ff 	mov    %r12,-0xe8(%rbp)
 1010067:	48 c7 85 20 ff ff ff 	movq   $0x1e8480,-0xe0(%rbp)
 101006e:	80 84 1e 00 
 1010072:	49 81 fc 80 84 1e 00 	cmp    $0x1e8480,%r12
 1010079:	0f 9c c0             	setl   %al
 101007c:	48 0f b6 c0          	movzbq %al,%rax
 1010080:	48 89 85 18 ff ff ff 	mov    %rax,-0xe8(%rbp)
 1010087:	0f 8d 51 03 00 00    	jge    10103de <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x143e>
 101008d:	48 8b b5 e0 fe ff ff 	mov    -0x120(%rbp),%rsi
 1010094:	48 89 b5 18 ff ff ff 	mov    %rsi,-0xe8(%rbp)
 101009b:	48 89 b5 f0 fe ff ff 	mov    %rsi,-0x110(%rbp)
 10100a2:	4c 89 a5 18 ff ff ff 	mov    %r12,-0xe8(%rbp)
 10100a9:	48 c7 85 20 ff ff ff 	movq   $0x1eef,-0xe0(%rbp)
 10100b0:	ef 1e 00 00 
 10100b4:	49 69 c4 ef 1e 00 00 	imul   $0x1eef,%r12,%rax
 10100bb:	b9 ff ff ff ff       	mov    $0xffffffff,%ecx
 10100c0:	4d 89 e1             	mov    %r12,%r9
 10100c3:	49 21 c9             	and    %rcx,%r9
 10100c6:	4d 89 e0             	mov    %r12,%r8
 10100c9:	49 c1 e8 20          	shr    $0x20,%r8
 10100cd:	49 69 c9 ef 1e 00 00 	imul   $0x1eef,%r9,%rcx
 10100d4:	48 c1 e9 20          	shr    $0x20,%rcx
 10100d8:	49 69 d0 ef 1e 00 00 	imul   $0x1eef,%r8,%rdx
 10100df:	48 01 ca             	add    %rcx,%rdx
 10100e2:	b9 ff ff ff ff       	mov    $0xffffffff,%ecx
 10100e7:	48 21 d1             	and    %rdx,%rcx
 10100ea:	48 c1 ea 20          	shr    $0x20,%rdx
 10100ee:	4d 6b c9 00          	imul   $0x0,%r9,%r9
 10100f2:	4c 01 c9             	add    %r9,%rcx
 10100f5:	48 c1 e9 20          	shr    $0x20,%rcx
 10100f9:	4d 6b c0 00          	imul   $0x0,%r8,%r8
 10100fd:	4c 01 c2             	add    %r8,%rdx
 1010100:	48 01 d1             	add    %rdx,%rcx
 1010103:	49 83 fc 00          	cmp    $0x0,%r12
 1010107:	0f 9c c2             	setl   %dl
 101010a:	48 0f b6 d2          	movzbq %dl,%rdx
 101010e:	48 f7 da             	neg    %rdx
 1010111:	49 89 d0             	mov    %rdx,%r8
 1010114:	49 81 e0 ef 1e 00 00 	and    $0x1eef,%r8
 101011b:	4c 89 e2             	mov    %r12,%rdx
 101011e:	48 83 e2 00          	and    $0x0,%rdx
 1010122:	4c 29 c1             	sub    %r8,%rcx
 1010125:	48 29 d1             	sub    %rdx,%rcx
 1010128:	48 89 c2             	mov    %rax,%rdx
 101012b:	48 c1 fa 3f          	sar    $0x3f,%rdx
 101012f:	48 39 ca             	cmp    %rcx,%rdx
 1010132:	0f 85 8c 02 00 00    	jne    10103c4 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1424>
 1010138:	48 89 85 18 ff ff ff 	mov    %rax,-0xe8(%rbp)
 101013f:	48 c7 85 20 ff ff ff 	movq   $0x3e8,-0xe0(%rbp)
 1010146:	e8 03 00 00 
 101014a:	48 b9 00 00 00 00 00 	movabs $0x8000000000000000,%rcx
 1010151:	00 00 80 
 1010154:	48 39 c8             	cmp    %rcx,%rax
 1010157:	0f 94 c1             	sete   %cl
 101015a:	48 0f b6 c9          	movzbq %cl,%rcx
 101015e:	48 83 e1 00          	and    $0x0,%rcx
 1010162:	48 f7 d9             	neg    %rcx
 1010165:	48 81 e1 e9 03 00 00 	and    $0x3e9,%rcx
 101016c:	49 89 c8             	mov    %rcx,%r8
 101016f:	49 81 f0 e8 03 00 00 	xor    $0x3e8,%r8
 1010176:	48 99                	cqto
 1010178:	49 f7 f8             	idiv   %r8
 101017b:	48 89 d1             	mov    %rdx,%rcx
 101017e:	48 83 f9 00          	cmp    $0x0,%rcx
 1010182:	0f 95 c0             	setne  %al
 1010185:	48 0f b6 c0          	movzbq %al,%rax
 1010189:	4c 89 c2             	mov    %r8,%rdx
 101018c:	48 31 ca             	xor    %rcx,%rdx
 101018f:	48 83 fa 00          	cmp    $0x0,%rdx
 1010193:	0f 9c c2             	setl   %dl
 1010196:	48 0f b6 d2          	movzbq %dl,%rdx
 101019a:	48 21 d0             	and    %rdx,%rax
 101019d:	48 f7 d8             	neg    %rax
 10101a0:	4c 21 c0             	and    %r8,%rax
 10101a3:	48 01 c1             	add    %rax,%rcx
 10101a6:	48 89 8d 18 ff ff ff 	mov    %rcx,-0xe8(%rbp)
 10101ad:	48 89 8d 18 ff ff ff 	mov    %rcx,-0xe8(%rbp)
 10101b4:	48 c7 85 20 ff ff ff 	movq   $0x0,-0xe0(%rbp)
 10101bb:	00 00 00 00 
 10101bf:	48 83 f9 00          	cmp    $0x0,%rcx
 10101c3:	0f 9c c0             	setl   %al
 10101c6:	48 0f b6 c0          	movzbq %al,%rax
 10101ca:	48 89 85 18 ff ff ff 	mov    %rax,-0xe8(%rbp)
 10101d1:	7d 51                	jge    1010224 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1284>
 10101d3:	4c 8b 0e             	mov    (%rsi),%r9
 10101d6:	4c 89 8d 18 ff ff ff 	mov    %r9,-0xe8(%rbp)
 10101dd:	48 b8 ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rax
 10101e4:	ff ff 7f 
 10101e7:	49 39 c1             	cmp    %rax,%r9
 10101ea:	0f 87 c5 01 00 00    	ja     10103b5 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1415>
 10101f0:	4c 89 8d 18 ff ff ff 	mov    %r9,-0xe8(%rbp)
 10101f7:	48 89 8d 20 ff ff ff 	mov    %rcx,-0xe0(%rbp)
 10101fe:	48 89 c8             	mov    %rcx,%rax
 1010201:	4c 01 c9             	add    %r9,%rcx
 1010204:	4c 89 ca             	mov    %r9,%rdx
 1010207:	48 31 ca             	xor    %rcx,%rdx
 101020a:	49 89 c0             	mov    %rax,%r8
 101020d:	49 31 c8             	xor    %rcx,%r8
 1010210:	4c 21 c2             	and    %r8,%rdx
 1010213:	48 83 fa 00          	cmp    $0x0,%rdx
 1010217:	0f 8c 7d 01 00 00    	jl     101039a <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x13fa>
 101021d:	48 89 8d 18 ff ff ff 	mov    %rcx,-0xe8(%rbp)
 1010224:	48 89 8d 18 ff ff ff 	mov    %rcx,-0xe8(%rbp)
 101022b:	48 8b 06             	mov    (%rsi),%rax
 101022e:	48 39 c1             	cmp    %rax,%rcx
 1010231:	0f 83 56 01 00 00    	jae    101038d <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x13ed>
 1010237:	48 8b 46 20          	mov    0x20(%rsi),%rax
 101023b:	48 8b 04 c8          	mov    (%rax,%rcx,8),%rax
 101023f:	48 89 85 18 ff ff ff 	mov    %rax,-0xe8(%rbp)
 1010246:	48 89 85 f8 fe ff ff 	mov    %rax,-0x108(%rbp)
 101024d:	48 89 85 18 ff ff ff 	mov    %rax,-0xe8(%rbp)
 1010254:	48 c7 85 20 ff ff ff 	movq   $0x0,-0xe0(%rbp)
 101025b:	00 00 00 00 
 101025f:	49 89 fe             	mov    %rdi,%r14
 1010262:	48 8b bd e8 fe ff ff 	mov    -0x118(%rbp),%rdi
 1010269:	48 8d 95 38 ff ff ff 	lea    -0xc8(%rbp),%rdx
 1010270:	48 8d b5 18 ff ff ff 	lea    -0xe8(%rbp),%rsi
 1010277:	e8 64 eb 00 00       	call   101ede0 <myl_native_dictionary_read>
 101027c:	4c 89 f7             	mov    %r14,%rdi
 101027f:	83 f8 00             	cmp    $0x0,%eax
 1010282:	75 10                	jne    1010294 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x12f4>
 1010284:	48 8b 85 20 ff ff ff 	mov    -0xe0(%rbp),%rax
 101028b:	48 89 85 18 ff ff ff 	mov    %rax,-0xe8(%rbp)
 1010292:	eb 0e                	jmp    10102a2 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1302>
 1010294:	48 8b 85 38 ff ff ff 	mov    -0xc8(%rbp),%rax
 101029b:	48 89 85 18 ff ff ff 	mov    %rax,-0xe8(%rbp)
 10102a2:	48 c7 85 20 ff ff ff 	movq   $0x1,-0xe0(%rbp)
 10102a9:	01 00 00 00 
 10102ad:	48 b9 fe ff ff ff ff 	movabs $0x7ffffffffffffffe,%rcx
 10102b4:	ff ff 7f 
 10102b7:	48 39 c8             	cmp    %rcx,%rax
 10102ba:	0f 8f b3 00 00 00    	jg     1010373 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x13d3>
 10102c0:	48 83 c0 01          	add    $0x1,%rax
 10102c4:	48 89 85 18 ff ff ff 	mov    %rax,-0xe8(%rbp)
 10102cb:	48 8b b5 e8 fe ff ff 	mov    -0x118(%rbp),%rsi
 10102d2:	48 89 b5 18 ff ff ff 	mov    %rsi,-0xe8(%rbp)
 10102d9:	48 89 b5 00 ff ff ff 	mov    %rsi,-0x100(%rbp)
 10102e0:	48 8b 8d f8 fe ff ff 	mov    -0x108(%rbp),%rcx
 10102e7:	48 89 8d 18 ff ff ff 	mov    %rcx,-0xe8(%rbp)
 10102ee:	48 89 85 20 ff ff ff 	mov    %rax,-0xe0(%rbp)
 10102f5:	48 8d 8d 20 ff ff ff 	lea    -0xe0(%rbp),%rcx
 10102fc:	48 8d 95 18 ff ff ff 	lea    -0xe8(%rbp),%rdx
 1010303:	49 89 fe             	mov    %rdi,%r14
 1010306:	48 89 df             	mov    %rbx,%rdi
 1010309:	e8 52 f0 00 00       	call   101f360 <myl_native_dictionary_write>
 101030e:	4c 89 f7             	mov    %r14,%rdi
 1010311:	83 f8 00             	cmp    $0x0,%eax
 1010314:	74 56                	je     101036c <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x13cc>
 1010316:	48 c7 85 18 ff ff ff 	movq   $0x0,-0xe8(%rbp)
 101031d:	00 00 00 00 
 1010321:	4c 89 a5 18 ff ff ff 	mov    %r12,-0xe8(%rbp)
 1010328:	48 c7 85 20 ff ff ff 	movq   $0x1,-0xe0(%rbp)
 101032f:	01 00 00 00 
 1010333:	48 b8 fe ff ff ff ff 	movabs $0x7ffffffffffffffe,%rax
 101033a:	ff ff 7f 
 101033d:	49 39 c4             	cmp    %rax,%r12
 1010340:	7f 10                	jg     1010352 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x13b2>
 1010342:	49 83 c4 01          	add    $0x1,%r12
 1010346:	4c 89 a5 18 ff ff ff 	mov    %r12,-0xe8(%rbp)
 101034d:	e9 0e fd ff ff       	jmp    1010060 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x10c0>
 1010352:	4c 89 e2             	mov    %r12,%rdx
 1010355:	41 b8 40 00 00 00    	mov    $0x40,%r8d
 101035b:	b9 01 00 00 00       	mov    $0x1,%ecx
 1010360:	be 00 00 00 00       	mov    $0x0,%esi
 1010365:	e8 86 6b 00 00       	call   1016ef0 <myl_qbe_fail_overflow_op>
 101036a:	0f 0b                	ud2
 101036c:	e8 7f 6a 00 00       	call   1016df0 <myl_qbe_fail_allocation>
 1010371:	0f 0b                	ud2
 1010373:	48 89 c2             	mov    %rax,%rdx
 1010376:	41 b8 40 00 00 00    	mov    $0x40,%r8d
 101037c:	b9 01 00 00 00       	mov    $0x1,%ecx
 1010381:	be 00 00 00 00       	mov    $0x0,%esi
 1010386:	e8 65 6b 00 00       	call   1016ef0 <myl_qbe_fail_overflow_op>
 101038b:	0f 0b                	ud2
 101038d:	48 89 c2             	mov    %rax,%rdx
 1010390:	48 89 ce             	mov    %rcx,%rsi
 1010393:	e8 e8 6a 00 00       	call   1016e80 <myl_qbe_fail_normalized_index_bounds>
 1010398:	0f 0b                	ud2
 101039a:	48 89 c1             	mov    %rax,%rcx
 101039d:	4c 89 ce             	mov    %r9,%rsi
 10103a0:	41 b8 40 00 00 00    	mov    $0x40,%r8d
 10103a6:	48 89 f2             	mov    %rsi,%rdx
 10103a9:	be 00 00 00 00       	mov    $0x0,%esi
 10103ae:	e8 3d 6b 00 00       	call   1016ef0 <myl_qbe_fail_overflow_op>
 10103b3:	0f 0b                	ud2
 10103b5:	4c 89 ce             	mov    %r9,%rsi
 10103b8:	ba 40 01 00 00       	mov    $0x140,%edx
 10103bd:	e8 6e 6c 00 00       	call   1017030 <myl_qbe_fail_cast>
 10103c2:	0f 0b                	ud2
 10103c4:	4c 89 e2             	mov    %r12,%rdx
 10103c7:	41 b8 40 00 00 00    	mov    $0x40,%r8d
 10103cd:	b9 ef 1e 00 00       	mov    $0x1eef,%ecx
 10103d2:	be 02 00 00 00       	mov    $0x2,%esi
 10103d7:	e8 14 6b 00 00       	call   1016ef0 <myl_qbe_fail_overflow_op>
 10103dc:	0f 0b                	ud2
 10103de:	4c 8b 75 b8          	mov    -0x48(%rbp),%r14
 10103e2:	4c 8b 7d c0          	mov    -0x40(%rbp),%r15
 10103e6:	48 c7 85 18 ff ff ff 	movq   $0x0,-0xe8(%rbp)
 10103ed:	00 00 00 00 
 10103f1:	48 8b b5 e0 fe ff ff 	mov    -0x120(%rbp),%rsi
 10103f8:	8b 85 80 fc ff ff    	mov    -0x380(%rbp),%eax
 10103fe:	83 f8 08             	cmp    $0x8,%eax
 1010401:	0f 94 c0             	sete   %al
 1010404:	0f b6 c0             	movzbl %al,%eax
 1010407:	8b 8d f0 fd ff ff    	mov    -0x210(%rbp),%ecx
 101040d:	85 c1                	test   %eax,%ecx
 101040f:	75 0c                	jne    101041d <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x147d>
 1010411:	48 89 b5 18 ff ff ff 	mov    %rsi,-0xe8(%rbp)
 1010418:	e9 d7 00 00 00       	jmp    10104f4 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1554>
 101041d:	48 c7 85 68 fe ff ff 	movq   $0x0,-0x198(%rbp)
 1010424:	00 00 00 00 
 1010428:	48 8d 95 68 fe ff ff 	lea    -0x198(%rbp),%rdx
 101042f:	49 89 fc             	mov    %rdi,%r12
 1010432:	48 89 df             	mov    %rbx,%rdi
 1010435:	e8 16 39 01 00       	call   1023d50 <myl_rc_hold_acquire>
 101043a:	4c 89 e7             	mov    %r12,%rdi
 101043d:	89 c6                	mov    %eax,%esi
 101043f:	49 89 fc             	mov    %rdi,%r12
 1010442:	e8 49 62 00 00       	call   1016690 <myl_qbe_rc_status>
 1010447:	4c 89 e7             	mov    %r12,%rdi
 101044a:	83 f8 00             	cmp    $0x0,%eax
 101044d:	0f 84 52 09 00 00    	je     1010da5 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1e05>
 1010453:	48 8d 05 a6 e9 01 00 	lea    0x1e9a6(%rip),%rax        # 102ee00 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b>
 101045a:	48 89 85 a8 fd ff ff 	mov    %rax,-0x258(%rbp)
 1010461:	c7 85 c0 fd ff ff 02 	movl   $0x2,-0x240(%rbp)
 1010468:	00 00 00 
 101046b:	48 8d 85 68 fe ff ff 	lea    -0x198(%rbp),%rax
 1010472:	48 89 85 b0 fd ff ff 	mov    %rax,-0x250(%rbp)
 1010479:	4c 89 b5 b8 fd ff ff 	mov    %r14,-0x248(%rbp)
 1010480:	c7 85 c0 fd ff ff 08 	movl   $0x8,-0x240(%rbp)
 1010487:	00 00 00 
 101048a:	c7 85 40 fe ff ff 01 	movl   $0x1,-0x1c0(%rbp)
 1010491:	00 00 00 
 1010494:	48 8b b5 68 fe ff ff 	mov    -0x198(%rbp),%rsi
 101049b:	48 89 b5 50 fe ff ff 	mov    %rsi,-0x1b0(%rbp)
 10104a2:	48 8d 05 57 e9 01 00 	lea    0x1e957(%rip),%rax        # 102ee00 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b>
 10104a9:	48 89 85 48 fd ff ff 	mov    %rax,-0x2b8(%rbp)
 10104b0:	c7 85 60 fd ff ff 02 	movl   $0x2,-0x2a0(%rbp)
 10104b7:	00 00 00 
 10104ba:	48 8d 85 50 fe ff ff 	lea    -0x1b0(%rbp),%rax
 10104c1:	48 89 85 50 fd ff ff 	mov    %rax,-0x2b0(%rbp)
 10104c8:	4c 89 bd 58 fd ff ff 	mov    %r15,-0x2a8(%rbp)
 10104cf:	c7 85 60 fd ff ff 08 	movl   $0x8,-0x2a0(%rbp)
 10104d6:	00 00 00 
 10104d9:	c7 85 28 fe ff ff 01 	movl   $0x1,-0x1d8(%rbp)
 10104e0:	00 00 00 
 10104e3:	c7 85 40 fe ff ff 00 	movl   $0x0,-0x1c0(%rbp)
 10104ea:	00 00 00 
 10104ed:	48 89 b5 18 ff ff ff 	mov    %rsi,-0xe8(%rbp)
 10104f4:	48 c7 85 68 fe ff ff 	movq   $0x0,-0x198(%rbp)
 10104fb:	00 00 00 00 
 10104ff:	48 8d 95 68 fe ff ff 	lea    -0x198(%rbp),%rdx
 1010506:	49 89 fc             	mov    %rdi,%r12
 1010509:	48 89 df             	mov    %rbx,%rdi
 101050c:	e8 3f 38 01 00       	call   1023d50 <myl_rc_hold_acquire>
 1010511:	4c 89 e7             	mov    %r12,%rdi
 1010514:	89 c6                	mov    %eax,%esi
 1010516:	49 89 fc             	mov    %rdi,%r12
 1010519:	e8 72 61 00 00       	call   1016690 <myl_qbe_rc_status>
 101051e:	4c 89 e7             	mov    %r12,%rdi
 1010521:	4c 8b 65 a8          	mov    -0x58(%rbp),%r12
 1010525:	48 8b 75 b0          	mov    -0x50(%rbp),%rsi
 1010529:	83 f8 00             	cmp    $0x0,%eax
 101052c:	0f 84 73 08 00 00    	je     1010da5 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1e05>
 1010532:	48 8d 05 c7 e8 01 00 	lea    0x1e8c7(%rip),%rax        # 102ee00 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b>
 1010539:	48 89 85 a8 fd ff ff 	mov    %rax,-0x258(%rbp)
 1010540:	c7 85 c0 fd ff ff 02 	movl   $0x2,-0x240(%rbp)
 1010547:	00 00 00 
 101054a:	48 8d 85 68 fe ff ff 	lea    -0x198(%rbp),%rax
 1010551:	48 89 85 b0 fd ff ff 	mov    %rax,-0x250(%rbp)
 1010558:	4c 89 b5 b8 fd ff ff 	mov    %r14,-0x248(%rbp)
 101055f:	c7 85 c0 fd ff ff 08 	movl   $0x8,-0x240(%rbp)
 1010566:	00 00 00 
 1010569:	c7 85 40 fe ff ff 01 	movl   $0x1,-0x1c0(%rbp)
 1010570:	00 00 00 
 1010573:	8b 85 28 fe ff ff    	mov    -0x1d8(%rbp),%eax
 1010579:	83 f8 00             	cmp    $0x0,%eax
 101057c:	74 16                	je     1010594 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x15f4>
 101057e:	4c 89 ee             	mov    %r13,%rsi
 1010581:	49 89 fc             	mov    %rdi,%r12
 1010584:	e8 d7 62 00 00       	call   1016860 <myl_qbe_rc_slot_drop>
 1010589:	4c 89 e7             	mov    %r12,%rdi
 101058c:	4c 8b 65 a8          	mov    -0x58(%rbp),%r12
 1010590:	48 8b 75 b0          	mov    -0x50(%rbp),%rsi
 1010594:	48 8b 85 68 fe ff ff 	mov    -0x198(%rbp),%rax
 101059b:	48 89 85 50 fe ff ff 	mov    %rax,-0x1b0(%rbp)
 10105a2:	48 8d 0d 57 e8 01 00 	lea    0x1e857(%rip),%rcx        # 102ee00 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b>
 10105a9:	48 89 8d 48 fd ff ff 	mov    %rcx,-0x2b8(%rbp)
 10105b0:	c7 85 60 fd ff ff 02 	movl   $0x2,-0x2a0(%rbp)
 10105b7:	00 00 00 
 10105ba:	48 8d 8d 50 fe ff ff 	lea    -0x1b0(%rbp),%rcx
 10105c1:	48 89 8d 50 fd ff ff 	mov    %rcx,-0x2b0(%rbp)
 10105c8:	4c 89 bd 58 fd ff ff 	mov    %r15,-0x2a8(%rbp)
 10105cf:	c7 85 60 fd ff ff 08 	movl   $0x8,-0x2a0(%rbp)
 10105d6:	00 00 00 
 10105d9:	c7 85 28 fe ff ff 01 	movl   $0x1,-0x1d8(%rbp)
 10105e0:	00 00 00 
 10105e3:	c7 85 40 fe ff ff 00 	movl   $0x0,-0x1c0(%rbp)
 10105ea:	00 00 00 
 10105ed:	48 89 85 18 ff ff ff 	mov    %rax,-0xe8(%rbp)
 10105f4:	48 89 85 68 fe ff ff 	mov    %rax,-0x198(%rbp)
 10105fb:	48 8d 05 fe e7 01 00 	lea    0x1e7fe(%rip),%rax        # 102ee00 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b>
 1010602:	48 89 85 a8 fd ff ff 	mov    %rax,-0x258(%rbp)
 1010609:	c7 85 c0 fd ff ff 02 	movl   $0x2,-0x240(%rbp)
 1010610:	00 00 00 
 1010613:	48 8d 85 68 fe ff ff 	lea    -0x198(%rbp),%rax
 101061a:	48 89 85 b0 fd ff ff 	mov    %rax,-0x250(%rbp)
 1010621:	4c 89 b5 b8 fd ff ff 	mov    %r14,-0x248(%rbp)
 1010628:	c7 85 c0 fd ff ff 08 	movl   $0x8,-0x240(%rbp)
 101062f:	00 00 00 
 1010632:	c7 85 40 fe ff ff 01 	movl   $0x1,-0x1c0(%rbp)
 1010639:	00 00 00 
 101063c:	c7 85 28 fe ff ff 00 	movl   $0x0,-0x1d8(%rbp)
 1010643:	00 00 00 
 1010646:	8b 85 18 fe ff ff    	mov    -0x1e8(%rbp),%eax
 101064c:	83 f8 00             	cmp    $0x0,%eax
 101064f:	74 0b                	je     101065c <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x16bc>
 1010651:	49 89 fe             	mov    %rdi,%r14
 1010654:	e8 07 62 00 00       	call   1016860 <myl_qbe_rc_slot_drop>
 1010659:	4c 89 f7             	mov    %r14,%rdi
 101065c:	48 8b 85 68 fe ff ff 	mov    -0x198(%rbp),%rax
 1010663:	48 89 85 08 ff ff ff 	mov    %rax,-0xf8(%rbp)
 101066a:	48 8d 0d 8f e7 01 00 	lea    0x1e78f(%rip),%rcx        # 102ee00 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b>
 1010671:	48 89 8d 08 fd ff ff 	mov    %rcx,-0x2f8(%rbp)
 1010678:	c7 85 20 fd ff ff 02 	movl   $0x2,-0x2e0(%rbp)
 101067f:	00 00 00 
 1010682:	48 8d 8d 08 ff ff ff 	lea    -0xf8(%rbp),%rcx
 1010689:	48 89 8d 10 fd ff ff 	mov    %rcx,-0x2f0(%rbp)
 1010690:	4c 89 a5 18 fd ff ff 	mov    %r12,-0x2e8(%rbp)
 1010697:	c7 85 20 fd ff ff 08 	movl   $0x8,-0x2e0(%rbp)
 101069e:	00 00 00 
 10106a1:	c7 85 18 fe ff ff 01 	movl   $0x1,-0x1e8(%rbp)
 10106a8:	00 00 00 
 10106ab:	c7 85 40 fe ff ff 00 	movl   $0x0,-0x1c0(%rbp)
 10106b2:	00 00 00 
 10106b5:	48 c7 85 18 ff ff ff 	movq   $0x0,-0xe8(%rbp)
 10106bc:	00 00 00 00 
 10106c0:	48 8b 30             	mov    (%rax),%rsi
 10106c3:	48 89 b5 18 ff ff ff 	mov    %rsi,-0xe8(%rbp)
 10106ca:	48 b9 ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rcx
 10106d1:	ff ff 7f 
 10106d4:	48 39 ce             	cmp    %rcx,%rsi
 10106d7:	0f 87 bc 06 00 00    	ja     1010d99 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1df9>
 10106dd:	48 89 b5 18 ff ff ff 	mov    %rsi,-0xe8(%rbp)
 10106e4:	49 89 f4             	mov    %rsi,%r12
 10106e7:	48 c7 45 a0 00 00 00 	movq   $0x0,-0x60(%rbp)
 10106ee:	00 
 10106ef:	41 be 00 00 00 00    	mov    $0x0,%r14d
 10106f5:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
 10106fc:	00 00 00 
 10106ff:	90                   	nop
 1010700:	4c 89 b5 18 ff ff ff 	mov    %r14,-0xe8(%rbp)
 1010707:	4c 89 a5 20 ff ff ff 	mov    %r12,-0xe0(%rbp)
 101070e:	4d 39 e6             	cmp    %r12,%r14
 1010711:	0f 9c c1             	setl   %cl
 1010714:	48 0f b6 c9          	movzbq %cl,%rcx
 1010718:	48 89 8d 18 ff ff ff 	mov    %rcx,-0xe8(%rbp)
 101071f:	0f 8d c2 05 00 00    	jge    1010ce7 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1d47>
 1010725:	4c 89 a5 18 ff ff ff 	mov    %r12,-0xe8(%rbp)
 101072c:	48 8b 08             	mov    (%rax),%rcx
 101072f:	49 39 cc             	cmp    %rcx,%r12
 1010732:	0f 85 a8 05 00 00    	jne    1010ce0 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1d40>
 1010738:	48 c7 85 18 ff ff ff 	movq   $0x0,-0xe8(%rbp)
 101073f:	00 00 00 00 
 1010743:	4c 89 b5 18 ff ff ff 	mov    %r14,-0xe8(%rbp)
 101074a:	48 8b 08             	mov    (%rax),%rcx
 101074d:	49 39 ce             	cmp    %rcx,%r14
 1010750:	0f 83 7d 05 00 00    	jae    1010cd3 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1d33>
 1010756:	48 8b 40 20          	mov    0x20(%rax),%rax
 101075a:	4a 8b 04 f0          	mov    (%rax,%r14,8),%rax
 101075e:	48 89 85 18 ff ff ff 	mov    %rax,-0xe8(%rbp)
 1010765:	48 8d 8d 18 ff ff ff 	lea    -0xe8(%rbp),%rcx
 101076c:	48 8d 95 68 fe ff ff 	lea    -0x198(%rbp),%rdx
 1010773:	48 8d 35 16 e6 01 00 	lea    0x1e616(%rip),%rsi        # 102ed90 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a>
 101077a:	49 89 ff             	mov    %rdi,%r15
 101077d:	48 89 df             	mov    %rbx,%rdi
 1010780:	e8 2b b3 01 00       	call   102bab0 <myl_rc_native_loan>
 1010785:	4c 89 ff             	mov    %r15,%rdi
 1010788:	83 f8 00             	cmp    $0x0,%eax
 101078b:	0f 84 25 05 00 00    	je     1010cb6 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1d16>
 1010791:	48 8d 05 f8 e5 01 00 	lea    0x1e5f8(%rip),%rax        # 102ed90 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a>
 1010798:	48 89 85 a8 fd ff ff 	mov    %rax,-0x258(%rbp)
 101079f:	c7 85 c0 fd ff ff 02 	movl   $0x2,-0x240(%rbp)
 10107a6:	00 00 00 
 10107a9:	c7 85 c0 fd ff ff 10 	movl   $0x10,-0x240(%rbp)
 10107b0:	00 00 00 
 10107b3:	c7 85 40 fe ff ff 01 	movl   $0x1,-0x1c0(%rbp)
 10107ba:	00 00 00 
 10107bd:	48 8b 85 68 fe ff ff 	mov    -0x198(%rbp),%rax
 10107c4:	48 89 85 50 fe ff ff 	mov    %rax,-0x1b0(%rbp)
 10107cb:	48 8d 05 be e5 01 00 	lea    0x1e5be(%rip),%rax        # 102ed90 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a>
 10107d2:	48 89 85 48 fd ff ff 	mov    %rax,-0x2b8(%rbp)
 10107d9:	c7 85 60 fd ff ff 02 	movl   $0x2,-0x2a0(%rbp)
 10107e0:	00 00 00 
 10107e3:	c7 85 60 fd ff ff 10 	movl   $0x10,-0x2a0(%rbp)
 10107ea:	00 00 00 
 10107ed:	c7 85 40 fe ff ff 00 	movl   $0x0,-0x1c0(%rbp)
 10107f4:	00 00 00 
 10107f7:	c7 85 28 fe ff ff 01 	movl   $0x1,-0x1d8(%rbp)
 10107fe:	00 00 00 
 1010801:	48 8b 85 50 fe ff ff 	mov    -0x1b0(%rbp),%rax
 1010808:	48 89 85 18 ff ff ff 	mov    %rax,-0xe8(%rbp)
 101080f:	48 8d 8d 18 ff ff ff 	lea    -0xe8(%rbp),%rcx
 1010816:	48 8d 95 68 fe ff ff 	lea    -0x198(%rbp),%rdx
 101081d:	48 8d 35 6c e5 01 00 	lea    0x1e56c(%rip),%rsi        # 102ed90 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a>
 1010824:	49 89 ff             	mov    %rdi,%r15
 1010827:	48 89 df             	mov    %rbx,%rdi
 101082a:	e8 81 b2 01 00       	call   102bab0 <myl_rc_native_loan>
 101082f:	4c 89 ff             	mov    %r15,%rdi
 1010832:	48 8b 4d a0          	mov    -0x60(%rbp),%rcx
 1010836:	4c 8b 8d 68 ff ff ff 	mov    -0x98(%rbp),%r9
 101083d:	4c 8b bd 50 ff ff ff 	mov    -0xb0(%rbp),%r15
 1010844:	83 f8 00             	cmp    $0x0,%eax
 1010847:	0f 84 4c 04 00 00    	je     1010c99 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1cf9>
 101084d:	48 8d 05 3c e5 01 00 	lea    0x1e53c(%rip),%rax        # 102ed90 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a>
 1010854:	48 89 85 a8 fd ff ff 	mov    %rax,-0x258(%rbp)
 101085b:	c7 85 c0 fd ff ff 02 	movl   $0x2,-0x240(%rbp)
 1010862:	00 00 00 
 1010865:	c7 85 c0 fd ff ff 10 	movl   $0x10,-0x240(%rbp)
 101086c:	00 00 00 
 101086f:	c7 85 40 fe ff ff 01 	movl   $0x1,-0x1c0(%rbp)
 1010876:	00 00 00 
 1010879:	8b 85 28 fe ff ff    	mov    -0x1d8(%rbp),%eax
 101087f:	83 f8 00             	cmp    $0x0,%eax
 1010882:	74 20                	je     10108a4 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1904>
 1010884:	4c 89 ee             	mov    %r13,%rsi
 1010887:	49 89 ff             	mov    %rdi,%r15
 101088a:	e8 d1 5f 00 00       	call   1016860 <myl_qbe_rc_slot_drop>
 101088f:	4c 89 ff             	mov    %r15,%rdi
 1010892:	48 8b 4d a0          	mov    -0x60(%rbp),%rcx
 1010896:	4c 8b 8d 68 ff ff ff 	mov    -0x98(%rbp),%r9
 101089d:	4c 8b bd 50 ff ff ff 	mov    -0xb0(%rbp),%r15
 10108a4:	8b 85 20 fe ff ff    	mov    -0x1e0(%rbp),%eax
 10108aa:	83 f8 00             	cmp    $0x0,%eax
 10108ad:	74 19                	je     10108c8 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1928>
 10108af:	4c 89 fe             	mov    %r15,%rsi
 10108b2:	49 89 ff             	mov    %rdi,%r15
 10108b5:	e8 a6 5f 00 00       	call   1016860 <myl_qbe_rc_slot_drop>
 10108ba:	4c 89 ff             	mov    %r15,%rdi
 10108bd:	48 8b 4d a0          	mov    -0x60(%rbp),%rcx
 10108c1:	4c 8b 8d 68 ff ff ff 	mov    -0x98(%rbp),%r9
 10108c8:	48 8b 85 68 fe ff ff 	mov    -0x198(%rbp),%rax
 10108cf:	48 89 85 10 ff ff ff 	mov    %rax,-0xf0(%rbp)
 10108d6:	c7 85 40 fe ff ff 00 	movl   $0x0,-0x1c0(%rbp)
 10108dd:	00 00 00 
 10108e0:	48 8d 05 a9 e4 01 00 	lea    0x1e4a9(%rip),%rax        # 102ed90 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a>
 10108e7:	48 89 85 28 fd ff ff 	mov    %rax,-0x2d8(%rbp)
 10108ee:	c7 85 40 fd ff ff 02 	movl   $0x2,-0x2c0(%rbp)
 10108f5:	00 00 00 
 10108f8:	48 8d 85 10 ff ff ff 	lea    -0xf0(%rbp),%rax
 10108ff:	48 89 85 30 fd ff ff 	mov    %rax,-0x2d0(%rbp)
 1010906:	4c 89 8d 38 fd ff ff 	mov    %r9,-0x2c8(%rbp)
 101090d:	8b 85 c0 fd ff ff    	mov    -0x240(%rbp),%eax
 1010913:	89 85 40 fd ff ff    	mov    %eax,-0x2c0(%rbp)
 1010919:	c7 85 20 fe ff ff 01 	movl   $0x1,-0x1e0(%rbp)
 1010920:	00 00 00 
 1010923:	48 89 8d 18 ff ff ff 	mov    %rcx,-0xe8(%rbp)
 101092a:	49 89 ff             	mov    %rdi,%r15
 101092d:	48 8b bd e8 fe ff ff 	mov    -0x118(%rbp),%rdi
 1010934:	48 89 bd 20 ff ff ff 	mov    %rdi,-0xe0(%rbp)
 101093b:	48 8b 85 10 ff ff ff 	mov    -0xf0(%rbp),%rax
 1010942:	48 89 85 28 ff ff ff 	mov    %rax,-0xd8(%rbp)
 1010949:	48 8d 95 30 ff ff ff 	lea    -0xd0(%rbp),%rdx
 1010950:	48 8d b5 28 ff ff ff 	lea    -0xd8(%rbp),%rsi
 1010957:	e8 84 e4 00 00       	call   101ede0 <myl_native_dictionary_read>
 101095c:	4c 89 ff             	mov    %r15,%rdi
 101095f:	4c 8b 85 60 ff ff ff 	mov    -0xa0(%rbp),%r8
 1010966:	48 8b b5 58 ff ff ff 	mov    -0xa8(%rbp),%rsi
 101096d:	4c 8b bd 50 ff ff ff 	mov    -0xb0(%rbp),%r15
 1010974:	83 f8 00             	cmp    $0x0,%eax
 1010977:	0f 84 12 03 00 00    	je     1010c8f <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1cef>
 101097d:	48 8b 85 30 ff ff ff 	mov    -0xd0(%rbp),%rax
 1010984:	48 89 85 20 ff ff ff 	mov    %rax,-0xe0(%rbp)
 101098b:	8b 85 30 fe ff ff    	mov    -0x1d0(%rbp),%eax
 1010991:	83 f8 00             	cmp    $0x0,%eax
 1010994:	74 19                	je     10109af <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1a0f>
 1010996:	49 89 ff             	mov    %rdi,%r15
 1010999:	e8 c2 5e 00 00       	call   1016860 <myl_qbe_rc_slot_drop>
 101099e:	4c 89 ff             	mov    %r15,%rdi
 10109a1:	4c 8b 85 60 ff ff ff 	mov    -0xa0(%rbp),%r8
 10109a8:	4c 8b bd 50 ff ff ff 	mov    -0xb0(%rbp),%r15
 10109af:	8b 85 38 fe ff ff    	mov    -0x1c8(%rbp),%eax
 10109b5:	83 f8 00             	cmp    $0x0,%eax
 10109b8:	74 1c                	je     10109d6 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1a36>
 10109ba:	4c 89 c6             	mov    %r8,%rsi
 10109bd:	49 89 ff             	mov    %rdi,%r15
 10109c0:	e8 9b 5e 00 00       	call   1016860 <myl_qbe_rc_slot_drop>
 10109c5:	4c 89 ff             	mov    %r15,%rdi
 10109c8:	4c 8b 85 60 ff ff ff 	mov    -0xa0(%rbp),%r8
 10109cf:	4c 8b bd 50 ff ff ff 	mov    -0xb0(%rbp),%r15
 10109d6:	48 8b 85 10 ff ff ff 	mov    -0xf0(%rbp),%rax
 10109dd:	48 89 85 28 ff ff ff 	mov    %rax,-0xd8(%rbp)
 10109e4:	48 8b 00             	mov    (%rax),%rax
 10109e7:	48 89 85 28 ff ff ff 	mov    %rax,-0xd8(%rbp)
 10109ee:	8b 85 38 fe ff ff    	mov    -0x1c8(%rbp),%eax
 10109f4:	83 f8 00             	cmp    $0x0,%eax
 10109f7:	74 15                	je     1010a0e <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1a6e>
 10109f9:	4c 89 c6             	mov    %r8,%rsi
 10109fc:	49 89 ff             	mov    %rdi,%r15
 10109ff:	e8 5c 5e 00 00       	call   1016860 <myl_qbe_rc_slot_drop>
 1010a04:	4c 89 ff             	mov    %r15,%rdi
 1010a07:	4c 8b bd 50 ff ff ff 	mov    -0xb0(%rbp),%r15
 1010a0e:	48 8b 85 28 ff ff ff 	mov    -0xd8(%rbp),%rax
 1010a15:	48 8b 95 20 ff ff ff 	mov    -0xe0(%rbp),%rdx
 1010a1c:	48 89 c1             	mov    %rax,%rcx
 1010a1f:	48 0f af ca          	imul   %rdx,%rcx
 1010a23:	be ff ff ff ff       	mov    $0xffffffff,%esi
 1010a28:	49 89 d0             	mov    %rdx,%r8
 1010a2b:	49 21 f0             	and    %rsi,%r8
 1010a2e:	49 89 d1             	mov    %rdx,%r9
 1010a31:	49 c1 e9 20          	shr    $0x20,%r9
 1010a35:	be ff ff ff ff       	mov    $0xffffffff,%esi
 1010a3a:	49 89 c2             	mov    %rax,%r10
 1010a3d:	49 21 f2             	and    %rsi,%r10
 1010a40:	49 89 c3             	mov    %rax,%r11
 1010a43:	49 c1 eb 20          	shr    $0x20,%r11
 1010a47:	4c 89 c6             	mov    %r8,%rsi
 1010a4a:	49 0f af f2          	imul   %r10,%rsi
 1010a4e:	48 c1 ee 20          	shr    $0x20,%rsi
 1010a52:	4d 0f af d1          	imul   %r9,%r10
 1010a56:	4c 01 d6             	add    %r10,%rsi
 1010a59:	41 ba ff ff ff ff    	mov    $0xffffffff,%r10d
 1010a5f:	4c 89 55 98          	mov    %r10,-0x68(%rbp)
 1010a63:	49 89 f2             	mov    %rsi,%r10
 1010a66:	4c 23 55 98          	and    -0x68(%rbp),%r10
 1010a6a:	4c 89 55 88          	mov    %r10,-0x78(%rbp)
 1010a6e:	49 89 f2             	mov    %rsi,%r10
 1010a71:	49 c1 ea 20          	shr    $0x20,%r10
 1010a75:	4c 89 95 78 ff ff ff 	mov    %r10,-0x88(%rbp)
 1010a7c:	48 8b b5 58 ff ff ff 	mov    -0xa8(%rbp),%rsi
 1010a83:	4d 0f af c3          	imul   %r11,%r8
 1010a87:	4c 89 45 90          	mov    %r8,-0x70(%rbp)
 1010a8b:	4c 8b 85 60 ff ff ff 	mov    -0xa0(%rbp),%r8
 1010a92:	4c 8b 55 88          	mov    -0x78(%rbp),%r10
 1010a96:	4c 03 55 90          	add    -0x70(%rbp),%r10
 1010a9a:	4c 89 55 80          	mov    %r10,-0x80(%rbp)
 1010a9e:	4c 8b 55 80          	mov    -0x80(%rbp),%r10
 1010aa2:	49 c1 ea 20          	shr    $0x20,%r10
 1010aa6:	4c 89 95 70 ff ff ff 	mov    %r10,-0x90(%rbp)
 1010aad:	4c 8b 95 78 ff ff ff 	mov    -0x88(%rbp),%r10
 1010ab4:	4d 0f af d9          	imul   %r9,%r11
 1010ab8:	4c 8b 8d 70 ff ff ff 	mov    -0x90(%rbp),%r9
 1010abf:	4d 01 da             	add    %r11,%r10
 1010ac2:	4d 01 d1             	add    %r10,%r9
 1010ac5:	48 83 fa 00          	cmp    $0x0,%rdx
 1010ac9:	41 0f 9c c2          	setl   %r10b
 1010acd:	4d 0f b6 d2          	movzbq %r10b,%r10
 1010ad1:	48 83 f8 00          	cmp    $0x0,%rax
 1010ad5:	41 0f 9c c3          	setl   %r11b
 1010ad9:	4d 0f b6 db          	movzbq %r11b,%r11
 1010add:	49 f7 da             	neg    %r10
 1010ae0:	49 f7 db             	neg    %r11
 1010ae3:	49 21 c2             	and    %rax,%r10
 1010ae6:	49 21 d3             	and    %rdx,%r11
 1010ae9:	49 f7 da             	neg    %r10
 1010aec:	4d 01 ca             	add    %r9,%r10
 1010aef:	4c 8b 8d 68 ff ff ff 	mov    -0x98(%rbp),%r9
 1010af6:	4d 29 da             	sub    %r11,%r10
 1010af9:	49 89 cb             	mov    %rcx,%r11
 1010afc:	49 c1 fb 3f          	sar    $0x3f,%r11
 1010b00:	4d 39 d3             	cmp    %r10,%r11
 1010b03:	0f 85 71 01 00 00    	jne    1010c7a <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1cda>
 1010b09:	48 89 8d 20 ff ff ff 	mov    %rcx,-0xe0(%rbp)
 1010b10:	48 8b 95 18 ff ff ff 	mov    -0xe8(%rbp),%rdx
 1010b17:	48 89 c8             	mov    %rcx,%rax
 1010b1a:	48 01 d0             	add    %rdx,%rax
 1010b1d:	49 89 d2             	mov    %rdx,%r10
 1010b20:	49 31 c2             	xor    %rax,%r10
 1010b23:	49 89 cb             	mov    %rcx,%r11
 1010b26:	49 31 c3             	xor    %rax,%r11
 1010b29:	4d 21 da             	and    %r11,%r10
 1010b2c:	49 83 fa 00          	cmp    $0x0,%r10
 1010b30:	0f 8c 32 01 00 00    	jl     1010c68 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1cc8>
 1010b36:	48 89 85 18 ff ff ff 	mov    %rax,-0xe8(%rbp)
 1010b3d:	48 c7 85 20 ff ff ff 	movq   $0xf4243,-0xe0(%rbp)
 1010b44:	43 42 0f 00 
 1010b48:	48 b9 00 00 00 00 00 	movabs $0x8000000000000000,%rcx
 1010b4f:	00 00 80 
 1010b52:	48 39 c8             	cmp    %rcx,%rax
 1010b55:	0f 94 c1             	sete   %cl
 1010b58:	48 0f b6 c9          	movzbq %cl,%rcx
 1010b5c:	48 83 e1 00          	and    $0x0,%rcx
 1010b60:	48 f7 d9             	neg    %rcx
 1010b63:	48 81 e1 42 42 0f 00 	and    $0xf4242,%rcx
 1010b6a:	49 89 ca             	mov    %rcx,%r10
 1010b6d:	49 81 f2 43 42 0f 00 	xor    $0xf4243,%r10
 1010b74:	48 99                	cqto
 1010b76:	49 f7 fa             	idiv   %r10
 1010b79:	48 89 d1             	mov    %rdx,%rcx
 1010b7c:	48 83 f9 00          	cmp    $0x0,%rcx
 1010b80:	0f 95 c0             	setne  %al
 1010b83:	48 0f b6 c0          	movzbq %al,%rax
 1010b87:	4c 89 d2             	mov    %r10,%rdx
 1010b8a:	48 31 ca             	xor    %rcx,%rdx
 1010b8d:	48 83 fa 00          	cmp    $0x0,%rdx
 1010b91:	0f 9c c2             	setl   %dl
 1010b94:	48 0f b6 d2          	movzbq %dl,%rdx
 1010b98:	48 21 d0             	and    %rdx,%rax
 1010b9b:	48 f7 d8             	neg    %rax
 1010b9e:	4c 21 d0             	and    %r10,%rax
 1010ba1:	48 01 c1             	add    %rax,%rcx
 1010ba4:	48 89 8d 48 ff ff ff 	mov    %rcx,-0xb8(%rbp)
 1010bab:	48 89 8d 18 ff ff ff 	mov    %rcx,-0xe8(%rbp)
 1010bb2:	8b 85 20 fe ff ff    	mov    -0x1e0(%rbp),%eax
 1010bb8:	83 f8 00             	cmp    $0x0,%eax
 1010bbb:	74 31                	je     1010bee <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1c4e>
 1010bbd:	4c 89 fe             	mov    %r15,%rsi
 1010bc0:	49 89 ff             	mov    %rdi,%r15
 1010bc3:	e8 98 5c 00 00       	call   1016860 <myl_qbe_rc_slot_drop>
 1010bc8:	4c 89 ff             	mov    %r15,%rdi
 1010bcb:	48 8b 8d 48 ff ff ff 	mov    -0xb8(%rbp),%rcx
 1010bd2:	4c 8b 85 60 ff ff ff 	mov    -0xa0(%rbp),%r8
 1010bd9:	48 8b b5 58 ff ff ff 	mov    -0xa8(%rbp),%rsi
 1010be0:	4c 8b 8d 68 ff ff ff 	mov    -0x98(%rbp),%r9
 1010be7:	4c 8b bd 50 ff ff ff 	mov    -0xb0(%rbp),%r15
 1010bee:	4c 89 a5 18 ff ff ff 	mov    %r12,-0xe8(%rbp)
 1010bf5:	48 8b 85 08 ff ff ff 	mov    -0xf8(%rbp),%rax
 1010bfc:	48 8b 10             	mov    (%rax),%rdx
 1010bff:	49 39 d4             	cmp    %rdx,%r12
 1010c02:	75 5d                	jne    1010c61 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1cc1>
 1010c04:	48 c7 85 18 ff ff ff 	movq   $0x0,-0xe8(%rbp)
 1010c0b:	00 00 00 00 
 1010c0f:	4c 89 b5 18 ff ff ff 	mov    %r14,-0xe8(%rbp)
 1010c16:	48 c7 85 20 ff ff ff 	movq   $0x1,-0xe0(%rbp)
 1010c1d:	01 00 00 00 
 1010c21:	48 ba fe ff ff ff ff 	movabs $0x7ffffffffffffffe,%rdx
 1010c28:	ff ff 7f 
 1010c2b:	49 39 d6             	cmp    %rdx,%r14
 1010c2e:	7f 14                	jg     1010c44 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1ca4>
 1010c30:	49 83 c6 01          	add    $0x1,%r14
 1010c34:	4c 89 b5 18 ff ff ff 	mov    %r14,-0xe8(%rbp)
 1010c3b:	48 89 4d a0          	mov    %rcx,-0x60(%rbp)
 1010c3f:	e9 bc fa ff ff       	jmp    1010700 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1760>
 1010c44:	4c 89 f6             	mov    %r14,%rsi
 1010c47:	41 b8 40 00 00 00    	mov    $0x40,%r8d
 1010c4d:	b9 01 00 00 00       	mov    $0x1,%ecx
 1010c52:	48 89 f2             	mov    %rsi,%rdx
 1010c55:	be 00 00 00 00       	mov    $0x0,%esi
 1010c5a:	e8 91 62 00 00       	call   1016ef0 <myl_qbe_fail_overflow_op>
 1010c5f:	0f 0b                	ud2
 1010c61:	e8 0a 62 00 00       	call   1016e70 <myl_qbe_fail_iteration>
 1010c66:	0f 0b                	ud2
 1010c68:	41 b8 40 00 00 00    	mov    $0x40,%r8d
 1010c6e:	be 00 00 00 00       	mov    $0x0,%esi
 1010c73:	e8 78 62 00 00       	call   1016ef0 <myl_qbe_fail_overflow_op>
 1010c78:	0f 0b                	ud2
 1010c7a:	48 89 c1             	mov    %rax,%rcx
 1010c7d:	41 b8 40 00 00 00    	mov    $0x40,%r8d
 1010c83:	be 02 00 00 00       	mov    $0x2,%esi
 1010c88:	e8 63 62 00 00       	call   1016ef0 <myl_qbe_fail_overflow_op>
 1010c8d:	0f 0b                	ud2
 1010c8f:	48 89 fb             	mov    %rdi,%rbx
 1010c92:	e8 c9 61 00 00       	call   1016e60 <myl_qbe_fail_missing_key>
 1010c97:	0f 0b                	ud2
 1010c99:	48 87 fb             	xchg   %rdi,%rbx
 1010c9c:	e8 5f 2b 01 00       	call   1023800 <myl_rc_take_failure>
 1010ca1:	48 89 df             	mov    %rbx,%rdi
 1010ca4:	89 c6                	mov    %eax,%esi
 1010ca6:	48 89 fb             	mov    %rdi,%rbx
 1010ca9:	e8 e2 59 00 00       	call   1016690 <myl_qbe_rc_status>
 1010cae:	48 89 df             	mov    %rbx,%rdi
 1010cb1:	e9 ef 00 00 00       	jmp    1010da5 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1e05>
 1010cb6:	48 87 fb             	xchg   %rdi,%rbx
 1010cb9:	e8 42 2b 01 00       	call   1023800 <myl_rc_take_failure>
 1010cbe:	48 89 df             	mov    %rbx,%rdi
 1010cc1:	89 c6                	mov    %eax,%esi
 1010cc3:	48 89 fb             	mov    %rdi,%rbx
 1010cc6:	e8 c5 59 00 00       	call   1016690 <myl_qbe_rc_status>
 1010ccb:	48 89 df             	mov    %rbx,%rdi
 1010cce:	e9 d2 00 00 00       	jmp    1010da5 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1e05>
 1010cd3:	48 89 ca             	mov    %rcx,%rdx
 1010cd6:	4c 89 f6             	mov    %r14,%rsi
 1010cd9:	e8 a2 61 00 00       	call   1016e80 <myl_qbe_fail_normalized_index_bounds>
 1010cde:	0f 0b                	ud2
 1010ce0:	e8 8b 61 00 00       	call   1016e70 <myl_qbe_fail_iteration>
 1010ce5:	0f 0b                	ud2
 1010ce7:	48 8b 4d a0          	mov    -0x60(%rbp),%rcx
 1010ceb:	4c 8b a5 40 ff ff ff 	mov    -0xc0(%rbp),%r12
 1010cf2:	4c 89 a5 18 ff ff ff 	mov    %r12,-0xe8(%rbp)
 1010cf9:	48 89 8d 20 ff ff ff 	mov    %rcx,-0xe0(%rbp)
 1010d00:	4c 89 e6             	mov    %r12,%rsi
 1010d03:	48 89 fb             	mov    %rdi,%rbx
 1010d06:	e8 25 80 00 00       	call   1018d30 <myl_qbe_stream_begin>
 1010d0b:	4c 89 e2             	mov    %r12,%rdx
 1010d0e:	48 89 df             	mov    %rbx,%rdi
 1010d11:	48 89 c6             	mov    %rax,%rsi
 1010d14:	49 89 d5             	mov    %rdx,%r13
 1010d17:	ba 00 00 00 00       	mov    $0x0,%edx
 1010d1c:	49 89 f4             	mov    %rsi,%r12
 1010d1f:	48 8d b5 20 ff ff ff 	lea    -0xe0(%rbp),%rsi
 1010d26:	48 89 fb             	mov    %rdi,%rbx
 1010d29:	4c 89 e7             	mov    %r12,%rdi
 1010d2c:	e8 af 00 00 00       	call   1010de0 <myl_r_1a91deb3742283487d66c3b500f6effd7ef1170e6d4b4368fe9ec3c3f0354fda>
 1010d31:	4c 89 e6             	mov    %r12,%rsi
 1010d34:	48 89 df             	mov    %rbx,%rdi
 1010d37:	49 89 f4             	mov    %rsi,%r12
 1010d3a:	be 0a 00 00 00       	mov    $0xa,%esi
 1010d3f:	48 89 fb             	mov    %rdi,%rbx
 1010d42:	4c 89 e7             	mov    %r12,%rdi
 1010d45:	e8 36 7f 00 00       	call   1018c80 <myl_qbe_print_byte>
 1010d4a:	4c 89 ea             	mov    %r13,%rdx
 1010d4d:	4c 89 e6             	mov    %r12,%rsi
 1010d50:	48 89 df             	mov    %rbx,%rdi
 1010d53:	48 89 fb             	mov    %rdi,%rbx
 1010d56:	e8 15 80 00 00       	call   1018d70 <myl_qbe_stream_finish>
 1010d5b:	48 89 df             	mov    %rbx,%rdi
 1010d5e:	48 c7 85 18 ff ff ff 	movq   $0x0,-0xe8(%rbp)
 1010d65:	00 00 00 00 
 1010d69:	48 c7 85 18 ff ff ff 	movq   $0x0,-0xe8(%rbp)
 1010d70:	00 00 00 00 
 1010d74:	48 8d b5 28 fc ff ff 	lea    -0x3d8(%rbp),%rsi
 1010d7b:	48 89 fb             	mov    %rdi,%rbx
 1010d7e:	e8 0d 5c 00 00       	call   1016990 <myl_qbe_rc_frame_cleanup>
 1010d83:	48 89 df             	mov    %rbx,%rdi
 1010d86:	48 8d b5 28 fc ff ff 	lea    -0x3d8(%rbp),%rsi
 1010d8d:	e8 6e 5a 00 00       	call   1016800 <myl_qbe_rc_frame_leave>
 1010d92:	b8 00 00 00 00       	mov    $0x0,%eax
 1010d97:	eb 2f                	jmp    1010dc8 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1e28>
 1010d99:	ba 40 01 00 00       	mov    $0x140,%edx
 1010d9e:	e8 8d 62 00 00       	call   1017030 <myl_qbe_fail_cast>
 1010da3:	0f 0b                	ud2
 1010da5:	48 8d b5 28 fc ff ff 	lea    -0x3d8(%rbp),%rsi
 1010dac:	48 89 fb             	mov    %rdi,%rbx
 1010daf:	e8 dc 5b 00 00       	call   1016990 <myl_qbe_rc_frame_cleanup>
 1010db4:	48 89 df             	mov    %rbx,%rdi
 1010db7:	48 8d b5 28 fc ff ff 	lea    -0x3d8(%rbp),%rsi
 1010dbe:	e8 3d 5a 00 00       	call   1016800 <myl_qbe_rc_frame_leave>
 1010dc3:	b8 00 00 00 00       	mov    $0x0,%eax
 1010dc8:	41 5f                	pop    %r15
 1010dca:	41 5e                	pop    %r14
 1010dcc:	41 5d                	pop    %r13
 1010dce:	41 5c                	pop    %r12
 1010dd0:	5b                   	pop    %rbx
 1010dd1:	c9                   	leave
 1010dd2:	c3                   	ret

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
