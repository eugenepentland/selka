
.tmp-rc/dict-empty/before-llvm-rc:     file format elf64-x86-64


Disassembly of section .text:

00000000010184f0 <entry_run>:
 10184f0:	55                   	push   %rbp
 10184f1:	48 89 e5             	mov    %rsp,%rbp
 10184f4:	41 57                	push   %r15
 10184f6:	41 56                	push   %r14
 10184f8:	41 55                	push   %r13
 10184fa:	41 54                	push   %r12
 10184fc:	53                   	push   %rbx
 10184fd:	48 81 ec a8 03 00 00 	sub    $0x3a8,%rsp
 1018504:	48 89 fb             	mov    %rdi,%rbx
 1018507:	48 83 bf a0 38 00 00 	cmpq   $0x0,0x38a0(%rdi)
 101850e:	00 
 101850f:	74 10                	je     1018521 <entry_run+0x31>
 1018511:	48 83 7b 20 00       	cmpq   $0x0,0x20(%rbx)
 1018516:	0f 85 60 26 00 00    	jne    101ab7c <entry_run+0x268c>
 101851c:	e9 10 01 00 00       	jmp    1018631 <entry_run+0x141>
 1018521:	bf 01 00 00 00       	mov    $0x1,%edi
 1018526:	be 40 00 00 00       	mov    $0x40,%esi
 101852b:	e8 60 9c 01 00       	call   1032190 <calloc@plt>
 1018530:	48 85 c0             	test   %rax,%rax
 1018533:	0f 84 c7 00 00 00    	je     1018600 <entry_run+0x110>
 1018539:	48 89 83 a0 38 00 00 	mov    %rax,0x38a0(%rbx)
 1018540:	48 8b 8b 70 38 00 00 	mov    0x3870(%rbx),%rcx
 1018547:	48 8d 91 a0 00 00 00 	lea    0xa0(%rcx),%rdx
 101854e:	48 85 c9             	test   %rcx,%rcx
 1018551:	b9 c0 b2 00 01       	mov    $0x100b2c0,%ecx
 1018556:	48 0f 45 ca          	cmovne %rdx,%rcx
 101855a:	48 89 08             	mov    %rcx,(%rax)
 101855d:	48 83 79 08 00       	cmpq   $0x0,0x8(%rcx)
 1018562:	74 0a                	je     101856e <entry_run+0x7e>
 1018564:	48 83 39 00          	cmpq   $0x0,(%rcx)
 1018568:	0f 84 99 00 00 00    	je     1018607 <entry_run+0x117>
 101856e:	48 8b 51 10          	mov    0x10(%rcx),%rdx
 1018572:	48 85 d2             	test   %rdx,%rdx
 1018575:	be 10 27 00 00       	mov    $0x2710,%esi
 101857a:	48 0f 45 f2          	cmovne %rdx,%rsi
 101857e:	48 89 70 18          	mov    %rsi,0x18(%rax)
 1018582:	48 8b 51 18          	mov    0x18(%rcx),%rdx
 1018586:	48 85 d2             	test   %rdx,%rdx
 1018589:	be 40 42 0f 00       	mov    $0xf4240,%esi
 101858e:	48 0f 45 f2          	cmovne %rdx,%rsi
 1018592:	48 89 70 10          	mov    %rsi,0x10(%rax)
 1018596:	48 8b 51 20          	mov    0x20(%rcx),%rdx
 101859a:	48 85 d2             	test   %rdx,%rdx
 101859d:	bf 00 00 01 00       	mov    $0x10000,%edi
 10185a2:	48 0f 45 fa          	cmovne %rdx,%rdi
 10185a6:	48 89 78 20          	mov    %rdi,0x20(%rax)
 10185aa:	48 8b 71 28          	mov    0x28(%rcx),%rsi
 10185ae:	48 85 f6             	test   %rsi,%rsi
 10185b1:	ba 40 00 00 00       	mov    $0x40,%edx
 10185b6:	48 0f 45 d6          	cmovne %rsi,%rdx
 10185ba:	48 89 50 28          	mov    %rdx,0x28(%rax)
 10185be:	4c 8b 41 30          	mov    0x30(%rcx),%r8
 10185c2:	4d 85 c0             	test   %r8,%r8
 10185c5:	be 00 00 10 00       	mov    $0x100000,%esi
 10185ca:	49 0f 45 f0          	cmovne %r8,%rsi
 10185ce:	48 89 70 30          	mov    %rsi,0x30(%rax)
 10185d2:	48 81 ff a0 86 01 00 	cmp    $0x186a0,%rdi
 10185d9:	77 1e                	ja     10185f9 <entry_run+0x109>
 10185db:	48 81 fa 81 00 00 00 	cmp    $0x81,%rdx
 10185e2:	0f 93 c2             	setae  %dl
 10185e5:	48 81 fe 01 00 00 04 	cmp    $0x4000001,%rsi
 10185ec:	40 0f 93 c6          	setae  %sil
 10185f0:	40 08 d6             	or     %dl,%sil
 10185f3:	40 80 fe 01          	cmp    $0x1,%sil
 10185f7:	75 15                	jne    101860e <entry_run+0x11e>
 10185f9:	be 4f 6e 00 01       	mov    $0x1006e4f,%esi
 10185fe:	eb 1e                	jmp    101861e <entry_run+0x12e>
 1018600:	be fa 6c 00 01       	mov    $0x1006cfa,%esi
 1018605:	eb 17                	jmp    101861e <entry_run+0x12e>
 1018607:	be a0 6f 00 01       	mov    $0x1006fa0,%esi
 101860c:	eb 10                	jmp    101861e <entry_run+0x12e>
 101860e:	48 83 79 08 00       	cmpq   $0x0,0x8(%rcx)
 1018613:	0f 84 fc 20 00 00    	je     101a715 <entry_run+0x2225>
 1018619:	be 8c 6f 00 01       	mov    $0x1006f8c,%esi
 101861e:	48 89 df             	mov    %rbx,%rdi
 1018621:	e8 fa 2f 00 00       	call   101b620 <fail>
 1018626:	48 83 7b 20 00       	cmpq   $0x0,0x20(%rbx)
 101862b:	0f 85 4b 25 00 00    	jne    101ab7c <entry_run+0x268c>
 1018631:	48 c7 85 18 fd ff ff 	movq   $0x0,-0x2e8(%rbp)
 1018638:	00 00 00 00 
 101863c:	48 c7 45 98 00 00 00 	movq   $0x0,-0x68(%rbp)
 1018643:	00 
 1018644:	48 c7 45 a0 00 00 00 	movq   $0x0,-0x60(%rbp)
 101864b:	00 
 101864c:	48 c7 85 20 fd ff ff 	movq   $0x0,-0x2e0(%rbp)
 1018653:	00 00 00 00 
 1018657:	48 c7 85 08 ff ff ff 	movq   $0x0,-0xf8(%rbp)
 101865e:	00 00 00 00 
 1018662:	48 c7 85 28 fd ff ff 	movq   $0x0,-0x2d8(%rbp)
 1018669:	00 00 00 00 
 101866d:	48 c7 85 10 ff ff ff 	movq   $0x0,-0xf0(%rbp)
 1018674:	00 00 00 00 
 1018678:	48 c7 85 18 ff ff ff 	movq   $0x0,-0xe8(%rbp)
 101867f:	00 00 00 00 
 1018683:	8b 83 c8 02 00 00    	mov    0x2c8(%rbx),%eax
 1018689:	89 45 b8             	mov    %eax,-0x48(%rbp)
 101868c:	48 8d 95 70 ff ff ff 	lea    -0x90(%rbp),%rdx
 1018693:	48 8d 85 50 ff ff ff 	lea    -0xb0(%rbp),%rax
 101869a:	48 c7 85 30 fd ff ff 	movq   $0x1009fd0,-0x2d0(%rbp)
 10186a1:	d0 9f 00 01 
 10186a5:	c7 85 48 fd ff ff 02 	movl   $0x2,-0x2b8(%rbp)
 10186ac:	00 00 00 
 10186af:	4c 8d b5 18 fd ff ff 	lea    -0x2e8(%rbp),%r14
 10186b6:	4c 89 b5 38 fd ff ff 	mov    %r14,-0x2c8(%rbp)
 10186bd:	4c 8d a5 30 ff ff ff 	lea    -0xd0(%rbp),%r12
 10186c4:	4c 89 a5 40 fd ff ff 	mov    %r12,-0x2c0(%rbp)
 10186cb:	48 c7 85 50 fd ff ff 	movq   $0x1009fd0,-0x2b0(%rbp)
 10186d2:	d0 9f 00 01 
 10186d6:	c7 85 68 fd ff ff 02 	movl   $0x2,-0x298(%rbp)
 10186dd:	00 00 00 
 10186e0:	48 8d 4d 98          	lea    -0x68(%rbp),%rcx
 10186e4:	48 89 8d 58 fd ff ff 	mov    %rcx,-0x2a8(%rbp)
 10186eb:	48 8d 8d 38 ff ff ff 	lea    -0xc8(%rbp),%rcx
 10186f2:	48 89 8d 60 fd ff ff 	mov    %rcx,-0x2a0(%rbp)
 10186f9:	48 c7 85 70 fd ff ff 	movq   $0x100a7b0,-0x290(%rbp)
 1018700:	b0 a7 00 01 
 1018704:	c7 85 88 fd ff ff 02 	movl   $0x2,-0x278(%rbp)
 101870b:	00 00 00 
 101870e:	48 8d 4d a0          	lea    -0x60(%rbp),%rcx
 1018712:	48 89 8d 78 fd ff ff 	mov    %rcx,-0x288(%rbp)
 1018719:	48 8d 8d 40 ff ff ff 	lea    -0xc0(%rbp),%rcx
 1018720:	48 89 8d 80 fd ff ff 	mov    %rcx,-0x280(%rbp)
 1018727:	48 c7 85 90 fd ff ff 	movq   $0x1009fd0,-0x270(%rbp)
 101872e:	d0 9f 00 01 
 1018732:	c7 85 a8 fd ff ff 02 	movl   $0x2,-0x258(%rbp)
 1018739:	00 00 00 
 101873c:	48 8d 8d 20 fd ff ff 	lea    -0x2e0(%rbp),%rcx
 1018743:	48 89 8d 98 fd ff ff 	mov    %rcx,-0x268(%rbp)
 101874a:	48 8d 8d 48 ff ff ff 	lea    -0xb8(%rbp),%rcx
 1018751:	48 89 8d a0 fd ff ff 	mov    %rcx,-0x260(%rbp)
 1018758:	48 c7 85 b0 fd ff ff 	movq   $0x1009f60,-0x250(%rbp)
 101875f:	60 9f 00 01 
 1018763:	c7 85 c8 fd ff ff 02 	movl   $0x2,-0x238(%rbp)
 101876a:	00 00 00 
 101876d:	48 8d 8d 08 ff ff ff 	lea    -0xf8(%rbp),%rcx
 1018774:	48 89 8d b8 fd ff ff 	mov    %rcx,-0x248(%rbp)
 101877b:	48 89 85 c0 fd ff ff 	mov    %rax,-0x240(%rbp)
 1018782:	48 c7 85 d0 fd ff ff 	movq   $0x100a7b0,-0x230(%rbp)
 1018789:	b0 a7 00 01 
 101878d:	c7 85 e8 fd ff ff 02 	movl   $0x2,-0x218(%rbp)
 1018794:	00 00 00 
 1018797:	48 8d 85 28 fd ff ff 	lea    -0x2d8(%rbp),%rax
 101879e:	48 89 85 d8 fd ff ff 	mov    %rax,-0x228(%rbp)
 10187a5:	48 8d 85 58 ff ff ff 	lea    -0xa8(%rbp),%rax
 10187ac:	48 89 85 e0 fd ff ff 	mov    %rax,-0x220(%rbp)
 10187b3:	48 c7 85 f0 fd ff ff 	movq   $0x1009fd0,-0x210(%rbp)
 10187ba:	d0 9f 00 01 
 10187be:	c7 85 08 fe ff ff 02 	movl   $0x2,-0x1f8(%rbp)
 10187c5:	00 00 00 
 10187c8:	48 8d 85 10 ff ff ff 	lea    -0xf0(%rbp),%rax
 10187cf:	48 89 85 f8 fd ff ff 	mov    %rax,-0x208(%rbp)
 10187d6:	48 8d 85 60 ff ff ff 	lea    -0xa0(%rbp),%rax
 10187dd:	48 89 85 00 fe ff ff 	mov    %rax,-0x200(%rbp)
 10187e4:	48 c7 85 10 fe ff ff 	movq   $0x1009f60,-0x1f0(%rbp)
 10187eb:	60 9f 00 01 
 10187ef:	c7 85 28 fe ff ff 02 	movl   $0x2,-0x1d8(%rbp)
 10187f6:	00 00 00 
 10187f9:	48 8d 85 18 ff ff ff 	lea    -0xe8(%rbp),%rax
 1018800:	48 89 85 18 fe ff ff 	mov    %rax,-0x1e8(%rbp)
 1018807:	48 8d 85 68 ff ff ff 	lea    -0x98(%rbp),%rax
 101880e:	48 89 85 20 fe ff ff 	mov    %rax,-0x1e0(%rbp)
 1018815:	48 c7 85 30 fe ff ff 	movq   $0x100a190,-0x1d0(%rbp)
 101881c:	90 a1 00 01 
 1018820:	c7 85 48 fe ff ff 00 	movl   $0x0,-0x1b8(%rbp)
 1018827:	00 00 00 
 101882a:	48 8d 45 a8          	lea    -0x58(%rbp),%rax
 101882e:	48 89 85 38 fe ff ff 	mov    %rax,-0x1c8(%rbp)
 1018835:	48 89 95 40 fe ff ff 	mov    %rdx,-0x1c0(%rbp)
 101883c:	48 c7 85 50 fe ff ff 	movq   $0x100a190,-0x1b0(%rbp)
 1018843:	90 a1 00 01 
 1018847:	c7 85 68 fe ff ff 00 	movl   $0x0,-0x198(%rbp)
 101884e:	00 00 00 
 1018851:	48 8d 85 c8 fc ff ff 	lea    -0x338(%rbp),%rax
 1018858:	48 89 85 58 fe ff ff 	mov    %rax,-0x1a8(%rbp)
 101885f:	48 8d 85 78 ff ff ff 	lea    -0x88(%rbp),%rax
 1018866:	48 89 85 60 fe ff ff 	mov    %rax,-0x1a0(%rbp)
 101886d:	48 c7 85 70 fe ff ff 	movq   $0x100a190,-0x190(%rbp)
 1018874:	90 a1 00 01 
 1018878:	c7 85 88 fe ff ff 00 	movl   $0x0,-0x178(%rbp)
 101887f:	00 00 00 
 1018882:	48 8d 85 38 fc ff ff 	lea    -0x3c8(%rbp),%rax
 1018889:	48 89 85 78 fe ff ff 	mov    %rax,-0x188(%rbp)
 1018890:	48 8d 45 80          	lea    -0x80(%rbp),%rax
 1018894:	48 89 85 80 fe ff ff 	mov    %rax,-0x180(%rbp)
 101889b:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
 101889f:	c5 fc 11 85 70 ff ff 	vmovups %ymm0,-0x90(%rbp)
 10188a6:	ff 
 10188a7:	c5 fc 11 85 50 ff ff 	vmovups %ymm0,-0xb0(%rbp)
 10188ae:	ff 
 10188af:	c5 fc 11 85 30 ff ff 	vmovups %ymm0,-0xd0(%rbp)
 10188b6:	ff 
 10188b7:	48 c7 45 90 00 00 00 	movq   $0x0,-0x70(%rbp)
 10188be:	00 
 10188bf:	48 c7 85 90 fe ff ff 	movq   $0x100a190,-0x170(%rbp)
 10188c6:	90 a1 00 01 
 10188ca:	c7 85 a8 fe ff ff 00 	movl   $0x0,-0x158(%rbp)
 10188d1:	00 00 00 
 10188d4:	48 8d 45 c8          	lea    -0x38(%rbp),%rax
 10188d8:	48 89 85 98 fe ff ff 	mov    %rax,-0x168(%rbp)
 10188df:	48 8d 45 88          	lea    -0x78(%rbp),%rax
 10188e3:	48 89 85 a0 fe ff ff 	mov    %rax,-0x160(%rbp)
 10188ea:	48 c7 85 b0 fe ff ff 	movq   $0x100a190,-0x150(%rbp)
 10188f1:	90 a1 00 01 
 10188f5:	c7 85 c8 fe ff ff 00 	movl   $0x0,-0x138(%rbp)
 10188fc:	00 00 00 
 10188ff:	48 8d 85 10 fd ff ff 	lea    -0x2f0(%rbp),%rax
 1018906:	48 89 85 b8 fe ff ff 	mov    %rax,-0x148(%rbp)
 101890d:	48 8d 45 90          	lea    -0x70(%rbp),%rax
 1018911:	48 89 85 c0 fe ff ff 	mov    %rax,-0x140(%rbp)
 1018918:	48 8b 83 60 18 00 00 	mov    0x1860(%rbx),%rax
 101891f:	48 85 c0             	test   %rax,%rax
 1018922:	0f 84 73 22 00 00    	je     101ab9b <entry_run+0x26ab>
 1018928:	48 8b 8b 80 3d 00 00 	mov    0x3d80(%rbx),%rcx
 101892f:	48 8b 40 70          	mov    0x70(%rax),%rax
 1018933:	48 89 8d e8 fe ff ff 	mov    %rcx,-0x118(%rbp)
 101893a:	48 8d 8d 30 fd ff ff 	lea    -0x2d0(%rbp),%rcx
 1018941:	48 89 8d f0 fe ff ff 	mov    %rcx,-0x110(%rbp)
 1018948:	48 c7 85 f8 fe ff ff 	movq   $0xd,-0x108(%rbp)
 101894f:	0d 00 00 00 
 1018953:	48 89 85 00 ff ff ff 	mov    %rax,-0x100(%rbp)
 101895a:	48 8d 85 e8 fe ff ff 	lea    -0x118(%rbp),%rax
 1018961:	48 89 83 80 3d 00 00 	mov    %rax,0x3d80(%rbx)
 1018968:	48 83 7b 10 ff       	cmpq   $0xffffffffffffffff,0x10(%rbx)
 101896d:	74 3c                	je     10189ab <entry_run+0x4bb>
 101896f:	48 83 7b 20 00       	cmpq   $0x0,0x20(%rbx)
 1018974:	75 25                	jne    101899b <entry_run+0x4ab>
 1018976:	c7 83 e0 38 00 00 01 	movl   $0x1,0x38e0(%rbx)
 101897d:	00 00 00 
 1018980:	c5 fc 11 83 e4 38 00 	vmovups %ymm0,0x38e4(%rbx)
 1018987:	00 
 1018988:	c5 fc 11 83 f0 38 00 	vmovups %ymm0,0x38f0(%rbx)
 101898f:	00 
 1018990:	48 c7 83 10 39 00 00 	movq   $0x1007097,0x3910(%rbx)
 1018997:	97 70 00 01 
 101899b:	be 39 75 00 01       	mov    $0x1007539,%esi
 10189a0:	48 89 df             	mov    %rbx,%rdi
 10189a3:	c5 f8 77             	vzeroupper
 10189a6:	e8 75 2c 00 00       	call   101b620 <fail>
 10189ab:	4c 8d ab 58 02 00 00 	lea    0x258(%rbx),%r13
 10189b2:	48 83 7b 38 ff       	cmpq   $0xffffffffffffffff,0x38(%rbx)
 10189b7:	74 40                	je     10189f9 <entry_run+0x509>
 10189b9:	48 83 7b 20 00       	cmpq   $0x0,0x20(%rbx)
 10189be:	75 29                	jne    10189e9 <entry_run+0x4f9>
 10189c0:	c7 83 e0 38 00 00 01 	movl   $0x1,0x38e0(%rbx)
 10189c7:	00 00 00 
 10189ca:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
 10189ce:	c5 fc 11 83 e4 38 00 	vmovups %ymm0,0x38e4(%rbx)
 10189d5:	00 
 10189d6:	c5 fc 11 83 f0 38 00 	vmovups %ymm0,0x38f0(%rbx)
 10189dd:	00 
 10189de:	48 c7 83 10 39 00 00 	movq   $0x10070e0,0x3910(%rbx)
 10189e5:	e0 70 00 01 
 10189e9:	be 4e 75 00 01       	mov    $0x100754e,%esi
 10189ee:	48 89 df             	mov    %rbx,%rdi
 10189f1:	c5 f8 77             	vzeroupper
 10189f4:	e8 27 2c 00 00       	call   101b620 <fail>
 10189f9:	48 c7 45 d0 00 00 00 	movq   $0x0,-0x30(%rbp)
 1018a00:	00 
 1018a01:	be 60 9f 00 01       	mov    $0x1009f60,%esi
 1018a06:	4c 89 ef             	mov    %r13,%rdi
 1018a09:	c5 f8 77             	vzeroupper
 1018a0c:	e8 5f 6d 00 00       	call   101f770 <myl_native_list_new>
 1018a11:	48 85 c0             	test   %rax,%rax
 1018a14:	0f 84 c7 21 00 00    	je     101abe1 <entry_run+0x26f1>
 1018a1a:	48 b9 01 00 00 00 00 	movabs $0x5000000000000001,%rcx
 1018a21:	00 00 50 
 1018a24:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
 1018a28:	48 c7 85 90 fe ff ff 	movq   $0x1009fd0,-0x170(%rbp)
 1018a2f:	d0 9f 00 01 
 1018a33:	c7 85 a8 fe ff ff 02 	movl   $0x2,-0x158(%rbp)
 1018a3a:	00 00 00 
 1018a3d:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
 1018a41:	48 c7 85 30 fe ff ff 	movq   $0x1009fd0,-0x1d0(%rbp)
 1018a48:	d0 9f 00 01 
 1018a4c:	c7 85 48 fe ff ff 02 	movl   $0x2,-0x1b8(%rbp)
 1018a53:	00 00 00 
 1018a56:	c7 45 88 00 00 00 00 	movl   $0x0,-0x78(%rbp)
 1018a5d:	c7 85 70 ff ff ff 01 	movl   $0x1,-0x90(%rbp)
 1018a64:	00 00 00 
 1018a67:	48 89 45 d0          	mov    %rax,-0x30(%rbp)
 1018a6b:	48 85 48 f0          	test   %rcx,-0x10(%rax)
 1018a6f:	74 22                	je     1018a93 <entry_run+0x5a3>
 1018a71:	48 8d 55 c8          	lea    -0x38(%rbp),%rdx
 1018a75:	48 8d 4d d0          	lea    -0x30(%rbp),%rcx
 1018a79:	be d0 9f 00 01       	mov    $0x1009fd0,%esi
 1018a7e:	4c 89 ef             	mov    %r13,%rdi
 1018a81:	44 8b 45 b8          	mov    -0x48(%rbp),%r8d
 1018a85:	e8 16 52 01 00       	call   102dca0 <myl_rc_native_take>
 1018a8a:	85 c0                	test   %eax,%eax
 1018a8c:	75 0d                	jne    1018a9b <entry_run+0x5ab>
 1018a8e:	e9 d9 07 00 00       	jmp    101926c <entry_run+0xd7c>
 1018a93:	48 c7 45 d0 00 00 00 	movq   $0x0,-0x30(%rbp)
 1018a9a:	00 
 1018a9b:	c7 85 70 ff ff ff 00 	movl   $0x0,-0x90(%rbp)
 1018aa2:	00 00 00 
 1018aa5:	48 c7 85 90 fe ff ff 	movq   $0x1009fd0,-0x170(%rbp)
 1018aac:	d0 9f 00 01 
 1018ab0:	c7 85 a8 fe ff ff 02 	movl   $0x2,-0x158(%rbp)
 1018ab7:	00 00 00 
 1018aba:	c7 45 88 01 00 00 00 	movl   $0x1,-0x78(%rbp)
 1018ac1:	83 bd 30 ff ff ff 00 	cmpl   $0x0,-0xd0(%rbp)
 1018ac8:	74 17                	je     1018ae1 <entry_run+0x5f1>
 1018aca:	48 8d b5 30 fd ff ff 	lea    -0x2d0(%rbp),%rsi
 1018ad1:	48 89 df             	mov    %rbx,%rdi
 1018ad4:	e8 b7 21 00 00       	call   101ac90 <myl_qbe_rc_slot_drop>
 1018ad9:	8b 8d a8 fe ff ff    	mov    -0x158(%rbp),%ecx
 1018adf:	eb 05                	jmp    1018ae6 <entry_run+0x5f6>
 1018ae1:	b9 02 00 00 00       	mov    $0x2,%ecx
 1018ae6:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
 1018aea:	48 89 85 18 fd ff ff 	mov    %rax,-0x2e8(%rbp)
 1018af1:	c7 45 88 00 00 00 00 	movl   $0x0,-0x78(%rbp)
 1018af8:	48 c7 85 30 fd ff ff 	movq   $0x1009fd0,-0x2d0(%rbp)
 1018aff:	d0 9f 00 01 
 1018b03:	4c 89 b5 38 fd ff ff 	mov    %r14,-0x2c8(%rbp)
 1018b0a:	4c 89 a5 40 fd ff ff 	mov    %r12,-0x2c0(%rbp)
 1018b11:	89 8d 48 fd ff ff    	mov    %ecx,-0x2b8(%rbp)
 1018b17:	c7 85 30 ff ff ff 01 	movl   $0x1,-0xd0(%rbp)
 1018b1e:	00 00 00 
 1018b21:	83 f9 08             	cmp    $0x8,%ecx
 1018b24:	0f 85 d1 00 00 00    	jne    1018bfb <entry_run+0x70b>
 1018b2a:	48 c7 45 c8 00 00 00 	movq   $0x0,-0x38(%rbp)
 1018b31:	00 
 1018b32:	48 85 c0             	test   %rax,%rax
 1018b35:	74 4c                	je     1018b83 <entry_run+0x693>
 1018b37:	48 8b 48 f0          	mov    -0x10(%rax),%rcx
 1018b3b:	48 ba 02 00 00 00 00 	movabs $0x4000000000000002,%rdx
 1018b42:	00 00 40 
 1018b45:	48 85 d1             	test   %rdx,%rcx
 1018b48:	75 39                	jne    1018b83 <entry_run+0x693>
 1018b4a:	48 83 bb 60 18 00 00 	cmpq   $0x0,0x1860(%rbx)
 1018b51:	00 
 1018b52:	0f 84 43 20 00 00    	je     101ab9b <entry_run+0x26ab>
 1018b58:	f6 c1 01             	test   $0x1,%cl
 1018b5b:	0f 85 3a 20 00 00    	jne    101ab9b <entry_run+0x26ab>
 1018b61:	48 8b 48 e8          	mov    -0x18(%rax),%rcx
 1018b65:	48 8b 50 e0          	mov    -0x20(%rax),%rdx
 1018b69:	48 09 ca             	or     %rcx,%rdx
 1018b6c:	0f 84 29 20 00 00    	je     101ab9b <entry_run+0x26ab>
 1018b72:	48 83 f9 ff          	cmp    $0xffffffffffffffff,%rcx
 1018b76:	0f 84 8f 1b 00 00    	je     101a70b <entry_run+0x221b>
 1018b7c:	48 ff c1             	inc    %rcx
 1018b7f:	48 89 48 e8          	mov    %rcx,-0x18(%rax)
 1018b83:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
 1018b87:	48 c7 85 90 fe ff ff 	movq   $0x1009fd0,-0x170(%rbp)
 1018b8e:	d0 9f 00 01 
 1018b92:	48 8d 4d c8          	lea    -0x38(%rbp),%rcx
 1018b96:	48 89 8d 98 fe ff ff 	mov    %rcx,-0x168(%rbp)
 1018b9d:	48 8d 4d 88          	lea    -0x78(%rbp),%rcx
 1018ba1:	48 89 8d a0 fe ff ff 	mov    %rcx,-0x160(%rbp)
 1018ba8:	c7 85 a8 fe ff ff 08 	movl   $0x8,-0x158(%rbp)
 1018baf:	00 00 00 
 1018bb2:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
 1018bb6:	48 c7 85 30 fe ff ff 	movq   $0x1009fd0,-0x1d0(%rbp)
 1018bbd:	d0 9f 00 01 
 1018bc1:	48 8d 4d a8          	lea    -0x58(%rbp),%rcx
 1018bc5:	48 89 8d 38 fe ff ff 	mov    %rcx,-0x1c8(%rbp)
 1018bcc:	48 8d 8d 70 ff ff ff 	lea    -0x90(%rbp),%rcx
 1018bd3:	48 89 8d 40 fe ff ff 	mov    %rcx,-0x1c0(%rbp)
 1018bda:	c7 85 48 fe ff ff 08 	movl   $0x8,-0x1b8(%rbp)
 1018be1:	00 00 00 
 1018be4:	c7 85 70 ff ff ff 01 	movl   $0x1,-0x90(%rbp)
 1018beb:	00 00 00 
 1018bee:	c7 45 88 00 00 00 00 	movl   $0x0,-0x78(%rbp)
 1018bf5:	48 89 45 d0          	mov    %rax,-0x30(%rbp)
 1018bf9:	eb 5b                	jmp    1018c56 <entry_run+0x766>
 1018bfb:	8b 8d 70 ff ff ff    	mov    -0x90(%rbp),%ecx
 1018c01:	f6 85 48 fe ff ff 18 	testb  $0x18,-0x1b8(%rbp)
 1018c08:	48 89 45 d0          	mov    %rax,-0x30(%rbp)
 1018c0c:	75 48                	jne    1018c56 <entry_run+0x766>
 1018c0e:	83 e1 01             	and    $0x1,%ecx
 1018c11:	74 43                	je     1018c56 <entry_run+0x766>
 1018c13:	48 85 c0             	test   %rax,%rax
 1018c16:	0f 84 14 07 00 00    	je     1019330 <entry_run+0xe40>
 1018c1c:	48 b9 01 00 00 00 00 	movabs $0x5000000000000001,%rcx
 1018c23:	00 00 50 
 1018c26:	48 85 48 f0          	test   %rcx,-0x10(%rax)
 1018c2a:	0f 84 00 07 00 00    	je     1019330 <entry_run+0xe40>
 1018c30:	48 8d 55 c8          	lea    -0x38(%rbp),%rdx
 1018c34:	48 8d 4d d0          	lea    -0x30(%rbp),%rcx
 1018c38:	be d0 9f 00 01       	mov    $0x1009fd0,%esi
 1018c3d:	4c 89 ef             	mov    %r13,%rdi
 1018c40:	44 8b 45 b8          	mov    -0x48(%rbp),%r8d
 1018c44:	e8 57 50 01 00       	call   102dca0 <myl_rc_native_take>
 1018c49:	85 c0                	test   %eax,%eax
 1018c4b:	0f 85 eb 06 00 00    	jne    101933c <entry_run+0xe4c>
 1018c51:	e9 16 06 00 00       	jmp    101926c <entry_run+0xd7c>
 1018c56:	48 8d 55 c8          	lea    -0x38(%rbp),%rdx
 1018c5a:	48 8d 4d d0          	lea    -0x30(%rbp),%rcx
 1018c5e:	be d0 9f 00 01       	mov    $0x1009fd0,%esi
 1018c63:	4c 89 ef             	mov    %r13,%rdi
 1018c66:	44 8b 45 b8          	mov    -0x48(%rbp),%r8d
 1018c6a:	e8 21 5d 01 00       	call   102e990 <myl_rc_native_retain>
 1018c6f:	85 c0                	test   %eax,%eax
 1018c71:	0f 84 f5 05 00 00    	je     101926c <entry_run+0xd7c>
 1018c77:	48 c7 85 90 fe ff ff 	movq   $0x1009fd0,-0x170(%rbp)
 1018c7e:	d0 9f 00 01 
 1018c82:	c7 85 a8 fe ff ff 02 	movl   $0x2,-0x158(%rbp)
 1018c89:	00 00 00 
 1018c8c:	c7 45 88 01 00 00 00 	movl   $0x1,-0x78(%rbp)
 1018c93:	83 bd 70 ff ff ff 00 	cmpl   $0x0,-0x90(%rbp)
 1018c9a:	74 0f                	je     1018cab <entry_run+0x7bb>
 1018c9c:	48 89 df             	mov    %rbx,%rdi
 1018c9f:	48 8d b5 30 fe ff ff 	lea    -0x1d0(%rbp),%rsi
 1018ca6:	e8 e5 1f 00 00       	call   101ac90 <myl_qbe_rc_slot_drop>
 1018cab:	83 bd 38 ff ff ff 00 	cmpl   $0x0,-0xc8(%rbp)
 1018cb2:	74 0f                	je     1018cc3 <entry_run+0x7d3>
 1018cb4:	48 8d b5 50 fd ff ff 	lea    -0x2b0(%rbp),%rsi
 1018cbb:	48 89 df             	mov    %rbx,%rdi
 1018cbe:	e8 cd 1f 00 00       	call   101ac90 <myl_qbe_rc_slot_drop>
 1018cc3:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
 1018cc7:	48 89 45 98          	mov    %rax,-0x68(%rbp)
 1018ccb:	c7 45 88 00 00 00 00 	movl   $0x0,-0x78(%rbp)
 1018cd2:	48 c7 85 50 fd ff ff 	movq   $0x1009fd0,-0x2b0(%rbp)
 1018cd9:	d0 9f 00 01 
 1018cdd:	48 8d 45 98          	lea    -0x68(%rbp),%rax
 1018ce1:	48 89 85 58 fd ff ff 	mov    %rax,-0x2a8(%rbp)
 1018ce8:	48 8d 85 38 ff ff ff 	lea    -0xc8(%rbp),%rax
 1018cef:	48 89 85 60 fd ff ff 	mov    %rax,-0x2a0(%rbp)
 1018cf6:	8b 85 a8 fe ff ff    	mov    -0x158(%rbp),%eax
 1018cfc:	89 85 68 fd ff ff    	mov    %eax,-0x298(%rbp)
 1018d02:	c7 85 38 ff ff ff 01 	movl   $0x1,-0xc8(%rbp)
 1018d09:	00 00 00 
 1018d0c:	83 bd 30 ff ff ff 00 	cmpl   $0x0,-0xd0(%rbp)
 1018d13:	74 0f                	je     1018d24 <entry_run+0x834>
 1018d15:	48 8d b5 30 fd ff ff 	lea    -0x2d0(%rbp),%rsi
 1018d1c:	48 89 df             	mov    %rbx,%rdi
 1018d1f:	e8 6c 1f 00 00       	call   101ac90 <myl_qbe_rc_slot_drop>
 1018d24:	48 c7 45 c0 e8 03 00 	movq   $0x3e8,-0x40(%rbp)
 1018d2b:	00 
 1018d2c:	45 31 e4             	xor    %r12d,%r12d
 1018d2f:	eb 39                	jmp    1018d6a <entry_run+0x87a>
 1018d31:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1018d38:	0f 1f 84 00 00 00 00 
 1018d3f:	00 
 1018d40:	31 c0                	xor    %eax,%eax
 1018d42:	49 81 fc e7 03 00 00 	cmp    $0x3e7,%r12
 1018d49:	4d 8d 64 24 01       	lea    0x1(%r12),%r12
 1018d4e:	48 c7 45 c0 e8 03 00 	movq   $0x3e8,-0x40(%rbp)
 1018d55:	00 
 1018d56:	0f 92 c0             	setb   %al
 1018d59:	48 89 45 d0          	mov    %rax,-0x30(%rbp)
 1018d5d:	49 81 fc e8 03 00 00 	cmp    $0x3e8,%r12
 1018d64:	0f 84 2a 04 00 00    	je     1019194 <entry_run+0xca4>
 1018d6a:	48 c7 85 20 ff ff ff 	movq   $0x79,-0xe0(%rbp)
 1018d71:	79 00 00 00 
 1018d75:	48 c7 45 c8 b8 5a 03 	movq   $0x1035ab8,-0x38(%rbp)
 1018d7c:	01 
 1018d7d:	48 c7 85 90 fe ff ff 	movq   $0x1009f60,-0x170(%rbp)
 1018d84:	60 9f 00 01 
 1018d88:	c7 85 a8 fe ff ff 02 	movl   $0x2,-0x158(%rbp)
 1018d8f:	00 00 00 
 1018d92:	48 c7 45 a8 b8 5a 03 	movq   $0x1035ab8,-0x58(%rbp)
 1018d99:	01 
 1018d9a:	48 c7 85 30 fe ff ff 	movq   $0x1009f60,-0x1d0(%rbp)
 1018da1:	60 9f 00 01 
 1018da5:	c7 85 48 fe ff ff 02 	movl   $0x2,-0x1b8(%rbp)
 1018dac:	00 00 00 
 1018daf:	c7 45 88 00 00 00 00 	movl   $0x0,-0x78(%rbp)
 1018db6:	c7 85 70 ff ff ff 01 	movl   $0x1,-0x90(%rbp)
 1018dbd:	00 00 00 
 1018dc0:	48 c7 45 d0 b8 5a 03 	movq   $0x1035ab8,-0x30(%rbp)
 1018dc7:	01 
 1018dc8:	4c 89 ef             	mov    %r13,%rdi
 1018dcb:	4c 89 e6             	mov    %r12,%rsi
 1018dce:	31 d2                	xor    %edx,%edx
 1018dd0:	e8 db 7e ff ff       	call   1010cb0 <myl_native_text_scalar>
 1018dd5:	48 85 c0             	test   %rax,%rax
 1018dd8:	0f 84 d2 1d 00 00    	je     101abb0 <entry_run+0x26c0>
 1018dde:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
 1018de2:	48 c7 85 90 fe ff ff 	movq   $0x1009f60,-0x170(%rbp)
 1018de9:	60 9f 00 01 
 1018ded:	c7 85 a8 fe ff ff 02 	movl   $0x2,-0x158(%rbp)
 1018df4:	00 00 00 
 1018df7:	48 89 85 c8 fc ff ff 	mov    %rax,-0x338(%rbp)
 1018dfe:	48 c7 85 50 fe ff ff 	movq   $0x1009f60,-0x1b0(%rbp)
 1018e05:	60 9f 00 01 
 1018e09:	c7 85 68 fe ff ff 02 	movl   $0x2,-0x198(%rbp)
 1018e10:	00 00 00 
 1018e13:	c7 45 88 00 00 00 00 	movl   $0x0,-0x78(%rbp)
 1018e1a:	c7 85 78 ff ff ff 01 	movl   $0x1,-0x88(%rbp)
 1018e21:	00 00 00 
 1018e24:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
 1018e28:	48 8b 4d d0          	mov    -0x30(%rbp),%rcx
 1018e2c:	48 89 8d d8 fe ff ff 	mov    %rcx,-0x128(%rbp)
 1018e33:	48 89 85 e0 fe ff ff 	mov    %rax,-0x120(%rbp)
 1018e3a:	4c 8b 71 08          	mov    0x8(%rcx),%r14
 1018e3e:	4c 03 70 08          	add    0x8(%rax),%r14
 1018e42:	0f 82 60 1d 00 00    	jb     101aba8 <entry_run+0x26b8>
 1018e48:	48 8b 83 68 02 00 00 	mov    0x268(%rbx),%rax
 1018e4f:	48 89 85 40 fc ff ff 	mov    %rax,-0x3c0(%rbp)
 1018e56:	48 8d 85 d8 fe ff ff 	lea    -0x128(%rbp),%rax
 1018e5d:	48 89 85 48 fc ff ff 	mov    %rax,-0x3b8(%rbp)
 1018e64:	48 c7 85 50 fc ff ff 	movq   $0x100c360,-0x3b0(%rbp)
 1018e6b:	60 c3 00 01 
 1018e6f:	48 8d 85 40 fc ff ff 	lea    -0x3c0(%rbp),%rax
 1018e76:	48 89 85 f0 fc ff ff 	mov    %rax,-0x310(%rbp)
 1018e7d:	48 8d 85 e0 fe ff ff 	lea    -0x120(%rbp),%rax
 1018e84:	48 89 85 f8 fc ff ff 	mov    %rax,-0x308(%rbp)
 1018e8b:	48 c7 85 00 fd ff ff 	movq   $0x100c360,-0x300(%rbp)
 1018e92:	60 c3 00 01 
 1018e96:	48 8d 85 f0 fc ff ff 	lea    -0x310(%rbp),%rax
 1018e9d:	48 89 83 68 02 00 00 	mov    %rax,0x268(%rbx)
 1018ea4:	49 83 fe e7          	cmp    $0xffffffffffffffe7,%r14
 1018ea8:	0f 87 d2 00 00 00    	ja     1018f80 <entry_run+0xa90>
 1018eae:	48 83 bb 60 18 00 00 	cmpq   $0x0,0x1860(%rbx)
 1018eb5:	00 
 1018eb6:	0f 84 c4 00 00 00    	je     1018f80 <entry_run+0xa90>
 1018ebc:	8b 83 c8 02 00 00    	mov    0x2c8(%rbx),%eax
 1018ec2:	49 8d 4e 18          	lea    0x18(%r14),%rcx
 1018ec6:	48 c7 85 d0 fe ff ff 	movq   $0x0,-0x130(%rbp)
 1018ecd:	00 00 00 00 
 1018ed1:	48 c7 85 d8 fc ff ff 	movq   $0x100c898,-0x328(%rbp)
 1018ed8:	98 c8 00 01 
 1018edc:	48 89 8d e0 fc ff ff 	mov    %rcx,-0x320(%rbp)
 1018ee3:	89 85 e8 fc ff ff    	mov    %eax,-0x318(%rbp)
 1018ee9:	c7 85 ec fc ff ff 00 	movl   $0x0,-0x314(%rbp)
 1018ef0:	00 00 00 
 1018ef3:	4c 89 ef             	mov    %r13,%rdi
 1018ef6:	48 8d b5 d8 fc ff ff 	lea    -0x328(%rbp),%rsi
 1018efd:	48 8d 95 d0 fe ff ff 	lea    -0x130(%rbp),%rdx
 1018f04:	e8 17 d0 00 00       	call   1025f20 <myl_rc_new>
 1018f09:	85 c0                	test   %eax,%eax
 1018f0b:	74 16                	je     1018f23 <entry_run+0xa33>
 1018f0d:	48 8b 8b 60 18 00 00 	mov    0x1860(%rbx),%rcx
 1018f14:	48 85 c9             	test   %rcx,%rcx
 1018f17:	0f 84 7e 1c 00 00    	je     101ab9b <entry_run+0x26ab>
 1018f1d:	83 79 78 00          	cmpl   $0x0,0x78(%rcx)
 1018f21:	74 40                	je     1018f63 <entry_run+0xa73>
 1018f23:	4c 8b bd d0 fe ff ff 	mov    -0x130(%rbp),%r15
 1018f2a:	4d 85 ff             	test   %r15,%r15
 1018f2d:	74 51                	je     1018f80 <entry_run+0xa90>
 1018f2f:	49 c7 07 00 00 00 00 	movq   $0x0,(%r15)
 1018f36:	4d 89 77 08          	mov    %r14,0x8(%r15)
 1018f3a:	49 c7 47 10 00 00 00 	movq   $0x0,0x10(%r15)
 1018f41:	00 
 1018f42:	4d 8d 77 18          	lea    0x18(%r15),%r14
 1018f46:	4c 8b ad d8 fe ff ff 	mov    -0x128(%rbp),%r13
 1018f4d:	49 8b 55 08          	mov    0x8(%r13),%rdx
 1018f51:	48 85 d2             	test   %rdx,%rdx
 1018f54:	74 7a                	je     1018fd0 <entry_run+0xae0>
 1018f56:	41 f6 45 10 04       	testb  $0x4,0x10(%r13)
 1018f5b:	75 5b                	jne    1018fb8 <entry_run+0xac8>
 1018f5d:	49 8d 75 18          	lea    0x18(%r13),%rsi
 1018f61:	eb 65                	jmp    1018fc8 <entry_run+0xad8>
 1018f63:	89 41 78             	mov    %eax,0x78(%rcx)
 1018f66:	4c 8b bd d0 fe ff ff 	mov    -0x130(%rbp),%r15
 1018f6d:	4d 85 ff             	test   %r15,%r15
 1018f70:	75 bd                	jne    1018f2f <entry_run+0xa3f>
 1018f72:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1018f79:	1f 84 00 00 00 00 00 
 1018f80:	45 31 ff             	xor    %r15d,%r15d
 1018f83:	48 8b 83 68 02 00 00 	mov    0x268(%rbx),%rax
 1018f8a:	48 8d 8d f0 fc ff ff 	lea    -0x310(%rbp),%rcx
 1018f91:	48 39 c8             	cmp    %rcx,%rax
 1018f94:	0f 84 b6 00 00 00    	je     1019050 <entry_run+0xb60>
 1018f9a:	48 8d 8d 40 fc ff ff 	lea    -0x3c0(%rbp),%rcx
 1018fa1:	48 39 c8             	cmp    %rcx,%rax
 1018fa4:	0f 84 c4 00 00 00    	je     101906e <entry_run+0xb7e>
 1018faa:	4d 85 ff             	test   %r15,%r15
 1018fad:	0f 85 d2 00 00 00    	jne    1019085 <entry_run+0xb95>
 1018fb3:	e9 f0 1b 00 00       	jmp    101aba8 <entry_run+0x26b8>
 1018fb8:	49 8b 45 18          	mov    0x18(%r13),%rax
 1018fbc:	41 8b 4d 14          	mov    0x14(%r13),%ecx
 1018fc0:	48 8d 34 08          	lea    (%rax,%rcx,1),%rsi
 1018fc4:	48 83 c6 18          	add    $0x18,%rsi
 1018fc8:	4c 89 f7             	mov    %r14,%rdi
 1018fcb:	e8 70 91 01 00       	call   1032140 <memcpy@plt>
 1018fd0:	48 8b b5 e0 fe ff ff 	mov    -0x120(%rbp),%rsi
 1018fd7:	48 8b 56 08          	mov    0x8(%rsi),%rdx
 1018fdb:	48 85 d2             	test   %rdx,%rdx
 1018fde:	74 35                	je     1019015 <entry_run+0xb25>
 1018fe0:	f6 46 10 04          	testb  $0x4,0x10(%rsi)
 1018fe4:	75 06                	jne    1018fec <entry_run+0xafc>
 1018fe6:	48 83 c6 18          	add    $0x18,%rsi
 1018fea:	eb 0f                	jmp    1018ffb <entry_run+0xb0b>
 1018fec:	48 8b 46 18          	mov    0x18(%rsi),%rax
 1018ff0:	8b 4e 14             	mov    0x14(%rsi),%ecx
 1018ff3:	48 8d 34 08          	lea    (%rax,%rcx,1),%rsi
 1018ff7:	48 83 c6 18          	add    $0x18,%rsi
 1018ffb:	4d 03 75 08          	add    0x8(%r13),%r14
 1018fff:	4c 89 f7             	mov    %r14,%rdi
 1019002:	e8 39 91 01 00       	call   1032140 <memcpy@plt>
 1019007:	4c 8b ad d8 fe ff ff 	mov    -0x128(%rbp),%r13
 101900e:	48 8b b5 e0 fe ff ff 	mov    -0x120(%rbp),%rsi
 1019015:	48 8b 06             	mov    (%rsi),%rax
 1019018:	49 03 45 00          	add    0x0(%r13),%rax
 101901c:	41 8b 4d 10          	mov    0x10(%r13),%ecx
 1019020:	23 4e 10             	and    0x10(%rsi),%ecx
 1019023:	83 e1 01             	and    $0x1,%ecx
 1019026:	49 89 07             	mov    %rax,(%r15)
 1019029:	41 89 4f 10          	mov    %ecx,0x10(%r15)
 101902d:	4c 8d ab 58 02 00 00 	lea    0x258(%rbx),%r13
 1019034:	48 8b 83 68 02 00 00 	mov    0x268(%rbx),%rax
 101903b:	48 8d 8d f0 fc ff ff 	lea    -0x310(%rbp),%rcx
 1019042:	48 39 c8             	cmp    %rcx,%rax
 1019045:	0f 85 4f ff ff ff    	jne    1018f9a <entry_run+0xaaa>
 101904b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
 1019050:	48 8b 85 f0 fc ff ff 	mov    -0x310(%rbp),%rax
 1019057:	48 89 83 68 02 00 00 	mov    %rax,0x268(%rbx)
 101905e:	48 8d 8d 40 fc ff ff 	lea    -0x3c0(%rbp),%rcx
 1019065:	48 39 c8             	cmp    %rcx,%rax
 1019068:	0f 85 3c ff ff ff    	jne    1018faa <entry_run+0xaba>
 101906e:	48 8b 85 40 fc ff ff 	mov    -0x3c0(%rbp),%rax
 1019075:	48 89 83 68 02 00 00 	mov    %rax,0x268(%rbx)
 101907c:	4d 85 ff             	test   %r15,%r15
 101907f:	0f 84 23 1b 00 00    	je     101aba8 <entry_run+0x26b8>
 1019085:	4c 89 7d d0          	mov    %r15,-0x30(%rbp)
 1019089:	4c 89 7d c8          	mov    %r15,-0x38(%rbp)
 101908d:	48 c7 85 90 fe ff ff 	movq   $0x1009f60,-0x170(%rbp)
 1019094:	60 9f 00 01 
 1019098:	c7 85 a8 fe ff ff 02 	movl   $0x2,-0x158(%rbp)
 101909f:	00 00 00 
 10190a2:	c7 45 88 01 00 00 00 	movl   $0x1,-0x78(%rbp)
 10190a9:	83 bd 70 ff ff ff 00 	cmpl   $0x0,-0x90(%rbp)
 10190b0:	74 0f                	je     10190c1 <entry_run+0xbd1>
 10190b2:	48 89 df             	mov    %rbx,%rdi
 10190b5:	48 8d b5 30 fe ff ff 	lea    -0x1d0(%rbp),%rsi
 10190bc:	e8 cf 1b 00 00       	call   101ac90 <myl_qbe_rc_slot_drop>
 10190c1:	83 bd 78 ff ff ff 00 	cmpl   $0x0,-0x88(%rbp)
 10190c8:	74 0f                	je     10190d9 <entry_run+0xbe9>
 10190ca:	48 89 df             	mov    %rbx,%rdi
 10190cd:	48 8d b5 50 fe ff ff 	lea    -0x1b0(%rbp),%rsi
 10190d4:	e8 b7 1b 00 00       	call   101ac90 <myl_qbe_rc_slot_drop>
 10190d9:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
 10190dd:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
 10190e1:	48 c7 85 30 fe ff ff 	movq   $0x1009f60,-0x1d0(%rbp)
 10190e8:	60 9f 00 01 
 10190ec:	8b 8d a8 fe ff ff    	mov    -0x158(%rbp),%ecx
 10190f2:	89 8d 48 fe ff ff    	mov    %ecx,-0x1b8(%rbp)
 10190f8:	c7 45 88 00 00 00 00 	movl   $0x0,-0x78(%rbp)
 10190ff:	c7 85 70 ff ff ff 01 	movl   $0x1,-0x90(%rbp)
 1019106:	00 00 00 
 1019109:	48 89 45 d0          	mov    %rax,-0x30(%rbp)
 101910d:	48 c7 85 50 fd ff ff 	movq   $0x1009fd0,-0x2b0(%rbp)
 1019114:	d0 9f 00 01 
 1019118:	c7 85 68 fd ff ff 02 	movl   $0x2,-0x298(%rbp)
 101911f:	00 00 00 
 1019122:	48 8d 55 98          	lea    -0x68(%rbp),%rdx
 1019126:	48 89 95 58 fd ff ff 	mov    %rdx,-0x2a8(%rbp)
 101912d:	48 8d 8d 38 ff ff ff 	lea    -0xc8(%rbp),%rcx
 1019134:	48 89 8d 60 fd ff ff 	mov    %rcx,-0x2a0(%rbp)
 101913b:	be d0 9f 00 01       	mov    $0x1009fd0,%esi
 1019140:	48 89 df             	mov    %rbx,%rdi
 1019143:	e8 08 21 00 00       	call   101b250 <myl_qbe_rc_unique_local>
 1019148:	85 c0                	test   %eax,%eax
 101914a:	0f 84 69 01 00 00    	je     10192b9 <entry_run+0xdc9>
 1019150:	48 8b 75 98          	mov    -0x68(%rbp),%rsi
 1019154:	48 8b 16             	mov    (%rsi),%rdx
 1019157:	4c 89 ef             	mov    %r13,%rdi
 101915a:	48 8d 4d d0          	lea    -0x30(%rbp),%rcx
 101915e:	e8 ad 6d 00 00       	call   101ff10 <rc_list_insert_at>
 1019163:	85 c0                	test   %eax,%eax
 1019165:	0f 84 4d 1a 00 00    	je     101abb8 <entry_run+0x26c8>
 101916b:	48 c7 45 d0 00 00 00 	movq   $0x0,-0x30(%rbp)
 1019172:	00 
 1019173:	83 bd 70 ff ff ff 00 	cmpl   $0x0,-0x90(%rbp)
 101917a:	0f 84 c0 fb ff ff    	je     1018d40 <entry_run+0x850>
 1019180:	48 89 df             	mov    %rbx,%rdi
 1019183:	48 8d b5 30 fe ff ff 	lea    -0x1d0(%rbp),%rsi
 101918a:	e8 01 1b 00 00       	call   101ac90 <myl_qbe_rc_slot_drop>
 101918f:	e9 ac fb ff ff       	jmp    1018d40 <entry_run+0x850>
 1019194:	be 60 9f 00 01       	mov    $0x1009f60,%esi
 1019199:	ba f0 9e 00 01       	mov    $0x1009ef0,%edx
 101919e:	4c 89 ef             	mov    %r13,%rdi
 10191a1:	b9 01 00 00 00       	mov    $0x1,%ecx
 10191a6:	e8 c5 76 00 00       	call   1020870 <myl_native_dictionary_new>
 10191ab:	48 85 c0             	test   %rax,%rax
 10191ae:	0f 84 5f 1a 00 00    	je     101ac13 <entry_run+0x2723>
 10191b4:	48 89 85 10 fd ff ff 	mov    %rax,-0x2f0(%rbp)
 10191bb:	48 c7 85 b0 fe ff ff 	movq   $0x100a7b0,-0x150(%rbp)
 10191c2:	b0 a7 00 01 
 10191c6:	48 8d 8d 10 fd ff ff 	lea    -0x2f0(%rbp),%rcx
 10191cd:	48 89 8d b8 fe ff ff 	mov    %rcx,-0x148(%rbp)
 10191d4:	48 8d 4d 90          	lea    -0x70(%rbp),%rcx
 10191d8:	48 89 8d c0 fe ff ff 	mov    %rcx,-0x140(%rbp)
 10191df:	c7 85 c8 fe ff ff 04 	movl   $0x4,-0x138(%rbp)
 10191e6:	00 00 00 
 10191e9:	c7 45 90 00 00 00 00 	movl   $0x0,-0x70(%rbp)
 10191f0:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
 10191f4:	48 c7 85 90 fe ff ff 	movq   $0x100a7b0,-0x170(%rbp)
 10191fb:	b0 a7 00 01 
 10191ff:	c7 85 a8 fe ff ff 02 	movl   $0x2,-0x158(%rbp)
 1019206:	00 00 00 
 1019209:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
 101920d:	48 c7 85 30 fe ff ff 	movq   $0x100a7b0,-0x1d0(%rbp)
 1019214:	b0 a7 00 01 
 1019218:	c7 85 48 fe ff ff 02 	movl   $0x2,-0x1b8(%rbp)
 101921f:	00 00 00 
 1019222:	c7 45 88 00 00 00 00 	movl   $0x0,-0x78(%rbp)
 1019229:	c7 85 70 ff ff ff 01 	movl   $0x1,-0x90(%rbp)
 1019230:	00 00 00 
 1019233:	48 89 45 d0          	mov    %rax,-0x30(%rbp)
 1019237:	48 b9 01 00 00 00 00 	movabs $0x5000000000000001,%rcx
 101923e:	00 00 50 
 1019241:	48 85 48 f0          	test   %rcx,-0x10(%rax)
 1019245:	0f 84 29 01 00 00    	je     1019374 <entry_run+0xe84>
 101924b:	48 8d 55 c8          	lea    -0x38(%rbp),%rdx
 101924f:	48 8d 4d d0          	lea    -0x30(%rbp),%rcx
 1019253:	be b0 a7 00 01       	mov    $0x100a7b0,%esi
 1019258:	4c 89 ef             	mov    %r13,%rdi
 101925b:	44 8b 45 b8          	mov    -0x48(%rbp),%r8d
 101925f:	e8 3c 4a 01 00       	call   102dca0 <myl_rc_native_take>
 1019264:	85 c0                	test   %eax,%eax
 1019266:	0f 85 10 01 00 00    	jne    101937c <entry_run+0xe8c>
 101926c:	48 8b 8b 60 18 00 00 	mov    0x1860(%rbx),%rcx
 1019273:	48 85 c9             	test   %rcx,%rcx
 1019276:	0f 84 1f 19 00 00    	je     101ab9b <entry_run+0x26ab>
 101927c:	8b 41 78             	mov    0x78(%rcx),%eax
 101927f:	c7 41 78 00 00 00 00 	movl   $0x0,0x78(%rcx)
 1019286:	48 85 c0             	test   %rax,%rax
 1019289:	74 2e                	je     10192b9 <entry_run+0xdc9>
 101928b:	83 f8 01             	cmp    $0x1,%eax
 101928e:	75 10                	jne    10192a0 <entry_run+0xdb0>
 1019290:	be 46 74 00 01       	mov    $0x1007446,%esi
 1019295:	83 bb c4 02 00 00 00 	cmpl   $0x0,0x2c4(%rbx)
 101929c:	75 13                	jne    10192b1 <entry_run+0xdc1>
 101929e:	eb 09                	jmp    10192a9 <entry_run+0xdb9>
 10192a0:	83 f8 04             	cmp    $0x4,%eax
 10192a3:	0f 83 fa 18 00 00    	jae    101aba3 <entry_run+0x26b3>
 10192a9:	48 8b 34 c5 48 c7 00 	mov    0x100c748(,%rax,8),%rsi
 10192b0:	01 
 10192b1:	48 89 df             	mov    %rbx,%rdi
 10192b4:	e8 67 23 00 00       	call   101b620 <fail>
 10192b9:	4c 8d a5 e8 fe ff ff 	lea    -0x118(%rbp),%r12
 10192c0:	4c 39 a3 80 3d 00 00 	cmp    %r12,0x3d80(%rbx)
 10192c7:	0f 85 ce 18 00 00    	jne    101ab9b <entry_run+0x26ab>
 10192cd:	48 8b b5 00 ff ff ff 	mov    -0x100(%rbp),%rsi
 10192d4:	4c 89 ef             	mov    %r13,%rdi
 10192d7:	e8 64 10 01 00       	call   102a340 <myl_rc_scope_unwind>
 10192dc:	4c 8b b5 f8 fe ff ff 	mov    -0x108(%rbp),%r14
 10192e3:	4d 85 f6             	test   %r14,%r14
 10192e6:	0f 84 60 18 00 00    	je     101ab4c <entry_run+0x265c>
 10192ec:	4d 89 f7             	mov    %r14,%r15
 10192ef:	49 c1 e7 05          	shl    $0x5,%r15
 10192f3:	49 83 c7 e0          	add    $0xffffffffffffffe0,%r15
 10192f7:	eb 1f                	jmp    1019318 <entry_run+0xe28>
 10192f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
 1019300:	4c 01 fe             	add    %r15,%rsi
 1019303:	48 89 df             	mov    %rbx,%rdi
 1019306:	e8 85 19 00 00       	call   101ac90 <myl_qbe_rc_slot_drop>
 101930b:	49 83 c7 e0          	add    $0xffffffffffffffe0,%r15
 101930f:	49 ff ce             	dec    %r14
 1019312:	0f 84 34 18 00 00    	je     101ab4c <entry_run+0x265c>
 1019318:	48 8b b5 f0 fe ff ff 	mov    -0x110(%rbp),%rsi
 101931f:	4a 8b 44 3e 10       	mov    0x10(%rsi,%r15,1),%rax
 1019324:	48 85 c0             	test   %rax,%rax
 1019327:	74 d7                	je     1019300 <entry_run+0xe10>
 1019329:	83 38 00             	cmpl   $0x0,(%rax)
 101932c:	75 d2                	jne    1019300 <entry_run+0xe10>
 101932e:	eb db                	jmp    101930b <entry_run+0xe1b>
 1019330:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
 1019334:	48 c7 45 d0 00 00 00 	movq   $0x0,-0x30(%rbp)
 101933b:	00 
 101933c:	c7 85 70 ff ff ff 00 	movl   $0x0,-0x90(%rbp)
 1019343:	00 00 00 
 1019346:	48 c7 85 90 fe ff ff 	movq   $0x1009fd0,-0x170(%rbp)
 101934d:	d0 9f 00 01 
 1019351:	c7 85 a8 fe ff ff 02 	movl   $0x2,-0x158(%rbp)
 1019358:	00 00 00 
 101935b:	c7 45 88 01 00 00 00 	movl   $0x1,-0x78(%rbp)
 1019362:	83 bd 38 ff ff ff 00 	cmpl   $0x0,-0xc8(%rbp)
 1019369:	0f 85 45 f9 ff ff    	jne    1018cb4 <entry_run+0x7c4>
 101936f:	e9 4f f9 ff ff       	jmp    1018cc3 <entry_run+0x7d3>
 1019374:	48 c7 45 d0 00 00 00 	movq   $0x0,-0x30(%rbp)
 101937b:	00 
 101937c:	c7 85 70 ff ff ff 00 	movl   $0x0,-0x90(%rbp)
 1019383:	00 00 00 
 1019386:	48 c7 85 90 fe ff ff 	movq   $0x100a7b0,-0x170(%rbp)
 101938d:	b0 a7 00 01 
 1019391:	c7 85 a8 fe ff ff 02 	movl   $0x2,-0x158(%rbp)
 1019398:	00 00 00 
 101939b:	c7 45 88 01 00 00 00 	movl   $0x1,-0x78(%rbp)
 10193a2:	83 bd 40 ff ff ff 00 	cmpl   $0x0,-0xc0(%rbp)
 10193a9:	74 0f                	je     10193ba <entry_run+0xeca>
 10193ab:	48 89 df             	mov    %rbx,%rdi
 10193ae:	48 8d b5 70 fd ff ff 	lea    -0x290(%rbp),%rsi
 10193b5:	e8 d6 18 00 00       	call   101ac90 <myl_qbe_rc_slot_drop>
 10193ba:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
 10193be:	48 89 45 a0          	mov    %rax,-0x60(%rbp)
 10193c2:	c7 45 88 00 00 00 00 	movl   $0x0,-0x78(%rbp)
 10193c9:	c7 85 40 ff ff ff 01 	movl   $0x1,-0xc0(%rbp)
 10193d0:	00 00 00 
 10193d3:	48 c7 45 d0 80 84 1e 	movq   $0x1e8480,-0x30(%rbp)
 10193da:	00 
 10193db:	48 c7 85 70 fd ff ff 	movq   $0x100a7b0,-0x290(%rbp)
 10193e2:	b0 a7 00 01 
 10193e6:	c7 85 88 fd ff ff 02 	movl   $0x2,-0x278(%rbp)
 10193ed:	00 00 00 
 10193f0:	48 8d 55 a0          	lea    -0x60(%rbp),%rdx
 10193f4:	48 89 95 78 fd ff ff 	mov    %rdx,-0x288(%rbp)
 10193fb:	48 8d 8d 40 ff ff ff 	lea    -0xc0(%rbp),%rcx
 1019402:	48 89 8d 80 fd ff ff 	mov    %rcx,-0x280(%rbp)
 1019409:	be b0 a7 00 01       	mov    $0x100a7b0,%esi
 101940e:	48 89 df             	mov    %rbx,%rdi
 1019411:	e8 3a 1e 00 00       	call   101b250 <myl_qbe_rc_unique_local>
 1019416:	85 c0                	test   %eax,%eax
 1019418:	0f 84 9b fe ff ff    	je     10192b9 <entry_run+0xdc9>
 101941e:	45 31 ff             	xor    %r15d,%r15d
 1019421:	eb 36                	jmp    1019459 <entry_run+0xf69>
 1019423:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 101942a:	84 00 00 00 00 00 
 1019430:	31 c0                	xor    %eax,%eax
 1019432:	49 81 ff 7f 84 1e 00 	cmp    $0x1e847f,%r15
 1019439:	4d 8d 7f 01          	lea    0x1(%r15),%r15
 101943d:	48 c7 45 c0 80 84 1e 	movq   $0x1e8480,-0x40(%rbp)
 1019444:	00 
 1019445:	0f 92 c0             	setb   %al
 1019448:	48 89 45 d0          	mov    %rax,-0x30(%rbp)
 101944c:	49 81 ff 80 84 1e 00 	cmp    $0x1e8480,%r15
 1019453:	0f 84 55 0d 00 00    	je     101a1ae <entry_run+0x1cbe>
 1019459:	48 8b 45 98          	mov    -0x68(%rbp),%rax
 101945d:	48 89 85 20 fd ff ff 	mov    %rax,-0x2e0(%rbp)
 1019464:	49 69 f7 ef 1e 00 00 	imul   $0x1eef,%r15,%rsi
 101946b:	48 89 f2             	mov    %rsi,%rdx
 101946e:	48 c1 ea 03          	shr    $0x3,%rdx
 1019472:	48 b9 cf f7 53 e3 a5 	movabs $0x20c49ba5e353f7cf,%rcx
 1019479:	9b c4 20 
 101947c:	c4 e2 f3 f6 c9       	mulx   %rcx,%rcx,%rcx
 1019481:	48 c1 e9 04          	shr    $0x4,%rcx
 1019485:	48 69 c9 e8 03 00 00 	imul   $0x3e8,%rcx,%rcx
 101948c:	48 29 ce             	sub    %rcx,%rsi
 101948f:	48 c7 45 c0 00 00 00 	movq   $0x0,-0x40(%rbp)
 1019496:	00 
 1019497:	48 89 75 d0          	mov    %rsi,-0x30(%rbp)
 101949b:	48 8b 10             	mov    (%rax),%rdx
 101949e:	48 39 d6             	cmp    %rdx,%rsi
 10194a1:	0f 83 19 17 00 00    	jae    101abc0 <entry_run+0x26d0>
 10194a7:	48 8b 40 20          	mov    0x20(%rax),%rax
 10194ab:	48 8b 04 f0          	mov    (%rax,%rsi,8),%rax
 10194af:	48 89 45 d0          	mov    %rax,-0x30(%rbp)
 10194b3:	48 89 85 08 ff ff ff 	mov    %rax,-0xf8(%rbp)
 10194ba:	83 bd 48 ff ff ff 00 	cmpl   $0x0,-0xb8(%rbp)
 10194c1:	74 16                	je     10194d9 <entry_run+0xfe9>
 10194c3:	48 89 df             	mov    %rbx,%rdi
 10194c6:	48 8d b5 90 fd ff ff 	lea    -0x270(%rbp),%rsi
 10194cd:	e8 be 17 00 00       	call   101ac90 <myl_qbe_rc_slot_drop>
 10194d2:	48 8b 85 08 ff ff ff 	mov    -0xf8(%rbp),%rax
 10194d9:	48 89 45 d0          	mov    %rax,-0x30(%rbp)
 10194dd:	48 c7 45 c0 00 00 00 	movq   $0x0,-0x40(%rbp)
 10194e4:	00 
 10194e5:	48 8b 7d a0          	mov    -0x60(%rbp),%rdi
 10194e9:	48 8d 75 d0          	lea    -0x30(%rbp),%rsi
 10194ed:	4c 8d b5 d0 fe ff ff 	lea    -0x130(%rbp),%r14
 10194f4:	4c 89 f2             	mov    %r14,%rdx
 10194f7:	e8 c4 98 00 00       	call   1022dc0 <myl_native_dictionary_read>
 10194fc:	85 c0                	test   %eax,%eax
 10194fe:	48 8d 4d c0          	lea    -0x40(%rbp),%rcx
 1019502:	4c 0f 44 f1          	cmove  %rcx,%r14
 1019506:	4d 8b 26             	mov    (%r14),%r12
 1019509:	4c 89 65 d0          	mov    %r12,-0x30(%rbp)
 101950d:	83 bd 70 ff ff ff 00 	cmpl   $0x0,-0x90(%rbp)
 1019514:	74 13                	je     1019529 <entry_run+0x1039>
 1019516:	48 89 df             	mov    %rbx,%rdi
 1019519:	48 8d b5 30 fe ff ff 	lea    -0x1d0(%rbp),%rsi
 1019520:	e8 6b 17 00 00       	call   101ac90 <myl_qbe_rc_slot_drop>
 1019525:	4c 8b 65 d0          	mov    -0x30(%rbp),%r12
 1019529:	48 c7 45 c0 01 00 00 	movq   $0x1,-0x40(%rbp)
 1019530:	00 
 1019531:	48 b8 ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rax
 1019538:	ff ff 7f 
 101953b:	49 39 c4             	cmp    %rax,%r12
 101953e:	0f 84 84 16 00 00    	je     101abc8 <entry_run+0x26d8>
 1019544:	48 8b 45 a0          	mov    -0x60(%rbp),%rax
 1019548:	48 89 45 d0          	mov    %rax,-0x30(%rbp)
 101954c:	83 bd 70 ff ff ff 00 	cmpl   $0x0,-0x90(%rbp)
 1019553:	74 0f                	je     1019564 <entry_run+0x1074>
 1019555:	48 89 df             	mov    %rbx,%rdi
 1019558:	48 8d b5 30 fe ff ff 	lea    -0x1d0(%rbp),%rsi
 101955f:	e8 2c 17 00 00       	call   101ac90 <myl_qbe_rc_slot_drop>
 1019564:	83 bd 58 ff ff ff 00 	cmpl   $0x0,-0xa8(%rbp)
 101956b:	74 0f                	je     101957c <entry_run+0x108c>
 101956d:	48 89 df             	mov    %rbx,%rdi
 1019570:	48 8d b5 d0 fd ff ff 	lea    -0x230(%rbp),%rsi
 1019577:	e8 14 17 00 00       	call   101ac90 <myl_qbe_rc_slot_drop>
 101957c:	49 ff c4             	inc    %r12
 101957f:	4c 8b 6d a0          	mov    -0x60(%rbp),%r13
 1019583:	4c 89 ad 28 fd ff ff 	mov    %r13,-0x2d8(%rbp)
 101958a:	4c 8b 8d 08 ff ff ff 	mov    -0xf8(%rbp),%r9
 1019591:	4c 89 4d d0          	mov    %r9,-0x30(%rbp)
 1019595:	4c 89 65 c0          	mov    %r12,-0x40(%rbp)
 1019599:	48 83 bb 60 18 00 00 	cmpq   $0x0,0x1860(%rbx)
 10195a0:	00 
 10195a1:	45 8b b5 f8 00 00 00 	mov    0xf8(%r13),%r14d
 10195a8:	74 66                	je     1019610 <entry_run+0x1120>
 10195aa:	4c 89 7d b8          	mov    %r15,-0x48(%rbp)
 10195ae:	45 8b 65 24          	mov    0x24(%r13),%r12d
 10195b2:	41 83 fe 01          	cmp    $0x1,%r14d
 10195b6:	0f 85 84 02 00 00    	jne    1019840 <entry_run+0x1350>
 10195bc:	4c 89 c9             	mov    %r9,%rcx
 10195bf:	41 83 fc 02          	cmp    $0x2,%r12d
 10195c3:	0f 82 d7 00 00 00    	jb     10196a0 <entry_run+0x11b0>
 10195c9:	0f 85 c1 02 00 00    	jne    1019890 <entry_run+0x13a0>
 10195cf:	49 8b 45 08          	mov    0x8(%r13),%rax
 10195d3:	48 8b 10             	mov    (%rax),%rdx
 10195d6:	48 c7 85 40 fc ff ff 	movq   $0x0,-0x3c0(%rbp)
 10195dd:	00 00 00 00 
 10195e1:	f3 48 0f b8 c2       	popcnt %rdx,%rax
 10195e6:	83 f8 01             	cmp    $0x1,%eax
 10195e9:	0f 85 87 00 00 00    	jne    1019676 <entry_run+0x1186>
 10195ef:	f3 48 0f bc c2       	tzcnt  %rdx,%rax
 10195f4:	48 83 f8 03          	cmp    $0x3,%rax
 10195f8:	77 7c                	ja     1019676 <entry_run+0x1186>
 10195fa:	4c 89 c9             	mov    %r9,%rcx
 10195fd:	ff 24 c5 38 96 00 01 	jmp    *0x1009638(,%rax,8)
 1019604:	41 0f b6 c9          	movzbl %r9b,%ecx
 1019608:	e9 93 00 00 00       	jmp    10196a0 <entry_run+0x11b0>
 101960d:	0f 1f 00             	nopl   (%rax)
 1019610:	41 83 fe 01          	cmp    $0x1,%r14d
 1019614:	0f 85 66 01 00 00    	jne    1019780 <entry_run+0x1290>
 101961a:	4d 89 fe             	mov    %r15,%r14
 101961d:	45 8b 7d 24          	mov    0x24(%r13),%r15d
 1019621:	4c 89 cf             	mov    %r9,%rdi
 1019624:	41 83 ff 02          	cmp    $0x2,%r15d
 1019628:	0f 82 ed 00 00 00    	jb     101971b <entry_run+0x122b>
 101962e:	0f 85 49 01 00 00    	jne    101977d <entry_run+0x128d>
 1019634:	49 8b 45 08          	mov    0x8(%r13),%rax
 1019638:	48 8b 10             	mov    (%rax),%rdx
 101963b:	48 c7 85 40 fc ff ff 	movq   $0x0,-0x3c0(%rbp)
 1019642:	00 00 00 00 
 1019646:	f3 48 0f b8 c2       	popcnt %rdx,%rax
 101964b:	83 f8 01             	cmp    $0x1,%eax
 101964e:	0f 85 95 00 00 00    	jne    10196e9 <entry_run+0x11f9>
 1019654:	f3 48 0f bc c2       	tzcnt  %rdx,%rax
 1019659:	48 83 f8 03          	cmp    $0x3,%rax
 101965d:	0f 87 86 00 00 00    	ja     10196e9 <entry_run+0x11f9>
 1019663:	4c 89 cf             	mov    %r9,%rdi
 1019666:	ff 24 c5 98 96 00 01 	jmp    *0x1009698(,%rax,8)
 101966d:	41 0f b6 f9          	movzbl %r9b,%edi
 1019671:	e9 a5 00 00 00       	jmp    101971b <entry_run+0x122b>
 1019676:	48 83 fa 08          	cmp    $0x8,%rdx
 101967a:	b8 08 00 00 00       	mov    $0x8,%eax
 101967f:	48 0f 43 d0          	cmovae %rax,%rdx
 1019683:	48 8d bd 40 fc ff ff 	lea    -0x3c0(%rbp),%rdi
 101968a:	48 8d 75 d0          	lea    -0x30(%rbp),%rsi
 101968e:	4d 89 cf             	mov    %r9,%r15
 1019691:	e8 aa 8a 01 00       	call   1032140 <memcpy@plt>
 1019696:	4d 89 f9             	mov    %r15,%r9
 1019699:	48 8b 8d 40 fc ff ff 	mov    -0x3c0(%rbp),%rcx
 10196a0:	49 3b 8d e0 00 00 00 	cmp    0xe0(%r13),%rcx
 10196a7:	0f 85 93 01 00 00    	jne    1019840 <entry_run+0x1350>
 10196ad:	49 8b 45 00          	mov    0x0(%r13),%rax
 10196b1:	4d 8b bd e8 00 00 00 	mov    0xe8(%r13),%r15
 10196b8:	4c 3b 38             	cmp    (%rax),%r15
 10196bb:	0f 83 7f 01 00 00    	jae    1019840 <entry_run+0x1350>
 10196c1:	49 8b 75 30          	mov    0x30(%r13),%rsi
 10196c5:	49 0f af f7          	imul   %r15,%rsi
 10196c9:	48 03 70 20          	add    0x20(%rax),%rsi
 10196cd:	41 83 fc 02          	cmp    $0x2,%r12d
 10196d1:	0f 84 c5 00 00 00    	je     101979c <entry_run+0x12ac>
 10196d7:	41 83 fc 01          	cmp    $0x1,%r12d
 10196db:	0f 85 ee 00 00 00    	jne    10197cf <entry_run+0x12df>
 10196e1:	48 8b 06             	mov    (%rsi),%rax
 10196e4:	e9 42 01 00 00       	jmp    101982b <entry_run+0x133b>
 10196e9:	48 83 fa 08          	cmp    $0x8,%rdx
 10196ed:	b8 08 00 00 00       	mov    $0x8,%eax
 10196f2:	48 0f 43 d0          	cmovae %rax,%rdx
 10196f6:	48 8d bd 40 fc ff ff 	lea    -0x3c0(%rbp),%rdi
 10196fd:	48 8d 75 d0          	lea    -0x30(%rbp),%rsi
 1019701:	4c 89 8d 28 ff ff ff 	mov    %r9,-0xd8(%rbp)
 1019708:	e8 33 8a 01 00       	call   1032140 <memcpy@plt>
 101970d:	4c 8b 8d 28 ff ff ff 	mov    -0xd8(%rbp),%r9
 1019714:	48 8b bd 40 fc ff ff 	mov    -0x3c0(%rbp),%rdi
 101971b:	49 3b bd e0 00 00 00 	cmp    0xe0(%r13),%rdi
 1019722:	75 59                	jne    101977d <entry_run+0x128d>
 1019724:	49 8b 45 00          	mov    0x0(%r13),%rax
 1019728:	4d 8b 95 e8 00 00 00 	mov    0xe8(%r13),%r10
 101972f:	4c 3b 10             	cmp    (%rax),%r10
 1019732:	73 49                	jae    101977d <entry_run+0x128d>
 1019734:	4d 0f af 55 30       	imul   0x30(%r13),%r10
 1019739:	4c 03 50 20          	add    0x20(%rax),%r10
 101973d:	41 83 ff 02          	cmp    $0x2,%r15d
 1019741:	0f 84 3b 07 00 00    	je     1019e82 <entry_run+0x1992>
 1019747:	41 83 ff 01          	cmp    $0x1,%r15d
 101974b:	0f 84 29 07 00 00    	je     1019e7a <entry_run+0x198a>
 1019751:	45 85 ff             	test   %r15d,%r15d
 1019754:	0f 85 66 07 00 00    	jne    1019ec0 <entry_run+0x19d0>
 101975a:	49 8b 02             	mov    (%r10),%rax
 101975d:	4c 39 c8             	cmp    %r9,%rax
 1019760:	4d 89 f7             	mov    %r14,%r15
 1019763:	0f 84 f0 09 00 00    	je     101a159 <entry_run+0x1c69>
 1019769:	41 f6 41 10 04       	testb  $0x4,0x10(%r9)
 101976e:	0f 85 3d 08 00 00    	jne    1019fb1 <entry_run+0x1ac1>
 1019774:	49 8d 49 18          	lea    0x18(%r9),%rcx
 1019778:	e9 43 08 00 00       	jmp    1019fc0 <entry_run+0x1ad0>
 101977d:	4d 89 f7             	mov    %r14,%r15
 1019780:	48 8d bb 58 02 00 00 	lea    0x258(%rbx),%rdi
 1019787:	4c 89 ee             	mov    %r13,%rsi
 101978a:	48 8d 55 d0          	lea    -0x30(%rbp),%rdx
 101978e:	48 8d 4d c0          	lea    -0x40(%rbp),%rcx
 1019792:	e8 09 b4 00 00       	call   1024ba0 <write_walk>
 1019797:	e9 4f 06 00 00       	jmp    1019deb <entry_run+0x18fb>
 101979c:	49 8b 45 08          	mov    0x8(%r13),%rax
 10197a0:	48 8b 10             	mov    (%rax),%rdx
 10197a3:	48 c7 85 40 fc ff ff 	movq   $0x0,-0x3c0(%rbp)
 10197aa:	00 00 00 00 
 10197ae:	f3 48 0f b8 c2       	popcnt %rdx,%rax
 10197b3:	83 f8 01             	cmp    $0x1,%eax
 10197b6:	75 37                	jne    10197ef <entry_run+0x12ff>
 10197b8:	f3 48 0f bc c2       	tzcnt  %rdx,%rax
 10197bd:	48 83 f8 03          	cmp    $0x3,%rax
 10197c1:	77 2c                	ja     10197ef <entry_run+0x12ff>
 10197c3:	ff 24 c5 58 96 00 01 	jmp    *0x1009658(,%rax,8)
 10197ca:	0f b6 06             	movzbl (%rsi),%eax
 10197cd:	eb 5c                	jmp    101982b <entry_run+0x133b>
 10197cf:	48 8b 06             	mov    (%rsi),%rax
 10197d2:	4c 39 c8             	cmp    %r9,%rax
 10197d5:	0f 84 fe 01 00 00    	je     10199d9 <entry_run+0x14e9>
 10197db:	41 f6 41 10 04       	testb  $0x4,0x10(%r9)
 10197e0:	0f 85 f7 06 00 00    	jne    1019edd <entry_run+0x19ed>
 10197e6:	49 8d 49 18          	lea    0x18(%r9),%rcx
 10197ea:	e9 fd 06 00 00       	jmp    1019eec <entry_run+0x19fc>
 10197ef:	48 83 fa 08          	cmp    $0x8,%rdx
 10197f3:	b8 08 00 00 00       	mov    $0x8,%eax
 10197f8:	48 0f 43 d0          	cmovae %rax,%rdx
 10197fc:	48 8d bd 40 fc ff ff 	lea    -0x3c0(%rbp),%rdi
 1019803:	4c 89 8d 28 ff ff ff 	mov    %r9,-0xd8(%rbp)
 101980a:	48 89 8d d0 fc ff ff 	mov    %rcx,-0x330(%rbp)
 1019811:	e8 2a 89 01 00       	call   1032140 <memcpy@plt>
 1019816:	48 8b 8d d0 fc ff ff 	mov    -0x330(%rbp),%rcx
 101981d:	4c 8b 8d 28 ff ff ff 	mov    -0xd8(%rbp),%r9
 1019824:	48 8b 85 40 fc ff ff 	mov    -0x3c0(%rbp),%rax
 101982b:	48 39 c8             	cmp    %rcx,%rax
 101982e:	0f 84 a5 01 00 00    	je     10199d9 <entry_run+0x14e9>
 1019834:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
 101983b:	00 00 00 00 00 
 1019840:	4c 89 ce             	mov    %r9,%rsi
 1019843:	41 83 fc 02          	cmp    $0x2,%r12d
 1019847:	0f 82 9c 00 00 00    	jb     10198e9 <entry_run+0x13f9>
 101984d:	75 41                	jne    1019890 <entry_run+0x13a0>
 101984f:	49 8b 45 08          	mov    0x8(%r13),%rax
 1019853:	48 8b 10             	mov    (%rax),%rdx
 1019856:	48 c7 85 40 fc ff ff 	movq   $0x0,-0x3c0(%rbp)
 101985d:	00 00 00 00 
 1019861:	f3 48 0f b8 c2       	popcnt %rdx,%rax
 1019866:	83 f8 01             	cmp    $0x1,%eax
 1019869:	75 4e                	jne    10198b9 <entry_run+0x13c9>
 101986b:	f3 48 0f bc c2       	tzcnt  %rdx,%rax
 1019870:	48 83 f8 03          	cmp    $0x3,%rax
 1019874:	77 43                	ja     10198b9 <entry_run+0x13c9>
 1019876:	4c 89 ce             	mov    %r9,%rsi
 1019879:	ff 24 c5 78 96 00 01 	jmp    *0x1009678(,%rax,8)
 1019880:	41 0f b6 f1          	movzbl %r9b,%esi
 1019884:	eb 5d                	jmp    10198e3 <entry_run+0x13f3>
 1019886:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
 101988d:	00 00 00 
 1019890:	4c 89 ef             	mov    %r13,%rdi
 1019893:	48 8d 75 d0          	lea    -0x30(%rbp),%rsi
 1019897:	e8 84 9a 00 00       	call   1023320 <probe_any>
 101989c:	49 89 c7             	mov    %rax,%r15
 101989f:	41 c7 85 f8 00 00 00 	movl   $0x0,0xf8(%r13)
 10198a6:	00 00 00 00 
 10198aa:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
 10198ae:	0f 85 25 01 00 00    	jne    10199d9 <entry_run+0x14e9>
 10198b4:	e9 17 05 00 00       	jmp    1019dd0 <entry_run+0x18e0>
 10198b9:	48 83 fa 08          	cmp    $0x8,%rdx
 10198bd:	b8 08 00 00 00       	mov    $0x8,%eax
 10198c2:	48 0f 43 d0          	cmovae %rax,%rdx
 10198c6:	48 8d bd 40 fc ff ff 	lea    -0x3c0(%rbp),%rdi
 10198cd:	48 8d 75 d0          	lea    -0x30(%rbp),%rsi
 10198d1:	4d 89 cf             	mov    %r9,%r15
 10198d4:	e8 67 88 01 00       	call   1032140 <memcpy@plt>
 10198d9:	4d 89 f9             	mov    %r15,%r9
 10198dc:	48 8b b5 40 fc ff ff 	mov    -0x3c0(%rbp),%rsi
 10198e3:	41 bc 02 00 00 00    	mov    $0x2,%r12d
 10198e9:	41 83 fe 02          	cmp    $0x2,%r14d
 10198ed:	75 0d                	jne    10198fc <entry_run+0x140c>
 10198ef:	49 3b b5 e0 00 00 00 	cmp    0xe0(%r13),%rsi
 10198f6:	0f 84 d4 04 00 00    	je     1019dd0 <entry_run+0x18e0>
 10198fc:	49 8b 8d d8 00 00 00 	mov    0xd8(%r13),%rcx
 1019903:	48 85 c9             	test   %rcx,%rcx
 1019906:	74 7f                	je     1019987 <entry_run+0x1497>
 1019908:	41 83 fc 01          	cmp    $0x1,%r12d
 101990c:	0f 84 08 04 00 00    	je     1019d1a <entry_run+0x182a>
 1019912:	45 85 e4             	test   %r12d,%r12d
 1019915:	0f 85 8c 04 00 00    	jne    1019da7 <entry_run+0x18b7>
 101991b:	49 89 f6             	mov    %rsi,%r14
 101991e:	4c 89 ef             	mov    %r13,%rdi
 1019921:	4c 89 ce             	mov    %r9,%rsi
 1019924:	e8 17 9b 00 00       	call   1023440 <probe_text>
 1019929:	49 89 c7             	mov    %rax,%r15
 101992c:	49 83 ff ff          	cmp    $0xffffffffffffffff,%r15
 1019930:	75 6d                	jne    101999f <entry_run+0x14af>
 1019932:	41 83 7d 24 00       	cmpl   $0x0,0x24(%r13)
 1019937:	0f 84 87 04 00 00    	je     1019dc4 <entry_run+0x18d4>
 101993d:	89 d0                	mov    %edx,%eax
 101993f:	83 f8 ff             	cmp    $0xffffffff,%eax
 1019942:	0f 84 7c 04 00 00    	je     1019dc4 <entry_run+0x18d4>
 1019948:	4d 89 b5 e0 00 00 00 	mov    %r14,0xe0(%r13)
 101994f:	49 c7 85 e8 00 00 00 	movq   $0x0,0xe8(%r13)
 1019956:	00 00 00 00 
 101995a:	49 89 95 f0 00 00 00 	mov    %rdx,0xf0(%r13)
 1019961:	41 c7 85 f8 00 00 00 	movl   $0x2,0xf8(%r13)
 1019968:	02 00 00 00 
 101996c:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
 1019970:	c4 c1 78 11 85 fc 00 	vmovups %xmm0,0xfc(%r13)
 1019977:	00 00 
 1019979:	c4 c1 78 11 85 08 01 	vmovups %xmm0,0x108(%r13)
 1019980:	00 00 
 1019982:	e9 49 04 00 00       	jmp    1019dd0 <entry_run+0x18e0>
 1019987:	49 89 f6             	mov    %rsi,%r14
 101998a:	4c 89 ef             	mov    %r13,%rdi
 101998d:	48 8d 75 d0          	lea    -0x30(%rbp),%rsi
 1019991:	e8 8a 99 00 00       	call   1023320 <probe_any>
 1019996:	49 89 c7             	mov    %rax,%r15
 1019999:	49 83 ff ff          	cmp    $0xffffffffffffffff,%r15
 101999d:	74 93                	je     1019932 <entry_run+0x1442>
 101999f:	4d 89 b5 e0 00 00 00 	mov    %r14,0xe0(%r13)
 10199a6:	4d 89 bd e8 00 00 00 	mov    %r15,0xe8(%r13)
 10199ad:	49 c7 85 f0 00 00 00 	movq   $0x0,0xf0(%r13)
 10199b4:	00 00 00 00 
 10199b8:	41 c7 85 f8 00 00 00 	movl   $0x1,0xf8(%r13)
 10199bf:	01 00 00 00 
 10199c3:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
 10199c7:	c4 c1 78 11 85 fc 00 	vmovups %xmm0,0xfc(%r13)
 10199ce:	00 00 
 10199d0:	c4 c1 78 11 85 08 01 	vmovups %xmm0,0x108(%r13)
 10199d7:	00 00 
 10199d9:	49 8b 45 f0          	mov    -0x10(%r13),%rax
 10199dd:	49 8b 4d 00          	mov    0x0(%r13),%rcx
 10199e1:	4d 0f af 7d 30       	imul   0x30(%r13),%r15
 10199e6:	4c 03 79 20          	add    0x20(%rcx),%r15
 10199ea:	4d 03 7d 18          	add    0x18(%r13),%r15
 10199ee:	48 b9 02 00 00 00 00 	movabs $0x4000000000000002,%rcx
 10199f5:	00 00 40 
 10199f8:	48 83 c1 fe          	add    $0xfffffffffffffffe,%rcx
 10199fc:	49 89 c4             	mov    %rax,%r12
 10199ff:	49 c1 ec 28          	shr    $0x28,%r12
 1019a03:	41 81 e4 ff ff 0f 00 	and    $0xfffff,%r12d
 1019a0a:	48 85 c8             	test   %rcx,%rax
 1019a0d:	b8 00 00 00 00       	mov    $0x0,%eax
 1019a12:	44 0f 44 e0          	cmove  %eax,%r12d
 1019a16:	48 8d 45 c0          	lea    -0x40(%rbp),%rax
 1019a1a:	49 39 c7             	cmp    %rax,%r15
 1019a1d:	74 17                	je     1019a36 <entry_run+0x1546>
 1019a1f:	4d 8b 75 10          	mov    0x10(%r13),%r14
 1019a23:	41 83 7e 30 00       	cmpl   $0x0,0x30(%r14)
 1019a28:	74 1c                	je     1019a46 <entry_run+0x1556>
 1019a2a:	48 8b 83 60 18 00 00 	mov    0x1860(%rbx),%rax
 1019a31:	e9 cc 00 00 00       	jmp    1019b02 <entry_run+0x1612>
 1019a36:	4c 8d ab 58 02 00 00 	lea    0x258(%rbx),%r13
 1019a3d:	4c 8b 7d b8          	mov    -0x48(%rbp),%r15
 1019a41:	e9 b4 03 00 00       	jmp    1019dfa <entry_run+0x190a>
 1019a46:	49 83 3e 08          	cmpq   $0x8,(%r14)
 1019a4a:	48 8b 83 60 18 00 00 	mov    0x1860(%rbx),%rax
 1019a51:	0f 85 ab 00 00 00    	jne    1019b02 <entry_run+0x1612>
 1019a57:	48 85 c0             	test   %rax,%rax
 1019a5a:	4c 8d ab 58 02 00 00 	lea    0x258(%rbx),%r13
 1019a61:	0f 84 49 01 00 00    	je     1019bb0 <entry_run+0x16c0>
 1019a67:	48 8b 48 40          	mov    0x40(%rax),%rcx
 1019a6b:	48 85 c9             	test   %rcx,%rcx
 1019a6e:	0f 84 95 00 00 00    	je     1019b09 <entry_run+0x1619>
 1019a74:	48 8b 50 30          	mov    0x30(%rax),%rdx
 1019a78:	4c 89 f6             	mov    %r14,%rsi
 1019a7b:	48 c1 ee 03          	shr    $0x3,%rsi
 1019a7f:	4c 89 f7             	mov    %r14,%rdi
 1019a82:	48 c1 ef 21          	shr    $0x21,%rdi
 1019a86:	48 31 f7             	xor    %rsi,%rdi
 1019a89:	48 be b9 e5 e4 1c 6d 	movabs $0xbf58476d1ce4e5b9,%rsi
 1019a90:	47 58 bf 
 1019a93:	48 0f af fe          	imul   %rsi,%rdi
 1019a97:	48 89 fe             	mov    %rdi,%rsi
 1019a9a:	48 c1 ee 1b          	shr    $0x1b,%rsi
 1019a9e:	48 31 fe             	xor    %rdi,%rsi
 1019aa1:	48 83 f6 02          	xor    $0x2,%rsi
 1019aa5:	48 ff c9             	dec    %rcx
 1019aa8:	eb 09                	jmp    1019ab3 <entry_run+0x15c3>
 1019aaa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
 1019ab0:	48 ff c6             	inc    %rsi
 1019ab3:	48 21 ce             	and    %rcx,%rsi
 1019ab6:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
 1019aba:	48 8b 3c fa          	mov    (%rdx,%rdi,8),%rdi
 1019abe:	48 85 ff             	test   %rdi,%rdi
 1019ac1:	74 46                	je     1019b09 <entry_run+0x1619>
 1019ac3:	4c 39 f7             	cmp    %r14,%rdi
 1019ac6:	75 e8                	jne    1019ab0 <entry_run+0x15c0>
 1019ac8:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
 1019acc:	83 7c fa 20 02       	cmpl   $0x2,0x20(%rdx,%rdi,8)
 1019ad1:	75 dd                	jne    1019ab0 <entry_run+0x15c0>
 1019ad3:	48 8d 0c fa          	lea    (%rdx,%rdi,8),%rcx
 1019ad7:	48 8b 49 08          	mov    0x8(%rcx),%rcx
 1019adb:	48 85 c9             	test   %rcx,%rcx
 1019ade:	74 29                	je     1019b09 <entry_run+0x1619>
 1019ae0:	83 79 78 00          	cmpl   $0x0,0x78(%rcx)
 1019ae4:	75 23                	jne    1019b09 <entry_run+0x1619>
 1019ae6:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
 1019aeb:	75 1c                	jne    1019b09 <entry_run+0x1619>
 1019aed:	44 3b a3 c8 02 00 00 	cmp    0x2c8(%rbx),%r12d
 1019af4:	77 13                	ja     1019b09 <entry_run+0x1619>
 1019af6:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
 1019afa:	49 89 07             	mov    %rax,(%r15)
 1019afd:	e9 3b ff ff ff       	jmp    1019a3d <entry_run+0x154d>
 1019b02:	4c 8d ab 58 02 00 00 	lea    0x258(%rbx),%r13
 1019b09:	48 85 c0             	test   %rax,%rax
 1019b0c:	0f 94 c1             	sete   %cl
 1019b0f:	4d 85 f6             	test   %r14,%r14
 1019b12:	0f 94 c2             	sete   %dl
 1019b15:	08 ca                	or     %cl,%dl
 1019b17:	0f 85 93 00 00 00    	jne    1019bb0 <entry_run+0x16c0>
 1019b1d:	48 8b 48 40          	mov    0x40(%rax),%rcx
 1019b21:	48 85 c9             	test   %rcx,%rcx
 1019b24:	0f 84 86 00 00 00    	je     1019bb0 <entry_run+0x16c0>
 1019b2a:	48 8b 50 30          	mov    0x30(%rax),%rdx
 1019b2e:	4c 89 f6             	mov    %r14,%rsi
 1019b31:	48 c1 ee 03          	shr    $0x3,%rsi
 1019b35:	4c 89 f7             	mov    %r14,%rdi
 1019b38:	48 c1 ef 21          	shr    $0x21,%rdi
 1019b3c:	48 31 f7             	xor    %rsi,%rdi
 1019b3f:	48 be b9 e5 e4 1c 6d 	movabs $0xbf58476d1ce4e5b9,%rsi
 1019b46:	47 58 bf 
 1019b49:	48 0f af fe          	imul   %rsi,%rdi
 1019b4d:	48 89 fe             	mov    %rdi,%rsi
 1019b50:	48 c1 ee 1b          	shr    $0x1b,%rsi
 1019b54:	48 31 fe             	xor    %rdi,%rsi
 1019b57:	48 83 f6 02          	xor    $0x2,%rsi
 1019b5b:	48 ff c9             	dec    %rcx
 1019b5e:	eb 03                	jmp    1019b63 <entry_run+0x1673>
 1019b60:	48 ff c6             	inc    %rsi
 1019b63:	48 21 ce             	and    %rcx,%rsi
 1019b66:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
 1019b6a:	48 8b 3c fa          	mov    (%rdx,%rdi,8),%rdi
 1019b6e:	48 85 ff             	test   %rdi,%rdi
 1019b71:	74 3d                	je     1019bb0 <entry_run+0x16c0>
 1019b73:	4c 39 f7             	cmp    %r14,%rdi
 1019b76:	75 e8                	jne    1019b60 <entry_run+0x1670>
 1019b78:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
 1019b7c:	83 7c fa 20 02       	cmpl   $0x2,0x20(%rdx,%rdi,8)
 1019b81:	75 dd                	jne    1019b60 <entry_run+0x1670>
 1019b83:	48 8d 0c fa          	lea    (%rdx,%rdi,8),%rcx
 1019b87:	48 8b 49 08          	mov    0x8(%rcx),%rcx
 1019b8b:	48 85 c9             	test   %rcx,%rcx
 1019b8e:	74 20                	je     1019bb0 <entry_run+0x16c0>
 1019b90:	83 79 78 00          	cmpl   $0x0,0x78(%rcx)
 1019b94:	75 1a                	jne    1019bb0 <entry_run+0x16c0>
 1019b96:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
 1019b9b:	0f 84 09 05 00 00    	je     101a0aa <entry_run+0x1bba>
 1019ba1:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1019ba8:	0f 1f 84 00 00 00 00 
 1019baf:	00 
 1019bb0:	49 8b 06             	mov    (%r14),%rax
 1019bb3:	4c 8d ad 40 fc ff ff 	lea    -0x3c0(%rbp),%r13
 1019bba:	48 3d 81 00 00 00    	cmp    $0x81,%rax
 1019bc0:	72 6f                	jb     1019c31 <entry_run+0x1741>
 1019bc2:	48 c7 85 d8 fc ff ff 	movq   $0x0,-0x328(%rbp)
 1019bc9:	00 00 00 00 
 1019bcd:	48 c7 85 f0 fc ff ff 	movq   $0x100c898,-0x310(%rbp)
 1019bd4:	98 c8 00 01 
 1019bd8:	48 89 85 f8 fc ff ff 	mov    %rax,-0x308(%rbp)
 1019bdf:	48 c7 85 00 fd ff ff 	movq   $0x0,-0x300(%rbp)
 1019be6:	00 00 00 00 
 1019bea:	48 8d bb 58 02 00 00 	lea    0x258(%rbx),%rdi
 1019bf1:	48 8d b5 f0 fc ff ff 	lea    -0x310(%rbp),%rsi
 1019bf8:	48 8d 95 d8 fc ff ff 	lea    -0x328(%rbp),%rdx
 1019bff:	e8 1c c3 00 00       	call   1025f20 <myl_rc_new>
 1019c04:	85 c0                	test   %eax,%eax
 1019c06:	74 19                	je     1019c21 <entry_run+0x1731>
 1019c08:	48 8b 8b 60 18 00 00 	mov    0x1860(%rbx),%rcx
 1019c0f:	48 85 c9             	test   %rcx,%rcx
 1019c12:	0f 84 83 0f 00 00    	je     101ab9b <entry_run+0x26ab>
 1019c18:	83 79 78 00          	cmpl   $0x0,0x78(%rcx)
 1019c1c:	75 03                	jne    1019c21 <entry_run+0x1731>
 1019c1e:	89 41 78             	mov    %eax,0x78(%rcx)
 1019c21:	4c 8b ad d8 fc ff ff 	mov    -0x328(%rbp),%r13
 1019c28:	4d 85 ed             	test   %r13,%r13
 1019c2b:	0f 84 f2 01 00 00    	je     1019e23 <entry_run+0x1933>
 1019c31:	48 8d bb 58 02 00 00 	lea    0x258(%rbx),%rdi
 1019c38:	4c 89 f6             	mov    %r14,%rsi
 1019c3b:	4c 89 ea             	mov    %r13,%rdx
 1019c3e:	48 8d 4d c0          	lea    -0x40(%rbp),%rcx
 1019c42:	45 89 e0             	mov    %r12d,%r8d
 1019c45:	e8 46 4d 01 00       	call   102e990 <myl_rc_native_retain>
 1019c4a:	85 c0                	test   %eax,%eax
 1019c4c:	74 43                	je     1019c91 <entry_run+0x17a1>
 1019c4e:	41 89 c4             	mov    %eax,%r12d
 1019c51:	49 83 3e 00          	cmpq   $0x0,(%r14)
 1019c55:	74 25                	je     1019c7c <entry_run+0x178c>
 1019c57:	31 c0                	xor    %eax,%eax
 1019c59:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
 1019c60:	41 0f b6 0c 07       	movzbl (%r15,%rax,1),%ecx
 1019c65:	41 0f b6 54 05 00    	movzbl 0x0(%r13,%rax,1),%edx
 1019c6b:	41 88 14 07          	mov    %dl,(%r15,%rax,1)
 1019c6f:	41 88 4c 05 00       	mov    %cl,0x0(%r13,%rax,1)
 1019c74:	48 ff c0             	inc    %rax
 1019c77:	49 3b 06             	cmp    (%r14),%rax
 1019c7a:	72 e4                	jb     1019c60 <entry_run+0x1770>
 1019c7c:	48 8d bb 58 02 00 00 	lea    0x258(%rbx),%rdi
 1019c83:	4c 89 f6             	mov    %r14,%rsi
 1019c86:	4c 89 ea             	mov    %r13,%rdx
 1019c89:	e8 82 45 01 00       	call   102e210 <myl_rc_native_drop>
 1019c8e:	44 89 e0             	mov    %r12d,%eax
 1019c91:	48 8d 8d 40 fc ff ff 	lea    -0x3c0(%rbp),%rcx
 1019c98:	49 39 cd             	cmp    %rcx,%r13
 1019c9b:	4c 8b 7d b8          	mov    -0x48(%rbp),%r15
 1019c9f:	0f 84 46 01 00 00    	je     1019deb <entry_run+0x18fb>
 1019ca5:	41 89 c6             	mov    %eax,%r14d
 1019ca8:	49 8b 45 f0          	mov    -0x10(%r13),%rax
 1019cac:	48 b9 02 00 00 00 00 	movabs $0x4000000000000002,%rcx
 1019cb3:	00 00 40 
 1019cb6:	48 85 c8             	test   %rcx,%rax
 1019cb9:	75 4b                	jne    1019d06 <entry_run+0x1816>
 1019cbb:	48 8b 8b 60 18 00 00 	mov    0x1860(%rbx),%rcx
 1019cc2:	48 85 c9             	test   %rcx,%rcx
 1019cc5:	0f 84 d0 0e 00 00    	je     101ab9b <entry_run+0x26ab>
 1019ccb:	a8 01                	test   $0x1,%al
 1019ccd:	0f 85 c8 0e 00 00    	jne    101ab9b <entry_run+0x26ab>
 1019cd3:	49 8d 55 e0          	lea    -0x20(%r13),%rdx
 1019cd7:	48 8b 32             	mov    (%rdx),%rsi
 1019cda:	48 85 f6             	test   %rsi,%rsi
 1019cdd:	0f 84 b8 0e 00 00    	je     101ab9b <entry_run+0x26ab>
 1019ce3:	48 ff ce             	dec    %rsi
 1019ce6:	48 89 32             	mov    %rsi,(%rdx)
 1019ce9:	75 1b                	jne    1019d06 <entry_run+0x1816>
 1019ceb:	49 83 7d e8 00       	cmpq   $0x0,-0x18(%r13)
 1019cf0:	75 14                	jne    1019d06 <entry_run+0x1816>
 1019cf2:	48 83 c8 01          	or     $0x1,%rax
 1019cf6:	49 89 45 f0          	mov    %rax,-0x10(%r13)
 1019cfa:	48 8b 41 60          	mov    0x60(%rcx),%rax
 1019cfe:	49 89 45 e0          	mov    %rax,-0x20(%r13)
 1019d02:	48 89 51 60          	mov    %rdx,0x60(%rcx)
 1019d06:	48 8d bb 58 02 00 00 	lea    0x258(%rbx),%rdi
 1019d0d:	e8 4e e5 00 00       	call   1028260 <myl_rc_drain>
 1019d12:	44 89 f0             	mov    %r14d,%eax
 1019d15:	e9 d1 00 00 00       	jmp    1019deb <entry_run+0x18fb>
 1019d1a:	48 89 f2             	mov    %rsi,%rdx
 1019d1d:	48 b8 15 7c 4a 7f b9 	movabs $0x9e3779b97f4a7c15,%rax
 1019d24:	79 37 9e 
 1019d27:	48 31 c2             	xor    %rax,%rdx
 1019d2a:	48 b8 b9 e5 e4 1c 6d 	movabs $0xbf58476d1ce4e5b9,%rax
 1019d31:	47 58 bf 
 1019d34:	c4 e2 fb f6 f8       	mulx   %rax,%rax,%rdi
 1019d39:	48 31 c7             	xor    %rax,%rdi
 1019d3c:	48 89 fa             	mov    %rdi,%rdx
 1019d3f:	48 c1 ea 20          	shr    $0x20,%rdx
 1019d43:	48 31 fa             	xor    %rdi,%rdx
 1019d46:	4d 8b 9d d0 00 00 00 	mov    0xd0(%r13),%r11
 1019d4d:	48 ff c9             	dec    %rcx
 1019d50:	89 c8                	mov    %ecx,%eax
 1019d52:	21 d0                	and    %edx,%eax
 1019d54:	4d 8b 0c c3          	mov    (%r11,%rax,8),%r9
 1019d58:	4d 85 c9             	test   %r9,%r9
 1019d5b:	0f 84 e8 00 00 00    	je     1019e49 <entry_run+0x1959>
 1019d61:	4d 8b 45 00          	mov    0x0(%r13),%r8
 1019d65:	49 8b 7d 30          	mov    0x30(%r13),%rdi
 1019d69:	4d 8b 40 20          	mov    0x20(%r8),%r8
 1019d6d:	eb 14                	jmp    1019d83 <entry_run+0x1893>
 1019d6f:	90                   	nop
 1019d70:	48 ff c0             	inc    %rax
 1019d73:	48 21 c8             	and    %rcx,%rax
 1019d76:	4d 8b 0c c3          	mov    (%r11,%rax,8),%r9
 1019d7a:	4d 85 c9             	test   %r9,%r9
 1019d7d:	0f 84 a4 00 00 00    	je     1019e27 <entry_run+0x1937>
 1019d83:	4d 89 ca             	mov    %r9,%r10
 1019d86:	49 c1 ea 20          	shr    $0x20,%r10
 1019d8a:	44 39 d2             	cmp    %r10d,%edx
 1019d8d:	75 e1                	jne    1019d70 <entry_run+0x1880>
 1019d8f:	45 89 cf             	mov    %r9d,%r15d
 1019d92:	49 ff cf             	dec    %r15
 1019d95:	4d 89 f9             	mov    %r15,%r9
 1019d98:	4c 0f af cf          	imul   %rdi,%r9
 1019d9c:	4b 39 34 08          	cmp    %rsi,(%r8,%r9,1)
 1019da0:	75 ce                	jne    1019d70 <entry_run+0x1880>
 1019da2:	e9 87 00 00 00       	jmp    1019e2e <entry_run+0x193e>
 1019da7:	4c 89 ef             	mov    %r13,%rdi
 1019daa:	49 89 f6             	mov    %rsi,%r14
 1019dad:	e8 2e 98 00 00       	call   10235e0 <probe_scalar>
 1019db2:	49 89 c7             	mov    %rax,%r15
 1019db5:	49 83 ff ff          	cmp    $0xffffffffffffffff,%r15
 1019db9:	0f 85 e0 fb ff ff    	jne    101999f <entry_run+0x14af>
 1019dbf:	e9 6e fb ff ff       	jmp    1019932 <entry_run+0x1442>
 1019dc4:	41 c7 85 f8 00 00 00 	movl   $0x0,0xf8(%r13)
 1019dcb:	00 00 00 00 
 1019dcf:	90                   	nop
 1019dd0:	48 8d bb 58 02 00 00 	lea    0x258(%rbx),%rdi
 1019dd7:	4c 89 ee             	mov    %r13,%rsi
 1019dda:	48 8d 55 d0          	lea    -0x30(%rbp),%rdx
 1019dde:	48 8d 4d c0          	lea    -0x40(%rbp),%rcx
 1019de2:	e8 79 75 00 00       	call   1021360 <rc_insert_result>
 1019de7:	4c 8b 7d b8          	mov    -0x48(%rbp),%r15
 1019deb:	85 c0                	test   %eax,%eax
 1019ded:	4c 8d ab 58 02 00 00 	lea    0x258(%rbx),%r13
 1019df4:	0f 84 2e 0e 00 00    	je     101ac28 <entry_run+0x2738>
 1019dfa:	48 c7 45 d0 00 00 00 	movq   $0x0,-0x30(%rbp)
 1019e01:	00 
 1019e02:	83 bd 70 ff ff ff 00 	cmpl   $0x0,-0x90(%rbp)
 1019e09:	0f 84 21 f6 ff ff    	je     1019430 <entry_run+0xf40>
 1019e0f:	48 89 df             	mov    %rbx,%rdi
 1019e12:	48 8d b5 30 fe ff ff 	lea    -0x1d0(%rbp),%rsi
 1019e19:	e8 72 0e 00 00       	call   101ac90 <myl_qbe_rc_slot_drop>
 1019e1e:	e9 0d f6 ff ff       	jmp    1019430 <entry_run+0xf40>
 1019e23:	31 c0                	xor    %eax,%eax
 1019e25:	eb c0                	jmp    1019de7 <entry_run+0x18f7>
 1019e27:	49 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%r15
 1019e2e:	49 89 f6             	mov    %rsi,%r14
 1019e31:	89 c0                	mov    %eax,%eax
 1019e33:	48 c1 e2 20          	shl    $0x20,%rdx
 1019e37:	48 09 c2             	or     %rax,%rdx
 1019e3a:	49 83 ff ff          	cmp    $0xffffffffffffffff,%r15
 1019e3e:	0f 85 5b fb ff ff    	jne    101999f <entry_run+0x14af>
 1019e44:	e9 e9 fa ff ff       	jmp    1019932 <entry_run+0x1442>
 1019e49:	49 89 f6             	mov    %rsi,%r14
 1019e4c:	49 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%r15
 1019e53:	48 c1 e2 20          	shl    $0x20,%rdx
 1019e57:	48 09 c2             	or     %rax,%rdx
 1019e5a:	49 83 ff ff          	cmp    $0xffffffffffffffff,%r15
 1019e5e:	0f 85 3b fb ff ff    	jne    101999f <entry_run+0x14af>
 1019e64:	e9 c9 fa ff ff       	jmp    1019932 <entry_run+0x1442>
 1019e69:	41 0f b7 f1          	movzwl %r9w,%esi
 1019e6d:	e9 71 fa ff ff       	jmp    10198e3 <entry_run+0x13f3>
 1019e72:	44 89 ce             	mov    %r9d,%esi
 1019e75:	e9 69 fa ff ff       	jmp    10198e3 <entry_run+0x13f3>
 1019e7a:	49 8b 02             	mov    (%r10),%rax
 1019e7d:	e9 da 00 00 00       	jmp    1019f5c <entry_run+0x1a6c>
 1019e82:	49 8b 45 08          	mov    0x8(%r13),%rax
 1019e86:	48 8b 10             	mov    (%rax),%rdx
 1019e89:	48 c7 85 40 fc ff ff 	movq   $0x0,-0x3c0(%rbp)
 1019e90:	00 00 00 00 
 1019e94:	f3 48 0f b8 c2       	popcnt %rdx,%rax
 1019e99:	83 f8 01             	cmp    $0x1,%eax
 1019e9c:	0f 85 89 00 00 00    	jne    1019f2b <entry_run+0x1a3b>
 1019ea2:	f3 48 0f bc c2       	tzcnt  %rdx,%rax
 1019ea7:	48 83 f8 03          	cmp    $0x3,%rax
 1019eab:	77 7e                	ja     1019f2b <entry_run+0x1a3b>
 1019ead:	4d 89 f7             	mov    %r14,%r15
 1019eb0:	ff 24 c5 b8 96 00 01 	jmp    *0x10096b8(,%rax,8)
 1019eb7:	41 0f b6 02          	movzbl (%r10),%eax
 1019ebb:	e9 9f 00 00 00       	jmp    1019f5f <entry_run+0x1a6f>
 1019ec0:	4d 89 f7             	mov    %r14,%r15
 1019ec3:	48 8b 45 b0          	mov    -0x50(%rbp),%rax
 1019ec7:	e9 93 00 00 00       	jmp    1019f5f <entry_run+0x1a6f>
 1019ecc:	41 0f b7 c9          	movzwl %r9w,%ecx
 1019ed0:	e9 cb f7 ff ff       	jmp    10196a0 <entry_run+0x11b0>
 1019ed5:	44 89 c9             	mov    %r9d,%ecx
 1019ed8:	e9 c3 f7 ff ff       	jmp    10196a0 <entry_run+0x11b0>
 1019edd:	49 8b 49 18          	mov    0x18(%r9),%rcx
 1019ee1:	41 8b 51 14          	mov    0x14(%r9),%edx
 1019ee5:	48 01 d1             	add    %rdx,%rcx
 1019ee8:	48 83 c1 18          	add    $0x18,%rcx
 1019eec:	48 8b 50 08          	mov    0x8(%rax),%rdx
 1019ef0:	45 31 e4             	xor    %r12d,%r12d
 1019ef3:	49 3b 51 08          	cmp    0x8(%r9),%rdx
 1019ef7:	0f 85 ac 00 00 00    	jne    1019fa9 <entry_run+0x1ab9>
 1019efd:	48 83 fa 08          	cmp    $0x8,%rdx
 1019f01:	72 7f                	jb     1019f82 <entry_run+0x1a92>
 1019f03:	31 f6                	xor    %esi,%esi
 1019f05:	48 8d 7e 08          	lea    0x8(%rsi),%rdi
 1019f09:	48 39 d7             	cmp    %rdx,%rdi
 1019f0c:	0f 83 f7 00 00 00    	jae    101a009 <entry_run+0x1b19>
 1019f12:	4c 8b 44 30 18       	mov    0x18(%rax,%rsi,1),%r8
 1019f17:	45 31 e4             	xor    %r12d,%r12d
 1019f1a:	4c 3b 04 31          	cmp    (%rcx,%rsi,1),%r8
 1019f1e:	48 89 fe             	mov    %rdi,%rsi
 1019f21:	74 e2                	je     1019f05 <entry_run+0x1a15>
 1019f23:	4c 89 ce             	mov    %r9,%rsi
 1019f26:	e9 be f9 ff ff       	jmp    10198e9 <entry_run+0x13f9>
 1019f2b:	48 83 fa 08          	cmp    $0x8,%rdx
 1019f2f:	b8 08 00 00 00       	mov    $0x8,%eax
 1019f34:	48 0f 43 d0          	cmovae %rax,%rdx
 1019f38:	48 89 7d b8          	mov    %rdi,-0x48(%rbp)
 1019f3c:	48 8d bd 40 fc ff ff 	lea    -0x3c0(%rbp),%rdi
 1019f43:	4c 89 d6             	mov    %r10,%rsi
 1019f46:	4d 89 d7             	mov    %r10,%r15
 1019f49:	e8 f2 81 01 00       	call   1032140 <memcpy@plt>
 1019f4e:	48 8b 7d b8          	mov    -0x48(%rbp),%rdi
 1019f52:	4d 89 fa             	mov    %r15,%r10
 1019f55:	48 8b 85 40 fc ff ff 	mov    -0x3c0(%rbp),%rax
 1019f5c:	4d 89 f7             	mov    %r14,%r15
 1019f5f:	48 89 45 b0          	mov    %rax,-0x50(%rbp)
 1019f63:	48 39 f8             	cmp    %rdi,%rax
 1019f66:	0f 85 14 f8 ff ff    	jne    1019780 <entry_run+0x1290>
 1019f6c:	e9 ec 01 00 00       	jmp    101a15d <entry_run+0x1c6d>
 1019f71:	41 0f b7 f9          	movzwl %r9w,%edi
 1019f75:	e9 a1 f7 ff ff       	jmp    101971b <entry_run+0x122b>
 1019f7a:	44 89 cf             	mov    %r9d,%edi
 1019f7d:	e9 99 f7 ff ff       	jmp    101971b <entry_run+0x122b>
 1019f82:	48 83 fa 03          	cmp    $0x3,%rdx
 1019f86:	0f 86 98 00 00 00    	jbe    101a024 <entry_run+0x1b34>
 1019f8c:	8b 70 18             	mov    0x18(%rax),%esi
 1019f8f:	3b 31                	cmp    (%rcx),%esi
 1019f91:	75 16                	jne    1019fa9 <entry_run+0x1ab9>
 1019f93:	8b 4c 11 fc          	mov    -0x4(%rcx,%rdx,1),%ecx
 1019f97:	4c 89 ce             	mov    %r9,%rsi
 1019f9a:	39 4c 10 14          	cmp    %ecx,0x14(%rax,%rdx,1)
 1019f9e:	0f 84 35 fa ff ff    	je     10199d9 <entry_run+0x14e9>
 1019fa4:	e9 53 f9 ff ff       	jmp    10198fc <entry_run+0x140c>
 1019fa9:	4c 89 ce             	mov    %r9,%rsi
 1019fac:	e9 4b f9 ff ff       	jmp    10198fc <entry_run+0x140c>
 1019fb1:	49 8b 49 18          	mov    0x18(%r9),%rcx
 1019fb5:	41 8b 51 14          	mov    0x14(%r9),%edx
 1019fb9:	48 01 d1             	add    %rdx,%rcx
 1019fbc:	48 83 c1 18          	add    $0x18,%rcx
 1019fc0:	48 8b 50 08          	mov    0x8(%rax),%rdx
 1019fc4:	49 3b 51 08          	cmp    0x8(%r9),%rdx
 1019fc8:	0f 85 b2 f7 ff ff    	jne    1019780 <entry_run+0x1290>
 1019fce:	48 83 fa 08          	cmp    $0x8,%rdx
 1019fd2:	0f 82 a6 00 00 00    	jb     101a07e <entry_run+0x1b8e>
 1019fd8:	31 f6                	xor    %esi,%esi
 1019fda:	48 8d 7e 08          	lea    0x8(%rsi),%rdi
 1019fde:	48 39 d7             	cmp    %rdx,%rdi
 1019fe1:	0f 83 0e 01 00 00    	jae    101a0f5 <entry_run+0x1c05>
 1019fe7:	4c 8b 44 30 18       	mov    0x18(%rax,%rsi,1),%r8
 1019fec:	4c 3b 04 31          	cmp    (%rcx,%rsi,1),%r8
 1019ff0:	48 89 fe             	mov    %rdi,%rsi
 1019ff3:	74 e5                	je     1019fda <entry_run+0x1aea>
 1019ff5:	e9 86 f7 ff ff       	jmp    1019780 <entry_run+0x1290>
 1019ffa:	8b 06                	mov    (%rsi),%eax
 1019ffc:	e9 2a f8 ff ff       	jmp    101982b <entry_run+0x133b>
 101a001:	0f b7 06             	movzwl (%rsi),%eax
 101a004:	e9 22 f8 ff ff       	jmp    101982b <entry_run+0x133b>
 101a009:	48 8b 44 10 10       	mov    0x10(%rax,%rdx,1),%rax
 101a00e:	45 31 e4             	xor    %r12d,%r12d
 101a011:	4c 89 ce             	mov    %r9,%rsi
 101a014:	48 3b 44 11 f8       	cmp    -0x8(%rcx,%rdx,1),%rax
 101a019:	0f 85 ca f8 ff ff    	jne    10198e9 <entry_run+0x13f9>
 101a01f:	e9 b5 f9 ff ff       	jmp    10199d9 <entry_run+0x14e9>
 101a024:	48 85 d2             	test   %rdx,%rdx
 101a027:	0f 84 ac f9 ff ff    	je     10199d9 <entry_run+0x14e9>
 101a02d:	0f b6 70 18          	movzbl 0x18(%rax),%esi
 101a031:	40 3a 31             	cmp    (%rcx),%sil
 101a034:	41 0f 94 c2          	sete   %r10b
 101a038:	40 0f 95 c7          	setne  %dil
 101a03c:	48 83 fa 01          	cmp    $0x1,%rdx
 101a040:	41 0f 94 c0          	sete   %r8b
 101a044:	41 08 f8             	or     %dil,%r8b
 101a047:	0f 85 97 00 00 00    	jne    101a0e4 <entry_run+0x1bf4>
 101a04d:	0f b6 70 19          	movzbl 0x19(%rax),%esi
 101a051:	40 3a 71 01          	cmp    0x1(%rcx),%sil
 101a055:	41 0f 94 c2          	sete   %r10b
 101a059:	40 0f 95 c7          	setne  %dil
 101a05d:	48 83 fa 02          	cmp    $0x2,%rdx
 101a061:	0f 94 c2             	sete   %dl
 101a064:	40 08 fa             	or     %dil,%dl
 101a067:	75 7b                	jne    101a0e4 <entry_run+0x1bf4>
 101a069:	0f b6 40 1a          	movzbl 0x1a(%rax),%eax
 101a06d:	4c 89 ce             	mov    %r9,%rsi
 101a070:	3a 41 02             	cmp    0x2(%rcx),%al
 101a073:	0f 85 83 f8 ff ff    	jne    10198fc <entry_run+0x140c>
 101a079:	e9 5b f9 ff ff       	jmp    10199d9 <entry_run+0x14e9>
 101a07e:	48 83 fa 03          	cmp    $0x3,%rdx
 101a082:	0f 86 82 00 00 00    	jbe    101a10a <entry_run+0x1c1a>
 101a088:	8b 70 18             	mov    0x18(%rax),%esi
 101a08b:	3b 31                	cmp    (%rcx),%esi
 101a08d:	0f 85 ed f6 ff ff    	jne    1019780 <entry_run+0x1290>
 101a093:	8b 4c 11 fc          	mov    -0x4(%rcx,%rdx,1),%ecx
 101a097:	48 8b 7d b0          	mov    -0x50(%rbp),%rdi
 101a09b:	39 4c 10 14          	cmp    %ecx,0x14(%rax,%rdx,1)
 101a09f:	0f 84 b8 00 00 00    	je     101a15d <entry_run+0x1c6d>
 101a0a5:	e9 d6 f6 ff ff       	jmp    1019780 <entry_run+0x1290>
 101a0aa:	44 3b a3 c8 02 00 00 	cmp    0x2c8(%rbx),%r12d
 101a0b1:	0f 87 64 0b 00 00    	ja     101ac1b <entry_run+0x272b>
 101a0b7:	49 8b 16             	mov    (%r14),%rdx
 101a0ba:	4c 89 ff             	mov    %r15,%rdi
 101a0bd:	48 8d 75 c0          	lea    -0x40(%rbp),%rsi
 101a0c1:	e8 ea 81 01 00       	call   10322b0 <memmove@plt>
 101a0c6:	e9 72 f9 ff ff       	jmp    1019a3d <entry_run+0x154d>
 101a0cb:	41 8b 02             	mov    (%r10),%eax
 101a0ce:	e9 8c fe ff ff       	jmp    1019f5f <entry_run+0x1a6f>
 101a0d3:	49 8b 02             	mov    (%r10),%rax
 101a0d6:	e9 84 fe ff ff       	jmp    1019f5f <entry_run+0x1a6f>
 101a0db:	41 0f b7 02          	movzwl (%r10),%eax
 101a0df:	e9 7b fe ff ff       	jmp    1019f5f <entry_run+0x1a6f>
 101a0e4:	4c 89 ce             	mov    %r9,%rsi
 101a0e7:	45 84 d2             	test   %r10b,%r10b
 101a0ea:	0f 84 0c f8 ff ff    	je     10198fc <entry_run+0x140c>
 101a0f0:	e9 e4 f8 ff ff       	jmp    10199d9 <entry_run+0x14e9>
 101a0f5:	48 8b 44 10 10       	mov    0x10(%rax,%rdx,1),%rax
 101a0fa:	48 8b 7d b0          	mov    -0x50(%rbp),%rdi
 101a0fe:	48 3b 44 11 f8       	cmp    -0x8(%rcx,%rdx,1),%rax
 101a103:	74 58                	je     101a15d <entry_run+0x1c6d>
 101a105:	e9 76 f6 ff ff       	jmp    1019780 <entry_run+0x1290>
 101a10a:	48 85 d2             	test   %rdx,%rdx
 101a10d:	74 4a                	je     101a159 <entry_run+0x1c69>
 101a10f:	0f b6 70 18          	movzbl 0x18(%rax),%esi
 101a113:	40 3a 31             	cmp    (%rcx),%sil
 101a116:	40 0f 94 c6          	sete   %sil
 101a11a:	40 0f 95 c7          	setne  %dil
 101a11e:	48 83 fa 01          	cmp    $0x1,%rdx
 101a122:	41 0f 94 c0          	sete   %r8b
 101a126:	41 08 f8             	or     %dil,%r8b
 101a129:	75 75                	jne    101a1a0 <entry_run+0x1cb0>
 101a12b:	0f b6 70 19          	movzbl 0x19(%rax),%esi
 101a12f:	40 3a 71 01          	cmp    0x1(%rcx),%sil
 101a133:	40 0f 94 c6          	sete   %sil
 101a137:	40 0f 95 c7          	setne  %dil
 101a13b:	48 83 fa 02          	cmp    $0x2,%rdx
 101a13f:	0f 94 c2             	sete   %dl
 101a142:	40 08 fa             	or     %dil,%dl
 101a145:	75 59                	jne    101a1a0 <entry_run+0x1cb0>
 101a147:	0f b6 40 1a          	movzbl 0x1a(%rax),%eax
 101a14b:	48 8b 7d b0          	mov    -0x50(%rbp),%rdi
 101a14f:	3a 41 02             	cmp    0x2(%rcx),%al
 101a152:	74 09                	je     101a15d <entry_run+0x1c6d>
 101a154:	e9 27 f6 ff ff       	jmp    1019780 <entry_run+0x1290>
 101a159:	48 8b 7d b0          	mov    -0x50(%rbp),%rdi
 101a15d:	4d 03 55 18          	add    0x18(%r13),%r10
 101a161:	49 8b 45 10          	mov    0x10(%r13),%rax
 101a165:	48 8b 10             	mov    (%rax),%rdx
 101a168:	48 83 fa 08          	cmp    $0x8,%rdx
 101a16c:	75 13                	jne    101a181 <entry_run+0x1c91>
 101a16e:	4d 89 22             	mov    %r12,(%r10)
 101a171:	48 89 7d b0          	mov    %rdi,-0x50(%rbp)
 101a175:	4c 8d ab 58 02 00 00 	lea    0x258(%rbx),%r13
 101a17c:	e9 79 fc ff ff       	jmp    1019dfa <entry_run+0x190a>
 101a181:	49 89 fe             	mov    %rdi,%r14
 101a184:	4c 89 d7             	mov    %r10,%rdi
 101a187:	48 8d 75 c0          	lea    -0x40(%rbp),%rsi
 101a18b:	e8 20 81 01 00       	call   10322b0 <memmove@plt>
 101a190:	4c 89 75 b0          	mov    %r14,-0x50(%rbp)
 101a194:	4c 8d ab 58 02 00 00 	lea    0x258(%rbx),%r13
 101a19b:	e9 5a fc ff ff       	jmp    1019dfa <entry_run+0x190a>
 101a1a0:	48 8b 7d b0          	mov    -0x50(%rbp),%rdi
 101a1a4:	40 84 f6             	test   %sil,%sil
 101a1a7:	75 b4                	jne    101a15d <entry_run+0x1c6d>
 101a1a9:	e9 d2 f5 ff ff       	jmp    1019780 <entry_run+0x1290>
 101a1ae:	48 c7 45 d0 00 00 00 	movq   $0x0,-0x30(%rbp)
 101a1b5:	00 
 101a1b6:	48 8b 45 98          	mov    -0x68(%rbp),%rax
 101a1ba:	83 bd 68 fd ff ff 08 	cmpl   $0x8,-0x298(%rbp)
 101a1c1:	0f 85 d6 00 00 00    	jne    101a29d <entry_run+0x1dad>
 101a1c7:	8b 8d 38 ff ff ff    	mov    -0xc8(%rbp),%ecx
 101a1cd:	83 e1 01             	and    $0x1,%ecx
 101a1d0:	0f 84 c7 00 00 00    	je     101a29d <entry_run+0x1dad>
 101a1d6:	48 c7 45 c8 00 00 00 	movq   $0x0,-0x38(%rbp)
 101a1dd:	00 
 101a1de:	48 85 c0             	test   %rax,%rax
 101a1e1:	74 4c                	je     101a22f <entry_run+0x1d3f>
 101a1e3:	48 8b 48 f0          	mov    -0x10(%rax),%rcx
 101a1e7:	48 ba 02 00 00 00 00 	movabs $0x4000000000000002,%rdx
 101a1ee:	00 00 40 
 101a1f1:	48 85 d1             	test   %rdx,%rcx
 101a1f4:	75 39                	jne    101a22f <entry_run+0x1d3f>
 101a1f6:	48 83 bb 60 18 00 00 	cmpq   $0x0,0x1860(%rbx)
 101a1fd:	00 
 101a1fe:	0f 84 97 09 00 00    	je     101ab9b <entry_run+0x26ab>
 101a204:	f6 c1 01             	test   $0x1,%cl
 101a207:	0f 85 8e 09 00 00    	jne    101ab9b <entry_run+0x26ab>
 101a20d:	48 8b 48 e8          	mov    -0x18(%rax),%rcx
 101a211:	48 8b 50 e0          	mov    -0x20(%rax),%rdx
 101a215:	48 09 ca             	or     %rcx,%rdx
 101a218:	0f 84 7d 09 00 00    	je     101ab9b <entry_run+0x26ab>
 101a21e:	48 83 f9 ff          	cmp    $0xffffffffffffffff,%rcx
 101a222:	0f 84 e3 04 00 00    	je     101a70b <entry_run+0x221b>
 101a228:	48 ff c1             	inc    %rcx
 101a22b:	48 89 48 e8          	mov    %rcx,-0x18(%rax)
 101a22f:	48 c7 85 90 fe ff ff 	movq   $0x1009fd0,-0x170(%rbp)
 101a236:	d0 9f 00 01 
 101a23a:	48 8d 4d c8          	lea    -0x38(%rbp),%rcx
 101a23e:	48 89 8d 98 fe ff ff 	mov    %rcx,-0x168(%rbp)
 101a245:	48 8d 4d 88          	lea    -0x78(%rbp),%rcx
 101a249:	48 89 8d a0 fe ff ff 	mov    %rcx,-0x160(%rbp)
 101a250:	c7 85 a8 fe ff ff 08 	movl   $0x8,-0x158(%rbp)
 101a257:	00 00 00 
 101a25a:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
 101a25e:	48 c7 85 30 fe ff ff 	movq   $0x1009fd0,-0x1d0(%rbp)
 101a265:	d0 9f 00 01 
 101a269:	48 8d 4d a8          	lea    -0x58(%rbp),%rcx
 101a26d:	48 89 8d 38 fe ff ff 	mov    %rcx,-0x1c8(%rbp)
 101a274:	48 8d 8d 70 ff ff ff 	lea    -0x90(%rbp),%rcx
 101a27b:	48 89 8d 40 fe ff ff 	mov    %rcx,-0x1c0(%rbp)
 101a282:	c7 85 48 fe ff ff 08 	movl   $0x8,-0x1b8(%rbp)
 101a289:	00 00 00 
 101a28c:	c7 85 70 ff ff ff 01 	movl   $0x1,-0x90(%rbp)
 101a293:	00 00 00 
 101a296:	c7 45 88 00 00 00 00 	movl   $0x0,-0x78(%rbp)
 101a29d:	48 89 45 d0          	mov    %rax,-0x30(%rbp)
 101a2a1:	48 c7 45 c8 00 00 00 	movq   $0x0,-0x38(%rbp)
 101a2a8:	00 
 101a2a9:	48 85 c0             	test   %rax,%rax
 101a2ac:	74 4c                	je     101a2fa <entry_run+0x1e0a>
 101a2ae:	48 8b 48 f0          	mov    -0x10(%rax),%rcx
 101a2b2:	48 ba 02 00 00 00 00 	movabs $0x4000000000000002,%rdx
 101a2b9:	00 00 40 
 101a2bc:	48 85 d1             	test   %rdx,%rcx
 101a2bf:	75 39                	jne    101a2fa <entry_run+0x1e0a>
 101a2c1:	48 83 bb 60 18 00 00 	cmpq   $0x0,0x1860(%rbx)
 101a2c8:	00 
 101a2c9:	0f 84 cc 08 00 00    	je     101ab9b <entry_run+0x26ab>
 101a2cf:	f6 c1 01             	test   $0x1,%cl
 101a2d2:	0f 85 c3 08 00 00    	jne    101ab9b <entry_run+0x26ab>
 101a2d8:	48 8b 48 e8          	mov    -0x18(%rax),%rcx
 101a2dc:	48 8b 50 e0          	mov    -0x20(%rax),%rdx
 101a2e0:	48 09 ca             	or     %rcx,%rdx
 101a2e3:	0f 84 b2 08 00 00    	je     101ab9b <entry_run+0x26ab>
 101a2e9:	48 83 f9 ff          	cmp    $0xffffffffffffffff,%rcx
 101a2ed:	0f 84 18 04 00 00    	je     101a70b <entry_run+0x221b>
 101a2f3:	48 ff c1             	inc    %rcx
 101a2f6:	48 89 48 e8          	mov    %rcx,-0x18(%rax)
 101a2fa:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
 101a2fe:	48 c7 85 90 fe ff ff 	movq   $0x1009fd0,-0x170(%rbp)
 101a305:	d0 9f 00 01 
 101a309:	48 8d 4d c8          	lea    -0x38(%rbp),%rcx
 101a30d:	48 89 8d 98 fe ff ff 	mov    %rcx,-0x168(%rbp)
 101a314:	48 8d 4d 88          	lea    -0x78(%rbp),%rcx
 101a318:	48 89 8d a0 fe ff ff 	mov    %rcx,-0x160(%rbp)
 101a31f:	c7 85 a8 fe ff ff 08 	movl   $0x8,-0x158(%rbp)
 101a326:	00 00 00 
 101a329:	c7 45 88 01 00 00 00 	movl   $0x1,-0x78(%rbp)
 101a330:	83 bd 70 ff ff ff 00 	cmpl   $0x0,-0x90(%rbp)
 101a337:	74 13                	je     101a34c <entry_run+0x1e5c>
 101a339:	48 89 df             	mov    %rbx,%rdi
 101a33c:	48 8d b5 30 fe ff ff 	lea    -0x1d0(%rbp),%rsi
 101a343:	e8 48 09 00 00       	call   101ac90 <myl_qbe_rc_slot_drop>
 101a348:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
 101a34c:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
 101a350:	48 c7 85 30 fe ff ff 	movq   $0x1009fd0,-0x1d0(%rbp)
 101a357:	d0 9f 00 01 
 101a35b:	48 8d 4d a8          	lea    -0x58(%rbp),%rcx
 101a35f:	48 89 8d 38 fe ff ff 	mov    %rcx,-0x1c8(%rbp)
 101a366:	48 8d 8d 70 ff ff ff 	lea    -0x90(%rbp),%rcx
 101a36d:	48 89 8d 40 fe ff ff 	mov    %rcx,-0x1c0(%rbp)
 101a374:	c7 85 48 fe ff ff 08 	movl   $0x8,-0x1b8(%rbp)
 101a37b:	00 00 00 
 101a37e:	48 89 45 d0          	mov    %rax,-0x30(%rbp)
 101a382:	48 c7 85 90 fe ff ff 	movq   $0x1009fd0,-0x170(%rbp)
 101a389:	d0 9f 00 01 
 101a38d:	48 8d 4d c8          	lea    -0x38(%rbp),%rcx
 101a391:	48 89 8d 98 fe ff ff 	mov    %rcx,-0x168(%rbp)
 101a398:	48 8d 4d 88          	lea    -0x78(%rbp),%rcx
 101a39c:	48 89 8d a0 fe ff ff 	mov    %rcx,-0x160(%rbp)
 101a3a3:	c7 85 a8 fe ff ff 08 	movl   $0x8,-0x158(%rbp)
 101a3aa:	00 00 00 
 101a3ad:	c7 45 88 01 00 00 00 	movl   $0x1,-0x78(%rbp)
 101a3b4:	c7 85 70 ff ff ff 00 	movl   $0x0,-0x90(%rbp)
 101a3bb:	00 00 00 
 101a3be:	83 bd 60 ff ff ff 00 	cmpl   $0x0,-0xa0(%rbp)
 101a3c5:	4c 8d b5 10 ff ff ff 	lea    -0xf0(%rbp),%r14
 101a3cc:	4c 8d bd 60 ff ff ff 	lea    -0xa0(%rbp),%r15
 101a3d3:	74 13                	je     101a3e8 <entry_run+0x1ef8>
 101a3d5:	48 89 df             	mov    %rbx,%rdi
 101a3d8:	48 8d b5 f0 fd ff ff 	lea    -0x210(%rbp),%rsi
 101a3df:	e8 ac 08 00 00       	call   101ac90 <myl_qbe_rc_slot_drop>
 101a3e4:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
 101a3e8:	48 89 85 10 ff ff ff 	mov    %rax,-0xf0(%rbp)
 101a3ef:	48 c7 85 f0 fd ff ff 	movq   $0x1009fd0,-0x210(%rbp)
 101a3f6:	d0 9f 00 01 
 101a3fa:	4c 89 b5 f8 fd ff ff 	mov    %r14,-0x208(%rbp)
 101a401:	4c 89 bd 00 fe ff ff 	mov    %r15,-0x200(%rbp)
 101a408:	c7 85 08 fe ff ff 08 	movl   $0x8,-0x1f8(%rbp)
 101a40f:	00 00 00 
 101a412:	c7 85 60 ff ff ff 01 	movl   $0x1,-0xa0(%rbp)
 101a419:	00 00 00 
 101a41c:	c7 45 88 00 00 00 00 	movl   $0x0,-0x78(%rbp)
 101a423:	48 8b 10             	mov    (%rax),%rdx
 101a426:	48 89 55 d0          	mov    %rdx,-0x30(%rbp)
 101a42a:	48 85 d2             	test   %rdx,%rdx
 101a42d:	0f 88 fd 07 00 00    	js     101ac30 <entry_run+0x2740>
 101a433:	48 89 55 c0          	mov    %rdx,-0x40(%rbp)
 101a437:	0f 84 ef 02 00 00    	je     101a72c <entry_run+0x223c>
 101a43d:	48 89 d1             	mov    %rdx,%rcx
 101a440:	48 f7 d9             	neg    %rcx
 101a443:	48 89 8d 28 ff ff ff 	mov    %rcx,-0xd8(%rbp)
 101a44a:	41 bc 01 00 00 00    	mov    $0x1,%r12d
 101a450:	45 31 ed             	xor    %r13d,%r13d
 101a453:	48 8d 75 c8          	lea    -0x38(%rbp),%rsi
 101a457:	4c 8d 75 d0          	lea    -0x30(%rbp),%r14
 101a45b:	48 89 55 b0          	mov    %rdx,-0x50(%rbp)
 101a45f:	90                   	nop
 101a460:	4c 89 6d b8          	mov    %r13,-0x48(%rbp)
 101a464:	48 8b 40 20          	mov    0x20(%rax),%rax
 101a468:	4d 89 e5             	mov    %r12,%r13
 101a46b:	4a 8b 44 e0 f8       	mov    -0x8(%rax,%r12,8),%rax
 101a470:	48 89 45 d0          	mov    %rax,-0x30(%rbp)
 101a474:	4c 8d bb 58 02 00 00 	lea    0x258(%rbx),%r15
 101a47b:	4c 89 ff             	mov    %r15,%rdi
 101a47e:	4c 89 f2             	mov    %r14,%rdx
 101a481:	4d 89 f4             	mov    %r14,%r12
 101a484:	49 89 f6             	mov    %rsi,%r14
 101a487:	e8 44 3f 01 00       	call   102e3d0 <myl_rc_native_loan>
 101a48c:	85 c0                	test   %eax,%eax
 101a48e:	0f 84 14 05 00 00    	je     101a9a8 <entry_run+0x24b8>
 101a494:	48 c7 85 90 fe ff ff 	movq   $0x1009f60,-0x170(%rbp)
 101a49b:	60 9f 00 01 
 101a49f:	c7 85 a8 fe ff ff 10 	movl   $0x10,-0x158(%rbp)
 101a4a6:	00 00 00 
 101a4a9:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
 101a4ad:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
 101a4b1:	48 c7 85 30 fe ff ff 	movq   $0x1009f60,-0x1d0(%rbp)
 101a4b8:	60 9f 00 01 
 101a4bc:	c7 85 48 fe ff ff 10 	movl   $0x10,-0x1b8(%rbp)
 101a4c3:	00 00 00 
 101a4c6:	c7 45 88 00 00 00 00 	movl   $0x0,-0x78(%rbp)
 101a4cd:	c7 85 70 ff ff ff 01 	movl   $0x1,-0x90(%rbp)
 101a4d4:	00 00 00 
 101a4d7:	48 89 45 d0          	mov    %rax,-0x30(%rbp)
 101a4db:	4c 89 ff             	mov    %r15,%rdi
 101a4de:	4d 89 f7             	mov    %r14,%r15
 101a4e1:	4c 89 f6             	mov    %r14,%rsi
 101a4e4:	4c 89 e2             	mov    %r12,%rdx
 101a4e7:	e8 e4 3e 01 00       	call   102e3d0 <myl_rc_native_loan>
 101a4ec:	85 c0                	test   %eax,%eax
 101a4ee:	0f 84 e2 04 00 00    	je     101a9d6 <entry_run+0x24e6>
 101a4f4:	4d 89 e6             	mov    %r12,%r14
 101a4f7:	48 c7 85 90 fe ff ff 	movq   $0x1009f60,-0x170(%rbp)
 101a4fe:	60 9f 00 01 
 101a502:	c7 85 a8 fe ff ff 10 	movl   $0x10,-0x158(%rbp)
 101a509:	00 00 00 
 101a50c:	c7 45 88 01 00 00 00 	movl   $0x1,-0x78(%rbp)
 101a513:	83 bd 70 ff ff ff 00 	cmpl   $0x0,-0x90(%rbp)
 101a51a:	74 0f                	je     101a52b <entry_run+0x203b>
 101a51c:	48 89 df             	mov    %rbx,%rdi
 101a51f:	48 8d b5 30 fe ff ff 	lea    -0x1d0(%rbp),%rsi
 101a526:	e8 65 07 00 00       	call   101ac90 <myl_qbe_rc_slot_drop>
 101a52b:	83 bd 68 ff ff ff 00 	cmpl   $0x0,-0x98(%rbp)
 101a532:	4d 89 ec             	mov    %r13,%r12
 101a535:	74 0f                	je     101a546 <entry_run+0x2056>
 101a537:	48 89 df             	mov    %rbx,%rdi
 101a53a:	48 8d b5 10 fe ff ff 	lea    -0x1f0(%rbp),%rsi
 101a541:	e8 4a 07 00 00       	call   101ac90 <myl_qbe_rc_slot_drop>
 101a546:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
 101a54a:	48 89 85 18 ff ff ff 	mov    %rax,-0xe8(%rbp)
 101a551:	c7 45 88 00 00 00 00 	movl   $0x0,-0x78(%rbp)
 101a558:	48 c7 85 10 fe ff ff 	movq   $0x1009f60,-0x1f0(%rbp)
 101a55f:	60 9f 00 01 
 101a563:	48 8d 8d 18 ff ff ff 	lea    -0xe8(%rbp),%rcx
 101a56a:	48 89 8d 18 fe ff ff 	mov    %rcx,-0x1e8(%rbp)
 101a571:	48 8d 8d 68 ff ff ff 	lea    -0x98(%rbp),%rcx
 101a578:	48 89 8d 20 fe ff ff 	mov    %rcx,-0x1e0(%rbp)
 101a57f:	8b 8d a8 fe ff ff    	mov    -0x158(%rbp),%ecx
 101a585:	89 8d 28 fe ff ff    	mov    %ecx,-0x1d8(%rbp)
 101a58b:	c7 85 68 ff ff ff 01 	movl   $0x1,-0x98(%rbp)
 101a592:	00 00 00 
 101a595:	48 8b 4d b8          	mov    -0x48(%rbp),%rcx
 101a599:	48 89 4d d0          	mov    %rcx,-0x30(%rbp)
 101a59d:	48 8b 7d a0          	mov    -0x60(%rbp),%rdi
 101a5a1:	48 89 7d c0          	mov    %rdi,-0x40(%rbp)
 101a5a5:	48 89 85 20 ff ff ff 	mov    %rax,-0xe0(%rbp)
 101a5ac:	48 8d b5 20 ff ff ff 	lea    -0xe0(%rbp),%rsi
 101a5b3:	48 8d 95 f0 fc ff ff 	lea    -0x310(%rbp),%rdx
 101a5ba:	e8 01 88 00 00       	call   1022dc0 <myl_native_dictionary_read>
 101a5bf:	85 c0                	test   %eax,%eax
 101a5c1:	0f 84 22 06 00 00    	je     101abe9 <entry_run+0x26f9>
 101a5c7:	48 8b 85 f0 fc ff ff 	mov    -0x310(%rbp),%rax
 101a5ce:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
 101a5d2:	83 bd 78 ff ff ff 00 	cmpl   $0x0,-0x88(%rbp)
 101a5d9:	74 0f                	je     101a5ea <entry_run+0x20fa>
 101a5db:	48 89 df             	mov    %rbx,%rdi
 101a5de:	48 8d b5 50 fe ff ff 	lea    -0x1b0(%rbp),%rsi
 101a5e5:	e8 a6 06 00 00       	call   101ac90 <myl_qbe_rc_slot_drop>
 101a5ea:	83 7d 80 00          	cmpl   $0x0,-0x80(%rbp)
 101a5ee:	74 3e                	je     101a62e <entry_run+0x213e>
 101a5f0:	48 89 df             	mov    %rbx,%rdi
 101a5f3:	48 8d b5 70 fe ff ff 	lea    -0x190(%rbp),%rsi
 101a5fa:	e8 91 06 00 00       	call   101ac90 <myl_qbe_rc_slot_drop>
 101a5ff:	48 8b 85 18 ff ff ff 	mov    -0xe8(%rbp),%rax
 101a606:	48 8b 08             	mov    (%rax),%rcx
 101a609:	48 89 8d 20 ff ff ff 	mov    %rcx,-0xe0(%rbp)
 101a610:	83 7d 80 00          	cmpl   $0x0,-0x80(%rbp)
 101a614:	74 29                	je     101a63f <entry_run+0x214f>
 101a616:	48 89 df             	mov    %rbx,%rdi
 101a619:	48 8d b5 70 fe ff ff 	lea    -0x190(%rbp),%rsi
 101a620:	e8 6b 06 00 00       	call   101ac90 <myl_qbe_rc_slot_drop>
 101a625:	48 8b 8d 20 ff ff ff 	mov    -0xe0(%rbp),%rcx
 101a62c:	eb 11                	jmp    101a63f <entry_run+0x214f>
 101a62e:	48 8b 85 18 ff ff ff 	mov    -0xe8(%rbp),%rax
 101a635:	48 8b 08             	mov    (%rax),%rcx
 101a638:	48 89 8d 20 ff ff ff 	mov    %rcx,-0xe0(%rbp)
 101a63f:	48 8b 55 c0          	mov    -0x40(%rbp),%rdx
 101a643:	48 89 d0             	mov    %rdx,%rax
 101a646:	48 0f af c1          	imul   %rcx,%rax
 101a64a:	0f 80 a1 05 00 00    	jo     101abf1 <entry_run+0x2701>
 101a650:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
 101a654:	48 8b 55 d0          	mov    -0x30(%rbp),%rdx
 101a658:	48 89 d1             	mov    %rdx,%rcx
 101a65b:	48 01 c1             	add    %rax,%rcx
 101a65e:	0f 80 9a 05 00 00    	jo     101abfe <entry_run+0x270e>
 101a664:	48 89 c8             	mov    %rcx,%rax
 101a667:	48 ba 35 ce 5a 4e a2 	movabs $0x8637a2a24e5ace35,%rdx
 101a66e:	a2 37 86 
 101a671:	48 f7 ea             	imul   %rdx
 101a674:	48 c7 45 c0 43 42 0f 	movq   $0xf4243,-0x40(%rbp)
 101a67b:	00 
 101a67c:	48 01 ca             	add    %rcx,%rdx
 101a67f:	48 89 d0             	mov    %rdx,%rax
 101a682:	48 c1 e8 3f          	shr    $0x3f,%rax
 101a686:	48 c1 fa 13          	sar    $0x13,%rdx
 101a68a:	48 01 c2             	add    %rax,%rdx
 101a68d:	48 69 c2 43 42 0f 00 	imul   $0xf4243,%rdx,%rax
 101a694:	48 29 c1             	sub    %rax,%rcx
 101a697:	49 89 cd             	mov    %rcx,%r13
 101a69a:	49 c1 fd 3f          	sar    $0x3f,%r13
 101a69e:	41 81 e5 43 42 0f 00 	and    $0xf4243,%r13d
 101a6a5:	49 01 cd             	add    %rcx,%r13
 101a6a8:	4c 89 6d d0          	mov    %r13,-0x30(%rbp)
 101a6ac:	83 bd 68 ff ff ff 00 	cmpl   $0x0,-0x98(%rbp)
 101a6b3:	74 0f                	je     101a6c4 <entry_run+0x21d4>
 101a6b5:	48 89 df             	mov    %rbx,%rdi
 101a6b8:	48 8d b5 10 fe ff ff 	lea    -0x1f0(%rbp),%rsi
 101a6bf:	e8 cc 05 00 00       	call   101ac90 <myl_qbe_rc_slot_drop>
 101a6c4:	48 8b 55 b0          	mov    -0x50(%rbp),%rdx
 101a6c8:	48 89 55 d0          	mov    %rdx,-0x30(%rbp)
 101a6cc:	48 8b 85 10 ff ff ff 	mov    -0xf0(%rbp),%rax
 101a6d3:	48 39 10             	cmp    %rdx,(%rax)
 101a6d6:	0f 85 2f 05 00 00    	jne    101ac0b <entry_run+0x271b>
 101a6dc:	48 89 55 c0          	mov    %rdx,-0x40(%rbp)
 101a6e0:	31 c9                	xor    %ecx,%ecx
 101a6e2:	49 39 d4             	cmp    %rdx,%r12
 101a6e5:	0f 9c c1             	setl   %cl
 101a6e8:	48 89 4d d0          	mov    %rcx,-0x30(%rbp)
 101a6ec:	48 8b 8d 28 ff ff ff 	mov    -0xd8(%rbp),%rcx
 101a6f3:	4c 01 e1             	add    %r12,%rcx
 101a6f6:	48 ff c1             	inc    %rcx
 101a6f9:	49 ff c4             	inc    %r12
 101a6fc:	48 83 f9 01          	cmp    $0x1,%rcx
 101a700:	4c 89 fe             	mov    %r15,%rsi
 101a703:	0f 85 57 fd ff ff    	jne    101a460 <entry_run+0x1f70>
 101a709:	eb 24                	jmp    101a72f <entry_run+0x223f>
 101a70b:	be 13 74 00 01       	mov    $0x1007413,%esi
 101a710:	e9 9c eb ff ff       	jmp    10192b1 <entry_run+0xdc1>
 101a715:	c7 40 38 01 00 00 00 	movl   $0x1,0x38(%rax)
 101a71c:	48 83 7b 20 00       	cmpq   $0x0,0x20(%rbx)
 101a721:	0f 85 55 04 00 00    	jne    101ab7c <entry_run+0x268c>
 101a727:	e9 05 df ff ff       	jmp    1018631 <entry_run+0x141>
 101a72c:	45 31 ed             	xor    %r13d,%r13d
 101a72f:	48 c7 45 d0 01 00 00 	movq   $0x1,-0x30(%rbp)
 101a736:	00 
 101a737:	4c 89 6d c0          	mov    %r13,-0x40(%rbp)
 101a73b:	bf 01 00 00 00       	mov    $0x1,%edi
 101a740:	be 20 00 00 00       	mov    $0x20,%esi
 101a745:	e8 46 7a 01 00       	call   1032190 <calloc@plt>
 101a74a:	49 89 c7             	mov    %rax,%r15
 101a74d:	48 85 c0             	test   %rax,%rax
 101a750:	75 0c                	jne    101a75e <entry_run+0x226e>
 101a752:	48 89 df             	mov    %rbx,%rdi
 101a755:	e8 76 15 00 00       	call   101bcd0 <myl_qbe_fail_allocation>
 101a75a:	4c 8b 6d c0          	mov    -0x40(%rbp),%r13
 101a75e:	48 8d bd 40 fc ff ff 	lea    -0x3c0(%rbp),%rdi
 101a765:	be 18 00 00 00       	mov    $0x18,%esi
 101a76a:	ba 04 72 00 01       	mov    $0x1007204,%edx
 101a76f:	4c 89 e9             	mov    %r13,%rcx
 101a772:	31 c0                	xor    %eax,%eax
 101a774:	e8 47 7b 01 00       	call   10322c0 <snprintf@plt>
 101a779:	85 c0                	test   %eax,%eax
 101a77b:	0f 8e fb 01 00 00    	jle    101a97c <entry_run+0x248c>
 101a781:	41 89 c4             	mov    %eax,%r12d
 101a784:	bf 40 00 00 00       	mov    $0x40,%edi
 101a789:	83 f8 41             	cmp    $0x41,%eax
 101a78c:	0f 82 95 01 00 00    	jb     101a927 <entry_run+0x2437>
 101a792:	bf 80 00 00 00       	mov    $0x80,%edi
 101a797:	41 81 fc 81 00 00 00 	cmp    $0x81,%r12d
 101a79e:	0f 82 83 01 00 00    	jb     101a927 <entry_run+0x2437>
 101a7a4:	bf 00 01 00 00       	mov    $0x100,%edi
 101a7a9:	41 81 fc 01 01 00 00 	cmp    $0x101,%r12d
 101a7b0:	0f 82 71 01 00 00    	jb     101a927 <entry_run+0x2437>
 101a7b6:	bf 00 02 00 00       	mov    $0x200,%edi
 101a7bb:	41 81 fc 01 02 00 00 	cmp    $0x201,%r12d
 101a7c2:	0f 82 5f 01 00 00    	jb     101a927 <entry_run+0x2437>
 101a7c8:	bf 00 04 00 00       	mov    $0x400,%edi
 101a7cd:	41 81 fc 01 04 00 00 	cmp    $0x401,%r12d
 101a7d4:	0f 82 4d 01 00 00    	jb     101a927 <entry_run+0x2437>
 101a7da:	bf 00 08 00 00       	mov    $0x800,%edi
 101a7df:	41 81 fc 01 08 00 00 	cmp    $0x801,%r12d
 101a7e6:	0f 82 3b 01 00 00    	jb     101a927 <entry_run+0x2437>
 101a7ec:	bf 00 10 00 00       	mov    $0x1000,%edi
 101a7f1:	41 81 fc 01 10 00 00 	cmp    $0x1001,%r12d
 101a7f8:	0f 82 29 01 00 00    	jb     101a927 <entry_run+0x2437>
 101a7fe:	bf 00 20 00 00       	mov    $0x2000,%edi
 101a803:	41 81 fc 01 20 00 00 	cmp    $0x2001,%r12d
 101a80a:	0f 82 17 01 00 00    	jb     101a927 <entry_run+0x2437>
 101a810:	bf 00 40 00 00       	mov    $0x4000,%edi
 101a815:	41 81 fc 01 40 00 00 	cmp    $0x4001,%r12d
 101a81c:	0f 82 05 01 00 00    	jb     101a927 <entry_run+0x2437>
 101a822:	bf 00 80 00 00       	mov    $0x8000,%edi
 101a827:	41 81 fc 01 80 00 00 	cmp    $0x8001,%r12d
 101a82e:	0f 82 f3 00 00 00    	jb     101a927 <entry_run+0x2437>
 101a834:	bf 00 00 01 00       	mov    $0x10000,%edi
 101a839:	41 81 fc 01 00 01 00 	cmp    $0x10001,%r12d
 101a840:	0f 82 e1 00 00 00    	jb     101a927 <entry_run+0x2437>
 101a846:	bf 00 00 02 00       	mov    $0x20000,%edi
 101a84b:	41 81 fc 01 00 02 00 	cmp    $0x20001,%r12d
 101a852:	0f 82 cf 00 00 00    	jb     101a927 <entry_run+0x2437>
 101a858:	bf 00 00 04 00       	mov    $0x40000,%edi
 101a85d:	41 81 fc 01 00 04 00 	cmp    $0x40001,%r12d
 101a864:	0f 82 bd 00 00 00    	jb     101a927 <entry_run+0x2437>
 101a86a:	bf 00 00 08 00       	mov    $0x80000,%edi
 101a86f:	41 81 fc 01 00 08 00 	cmp    $0x80001,%r12d
 101a876:	0f 82 ab 00 00 00    	jb     101a927 <entry_run+0x2437>
 101a87c:	bf 00 00 10 00       	mov    $0x100000,%edi
 101a881:	41 81 fc 01 00 10 00 	cmp    $0x100001,%r12d
 101a888:	0f 82 99 00 00 00    	jb     101a927 <entry_run+0x2437>
 101a88e:	bf 00 00 20 00       	mov    $0x200000,%edi
 101a893:	41 81 fc 01 00 20 00 	cmp    $0x200001,%r12d
 101a89a:	0f 82 87 00 00 00    	jb     101a927 <entry_run+0x2437>
 101a8a0:	bf 00 00 40 00       	mov    $0x400000,%edi
 101a8a5:	41 81 fc 01 00 40 00 	cmp    $0x400001,%r12d
 101a8ac:	72 79                	jb     101a927 <entry_run+0x2437>
 101a8ae:	bf 00 00 80 00       	mov    $0x800000,%edi
 101a8b3:	41 81 fc 01 00 80 00 	cmp    $0x800001,%r12d
 101a8ba:	72 6b                	jb     101a927 <entry_run+0x2437>
 101a8bc:	bf 00 00 00 01       	mov    $0x1000000,%edi
 101a8c1:	41 81 fc 01 00 00 01 	cmp    $0x1000001,%r12d
 101a8c8:	72 5d                	jb     101a927 <entry_run+0x2437>
 101a8ca:	bf 00 00 00 02       	mov    $0x2000000,%edi
 101a8cf:	41 81 fc 01 00 00 02 	cmp    $0x2000001,%r12d
 101a8d6:	72 4f                	jb     101a927 <entry_run+0x2437>
 101a8d8:	bf 00 00 00 04       	mov    $0x4000000,%edi
 101a8dd:	41 81 fc 01 00 00 04 	cmp    $0x4000001,%r12d
 101a8e4:	72 41                	jb     101a927 <entry_run+0x2437>
 101a8e6:	bf 00 00 00 08       	mov    $0x8000000,%edi
 101a8eb:	41 81 fc 01 00 00 08 	cmp    $0x8000001,%r12d
 101a8f2:	72 33                	jb     101a927 <entry_run+0x2437>
 101a8f4:	bf 00 00 00 10       	mov    $0x10000000,%edi
 101a8f9:	41 81 fc 01 00 00 10 	cmp    $0x10000001,%r12d
 101a900:	72 25                	jb     101a927 <entry_run+0x2437>
 101a902:	bf 00 00 00 20       	mov    $0x20000000,%edi
 101a907:	41 81 fc 01 00 00 20 	cmp    $0x20000001,%r12d
 101a90e:	72 17                	jb     101a927 <entry_run+0x2437>
 101a910:	31 ff                	xor    %edi,%edi
 101a912:	41 81 fc 01 00 00 40 	cmp    $0x40000001,%r12d
 101a919:	40 0f 93 c7          	setae  %dil
 101a91d:	c1 e7 1e             	shl    $0x1e,%edi
 101a920:	48 81 c7 00 00 00 40 	add    $0x40000000,%rdi
 101a927:	49 89 fe             	mov    %rdi,%r14
 101a92a:	e8 51 78 01 00       	call   1032180 <malloc@plt>
 101a92f:	48 85 c0             	test   %rax,%rax
 101a932:	0f 84 cc 00 00 00    	je     101aa04 <entry_run+0x2514>
 101a938:	45 89 e4             	mov    %r12d,%r12d
 101a93b:	49 89 07             	mov    %rax,(%r15)
 101a93e:	4d 89 77 10          	mov    %r14,0x10(%r15)
 101a942:	48 8d b5 40 fc ff ff 	lea    -0x3c0(%rbp),%rsi
 101a949:	48 89 45 b8          	mov    %rax,-0x48(%rbp)
 101a94d:	48 89 c7             	mov    %rax,%rdi
 101a950:	4c 89 e2             	mov    %r12,%rdx
 101a953:	e8 e8 77 01 00       	call   1032140 <memcpy@plt>
 101a958:	4c 89 f6             	mov    %r14,%rsi
 101a95b:	4d 8d 77 08          	lea    0x8(%r15),%r14
 101a95f:	4d 89 67 08          	mov    %r12,0x8(%r15)
 101a963:	4d 89 fd             	mov    %r15,%r13
 101a966:	49 83 c5 18          	add    $0x18,%r13
 101a96a:	4c 39 e6             	cmp    %r12,%rsi
 101a96d:	0f 85 ac 00 00 00    	jne    101aa1f <entry_run+0x252f>
 101a973:	48 01 f6             	add    %rsi,%rsi
 101a976:	48 8b 7d b8          	mov    -0x48(%rbp),%rdi
 101a97a:	eb 12                	jmp    101a98e <entry_run+0x249e>
 101a97c:	4d 8d 6f 18          	lea    0x18(%r15),%r13
 101a980:	4d 89 fe             	mov    %r15,%r14
 101a983:	49 83 c6 08          	add    $0x8,%r14
 101a987:	be 40 00 00 00       	mov    $0x40,%esi
 101a98c:	31 ff                	xor    %edi,%edi
 101a98e:	49 89 f4             	mov    %rsi,%r12
 101a991:	e8 3a 79 01 00       	call   10322d0 <realloc@plt>
 101a996:	48 85 c0             	test   %rax,%rax
 101a999:	74 7a                	je     101aa15 <entry_run+0x2525>
 101a99b:	49 89 07             	mov    %rax,(%r15)
 101a99e:	4d 89 67 10          	mov    %r12,0x10(%r15)
 101a9a2:	4d 8b 67 08          	mov    0x8(%r15),%r12
 101a9a6:	eb 7b                	jmp    101aa23 <entry_run+0x2533>
 101a9a8:	48 8b 83 60 18 00 00 	mov    0x1860(%rbx),%rax
 101a9af:	48 85 c0             	test   %rax,%rax
 101a9b2:	0f 84 e3 01 00 00    	je     101ab9b <entry_run+0x26ab>
 101a9b8:	8b 70 78             	mov    0x78(%rax),%esi
 101a9bb:	c7 40 78 00 00 00 00 	movl   $0x0,0x78(%rax)
 101a9c2:	48 89 df             	mov    %rbx,%rdi
 101a9c5:	e8 76 02 00 00       	call   101ac40 <myl_qbe_rc_status>
 101a9ca:	4c 8d ab 58 02 00 00 	lea    0x258(%rbx),%r13
 101a9d1:	e9 e3 e8 ff ff       	jmp    10192b9 <entry_run+0xdc9>
 101a9d6:	48 8b 83 60 18 00 00 	mov    0x1860(%rbx),%rax
 101a9dd:	48 85 c0             	test   %rax,%rax
 101a9e0:	0f 84 b5 01 00 00    	je     101ab9b <entry_run+0x26ab>
 101a9e6:	8b 70 78             	mov    0x78(%rax),%esi
 101a9e9:	c7 40 78 00 00 00 00 	movl   $0x0,0x78(%rax)
 101a9f0:	48 89 df             	mov    %rbx,%rdi
 101a9f3:	e8 48 02 00 00       	call   101ac40 <myl_qbe_rc_status>
 101a9f8:	4c 8d ab 58 02 00 00 	lea    0x258(%rbx),%r13
 101a9ff:	e9 b5 e8 ff ff       	jmp    10192b9 <entry_run+0xdc9>
 101aa04:	4d 89 fd             	mov    %r15,%r13
 101aa07:	49 83 c5 18          	add    $0x18,%r13
 101aa0b:	41 c7 47 18 01 00 00 	movl   $0x1,0x18(%r15)
 101aa12:	00 
 101aa13:	eb 16                	jmp    101aa2b <entry_run+0x253b>
 101aa15:	41 c7 45 00 01 00 00 	movl   $0x1,0x0(%r13)
 101aa1c:	00 
 101aa1d:	eb 0c                	jmp    101aa2b <entry_run+0x253b>
 101aa1f:	48 8b 45 b8          	mov    -0x48(%rbp),%rax
 101aa23:	42 c6 04 20 0a       	movb   $0xa,(%rax,%r12,1)
 101aa28:	49 ff 06             	incq   (%r14)
 101aa2b:	41 83 7f 1c 00       	cmpl   $0x0,0x1c(%r15)
 101aa30:	4c 8d a5 e8 fe ff ff 	lea    -0x118(%rbp),%r12
 101aa37:	74 19                	je     101aa52 <entry_run+0x2562>
 101aa39:	be a7 6e 00 01       	mov    $0x1006ea7,%esi
 101aa3e:	48 89 df             	mov    %rbx,%rdi
 101aa41:	e8 da 0b 00 00       	call   101b620 <fail>
 101aa46:	4c 8d ab 58 02 00 00 	lea    0x258(%rbx),%r13
 101aa4d:	e9 80 00 00 00       	jmp    101aad2 <entry_run+0x25e2>
 101aa52:	41 83 7d 00 00       	cmpl   $0x0,0x0(%r13)
 101aa57:	74 11                	je     101aa6a <entry_run+0x257a>
 101aa59:	48 89 df             	mov    %rbx,%rdi
 101aa5c:	e8 6f 12 00 00       	call   101bcd0 <myl_qbe_fail_allocation>
 101aa61:	4c 8d ab 58 02 00 00 	lea    0x258(%rbx),%r13
 101aa68:	eb 68                	jmp    101aad2 <entry_run+0x25e2>
 101aa6a:	48 8b 05 1f 9a 01 00 	mov    0x19a1f(%rip),%rax        # 1034490 <stdout@GLIBC_2.2.5>
 101aa71:	4c 8b 30             	mov    (%rax),%r14
 101aa74:	4d 8b 67 08          	mov    0x8(%r15),%r12
 101aa78:	4d 85 e4             	test   %r12,%r12
 101aa7b:	4c 8d ab 58 02 00 00 	lea    0x258(%rbx),%r13
 101aa82:	74 18                	je     101aa9c <entry_run+0x25ac>
 101aa84:	49 8b 3f             	mov    (%r15),%rdi
 101aa87:	be 01 00 00 00       	mov    $0x1,%esi
 101aa8c:	4c 89 e2             	mov    %r12,%rdx
 101aa8f:	4c 89 f1             	mov    %r14,%rcx
 101aa92:	e8 a9 77 01 00       	call   1032240 <fwrite@plt>
 101aa97:	4c 39 e0             	cmp    %r12,%rax
 101aa9a:	75 22                	jne    101aabe <entry_run+0x25ce>
 101aa9c:	4c 89 f7             	mov    %r14,%rdi
 101aa9f:	e8 3c 78 01 00       	call   10322e0 <fflush@plt>
 101aaa4:	85 c0                	test   %eax,%eax
 101aaa6:	4c 8d a5 e8 fe ff ff 	lea    -0x118(%rbp),%r12
 101aaad:	74 23                	je     101aad2 <entry_run+0x25e2>
 101aaaf:	be d6 73 00 01       	mov    $0x10073d6,%esi
 101aab4:	48 89 df             	mov    %rbx,%rdi
 101aab7:	e8 64 0b 00 00       	call   101b620 <fail>
 101aabc:	eb 14                	jmp    101aad2 <entry_run+0x25e2>
 101aabe:	be d6 73 00 01       	mov    $0x10073d6,%esi
 101aac3:	48 89 df             	mov    %rbx,%rdi
 101aac6:	e8 55 0b 00 00       	call   101b620 <fail>
 101aacb:	4c 8d a5 e8 fe ff ff 	lea    -0x118(%rbp),%r12
 101aad2:	49 8b 3f             	mov    (%r15),%rdi
 101aad5:	e8 06 77 01 00       	call   10321e0 <free@plt>
 101aada:	4c 89 ff             	mov    %r15,%rdi
 101aadd:	e8 fe 76 01 00       	call   10321e0 <free@plt>
 101aae2:	48 c7 45 d0 00 00 00 	movq   $0x0,-0x30(%rbp)
 101aae9:	00 
 101aaea:	4c 39 a3 80 3d 00 00 	cmp    %r12,0x3d80(%rbx)
 101aaf1:	0f 85 a4 00 00 00    	jne    101ab9b <entry_run+0x26ab>
 101aaf7:	48 8b b5 00 ff ff ff 	mov    -0x100(%rbp),%rsi
 101aafe:	4c 89 ef             	mov    %r13,%rdi
 101ab01:	e8 3a f8 00 00       	call   102a340 <myl_rc_scope_unwind>
 101ab06:	4c 8b b5 f8 fe ff ff 	mov    -0x108(%rbp),%r14
 101ab0d:	4d 85 f6             	test   %r14,%r14
 101ab10:	74 3a                	je     101ab4c <entry_run+0x265c>
 101ab12:	4d 89 f7             	mov    %r14,%r15
 101ab15:	49 c1 e7 05          	shl    $0x5,%r15
 101ab19:	49 83 c7 e0          	add    $0xffffffffffffffe0,%r15
 101ab1d:	eb 15                	jmp    101ab34 <entry_run+0x2644>
 101ab1f:	90                   	nop
 101ab20:	4c 01 fe             	add    %r15,%rsi
 101ab23:	48 89 df             	mov    %rbx,%rdi
 101ab26:	e8 65 01 00 00       	call   101ac90 <myl_qbe_rc_slot_drop>
 101ab2b:	49 83 c7 e0          	add    $0xffffffffffffffe0,%r15
 101ab2f:	49 ff ce             	dec    %r14
 101ab32:	74 18                	je     101ab4c <entry_run+0x265c>
 101ab34:	48 8b b5 f0 fe ff ff 	mov    -0x110(%rbp),%rsi
 101ab3b:	4a 8b 44 3e 10       	mov    0x10(%rsi,%r15,1),%rax
 101ab40:	48 85 c0             	test   %rax,%rax
 101ab43:	74 db                	je     101ab20 <entry_run+0x2630>
 101ab45:	83 38 00             	cmpl   $0x0,(%rax)
 101ab48:	75 d6                	jne    101ab20 <entry_run+0x2630>
 101ab4a:	eb df                	jmp    101ab2b <entry_run+0x263b>
 101ab4c:	4c 39 a3 80 3d 00 00 	cmp    %r12,0x3d80(%rbx)
 101ab53:	75 46                	jne    101ab9b <entry_run+0x26ab>
 101ab55:	48 8b 83 60 18 00 00 	mov    0x1860(%rbx),%rax
 101ab5c:	48 85 c0             	test   %rax,%rax
 101ab5f:	74 2f                	je     101ab90 <entry_run+0x26a0>
 101ab61:	48 8b 40 70          	mov    0x70(%rax),%rax
 101ab65:	48 3b 85 00 ff ff ff 	cmp    -0x100(%rbp),%rax
 101ab6c:	75 2d                	jne    101ab9b <entry_run+0x26ab>
 101ab6e:	48 8b 85 e8 fe ff ff 	mov    -0x118(%rbp),%rax
 101ab75:	48 89 83 80 3d 00 00 	mov    %rax,0x3d80(%rbx)
 101ab7c:	31 c0                	xor    %eax,%eax
 101ab7e:	48 81 c4 a8 03 00 00 	add    $0x3a8,%rsp
 101ab85:	5b                   	pop    %rbx
 101ab86:	41 5c                	pop    %r12
 101ab88:	41 5d                	pop    %r13
 101ab8a:	41 5e                	pop    %r14
 101ab8c:	41 5f                	pop    %r15
 101ab8e:	5d                   	pop    %rbp
 101ab8f:	c3                   	ret
 101ab90:	31 c0                	xor    %eax,%eax
 101ab92:	48 3b 85 00 ff ff ff 	cmp    -0x100(%rbp),%rax
 101ab99:	74 d3                	je     101ab6e <entry_run+0x267e>
 101ab9b:	c5 f8 77             	vzeroupper
 101ab9e:	e8 5e b1 00 00       	call   1025d01 <myl_rc_invariant_failed>
 101aba3:	e8 48 77 01 00       	call   10322f0 <abort@plt>
 101aba8:	48 89 df             	mov    %rbx,%rdi
 101abab:	e8 20 11 00 00       	call   101bcd0 <myl_qbe_fail_allocation>
 101abb0:	48 89 df             	mov    %rbx,%rdi
 101abb3:	e8 18 11 00 00       	call   101bcd0 <myl_qbe_fail_allocation>
 101abb8:	48 89 df             	mov    %rbx,%rdi
 101abbb:	e8 10 11 00 00       	call   101bcd0 <myl_qbe_fail_allocation>
 101abc0:	48 89 df             	mov    %rbx,%rdi
 101abc3:	e8 b8 11 00 00       	call   101bd80 <myl_qbe_fail_normalized_index_bounds>
 101abc8:	b9 01 00 00 00       	mov    $0x1,%ecx
 101abcd:	48 89 df             	mov    %rbx,%rdi
 101abd0:	31 f6                	xor    %esi,%esi
 101abd2:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
 101abd9:	ff ff 7f 
 101abdc:	e8 ff 11 00 00       	call   101bde0 <myl_qbe_fail_overflow_op>
 101abe1:	48 89 df             	mov    %rbx,%rdi
 101abe4:	e8 e7 10 00 00       	call   101bcd0 <myl_qbe_fail_allocation>
 101abe9:	48 89 df             	mov    %rbx,%rdi
 101abec:	e8 6f 11 00 00       	call   101bd60 <myl_qbe_fail_missing_key>
 101abf1:	be 02 00 00 00       	mov    $0x2,%esi
 101abf6:	48 89 df             	mov    %rbx,%rdi
 101abf9:	e8 e2 11 00 00       	call   101bde0 <myl_qbe_fail_overflow_op>
 101abfe:	48 89 df             	mov    %rbx,%rdi
 101ac01:	31 f6                	xor    %esi,%esi
 101ac03:	48 89 c1             	mov    %rax,%rcx
 101ac06:	e8 d5 11 00 00       	call   101bde0 <myl_qbe_fail_overflow_op>
 101ac0b:	48 89 df             	mov    %rbx,%rdi
 101ac0e:	e8 5d 11 00 00       	call   101bd70 <myl_qbe_fail_iteration>
 101ac13:	48 89 df             	mov    %rbx,%rdi
 101ac16:	e8 b5 10 00 00       	call   101bcd0 <myl_qbe_fail_allocation>
 101ac1b:	83 78 78 00          	cmpl   $0x0,0x78(%rax)
 101ac1f:	75 07                	jne    101ac28 <entry_run+0x2738>
 101ac21:	c7 40 78 03 00 00 00 	movl   $0x3,0x78(%rax)
 101ac28:	48 89 df             	mov    %rbx,%rdi
 101ac2b:	e8 a0 10 00 00       	call   101bcd0 <myl_qbe_fail_allocation>
 101ac30:	48 89 df             	mov    %rbx,%rdi
 101ac33:	48 89 d6             	mov    %rdx,%rsi
 101ac36:	e8 05 12 00 00       	call   101be40 <myl_qbe_fail_cast>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
