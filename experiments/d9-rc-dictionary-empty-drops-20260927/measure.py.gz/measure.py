from pathlib import Path
import os,subprocess,json,hashlib,statistics,sys
r=Path.cwd();w=r/'.tmp-rc/dict-empty';phase=sys.argv[1]
cs={'before':r.parent/'d9-rc-integration/.tmp-rc/install-helpers-word/bin/mylang','after':r/'.tmp-rc/install-dict-empty-final/bin/mylang'}
s=r/'bench/parity/micro/dict_count.my';expected=s.with_suffix('.expected').read_text()
e={k:v for k,v in os.environ.items() if not k.startswith('MYLANG_') and k!='LD_PRELOAD'};e['TMPDIR']=str(r/'.tmp-rc/tmp')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
d=json.loads((w/'measurements.json').read_text()) if (w/'measurements.json').exists() else {'source':{'path':str(s),'sha256':sha(s)},'compilers':{k:{'path':str(c),'sha256':sha(c)} for k,c in cs.items()},'builds':[],'emission':[],'runs':[],'medians':{}}
def save():(w/'measurements.json').write_text(json.dumps(d,indent=2)+'\n')
if phase=='build':
 for side,c in cs.items():
  cmd=[str(r/'scripts/build-slot.sh'),'build',str(c),'emit-qbe',str(s),'--rc-runtime'];p=subprocess.run(cmd,env=e,text=True,capture_output=True);assert not p.returncode,p.stderr
  (w/(side+'-emission.json')).write_text(p.stdout);m=json.loads(p.stdout);fn=next(f for f in m['functions'] if f['name']=='main');il=fn['il'];(w/(side+'-main.ssa')).write_text(il)
  row=dict(side=side,command=cmd,sha256=hashlib.sha256(p.stdout.encode()).hexdigest(),markers=il.count('# RC-DICTIONARY-EMPTY-DROPS-1'),slot_drop=il.count('call $myl_qbe_rc_slot_drop'),unique=il.count('call $myl_qbe_rc_unique_local'))
  assert row['markers']==(5 if side=='after' else 0),row
  assert '%rcentries =l alloc8 416' in il and '%rcguards =l alloc8 104' in il,row
  d['emission'].append(row);save()
  for backend in ['qbe','llvm']:
   for stats in [False,True]:
    b=w/(side+'-'+backend+('-stats' if stats else '-rc'))
    cmd=[str(r/'scripts/build-slot.sh'),'build',str(c),'build',str(s),'-o',str(b),'--cache-dir='+str(w/('cache-'+side)),'--keep-symbols','--rc-runtime'+('=stats' if stats else ''),'--backend',backend,'--mode=ReleaseFast']
    if backend=='llvm':cmd+=['--llvm-opt=3','--lto=full']
    p=subprocess.run(cmd,env=e,text=True,capture_output=True);row=dict(side=side,backend=backend,stats=stats,command=cmd,status=p.returncode,stdout=p.stdout,stderr=p.stderr);d['builds'].append(row);save();assert not p.returncode,row
    manifest=json.loads(Path(str(b)+'.qbe-manifest.json').read_text());assert manifest['backend']==backend;row.update(binary_sha256=sha(b),manifest=manifest);save()
    if not stats:
     symbol=next(f['symbol'] for f in manifest['functions'] if f['name']=='main') if backend=='qbe' else 'entry_run'
     p=subprocess.run(['objdump','-d','--disassemble='+symbol,str(b)],text=True,capture_output=True,check=True);(w/(side+'-'+backend+'-main.asm')).write_text(p.stdout)
    print('built',side,backend,stats,flush=True)
else:
 assert phase=='measure'
 for backend in ['qbe','llvm']:
  for repeat in range(3):
   for side in ['gc','before','after']:
    b=r.parent/'d9-rc-performance/.tmp-rc-performance/bin/gc'/('parity-micro-dict_count.'+backend) if side=='gc' else w/(side+'-'+backend+'-rc')
    stat=w/(side+'-'+backend+'-'+str(repeat)+'.stat');cmd=['taskset','-c','11','perf','stat','-x,','-e','instructions:u','-o',str(stat),str(b)]
    p=subprocess.run(cmd,env=e,text=True,capture_output=True,timeout=600);raw=stat.read_text();lines=[x for x in raw.splitlines() if 'instructions' in x and x.split(',')[0].isdigit()];assert len(lines)==1,raw
    line=lines[0];n=int(line.split(',')[0]);assert float(line.split(',')[4])==100.0,line
    row=dict(side=side,backend=backend,repeat=repeat,command=cmd,status=p.returncode,stdout=p.stdout,stderr=p.stderr,perf=raw,instructions=n,binary_sha256=sha(b));d['runs'].append(row);save();assert not p.returncode and p.stdout==expected,row
  for side in ['gc','before','after']:
   d['medians'][side+'-'+backend]=statistics.median(x['instructions'] for x in d['runs'] if x['side']==side and x['backend']==backend and 'instructions' in x)
  for side in ['before','after']:
   b=w/(side+'-'+backend+'-stats');cmd=['taskset','-c','11',str(b)];p=subprocess.run(cmd,env=e,text=True,capture_output=True,timeout=600)
   row=dict(side=side,backend=backend,stats=True,command=cmd,status=p.returncode,stdout=p.stdout,stderr=p.stderr,binary_sha256=sha(b));d['runs'].append(row);save();assert not p.returncode and p.stdout==expected,row
   lines=[x.removeprefix('MYLANG_RC_COUNTS ') for x in p.stderr.splitlines() if x.startswith('MYLANG_RC_COUNTS ')];assert len(lines)==1,row
   c=json.loads(lines[0]);row['counts']=c;save();assert c['heap_allocate']==c['retire'] and c['hold_acquire']==c['hold_release'] and c['owner_acquire']+c['heap_allocate']==c['owner_release'],c
  rows=[x['counts'] for x in d['runs'] if x.get('stats') and x['backend']==backend];assert rows[0]==rows[1],rows
  save();print(backend,{k:v for k,v in d['medians'].items() if k.endswith(backend)},flush=True)
