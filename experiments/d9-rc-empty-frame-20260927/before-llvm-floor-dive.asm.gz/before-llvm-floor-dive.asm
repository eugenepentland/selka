
.tmp-rc/empty-frame/before-llvm-floor:     file format elf64-x86-64


Disassembly of section .text:

0000000001009be0 <myl_f_0f8897661f150233e7e27edda4e9754f6d6085f440055468118b41838e529fbd>:
 1009be0:	55                   	push   %rbp
 1009be1:	41 57                	push   %r15
 1009be3:	41 56                	push   %r14
 1009be5:	41 55                	push   %r13
 1009be7:	41 54                	push   %r12
 1009be9:	53                   	push   %rbx
 1009bea:	48 81 ec f8 01 00 00 	sub    $0x1f8,%rsp
 1009bf1:	48 89 fb             	mov    %rdi,%rbx
 1009bf4:	48 39 67 40          	cmp    %rsp,0x40(%rdi)
 1009bf8:	0f 87 e8 04 00 00    	ja     100a0e6 <myl_f_0f8897661f150233e7e27edda4e9754f6d6085f440055468118b41838e529fbd+0x506>
 1009bfe:	49 89 f4             	mov    %rsi,%r12
 1009c01:	48 89 74 24 40       	mov    %rsi,0x40(%rsp)
 1009c06:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
 1009c0a:	c5 fc 11 44 24 50    	vmovups %ymm0,0x50(%rsp)
 1009c10:	48 c7 84 24 b8 00 00 	movq   $0x1002098,0xb8(%rsp)
 1009c17:	00 98 20 00 01 
 1009c1c:	c7 84 24 d0 00 00 00 	movl   $0x2,0xd0(%rsp)
 1009c23:	02 00 00 00 
 1009c27:	48 8d 44 24 40       	lea    0x40(%rsp),%rax
 1009c2c:	48 89 84 24 c0 00 00 	mov    %rax,0xc0(%rsp)
 1009c33:	00 
 1009c34:	48 8d 44 24 50       	lea    0x50(%rsp),%rax
 1009c39:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
 1009c40:	00 
 1009c41:	48 c7 84 24 d8 00 00 	movq   $0x1001c38,0xd8(%rsp)
 1009c48:	00 38 1c 00 01 
 1009c4d:	c7 84 24 f0 00 00 00 	movl   $0x0,0xf0(%rsp)
 1009c54:	00 00 00 00 
 1009c58:	48 8d 84 24 c8 01 00 	lea    0x1c8(%rsp),%rax
 1009c5f:	00 
 1009c60:	48 89 84 24 e0 00 00 	mov    %rax,0xe0(%rsp)
 1009c67:	00 
 1009c68:	48 8d 44 24 58       	lea    0x58(%rsp),%rax
 1009c6d:	48 89 84 24 e8 00 00 	mov    %rax,0xe8(%rsp)
 1009c74:	00 
 1009c75:	48 c7 84 24 f8 00 00 	movq   $0x1001c38,0xf8(%rsp)
 1009c7c:	00 38 1c 00 01 
 1009c81:	c7 84 24 10 01 00 00 	movl   $0x0,0x110(%rsp)
 1009c88:	00 00 00 00 
 1009c8c:	48 8d 84 24 c0 01 00 	lea    0x1c0(%rsp),%rax
 1009c93:	00 
 1009c94:	48 89 84 24 00 01 00 	mov    %rax,0x100(%rsp)
 1009c9b:	00 
 1009c9c:	48 8d 44 24 60       	lea    0x60(%rsp),%rax
 1009ca1:	48 89 84 24 08 01 00 	mov    %rax,0x108(%rsp)
 1009ca8:	00 
 1009ca9:	48 c7 84 24 18 01 00 	movq   $0x1001c38,0x118(%rsp)
 1009cb0:	00 38 1c 00 01 
 1009cb5:	c7 84 24 30 01 00 00 	movl   $0x0,0x130(%rsp)
 1009cbc:	00 00 00 00 
 1009cc0:	48 8d 84 24 b8 01 00 	lea    0x1b8(%rsp),%rax
 1009cc7:	00 
 1009cc8:	48 89 84 24 20 01 00 	mov    %rax,0x120(%rsp)
 1009ccf:	00 
 1009cd0:	48 8d 44 24 68       	lea    0x68(%rsp),%rax
 1009cd5:	48 89 84 24 28 01 00 	mov    %rax,0x128(%rsp)
 1009cdc:	00 
 1009cdd:	48 85 db             	test   %rbx,%rbx
 1009ce0:	0f 84 f8 03 00 00    	je     100a0de <myl_f_0f8897661f150233e7e27edda4e9754f6d6085f440055468118b41838e529fbd+0x4fe>
 1009ce6:	48 8b 83 60 18 00 00 	mov    0x1860(%rbx),%rax
 1009ced:	48 85 c0             	test   %rax,%rax
 1009cf0:	0f 84 e8 03 00 00    	je     100a0de <myl_f_0f8897661f150233e7e27edda4e9754f6d6085f440055468118b41838e529fbd+0x4fe>
 1009cf6:	4c 8d bc 24 d8 00 00 	lea    0xd8(%rsp),%r15
 1009cfd:	00 
 1009cfe:	48 8b 8b 80 3d 00 00 	mov    0x3d80(%rbx),%rcx
 1009d05:	48 8b 70 70          	mov    0x70(%rax),%rsi
 1009d09:	48 89 4c 24 20       	mov    %rcx,0x20(%rsp)
 1009d0e:	48 8d 8c 24 b8 00 00 	lea    0xb8(%rsp),%rcx
 1009d15:	00 
 1009d16:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
 1009d1b:	48 c7 44 24 30 04 00 	movq   $0x4,0x30(%rsp)
 1009d22:	00 00 
 1009d24:	48 89 74 24 38       	mov    %rsi,0x38(%rsp)
 1009d29:	4c 8d 74 24 20       	lea    0x20(%rsp),%r14
 1009d2e:	4c 89 b3 80 3d 00 00 	mov    %r14,0x3d80(%rbx)
 1009d35:	48 85 d2             	test   %rdx,%rdx
 1009d38:	0f 84 d6 00 00 00    	je     1009e14 <myl_f_0f8897661f150233e7e27edda4e9754f6d6085f440055468118b41838e529fbd+0x234>
 1009d3e:	48 89 d1             	mov    %rdx,%rcx
 1009d41:	48 f7 d9             	neg    %rcx
 1009d44:	0f 80 a4 03 00 00    	jo     100a0ee <myl_f_0f8897661f150233e7e27edda4e9754f6d6085f440055468118b41838e529fbd+0x50e>
 1009d4a:	48 89 d5             	mov    %rdx,%rbp
 1009d4d:	4c 8d ab 58 02 00 00 	lea    0x258(%rbx),%r13
 1009d54:	48 8b 48 70          	mov    0x70(%rax),%rcx
 1009d58:	8b 93 c8 02 00 00    	mov    0x2c8(%rbx),%edx
 1009d5e:	4c 89 2c 24          	mov    %r13,(%rsp)
 1009d62:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
 1009d67:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
 1009d6e:	00 00 
 1009d70:	c7 44 24 18 01 00 00 	movl   $0x1,0x18(%rsp)
 1009d77:	00 
 1009d78:	89 54 24 1c          	mov    %edx,0x1c(%rsp)
 1009d7c:	48 89 e6             	mov    %rsp,%rsi
 1009d7f:	48 89 70 70          	mov    %rsi,0x70(%rax)
 1009d83:	48 89 df             	mov    %rbx,%rdi
 1009d86:	4c 89 e2             	mov    %r12,%rdx
 1009d89:	c5 f8 77             	vzeroupper
 1009d8c:	e8 4f 3a 00 00       	call   100d7e0 <myl_qbe_rc_scope_pin>
 1009d91:	85 c0                	test   %eax,%eax
 1009d93:	0f 84 6e 02 00 00    	je     100a007 <myl_f_0f8897661f150233e7e27edda4e9754f6d6085f440055468118b41838e529fbd+0x427>
 1009d99:	48 89 ea             	mov    %rbp,%rdx
 1009d9c:	48 ff ca             	dec    %rdx
 1009d9f:	48 89 df             	mov    %rbx,%rdi
 1009da2:	4c 89 e6             	mov    %r12,%rsi
 1009da5:	e8 36 fe ff ff       	call   1009be0 <myl_f_0f8897661f150233e7e27edda4e9754f6d6085f440055468118b41838e529fbd>
 1009daa:	49 89 c4             	mov    %rax,%r12
 1009dad:	83 7c 24 18 00       	cmpl   $0x0,0x18(%rsp)
 1009db2:	74 0a                	je     1009dbe <myl_f_0f8897661f150233e7e27edda4e9754f6d6085f440055468118b41838e529fbd+0x1de>
 1009db4:	4c 39 2c 24          	cmp    %r13,(%rsp)
 1009db8:	0f 85 20 03 00 00    	jne    100a0de <myl_f_0f8897661f150233e7e27edda4e9754f6d6085f440055468118b41838e529fbd+0x4fe>
 1009dbe:	48 89 e7             	mov    %rsp,%rdi
 1009dc1:	e8 9a d1 00 00       	call   1016f60 <myl_rc_scope_end>
 1009dc6:	83 7c 24 58 00       	cmpl   $0x0,0x58(%rsp)
 1009dcb:	74 0b                	je     1009dd8 <myl_f_0f8897661f150233e7e27edda4e9754f6d6085f440055468118b41838e529fbd+0x1f8>
 1009dcd:	48 89 df             	mov    %rbx,%rdi
 1009dd0:	4c 89 fe             	mov    %r15,%rsi
 1009dd3:	e8 a8 2a 00 00       	call   100c880 <myl_qbe_rc_slot_drop>
 1009dd8:	48 89 df             	mov    %rbx,%rdi
 1009ddb:	4c 89 f6             	mov    %r14,%rsi
 1009dde:	e8 bd 30 00 00       	call   100cea0 <myl_qbe_rc_frame_cleanup>
 1009de3:	4c 39 b3 80 3d 00 00 	cmp    %r14,0x3d80(%rbx)
 1009dea:	0f 85 ee 02 00 00    	jne    100a0de <myl_f_0f8897661f150233e7e27edda4e9754f6d6085f440055468118b41838e529fbd+0x4fe>
 1009df0:	48 8b 83 60 18 00 00 	mov    0x1860(%rbx),%rax
 1009df7:	48 85 c0             	test   %rax,%rax
 1009dfa:	0f 84 b4 02 00 00    	je     100a0b4 <myl_f_0f8897661f150233e7e27edda4e9754f6d6085f440055468118b41838e529fbd+0x4d4>
 1009e00:	48 8b 40 70          	mov    0x70(%rax),%rax
 1009e04:	48 3b 44 24 38       	cmp    0x38(%rsp),%rax
 1009e09:	0f 84 ae 02 00 00    	je     100a0bd <myl_f_0f8897661f150233e7e27edda4e9754f6d6085f440055468118b41838e529fbd+0x4dd>
 1009e0f:	e9 ca 02 00 00       	jmp    100a0de <myl_f_0f8897661f150233e7e27edda4e9754f6d6085f440055468118b41838e529fbd+0x4fe>
 1009e14:	48 8d ab 58 02 00 00 	lea    0x258(%rbx),%rbp
 1009e1b:	48 8b 48 70          	mov    0x70(%rax),%rcx
 1009e1f:	8b 93 c8 02 00 00    	mov    0x2c8(%rbx),%edx
 1009e25:	48 89 2c 24          	mov    %rbp,(%rsp)
 1009e29:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
 1009e2e:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
 1009e35:	00 00 
 1009e37:	c7 44 24 18 01 00 00 	movl   $0x1,0x18(%rsp)
 1009e3e:	00 
 1009e3f:	89 54 24 1c          	mov    %edx,0x1c(%rsp)
 1009e43:	48 89 e6             	mov    %rsp,%rsi
 1009e46:	48 89 70 70          	mov    %rsi,0x70(%rax)
 1009e4a:	48 89 df             	mov    %rbx,%rdi
 1009e4d:	4c 89 e2             	mov    %r12,%rdx
 1009e50:	c5 f8 77             	vzeroupper
 1009e53:	e8 88 39 00 00       	call   100d7e0 <myl_qbe_rc_scope_pin>
 1009e58:	85 c0                	test   %eax,%eax
 1009e5a:	0f 84 a7 01 00 00    	je     100a007 <myl_f_0f8897661f150233e7e27edda4e9754f6d6085f440055468118b41838e529fbd+0x427>
 1009e60:	4c 89 64 24 48       	mov    %r12,0x48(%rsp)
 1009e65:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
 1009e69:	c5 fc 11 84 24 90 00 	vmovups %ymm0,0x90(%rsp)
 1009e70:	00 00 
 1009e72:	48 c7 84 24 38 01 00 	movq   $0x1002098,0x138(%rsp)
 1009e79:	00 98 20 00 01 
 1009e7e:	c7 84 24 50 01 00 00 	movl   $0x2,0x150(%rsp)
 1009e85:	02 00 00 00 
 1009e89:	48 8d 44 24 48       	lea    0x48(%rsp),%rax
 1009e8e:	48 89 84 24 40 01 00 	mov    %rax,0x140(%rsp)
 1009e95:	00 
 1009e96:	48 8d 84 24 90 00 00 	lea    0x90(%rsp),%rax
 1009e9d:	00 
 1009e9e:	48 89 84 24 48 01 00 	mov    %rax,0x148(%rsp)
 1009ea5:	00 
 1009ea6:	48 c7 84 24 58 01 00 	movq   $0x1001c38,0x158(%rsp)
 1009ead:	00 38 1c 00 01 
 1009eb2:	c7 84 24 70 01 00 00 	movl   $0x0,0x170(%rsp)
 1009eb9:	00 00 00 00 
 1009ebd:	48 8d 84 24 e8 01 00 	lea    0x1e8(%rsp),%rax
 1009ec4:	00 
 1009ec5:	48 89 84 24 60 01 00 	mov    %rax,0x160(%rsp)
 1009ecc:	00 
 1009ecd:	48 8d 84 24 98 00 00 	lea    0x98(%rsp),%rax
 1009ed4:	00 
 1009ed5:	48 89 84 24 68 01 00 	mov    %rax,0x168(%rsp)
 1009edc:	00 
 1009edd:	48 c7 84 24 78 01 00 	movq   $0x1001c38,0x178(%rsp)
 1009ee4:	00 38 1c 00 01 
 1009ee9:	c7 84 24 90 01 00 00 	movl   $0x0,0x190(%rsp)
 1009ef0:	00 00 00 00 
 1009ef4:	48 8d 84 24 d8 01 00 	lea    0x1d8(%rsp),%rax
 1009efb:	00 
 1009efc:	48 89 84 24 80 01 00 	mov    %rax,0x180(%rsp)
 1009f03:	00 
 1009f04:	48 8d 84 24 a0 00 00 	lea    0xa0(%rsp),%rax
 1009f0b:	00 
 1009f0c:	48 89 84 24 88 01 00 	mov    %rax,0x188(%rsp)
 1009f13:	00 
 1009f14:	48 c7 84 24 98 01 00 	movq   $0x1001c38,0x198(%rsp)
 1009f1b:	00 38 1c 00 01 
 1009f20:	c7 84 24 b0 01 00 00 	movl   $0x0,0x1b0(%rsp)
 1009f27:	00 00 00 00 
 1009f2b:	48 8d 84 24 d0 01 00 	lea    0x1d0(%rsp),%rax
 1009f32:	00 
 1009f33:	48 89 84 24 a0 01 00 	mov    %rax,0x1a0(%rsp)
 1009f3a:	00 
 1009f3b:	48 8d 84 24 a8 00 00 	lea    0xa8(%rsp),%rax
 1009f42:	00 
 1009f43:	48 89 84 24 a8 01 00 	mov    %rax,0x1a8(%rsp)
 1009f4a:	00 
 1009f4b:	48 8b 83 60 18 00 00 	mov    0x1860(%rbx),%rax
 1009f52:	48 85 c0             	test   %rax,%rax
 1009f55:	0f 84 83 01 00 00    	je     100a0de <myl_f_0f8897661f150233e7e27edda4e9754f6d6085f440055468118b41838e529fbd+0x4fe>
 1009f5b:	48 8b 8b 80 3d 00 00 	mov    0x3d80(%rbx),%rcx
 1009f62:	48 8b 40 70          	mov    0x70(%rax),%rax
 1009f66:	48 89 4c 24 70       	mov    %rcx,0x70(%rsp)
 1009f6b:	48 8d 8c 24 38 01 00 	lea    0x138(%rsp),%rcx
 1009f72:	00 
 1009f73:	48 89 4c 24 78       	mov    %rcx,0x78(%rsp)
 1009f78:	48 c7 84 24 80 00 00 	movq   $0x4,0x80(%rsp)
 1009f7f:	00 04 00 00 00 
 1009f84:	48 89 84 24 88 00 00 	mov    %rax,0x88(%rsp)
 1009f8b:	00 
 1009f8c:	4c 8d 6c 24 70       	lea    0x70(%rsp),%r13
 1009f91:	4c 89 ab 80 3d 00 00 	mov    %r13,0x3d80(%rbx)
 1009f98:	49 83 3c 24 00       	cmpq   $0x0,(%r12)
 1009f9d:	0f 84 65 01 00 00    	je     100a108 <myl_f_0f8897661f150233e7e27edda4e9754f6d6085f440055468118b41838e529fbd+0x528>
 1009fa3:	49 8b 44 24 20       	mov    0x20(%r12),%rax
 1009fa8:	48 8b 10             	mov    (%rax),%rdx
 1009fab:	49 89 d4             	mov    %rdx,%r12
 1009fae:	49 ff c4             	inc    %r12
 1009fb1:	0f 80 5c 01 00 00    	jo     100a113 <myl_f_0f8897661f150233e7e27edda4e9754f6d6085f440055468118b41838e529fbd+0x533>
 1009fb7:	48 8b 48 08          	mov    0x8(%rax),%rcx
 1009fbb:	c7 84 24 a8 00 00 00 	movl   $0x0,0xa8(%rsp)
 1009fc2:	00 00 00 00 
 1009fc6:	4c 89 20             	mov    %r12,(%rax)
 1009fc9:	48 89 48 08          	mov    %rcx,0x8(%rax)
 1009fcd:	48 89 df             	mov    %rbx,%rdi
 1009fd0:	4c 89 ee             	mov    %r13,%rsi
 1009fd3:	c5 f8 77             	vzeroupper
 1009fd6:	e8 c5 2e 00 00       	call   100cea0 <myl_qbe_rc_frame_cleanup>
 1009fdb:	4c 39 ab 80 3d 00 00 	cmp    %r13,0x3d80(%rbx)
 1009fe2:	0f 85 f6 00 00 00    	jne    100a0de <myl_f_0f8897661f150233e7e27edda4e9754f6d6085f440055468118b41838e529fbd+0x4fe>
 1009fe8:	48 8b 83 60 18 00 00 	mov    0x1860(%rbx),%rax
 1009fef:	48 85 c0             	test   %rax,%rax
 1009ff2:	74 59                	je     100a04d <myl_f_0f8897661f150233e7e27edda4e9754f6d6085f440055468118b41838e529fbd+0x46d>
 1009ff4:	48 8b 40 70          	mov    0x70(%rax),%rax
 1009ff8:	48 3b 84 24 88 00 00 	cmp    0x88(%rsp),%rax
 1009fff:	00 
 100a000:	74 5b                	je     100a05d <myl_f_0f8897661f150233e7e27edda4e9754f6d6085f440055468118b41838e529fbd+0x47d>
 100a002:	e9 d7 00 00 00       	jmp    100a0de <myl_f_0f8897661f150233e7e27edda4e9754f6d6085f440055468118b41838e529fbd+0x4fe>
 100a007:	48 89 df             	mov    %rbx,%rdi
 100a00a:	4c 89 f6             	mov    %r14,%rsi
 100a00d:	e8 8e 2e 00 00       	call   100cea0 <myl_qbe_rc_frame_cleanup>
 100a012:	4c 39 b3 80 3d 00 00 	cmp    %r14,0x3d80(%rbx)
 100a019:	0f 85 bf 00 00 00    	jne    100a0de <myl_f_0f8897661f150233e7e27edda4e9754f6d6085f440055468118b41838e529fbd+0x4fe>
 100a01f:	48 8b 83 60 18 00 00 	mov    0x1860(%rbx),%rax
 100a026:	48 85 c0             	test   %rax,%rax
 100a029:	74 10                	je     100a03b <myl_f_0f8897661f150233e7e27edda4e9754f6d6085f440055468118b41838e529fbd+0x45b>
 100a02b:	48 8b 40 70          	mov    0x70(%rax),%rax
 100a02f:	48 3b 44 24 38       	cmp    0x38(%rsp),%rax
 100a034:	74 12                	je     100a048 <myl_f_0f8897661f150233e7e27edda4e9754f6d6085f440055468118b41838e529fbd+0x468>
 100a036:	e9 a3 00 00 00       	jmp    100a0de <myl_f_0f8897661f150233e7e27edda4e9754f6d6085f440055468118b41838e529fbd+0x4fe>
 100a03b:	31 c0                	xor    %eax,%eax
 100a03d:	48 3b 44 24 38       	cmp    0x38(%rsp),%rax
 100a042:	0f 85 96 00 00 00    	jne    100a0de <myl_f_0f8897661f150233e7e27edda4e9754f6d6085f440055468118b41838e529fbd+0x4fe>
 100a048:	45 31 e4             	xor    %r12d,%r12d
 100a04b:	eb 70                	jmp    100a0bd <myl_f_0f8897661f150233e7e27edda4e9754f6d6085f440055468118b41838e529fbd+0x4dd>
 100a04d:	31 c0                	xor    %eax,%eax
 100a04f:	48 3b 84 24 88 00 00 	cmp    0x88(%rsp),%rax
 100a056:	00 
 100a057:	0f 85 81 00 00 00    	jne    100a0de <myl_f_0f8897661f150233e7e27edda4e9754f6d6085f440055468118b41838e529fbd+0x4fe>
 100a05d:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
 100a062:	48 89 83 80 3d 00 00 	mov    %rax,0x3d80(%rbx)
 100a069:	83 7c 24 18 00       	cmpl   $0x0,0x18(%rsp)
 100a06e:	74 06                	je     100a076 <myl_f_0f8897661f150233e7e27edda4e9754f6d6085f440055468118b41838e529fbd+0x496>
 100a070:	48 39 2c 24          	cmp    %rbp,(%rsp)
 100a074:	75 68                	jne    100a0de <myl_f_0f8897661f150233e7e27edda4e9754f6d6085f440055468118b41838e529fbd+0x4fe>
 100a076:	48 89 e7             	mov    %rsp,%rdi
 100a079:	e8 e2 ce 00 00       	call   1016f60 <myl_rc_scope_end>
 100a07e:	83 7c 24 58 00       	cmpl   $0x0,0x58(%rsp)
 100a083:	74 0b                	je     100a090 <myl_f_0f8897661f150233e7e27edda4e9754f6d6085f440055468118b41838e529fbd+0x4b0>
 100a085:	48 89 df             	mov    %rbx,%rdi
 100a088:	4c 89 fe             	mov    %r15,%rsi
 100a08b:	e8 f0 27 00 00       	call   100c880 <myl_qbe_rc_slot_drop>
 100a090:	48 89 df             	mov    %rbx,%rdi
 100a093:	4c 89 f6             	mov    %r14,%rsi
 100a096:	e8 05 2e 00 00       	call   100cea0 <myl_qbe_rc_frame_cleanup>
 100a09b:	4c 39 b3 80 3d 00 00 	cmp    %r14,0x3d80(%rbx)
 100a0a2:	75 3a                	jne    100a0de <myl_f_0f8897661f150233e7e27edda4e9754f6d6085f440055468118b41838e529fbd+0x4fe>
 100a0a4:	48 8b 83 60 18 00 00 	mov    0x1860(%rbx),%rax
 100a0ab:	48 85 c0             	test   %rax,%rax
 100a0ae:	0f 85 4c fd ff ff    	jne    1009e00 <myl_f_0f8897661f150233e7e27edda4e9754f6d6085f440055468118b41838e529fbd+0x220>
 100a0b4:	31 c0                	xor    %eax,%eax
 100a0b6:	48 3b 44 24 38       	cmp    0x38(%rsp),%rax
 100a0bb:	75 21                	jne    100a0de <myl_f_0f8897661f150233e7e27edda4e9754f6d6085f440055468118b41838e529fbd+0x4fe>
 100a0bd:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
 100a0c2:	48 89 83 80 3d 00 00 	mov    %rax,0x3d80(%rbx)
 100a0c9:	4c 89 e0             	mov    %r12,%rax
 100a0cc:	48 81 c4 f8 01 00 00 	add    $0x1f8,%rsp
 100a0d3:	5b                   	pop    %rbx
 100a0d4:	41 5c                	pop    %r12
 100a0d6:	41 5d                	pop    %r13
 100a0d8:	41 5e                	pop    %r14
 100a0da:	41 5f                	pop    %r15
 100a0dc:	5d                   	pop    %rbp
 100a0dd:	c3                   	ret
 100a0de:	c5 f8 77             	vzeroupper
 100a0e1:	e8 2e 86 00 00       	call   1012714 <myl_rc_invariant_failed>
 100a0e6:	48 89 df             	mov    %rbx,%rdi
 100a0e9:	e8 b2 41 00 00       	call   100e2a0 <myl_qbe_fail_frame>
 100a0ee:	48 ba 00 00 00 00 00 	movabs $0x8000000000000000,%rdx
 100a0f5:	00 00 80 
 100a0f8:	be 01 00 00 00       	mov    $0x1,%esi
 100a0fd:	48 89 df             	mov    %rbx,%rdi
 100a100:	c5 f8 77             	vzeroupper
 100a103:	e8 28 41 00 00       	call   100e230 <myl_qbe_fail_overflow_op>
 100a108:	48 89 df             	mov    %rbx,%rdi
 100a10b:	c5 f8 77             	vzeroupper
 100a10e:	e8 bd 40 00 00       	call   100e1d0 <myl_qbe_fail_normalized_index_bounds>
 100a113:	48 89 df             	mov    %rbx,%rdi
 100a116:	31 f6                	xor    %esi,%esi
 100a118:	c5 f8 77             	vzeroupper
 100a11b:	e8 10 41 00 00       	call   100e230 <myl_qbe_fail_overflow_op>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
