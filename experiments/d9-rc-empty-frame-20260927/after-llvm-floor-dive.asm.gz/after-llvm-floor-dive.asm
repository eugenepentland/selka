
.tmp-rc/empty-frame/after-llvm-floor:     file format elf64-x86-64


Disassembly of section .text:

0000000001009bc0 <myl_f_0f8897661f150233e7e27edda4e9754f6d6085f440055468118b41838e529fbd>:
 1009bc0:	55                   	push   %rbp
 1009bc1:	41 57                	push   %r15
 1009bc3:	41 56                	push   %r14
 1009bc5:	41 55                	push   %r13
 1009bc7:	41 54                	push   %r12
 1009bc9:	53                   	push   %rbx
 1009bca:	48 81 ec 08 01 00 00 	sub    $0x108,%rsp
 1009bd1:	48 89 fb             	mov    %rdi,%rbx
 1009bd4:	48 39 67 40          	cmp    %rsp,0x40(%rdi)
 1009bd8:	0f 87 3d 03 00 00    	ja     1009f1b <myl_f_0f8897661f150233e7e27edda4e9754f6d6085f440055468118b41838e529fbd+0x35b>
 1009bde:	49 89 f4             	mov    %rsi,%r12
 1009be1:	48 89 74 24 48       	mov    %rsi,0x48(%rsp)
 1009be6:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
 1009bea:	c5 fc 11 44 24 50    	vmovups %ymm0,0x50(%rsp)
 1009bf0:	48 c7 44 24 70 98 20 	movq   $0x1002098,0x70(%rsp)
 1009bf7:	00 01 
 1009bf9:	c7 84 24 88 00 00 00 	movl   $0x2,0x88(%rsp)
 1009c00:	02 00 00 00 
 1009c04:	48 8d 44 24 48       	lea    0x48(%rsp),%rax
 1009c09:	48 89 44 24 78       	mov    %rax,0x78(%rsp)
 1009c0e:	48 8d 44 24 50       	lea    0x50(%rsp),%rax
 1009c13:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
 1009c1a:	00 
 1009c1b:	48 c7 84 24 90 00 00 	movq   $0x1001c38,0x90(%rsp)
 1009c22:	00 38 1c 00 01 
 1009c27:	c7 84 24 a8 00 00 00 	movl   $0x0,0xa8(%rsp)
 1009c2e:	00 00 00 00 
 1009c32:	48 8d 84 24 00 01 00 	lea    0x100(%rsp),%rax
 1009c39:	00 
 1009c3a:	48 89 84 24 98 00 00 	mov    %rax,0x98(%rsp)
 1009c41:	00 
 1009c42:	48 8d 44 24 58       	lea    0x58(%rsp),%rax
 1009c47:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
 1009c4e:	00 
 1009c4f:	48 c7 84 24 b0 00 00 	movq   $0x1001c38,0xb0(%rsp)
 1009c56:	00 38 1c 00 01 
 1009c5b:	c7 84 24 c8 00 00 00 	movl   $0x0,0xc8(%rsp)
 1009c62:	00 00 00 00 
 1009c66:	48 8d 84 24 f8 00 00 	lea    0xf8(%rsp),%rax
 1009c6d:	00 
 1009c6e:	48 89 84 24 b8 00 00 	mov    %rax,0xb8(%rsp)
 1009c75:	00 
 1009c76:	48 8d 44 24 60       	lea    0x60(%rsp),%rax
 1009c7b:	48 89 84 24 c0 00 00 	mov    %rax,0xc0(%rsp)
 1009c82:	00 
 1009c83:	48 c7 84 24 d0 00 00 	movq   $0x1001c38,0xd0(%rsp)
 1009c8a:	00 38 1c 00 01 
 1009c8f:	c7 84 24 e8 00 00 00 	movl   $0x0,0xe8(%rsp)
 1009c96:	00 00 00 00 
 1009c9a:	48 8d 84 24 f0 00 00 	lea    0xf0(%rsp),%rax
 1009ca1:	00 
 1009ca2:	48 89 84 24 d8 00 00 	mov    %rax,0xd8(%rsp)
 1009ca9:	00 
 1009caa:	48 8d 44 24 68       	lea    0x68(%rsp),%rax
 1009caf:	48 89 84 24 e0 00 00 	mov    %rax,0xe0(%rsp)
 1009cb6:	00 
 1009cb7:	48 85 db             	test   %rbx,%rbx
 1009cba:	0f 84 53 02 00 00    	je     1009f13 <myl_f_0f8897661f150233e7e27edda4e9754f6d6085f440055468118b41838e529fbd+0x353>
 1009cc0:	48 8b 83 60 18 00 00 	mov    0x1860(%rbx),%rax
 1009cc7:	48 85 c0             	test   %rax,%rax
 1009cca:	0f 84 43 02 00 00    	je     1009f13 <myl_f_0f8897661f150233e7e27edda4e9754f6d6085f440055468118b41838e529fbd+0x353>
 1009cd0:	4c 8d bc 24 90 00 00 	lea    0x90(%rsp),%r15
 1009cd7:	00 
 1009cd8:	48 8b 8b 80 3d 00 00 	mov    0x3d80(%rbx),%rcx
 1009cdf:	48 8b 70 70          	mov    0x70(%rax),%rsi
 1009ce3:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
 1009ce8:	48 8d 4c 24 70       	lea    0x70(%rsp),%rcx
 1009ced:	48 89 4c 24 30       	mov    %rcx,0x30(%rsp)
 1009cf2:	48 c7 44 24 38 04 00 	movq   $0x4,0x38(%rsp)
 1009cf9:	00 00 
 1009cfb:	48 89 74 24 40       	mov    %rsi,0x40(%rsp)
 1009d00:	4c 8d 74 24 28       	lea    0x28(%rsp),%r14
 1009d05:	4c 89 b3 80 3d 00 00 	mov    %r14,0x3d80(%rbx)
 1009d0c:	48 85 d2             	test   %rdx,%rdx
 1009d0f:	0f 84 dc 00 00 00    	je     1009df1 <myl_f_0f8897661f150233e7e27edda4e9754f6d6085f440055468118b41838e529fbd+0x231>
 1009d15:	48 89 d1             	mov    %rdx,%rcx
 1009d18:	48 f7 d9             	neg    %rcx
 1009d1b:	0f 80 02 02 00 00    	jo     1009f23 <myl_f_0f8897661f150233e7e27edda4e9754f6d6085f440055468118b41838e529fbd+0x363>
 1009d21:	48 89 d5             	mov    %rdx,%rbp
 1009d24:	4c 8d ab 58 02 00 00 	lea    0x258(%rbx),%r13
 1009d2b:	48 8b 48 70          	mov    0x70(%rax),%rcx
 1009d2f:	8b 93 c8 02 00 00    	mov    0x2c8(%rbx),%edx
 1009d35:	4c 89 6c 24 08       	mov    %r13,0x8(%rsp)
 1009d3a:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
 1009d3f:	48 c7 44 24 18 00 00 	movq   $0x0,0x18(%rsp)
 1009d46:	00 00 
 1009d48:	c7 44 24 20 01 00 00 	movl   $0x1,0x20(%rsp)
 1009d4f:	00 
 1009d50:	89 54 24 24          	mov    %edx,0x24(%rsp)
 1009d54:	48 8d 74 24 08       	lea    0x8(%rsp),%rsi
 1009d59:	48 89 70 70          	mov    %rsi,0x70(%rax)
 1009d5d:	48 89 df             	mov    %rbx,%rdi
 1009d60:	4c 89 e2             	mov    %r12,%rdx
 1009d63:	c5 f8 77             	vzeroupper
 1009d66:	e8 a5 38 00 00       	call   100d610 <myl_qbe_rc_scope_pin>
 1009d6b:	85 c0                	test   %eax,%eax
 1009d6d:	0f 84 48 01 00 00    	je     1009ebb <myl_f_0f8897661f150233e7e27edda4e9754f6d6085f440055468118b41838e529fbd+0x2fb>
 1009d73:	48 89 ea             	mov    %rbp,%rdx
 1009d76:	48 ff ca             	dec    %rdx
 1009d79:	48 89 df             	mov    %rbx,%rdi
 1009d7c:	4c 89 e6             	mov    %r12,%rsi
 1009d7f:	e8 3c fe ff ff       	call   1009bc0 <myl_f_0f8897661f150233e7e27edda4e9754f6d6085f440055468118b41838e529fbd>
 1009d84:	49 89 c4             	mov    %rax,%r12
 1009d87:	83 7c 24 20 00       	cmpl   $0x0,0x20(%rsp)
 1009d8c:	74 0b                	je     1009d99 <myl_f_0f8897661f150233e7e27edda4e9754f6d6085f440055468118b41838e529fbd+0x1d9>
 1009d8e:	4c 39 6c 24 08       	cmp    %r13,0x8(%rsp)
 1009d93:	0f 85 7a 01 00 00    	jne    1009f13 <myl_f_0f8897661f150233e7e27edda4e9754f6d6085f440055468118b41838e529fbd+0x353>
 1009d99:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
 1009d9e:	e8 ed cf 00 00       	call   1016d90 <myl_rc_scope_end>
 1009da3:	83 7c 24 58 00       	cmpl   $0x0,0x58(%rsp)
 1009da8:	74 0b                	je     1009db5 <myl_f_0f8897661f150233e7e27edda4e9754f6d6085f440055468118b41838e529fbd+0x1f5>
 1009daa:	48 89 df             	mov    %rbx,%rdi
 1009dad:	4c 89 fe             	mov    %r15,%rsi
 1009db0:	e8 fb 28 00 00       	call   100c6b0 <myl_qbe_rc_slot_drop>
 1009db5:	48 89 df             	mov    %rbx,%rdi
 1009db8:	4c 89 f6             	mov    %r14,%rsi
 1009dbb:	e8 10 2f 00 00       	call   100ccd0 <myl_qbe_rc_frame_cleanup>
 1009dc0:	4c 39 b3 80 3d 00 00 	cmp    %r14,0x3d80(%rbx)
 1009dc7:	0f 85 46 01 00 00    	jne    1009f13 <myl_f_0f8897661f150233e7e27edda4e9754f6d6085f440055468118b41838e529fbd+0x353>
 1009dcd:	48 8b 83 60 18 00 00 	mov    0x1860(%rbx),%rax
 1009dd4:	48 85 c0             	test   %rax,%rax
 1009dd7:	0f 84 d3 00 00 00    	je     1009eb0 <myl_f_0f8897661f150233e7e27edda4e9754f6d6085f440055468118b41838e529fbd+0x2f0>
 1009ddd:	48 8b 40 70          	mov    0x70(%rax),%rax
 1009de1:	48 3b 44 24 40       	cmp    0x40(%rsp),%rax
 1009de6:	0f 84 fd 00 00 00    	je     1009ee9 <myl_f_0f8897661f150233e7e27edda4e9754f6d6085f440055468118b41838e529fbd+0x329>
 1009dec:	e9 22 01 00 00       	jmp    1009f13 <myl_f_0f8897661f150233e7e27edda4e9754f6d6085f440055468118b41838e529fbd+0x353>
 1009df1:	4c 8d ab 58 02 00 00 	lea    0x258(%rbx),%r13
 1009df8:	48 8b 48 70          	mov    0x70(%rax),%rcx
 1009dfc:	8b 93 c8 02 00 00    	mov    0x2c8(%rbx),%edx
 1009e02:	4c 89 6c 24 08       	mov    %r13,0x8(%rsp)
 1009e07:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
 1009e0c:	48 c7 44 24 18 00 00 	movq   $0x0,0x18(%rsp)
 1009e13:	00 00 
 1009e15:	c7 44 24 20 01 00 00 	movl   $0x1,0x20(%rsp)
 1009e1c:	00 
 1009e1d:	89 54 24 24          	mov    %edx,0x24(%rsp)
 1009e21:	48 8d 74 24 08       	lea    0x8(%rsp),%rsi
 1009e26:	48 89 70 70          	mov    %rsi,0x70(%rax)
 1009e2a:	48 89 df             	mov    %rbx,%rdi
 1009e2d:	4c 89 e2             	mov    %r12,%rdx
 1009e30:	c5 f8 77             	vzeroupper
 1009e33:	e8 d8 37 00 00       	call   100d610 <myl_qbe_rc_scope_pin>
 1009e38:	85 c0                	test   %eax,%eax
 1009e3a:	74 7f                	je     1009ebb <myl_f_0f8897661f150233e7e27edda4e9754f6d6085f440055468118b41838e529fbd+0x2fb>
 1009e3c:	49 83 3c 24 00       	cmpq   $0x0,(%r12)
 1009e41:	0f 84 f6 00 00 00    	je     1009f3d <myl_f_0f8897661f150233e7e27edda4e9754f6d6085f440055468118b41838e529fbd+0x37d>
 1009e47:	49 8b 44 24 20       	mov    0x20(%r12),%rax
 1009e4c:	48 8b 10             	mov    (%rax),%rdx
 1009e4f:	49 89 d4             	mov    %rdx,%r12
 1009e52:	49 ff c4             	inc    %r12
 1009e55:	0f 80 ea 00 00 00    	jo     1009f45 <myl_f_0f8897661f150233e7e27edda4e9754f6d6085f440055468118b41838e529fbd+0x385>
 1009e5b:	4c 89 20             	mov    %r12,(%rax)
 1009e5e:	83 7c 24 20 00       	cmpl   $0x0,0x20(%rsp)
 1009e63:	74 0b                	je     1009e70 <myl_f_0f8897661f150233e7e27edda4e9754f6d6085f440055468118b41838e529fbd+0x2b0>
 1009e65:	4c 39 6c 24 08       	cmp    %r13,0x8(%rsp)
 1009e6a:	0f 85 a3 00 00 00    	jne    1009f13 <myl_f_0f8897661f150233e7e27edda4e9754f6d6085f440055468118b41838e529fbd+0x353>
 1009e70:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
 1009e75:	e8 16 cf 00 00       	call   1016d90 <myl_rc_scope_end>
 1009e7a:	83 7c 24 58 00       	cmpl   $0x0,0x58(%rsp)
 1009e7f:	74 0b                	je     1009e8c <myl_f_0f8897661f150233e7e27edda4e9754f6d6085f440055468118b41838e529fbd+0x2cc>
 1009e81:	48 89 df             	mov    %rbx,%rdi
 1009e84:	4c 89 fe             	mov    %r15,%rsi
 1009e87:	e8 24 28 00 00       	call   100c6b0 <myl_qbe_rc_slot_drop>
 1009e8c:	48 89 df             	mov    %rbx,%rdi
 1009e8f:	4c 89 f6             	mov    %r14,%rsi
 1009e92:	e8 39 2e 00 00       	call   100ccd0 <myl_qbe_rc_frame_cleanup>
 1009e97:	4c 39 b3 80 3d 00 00 	cmp    %r14,0x3d80(%rbx)
 1009e9e:	75 73                	jne    1009f13 <myl_f_0f8897661f150233e7e27edda4e9754f6d6085f440055468118b41838e529fbd+0x353>
 1009ea0:	48 8b 83 60 18 00 00 	mov    0x1860(%rbx),%rax
 1009ea7:	48 85 c0             	test   %rax,%rax
 1009eaa:	0f 85 2d ff ff ff    	jne    1009ddd <myl_f_0f8897661f150233e7e27edda4e9754f6d6085f440055468118b41838e529fbd+0x21d>
 1009eb0:	31 c0                	xor    %eax,%eax
 1009eb2:	48 3b 44 24 40       	cmp    0x40(%rsp),%rax
 1009eb7:	74 30                	je     1009ee9 <myl_f_0f8897661f150233e7e27edda4e9754f6d6085f440055468118b41838e529fbd+0x329>
 1009eb9:	eb 58                	jmp    1009f13 <myl_f_0f8897661f150233e7e27edda4e9754f6d6085f440055468118b41838e529fbd+0x353>
 1009ebb:	48 89 df             	mov    %rbx,%rdi
 1009ebe:	4c 89 f6             	mov    %r14,%rsi
 1009ec1:	e8 0a 2e 00 00       	call   100ccd0 <myl_qbe_rc_frame_cleanup>
 1009ec6:	4c 39 b3 80 3d 00 00 	cmp    %r14,0x3d80(%rbx)
 1009ecd:	75 44                	jne    1009f13 <myl_f_0f8897661f150233e7e27edda4e9754f6d6085f440055468118b41838e529fbd+0x353>
 1009ecf:	48 8b 83 60 18 00 00 	mov    0x1860(%rbx),%rax
 1009ed6:	48 85 c0             	test   %rax,%rax
 1009ed9:	74 2f                	je     1009f0a <myl_f_0f8897661f150233e7e27edda4e9754f6d6085f440055468118b41838e529fbd+0x34a>
 1009edb:	48 8b 40 70          	mov    0x70(%rax),%rax
 1009edf:	48 3b 44 24 40       	cmp    0x40(%rsp),%rax
 1009ee4:	75 2d                	jne    1009f13 <myl_f_0f8897661f150233e7e27edda4e9754f6d6085f440055468118b41838e529fbd+0x353>
 1009ee6:	45 31 e4             	xor    %r12d,%r12d
 1009ee9:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
 1009eee:	48 89 83 80 3d 00 00 	mov    %rax,0x3d80(%rbx)
 1009ef5:	4c 89 e0             	mov    %r12,%rax
 1009ef8:	48 81 c4 08 01 00 00 	add    $0x108,%rsp
 1009eff:	5b                   	pop    %rbx
 1009f00:	41 5c                	pop    %r12
 1009f02:	41 5d                	pop    %r13
 1009f04:	41 5e                	pop    %r14
 1009f06:	41 5f                	pop    %r15
 1009f08:	5d                   	pop    %rbp
 1009f09:	c3                   	ret
 1009f0a:	31 c0                	xor    %eax,%eax
 1009f0c:	48 3b 44 24 40       	cmp    0x40(%rsp),%rax
 1009f11:	74 d3                	je     1009ee6 <myl_f_0f8897661f150233e7e27edda4e9754f6d6085f440055468118b41838e529fbd+0x326>
 1009f13:	c5 f8 77             	vzeroupper
 1009f16:	e8 29 86 00 00       	call   1012544 <myl_rc_invariant_failed>
 1009f1b:	48 89 df             	mov    %rbx,%rdi
 1009f1e:	e8 ad 41 00 00       	call   100e0d0 <myl_qbe_fail_frame>
 1009f23:	48 ba 00 00 00 00 00 	movabs $0x8000000000000000,%rdx
 1009f2a:	00 00 80 
 1009f2d:	be 01 00 00 00       	mov    $0x1,%esi
 1009f32:	48 89 df             	mov    %rbx,%rdi
 1009f35:	c5 f8 77             	vzeroupper
 1009f38:	e8 23 41 00 00       	call   100e060 <myl_qbe_fail_overflow_op>
 1009f3d:	48 89 df             	mov    %rbx,%rdi
 1009f40:	e8 bb 40 00 00       	call   100e000 <myl_qbe_fail_normalized_index_bounds>
 1009f45:	48 89 df             	mov    %rbx,%rdi
 1009f48:	31 f6                	xor    %esi,%esi
 1009f4a:	e8 11 41 00 00       	call   100e060 <myl_qbe_fail_overflow_op>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
