
.mylang-cache/goal110-join-short/runner/bin/text-my-llvm:     file format elf64-x86-64


Disassembly of section .text:

0000000001090f30 <index_walk>:
 1090f30:	push   %rbp
 1090f31:	mov    %rsp,%rbp
 1090f34:	push   %r15
 1090f36:	push   %r14
 1090f38:	push   %rbx
 1090f39:	push   %rax
 1090f3a:	mov    0x8(%rdi),%rdx
 1090f3e:	mov    %rdx,%rax
 1090f41:	sub    %rsi,%rax
 1090f44:	jbe    1090faa <index_walk+0x7a>
 1090f46:	mov    0x10(%rdi),%r9d
 1090f4a:	lea    0x18(%rdi),%r8
 1090f4e:	mov    %r8,%rcx
 1090f51:	test   $0x4,%r9b
 1090f55:	je     1090f66 <index_walk+0x36>
 1090f57:	mov    0x18(%rdi),%rcx
 1090f5b:	mov    0x14(%rdi),%r10d
 1090f5f:	add    %r10,%rcx
 1090f62:	add    $0x18,%rcx
 1090f66:	cmp    %rax,%rsi
 1090f69:	mov    %rax,%r10
 1090f6c:	cmovb  %rsi,%r10
 1090f70:	cmp    $0x401,%r10
 1090f77:	jb     1090f97 <index_walk+0x67>
 1090f79:	test   $0x8,%r9b
 1090f7d:	jne    1090fc5 <index_walk+0x95>
 1090f7f:	test   $0x4,%r9b
 1090f83:	je     1090f97 <index_walk+0x67>
 1090f85:	mov    (%r8),%rbx
 1090f88:	test   %rbx,%rbx
 1090f8b:	je     1090f97 <index_walk+0x67>
 1090f8d:	testb  $0x8,0x10(%rbx)
 1090f91:	jne    1091567 <index_walk+0x637>
 1090f97:	cmp    %rax,%rsi
 1090f9a:	jbe    1090fb2 <index_walk+0x82>
 1090f9c:	lea    0x8(%rsi),%rax
 1090fa0:	cmp    %rdx,%rax
 1090fa3:	jbe    1090fd4 <index_walk+0xa4>
 1090fa5:	xor    %r8d,%r8d
 1090fa8:	jmp    1091026 <index_walk+0xf6>
 1090faa:	mov    (%rdi),%rax
 1090fad:	jmp    1091590 <index_walk+0x660>
 1090fb2:	cmp    $0x8,%rsi
 1090fb6:	jae    1091051 <index_walk+0x121>
 1090fbc:	xor    %eax,%eax
 1090fbe:	xor    %edx,%edx
 1090fc0:	jmp    1091279 <index_walk+0x349>
 1090fc5:	add    $0x8,%rsp
 1090fc9:	pop    %rbx
 1090fca:	pop    %r14
 1090fcc:	pop    %r15
 1090fce:	pop    %rbp
 1090fcf:	jmp    10915b0 <index_at>
 1090fd4:	movabs $0x101010101010101,%rax
 1090fde:	xor    %r8d,%r8d
 1090fe1:	mov    %rsi,%r9
 1090fe4:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 1090ff0:	mov    (%rcx,%r9,1),%rsi
 1090ff4:	mov    %rsi,%r10
 1090ff7:	not    %r10
 1090ffa:	add    %r10,%r10
 1090ffd:	and    %rsi,%r10
 1091000:	shr    $0x7,%r10
 1091004:	and    %rax,%r10
 1091007:	imul   %rax,%r10
 109100b:	shr    $0x38,%r10
 109100f:	sub    %r10,%r8
 1091012:	add    $0x8,%r8
 1091016:	lea    0x8(%r9),%rsi
 109101a:	add    $0x10,%r9
 109101e:	cmp    %rdx,%r9
 1091021:	mov    %rsi,%r9
 1091024:	jbe    1090ff0 <index_walk+0xc0>
 1091026:	mov    (%rdi),%rax
 1091029:	mov    %rdx,%rdi
 109102c:	sub    %rsi,%rdi
 109102f:	jbe    10913f5 <index_walk+0x4c5>
 1091035:	cmp    $0x3,%rdi
 1091039:	jbe    10913e0 <index_walk+0x4b0>
 109103f:	cmp    $0x10,%rdi
 1091043:	jae    10912a1 <index_walk+0x371>
 1091049:	xor    %r9d,%r9d
 109104c:	jmp    109137f <index_walk+0x44f>
 1091051:	lea    -0x8(%rsi),%r8
 1091055:	cmp    $0x78,%r8
 1091059:	jae    1091069 <index_walk+0x139>
 109105b:	mov    $0x8,%edi
 1091060:	xor    %edx,%edx
 1091062:	xor    %eax,%eax
 1091064:	jmp    1091231 <index_walk+0x301>
 1091069:	shr    $0x3,%r8
 109106d:	inc    %r8
 1091070:	mov    %r8,%r9
 1091073:	and    $0xfffffffffffffff0,%r9
 1091077:	lea    0x0(,%r9,8),%rdx
 109107f:	lea    0x8(,%r9,8),%rdi
 1091087:	vpxor  %xmm2,%xmm2,%xmm2
 109108b:	xor    %eax,%eax
 109108d:	vpbroadcastq -0x89f56(%rip),%ymm0        # 1007140 <__abi_tag+0x6e44>
 1091096:	vpbroadcastq -0x89f57(%rip),%ymm1        # 1007148 <__abi_tag+0x6e4c>
 109109f:	vpbroadcastq -0x89fd8(%rip),%ymm3        # 10070d0 <__abi_tag+0x6dd4>
 10910a8:	vpcmpeqd %ymm4,%ymm4,%ymm4
 10910ac:	vpxor  %xmm7,%xmm7,%xmm7
 10910b0:	vpxor  %xmm6,%xmm6,%xmm6
 10910b4:	vpxor  %xmm5,%xmm5,%xmm5
 10910b8:	nopl   0x0(%rax,%rax,1)
 10910c0:	vmovdqu (%rcx,%rax,8),%ymm8
 10910c5:	vmovdqu 0x20(%rcx,%rax,8),%ymm9
 10910cb:	vmovdqu 0x40(%rcx,%rax,8),%ymm10
 10910d1:	vmovdqu 0x60(%rcx,%rax,8),%ymm11
 10910d7:	vpxor  %ymm4,%ymm8,%ymm12
 10910db:	vpaddq %ymm12,%ymm12,%ymm12
 10910e0:	vpxor  %ymm4,%ymm9,%ymm13
 10910e4:	vpaddq %ymm13,%ymm13,%ymm13
 10910e9:	vpxor  %ymm4,%ymm10,%ymm14
 10910ed:	vpaddq %ymm14,%ymm14,%ymm14
 10910f2:	vpxor  %ymm4,%ymm11,%ymm15
 10910f6:	vpaddq %ymm15,%ymm15,%ymm15
 10910fb:	vpand  %ymm12,%ymm8,%ymm8
 1091100:	vpand  %ymm13,%ymm9,%ymm9
 1091105:	vpand  %ymm14,%ymm10,%ymm10
 109110a:	vpand  %ymm15,%ymm11,%ymm11
 109110f:	vpsrlq $0x7,%ymm8,%ymm8
 1091115:	vpsrlq $0x7,%ymm9,%ymm9
 109111b:	vpsrlq $0x7,%ymm10,%ymm10
 1091121:	vpsrlq $0x7,%ymm11,%ymm11
 1091127:	vpand  %ymm0,%ymm8,%ymm8
 109112b:	vpand  %ymm0,%ymm9,%ymm9
 109112f:	vpand  %ymm0,%ymm10,%ymm10
 1091133:	vpand  %ymm0,%ymm11,%ymm11
 1091137:	vpmuludq %ymm1,%ymm8,%ymm12
 109113b:	vpsrlq $0x20,%ymm8,%ymm13
 1091141:	vpmuludq %ymm0,%ymm13,%ymm13
 1091145:	vpaddq %ymm13,%ymm12,%ymm12
 109114a:	vpsllq $0x20,%ymm12,%ymm12
 1091150:	vpmuludq %ymm0,%ymm8,%ymm8
 1091154:	vpaddq %ymm12,%ymm8,%ymm8
 1091159:	vpmuludq %ymm1,%ymm9,%ymm12
 109115d:	vpsrlq $0x20,%ymm9,%ymm13
 1091163:	vpmuludq %ymm0,%ymm13,%ymm13
 1091167:	vpaddq %ymm13,%ymm12,%ymm12
 109116c:	vpsllq $0x20,%ymm12,%ymm12
 1091172:	vpmuludq %ymm0,%ymm9,%ymm9
 1091176:	vpaddq %ymm12,%ymm9,%ymm9
 109117b:	vpmuludq %ymm1,%ymm10,%ymm12
 109117f:	vpsrlq $0x20,%ymm10,%ymm13
 1091185:	vpmuludq %ymm0,%ymm13,%ymm13
 1091189:	vpaddq %ymm13,%ymm12,%ymm12
 109118e:	vpsllq $0x20,%ymm12,%ymm12
 1091194:	vpmuludq %ymm0,%ymm10,%ymm10
 1091198:	vpaddq %ymm12,%ymm10,%ymm10
 109119d:	vpmuludq %ymm1,%ymm11,%ymm12
 10911a1:	vpsrlq $0x20,%ymm11,%ymm13
 10911a7:	vpmuludq %ymm0,%ymm13,%ymm13
 10911ab:	vpaddq %ymm13,%ymm12,%ymm12
 10911b0:	vpsllq $0x20,%ymm12,%ymm12
 10911b6:	vpmuludq %ymm0,%ymm11,%ymm11
 10911ba:	vpaddq %ymm12,%ymm11,%ymm11
 10911bf:	vpsrlq $0x38,%ymm8,%ymm8
 10911c5:	vpsubq %ymm8,%ymm2,%ymm2
 10911ca:	vpsrlq $0x38,%ymm9,%ymm8
 10911d0:	vpsubq %ymm8,%ymm7,%ymm7
 10911d5:	vpsrlq $0x38,%ymm10,%ymm8
 10911db:	vpsubq %ymm8,%ymm6,%ymm6
 10911e0:	vpsrlq $0x38,%ymm11,%ymm8
 10911e6:	vpsubq %ymm8,%ymm5,%ymm5
 10911eb:	vpaddq %ymm3,%ymm2,%ymm2
 10911ef:	vpaddq %ymm3,%ymm7,%ymm7
 10911f3:	vpaddq %ymm3,%ymm6,%ymm6
 10911f7:	vpaddq %ymm3,%ymm5,%ymm5
 10911fb:	add    $0x10,%rax
 10911ff:	cmp    %rax,%r9
 1091202:	jne    10910c0 <index_walk+0x190>
 1091208:	vpaddq %ymm2,%ymm7,%ymm0
 109120c:	vpaddq %ymm0,%ymm6,%ymm0
 1091210:	vpaddq %ymm0,%ymm5,%ymm0
 1091214:	vextracti128 $0x1,%ymm0,%xmm1
 109121a:	vpaddq %xmm1,%xmm0,%xmm0
 109121e:	vpshufd $0xee,%xmm0,%xmm1
 1091223:	vpaddq %xmm1,%xmm0,%xmm0
 1091227:	vmovq  %xmm0,%rax
 109122c:	cmp    %r9,%r8
 109122f:	je     1091279 <index_walk+0x349>
 1091231:	movabs $0x101010101010101,%r8
 109123b:	nopl   0x0(%rax,%rax,1)
 1091240:	mov    (%rcx,%rdx,1),%r9
 1091244:	mov    %rdi,%rdx
 1091247:	mov    %r9,%rdi
 109124a:	not    %rdi
 109124d:	add    %rdi,%rdi
 1091250:	and    %r9,%rdi
 1091253:	shr    $0x7,%rdi
 1091257:	and    %r8,%rdi
 109125a:	imul   %r8,%rdi
 109125e:	shr    $0x38,%rdi
 1091262:	sub    %rdi,%rax
 1091265:	add    $0x8,%rax
 1091269:	lea    0x8(%rdx),%rdi
 109126d:	cmp    %rsi,%rdi
 1091270:	jbe    1091240 <index_walk+0x310>
 1091272:	add    $0xfffffffffffffff8,%rdi
 1091276:	mov    %rdi,%rdx
 1091279:	mov    %rsi,%rdi
 109127c:	sub    %rdx,%rdi
 109127f:	jbe    1091590 <index_walk+0x660>
 1091285:	cmp    $0x3,%rdi
 1091289:	jbe    1091550 <index_walk+0x620>
 109128f:	cmp    $0x10,%rdi
 1091293:	jae    10913fd <index_walk+0x4cd>
 1091299:	xor    %r8d,%r8d
 109129c:	jmp    10914df <index_walk+0x5af>
 10912a1:	mov    %rdi,%r9
 10912a4:	and    $0xfffffffffffffff0,%r9
 10912a8:	vmovq  %r8,%xmm0
 10912ad:	lea    (%rsi,%rcx,1),%r8
 10912b1:	add    $0xc,%r8
 10912b5:	vpxor  %xmm1,%xmm1,%xmm1
 10912b9:	xor    %r10d,%r10d
 10912bc:	vmovdqa -0x8f894(%rip),%xmm2        # 1001a30 <__abi_tag+0x1734>
 10912c4:	vpbroadcastq -0x8a1b5(%rip),%ymm3        # 1007118 <__abi_tag+0x6e1c>
 10912cd:	vpxor  %xmm4,%xmm4,%xmm4
 10912d1:	vpxor  %xmm5,%xmm5,%xmm5
 10912d5:	data16 cs nopw 0x0(%rax,%rax,1)
 10912e0:	vmovd  -0xc(%r8,%r10,1),%xmm6
 10912e7:	vmovd  -0x8(%r8,%r10,1),%xmm7
 10912ee:	vmovd  -0x4(%r8,%r10,1),%xmm8
 10912f5:	vmovd  (%r8,%r10,1),%xmm9
 10912fb:	vpcmpgtb %xmm2,%xmm6,%xmm6
 10912ff:	vpmovzxbq %xmm6,%ymm6
 1091304:	vpand  %ymm3,%ymm6,%ymm6
 1091308:	vpaddq %ymm6,%ymm0,%ymm0
 109130c:	vpcmpgtb %xmm2,%xmm7,%xmm6
 1091310:	vpmovzxbq %xmm6,%ymm6
 1091315:	vpand  %ymm3,%ymm6,%ymm6
 1091319:	vpaddq %ymm6,%ymm1,%ymm1
 109131d:	vpcmpgtb %xmm2,%xmm8,%xmm6
 1091321:	vpmovzxbq %xmm6,%ymm6
 1091326:	vpand  %ymm3,%ymm6,%ymm6
 109132a:	vpaddq %ymm6,%ymm4,%ymm4
 109132e:	vpcmpgtb %xmm2,%xmm9,%xmm6
 1091332:	vpmovzxbq %xmm6,%ymm6
 1091337:	vpand  %ymm3,%ymm6,%ymm6
 109133b:	vpaddq %ymm6,%ymm5,%ymm5
 109133f:	add    $0x10,%r10
 1091343:	cmp    %r10,%r9
 1091346:	jne    10912e0 <index_walk+0x3b0>
 1091348:	vpaddq %ymm0,%ymm1,%ymm0
 109134c:	vpaddq %ymm0,%ymm4,%ymm0
 1091350:	vpaddq %ymm0,%ymm5,%ymm0
 1091354:	vextracti128 $0x1,%ymm0,%xmm1
 109135a:	vpaddq %xmm1,%xmm0,%xmm0
 109135e:	vpshufd $0xee,%xmm0,%xmm1
 1091363:	vpaddq %xmm1,%xmm0,%xmm0
 1091367:	vmovq  %xmm0,%r8
 109136c:	cmp    %r9,%rdi
 109136f:	je     10913f5 <index_walk+0x4c5>
 1091375:	test   $0xc,%dil
 1091379:	je     109159e <index_walk+0x66e>
 109137f:	mov    %rdi,%r10
 1091382:	and    $0xfffffffffffffffc,%r10
 1091386:	vmovq  %r8,%xmm0
 109138b:	lea    (%rcx,%rsi,1),%r8
 109138f:	vmovdqa -0x8f967(%rip),%xmm1        # 1001a30 <__abi_tag+0x1734>
 1091397:	vpbroadcastq -0x8a288(%rip),%ymm2        # 1007118 <__abi_tag+0x6e1c>
 10913a0:	vmovd  (%r8,%r9,1),%xmm3
 10913a6:	vpcmpgtb %xmm1,%xmm3,%xmm3
 10913aa:	vpmovzxbq %xmm3,%ymm3
 10913af:	vpand  %ymm2,%ymm3,%ymm3
 10913b3:	vpaddq %ymm3,%ymm0,%ymm0
 10913b7:	add    $0x4,%r9
 10913bb:	cmp    %r9,%r10
 10913be:	jne    10913a0 <index_walk+0x470>
 10913c0:	vextracti128 $0x1,%ymm0,%xmm1
 10913c6:	vpaddq %xmm1,%xmm0,%xmm0
 10913ca:	vpshufd $0xee,%xmm0,%xmm1
 10913cf:	vpaddq %xmm1,%xmm0,%xmm0
 10913d3:	vmovq  %xmm0,%r8
 10913d8:	cmp    %r10,%rdi
 10913db:	je     10913f5 <index_walk+0x4c5>
 10913dd:	add    %r10,%rsi
 10913e0:	xor    %edi,%edi
 10913e2:	cmpb   $0xc0,(%rcx,%rsi,1)
 10913e6:	setge  %dil
 10913ea:	add    %rdi,%r8
 10913ed:	inc    %rsi
 10913f0:	cmp    %rsi,%rdx
 10913f3:	jne    10913e0 <index_walk+0x4b0>
 10913f5:	sub    %r8,%rax
 10913f8:	jmp    1091590 <index_walk+0x660>
 10913fd:	mov    %rdi,%r8
 1091400:	and    $0xfffffffffffffff0,%r8
 1091404:	vmovq  %rax,%xmm0
 1091409:	lea    (%rdx,%rcx,1),%rax
 109140d:	add    $0xc,%rax
 1091411:	vpxor  %xmm1,%xmm1,%xmm1
 1091415:	xor    %r9d,%r9d
 1091418:	vmovdqa -0x8f9f0(%rip),%xmm2        # 1001a30 <__abi_tag+0x1734>
 1091420:	vpbroadcastq -0x8a311(%rip),%ymm3        # 1007118 <__abi_tag+0x6e1c>
 1091429:	vpxor  %xmm4,%xmm4,%xmm4
 109142d:	vpxor  %xmm5,%xmm5,%xmm5
 1091431:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1091440:	vmovd  -0xc(%rax,%r9,1),%xmm6
 1091447:	vmovd  -0x8(%rax,%r9,1),%xmm7
 109144e:	vmovd  -0x4(%rax,%r9,1),%xmm8
 1091455:	vmovd  (%rax,%r9,1),%xmm9
 109145b:	vpcmpgtb %xmm2,%xmm6,%xmm6
 109145f:	vpmovzxbq %xmm6,%ymm6
 1091464:	vpand  %ymm3,%ymm6,%ymm6
 1091468:	vpaddq %ymm6,%ymm0,%ymm0
 109146c:	vpcmpgtb %xmm2,%xmm7,%xmm6
 1091470:	vpmovzxbq %xmm6,%ymm6
 1091475:	vpand  %ymm3,%ymm6,%ymm6
 1091479:	vpaddq %ymm6,%ymm1,%ymm1
 109147d:	vpcmpgtb %xmm2,%xmm8,%xmm6
 1091481:	vpmovzxbq %xmm6,%ymm6
 1091486:	vpand  %ymm3,%ymm6,%ymm6
 109148a:	vpaddq %ymm6,%ymm4,%ymm4
 109148e:	vpcmpgtb %xmm2,%xmm9,%xmm6
 1091492:	vpmovzxbq %xmm6,%ymm6
 1091497:	vpand  %ymm3,%ymm6,%ymm6
 109149b:	vpaddq %ymm6,%ymm5,%ymm5
 109149f:	add    $0x10,%r9
 10914a3:	cmp    %r9,%r8
 10914a6:	jne    1091440 <index_walk+0x510>
 10914a8:	vpaddq %ymm0,%ymm1,%ymm0
 10914ac:	vpaddq %ymm0,%ymm4,%ymm0
 10914b0:	vpaddq %ymm0,%ymm5,%ymm0
 10914b4:	vextracti128 $0x1,%ymm0,%xmm1
 10914ba:	vpaddq %xmm1,%xmm0,%xmm0
 10914be:	vpshufd $0xee,%xmm0,%xmm1
 10914c3:	vpaddq %xmm1,%xmm0,%xmm0
 10914c7:	vmovq  %xmm0,%rax
 10914cc:	cmp    %r8,%rdi
 10914cf:	je     1091590 <index_walk+0x660>
 10914d5:	test   $0xc,%dil
 10914d9:	je     10915a6 <index_walk+0x676>
 10914df:	mov    %esi,%r9d
 10914e2:	and    $0x3,%r9d
 10914e6:	sub    %r9,%rdi
 10914e9:	vmovq  %rax,%xmm0
 10914ee:	mov    %rsi,%rax
 10914f1:	and    $0xfffffffffffffffc,%rax
 10914f5:	add    %rdx,%r8
 10914f8:	vmovdqa -0x8fad0(%rip),%xmm1        # 1001a30 <__abi_tag+0x1734>
 1091500:	vpbroadcastq -0x8a3f1(%rip),%ymm2        # 1007118 <__abi_tag+0x6e1c>
 1091509:	nopl   0x0(%rax)
 1091510:	vmovd  (%rcx,%r8,1),%xmm3
 1091516:	vpcmpgtb %xmm1,%xmm3,%xmm3
 109151a:	vpmovzxbq %xmm3,%ymm3
 109151f:	vpand  %ymm2,%ymm3,%ymm3
 1091523:	vpaddq %ymm3,%ymm0,%ymm0
 1091527:	add    $0x4,%r8
 109152b:	cmp    %r8,%rax
 109152e:	jne    1091510 <index_walk+0x5e0>
 1091530:	vextracti128 $0x1,%ymm0,%xmm1
 1091536:	vpaddq %xmm1,%xmm0,%xmm0
 109153a:	vpshufd $0xee,%xmm0,%xmm1
 109153f:	vpaddq %xmm1,%xmm0,%xmm0
 1091543:	vmovq  %xmm0,%rax
 1091548:	test   %r9,%r9
 109154b:	je     1091590 <index_walk+0x660>
 109154d:	add    %rdi,%rdx
 1091550:	xor    %edi,%edi
 1091552:	cmpb   $0xc0,(%rcx,%rdx,1)
 1091556:	setge  %dil
 109155a:	add    %rdi,%rax
 109155d:	inc    %rdx
 1091560:	cmp    %rdx,%rsi
 1091563:	jne    1091550 <index_walk+0x620>
 1091565:	jmp    1091590 <index_walk+0x660>
 1091567:	mov    0x14(%rdi),%eax
 109156a:	add    %rax,%rsi
 109156d:	mov    %rdi,%r15
 1091570:	mov    %rbx,%rdi
 1091573:	call   10915b0 <index_at>
 1091578:	mov    %rax,%r14
 109157b:	mov    0x14(%r15),%esi
 109157f:	mov    %rbx,%rdi
 1091582:	call   10915b0 <index_at>
 1091587:	mov    %rax,%rcx
 109158a:	mov    %r14,%rax
 109158d:	sub    %rcx,%rax
 1091590:	add    $0x8,%rsp
 1091594:	pop    %rbx
 1091595:	pop    %r14
 1091597:	pop    %r15
 1091599:	pop    %rbp
 109159a:	vzeroupper
 109159d:	ret
 109159e:	add    %r9,%rsi
 10915a1:	jmp    10913e0 <index_walk+0x4b0>
 10915a6:	add    %r8,%rdx
 10915a9:	jmp    1091550 <index_walk+0x620>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
