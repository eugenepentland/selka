
.mylang-cache/goal110-join-short/runner/bin/text-my-llvm:     file format elf64-x86-64


Disassembly of section .text:

000000000104e7d0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76>:
 104e7d0:	push   %rbp
 104e7d1:	push   %r15
 104e7d3:	push   %r14
 104e7d5:	push   %r13
 104e7d7:	push   %r12
 104e7d9:	push   %rbx
 104e7da:	sub    $0x258,%rsp
 104e7e1:	mov    %r8,0x8(%rsp)
 104e7e6:	mov    %rcx,0x28(%rsp)
 104e7eb:	mov    %rdi,%rbp
 104e7ee:	cmp    %rsp,0x40(%rdi)
 104e7f2:	ja     1051dd1 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3601>
 104e7f8:	mov    %rdx,%r15
 104e7fb:	movq   $0x0,0xa8(%rsp)
 104e807:	movq   $0x0,0xa0(%rsp)
 104e813:	mov    0x2c8(%rbp),%eax
 104e819:	mov    %eax,0x44(%rsp)
 104e81d:	movq   $0x10bb6c0,0x38(%rsp)
 104e826:	movq   $0x10bb6c0,0x70(%rsp)
 104e82f:	cmp    $0x10bb6c0,%rsi
 104e836:	jne    104e83f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x6f>
 104e838:	xor    %ebx,%ebx
 104e83a:	jmp    104e924 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x154>
 104e83f:	mov    $0x1,%bl
 104e841:	test   %rsi,%rsi
 104e844:	je     104e924 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x154>
 104e84a:	mov    0x8(%rsi),%rdx
 104e84e:	cmp    0x6ce73(%rip),%rdx        # 10bb6c8 <myl_lit_d666bf92bda1d63f03bf95c09e1bffde05f85315fdade322db024e5b0244b85a_instance+0x18>
 104e855:	jne    104e924 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x154>
 104e85b:	test   %rdx,%rdx
 104e85e:	je     104e838 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x68>
 104e860:	testb  $0x4,0x10(%rsi)
 104e864:	jne    104e86c <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x9c>
 104e866:	lea    0x18(%rsi),%rdi
 104e86a:	jmp    104e87b <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xab>
 104e86c:	mov    0x18(%rsi),%rax
 104e870:	mov    0x14(%rsi),%ecx
 104e873:	lea    (%rax,%rcx,1),%rdi
 104e877:	add    $0x18,%rdi
 104e87b:	testb  $0x4,0x6ce4e(%rip)        # 10bb6d0 <myl_lit_d666bf92bda1d63f03bf95c09e1bffde05f85315fdade322db024e5b0244b85a_instance+0x20>
 104e882:	mov    0x6ce4f(%rip),%rax        # 10bb6d8 <myl_lit_d666bf92bda1d63f03bf95c09e1bffde05f85315fdade322db024e5b0244b85a_instance+0x28>
 104e889:	mov    0x6ce45(%rip),%ecx        # 10bb6d4 <myl_lit_d666bf92bda1d63f03bf95c09e1bffde05f85315fdade322db024e5b0244b85a_instance+0x24>
 104e88f:	lea    0x18(%rax,%rcx,1),%rcx
 104e894:	mov    $0x10bb6d8,%eax
 104e899:	cmovne %rcx,%rax
 104e89d:	cmp    $0x10,%rdx
 104e8a1:	ja     104e8be <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xee>
 104e8a3:	cmp    $0x8,%rdx
 104e8a7:	jb     104e8d9 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x109>
 104e8a9:	mov    (%rdi),%rcx
 104e8ac:	mov    -0x8(%rdi,%rdx,1),%rdi
 104e8b1:	xor    (%rax),%rcx
 104e8b4:	xor    -0x8(%rax,%rdx,1),%rdi
 104e8b9:	or     %rcx,%rdi
 104e8bc:	jmp    104e91e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x14e>
 104e8be:	mov    %rsi,%r14
 104e8c1:	mov    %rax,%rsi
 104e8c4:	cmp    $0x100,%rdx
 104e8cb:	ja     104e8ef <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x11f>
 104e8cd:	call   10ad360 <bcmp@plt>
 104e8d2:	test   %eax,%eax
 104e8d4:	setne  %bl
 104e8d7:	jmp    104e8f9 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x129>
 104e8d9:	cmp    $0x4,%rdx
 104e8dd:	jb     104e8fe <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x12e>
 104e8df:	mov    (%rdi),%ecx
 104e8e1:	mov    -0x4(%rdi,%rdx,1),%edi
 104e8e5:	xor    (%rax),%ecx
 104e8e7:	xor    -0x4(%rax,%rdx,1),%edi
 104e8eb:	or     %ecx,%edi
 104e8ed:	jmp    104e91e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x14e>
 104e8ef:	call   1093490 <equal_large_octets>
 104e8f4:	test   %eax,%eax
 104e8f6:	sete   %bl
 104e8f9:	mov    %r14,%rsi
 104e8fc:	jmp    104e924 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x154>
 104e8fe:	cmp    $0x1,%rdx
 104e902:	jne    104e90b <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x13b>
 104e904:	movzbl (%rdi),%ecx
 104e907:	cmp    (%rax),%cl
 104e909:	jmp    104e91e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x14e>
 104e90b:	movzwl (%rdi),%ecx
 104e90e:	movzwl -0x2(%rdi,%rdx,1),%edi
 104e913:	xor    (%rax),%cx
 104e916:	xor    -0x2(%rax,%rdx,1),%di
 104e91b:	or     %cx,%di
 104e91e:	sete   %bl
 104e921:	xor    $0x1,%bl
 104e924:	lea    0x258(%rbp),%rax
 104e92b:	mov    %rax,0x18(%rsp)
 104e930:	movabs $0x4000000000000002,%r13
 104e93a:	test   %r13,0x6cd6f(%rip)        # 10bb6b0 <myl_lit_d666bf92bda1d63f03bf95c09e1bffde05f85315fdade322db024e5b0244b85a_instance>
 104e941:	jne    104e964 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x194>
 104e943:	mov    0x6cd56(%rip),%rax        # 10bb6a0 <myl_lit_d3cafad273dd497c488894ca58a5701d146f3969ca50fbb18df3109543cd07e8_instance+0x60>
 104e94a:	dec    %rax
 104e94d:	jne    104e95d <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x18d>
 104e94f:	cmpq   $0x0,0x6cd51(%rip)        # 10bb6a8 <myl_lit_d3cafad273dd497c488894ca58a5701d146f3969ca50fbb18df3109543cd07e8_instance+0x68>
 104e957:	je     104e9e4 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x214>
 104e95d:	mov    %rax,0x6cd3c(%rip)        # 10bb6a0 <myl_lit_d3cafad273dd497c488894ca58a5701d146f3969ca50fbb18df3109543cd07e8_instance+0x60>
 104e964:	movq   $0x0,0xc8(%rsp)
 104e970:	test   %bl,%bl
 104e972:	mov    %rbp,0x10(%rsp)
 104e977:	mov    %r15,0x30(%rsp)
 104e97c:	je     104ea24 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x254>
 104e982:	movq   $0x10bb1d0,0x38(%rsp)
 104e98b:	movq   $0x10bb1d0,0x70(%rsp)
 104e994:	movq   $0x10bb1d0,0xc8(%rsp)
 104e9a0:	cmp    $0x10bb1d0,%rsi
 104e9a7:	jne    104e9b0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1e0>
 104e9a9:	xor    %ebx,%ebx
 104e9ab:	jmp    104f04e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x87e>
 104e9b0:	mov    $0x1,%bl
 104e9b2:	test   %rsi,%rsi
 104e9b5:	je     104f04e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x87e>
 104e9bb:	mov    0x8(%rsi),%rdx
 104e9bf:	cmp    0x6c812(%rip),%rdx        # 10bb1d8 <myl_lit_8c12e724a44132b907ad7be4d7bffd05d284ce5c644f94f5ab8dbc188941e631_instance+0x18>
 104e9c6:	jne    104f04e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x87e>
 104e9cc:	test   %rdx,%rdx
 104e9cf:	je     104e9a9 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1d9>
 104e9d1:	testb  $0x4,0x10(%rsi)
 104e9d5:	jne    104ef96 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x7c6>
 104e9db:	lea    0x18(%rsi),%rdi
 104e9df:	jmp    104efa5 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x7d5>
 104e9e4:	mov    %rsi,%r14
 104e9e7:	mov    $0x10bb6c0,%esi
 104e9ec:	lea    0x258(%rbp),%r12
 104e9f3:	mov    %r12,%rdi
 104e9f6:	call   109bb70 <myl_rc_edge_release>
 104e9fb:	movq   $0x0,0xc8(%rsp)
 104ea07:	mov    %r12,%rdi
 104ea0a:	call   109ecf0 <myl_rc_drain>
 104ea0f:	mov    %r14,%rsi
 104ea12:	test   %bl,%bl
 104ea14:	mov    %rbp,0x10(%rsp)
 104ea19:	mov    %r15,0x30(%rsp)
 104ea1e:	jne    104e982 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1b2>
 104ea24:	xor    %eax,%eax
 104ea26:	movabs $0x89705f3112a28fe5,%r15
 104ea30:	vpxor  %xmm11,%xmm11,%xmm11
 104ea35:	vmovd  -0x4d09d(%rip),%xmm12        # 10019a0 <__abi_tag+0x16a4>
 104ea3d:	vmovd  -0x4d055(%rip),%xmm13        # 10019f0 <__abi_tag+0x16f4>
 104ea45:	vmovd  -0x4d0cd(%rip),%xmm14        # 1001980 <__abi_tag+0x1684>
 104ea4d:	vmovd  -0x4d135(%rip),%xmm15        # 1001920 <__abi_tag+0x1624>
 104ea55:	xor    %r14d,%r14d
 104ea58:	nopl   0x0(%rax,%rax,1)
 104ea60:	mov    0x8(%rsp),%rdx
 104ea65:	add    %r14,%rdx
 104ea68:	jo     1051cd2 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3502>
 104ea6e:	mov    %rax,%r12
 104ea71:	mov    0x30(%rsp),%rax
 104ea76:	mov    (%rax),%rsi
 104ea79:	mov    -0x10(%rsi),%rax
 104ea7d:	movabs $0x4000000000000002,%r13
 104ea87:	test   %r13,%rax
 104ea8a:	jne    104ea9d <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2cd>
 104ea8c:	mov    -0x18(%rsi),%rcx
 104ea90:	inc    %rcx
 104ea93:	je     104ef5a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x78a>
 104ea99:	mov    %rcx,-0x18(%rsi)
 104ea9d:	movzbl %dl,%r8d
 104eaa1:	mov    (%rsi),%rdi
 104eaa4:	lea    -0x10(%rdi),%r9
 104eaa8:	movabs $0xffffffffffffff0,%rcx
 104eab2:	cmp    %rcx,%r9
 104eab5:	ja     104eaf0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x320>
 104eab7:	mov    0x20(%rsi),%rcx
 104eabb:	movabs $0x80808080808080,%r10
 104eac5:	cmp    %r10,%rdi
 104eac8:	ja     104eb20 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x350>
 104eaca:	vmovd  %edx,%xmm0
 104eace:	vpbroadcastb %xmm0,%xmm0
 104ead3:	mov    %r9d,%r8d
 104ead6:	not    %r8d
 104ead9:	test   $0x30,%r8b
 104eadd:	jne    104ec58 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x488>
 104eae3:	vpxor  %xmm1,%xmm1,%xmm1
 104eae7:	jmp    104eca0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x4d0>
 104eaec:	nopl   0x0(%rax)
 104eaf0:	test   %rdi,%rdi
 104eaf3:	jle    104ec51 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x481>
 104eaf9:	mov    0x20(%rsi),%rcx
 104eafd:	cmp    $0x8,%rdi
 104eb01:	jae    104eb20 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x350>
 104eb03:	mov    $0x1,%r10d
 104eb09:	xor    %r9d,%r9d
 104eb0c:	xor    %edx,%edx
 104eb0e:	xor    %ebx,%ebx
 104eb10:	jmp    104ebc7 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3f7>
 104eb15:	data16 cs nopw 0x0(%rax,%rax,1)
 104eb20:	mov    %rdi,%rdx
 104eb23:	and    $0xfffffffffffffff8,%rdx
 104eb27:	vmovq  %r8,%xmm0
 104eb2c:	vpbroadcastq %xmm0,%ymm3
 104eb31:	vpxor  %xmm2,%xmm2,%xmm2
 104eb35:	xor    %r9d,%r9d
 104eb38:	vpxor  %xmm4,%xmm4,%xmm4
 104eb3c:	vpxor  %xmm0,%xmm0,%xmm0
 104eb40:	vpxor  %xmm1,%xmm1,%xmm1
 104eb44:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 104eb50:	vpmovzxbq (%rcx,%r9,1),%ymm5
 104eb56:	vpmovzxbq 0x4(%rcx,%r9,1),%ymm6
 104eb5d:	vpxor  %ymm5,%ymm3,%ymm5
 104eb61:	vpxor  %ymm6,%ymm3,%ymm6
 104eb65:	vpaddq %ymm2,%ymm5,%ymm2
 104eb69:	vpaddq %ymm4,%ymm6,%ymm4
 104eb6d:	vpaddq %ymm0,%ymm5,%ymm0
 104eb71:	vpaddq %ymm1,%ymm6,%ymm1
 104eb75:	add    $0x8,%r9
 104eb79:	cmp    %r9,%rdx
 104eb7c:	jne    104eb50 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x380>
 104eb7e:	vpaddq %ymm2,%ymm4,%ymm2
 104eb82:	vextracti128 $0x1,%ymm2,%xmm3
 104eb88:	vpaddq %xmm3,%xmm2,%xmm2
 104eb8c:	vpshufd $0xee,%xmm2,%xmm3
 104eb91:	vpaddq %xmm3,%xmm2,%xmm2
 104eb95:	vmovq  %xmm2,%r9
 104eb9a:	vpaddq %ymm0,%ymm1,%ymm0
 104eb9e:	vextracti128 $0x1,%ymm0,%xmm1
 104eba4:	vpaddq %xmm1,%xmm0,%xmm0
 104eba8:	vpshufd $0xee,%xmm0,%xmm1
 104ebad:	vpaddq %xmm1,%xmm0,%xmm0
 104ebb1:	vmovq  %xmm0,%rbx
 104ebb6:	cmp    %rdx,%rdi
 104ebb9:	jne    104ebc0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3f0>
 104ebbb:	mov    %rdi,%rcx
 104ebbe:	jmp    104ec01 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x431>
 104ebc0:	mov    %rdx,%r10
 104ebc3:	or     $0x1,%r10
 104ebc7:	add    %rdx,%rcx
 104ebca:	mov    %rdi,%r11
 104ebcd:	sub    %rdx,%r11
 104ebd0:	xor    %edx,%edx
 104ebd2:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 104ebe0:	movzbl (%rcx,%rdx,1),%ebp
 104ebe4:	xor    %r8,%rbp
 104ebe7:	add    %rbp,%r9
 104ebea:	add    %rbp,%rbx
 104ebed:	inc    %rdx
 104ebf0:	cmp    %rdx,%r11
 104ebf3:	jne    104ebe0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x410>
 104ebf5:	lea    (%r10,%rdx,1),%rcx
 104ebf9:	dec    %rcx
 104ebfc:	mov    0x10(%rsp),%rbp
 104ec01:	mov    $0xffffffff,%edx
 104ec06:	cmp    %rdx,%rcx
 104ec09:	setb   %cl
 104ec0c:	test   %r9,%r9
 104ec0f:	setns  %dl
 104ec12:	test   %dl,%cl
 104ec14:	jne    104eeb0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x6e0>
 104ec1a:	mov    0x20(%rsi),%r9
 104ec1e:	xor    %r10d,%r10d
 104ec21:	xor    %edx,%edx
 104ec23:	xor    %ebx,%ebx
 104ec25:	data16 cs nopw 0x0(%rax,%rax,1)
 104ec30:	movzbl (%r9,%r10,1),%ecx
 104ec35:	xor    %r8,%rcx
 104ec38:	add    %rcx,%rbx
 104ec3b:	jo     1051ca6 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x34d6>
 104ec41:	inc    %r10
 104ec44:	mov    %rbx,%rdx
 104ec47:	cmp    %r10,%rdi
 104ec4a:	jne    104ec30 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x460>
 104ec4c:	jmp    104eeb0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x6e0>
 104ec51:	xor    %ebx,%ebx
 104ec53:	jmp    104eeb0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x6e0>
 104ec58:	mov    %r9d,%r8d
 104ec5b:	shr    $0x4,%r8d
 104ec5f:	inc    %r8d
 104ec62:	and    $0x3,%r8d
 104ec66:	vpxor  %xmm1,%xmm1,%xmm1
 104ec6a:	mov    %r8,%r10
 104ec6d:	mov    %rcx,%r11
 104ec70:	vpxor  (%r11),%xmm0,%xmm2
 104ec75:	vpsadbw %xmm2,%xmm11,%xmm2
 104ec79:	vpaddq %xmm1,%xmm2,%xmm1
 104ec7d:	add    $0x10,%r11
 104ec81:	dec    %r10
 104ec84:	jne    104ec70 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x4a0>
 104ec86:	shl    $0x4,%r8d
 104ec8a:	add    %r8,%rcx
 104ec8d:	sub    %r8,%rdi
 104ec90:	cmp    $0x30,%r9
 104ec94:	jb     104ece1 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x511>
 104ec96:	cs nopw 0x0(%rax,%rax,1)
 104eca0:	vpxor  (%rcx),%xmm0,%xmm2
 104eca4:	vpsadbw %xmm2,%xmm11,%xmm2
 104eca8:	vpaddq %xmm1,%xmm2,%xmm1
 104ecac:	vpxor  0x10(%rcx),%xmm0,%xmm2
 104ecb1:	vpsadbw %xmm2,%xmm11,%xmm2
 104ecb5:	vpxor  0x20(%rcx),%xmm0,%xmm3
 104ecba:	vpsadbw %xmm3,%xmm11,%xmm3
 104ecbe:	vpaddq %xmm2,%xmm3,%xmm2
 104ecc2:	vpaddq %xmm1,%xmm2,%xmm1
 104ecc6:	vpxor  0x30(%rcx),%xmm0,%xmm2
 104eccb:	vpsadbw %xmm2,%xmm11,%xmm2
 104eccf:	vpaddq %xmm1,%xmm2,%xmm1
 104ecd3:	add    $0x40,%rcx
 104ecd7:	add    $0xffffffffffffffc0,%rdi
 104ecdb:	cmp    $0xf,%rdi
 104ecdf:	ja     104eca0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x4d0>
 104ece1:	vpshufd $0xee,%xmm1,%xmm0
 104ece6:	vpaddq %xmm0,%xmm1,%xmm0
 104ecea:	vmovq  %xmm0,%rbx
 104ecef:	test   %rdi,%rdi
 104ecf2:	je     104eeb0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x6e0>
 104ecf8:	mov    %rdi,%r11
 104ecfb:	and    $0x3,%r11
 104ecff:	je     104ed3d <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x56d>
 104ed01:	xor    %r8d,%r8d
 104ed04:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 104ed10:	movzbl (%rcx,%r8,1),%r9d
 104ed15:	xor    %dl,%r9b
 104ed18:	movzbl %r9b,%r9d
 104ed1c:	add    %r9,%rbx
 104ed1f:	inc    %r8
 104ed22:	cmp    %r8,%r11
 104ed25:	jne    104ed10 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x540>
 104ed27:	mov    %rdi,%r8
 104ed2a:	and    $0xfffffffffffffffc,%r8
 104ed2e:	lea    (%rcx,%r11,1),%r9
 104ed32:	cmp    $0x4,%rdi
 104ed36:	jae    104ed4d <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x57d>
 104ed38:	jmp    104eeb0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x6e0>
 104ed3d:	mov    %rcx,%r9
 104ed40:	mov    %rdi,%r8
 104ed43:	cmp    $0x4,%rdi
 104ed47:	jb     104eeb0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x6e0>
 104ed4d:	lea    -0x4(%r8),%rdi
 104ed51:	cmp    $0x1c,%rdi
 104ed55:	jb     104ee70 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x6a0>
 104ed5b:	shr    $0x2,%rdi
 104ed5f:	inc    %rdi
 104ed62:	mov    %rdi,%r10
 104ed65:	and    $0xfffffffffffffff8,%r10
 104ed69:	lea    0x0(,%r10,4),%rbp
 104ed71:	lea    (%r9,%r10,4),%r9
 104ed75:	sub    %rbp,%r8
 104ed78:	vmovq  %rbx,%xmm1
 104ed7d:	vmovd  %edx,%xmm0
 104ed81:	vpbroadcastb %xmm0,%xmm0
 104ed86:	add    %r11,%rcx
 104ed89:	add    $0x10,%rcx
 104ed8d:	vpxor  %xmm2,%xmm2,%xmm2
 104ed91:	xor    %r11d,%r11d
 104ed94:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 104eda0:	vmovdqu -0x10(%rcx,%r11,4),%xmm3
 104eda7:	vmovdqu (%rcx,%r11,4),%xmm4
 104edad:	vpshufb %xmm12,%xmm3,%xmm5
 104edb2:	vpshufb %xmm13,%xmm3,%xmm6
 104edb7:	vpshufb %xmm14,%xmm3,%xmm7
 104edbc:	vpshufb %xmm15,%xmm3,%xmm3
 104edc1:	vpshufb %xmm12,%xmm4,%xmm8
 104edc6:	vpshufb %xmm13,%xmm4,%xmm9
 104edcb:	vpshufb %xmm14,%xmm4,%xmm10
 104edd0:	vpshufb %xmm15,%xmm4,%xmm4
 104edd5:	vpxor  %xmm0,%xmm5,%xmm5
 104edd9:	vpxor  %xmm0,%xmm8,%xmm8
 104eddd:	vpmovzxbq %xmm5,%ymm5
 104ede2:	vpaddq %ymm5,%ymm1,%ymm1
 104ede6:	vpmovzxbq %xmm8,%ymm5
 104edeb:	vpaddq %ymm5,%ymm2,%ymm2
 104edef:	vpxor  %xmm0,%xmm6,%xmm5
 104edf3:	vpxor  %xmm0,%xmm9,%xmm6
 104edf7:	vpmovzxbq %xmm5,%ymm5
 104edfc:	vpmovzxbq %xmm6,%ymm6
 104ee01:	vpxor  %xmm0,%xmm7,%xmm7
 104ee05:	vpxor  %xmm0,%xmm10,%xmm8
 104ee09:	vpmovzxbq %xmm7,%ymm7
 104ee0e:	vpaddq %ymm7,%ymm5,%ymm5
 104ee12:	vpaddq %ymm5,%ymm1,%ymm1
 104ee16:	vpmovzxbq %xmm8,%ymm5
 104ee1b:	vpaddq %ymm5,%ymm6,%ymm5
 104ee1f:	vpaddq %ymm5,%ymm2,%ymm2
 104ee23:	vpxor  %xmm0,%xmm3,%xmm3
 104ee27:	vpxor  %xmm0,%xmm4,%xmm4
 104ee2b:	vpmovzxbq %xmm3,%ymm3
 104ee30:	vpaddq %ymm3,%ymm1,%ymm1
 104ee34:	vpmovzxbq %xmm4,%ymm3
 104ee39:	vpaddq %ymm3,%ymm2,%ymm2
 104ee3d:	add    $0x8,%r11
 104ee41:	cmp    %r11,%r10
 104ee44:	jne    104eda0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x5d0>
 104ee4a:	vpaddq %ymm1,%ymm2,%ymm0
 104ee4e:	vextracti128 $0x1,%ymm0,%xmm1
 104ee54:	vpaddq %xmm1,%xmm0,%xmm0
 104ee58:	vpshufd $0xee,%xmm0,%xmm1
 104ee5d:	vpaddq %xmm1,%xmm0,%xmm0
 104ee61:	vmovq  %xmm0,%rbx
 104ee66:	cmp    %r10,%rdi
 104ee69:	mov    0x10(%rsp),%rbp
 104ee6e:	je     104eeb0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x6e0>
 104ee70:	vmovd  %edx,%xmm0
 104ee74:	vpbroadcastb %xmm0,%xmm0
 104ee79:	xor    %ecx,%ecx
 104ee7b:	nopl   0x0(%rax,%rax,1)
 104ee80:	vmovd  (%r9,%rcx,1),%xmm1
 104ee86:	vpxor  %xmm0,%xmm1,%xmm1
 104ee8a:	vpblendd $0x1,%xmm1,%xmm11,%xmm1
 104ee90:	vpsadbw %xmm1,%xmm11,%xmm1
 104ee94:	vmovq  %xmm1,%rdx
 104ee99:	add    %rdx,%rbx
 104ee9c:	add    $0x4,%rcx
 104eea0:	cmp    %rcx,%r8
 104eea3:	jne    104ee80 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x6b0>
 104eea5:	data16 cs nopw 0x0(%rax,%rax,1)
 104eeb0:	test   %r13,%rax
 104eeb3:	jne    104eec9 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x6f9>
 104eeb5:	mov    -0x18(%rsi),%rax
 104eeb9:	dec    %rax
 104eebc:	jne    104eec5 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x6f5>
 104eebe:	cmpq   $0x0,-0x20(%rsi)
 104eec3:	je     104ef18 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x748>
 104eec5:	mov    %rax,-0x18(%rsi)
 104eec9:	mov    %r12,%rcx
 104eecc:	add    %rbx,%rcx
 104eecf:	jo     1051ce7 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3517>
 104eed5:	mov    %rcx,%rax
 104eed8:	imul   %r15
 104eedb:	add    %rcx,%rdx
 104eede:	mov    %rdx,%rax
 104eee1:	shr    $0x3f,%rax
 104eee5:	sar    $0x1d,%rdx
 104eee9:	add    %rax,%rdx
 104eeec:	imul   $0x3b9aca07,%rdx,%rax
 104eef3:	sub    %rax,%rcx
 104eef6:	mov    %rcx,%rax
 104eef9:	sar    $0x3f,%rax
 104eefd:	and    $0x3b9aca07,%eax
 104ef02:	add    %rcx,%rax
 104ef05:	inc    %r14
 104ef08:	cmp    0x28(%rsp),%r14
 104ef0d:	jne    104ea60 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x290>
 104ef13:	jmp    104f0fc <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x92c>
 104ef18:	mov    0x18(%rsp),%r13
 104ef1d:	mov    %r13,%rdi
 104ef20:	vzeroupper
 104ef23:	call   109bcd0 <myl_rc_hold_edge_release>
 104ef28:	mov    %r13,%rdi
 104ef2b:	call   109ecf0 <myl_rc_drain>
 104ef30:	vmovd  -0x4d618(%rip),%xmm15        # 1001920 <__abi_tag+0x1624>
 104ef38:	vmovd  -0x4d5c0(%rip),%xmm14        # 1001980 <__abi_tag+0x1684>
 104ef40:	vmovd  -0x4d558(%rip),%xmm13        # 10019f0 <__abi_tag+0x16f4>
 104ef48:	vmovd  -0x4d5b0(%rip),%xmm12        # 10019a0 <__abi_tag+0x16a4>
 104ef50:	vpxor  %xmm11,%xmm11,%xmm11
 104ef55:	jmp    104eec9 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x6f9>
 104ef5a:	mov    $0x1007dbf,%esi
 104ef5f:	mov    %rbp,%rdi
 104ef62:	vzeroupper
 104ef65:	call   108be4e <fail>
 104ef6a:	vmovd  -0x4d652(%rip),%xmm15        # 1001920 <__abi_tag+0x1624>
 104ef72:	vmovd  -0x4d5fa(%rip),%xmm14        # 1001980 <__abi_tag+0x1684>
 104ef7a:	vmovd  -0x4d592(%rip),%xmm13        # 10019f0 <__abi_tag+0x16f4>
 104ef82:	vmovd  -0x4d5ea(%rip),%xmm12        # 10019a0 <__abi_tag+0x16a4>
 104ef8a:	vpxor  %xmm11,%xmm11,%xmm11
 104ef8f:	xor    %ebx,%ebx
 104ef91:	jmp    104eec9 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x6f9>
 104ef96:	mov    0x18(%rsi),%rax
 104ef9a:	mov    0x14(%rsi),%ecx
 104ef9d:	lea    (%rax,%rcx,1),%rdi
 104efa1:	add    $0x18,%rdi
 104efa5:	testb  $0x4,0x6c234(%rip)        # 10bb1e0 <myl_lit_8c12e724a44132b907ad7be4d7bffd05d284ce5c644f94f5ab8dbc188941e631_instance+0x20>
 104efac:	mov    0x6c235(%rip),%rax        # 10bb1e8 <myl_lit_8c12e724a44132b907ad7be4d7bffd05d284ce5c644f94f5ab8dbc188941e631_instance+0x28>
 104efb3:	mov    0x6c22b(%rip),%ecx        # 10bb1e4 <myl_lit_8c12e724a44132b907ad7be4d7bffd05d284ce5c644f94f5ab8dbc188941e631_instance+0x24>
 104efb9:	lea    0x18(%rax,%rcx,1),%rcx
 104efbe:	mov    $0x10bb1e8,%eax
 104efc3:	cmovne %rcx,%rax
 104efc7:	cmp    $0x10,%rdx
 104efcb:	ja     104efe8 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x818>
 104efcd:	cmp    $0x8,%rdx
 104efd1:	jb     104f003 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x833>
 104efd3:	mov    (%rdi),%rcx
 104efd6:	mov    -0x8(%rdi,%rdx,1),%rdi
 104efdb:	xor    (%rax),%rcx
 104efde:	xor    -0x8(%rax,%rdx,1),%rdi
 104efe3:	or     %rcx,%rdi
 104efe6:	jmp    104f048 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x878>
 104efe8:	mov    %rsi,%r14
 104efeb:	mov    %rax,%rsi
 104efee:	cmp    $0x100,%rdx
 104eff5:	ja     104f019 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x849>
 104eff7:	call   10ad360 <bcmp@plt>
 104effc:	test   %eax,%eax
 104effe:	setne  %bl
 104f001:	jmp    104f023 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x853>
 104f003:	cmp    $0x4,%rdx
 104f007:	jb     104f028 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x858>
 104f009:	mov    (%rdi),%ecx
 104f00b:	mov    -0x4(%rdi,%rdx,1),%edi
 104f00f:	xor    (%rax),%ecx
 104f011:	xor    -0x4(%rax,%rdx,1),%edi
 104f015:	or     %ecx,%edi
 104f017:	jmp    104f048 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x878>
 104f019:	call   1093490 <equal_large_octets>
 104f01e:	test   %eax,%eax
 104f020:	sete   %bl
 104f023:	mov    %r14,%rsi
 104f026:	jmp    104f04e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x87e>
 104f028:	cmp    $0x1,%rdx
 104f02c:	jne    104f035 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x865>
 104f02e:	movzbl (%rdi),%ecx
 104f031:	cmp    (%rax),%cl
 104f033:	jmp    104f048 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x878>
 104f035:	movzwl (%rdi),%ecx
 104f038:	movzwl -0x2(%rdi,%rdx,1),%edi
 104f03d:	xor    (%rax),%cx
 104f040:	xor    -0x2(%rax,%rdx,1),%di
 104f045:	or     %cx,%di
 104f048:	sete   %bl
 104f04b:	xor    $0x1,%bl
 104f04e:	test   %r13,0x6c16b(%rip)        # 10bb1c0 <myl_lit_8c12e724a44132b907ad7be4d7bffd05d284ce5c644f94f5ab8dbc188941e631_instance>
 104f055:	je     104f084 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x8b4>
 104f057:	test   %bl,%bl
 104f059:	je     104f0a9 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x8d9>
 104f05b:	movq   $0x10bb020,0x70(%rsp)
 104f064:	movq   $0x10bb020,0xc8(%rsp)
 104f070:	cmp    $0x10bb020,%rsi
 104f077:	jne    104f111 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x941>
 104f07d:	xor    %ebx,%ebx
 104f07f:	jmp    104f4db <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xd0b>
 104f084:	mov    0x6c125(%rip),%rax        # 10bb1b0 <myl_lit_842ab9229ccb9156d5ed82c31992b7b48b2d840046545e9d568e989652f87fd6_instance+0x20>
 104f08b:	dec    %rax
 104f08e:	jne    104f09e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x8ce>
 104f090:	cmpq   $0x0,0x6c120(%rip)        # 10bb1b8 <myl_lit_842ab9229ccb9156d5ed82c31992b7b48b2d840046545e9d568e989652f87fd6_instance+0x28>
 104f098:	je     104f34a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xb7a>
 104f09e:	mov    %rax,0x6c10b(%rip)        # 10bb1b0 <myl_lit_842ab9229ccb9156d5ed82c31992b7b48b2d840046545e9d568e989652f87fd6_instance+0x20>
 104f0a5:	test   %bl,%bl
 104f0a7:	jne    104f05b <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x88b>
 104f0a9:	mov    0x8(%r15),%rax
 104f0ad:	mov    0x8(%rsp),%rsi
 104f0b2:	and    $0x3,%esi
 104f0b5:	mov    (%rax),%rdx
 104f0b8:	cmp    %rdx,%rsi
 104f0bb:	jae    1051cfa <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x352a>
 104f0c1:	mov    0x10(%r15),%rcx
 104f0c5:	mov    (%rcx),%rdx
 104f0c8:	cmp    %rdx,%rsi
 104f0cb:	jae    1051d04 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3534>
 104f0d1:	mov    0x20(%rax),%rax
 104f0d5:	shl    $0x3,%esi
 104f0d8:	mov    (%rax,%rsi,1),%rdi
 104f0dc:	mov    0x20(%rcx),%rax
 104f0e0:	mov    (%rax,%rsi,1),%rsi
 104f0e4:	mov    $0x1,%eax
 104f0e9:	cmp    %rsi,%rdi
 104f0ec:	jne    104f149 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x979>
 104f0ee:	mov    %eax,%eax
 104f0f0:	cmpq   $0x1,0x28(%rsp)
 104f0f6:	jne    104f17c <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x9ac>
 104f0fc:	add    $0x258,%rsp
 104f103:	pop    %rbx
 104f104:	pop    %r12
 104f106:	pop    %r13
 104f108:	pop    %r14
 104f10a:	pop    %r15
 104f10c:	pop    %rbp
 104f10d:	vzeroupper
 104f110:	ret
 104f111:	mov    $0x1,%bl
 104f113:	test   %rsi,%rsi
 104f116:	je     104f4db <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xd0b>
 104f11c:	mov    0x8(%rsi),%rdx
 104f120:	cmp    0x6bf01(%rip),%rdx        # 10bb028 <myl_lit_7afa21b5dfd0bec52f3c46b131c861acf738a60d12be67523b48ae28324a1934_instance+0x18>
 104f127:	jne    104f4db <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xd0b>
 104f12d:	test   %rdx,%rdx
 104f130:	je     104f07d <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x8ad>
 104f136:	testb  $0x4,0x10(%rsi)
 104f13a:	jne    104f374 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xba4>
 104f140:	lea    0x18(%rsi),%rdi
 104f144:	jmp    104f383 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xbb3>
 104f149:	xor    %eax,%eax
 104f14b:	test   %rdi,%rdi
 104f14e:	je     104f0ee <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x91e>
 104f150:	test   %rsi,%rsi
 104f153:	je     104f0ee <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x91e>
 104f155:	mov    0x8(%rdi),%rdx
 104f159:	cmp    0x8(%rsi),%rdx
 104f15d:	jne    104f0ee <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x91e>
 104f15f:	mov    $0x1,%eax
 104f164:	test   %rdx,%rdx
 104f167:	je     104f0ee <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x91e>
 104f169:	testb  $0x4,0x10(%rdi)
 104f16d:	jne    104f3ef <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xc1f>
 104f173:	add    $0x18,%rdi
 104f177:	jmp    104f3fe <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xc2e>
 104f17c:	mov    $0x1,%ebx
 104f181:	movabs $0x89705f3112a28fe5,%r14
 104f18b:	jmp    104f1e9 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xa19>
 104f18d:	call   1093490 <equal_large_octets>
 104f192:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 104f1a0:	mov    %eax,%eax
 104f1a2:	mov    %r15,%rcx
 104f1a5:	add    %rax,%rcx
 104f1a8:	mov    %rcx,%rax
 104f1ab:	imul   %r14
 104f1ae:	add    %rcx,%rdx
 104f1b1:	mov    %rdx,%rax
 104f1b4:	shr    $0x3f,%rax
 104f1b8:	sar    $0x1d,%rdx
 104f1bc:	add    %rax,%rdx
 104f1bf:	imul   $0x3b9aca07,%rdx,%rax
 104f1c6:	sub    %rax,%rcx
 104f1c9:	mov    %rcx,%rax
 104f1cc:	sar    $0x3f,%rax
 104f1d0:	and    $0x3b9aca07,%eax
 104f1d5:	add    %rax,%rcx
 104f1d8:	mov    %rcx,%rax
 104f1db:	inc    %rbx
 104f1de:	cmp    %rbx,0x28(%rsp)
 104f1e3:	je     104f0fc <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x92c>
 104f1e9:	mov    0x8(%rsp),%rsi
 104f1ee:	add    %rbx,%rsi
 104f1f1:	jo     1051d0e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x353e>
 104f1f7:	mov    %rax,%r15
 104f1fa:	mov    0x30(%rsp),%rcx
 104f1ff:	mov    0x8(%rcx),%rax
 104f203:	and    $0x3,%esi
 104f206:	mov    (%rax),%rdx
 104f209:	cmp    %rdx,%rsi
 104f20c:	jae    1051cfa <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x352a>
 104f212:	mov    0x10(%rcx),%rcx
 104f216:	mov    (%rcx),%rdx
 104f219:	cmp    %rdx,%rsi
 104f21c:	jae    1051d04 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3534>
 104f222:	mov    0x20(%rax),%rax
 104f226:	shl    $0x3,%esi
 104f229:	mov    (%rax,%rsi,1),%rdi
 104f22d:	mov    0x20(%rcx),%rax
 104f231:	mov    (%rax,%rsi,1),%rsi
 104f235:	mov    $0x1,%eax
 104f23a:	cmp    %rsi,%rdi
 104f23d:	je     104f1a0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x9d0>
 104f243:	xor    %eax,%eax
 104f245:	test   %rdi,%rdi
 104f248:	je     104f1a0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x9d0>
 104f24e:	test   %rsi,%rsi
 104f251:	je     104f1a0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x9d0>
 104f257:	mov    0x8(%rdi),%rdx
 104f25b:	cmp    0x8(%rsi),%rdx
 104f25f:	jne    104f1a0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x9d0>
 104f265:	mov    $0x1,%eax
 104f26a:	test   %rdx,%rdx
 104f26d:	je     104f1a0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x9d0>
 104f273:	testb  $0x4,0x10(%rdi)
 104f277:	jne    104f2b8 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xae8>
 104f279:	add    $0x18,%rdi
 104f27d:	testb  $0x4,0x10(%rsi)
 104f281:	je     104f2cd <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xafd>
 104f283:	mov    0x18(%rsi),%rax
 104f287:	mov    0x14(%rsi),%ecx
 104f28a:	lea    (%rax,%rcx,1),%rsi
 104f28e:	add    $0x18,%rsi
 104f292:	cmp    $0x10,%rdx
 104f296:	jbe    104f2d7 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xb07>
 104f298:	cmp    $0x100,%rdx
 104f29f:	ja     104f18d <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x9bd>
 104f2a5:	call   10ad360 <bcmp@plt>
 104f2aa:	mov    %eax,%ecx
 104f2ac:	xor    %eax,%eax
 104f2ae:	test   %ecx,%ecx
 104f2b0:	sete   %al
 104f2b3:	jmp    104f1a0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x9d0>
 104f2b8:	mov    0x18(%rdi),%rax
 104f2bc:	mov    0x14(%rdi),%ecx
 104f2bf:	lea    (%rax,%rcx,1),%rdi
 104f2c3:	add    $0x18,%rdi
 104f2c7:	testb  $0x4,0x10(%rsi)
 104f2cb:	jne    104f283 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xab3>
 104f2cd:	add    $0x18,%rsi
 104f2d1:	cmp    $0x10,%rdx
 104f2d5:	ja     104f298 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xac8>
 104f2d7:	cmp    $0x8,%rdx
 104f2db:	jb     104f2fa <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xb2a>
 104f2dd:	mov    (%rdi),%rcx
 104f2e0:	mov    -0x8(%rdi,%rdx,1),%rdi
 104f2e5:	xor    (%rsi),%rcx
 104f2e8:	xor    -0x8(%rsi,%rdx,1),%rdi
 104f2ed:	xor    %eax,%eax
 104f2ef:	or     %rcx,%rdi
 104f2f2:	sete   %al
 104f2f5:	jmp    104f1a0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x9d0>
 104f2fa:	cmp    $0x4,%rdx
 104f2fe:	jb     104f318 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xb48>
 104f300:	mov    (%rdi),%ecx
 104f302:	mov    -0x4(%rdi,%rdx,1),%edi
 104f306:	xor    (%rsi),%ecx
 104f308:	xor    -0x4(%rsi,%rdx,1),%edi
 104f30c:	xor    %eax,%eax
 104f30e:	or     %ecx,%edi
 104f310:	sete   %al
 104f313:	jmp    104f1a0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x9d0>
 104f318:	cmp    $0x1,%rdx
 104f31c:	jne    104f32d <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xb5d>
 104f31e:	movzbl (%rdi),%ecx
 104f321:	xor    %eax,%eax
 104f323:	cmp    (%rsi),%cl
 104f325:	sete   %al
 104f328:	jmp    104f1a0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x9d0>
 104f32d:	movzwl (%rdi),%ecx
 104f330:	movzwl -0x2(%rdi,%rdx,1),%edi
 104f335:	xor    (%rsi),%cx
 104f338:	xor    -0x2(%rsi,%rdx,1),%di
 104f33d:	xor    %eax,%eax
 104f33f:	or     %cx,%di
 104f342:	sete   %al
 104f345:	jmp    104f1a0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x9d0>
 104f34a:	lea    0xc8(%rsp),%rax
 104f352:	lea    0x258(%rbp),%rdi
 104f359:	mov    %rsi,%r14
 104f35c:	mov    %rax,%rsi
 104f35f:	call   1087900 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop>
 104f364:	mov    %r14,%rsi
 104f367:	test   %bl,%bl
 104f369:	jne    104f05b <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x88b>
 104f36f:	jmp    104f0a9 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x8d9>
 104f374:	mov    0x18(%rsi),%rax
 104f378:	mov    0x14(%rsi),%ecx
 104f37b:	lea    (%rax,%rcx,1),%rdi
 104f37f:	add    $0x18,%rdi
 104f383:	testb  $0x4,0x6bca6(%rip)        # 10bb030 <myl_lit_7afa21b5dfd0bec52f3c46b131c861acf738a60d12be67523b48ae28324a1934_instance+0x20>
 104f38a:	mov    0x6bca7(%rip),%rax        # 10bb038 <myl_lit_7afa21b5dfd0bec52f3c46b131c861acf738a60d12be67523b48ae28324a1934_instance+0x28>
 104f391:	mov    0x6bc9d(%rip),%ecx        # 10bb034 <myl_lit_7afa21b5dfd0bec52f3c46b131c861acf738a60d12be67523b48ae28324a1934_instance+0x24>
 104f397:	lea    0x18(%rax,%rcx,1),%rcx
 104f39c:	mov    $0x10bb038,%eax
 104f3a1:	cmovne %rcx,%rax
 104f3a5:	cmp    $0x10,%rdx
 104f3a9:	ja     104f3cd <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xbfd>
 104f3ab:	cmp    $0x8,%rdx
 104f3af:	jb     104f459 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xc89>
 104f3b5:	mov    (%rdi),%rcx
 104f3b8:	mov    -0x8(%rdi,%rdx,1),%rdi
 104f3bd:	xor    (%rax),%rcx
 104f3c0:	xor    -0x8(%rax,%rdx,1),%rdi
 104f3c5:	or     %rcx,%rdi
 104f3c8:	jmp    104f4d5 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xd05>
 104f3cd:	mov    %rsi,%r14
 104f3d0:	mov    %rax,%rsi
 104f3d3:	cmp    $0x100,%rdx
 104f3da:	ja     104f46f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xc9f>
 104f3e0:	call   10ad360 <bcmp@plt>
 104f3e5:	test   %eax,%eax
 104f3e7:	setne  %bl
 104f3ea:	jmp    104f479 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xca9>
 104f3ef:	mov    0x18(%rdi),%rax
 104f3f3:	mov    0x14(%rdi),%ecx
 104f3f6:	lea    (%rax,%rcx,1),%rdi
 104f3fa:	add    $0x18,%rdi
 104f3fe:	testb  $0x4,0x10(%rsi)
 104f402:	jne    104f40a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xc3a>
 104f404:	add    $0x18,%rsi
 104f408:	jmp    104f419 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xc49>
 104f40a:	mov    0x18(%rsi),%rax
 104f40e:	mov    0x14(%rsi),%ecx
 104f411:	lea    (%rax,%rcx,1),%rsi
 104f415:	add    $0x18,%rsi
 104f419:	cmp    $0x11,%rdx
 104f41d:	jae    104f43d <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xc6d>
 104f41f:	cmp    $0x7,%rdx
 104f423:	jbe    104f47e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xcae>
 104f425:	mov    (%rdi),%rax
 104f428:	mov    -0x8(%rdi,%rdx,1),%rcx
 104f42d:	xor    (%rsi),%rax
 104f430:	xor    -0x8(%rsi,%rdx,1),%rcx
 104f435:	or     %rax,%rcx
 104f438:	jmp    104f82c <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x105c>
 104f43d:	cmp    $0x101,%rdx
 104f444:	jae    104f497 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xcc7>
 104f446:	call   10ad360 <bcmp@plt>
 104f44b:	mov    %eax,%ecx
 104f44d:	xor    %eax,%eax
 104f44f:	test   %ecx,%ecx
 104f451:	sete   %al
 104f454:	jmp    104f0ee <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x91e>
 104f459:	cmp    $0x4,%rdx
 104f45d:	jb     104f4a1 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xcd1>
 104f45f:	mov    (%rdi),%ecx
 104f461:	mov    -0x4(%rdi,%rdx,1),%edi
 104f465:	xor    (%rax),%ecx
 104f467:	xor    -0x4(%rax,%rdx,1),%edi
 104f46b:	or     %ecx,%edi
 104f46d:	jmp    104f4d5 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xd05>
 104f46f:	call   1093490 <equal_large_octets>
 104f474:	test   %eax,%eax
 104f476:	sete   %bl
 104f479:	mov    %r14,%rsi
 104f47c:	jmp    104f4db <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xd0b>
 104f47e:	cmp    $0x3,%rdx
 104f482:	jbe    104f4ae <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xcde>
 104f484:	mov    (%rdi),%eax
 104f486:	mov    -0x4(%rdi,%rdx,1),%ecx
 104f48a:	xor    (%rsi),%eax
 104f48c:	xor    -0x4(%rsi,%rdx,1),%ecx
 104f490:	or     %eax,%ecx
 104f492:	jmp    104f82c <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x105c>
 104f497:	call   1093490 <equal_large_octets>
 104f49c:	jmp    104f0ee <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x91e>
 104f4a1:	cmp    $0x1,%rdx
 104f4a5:	jne    104f4c2 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xcf2>
 104f4a7:	movzbl (%rdi),%ecx
 104f4aa:	cmp    (%rax),%cl
 104f4ac:	jmp    104f4d5 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xd05>
 104f4ae:	cmp    $0x1,%rdx
 104f4b2:	jne    104f819 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1049>
 104f4b8:	movzbl (%rdi),%eax
 104f4bb:	cmp    (%rsi),%al
 104f4bd:	jmp    104f82c <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x105c>
 104f4c2:	movzwl (%rdi),%ecx
 104f4c5:	movzwl -0x2(%rdi,%rdx,1),%edi
 104f4ca:	xor    (%rax),%cx
 104f4cd:	xor    -0x2(%rax,%rdx,1),%di
 104f4d2:	or     %cx,%di
 104f4d5:	sete   %bl
 104f4d8:	xor    $0x1,%bl
 104f4db:	test   %r13,0x6bb2e(%rip)        # 10bb010 <myl_lit_7afa21b5dfd0bec52f3c46b131c861acf738a60d12be67523b48ae28324a1934_instance>
 104f4e2:	je     104f51a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xd4a>
 104f4e4:	test   %bl,%bl
 104f4e6:	je     104f53f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xd6f>
 104f4e8:	movq   $0x10baca8,0x38(%rsp)
 104f4f1:	movq   $0x10baca8,0x70(%rsp)
 104f4fa:	movq   $0x10baca8,0xc8(%rsp)
 104f506:	cmp    $0x10baca8,%rsi
 104f50d:	jne    104f71f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xf4f>
 104f513:	xor    %ebx,%ebx
 104f515:	jmp    104f850 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1080>
 104f51a:	mov    0x6badf(%rip),%rax        # 10bb000 <myl_lit_7a43bb86b2bccf6ad7e922d1f9ee2e9c1abbad0e5e2f1aa80d1ed73fc964ae92_instance+0x20>
 104f521:	dec    %rax
 104f524:	jne    104f534 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xd64>
 104f526:	cmpq   $0x0,0x6bada(%rip)        # 10bb008 <myl_lit_7a43bb86b2bccf6ad7e922d1f9ee2e9c1abbad0e5e2f1aa80d1ed73fc964ae92_instance+0x28>
 104f52e:	je     104f750 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xf80>
 104f534:	mov    %rax,0x6bac5(%rip)        # 10bb000 <myl_lit_7a43bb86b2bccf6ad7e922d1f9ee2e9c1abbad0e5e2f1aa80d1ed73fc964ae92_instance+0x20>
 104f53b:	test   %bl,%bl
 104f53d:	jne    104f4e8 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xd18>
 104f53f:	xor    %eax,%eax
 104f541:	movabs $0x89705f3112a28fe5,%rdi
 104f54b:	xor    %ebx,%ebx
 104f54d:	nopl   (%rax)
 104f550:	mov    0x8(%rsp),%rsi
 104f555:	add    %rbx,%rsi
 104f558:	jo     1051d20 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3550>
 104f55e:	mov    %rax,%r13
 104f561:	mov    0x30(%rsp),%rcx
 104f566:	mov    0x8(%rcx),%rax
 104f56a:	cmpq   $0x0,(%rax)
 104f56e:	je     1051d32 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3562>
 104f574:	mov    0x20(%rax),%rax
 104f578:	mov    (%rax),%r14
 104f57b:	test   %r14,%r14
 104f57e:	je     104f5a1 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xdd1>
 104f580:	movabs $0x4000000000000002,%rax
 104f58a:	test   %rax,-0x10(%r14)
 104f58e:	jne    104f5a1 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xdd1>
 104f590:	mov    -0x18(%r14),%rax
 104f594:	inc    %rax
 104f597:	je     1051019 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2849>
 104f59d:	mov    %rax,-0x18(%r14)
 104f5a1:	mov    %r14,0x70(%rsp)
 104f5a6:	mov    0x10(%rcx),%rax
 104f5aa:	and    $0x3,%esi
 104f5ad:	mov    (%rax),%rdx
 104f5b0:	cmp    %rdx,%rsi
 104f5b3:	jae    1051d3e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x356e>
 104f5b9:	mov    0x20(%rax),%rax
 104f5bd:	mov    (%rax,%rsi,8),%rax
 104f5c1:	mov    (%rax),%rcx
 104f5c4:	test   %rcx,%rcx
 104f5c7:	je     104f600 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xe30>
 104f5c9:	mov    $0xffffffffffffffff,%r15
 104f5d0:	cmp    (%r14),%rcx
 104f5d3:	ja     104f660 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xe90>
 104f5d9:	mov    0x10(%r14),%ebp
 104f5dd:	test   $0x4,%bpl
 104f5e1:	jne    104f605 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xe35>
 104f5e3:	lea    0x18(%r14),%rdi
 104f5e7:	testb  $0x4,0x10(%rax)
 104f5eb:	je     104f61b <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xe4b>
 104f5ed:	mov    0x18(%rax),%rcx
 104f5f1:	mov    0x14(%rax),%edx
 104f5f4:	add    %rcx,%rdx
 104f5f7:	add    $0x18,%rdx
 104f5fb:	jmp    104f61f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xe4f>
 104f5fd:	nopl   (%rax)
 104f600:	xor    %r15d,%r15d
 104f603:	jmp    104f660 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xe90>
 104f605:	mov    0x18(%r14),%rcx
 104f609:	mov    0x14(%r14),%edx
 104f60d:	lea    (%rcx,%rdx,1),%rdi
 104f611:	add    $0x18,%rdi
 104f615:	testb  $0x4,0x10(%rax)
 104f619:	jne    104f5ed <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xe1d>
 104f61b:	lea    0x18(%rax),%rdx
 104f61f:	mov    0x8(%r14),%rsi
 104f623:	mov    0x8(%rax),%rcx
 104f627:	call   1093500 <myl_native_octets_find>
 104f62c:	cmp    $0xffffffffffffffff,%rax
 104f630:	movabs $0x89705f3112a28fe5,%rdi
 104f63a:	je     104f660 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xe90>
 104f63c:	test   $0x1,%bpl
 104f640:	jne    104f657 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xe87>
 104f642:	mov    %r14,%rdi
 104f645:	mov    %rax,%rsi
 104f648:	call   1090f30 <index_walk>
 104f64d:	movabs $0x89705f3112a28fe5,%rdi
 104f657:	mov    %rax,%r15
 104f65a:	nopw   0x0(%rax,%rax,1)
 104f660:	mov    %r15,%r12
 104f663:	inc    %r12
 104f666:	jo     1051d46 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3576>
 104f66c:	test   %r14,%r14
 104f66f:	mov    0x10(%rsp),%rbp
 104f674:	je     104f69a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xeca>
 104f676:	movabs $0x4000000000000002,%rax
 104f680:	test   %rax,-0x10(%r14)
 104f684:	jne    104f69a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xeca>
 104f686:	mov    -0x18(%r14),%rax
 104f68a:	dec    %rax
 104f68d:	jne    104f696 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xec6>
 104f68f:	cmpq   $0x0,-0x20(%r14)
 104f694:	je     104f6e5 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xf15>
 104f696:	mov    %rax,-0x18(%r14)
 104f69a:	mov    %r13,%rcx
 104f69d:	add    %r12,%rcx
 104f6a0:	jo     104f70f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xf3f>
 104f6a2:	mov    %rcx,%rax
 104f6a5:	imul   %rdi
 104f6a8:	add    %rcx,%rdx
 104f6ab:	mov    %rdx,%rax
 104f6ae:	shr    $0x3f,%rax
 104f6b2:	sar    $0x1d,%rdx
 104f6b6:	add    %rax,%rdx
 104f6b9:	imul   $0x3b9aca07,%rdx,%rax
 104f6c0:	sub    %rax,%rcx
 104f6c3:	mov    %rcx,%rax
 104f6c6:	sar    $0x3f,%rax
 104f6ca:	and    $0x3b9aca07,%eax
 104f6cf:	add    %rcx,%rax
 104f6d2:	inc    %rbx
 104f6d5:	cmp    %rbx,0x28(%rsp)
 104f6da:	jne    104f550 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xd80>
 104f6e0:	jmp    104f0fc <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x92c>
 104f6e5:	mov    0x18(%rsp),%r15
 104f6ea:	mov    %r15,%rdi
 104f6ed:	mov    %r14,%rsi
 104f6f0:	call   109bcd0 <myl_rc_hold_edge_release>
 104f6f5:	mov    %r15,%rdi
 104f6f8:	call   109ecf0 <myl_rc_drain>
 104f6fd:	movabs $0x89705f3112a28fe5,%rdi
 104f707:	mov    %r13,%rcx
 104f70a:	add    %r12,%rcx
 104f70d:	jno    104f6a2 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xed2>
 104f70f:	mov    %rbp,%rdi
 104f712:	xor    %esi,%esi
 104f714:	mov    %r13,%rdx
 104f717:	mov    %r12,%rcx
 104f71a:	call   108c860 <myl_qbe_fail_overflow_op>
 104f71f:	mov    $0x1,%bl
 104f721:	test   %rsi,%rsi
 104f724:	je     104f850 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1080>
 104f72a:	mov    0x8(%rsi),%rdx
 104f72e:	cmp    0x6b57b(%rip),%rdx        # 10bacb0 <myl_lit_4d6ff6f7284ab5ea56c67ebc627dbe0fd0bb153a04fdd105bd867658d486b6d7_instance+0x18>
 104f735:	jne    104f850 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1080>
 104f73b:	test   %rdx,%rdx
 104f73e:	je     104f513 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xd43>
 104f744:	testb  $0x4,0x10(%rsi)
 104f748:	jne    104f77a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xfaa>
 104f74a:	lea    0x18(%rsi),%rdi
 104f74e:	jmp    104f789 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xfb9>
 104f750:	lea    0xc8(%rsp),%rax
 104f758:	lea    0x258(%rbp),%rdi
 104f75f:	mov    %rsi,%r14
 104f762:	mov    %rax,%rsi
 104f765:	call   1087900 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop>
 104f76a:	mov    %r14,%rsi
 104f76d:	test   %bl,%bl
 104f76f:	jne    104f4e8 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xd18>
 104f775:	jmp    104f53f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xd6f>
 104f77a:	mov    0x18(%rsi),%rax
 104f77e:	mov    0x14(%rsi),%ecx
 104f781:	lea    (%rax,%rcx,1),%rdi
 104f785:	add    $0x18,%rdi
 104f789:	testb  $0x4,0x6b528(%rip)        # 10bacb8 <myl_lit_4d6ff6f7284ab5ea56c67ebc627dbe0fd0bb153a04fdd105bd867658d486b6d7_instance+0x20>
 104f790:	mov    0x6b529(%rip),%rax        # 10bacc0 <myl_lit_4d6ff6f7284ab5ea56c67ebc627dbe0fd0bb153a04fdd105bd867658d486b6d7_instance+0x28>
 104f797:	mov    0x6b51f(%rip),%ecx        # 10bacbc <myl_lit_4d6ff6f7284ab5ea56c67ebc627dbe0fd0bb153a04fdd105bd867658d486b6d7_instance+0x24>
 104f79d:	lea    0x18(%rax,%rcx,1),%rcx
 104f7a2:	mov    $0x10bacc0,%eax
 104f7a7:	cmovne %rcx,%rax
 104f7ab:	cmp    $0x10,%rdx
 104f7af:	ja     104f7cc <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xffc>
 104f7b1:	cmp    $0x8,%rdx
 104f7b5:	jb     104f7e7 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1017>
 104f7b7:	mov    (%rdi),%rcx
 104f7ba:	mov    -0x8(%rdi,%rdx,1),%rdi
 104f7bf:	xor    (%rax),%rcx
 104f7c2:	xor    -0x8(%rax,%rdx,1),%rdi
 104f7c7:	or     %rcx,%rdi
 104f7ca:	jmp    104f84a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x107a>
 104f7cc:	mov    %rsi,%r14
 104f7cf:	mov    %rax,%rsi
 104f7d2:	cmp    $0x100,%rdx
 104f7d9:	ja     104f7fd <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x102d>
 104f7db:	call   10ad360 <bcmp@plt>
 104f7e0:	test   %eax,%eax
 104f7e2:	setne  %bl
 104f7e5:	jmp    104f807 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1037>
 104f7e7:	cmp    $0x4,%rdx
 104f7eb:	jb     104f80c <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x103c>
 104f7ed:	mov    (%rdi),%ecx
 104f7ef:	mov    -0x4(%rdi,%rdx,1),%edi
 104f7f3:	xor    (%rax),%ecx
 104f7f5:	xor    -0x4(%rax,%rdx,1),%edi
 104f7f9:	or     %ecx,%edi
 104f7fb:	jmp    104f84a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x107a>
 104f7fd:	call   1093490 <equal_large_octets>
 104f802:	test   %eax,%eax
 104f804:	sete   %bl
 104f807:	mov    %r14,%rsi
 104f80a:	jmp    104f850 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1080>
 104f80c:	cmp    $0x1,%rdx
 104f810:	jne    104f837 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1067>
 104f812:	movzbl (%rdi),%ecx
 104f815:	cmp    (%rax),%cl
 104f817:	jmp    104f84a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x107a>
 104f819:	movzwl (%rdi),%eax
 104f81c:	movzwl -0x2(%rdi,%rdx,1),%ecx
 104f821:	xor    (%rsi),%ax
 104f824:	xor    -0x2(%rsi,%rdx,1),%cx
 104f829:	or     %ax,%cx
 104f82c:	sete   %al
 104f82f:	movzbl %al,%eax
 104f832:	jmp    104f0ee <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x91e>
 104f837:	movzwl (%rdi),%ecx
 104f83a:	movzwl -0x2(%rdi,%rdx,1),%edi
 104f83f:	xor    (%rax),%cx
 104f842:	xor    -0x2(%rax,%rdx,1),%di
 104f847:	or     %cx,%di
 104f84a:	sete   %bl
 104f84d:	xor    $0x1,%bl
 104f850:	test   %r13,0x6b441(%rip)        # 10bac98 <myl_lit_4d6ff6f7284ab5ea56c67ebc627dbe0fd0bb153a04fdd105bd867658d486b6d7_instance>
 104f857:	je     104f886 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x10b6>
 104f859:	test   %bl,%bl
 104f85b:	je     104f8ab <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x10db>
 104f85d:	movq   $0x10bab70,0x70(%rsp)
 104f866:	movq   $0x10bab70,0xc8(%rsp)
 104f872:	cmp    $0x10bab70,%rsi
 104f879:	jne    1050999 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x21c9>
 104f87f:	xor    %ebx,%ebx
 104f881:	jmp    1050b17 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2347>
 104f886:	mov    0x6b3fb(%rip),%rax        # 10bac88 <myl_lit_4b4df4d43798003d79847faa0fc7a8aff0b04bace93d5fc2cc109ef7308827f6_instance+0x38>
 104f88d:	dec    %rax
 104f890:	jne    104f8a0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x10d0>
 104f892:	cmpq   $0x0,0x6b3f6(%rip)        # 10bac90 <myl_lit_4b4df4d43798003d79847faa0fc7a8aff0b04bace93d5fc2cc109ef7308827f6_instance+0x40>
 104f89a:	je     1050a35 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2265>
 104f8a0:	mov    %rax,0x6b3e1(%rip)        # 10bac88 <myl_lit_4b4df4d43798003d79847faa0fc7a8aff0b04bace93d5fc2cc109ef7308827f6_instance+0x38>
 104f8a7:	test   %bl,%bl
 104f8a9:	jne    104f85d <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x108d>
 104f8ab:	movabs $0x5000000000000000,%rcx
 104f8b5:	movabs $0x101010101010101,%r15
 104f8bf:	lea    0x38(%rsp),%rdx
 104f8c4:	lea    0x70(%rsp),%rsi
 104f8c9:	mov    %rsi,%rax
 104f8cc:	sub    %rdx,%rax
 104f8cf:	sub    %rsi,%rdx
 104f8d2:	cmovb  %rax,%rdx
 104f8d6:	mov    %rdx,0x128(%rsp)
 104f8de:	lea    0x68(%rsp),%rdx
 104f8e3:	lea    0x60(%rsp),%rsi
 104f8e8:	mov    %rsi,%rax
 104f8eb:	sub    %rdx,%rax
 104f8ee:	sub    %rsi,%rdx
 104f8f1:	cmovb  %rax,%rdx
 104f8f5:	mov    %rdx,0x180(%rsp)
 104f8fd:	xor    %r12d,%r12d
 104f900:	lea    0x1(%rcx),%rax
 104f904:	mov    %rax,0x110(%rsp)
 104f90c:	vpbroadcastd -0x48791(%rip),%xmm9        # 1007184 <__abi_tag+0x6e88>
 104f915:	vpbroadcastd -0x4879a(%rip),%ymm10        # 1007184 <__abi_tag+0x6e88>
 104f91e:	vpbroadcastq -0x4880f(%rip),%ymm0        # 1007118 <__abi_tag+0x6e1c>
 104f927:	vmovdqu %ymm0,0x1f0(%rsp)
 104f930:	xor    %eax,%eax
 104f932:	vmovdqa %xmm9,0x50(%rsp)
 104f938:	vmovdqu %ymm10,0xf0(%rsp)
 104f941:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 104f950:	mov    %rax,0x20(%rsp)
 104f955:	mov    0x8(%rsp),%rsi
 104f95a:	add    %r12,%rsi
 104f95d:	jo     1051d65 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3595>
 104f963:	mov    0x30(%rsp),%rax
 104f968:	mov    0x8(%rax),%rax
 104f96c:	and    $0x1,%esi
 104f96f:	mov    (%rax),%rdx
 104f972:	cmp    %rdx,%rsi
 104f975:	jae    1051d5a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x358a>
 104f97b:	mov    0x20(%rax),%rax
 104f97f:	mov    (%rax,%rsi,8),%r14
 104f983:	test   %rsi,%rsi
 104f986:	jne    104fa30 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1260>
 104f98c:	movq   $0x10bb9c0,0x70(%rsp)
 104f995:	movq   $0x10bb9c0,0xc8(%rsp)
 104f9a1:	movq   $0x10bb9c0,0x38(%rsp)
 104f9aa:	mov    0x6bfff(%rip),%rax        # 10bb9b0 <myl_lit_f3eaad558815542caf7da2bdfda9d4cabeaf9c2200b79ab8ff85b21b8470fac6_instance>
 104f9b1:	test   %rax,0x110(%rsp)
 104f9b9:	je     104fac5 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x12f5>
 104f9bf:	cmpq   $0x0,0x128(%rsp)
 104f9c8:	setne  %cl
 104f9cb:	movabs $0x5000000000000000,%rdx
 104f9d5:	test   %rdx,%rax
 104f9d8:	sete   %dl
 104f9db:	mov    $0x10bb9c0,%eax
 104f9e0:	test   %cl,%dl
 104f9e2:	jne    104fac0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x12f0>
 104f9e8:	mov    $0x1030c78,%esi
 104f9ed:	mov    0x18(%rsp),%rdi
 104f9f2:	lea    0x70(%rsp),%rdx
 104f9f7:	lea    0x38(%rsp),%rcx
 104f9fc:	mov    0x44(%rsp),%r8d
 104fa01:	vzeroupper
 104fa04:	call   10a8110 <myl_rc_native_take>
 104fa09:	vmovdqu 0xf0(%rsp),%ymm10
 104fa12:	vmovdqa 0x50(%rsp),%xmm9
 104fa18:	test   %eax,%eax
 104fa1a:	jne    104face <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x12fe>
 104fa20:	jmp    10509d1 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2201>
 104fa25:	data16 cs nopw 0x0(%rax,%rax,1)
 104fa30:	movq   $0x10bad30,0x70(%rsp)
 104fa39:	movq   $0x10bad30,0xc8(%rsp)
 104fa45:	movq   $0x10bad30,0x38(%rsp)
 104fa4e:	mov    0x6b2cb(%rip),%rax        # 10bad20 <myl_lit_54807ae7ae90f7f8ab8705f04b17dcd2d77e7355f27b7f7252156b0c234f7d3f_instance>
 104fa55:	test   %rax,0x110(%rsp)
 104fa5d:	je     104fac5 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x12f5>
 104fa5f:	cmpq   $0x0,0x128(%rsp)
 104fa68:	setne  %cl
 104fa6b:	movabs $0x5000000000000000,%rdx
 104fa75:	test   %rdx,%rax
 104fa78:	sete   %dl
 104fa7b:	mov    $0x10bad30,%eax
 104fa80:	test   %cl,%dl
 104fa82:	jne    104fac0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x12f0>
 104fa84:	mov    $0x1030c78,%esi
 104fa89:	mov    0x18(%rsp),%rdi
 104fa8e:	lea    0x70(%rsp),%rdx
 104fa93:	lea    0x38(%rsp),%rcx
 104fa98:	mov    0x44(%rsp),%r8d
 104fa9d:	vzeroupper
 104faa0:	call   10a8110 <myl_rc_native_take>
 104faa5:	vmovdqu 0xf0(%rsp),%ymm10
 104faae:	vmovdqa 0x50(%rsp),%xmm9
 104fab4:	test   %eax,%eax
 104fab6:	jne    104face <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x12fe>
 104fab8:	jmp    1050a03 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2233>
 104fabd:	nopl   (%rax)
 104fac0:	mov    %rax,0x70(%rsp)
 104fac5:	movq   $0x0,0x38(%rsp)
 104face:	mov    0x70(%rsp),%rdx
 104fad3:	movq   $0x0,0x250(%rsp)
 104fadf:	movq   $0x0,0x230(%rsp)
 104faeb:	cmp    %rsp,0x40(%rbp)
 104faef:	ja     1051d7a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x35aa>
 104faf5:	cmpq   $0x0,(%rdx)
 104faf9:	je     1051d85 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x35b5>
 104faff:	mov    0x2c8(%rbp),%esi
 104fb05:	mov    %r14,0xc0(%rsp)
 104fb0d:	mov    %rdx,0x138(%rsp)
 104fb15:	testb  $0x4,0x10(%r14)
 104fb1a:	jne    104fb40 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1370>
 104fb1c:	lea    0x18(%r14),%rbx
 104fb20:	mov    %r12,0x198(%rsp)
 104fb28:	testb  $0x4,0x10(%rdx)
 104fb2c:	je     104fb5e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x138e>
 104fb2e:	mov    0x18(%rdx),%rax
 104fb32:	mov    0x14(%rdx),%ecx
 104fb35:	lea    (%rax,%rcx,1),%r13
 104fb39:	add    $0x18,%r13
 104fb3d:	jmp    104fb62 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1392>
 104fb3f:	nop
 104fb40:	mov    0x18(%r14),%rax
 104fb44:	mov    0x14(%r14),%ecx
 104fb48:	lea    (%rax,%rcx,1),%rbx
 104fb4c:	add    $0x18,%rbx
 104fb50:	mov    %r12,0x198(%rsp)
 104fb58:	testb  $0x4,0x10(%rdx)
 104fb5c:	jne    104fb2e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x135e>
 104fb5e:	lea    0x18(%rdx),%r13
 104fb62:	mov    0x8(%rdx),%rcx
 104fb66:	mov    0x8(%r14),%r14
 104fb6a:	lea    -0x1(%rcx),%rax
 104fb6e:	cmp    %r14,%rax
 104fb71:	mov    %rcx,0x118(%rsp)
 104fb79:	mov    %rdx,0x190(%rsp)
 104fb81:	mov    %esi,0x124(%rsp)
 104fb88:	jae    104fd80 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x15b0>
 104fb8e:	cmp    $0x1,%rcx
 104fb92:	jne    104fd90 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x15c0>
 104fb98:	movzbl 0x0(%r13),%eax
 104fb9d:	vmovd  %eax,%xmm0
 104fba1:	vpbroadcastb %xmm0,%xmm0
 104fba6:	lea    0x18(%rbx),%rcx
 104fbaa:	xor    %r12d,%r12d
 104fbad:	xor    %edx,%edx
 104fbaf:	mov    $0x10000,%r11d
 104fbb5:	jmp    104fbd2 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1402>
 104fbb7:	nopw   0x0(%rax,%rax,1)
 104fbc0:	mov    %r9d,%edi
 104fbc3:	add    %rdi,%r12
 104fbc6:	add    %rsi,%rdx
 104fbc9:	cmp    %r14,%rdx
 104fbcc:	jae    104fde3 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1613>
 104fbd2:	mov    %r14,%rsi
 104fbd5:	sub    %rdx,%rsi
 104fbd8:	cmp    $0x10000,%rsi
 104fbdf:	cmovae %r11,%rsi
 104fbe3:	mov    %r14,%r8
 104fbe6:	sub    %rdx,%r8
 104fbe9:	jne    104fc00 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1430>
 104fbeb:	xor    %edi,%edi
 104fbed:	add    %rdi,%r12
 104fbf0:	add    %rsi,%rdx
 104fbf3:	cmp    %r14,%rdx
 104fbf6:	jb     104fbd2 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1402>
 104fbf8:	jmp    104fde3 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1613>
 104fbfd:	nopl   (%rax)
 104fc00:	lea    (%rbx,%rdx,1),%rdi
 104fc04:	cmp    $0x3,%r8
 104fc08:	ja     104fc20 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1450>
 104fc0a:	xor    %r8d,%r8d
 104fc0d:	xor    %r9d,%r9d
 104fc10:	jmp    104fd60 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1590>
 104fc15:	data16 cs nopw 0x0(%rax,%rax,1)
 104fc20:	cmp    $0x20,%r8
 104fc24:	jae    104fc31 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1461>
 104fc26:	xor    %r8d,%r8d
 104fc29:	xor    %r9d,%r9d
 104fc2c:	jmp    104fd04 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1534>
 104fc31:	mov    %esi,%r8d
 104fc34:	and    $0x1ffe0,%r8d
 104fc3b:	lea    (%rcx,%rdx,1),%r9
 104fc3f:	vpxor  %xmm1,%xmm1,%xmm1
 104fc43:	xor    %r10d,%r10d
 104fc46:	vpxor  %xmm2,%xmm2,%xmm2
 104fc4a:	vpxor  %xmm3,%xmm3,%xmm3
 104fc4e:	vpxor  %xmm4,%xmm4,%xmm4
 104fc52:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 104fc60:	vmovq  -0x18(%r9,%r10,1),%xmm5
 104fc67:	vmovq  -0x10(%r9,%r10,1),%xmm6
 104fc6e:	vmovq  -0x8(%r9,%r10,1),%xmm7
 104fc75:	vmovq  (%r9,%r10,1),%xmm8
 104fc7b:	vpcmpeqb %xmm0,%xmm5,%xmm5
 104fc7f:	vpmovzxbd %xmm5,%ymm5
 104fc84:	vpand  %ymm5,%ymm10,%ymm5
 104fc88:	vpaddd %ymm5,%ymm1,%ymm1
 104fc8c:	vpcmpeqb %xmm0,%xmm6,%xmm5
 104fc90:	vpmovzxbd %xmm5,%ymm5
 104fc95:	vpand  %ymm5,%ymm10,%ymm5
 104fc99:	vpaddd %ymm5,%ymm2,%ymm2
 104fc9d:	vpcmpeqb %xmm0,%xmm7,%xmm5
 104fca1:	vpmovzxbd %xmm5,%ymm5
 104fca6:	vpand  %ymm5,%ymm10,%ymm5
 104fcaa:	vpaddd %ymm5,%ymm3,%ymm3
 104fcae:	vpcmpeqb %xmm0,%xmm8,%xmm5
 104fcb2:	vpmovzxbd %xmm5,%ymm5
 104fcb7:	vpand  %ymm5,%ymm10,%ymm5
 104fcbb:	vpaddd %ymm5,%ymm4,%ymm4
 104fcbf:	add    $0x20,%r10
 104fcc3:	cmp    %r10,%r8
 104fcc6:	jne    104fc60 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1490>
 104fcc8:	vpaddd %ymm1,%ymm2,%ymm1
 104fccc:	vpaddd %ymm1,%ymm3,%ymm1
 104fcd0:	vpaddd %ymm1,%ymm4,%ymm1
 104fcd4:	vextracti128 $0x1,%ymm1,%xmm2
 104fcda:	vpaddd %xmm2,%xmm1,%xmm1
 104fcde:	vpshufd $0xee,%xmm1,%xmm2
 104fce3:	vpaddd %xmm2,%xmm1,%xmm1
 104fce7:	vpshufd $0x55,%xmm1,%xmm2
 104fcec:	vpaddd %xmm2,%xmm1,%xmm1
 104fcf0:	vmovd  %xmm1,%r9d
 104fcf5:	cmp    %r8,%rsi
 104fcf8:	je     104fbc0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x13f0>
 104fcfe:	test   $0x1c,%sil
 104fd02:	je     104fd60 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1590>
 104fd04:	mov    %r8,%r10
 104fd07:	mov    %esi,%r8d
 104fd0a:	and    $0x1fffc,%r8d
 104fd11:	vmovd  %r9d,%xmm1
 104fd16:	cs nopw 0x0(%rax,%rax,1)
 104fd20:	vmovd  (%rdi,%r10,1),%xmm2
 104fd26:	vpcmpeqb %xmm0,%xmm2,%xmm2
 104fd2a:	vpmovzxbd %xmm2,%xmm2
 104fd2f:	vpand  %xmm2,%xmm9,%xmm2
 104fd33:	vpaddd %xmm2,%xmm1,%xmm1
 104fd37:	add    $0x4,%r10
 104fd3b:	cmp    %r10,%r8
 104fd3e:	jne    104fd20 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1550>
 104fd40:	vpshufd $0xee,%xmm1,%xmm2
 104fd45:	vpaddd %xmm2,%xmm1,%xmm1
 104fd49:	vpshufd $0x55,%xmm1,%xmm2
 104fd4e:	vpaddd %xmm2,%xmm1,%xmm1
 104fd52:	vmovd  %xmm1,%r9d
 104fd57:	jmp    104fd71 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x15a1>
 104fd59:	nopl   0x0(%rax)
 104fd60:	xor    %r10d,%r10d
 104fd63:	cmp    %al,(%rdi,%r8,1)
 104fd67:	sete   %r10b
 104fd6b:	add    %r10d,%r9d
 104fd6e:	inc    %r8
 104fd71:	cmp    %r8,%rsi
 104fd74:	jne    104fd60 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1590>
 104fd76:	jmp    104fbc0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x13f0>
 104fd7b:	nopl   0x0(%rax,%rax,1)
 104fd80:	xor    %r12d,%r12d
 104fd83:	jmp    104fde3 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1613>
 104fd85:	data16 cs nopw 0x0(%rax,%rax,1)
 104fd90:	mov    %rbx,%rdi
 104fd93:	mov    %r14,%rsi
 104fd96:	mov    %r13,%rdx
 104fd99:	vzeroupper
 104fd9c:	call   1093500 <myl_native_octets_find>
 104fda1:	xor    %r12d,%r12d
 104fda4:	xor    %r15d,%r15d
 104fda7:	cmp    $0xffffffffffffffff,%rax
 104fdab:	je     104fdd9 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1609>
 104fdad:	nopl   (%rax)
 104fdb0:	mov    0x118(%rsp),%rcx
 104fdb8:	add    %rcx,%r15
 104fdbb:	add    %rax,%r15
 104fdbe:	inc    %r12
 104fdc1:	lea    (%rbx,%r15,1),%rdi
 104fdc5:	mov    %r14,%rsi
 104fdc8:	sub    %r15,%rsi
 104fdcb:	mov    %r13,%rdx
 104fdce:	call   1093500 <myl_native_octets_find>
 104fdd3:	cmp    $0xffffffffffffffff,%rax
 104fdd7:	jne    104fdb0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x15e0>
 104fdd9:	movabs $0x101010101010101,%r15
 104fde3:	inc    %r12
 104fde6:	mov    0x10(%rsp),%r14
 104fdeb:	mov    0x268(%r14),%rax
 104fdf2:	mov    %rax,0x1a8(%rsp)
 104fdfa:	lea    0xc0(%rsp),%rax
 104fe02:	mov    %rax,0x1b0(%rsp)
 104fe0a:	movq   $0x1031628,0x1b8(%rsp)
 104fe16:	lea    0x1a8(%rsp),%rax
 104fe1e:	mov    %rax,0x160(%rsp)
 104fe26:	lea    0x138(%rsp),%rax
 104fe2e:	mov    %rax,0x168(%rsp)
 104fe36:	movq   $0x1031628,0x170(%rsp)
 104fe42:	lea    0x160(%rsp),%rax
 104fe4a:	mov    %rax,0x268(%r14)
 104fe51:	mov    $0x1031628,%esi
 104fe56:	mov    0x18(%rsp),%rdi
 104fe5b:	mov    %r12,%rdx
 104fe5e:	vzeroupper
 104fe61:	call   108f5d0 <myl_native_list_new>
 104fe66:	mov    %rax,%rbx
 104fe69:	mov    %rax,0xb8(%rsp)
 104fe71:	mov    0x268(%r14),%rax
 104fe78:	mov    %rax,0x140(%rsp)
 104fe80:	lea    0xb8(%rsp),%rax
 104fe88:	mov    %rax,0x148(%rsp)
 104fe90:	movq   $0x1031628,0x150(%rsp)
 104fe9c:	lea    0x140(%rsp),%rax
 104fea4:	mov    %rax,0x268(%r14)
 104feab:	test   %rbx,%rbx
 104feae:	je     10503fc <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1c2c>
 104feb4:	mov    0xc0(%rsp),%r13
 104febc:	mov    0x10(%r13),%ecx
 104fec0:	lea    0x18(%r13),%rax
 104fec4:	mov    %rax,0x98(%rsp)
 104fecc:	mov    %ecx,0xb4(%rsp)
 104fed3:	test   $0x4,%cl
 104fed6:	vmovdqa -0x4e4ae(%rip),%xmm8        # 1001a30 <__abi_tag+0x1734>
 104fede:	vmovdqu 0x1f0(%rsp),%ymm9
 104fee7:	vmovdqa -0x4e4bf(%rip),%xmm10        # 1001a30 <__abi_tag+0x1734>
 104feef:	je     104ff08 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1738>
 104fef1:	mov    0x18(%r13),%rcx
 104fef5:	mov    0x14(%r13),%edx
 104fef9:	add    %rdx,%rcx
 104fefc:	add    $0x18,%rcx
 104ff00:	mov    %rcx,0x98(%rsp)
 104ff08:	mov    0x138(%rsp),%rcx
 104ff10:	testb  $0x4,0x10(%rcx)
 104ff14:	jne    104ff40 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1770>
 104ff16:	add    $0x18,%rcx
 104ff1a:	mov    %rcx,0x130(%rsp)
 104ff22:	mov    %r13,%rcx
 104ff25:	testb  $0x4,0xb4(%rsp)
 104ff2d:	jne    104ff66 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1796>
 104ff2f:	jmp    104ff69 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1799>
 104ff31:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 104ff40:	mov    %rcx,%rdx
 104ff43:	mov    0x18(%rcx),%rcx
 104ff47:	mov    0x14(%rdx),%edx
 104ff4a:	add    %rdx,%rcx
 104ff4d:	add    $0x18,%rcx
 104ff51:	mov    %rcx,0x130(%rsp)
 104ff59:	mov    %r13,%rcx
 104ff5c:	testb  $0x4,0xb4(%rsp)
 104ff64:	je     104ff69 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1799>
 104ff66:	mov    (%rax),%rcx
 104ff69:	mov    0x8(%rcx),%rcx
 104ff6d:	shr    $0x2,%rcx
 104ff71:	cmp    $0xa,%rcx
 104ff75:	mov    $0x9,%eax
 104ff7a:	cmovb  %rax,%rcx
 104ff7e:	mov    %rcx,0x1a0(%rsp)
 104ff86:	mov    0x98(%rsp),%rax
 104ff8e:	add    $0xc,%rax
 104ff92:	mov    %rax,0x188(%rsp)
 104ff9a:	xor    %ebp,%ebp
 104ff9c:	mov    0x118(%rsp),%rcx
 104ffa4:	cmp    $0x1,%r12
 104ffa8:	je     1050050 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1880>
 104ffae:	xchg   %ax,%ax
 104ffb0:	test   %r12,%r12
 104ffb3:	je     10503fe <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1c2e>
 104ffb9:	mov    0x98(%rsp),%rax
 104ffc1:	lea    (%rax,%rbp,1),%rdi
 104ffc5:	mov    0x8(%r13),%rbx
 104ffc9:	mov    %rbx,%rsi
 104ffcc:	sub    %rbp,%rsi
 104ffcf:	mov    0x130(%rsp),%rdx
 104ffd7:	vzeroupper
 104ffda:	call   1093500 <myl_native_octets_find>
 104ffdf:	vmovdqa -0x4e5b7(%rip),%xmm10        # 1001a30 <__abi_tag+0x1734>
 104ffe7:	vmovdqu 0x1f0(%rsp),%ymm9
 104fff0:	vmovdqa -0x4e5c8(%rip),%xmm8        # 1001a30 <__abi_tag+0x1734>
 104fff8:	lea    (%rax,%rbp,1),%r14
 104fffc:	cmp    $0xffffffffffffffff,%rax
 1050000:	cmove  %rbx,%r14
 1050004:	mov    %r14,%rbx
 1050007:	sub    %rbp,%rbx
 105000a:	cmp    0x1a0(%rsp),%rbx
 1050012:	jb     1050064 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1894>
 1050014:	mov    0x18(%rsp),%rdi
 1050019:	mov    %r13,%rsi
 105001c:	mov    %rbp,%rdx
 105001f:	mov    %rbx,%rcx
 1050022:	mov    $0xffffffffffffffff,%r8
 1050029:	vzeroupper
 105002c:	call   1091e90 <long_piece>
 1050031:	mov    %rax,%r15
 1050034:	test   %rax,%rax
 1050037:	jne    10502e0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1b10>
 105003d:	jmp    1050370 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1ba0>
 1050042:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1050050:	mov    0x8(%r13),%r14
 1050054:	mov    %r14,%rbx
 1050057:	sub    %rbp,%rbx
 105005a:	cmp    0x1a0(%rsp),%rbx
 1050062:	jae    1050014 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1844>
 1050064:	mov    0x98(%rsp),%rax
 105006c:	lea    (%rax,%rbp,1),%r13
 1050070:	testb  $0x1,0xb4(%rsp)
 1050078:	jne    105024a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1a7a>
 105007e:	cmp    $0x8,%rbx
 1050082:	jae    1050090 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x18c0>
 1050084:	xor    %ecx,%ecx
 1050086:	xor    %eax,%eax
 1050088:	jmp    10500d7 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1907>
 105008a:	nopw   0x0(%rax,%rax,1)
 1050090:	xor    %edx,%edx
 1050092:	xor    %ecx,%ecx
 1050094:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 10500a0:	mov    0x0(%r13,%rdx,1),%rax
 10500a5:	mov    %rax,%rsi
 10500a8:	not    %rsi
 10500ab:	add    %rsi,%rsi
 10500ae:	and    %rax,%rsi
 10500b1:	shr    $0x7,%rsi
 10500b5:	and    %r15,%rsi
 10500b8:	imul   %r15,%rsi
 10500bc:	shr    $0x38,%rsi
 10500c0:	sub    %rsi,%rcx
 10500c3:	add    $0x8,%rcx
 10500c7:	lea    0x8(%rdx),%rax
 10500cb:	add    $0x10,%rdx
 10500cf:	cmp    %rbx,%rdx
 10500d2:	mov    %rax,%rdx
 10500d5:	jbe    10500a0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x18d0>
 10500d7:	cmp    %rbx,%rax
 10500da:	jae    1050245 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1a75>
 10500e0:	lea    (%rax,%rbp,1),%rdi
 10500e4:	mov    %r14,%rdx
 10500e7:	sub    %rdi,%rdx
 10500ea:	cmp    $0x3,%rdx
 10500ee:	mov    0x98(%rsp),%r8
 10500f6:	jbe    1050220 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1a50>
 10500fc:	cmp    $0x10,%rdx
 1050100:	jae    1050109 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1939>
 1050102:	xor    %esi,%esi
 1050104:	jmp    10501ce <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x19fe>
 1050109:	mov    %rdx,%rsi
 105010c:	and    $0xfffffffffffffff0,%rsi
 1050110:	vmovq  %rcx,%xmm0
 1050115:	add    0x188(%rsp),%rdi
 105011d:	vpxor  %xmm1,%xmm1,%xmm1
 1050121:	xor    %ecx,%ecx
 1050123:	vpxor  %xmm2,%xmm2,%xmm2
 1050127:	vpxor  %xmm3,%xmm3,%xmm3
 105012b:	nopl   0x0(%rax,%rax,1)
 1050130:	vmovd  -0xc(%rdi,%rcx,1),%xmm4
 1050136:	vmovd  -0x8(%rdi,%rcx,1),%xmm5
 105013c:	vmovd  -0x4(%rdi,%rcx,1),%xmm6
 1050142:	vmovd  (%rdi,%rcx,1),%xmm7
 1050147:	vpcmpgtb %xmm10,%xmm4,%xmm4
 105014c:	vpmovzxbq %xmm4,%ymm4
 1050151:	vpand  %ymm4,%ymm9,%ymm4
 1050155:	vpaddq %ymm4,%ymm0,%ymm0
 1050159:	vpcmpgtb %xmm10,%xmm5,%xmm4
 105015e:	vpmovzxbq %xmm4,%ymm4
 1050163:	vpand  %ymm4,%ymm9,%ymm4
 1050167:	vpaddq %ymm4,%ymm1,%ymm1
 105016b:	vpcmpgtb %xmm10,%xmm6,%xmm4
 1050170:	vpmovzxbq %xmm4,%ymm4
 1050175:	vpand  %ymm4,%ymm9,%ymm4
 1050179:	vpaddq %ymm4,%ymm2,%ymm2
 105017d:	vpcmpgtb %xmm10,%xmm7,%xmm4
 1050182:	vpmovzxbq %xmm4,%ymm4
 1050187:	vpand  %ymm4,%ymm9,%ymm4
 105018b:	vpaddq %ymm4,%ymm3,%ymm3
 105018f:	add    $0x10,%rcx
 1050193:	cmp    %rcx,%rsi
 1050196:	jne    1050130 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1960>
 1050198:	vpaddq %ymm0,%ymm1,%ymm0
 105019c:	vpaddq %ymm0,%ymm2,%ymm0
 10501a0:	vpaddq %ymm0,%ymm3,%ymm0
 10501a4:	vextracti128 $0x1,%ymm0,%xmm1
 10501aa:	vpaddq %xmm1,%xmm0,%xmm0
 10501ae:	vpshufd $0xee,%xmm0,%xmm1
 10501b3:	vpaddq %xmm1,%xmm0,%xmm0
 10501b7:	vmovq  %xmm0,%rcx
 10501bc:	cmp    %rsi,%rdx
 10501bf:	je     1050245 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1a75>
 10501c5:	test   $0xc,%dl
 10501c8:	je     105035b <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1b8b>
 10501ce:	mov    %rdx,%rdi
 10501d1:	and    $0xfffffffffffffffc,%rdi
 10501d5:	vmovq  %rcx,%xmm0
 10501da:	lea    (%rax,%r13,1),%rcx
 10501de:	xchg   %ax,%ax
 10501e0:	vmovd  (%rcx,%rsi,1),%xmm1
 10501e5:	vpcmpgtb %xmm8,%xmm1,%xmm1
 10501ea:	vpmovzxbq %xmm1,%ymm1
 10501ef:	vpand  %ymm1,%ymm9,%ymm1
 10501f3:	vpaddq %ymm1,%ymm0,%ymm0
 10501f7:	add    $0x4,%rsi
 10501fb:	cmp    %rsi,%rdi
 10501fe:	jne    10501e0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1a10>
 1050200:	vextracti128 $0x1,%ymm0,%xmm1
 1050206:	vpaddq %xmm1,%xmm0,%xmm0
 105020a:	vpshufd $0xee,%xmm0,%xmm1
 105020f:	vpaddq %xmm1,%xmm0,%xmm0
 1050213:	vmovq  %xmm0,%rcx
 1050218:	cmp    %rdi,%rdx
 105021b:	je     1050245 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1a75>
 105021d:	add    %rdi,%rax
 1050220:	add    %rbp,%rax
 1050223:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1050230:	xor    %edx,%edx
 1050232:	cmpb   $0xc0,(%r8,%rax,1)
 1050237:	setge  %dl
 105023a:	add    %rdx,%rcx
 105023d:	inc    %rax
 1050240:	cmp    %rax,%r14
 1050243:	jne    1050230 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1a60>
 1050245:	cmp    %rbx,%rcx
 1050248:	jne    10502c0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1af0>
 105024a:	mov    0x10(%rsp),%rax
 105024f:	cmpq   $0x0,0x1860(%rax)
 1050257:	je     10503fc <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1c2c>
 105025d:	lea    0x18(%rbx),%rsi
 1050261:	mov    0x2c8(%rax),%edx
 1050267:	mov    0x18(%rsp),%rdi
 105026c:	xor    %ecx,%ecx
 105026e:	vzeroupper
 1050271:	call   10a78b0 <raw_bytes>
 1050276:	test   %rax,%rax
 1050279:	je     1050370 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1ba0>
 105027f:	mov    %rax,%r15
 1050282:	movq   $0x0,(%rax)
 1050289:	mov    %rbx,0x8(%rax)
 105028d:	movq   $0x0,0x10(%rax)
 1050295:	cmp    %rbp,%r14
 1050298:	je     10502ac <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1adc>
 105029a:	mov    %r15,%rdi
 105029d:	add    $0x18,%rdi
 10502a1:	mov    %r13,%rsi
 10502a4:	mov    %rbx,%rdx
 10502a7:	call   10ad320 <memcpy@plt>
 10502ac:	mov    %rbx,(%r15)
 10502af:	movl   $0x1,0x10(%r15)
 10502b7:	jmp    10502e0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1b10>
 10502b9:	nopl   0x0(%rax)
 10502c0:	mov    0x18(%rsp),%rdi
 10502c5:	mov    %r13,%rsi
 10502c8:	mov    %rbx,%rdx
 10502cb:	vzeroupper
 10502ce:	call   1090df0 <build_wide>
 10502d3:	mov    %rax,%r15
 10502d6:	test   %rax,%rax
 10502d9:	je     1050370 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1ba0>
 10502df:	nop
 10502e0:	mov    0xb8(%rsp),%rax
 10502e8:	mov    (%rax),%rcx
 10502eb:	mov    0x20(%rax),%rdx
 10502ef:	lea    0x1(%rcx),%rsi
 10502f3:	mov    %rsi,(%rax)
 10502f6:	mov    %r15,(%rdx,%rcx,8)
 10502fa:	mov    0xb8(%rsp),%rbx
 1050302:	incq   0x10(%rbx)
 1050306:	mov    0xc0(%rsp),%r13
 105030e:	cmp    0x8(%r13),%r14
 1050312:	je     10503fe <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1c2e>
 1050318:	mov    0x118(%rsp),%rcx
 1050320:	add    %rcx,%r14
 1050323:	dec    %r12
 1050326:	mov    %r14,%rbp
 1050329:	movabs $0x101010101010101,%r15
 1050333:	vmovdqa -0x4e90b(%rip),%xmm8        # 1001a30 <__abi_tag+0x1734>
 105033b:	vmovdqu 0x1f0(%rsp),%ymm9
 1050344:	vmovdqa -0x4e91c(%rip),%xmm10        # 1001a30 <__abi_tag+0x1734>
 105034c:	cmp    $0x1,%r12
 1050350:	jne    104ffb0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x17e0>
 1050356:	jmp    1050050 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1880>
 105035b:	add    %rsi,%rax
 105035e:	jmp    1050220 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1a50>
 1050363:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1050370:	mov    0x10(%rsp),%rax
 1050375:	cmpq   $0x0,0x1860(%rax)
 105037d:	movabs $0x4000000000000002,%r13
 1050387:	je     10503fc <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1c2c>
 1050389:	mov    0xb8(%rsp),%rbx
 1050391:	mov    0x18(%rbx),%rax
 1050395:	cmpw   $0x1,0x30(%rax)
 105039a:	jne    1051c96 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x34c6>
 10503a0:	mov    (%rbx),%rax
 10503a3:	test   %rax,%rax
 10503a6:	je     10503ef <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1c1f>
 10503a8:	mov    0xc0(%rsp),%r14
 10503b0:	mov    0x20(%rbx),%r15
 10503b4:	xor    %r12d,%r12d
 10503b7:	jmp    10503c8 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1bf8>
 10503b9:	nopl   0x0(%rax)
 10503c0:	inc    %r12
 10503c3:	cmp    %rax,%r12
 10503c6:	jae    10503ef <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1c1f>
 10503c8:	mov    (%r15,%r12,8),%rsi
 10503cc:	test   %rsi,%rsi
 10503cf:	je     10503c0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1bf0>
 10503d1:	cmp    %r14,%rsi
 10503d4:	je     10503c0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1bf0>
 10503d6:	lea    -0x2(%r13),%rcx
 10503da:	test   %rcx,-0x10(%rsi)
 10503de:	je     10503c0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1bf0>
 10503e0:	mov    0x18(%rsp),%rdi
 10503e5:	call   109fd30 <myl_rc_construction_abort>
 10503ea:	mov    (%rbx),%rax
 10503ed:	jmp    10503c0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1bf0>
 10503ef:	mov    0x18(%rsp),%rdi
 10503f4:	mov    %rbx,%rsi
 10503f7:	call   109fd30 <myl_rc_construction_abort>
 10503fc:	xor    %ebx,%ebx
 10503fe:	mov    0x10(%rsp),%rbp
 1050403:	mov    0x268(%rbp),%rax
 105040a:	lea    0x140(%rsp),%rcx
 1050412:	cmp    %rcx,%rax
 1050415:	je     1050450 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1c80>
 1050417:	lea    0x160(%rsp),%rcx
 105041f:	cmp    %rcx,%rax
 1050422:	je     105046c <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1c9c>
 1050424:	lea    0x1a8(%rsp),%rcx
 105042c:	cmp    %rcx,%rax
 105042f:	je     1050488 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1cb8>
 1050431:	test   %rbx,%rbx
 1050434:	movabs $0x4000000000000002,%r13
 105043e:	jne    10504aa <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1cda>
 1050440:	jmp    1051d90 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x35c0>
 1050445:	data16 cs nopw 0x0(%rax,%rax,1)
 1050450:	mov    0x140(%rsp),%rax
 1050458:	mov    %rax,0x268(%rbp)
 105045f:	lea    0x160(%rsp),%rcx
 1050467:	cmp    %rcx,%rax
 105046a:	jne    1050424 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1c54>
 105046c:	mov    0x160(%rsp),%rax
 1050474:	mov    %rax,0x268(%rbp)
 105047b:	lea    0x1a8(%rsp),%rcx
 1050483:	cmp    %rcx,%rax
 1050486:	jne    1050431 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1c61>
 1050488:	mov    0x1a8(%rsp),%rax
 1050490:	mov    %rax,0x268(%rbp)
 1050497:	test   %rbx,%rbx
 105049a:	movabs $0x4000000000000002,%r13
 10504a4:	je     1051d90 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x35c0>
 10504aa:	mov    %rbx,0x60(%rsp)
 10504af:	mov    %rbx,0x68(%rsp)
 10504b4:	mov    -0x10(%rbx),%rax
 10504b8:	test   %rax,0x110(%rsp)
 10504c0:	je     10504e1 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1d11>
 10504c2:	movabs $0x5000000000000000,%rcx
 10504cc:	test   %rcx,%rax
 10504cf:	jne    1050500 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1d30>
 10504d1:	cmpq   $0x0,0x180(%rsp)
 10504da:	je     1050500 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1d30>
 10504dc:	mov    %rbx,0x60(%rsp)
 10504e1:	movq   $0x0,0x68(%rsp)
 10504ea:	mov    (%rbx),%r15
 10504ed:	test   %r15,%r15
 10504f0:	jns    105053d <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1d6d>
 10504f2:	jmp    1051dab <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x35db>
 10504f7:	nopw   0x0(%rax,%rax,1)
 1050500:	mov    $0x100ba48,%esi
 1050505:	mov    0x18(%rsp),%rdi
 105050a:	lea    0x60(%rsp),%rdx
 105050f:	lea    0x68(%rsp),%rcx
 1050514:	mov    0x124(%rsp),%r8d
 105051c:	vzeroupper
 105051f:	call   10a8110 <myl_rc_native_take>
 1050524:	test   %eax,%eax
 1050526:	je     10507e1 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2011>
 105052c:	mov    0x60(%rsp),%rbx
 1050531:	mov    (%rbx),%r15
 1050534:	test   %r15,%r15
 1050537:	js     1051dab <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x35db>
 105053d:	imul   $0x7,%r15,%r12
 1050541:	vmovdqa 0x50(%rsp),%xmm9
 1050547:	vmovdqu 0xf0(%rsp),%ymm10
 1050550:	jo     1051db9 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x35e9>
 1050556:	test   %rbx,%rbx
 1050559:	je     1050565 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1d95>
 105055b:	test   %r13,-0x10(%rbx)
 105055f:	je     1050670 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1ea0>
 1050565:	mov    %rbx,0x60(%rsp)
 105056a:	test   %r15,%r15
 105056d:	je     105068f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1ebf>
 1050573:	xor    %ebp,%ebp
 1050575:	data16 cs nopw 0x0(%rax,%rax,1)
 1050580:	mov    0x20(%rbx),%rax
 1050584:	mov    (%rax,%rbp,8),%r13
 1050588:	mov    %r13,0x68(%rsp)
 105058d:	test   %r13,%r13
 1050590:	je     10505b3 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1de3>
 1050592:	movabs $0x4000000000000002,%rax
 105059c:	test   %rax,-0x10(%r13)
 10505a0:	jne    10505b3 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1de3>
 10505a2:	mov    -0x18(%r13),%rax
 10505a6:	inc    %rax
 10505a9:	je     105091b <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x214b>
 10505af:	mov    %rax,-0x18(%r13)
 10505b3:	mov    %r13,0x60(%rsp)
 10505b8:	movq   $0x0,0x68(%rsp)
 10505c1:	mov    0x10(%rsp),%rdi
 10505c6:	mov    %r13,%rsi
 10505c9:	vzeroupper
 10505cc:	call   1074e30 <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85>
 10505d1:	mov    %r12,%r14
 10505d4:	add    %rax,%r14
 10505d7:	jo     1051cb3 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x34e3>
 10505dd:	test   %r13,%r13
 10505e0:	vmovdqa 0x50(%rsp),%xmm9
 10505e6:	vmovdqu 0xf0(%rsp),%ymm10
 10505ef:	je     1050615 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1e45>
 10505f1:	movabs $0x4000000000000002,%rax
 10505fb:	test   %rax,-0x10(%r13)
 10505ff:	jne    1050615 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1e45>
 1050601:	mov    -0x18(%r13),%rax
 1050605:	dec    %rax
 1050608:	jne    1050611 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1e41>
 105060a:	cmpq   $0x0,-0x20(%r13)
 105060f:	je     105062f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1e5f>
 1050611:	mov    %rax,-0x18(%r13)
 1050615:	cmp    %r15,(%rbx)
 1050618:	jne    1051cc5 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x34f5>
 105061e:	inc    %rbp
 1050621:	mov    %r14,%r12
 1050624:	cmp    %rbp,%r15
 1050627:	jne    1050580 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1db0>
 105062d:	jmp    1050692 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1ec2>
 105062f:	mov    0x18(%rsp),%r12
 1050634:	mov    %r12,%rdi
 1050637:	mov    %r13,%rsi
 105063a:	vzeroupper
 105063d:	call   109bcd0 <myl_rc_hold_edge_release>
 1050642:	mov    %r12,%rdi
 1050645:	call   109ecf0 <myl_rc_drain>
 105064a:	vmovdqu 0xf0(%rsp),%ymm10
 1050653:	vmovdqa 0x50(%rsp),%xmm9
 1050659:	cmp    %r15,(%rbx)
 105065c:	je     105061e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1e4e>
 105065e:	jmp    1051cc5 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x34f5>
 1050663:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1050670:	mov    -0x18(%rbx),%rax
 1050674:	inc    %rax
 1050677:	je     10508f7 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2127>
 105067d:	mov    %rax,-0x18(%rbx)
 1050681:	mov    %rbx,0x60(%rsp)
 1050686:	test   %r15,%r15
 1050689:	jne    1050573 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1da3>
 105068f:	mov    %r12,%r14
 1050692:	mov    0x230(%rsp),%eax
 1050699:	or     0x250(%rsp),%eax
 10506a0:	mov    0x10(%rsp),%rbp
 10506a5:	movabs $0x4000000000000002,%r13
 10506af:	movabs $0x101010101010101,%r15
 10506b9:	je     10506ee <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1f1e>
 10506bb:	mov    0x1860(%rbp),%rax
 10506c2:	test   %rax,%rax
 10506c5:	je     10506d0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1f00>
 10506c7:	mov    0xf8(%rax),%rsi
 10506ce:	jmp    10506d2 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1f02>
 10506d0:	xor    %esi,%esi
 10506d2:	mov    0x18(%rsp),%rdi
 10506d7:	vzeroupper
 10506da:	call   10a2320 <myl_rc_scope_unwind>
 10506df:	vmovdqa 0x50(%rsp),%xmm9
 10506e5:	vmovdqu 0xf0(%rsp),%ymm10
 10506ee:	test   %rbx,%rbx
 10506f1:	je     105074b <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1f7b>
 10506f3:	test   %r13,-0x10(%rbx)
 10506f7:	mov    0x20(%rsp),%rdx
 10506fc:	je     1050710 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1f40>
 10506fe:	test   %r13,-0x10(%rbx)
 1050702:	jne    1050750 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1f80>
 1050704:	jmp    1050733 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1f63>
 1050706:	cs nopw 0x0(%rax,%rax,1)
 1050710:	mov    -0x18(%rbx),%rax
 1050714:	dec    %rax
 1050717:	jne    1050724 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1f54>
 1050719:	cmpq   $0x0,-0x20(%rbx)
 105071e:	je     1050876 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x20a6>
 1050724:	mov    %rax,-0x18(%rbx)
 1050728:	mov    0x20(%rsp),%rdx
 105072d:	test   %r13,-0x10(%rbx)
 1050731:	jne    1050750 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1f80>
 1050733:	mov    -0x20(%rbx),%rax
 1050737:	dec    %rax
 105073a:	jne    1050747 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1f77>
 105073c:	cmpq   $0x0,-0x18(%rbx)
 1050741:	je     10508be <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x20ee>
 1050747:	mov    %rax,-0x20(%rbx)
 105074b:	mov    0x20(%rsp),%rdx
 1050750:	mov    0x190(%rsp),%rsi
 1050758:	test   %rsi,%rsi
 105075b:	je     1050780 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1fb0>
 105075d:	test   %r13,-0x10(%rsi)
 1050761:	jne    1050780 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1fb0>
 1050763:	mov    -0x20(%rsi),%rax
 1050767:	dec    %rax
 105076a:	jne    1050777 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1fa7>
 105076c:	cmpq   $0x0,-0x18(%rsi)
 1050771:	je     105084a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x207a>
 1050777:	mov    %rax,-0x20(%rsi)
 105077b:	mov    0x20(%rsp),%rdx
 1050780:	mov    %rdx,%rcx
 1050783:	add    %r14,%rcx
 1050786:	jo     1051d9b <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x35cb>
 105078c:	mov    %rcx,%rax
 105078f:	movabs $0x89705f3112a28fe5,%rdx
 1050799:	imul   %rdx
 105079c:	add    %rcx,%rdx
 105079f:	mov    %rdx,%rax
 10507a2:	shr    $0x3f,%rax
 10507a6:	sar    $0x1d,%rdx
 10507aa:	add    %rax,%rdx
 10507ad:	imul   $0x3b9aca07,%rdx,%rax
 10507b4:	sub    %rax,%rcx
 10507b7:	mov    %rcx,%rax
 10507ba:	sar    $0x3f,%rax
 10507be:	and    $0x3b9aca07,%eax
 10507c3:	add    %rcx,%rax
 10507c6:	mov    0x198(%rsp),%r12
 10507ce:	inc    %r12
 10507d1:	cmp    0x28(%rsp),%r12
 10507d6:	jne    104f950 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1180>
 10507dc:	jmp    104f0fc <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x92c>
 10507e1:	mov    0x1860(%rbp),%rax
 10507e8:	test   %rax,%rax
 10507eb:	vmovdqa 0x50(%rsp),%xmm9
 10507f1:	vmovdqu 0xf0(%rsp),%ymm10
 10507fa:	je     1051c9e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x34ce>
 1050800:	mov    0x124(%rax),%r14d
 1050807:	movl   $0x0,0x124(%rax)
 1050811:	test   %r14,%r14
 1050814:	mov    0x20(%rsp),%rdx
 1050819:	movabs $0x101010101010101,%r15
 1050823:	je     1050750 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1f80>
 1050829:	cmp    $0x1,%r14d
 105082d:	jne    1050960 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2190>
 1050833:	mov    $0x1007df2,%esi
 1050838:	cmpl   $0x0,0x2c4(%rbp)
 105083f:	je     105096a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x219a>
 1050845:	jmp    1050972 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x21a2>
 105084a:	mov    0x18(%rsp),%rbx
 105084f:	mov    %rbx,%rdi
 1050852:	vzeroupper
 1050855:	call   109bb70 <myl_rc_edge_release>
 105085a:	mov    %rbx,%rdi
 105085d:	call   109ecf0 <myl_rc_drain>
 1050862:	vmovdqu 0xf0(%rsp),%ymm10
 105086b:	vmovdqa 0x50(%rsp),%xmm9
 1050871:	jmp    105077b <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1fab>
 1050876:	mov    0x18(%rsp),%r15
 105087b:	mov    %r15,%rdi
 105087e:	mov    %rbx,%rsi
 1050881:	vzeroupper
 1050884:	call   109bcd0 <myl_rc_hold_edge_release>
 1050889:	mov    %r15,%rdi
 105088c:	movabs $0x101010101010101,%r15
 1050896:	call   109ecf0 <myl_rc_drain>
 105089b:	vmovdqu 0xf0(%rsp),%ymm10
 10508a4:	vmovdqa 0x50(%rsp),%xmm9
 10508aa:	mov    0x20(%rsp),%rdx
 10508af:	test   %r13,-0x10(%rbx)
 10508b3:	jne    1050750 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1f80>
 10508b9:	jmp    1050733 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1f63>
 10508be:	mov    0x18(%rsp),%r15
 10508c3:	mov    %r15,%rdi
 10508c6:	mov    %rbx,%rsi
 10508c9:	vzeroupper
 10508cc:	call   109bb70 <myl_rc_edge_release>
 10508d1:	mov    %r15,%rdi
 10508d4:	movabs $0x101010101010101,%r15
 10508de:	call   109ecf0 <myl_rc_drain>
 10508e3:	vmovdqu 0xf0(%rsp),%ymm10
 10508ec:	vmovdqa 0x50(%rsp),%xmm9
 10508f2:	jmp    105074b <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1f7b>
 10508f7:	mov    $0x1007dbf,%esi
 10508fc:	mov    %rbp,%rdi
 10508ff:	vzeroupper
 1050902:	call   108be4e <fail>
 1050907:	vmovdqu 0xf0(%rsp),%ymm10
 1050910:	vmovdqa 0x50(%rsp),%xmm9
 1050916:	xor    %r14d,%r14d
 1050919:	jmp    105094c <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x217c>
 105091b:	mov    $0x1007dbf,%esi
 1050920:	mov    0x10(%rsp),%rbp
 1050925:	mov    %rbp,%rdi
 1050928:	vzeroupper
 105092b:	call   108be4e <fail>
 1050930:	vmovdqu 0xf0(%rsp),%ymm10
 1050939:	vmovdqa 0x50(%rsp),%xmm9
 105093f:	xor    %r14d,%r14d
 1050942:	movabs $0x4000000000000002,%r13
 105094c:	mov    0x20(%rsp),%rdx
 1050951:	movabs $0x101010101010101,%r15
 105095b:	jmp    1050750 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1f80>
 1050960:	cmp    $0x4,%r14d
 1050964:	jae    1051c96 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x34c6>
 105096a:	mov    0x10315e0(,%r14,8),%rsi
 1050972:	mov    %rbp,%rdi
 1050975:	vzeroupper
 1050978:	call   108be4e <fail>
 105097d:	xor    %r14d,%r14d
 1050980:	mov    0x20(%rsp),%rdx
 1050985:	vmovdqa 0x50(%rsp),%xmm9
 105098b:	vmovdqu 0xf0(%rsp),%ymm10
 1050994:	jmp    1050750 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1f80>
 1050999:	mov    $0x1,%bl
 105099b:	test   %rsi,%rsi
 105099e:	je     1050b17 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2347>
 10509a4:	mov    0x8(%rsi),%rdx
 10509a8:	cmp    0x6a1c9(%rip),%rdx        # 10bab78 <myl_lit_4a11bea7b5a6ce8d077c05a11569e05d5d64f10b6601437976e3917dc8273132_instance+0x18>
 10509af:	jne    1050b17 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2347>
 10509b5:	test   %rdx,%rdx
 10509b8:	je     104f87f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x10af>
 10509be:	testb  $0x4,0x10(%rsi)
 10509c2:	jne    1050a5f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x228f>
 10509c8:	lea    0x18(%rsi),%rdi
 10509cc:	jmp    1050a6e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x229e>
 10509d1:	mov    0x1860(%rbp),%rax
 10509d8:	test   %rax,%rax
 10509db:	je     1051c9e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x34ce>
 10509e1:	mov    0x124(%rax),%esi
 10509e7:	movl   $0x0,0x124(%rax)
 10509f1:	mov    %rbp,%rdi
 10509f4:	vzeroupper
 10509f7:	call   108b5f0 <myl_qbe_rc_status>
 10509fc:	xor    %eax,%eax
 10509fe:	jmp    104f0fc <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x92c>
 1050a03:	mov    0x1860(%rbp),%rax
 1050a0a:	test   %rax,%rax
 1050a0d:	je     1051c9e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x34ce>
 1050a13:	mov    0x124(%rax),%esi
 1050a19:	movl   $0x0,0x124(%rax)
 1050a23:	mov    %rbp,%rdi
 1050a26:	vzeroupper
 1050a29:	call   108b5f0 <myl_qbe_rc_status>
 1050a2e:	xor    %eax,%eax
 1050a30:	jmp    104f0fc <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x92c>
 1050a35:	lea    0xc8(%rsp),%rax
 1050a3d:	lea    0x258(%rbp),%rdi
 1050a44:	mov    %rsi,%r14
 1050a47:	mov    %rax,%rsi
 1050a4a:	call   1087900 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop>
 1050a4f:	mov    %r14,%rsi
 1050a52:	test   %bl,%bl
 1050a54:	jne    104f85d <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x108d>
 1050a5a:	jmp    104f8ab <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x10db>
 1050a5f:	mov    0x18(%rsi),%rax
 1050a63:	mov    0x14(%rsi),%ecx
 1050a66:	lea    (%rax,%rcx,1),%rdi
 1050a6a:	add    $0x18,%rdi
 1050a6e:	testb  $0x4,0x6a10b(%rip)        # 10bab80 <myl_lit_4a11bea7b5a6ce8d077c05a11569e05d5d64f10b6601437976e3917dc8273132_instance+0x20>
 1050a75:	mov    0x6a10c(%rip),%rax        # 10bab88 <myl_lit_4a11bea7b5a6ce8d077c05a11569e05d5d64f10b6601437976e3917dc8273132_instance+0x28>
 1050a7c:	mov    0x6a102(%rip),%ecx        # 10bab84 <myl_lit_4a11bea7b5a6ce8d077c05a11569e05d5d64f10b6601437976e3917dc8273132_instance+0x24>
 1050a82:	lea    0x18(%rax,%rcx,1),%rcx
 1050a87:	mov    $0x10bab88,%eax
 1050a8c:	cmovne %rcx,%rax
 1050a90:	cmp    $0x10,%rdx
 1050a94:	ja     1050ab1 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x22e1>
 1050a96:	cmp    $0x8,%rdx
 1050a9a:	jb     1050acc <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x22fc>
 1050a9c:	mov    (%rdi),%rcx
 1050a9f:	mov    -0x8(%rdi,%rdx,1),%rdi
 1050aa4:	xor    (%rax),%rcx
 1050aa7:	xor    -0x8(%rax,%rdx,1),%rdi
 1050aac:	or     %rcx,%rdi
 1050aaf:	jmp    1050b11 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2341>
 1050ab1:	mov    %rsi,%r14
 1050ab4:	mov    %rax,%rsi
 1050ab7:	cmp    $0x100,%rdx
 1050abe:	ja     1050ae2 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2312>
 1050ac0:	call   10ad360 <bcmp@plt>
 1050ac5:	test   %eax,%eax
 1050ac7:	setne  %bl
 1050aca:	jmp    1050aec <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x231c>
 1050acc:	cmp    $0x4,%rdx
 1050ad0:	jb     1050af1 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2321>
 1050ad2:	mov    (%rdi),%ecx
 1050ad4:	mov    -0x4(%rdi,%rdx,1),%edi
 1050ad8:	xor    (%rax),%ecx
 1050ada:	xor    -0x4(%rax,%rdx,1),%edi
 1050ade:	or     %ecx,%edi
 1050ae0:	jmp    1050b11 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2341>
 1050ae2:	call   1093490 <equal_large_octets>
 1050ae7:	test   %eax,%eax
 1050ae9:	sete   %bl
 1050aec:	mov    %r14,%rsi
 1050aef:	jmp    1050b17 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2347>
 1050af1:	cmp    $0x1,%rdx
 1050af5:	jne    1050afe <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x232e>
 1050af7:	movzbl (%rdi),%ecx
 1050afa:	cmp    (%rax),%cl
 1050afc:	jmp    1050b11 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2341>
 1050afe:	movzwl (%rdi),%ecx
 1050b01:	movzwl -0x2(%rdi,%rdx,1),%edi
 1050b06:	xor    (%rax),%cx
 1050b09:	xor    -0x2(%rax,%rdx,1),%di
 1050b0e:	or     %cx,%di
 1050b11:	sete   %bl
 1050b14:	xor    $0x1,%bl
 1050b17:	test   %r13,0x6a042(%rip)        # 10bab60 <myl_lit_4a11bea7b5a6ce8d077c05a11569e05d5d64f10b6601437976e3917dc8273132_instance>
 1050b1e:	jne    1050b3d <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x236d>
 1050b20:	mov    0x6a029(%rip),%rax        # 10bab50 <myl_lit_49ddcee716aac9f3632795416226e674fb40f0332dabf1de33fc7f8b34af0696_instance+0x38>
 1050b27:	dec    %rax
 1050b2a:	jne    1050b36 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2366>
 1050b2c:	cmpq   $0x0,0x6a024(%rip)        # 10bab58 <myl_lit_49ddcee716aac9f3632795416226e674fb40f0332dabf1de33fc7f8b34af0696_instance+0x40>
 1050b34:	je     1050ba7 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x23d7>
 1050b36:	mov    %rax,0x6a013(%rip)        # 10bab50 <myl_lit_49ddcee716aac9f3632795416226e674fb40f0332dabf1de33fc7f8b34af0696_instance+0x38>
 1050b3d:	test   %bl,%bl
 1050b3f:	je     1050bcc <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x23fc>
 1050b45:	movq   $0x10baa10,0x38(%rsp)
 1050b4e:	movq   $0x10baa10,0x70(%rsp)
 1050b57:	movq   $0x10baa10,0xc8(%rsp)
 1050b63:	cmp    $0x10baa10,%rsi
 1050b6a:	jne    1050b73 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x23a3>
 1050b6c:	xor    %ebx,%ebx
 1050b6e:	jmp    10510e5 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2915>
 1050b73:	mov    $0x1,%bl
 1050b75:	test   %rsi,%rsi
 1050b78:	je     10510e5 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2915>
 1050b7e:	mov    0x8(%rsi),%rdx
 1050b82:	cmp    0x69e8f(%rip),%rdx        # 10baa18 <myl_lit_3b82d7fd89ea641dc3c74175c3081dd70840c2be20de843e08a42204e3d9c4cc_instance+0x18>
 1050b89:	jne    10510e5 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2915>
 1050b8f:	test   %rdx,%rdx
 1050b92:	je     1050b6c <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x239c>
 1050b94:	testb  $0x4,0x10(%rsi)
 1050b98:	jne    105102d <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x285d>
 1050b9e:	lea    0x18(%rsi),%rdi
 1050ba2:	jmp    105103c <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x286c>
 1050ba7:	lea    0xc8(%rsp),%rax
 1050baf:	lea    0x258(%rbp),%rdi
 1050bb6:	mov    %rsi,%r14
 1050bb9:	mov    %rax,%rsi
 1050bbc:	call   1087900 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop>
 1050bc1:	mov    %r14,%rsi
 1050bc4:	test   %bl,%bl
 1050bc6:	jne    1050b45 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2375>
 1050bcc:	lea    0x48(%rsp),%rcx
 1050bd1:	lea    0x70(%rsp),%rdx
 1050bd6:	mov    %rdx,%rax
 1050bd9:	sub    %rcx,%rax
 1050bdc:	sub    %rdx,%rcx
 1050bdf:	cmovb  %rax,%rcx
 1050be3:	mov    %rcx,0xf0(%rsp)
 1050beb:	movabs $0x5000000000000000,%rax
 1050bf5:	xor    %r15d,%r15d
 1050bf8:	inc    %rax
 1050bfb:	mov    %rax,0x50(%rsp)
 1050c00:	xor    %eax,%eax
 1050c02:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1050c10:	mov    %rax,%r14
 1050c13:	mov    0x8(%rsp),%rax
 1050c18:	add    %r15,%rax
 1050c1b:	jo     1051df1 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3621>
 1050c21:	test   $0x1,%al
 1050c23:	jne    1050cc0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x24f0>
 1050c29:	movq   $0x10bb9c0,0x70(%rsp)
 1050c32:	movq   $0x10bb9c0,0x1c8(%rsp)
 1050c3e:	movq   $0x10bb9c0,0x48(%rsp)
 1050c47:	mov    0x6ad62(%rip),%rax        # 10bb9b0 <myl_lit_f3eaad558815542caf7da2bdfda9d4cabeaf9c2200b79ab8ff85b21b8470fac6_instance>
 1050c4e:	test   %rax,0x50(%rsp)
 1050c53:	movabs $0x4000000000000002,%rbx
 1050c5d:	je     1050d7a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x25aa>
 1050c63:	cmpq   $0x0,0xf0(%rsp)
 1050c6c:	sete   %cl
 1050c6f:	movabs $0x5000000000000000,%rdx
 1050c79:	test   %rdx,%rax
 1050c7c:	setne  %al
 1050c7f:	or     %cl,%al
 1050c81:	je     1050d96 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x25c6>
 1050c87:	mov    $0x1030c78,%esi
 1050c8c:	lea    0x258(%rbp),%rdi
 1050c93:	lea    0x70(%rsp),%rdx
 1050c98:	lea    0x48(%rsp),%rcx
 1050c9d:	mov    0x44(%rsp),%r8d
 1050ca2:	call   10a8110 <myl_rc_native_take>
 1050ca7:	test   %eax,%eax
 1050ca9:	jne    1050d46 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2576>
 1050caf:	jmp    1050fbb <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x27eb>
 1050cb4:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 1050cc0:	movq   $0x10bad30,0x70(%rsp)
 1050cc9:	movq   $0x10bad30,0x1c8(%rsp)
 1050cd5:	movq   $0x10bad30,0x48(%rsp)
 1050cde:	mov    0x6a03b(%rip),%rax        # 10bad20 <myl_lit_54807ae7ae90f7f8ab8705f04b17dcd2d77e7355f27b7f7252156b0c234f7d3f_instance>
 1050ce5:	test   %rax,0x50(%rsp)
 1050cea:	movabs $0x4000000000000002,%rbx
 1050cf4:	je     1050dc4 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x25f4>
 1050cfa:	cmpq   $0x0,0xf0(%rsp)
 1050d03:	sete   %cl
 1050d06:	movabs $0x5000000000000000,%rdx
 1050d10:	test   %rdx,%rax
 1050d13:	setne  %al
 1050d16:	or     %cl,%al
 1050d18:	je     1050dbb <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x25eb>
 1050d1e:	mov    $0x1030c78,%esi
 1050d23:	lea    0x258(%rbp),%rdi
 1050d2a:	lea    0x70(%rsp),%rdx
 1050d2f:	lea    0x48(%rsp),%rcx
 1050d34:	mov    0x44(%rsp),%r8d
 1050d39:	call   10a8110 <myl_rc_native_take>
 1050d3e:	test   %eax,%eax
 1050d40:	je     1050fea <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x281a>
 1050d46:	mov    0x70(%rsp),%r12
 1050d4b:	mov    %r12,0xa8(%rsp)
 1050d53:	mov    %r12,0x48(%rsp)
 1050d58:	test   %r12,%r12
 1050d5b:	je     1050f4a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x277a>
 1050d61:	test   %rbx,-0x10(%r12)
 1050d66:	je     1050dde <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x260e>
 1050d68:	mov    %r12,0x70(%rsp)
 1050d6d:	mov    %r12,0xa0(%rsp)
 1050d75:	jmp    1050e19 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2649>
 1050d7a:	mov    $0x10bb9c0,%r12d
 1050d80:	mov    %r12,0xa8(%rsp)
 1050d88:	mov    %r12,0x48(%rsp)
 1050d8d:	test   %rbx,-0x10(%r12)
 1050d92:	jne    1050d68 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2598>
 1050d94:	jmp    1050dde <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x260e>
 1050d96:	movq   $0x10bb9c0,0x70(%rsp)
 1050d9f:	mov    $0x10bb9c0,%r12d
 1050da5:	mov    %r12,0xa8(%rsp)
 1050dad:	mov    %r12,0x48(%rsp)
 1050db2:	test   %rbx,-0x10(%r12)
 1050db7:	jne    1050d68 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2598>
 1050db9:	jmp    1050dde <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x260e>
 1050dbb:	movq   $0x10bad30,0x70(%rsp)
 1050dc4:	mov    $0x10bad30,%r12d
 1050dca:	mov    %r12,0xa8(%rsp)
 1050dd2:	mov    %r12,0x48(%rsp)
 1050dd7:	test   %rbx,-0x10(%r12)
 1050ddc:	jne    1050d68 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2598>
 1050dde:	mov    -0x18(%r12),%rax
 1050de3:	inc    %rax
 1050de6:	je     1051019 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2849>
 1050dec:	mov    %rax,-0x18(%r12)
 1050df1:	mov    %r12,0x70(%rsp)
 1050df6:	mov    %r12,0xa0(%rsp)
 1050dfe:	mov    -0x20(%r12),%rax
 1050e03:	dec    %rax
 1050e06:	jne    1050e14 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2644>
 1050e08:	cmpq   $0x0,-0x18(%r12)
 1050e0e:	je     1050f89 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x27b9>
 1050e14:	mov    %rax,-0x20(%r12)
 1050e19:	movq   $0x0,0xa8(%rsp)
 1050e25:	mov    0x30(%rsp),%rax
 1050e2a:	mov    0x20(%rax),%rdx
 1050e2e:	lea    0x258(%rbp),%rdi
 1050e35:	mov    %r12,%rsi
 1050e38:	call   1093810 <myl_native_text_join>
 1050e3d:	test   %rax,%rax
 1050e40:	je     1051dd9 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3609>
 1050e46:	mov    %rax,%rbx
 1050e49:	mov    %rax,0x48(%rsp)
 1050e4e:	mov    %rax,0x70(%rsp)
 1050e53:	mov    %rax,0x1c8(%rsp)
 1050e5b:	mov    %rbp,%rdi
 1050e5e:	mov    %rax,%rsi
 1050e61:	call   1074e30 <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85>
 1050e66:	mov    %rax,%r13
 1050e69:	movabs $0x4000000000000002,%rax
 1050e73:	test   %rax,-0x10(%rbx)
 1050e77:	je     1050e90 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x26c0>
 1050e79:	movq   $0x0,0x1c8(%rsp)
 1050e85:	test   %r12,%r12
 1050e88:	jne    1050eb9 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x26e9>
 1050e8a:	jmp    1050ef1 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2721>
 1050e8c:	nopl   0x0(%rax)
 1050e90:	mov    -0x20(%rbx),%rax
 1050e94:	dec    %rax
 1050e97:	jne    1050ea4 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x26d4>
 1050e99:	cmpq   $0x0,-0x18(%rbx)
 1050e9e:	je     1050f67 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2797>
 1050ea4:	mov    %rax,-0x20(%rbx)
 1050ea8:	movq   $0x0,0x1c8(%rsp)
 1050eb4:	test   %r12,%r12
 1050eb7:	je     1050ef1 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2721>
 1050eb9:	movabs $0x4000000000000002,%rax
 1050ec3:	test   %rax,-0x10(%r12)
 1050ec8:	jne    1050ee5 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2715>
 1050eca:	mov    -0x18(%r12),%rax
 1050ecf:	dec    %rax
 1050ed2:	jne    1050ee0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2710>
 1050ed4:	cmpq   $0x0,-0x20(%r12)
 1050eda:	je     1050fa2 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x27d2>
 1050ee0:	mov    %rax,-0x18(%r12)
 1050ee5:	movq   $0x0,0xa0(%rsp)
 1050ef1:	mov    %r14,%rcx
 1050ef4:	add    %r13,%rcx
 1050ef7:	jo     1051de1 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3611>
 1050efd:	mov    %rcx,%rax
 1050f00:	movabs $0x89705f3112a28fe5,%rdx
 1050f0a:	imul   %rdx
 1050f0d:	add    %rcx,%rdx
 1050f10:	mov    %rdx,%rax
 1050f13:	shr    $0x3f,%rax
 1050f17:	sar    $0x1d,%rdx
 1050f1b:	add    %rax,%rdx
 1050f1e:	imul   $0x3b9aca07,%rdx,%rax
 1050f25:	sub    %rax,%rcx
 1050f28:	mov    %rcx,%rax
 1050f2b:	sar    $0x3f,%rax
 1050f2f:	and    $0x3b9aca07,%eax
 1050f34:	add    %rcx,%rax
 1050f37:	inc    %r15
 1050f3a:	cmp    %r15,0x28(%rsp)
 1050f3f:	jne    1050c10 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2440>
 1050f45:	jmp    104f0fc <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x92c>
 1050f4a:	movq   $0x0,0x70(%rsp)
 1050f53:	movq   $0x0,0xa0(%rsp)
 1050f5f:	xor    %r12d,%r12d
 1050f62:	jmp    1050e25 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2655>
 1050f67:	lea    0x258(%rbp),%rdi
 1050f6e:	lea    0x1c8(%rsp),%rsi
 1050f76:	call   1087900 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop>
 1050f7b:	test   %r12,%r12
 1050f7e:	jne    1050eb9 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x26e9>
 1050f84:	jmp    1050ef1 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2721>
 1050f89:	lea    0x258(%rbp),%rdi
 1050f90:	lea    0xa8(%rsp),%rsi
 1050f98:	call   1087900 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop>
 1050f9d:	jmp    1050e25 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2655>
 1050fa2:	lea    0x258(%rbp),%rdi
 1050fa9:	lea    0xa0(%rsp),%rsi
 1050fb1:	call   1087890 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan>
 1050fb6:	jmp    1050ef1 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2721>
 1050fbb:	mov    0x1860(%rbp),%rax
 1050fc2:	test   %rax,%rax
 1050fc5:	je     1051c9e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x34ce>
 1050fcb:	mov    0x124(%rax),%esi
 1050fd1:	movl   $0x0,0x124(%rax)
 1050fdb:	mov    %rbp,%rdi
 1050fde:	call   108b5f0 <myl_qbe_rc_status>
 1050fe3:	xor    %eax,%eax
 1050fe5:	jmp    104f0fc <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x92c>
 1050fea:	mov    0x1860(%rbp),%rax
 1050ff1:	test   %rax,%rax
 1050ff4:	je     1051c9e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x34ce>
 1050ffa:	mov    0x124(%rax),%esi
 1051000:	movl   $0x0,0x124(%rax)
 105100a:	mov    %rbp,%rdi
 105100d:	call   108b5f0 <myl_qbe_rc_status>
 1051012:	xor    %eax,%eax
 1051014:	jmp    104f0fc <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x92c>
 1051019:	mov    $0x1007dbf,%esi
 105101e:	mov    %rbp,%rdi
 1051021:	call   108be4e <fail>
 1051026:	xor    %eax,%eax
 1051028:	jmp    104f0fc <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x92c>
 105102d:	mov    0x18(%rsi),%rax
 1051031:	mov    0x14(%rsi),%ecx
 1051034:	lea    (%rax,%rcx,1),%rdi
 1051038:	add    $0x18,%rdi
 105103c:	testb  $0x4,0x699dd(%rip)        # 10baa20 <myl_lit_3b82d7fd89ea641dc3c74175c3081dd70840c2be20de843e08a42204e3d9c4cc_instance+0x20>
 1051043:	mov    0x699de(%rip),%rax        # 10baa28 <myl_lit_3b82d7fd89ea641dc3c74175c3081dd70840c2be20de843e08a42204e3d9c4cc_instance+0x28>
 105104a:	mov    0x699d4(%rip),%ecx        # 10baa24 <myl_lit_3b82d7fd89ea641dc3c74175c3081dd70840c2be20de843e08a42204e3d9c4cc_instance+0x24>
 1051050:	lea    0x18(%rax,%rcx,1),%rcx
 1051055:	mov    $0x10baa28,%eax
 105105a:	cmovne %rcx,%rax
 105105e:	cmp    $0x10,%rdx
 1051062:	ja     105107f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x28af>
 1051064:	cmp    $0x8,%rdx
 1051068:	jb     105109a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x28ca>
 105106a:	mov    (%rdi),%rcx
 105106d:	mov    -0x8(%rdi,%rdx,1),%rdi
 1051072:	xor    (%rax),%rcx
 1051075:	xor    -0x8(%rax,%rdx,1),%rdi
 105107a:	or     %rcx,%rdi
 105107d:	jmp    10510df <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x290f>
 105107f:	mov    %rsi,%r14
 1051082:	mov    %rax,%rsi
 1051085:	cmp    $0x100,%rdx
 105108c:	ja     10510b0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x28e0>
 105108e:	call   10ad360 <bcmp@plt>
 1051093:	test   %eax,%eax
 1051095:	setne  %bl
 1051098:	jmp    10510ba <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x28ea>
 105109a:	cmp    $0x4,%rdx
 105109e:	jb     10510bf <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x28ef>
 10510a0:	mov    (%rdi),%ecx
 10510a2:	mov    -0x4(%rdi,%rdx,1),%edi
 10510a6:	xor    (%rax),%ecx
 10510a8:	xor    -0x4(%rax,%rdx,1),%edi
 10510ac:	or     %ecx,%edi
 10510ae:	jmp    10510df <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x290f>
 10510b0:	call   1093490 <equal_large_octets>
 10510b5:	test   %eax,%eax
 10510b7:	sete   %bl
 10510ba:	mov    %r14,%rsi
 10510bd:	jmp    10510e5 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2915>
 10510bf:	cmp    $0x1,%rdx
 10510c3:	jne    10510cc <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x28fc>
 10510c5:	movzbl (%rdi),%ecx
 10510c8:	cmp    (%rax),%cl
 10510ca:	jmp    10510df <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x290f>
 10510cc:	movzwl (%rdi),%ecx
 10510cf:	movzwl -0x2(%rdi,%rdx,1),%edi
 10510d4:	xor    (%rax),%cx
 10510d7:	xor    -0x2(%rax,%rdx,1),%di
 10510dc:	or     %cx,%di
 10510df:	sete   %bl
 10510e2:	xor    $0x1,%bl
 10510e5:	test   %r13,0x69914(%rip)        # 10baa00 <myl_lit_3b82d7fd89ea641dc3c74175c3081dd70840c2be20de843e08a42204e3d9c4cc_instance>
 10510ec:	jne    105110b <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x293b>
 10510ee:	mov    0x698fb(%rip),%rax        # 10ba9f0 <myl_lit_3b2e9d8953e261b03d089bbc831cd3b7c9a128df1fa9770dfd3ff0548594ae5c_instance+0x20>
 10510f5:	dec    %rax
 10510f8:	jne    1051104 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2934>
 10510fa:	cmpq   $0x0,0x698f6(%rip)        # 10ba9f8 <myl_lit_3b2e9d8953e261b03d089bbc831cd3b7c9a128df1fa9770dfd3ff0548594ae5c_instance+0x28>
 1051102:	je     1051174 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x29a4>
 1051104:	mov    %rax,0x698e5(%rip)        # 10ba9f0 <myl_lit_3b2e9d8953e261b03d089bbc831cd3b7c9a128df1fa9770dfd3ff0548594ae5c_instance+0x20>
 105110b:	movq   $0x0,0xc8(%rsp)
 1051117:	test   %bl,%bl
 1051119:	je     1051195 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x29c5>
 105111b:	movq   $0x10baf18,0x70(%rsp)
 1051124:	movq   $0x10baf18,0xc8(%rsp)
 1051130:	cmp    $0x10baf18,%rsi
 1051137:	jne    1051140 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2970>
 1051139:	xor    %ebx,%ebx
 105113b:	jmp    105148c <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2cbc>
 1051140:	mov    $0x1,%bl
 1051142:	test   %rsi,%rsi
 1051145:	je     105148c <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2cbc>
 105114b:	mov    0x8(%rsi),%rdx
 105114f:	cmp    0x69dca(%rip),%rdx        # 10baf20 <myl_lit_626da83bb2caf4205ae415768034d7bb2b32d76c3b0b29af95ab0567cf1d3ca9_instance+0x18>
 1051156:	jne    105148c <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2cbc>
 105115c:	test   %rdx,%rdx
 105115f:	je     1051139 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2969>
 1051161:	testb  $0x4,0x10(%rsi)
 1051165:	jne    10513d4 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2c04>
 105116b:	lea    0x18(%rsi),%rdi
 105116f:	jmp    10513e3 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2c13>
 1051174:	lea    0xc8(%rsp),%rax
 105117c:	lea    0x258(%rbp),%rdi
 1051183:	mov    %rsi,%r14
 1051186:	mov    %rax,%rsi
 1051189:	call   1087900 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop>
 105118e:	mov    %r14,%rsi
 1051191:	test   %bl,%bl
 1051193:	jne    105111b <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x294b>
 1051195:	xor    %ebx,%ebx
 1051197:	lea    0x1a8(%rsp),%r14
 105119f:	movabs $0x89705f3112a28fe5,%r13
 10511a9:	xor    %eax,%eax
 10511ab:	nopl   0x0(%rax,%rax,1)
 10511b0:	mov    %rax,%r15
 10511b3:	mov    0x8(%rsp),%rax
 10511b8:	add    %rbx,%rax
 10511bb:	jo     1051e03 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3633>
 10511c1:	mov    0x30(%rsp),%rcx
 10511c6:	mov    0x8(%rcx),%rdi
 10511ca:	mov    (%rdi),%rcx
 10511cd:	test   %rcx,%rcx
 10511d0:	js     1051e15 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3645>
 10511d6:	je     1051e20 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3650>
 10511dc:	mov    %rax,%rdx
 10511df:	or     %rcx,%rdx
 10511e2:	shr    $0x20,%rdx
 10511e6:	je     10511ef <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2a1f>
 10511e8:	cqto
 10511ea:	idiv   %rcx
 10511ed:	jmp    10511f3 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2a23>
 10511ef:	xor    %edx,%edx
 10511f1:	div    %ecx
 10511f3:	mov    %rdx,%rax
 10511f6:	sar    $0x3f,%rax
 10511fa:	and    %rcx,%rax
 10511fd:	add    %rdx,%rax
 1051200:	mov    %rax,%rsi
 1051203:	sar    $0x3f,%rsi
 1051207:	and    %rcx,%rsi
 105120a:	add    %rax,%rsi
 105120d:	cmp    %rcx,%rsi
 1051210:	jae    1051e2b <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x365b>
 1051216:	mov    0x20(%rdi),%rax
 105121a:	mov    (%rax,%rsi,8),%rax
 105121e:	test   %rax,%rax
 1051221:	je     105124e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2a7e>
 1051223:	mov    %rax,%rdi
 1051226:	movabs $0x4000000000000002,%rcx
 1051230:	test   %rcx,-0x10(%rax)
 1051234:	je     105137f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2baf>
 105123a:	mov    %rax,0x140(%rsp)
 1051242:	testb  $0x4,0x10(%rdi)
 1051246:	jne    105125e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2a8e>
 1051248:	add    $0x18,%rdi
 105124c:	jmp    105126d <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2a9d>
 105124e:	xor    %edi,%edi
 1051250:	mov    %rax,0x140(%rsp)
 1051258:	testb  $0x4,0x10(%rdi)
 105125c:	je     1051248 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2a78>
 105125e:	mov    0x18(%rdi),%rcx
 1051262:	mov    0x14(%rdi),%edx
 1051265:	lea    (%rcx,%rdx,1),%rdi
 1051269:	add    $0x18,%rdi
 105126d:	mov    0x8(%rax),%rsi
 1051271:	xor    %edx,%edx
 1051273:	mov    %r14,%rcx
 1051276:	call   104a290 <myl_native_bytes_number_parse>
 105127b:	test   %eax,%eax
 105127d:	je     10512e1 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2b11>
 105127f:	mov    0x1a8(%rsp),%r12
 1051287:	movl   $0x1,0x160(%rsp)
 1051292:	mov    %r12,0x168(%rsp)
 105129a:	mov    0x140(%rsp),%rax
 10512a2:	test   %rax,%rax
 10512a5:	je     1051330 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2b60>
 10512ab:	movabs $0x4000000000000002,%rcx
 10512b5:	test   %rcx,-0x10(%rax)
 10512b9:	jne    1051330 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2b60>
 10512bb:	mov    -0x18(%rax),%rcx
 10512bf:	dec    %rcx
 10512c2:	jne    1051323 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2b53>
 10512c4:	cmpq   $0x0,-0x20(%rax)
 10512c9:	jne    1051323 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2b53>
 10512cb:	lea    0x258(%rbp),%rdi
 10512d2:	lea    0x140(%rsp),%rsi
 10512da:	call   1087890 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan>
 10512df:	jmp    1051330 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2b60>
 10512e1:	movl   $0x0,0x160(%rsp)
 10512ec:	mov    0x140(%rsp),%rax
 10512f4:	mov    $0x61,%r12d
 10512fa:	test   %rax,%rax
 10512fd:	je     1051330 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2b60>
 10512ff:	movabs $0x4000000000000002,%rcx
 1051309:	test   %rcx,-0x10(%rax)
 105130d:	jne    1051330 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2b60>
 105130f:	mov    -0x18(%rax),%rcx
 1051313:	dec    %rcx
 1051316:	jne    1051323 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2b53>
 1051318:	cmpq   $0x0,-0x20(%rax)
 105131d:	je     10513bb <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2beb>
 1051323:	mov    %rcx,-0x18(%rax)
 1051327:	nopw   0x0(%rax,%rax,1)
 1051330:	mov    %r15,%rcx
 1051333:	add    %r12,%rcx
 1051336:	jo     1051e36 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3666>
 105133c:	mov    %rcx,%rax
 105133f:	imul   %r13
 1051342:	add    %rcx,%rdx
 1051345:	mov    %rdx,%rax
 1051348:	shr    $0x3f,%rax
 105134c:	sar    $0x1d,%rdx
 1051350:	add    %rax,%rdx
 1051353:	imul   $0x3b9aca07,%rdx,%rax
 105135a:	sub    %rax,%rcx
 105135d:	mov    %rcx,%rax
 1051360:	sar    $0x3f,%rax
 1051364:	and    $0x3b9aca07,%eax
 1051369:	add    %rcx,%rax
 105136c:	inc    %rbx
 105136f:	cmp    %rbx,0x28(%rsp)
 1051374:	jne    10511b0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x29e0>
 105137a:	jmp    104f0fc <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x92c>
 105137f:	mov    -0x18(%rax),%rcx
 1051383:	inc    %rcx
 1051386:	je     10513a6 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2bd6>
 1051388:	mov    %rcx,-0x18(%rax)
 105138c:	mov    %rax,%rdi
 105138f:	mov    %rax,0x140(%rsp)
 1051397:	testb  $0x4,0x10(%rdi)
 105139b:	jne    105125e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2a8e>
 10513a1:	jmp    1051248 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2a78>
 10513a6:	mov    $0x1007dbf,%esi
 10513ab:	mov    %rbp,%rdi
 10513ae:	call   108be4e <fail>
 10513b3:	xor    %r12d,%r12d
 10513b6:	jmp    1051330 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2b60>
 10513bb:	lea    0x258(%rbp),%rdi
 10513c2:	lea    0x140(%rsp),%rsi
 10513ca:	call   1087890 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan>
 10513cf:	jmp    1051330 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2b60>
 10513d4:	mov    0x18(%rsi),%rax
 10513d8:	mov    0x14(%rsi),%ecx
 10513db:	lea    (%rax,%rcx,1),%rdi
 10513df:	add    $0x18,%rdi
 10513e3:	testb  $0x4,0x69b3e(%rip)        # 10baf28 <myl_lit_626da83bb2caf4205ae415768034d7bb2b32d76c3b0b29af95ab0567cf1d3ca9_instance+0x20>
 10513ea:	mov    0x69b3f(%rip),%rax        # 10baf30 <myl_lit_626da83bb2caf4205ae415768034d7bb2b32d76c3b0b29af95ab0567cf1d3ca9_instance+0x28>
 10513f1:	mov    0x69b35(%rip),%ecx        # 10baf2c <myl_lit_626da83bb2caf4205ae415768034d7bb2b32d76c3b0b29af95ab0567cf1d3ca9_instance+0x24>
 10513f7:	lea    0x18(%rax,%rcx,1),%rcx
 10513fc:	mov    $0x10baf30,%eax
 1051401:	cmovne %rcx,%rax
 1051405:	cmp    $0x10,%rdx
 1051409:	ja     1051426 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2c56>
 105140b:	cmp    $0x8,%rdx
 105140f:	jb     1051441 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2c71>
 1051411:	mov    (%rdi),%rcx
 1051414:	mov    -0x8(%rdi,%rdx,1),%rdi
 1051419:	xor    (%rax),%rcx
 105141c:	xor    -0x8(%rax,%rdx,1),%rdi
 1051421:	or     %rcx,%rdi
 1051424:	jmp    1051486 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2cb6>
 1051426:	mov    %rsi,%r14
 1051429:	mov    %rax,%rsi
 105142c:	cmp    $0x100,%rdx
 1051433:	ja     1051457 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2c87>
 1051435:	call   10ad360 <bcmp@plt>
 105143a:	test   %eax,%eax
 105143c:	setne  %bl
 105143f:	jmp    1051461 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2c91>
 1051441:	cmp    $0x4,%rdx
 1051445:	jb     1051466 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2c96>
 1051447:	mov    (%rdi),%ecx
 1051449:	mov    -0x4(%rdi,%rdx,1),%edi
 105144d:	xor    (%rax),%ecx
 105144f:	xor    -0x4(%rax,%rdx,1),%edi
 1051453:	or     %ecx,%edi
 1051455:	jmp    1051486 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2cb6>
 1051457:	call   1093490 <equal_large_octets>
 105145c:	test   %eax,%eax
 105145e:	sete   %bl
 1051461:	mov    %r14,%rsi
 1051464:	jmp    105148c <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2cbc>
 1051466:	cmp    $0x1,%rdx
 105146a:	jne    1051473 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2ca3>
 105146c:	movzbl (%rdi),%ecx
 105146f:	cmp    (%rax),%cl
 1051471:	jmp    1051486 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2cb6>
 1051473:	movzwl (%rdi),%ecx
 1051476:	movzwl -0x2(%rdi,%rdx,1),%edi
 105147b:	xor    (%rax),%cx
 105147e:	xor    -0x2(%rax,%rdx,1),%di
 1051483:	or     %cx,%di
 1051486:	sete   %bl
 1051489:	xor    $0x1,%bl
 105148c:	test   %r13,0x69a75(%rip)        # 10baf08 <myl_lit_626da83bb2caf4205ae415768034d7bb2b32d76c3b0b29af95ab0567cf1d3ca9_instance>
 1051493:	jne    10514b2 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2ce2>
 1051495:	mov    0x69a5c(%rip),%rax        # 10baef8 <myl_lit_5ffcfeefbc77603111eb9faae2375c1bd71d00fc5610c522261905cf007d59b3_instance+0x60>
 105149c:	dec    %rax
 105149f:	jne    10514ab <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2cdb>
 10514a1:	cmpq   $0x0,0x69a57(%rip)        # 10baf00 <myl_lit_5ffcfeefbc77603111eb9faae2375c1bd71d00fc5610c522261905cf007d59b3_instance+0x68>
 10514a9:	je     105150f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2d3f>
 10514ab:	mov    %rax,0x69a46(%rip)        # 10baef8 <myl_lit_5ffcfeefbc77603111eb9faae2375c1bd71d00fc5610c522261905cf007d59b3_instance+0x60>
 10514b2:	test   %bl,%bl
 10514b4:	je     1051530 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2d60>
 10514b6:	movq   $0x10bb330,0x70(%rsp)
 10514bf:	movq   $0x10bb330,0xc8(%rsp)
 10514cb:	cmp    $0x10bb330,%rsi
 10514d2:	jne    10514db <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2d0b>
 10514d4:	xor    %ebx,%ebx
 10514d6:	jmp    105174e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2f7e>
 10514db:	mov    $0x1,%bl
 10514dd:	test   %rsi,%rsi
 10514e0:	je     105174e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2f7e>
 10514e6:	mov    0x8(%rsi),%rdx
 10514ea:	cmp    0x69e47(%rip),%rdx        # 10bb338 <myl_lit_a35604ac3394cc7d310962e0ecc5dd785c46f6dc02140680027413a7b439bcdd_instance+0x18>
 10514f1:	jne    105174e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2f7e>
 10514f7:	test   %rdx,%rdx
 10514fa:	je     10514d4 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2d04>
 10514fc:	testb  $0x4,0x10(%rsi)
 1051500:	jne    1051696 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2ec6>
 1051506:	lea    0x18(%rsi),%rdi
 105150a:	jmp    10516a5 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2ed5>
 105150f:	lea    0xc8(%rsp),%rax
 1051517:	lea    0x258(%rbp),%rdi
 105151e:	mov    %rsi,%r14
 1051521:	mov    %rax,%rsi
 1051524:	call   1087900 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop>
 1051529:	mov    %r14,%rsi
 105152c:	test   %bl,%bl
 105152e:	jne    10514b6 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2ce6>
 1051530:	xor    %ebx,%ebx
 1051532:	movabs $0x89705f3112a28fe5,%r12
 105153c:	xor    %eax,%eax
 105153e:	movabs $0x4000000000000002,%r13
 1051548:	nopl   0x0(%rax,%rax,1)
 1051550:	mov    %rax,%r14
 1051553:	mov    0x8(%rsp),%rax
 1051558:	add    %rbx,%rax
 105155b:	jo     1051e46 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3676>
 1051561:	mov    0x30(%rsp),%rcx
 1051566:	mov    0x18(%rcx),%rdi
 105156a:	mov    (%rdi),%rcx
 105156d:	test   %rcx,%rcx
 1051570:	js     1051e58 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3688>
 1051576:	je     1051e63 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3693>
 105157c:	mov    %rax,%rdx
 105157f:	or     %rcx,%rdx
 1051582:	shr    $0x20,%rdx
 1051586:	je     105158f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2dbf>
 1051588:	cqto
 105158a:	idiv   %rcx
 105158d:	jmp    1051593 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2dc3>
 105158f:	xor    %edx,%edx
 1051591:	div    %ecx
 1051593:	mov    %rdx,%rsi
 1051596:	sar    $0x3f,%rsi
 105159a:	and    %rcx,%rsi
 105159d:	add    %rdx,%rsi
 10515a0:	cmp    %rcx,%rsi
 10515a3:	jb     10515bb <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2deb>
 10515a5:	mov    %rsi,%rax
 10515a8:	sar    $0x3f,%rax
 10515ac:	and    %rcx,%rax
 10515af:	add    %rax,%rsi
 10515b2:	cmp    %rcx,%rsi
 10515b5:	jae    1051e76 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x36a6>
 10515bb:	mov    0x20(%rdi),%rax
 10515bf:	mov    (%rax,%rsi,8),%rsi
 10515c3:	lea    0x258(%rbp),%rdi
 10515ca:	call   104bdf0 <myl_native_text_integer>
 10515cf:	test   %rax,%rax
 10515d2:	je     1051e6e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x369e>
 10515d8:	mov    %rax,%r15
 10515db:	mov    %rax,0x70(%rsp)
 10515e0:	mov    %rax,0x1c8(%rsp)
 10515e8:	mov    %rbp,%rdi
 10515eb:	mov    %rax,%rsi
 10515ee:	call   1074e30 <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85>
 10515f3:	test   %r13,-0x10(%r15)
 10515f7:	jne    105160d <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2e3d>
 10515f9:	mov    -0x20(%r15),%rcx
 10515fd:	dec    %rcx
 1051600:	jne    1051609 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2e39>
 1051602:	cmpq   $0x0,-0x18(%r15)
 1051607:	je     1051664 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2e94>
 1051609:	mov    %rcx,-0x20(%r15)
 105160d:	movq   $0x0,0x1c8(%rsp)
 1051619:	mov    %r14,%rcx
 105161c:	add    %rax,%rcx
 105161f:	jo     1051686 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2eb6>
 1051621:	mov    %rcx,%rax
 1051624:	imul   %r12
 1051627:	add    %rcx,%rdx
 105162a:	mov    %rdx,%rax
 105162d:	shr    $0x3f,%rax
 1051631:	sar    $0x1d,%rdx
 1051635:	add    %rax,%rdx
 1051638:	imul   $0x3b9aca07,%rdx,%rax
 105163f:	sub    %rax,%rcx
 1051642:	mov    %rcx,%rax
 1051645:	sar    $0x3f,%rax
 1051649:	and    $0x3b9aca07,%eax
 105164e:	add    %rcx,%rax
 1051651:	inc    %rbx
 1051654:	cmp    %rbx,0x28(%rsp)
 1051659:	jne    1051550 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2d80>
 105165f:	jmp    104f0fc <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x92c>
 1051664:	lea    0x258(%rbp),%rdi
 105166b:	lea    0x1c8(%rsp),%rsi
 1051673:	mov    %rax,%r15
 1051676:	call   1087900 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop>
 105167b:	mov    %r15,%rax
 105167e:	mov    %r14,%rcx
 1051681:	add    %rax,%rcx
 1051684:	jno    1051621 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2e51>
 1051686:	mov    %rbp,%rdi
 1051689:	xor    %esi,%esi
 105168b:	mov    %r14,%rdx
 105168e:	mov    %rax,%rcx
 1051691:	call   108c860 <myl_qbe_fail_overflow_op>
 1051696:	mov    0x18(%rsi),%rax
 105169a:	mov    0x14(%rsi),%ecx
 105169d:	lea    (%rax,%rcx,1),%rdi
 10516a1:	add    $0x18,%rdi
 10516a5:	testb  $0x4,0x69c94(%rip)        # 10bb340 <myl_lit_a35604ac3394cc7d310962e0ecc5dd785c46f6dc02140680027413a7b439bcdd_instance+0x20>
 10516ac:	mov    0x69c95(%rip),%rax        # 10bb348 <myl_lit_a35604ac3394cc7d310962e0ecc5dd785c46f6dc02140680027413a7b439bcdd_instance+0x28>
 10516b3:	mov    0x69c8b(%rip),%ecx        # 10bb344 <myl_lit_a35604ac3394cc7d310962e0ecc5dd785c46f6dc02140680027413a7b439bcdd_instance+0x24>
 10516b9:	lea    0x18(%rax,%rcx,1),%rcx
 10516be:	mov    $0x10bb348,%eax
 10516c3:	cmovne %rcx,%rax
 10516c7:	cmp    $0x10,%rdx
 10516cb:	ja     10516e8 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2f18>
 10516cd:	cmp    $0x8,%rdx
 10516d1:	jb     1051703 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2f33>
 10516d3:	mov    (%rdi),%rcx
 10516d6:	mov    -0x8(%rdi,%rdx,1),%rdi
 10516db:	xor    (%rax),%rcx
 10516de:	xor    -0x8(%rax,%rdx,1),%rdi
 10516e3:	or     %rcx,%rdi
 10516e6:	jmp    1051748 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2f78>
 10516e8:	mov    %rsi,%r14
 10516eb:	mov    %rax,%rsi
 10516ee:	cmp    $0x100,%rdx
 10516f5:	ja     1051719 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2f49>
 10516f7:	call   10ad360 <bcmp@plt>
 10516fc:	test   %eax,%eax
 10516fe:	setne  %bl
 1051701:	jmp    1051723 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2f53>
 1051703:	cmp    $0x4,%rdx
 1051707:	jb     1051728 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2f58>
 1051709:	mov    (%rdi),%ecx
 105170b:	mov    -0x4(%rdi,%rdx,1),%edi
 105170f:	xor    (%rax),%ecx
 1051711:	xor    -0x4(%rax,%rdx,1),%edi
 1051715:	or     %ecx,%edi
 1051717:	jmp    1051748 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2f78>
 1051719:	call   1093490 <equal_large_octets>
 105171e:	test   %eax,%eax
 1051720:	sete   %bl
 1051723:	mov    %r14,%rsi
 1051726:	jmp    105174e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2f7e>
 1051728:	cmp    $0x1,%rdx
 105172c:	jne    1051735 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2f65>
 105172e:	movzbl (%rdi),%ecx
 1051731:	cmp    (%rax),%cl
 1051733:	jmp    1051748 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2f78>
 1051735:	movzwl (%rdi),%ecx
 1051738:	movzwl -0x2(%rdi,%rdx,1),%edi
 105173d:	xor    (%rax),%cx
 1051740:	xor    -0x2(%rax,%rdx,1),%di
 1051745:	or     %cx,%di
 1051748:	sete   %bl
 105174b:	xor    $0x1,%bl
 105174e:	test   %r13,0x69bcb(%rip)        # 10bb320 <myl_lit_a35604ac3394cc7d310962e0ecc5dd785c46f6dc02140680027413a7b439bcdd_instance>
 1051755:	jne    1051774 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2fa4>
 1051757:	mov    0x69bb2(%rip),%rax        # 10bb310 <myl_lit_9d259d114fa076e260ed1d46f937777788fb8ac5c28077065c4fa3e2a22cd22a_instance+0x38>
 105175e:	dec    %rax
 1051761:	jne    105176d <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2f9d>
 1051763:	cmpq   $0x0,0x69bad(%rip)        # 10bb318 <myl_lit_9d259d114fa076e260ed1d46f937777788fb8ac5c28077065c4fa3e2a22cd22a_instance+0x40>
 105176b:	je     10517e2 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3012>
 105176d:	mov    %rax,0x69b9c(%rip)        # 10bb310 <myl_lit_9d259d114fa076e260ed1d46f937777788fb8ac5c28077065c4fa3e2a22cd22a_instance+0x38>
 1051774:	test   %bl,%bl
 1051776:	je     1051807 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3037>
 105177c:	movq   $0x10ba7c8,0x70(%rsp)
 1051785:	movq   $0x10ba7c8,0xc8(%rsp)
 1051791:	cmp    $0x10ba7c8,%rsi
 1051798:	jne    10517ae <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2fde>
 105179a:	xor    %ebx,%ebx
 105179c:	test   %r13,0x69015(%rip)        # 10ba7b8 <myl_lit_20a5074191baf0b9771e8515f87070a522415c098c80effc97a3fee2e9d89d03_instance>
 10517a3:	jne    1051966 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3196>
 10517a9:	jmp    1051945 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3175>
 10517ae:	mov    $0x1,%bl
 10517b0:	test   %rsi,%rsi
 10517b3:	je     105193c <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x316c>
 10517b9:	mov    0x8(%rsi),%rdx
 10517bd:	cmp    0x6900c(%rip),%rdx        # 10ba7d0 <myl_lit_20a5074191baf0b9771e8515f87070a522415c098c80effc97a3fee2e9d89d03_instance+0x18>
 10517c4:	jne    105193c <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x316c>
 10517ca:	test   %rdx,%rdx
 10517cd:	je     105179a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2fca>
 10517cf:	testb  $0x4,0x10(%rsi)
 10517d3:	jne    1051899 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x30c9>
 10517d9:	lea    0x18(%rsi),%rdi
 10517dd:	jmp    10518a8 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x30d8>
 10517e2:	lea    0xc8(%rsp),%rax
 10517ea:	lea    0x258(%rbp),%rdi
 10517f1:	mov    %rsi,%r14
 10517f4:	mov    %rax,%rsi
 10517f7:	call   1087900 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop>
 10517fc:	mov    %r14,%rsi
 10517ff:	test   %bl,%bl
 1051801:	jne    105177c <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2fac>
 1051807:	xor    %ebx,%ebx
 1051809:	movabs $0x89705f3112a28fe5,%r14
 1051813:	xor    %eax,%eax
 1051815:	mov    0x8(%rsp),%rsi
 105181a:	add    %rbx,%rsi
 105181d:	jo     1051e81 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x36b1>
 1051823:	mov    %rax,%r15
 1051826:	mov    0x30(%rsp),%rax
 105182b:	mov    0x8(%rax),%rax
 105182f:	and    $0x1,%esi
 1051832:	mov    (%rax),%rdx
 1051835:	cmp    %rdx,%rsi
 1051838:	jae    1051e93 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x36c3>
 105183e:	mov    0x20(%rax),%rax
 1051842:	mov    (%rax,%rsi,8),%rsi
 1051846:	mov    %rbp,%rdi
 1051849:	call   106b590 <myl_f_ad1ca9f864adc8c89d572ada651cc6dc28bc6d83eeae5c5fc70bc26744bcdb57>
 105184e:	mov    %r15,%rcx
 1051851:	add    %rax,%rcx
 1051854:	jo     1051e9b <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x36cb>
 105185a:	mov    %rcx,%rax
 105185d:	imul   %r14
 1051860:	add    %rcx,%rdx
 1051863:	mov    %rdx,%rax
 1051866:	shr    $0x3f,%rax
 105186a:	sar    $0x1d,%rdx
 105186e:	add    %rax,%rdx
 1051871:	imul   $0x3b9aca07,%rdx,%rax
 1051878:	sub    %rax,%rcx
 105187b:	mov    %rcx,%rax
 105187e:	sar    $0x3f,%rax
 1051882:	and    $0x3b9aca07,%eax
 1051887:	add    %rcx,%rax
 105188a:	inc    %rbx
 105188d:	cmp    %rbx,0x28(%rsp)
 1051892:	jne    1051815 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3045>
 1051894:	jmp    104f0fc <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x92c>
 1051899:	mov    0x18(%rsi),%rax
 105189d:	mov    0x14(%rsi),%ecx
 10518a0:	lea    (%rax,%rcx,1),%rdi
 10518a4:	add    $0x18,%rdi
 10518a8:	testb  $0x4,0x68f29(%rip)        # 10ba7d8 <myl_lit_20a5074191baf0b9771e8515f87070a522415c098c80effc97a3fee2e9d89d03_instance+0x20>
 10518af:	mov    0x68f2a(%rip),%rax        # 10ba7e0 <myl_lit_20a5074191baf0b9771e8515f87070a522415c098c80effc97a3fee2e9d89d03_instance+0x28>
 10518b6:	mov    0x68f20(%rip),%ecx        # 10ba7dc <myl_lit_20a5074191baf0b9771e8515f87070a522415c098c80effc97a3fee2e9d89d03_instance+0x24>
 10518bc:	lea    0x18(%rax,%rcx,1),%rcx
 10518c1:	mov    $0x10ba7e0,%eax
 10518c6:	cmovne %rcx,%rax
 10518ca:	cmp    $0x10,%rdx
 10518ce:	ja     10518eb <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x311b>
 10518d0:	cmp    $0x8,%rdx
 10518d4:	jb     1051906 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3136>
 10518d6:	mov    (%rdi),%rcx
 10518d9:	mov    -0x8(%rdi,%rdx,1),%rdi
 10518de:	xor    (%rax),%rcx
 10518e1:	xor    -0x8(%rax,%rdx,1),%rdi
 10518e6:	or     %rcx,%rdi
 10518e9:	jmp    105191e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x314e>
 10518eb:	mov    %rsi,%r14
 10518ee:	mov    %rax,%rsi
 10518f1:	cmp    $0x100,%rdx
 10518f8:	ja     105192f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x315f>
 10518fa:	call   10ad360 <bcmp@plt>
 10518ff:	test   %eax,%eax
 1051901:	setne  %bl
 1051904:	jmp    1051939 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3169>
 1051906:	cmp    $0x4,%rdx
 105190a:	jb     1051ae9 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3319>
 1051910:	mov    (%rdi),%ecx
 1051912:	mov    -0x4(%rdi,%rdx,1),%edi
 1051916:	xor    (%rax),%ecx
 1051918:	xor    -0x4(%rax,%rdx,1),%edi
 105191c:	or     %ecx,%edi
 105191e:	sete   %bl
 1051921:	xor    $0x1,%bl
 1051924:	test   %r13,0x68e8d(%rip)        # 10ba7b8 <myl_lit_20a5074191baf0b9771e8515f87070a522415c098c80effc97a3fee2e9d89d03_instance>
 105192b:	jne    1051966 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3196>
 105192d:	jmp    1051945 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3175>
 105192f:	call   1093490 <equal_large_octets>
 1051934:	test   %eax,%eax
 1051936:	sete   %bl
 1051939:	mov    %r14,%rsi
 105193c:	test   %r13,0x68e75(%rip)        # 10ba7b8 <myl_lit_20a5074191baf0b9771e8515f87070a522415c098c80effc97a3fee2e9d89d03_instance>
 1051943:	jne    1051966 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3196>
 1051945:	mov    0x68e5c(%rip),%rax        # 10ba7a8 <myl_lit_1ad4f10fd641593331eda3448c74a0b009c6527a19d75e6283c9d7ef74595fd2_instance+0x38>
 105194c:	dec    %rax
 105194f:	jne    105195f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x318f>
 1051951:	cmpq   $0x0,0x68e57(%rip)        # 10ba7b0 <myl_lit_1ad4f10fd641593331eda3448c74a0b009c6527a19d75e6283c9d7ef74595fd2_instance+0x40>
 1051959:	je     1051a50 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3280>
 105195f:	mov    %rax,0x68e42(%rip)        # 10ba7a8 <myl_lit_1ad4f10fd641593331eda3448c74a0b009c6527a19d75e6283c9d7ef74595fd2_instance+0x38>
 1051966:	test   %bl,%bl
 1051968:	je     1051993 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x31c3>
 105196a:	movq   $0x10ba898,0x70(%rsp)
 1051973:	movq   $0x10ba898,0xc8(%rsp)
 105197f:	cmp    $0x10ba898,%rsi
 1051986:	jne    1051a1f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x324f>
 105198c:	xor    %ebx,%ebx
 105198e:	jmp    1051b87 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x33b7>
 1051993:	xor    %ebx,%ebx
 1051995:	movabs $0x89705f3112a28fe5,%r14
 105199f:	xor    %eax,%eax
 10519a1:	mov    %rax,%r15
 10519a4:	mov    0x8(%rsp),%rax
 10519a9:	add    %rbx,%rax
 10519ac:	jo     1051eab <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x36db>
 10519b2:	mov    0x30(%rsp),%rax
 10519b7:	mov    0x8(%rax),%rax
 10519bb:	cmpq   $0x0,(%rax)
 10519bf:	je     1051ebd <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x36ed>
 10519c5:	mov    0x20(%rax),%rax
 10519c9:	mov    (%rax),%rsi
 10519cc:	mov    %rbp,%rdi
 10519cf:	call   1072b10 <myl_f_bc9060da36c8e282f8d98349f6541aa0f2c1802b8a99e1d4c2ef7b134103c5e2>
 10519d4:	mov    %r15,%rcx
 10519d7:	add    %rax,%rcx
 10519da:	jo     1051ec9 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x36f9>
 10519e0:	mov    %rcx,%rax
 10519e3:	imul   %r14
 10519e6:	add    %rcx,%rdx
 10519e9:	mov    %rdx,%rax
 10519ec:	shr    $0x3f,%rax
 10519f0:	sar    $0x1d,%rdx
 10519f4:	add    %rax,%rdx
 10519f7:	imul   $0x3b9aca07,%rdx,%rax
 10519fe:	sub    %rax,%rcx
 1051a01:	mov    %rcx,%rax
 1051a04:	sar    $0x3f,%rax
 1051a08:	and    $0x3b9aca07,%eax
 1051a0d:	add    %rcx,%rax
 1051a10:	inc    %rbx
 1051a13:	cmp    %rbx,0x28(%rsp)
 1051a18:	jne    10519a1 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x31d1>
 1051a1a:	jmp    104f0fc <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x92c>
 1051a1f:	mov    $0x1,%bl
 1051a21:	test   %rsi,%rsi
 1051a24:	je     1051b87 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x33b7>
 1051a2a:	mov    0x8(%rsi),%rdx
 1051a2e:	cmp    0x68e6b(%rip),%rdx        # 10ba8a0 <myl_lit_2cecebef85ac89e87c0bdc9d723015d4a10a29fb007a542e0de04f511346a3b5_instance+0x18>
 1051a35:	jne    1051b87 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x33b7>
 1051a3b:	test   %rdx,%rdx
 1051a3e:	je     105198c <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x31bc>
 1051a44:	testb  $0x4,0x10(%rsi)
 1051a48:	jne    1051a70 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x32a0>
 1051a4a:	add    $0x18,%rsi
 1051a4e:	jmp    1051a7f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x32af>
 1051a50:	lea    0xc8(%rsp),%rax
 1051a58:	mov    0x18(%rsp),%rdi
 1051a5d:	mov    %rsi,%r14
 1051a60:	mov    %rax,%rsi
 1051a63:	call   1087900 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop>
 1051a68:	mov    %r14,%rsi
 1051a6b:	jmp    1051966 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3196>
 1051a70:	mov    0x18(%rsi),%rax
 1051a74:	mov    0x14(%rsi),%ecx
 1051a77:	lea    (%rax,%rcx,1),%rsi
 1051a7b:	add    $0x18,%rsi
 1051a7f:	testb  $0x4,0x68e22(%rip)        # 10ba8a8 <myl_lit_2cecebef85ac89e87c0bdc9d723015d4a10a29fb007a542e0de04f511346a3b5_instance+0x20>
 1051a86:	mov    0x68e23(%rip),%rax        # 10ba8b0 <myl_lit_2cecebef85ac89e87c0bdc9d723015d4a10a29fb007a542e0de04f511346a3b5_instance+0x28>
 1051a8d:	mov    0x68e19(%rip),%ecx        # 10ba8ac <myl_lit_2cecebef85ac89e87c0bdc9d723015d4a10a29fb007a542e0de04f511346a3b5_instance+0x24>
 1051a93:	lea    0x18(%rax,%rcx,1),%rcx
 1051a98:	mov    $0x10ba8b0,%eax
 1051a9d:	cmovne %rcx,%rax
 1051aa1:	cmp    $0x10,%rdx
 1051aa5:	ja     1051acb <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x32fb>
 1051aa7:	cmp    $0x8,%rdx
 1051aab:	jb     1051af6 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3326>
 1051aad:	mov    (%rsi),%rcx
 1051ab0:	mov    -0x8(%rsi,%rdx,1),%rsi
 1051ab5:	xor    (%rax),%rcx
 1051ab8:	xor    -0x8(%rax,%rdx,1),%rsi
 1051abd:	or     %rcx,%rsi
 1051ac0:	sete   %bl
 1051ac3:	xor    $0x1,%bl
 1051ac6:	jmp    1051b87 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x33b7>
 1051acb:	mov    %rsi,%rdi
 1051ace:	mov    %rax,%rsi
 1051ad1:	cmp    $0x100,%rdx
 1051ad8:	ja     1051b0c <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x333c>
 1051ada:	call   10ad360 <bcmp@plt>
 1051adf:	test   %eax,%eax
 1051ae1:	setne  %bl
 1051ae4:	jmp    1051b87 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x33b7>
 1051ae9:	cmp    $0x1,%rdx
 1051aed:	jne    1051b18 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3348>
 1051aef:	movzbl (%rdi),%ecx
 1051af2:	cmp    (%rax),%cl
 1051af4:	jmp    1051b2b <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x335b>
 1051af6:	cmp    $0x4,%rdx
 1051afa:	jb     1051b52 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3382>
 1051afc:	mov    (%rsi),%ecx
 1051afe:	mov    -0x4(%rsi,%rdx,1),%esi
 1051b02:	xor    (%rax),%ecx
 1051b04:	xor    -0x4(%rax,%rdx,1),%esi
 1051b08:	or     %ecx,%esi
 1051b0a:	jmp    1051b72 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x33a2>
 1051b0c:	call   1093490 <equal_large_octets>
 1051b11:	test   %eax,%eax
 1051b13:	sete   %bl
 1051b16:	jmp    1051b87 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x33b7>
 1051b18:	movzwl (%rdi),%ecx
 1051b1b:	movzwl -0x2(%rdi,%rdx,1),%edi
 1051b20:	xor    (%rax),%cx
 1051b23:	xor    -0x2(%rax,%rdx,1),%di
 1051b28:	or     %cx,%di
 1051b2b:	sete   %bl
 1051b2e:	xor    $0x1,%bl
 1051b31:	mov    0x10(%rsp),%rbp
 1051b36:	movabs $0x4000000000000002,%r13
 1051b40:	test   %r13,0x68c71(%rip)        # 10ba7b8 <myl_lit_20a5074191baf0b9771e8515f87070a522415c098c80effc97a3fee2e9d89d03_instance>
 1051b47:	jne    1051966 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3196>
 1051b4d:	jmp    1051945 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3175>
 1051b52:	cmp    $0x1,%rdx
 1051b56:	jne    1051b5f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x338f>
 1051b58:	movzbl (%rsi),%ecx
 1051b5b:	cmp    (%rax),%cl
 1051b5d:	jmp    1051b72 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x33a2>
 1051b5f:	movzwl (%rsi),%ecx
 1051b62:	movzwl -0x2(%rsi,%rdx,1),%esi
 1051b67:	xor    (%rax),%cx
 1051b6a:	xor    -0x2(%rax,%rdx,1),%si
 1051b6f:	or     %cx,%si
 1051b72:	sete   %bl
 1051b75:	xor    $0x1,%bl
 1051b78:	mov    0x10(%rsp),%rbp
 1051b7d:	movabs $0x4000000000000002,%r13
 1051b87:	test   %r13,0x68cfa(%rip)        # 10ba888 <myl_lit_2cecebef85ac89e87c0bdc9d723015d4a10a29fb007a542e0de04f511346a3b5_instance>
 1051b8e:	jne    1051bad <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x33dd>
 1051b90:	mov    0x68ce1(%rip),%rax        # 10ba878 <myl_lit_2ac6840555c10725b6640492294f67393cd0d698e5786fc4e12cdb1cc9a394a2_instance+0x38>
 1051b97:	dec    %rax
 1051b9a:	jne    1051ba6 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x33d6>
 1051b9c:	cmpq   $0x0,0x68cdc(%rip)        # 10ba880 <myl_lit_2ac6840555c10725b6640492294f67393cd0d698e5786fc4e12cdb1cc9a394a2_instance+0x40>
 1051ba4:	je     1051bb8 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x33e8>
 1051ba6:	mov    %rax,0x68ccb(%rip)        # 10ba878 <myl_lit_2ac6840555c10725b6640492294f67393cd0d698e5786fc4e12cdb1cc9a394a2_instance+0x38>
 1051bad:	test   %bl,%bl
 1051baf:	je     1051bce <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x33fe>
 1051bb1:	xor    %eax,%eax
 1051bb3:	jmp    104f0fc <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x92c>
 1051bb8:	lea    0xc8(%rsp),%rsi
 1051bc0:	mov    0x18(%rsp),%rdi
 1051bc5:	call   1087900 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop>
 1051bca:	test   %bl,%bl
 1051bcc:	jne    1051bb1 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x33e1>
 1051bce:	xor    %ebx,%ebx
 1051bd0:	movabs $0x7878787878787879,%r14
 1051bda:	movabs $0x89705f3112a28fe5,%r15
 1051be4:	xor    %eax,%eax
 1051be6:	mov    0x8(%rsp),%rcx
 1051beb:	add    %rbx,%rcx
 1051bee:	jo     1051ed9 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3709>
 1051bf4:	mov    %rax,%r12
 1051bf7:	mov    0x30(%rsp),%rax
 1051bfc:	mov    0x8(%rax),%rax
 1051c00:	cmpq   $0x0,(%rax)
 1051c04:	je     1051eeb <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x371b>
 1051c0a:	mov    0x20(%rax),%rax
 1051c0e:	mov    (%rax),%rsi
 1051c11:	mov    %rcx,%rax
 1051c14:	imul   %r14
 1051c17:	mov    %rdx,%rax
 1051c1a:	shr    $0x3f,%rax
 1051c1e:	sar    $0x3,%rdx
 1051c22:	add    %rax,%rdx
 1051c25:	mov    %rdx,%rax
 1051c28:	shl    $0x4,%rax
 1051c2c:	add    %rdx,%rax
 1051c2f:	sub    %rax,%rcx
 1051c32:	mov    %rcx,%rdx
 1051c35:	sar    $0x3f,%rdx
 1051c39:	and    $0x11,%edx
 1051c3c:	add    %rcx,%rdx
 1051c3f:	mov    %rbp,%rdi
 1051c42:	call   10586c0 <myl_f_47022dd26e980fcb99b6abeb2cfdf289edce3d6955dda89c0a131b73692c5f56>
 1051c47:	mov    %r12,%rcx
 1051c4a:	add    %rax,%rcx
 1051c4d:	jo     1051ef7 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3727>
 1051c53:	mov    %rcx,%rax
 1051c56:	imul   %r15
 1051c59:	add    %rcx,%rdx
 1051c5c:	mov    %rdx,%rax
 1051c5f:	shr    $0x3f,%rax
 1051c63:	sar    $0x1d,%rdx
 1051c67:	add    %rax,%rdx
 1051c6a:	imul   $0x3b9aca07,%rdx,%rax
 1051c71:	sub    %rax,%rcx
 1051c74:	mov    %rcx,%rax
 1051c77:	sar    $0x3f,%rax
 1051c7b:	and    $0x3b9aca07,%eax
 1051c80:	add    %rcx,%rax
 1051c83:	inc    %rbx
 1051c86:	cmp    %rbx,0x28(%rsp)
 1051c8b:	jne    1051be6 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3416>
 1051c91:	jmp    104f0fc <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x92c>
 1051c96:	vzeroupper
 1051c99:	call   10ad340 <abort@plt>
 1051c9e:	vzeroupper
 1051ca1:	call   109b6c7 <myl_rc_invariant_failed>
 1051ca6:	mov    %rbp,%rdi
 1051ca9:	xor    %esi,%esi
 1051cab:	vzeroupper
 1051cae:	call   108c860 <myl_qbe_fail_overflow_op>
 1051cb3:	mov    0x10(%rsp),%rdi
 1051cb8:	xor    %esi,%esi
 1051cba:	mov    %r12,%rdx
 1051cbd:	mov    %rax,%rcx
 1051cc0:	call   108c860 <myl_qbe_fail_overflow_op>
 1051cc5:	mov    0x10(%rsp),%rdi
 1051cca:	vzeroupper
 1051ccd:	call   108c610 <myl_qbe_fail_iteration>
 1051cd2:	mov    %rbp,%rdi
 1051cd5:	xor    %esi,%esi
 1051cd7:	mov    0x8(%rsp),%rdx
 1051cdc:	mov    %r14,%rcx
 1051cdf:	vzeroupper
 1051ce2:	call   108c860 <myl_qbe_fail_overflow_op>
 1051ce7:	mov    %rbp,%rdi
 1051cea:	xor    %esi,%esi
 1051cec:	mov    %r12,%rdx
 1051cef:	mov    %rbx,%rcx
 1051cf2:	vzeroupper
 1051cf5:	call   108c860 <myl_qbe_fail_overflow_op>
 1051cfa:	mov    0x10(%rsp),%rdi
 1051cff:	call   108c750 <myl_qbe_fail_normalized_index_bounds>
 1051d04:	mov    0x10(%rsp),%rdi
 1051d09:	call   108c750 <myl_qbe_fail_normalized_index_bounds>
 1051d0e:	mov    %rbp,%rdi
 1051d11:	xor    %esi,%esi
 1051d13:	mov    0x8(%rsp),%rdx
 1051d18:	mov    %rbx,%rcx
 1051d1b:	call   108c860 <myl_qbe_fail_overflow_op>
 1051d20:	mov    %rbp,%rdi
 1051d23:	xor    %esi,%esi
 1051d25:	mov    0x8(%rsp),%rdx
 1051d2a:	mov    %rbx,%rcx
 1051d2d:	call   108c860 <myl_qbe_fail_overflow_op>
 1051d32:	mov    %rbp,%rdi
 1051d35:	xor    %esi,%esi
 1051d37:	xor    %edx,%edx
 1051d39:	call   108c750 <myl_qbe_fail_normalized_index_bounds>
 1051d3e:	mov    %rbp,%rdi
 1051d41:	call   108c750 <myl_qbe_fail_normalized_index_bounds>
 1051d46:	mov    $0x1,%ecx
 1051d4b:	mov    0x10(%rsp),%rdi
 1051d50:	xor    %esi,%esi
 1051d52:	mov    %r15,%rdx
 1051d55:	call   108c860 <myl_qbe_fail_overflow_op>
 1051d5a:	mov    %rbp,%rdi
 1051d5d:	vzeroupper
 1051d60:	call   108c750 <myl_qbe_fail_normalized_index_bounds>
 1051d65:	mov    %rbp,%rdi
 1051d68:	xor    %esi,%esi
 1051d6a:	mov    0x8(%rsp),%rdx
 1051d6f:	mov    %r12,%rcx
 1051d72:	vzeroupper
 1051d75:	call   108c860 <myl_qbe_fail_overflow_op>
 1051d7a:	mov    %rbp,%rdi
 1051d7d:	vzeroupper
 1051d80:	call   108c920 <myl_qbe_fail_frame>
 1051d85:	mov    %rbp,%rdi
 1051d88:	vzeroupper
 1051d8b:	call   108c600 <myl_qbe_fail_empty_separator>
 1051d90:	mov    %rbp,%rdi
 1051d93:	vzeroupper
 1051d96:	call   108c510 <myl_qbe_fail_allocation>
 1051d9b:	mov    %rbp,%rdi
 1051d9e:	xor    %esi,%esi
 1051da0:	mov    %r14,%rcx
 1051da3:	vzeroupper
 1051da6:	call   108c860 <myl_qbe_fail_overflow_op>
 1051dab:	mov    %rbp,%rdi
 1051dae:	mov    %r15,%rsi
 1051db1:	vzeroupper
 1051db4:	call   108c8c0 <myl_qbe_fail_cast>
 1051db9:	mov    $0x2,%esi
 1051dbe:	mov    $0x7,%ecx
 1051dc3:	mov    %rbp,%rdi
 1051dc6:	mov    %r15,%rdx
 1051dc9:	vzeroupper
 1051dcc:	call   108c860 <myl_qbe_fail_overflow_op>
 1051dd1:	mov    %rbp,%rdi
 1051dd4:	call   108c920 <myl_qbe_fail_frame>
 1051dd9:	mov    %rbp,%rdi
 1051ddc:	call   108c510 <myl_qbe_fail_allocation>
 1051de1:	mov    %rbp,%rdi
 1051de4:	xor    %esi,%esi
 1051de6:	mov    %r14,%rdx
 1051de9:	mov    %r13,%rcx
 1051dec:	call   108c860 <myl_qbe_fail_overflow_op>
 1051df1:	mov    %rbp,%rdi
 1051df4:	xor    %esi,%esi
 1051df6:	mov    0x8(%rsp),%rdx
 1051dfb:	mov    %r15,%rcx
 1051dfe:	call   108c860 <myl_qbe_fail_overflow_op>
 1051e03:	mov    %rbp,%rdi
 1051e06:	xor    %esi,%esi
 1051e08:	mov    0x8(%rsp),%rdx
 1051e0d:	mov    %rbx,%rcx
 1051e10:	call   108c860 <myl_qbe_fail_overflow_op>
 1051e15:	mov    %rbp,%rdi
 1051e18:	mov    %rcx,%rsi
 1051e1b:	call   108c8c0 <myl_qbe_fail_cast>
 1051e20:	mov    %rbp,%rdi
 1051e23:	mov    %rax,%rsi
 1051e26:	call   108c810 <myl_qbe_fail_division>
 1051e2b:	mov    %rbp,%rdi
 1051e2e:	mov    %rcx,%rdx
 1051e31:	call   108c750 <myl_qbe_fail_normalized_index_bounds>
 1051e36:	mov    %rbp,%rdi
 1051e39:	xor    %esi,%esi
 1051e3b:	mov    %r15,%rdx
 1051e3e:	mov    %r12,%rcx
 1051e41:	call   108c860 <myl_qbe_fail_overflow_op>
 1051e46:	mov    %rbp,%rdi
 1051e49:	xor    %esi,%esi
 1051e4b:	mov    0x8(%rsp),%rdx
 1051e50:	mov    %rbx,%rcx
 1051e53:	call   108c860 <myl_qbe_fail_overflow_op>
 1051e58:	mov    %rbp,%rdi
 1051e5b:	mov    %rcx,%rsi
 1051e5e:	call   108c8c0 <myl_qbe_fail_cast>
 1051e63:	mov    %rbp,%rdi
 1051e66:	mov    %rax,%rsi
 1051e69:	call   108c810 <myl_qbe_fail_division>
 1051e6e:	mov    %rbp,%rdi
 1051e71:	call   108c510 <myl_qbe_fail_allocation>
 1051e76:	mov    %rbp,%rdi
 1051e79:	mov    %rcx,%rdx
 1051e7c:	call   108c750 <myl_qbe_fail_normalized_index_bounds>
 1051e81:	mov    %rbp,%rdi
 1051e84:	xor    %esi,%esi
 1051e86:	mov    0x8(%rsp),%rdx
 1051e8b:	mov    %rbx,%rcx
 1051e8e:	call   108c860 <myl_qbe_fail_overflow_op>
 1051e93:	mov    %rbp,%rdi
 1051e96:	call   108c750 <myl_qbe_fail_normalized_index_bounds>
 1051e9b:	mov    %r15,%rdx
 1051e9e:	mov    %rbp,%rdi
 1051ea1:	xor    %esi,%esi
 1051ea3:	mov    %rax,%rcx
 1051ea6:	call   108c860 <myl_qbe_fail_overflow_op>
 1051eab:	mov    %rbp,%rdi
 1051eae:	xor    %esi,%esi
 1051eb0:	mov    0x8(%rsp),%rdx
 1051eb5:	mov    %rbx,%rcx
 1051eb8:	call   108c860 <myl_qbe_fail_overflow_op>
 1051ebd:	mov    %rbp,%rdi
 1051ec0:	xor    %esi,%esi
 1051ec2:	xor    %edx,%edx
 1051ec4:	call   108c750 <myl_qbe_fail_normalized_index_bounds>
 1051ec9:	mov    %r15,%rdx
 1051ecc:	mov    %rbp,%rdi
 1051ecf:	xor    %esi,%esi
 1051ed1:	mov    %rax,%rcx
 1051ed4:	call   108c860 <myl_qbe_fail_overflow_op>
 1051ed9:	mov    %rbp,%rdi
 1051edc:	xor    %esi,%esi
 1051ede:	mov    0x8(%rsp),%rdx
 1051ee3:	mov    %rbx,%rcx
 1051ee6:	call   108c860 <myl_qbe_fail_overflow_op>
 1051eeb:	mov    %rbp,%rdi
 1051eee:	xor    %esi,%esi
 1051ef0:	xor    %edx,%edx
 1051ef2:	call   108c750 <myl_qbe_fail_normalized_index_bounds>
 1051ef7:	mov    %r12,%rdx
 1051efa:	mov    %rbp,%rdi
 1051efd:	xor    %esi,%esi
 1051eff:	mov    %rax,%rcx
 1051f02:	call   108c860 <myl_qbe_fail_overflow_op>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
