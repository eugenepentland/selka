
/home/epentland/ai/canopy/mylang-worktrees/goal110-text-combined-20261004/.mylang-cache/goal110-text-combined/runner/bin/text-my-llvm:     file format elf64-x86-64


Disassembly of section .text:

0000000001090ef0 <index_walk>:
 1090ef0:	push   %rbp
 1090ef1:	mov    %rsp,%rbp
 1090ef4:	push   %r15
 1090ef6:	push   %r14
 1090ef8:	push   %rbx
 1090ef9:	push   %rax
 1090efa:	mov    0x8(%rdi),%rdx
 1090efe:	mov    %rdx,%rax
 1090f01:	sub    %rsi,%rax
 1090f04:	jbe    1090f6a <index_walk+0x7a>
 1090f06:	mov    0x10(%rdi),%r9d
 1090f0a:	lea    0x18(%rdi),%r8
 1090f0e:	mov    %r8,%rcx
 1090f11:	test   $0x4,%r9b
 1090f15:	je     1090f26 <index_walk+0x36>
 1090f17:	mov    0x18(%rdi),%rcx
 1090f1b:	mov    0x14(%rdi),%r10d
 1090f1f:	add    %r10,%rcx
 1090f22:	add    $0x18,%rcx
 1090f26:	cmp    %rax,%rsi
 1090f29:	mov    %rax,%r10
 1090f2c:	cmovb  %rsi,%r10
 1090f30:	cmp    $0x401,%r10
 1090f37:	jb     1090f57 <index_walk+0x67>
 1090f39:	test   $0x8,%r9b
 1090f3d:	jne    1090f85 <index_walk+0x95>
 1090f3f:	test   $0x4,%r9b
 1090f43:	je     1090f57 <index_walk+0x67>
 1090f45:	mov    (%r8),%rbx
 1090f48:	test   %rbx,%rbx
 1090f4b:	je     1090f57 <index_walk+0x67>
 1090f4d:	testb  $0x8,0x10(%rbx)
 1090f51:	jne    1091527 <index_walk+0x637>
 1090f57:	cmp    %rax,%rsi
 1090f5a:	jbe    1090f72 <index_walk+0x82>
 1090f5c:	lea    0x8(%rsi),%rax
 1090f60:	cmp    %rdx,%rax
 1090f63:	jbe    1090f94 <index_walk+0xa4>
 1090f65:	xor    %r8d,%r8d
 1090f68:	jmp    1090fe6 <index_walk+0xf6>
 1090f6a:	mov    (%rdi),%rax
 1090f6d:	jmp    1091550 <index_walk+0x660>
 1090f72:	cmp    $0x8,%rsi
 1090f76:	jae    1091011 <index_walk+0x121>
 1090f7c:	xor    %eax,%eax
 1090f7e:	xor    %edx,%edx
 1090f80:	jmp    1091239 <index_walk+0x349>
 1090f85:	add    $0x8,%rsp
 1090f89:	pop    %rbx
 1090f8a:	pop    %r14
 1090f8c:	pop    %r15
 1090f8e:	pop    %rbp
 1090f8f:	jmp    1091570 <index_at>
 1090f94:	movabs $0x101010101010101,%rax
 1090f9e:	xor    %r8d,%r8d
 1090fa1:	mov    %rsi,%r9
 1090fa4:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 1090fb0:	mov    (%rcx,%r9,1),%rsi
 1090fb4:	mov    %rsi,%r10
 1090fb7:	not    %r10
 1090fba:	add    %r10,%r10
 1090fbd:	and    %rsi,%r10
 1090fc0:	shr    $0x7,%r10
 1090fc4:	and    %rax,%r10
 1090fc7:	imul   %rax,%r10
 1090fcb:	shr    $0x38,%r10
 1090fcf:	sub    %r10,%r8
 1090fd2:	add    $0x8,%r8
 1090fd6:	lea    0x8(%r9),%rsi
 1090fda:	add    $0x10,%r9
 1090fde:	cmp    %rdx,%r9
 1090fe1:	mov    %rsi,%r9
 1090fe4:	jbe    1090fb0 <index_walk+0xc0>
 1090fe6:	mov    (%rdi),%rax
 1090fe9:	mov    %rdx,%rdi
 1090fec:	sub    %rsi,%rdi
 1090fef:	jbe    10913b5 <index_walk+0x4c5>
 1090ff5:	cmp    $0x3,%rdi
 1090ff9:	jbe    10913a0 <index_walk+0x4b0>
 1090fff:	cmp    $0x10,%rdi
 1091003:	jae    1091261 <index_walk+0x371>
 1091009:	xor    %r9d,%r9d
 109100c:	jmp    109133f <index_walk+0x44f>
 1091011:	lea    -0x8(%rsi),%r8
 1091015:	cmp    $0x78,%r8
 1091019:	jae    1091029 <index_walk+0x139>
 109101b:	mov    $0x8,%edi
 1091020:	xor    %edx,%edx
 1091022:	xor    %eax,%eax
 1091024:	jmp    10911f1 <index_walk+0x301>
 1091029:	shr    $0x3,%r8
 109102d:	inc    %r8
 1091030:	mov    %r8,%r9
 1091033:	and    $0xfffffffffffffff0,%r9
 1091037:	lea    0x0(,%r9,8),%rdx
 109103f:	lea    0x8(,%r9,8),%rdi
 1091047:	vpxor  %xmm2,%xmm2,%xmm2
 109104b:	xor    %eax,%eax
 109104d:	vpbroadcastq -0x89f16(%rip),%ymm0        # 1007140 <__abi_tag+0x6e44>
 1091056:	vpbroadcastq -0x89f17(%rip),%ymm1        # 1007148 <__abi_tag+0x6e4c>
 109105f:	vpbroadcastq -0x89f98(%rip),%ymm3        # 10070d0 <__abi_tag+0x6dd4>
 1091068:	vpcmpeqd %ymm4,%ymm4,%ymm4
 109106c:	vpxor  %xmm7,%xmm7,%xmm7
 1091070:	vpxor  %xmm6,%xmm6,%xmm6
 1091074:	vpxor  %xmm5,%xmm5,%xmm5
 1091078:	nopl   0x0(%rax,%rax,1)
 1091080:	vmovdqu (%rcx,%rax,8),%ymm8
 1091085:	vmovdqu 0x20(%rcx,%rax,8),%ymm9
 109108b:	vmovdqu 0x40(%rcx,%rax,8),%ymm10
 1091091:	vmovdqu 0x60(%rcx,%rax,8),%ymm11
 1091097:	vpxor  %ymm4,%ymm8,%ymm12
 109109b:	vpaddq %ymm12,%ymm12,%ymm12
 10910a0:	vpxor  %ymm4,%ymm9,%ymm13
 10910a4:	vpaddq %ymm13,%ymm13,%ymm13
 10910a9:	vpxor  %ymm4,%ymm10,%ymm14
 10910ad:	vpaddq %ymm14,%ymm14,%ymm14
 10910b2:	vpxor  %ymm4,%ymm11,%ymm15
 10910b6:	vpaddq %ymm15,%ymm15,%ymm15
 10910bb:	vpand  %ymm12,%ymm8,%ymm8
 10910c0:	vpand  %ymm13,%ymm9,%ymm9
 10910c5:	vpand  %ymm14,%ymm10,%ymm10
 10910ca:	vpand  %ymm15,%ymm11,%ymm11
 10910cf:	vpsrlq $0x7,%ymm8,%ymm8
 10910d5:	vpsrlq $0x7,%ymm9,%ymm9
 10910db:	vpsrlq $0x7,%ymm10,%ymm10
 10910e1:	vpsrlq $0x7,%ymm11,%ymm11
 10910e7:	vpand  %ymm0,%ymm8,%ymm8
 10910eb:	vpand  %ymm0,%ymm9,%ymm9
 10910ef:	vpand  %ymm0,%ymm10,%ymm10
 10910f3:	vpand  %ymm0,%ymm11,%ymm11
 10910f7:	vpmuludq %ymm1,%ymm8,%ymm12
 10910fb:	vpsrlq $0x20,%ymm8,%ymm13
 1091101:	vpmuludq %ymm0,%ymm13,%ymm13
 1091105:	vpaddq %ymm13,%ymm12,%ymm12
 109110a:	vpsllq $0x20,%ymm12,%ymm12
 1091110:	vpmuludq %ymm0,%ymm8,%ymm8
 1091114:	vpaddq %ymm12,%ymm8,%ymm8
 1091119:	vpmuludq %ymm1,%ymm9,%ymm12
 109111d:	vpsrlq $0x20,%ymm9,%ymm13
 1091123:	vpmuludq %ymm0,%ymm13,%ymm13
 1091127:	vpaddq %ymm13,%ymm12,%ymm12
 109112c:	vpsllq $0x20,%ymm12,%ymm12
 1091132:	vpmuludq %ymm0,%ymm9,%ymm9
 1091136:	vpaddq %ymm12,%ymm9,%ymm9
 109113b:	vpmuludq %ymm1,%ymm10,%ymm12
 109113f:	vpsrlq $0x20,%ymm10,%ymm13
 1091145:	vpmuludq %ymm0,%ymm13,%ymm13
 1091149:	vpaddq %ymm13,%ymm12,%ymm12
 109114e:	vpsllq $0x20,%ymm12,%ymm12
 1091154:	vpmuludq %ymm0,%ymm10,%ymm10
 1091158:	vpaddq %ymm12,%ymm10,%ymm10
 109115d:	vpmuludq %ymm1,%ymm11,%ymm12
 1091161:	vpsrlq $0x20,%ymm11,%ymm13
 1091167:	vpmuludq %ymm0,%ymm13,%ymm13
 109116b:	vpaddq %ymm13,%ymm12,%ymm12
 1091170:	vpsllq $0x20,%ymm12,%ymm12
 1091176:	vpmuludq %ymm0,%ymm11,%ymm11
 109117a:	vpaddq %ymm12,%ymm11,%ymm11
 109117f:	vpsrlq $0x38,%ymm8,%ymm8
 1091185:	vpsubq %ymm8,%ymm2,%ymm2
 109118a:	vpsrlq $0x38,%ymm9,%ymm8
 1091190:	vpsubq %ymm8,%ymm7,%ymm7
 1091195:	vpsrlq $0x38,%ymm10,%ymm8
 109119b:	vpsubq %ymm8,%ymm6,%ymm6
 10911a0:	vpsrlq $0x38,%ymm11,%ymm8
 10911a6:	vpsubq %ymm8,%ymm5,%ymm5
 10911ab:	vpaddq %ymm3,%ymm2,%ymm2
 10911af:	vpaddq %ymm3,%ymm7,%ymm7
 10911b3:	vpaddq %ymm3,%ymm6,%ymm6
 10911b7:	vpaddq %ymm3,%ymm5,%ymm5
 10911bb:	add    $0x10,%rax
 10911bf:	cmp    %rax,%r9
 10911c2:	jne    1091080 <index_walk+0x190>
 10911c8:	vpaddq %ymm2,%ymm7,%ymm0
 10911cc:	vpaddq %ymm0,%ymm6,%ymm0
 10911d0:	vpaddq %ymm0,%ymm5,%ymm0
 10911d4:	vextracti128 $0x1,%ymm0,%xmm1
 10911da:	vpaddq %xmm1,%xmm0,%xmm0
 10911de:	vpshufd $0xee,%xmm0,%xmm1
 10911e3:	vpaddq %xmm1,%xmm0,%xmm0
 10911e7:	vmovq  %xmm0,%rax
 10911ec:	cmp    %r9,%r8
 10911ef:	je     1091239 <index_walk+0x349>
 10911f1:	movabs $0x101010101010101,%r8
 10911fb:	nopl   0x0(%rax,%rax,1)
 1091200:	mov    (%rcx,%rdx,1),%r9
 1091204:	mov    %rdi,%rdx
 1091207:	mov    %r9,%rdi
 109120a:	not    %rdi
 109120d:	add    %rdi,%rdi
 1091210:	and    %r9,%rdi
 1091213:	shr    $0x7,%rdi
 1091217:	and    %r8,%rdi
 109121a:	imul   %r8,%rdi
 109121e:	shr    $0x38,%rdi
 1091222:	sub    %rdi,%rax
 1091225:	add    $0x8,%rax
 1091229:	lea    0x8(%rdx),%rdi
 109122d:	cmp    %rsi,%rdi
 1091230:	jbe    1091200 <index_walk+0x310>
 1091232:	add    $0xfffffffffffffff8,%rdi
 1091236:	mov    %rdi,%rdx
 1091239:	mov    %rsi,%rdi
 109123c:	sub    %rdx,%rdi
 109123f:	jbe    1091550 <index_walk+0x660>
 1091245:	cmp    $0x3,%rdi
 1091249:	jbe    1091510 <index_walk+0x620>
 109124f:	cmp    $0x10,%rdi
 1091253:	jae    10913bd <index_walk+0x4cd>
 1091259:	xor    %r8d,%r8d
 109125c:	jmp    109149f <index_walk+0x5af>
 1091261:	mov    %rdi,%r9
 1091264:	and    $0xfffffffffffffff0,%r9
 1091268:	vmovq  %r8,%xmm0
 109126d:	lea    (%rsi,%rcx,1),%r8
 1091271:	add    $0xc,%r8
 1091275:	vpxor  %xmm1,%xmm1,%xmm1
 1091279:	xor    %r10d,%r10d
 109127c:	vmovdqa -0x8f854(%rip),%xmm2        # 1001a30 <__abi_tag+0x1734>
 1091284:	vpbroadcastq -0x8a175(%rip),%ymm3        # 1007118 <__abi_tag+0x6e1c>
 109128d:	vpxor  %xmm4,%xmm4,%xmm4
 1091291:	vpxor  %xmm5,%xmm5,%xmm5
 1091295:	data16 cs nopw 0x0(%rax,%rax,1)
 10912a0:	vmovd  -0xc(%r8,%r10,1),%xmm6
 10912a7:	vmovd  -0x8(%r8,%r10,1),%xmm7
 10912ae:	vmovd  -0x4(%r8,%r10,1),%xmm8
 10912b5:	vmovd  (%r8,%r10,1),%xmm9
 10912bb:	vpcmpgtb %xmm2,%xmm6,%xmm6
 10912bf:	vpmovzxbq %xmm6,%ymm6
 10912c4:	vpand  %ymm3,%ymm6,%ymm6
 10912c8:	vpaddq %ymm6,%ymm0,%ymm0
 10912cc:	vpcmpgtb %xmm2,%xmm7,%xmm6
 10912d0:	vpmovzxbq %xmm6,%ymm6
 10912d5:	vpand  %ymm3,%ymm6,%ymm6
 10912d9:	vpaddq %ymm6,%ymm1,%ymm1
 10912dd:	vpcmpgtb %xmm2,%xmm8,%xmm6
 10912e1:	vpmovzxbq %xmm6,%ymm6
 10912e6:	vpand  %ymm3,%ymm6,%ymm6
 10912ea:	vpaddq %ymm6,%ymm4,%ymm4
 10912ee:	vpcmpgtb %xmm2,%xmm9,%xmm6
 10912f2:	vpmovzxbq %xmm6,%ymm6
 10912f7:	vpand  %ymm3,%ymm6,%ymm6
 10912fb:	vpaddq %ymm6,%ymm5,%ymm5
 10912ff:	add    $0x10,%r10
 1091303:	cmp    %r10,%r9
 1091306:	jne    10912a0 <index_walk+0x3b0>
 1091308:	vpaddq %ymm0,%ymm1,%ymm0
 109130c:	vpaddq %ymm0,%ymm4,%ymm0
 1091310:	vpaddq %ymm0,%ymm5,%ymm0
 1091314:	vextracti128 $0x1,%ymm0,%xmm1
 109131a:	vpaddq %xmm1,%xmm0,%xmm0
 109131e:	vpshufd $0xee,%xmm0,%xmm1
 1091323:	vpaddq %xmm1,%xmm0,%xmm0
 1091327:	vmovq  %xmm0,%r8
 109132c:	cmp    %r9,%rdi
 109132f:	je     10913b5 <index_walk+0x4c5>
 1091335:	test   $0xc,%dil
 1091339:	je     109155e <index_walk+0x66e>
 109133f:	mov    %rdi,%r10
 1091342:	and    $0xfffffffffffffffc,%r10
 1091346:	vmovq  %r8,%xmm0
 109134b:	lea    (%rcx,%rsi,1),%r8
 109134f:	vmovdqa -0x8f927(%rip),%xmm1        # 1001a30 <__abi_tag+0x1734>
 1091357:	vpbroadcastq -0x8a248(%rip),%ymm2        # 1007118 <__abi_tag+0x6e1c>
 1091360:	vmovd  (%r8,%r9,1),%xmm3
 1091366:	vpcmpgtb %xmm1,%xmm3,%xmm3
 109136a:	vpmovzxbq %xmm3,%ymm3
 109136f:	vpand  %ymm2,%ymm3,%ymm3
 1091373:	vpaddq %ymm3,%ymm0,%ymm0
 1091377:	add    $0x4,%r9
 109137b:	cmp    %r9,%r10
 109137e:	jne    1091360 <index_walk+0x470>
 1091380:	vextracti128 $0x1,%ymm0,%xmm1
 1091386:	vpaddq %xmm1,%xmm0,%xmm0
 109138a:	vpshufd $0xee,%xmm0,%xmm1
 109138f:	vpaddq %xmm1,%xmm0,%xmm0
 1091393:	vmovq  %xmm0,%r8
 1091398:	cmp    %r10,%rdi
 109139b:	je     10913b5 <index_walk+0x4c5>
 109139d:	add    %r10,%rsi
 10913a0:	xor    %edi,%edi
 10913a2:	cmpb   $0xc0,(%rcx,%rsi,1)
 10913a6:	setge  %dil
 10913aa:	add    %rdi,%r8
 10913ad:	inc    %rsi
 10913b0:	cmp    %rsi,%rdx
 10913b3:	jne    10913a0 <index_walk+0x4b0>
 10913b5:	sub    %r8,%rax
 10913b8:	jmp    1091550 <index_walk+0x660>
 10913bd:	mov    %rdi,%r8
 10913c0:	and    $0xfffffffffffffff0,%r8
 10913c4:	vmovq  %rax,%xmm0
 10913c9:	lea    (%rdx,%rcx,1),%rax
 10913cd:	add    $0xc,%rax
 10913d1:	vpxor  %xmm1,%xmm1,%xmm1
 10913d5:	xor    %r9d,%r9d
 10913d8:	vmovdqa -0x8f9b0(%rip),%xmm2        # 1001a30 <__abi_tag+0x1734>
 10913e0:	vpbroadcastq -0x8a2d1(%rip),%ymm3        # 1007118 <__abi_tag+0x6e1c>
 10913e9:	vpxor  %xmm4,%xmm4,%xmm4
 10913ed:	vpxor  %xmm5,%xmm5,%xmm5
 10913f1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1091400:	vmovd  -0xc(%rax,%r9,1),%xmm6
 1091407:	vmovd  -0x8(%rax,%r9,1),%xmm7
 109140e:	vmovd  -0x4(%rax,%r9,1),%xmm8
 1091415:	vmovd  (%rax,%r9,1),%xmm9
 109141b:	vpcmpgtb %xmm2,%xmm6,%xmm6
 109141f:	vpmovzxbq %xmm6,%ymm6
 1091424:	vpand  %ymm3,%ymm6,%ymm6
 1091428:	vpaddq %ymm6,%ymm0,%ymm0
 109142c:	vpcmpgtb %xmm2,%xmm7,%xmm6
 1091430:	vpmovzxbq %xmm6,%ymm6
 1091435:	vpand  %ymm3,%ymm6,%ymm6
 1091439:	vpaddq %ymm6,%ymm1,%ymm1
 109143d:	vpcmpgtb %xmm2,%xmm8,%xmm6
 1091441:	vpmovzxbq %xmm6,%ymm6
 1091446:	vpand  %ymm3,%ymm6,%ymm6
 109144a:	vpaddq %ymm6,%ymm4,%ymm4
 109144e:	vpcmpgtb %xmm2,%xmm9,%xmm6
 1091452:	vpmovzxbq %xmm6,%ymm6
 1091457:	vpand  %ymm3,%ymm6,%ymm6
 109145b:	vpaddq %ymm6,%ymm5,%ymm5
 109145f:	add    $0x10,%r9
 1091463:	cmp    %r9,%r8
 1091466:	jne    1091400 <index_walk+0x510>
 1091468:	vpaddq %ymm0,%ymm1,%ymm0
 109146c:	vpaddq %ymm0,%ymm4,%ymm0
 1091470:	vpaddq %ymm0,%ymm5,%ymm0
 1091474:	vextracti128 $0x1,%ymm0,%xmm1
 109147a:	vpaddq %xmm1,%xmm0,%xmm0
 109147e:	vpshufd $0xee,%xmm0,%xmm1
 1091483:	vpaddq %xmm1,%xmm0,%xmm0
 1091487:	vmovq  %xmm0,%rax
 109148c:	cmp    %r8,%rdi
 109148f:	je     1091550 <index_walk+0x660>
 1091495:	test   $0xc,%dil
 1091499:	je     1091566 <index_walk+0x676>
 109149f:	mov    %esi,%r9d
 10914a2:	and    $0x3,%r9d
 10914a6:	sub    %r9,%rdi
 10914a9:	vmovq  %rax,%xmm0
 10914ae:	mov    %rsi,%rax
 10914b1:	and    $0xfffffffffffffffc,%rax
 10914b5:	add    %rdx,%r8
 10914b8:	vmovdqa -0x8fa90(%rip),%xmm1        # 1001a30 <__abi_tag+0x1734>
 10914c0:	vpbroadcastq -0x8a3b1(%rip),%ymm2        # 1007118 <__abi_tag+0x6e1c>
 10914c9:	nopl   0x0(%rax)
 10914d0:	vmovd  (%rcx,%r8,1),%xmm3
 10914d6:	vpcmpgtb %xmm1,%xmm3,%xmm3
 10914da:	vpmovzxbq %xmm3,%ymm3
 10914df:	vpand  %ymm2,%ymm3,%ymm3
 10914e3:	vpaddq %ymm3,%ymm0,%ymm0
 10914e7:	add    $0x4,%r8
 10914eb:	cmp    %r8,%rax
 10914ee:	jne    10914d0 <index_walk+0x5e0>
 10914f0:	vextracti128 $0x1,%ymm0,%xmm1
 10914f6:	vpaddq %xmm1,%xmm0,%xmm0
 10914fa:	vpshufd $0xee,%xmm0,%xmm1
 10914ff:	vpaddq %xmm1,%xmm0,%xmm0
 1091503:	vmovq  %xmm0,%rax
 1091508:	test   %r9,%r9
 109150b:	je     1091550 <index_walk+0x660>
 109150d:	add    %rdi,%rdx
 1091510:	xor    %edi,%edi
 1091512:	cmpb   $0xc0,(%rcx,%rdx,1)
 1091516:	setge  %dil
 109151a:	add    %rdi,%rax
 109151d:	inc    %rdx
 1091520:	cmp    %rdx,%rsi
 1091523:	jne    1091510 <index_walk+0x620>
 1091525:	jmp    1091550 <index_walk+0x660>
 1091527:	mov    0x14(%rdi),%eax
 109152a:	add    %rax,%rsi
 109152d:	mov    %rdi,%r15
 1091530:	mov    %rbx,%rdi
 1091533:	call   1091570 <index_at>
 1091538:	mov    %rax,%r14
 109153b:	mov    0x14(%r15),%esi
 109153f:	mov    %rbx,%rdi
 1091542:	call   1091570 <index_at>
 1091547:	mov    %rax,%rcx
 109154a:	mov    %r14,%rax
 109154d:	sub    %rcx,%rax
 1091550:	add    $0x8,%rsp
 1091554:	pop    %rbx
 1091555:	pop    %r14
 1091557:	pop    %r15
 1091559:	pop    %rbp
 109155a:	vzeroupper
 109155d:	ret
 109155e:	add    %r9,%rsi
 1091561:	jmp    10913a0 <index_walk+0x4b0>
 1091566:	add    %r8,%rdx
 1091569:	jmp    1091510 <index_walk+0x620>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
