
.mylang-cache/goal110-join-short/runner/bin/text-my-llvm:     file format elf64-x86-64


Disassembly of section .text:

0000000001093810 <myl_native_text_join>:
 1093810:	push   %rbp
 1093811:	mov    %rsp,%rbp
 1093814:	push   %r15
 1093816:	push   %r14
 1093818:	push   %r13
 109381a:	push   %r12
 109381c:	push   %rbx
 109381d:	sub    $0x98,%rsp
 1093824:	mov    %rsi,-0x70(%rbp)
 1093828:	mov    %rdx,-0xb8(%rbp)
 109382f:	mov    (%rdx),%r8
 1093832:	mov    0x20(%rdx),%r10
 1093836:	mov    0x8(%rsi),%r9
 109383a:	mov    0x10(%rsi),%r13d
 109383e:	and    $0x1,%r13d
 1093842:	xor    %r14d,%r14d
 1093845:	cmp    $0x11,%r9
 1093849:	setb   %r14b
 109384d:	cmp    $0x2,%r8
 1093851:	jb     109386b <myl_native_text_join+0x5b>
 1093853:	lea    -0x1(%r8),%rcx
 1093857:	test   %r9,%r9
 109385a:	je     1093876 <myl_native_text_join+0x66>
 109385c:	mov    %r9,%rax
 109385f:	mul    %rcx
 1093862:	jno    1093876 <myl_native_text_join+0x66>
 1093864:	xor    %eax,%eax
 1093866:	jmp    1093b79 <myl_native_text_join+0x369>
 109386b:	xor    %ebx,%ebx
 109386d:	test   %r8,%r8
 1093870:	je     10938bd <myl_native_text_join+0xad>
 1093872:	xor    %ecx,%ecx
 1093874:	jmp    1093881 <myl_native_text_join+0x71>
 1093876:	mov    %rcx,%rbx
 1093879:	imul   %r9,%rbx
 109387d:	imul   (%rsi),%rcx
 1093881:	xor    %eax,%eax
 1093883:	mov    %rbx,%r12
 1093886:	mov    %rcx,%rbx
 1093889:	xor    %ecx,%ecx
 109388b:	nopl   0x0(%rax,%rax,1)
 1093890:	mov    (%r10,%rcx,8),%rsi
 1093894:	mov    0x8(%rsi),%rdx
 1093898:	add    %rdx,%r12
 109389b:	jb     1093b79 <myl_native_text_join+0x369>
 10938a1:	add    (%rsi),%rbx
 10938a4:	and    0x10(%rsi),%r13d
 10938a8:	xor    %r15d,%r15d
 10938ab:	cmp    $0x11,%rdx
 10938af:	cmovae %r15d,%r14d
 10938b3:	inc    %rcx
 10938b6:	cmp    %rcx,%r8
 10938b9:	jne    1093890 <myl_native_text_join+0x80>
 10938bb:	jmp    10938c3 <myl_native_text_join+0xb3>
 10938bd:	mov    $0x1,%r15b
 10938c0:	xor    %r12d,%r12d
 10938c3:	mov    0x10(%rdi),%rax
 10938c7:	mov    %rax,-0xb0(%rbp)
 10938ce:	lea    -0x70(%rbp),%rax
 10938d2:	mov    %rax,-0xa8(%rbp)
 10938d9:	movq   $0x1031628,-0xa0(%rbp)
 10938e4:	lea    -0xb0(%rbp),%rdx
 10938eb:	mov    %rdx,-0x90(%rbp)
 10938f2:	lea    -0xb8(%rbp),%rax
 10938f9:	mov    %rax,-0x88(%rbp)
 1093900:	movq   $0x1031628,-0x80(%rbp)
 1093908:	lea    -0x90(%rbp),%rsi
 109390f:	mov    %rsi,0x10(%rdi)
 1093913:	cmp    %r12,%rbx
 1093916:	jne    1093925 <myl_native_text_join+0x115>
 1093918:	cmp    $0xffffffffffffffe7,%r12
 109391c:	jbe    109399c <myl_native_text_join+0x18c>
 109391e:	xor    %eax,%eax
 1093920:	jmp    1093b6b <myl_native_text_join+0x35b>
 1093925:	cmp    $0x100,%r12
 109392c:	jb     109399c <myl_native_text_join+0x18c>
 109392e:	mov    %r12,%rax
 1093931:	shr    $0x20,%rax
 1093935:	jne    1093918 <myl_native_text_join+0x108>
 1093937:	mov    %r10,-0x68(%rbp)
 109393b:	mov    %r9,-0x50(%rbp)
 109393f:	mov    %r8,-0x58(%rbp)
 1093943:	lea    -0x1(%rbx),%rax
 1093947:	shr    $0x7,%rax
 109394b:	lea    0x17(,%rax,4),%rax
 1093953:	and    $0xfffffffffffffff8,%rax
 1093957:	cmp    $0x1,%rbx
 109395b:	mov    $0x10,%ecx
 1093960:	cmovae %rax,%rcx
 1093964:	lea    0x7(%r12),%rax
 1093969:	movabs $0x1fffffff8,%rsi
 1093973:	and    %rax,%rsi
 1093976:	add    %rcx,%rsi
 1093979:	mov    %rdi,-0x30(%rbp)
 109397d:	call   108eaa0 <myl_native_heap_alloc_block>
 1093982:	test   %rax,%rax
 1093985:	je     1093a41 <myl_native_text_join+0x231>
 109398b:	mov    %rax,%rcx
 109398e:	mov    %rbx,(%rcx)
 1093991:	mov    $0x8,%ecx
 1093996:	mov    %rcx,-0x38(%rbp)
 109399a:	jmp    10939e9 <myl_native_text_join+0x1d9>
 109399c:	xor    %eax,%eax
 109399e:	cmp    $0xffffffffffffffe7,%r12
 10939a2:	ja     1093b6b <myl_native_text_join+0x35b>
 10939a8:	cmpq   $0x0,0x1608(%rdi)
 10939b0:	je     1093b6b <myl_native_text_join+0x35b>
 10939b6:	mov    %r10,-0x68(%rbp)
 10939ba:	mov    %r9,-0x50(%rbp)
 10939be:	mov    %r8,-0x58(%rbp)
 10939c2:	lea    0x18(%r12),%rsi
 10939c7:	mov    0x70(%rdi),%edx
 10939ca:	movq   $0x0,-0x38(%rbp)
 10939d2:	mov    %rdi,-0x30(%rbp)
 10939d6:	xor    %ecx,%ecx
 10939d8:	call   10a78b0 <raw_bytes>
 10939dd:	test   %rax,%rax
 10939e0:	je     1093a41 <myl_native_text_join+0x231>
 10939e2:	movq   $0x0,(%rax)
 10939e9:	mov    %r12,0x8(%rax)
 10939ed:	mov    -0x38(%rbp),%rcx
 10939f1:	mov    %ecx,0x10(%rax)
 10939f4:	movl   $0x0,0x14(%rax)
 10939fb:	mov    -0x70(%rbp),%r11
 10939ff:	testb  $0x4,0x10(%r11)
 1093a04:	mov    -0x58(%rbp),%r8
 1093a08:	mov    -0x50(%rbp),%r9
 1093a0c:	mov    -0x68(%rbp),%r10
 1093a10:	jne    1093a4c <myl_native_text_join+0x23c>
 1093a12:	add    $0x18,%r11
 1093a16:	lea    0x18(%rax),%rdi
 1093a1a:	test   %r14d,%r14d
 1093a1d:	mov    %rax,-0x40(%rbp)
 1093a21:	je     1093a69 <myl_native_text_join+0x259>
 1093a23:	mov    %r10,%rsi
 1093a26:	mov    %r8,%rdx
 1093a29:	mov    %r11,%rcx
 1093a2c:	mov    %r9,%r8
 1093a2f:	call   1093d60 <join_short>
 1093a34:	mov    -0x40(%rbp),%rax
 1093a38:	mov    -0x30(%rbp),%rdi
 1093a3c:	jmp    1093b4a <myl_native_text_join+0x33a>
 1093a41:	xor    %eax,%eax
 1093a43:	mov    -0x30(%rbp),%rdi
 1093a47:	jmp    1093b5d <myl_native_text_join+0x34d>
 1093a4c:	mov    0x18(%r11),%rcx
 1093a50:	mov    0x14(%r11),%edx
 1093a54:	lea    (%rcx,%rdx,1),%r11
 1093a58:	add    $0x18,%r11
 1093a5c:	lea    0x18(%rax),%rdi
 1093a60:	test   %r14d,%r14d
 1093a63:	mov    %rax,-0x40(%rbp)
 1093a67:	jne    1093a23 <myl_native_text_join+0x213>
 1093a69:	mov    %rdi,-0x38(%rbp)
 1093a6d:	test   %r15b,%r15b
 1093a70:	mov    -0x30(%rbp),%rdi
 1093a74:	jne    1093b4a <myl_native_text_join+0x33a>
 1093a7a:	mov    (%r10),%rsi
 1093a7d:	mov    0x8(%rsi),%r12
 1093a81:	test   %r12,%r12
 1093a84:	mov    %r11,-0x60(%rbp)
 1093a88:	je     1093b44 <myl_native_text_join+0x334>
 1093a8e:	testb  $0x4,0x10(%rsi)
 1093a92:	jne    1093a9a <myl_native_text_join+0x28a>
 1093a94:	add    $0x18,%rsi
 1093a98:	jmp    1093aa9 <myl_native_text_join+0x299>
 1093a9a:	mov    0x18(%rsi),%rcx
 1093a9e:	mov    0x14(%rsi),%edx
 1093aa1:	lea    (%rcx,%rdx,1),%rsi
 1093aa5:	add    $0x18,%rsi
 1093aa9:	cmp    $0x10,%r12
 1093aad:	jbe    1093ae7 <myl_native_text_join+0x2d7>
 1093aaf:	mov    %rdi,-0x30(%rbp)
 1093ab3:	mov    -0x38(%rbp),%rdi
 1093ab7:	mov    %r12,%rdx
 1093aba:	mov    %r8,%r15
 1093abd:	mov    %r12,-0x48(%rbp)
 1093ac1:	mov    %r9,%r12
 1093ac4:	mov    %r10,%r14
 1093ac7:	call   10ad320 <memcpy@plt>
 1093acc:	mov    -0x60(%rbp),%r11
 1093ad0:	mov    %r14,%r10
 1093ad3:	mov    %r12,%r9
 1093ad6:	mov    -0x48(%rbp),%r12
 1093ada:	mov    %r15,%r8
 1093add:	mov    -0x40(%rbp),%rax
 1093ae1:	mov    -0x30(%rbp),%rdi
 1093ae5:	jmp    1093b44 <myl_native_text_join+0x334>
 1093ae7:	cmp    $0x7,%r12
 1093aeb:	jbe    1093b03 <myl_native_text_join+0x2f3>
 1093aed:	mov    (%rsi),%rcx
 1093af0:	mov    -0x8(%rsi,%r12,1),%rdx
 1093af5:	lea    0x18(%rax),%rsi
 1093af9:	mov    %rcx,(%rsi)
 1093afc:	mov    %rdx,-0x8(%rsi,%r12,1)
 1093b01:	jmp    1093b44 <myl_native_text_join+0x334>
 1093b03:	cmp    $0x3,%r12
 1093b07:	jbe    1093b1d <myl_native_text_join+0x30d>
 1093b09:	mov    (%rsi),%ecx
 1093b0b:	mov    -0x4(%rsi,%r12,1),%edx
 1093b10:	lea    0x18(%rax),%rsi
 1093b14:	mov    %ecx,(%rsi)
 1093b16:	mov    %edx,-0x4(%rsi,%r12,1)
 1093b1b:	jmp    1093b44 <myl_native_text_join+0x334>
 1093b1d:	cmp    $0x1,%r12
 1093b21:	jne    1093b2e <myl_native_text_join+0x31e>
 1093b23:	movzbl (%rsi),%ecx
 1093b26:	lea    0x18(%rax),%rdx
 1093b2a:	mov    %cl,(%rdx)
 1093b2c:	jmp    1093b44 <myl_native_text_join+0x334>
 1093b2e:	movzwl (%rsi),%ecx
 1093b31:	movzwl -0x2(%rsi,%r12,1),%edx
 1093b37:	lea    0x18(%rax),%rsi
 1093b3b:	mov    %cx,(%rsi)
 1093b3e:	mov    %dx,-0x2(%rsi,%r12,1)
 1093b44:	cmp    $0x1,%r8
 1093b48:	jne    1093ba8 <myl_native_text_join+0x398>
 1093b4a:	test   %r13d,%r13d
 1093b4d:	je     1093d3e <myl_native_text_join+0x52e>
 1093b53:	mov    %rbx,(%rax)
 1093b56:	movl   $0x1,0x10(%rax)
 1093b5d:	lea    -0xb0(%rbp),%rdx
 1093b64:	lea    -0x90(%rbp),%rsi
 1093b6b:	mov    0x10(%rdi),%rcx
 1093b6f:	cmp    %rsi,%rcx
 1093b72:	je     1093b8b <myl_native_text_join+0x37b>
 1093b74:	cmp    %rdx,%rcx
 1093b77:	je     1093b9b <myl_native_text_join+0x38b>
 1093b79:	add    $0x98,%rsp
 1093b80:	pop    %rbx
 1093b81:	pop    %r12
 1093b83:	pop    %r13
 1093b85:	pop    %r14
 1093b87:	pop    %r15
 1093b89:	pop    %rbp
 1093b8a:	ret
 1093b8b:	mov    -0x90(%rbp),%rcx
 1093b92:	mov    %rcx,0x10(%rdi)
 1093b96:	cmp    %rdx,%rcx
 1093b99:	jne    1093b79 <myl_native_text_join+0x369>
 1093b9b:	mov    -0xb0(%rbp),%rcx
 1093ba2:	mov    %rcx,0x10(%rdi)
 1093ba6:	jmp    1093b79 <myl_native_text_join+0x369>
 1093ba8:	mov    $0x1,%r15d
 1093bae:	mov    %rdi,-0x30(%rbp)
 1093bb2:	mov    %r8,-0x58(%rbp)
 1093bb6:	mov    %r9,-0x50(%rbp)
 1093bba:	jmp    1093bf8 <myl_native_text_join+0x3e8>
 1093bbc:	mov    %rcx,%rdi
 1093bbf:	mov    %r14,%rdx
 1093bc2:	mov    %r12,-0x48(%rbp)
 1093bc6:	mov    %r10,%r12
 1093bc9:	call   10ad320 <memcpy@plt>
 1093bce:	mov    -0x60(%rbp),%r11
 1093bd2:	mov    %r12,%r10
 1093bd5:	mov    -0x48(%rbp),%r12
 1093bd9:	mov    -0x50(%rbp),%r9
 1093bdd:	mov    -0x58(%rbp),%r8
 1093be1:	mov    -0x40(%rbp),%rax
 1093be5:	mov    -0x30(%rbp),%rdi
 1093be9:	add    %r14,%r12
 1093bec:	inc    %r15
 1093bef:	cmp    %r15,%r8
 1093bf2:	je     1093b4a <myl_native_text_join+0x33a>
 1093bf8:	test   %r9,%r9
 1093bfb:	je     1093c95 <myl_native_text_join+0x485>
 1093c01:	mov    -0x38(%rbp),%rcx
 1093c05:	add    %r12,%rcx
 1093c08:	cmp    $0x11,%r9
 1093c0c:	jb     1093c42 <myl_native_text_join+0x432>
 1093c0e:	mov    %rcx,%rdi
 1093c11:	mov    %r11,%rsi
 1093c14:	mov    %r9,%rdx
 1093c17:	mov    %r12,-0x48(%rbp)
 1093c1b:	mov    %r8,%r12
 1093c1e:	mov    %r10,%r14
 1093c21:	call   10ad320 <memcpy@plt>
 1093c26:	mov    -0x60(%rbp),%r11
 1093c2a:	mov    %r14,%r10
 1093c2d:	mov    -0x50(%rbp),%r9
 1093c31:	mov    %r12,%r8
 1093c34:	mov    -0x48(%rbp),%r12
 1093c38:	mov    -0x40(%rbp),%rax
 1093c3c:	mov    -0x30(%rbp),%rdi
 1093c40:	jmp    1093c92 <myl_native_text_join+0x482>
 1093c42:	cmp    $0x8,%r9
 1093c46:	jb     1093c5a <myl_native_text_join+0x44a>
 1093c48:	mov    (%r11),%rdx
 1093c4b:	mov    -0x8(%r11,%r9,1),%rsi
 1093c50:	mov    %rdx,(%rcx)
 1093c53:	mov    %rsi,-0x8(%rcx,%r9,1)
 1093c58:	jmp    1093c92 <myl_native_text_join+0x482>
 1093c5a:	cmp    $0x4,%r9
 1093c5e:	jb     1093c71 <myl_native_text_join+0x461>
 1093c60:	mov    (%r11),%edx
 1093c63:	mov    -0x4(%r11,%r9,1),%esi
 1093c68:	mov    %edx,(%rcx)
 1093c6a:	mov    %esi,-0x4(%rcx,%r9,1)
 1093c6f:	jmp    1093c92 <myl_native_text_join+0x482>
 1093c71:	cmp    $0x2,%r9
 1093c75:	jb     1093c8c <myl_native_text_join+0x47c>
 1093c77:	movzwl (%r11),%edx
 1093c7b:	movzwl -0x2(%r11,%r9,1),%esi
 1093c81:	mov    %dx,(%rcx)
 1093c84:	mov    %si,-0x2(%rcx,%r9,1)
 1093c8a:	jmp    1093c92 <myl_native_text_join+0x482>
 1093c8c:	movzbl (%r11),%edx
 1093c90:	mov    %dl,(%rcx)
 1093c92:	add    %r9,%r12
 1093c95:	mov    (%r10,%r15,8),%rsi
 1093c99:	mov    0x8(%rsi),%r14
 1093c9d:	test   %r14,%r14
 1093ca0:	je     1093be9 <myl_native_text_join+0x3d9>
 1093ca6:	testb  $0x4,0x10(%rsi)
 1093caa:	jne    1093cc3 <myl_native_text_join+0x4b3>
 1093cac:	add    $0x18,%rsi
 1093cb0:	mov    -0x38(%rbp),%rcx
 1093cb4:	add    %r12,%rcx
 1093cb7:	cmp    $0x11,%r14
 1093cbb:	jae    1093bbc <myl_native_text_join+0x3ac>
 1093cc1:	jmp    1093ce3 <myl_native_text_join+0x4d3>
 1093cc3:	mov    0x18(%rsi),%rcx
 1093cc7:	mov    0x14(%rsi),%edx
 1093cca:	lea    (%rcx,%rdx,1),%rsi
 1093cce:	add    $0x18,%rsi
 1093cd2:	mov    -0x38(%rbp),%rcx
 1093cd6:	add    %r12,%rcx
 1093cd9:	cmp    $0x11,%r14
 1093cdd:	jae    1093bbc <myl_native_text_join+0x3ac>
 1093ce3:	cmp    $0x8,%r14
 1093ce7:	jb     1093cfe <myl_native_text_join+0x4ee>
 1093ce9:	mov    (%rsi),%rdx
 1093cec:	mov    -0x8(%rsi,%r14,1),%rsi
 1093cf1:	mov    %rdx,(%rcx)
 1093cf4:	mov    %rsi,-0x8(%rcx,%r14,1)
 1093cf9:	jmp    1093be9 <myl_native_text_join+0x3d9>
 1093cfe:	cmp    $0x4,%r14
 1093d02:	jb     1093d17 <myl_native_text_join+0x507>
 1093d04:	mov    (%rsi),%edx
 1093d06:	mov    -0x4(%rsi,%r14,1),%esi
 1093d0b:	mov    %edx,(%rcx)
 1093d0d:	mov    %esi,-0x4(%rcx,%r14,1)
 1093d12:	jmp    1093be9 <myl_native_text_join+0x3d9>
 1093d17:	cmp    $0x1,%r14
 1093d1b:	jne    1093d27 <myl_native_text_join+0x517>
 1093d1d:	movzbl (%rsi),%edx
 1093d20:	mov    %dl,(%rcx)
 1093d22:	jmp    1093be9 <myl_native_text_join+0x3d9>
 1093d27:	movzwl (%rsi),%edx
 1093d2a:	movzwl -0x2(%rsi,%r14,1),%esi
 1093d30:	mov    %dx,(%rcx)
 1093d33:	mov    %si,-0x2(%rcx,%r14,1)
 1093d39:	jmp    1093be9 <myl_native_text_join+0x3d9>
 1093d3e:	mov    %rdi,%r14
 1093d41:	mov    %rax,%rdi
 1093d44:	mov    %rbx,%rsi
 1093d47:	call   1090940 <publish_wide>
 1093d4c:	mov    -0x40(%rbp),%rax
 1093d50:	mov    %r14,%rdi
 1093d53:	jmp    1093b5d <myl_native_text_join+0x34d>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
