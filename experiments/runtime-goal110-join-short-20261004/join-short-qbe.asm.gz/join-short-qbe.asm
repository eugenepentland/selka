
.mylang-cache/goal110-join-short/runner/bin/text-my-qbe:     file format elf64-x86-64


Disassembly of section .text:

00000000010c9140 <join_short>:
 10c9140:	test   %rdx,%rdx
 10c9143:	je     10c96da <join_short+0x59a>
 10c9149:	push   %rbp
 10c914a:	mov    %rsp,%rbp
 10c914d:	push   %rbx
 10c914e:	cmp    $0x8,%r8
 10c9152:	jb     10c91a4 <join_short+0x64>
 10c9154:	mov    (%rcx),%rax
 10c9157:	mov    -0x8(%rcx,%r8,1),%rcx
 10c915c:	mov    (%rsi),%r10
 10c915f:	mov    0x8(%r10),%r9
 10c9163:	test   %r9,%r9
 10c9166:	je     10c927d <join_short+0x13d>
 10c916c:	testb  $0x4,0x10(%r10)
 10c9171:	jne    10c9254 <join_short+0x114>
 10c9177:	add    $0x18,%r10
 10c917b:	cmp    $0x7,%r9
 10c917f:	ja     10c926d <join_short+0x12d>
 10c9185:	cmp    $0x3,%r9
 10c9189:	jbe    10c9373 <join_short+0x233>
 10c918f:	mov    (%r10),%r11d
 10c9192:	mov    -0x4(%r10,%r9,1),%r10d
 10c9197:	mov    %r11d,(%rdi)
 10c919a:	mov    %r10d,-0x4(%rdi,%r9,1)
 10c919f:	jmp    10c927d <join_short+0x13d>
 10c91a4:	cmp    $0x4,%r8
 10c91a8:	jb     10c91f9 <join_short+0xb9>
 10c91aa:	mov    (%rcx),%eax
 10c91ac:	mov    -0x4(%rcx,%r8,1),%ecx
 10c91b1:	mov    (%rsi),%r10
 10c91b4:	mov    0x8(%r10),%r9
 10c91b8:	test   %r9,%r9
 10c91bb:	je     10c93b2 <join_short+0x272>
 10c91c1:	testb  $0x4,0x10(%r10)
 10c91c6:	jne    10c9389 <join_short+0x249>
 10c91cc:	add    $0x18,%r10
 10c91d0:	cmp    $0x7,%r9
 10c91d4:	ja     10c93a2 <join_short+0x262>
 10c91da:	cmp    $0x3,%r9
 10c91de:	jbe    10c9515 <join_short+0x3d5>
 10c91e4:	mov    (%r10),%r11d
 10c91e7:	mov    -0x4(%r10,%r9,1),%r10d
 10c91ec:	mov    %r11d,(%rdi)
 10c91ef:	mov    %r10d,-0x4(%rdi,%r9,1)
 10c91f4:	jmp    10c93b2 <join_short+0x272>
 10c91f9:	cmp    $0x2,%r8
 10c91fd:	jb     10c9343 <join_short+0x203>
 10c9203:	movzwl (%rcx),%eax
 10c9206:	movzwl -0x2(%rcx,%r8,1),%ecx
 10c920c:	mov    (%rsi),%r10
 10c920f:	mov    0x8(%r10),%r9
 10c9213:	test   %r9,%r9
 10c9216:	je     10c9554 <join_short+0x414>
 10c921c:	testb  $0x4,0x10(%r10)
 10c9221:	jne    10c952b <join_short+0x3eb>
 10c9227:	add    $0x18,%r10
 10c922b:	cmp    $0x7,%r9
 10c922f:	ja     10c9544 <join_short+0x404>
 10c9235:	cmp    $0x3,%r9
 10c9239:	jbe    10c966b <join_short+0x52b>
 10c923f:	mov    (%r10),%r11d
 10c9242:	mov    -0x4(%r10,%r9,1),%r10d
 10c9247:	mov    %r11d,(%rdi)
 10c924a:	mov    %r10d,-0x4(%rdi,%r9,1)
 10c924f:	jmp    10c9554 <join_short+0x414>
 10c9254:	mov    0x18(%r10),%r11
 10c9258:	mov    0x14(%r10),%r10d
 10c925c:	add    %r11,%r10
 10c925f:	add    $0x18,%r10
 10c9263:	cmp    $0x7,%r9
 10c9267:	jbe    10c9185 <join_short+0x45>
 10c926d:	mov    (%r10),%r11
 10c9270:	mov    -0x8(%r10,%r9,1),%r10
 10c9275:	mov    %r11,(%rdi)
 10c9278:	mov    %r10,-0x8(%rdi,%r9,1)
 10c927d:	cmp    $0x1,%rdx
 10c9281:	je     10c96d8 <join_short+0x598>
 10c9287:	add    %r9,%rdi
 10c928a:	mov    $0x1,%r9d
 10c9290:	jmp    10c92bf <join_short+0x17f>
 10c9292:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 10c92a0:	mov    (%r11),%rbx
 10c92a3:	mov    -0x8(%r11,%r10,1),%r11
 10c92a8:	mov    %rbx,(%rdi)
 10c92ab:	mov    %r11,-0x8(%rdi,%r10,1)
 10c92b0:	add    %r10,%rdi
 10c92b3:	inc    %r9
 10c92b6:	cmp    %r9,%rdx
 10c92b9:	je     10c96d8 <join_short+0x598>
 10c92bf:	mov    %rax,(%rdi)
 10c92c2:	mov    %rcx,-0x8(%rdi,%r8,1)
 10c92c7:	add    %r8,%rdi
 10c92ca:	mov    (%rsi,%r9,8),%r11
 10c92ce:	mov    0x8(%r11),%r10
 10c92d2:	test   %r10,%r10
 10c92d5:	je     10c92b0 <join_short+0x170>
 10c92d7:	testb  $0x4,0x10(%r11)
 10c92dc:	jne    10c92f0 <join_short+0x1b0>
 10c92de:	add    $0x18,%r11
 10c92e2:	cmp    $0x8,%r10
 10c92e6:	jae    10c92a0 <join_short+0x160>
 10c92e8:	jmp    10c9305 <join_short+0x1c5>
 10c92ea:	nopw   0x0(%rax,%rax,1)
 10c92f0:	mov    0x18(%r11),%rbx
 10c92f4:	mov    0x14(%r11),%r11d
 10c92f8:	add    %rbx,%r11
 10c92fb:	add    $0x18,%r11
 10c92ff:	cmp    $0x8,%r10
 10c9303:	jae    10c92a0 <join_short+0x160>
 10c9305:	cmp    $0x4,%r10
 10c9309:	jb     10c931c <join_short+0x1dc>
 10c930b:	mov    (%r11),%ebx
 10c930e:	mov    -0x4(%r11,%r10,1),%r11d
 10c9313:	mov    %ebx,(%rdi)
 10c9315:	mov    %r11d,-0x4(%rdi,%r10,1)
 10c931a:	jmp    10c92b0 <join_short+0x170>
 10c931c:	cmp    $0x1,%r10
 10c9320:	jne    10c932b <join_short+0x1eb>
 10c9322:	movzbl (%r11),%r11d
 10c9326:	mov    %r11b,(%rdi)
 10c9329:	jmp    10c92b0 <join_short+0x170>
 10c932b:	movzwl (%r11),%ebx
 10c932f:	movzwl -0x2(%r11,%r10,1),%r11d
 10c9335:	mov    %bx,(%rdi)
 10c9338:	mov    %r11w,-0x2(%rdi,%r10,1)
 10c933e:	jmp    10c92b0 <join_short+0x170>
 10c9343:	test   %r8,%r8
 10c9346:	je     10c9473 <join_short+0x333>
 10c934c:	movzbl (%rcx),%eax
 10c934f:	mov    (%rsi),%r8
 10c9352:	mov    0x8(%r8),%rcx
 10c9356:	test   %rcx,%rcx
 10c9359:	je     10c96d2 <join_short+0x592>
 10c935f:	testb  $0x4,0x10(%r8)
 10c9364:	jne    10c962c <join_short+0x4ec>
 10c936a:	add    $0x18,%r8
 10c936e:	jmp    10c963b <join_short+0x4fb>
 10c9373:	cmp    $0x1,%r9
 10c9377:	jne    10c9613 <join_short+0x4d3>
 10c937d:	movzbl (%r10),%r10d
 10c9381:	mov    %r10b,(%rdi)
 10c9384:	jmp    10c927d <join_short+0x13d>
 10c9389:	mov    0x18(%r10),%r11
 10c938d:	mov    0x14(%r10),%r10d
 10c9391:	add    %r11,%r10
 10c9394:	add    $0x18,%r10
 10c9398:	cmp    $0x7,%r9
 10c939c:	jbe    10c91da <join_short+0x9a>
 10c93a2:	mov    (%r10),%r11
 10c93a5:	mov    -0x8(%r10,%r9,1),%r10
 10c93aa:	mov    %r11,(%rdi)
 10c93ad:	mov    %r10,-0x8(%rdi,%r9,1)
 10c93b2:	cmp    $0x1,%rdx
 10c93b6:	je     10c96d8 <join_short+0x598>
 10c93bc:	add    %r9,%rdi
 10c93bf:	mov    $0x1,%r9d
 10c93c5:	jmp    10c93ef <join_short+0x2af>
 10c93c7:	nopw   0x0(%rax,%rax,1)
 10c93d0:	mov    (%r11),%rbx
 10c93d3:	mov    -0x8(%r11,%r10,1),%r11
 10c93d8:	mov    %rbx,(%rdi)
 10c93db:	mov    %r11,-0x8(%rdi,%r10,1)
 10c93e0:	add    %r10,%rdi
 10c93e3:	inc    %r9
 10c93e6:	cmp    %r9,%rdx
 10c93e9:	je     10c96d8 <join_short+0x598>
 10c93ef:	mov    %eax,(%rdi)
 10c93f1:	mov    %ecx,-0x4(%rdi,%r8,1)
 10c93f6:	add    %r8,%rdi
 10c93f9:	mov    (%rsi,%r9,8),%r11
 10c93fd:	mov    0x8(%r11),%r10
 10c9401:	test   %r10,%r10
 10c9404:	je     10c93e0 <join_short+0x2a0>
 10c9406:	testb  $0x4,0x10(%r11)
 10c940b:	jne    10c9420 <join_short+0x2e0>
 10c940d:	add    $0x18,%r11
 10c9411:	cmp    $0x8,%r10
 10c9415:	jae    10c93d0 <join_short+0x290>
 10c9417:	jmp    10c9435 <join_short+0x2f5>
 10c9419:	nopl   0x0(%rax)
 10c9420:	mov    0x18(%r11),%rbx
 10c9424:	mov    0x14(%r11),%r11d
 10c9428:	add    %rbx,%r11
 10c942b:	add    $0x18,%r11
 10c942f:	cmp    $0x8,%r10
 10c9433:	jae    10c93d0 <join_short+0x290>
 10c9435:	cmp    $0x4,%r10
 10c9439:	jb     10c944c <join_short+0x30c>
 10c943b:	mov    (%r11),%ebx
 10c943e:	mov    -0x4(%r11,%r10,1),%r11d
 10c9443:	mov    %ebx,(%rdi)
 10c9445:	mov    %r11d,-0x4(%rdi,%r10,1)
 10c944a:	jmp    10c93e0 <join_short+0x2a0>
 10c944c:	cmp    $0x1,%r10
 10c9450:	jne    10c945b <join_short+0x31b>
 10c9452:	movzbl (%r11),%r11d
 10c9456:	mov    %r11b,(%rdi)
 10c9459:	jmp    10c93e0 <join_short+0x2a0>
 10c945b:	movzwl (%r11),%ebx
 10c945f:	movzwl -0x2(%r11,%r10,1),%r11d
 10c9465:	mov    %bx,(%rdi)
 10c9468:	mov    %r11w,-0x2(%rdi,%r10,1)
 10c946e:	jmp    10c93e0 <join_short+0x2a0>
 10c9473:	xor    %eax,%eax
 10c9475:	jmp    10c949f <join_short+0x35f>
 10c9477:	nopw   0x0(%rax,%rax,1)
 10c9480:	mov    (%r8),%r9
 10c9483:	mov    -0x8(%r8,%rcx,1),%r8
 10c9488:	mov    %r9,(%rdi)
 10c948b:	mov    %r8,-0x8(%rdi,%rcx,1)
 10c9490:	add    %rcx,%rdi
 10c9493:	inc    %rax
 10c9496:	cmp    %rax,%rdx
 10c9499:	je     10c96d8 <join_short+0x598>
 10c949f:	mov    (%rsi,%rax,8),%r8
 10c94a3:	mov    0x8(%r8),%rcx
 10c94a7:	test   %rcx,%rcx
 10c94aa:	je     10c9490 <join_short+0x350>
 10c94ac:	testb  $0x4,0x10(%r8)
 10c94b1:	jne    10c94c0 <join_short+0x380>
 10c94b3:	add    $0x18,%r8
 10c94b7:	cmp    $0x8,%rcx
 10c94bb:	jae    10c9480 <join_short+0x340>
 10c94bd:	jmp    10c94d5 <join_short+0x395>
 10c94bf:	nop
 10c94c0:	mov    0x18(%r8),%r9
 10c94c4:	mov    0x14(%r8),%r8d
 10c94c8:	add    %r9,%r8
 10c94cb:	add    $0x18,%r8
 10c94cf:	cmp    $0x8,%rcx
 10c94d3:	jae    10c9480 <join_short+0x340>
 10c94d5:	cmp    $0x4,%rcx
 10c94d9:	jb     10c94ed <join_short+0x3ad>
 10c94db:	mov    (%r8),%r9d
 10c94de:	mov    -0x4(%r8,%rcx,1),%r8d
 10c94e3:	mov    %r9d,(%rdi)
 10c94e6:	mov    %r8d,-0x4(%rdi,%rcx,1)
 10c94eb:	jmp    10c9490 <join_short+0x350>
 10c94ed:	cmp    $0x1,%rcx
 10c94f1:	jne    10c94fc <join_short+0x3bc>
 10c94f3:	movzbl (%r8),%r8d
 10c94f7:	mov    %r8b,(%rdi)
 10c94fa:	jmp    10c9490 <join_short+0x350>
 10c94fc:	movzwl (%r8),%r9d
 10c9500:	movzwl -0x2(%r8,%rcx,1),%r8d
 10c9506:	mov    %r9w,(%rdi)
 10c950a:	mov    %r8w,-0x2(%rdi,%rcx,1)
 10c9510:	jmp    10c9490 <join_short+0x350>
 10c9515:	cmp    $0x1,%r9
 10c9519:	jne    10c967d <join_short+0x53d>
 10c951f:	movzbl (%r10),%r10d
 10c9523:	mov    %r10b,(%rdi)
 10c9526:	jmp    10c93b2 <join_short+0x272>
 10c952b:	mov    0x18(%r10),%r11
 10c952f:	mov    0x14(%r10),%r10d
 10c9533:	add    %r11,%r10
 10c9536:	add    $0x18,%r10
 10c953a:	cmp    $0x7,%r9
 10c953e:	jbe    10c9235 <join_short+0xf5>
 10c9544:	mov    (%r10),%r11
 10c9547:	mov    -0x8(%r10,%r9,1),%r10
 10c954c:	mov    %r11,(%rdi)
 10c954f:	mov    %r10,-0x8(%rdi,%r9,1)
 10c9554:	cmp    $0x1,%rdx
 10c9558:	je     10c96d8 <join_short+0x598>
 10c955e:	add    %r9,%rdi
 10c9561:	mov    $0x1,%r9d
 10c9567:	jmp    10c958f <join_short+0x44f>
 10c9569:	nopl   0x0(%rax)
 10c9570:	mov    (%r11),%rbx
 10c9573:	mov    -0x8(%r11,%r10,1),%r11
 10c9578:	mov    %rbx,(%rdi)
 10c957b:	mov    %r11,-0x8(%rdi,%r10,1)
 10c9580:	add    %r10,%rdi
 10c9583:	inc    %r9
 10c9586:	cmp    %r9,%rdx
 10c9589:	je     10c96d8 <join_short+0x598>
 10c958f:	mov    %ax,(%rdi)
 10c9592:	mov    %cx,-0x2(%rdi,%r8,1)
 10c9598:	add    %r8,%rdi
 10c959b:	mov    (%rsi,%r9,8),%r11
 10c959f:	mov    0x8(%r11),%r10
 10c95a3:	test   %r10,%r10
 10c95a6:	je     10c9580 <join_short+0x440>
 10c95a8:	testb  $0x4,0x10(%r11)
 10c95ad:	jne    10c95c0 <join_short+0x480>
 10c95af:	add    $0x18,%r11
 10c95b3:	cmp    $0x8,%r10
 10c95b7:	jae    10c9570 <join_short+0x430>
 10c95b9:	jmp    10c95d5 <join_short+0x495>
 10c95bb:	nopl   0x0(%rax,%rax,1)
 10c95c0:	mov    0x18(%r11),%rbx
 10c95c4:	mov    0x14(%r11),%r11d
 10c95c8:	add    %rbx,%r11
 10c95cb:	add    $0x18,%r11
 10c95cf:	cmp    $0x8,%r10
 10c95d3:	jae    10c9570 <join_short+0x430>
 10c95d5:	cmp    $0x4,%r10
 10c95d9:	jb     10c95ec <join_short+0x4ac>
 10c95db:	mov    (%r11),%ebx
 10c95de:	mov    -0x4(%r11,%r10,1),%r11d
 10c95e3:	mov    %ebx,(%rdi)
 10c95e5:	mov    %r11d,-0x4(%rdi,%r10,1)
 10c95ea:	jmp    10c9580 <join_short+0x440>
 10c95ec:	cmp    $0x1,%r10
 10c95f0:	jne    10c95fb <join_short+0x4bb>
 10c95f2:	movzbl (%r11),%r11d
 10c95f6:	mov    %r11b,(%rdi)
 10c95f9:	jmp    10c9580 <join_short+0x440>
 10c95fb:	movzwl (%r11),%ebx
 10c95ff:	movzwl -0x2(%r11,%r10,1),%r11d
 10c9605:	mov    %bx,(%rdi)
 10c9608:	mov    %r11w,-0x2(%rdi,%r10,1)
 10c960e:	jmp    10c9580 <join_short+0x440>
 10c9613:	movzwl (%r10),%r11d
 10c9617:	movzwl -0x2(%r10,%r9,1),%r10d
 10c961d:	mov    %r11w,(%rdi)
 10c9621:	mov    %r10w,-0x2(%rdi,%r9,1)
 10c9627:	jmp    10c927d <join_short+0x13d>
 10c962c:	mov    0x18(%r8),%r9
 10c9630:	mov    0x14(%r8),%r8d
 10c9634:	add    %r9,%r8
 10c9637:	add    $0x18,%r8
 10c963b:	cmp    $0x7,%rcx
 10c963f:	jbe    10c9653 <join_short+0x513>
 10c9641:	mov    (%r8),%r9
 10c9644:	mov    -0x8(%r8,%rcx,1),%r8
 10c9649:	mov    %r9,(%rdi)
 10c964c:	mov    %r8,-0x8(%rdi,%rcx,1)
 10c9651:	jmp    10c96d2 <join_short+0x592>
 10c9653:	cmp    $0x3,%rcx
 10c9657:	jbe    10c9696 <join_short+0x556>
 10c9659:	mov    (%r8),%r9d
 10c965c:	mov    -0x4(%r8,%rcx,1),%r8d
 10c9661:	mov    %r9d,(%rdi)
 10c9664:	mov    %r8d,-0x4(%rdi,%rcx,1)
 10c9669:	jmp    10c96d2 <join_short+0x592>
 10c966b:	cmp    $0x1,%r9
 10c966f:	jne    10c96a5 <join_short+0x565>
 10c9671:	movzbl (%r10),%r10d
 10c9675:	mov    %r10b,(%rdi)
 10c9678:	jmp    10c9554 <join_short+0x414>
 10c967d:	movzwl (%r10),%r11d
 10c9681:	movzwl -0x2(%r10,%r9,1),%r10d
 10c9687:	mov    %r11w,(%rdi)
 10c968b:	mov    %r10w,-0x2(%rdi,%r9,1)
 10c9691:	jmp    10c93b2 <join_short+0x272>
 10c9696:	cmp    $0x1,%rcx
 10c969a:	jne    10c96be <join_short+0x57e>
 10c969c:	movzbl (%r8),%r8d
 10c96a0:	mov    %r8b,(%rdi)
 10c96a3:	jmp    10c96d2 <join_short+0x592>
 10c96a5:	movzwl (%r10),%r11d
 10c96a9:	movzwl -0x2(%r10,%r9,1),%r10d
 10c96af:	mov    %r11w,(%rdi)
 10c96b3:	mov    %r10w,-0x2(%rdi,%r9,1)
 10c96b9:	jmp    10c9554 <join_short+0x414>
 10c96be:	movzwl (%r8),%r9d
 10c96c2:	movzwl -0x2(%r8,%rcx,1),%r8d
 10c96c8:	mov    %r9w,(%rdi)
 10c96cc:	mov    %r8w,-0x2(%rdi,%rcx,1)
 10c96d2:	cmp    $0x1,%rdx
 10c96d6:	jne    10c96db <join_short+0x59b>
 10c96d8:	pop    %rbx
 10c96d9:	pop    %rbp
 10c96da:	ret
 10c96db:	add    %rcx,%rdi
 10c96de:	mov    $0x1,%ecx
 10c96e3:	jmp    10c970b <join_short+0x5cb>
 10c96e5:	data16 cs nopw 0x0(%rax,%rax,1)
 10c96f0:	mov    (%r9),%r10
 10c96f3:	mov    -0x8(%r9,%r8,1),%r9
 10c96f8:	mov    %r10,(%rdi)
 10c96fb:	mov    %r9,-0x8(%rdi,%r8,1)
 10c9700:	add    %r8,%rdi
 10c9703:	inc    %rcx
 10c9706:	cmp    %rcx,%rdx
 10c9709:	je     10c96d8 <join_short+0x598>
 10c970b:	mov    %al,(%rdi)
 10c970d:	inc    %rdi
 10c9710:	mov    (%rsi,%rcx,8),%r9
 10c9714:	mov    0x8(%r9),%r8
 10c9718:	test   %r8,%r8
 10c971b:	je     10c9700 <join_short+0x5c0>
 10c971d:	testb  $0x4,0x10(%r9)
 10c9722:	jne    10c9730 <join_short+0x5f0>
 10c9724:	add    $0x18,%r9
 10c9728:	cmp    $0x8,%r8
 10c972c:	jae    10c96f0 <join_short+0x5b0>
 10c972e:	jmp    10c9745 <join_short+0x605>
 10c9730:	mov    0x18(%r9),%r10
 10c9734:	mov    0x14(%r9),%r9d
 10c9738:	add    %r10,%r9
 10c973b:	add    $0x18,%r9
 10c973f:	cmp    $0x8,%r8
 10c9743:	jae    10c96f0 <join_short+0x5b0>
 10c9745:	cmp    $0x4,%r8
 10c9749:	jb     10c975d <join_short+0x61d>
 10c974b:	mov    (%r9),%r10d
 10c974e:	mov    -0x4(%r9,%r8,1),%r9d
 10c9753:	mov    %r10d,(%rdi)
 10c9756:	mov    %r9d,-0x4(%rdi,%r8,1)
 10c975b:	jmp    10c9700 <join_short+0x5c0>
 10c975d:	cmp    $0x1,%r8
 10c9761:	jne    10c976c <join_short+0x62c>
 10c9763:	movzbl (%r9),%r9d
 10c9767:	mov    %r9b,(%rdi)
 10c976a:	jmp    10c9700 <join_short+0x5c0>
 10c976c:	movzwl (%r9),%r10d
 10c9770:	movzwl -0x2(%r9,%r8,1),%r9d
 10c9776:	mov    %r10w,(%rdi)
 10c977a:	mov    %r9w,-0x2(%rdi,%r8,1)
 10c9780:	jmp    10c9700 <join_short+0x5c0>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
