#include "native_text_methods.h"
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static const myl_native_type pointer={.size=sizeof(void *),.alignment=_Alignof(void *),.kind=MYL_NATIVE_POINTER};
void myl_qbe_fail(void *context,const char *code) {
    (void)context; (void)code;
    assert(0 && "unexpected text trap");
}
/* Every temporary this test builds is retained here, so collection stress never
   reclaims an operand that is still an argument of the expression under test. */
static myl_native_list *bag;
static myl_native_text *raw(myl_native_heap *heap,const char *text) {
    myl_native_text *value=myl_native_text_from_utf8(heap,(const unsigned char *)text,strlen(text));
    assert(value);
    myl_native_root root;
    myl_native_root_push(heap,&root,&value,&pointer);
    assert(myl_native_list_append(heap,bag,&value));
    myl_native_root_pop(heap,&root);
    return value;
}
static void equals(myl_native_text *value,const char *text) {
    assert(value);
    unsigned char frame[64];
    size_t written=myl_native_text_utf8(value,frame,sizeof frame);
    assert(written<=sizeof frame);
    assert(written==strlen(text));
    assert(!written || !memcmp(frame,text,written));
}
static void keep(myl_native_heap *heap,myl_native_text *value) {
    myl_native_root root;
    myl_native_root_push(heap,&root,&value,&pointer);
    assert(myl_native_list_append(heap,bag,&value));
    myl_native_root_pop(heap,&root);
}
static size_t find(const char *haystack,const char *needle) {
    return myl_native_octets_find((const unsigned char *)haystack,strlen(haystack),(const unsigned char *)needle,strlen(needle));
}
static size_t tally(const char *haystack,const char *needle) {
    return myl_native_octets_count((const unsigned char *)haystack,strlen(haystack),(const unsigned char *)needle,strlen(needle));
}
static size_t first_octets(const unsigned char *haystack,size_t length,const unsigned char *needle,size_t count) {
    if (!count) return 0;
    if (count>length) return SIZE_MAX;
    for (size_t at=0;at<=length-count;at++) {
        size_t matched=0;
        while (matched<count && haystack[at+matched]==needle[matched]) matched++;
        if (matched==count) return at;
    }
    return SIZE_MAX;
}
/* spec-case: TEXT-SCAN-1. Exact-sized, unaligned slices agree with an independent
   first-match oracle across nearby fetch/block boundaries, repeated candidates,
   zero octets and UTF-8 octets. An allocator red zone follows each payload. */
static void search_boundaries(void) {
    static const size_t lengths[]={0,1,2,7,8,9,15,16,17,31,32,33,63,64,65,127,128,129,255,256,257,1023,1024,1025,4095,4096,4097};
    static const size_t widths[]={0,1,2,3,8,9,16,17,32};
    static const unsigned char utf8[]={0xc3,0xa9,'a',0xce,0xa9,';'};
    size_t checked=0;
    for (size_t row=0;row<sizeof lengths/sizeof *lengths;row++) {
        size_t length=lengths[row];
        for (size_t offset=0;offset<8;offset++) {
            unsigned char *allocation=malloc(offset+length+(!length && !offset));
            assert(allocation);
            unsigned char *haystack=allocation+offset;
            for (size_t distribution=0;distribution<4;distribution++) {
                for (size_t at=0;at<length;at++)
                    haystack[at]=distribution==0?'a':distribution==1?(unsigned char)(at*37):distribution==2?utf8[at%sizeof utf8]:'a';
                if (distribution==3 && length) haystack[length-1]='b';
                for (size_t column=0;column<sizeof widths/sizeof *widths;column++) {
                    size_t count=widths[column];
                    unsigned char *needle_allocation=malloc(7+count);
                    assert(needle_allocation);
                    unsigned char *needle=needle_allocation+7;
                    for (size_t mode=0;mode<4;mode++) {
                        size_t begin=mode==0?0:mode==1?length/2:count<=length?length-count:0;
                        for (size_t at=0;at<count;at++) needle[at]=mode<3 && begin+at<length?haystack[begin+at]:'a';
                        if (mode==3 && count) needle[count-1]='b';
                        assert(myl_native_octets_find(haystack,length,needle,count)==first_octets(haystack,length,needle,count));
                        checked++;
                    }
                    free(needle_allocation);
                }
            }
            free(allocation);
        }
    }
    printf("exact search slices: %zu oracle outcomes\n",checked);
}
/* spec-case: TEXT-SCAN-1. The bulk search answers exactly what a comparison at
   every offset answered: the first match, at either end, past any number of
   first-octet candidates that fail (more than the in-place budget hands the rest
   to `memmem`), and non-overlapping counts. */
static void octet_search(void) {
    assert(find("abc","")==0 && find("","")==0);
    assert(find("","a")==SIZE_MAX && find("ab","abc")==SIZE_MAX);
    assert(find("abc","a")==0 && find("abc","c")==2 && find("abc","z")==SIZE_MAX);
    assert(find("abcab","ab")==0 && find("xxab","ab")==2 && find("abc","abc")==0);
    assert(find("aaaaaaaaaaaaaaaaaaaaaab","ab")==21);
    assert(find("aaaaaaaaaaaaaaaaaaaaaaa","aab")==SIZE_MAX);
    assert(find("abababababababababababx","abx")==20);
    assert(find("h\xc3\xa9llo \xc3\xa9","\xc3\xa9 ")==SIZE_MAX && find("h\xc3\xa9llo \xc3\xa9","o \xc3\xa9")==5);
    assert(tally("aaa","aa")==1 && tally("aaaa","aa")==2 && tally("abababa","aba")==2);
    assert(tally("a,b,,c,",",")==4 && tally("",",")==0 && tally("abc","")==0 && tally("ab","abc")==0);
    assert(tally("aaaaaaaaaaaaaaaaaaaaaabaab","aab")==2);
    /* A one-octet tally spans several 64 KiB blocks. */
    static unsigned char large[200001];
    memset(large,'x',sizeof large);
    for (size_t i=0;i<sizeof large;i+=7) large[i]=',';
    assert(myl_native_octets_count(large,sizeof large,(const unsigned char *)",",1)==200001/7+1);
    assert(myl_native_octets_count(large,sizeof large,(const unsigned char *)",x",2)==200001/7+1);
    assert(myl_native_octets_count(large,sizeof large,(const unsigned char *)"x,",2)==200001/7);
    assert(myl_native_octets_find(large+1,sizeof large-1,(const unsigned char *)",",1)==6);
    search_boundaries();
}
static myl_native_list *pieces(myl_native_heap *heap,myl_native_root *root,const char *text,const char *separator) {
    myl_native_list *parts=myl_native_text_split(heap,raw(heap,text),raw(heap,separator));
    assert(parts);
    myl_native_root_push(heap,root,&parts,&pointer);
    return parts;
}
/* spec-case: TEXT-SCAN-3. Separator splits keep every empty piece and the count
   of cuts the list was sized for, and a non-ASCII receiver's pieces measure
   their own scalars. */
static void separator_split(myl_native_heap *heap) {
    myl_native_root root;
    myl_native_list *parts=pieces(heap,&root,"a,b,,c,",",");
    myl_native_text **items=parts->storage;
    assert(parts->length==5 && parts->capacity==5);
    equals(items[0],"a"); equals(items[1],"b"); equals(items[2],""); equals(items[3],"c"); equals(items[4],"");
    myl_native_root_pop(heap,&root);
    parts=pieces(heap,&root,"",",");
    assert(parts->length==1); equals(((myl_native_text **)parts->storage)[0],"");
    myl_native_root_pop(heap,&root);
    parts=pieces(heap,&root,"abc","abcd");
    assert(parts->length==1); equals(((myl_native_text **)parts->storage)[0],"abc");
    myl_native_root_pop(heap,&root);
    parts=pieces(heap,&root,"aaa","aa");
    items=parts->storage;
    assert(parts->length==2); equals(items[0],""); equals(items[1],"a");
    myl_native_root_pop(heap,&root);
    parts=pieces(heap,&root,"aaaaaaaaaaaaaaaaaaaab--c--","--");
    items=parts->storage;
    assert(parts->length==3); equals(items[0],"aaaaaaaaaaaaaaaaaaaab"); equals(items[1],"c"); equals(items[2],"");
    myl_native_root_pop(heap,&root);
    parts=pieces(heap,&root,"\xc3\xa9|\xf0\x9f\x99\x82\xc3\xa9|x","|");
    items=parts->storage;
    assert(parts->length==3);
    assert(items[0]->length==1 && items[1]->length==2 && items[2]->length==1);
    assert(!(items[0]->flags&MYL_TEXT_ASCII) && (items[2]->flags&MYL_TEXT_ASCII));
    equals(items[1],"\xf0\x9f\x99\x82\xc3\xa9");
    myl_native_root_pop(heap,&root);
}
/* Exact-size, unaligned payloads exercise every short-copy boundary. These
   synthetic immutable headers are used only with collection disabled; the
   managed-input check below separately stresses roots across allocation. */
static myl_native_text *join_operand(size_t bytes,size_t offset,int wide) {
    myl_native_text *owner=malloc(sizeof(*owner)+offset+bytes);
    assert(owner);
    *owner=(myl_native_text){.length=offset+bytes,.bytes=offset+bytes,.flags=MYL_TEXT_ASCII};
    unsigned char *raw=(unsigned char *)(owner+1);
    memset(raw,'p',offset);
    for (size_t i=0;i<bytes;++i) raw[offset+i]=(unsigned char)(i%127);
    size_t scalars=bytes;
    if (wide) {
        for (size_t i=0;i+1<bytes;i+=2) { raw[offset+i]=0xc3; raw[offset+i+1]=0xa9; }
        if (bytes&1) raw[offset+bytes-1]='x';
        scalars=(bytes+1)/2;
    }
    if (!offset) {
        owner->length=scalars;
        owner->flags=scalars==bytes ? MYL_TEXT_ASCII : 0;
        return owner;
    }
    myl_native_text_view *view=malloc(sizeof(*view));
    assert(view);
    *view=(myl_native_text_view){.text={.length=scalars,.bytes=bytes,
        .flags=MYL_TEXT_VIEW|(scalars==bytes ? MYL_TEXT_ASCII : 0),.hash=(uint32_t)offset},.owner=owner};
    return &view->text;
}
static void free_join_operand(myl_native_text *text) {
    if (text->flags&MYL_TEXT_VIEW) free((void *)((myl_native_text_view *)text)->owner);
    free(text);
}
static void join_payload_boundaries(void) {
    static const size_t lengths[]={0,1,2,3,4,5,7,8,9,15,16,17,23,31,32,33,63,64,65,257};
    static const size_t widths[]={0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,33,65};
    myl_native_heap heap;
    myl_native_heap_init(&heap,1<<27);
    heap.next_collection=SIZE_MAX;
    for (size_t k=0;k<sizeof(lengths)/sizeof(*lengths);++k)
    for (size_t j=0;j<sizeof(widths)/sizeof(*widths);++j)
    for (size_t offset=0;offset<=7;++offset)
    for (int wide=0;wide<=1;++wide) {
        myl_native_text *part=join_operand(lengths[k],offset,wide);
        myl_native_text *separator=join_operand(widths[j],offset,!wide);
        myl_native_text *empty=join_operand(0,offset,0);
        myl_native_text *parts[]={part,empty,part};
        for (size_t n=0;n<=3;n+=(n ? 2 : 1)) {
            myl_native_list list={.length=n,.storage=parts};
            const size_t allocations=heap.allocations;
            myl_native_text *result=myl_native_text_join(&heap,separator,&list);
            assert(result && heap.allocations==allocations+1 && !heap.collections);
            const size_t expected=(n==0 ? 0 : n==1 ? part->bytes : 2*part->bytes+2*separator->bytes);
            const size_t scalars=(n==0 ? 0 : n==1 ? part->length : 2*part->length+2*separator->length);
            assert(result->bytes==expected && result->length==scalars);
            assert(!!(result->flags&MYL_TEXT_ASCII)==(scalars==expected));
            const unsigned char *out=myl_native_text_storage(result);
            size_t cursor=0;
            for (size_t i=0;i<n;++i) {
                if (i) { assert(!memcmp(out+cursor,myl_native_text_storage(separator),separator->bytes)); cursor+=separator->bytes; }
                assert(!memcmp(out+cursor,myl_native_text_storage(parts[i]),parts[i]->bytes));
                cursor+=parts[i]->bytes;
            }
            assert(cursor==expected && !heap.roots);
        }
        free_join_operand(empty); free_join_operand(separator); free_join_operand(part);
    }
    myl_native_heap_destroy(&heap);
}
/* A short separator is used repeatedly over mixed-width inputs, including
   empty pieces; one seventeen-octet piece switches the same request to the
   general copy path. Exact payloads and views expose both copy endpoints. */
static void join_mixed_widths(void) {
    static const size_t lengths[]={0,1,2,3,4,7,8,9,15,16};
    static const size_t counts[]={2,17,64};
    static const size_t offsets[]={0,1,7};
    myl_native_heap heap;
    myl_native_heap_init(&heap,1<<27); heap.next_collection=SIZE_MAX;
    size_t checked=0;
    for (size_t width=0;width<=18;width++)
    for (size_t row=0;row<sizeof offsets/sizeof *offsets;row++)
    for (int wide=0;wide<=1;wide++)
    for (size_t column=0;column<sizeof counts/sizeof *counts;column++)
    for (int bulk=0;bulk<=1;bulk++) {
        const size_t count=counts[column], offset=offsets[row];
        myl_native_text *separator=join_operand(width,offset,!wide);
        myl_native_text *parts[64];
        unsigned char expected[4096];
        size_t bytes=0,scalars=0;
        for (size_t i=0;i<count;i++) {
            size_t length=bulk && i==count/2 ? 17 : lengths[i%(sizeof lengths/sizeof *lengths)];
            parts[i]=join_operand(length,offset,wide);
            if (i) {
                memcpy(expected+bytes,myl_native_text_storage(separator),width);
                bytes+=width; scalars+=separator->length;
            }
            memcpy(expected+bytes,myl_native_text_storage(parts[i]),length);
            bytes+=length; scalars+=parts[i]->length;
        }
        myl_native_list list={.length=count,.storage=parts};
        const size_t allocations=heap.allocations;
        myl_native_text *result=myl_native_text_join(&heap,separator,&list);
        assert(result && heap.allocations==allocations+1 && !heap.collections && !heap.roots);
        assert(result->bytes==bytes && result->length==scalars);
        assert(!!(result->flags&MYL_TEXT_ASCII)==(scalars==bytes));
        assert(!memcmp(myl_native_text_storage(result),expected,bytes));
        for (size_t i=0;i<count;i++) free_join_operand(parts[i]);
        free_join_operand(separator);
        checked++;
    }
    myl_native_heap_destroy(&heap);
    printf("mixed-width short/bulk joins: %zu oracle outcomes\n",checked);
}
/* Rooted operands survive a join safepoint, and a refused output allocation
   leaves every input available. Overflow refuses before touching the heap. */
static void join_collection_and_limits(void) {
    myl_native_heap heap;
    myl_native_heap_init(&heap,1<<20); heap.stress=1;
    myl_native_list *parts=myl_native_list_new(&heap,&pointer,3);
    assert(parts);
    myl_native_root list_root,separator_root;
    myl_native_root_push(&heap,&list_root,&parts,&pointer);
    parts->length=3;
    myl_native_text *separator=myl_native_text_from_utf8(&heap,(const unsigned char *)"|",1);
    assert(separator);
    myl_native_root_push(&heap,&separator_root,&separator,&pointer);
    for (size_t i=0;i<3;++i) {
        myl_native_text *part=myl_native_text_from_utf8(&heap,(const unsigned char *)"caf\xc3\xa9",5);
        assert(part);
        ((myl_native_text **)parts->storage)[i]=part;
    }
    myl_native_text *result=myl_native_text_join(&heap,separator,parts);
    equals(result,"caf\xc3\xa9|caf\xc3\xa9|caf\xc3\xa9");
    assert(result->length==14 && result->bytes==17 && !((result->flags)&MYL_TEXT_ASCII));
    myl_native_root result_root;
    myl_native_root_push(&heap,&result_root,&result,&pointer);
    heap.limit=heap.bytes;
    assert(!myl_native_text_join(&heap,separator,parts) && heap.exhausted);
    for (size_t i=0;i<3;++i) equals(((myl_native_text **)parts->storage)[i],"caf\xc3\xa9");
    assert(myl_native_root_pop(&heap,&result_root));
    assert(myl_native_root_pop(&heap,&separator_root));
    assert(myl_native_root_pop(&heap,&list_root));
    myl_native_heap_destroy(&heap);
    myl_native_heap_init(&heap,1<<20);
    myl_native_text enormous={.length=SIZE_MAX,.bytes=SIZE_MAX,.flags=MYL_TEXT_ASCII};
    myl_native_text comma={.length=1,.bytes=1,.flags=MYL_TEXT_ASCII};
    myl_native_text *items[]={&enormous,&enormous};
    myl_native_list list={.length=2,.storage=items};
    assert(!myl_native_text_join(&heap,&comma,&list) && !heap.allocations && !heap.roots);
    list.length=SIZE_MAX; comma.bytes=2; comma.length=2;
    assert(!myl_native_text_join(&heap,&comma,&list) && !heap.allocations && !heap.roots);
    myl_native_heap_destroy(&heap);
}
int main(void) {
    join_payload_boundaries();
    join_mixed_widths();
    join_collection_and_limits();
    myl_native_heap heap;
    myl_native_heap_init(&heap,1<<20); heap.stress=1;
    myl_native_root roots[2];
    bag=myl_native_list_new(&heap,&pointer,0); assert(bag);
    myl_native_root_push(&heap,&roots[0],&bag,&pointer);
    myl_native_text *padded=raw(&heap,"  value  ");
    equals(myl_native_text_trim(&heap,padded,MYL_TEXT_BOTH),"value");
    equals(myl_native_text_trim(&heap,padded,MYL_TEXT_LEADING),"value  ");
    equals(myl_native_text_trim(&heap,padded,MYL_TEXT_TRAILING),"  value");
    equals(myl_native_text_trim(&heap,raw(&heap,"\t\n\v\f\r x "),MYL_TEXT_BOTH),"x");
    equals(myl_native_text_trim(&heap,raw(&heap,"   "),MYL_TEXT_BOTH),"");
    equals(myl_native_text_trim(&heap,raw(&heap,""),MYL_TEXT_BOTH),"");
    /* Case mapping covers ASCII letters and leaves every other scalar alone. */
    equals(myl_native_text_case(&heap,raw(&heap,"aB\xc3\xa9"),1),"AB\xc3\xa9");
    equals(myl_native_text_case(&heap,raw(&heap,"aB\xc3\xa9"),0),"ab\xc3\xa9");
    equals(myl_native_text_case(&heap,raw(&heap,""),1),"");
    /* zfill keeps a leading sign in front of its padding and never truncates. */
    equals(myl_native_text_zfill(&heap,raw(&heap,"7"),3),"007");
    equals(myl_native_text_zfill(&heap,raw(&heap,"-7"),4),"-007");
    equals(myl_native_text_zfill(&heap,raw(&heap,"+7"),4),"+007");
    equals(myl_native_text_zfill(&heap,raw(&heap,"-"),3),"-00");
    equals(myl_native_text_zfill(&heap,raw(&heap,"1234"),2),"1234");
    equals(myl_native_text_zfill(&heap,raw(&heap,""),3),"000");
    equals(myl_native_text_zfill(&heap,raw(&heap,"7"),-5),"7");
    equals(myl_native_text_zfill(&heap,raw(&heap,""),0),"");
    /* Search answers Python's indices and counts, including for absent needles. */
    myl_native_text *line=raw(&heap,"banana");
    myl_native_text *empty=raw(&heap,"");
    assert(myl_native_text_find(line,raw(&heap,"na"))==2);
    assert(myl_native_text_find(line,raw(&heap,"zz"))==-1);
    assert(myl_native_text_find(line,raw(&heap,"bananas"))==-1);
    assert(myl_native_text_find(line,empty)==0);
    assert(myl_native_text_count(line,raw(&heap,"na"))==2);
    assert(myl_native_text_count(line,raw(&heap,"ana"))==1);
    assert(myl_native_text_count(empty,raw(&heap,"a"))==0);
    assert(myl_native_text_count(line,empty)==(int64_t)line->length+1);
    assert(myl_native_text_edge(line,raw(&heap,"ban"),1));
    assert(myl_native_text_edge(line,raw(&heap,"ana"),0));
    assert(!myl_native_text_edge(line,raw(&heap,"nan"),1));
    assert(myl_native_text_edge(line,empty,1) && myl_native_text_edge(line,empty,0));
    assert(!myl_native_text_edge(empty,line,1));
    /* Classification answers false for empty text, as in Python. */
    assert(myl_native_text_every(raw(&heap,"42"),MYL_TEXT_DIGIT));
    assert(!myl_native_text_every(raw(&heap,"4a"),MYL_TEXT_DIGIT));
    assert(myl_native_text_every(raw(&heap,"abZ"),MYL_TEXT_ALPHA));
    assert(!myl_native_text_every(raw(&heap,"\xc3\xa9"),MYL_TEXT_ALPHA));
    assert(myl_native_text_every(raw(&heap," \t\n\r\v\f"),MYL_TEXT_SPACE));
    assert(!myl_native_text_every(empty,MYL_TEXT_DIGIT));
    assert(!myl_native_text_every(empty,MYL_TEXT_ALPHA));
    assert(!myl_native_text_every(empty,MYL_TEXT_SPACE));
    /* Replacement is non-overlapping and may shrink, grow or empty the text. */
    equals(myl_native_text_replace(&heap,line,raw(&heap,"na"),raw(&heap,"NA")),"baNANA");
    equals(myl_native_text_replace(&heap,raw(&heap,"aaa"),raw(&heap,"aa"),raw(&heap,"b")),"ba");
    equals(myl_native_text_replace(&heap,raw(&heap,"aaa"),raw(&heap,"a"),empty),"");
    equals(myl_native_text_replace(&heap,raw(&heap,"aa"),raw(&heap,"a"),raw(&heap,"bb")),"bbbb");
    equals(myl_native_text_replace(&heap,line,raw(&heap,"zz"),raw(&heap,"y")),"banana");
    equals(myl_native_text_replace(&heap,empty,raw(&heap,"a"),raw(&heap,"b")),"");
    assert(!myl_native_text_replace(&heap,line,empty,raw(&heap,"b")));
    /* Runs between matches are copied whole, matches at either end included,
       and a first octet that recurs without matching changes nothing. */
    equals(myl_native_text_replace(&heap,raw(&heap,"abxab"),raw(&heap,"ab"),empty),"x");
    equals(myl_native_text_replace(&heap,raw(&heap,"aaaaaaaaaaaaaaaaaaaaaab"),raw(&heap,"ab"),raw(&heap,"X")),"aaaaaaaaaaaaaaaaaaaaaX");
    myl_native_text *accented=myl_native_text_replace(&heap,raw(&heap,"h\xc3\xa9llo \xc3\xa9t\xc3\xa9"),raw(&heap,"\xc3\xa9"),raw(&heap,"e"));
    equals(accented,"hello ete");
    assert(accented->length==9);
    myl_native_text *widened=myl_native_text_replace(&heap,raw(&heap,"a-b"),raw(&heap,"-"),raw(&heap,"\xf0\x9f\x99\x82"));
    equals(widened,"a\xf0\x9f\x99\x82" "b");
    assert(widened->length==3 && widened->bytes==6);
    assert(myl_native_text_count(raw(&heap,"h\xc3\xa9llo \xc3\xa9"),raw(&heap,"\xc3\xa9"))==2);
    assert(myl_native_text_count(raw(&heap,"aaaaaaaaaaaaaaaaaaaaaabaab"),raw(&heap,"aab"))==2);
    assert(myl_native_text_find(raw(&heap,"\xc3\xa9t\xc3\xa9"),raw(&heap,"t"))==1);
    octet_search();
    separator_split(&heap);
    /* splitlines drops the terminators and yields no line for empty text. */
    myl_native_list *lines=myl_native_text_lines(&heap,raw(&heap,"a\nb\r\nc\rd"));
    assert(lines && lines->length==4);
    myl_native_root_push(&heap,&roots[1],&lines,&pointer);
    myl_native_text **pieces=lines->storage;
    equals(pieces[0],"a"); equals(pieces[1],"b"); equals(pieces[2],"c"); equals(pieces[3],"d");
    myl_native_list *none=myl_native_text_lines(&heap,empty);
    assert(none && none->length==0);
    myl_native_list *one=myl_native_text_lines(&heap,raw(&heap,"a\n"));
    assert(one && one->length==1);
    myl_native_list *blanks=myl_native_text_lines(&heap,raw(&heap,"\n\n"));
    assert(blanks && blanks->length==2);
    /* The payload is UTF-8 octets, which is exactly what the shared number
       grammar reads. */
    assert(myl_native_text_payload(line)[0]=='b' && line->bytes==strlen("banana"));
    keep(&heap,myl_native_text_trim(&heap,padded,MYL_TEXT_BOTH));
    myl_native_heap_collect(&heap);
    equals(((myl_native_text **)bag->storage)[bag->length-1],"value");
    equals(padded,"  value  ");
    equals(((myl_native_text **)lines->storage)[0],"a");
    for (int i=1;i>=0;--i) assert(myl_native_root_pop(&heap,&roots[i]));
    bag=NULL;
    myl_native_heap_collect(&heap);
    assert(heap.objects_live==0);
    myl_native_heap_destroy(&heap);
    puts("native text method tests passed");
    return 0;
}
