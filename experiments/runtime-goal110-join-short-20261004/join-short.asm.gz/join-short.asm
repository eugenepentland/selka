
.mylang-cache/goal110-join-short/runner/bin/text-my-llvm:     file format elf64-x86-64


Disassembly of section .text:

0000000001093d60 <join_short>:
 1093d60:	test   %rdx,%rdx
 1093d63:	je     10942fa <join_short+0x59a>
 1093d69:	push   %rbp
 1093d6a:	mov    %rsp,%rbp
 1093d6d:	push   %rbx
 1093d6e:	cmp    $0x8,%r8
 1093d72:	jb     1093dc4 <join_short+0x64>
 1093d74:	mov    (%rcx),%rax
 1093d77:	mov    -0x8(%rcx,%r8,1),%rcx
 1093d7c:	mov    (%rsi),%r10
 1093d7f:	mov    0x8(%r10),%r9
 1093d83:	test   %r9,%r9
 1093d86:	je     1093e9d <join_short+0x13d>
 1093d8c:	testb  $0x4,0x10(%r10)
 1093d91:	jne    1093e74 <join_short+0x114>
 1093d97:	add    $0x18,%r10
 1093d9b:	cmp    $0x7,%r9
 1093d9f:	ja     1093e8d <join_short+0x12d>
 1093da5:	cmp    $0x3,%r9
 1093da9:	jbe    1093f93 <join_short+0x233>
 1093daf:	mov    (%r10),%r11d
 1093db2:	mov    -0x4(%r10,%r9,1),%r10d
 1093db7:	mov    %r11d,(%rdi)
 1093dba:	mov    %r10d,-0x4(%rdi,%r9,1)
 1093dbf:	jmp    1093e9d <join_short+0x13d>
 1093dc4:	cmp    $0x4,%r8
 1093dc8:	jb     1093e19 <join_short+0xb9>
 1093dca:	mov    (%rcx),%eax
 1093dcc:	mov    -0x4(%rcx,%r8,1),%ecx
 1093dd1:	mov    (%rsi),%r10
 1093dd4:	mov    0x8(%r10),%r9
 1093dd8:	test   %r9,%r9
 1093ddb:	je     1093fd2 <join_short+0x272>
 1093de1:	testb  $0x4,0x10(%r10)
 1093de6:	jne    1093fa9 <join_short+0x249>
 1093dec:	add    $0x18,%r10
 1093df0:	cmp    $0x7,%r9
 1093df4:	ja     1093fc2 <join_short+0x262>
 1093dfa:	cmp    $0x3,%r9
 1093dfe:	jbe    1094135 <join_short+0x3d5>
 1093e04:	mov    (%r10),%r11d
 1093e07:	mov    -0x4(%r10,%r9,1),%r10d
 1093e0c:	mov    %r11d,(%rdi)
 1093e0f:	mov    %r10d,-0x4(%rdi,%r9,1)
 1093e14:	jmp    1093fd2 <join_short+0x272>
 1093e19:	cmp    $0x2,%r8
 1093e1d:	jb     1093f63 <join_short+0x203>
 1093e23:	movzwl (%rcx),%eax
 1093e26:	movzwl -0x2(%rcx,%r8,1),%ecx
 1093e2c:	mov    (%rsi),%r10
 1093e2f:	mov    0x8(%r10),%r9
 1093e33:	test   %r9,%r9
 1093e36:	je     1094174 <join_short+0x414>
 1093e3c:	testb  $0x4,0x10(%r10)
 1093e41:	jne    109414b <join_short+0x3eb>
 1093e47:	add    $0x18,%r10
 1093e4b:	cmp    $0x7,%r9
 1093e4f:	ja     1094164 <join_short+0x404>
 1093e55:	cmp    $0x3,%r9
 1093e59:	jbe    109428b <join_short+0x52b>
 1093e5f:	mov    (%r10),%r11d
 1093e62:	mov    -0x4(%r10,%r9,1),%r10d
 1093e67:	mov    %r11d,(%rdi)
 1093e6a:	mov    %r10d,-0x4(%rdi,%r9,1)
 1093e6f:	jmp    1094174 <join_short+0x414>
 1093e74:	mov    0x18(%r10),%r11
 1093e78:	mov    0x14(%r10),%r10d
 1093e7c:	add    %r11,%r10
 1093e7f:	add    $0x18,%r10
 1093e83:	cmp    $0x7,%r9
 1093e87:	jbe    1093da5 <join_short+0x45>
 1093e8d:	mov    (%r10),%r11
 1093e90:	mov    -0x8(%r10,%r9,1),%r10
 1093e95:	mov    %r11,(%rdi)
 1093e98:	mov    %r10,-0x8(%rdi,%r9,1)
 1093e9d:	cmp    $0x1,%rdx
 1093ea1:	je     10942f8 <join_short+0x598>
 1093ea7:	add    %r9,%rdi
 1093eaa:	mov    $0x1,%r9d
 1093eb0:	jmp    1093edf <join_short+0x17f>
 1093eb2:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1093ec0:	mov    (%r11),%rbx
 1093ec3:	mov    -0x8(%r11,%r10,1),%r11
 1093ec8:	mov    %rbx,(%rdi)
 1093ecb:	mov    %r11,-0x8(%rdi,%r10,1)
 1093ed0:	add    %r10,%rdi
 1093ed3:	inc    %r9
 1093ed6:	cmp    %r9,%rdx
 1093ed9:	je     10942f8 <join_short+0x598>
 1093edf:	mov    %rax,(%rdi)
 1093ee2:	mov    %rcx,-0x8(%rdi,%r8,1)
 1093ee7:	add    %r8,%rdi
 1093eea:	mov    (%rsi,%r9,8),%r11
 1093eee:	mov    0x8(%r11),%r10
 1093ef2:	test   %r10,%r10
 1093ef5:	je     1093ed0 <join_short+0x170>
 1093ef7:	testb  $0x4,0x10(%r11)
 1093efc:	jne    1093f10 <join_short+0x1b0>
 1093efe:	add    $0x18,%r11
 1093f02:	cmp    $0x8,%r10
 1093f06:	jae    1093ec0 <join_short+0x160>
 1093f08:	jmp    1093f25 <join_short+0x1c5>
 1093f0a:	nopw   0x0(%rax,%rax,1)
 1093f10:	mov    0x18(%r11),%rbx
 1093f14:	mov    0x14(%r11),%r11d
 1093f18:	add    %rbx,%r11
 1093f1b:	add    $0x18,%r11
 1093f1f:	cmp    $0x8,%r10
 1093f23:	jae    1093ec0 <join_short+0x160>
 1093f25:	cmp    $0x4,%r10
 1093f29:	jb     1093f3c <join_short+0x1dc>
 1093f2b:	mov    (%r11),%ebx
 1093f2e:	mov    -0x4(%r11,%r10,1),%r11d
 1093f33:	mov    %ebx,(%rdi)
 1093f35:	mov    %r11d,-0x4(%rdi,%r10,1)
 1093f3a:	jmp    1093ed0 <join_short+0x170>
 1093f3c:	cmp    $0x1,%r10
 1093f40:	jne    1093f4b <join_short+0x1eb>
 1093f42:	movzbl (%r11),%r11d
 1093f46:	mov    %r11b,(%rdi)
 1093f49:	jmp    1093ed0 <join_short+0x170>
 1093f4b:	movzwl (%r11),%ebx
 1093f4f:	movzwl -0x2(%r11,%r10,1),%r11d
 1093f55:	mov    %bx,(%rdi)
 1093f58:	mov    %r11w,-0x2(%rdi,%r10,1)
 1093f5e:	jmp    1093ed0 <join_short+0x170>
 1093f63:	test   %r8,%r8
 1093f66:	je     1094093 <join_short+0x333>
 1093f6c:	movzbl (%rcx),%eax
 1093f6f:	mov    (%rsi),%r8
 1093f72:	mov    0x8(%r8),%rcx
 1093f76:	test   %rcx,%rcx
 1093f79:	je     10942f2 <join_short+0x592>
 1093f7f:	testb  $0x4,0x10(%r8)
 1093f84:	jne    109424c <join_short+0x4ec>
 1093f8a:	add    $0x18,%r8
 1093f8e:	jmp    109425b <join_short+0x4fb>
 1093f93:	cmp    $0x1,%r9
 1093f97:	jne    1094233 <join_short+0x4d3>
 1093f9d:	movzbl (%r10),%r10d
 1093fa1:	mov    %r10b,(%rdi)
 1093fa4:	jmp    1093e9d <join_short+0x13d>
 1093fa9:	mov    0x18(%r10),%r11
 1093fad:	mov    0x14(%r10),%r10d
 1093fb1:	add    %r11,%r10
 1093fb4:	add    $0x18,%r10
 1093fb8:	cmp    $0x7,%r9
 1093fbc:	jbe    1093dfa <join_short+0x9a>
 1093fc2:	mov    (%r10),%r11
 1093fc5:	mov    -0x8(%r10,%r9,1),%r10
 1093fca:	mov    %r11,(%rdi)
 1093fcd:	mov    %r10,-0x8(%rdi,%r9,1)
 1093fd2:	cmp    $0x1,%rdx
 1093fd6:	je     10942f8 <join_short+0x598>
 1093fdc:	add    %r9,%rdi
 1093fdf:	mov    $0x1,%r9d
 1093fe5:	jmp    109400f <join_short+0x2af>
 1093fe7:	nopw   0x0(%rax,%rax,1)
 1093ff0:	mov    (%r11),%rbx
 1093ff3:	mov    -0x8(%r11,%r10,1),%r11
 1093ff8:	mov    %rbx,(%rdi)
 1093ffb:	mov    %r11,-0x8(%rdi,%r10,1)
 1094000:	add    %r10,%rdi
 1094003:	inc    %r9
 1094006:	cmp    %r9,%rdx
 1094009:	je     10942f8 <join_short+0x598>
 109400f:	mov    %eax,(%rdi)
 1094011:	mov    %ecx,-0x4(%rdi,%r8,1)
 1094016:	add    %r8,%rdi
 1094019:	mov    (%rsi,%r9,8),%r11
 109401d:	mov    0x8(%r11),%r10
 1094021:	test   %r10,%r10
 1094024:	je     1094000 <join_short+0x2a0>
 1094026:	testb  $0x4,0x10(%r11)
 109402b:	jne    1094040 <join_short+0x2e0>
 109402d:	add    $0x18,%r11
 1094031:	cmp    $0x8,%r10
 1094035:	jae    1093ff0 <join_short+0x290>
 1094037:	jmp    1094055 <join_short+0x2f5>
 1094039:	nopl   0x0(%rax)
 1094040:	mov    0x18(%r11),%rbx
 1094044:	mov    0x14(%r11),%r11d
 1094048:	add    %rbx,%r11
 109404b:	add    $0x18,%r11
 109404f:	cmp    $0x8,%r10
 1094053:	jae    1093ff0 <join_short+0x290>
 1094055:	cmp    $0x4,%r10
 1094059:	jb     109406c <join_short+0x30c>
 109405b:	mov    (%r11),%ebx
 109405e:	mov    -0x4(%r11,%r10,1),%r11d
 1094063:	mov    %ebx,(%rdi)
 1094065:	mov    %r11d,-0x4(%rdi,%r10,1)
 109406a:	jmp    1094000 <join_short+0x2a0>
 109406c:	cmp    $0x1,%r10
 1094070:	jne    109407b <join_short+0x31b>
 1094072:	movzbl (%r11),%r11d
 1094076:	mov    %r11b,(%rdi)
 1094079:	jmp    1094000 <join_short+0x2a0>
 109407b:	movzwl (%r11),%ebx
 109407f:	movzwl -0x2(%r11,%r10,1),%r11d
 1094085:	mov    %bx,(%rdi)
 1094088:	mov    %r11w,-0x2(%rdi,%r10,1)
 109408e:	jmp    1094000 <join_short+0x2a0>
 1094093:	xor    %eax,%eax
 1094095:	jmp    10940bf <join_short+0x35f>
 1094097:	nopw   0x0(%rax,%rax,1)
 10940a0:	mov    (%r8),%r9
 10940a3:	mov    -0x8(%r8,%rcx,1),%r8
 10940a8:	mov    %r9,(%rdi)
 10940ab:	mov    %r8,-0x8(%rdi,%rcx,1)
 10940b0:	add    %rcx,%rdi
 10940b3:	inc    %rax
 10940b6:	cmp    %rax,%rdx
 10940b9:	je     10942f8 <join_short+0x598>
 10940bf:	mov    (%rsi,%rax,8),%r8
 10940c3:	mov    0x8(%r8),%rcx
 10940c7:	test   %rcx,%rcx
 10940ca:	je     10940b0 <join_short+0x350>
 10940cc:	testb  $0x4,0x10(%r8)
 10940d1:	jne    10940e0 <join_short+0x380>
 10940d3:	add    $0x18,%r8
 10940d7:	cmp    $0x8,%rcx
 10940db:	jae    10940a0 <join_short+0x340>
 10940dd:	jmp    10940f5 <join_short+0x395>
 10940df:	nop
 10940e0:	mov    0x18(%r8),%r9
 10940e4:	mov    0x14(%r8),%r8d
 10940e8:	add    %r9,%r8
 10940eb:	add    $0x18,%r8
 10940ef:	cmp    $0x8,%rcx
 10940f3:	jae    10940a0 <join_short+0x340>
 10940f5:	cmp    $0x4,%rcx
 10940f9:	jb     109410d <join_short+0x3ad>
 10940fb:	mov    (%r8),%r9d
 10940fe:	mov    -0x4(%r8,%rcx,1),%r8d
 1094103:	mov    %r9d,(%rdi)
 1094106:	mov    %r8d,-0x4(%rdi,%rcx,1)
 109410b:	jmp    10940b0 <join_short+0x350>
 109410d:	cmp    $0x1,%rcx
 1094111:	jne    109411c <join_short+0x3bc>
 1094113:	movzbl (%r8),%r8d
 1094117:	mov    %r8b,(%rdi)
 109411a:	jmp    10940b0 <join_short+0x350>
 109411c:	movzwl (%r8),%r9d
 1094120:	movzwl -0x2(%r8,%rcx,1),%r8d
 1094126:	mov    %r9w,(%rdi)
 109412a:	mov    %r8w,-0x2(%rdi,%rcx,1)
 1094130:	jmp    10940b0 <join_short+0x350>
 1094135:	cmp    $0x1,%r9
 1094139:	jne    109429d <join_short+0x53d>
 109413f:	movzbl (%r10),%r10d
 1094143:	mov    %r10b,(%rdi)
 1094146:	jmp    1093fd2 <join_short+0x272>
 109414b:	mov    0x18(%r10),%r11
 109414f:	mov    0x14(%r10),%r10d
 1094153:	add    %r11,%r10
 1094156:	add    $0x18,%r10
 109415a:	cmp    $0x7,%r9
 109415e:	jbe    1093e55 <join_short+0xf5>
 1094164:	mov    (%r10),%r11
 1094167:	mov    -0x8(%r10,%r9,1),%r10
 109416c:	mov    %r11,(%rdi)
 109416f:	mov    %r10,-0x8(%rdi,%r9,1)
 1094174:	cmp    $0x1,%rdx
 1094178:	je     10942f8 <join_short+0x598>
 109417e:	add    %r9,%rdi
 1094181:	mov    $0x1,%r9d
 1094187:	jmp    10941af <join_short+0x44f>
 1094189:	nopl   0x0(%rax)
 1094190:	mov    (%r11),%rbx
 1094193:	mov    -0x8(%r11,%r10,1),%r11
 1094198:	mov    %rbx,(%rdi)
 109419b:	mov    %r11,-0x8(%rdi,%r10,1)
 10941a0:	add    %r10,%rdi
 10941a3:	inc    %r9
 10941a6:	cmp    %r9,%rdx
 10941a9:	je     10942f8 <join_short+0x598>
 10941af:	mov    %ax,(%rdi)
 10941b2:	mov    %cx,-0x2(%rdi,%r8,1)
 10941b8:	add    %r8,%rdi
 10941bb:	mov    (%rsi,%r9,8),%r11
 10941bf:	mov    0x8(%r11),%r10
 10941c3:	test   %r10,%r10
 10941c6:	je     10941a0 <join_short+0x440>
 10941c8:	testb  $0x4,0x10(%r11)
 10941cd:	jne    10941e0 <join_short+0x480>
 10941cf:	add    $0x18,%r11
 10941d3:	cmp    $0x8,%r10
 10941d7:	jae    1094190 <join_short+0x430>
 10941d9:	jmp    10941f5 <join_short+0x495>
 10941db:	nopl   0x0(%rax,%rax,1)
 10941e0:	mov    0x18(%r11),%rbx
 10941e4:	mov    0x14(%r11),%r11d
 10941e8:	add    %rbx,%r11
 10941eb:	add    $0x18,%r11
 10941ef:	cmp    $0x8,%r10
 10941f3:	jae    1094190 <join_short+0x430>
 10941f5:	cmp    $0x4,%r10
 10941f9:	jb     109420c <join_short+0x4ac>
 10941fb:	mov    (%r11),%ebx
 10941fe:	mov    -0x4(%r11,%r10,1),%r11d
 1094203:	mov    %ebx,(%rdi)
 1094205:	mov    %r11d,-0x4(%rdi,%r10,1)
 109420a:	jmp    10941a0 <join_short+0x440>
 109420c:	cmp    $0x1,%r10
 1094210:	jne    109421b <join_short+0x4bb>
 1094212:	movzbl (%r11),%r11d
 1094216:	mov    %r11b,(%rdi)
 1094219:	jmp    10941a0 <join_short+0x440>
 109421b:	movzwl (%r11),%ebx
 109421f:	movzwl -0x2(%r11,%r10,1),%r11d
 1094225:	mov    %bx,(%rdi)
 1094228:	mov    %r11w,-0x2(%rdi,%r10,1)
 109422e:	jmp    10941a0 <join_short+0x440>
 1094233:	movzwl (%r10),%r11d
 1094237:	movzwl -0x2(%r10,%r9,1),%r10d
 109423d:	mov    %r11w,(%rdi)
 1094241:	mov    %r10w,-0x2(%rdi,%r9,1)
 1094247:	jmp    1093e9d <join_short+0x13d>
 109424c:	mov    0x18(%r8),%r9
 1094250:	mov    0x14(%r8),%r8d
 1094254:	add    %r9,%r8
 1094257:	add    $0x18,%r8
 109425b:	cmp    $0x7,%rcx
 109425f:	jbe    1094273 <join_short+0x513>
 1094261:	mov    (%r8),%r9
 1094264:	mov    -0x8(%r8,%rcx,1),%r8
 1094269:	mov    %r9,(%rdi)
 109426c:	mov    %r8,-0x8(%rdi,%rcx,1)
 1094271:	jmp    10942f2 <join_short+0x592>
 1094273:	cmp    $0x3,%rcx
 1094277:	jbe    10942b6 <join_short+0x556>
 1094279:	mov    (%r8),%r9d
 109427c:	mov    -0x4(%r8,%rcx,1),%r8d
 1094281:	mov    %r9d,(%rdi)
 1094284:	mov    %r8d,-0x4(%rdi,%rcx,1)
 1094289:	jmp    10942f2 <join_short+0x592>
 109428b:	cmp    $0x1,%r9
 109428f:	jne    10942c5 <join_short+0x565>
 1094291:	movzbl (%r10),%r10d
 1094295:	mov    %r10b,(%rdi)
 1094298:	jmp    1094174 <join_short+0x414>
 109429d:	movzwl (%r10),%r11d
 10942a1:	movzwl -0x2(%r10,%r9,1),%r10d
 10942a7:	mov    %r11w,(%rdi)
 10942ab:	mov    %r10w,-0x2(%rdi,%r9,1)
 10942b1:	jmp    1093fd2 <join_short+0x272>
 10942b6:	cmp    $0x1,%rcx
 10942ba:	jne    10942de <join_short+0x57e>
 10942bc:	movzbl (%r8),%r8d
 10942c0:	mov    %r8b,(%rdi)
 10942c3:	jmp    10942f2 <join_short+0x592>
 10942c5:	movzwl (%r10),%r11d
 10942c9:	movzwl -0x2(%r10,%r9,1),%r10d
 10942cf:	mov    %r11w,(%rdi)
 10942d3:	mov    %r10w,-0x2(%rdi,%r9,1)
 10942d9:	jmp    1094174 <join_short+0x414>
 10942de:	movzwl (%r8),%r9d
 10942e2:	movzwl -0x2(%r8,%rcx,1),%r8d
 10942e8:	mov    %r9w,(%rdi)
 10942ec:	mov    %r8w,-0x2(%rdi,%rcx,1)
 10942f2:	cmp    $0x1,%rdx
 10942f6:	jne    10942fb <join_short+0x59b>
 10942f8:	pop    %rbx
 10942f9:	pop    %rbp
 10942fa:	ret
 10942fb:	add    %rcx,%rdi
 10942fe:	mov    $0x1,%ecx
 1094303:	jmp    109432b <join_short+0x5cb>
 1094305:	data16 cs nopw 0x0(%rax,%rax,1)
 1094310:	mov    (%r9),%r10
 1094313:	mov    -0x8(%r9,%r8,1),%r9
 1094318:	mov    %r10,(%rdi)
 109431b:	mov    %r9,-0x8(%rdi,%r8,1)
 1094320:	add    %r8,%rdi
 1094323:	inc    %rcx
 1094326:	cmp    %rcx,%rdx
 1094329:	je     10942f8 <join_short+0x598>
 109432b:	mov    %al,(%rdi)
 109432d:	inc    %rdi
 1094330:	mov    (%rsi,%rcx,8),%r9
 1094334:	mov    0x8(%r9),%r8
 1094338:	test   %r8,%r8
 109433b:	je     1094320 <join_short+0x5c0>
 109433d:	testb  $0x4,0x10(%r9)
 1094342:	jne    1094350 <join_short+0x5f0>
 1094344:	add    $0x18,%r9
 1094348:	cmp    $0x8,%r8
 109434c:	jae    1094310 <join_short+0x5b0>
 109434e:	jmp    1094365 <join_short+0x605>
 1094350:	mov    0x18(%r9),%r10
 1094354:	mov    0x14(%r9),%r9d
 1094358:	add    %r10,%r9
 109435b:	add    $0x18,%r9
 109435f:	cmp    $0x8,%r8
 1094363:	jae    1094310 <join_short+0x5b0>
 1094365:	cmp    $0x4,%r8
 1094369:	jb     109437d <join_short+0x61d>
 109436b:	mov    (%r9),%r10d
 109436e:	mov    -0x4(%r9,%r8,1),%r9d
 1094373:	mov    %r10d,(%rdi)
 1094376:	mov    %r9d,-0x4(%rdi,%r8,1)
 109437b:	jmp    1094320 <join_short+0x5c0>
 109437d:	cmp    $0x1,%r8
 1094381:	jne    109438c <join_short+0x62c>
 1094383:	movzbl (%r9),%r9d
 1094387:	mov    %r9b,(%rdi)
 109438a:	jmp    1094320 <join_short+0x5c0>
 109438c:	movzwl (%r9),%r10d
 1094390:	movzwl -0x2(%r9,%r8,1),%r9d
 1094396:	mov    %r10w,(%rdi)
 109439a:	mov    %r9w,-0x2(%rdi,%r8,1)
 10943a0:	jmp    1094320 <join_short+0x5c0>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
