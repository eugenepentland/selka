
.tmp-plain/controls-qbe-after:     file format elf64-x86-64


Disassembly of section .text:

0000000001008c70 <myl_f_7ab3778776cde4fa728a162a53ad3abcc967d1bd7361039e0942888240c4ce86>:
 1008c70:	f3 0f 1e fa          	endbr64
 1008c74:	55                   	push   %rbp
 1008c75:	48 89 e5             	mov    %rsp,%rbp
 1008c78:	48 81 ec a8 01 00 00 	sub    $0x1a8,%rsp
 1008c7f:	53                   	push   %rbx
 1008c80:	41 54                	push   %r12
 1008c82:	41 55                	push   %r13
 1008c84:	41 56                	push   %r14
 1008c86:	41 57                	push   %r15
 1008c88:	49 89 ce             	mov    %rcx,%r14
 1008c8b:	49 89 d5             	mov    %rdx,%r13
 1008c8e:	ba 20 00 00 00       	mov    $0x20,%edx
 1008c93:	49 89 f4             	mov    %rsi,%r12
 1008c96:	be 00 00 00 00       	mov    $0x0,%esi
 1008c9b:	48 89 fb             	mov    %rdi,%rbx
 1008c9e:	48 8d 7d 88          	lea    -0x78(%rbp),%rdi
 1008ca2:	e8 a9 a0 01 00       	call   1022d50 <compiler_rt.fastMemset>
 1008ca7:	4c 89 e6             	mov    %r12,%rsi
 1008caa:	48 89 df             	mov    %rbx,%rdi
 1008cad:	48 c7 45 b0 00 00 00 	movq   $0x0,-0x50(%rbp)
 1008cb4:	00 
 1008cb5:	48 89 75 a8          	mov    %rsi,-0x58(%rbp)
 1008cb9:	48 89 fb             	mov    %rdi,%rbx
 1008cbc:	e8 cf 52 00 00       	call   100df90 <myl_qbe_heap>
 1008cc1:	48 89 df             	mov    %rbx,%rdi
 1008cc4:	48 89 c3             	mov    %rax,%rbx
 1008cc7:	49 89 fc             	mov    %rdi,%r12
 1008cca:	e8 81 70 00 00       	call   100fd50 <myl_qbe_region_mark>
 1008ccf:	4c 89 ea             	mov    %r13,%rdx
 1008cd2:	4c 89 e7             	mov    %r12,%rdi
 1008cd5:	49 89 d5             	mov    %rdx,%r13
 1008cd8:	ba 28 00 00 00       	mov    $0x28,%edx
 1008cdd:	be 00 00 00 00       	mov    $0x0,%esi
 1008ce2:	49 89 fc             	mov    %rdi,%r12
 1008ce5:	48 8d bd 28 ff ff ff 	lea    -0xd8(%rbp),%rdi
 1008cec:	e8 5f a0 01 00       	call   1022d50 <compiler_rt.fastMemset>
 1008cf1:	4c 89 ea             	mov    %r13,%rdx
 1008cf4:	4c 89 e7             	mov    %r12,%rdi
 1008cf7:	49 89 d5             	mov    %rdx,%r13
 1008cfa:	ba a0 00 00 00       	mov    $0xa0,%edx
 1008cff:	be 00 00 00 00       	mov    $0x0,%esi
 1008d04:	49 89 fc             	mov    %rdi,%r12
 1008d07:	48 8d bd 88 fe ff ff 	lea    -0x178(%rbp),%rdi
 1008d0e:	e8 3d a0 01 00       	call   1022d50 <compiler_rt.fastMemset>
 1008d13:	4c 89 f1             	mov    %r14,%rcx
 1008d16:	4c 89 ea             	mov    %r13,%rdx
 1008d19:	4c 89 e7             	mov    %r12,%rdi
 1008d1c:	48 8d 05 9d ec 01 00 	lea    0x1ec9d(%rip),%rax        # 10279c0 <myl_t_75210166ffbb835f16670b503c826b4b943605401f2cadfc4565dc5df6dffd29>
 1008d23:	48 89 85 88 fe ff ff 	mov    %rax,-0x178(%rbp)
 1008d2a:	c7 85 a0 fe ff ff 02 	movl   $0x2,-0x160(%rbp)
 1008d31:	00 00 00 
 1008d34:	48 8d 45 a8          	lea    -0x58(%rbp),%rax
 1008d38:	48 89 85 90 fe ff ff 	mov    %rax,-0x170(%rbp)
 1008d3f:	48 8d 85 28 ff ff ff 	lea    -0xd8(%rbp),%rax
 1008d46:	48 89 85 98 fe ff ff 	mov    %rax,-0x168(%rbp)
 1008d4d:	48 8d 85 88 fe ff ff 	lea    -0x178(%rbp),%rax
 1008d54:	48 89 c6             	mov    %rax,%rsi
 1008d57:	48 83 c6 20          	add    $0x20,%rsi
 1008d5b:	48 8d 05 5e ec 01 00 	lea    0x1ec5e(%rip),%rax        # 10279c0 <myl_t_75210166ffbb835f16670b503c826b4b943605401f2cadfc4565dc5df6dffd29>
 1008d62:	48 89 85 a8 fe ff ff 	mov    %rax,-0x158(%rbp)
 1008d69:	c7 85 c0 fe ff ff 02 	movl   $0x2,-0x140(%rbp)
 1008d70:	00 00 00 
 1008d73:	48 8d 45 b0          	lea    -0x50(%rbp),%rax
 1008d77:	48 89 85 b0 fe ff ff 	mov    %rax,-0x150(%rbp)
 1008d7e:	48 8d 85 28 ff ff ff 	lea    -0xd8(%rbp),%rax
 1008d85:	48 83 c0 08          	add    $0x8,%rax
 1008d89:	48 89 85 b8 fe ff ff 	mov    %rax,-0x148(%rbp)
 1008d90:	48 8d 85 88 fe ff ff 	lea    -0x178(%rbp),%rax
 1008d97:	48 83 c0 40          	add    $0x40,%rax
 1008d9b:	48 89 45 f0          	mov    %rax,-0x10(%rbp)
 1008d9f:	48 8d 05 42 95 ff ff 	lea    -0x6abe(%rip),%rax        # 10022e8 <myl_t_385cfdbc00ec32031699460779c15099b2bba3cad0e440fffb08e10df0acb9e1>
 1008da6:	48 89 85 c8 fe ff ff 	mov    %rax,-0x138(%rbp)
 1008dad:	c7 85 e0 fe ff ff 00 	movl   $0x0,-0x120(%rbp)
 1008db4:	00 00 00 
 1008db7:	48 8d 85 50 ff ff ff 	lea    -0xb0(%rbp),%rax
 1008dbe:	48 89 85 d0 fe ff ff 	mov    %rax,-0x130(%rbp)
 1008dc5:	48 8d 85 28 ff ff ff 	lea    -0xd8(%rbp),%rax
 1008dcc:	48 83 c0 10          	add    $0x10,%rax
 1008dd0:	48 89 85 d8 fe ff ff 	mov    %rax,-0x128(%rbp)
 1008dd7:	48 8d 05 0a 95 ff ff 	lea    -0x6af6(%rip),%rax        # 10022e8 <myl_t_385cfdbc00ec32031699460779c15099b2bba3cad0e440fffb08e10df0acb9e1>
 1008dde:	48 89 85 e8 fe ff ff 	mov    %rax,-0x118(%rbp)
 1008de5:	c7 85 00 ff ff ff 00 	movl   $0x0,-0x100(%rbp)
 1008dec:	00 00 00 
 1008def:	48 8d 85 68 ff ff ff 	lea    -0x98(%rbp),%rax
 1008df6:	48 89 85 f0 fe ff ff 	mov    %rax,-0x110(%rbp)
 1008dfd:	48 8d 85 28 ff ff ff 	lea    -0xd8(%rbp),%rax
 1008e04:	48 83 c0 18          	add    $0x18,%rax
 1008e08:	48 89 85 f8 fe ff ff 	mov    %rax,-0x108(%rbp)
 1008e0f:	48 8d 05 d2 94 ff ff 	lea    -0x6b2e(%rip),%rax        # 10022e8 <myl_t_385cfdbc00ec32031699460779c15099b2bba3cad0e440fffb08e10df0acb9e1>
 1008e16:	48 89 85 08 ff ff ff 	mov    %rax,-0xf8(%rbp)
 1008e1d:	c7 85 20 ff ff ff 00 	movl   $0x0,-0xe0(%rbp)
 1008e24:	00 00 00 
 1008e27:	48 8d 45 80          	lea    -0x80(%rbp),%rax
 1008e2b:	48 89 85 10 ff ff ff 	mov    %rax,-0xf0(%rbp)
 1008e32:	48 8d 85 28 ff ff ff 	lea    -0xd8(%rbp),%rax
 1008e39:	48 83 c0 20          	add    $0x20,%rax
 1008e3d:	48 89 85 18 ff ff ff 	mov    %rax,-0xe8(%rbp)
 1008e44:	49 89 cf             	mov    %rcx,%r15
 1008e47:	b9 05 00 00 00       	mov    $0x5,%ecx
 1008e4c:	49 89 d5             	mov    %rdx,%r13
 1008e4f:	48 8d 95 88 fe ff ff 	lea    -0x178(%rbp),%rdx
 1008e56:	49 89 f6             	mov    %rsi,%r14
 1008e59:	48 8d b5 68 fe ff ff 	lea    -0x198(%rbp),%rsi
 1008e60:	49 89 fc             	mov    %rdi,%r12
 1008e63:	e8 f8 45 00 00       	call   100d460 <myl_qbe_rc_frame_enter>
 1008e68:	4c 89 f9             	mov    %r15,%rcx
 1008e6b:	4c 89 f6             	mov    %r14,%rsi
 1008e6e:	4c 89 e7             	mov    %r12,%rdi
 1008e71:	49 89 f6             	mov    %rsi,%r14
 1008e74:	48 8b 75 f0          	mov    -0x10(%rbp),%rsi
 1008e78:	48 89 4d d0          	mov    %rcx,-0x30(%rbp)
 1008e7c:	48 8b 01             	mov    (%rcx),%rax
 1008e7f:	48 89 45 b8          	mov    %rax,-0x48(%rbp)
 1008e83:	48 8b 41 08          	mov    0x8(%rcx),%rax
 1008e87:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
 1008e8b:	48 8b 41 10          	mov    0x10(%rcx),%rax
 1008e8f:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
 1008e93:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
 1008e97:	48 89 45 d0          	mov    %rax,-0x30(%rbp)
 1008e9b:	8b 85 38 ff ff ff    	mov    -0xc8(%rbp),%eax
 1008ea1:	83 f8 00             	cmp    $0x0,%eax
 1008ea4:	75 05                	jne    1008eab <myl_f_7ab3778776cde4fa728a162a53ad3abcc967d1bd7361039e0942888240c4ce86+0x23b>
 1008ea6:	4c 89 f6             	mov    %r14,%rsi
 1008ea9:	eb 0e                	jmp    1008eb9 <myl_f_7ab3778776cde4fa728a162a53ad3abcc967d1bd7361039e0942888240c4ce86+0x249>
 1008eab:	49 89 fc             	mov    %rdi,%r12
 1008eae:	e8 8d 46 00 00       	call   100d540 <myl_qbe_rc_slot_drop>
 1008eb3:	4c 89 f6             	mov    %r14,%rsi
 1008eb6:	4c 89 e7             	mov    %r12,%rdi
 1008eb9:	8b 85 30 ff ff ff    	mov    -0xd0(%rbp),%eax
 1008ebf:	83 f8 00             	cmp    $0x0,%eax
 1008ec2:	75 05                	jne    1008ec9 <myl_f_7ab3778776cde4fa728a162a53ad3abcc967d1bd7361039e0942888240c4ce86+0x259>
 1008ec4:	4c 89 ea             	mov    %r13,%rdx
 1008ec7:	eb 0e                	jmp    1008ed7 <myl_f_7ab3778776cde4fa728a162a53ad3abcc967d1bd7361039e0942888240c4ce86+0x267>
 1008ec9:	49 89 fc             	mov    %rdi,%r12
 1008ecc:	e8 6f 46 00 00       	call   100d540 <myl_qbe_rc_slot_drop>
 1008ed1:	4c 89 ea             	mov    %r13,%rdx
 1008ed4:	4c 89 e7             	mov    %r12,%rdi
 1008ed7:	48 8d 05 e2 ea 01 00 	lea    0x1eae2(%rip),%rax        # 10279c0 <myl_t_75210166ffbb835f16670b503c826b4b943605401f2cadfc4565dc5df6dffd29>
 1008ede:	48 89 85 88 fe ff ff 	mov    %rax,-0x178(%rbp)
 1008ee5:	c7 85 a0 fe ff ff 02 	movl   $0x2,-0x160(%rbp)
 1008eec:	00 00 00 
 1008eef:	48 8d 45 a8          	lea    -0x58(%rbp),%rax
 1008ef3:	48 89 85 90 fe ff ff 	mov    %rax,-0x170(%rbp)
 1008efa:	48 8d 85 28 ff ff ff 	lea    -0xd8(%rbp),%rax
 1008f01:	48 89 85 98 fe ff ff 	mov    %rax,-0x168(%rbp)
 1008f08:	48 8d 8d 28 ff ff ff 	lea    -0xd8(%rbp),%rcx
 1008f0f:	49 89 d6             	mov    %rdx,%r14
 1008f12:	48 8d 55 a8          	lea    -0x58(%rbp),%rdx
 1008f16:	48 8d 35 a3 ea 01 00 	lea    0x1eaa3(%rip),%rsi        # 10279c0 <myl_t_75210166ffbb835f16670b503c826b4b943605401f2cadfc4565dc5df6dffd29>
 1008f1d:	49 89 fc             	mov    %rdi,%r12
 1008f20:	e8 1b 4a 00 00       	call   100d940 <myl_qbe_rc_unique_local>
 1008f25:	4c 89 e7             	mov    %r12,%rdi
 1008f28:	83 f8 00             	cmp    $0x0,%eax
 1008f2b:	74 3f                	je     1008f6c <myl_f_7ab3778776cde4fa728a162a53ad3abcc967d1bd7361039e0942888240c4ce86+0x2fc>
 1008f2d:	48 8b 75 a8          	mov    -0x58(%rbp),%rsi
 1008f31:	49 89 f5             	mov    %rsi,%r13
 1008f34:	48 8d 75 88          	lea    -0x78(%rbp),%rsi
 1008f38:	49 89 fc             	mov    %rdi,%r12
 1008f3b:	e8 30 4b 00 00       	call   100da70 <myl_qbe_rc_scope_begin>
 1008f40:	4c 89 f2             	mov    %r14,%rdx
 1008f43:	4c 89 ee             	mov    %r13,%rsi
 1008f46:	4c 89 e7             	mov    %r12,%rdi
 1008f49:	49 89 d6             	mov    %rdx,%r14
 1008f4c:	48 89 f2             	mov    %rsi,%rdx
 1008f4f:	49 89 f5             	mov    %rsi,%r13
 1008f52:	48 8d 75 88          	lea    -0x78(%rbp),%rsi
 1008f56:	49 89 fc             	mov    %rdi,%r12
 1008f59:	e8 52 4b 00 00       	call   100dab0 <myl_qbe_rc_scope_pin>
 1008f5e:	4c 89 f2             	mov    %r14,%rdx
 1008f61:	4c 89 ee             	mov    %r13,%rsi
 1008f64:	4c 89 e7             	mov    %r12,%rdi
 1008f67:	83 f8 00             	cmp    $0x0,%eax
 1008f6a:	75 2b                	jne    1008f97 <myl_f_7ab3778776cde4fa728a162a53ad3abcc967d1bd7361039e0942888240c4ce86+0x327>
 1008f6c:	48 8d b5 68 fe ff ff 	lea    -0x198(%rbp),%rsi
 1008f73:	48 89 fb             	mov    %rdi,%rbx
 1008f76:	e8 f5 46 00 00       	call   100d670 <myl_qbe_rc_frame_cleanup>
 1008f7b:	48 89 df             	mov    %rbx,%rdi
 1008f7e:	48 8d b5 68 fe ff ff 	lea    -0x198(%rbp),%rsi
 1008f85:	48 89 fb             	mov    %rdi,%rbx
 1008f88:	e8 53 45 00 00       	call   100d4e0 <myl_qbe_rc_frame_leave>
 1008f8d:	b8 00 00 00 00       	mov    $0x0,%eax
 1008f92:	e9 81 00 00 00       	jmp    1009018 <myl_f_7ab3778776cde4fa728a162a53ad3abcc967d1bd7361039e0942888240c4ce86+0x3a8>
 1008f97:	48 87 fb             	xchg   %rdi,%rbx
 1008f9a:	48 89 75 b0          	mov    %rsi,-0x50(%rbp)
 1008f9e:	48 89 55 d0          	mov    %rdx,-0x30(%rbp)
 1008fa2:	48 8b 45 b8          	mov    -0x48(%rbp),%rax
 1008fa6:	48 89 45 d8          	mov    %rax,-0x28(%rbp)
 1008faa:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
 1008fae:	48 89 45 e0          	mov    %rax,-0x20(%rbp)
 1008fb2:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
 1008fb6:	48 89 45 e8          	mov    %rax,-0x18(%rbp)
 1008fba:	48 8d 4d d8          	lea    -0x28(%rbp),%rcx
 1008fbe:	48 8d 55 d0          	lea    -0x30(%rbp),%rdx
 1008fc2:	e8 f9 d0 00 00       	call   10160c0 <myl_native_dictionary_write>
 1008fc7:	48 89 df             	mov    %rbx,%rdi
 1008fca:	83 f8 00             	cmp    $0x0,%eax
 1008fcd:	75 07                	jne    1008fd6 <myl_f_7ab3778776cde4fa728a162a53ad3abcc967d1bd7361039e0942888240c4ce86+0x366>
 1008fcf:	e8 bc 4c 00 00       	call   100dc90 <myl_qbe_fail_allocation>
 1008fd4:	0f 0b                	ud2
 1008fd6:	48 c7 45 d0 00 00 00 	movq   $0x0,-0x30(%rbp)
 1008fdd:	00 
 1008fde:	48 8d 75 88          	lea    -0x78(%rbp),%rsi
 1008fe2:	48 89 fb             	mov    %rdi,%rbx
 1008fe5:	e8 96 4a 00 00       	call   100da80 <myl_qbe_rc_scope_end>
 1008fea:	48 89 df             	mov    %rbx,%rdi
 1008fed:	48 c7 45 d0 00 00 00 	movq   $0x0,-0x30(%rbp)
 1008ff4:	00 
 1008ff5:	48 8d b5 68 fe ff ff 	lea    -0x198(%rbp),%rsi
 1008ffc:	48 89 fb             	mov    %rdi,%rbx
 1008fff:	e8 6c 46 00 00       	call   100d670 <myl_qbe_rc_frame_cleanup>
 1009004:	48 89 df             	mov    %rbx,%rdi
 1009007:	48 8d b5 68 fe ff ff 	lea    -0x198(%rbp),%rsi
 100900e:	e8 cd 44 00 00       	call   100d4e0 <myl_qbe_rc_frame_leave>
 1009013:	b8 00 00 00 00       	mov    $0x0,%eax
 1009018:	41 5f                	pop    %r15
 100901a:	41 5e                	pop    %r14
 100901c:	41 5d                	pop    %r13
 100901e:	41 5c                	pop    %r12
 1009020:	5b                   	pop    %rbx
 1009021:	c9                   	leave
 1009022:	c3                   	ret

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
