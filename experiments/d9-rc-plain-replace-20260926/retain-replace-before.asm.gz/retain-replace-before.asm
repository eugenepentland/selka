
.tmp-plain/nbody-qbe-before-rc:     file format elf64-x86-64


Disassembly of section .text:

0000000001028b00 <myl_rc_native_retain_replace>:
 1028b00:	55                   	push   %rbp
 1028b01:	48 89 e5             	mov    %rsp,%rbp
 1028b04:	41 57                	push   %r15
 1028b06:	41 56                	push   %r14
 1028b08:	41 55                	push   %r13
 1028b0a:	41 54                	push   %r12
 1028b0c:	53                   	push   %rbx
 1028b0d:	48 81 ec 88 00 00 00 	sub    $0x88,%rsp
 1028b14:	48 39 ca             	cmp    %rcx,%rdx
 1028b17:	74 1e                	je     1028b37 <myl_rc_native_retain_replace+0x37>
 1028b19:	48 89 cb             	mov    %rcx,%rbx
 1028b1c:	49 89 d4             	mov    %rdx,%r12
 1028b1f:	49 89 f7             	mov    %rsi,%r15
 1028b22:	48 8b 36             	mov    (%rsi),%rsi
 1028b25:	48 81 fe 81 00 00 00 	cmp    $0x81,%rsi
 1028b2c:	73 14                	jae    1028b42 <myl_rc_native_retain_replace+0x42>
 1028b2e:	4c 8d ad 50 ff ff ff 	lea    -0xb0(%rbp),%r13
 1028b35:	eb 2b                	jmp    1028b62 <myl_rc_native_retain_replace+0x62>
 1028b37:	41 be 01 00 00 00    	mov    $0x1,%r14d
 1028b3d:	e9 91 00 00 00       	jmp    1028bd3 <myl_rc_native_retain_replace+0xd3>
 1028b42:	45 31 f6             	xor    %r14d,%r14d
 1028b45:	49 89 fd             	mov    %rdi,%r13
 1028b48:	31 d2                	xor    %edx,%edx
 1028b4a:	44 89 45 d0          	mov    %r8d,-0x30(%rbp)
 1028b4e:	e8 0d f0 ff ff       	call   1027b60 <myl_rc_storage_bytes>
 1028b53:	44 8b 45 d0          	mov    -0x30(%rbp),%r8d
 1028b57:	4c 89 ef             	mov    %r13,%rdi
 1028b5a:	49 89 c5             	mov    %rax,%r13
 1028b5d:	48 85 c0             	test   %rax,%rax
 1028b60:	74 71                	je     1028bd3 <myl_rc_native_retain_replace+0xd3>
 1028b62:	48 89 7d d0          	mov    %rdi,-0x30(%rbp)
 1028b66:	4c 89 fe             	mov    %r15,%rsi
 1028b69:	4c 89 ea             	mov    %r13,%rdx
 1028b6c:	48 89 d9             	mov    %rbx,%rcx
 1028b6f:	e8 ac fe ff ff       	call   1028a20 <myl_rc_native_retain>
 1028b74:	41 89 c6             	mov    %eax,%r14d
 1028b77:	85 c0                	test   %eax,%eax
 1028b79:	74 40                	je     1028bbb <myl_rc_native_retain_replace+0xbb>
 1028b7b:	49 83 3f 00          	cmpq   $0x0,(%r15)
 1028b7f:	74 2b                	je     1028bac <myl_rc_native_retain_replace+0xac>
 1028b81:	31 c0                	xor    %eax,%eax
 1028b83:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1028b8a:	84 00 00 00 00 00 
 1028b90:	41 0f b6 0c 04       	movzbl (%r12,%rax,1),%ecx
 1028b95:	41 0f b6 54 05 00    	movzbl 0x0(%r13,%rax,1),%edx
 1028b9b:	41 88 14 04          	mov    %dl,(%r12,%rax,1)
 1028b9f:	41 88 4c 05 00       	mov    %cl,0x0(%r13,%rax,1)
 1028ba4:	48 ff c0             	inc    %rax
 1028ba7:	49 3b 07             	cmp    (%r15),%rax
 1028baa:	72 e4                	jb     1028b90 <myl_rc_native_retain_replace+0x90>
 1028bac:	48 8b 7d d0          	mov    -0x30(%rbp),%rdi
 1028bb0:	4c 89 fe             	mov    %r15,%rsi
 1028bb3:	4c 89 ea             	mov    %r13,%rdx
 1028bb6:	e8 a5 fc ff ff       	call   1028860 <myl_rc_native_drop>
 1028bbb:	48 8d 85 50 ff ff ff 	lea    -0xb0(%rbp),%rax
 1028bc2:	49 39 c5             	cmp    %rax,%r13
 1028bc5:	74 0c                	je     1028bd3 <myl_rc_native_retain_replace+0xd3>
 1028bc7:	48 8b 7d d0          	mov    -0x30(%rbp),%rdi
 1028bcb:	4c 89 ee             	mov    %r13,%rsi
 1028bce:	e8 9d 7b ff ff       	call   1020770 <myl_rc_owner_release>
 1028bd3:	44 89 f0             	mov    %r14d,%eax
 1028bd6:	48 81 c4 88 00 00 00 	add    $0x88,%rsp
 1028bdd:	5b                   	pop    %rbx
 1028bde:	41 5c                	pop    %r12
 1028be0:	41 5d                	pop    %r13
 1028be2:	41 5e                	pop    %r14
 1028be4:	41 5f                	pop    %r15
 1028be6:	5d                   	pop    %rbp
 1028be7:	c3                   	ret

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
