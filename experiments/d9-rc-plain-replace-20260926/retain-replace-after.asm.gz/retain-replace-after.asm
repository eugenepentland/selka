
.tmp-plain/nbody-qbe-after-rc:     file format elf64-x86-64


Disassembly of section .text:

0000000001028b10 <myl_rc_native_retain_replace>:
 1028b10:	b8 01 00 00 00       	mov    $0x1,%eax
 1028b15:	48 39 ca             	cmp    %rcx,%rdx
 1028b18:	0f 84 f3 00 00 00    	je     1028c11 <myl_rc_native_retain_replace+0x101>
 1028b1e:	55                   	push   %rbp
 1028b1f:	48 89 e5             	mov    %rsp,%rbp
 1028b22:	41 57                	push   %r15
 1028b24:	41 56                	push   %r14
 1028b26:	41 55                	push   %r13
 1028b28:	41 54                	push   %r12
 1028b2a:	53                   	push   %rbx
 1028b2b:	48 81 ec 88 00 00 00 	sub    $0x88,%rsp
 1028b32:	44 89 c3             	mov    %r8d,%ebx
 1028b35:	49 89 cd             	mov    %rcx,%r13
 1028b38:	49 89 d4             	mov    %rdx,%r12
 1028b3b:	49 89 f7             	mov    %rsi,%r15
 1028b3e:	49 89 fe             	mov    %rdi,%r14
 1028b41:	e8 1a 84 ff ff       	call   1020f60 <myl_rc_descriptor_find>
 1028b46:	48 85 c0             	test   %rax,%rax
 1028b49:	74 18                	je     1028b63 <myl_rc_native_retain_replace+0x53>
 1028b4b:	83 78 78 00          	cmpl   $0x0,0x78(%rax)
 1028b4f:	75 12                	jne    1028b63 <myl_rc_native_retain_replace+0x53>
 1028b51:	49 8b 86 08 16 00 00 	mov    0x1608(%r14),%rax
 1028b58:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
 1028b5d:	0f 84 af 00 00 00    	je     1028c12 <myl_rc_native_retain_replace+0x102>
 1028b63:	89 5d d0             	mov    %ebx,-0x30(%rbp)
 1028b66:	49 8b 37             	mov    (%r15),%rsi
 1028b69:	48 81 fe 81 00 00 00 	cmp    $0x81,%rsi
 1028b70:	73 09                	jae    1028b7b <myl_rc_native_retain_replace+0x6b>
 1028b72:	48 8d 9d 50 ff ff ff 	lea    -0xb0(%rbp),%rbx
 1028b79:	eb 19                	jmp    1028b94 <myl_rc_native_retain_replace+0x84>
 1028b7b:	c7 45 d4 00 00 00 00 	movl   $0x0,-0x2c(%rbp)
 1028b82:	4c 89 f7             	mov    %r14,%rdi
 1028b85:	31 d2                	xor    %edx,%edx
 1028b87:	e8 e4 ef ff ff       	call   1027b70 <myl_rc_storage_bytes>
 1028b8c:	48 89 c3             	mov    %rax,%rbx
 1028b8f:	48 85 c0             	test   %rax,%rax
 1028b92:	74 69                	je     1028bfd <myl_rc_native_retain_replace+0xed>
 1028b94:	4c 89 f7             	mov    %r14,%rdi
 1028b97:	4c 89 fe             	mov    %r15,%rsi
 1028b9a:	48 89 da             	mov    %rbx,%rdx
 1028b9d:	4c 89 e9             	mov    %r13,%rcx
 1028ba0:	44 8b 45 d0          	mov    -0x30(%rbp),%r8d
 1028ba4:	e8 87 fe ff ff       	call   1028a30 <myl_rc_native_retain>
 1028ba9:	89 45 d4             	mov    %eax,-0x2c(%rbp)
 1028bac:	85 c0                	test   %eax,%eax
 1028bae:	74 36                	je     1028be6 <myl_rc_native_retain_replace+0xd6>
 1028bb0:	49 83 3f 00          	cmpq   $0x0,(%r15)
 1028bb4:	74 22                	je     1028bd8 <myl_rc_native_retain_replace+0xc8>
 1028bb6:	31 c0                	xor    %eax,%eax
 1028bb8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
 1028bbf:	00 
 1028bc0:	41 0f b6 0c 04       	movzbl (%r12,%rax,1),%ecx
 1028bc5:	0f b6 14 03          	movzbl (%rbx,%rax,1),%edx
 1028bc9:	41 88 14 04          	mov    %dl,(%r12,%rax,1)
 1028bcd:	88 0c 03             	mov    %cl,(%rbx,%rax,1)
 1028bd0:	48 ff c0             	inc    %rax
 1028bd3:	49 3b 07             	cmp    (%r15),%rax
 1028bd6:	72 e8                	jb     1028bc0 <myl_rc_native_retain_replace+0xb0>
 1028bd8:	4c 89 f7             	mov    %r14,%rdi
 1028bdb:	4c 89 fe             	mov    %r15,%rsi
 1028bde:	48 89 da             	mov    %rbx,%rdx
 1028be1:	e8 8a fc ff ff       	call   1028870 <myl_rc_native_drop>
 1028be6:	48 8d 85 50 ff ff ff 	lea    -0xb0(%rbp),%rax
 1028bed:	48 39 c3             	cmp    %rax,%rbx
 1028bf0:	74 0b                	je     1028bfd <myl_rc_native_retain_replace+0xed>
 1028bf2:	4c 89 f7             	mov    %r14,%rdi
 1028bf5:	48 89 de             	mov    %rbx,%rsi
 1028bf8:	e8 83 7b ff ff       	call   1020780 <myl_rc_owner_release>
 1028bfd:	8b 45 d4             	mov    -0x2c(%rbp),%eax
 1028c00:	48 81 c4 88 00 00 00 	add    $0x88,%rsp
 1028c07:	5b                   	pop    %rbx
 1028c08:	41 5c                	pop    %r12
 1028c0a:	41 5d                	pop    %r13
 1028c0c:	41 5e                	pop    %r14
 1028c0e:	41 5f                	pop    %r15
 1028c10:	5d                   	pop    %rbp
 1028c11:	c3                   	ret
 1028c12:	41 3b 5e 70          	cmp    0x70(%r14),%ebx
 1028c16:	76 11                	jbe    1028c29 <myl_rc_native_retain_replace+0x119>
 1028c18:	4c 89 f7             	mov    %r14,%rdi
 1028c1b:	be 03 00 00 00       	mov    $0x3,%esi
 1028c20:	e8 cb 76 ff ff       	call   10202f0 <myl_rc_record_failure>
 1028c25:	31 c0                	xor    %eax,%eax
 1028c27:	eb d7                	jmp    1028c00 <myl_rc_native_retain_replace+0xf0>
 1028c29:	49 8b 17             	mov    (%r15),%rdx
 1028c2c:	4c 89 e7             	mov    %r12,%rdi
 1028c2f:	4c 89 ee             	mov    %r13,%rsi
 1028c32:	e8 49 02 00 00       	call   1028e80 <compiler_rt.memmove.memmoveFast>
 1028c37:	b8 01 00 00 00       	mov    $0x1,%eax
 1028c3c:	eb c2                	jmp    1028c00 <myl_rc_native_retain_replace+0xf0>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
