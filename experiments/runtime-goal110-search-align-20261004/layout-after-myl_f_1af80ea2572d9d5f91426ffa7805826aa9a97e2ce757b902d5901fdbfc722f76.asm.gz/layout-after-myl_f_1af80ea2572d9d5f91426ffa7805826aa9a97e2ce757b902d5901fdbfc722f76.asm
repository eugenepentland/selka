
.mylang-cache/goal110-search-align/runner/bin/text-my-llvm:     file format elf64-x86-64


Disassembly of section .text:

000000000104e650 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76>:
 104e650:	push   %rbp
 104e651:	push   %r15
 104e653:	push   %r14
 104e655:	push   %r13
 104e657:	push   %r12
 104e659:	push   %rbx
 104e65a:	sub    $0x258,%rsp
 104e661:	mov    %r8,0x10(%rsp)
 104e666:	mov    %rcx,0x28(%rsp)
 104e66b:	mov    %rdi,%rbp
 104e66e:	cmp    %rsp,0x40(%rdi)
 104e672:	ja     10513f0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2da0>
 104e678:	mov    %rdx,%r15
 104e67b:	mov    %rsi,%r14
 104e67e:	movq   $0x0,0xa8(%rsp)
 104e68a:	movq   $0x0,0xa0(%rsp)
 104e696:	mov    0x2c8(%rbp),%eax
 104e69c:	mov    %eax,0x44(%rsp)
 104e6a0:	movq   $0x10b9760,0x38(%rsp)
 104e6a9:	movq   $0x10b9760,0x70(%rsp)
 104e6b2:	cmp    $0x10b9760,%rsi
 104e6b9:	jne    104e6bf <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x6f>
 104e6bb:	xor    %ebx,%ebx
 104e6bd:	jmp    104e721 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xd1>
 104e6bf:	mov    $0x1,%bl
 104e6c1:	test   %r14,%r14
 104e6c4:	je     104e721 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xd1>
 104e6c6:	mov    0x8(%r14),%rdx
 104e6ca:	cmp    0x6b097(%rip),%rdx        # 10b9768 <myl_lit_d666bf92bda1d63f03bf95c09e1bffde05f85315fdade322db024e5b0244b85a_instance+0x18>
 104e6d1:	jne    104e721 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xd1>
 104e6d3:	test   %rdx,%rdx
 104e6d6:	je     104e6bb <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x6b>
 104e6d8:	testb  $0x4,0x10(%r14)
 104e6dd:	jne    104e6e5 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x95>
 104e6df:	lea    0x18(%r14),%rdi
 104e6e3:	jmp    104e6f5 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xa5>
 104e6e5:	mov    0x18(%r14),%rax
 104e6e9:	mov    0x14(%r14),%ecx
 104e6ed:	lea    (%rax,%rcx,1),%rdi
 104e6f1:	add    $0x18,%rdi
 104e6f5:	testb  $0x4,0x6b074(%rip)        # 10b9770 <myl_lit_d666bf92bda1d63f03bf95c09e1bffde05f85315fdade322db024e5b0244b85a_instance+0x20>
 104e6fc:	mov    0x6b075(%rip),%rax        # 10b9778 <myl_lit_d666bf92bda1d63f03bf95c09e1bffde05f85315fdade322db024e5b0244b85a_instance+0x28>
 104e703:	mov    0x6b06b(%rip),%ecx        # 10b9774 <myl_lit_d666bf92bda1d63f03bf95c09e1bffde05f85315fdade322db024e5b0244b85a_instance+0x24>
 104e709:	lea    0x18(%rax,%rcx,1),%rax
 104e70e:	mov    $0x10b9778,%esi
 104e713:	cmovne %rax,%rsi
 104e717:	call   10ab400 <bcmp@plt>
 104e71c:	test   %eax,%eax
 104e71e:	setne  %bl
 104e721:	lea    0x258(%rbp),%rax
 104e728:	mov    %rax,0x18(%rsp)
 104e72d:	movabs $0x4000000000000002,%r13
 104e737:	test   %r13,0x6b012(%rip)        # 10b9750 <myl_lit_d666bf92bda1d63f03bf95c09e1bffde05f85315fdade322db024e5b0244b85a_instance>
 104e73e:	jne    104e761 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x111>
 104e740:	mov    0x6aff9(%rip),%rax        # 10b9740 <myl_lit_d3cafad273dd497c488894ca58a5701d146f3969ca50fbb18df3109543cd07e8_instance+0x60>
 104e747:	dec    %rax
 104e74a:	jne    104e75a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x10a>
 104e74c:	cmpq   $0x0,0x6aff4(%rip)        # 10b9748 <myl_lit_d3cafad273dd497c488894ca58a5701d146f3969ca50fbb18df3109543cd07e8_instance+0x68>
 104e754:	je     104e7e2 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x192>
 104e75a:	mov    %rax,0x6afdf(%rip)        # 10b9740 <myl_lit_d3cafad273dd497c488894ca58a5701d146f3969ca50fbb18df3109543cd07e8_instance+0x60>
 104e761:	movq   $0x0,0xd0(%rsp)
 104e76d:	test   %bl,%bl
 104e76f:	mov    %rbp,0x20(%rsp)
 104e774:	mov    %r15,0x30(%rsp)
 104e779:	je     104e81c <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1cc>
 104e77f:	movq   $0x10b9270,0x38(%rsp)
 104e788:	movq   $0x10b9270,0x70(%rsp)
 104e791:	movq   $0x10b9270,0xd0(%rsp)
 104e79d:	cmp    $0x10b9270,%r14
 104e7a4:	jne    104e7ad <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x15d>
 104e7a6:	xor    %ebx,%ebx
 104e7a8:	jmp    104edf1 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x7a1>
 104e7ad:	mov    $0x1,%bl
 104e7af:	test   %r14,%r14
 104e7b2:	je     104edf1 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x7a1>
 104e7b8:	mov    0x8(%r14),%rdx
 104e7bc:	cmp    0x6aab5(%rip),%rdx        # 10b9278 <myl_lit_8c12e724a44132b907ad7be4d7bffd05d284ce5c644f94f5ab8dbc188941e631_instance+0x18>
 104e7c3:	jne    104edf1 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x7a1>
 104e7c9:	test   %rdx,%rdx
 104e7cc:	je     104e7a6 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x156>
 104e7ce:	testb  $0x4,0x10(%r14)
 104e7d3:	jne    104edb5 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x765>
 104e7d9:	lea    0x18(%r14),%rdi
 104e7dd:	jmp    104edc5 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x775>
 104e7e2:	mov    $0x10b9760,%esi
 104e7e7:	lea    0x258(%rbp),%r12
 104e7ee:	mov    %r12,%rdi
 104e7f1:	call   1099c10 <myl_rc_edge_release>
 104e7f6:	movq   $0x0,0xd0(%rsp)
 104e802:	mov    %r12,%rdi
 104e805:	call   109cd90 <myl_rc_drain>
 104e80a:	test   %bl,%bl
 104e80c:	mov    %rbp,0x20(%rsp)
 104e811:	mov    %r15,0x30(%rsp)
 104e816:	jne    104e77f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x12f>
 104e81c:	movq   $0x0,0x8(%rsp)
 104e825:	movabs $0x89705f3112a28fe5,%r15
 104e82f:	movabs $0xffffffffffffff0,%r12
 104e839:	vpxor  %xmm11,%xmm11,%xmm11
 104e83e:	vmovd  -0x4cea6(%rip),%xmm12        # 10019a0 <__abi_tag+0x16a4>
 104e846:	vmovd  -0x4ce5e(%rip),%xmm13        # 10019f0 <__abi_tag+0x16f4>
 104e84e:	vmovd  -0x4ced6(%rip),%xmm14        # 1001980 <__abi_tag+0x1684>
 104e856:	vmovd  -0x4cf3e(%rip),%xmm15        # 1001920 <__abi_tag+0x1624>
 104e85e:	xor    %r14d,%r14d
 104e861:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 104e870:	mov    0x10(%rsp),%rdx
 104e875:	add    %r14,%rdx
 104e878:	jo     10512f1 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2ca1>
 104e87e:	mov    0x30(%rsp),%rax
 104e883:	mov    (%rax),%rsi
 104e886:	mov    -0x10(%rsi),%rax
 104e88a:	movabs $0x4000000000000002,%r13
 104e894:	test   %r13,%rax
 104e897:	jne    104e8aa <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x25a>
 104e899:	mov    -0x18(%rsi),%rcx
 104e89d:	inc    %rcx
 104e8a0:	je     104ed74 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x724>
 104e8a6:	mov    %rcx,-0x18(%rsi)
 104e8aa:	movzbl %dl,%r8d
 104e8ae:	mov    (%rsi),%rdi
 104e8b1:	lea    -0x10(%rdi),%r9
 104e8b5:	cmp    %r12,%r9
 104e8b8:	ja     104e8f0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2a0>
 104e8ba:	mov    0x20(%rsi),%rcx
 104e8be:	movabs $0x80808080808080,%r10
 104e8c8:	cmp    %r10,%rdi
 104e8cb:	ja     104e920 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2d0>
 104e8cd:	vmovd  %edx,%xmm0
 104e8d1:	vpbroadcastb %xmm0,%xmm0
 104e8d6:	mov    %r9d,%r8d
 104e8d9:	not    %r8d
 104e8dc:	test   $0x30,%r8b
 104e8e0:	jne    104ea58 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x408>
 104e8e6:	vpxor  %xmm1,%xmm1,%xmm1
 104e8ea:	jmp    104eaa0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x450>
 104e8ef:	nop
 104e8f0:	test   %rdi,%rdi
 104e8f3:	jle    104ea51 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x401>
 104e8f9:	mov    0x20(%rsi),%rcx
 104e8fd:	cmp    $0x8,%rdi
 104e901:	jae    104e920 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2d0>
 104e903:	mov    $0x1,%r10d
 104e909:	xor    %r9d,%r9d
 104e90c:	xor    %edx,%edx
 104e90e:	xor    %ebx,%ebx
 104e910:	jmp    104e9c7 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x377>
 104e915:	data16 cs nopw 0x0(%rax,%rax,1)
 104e920:	mov    %rdi,%rdx
 104e923:	and    $0xfffffffffffffff8,%rdx
 104e927:	vmovq  %r8,%xmm0
 104e92c:	vpbroadcastq %xmm0,%ymm3
 104e931:	vpxor  %xmm2,%xmm2,%xmm2
 104e935:	xor    %r9d,%r9d
 104e938:	vpxor  %xmm4,%xmm4,%xmm4
 104e93c:	vpxor  %xmm0,%xmm0,%xmm0
 104e940:	vpxor  %xmm1,%xmm1,%xmm1
 104e944:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 104e950:	vpmovzxbq (%rcx,%r9,1),%ymm5
 104e956:	vpmovzxbq 0x4(%rcx,%r9,1),%ymm6
 104e95d:	vpxor  %ymm5,%ymm3,%ymm5
 104e961:	vpxor  %ymm6,%ymm3,%ymm6
 104e965:	vpaddq %ymm2,%ymm5,%ymm2
 104e969:	vpaddq %ymm4,%ymm6,%ymm4
 104e96d:	vpaddq %ymm0,%ymm5,%ymm0
 104e971:	vpaddq %ymm1,%ymm6,%ymm1
 104e975:	add    $0x8,%r9
 104e979:	cmp    %r9,%rdx
 104e97c:	jne    104e950 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x300>
 104e97e:	vpaddq %ymm2,%ymm4,%ymm2
 104e982:	vextracti128 $0x1,%ymm2,%xmm3
 104e988:	vpaddq %xmm3,%xmm2,%xmm2
 104e98c:	vpshufd $0xee,%xmm2,%xmm3
 104e991:	vpaddq %xmm3,%xmm2,%xmm2
 104e995:	vmovq  %xmm2,%r9
 104e99a:	vpaddq %ymm0,%ymm1,%ymm0
 104e99e:	vextracti128 $0x1,%ymm0,%xmm1
 104e9a4:	vpaddq %xmm1,%xmm0,%xmm0
 104e9a8:	vpshufd $0xee,%xmm0,%xmm1
 104e9ad:	vpaddq %xmm1,%xmm0,%xmm0
 104e9b1:	vmovq  %xmm0,%rbx
 104e9b6:	cmp    %rdx,%rdi
 104e9b9:	jne    104e9c0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x370>
 104e9bb:	mov    %rdi,%rcx
 104e9be:	jmp    104ea01 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3b1>
 104e9c0:	mov    %rdx,%r10
 104e9c3:	or     $0x1,%r10
 104e9c7:	add    %rdx,%rcx
 104e9ca:	mov    %rdi,%r11
 104e9cd:	sub    %rdx,%r11
 104e9d0:	xor    %edx,%edx
 104e9d2:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 104e9e0:	movzbl (%rcx,%rdx,1),%ebp
 104e9e4:	xor    %r8,%rbp
 104e9e7:	add    %rbp,%r9
 104e9ea:	add    %rbp,%rbx
 104e9ed:	inc    %rdx
 104e9f0:	cmp    %rdx,%r11
 104e9f3:	jne    104e9e0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x390>
 104e9f5:	lea    (%r10,%rdx,1),%rcx
 104e9f9:	dec    %rcx
 104e9fc:	mov    0x20(%rsp),%rbp
 104ea01:	mov    $0xffffffff,%edx
 104ea06:	cmp    %rdx,%rcx
 104ea09:	setb   %cl
 104ea0c:	test   %r9,%r9
 104ea0f:	setns  %dl
 104ea12:	test   %dl,%cl
 104ea14:	jne    104ecb0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x660>
 104ea1a:	mov    0x20(%rsi),%r9
 104ea1e:	xor    %r10d,%r10d
 104ea21:	xor    %edx,%edx
 104ea23:	xor    %ebx,%ebx
 104ea25:	data16 cs nopw 0x0(%rax,%rax,1)
 104ea30:	movzbl (%r9,%r10,1),%ecx
 104ea35:	xor    %r8,%rcx
 104ea38:	add    %rcx,%rbx
 104ea3b:	jo     10512c5 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2c75>
 104ea41:	inc    %r10
 104ea44:	mov    %rbx,%rdx
 104ea47:	cmp    %r10,%rdi
 104ea4a:	jne    104ea30 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3e0>
 104ea4c:	jmp    104ecb0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x660>
 104ea51:	xor    %ebx,%ebx
 104ea53:	jmp    104ecb0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x660>
 104ea58:	mov    %r9d,%r8d
 104ea5b:	shr    $0x4,%r8d
 104ea5f:	inc    %r8d
 104ea62:	and    $0x3,%r8d
 104ea66:	vpxor  %xmm1,%xmm1,%xmm1
 104ea6a:	mov    %r8,%r10
 104ea6d:	mov    %rcx,%r11
 104ea70:	vpxor  (%r11),%xmm0,%xmm2
 104ea75:	vpsadbw %xmm2,%xmm11,%xmm2
 104ea79:	vpaddq %xmm1,%xmm2,%xmm1
 104ea7d:	add    $0x10,%r11
 104ea81:	dec    %r10
 104ea84:	jne    104ea70 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x420>
 104ea86:	shl    $0x4,%r8d
 104ea8a:	add    %r8,%rcx
 104ea8d:	sub    %r8,%rdi
 104ea90:	cmp    $0x30,%r9
 104ea94:	jb     104eae1 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x491>
 104ea96:	cs nopw 0x0(%rax,%rax,1)
 104eaa0:	vpxor  (%rcx),%xmm0,%xmm2
 104eaa4:	vpsadbw %xmm2,%xmm11,%xmm2
 104eaa8:	vpaddq %xmm1,%xmm2,%xmm1
 104eaac:	vpxor  0x10(%rcx),%xmm0,%xmm2
 104eab1:	vpsadbw %xmm2,%xmm11,%xmm2
 104eab5:	vpxor  0x20(%rcx),%xmm0,%xmm3
 104eaba:	vpsadbw %xmm3,%xmm11,%xmm3
 104eabe:	vpaddq %xmm2,%xmm3,%xmm2
 104eac2:	vpaddq %xmm1,%xmm2,%xmm1
 104eac6:	vpxor  0x30(%rcx),%xmm0,%xmm2
 104eacb:	vpsadbw %xmm2,%xmm11,%xmm2
 104eacf:	vpaddq %xmm1,%xmm2,%xmm1
 104ead3:	add    $0x40,%rcx
 104ead7:	add    $0xffffffffffffffc0,%rdi
 104eadb:	cmp    $0xf,%rdi
 104eadf:	ja     104eaa0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x450>
 104eae1:	vpshufd $0xee,%xmm1,%xmm0
 104eae6:	vpaddq %xmm0,%xmm1,%xmm0
 104eaea:	vmovq  %xmm0,%rbx
 104eaef:	test   %rdi,%rdi
 104eaf2:	je     104ecb0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x660>
 104eaf8:	mov    %rdi,%r11
 104eafb:	and    $0x3,%r11
 104eaff:	je     104eb3d <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x4ed>
 104eb01:	xor    %r8d,%r8d
 104eb04:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 104eb10:	movzbl (%rcx,%r8,1),%r9d
 104eb15:	xor    %dl,%r9b
 104eb18:	movzbl %r9b,%r9d
 104eb1c:	add    %r9,%rbx
 104eb1f:	inc    %r8
 104eb22:	cmp    %r8,%r11
 104eb25:	jne    104eb10 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x4c0>
 104eb27:	mov    %rdi,%r8
 104eb2a:	and    $0xfffffffffffffffc,%r8
 104eb2e:	lea    (%rcx,%r11,1),%r9
 104eb32:	cmp    $0x4,%rdi
 104eb36:	jae    104eb4d <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x4fd>
 104eb38:	jmp    104ecb0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x660>
 104eb3d:	mov    %rcx,%r9
 104eb40:	mov    %rdi,%r8
 104eb43:	cmp    $0x4,%rdi
 104eb47:	jb     104ecb0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x660>
 104eb4d:	lea    -0x4(%r8),%rdi
 104eb51:	cmp    $0x1c,%rdi
 104eb55:	jb     104ec70 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x620>
 104eb5b:	shr    $0x2,%rdi
 104eb5f:	inc    %rdi
 104eb62:	mov    %rdi,%r10
 104eb65:	and    $0xfffffffffffffff8,%r10
 104eb69:	lea    0x0(,%r10,4),%rbp
 104eb71:	lea    (%r9,%r10,4),%r9
 104eb75:	sub    %rbp,%r8
 104eb78:	vmovq  %rbx,%xmm1
 104eb7d:	vmovd  %edx,%xmm0
 104eb81:	vpbroadcastb %xmm0,%xmm0
 104eb86:	add    %r11,%rcx
 104eb89:	add    $0x10,%rcx
 104eb8d:	vpxor  %xmm2,%xmm2,%xmm2
 104eb91:	xor    %r11d,%r11d
 104eb94:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 104eba0:	vmovdqu -0x10(%rcx,%r11,4),%xmm3
 104eba7:	vmovdqu (%rcx,%r11,4),%xmm4
 104ebad:	vpshufb %xmm12,%xmm3,%xmm5
 104ebb2:	vpshufb %xmm13,%xmm3,%xmm6
 104ebb7:	vpshufb %xmm14,%xmm3,%xmm7
 104ebbc:	vpshufb %xmm15,%xmm3,%xmm3
 104ebc1:	vpshufb %xmm12,%xmm4,%xmm8
 104ebc6:	vpshufb %xmm13,%xmm4,%xmm9
 104ebcb:	vpshufb %xmm14,%xmm4,%xmm10
 104ebd0:	vpshufb %xmm15,%xmm4,%xmm4
 104ebd5:	vpxor  %xmm0,%xmm5,%xmm5
 104ebd9:	vpxor  %xmm0,%xmm8,%xmm8
 104ebdd:	vpmovzxbq %xmm5,%ymm5
 104ebe2:	vpaddq %ymm5,%ymm1,%ymm1
 104ebe6:	vpmovzxbq %xmm8,%ymm5
 104ebeb:	vpaddq %ymm5,%ymm2,%ymm2
 104ebef:	vpxor  %xmm0,%xmm6,%xmm5
 104ebf3:	vpxor  %xmm0,%xmm9,%xmm6
 104ebf7:	vpmovzxbq %xmm5,%ymm5
 104ebfc:	vpmovzxbq %xmm6,%ymm6
 104ec01:	vpxor  %xmm0,%xmm7,%xmm7
 104ec05:	vpxor  %xmm0,%xmm10,%xmm8
 104ec09:	vpmovzxbq %xmm7,%ymm7
 104ec0e:	vpaddq %ymm7,%ymm5,%ymm5
 104ec12:	vpaddq %ymm5,%ymm1,%ymm1
 104ec16:	vpmovzxbq %xmm8,%ymm5
 104ec1b:	vpaddq %ymm5,%ymm6,%ymm5
 104ec1f:	vpaddq %ymm5,%ymm2,%ymm2
 104ec23:	vpxor  %xmm0,%xmm3,%xmm3
 104ec27:	vpxor  %xmm0,%xmm4,%xmm4
 104ec2b:	vpmovzxbq %xmm3,%ymm3
 104ec30:	vpaddq %ymm3,%ymm1,%ymm1
 104ec34:	vpmovzxbq %xmm4,%ymm3
 104ec39:	vpaddq %ymm3,%ymm2,%ymm2
 104ec3d:	add    $0x8,%r11
 104ec41:	cmp    %r11,%r10
 104ec44:	jne    104eba0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x550>
 104ec4a:	vpaddq %ymm1,%ymm2,%ymm0
 104ec4e:	vextracti128 $0x1,%ymm0,%xmm1
 104ec54:	vpaddq %xmm1,%xmm0,%xmm0
 104ec58:	vpshufd $0xee,%xmm0,%xmm1
 104ec5d:	vpaddq %xmm1,%xmm0,%xmm0
 104ec61:	vmovq  %xmm0,%rbx
 104ec66:	cmp    %r10,%rdi
 104ec69:	mov    0x20(%rsp),%rbp
 104ec6e:	je     104ecb0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x660>
 104ec70:	vmovd  %edx,%xmm0
 104ec74:	vpbroadcastb %xmm0,%xmm0
 104ec79:	xor    %ecx,%ecx
 104ec7b:	nopl   0x0(%rax,%rax,1)
 104ec80:	vmovd  (%r9,%rcx,1),%xmm1
 104ec86:	vpxor  %xmm0,%xmm1,%xmm1
 104ec8a:	vpblendd $0x1,%xmm1,%xmm11,%xmm1
 104ec90:	vpsadbw %xmm1,%xmm11,%xmm1
 104ec94:	vmovq  %xmm1,%rdx
 104ec99:	add    %rdx,%rbx
 104ec9c:	add    $0x4,%rcx
 104eca0:	cmp    %rcx,%r8
 104eca3:	jne    104ec80 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x630>
 104eca5:	data16 cs nopw 0x0(%rax,%rax,1)
 104ecb0:	test   %r13,%rax
 104ecb3:	je     104ecc0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x670>
 104ecb5:	mov    0x8(%rsp),%r13
 104ecba:	jmp    104ecd9 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x689>
 104ecbc:	nopl   0x0(%rax)
 104ecc0:	mov    -0x18(%rsi),%rax
 104ecc4:	dec    %rax
 104ecc7:	mov    0x8(%rsp),%r13
 104eccc:	jne    104ecd5 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x685>
 104ecce:	cmpq   $0x0,-0x20(%rsi)
 104ecd3:	je     104ed2d <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x6dd>
 104ecd5:	mov    %rax,-0x18(%rsi)
 104ecd9:	mov    %r13,%rcx
 104ecdc:	add    %rbx,%rcx
 104ecdf:	jo     1051306 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2cb6>
 104ece5:	mov    %rcx,%rax
 104ece8:	imul   %r15
 104eceb:	add    %rcx,%rdx
 104ecee:	mov    %rdx,%rax
 104ecf1:	shr    $0x3f,%rax
 104ecf5:	sar    $0x1d,%rdx
 104ecf9:	add    %rax,%rdx
 104ecfc:	imul   $0x3b9aca07,%rdx,%rax
 104ed03:	sub    %rax,%rcx
 104ed06:	mov    %rcx,%rax
 104ed09:	sar    $0x3f,%rax
 104ed0d:	and    $0x3b9aca07,%eax
 104ed12:	add    %rcx,%rax
 104ed15:	mov    %rax,0x8(%rsp)
 104ed1a:	inc    %r14
 104ed1d:	cmp    0x28(%rsp),%r14
 104ed22:	jne    104e870 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x220>
 104ed28:	jmp    104eea2 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x852>
 104ed2d:	mov    0x18(%rsp),%r13
 104ed32:	mov    %r13,%rdi
 104ed35:	vzeroupper
 104ed38:	call   1099d70 <myl_rc_hold_edge_release>
 104ed3d:	mov    %r13,%rdi
 104ed40:	mov    0x8(%rsp),%r13
 104ed45:	call   109cd90 <myl_rc_drain>
 104ed4a:	vmovd  -0x4d432(%rip),%xmm15        # 1001920 <__abi_tag+0x1624>
 104ed52:	vmovd  -0x4d3da(%rip),%xmm14        # 1001980 <__abi_tag+0x1684>
 104ed5a:	vmovd  -0x4d372(%rip),%xmm13        # 10019f0 <__abi_tag+0x16f4>
 104ed62:	vmovd  -0x4d3ca(%rip),%xmm12        # 10019a0 <__abi_tag+0x16a4>
 104ed6a:	vpxor  %xmm11,%xmm11,%xmm11
 104ed6f:	jmp    104ecd9 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x689>
 104ed74:	mov    $0x1007dbf,%esi
 104ed79:	mov    %rbp,%rdi
 104ed7c:	vzeroupper
 104ed7f:	call   108a68e <fail>
 104ed84:	vmovd  -0x4d46c(%rip),%xmm15        # 1001920 <__abi_tag+0x1624>
 104ed8c:	vmovd  -0x4d414(%rip),%xmm14        # 1001980 <__abi_tag+0x1684>
 104ed94:	vmovd  -0x4d3ac(%rip),%xmm13        # 10019f0 <__abi_tag+0x16f4>
 104ed9c:	vmovd  -0x4d404(%rip),%xmm12        # 10019a0 <__abi_tag+0x16a4>
 104eda4:	vpxor  %xmm11,%xmm11,%xmm11
 104eda9:	xor    %ebx,%ebx
 104edab:	mov    0x8(%rsp),%r13
 104edb0:	jmp    104ecd9 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x689>
 104edb5:	mov    0x18(%r14),%rax
 104edb9:	mov    0x14(%r14),%ecx
 104edbd:	lea    (%rax,%rcx,1),%rdi
 104edc1:	add    $0x18,%rdi
 104edc5:	testb  $0x4,0x6a4b4(%rip)        # 10b9280 <myl_lit_8c12e724a44132b907ad7be4d7bffd05d284ce5c644f94f5ab8dbc188941e631_instance+0x20>
 104edcc:	mov    0x6a4b5(%rip),%rax        # 10b9288 <myl_lit_8c12e724a44132b907ad7be4d7bffd05d284ce5c644f94f5ab8dbc188941e631_instance+0x28>
 104edd3:	mov    0x6a4ab(%rip),%ecx        # 10b9284 <myl_lit_8c12e724a44132b907ad7be4d7bffd05d284ce5c644f94f5ab8dbc188941e631_instance+0x24>
 104edd9:	lea    0x18(%rax,%rcx,1),%rax
 104edde:	mov    $0x10b9288,%esi
 104ede3:	cmovne %rax,%rsi
 104ede7:	call   10ab400 <bcmp@plt>
 104edec:	test   %eax,%eax
 104edee:	setne  %bl
 104edf1:	test   %r13,0x6a468(%rip)        # 10b9260 <myl_lit_8c12e724a44132b907ad7be4d7bffd05d284ce5c644f94f5ab8dbc188941e631_instance>
 104edf8:	je     104ee27 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x7d7>
 104edfa:	test   %bl,%bl
 104edfc:	je     104ee4c <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x7fc>
 104edfe:	movq   $0x10b90c0,0x70(%rsp)
 104ee07:	movq   $0x10b90c0,0xd0(%rsp)
 104ee13:	cmp    $0x10b90c0,%r14
 104ee1a:	jne    104eebc <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x86c>
 104ee20:	xor    %ebx,%ebx
 104ee22:	jmp    104f0d6 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xa86>
 104ee27:	mov    0x6a422(%rip),%rax        # 10b9250 <myl_lit_842ab9229ccb9156d5ed82c31992b7b48b2d840046545e9d568e989652f87fd6_instance+0x20>
 104ee2e:	dec    %rax
 104ee31:	jne    104ee41 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x7f1>
 104ee33:	cmpq   $0x0,0x6a41d(%rip)        # 10b9258 <myl_lit_842ab9229ccb9156d5ed82c31992b7b48b2d840046545e9d568e989652f87fd6_instance+0x28>
 104ee3b:	je     104f079 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xa29>
 104ee41:	mov    %rax,0x6a408(%rip)        # 10b9250 <myl_lit_842ab9229ccb9156d5ed82c31992b7b48b2d840046545e9d568e989652f87fd6_instance+0x20>
 104ee48:	test   %bl,%bl
 104ee4a:	jne    104edfe <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x7ae>
 104ee4c:	mov    0x8(%r15),%rax
 104ee50:	mov    0x10(%rsp),%rsi
 104ee55:	and    $0x3,%esi
 104ee58:	mov    (%rax),%rdx
 104ee5b:	cmp    %rdx,%rsi
 104ee5e:	jae    1051319 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2cc9>
 104ee64:	mov    0x10(%r15),%rcx
 104ee68:	mov    (%rcx),%rdx
 104ee6b:	cmp    %rdx,%rsi
 104ee6e:	jae    1051323 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2cd3>
 104ee74:	mov    0x20(%rax),%rax
 104ee78:	shl    $0x3,%esi
 104ee7b:	mov    (%rax,%rsi,1),%rdi
 104ee7f:	mov    0x20(%rcx),%rax
 104ee83:	mov    (%rax,%rsi,1),%rsi
 104ee87:	mov    $0x1,%ecx
 104ee8c:	cmp    %rsi,%rdi
 104ee8f:	jne    104eef5 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x8a5>
 104ee91:	mov    %rcx,0x8(%rsp)
 104ee96:	cmpq   $0x1,0x28(%rsp)
 104ee9c:	jne    104ef30 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x8e0>
 104eea2:	mov    0x8(%rsp),%rax
 104eea7:	add    $0x258,%rsp
 104eeae:	pop    %rbx
 104eeaf:	pop    %r12
 104eeb1:	pop    %r13
 104eeb3:	pop    %r14
 104eeb5:	pop    %r15
 104eeb7:	pop    %rbp
 104eeb8:	vzeroupper
 104eebb:	ret
 104eebc:	mov    $0x1,%bl
 104eebe:	test   %r14,%r14
 104eec1:	je     104f0d6 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xa86>
 104eec7:	mov    0x8(%r14),%rdx
 104eecb:	cmp    0x6a1f6(%rip),%rdx        # 10b90c8 <myl_lit_7afa21b5dfd0bec52f3c46b131c861acf738a60d12be67523b48ae28324a1934_instance+0x18>
 104eed2:	jne    104f0d6 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xa86>
 104eed8:	test   %rdx,%rdx
 104eedb:	je     104ee20 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x7d0>
 104eee1:	testb  $0x4,0x10(%r14)
 104eee6:	jne    104f09a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xa4a>
 104eeec:	lea    0x18(%r14),%rdi
 104eef0:	jmp    104f0aa <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xa5a>
 104eef5:	xor    %ecx,%ecx
 104eef7:	test   %rdi,%rdi
 104eefa:	je     104ee91 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x841>
 104eefc:	test   %rsi,%rsi
 104eeff:	je     104ee91 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x841>
 104ef01:	mov    0x8(%rdi),%rdx
 104ef05:	cmp    0x8(%rsi),%rdx
 104ef09:	jne    104f072 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xa22>
 104ef0f:	mov    $0x1,%ecx
 104ef14:	test   %rdx,%rdx
 104ef17:	je     104ee91 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x841>
 104ef1d:	testb  $0x4,0x10(%rdi)
 104ef21:	jne    104f364 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xd14>
 104ef27:	add    $0x18,%rdi
 104ef2b:	jmp    104f373 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xd23>
 104ef30:	mov    $0x1,%ebx
 104ef35:	movabs $0x89705f3112a28fe5,%r14
 104ef3f:	jmp    104ef98 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x948>
 104ef41:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 104ef50:	xor    %ecx,%ecx
 104ef52:	add    %rcx,%r15
 104ef55:	mov    %r15,%rax
 104ef58:	imul   %r14
 104ef5b:	add    %r15,%rdx
 104ef5e:	mov    %rdx,%rax
 104ef61:	shr    $0x3f,%rax
 104ef65:	sar    $0x1d,%rdx
 104ef69:	add    %rax,%rdx
 104ef6c:	imul   $0x3b9aca07,%rdx,%rax
 104ef73:	sub    %rax,%r15
 104ef76:	mov    %r15,%rax
 104ef79:	sar    $0x3f,%rax
 104ef7d:	and    $0x3b9aca07,%eax
 104ef82:	add    %rax,%r15
 104ef85:	mov    %r15,0x8(%rsp)
 104ef8a:	inc    %rbx
 104ef8d:	cmp    %rbx,0x28(%rsp)
 104ef92:	je     104eea2 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x852>
 104ef98:	mov    0x10(%rsp),%rsi
 104ef9d:	add    %rbx,%rsi
 104efa0:	jo     105132d <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2cdd>
 104efa6:	mov    0x30(%rsp),%rcx
 104efab:	mov    0x8(%rcx),%rax
 104efaf:	and    $0x3,%esi
 104efb2:	mov    (%rax),%rdx
 104efb5:	cmp    %rdx,%rsi
 104efb8:	mov    0x8(%rsp),%r15
 104efbd:	jae    1051319 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2cc9>
 104efc3:	mov    0x10(%rcx),%rcx
 104efc7:	mov    (%rcx),%rdx
 104efca:	cmp    %rdx,%rsi
 104efcd:	jae    1051323 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2cd3>
 104efd3:	mov    0x20(%rax),%rax
 104efd7:	shl    $0x3,%esi
 104efda:	mov    (%rax,%rsi,1),%rdi
 104efde:	mov    0x20(%rcx),%rax
 104efe2:	mov    (%rax,%rsi,1),%rsi
 104efe6:	mov    $0x1,%ecx
 104efeb:	cmp    %rsi,%rdi
 104efee:	je     104ef52 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x902>
 104eff4:	test   %rdi,%rdi
 104eff7:	je     104ef50 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x900>
 104effd:	mov    $0x0,%ecx
 104f002:	test   %rsi,%rsi
 104f005:	je     104ef52 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x902>
 104f00b:	mov    0x8(%rdi),%rdx
 104f00f:	cmp    0x8(%rsi),%rdx
 104f013:	jne    104ef50 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x900>
 104f019:	mov    $0x1,%ecx
 104f01e:	test   %rdx,%rdx
 104f021:	je     104ef52 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x902>
 104f027:	testb  $0x4,0x10(%rdi)
 104f02b:	jne    104f048 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x9f8>
 104f02d:	add    $0x18,%rdi
 104f031:	testb  $0x4,0x10(%rsi)
 104f035:	je     104f05d <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xa0d>
 104f037:	mov    0x18(%rsi),%rax
 104f03b:	mov    0x14(%rsi),%ecx
 104f03e:	lea    (%rax,%rcx,1),%rsi
 104f042:	add    $0x18,%rsi
 104f046:	jmp    104f061 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xa11>
 104f048:	mov    0x18(%rdi),%rax
 104f04c:	mov    0x14(%rdi),%ecx
 104f04f:	lea    (%rax,%rcx,1),%rdi
 104f053:	add    $0x18,%rdi
 104f057:	testb  $0x4,0x10(%rsi)
 104f05b:	jne    104f037 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x9e7>
 104f05d:	add    $0x18,%rsi
 104f061:	call   10ab400 <bcmp@plt>
 104f066:	xor    %ecx,%ecx
 104f068:	test   %eax,%eax
 104f06a:	sete   %cl
 104f06d:	jmp    104ef52 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x902>
 104f072:	xor    %ecx,%ecx
 104f074:	jmp    104ee91 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x841>
 104f079:	lea    0xd0(%rsp),%rsi
 104f081:	lea    0x258(%rbp),%rdi
 104f088:	call   1086140 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop>
 104f08d:	test   %bl,%bl
 104f08f:	jne    104edfe <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x7ae>
 104f095:	jmp    104ee4c <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x7fc>
 104f09a:	mov    0x18(%r14),%rax
 104f09e:	mov    0x14(%r14),%ecx
 104f0a2:	lea    (%rax,%rcx,1),%rdi
 104f0a6:	add    $0x18,%rdi
 104f0aa:	testb  $0x4,0x6a01f(%rip)        # 10b90d0 <myl_lit_7afa21b5dfd0bec52f3c46b131c861acf738a60d12be67523b48ae28324a1934_instance+0x20>
 104f0b1:	mov    0x6a020(%rip),%rax        # 10b90d8 <myl_lit_7afa21b5dfd0bec52f3c46b131c861acf738a60d12be67523b48ae28324a1934_instance+0x28>
 104f0b8:	mov    0x6a016(%rip),%ecx        # 10b90d4 <myl_lit_7afa21b5dfd0bec52f3c46b131c861acf738a60d12be67523b48ae28324a1934_instance+0x24>
 104f0be:	lea    0x18(%rax,%rcx,1),%rax
 104f0c3:	mov    $0x10b90d8,%esi
 104f0c8:	cmovne %rax,%rsi
 104f0cc:	call   10ab400 <bcmp@plt>
 104f0d1:	test   %eax,%eax
 104f0d3:	setne  %bl
 104f0d6:	test   %r13,0x69fd3(%rip)        # 10b90b0 <myl_lit_7afa21b5dfd0bec52f3c46b131c861acf738a60d12be67523b48ae28324a1934_instance>
 104f0dd:	je     104f115 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xac5>
 104f0df:	test   %bl,%bl
 104f0e1:	je     104f13a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xaea>
 104f0e3:	movq   $0x10b8d48,0x38(%rsp)
 104f0ec:	movq   $0x10b8d48,0x70(%rsp)
 104f0f5:	movq   $0x10b8d48,0xd0(%rsp)
 104f101:	cmp    $0x10b8d48,%r14
 104f108:	jne    104f311 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xcc1>
 104f10e:	xor    %ebx,%ebx
 104f110:	jmp    104f3db <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xd8b>
 104f115:	mov    0x69f84(%rip),%rax        # 10b90a0 <myl_lit_7a43bb86b2bccf6ad7e922d1f9ee2e9c1abbad0e5e2f1aa80d1ed73fc964ae92_instance+0x20>
 104f11c:	dec    %rax
 104f11f:	jne    104f12f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xadf>
 104f121:	cmpq   $0x0,0x69f7f(%rip)        # 10b90a8 <myl_lit_7a43bb86b2bccf6ad7e922d1f9ee2e9c1abbad0e5e2f1aa80d1ed73fc964ae92_instance+0x28>
 104f129:	je     104f343 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xcf3>
 104f12f:	mov    %rax,0x69f6a(%rip)        # 10b90a0 <myl_lit_7a43bb86b2bccf6ad7e922d1f9ee2e9c1abbad0e5e2f1aa80d1ed73fc964ae92_instance+0x20>
 104f136:	test   %bl,%bl
 104f138:	jne    104f0e3 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xa93>
 104f13a:	movq   $0x0,0x8(%rsp)
 104f143:	movabs $0x89705f3112a28fe5,%r13
 104f14d:	xor    %ebx,%ebx
 104f14f:	nop
 104f150:	mov    0x10(%rsp),%rsi
 104f155:	add    %rbx,%rsi
 104f158:	jo     105133f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2cef>
 104f15e:	mov    0x30(%rsp),%rcx
 104f163:	mov    0x8(%rcx),%rax
 104f167:	cmpq   $0x0,(%rax)
 104f16b:	je     1051351 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2d01>
 104f171:	mov    0x20(%rax),%rax
 104f175:	mov    (%rax),%r14
 104f178:	test   %r14,%r14
 104f17b:	je     104f19e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xb4e>
 104f17d:	movabs $0x4000000000000002,%rax
 104f187:	test   %rax,-0x10(%r14)
 104f18b:	jne    104f19e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xb4e>
 104f18d:	mov    -0x18(%r14),%rax
 104f191:	inc    %rax
 104f194:	je     1050d19 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x26c9>
 104f19a:	mov    %rax,-0x18(%r14)
 104f19e:	mov    %r14,0x70(%rsp)
 104f1a3:	mov    0x10(%rcx),%rax
 104f1a7:	and    $0x3,%esi
 104f1aa:	mov    (%rax),%rdx
 104f1ad:	cmp    %rdx,%rsi
 104f1b0:	jae    105135d <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2d0d>
 104f1b6:	mov    0x20(%rax),%rax
 104f1ba:	mov    (%rax,%rsi,8),%rax
 104f1be:	mov    (%rax),%rcx
 104f1c1:	test   %rcx,%rcx
 104f1c4:	je     104f200 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xbb0>
 104f1c6:	mov    $0xffffffffffffffff,%r15
 104f1cd:	cmp    (%r14),%rcx
 104f1d0:	ja     104f250 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xc00>
 104f1d2:	mov    0x10(%r14),%ebp
 104f1d6:	test   $0x4,%bpl
 104f1da:	jne    104f205 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xbb5>
 104f1dc:	lea    0x18(%r14),%rdi
 104f1e0:	testb  $0x4,0x10(%rax)
 104f1e4:	je     104f21b <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xbcb>
 104f1e6:	mov    0x18(%rax),%rcx
 104f1ea:	mov    0x14(%rax),%edx
 104f1ed:	add    %rcx,%rdx
 104f1f0:	add    $0x18,%rdx
 104f1f4:	jmp    104f21f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xbcf>
 104f1f6:	cs nopw 0x0(%rax,%rax,1)
 104f200:	xor    %r15d,%r15d
 104f203:	jmp    104f250 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xc00>
 104f205:	mov    0x18(%r14),%rcx
 104f209:	mov    0x14(%r14),%edx
 104f20d:	lea    (%rcx,%rdx,1),%rdi
 104f211:	add    $0x18,%rdi
 104f215:	testb  $0x4,0x10(%rax)
 104f219:	jne    104f1e6 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xb96>
 104f21b:	lea    0x18(%rax),%rdx
 104f21f:	mov    0x8(%r14),%rsi
 104f223:	mov    0x8(%rax),%rcx
 104f227:	call   1091d80 <myl_native_octets_find>
 104f22c:	cmp    $0xffffffffffffffff,%rax
 104f230:	je     104f250 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xc00>
 104f232:	test   $0x1,%bpl
 104f236:	jne    104f243 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xbf3>
 104f238:	mov    %r14,%rdi
 104f23b:	mov    %rax,%rsi
 104f23e:	call   108f770 <index_walk>
 104f243:	mov    %rax,%r15
 104f246:	cs nopw 0x0(%rax,%rax,1)
 104f250:	mov    %r15,%r12
 104f253:	inc    %r12
 104f256:	jo     1051365 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2d15>
 104f25c:	test   %r14,%r14
 104f25f:	mov    0x20(%rsp),%rbp
 104f264:	je     104f28a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xc3a>
 104f266:	movabs $0x4000000000000002,%rax
 104f270:	test   %rax,-0x10(%r14)
 104f274:	jne    104f28a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xc3a>
 104f276:	mov    -0x18(%r14),%rax
 104f27a:	dec    %rax
 104f27d:	jne    104f286 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xc36>
 104f27f:	cmpq   $0x0,-0x20(%r14)
 104f284:	je     104f2df <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xc8f>
 104f286:	mov    %rax,-0x18(%r14)
 104f28a:	mov    0x8(%rsp),%rdx
 104f28f:	mov    %rdx,%rcx
 104f292:	add    %r12,%rcx
 104f295:	jo     104f304 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xcb4>
 104f297:	mov    %rcx,%rax
 104f29a:	imul   %r13
 104f29d:	add    %rcx,%rdx
 104f2a0:	mov    %rdx,%rax
 104f2a3:	shr    $0x3f,%rax
 104f2a7:	sar    $0x1d,%rdx
 104f2ab:	add    %rax,%rdx
 104f2ae:	imul   $0x3b9aca07,%rdx,%rax
 104f2b5:	sub    %rax,%rcx
 104f2b8:	mov    %rcx,%rax
 104f2bb:	sar    $0x3f,%rax
 104f2bf:	and    $0x3b9aca07,%eax
 104f2c4:	add    %rcx,%rax
 104f2c7:	mov    %rax,0x8(%rsp)
 104f2cc:	inc    %rbx
 104f2cf:	cmp    %rbx,0x28(%rsp)
 104f2d4:	jne    104f150 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xb00>
 104f2da:	jmp    104eea2 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x852>
 104f2df:	mov    0x18(%rsp),%r15
 104f2e4:	mov    %r15,%rdi
 104f2e7:	mov    %r14,%rsi
 104f2ea:	call   1099d70 <myl_rc_hold_edge_release>
 104f2ef:	mov    %r15,%rdi
 104f2f2:	call   109cd90 <myl_rc_drain>
 104f2f7:	mov    0x8(%rsp),%rdx
 104f2fc:	mov    %rdx,%rcx
 104f2ff:	add    %r12,%rcx
 104f302:	jno    104f297 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xc47>
 104f304:	mov    %rbp,%rdi
 104f307:	xor    %esi,%esi
 104f309:	mov    %r12,%rcx
 104f30c:	call   108b0a0 <myl_qbe_fail_overflow_op>
 104f311:	mov    $0x1,%bl
 104f313:	test   %r14,%r14
 104f316:	je     104f3db <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xd8b>
 104f31c:	mov    0x8(%r14),%rdx
 104f320:	cmp    0x69a29(%rip),%rdx        # 10b8d50 <myl_lit_4d6ff6f7284ab5ea56c67ebc627dbe0fd0bb153a04fdd105bd867658d486b6d7_instance+0x18>
 104f327:	jne    104f3db <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xd8b>
 104f32d:	test   %rdx,%rdx
 104f330:	je     104f10e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xabe>
 104f336:	testb  $0x4,0x10(%r14)
 104f33b:	jne    104f39f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xd4f>
 104f33d:	lea    0x18(%r14),%rdi
 104f341:	jmp    104f3af <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xd5f>
 104f343:	lea    0xd0(%rsp),%rsi
 104f34b:	lea    0x258(%rbp),%rdi
 104f352:	call   1086140 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop>
 104f357:	test   %bl,%bl
 104f359:	jne    104f0e3 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xa93>
 104f35f:	jmp    104f13a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xaea>
 104f364:	mov    0x18(%rdi),%rax
 104f368:	mov    0x14(%rdi),%ecx
 104f36b:	lea    (%rax,%rcx,1),%rdi
 104f36f:	add    $0x18,%rdi
 104f373:	testb  $0x4,0x10(%rsi)
 104f377:	jne    104f37f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xd2f>
 104f379:	add    $0x18,%rsi
 104f37d:	jmp    104f38e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xd3e>
 104f37f:	mov    0x18(%rsi),%rax
 104f383:	mov    0x14(%rsi),%ecx
 104f386:	lea    (%rax,%rcx,1),%rsi
 104f38a:	add    $0x18,%rsi
 104f38e:	call   10ab400 <bcmp@plt>
 104f393:	xor    %ecx,%ecx
 104f395:	test   %eax,%eax
 104f397:	sete   %cl
 104f39a:	jmp    104ee91 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x841>
 104f39f:	mov    0x18(%r14),%rax
 104f3a3:	mov    0x14(%r14),%ecx
 104f3a7:	lea    (%rax,%rcx,1),%rdi
 104f3ab:	add    $0x18,%rdi
 104f3af:	testb  $0x4,0x699a2(%rip)        # 10b8d58 <myl_lit_4d6ff6f7284ab5ea56c67ebc627dbe0fd0bb153a04fdd105bd867658d486b6d7_instance+0x20>
 104f3b6:	mov    0x699a3(%rip),%rax        # 10b8d60 <myl_lit_4d6ff6f7284ab5ea56c67ebc627dbe0fd0bb153a04fdd105bd867658d486b6d7_instance+0x28>
 104f3bd:	mov    0x69999(%rip),%ecx        # 10b8d5c <myl_lit_4d6ff6f7284ab5ea56c67ebc627dbe0fd0bb153a04fdd105bd867658d486b6d7_instance+0x24>
 104f3c3:	lea    0x18(%rax,%rcx,1),%rax
 104f3c8:	mov    $0x10b8d60,%esi
 104f3cd:	cmovne %rax,%rsi
 104f3d1:	call   10ab400 <bcmp@plt>
 104f3d6:	test   %eax,%eax
 104f3d8:	setne  %bl
 104f3db:	test   %r13,0x69956(%rip)        # 10b8d38 <myl_lit_4d6ff6f7284ab5ea56c67ebc627dbe0fd0bb153a04fdd105bd867658d486b6d7_instance>
 104f3e2:	je     104f815 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x11c5>
 104f3e8:	test   %bl,%bl
 104f3ea:	je     104f83e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x11ee>
 104f3f0:	movq   $0x10b8c10,0x70(%rsp)
 104f3f9:	movq   $0x10b8c10,0xd0(%rsp)
 104f405:	mov    $0x10b8c10,%esi
 104f40a:	mov    %r14,%rdi
 104f40d:	call   1091cd0 <myl_native_text_equal>
 104f412:	test   %r13,0x697e7(%rip)        # 10b8c00 <myl_lit_4a11bea7b5a6ce8d077c05a11569e05d5d64f10b6601437976e3917dc8273132_instance>
 104f419:	jne    104f43c <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xdec>
 104f41b:	mov    0x697ce(%rip),%rcx        # 10b8bf0 <myl_lit_49ddcee716aac9f3632795416226e674fb40f0332dabf1de33fc7f8b34af0696_instance+0x38>
 104f422:	dec    %rcx
 104f425:	jne    104f435 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xde5>
 104f427:	cmpq   $0x0,0x697c9(%rip)        # 10b8bf8 <myl_lit_49ddcee716aac9f3632795416226e674fb40f0332dabf1de33fc7f8b34af0696_instance+0x40>
 104f42f:	je     1050a4a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x23fa>
 104f435:	mov    %rcx,0x697b4(%rip)        # 10b8bf0 <myl_lit_49ddcee716aac9f3632795416226e674fb40f0332dabf1de33fc7f8b34af0696_instance+0x38>
 104f43c:	test   %eax,%eax
 104f43e:	je     1050a6a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x241a>
 104f444:	lea    0x48(%rsp),%r14
 104f449:	lea    0x70(%rsp),%rcx
 104f44e:	mov    %rcx,%rax
 104f451:	sub    %r14,%rax
 104f454:	sub    %rcx,%r14
 104f457:	cmovb  %rax,%r14
 104f45b:	movabs $0x5000000000000000,%rax
 104f465:	xor    %r15d,%r15d
 104f468:	inc    %rax
 104f46b:	mov    %rax,0x50(%rsp)
 104f470:	movq   $0x0,0x8(%rsp)
 104f479:	nopl   0x0(%rax)
 104f480:	mov    0x10(%rsp),%rax
 104f485:	add    %r15,%rax
 104f488:	jo     105140d <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2dbd>
 104f48e:	test   $0x1,%al
 104f490:	movabs $0x4000000000000002,%rbx
 104f49a:	jne    104f520 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xed0>
 104f4a0:	movq   $0x10b9a60,0x70(%rsp)
 104f4a9:	movq   $0x10b9a60,0x1c8(%rsp)
 104f4b5:	movq   $0x10b9a60,0x48(%rsp)
 104f4be:	mov    0x6a58b(%rip),%rax        # 10b9a50 <myl_lit_f3eaad558815542caf7da2bdfda9d4cabeaf9c2200b79ab8ff85b21b8470fac6_instance>
 104f4c5:	test   %rax,0x50(%rsp)
 104f4ca:	je     104f5ca <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xf7a>
 104f4d0:	test   %r14,%r14
 104f4d3:	sete   %cl
 104f4d6:	movabs $0x5000000000000000,%rdx
 104f4e0:	test   %rdx,%rax
 104f4e3:	setne  %al
 104f4e6:	or     %cl,%al
 104f4e8:	je     104f5e6 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xf96>
 104f4ee:	mov    $0x1030c78,%esi
 104f4f3:	lea    0x258(%rbp),%rdi
 104f4fa:	lea    0x70(%rsp),%rdx
 104f4ff:	lea    0x48(%rsp),%rcx
 104f504:	mov    0x44(%rsp),%r8d
 104f509:	call   10a61b0 <myl_rc_native_take>
 104f50e:	test   %eax,%eax
 104f510:	jne    104f596 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xf46>
 104f516:	jmp    10509de <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x238e>
 104f51b:	nopl   0x0(%rax,%rax,1)
 104f520:	movq   $0x10b8dd0,0x70(%rsp)
 104f529:	movq   $0x10b8dd0,0x1c8(%rsp)
 104f535:	movq   $0x10b8dd0,0x48(%rsp)
 104f53e:	mov    0x6987b(%rip),%rax        # 10b8dc0 <myl_lit_54807ae7ae90f7f8ab8705f04b17dcd2d77e7355f27b7f7252156b0c234f7d3f_instance>
 104f545:	test   %rax,0x50(%rsp)
 104f54a:	je     104f614 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xfc4>
 104f550:	test   %r14,%r14
 104f553:	sete   %cl
 104f556:	movabs $0x5000000000000000,%rdx
 104f560:	test   %rdx,%rax
 104f563:	setne  %al
 104f566:	or     %cl,%al
 104f568:	je     104f60b <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xfbb>
 104f56e:	mov    $0x1030c78,%esi
 104f573:	lea    0x258(%rbp),%rdi
 104f57a:	lea    0x70(%rsp),%rdx
 104f57f:	lea    0x48(%rsp),%rcx
 104f584:	mov    0x44(%rsp),%r8d
 104f589:	call   10a61b0 <myl_rc_native_take>
 104f58e:	test   %eax,%eax
 104f590:	je     1050a14 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x23c4>
 104f596:	mov    0x70(%rsp),%r12
 104f59b:	mov    %r12,0xa8(%rsp)
 104f5a3:	mov    %r12,0x48(%rsp)
 104f5a8:	test   %r12,%r12
 104f5ab:	je     104f7a4 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1154>
 104f5b1:	test   %rbx,-0x10(%r12)
 104f5b6:	je     104f62e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xfde>
 104f5b8:	mov    %r12,0x70(%rsp)
 104f5bd:	mov    %r12,0xa0(%rsp)
 104f5c5:	jmp    104f669 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1019>
 104f5ca:	mov    $0x10b9a60,%r12d
 104f5d0:	mov    %r12,0xa8(%rsp)
 104f5d8:	mov    %r12,0x48(%rsp)
 104f5dd:	test   %rbx,-0x10(%r12)
 104f5e2:	jne    104f5b8 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xf68>
 104f5e4:	jmp    104f62e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xfde>
 104f5e6:	movq   $0x10b9a60,0x70(%rsp)
 104f5ef:	mov    $0x10b9a60,%r12d
 104f5f5:	mov    %r12,0xa8(%rsp)
 104f5fd:	mov    %r12,0x48(%rsp)
 104f602:	test   %rbx,-0x10(%r12)
 104f607:	jne    104f5b8 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xf68>
 104f609:	jmp    104f62e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xfde>
 104f60b:	movq   $0x10b8dd0,0x70(%rsp)
 104f614:	mov    $0x10b8dd0,%r12d
 104f61a:	mov    %r12,0xa8(%rsp)
 104f622:	mov    %r12,0x48(%rsp)
 104f627:	test   %rbx,-0x10(%r12)
 104f62c:	jne    104f5b8 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xf68>
 104f62e:	mov    -0x18(%r12),%rax
 104f633:	inc    %rax
 104f636:	je     1050d19 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x26c9>
 104f63c:	mov    %rax,-0x18(%r12)
 104f641:	mov    %r12,0x70(%rsp)
 104f646:	mov    %r12,0xa0(%rsp)
 104f64e:	mov    -0x20(%r12),%rax
 104f653:	dec    %rax
 104f656:	jne    104f664 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1014>
 104f658:	cmpq   $0x0,-0x18(%r12)
 104f65e:	je     104f7e3 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1193>
 104f664:	mov    %rax,-0x20(%r12)
 104f669:	movq   $0x0,0xa8(%rsp)
 104f675:	mov    0x30(%rsp),%rax
 104f67a:	mov    0x20(%rax),%rdx
 104f67e:	lea    0x258(%rbp),%rdi
 104f685:	mov    %r12,%rsi
 104f688:	call   1092090 <myl_native_text_join>
 104f68d:	test   %rax,%rax
 104f690:	je     10513f8 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2da8>
 104f696:	mov    %rax,%rbx
 104f699:	mov    %rax,0x48(%rsp)
 104f69e:	mov    %rax,0x70(%rsp)
 104f6a3:	mov    %rax,0x1c8(%rsp)
 104f6ab:	mov    %rbp,%rdi
 104f6ae:	mov    %rax,%rsi
 104f6b1:	call   10740a0 <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85>
 104f6b6:	mov    %rax,%r13
 104f6b9:	movabs $0x4000000000000002,%rax
 104f6c3:	test   %rax,-0x10(%rbx)
 104f6c7:	je     104f6e0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1090>
 104f6c9:	movq   $0x0,0x1c8(%rsp)
 104f6d5:	test   %r12,%r12
 104f6d8:	jne    104f709 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x10b9>
 104f6da:	jmp    104f741 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x10f1>
 104f6dc:	nopl   0x0(%rax)
 104f6e0:	mov    -0x20(%rbx),%rax
 104f6e4:	dec    %rax
 104f6e7:	jne    104f6f4 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x10a4>
 104f6e9:	cmpq   $0x0,-0x18(%rbx)
 104f6ee:	je     104f7c1 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1171>
 104f6f4:	mov    %rax,-0x20(%rbx)
 104f6f8:	movq   $0x0,0x1c8(%rsp)
 104f704:	test   %r12,%r12
 104f707:	je     104f741 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x10f1>
 104f709:	movabs $0x4000000000000002,%rax
 104f713:	test   %rax,-0x10(%r12)
 104f718:	jne    104f735 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x10e5>
 104f71a:	mov    -0x18(%r12),%rax
 104f71f:	dec    %rax
 104f722:	jne    104f730 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x10e0>
 104f724:	cmpq   $0x0,-0x20(%r12)
 104f72a:	je     104f7fc <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x11ac>
 104f730:	mov    %rax,-0x18(%r12)
 104f735:	movq   $0x0,0xa0(%rsp)
 104f741:	mov    0x8(%rsp),%rdx
 104f746:	mov    %rdx,%rcx
 104f749:	add    %r13,%rcx
 104f74c:	jo     1051400 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2db0>
 104f752:	mov    %rcx,%rax
 104f755:	movabs $0x89705f3112a28fe5,%rdx
 104f75f:	imul   %rdx
 104f762:	add    %rcx,%rdx
 104f765:	mov    %rdx,%rax
 104f768:	shr    $0x3f,%rax
 104f76c:	sar    $0x1d,%rdx
 104f770:	add    %rax,%rdx
 104f773:	imul   $0x3b9aca07,%rdx,%rax
 104f77a:	sub    %rax,%rcx
 104f77d:	mov    %rcx,%rax
 104f780:	sar    $0x3f,%rax
 104f784:	and    $0x3b9aca07,%eax
 104f789:	add    %rcx,%rax
 104f78c:	mov    %rax,0x8(%rsp)
 104f791:	inc    %r15
 104f794:	cmp    %r15,0x28(%rsp)
 104f799:	jne    104f480 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xe30>
 104f79f:	jmp    104eea2 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x852>
 104f7a4:	movq   $0x0,0x70(%rsp)
 104f7ad:	movq   $0x0,0xa0(%rsp)
 104f7b9:	xor    %r12d,%r12d
 104f7bc:	jmp    104f675 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1025>
 104f7c1:	lea    0x258(%rbp),%rdi
 104f7c8:	lea    0x1c8(%rsp),%rsi
 104f7d0:	call   1086140 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop>
 104f7d5:	test   %r12,%r12
 104f7d8:	jne    104f709 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x10b9>
 104f7de:	jmp    104f741 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x10f1>
 104f7e3:	lea    0x258(%rbp),%rdi
 104f7ea:	lea    0xa8(%rsp),%rsi
 104f7f2:	call   1086140 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop>
 104f7f7:	jmp    104f675 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1025>
 104f7fc:	lea    0x258(%rbp),%rdi
 104f803:	lea    0xa0(%rsp),%rsi
 104f80b:	call   10860d0 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan>
 104f810:	jmp    104f741 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x10f1>
 104f815:	mov    0x6950c(%rip),%rax        # 10b8d28 <myl_lit_4b4df4d43798003d79847faa0fc7a8aff0b04bace93d5fc2cc109ef7308827f6_instance+0x38>
 104f81c:	dec    %rax
 104f81f:	jne    104f82f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x11df>
 104f821:	cmpq   $0x0,0x69507(%rip)        # 10b8d30 <myl_lit_4b4df4d43798003d79847faa0fc7a8aff0b04bace93d5fc2cc109ef7308827f6_instance+0x40>
 104f829:	je     10509bd <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x236d>
 104f82f:	mov    %rax,0x694f2(%rip)        # 10b8d28 <myl_lit_4b4df4d43798003d79847faa0fc7a8aff0b04bace93d5fc2cc109ef7308827f6_instance+0x38>
 104f836:	test   %bl,%bl
 104f838:	jne    104f3f0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xda0>
 104f83e:	movabs $0x5000000000000000,%rcx
 104f848:	movabs $0x101010101010101,%r15
 104f852:	lea    0x38(%rsp),%rdx
 104f857:	lea    0x70(%rsp),%rsi
 104f85c:	mov    %rsi,%rax
 104f85f:	sub    %rdx,%rax
 104f862:	sub    %rsi,%rdx
 104f865:	cmovb  %rax,%rdx
 104f869:	mov    %rdx,0x130(%rsp)
 104f871:	lea    0x68(%rsp),%rdx
 104f876:	lea    0x60(%rsp),%rsi
 104f87b:	mov    %rsi,%rax
 104f87e:	sub    %rdx,%rax
 104f881:	sub    %rsi,%rdx
 104f884:	cmovb  %rax,%rdx
 104f888:	mov    %rdx,0x188(%rsp)
 104f890:	xor    %r13d,%r13d
 104f893:	lea    0x1(%rcx),%rax
 104f897:	mov    %rax,0xf8(%rsp)
 104f89f:	vpbroadcastd -0x48724(%rip),%xmm9        # 1007184 <__abi_tag+0x6e88>
 104f8a8:	vpbroadcastd -0x4872d(%rip),%ymm10        # 1007184 <__abi_tag+0x6e88>
 104f8b1:	vpbroadcastq -0x487a2(%rip),%ymm0        # 1007118 <__abi_tag+0x6e1c>
 104f8ba:	vmovdqu %ymm0,0x1f0(%rsp)
 104f8c3:	movq   $0x0,0x8(%rsp)
 104f8cc:	vmovdqa %xmm9,0x50(%rsp)
 104f8d2:	vmovdqu %ymm10,0x110(%rsp)
 104f8db:	nopl   0x0(%rax,%rax,1)
 104f8e0:	mov    0x10(%rsp),%rsi
 104f8e5:	add    %r13,%rsi
 104f8e8:	jo     1051384 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2d34>
 104f8ee:	mov    0x30(%rsp),%rax
 104f8f3:	mov    0x8(%rax),%rax
 104f8f7:	and    $0x1,%esi
 104f8fa:	mov    (%rax),%rdx
 104f8fd:	cmp    %rdx,%rsi
 104f900:	jae    1051379 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2d29>
 104f906:	mov    0x20(%rax),%rax
 104f90a:	mov    (%rax,%rsi,8),%r14
 104f90e:	test   %rsi,%rsi
 104f911:	jne    104f9b0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1360>
 104f917:	movq   $0x10b9a60,0x70(%rsp)
 104f920:	movq   $0x10b9a60,0xd0(%rsp)
 104f92c:	movq   $0x10b9a60,0x38(%rsp)
 104f935:	mov    0x6a114(%rip),%rax        # 10b9a50 <myl_lit_f3eaad558815542caf7da2bdfda9d4cabeaf9c2200b79ab8ff85b21b8470fac6_instance>
 104f93c:	test   %rax,0xf8(%rsp)
 104f944:	je     104fa45 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x13f5>
 104f94a:	cmpq   $0x0,0x130(%rsp)
 104f953:	setne  %cl
 104f956:	movabs $0x5000000000000000,%rdx
 104f960:	test   %rdx,%rax
 104f963:	sete   %dl
 104f966:	mov    $0x10b9a60,%eax
 104f96b:	test   %cl,%dl
 104f96d:	jne    104fa40 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x13f0>
 104f973:	mov    $0x1030c78,%esi
 104f978:	mov    0x18(%rsp),%rdi
 104f97d:	lea    0x70(%rsp),%rdx
 104f982:	lea    0x38(%rsp),%rcx
 104f987:	mov    0x44(%rsp),%r8d
 104f98c:	vzeroupper
 104f98f:	call   10a61b0 <myl_rc_native_take>
 104f994:	vmovdqu 0x110(%rsp),%ymm10
 104f99d:	vmovdqa 0x50(%rsp),%xmm9
 104f9a3:	test   %eax,%eax
 104f9a5:	jne    104fa4e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x13fe>
 104f9ab:	jmp    105094b <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x22fb>
 104f9b0:	movq   $0x10b8dd0,0x70(%rsp)
 104f9b9:	movq   $0x10b8dd0,0xd0(%rsp)
 104f9c5:	movq   $0x10b8dd0,0x38(%rsp)
 104f9ce:	mov    0x693eb(%rip),%rax        # 10b8dc0 <myl_lit_54807ae7ae90f7f8ab8705f04b17dcd2d77e7355f27b7f7252156b0c234f7d3f_instance>
 104f9d5:	test   %rax,0xf8(%rsp)
 104f9dd:	je     104fa45 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x13f5>
 104f9df:	cmpq   $0x0,0x130(%rsp)
 104f9e8:	setne  %cl
 104f9eb:	movabs $0x5000000000000000,%rdx
 104f9f5:	test   %rdx,%rax
 104f9f8:	sete   %dl
 104f9fb:	mov    $0x10b8dd0,%eax
 104fa00:	test   %cl,%dl
 104fa02:	jne    104fa40 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x13f0>
 104fa04:	mov    $0x1030c78,%esi
 104fa09:	mov    0x18(%rsp),%rdi
 104fa0e:	lea    0x70(%rsp),%rdx
 104fa13:	lea    0x38(%rsp),%rcx
 104fa18:	mov    0x44(%rsp),%r8d
 104fa1d:	vzeroupper
 104fa20:	call   10a61b0 <myl_rc_native_take>
 104fa25:	vmovdqu 0x110(%rsp),%ymm10
 104fa2e:	vmovdqa 0x50(%rsp),%xmm9
 104fa34:	test   %eax,%eax
 104fa36:	jne    104fa4e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x13fe>
 104fa38:	jmp    1050984 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2334>
 104fa3d:	nopl   (%rax)
 104fa40:	mov    %rax,0x70(%rsp)
 104fa45:	movq   $0x0,0x38(%rsp)
 104fa4e:	mov    0x70(%rsp),%rdx
 104fa53:	movq   $0x0,0x250(%rsp)
 104fa5f:	movq   $0x0,0x230(%rsp)
 104fa6b:	cmp    %rsp,0x40(%rbp)
 104fa6f:	ja     1051399 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2d49>
 104fa75:	cmpq   $0x0,(%rdx)
 104fa79:	je     10513a4 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2d54>
 104fa7f:	mov    0x2c8(%rbp),%esi
 104fa85:	mov    %r14,0xc8(%rsp)
 104fa8d:	mov    %rdx,0x140(%rsp)
 104fa95:	testb  $0x4,0x10(%r14)
 104fa9a:	jne    104fac0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1470>
 104fa9c:	lea    0x18(%r14),%rbx
 104faa0:	testb  $0x4,0x10(%rdx)
 104faa4:	je     104fad6 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1486>
 104faa6:	mov    0x18(%rdx),%rax
 104faaa:	mov    0x14(%rdx),%ecx
 104faad:	lea    (%rax,%rcx,1),%r12
 104fab1:	add    $0x18,%r12
 104fab5:	jmp    104fada <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x148a>
 104fab7:	nopw   0x0(%rax,%rax,1)
 104fac0:	mov    0x18(%r14),%rax
 104fac4:	mov    0x14(%r14),%ecx
 104fac8:	lea    (%rax,%rcx,1),%rbx
 104facc:	add    $0x18,%rbx
 104fad0:	testb  $0x4,0x10(%rdx)
 104fad4:	jne    104faa6 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1456>
 104fad6:	lea    0x18(%rdx),%r12
 104fada:	mov    %rdx,0xb8(%rsp)
 104fae2:	mov    0x8(%rdx),%rcx
 104fae6:	mov    0x8(%r14),%r14
 104faea:	lea    -0x1(%rcx),%rax
 104faee:	cmp    %r14,%rax
 104faf1:	mov    %rcx,0x100(%rsp)
 104faf9:	mov    %r13,0x198(%rsp)
 104fb01:	mov    %esi,0x10c(%rsp)
 104fb08:	jae    104fd00 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x16b0>
 104fb0e:	cmp    $0x1,%rcx
 104fb12:	jne    104fd10 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x16c0>
 104fb18:	movzbl (%r12),%eax
 104fb1d:	vmovd  %eax,%xmm0
 104fb21:	vpbroadcastb %xmm0,%xmm0
 104fb26:	lea    0x18(%rbx),%rcx
 104fb2a:	xor    %r13d,%r13d
 104fb2d:	xor    %edx,%edx
 104fb2f:	mov    $0x10000,%r11d
 104fb35:	jmp    104fb52 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1502>
 104fb37:	nopw   0x0(%rax,%rax,1)
 104fb40:	mov    %r9d,%edi
 104fb43:	add    %rdi,%r13
 104fb46:	add    %rsi,%rdx
 104fb49:	cmp    %r14,%rdx
 104fb4c:	jae    104fd63 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1713>
 104fb52:	mov    %r14,%rsi
 104fb55:	sub    %rdx,%rsi
 104fb58:	cmp    $0x10000,%rsi
 104fb5f:	cmovae %r11,%rsi
 104fb63:	mov    %r14,%r8
 104fb66:	sub    %rdx,%r8
 104fb69:	jne    104fb80 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1530>
 104fb6b:	xor    %edi,%edi
 104fb6d:	add    %rdi,%r13
 104fb70:	add    %rsi,%rdx
 104fb73:	cmp    %r14,%rdx
 104fb76:	jb     104fb52 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1502>
 104fb78:	jmp    104fd63 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1713>
 104fb7d:	nopl   (%rax)
 104fb80:	lea    (%rbx,%rdx,1),%rdi
 104fb84:	cmp    $0x3,%r8
 104fb88:	ja     104fba0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1550>
 104fb8a:	xor    %r8d,%r8d
 104fb8d:	xor    %r9d,%r9d
 104fb90:	jmp    104fce0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1690>
 104fb95:	data16 cs nopw 0x0(%rax,%rax,1)
 104fba0:	cmp    $0x20,%r8
 104fba4:	jae    104fbb1 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1561>
 104fba6:	xor    %r8d,%r8d
 104fba9:	xor    %r9d,%r9d
 104fbac:	jmp    104fc84 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1634>
 104fbb1:	mov    %esi,%r8d
 104fbb4:	and    $0x1ffe0,%r8d
 104fbbb:	lea    (%rcx,%rdx,1),%r9
 104fbbf:	vpxor  %xmm1,%xmm1,%xmm1
 104fbc3:	xor    %r10d,%r10d
 104fbc6:	vpxor  %xmm2,%xmm2,%xmm2
 104fbca:	vpxor  %xmm3,%xmm3,%xmm3
 104fbce:	vpxor  %xmm4,%xmm4,%xmm4
 104fbd2:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 104fbe0:	vmovq  -0x18(%r9,%r10,1),%xmm5
 104fbe7:	vmovq  -0x10(%r9,%r10,1),%xmm6
 104fbee:	vmovq  -0x8(%r9,%r10,1),%xmm7
 104fbf5:	vmovq  (%r9,%r10,1),%xmm8
 104fbfb:	vpcmpeqb %xmm0,%xmm5,%xmm5
 104fbff:	vpmovzxbd %xmm5,%ymm5
 104fc04:	vpand  %ymm5,%ymm10,%ymm5
 104fc08:	vpaddd %ymm5,%ymm1,%ymm1
 104fc0c:	vpcmpeqb %xmm0,%xmm6,%xmm5
 104fc10:	vpmovzxbd %xmm5,%ymm5
 104fc15:	vpand  %ymm5,%ymm10,%ymm5
 104fc19:	vpaddd %ymm5,%ymm2,%ymm2
 104fc1d:	vpcmpeqb %xmm0,%xmm7,%xmm5
 104fc21:	vpmovzxbd %xmm5,%ymm5
 104fc26:	vpand  %ymm5,%ymm10,%ymm5
 104fc2a:	vpaddd %ymm5,%ymm3,%ymm3
 104fc2e:	vpcmpeqb %xmm0,%xmm8,%xmm5
 104fc32:	vpmovzxbd %xmm5,%ymm5
 104fc37:	vpand  %ymm5,%ymm10,%ymm5
 104fc3b:	vpaddd %ymm5,%ymm4,%ymm4
 104fc3f:	add    $0x20,%r10
 104fc43:	cmp    %r10,%r8
 104fc46:	jne    104fbe0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1590>
 104fc48:	vpaddd %ymm1,%ymm2,%ymm1
 104fc4c:	vpaddd %ymm1,%ymm3,%ymm1
 104fc50:	vpaddd %ymm1,%ymm4,%ymm1
 104fc54:	vextracti128 $0x1,%ymm1,%xmm2
 104fc5a:	vpaddd %xmm2,%xmm1,%xmm1
 104fc5e:	vpshufd $0xee,%xmm1,%xmm2
 104fc63:	vpaddd %xmm2,%xmm1,%xmm1
 104fc67:	vpshufd $0x55,%xmm1,%xmm2
 104fc6c:	vpaddd %xmm2,%xmm1,%xmm1
 104fc70:	vmovd  %xmm1,%r9d
 104fc75:	cmp    %r8,%rsi
 104fc78:	je     104fb40 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x14f0>
 104fc7e:	test   $0x1c,%sil
 104fc82:	je     104fce0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1690>
 104fc84:	mov    %r8,%r10
 104fc87:	mov    %esi,%r8d
 104fc8a:	and    $0x1fffc,%r8d
 104fc91:	vmovd  %r9d,%xmm1
 104fc96:	cs nopw 0x0(%rax,%rax,1)
 104fca0:	vmovd  (%rdi,%r10,1),%xmm2
 104fca6:	vpcmpeqb %xmm0,%xmm2,%xmm2
 104fcaa:	vpmovzxbd %xmm2,%xmm2
 104fcaf:	vpand  %xmm2,%xmm9,%xmm2
 104fcb3:	vpaddd %xmm2,%xmm1,%xmm1
 104fcb7:	add    $0x4,%r10
 104fcbb:	cmp    %r10,%r8
 104fcbe:	jne    104fca0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1650>
 104fcc0:	vpshufd $0xee,%xmm1,%xmm2
 104fcc5:	vpaddd %xmm2,%xmm1,%xmm1
 104fcc9:	vpshufd $0x55,%xmm1,%xmm2
 104fcce:	vpaddd %xmm2,%xmm1,%xmm1
 104fcd2:	vmovd  %xmm1,%r9d
 104fcd7:	jmp    104fcf1 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x16a1>
 104fcd9:	nopl   0x0(%rax)
 104fce0:	xor    %r10d,%r10d
 104fce3:	cmp    %al,(%rdi,%r8,1)
 104fce7:	sete   %r10b
 104fceb:	add    %r10d,%r9d
 104fcee:	inc    %r8
 104fcf1:	cmp    %r8,%rsi
 104fcf4:	jne    104fce0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1690>
 104fcf6:	jmp    104fb40 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x14f0>
 104fcfb:	nopl   0x0(%rax,%rax,1)
 104fd00:	xor    %r13d,%r13d
 104fd03:	jmp    104fd63 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1713>
 104fd05:	data16 cs nopw 0x0(%rax,%rax,1)
 104fd10:	mov    %rbx,%rdi
 104fd13:	mov    %r14,%rsi
 104fd16:	mov    %r12,%rdx
 104fd19:	vzeroupper
 104fd1c:	call   1091d80 <myl_native_octets_find>
 104fd21:	xor    %r13d,%r13d
 104fd24:	xor    %r15d,%r15d
 104fd27:	cmp    $0xffffffffffffffff,%rax
 104fd2b:	je     104fd59 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1709>
 104fd2d:	nopl   (%rax)
 104fd30:	mov    0x100(%rsp),%rcx
 104fd38:	add    %rcx,%r15
 104fd3b:	add    %rax,%r15
 104fd3e:	inc    %r13
 104fd41:	lea    (%rbx,%r15,1),%rdi
 104fd45:	mov    %r14,%rsi
 104fd48:	sub    %r15,%rsi
 104fd4b:	mov    %r12,%rdx
 104fd4e:	call   1091d80 <myl_native_octets_find>
 104fd53:	cmp    $0xffffffffffffffff,%rax
 104fd57:	jne    104fd30 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x16e0>
 104fd59:	movabs $0x101010101010101,%r15
 104fd63:	inc    %r13
 104fd66:	mov    0x20(%rsp),%r14
 104fd6b:	mov    0x268(%r14),%rax
 104fd72:	mov    %rax,0x1a8(%rsp)
 104fd7a:	lea    0xc8(%rsp),%rax
 104fd82:	mov    %rax,0x1b0(%rsp)
 104fd8a:	movq   $0x1031628,0x1b8(%rsp)
 104fd96:	lea    0x1a8(%rsp),%rax
 104fd9e:	mov    %rax,0x168(%rsp)
 104fda6:	lea    0x140(%rsp),%rax
 104fdae:	mov    %rax,0x170(%rsp)
 104fdb6:	movq   $0x1031628,0x178(%rsp)
 104fdc2:	lea    0x168(%rsp),%rax
 104fdca:	mov    %rax,0x268(%r14)
 104fdd1:	mov    $0x1031628,%esi
 104fdd6:	mov    0x18(%rsp),%rdi
 104fddb:	mov    %r13,%rdx
 104fdde:	vzeroupper
 104fde1:	call   108de10 <myl_native_list_new>
 104fde6:	mov    %rax,%rbx
 104fde9:	mov    %rax,0xc0(%rsp)
 104fdf1:	mov    0x268(%r14),%rax
 104fdf8:	mov    %rax,0x148(%rsp)
 104fe00:	lea    0xc0(%rsp),%rax
 104fe08:	mov    %rax,0x150(%rsp)
 104fe10:	movq   $0x1031628,0x158(%rsp)
 104fe1c:	lea    0x148(%rsp),%rax
 104fe24:	mov    %rax,0x268(%r14)
 104fe2b:	test   %rbx,%rbx
 104fe2e:	je     105037c <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1d2c>
 104fe34:	mov    0xc8(%rsp),%r12
 104fe3c:	mov    0x10(%r12),%ecx
 104fe41:	lea    0x18(%r12),%rax
 104fe46:	mov    %rax,0x98(%rsp)
 104fe4e:	mov    %ecx,0xb4(%rsp)
 104fe55:	test   $0x4,%cl
 104fe58:	vmovdqa -0x4e430(%rip),%xmm8        # 1001a30 <__abi_tag+0x1734>
 104fe60:	vmovdqu 0x1f0(%rsp),%ymm9
 104fe69:	vmovdqa -0x4e441(%rip),%xmm10        # 1001a30 <__abi_tag+0x1734>
 104fe71:	je     104fe8c <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x183c>
 104fe73:	mov    0x18(%r12),%rcx
 104fe78:	mov    0x14(%r12),%edx
 104fe7d:	add    %rdx,%rcx
 104fe80:	add    $0x18,%rcx
 104fe84:	mov    %rcx,0x98(%rsp)
 104fe8c:	mov    0x140(%rsp),%rcx
 104fe94:	testb  $0x4,0x10(%rcx)
 104fe98:	jne    104fec0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1870>
 104fe9a:	add    $0x18,%rcx
 104fe9e:	mov    %rcx,0x138(%rsp)
 104fea6:	mov    %r12,%rcx
 104fea9:	testb  $0x4,0xb4(%rsp)
 104feb1:	jne    104fee6 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1896>
 104feb3:	jmp    104fee9 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1899>
 104feb5:	data16 cs nopw 0x0(%rax,%rax,1)
 104fec0:	mov    %rcx,%rdx
 104fec3:	mov    0x18(%rcx),%rcx
 104fec7:	mov    0x14(%rdx),%edx
 104feca:	add    %rdx,%rcx
 104fecd:	add    $0x18,%rcx
 104fed1:	mov    %rcx,0x138(%rsp)
 104fed9:	mov    %r12,%rcx
 104fedc:	testb  $0x4,0xb4(%rsp)
 104fee4:	je     104fee9 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1899>
 104fee6:	mov    (%rax),%rcx
 104fee9:	mov    0x8(%rcx),%rcx
 104feed:	shr    $0x2,%rcx
 104fef1:	cmp    $0xa,%rcx
 104fef5:	mov    $0x9,%eax
 104fefa:	cmovb  %rax,%rcx
 104fefe:	mov    %rcx,0x1a0(%rsp)
 104ff06:	mov    0x98(%rsp),%rax
 104ff0e:	add    $0xc,%rax
 104ff12:	mov    %rax,0x190(%rsp)
 104ff1a:	xor    %ebp,%ebp
 104ff1c:	mov    0x100(%rsp),%rcx
 104ff24:	cmp    $0x1,%r13
 104ff28:	je     104ffd0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1980>
 104ff2e:	xchg   %ax,%ax
 104ff30:	test   %r13,%r13
 104ff33:	je     105037e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1d2e>
 104ff39:	mov    0x98(%rsp),%rax
 104ff41:	lea    (%rax,%rbp,1),%rdi
 104ff45:	mov    0x8(%r12),%rbx
 104ff4a:	mov    %rbx,%rsi
 104ff4d:	sub    %rbp,%rsi
 104ff50:	mov    0x138(%rsp),%rdx
 104ff58:	vzeroupper
 104ff5b:	call   1091d80 <myl_native_octets_find>
 104ff60:	vmovdqa -0x4e538(%rip),%xmm10        # 1001a30 <__abi_tag+0x1734>
 104ff68:	vmovdqu 0x1f0(%rsp),%ymm9
 104ff71:	vmovdqa -0x4e549(%rip),%xmm8        # 1001a30 <__abi_tag+0x1734>
 104ff79:	lea    (%rax,%rbp,1),%r14
 104ff7d:	cmp    $0xffffffffffffffff,%rax
 104ff81:	cmove  %rbx,%r14
 104ff85:	mov    %r14,%rbx
 104ff88:	sub    %rbp,%rbx
 104ff8b:	cmp    0x1a0(%rsp),%rbx
 104ff93:	jb     104ffe5 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1995>
 104ff95:	mov    0x18(%rsp),%rdi
 104ff9a:	mov    %r12,%rsi
 104ff9d:	mov    %rbp,%rdx
 104ffa0:	mov    %rbx,%rcx
 104ffa3:	mov    $0xffffffffffffffff,%r8
 104ffaa:	vzeroupper
 104ffad:	call   10906d0 <long_piece>
 104ffb2:	mov    %rax,%r15
 104ffb5:	test   %rax,%rax
 104ffb8:	jne    1050260 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1c10>
 104ffbe:	jmp    10502f0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1ca0>
 104ffc3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 104ffd0:	mov    0x8(%r12),%r14
 104ffd5:	mov    %r14,%rbx
 104ffd8:	sub    %rbp,%rbx
 104ffdb:	cmp    0x1a0(%rsp),%rbx
 104ffe3:	jae    104ff95 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1945>
 104ffe5:	mov    0x98(%rsp),%rax
 104ffed:	lea    (%rax,%rbp,1),%r12
 104fff1:	testb  $0x1,0xb4(%rsp)
 104fff9:	jne    10501ca <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1b7a>
 104ffff:	cmp    $0x8,%rbx
 1050003:	jae    1050010 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x19c0>
 1050005:	xor    %ecx,%ecx
 1050007:	xor    %eax,%eax
 1050009:	jmp    1050056 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1a06>
 105000b:	nopl   0x0(%rax,%rax,1)
 1050010:	xor    %edx,%edx
 1050012:	xor    %ecx,%ecx
 1050014:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 1050020:	mov    (%r12,%rdx,1),%rax
 1050024:	mov    %rax,%rsi
 1050027:	not    %rsi
 105002a:	add    %rsi,%rsi
 105002d:	and    %rax,%rsi
 1050030:	shr    $0x7,%rsi
 1050034:	and    %r15,%rsi
 1050037:	imul   %r15,%rsi
 105003b:	shr    $0x38,%rsi
 105003f:	sub    %rsi,%rcx
 1050042:	add    $0x8,%rcx
 1050046:	lea    0x8(%rdx),%rax
 105004a:	add    $0x10,%rdx
 105004e:	cmp    %rbx,%rdx
 1050051:	mov    %rax,%rdx
 1050054:	jbe    1050020 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x19d0>
 1050056:	cmp    %rbx,%rax
 1050059:	jae    10501c5 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1b75>
 105005f:	lea    (%rax,%rbp,1),%rdi
 1050063:	mov    %r14,%rdx
 1050066:	sub    %rdi,%rdx
 1050069:	cmp    $0x3,%rdx
 105006d:	mov    0x98(%rsp),%r8
 1050075:	jbe    10501a0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1b50>
 105007b:	cmp    $0x10,%rdx
 105007f:	jae    1050088 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1a38>
 1050081:	xor    %esi,%esi
 1050083:	jmp    105014e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1afe>
 1050088:	mov    %rdx,%rsi
 105008b:	and    $0xfffffffffffffff0,%rsi
 105008f:	vmovq  %rcx,%xmm0
 1050094:	add    0x190(%rsp),%rdi
 105009c:	vpxor  %xmm1,%xmm1,%xmm1
 10500a0:	xor    %ecx,%ecx
 10500a2:	vpxor  %xmm2,%xmm2,%xmm2
 10500a6:	vpxor  %xmm3,%xmm3,%xmm3
 10500aa:	nopw   0x0(%rax,%rax,1)
 10500b0:	vmovd  -0xc(%rdi,%rcx,1),%xmm4
 10500b6:	vmovd  -0x8(%rdi,%rcx,1),%xmm5
 10500bc:	vmovd  -0x4(%rdi,%rcx,1),%xmm6
 10500c2:	vmovd  (%rdi,%rcx,1),%xmm7
 10500c7:	vpcmpgtb %xmm10,%xmm4,%xmm4
 10500cc:	vpmovzxbq %xmm4,%ymm4
 10500d1:	vpand  %ymm4,%ymm9,%ymm4
 10500d5:	vpaddq %ymm4,%ymm0,%ymm0
 10500d9:	vpcmpgtb %xmm10,%xmm5,%xmm4
 10500de:	vpmovzxbq %xmm4,%ymm4
 10500e3:	vpand  %ymm4,%ymm9,%ymm4
 10500e7:	vpaddq %ymm4,%ymm1,%ymm1
 10500eb:	vpcmpgtb %xmm10,%xmm6,%xmm4
 10500f0:	vpmovzxbq %xmm4,%ymm4
 10500f5:	vpand  %ymm4,%ymm9,%ymm4
 10500f9:	vpaddq %ymm4,%ymm2,%ymm2
 10500fd:	vpcmpgtb %xmm10,%xmm7,%xmm4
 1050102:	vpmovzxbq %xmm4,%ymm4
 1050107:	vpand  %ymm4,%ymm9,%ymm4
 105010b:	vpaddq %ymm4,%ymm3,%ymm3
 105010f:	add    $0x10,%rcx
 1050113:	cmp    %rcx,%rsi
 1050116:	jne    10500b0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1a60>
 1050118:	vpaddq %ymm0,%ymm1,%ymm0
 105011c:	vpaddq %ymm0,%ymm2,%ymm0
 1050120:	vpaddq %ymm0,%ymm3,%ymm0
 1050124:	vextracti128 $0x1,%ymm0,%xmm1
 105012a:	vpaddq %xmm1,%xmm0,%xmm0
 105012e:	vpshufd $0xee,%xmm0,%xmm1
 1050133:	vpaddq %xmm1,%xmm0,%xmm0
 1050137:	vmovq  %xmm0,%rcx
 105013c:	cmp    %rsi,%rdx
 105013f:	je     10501c5 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1b75>
 1050145:	test   $0xc,%dl
 1050148:	je     10502dc <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1c8c>
 105014e:	mov    %rdx,%rdi
 1050151:	and    $0xfffffffffffffffc,%rdi
 1050155:	vmovq  %rcx,%xmm0
 105015a:	lea    (%r12,%rax,1),%rcx
 105015e:	xchg   %ax,%ax
 1050160:	vmovd  (%rcx,%rsi,1),%xmm1
 1050165:	vpcmpgtb %xmm8,%xmm1,%xmm1
 105016a:	vpmovzxbq %xmm1,%ymm1
 105016f:	vpand  %ymm1,%ymm9,%ymm1
 1050173:	vpaddq %ymm1,%ymm0,%ymm0
 1050177:	add    $0x4,%rsi
 105017b:	cmp    %rsi,%rdi
 105017e:	jne    1050160 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1b10>
 1050180:	vextracti128 $0x1,%ymm0,%xmm1
 1050186:	vpaddq %xmm1,%xmm0,%xmm0
 105018a:	vpshufd $0xee,%xmm0,%xmm1
 105018f:	vpaddq %xmm1,%xmm0,%xmm0
 1050193:	vmovq  %xmm0,%rcx
 1050198:	cmp    %rdi,%rdx
 105019b:	je     10501c5 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1b75>
 105019d:	add    %rdi,%rax
 10501a0:	add    %rbp,%rax
 10501a3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 10501b0:	xor    %edx,%edx
 10501b2:	cmpb   $0xc0,(%r8,%rax,1)
 10501b7:	setge  %dl
 10501ba:	add    %rdx,%rcx
 10501bd:	inc    %rax
 10501c0:	cmp    %rax,%r14
 10501c3:	jne    10501b0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1b60>
 10501c5:	cmp    %rbx,%rcx
 10501c8:	jne    1050240 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1bf0>
 10501ca:	mov    0x20(%rsp),%rax
 10501cf:	cmpq   $0x0,0x1860(%rax)
 10501d7:	je     105037c <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1d2c>
 10501dd:	lea    0x18(%rbx),%rsi
 10501e1:	mov    0x2c8(%rax),%edx
 10501e7:	mov    0x18(%rsp),%rdi
 10501ec:	xor    %ecx,%ecx
 10501ee:	vzeroupper
 10501f1:	call   10a5950 <raw_bytes>
 10501f6:	test   %rax,%rax
 10501f9:	je     10502f0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1ca0>
 10501ff:	mov    %rax,%r15
 1050202:	movq   $0x0,(%rax)
 1050209:	mov    %rbx,0x8(%rax)
 105020d:	movq   $0x0,0x10(%rax)
 1050215:	cmp    %rbp,%r14
 1050218:	je     105022c <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1bdc>
 105021a:	mov    %r15,%rdi
 105021d:	add    $0x18,%rdi
 1050221:	mov    %r12,%rsi
 1050224:	mov    %rbx,%rdx
 1050227:	call   10ab3c0 <memcpy@plt>
 105022c:	mov    %rbx,(%r15)
 105022f:	movl   $0x1,0x10(%r15)
 1050237:	jmp    1050260 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1c10>
 1050239:	nopl   0x0(%rax)
 1050240:	mov    0x18(%rsp),%rdi
 1050245:	mov    %r12,%rsi
 1050248:	mov    %rbx,%rdx
 105024b:	vzeroupper
 105024e:	call   108f630 <build_wide>
 1050253:	mov    %rax,%r15
 1050256:	test   %rax,%rax
 1050259:	je     10502f0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1ca0>
 105025f:	nop
 1050260:	mov    0xc0(%rsp),%rax
 1050268:	mov    (%rax),%rcx
 105026b:	mov    0x20(%rax),%rdx
 105026f:	lea    0x1(%rcx),%rsi
 1050273:	mov    %rsi,(%rax)
 1050276:	mov    %r15,(%rdx,%rcx,8)
 105027a:	mov    0xc0(%rsp),%rbx
 1050282:	incq   0x10(%rbx)
 1050286:	mov    0xc8(%rsp),%r12
 105028e:	cmp    0x8(%r12),%r14
 1050293:	je     105037e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1d2e>
 1050299:	mov    0x100(%rsp),%rcx
 10502a1:	add    %rcx,%r14
 10502a4:	dec    %r13
 10502a7:	mov    %r14,%rbp
 10502aa:	movabs $0x101010101010101,%r15
 10502b4:	vmovdqa -0x4e88c(%rip),%xmm8        # 1001a30 <__abi_tag+0x1734>
 10502bc:	vmovdqu 0x1f0(%rsp),%ymm9
 10502c5:	vmovdqa -0x4e89d(%rip),%xmm10        # 1001a30 <__abi_tag+0x1734>
 10502cd:	cmp    $0x1,%r13
 10502d1:	jne    104ff30 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x18e0>
 10502d7:	jmp    104ffd0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1980>
 10502dc:	add    %rsi,%rax
 10502df:	jmp    10501a0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1b50>
 10502e4:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 10502f0:	mov    0x20(%rsp),%rax
 10502f5:	cmpq   $0x0,0x1860(%rax)
 10502fd:	movabs $0x4000000000000002,%r13
 1050307:	je     105037c <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1d2c>
 1050309:	mov    0xc0(%rsp),%rbx
 1050311:	mov    0x18(%rbx),%rax
 1050315:	cmpw   $0x1,0x30(%rax)
 105031a:	jne    10512b5 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2c65>
 1050320:	mov    (%rbx),%rax
 1050323:	test   %rax,%rax
 1050326:	je     105036f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1d1f>
 1050328:	mov    0xc8(%rsp),%r14
 1050330:	mov    0x20(%rbx),%r15
 1050334:	xor    %r12d,%r12d
 1050337:	jmp    1050348 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1cf8>
 1050339:	nopl   0x0(%rax)
 1050340:	inc    %r12
 1050343:	cmp    %rax,%r12
 1050346:	jae    105036f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1d1f>
 1050348:	mov    (%r15,%r12,8),%rsi
 105034c:	test   %rsi,%rsi
 105034f:	je     1050340 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1cf0>
 1050351:	cmp    %r14,%rsi
 1050354:	je     1050340 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1cf0>
 1050356:	lea    -0x2(%r13),%rcx
 105035a:	test   %rcx,-0x10(%rsi)
 105035e:	je     1050340 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1cf0>
 1050360:	mov    0x18(%rsp),%rdi
 1050365:	call   109ddd0 <myl_rc_construction_abort>
 105036a:	mov    (%rbx),%rax
 105036d:	jmp    1050340 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1cf0>
 105036f:	mov    0x18(%rsp),%rdi
 1050374:	mov    %rbx,%rsi
 1050377:	call   109ddd0 <myl_rc_construction_abort>
 105037c:	xor    %ebx,%ebx
 105037e:	mov    0x20(%rsp),%rbp
 1050383:	mov    0x268(%rbp),%rax
 105038a:	lea    0x148(%rsp),%rcx
 1050392:	cmp    %rcx,%rax
 1050395:	je     10503d0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1d80>
 1050397:	lea    0x168(%rsp),%rcx
 105039f:	cmp    %rcx,%rax
 10503a2:	mov    0xb8(%rsp),%r12
 10503aa:	je     10503f4 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1da4>
 10503ac:	lea    0x1a8(%rsp),%rcx
 10503b4:	cmp    %rcx,%rax
 10503b7:	je     1050410 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1dc0>
 10503b9:	test   %rbx,%rbx
 10503bc:	movabs $0x4000000000000002,%r13
 10503c6:	jne    1050432 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1de2>
 10503c8:	jmp    10513af <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2d5f>
 10503cd:	nopl   (%rax)
 10503d0:	mov    0x148(%rsp),%rax
 10503d8:	mov    %rax,0x268(%rbp)
 10503df:	lea    0x168(%rsp),%rcx
 10503e7:	cmp    %rcx,%rax
 10503ea:	mov    0xb8(%rsp),%r12
 10503f2:	jne    10503ac <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1d5c>
 10503f4:	mov    0x168(%rsp),%rax
 10503fc:	mov    %rax,0x268(%rbp)
 1050403:	lea    0x1a8(%rsp),%rcx
 105040b:	cmp    %rcx,%rax
 105040e:	jne    10503b9 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1d69>
 1050410:	mov    0x1a8(%rsp),%rax
 1050418:	mov    %rax,0x268(%rbp)
 105041f:	test   %rbx,%rbx
 1050422:	movabs $0x4000000000000002,%r13
 105042c:	je     10513af <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2d5f>
 1050432:	mov    %rbx,0x60(%rsp)
 1050437:	mov    %rbx,0x68(%rsp)
 105043c:	mov    -0x10(%rbx),%rax
 1050440:	test   %rax,0xf8(%rsp)
 1050448:	je     1050469 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1e19>
 105044a:	movabs $0x5000000000000000,%rcx
 1050454:	test   %rcx,%rax
 1050457:	jne    1050480 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1e30>
 1050459:	cmpq   $0x0,0x188(%rsp)
 1050462:	je     1050480 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1e30>
 1050464:	mov    %rbx,0x60(%rsp)
 1050469:	movq   $0x0,0x68(%rsp)
 1050472:	mov    (%rbx),%r15
 1050475:	test   %r15,%r15
 1050478:	jns    10504bd <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1e6d>
 105047a:	jmp    10513ca <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2d7a>
 105047f:	nop
 1050480:	mov    $0x100ba48,%esi
 1050485:	mov    0x18(%rsp),%rdi
 105048a:	lea    0x60(%rsp),%rdx
 105048f:	lea    0x68(%rsp),%rcx
 1050494:	mov    0x10c(%rsp),%r8d
 105049c:	vzeroupper
 105049f:	call   10a61b0 <myl_rc_native_take>
 10504a4:	test   %eax,%eax
 10504a6:	je     10506e8 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2098>
 10504ac:	mov    0x60(%rsp),%rbx
 10504b1:	mov    (%rbx),%r15
 10504b4:	test   %r15,%r15
 10504b7:	js     10513ca <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2d7a>
 10504bd:	imul   $0x7,%r15,%r12
 10504c1:	vmovdqa 0x50(%rsp),%xmm9
 10504c7:	vmovdqu 0x110(%rsp),%ymm10
 10504d0:	jo     10513d8 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2d88>
 10504d6:	test   %rbx,%rbx
 10504d9:	je     10504e5 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1e95>
 10504db:	test   %r13,-0x10(%rbx)
 10504df:	je     10505f0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1fa0>
 10504e5:	mov    %rbx,0x60(%rsp)
 10504ea:	test   %r15,%r15
 10504ed:	je     105060f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1fbf>
 10504f3:	xor    %ebp,%ebp
 10504f5:	data16 cs nopw 0x0(%rax,%rax,1)
 1050500:	mov    0x20(%rbx),%rax
 1050504:	mov    (%rax,%rbp,8),%r13
 1050508:	mov    %r13,0x68(%rsp)
 105050d:	test   %r13,%r13
 1050510:	je     1050533 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1ee3>
 1050512:	movabs $0x4000000000000002,%rax
 105051c:	test   %rax,-0x10(%r13)
 1050520:	jne    1050533 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1ee3>
 1050522:	mov    -0x18(%r13),%rax
 1050526:	inc    %rax
 1050529:	je     10507f1 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x21a1>
 105052f:	mov    %rax,-0x18(%r13)
 1050533:	mov    %r13,0x60(%rsp)
 1050538:	movq   $0x0,0x68(%rsp)
 1050541:	mov    0x20(%rsp),%rdi
 1050546:	mov    %r13,%rsi
 1050549:	vzeroupper
 105054c:	call   10740a0 <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85>
 1050551:	mov    %r12,%r14
 1050554:	add    %rax,%r14
 1050557:	jo     10512d2 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2c82>
 105055d:	test   %r13,%r13
 1050560:	vmovdqa 0x50(%rsp),%xmm9
 1050566:	vmovdqu 0x110(%rsp),%ymm10
 105056f:	je     1050595 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1f45>
 1050571:	movabs $0x4000000000000002,%rax
 105057b:	test   %rax,-0x10(%r13)
 105057f:	jne    1050595 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1f45>
 1050581:	mov    -0x18(%r13),%rax
 1050585:	dec    %rax
 1050588:	jne    1050591 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1f41>
 105058a:	cmpq   $0x0,-0x20(%r13)
 105058f:	je     10505af <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1f5f>
 1050591:	mov    %rax,-0x18(%r13)
 1050595:	cmp    %r15,(%rbx)
 1050598:	jne    10512e4 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2c94>
 105059e:	inc    %rbp
 10505a1:	mov    %r14,%r12
 10505a4:	cmp    %rbp,%r15
 10505a7:	jne    1050500 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1eb0>
 10505ad:	jmp    1050612 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1fc2>
 10505af:	mov    0x18(%rsp),%r12
 10505b4:	mov    %r12,%rdi
 10505b7:	mov    %r13,%rsi
 10505ba:	vzeroupper
 10505bd:	call   1099d70 <myl_rc_hold_edge_release>
 10505c2:	mov    %r12,%rdi
 10505c5:	call   109cd90 <myl_rc_drain>
 10505ca:	vmovdqu 0x110(%rsp),%ymm10
 10505d3:	vmovdqa 0x50(%rsp),%xmm9
 10505d9:	cmp    %r15,(%rbx)
 10505dc:	je     105059e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1f4e>
 10505de:	jmp    10512e4 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2c94>
 10505e3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 10505f0:	mov    -0x18(%rbx),%rax
 10505f4:	inc    %rax
 10505f7:	je     10507cd <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x217d>
 10505fd:	mov    %rax,-0x18(%rbx)
 1050601:	mov    %rbx,0x60(%rsp)
 1050606:	test   %r15,%r15
 1050609:	jne    10504f3 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1ea3>
 105060f:	mov    %r12,%r14
 1050612:	mov    0x230(%rsp),%eax
 1050619:	or     0x250(%rsp),%eax
 1050620:	mov    0x20(%rsp),%rbp
 1050625:	movabs $0x4000000000000002,%r13
 105062f:	movabs $0x101010101010101,%r15
 1050639:	mov    0xb8(%rsp),%r12
 1050641:	je     105067e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x202e>
 1050643:	mov    0x1860(%rbp),%rax
 105064a:	test   %rax,%rax
 105064d:	je     1050660 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2010>
 105064f:	mov    0xf8(%rax),%rsi
 1050656:	jmp    1050662 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2012>
 1050658:	nopl   0x0(%rax,%rax,1)
 1050660:	xor    %esi,%esi
 1050662:	mov    0x18(%rsp),%rdi
 1050667:	vzeroupper
 105066a:	call   10a03c0 <myl_rc_scope_unwind>
 105066f:	vmovdqa 0x50(%rsp),%xmm9
 1050675:	vmovdqu 0x110(%rsp),%ymm10
 105067e:	test   %rbx,%rbx
 1050681:	je     1050840 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x21f0>
 1050687:	test   %r13,-0x10(%rbx)
 105068b:	je     10506a0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2050>
 105068d:	test   %r13,-0x10(%rbx)
 1050691:	jne    1050840 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x21f0>
 1050697:	jmp    10506c2 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2072>
 1050699:	nopl   0x0(%rax)
 10506a0:	mov    -0x18(%rbx),%rax
 10506a4:	dec    %rax
 10506a7:	jne    10506b4 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2064>
 10506a9:	cmpq   $0x0,-0x20(%rbx)
 10506ae:	je     105074c <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x20fc>
 10506b4:	mov    %rax,-0x18(%rbx)
 10506b8:	test   %r13,-0x10(%rbx)
 10506bc:	jne    1050840 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x21f0>
 10506c2:	mov    -0x20(%rbx),%rax
 10506c6:	dec    %rax
 10506c9:	jne    10506d6 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2086>
 10506cb:	cmpq   $0x0,-0x18(%rbx)
 10506d0:	je     105078f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x213f>
 10506d6:	mov    %rax,-0x20(%rbx)
 10506da:	test   %r12,%r12
 10506dd:	jne    1050845 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x21f5>
 10506e3:	jmp    1050863 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2213>
 10506e8:	mov    0x1860(%rbp),%rax
 10506ef:	test   %rax,%rax
 10506f2:	vmovdqa 0x50(%rsp),%xmm9
 10506f8:	vmovdqu 0x110(%rsp),%ymm10
 1050701:	je     10512bd <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2c6d>
 1050707:	mov    0x124(%rax),%r14d
 105070e:	movl   $0x0,0x124(%rax)
 1050718:	test   %r14,%r14
 105071b:	movabs $0x101010101010101,%r15
 1050725:	je     1050840 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x21f0>
 105072b:	cmp    $0x1,%r14d
 105072f:	jne    105090e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x22be>
 1050735:	mov    $0x1007df2,%esi
 105073a:	cmpl   $0x0,0x2c4(%rbp)
 1050741:	je     1050918 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x22c8>
 1050747:	jmp    1050920 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x22d0>
 105074c:	mov    0x18(%rsp),%r15
 1050751:	mov    %r15,%rdi
 1050754:	mov    %rbx,%rsi
 1050757:	vzeroupper
 105075a:	call   1099d70 <myl_rc_hold_edge_release>
 105075f:	mov    %r15,%rdi
 1050762:	movabs $0x101010101010101,%r15
 105076c:	call   109cd90 <myl_rc_drain>
 1050771:	vmovdqu 0x110(%rsp),%ymm10
 105077a:	vmovdqa 0x50(%rsp),%xmm9
 1050780:	test   %r13,-0x10(%rbx)
 1050784:	jne    1050840 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x21f0>
 105078a:	jmp    10506c2 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2072>
 105078f:	mov    0x18(%rsp),%r15
 1050794:	mov    %r15,%rdi
 1050797:	mov    %rbx,%rsi
 105079a:	vzeroupper
 105079d:	call   1099c10 <myl_rc_edge_release>
 10507a2:	mov    %r15,%rdi
 10507a5:	movabs $0x101010101010101,%r15
 10507af:	call   109cd90 <myl_rc_drain>
 10507b4:	vmovdqu 0x110(%rsp),%ymm10
 10507bd:	vmovdqa 0x50(%rsp),%xmm9
 10507c3:	test   %r12,%r12
 10507c6:	jne    1050845 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x21f5>
 10507c8:	jmp    1050863 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2213>
 10507cd:	mov    $0x1007dbf,%esi
 10507d2:	mov    %rbp,%rdi
 10507d5:	vzeroupper
 10507d8:	call   108a68e <fail>
 10507dd:	vmovdqu 0x110(%rsp),%ymm10
 10507e6:	vmovdqa 0x50(%rsp),%xmm9
 10507ec:	xor    %r14d,%r14d
 10507ef:	jmp    1050822 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x21d2>
 10507f1:	mov    $0x1007dbf,%esi
 10507f6:	mov    0x20(%rsp),%rbp
 10507fb:	mov    %rbp,%rdi
 10507fe:	vzeroupper
 1050801:	call   108a68e <fail>
 1050806:	vmovdqu 0x110(%rsp),%ymm10
 105080f:	vmovdqa 0x50(%rsp),%xmm9
 1050815:	xor    %r14d,%r14d
 1050818:	movabs $0x4000000000000002,%r13
 1050822:	movabs $0x101010101010101,%r15
 105082c:	mov    0xb8(%rsp),%r12
 1050834:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 1050840:	test   %r12,%r12
 1050843:	je     1050863 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2213>
 1050845:	test   %r13,-0x10(%r12)
 105084a:	jne    1050863 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2213>
 105084c:	mov    -0x20(%r12),%rax
 1050851:	dec    %rax
 1050854:	jne    105085e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x220e>
 1050856:	cmpq   $0x0,-0x18(%r12)
 105085c:	je     10508ce <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x227e>
 105085e:	mov    %rax,-0x20(%r12)
 1050863:	mov    0x8(%rsp),%rdx
 1050868:	mov    %rdx,%rcx
 105086b:	add    %r14,%rcx
 105086e:	jo     10513ba <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2d6a>
 1050874:	mov    %rcx,%rax
 1050877:	movabs $0x89705f3112a28fe5,%rdx
 1050881:	imul   %rdx
 1050884:	add    %rcx,%rdx
 1050887:	mov    %rdx,%rax
 105088a:	shr    $0x3f,%rax
 105088e:	sar    $0x1d,%rdx
 1050892:	add    %rax,%rdx
 1050895:	imul   $0x3b9aca07,%rdx,%rax
 105089c:	sub    %rax,%rcx
 105089f:	mov    %rcx,%rax
 10508a2:	sar    $0x3f,%rax
 10508a6:	and    $0x3b9aca07,%eax
 10508ab:	add    %rcx,%rax
 10508ae:	mov    %rax,0x8(%rsp)
 10508b3:	mov    0x198(%rsp),%r13
 10508bb:	inc    %r13
 10508be:	cmp    0x28(%rsp),%r13
 10508c3:	jne    104f8e0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1290>
 10508c9:	jmp    104eea2 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x852>
 10508ce:	mov    0x18(%rsp),%rbx
 10508d3:	mov    %rbx,%rdi
 10508d6:	mov    %r12,%rsi
 10508d9:	vzeroupper
 10508dc:	call   1099c10 <myl_rc_edge_release>
 10508e1:	mov    %rbx,%rdi
 10508e4:	call   109cd90 <myl_rc_drain>
 10508e9:	vmovdqu 0x110(%rsp),%ymm10
 10508f2:	vmovdqa 0x50(%rsp),%xmm9
 10508f8:	mov    0x8(%rsp),%rdx
 10508fd:	mov    %rdx,%rcx
 1050900:	add    %r14,%rcx
 1050903:	jno    1050874 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2224>
 1050909:	jmp    10513ba <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2d6a>
 105090e:	cmp    $0x4,%r14d
 1050912:	jae    10512b5 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2c65>
 1050918:	mov    0x10315e0(,%r14,8),%rsi
 1050920:	mov    %rbp,%rdi
 1050923:	vzeroupper
 1050926:	call   108a68e <fail>
 105092b:	xor    %r14d,%r14d
 105092e:	vmovdqa 0x50(%rsp),%xmm9
 1050934:	vmovdqu 0x110(%rsp),%ymm10
 105093d:	test   %r12,%r12
 1050940:	jne    1050845 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x21f5>
 1050946:	jmp    1050863 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2213>
 105094b:	mov    0x1860(%rbp),%rax
 1050952:	test   %rax,%rax
 1050955:	je     10512bd <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2c6d>
 105095b:	mov    0x124(%rax),%esi
 1050961:	movl   $0x0,0x124(%rax)
 105096b:	mov    %rbp,%rdi
 105096e:	vzeroupper
 1050971:	call   1089e30 <myl_qbe_rc_status>
 1050976:	movq   $0x0,0x8(%rsp)
 105097f:	jmp    104eea2 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x852>
 1050984:	mov    0x1860(%rbp),%rax
 105098b:	test   %rax,%rax
 105098e:	je     10512bd <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2c6d>
 1050994:	mov    0x124(%rax),%esi
 105099a:	movl   $0x0,0x124(%rax)
 10509a4:	mov    %rbp,%rdi
 10509a7:	vzeroupper
 10509aa:	call   1089e30 <myl_qbe_rc_status>
 10509af:	movq   $0x0,0x8(%rsp)
 10509b8:	jmp    104eea2 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x852>
 10509bd:	lea    0xd0(%rsp),%rsi
 10509c5:	lea    0x258(%rbp),%rdi
 10509cc:	call   1086140 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop>
 10509d1:	test   %bl,%bl
 10509d3:	jne    104f3f0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xda0>
 10509d9:	jmp    104f83e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x11ee>
 10509de:	mov    0x1860(%rbp),%rax
 10509e5:	test   %rax,%rax
 10509e8:	je     10512bd <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2c6d>
 10509ee:	mov    0x124(%rax),%esi
 10509f4:	movl   $0x0,0x124(%rax)
 10509fe:	mov    %rbp,%rdi
 1050a01:	call   1089e30 <myl_qbe_rc_status>
 1050a06:	movq   $0x0,0x8(%rsp)
 1050a0f:	jmp    104eea2 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x852>
 1050a14:	mov    0x1860(%rbp),%rax
 1050a1b:	test   %rax,%rax
 1050a1e:	je     10512bd <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2c6d>
 1050a24:	mov    0x124(%rax),%esi
 1050a2a:	movl   $0x0,0x124(%rax)
 1050a34:	mov    %rbp,%rdi
 1050a37:	call   1089e30 <myl_qbe_rc_status>
 1050a3c:	movq   $0x0,0x8(%rsp)
 1050a45:	jmp    104eea2 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x852>
 1050a4a:	lea    0xd0(%rsp),%rsi
 1050a52:	lea    0x258(%rbp),%rdi
 1050a59:	mov    %eax,%ebx
 1050a5b:	call   1086140 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop>
 1050a60:	mov    %ebx,%eax
 1050a62:	test   %eax,%eax
 1050a64:	jne    104f444 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xdf4>
 1050a6a:	movq   $0x10b8ab0,0x38(%rsp)
 1050a73:	movq   $0x10b8ab0,0x70(%rsp)
 1050a7c:	movq   $0x10b8ab0,0xd0(%rsp)
 1050a88:	mov    $0x10b8ab0,%esi
 1050a8d:	mov    %r14,%rdi
 1050a90:	call   1091cd0 <myl_native_text_equal>
 1050a95:	test   %r13,0x68004(%rip)        # 10b8aa0 <myl_lit_3b82d7fd89ea641dc3c74175c3081dd70840c2be20de843e08a42204e3d9c4cc_instance>
 1050a9c:	jne    1050abf <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x246f>
 1050a9e:	mov    0x67feb(%rip),%rcx        # 10b8a90 <myl_lit_3b2e9d8953e261b03d089bbc831cd3b7c9a128df1fa9770dfd3ff0548594ae5c_instance+0x20>
 1050aa5:	dec    %rcx
 1050aa8:	jne    1050ab8 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2468>
 1050aaa:	cmpq   $0x0,0x67fe6(%rip)        # 10b8a98 <myl_lit_3b2e9d8953e261b03d089bbc831cd3b7c9a128df1fa9770dfd3ff0548594ae5c_instance+0x28>
 1050ab2:	je     1050d34 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x26e4>
 1050ab8:	mov    %rcx,0x67fd1(%rip)        # 10b8a90 <myl_lit_3b2e9d8953e261b03d089bbc831cd3b7c9a128df1fa9770dfd3ff0548594ae5c_instance+0x20>
 1050abf:	movq   $0x0,0xd0(%rsp)
 1050acb:	test   %eax,%eax
 1050acd:	je     1050d54 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2704>
 1050ad3:	xor    %ebx,%ebx
 1050ad5:	lea    0x1a8(%rsp),%r14
 1050add:	lea    0x148(%rsp),%r15
 1050ae5:	movabs $0x89705f3112a28fe5,%r13
 1050aef:	movq   $0x0,0x8(%rsp)
 1050af8:	nopl   0x0(%rax,%rax,1)
 1050b00:	mov    0x10(%rsp),%rax
 1050b05:	add    %rbx,%rax
 1050b08:	jo     105141f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2dcf>
 1050b0e:	mov    0x30(%rsp),%rcx
 1050b13:	mov    0x8(%rcx),%rdi
 1050b17:	mov    (%rdi),%rcx
 1050b1a:	test   %rcx,%rcx
 1050b1d:	js     1051431 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2de1>
 1050b23:	je     105143c <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2dec>
 1050b29:	mov    %rax,%rdx
 1050b2c:	or     %rcx,%rdx
 1050b2f:	shr    $0x20,%rdx
 1050b33:	je     1050b3c <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x24ec>
 1050b35:	cqto
 1050b37:	idiv   %rcx
 1050b3a:	jmp    1050b40 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x24f0>
 1050b3c:	xor    %edx,%edx
 1050b3e:	div    %ecx
 1050b40:	mov    %rdx,%rax
 1050b43:	sar    $0x3f,%rax
 1050b47:	and    %rcx,%rax
 1050b4a:	add    %rdx,%rax
 1050b4d:	mov    %rax,%rsi
 1050b50:	sar    $0x3f,%rsi
 1050b54:	and    %rcx,%rsi
 1050b57:	add    %rax,%rsi
 1050b5a:	cmp    %rcx,%rsi
 1050b5d:	jae    1051447 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2df7>
 1050b63:	mov    0x20(%rdi),%rax
 1050b67:	mov    (%rax,%rsi,8),%rax
 1050b6b:	test   %rax,%rax
 1050b6e:	je     1050b9b <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x254b>
 1050b70:	mov    %rax,%rdi
 1050b73:	movabs $0x4000000000000002,%rcx
 1050b7d:	test   %rcx,-0x10(%rax)
 1050b81:	je     1050cc9 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2679>
 1050b87:	mov    %rax,0x148(%rsp)
 1050b8f:	testb  $0x4,0x10(%rdi)
 1050b93:	jne    1050bab <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x255b>
 1050b95:	add    $0x18,%rdi
 1050b99:	jmp    1050bba <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x256a>
 1050b9b:	xor    %edi,%edi
 1050b9d:	mov    %rax,0x148(%rsp)
 1050ba5:	testb  $0x4,0x10(%rdi)
 1050ba9:	je     1050b95 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2545>
 1050bab:	mov    0x18(%rdi),%rcx
 1050baf:	mov    0x14(%rdi),%edx
 1050bb2:	lea    (%rcx,%rdx,1),%rdi
 1050bb6:	add    $0x18,%rdi
 1050bba:	mov    0x8(%rax),%rsi
 1050bbe:	xor    %edx,%edx
 1050bc0:	mov    %r14,%rcx
 1050bc3:	call   104a110 <myl_native_bytes_number_parse>
 1050bc8:	test   %eax,%eax
 1050bca:	je     1050c29 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x25d9>
 1050bcc:	mov    0x1a8(%rsp),%r12
 1050bd4:	movl   $0x1,0x168(%rsp)
 1050bdf:	mov    %r12,0x170(%rsp)
 1050be7:	mov    0x148(%rsp),%rax
 1050bef:	test   %rax,%rax
 1050bf2:	je     1050c70 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2620>
 1050bf8:	movabs $0x4000000000000002,%rcx
 1050c02:	test   %rcx,-0x10(%rax)
 1050c06:	jne    1050c70 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2620>
 1050c08:	mov    -0x18(%rax),%rcx
 1050c0c:	dec    %rcx
 1050c0f:	jne    1050c6b <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x261b>
 1050c11:	cmpq   $0x0,-0x20(%rax)
 1050c16:	jne    1050c6b <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x261b>
 1050c18:	lea    0x258(%rbp),%rdi
 1050c1f:	mov    %r15,%rsi
 1050c22:	call   10860d0 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan>
 1050c27:	jmp    1050c70 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2620>
 1050c29:	movl   $0x0,0x168(%rsp)
 1050c34:	mov    0x148(%rsp),%rax
 1050c3c:	mov    $0x61,%r12d
 1050c42:	test   %rax,%rax
 1050c45:	je     1050c70 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2620>
 1050c47:	movabs $0x4000000000000002,%rcx
 1050c51:	test   %rcx,-0x10(%rax)
 1050c55:	jne    1050c70 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2620>
 1050c57:	mov    -0x18(%rax),%rcx
 1050c5b:	dec    %rcx
 1050c5e:	jne    1050c6b <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x261b>
 1050c60:	cmpq   $0x0,-0x20(%rax)
 1050c65:	je     1050d05 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x26b5>
 1050c6b:	mov    %rcx,-0x18(%rax)
 1050c6f:	nop
 1050c70:	mov    0x8(%rsp),%rdx
 1050c75:	mov    %rdx,%rcx
 1050c78:	add    %r12,%rcx
 1050c7b:	jo     1051452 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2e02>
 1050c81:	mov    %rcx,%rax
 1050c84:	imul   %r13
 1050c87:	add    %rcx,%rdx
 1050c8a:	mov    %rdx,%rax
 1050c8d:	shr    $0x3f,%rax
 1050c91:	sar    $0x1d,%rdx
 1050c95:	add    %rax,%rdx
 1050c98:	imul   $0x3b9aca07,%rdx,%rax
 1050c9f:	sub    %rax,%rcx
 1050ca2:	mov    %rcx,%rax
 1050ca5:	sar    $0x3f,%rax
 1050ca9:	and    $0x3b9aca07,%eax
 1050cae:	add    %rcx,%rax
 1050cb1:	mov    %rax,0x8(%rsp)
 1050cb6:	inc    %rbx
 1050cb9:	cmp    %rbx,0x28(%rsp)
 1050cbe:	jne    1050b00 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x24b0>
 1050cc4:	jmp    104eea2 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x852>
 1050cc9:	mov    -0x18(%rax),%rcx
 1050ccd:	inc    %rcx
 1050cd0:	je     1050cf0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x26a0>
 1050cd2:	mov    %rcx,-0x18(%rax)
 1050cd6:	mov    %rax,%rdi
 1050cd9:	mov    %rax,0x148(%rsp)
 1050ce1:	testb  $0x4,0x10(%rdi)
 1050ce5:	jne    1050bab <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x255b>
 1050ceb:	jmp    1050b95 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2545>
 1050cf0:	mov    $0x1007dbf,%esi
 1050cf5:	mov    %rbp,%rdi
 1050cf8:	call   108a68e <fail>
 1050cfd:	xor    %r12d,%r12d
 1050d00:	jmp    1050c70 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2620>
 1050d05:	lea    0x258(%rbp),%rdi
 1050d0c:	mov    %r15,%rsi
 1050d0f:	call   10860d0 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan>
 1050d14:	jmp    1050c70 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2620>
 1050d19:	mov    $0x1007dbf,%esi
 1050d1e:	mov    %rbp,%rdi
 1050d21:	call   108a68e <fail>
 1050d26:	movq   $0x0,0x8(%rsp)
 1050d2f:	jmp    104eea2 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x852>
 1050d34:	lea    0xd0(%rsp),%rsi
 1050d3c:	lea    0x258(%rbp),%rdi
 1050d43:	mov    %eax,%ebx
 1050d45:	call   1086140 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop>
 1050d4a:	mov    %ebx,%eax
 1050d4c:	test   %eax,%eax
 1050d4e:	jne    1050ad3 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2483>
 1050d54:	movq   $0x10b8fb8,0x70(%rsp)
 1050d5d:	movq   $0x10b8fb8,0xd0(%rsp)
 1050d69:	mov    $0x10b8fb8,%esi
 1050d6e:	mov    %r14,%rdi
 1050d71:	call   1091cd0 <myl_native_text_equal>
 1050d76:	test   %r13,0x6822b(%rip)        # 10b8fa8 <myl_lit_626da83bb2caf4205ae415768034d7bb2b32d76c3b0b29af95ab0567cf1d3ca9_instance>
 1050d7d:	jne    1050da0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2750>
 1050d7f:	mov    0x68212(%rip),%rcx        # 10b8f98 <myl_lit_5ffcfeefbc77603111eb9faae2375c1bd71d00fc5610c522261905cf007d59b3_instance+0x60>
 1050d86:	dec    %rcx
 1050d89:	jne    1050d99 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2749>
 1050d8b:	cmpq   $0x0,0x6820d(%rip)        # 10b8fa0 <myl_lit_5ffcfeefbc77603111eb9faae2375c1bd71d00fc5610c522261905cf007d59b3_instance+0x68>
 1050d93:	je     1050f17 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x28c7>
 1050d99:	mov    %rcx,0x681f8(%rip)        # 10b8f98 <myl_lit_5ffcfeefbc77603111eb9faae2375c1bd71d00fc5610c522261905cf007d59b3_instance+0x60>
 1050da0:	test   %eax,%eax
 1050da2:	je     1050f37 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x28e7>
 1050da8:	xor    %ebx,%ebx
 1050daa:	lea    0x1c8(%rsp),%r14
 1050db2:	movabs $0x89705f3112a28fe5,%r12
 1050dbc:	movq   $0x0,0x8(%rsp)
 1050dc5:	mov    0x10(%rsp),%rax
 1050dca:	add    %rbx,%rax
 1050dcd:	jo     105145f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2e0f>
 1050dd3:	mov    0x30(%rsp),%rcx
 1050dd8:	mov    0x18(%rcx),%rdi
 1050ddc:	mov    (%rdi),%rcx
 1050ddf:	test   %rcx,%rcx
 1050de2:	movabs $0x4000000000000002,%r13
 1050dec:	js     1051471 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2e21>
 1050df2:	je     105147c <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2e2c>
 1050df8:	mov    %rax,%rdx
 1050dfb:	or     %rcx,%rdx
 1050dfe:	shr    $0x20,%rdx
 1050e02:	je     1050e0b <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x27bb>
 1050e04:	cqto
 1050e06:	idiv   %rcx
 1050e09:	jmp    1050e0f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x27bf>
 1050e0b:	xor    %edx,%edx
 1050e0d:	div    %ecx
 1050e0f:	mov    %rdx,%rsi
 1050e12:	sar    $0x3f,%rsi
 1050e16:	and    %rcx,%rsi
 1050e19:	add    %rdx,%rsi
 1050e1c:	cmp    %rcx,%rsi
 1050e1f:	jb     1050e37 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x27e7>
 1050e21:	mov    %rsi,%rax
 1050e24:	sar    $0x3f,%rax
 1050e28:	and    %rcx,%rax
 1050e2b:	add    %rax,%rsi
 1050e2e:	cmp    %rcx,%rsi
 1050e31:	jae    105148f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2e3f>
 1050e37:	mov    0x20(%rdi),%rax
 1050e3b:	mov    (%rax,%rsi,8),%rsi
 1050e3f:	lea    0x258(%rbp),%rdi
 1050e46:	call   104bc70 <myl_native_text_integer>
 1050e4b:	test   %rax,%rax
 1050e4e:	je     1051487 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2e37>
 1050e54:	mov    %rax,%r15
 1050e57:	mov    %rax,0x70(%rsp)
 1050e5c:	mov    %rax,0x1c8(%rsp)
 1050e64:	mov    %rbp,%rdi
 1050e67:	mov    %rax,%rsi
 1050e6a:	call   10740a0 <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85>
 1050e6f:	test   %r13,-0x10(%r15)
 1050e73:	mov    0x8(%rsp),%r13
 1050e78:	jne    1050e8e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x283e>
 1050e7a:	mov    -0x20(%r15),%rcx
 1050e7e:	dec    %rcx
 1050e81:	jne    1050e8a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x283a>
 1050e83:	cmpq   $0x0,-0x18(%r15)
 1050e88:	je     1050eea <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x289a>
 1050e8a:	mov    %rcx,-0x20(%r15)
 1050e8e:	movq   $0x0,0x1c8(%rsp)
 1050e9a:	mov    %r13,%rcx
 1050e9d:	add    %rax,%rcx
 1050ea0:	jo     1050f07 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x28b7>
 1050ea2:	mov    %rcx,%rax
 1050ea5:	imul   %r12
 1050ea8:	add    %rcx,%rdx
 1050eab:	mov    %rdx,%rax
 1050eae:	shr    $0x3f,%rax
 1050eb2:	sar    $0x1d,%rdx
 1050eb6:	add    %rax,%rdx
 1050eb9:	imul   $0x3b9aca07,%rdx,%rax
 1050ec0:	sub    %rax,%rcx
 1050ec3:	mov    %rcx,%rax
 1050ec6:	sar    $0x3f,%rax
 1050eca:	and    $0x3b9aca07,%eax
 1050ecf:	add    %rcx,%rax
 1050ed2:	mov    %rax,0x8(%rsp)
 1050ed7:	inc    %rbx
 1050eda:	cmp    %rbx,0x28(%rsp)
 1050edf:	jne    1050dc5 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2775>
 1050ee5:	jmp    104eea2 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x852>
 1050eea:	lea    0x258(%rbp),%rdi
 1050ef1:	mov    %r14,%rsi
 1050ef4:	mov    %rax,%r15
 1050ef7:	call   1086140 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop>
 1050efc:	mov    %r15,%rax
 1050eff:	mov    %r13,%rcx
 1050f02:	add    %rax,%rcx
 1050f05:	jno    1050ea2 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2852>
 1050f07:	mov    %rbp,%rdi
 1050f0a:	xor    %esi,%esi
 1050f0c:	mov    %r13,%rdx
 1050f0f:	mov    %rax,%rcx
 1050f12:	call   108b0a0 <myl_qbe_fail_overflow_op>
 1050f17:	lea    0xd0(%rsp),%rsi
 1050f1f:	lea    0x258(%rbp),%rdi
 1050f26:	mov    %eax,%ebx
 1050f28:	call   1086140 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop>
 1050f2d:	mov    %ebx,%eax
 1050f2f:	test   %eax,%eax
 1050f31:	jne    1050da8 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2758>
 1050f37:	movq   $0x10b93d0,0x70(%rsp)
 1050f40:	movq   $0x10b93d0,0xd0(%rsp)
 1050f4c:	mov    $0x10b93d0,%esi
 1050f51:	mov    %r14,%rdi
 1050f54:	call   1091cd0 <myl_native_text_equal>
 1050f59:	test   %r13,0x68460(%rip)        # 10b93c0 <myl_lit_a35604ac3394cc7d310962e0ecc5dd785c46f6dc02140680027413a7b439bcdd_instance>
 1050f60:	jne    1050f83 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2933>
 1050f62:	mov    0x68447(%rip),%rcx        # 10b93b0 <myl_lit_9d259d114fa076e260ed1d46f937777788fb8ac5c28077065c4fa3e2a22cd22a_instance+0x38>
 1050f69:	dec    %rcx
 1050f6c:	jne    1050f7c <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x292c>
 1050f6e:	cmpq   $0x0,0x68442(%rip)        # 10b93b8 <myl_lit_9d259d114fa076e260ed1d46f937777788fb8ac5c28077065c4fa3e2a22cd22a_instance+0x40>
 1050f76:	je     105102f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x29df>
 1050f7c:	mov    %rcx,0x6842d(%rip)        # 10b93b0 <myl_lit_9d259d114fa076e260ed1d46f937777788fb8ac5c28077065c4fa3e2a22cd22a_instance+0x38>
 1050f83:	test   %eax,%eax
 1050f85:	je     105104f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x29ff>
 1050f8b:	xor    %ebx,%ebx
 1050f8d:	movabs $0x89705f3112a28fe5,%r14
 1050f97:	movq   $0x0,0x8(%rsp)
 1050fa0:	mov    0x10(%rsp),%rsi
 1050fa5:	add    %rbx,%rsi
 1050fa8:	jo     105149a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2e4a>
 1050fae:	mov    0x30(%rsp),%rax
 1050fb3:	mov    0x8(%rax),%rax
 1050fb7:	and    $0x1,%esi
 1050fba:	mov    (%rax),%rdx
 1050fbd:	cmp    %rdx,%rsi
 1050fc0:	mov    0x8(%rsp),%r15
 1050fc5:	jae    10514ac <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2e5c>
 1050fcb:	mov    0x20(%rax),%rax
 1050fcf:	mov    (%rax,%rsi,8),%rsi
 1050fd3:	mov    %rbp,%rdi
 1050fd6:	call   106a880 <myl_f_ad1ca9f864adc8c89d572ada651cc6dc28bc6d83eeae5c5fc70bc26744bcdb57>
 1050fdb:	mov    %r15,%rcx
 1050fde:	add    %rax,%rcx
 1050fe1:	jo     10514b4 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2e64>
 1050fe7:	mov    %rcx,%rax
 1050fea:	imul   %r14
 1050fed:	add    %rcx,%rdx
 1050ff0:	mov    %rdx,%rax
 1050ff3:	shr    $0x3f,%rax
 1050ff7:	sar    $0x1d,%rdx
 1050ffb:	add    %rax,%rdx
 1050ffe:	imul   $0x3b9aca07,%rdx,%rax
 1051005:	sub    %rax,%rcx
 1051008:	mov    %rcx,%rax
 105100b:	sar    $0x3f,%rax
 105100f:	and    $0x3b9aca07,%eax
 1051014:	add    %rcx,%rax
 1051017:	mov    %rax,0x8(%rsp)
 105101c:	inc    %rbx
 105101f:	cmp    %rbx,0x28(%rsp)
 1051024:	jne    1050fa0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2950>
 105102a:	jmp    104eea2 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x852>
 105102f:	lea    0xd0(%rsp),%rsi
 1051037:	lea    0x258(%rbp),%rdi
 105103e:	mov    %eax,%ebx
 1051040:	call   1086140 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop>
 1051045:	mov    %ebx,%eax
 1051047:	test   %eax,%eax
 1051049:	jne    1050f8b <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x293b>
 105104f:	movq   $0x10b8868,0x70(%rsp)
 1051058:	movq   $0x10b8868,0xd0(%rsp)
 1051064:	mov    $0x10b8868,%esi
 1051069:	mov    %r14,%rdi
 105106c:	call   1091cd0 <myl_native_text_equal>
 1051071:	test   %r13,0x677e0(%rip)        # 10b8858 <myl_lit_20a5074191baf0b9771e8515f87070a522415c098c80effc97a3fee2e9d89d03_instance>
 1051078:	jne    105109b <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2a4b>
 105107a:	mov    0x677c7(%rip),%rcx        # 10b8848 <myl_lit_1ad4f10fd641593331eda3448c74a0b009c6527a19d75e6283c9d7ef74595fd2_instance+0x38>
 1051081:	dec    %rcx
 1051084:	jne    1051094 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2a44>
 1051086:	cmpq   $0x0,0x677c2(%rip)        # 10b8850 <myl_lit_1ad4f10fd641593331eda3448c74a0b009c6527a19d75e6283c9d7ef74595fd2_instance+0x40>
 105108e:	je     105113d <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2aed>
 1051094:	mov    %rcx,0x677ad(%rip)        # 10b8848 <myl_lit_1ad4f10fd641593331eda3448c74a0b009c6527a19d75e6283c9d7ef74595fd2_instance+0x38>
 105109b:	test   %eax,%eax
 105109d:	je     105115d <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2b0d>
 10510a3:	xor    %ebx,%ebx
 10510a5:	movabs $0x89705f3112a28fe5,%r14
 10510af:	movq   $0x0,0x8(%rsp)
 10510b8:	mov    0x10(%rsp),%rax
 10510bd:	add    %rbx,%rax
 10510c0:	jo     10514c4 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2e74>
 10510c6:	mov    0x30(%rsp),%rax
 10510cb:	mov    0x8(%rax),%rax
 10510cf:	cmpq   $0x0,(%rax)
 10510d3:	mov    0x8(%rsp),%r15
 10510d8:	je     10514d6 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2e86>
 10510de:	mov    0x20(%rax),%rax
 10510e2:	mov    (%rax),%rsi
 10510e5:	mov    %rbp,%rdi
 10510e8:	call   1071e00 <myl_f_bc9060da36c8e282f8d98349f6541aa0f2c1802b8a99e1d4c2ef7b134103c5e2>
 10510ed:	mov    %r15,%rcx
 10510f0:	add    %rax,%rcx
 10510f3:	jo     10514e2 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2e92>
 10510f9:	mov    %rcx,%rax
 10510fc:	imul   %r14
 10510ff:	add    %rcx,%rdx
 1051102:	mov    %rdx,%rax
 1051105:	shr    $0x3f,%rax
 1051109:	sar    $0x1d,%rdx
 105110d:	add    %rax,%rdx
 1051110:	imul   $0x3b9aca07,%rdx,%rax
 1051117:	sub    %rax,%rcx
 105111a:	mov    %rcx,%rax
 105111d:	sar    $0x3f,%rax
 1051121:	and    $0x3b9aca07,%eax
 1051126:	add    %rcx,%rax
 1051129:	mov    %rax,0x8(%rsp)
 105112e:	inc    %rbx
 1051131:	cmp    %rbx,0x28(%rsp)
 1051136:	jne    10510b8 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2a68>
 1051138:	jmp    104eea2 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x852>
 105113d:	lea    0xd0(%rsp),%rsi
 1051145:	lea    0x258(%rbp),%rdi
 105114c:	mov    %eax,%ebx
 105114e:	call   1086140 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop>
 1051153:	mov    %ebx,%eax
 1051155:	test   %eax,%eax
 1051157:	jne    10510a3 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2a53>
 105115d:	movq   $0x10b8938,0x70(%rsp)
 1051166:	movq   $0x10b8938,0xd0(%rsp)
 1051172:	mov    $0x10b8938,%esi
 1051177:	mov    %r14,%rdi
 105117a:	call   1091cd0 <myl_native_text_equal>
 105117f:	test   %r13,0x677a2(%rip)        # 10b8928 <myl_lit_2cecebef85ac89e87c0bdc9d723015d4a10a29fb007a542e0de04f511346a3b5_instance>
 1051186:	jne    10511a9 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2b59>
 1051188:	mov    0x67789(%rip),%rcx        # 10b8918 <myl_lit_2ac6840555c10725b6640492294f67393cd0d698e5786fc4e12cdb1cc9a394a2_instance+0x38>
 105118f:	dec    %rcx
 1051192:	jne    10511a2 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2b52>
 1051194:	cmpq   $0x0,0x67784(%rip)        # 10b8920 <myl_lit_2ac6840555c10725b6640492294f67393cd0d698e5786fc4e12cdb1cc9a394a2_instance+0x40>
 105119c:	je     1051287 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2c37>
 10511a2:	mov    %rcx,0x6776f(%rip)        # 10b8918 <myl_lit_2ac6840555c10725b6640492294f67393cd0d698e5786fc4e12cdb1cc9a394a2_instance+0x38>
 10511a9:	test   %eax,%eax
 10511ab:	je     10512a7 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2c57>
 10511b1:	xor    %ebx,%ebx
 10511b3:	movabs $0x7878787878787879,%r14
 10511bd:	movabs $0x89705f3112a28fe5,%r15
 10511c7:	movq   $0x0,0x8(%rsp)
 10511d0:	mov    0x10(%rsp),%rcx
 10511d5:	add    %rbx,%rcx
 10511d8:	jo     10514f2 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2ea2>
 10511de:	mov    0x30(%rsp),%rax
 10511e3:	mov    0x8(%rax),%rax
 10511e7:	cmpq   $0x0,(%rax)
 10511eb:	mov    0x8(%rsp),%r12
 10511f0:	je     1051504 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2eb4>
 10511f6:	mov    0x20(%rax),%rax
 10511fa:	mov    (%rax),%rsi
 10511fd:	mov    %rcx,%rax
 1051200:	imul   %r14
 1051203:	mov    %rdx,%rax
 1051206:	shr    $0x3f,%rax
 105120a:	sar    $0x3,%rdx
 105120e:	add    %rax,%rdx
 1051211:	mov    %rdx,%rax
 1051214:	shl    $0x4,%rax
 1051218:	add    %rdx,%rax
 105121b:	sub    %rax,%rcx
 105121e:	mov    %rcx,%rdx
 1051221:	sar    $0x3f,%rdx
 1051225:	and    $0x11,%edx
 1051228:	add    %rcx,%rdx
 105122b:	mov    %rbp,%rdi
 105122e:	call   1057cd0 <myl_f_47022dd26e980fcb99b6abeb2cfdf289edce3d6955dda89c0a131b73692c5f56>
 1051233:	mov    %r12,%rcx
 1051236:	add    %rax,%rcx
 1051239:	jo     1051510 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2ec0>
 105123f:	mov    %rcx,%rax
 1051242:	imul   %r15
 1051245:	add    %rcx,%rdx
 1051248:	mov    %rdx,%rax
 105124b:	shr    $0x3f,%rax
 105124f:	sar    $0x1d,%rdx
 1051253:	add    %rax,%rdx
 1051256:	imul   $0x3b9aca07,%rdx,%rax
 105125d:	sub    %rax,%rcx
 1051260:	mov    %rcx,%rax
 1051263:	sar    $0x3f,%rax
 1051267:	and    $0x3b9aca07,%eax
 105126c:	add    %rcx,%rax
 105126f:	mov    %rax,0x8(%rsp)
 1051274:	inc    %rbx
 1051277:	cmp    %rbx,0x28(%rsp)
 105127c:	jne    10511d0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2b80>
 1051282:	jmp    104eea2 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x852>
 1051287:	lea    0xd0(%rsp),%rsi
 105128f:	lea    0x258(%rbp),%rdi
 1051296:	mov    %eax,%ebx
 1051298:	call   1086140 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop>
 105129d:	mov    %ebx,%eax
 105129f:	test   %eax,%eax
 10512a1:	jne    10511b1 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2b61>
 10512a7:	movq   $0x0,0x8(%rsp)
 10512b0:	jmp    104eea2 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x852>
 10512b5:	vzeroupper
 10512b8:	call   10ab3e0 <abort@plt>
 10512bd:	vzeroupper
 10512c0:	call   1099767 <myl_rc_invariant_failed>
 10512c5:	mov    %rbp,%rdi
 10512c8:	xor    %esi,%esi
 10512ca:	vzeroupper
 10512cd:	call   108b0a0 <myl_qbe_fail_overflow_op>
 10512d2:	mov    0x20(%rsp),%rdi
 10512d7:	xor    %esi,%esi
 10512d9:	mov    %r12,%rdx
 10512dc:	mov    %rax,%rcx
 10512df:	call   108b0a0 <myl_qbe_fail_overflow_op>
 10512e4:	mov    0x20(%rsp),%rdi
 10512e9:	vzeroupper
 10512ec:	call   108ae50 <myl_qbe_fail_iteration>
 10512f1:	mov    %rbp,%rdi
 10512f4:	xor    %esi,%esi
 10512f6:	mov    0x10(%rsp),%rdx
 10512fb:	mov    %r14,%rcx
 10512fe:	vzeroupper
 1051301:	call   108b0a0 <myl_qbe_fail_overflow_op>
 1051306:	mov    %rbp,%rdi
 1051309:	xor    %esi,%esi
 105130b:	mov    %r13,%rdx
 105130e:	mov    %rbx,%rcx
 1051311:	vzeroupper
 1051314:	call   108b0a0 <myl_qbe_fail_overflow_op>
 1051319:	mov    0x20(%rsp),%rdi
 105131e:	call   108af90 <myl_qbe_fail_normalized_index_bounds>
 1051323:	mov    0x20(%rsp),%rdi
 1051328:	call   108af90 <myl_qbe_fail_normalized_index_bounds>
 105132d:	mov    %rbp,%rdi
 1051330:	xor    %esi,%esi
 1051332:	mov    0x10(%rsp),%rdx
 1051337:	mov    %rbx,%rcx
 105133a:	call   108b0a0 <myl_qbe_fail_overflow_op>
 105133f:	mov    %rbp,%rdi
 1051342:	xor    %esi,%esi
 1051344:	mov    0x10(%rsp),%rdx
 1051349:	mov    %rbx,%rcx
 105134c:	call   108b0a0 <myl_qbe_fail_overflow_op>
 1051351:	mov    %rbp,%rdi
 1051354:	xor    %esi,%esi
 1051356:	xor    %edx,%edx
 1051358:	call   108af90 <myl_qbe_fail_normalized_index_bounds>
 105135d:	mov    %rbp,%rdi
 1051360:	call   108af90 <myl_qbe_fail_normalized_index_bounds>
 1051365:	mov    $0x1,%ecx
 105136a:	mov    0x20(%rsp),%rdi
 105136f:	xor    %esi,%esi
 1051371:	mov    %r15,%rdx
 1051374:	call   108b0a0 <myl_qbe_fail_overflow_op>
 1051379:	mov    %rbp,%rdi
 105137c:	vzeroupper
 105137f:	call   108af90 <myl_qbe_fail_normalized_index_bounds>
 1051384:	mov    %rbp,%rdi
 1051387:	xor    %esi,%esi
 1051389:	mov    0x10(%rsp),%rdx
 105138e:	mov    %r13,%rcx
 1051391:	vzeroupper
 1051394:	call   108b0a0 <myl_qbe_fail_overflow_op>
 1051399:	mov    %rbp,%rdi
 105139c:	vzeroupper
 105139f:	call   108b160 <myl_qbe_fail_frame>
 10513a4:	mov    %rbp,%rdi
 10513a7:	vzeroupper
 10513aa:	call   108ae40 <myl_qbe_fail_empty_separator>
 10513af:	mov    %rbp,%rdi
 10513b2:	vzeroupper
 10513b5:	call   108ad50 <myl_qbe_fail_allocation>
 10513ba:	mov    %rbp,%rdi
 10513bd:	xor    %esi,%esi
 10513bf:	mov    %r14,%rcx
 10513c2:	vzeroupper
 10513c5:	call   108b0a0 <myl_qbe_fail_overflow_op>
 10513ca:	mov    %rbp,%rdi
 10513cd:	mov    %r15,%rsi
 10513d0:	vzeroupper
 10513d3:	call   108b100 <myl_qbe_fail_cast>
 10513d8:	mov    $0x2,%esi
 10513dd:	mov    $0x7,%ecx
 10513e2:	mov    %rbp,%rdi
 10513e5:	mov    %r15,%rdx
 10513e8:	vzeroupper
 10513eb:	call   108b0a0 <myl_qbe_fail_overflow_op>
 10513f0:	mov    %rbp,%rdi
 10513f3:	call   108b160 <myl_qbe_fail_frame>
 10513f8:	mov    %rbp,%rdi
 10513fb:	call   108ad50 <myl_qbe_fail_allocation>
 1051400:	mov    %rbp,%rdi
 1051403:	xor    %esi,%esi
 1051405:	mov    %r13,%rcx
 1051408:	call   108b0a0 <myl_qbe_fail_overflow_op>
 105140d:	mov    %rbp,%rdi
 1051410:	xor    %esi,%esi
 1051412:	mov    0x10(%rsp),%rdx
 1051417:	mov    %r15,%rcx
 105141a:	call   108b0a0 <myl_qbe_fail_overflow_op>
 105141f:	mov    %rbp,%rdi
 1051422:	xor    %esi,%esi
 1051424:	mov    0x10(%rsp),%rdx
 1051429:	mov    %rbx,%rcx
 105142c:	call   108b0a0 <myl_qbe_fail_overflow_op>
 1051431:	mov    %rbp,%rdi
 1051434:	mov    %rcx,%rsi
 1051437:	call   108b100 <myl_qbe_fail_cast>
 105143c:	mov    %rbp,%rdi
 105143f:	mov    %rax,%rsi
 1051442:	call   108b050 <myl_qbe_fail_division>
 1051447:	mov    %rbp,%rdi
 105144a:	mov    %rcx,%rdx
 105144d:	call   108af90 <myl_qbe_fail_normalized_index_bounds>
 1051452:	mov    %rbp,%rdi
 1051455:	xor    %esi,%esi
 1051457:	mov    %r12,%rcx
 105145a:	call   108b0a0 <myl_qbe_fail_overflow_op>
 105145f:	mov    %rbp,%rdi
 1051462:	xor    %esi,%esi
 1051464:	mov    0x10(%rsp),%rdx
 1051469:	mov    %rbx,%rcx
 105146c:	call   108b0a0 <myl_qbe_fail_overflow_op>
 1051471:	mov    %rbp,%rdi
 1051474:	mov    %rcx,%rsi
 1051477:	call   108b100 <myl_qbe_fail_cast>
 105147c:	mov    %rbp,%rdi
 105147f:	mov    %rax,%rsi
 1051482:	call   108b050 <myl_qbe_fail_division>
 1051487:	mov    %rbp,%rdi
 105148a:	call   108ad50 <myl_qbe_fail_allocation>
 105148f:	mov    %rbp,%rdi
 1051492:	mov    %rcx,%rdx
 1051495:	call   108af90 <myl_qbe_fail_normalized_index_bounds>
 105149a:	mov    %rbp,%rdi
 105149d:	xor    %esi,%esi
 105149f:	mov    0x10(%rsp),%rdx
 10514a4:	mov    %rbx,%rcx
 10514a7:	call   108b0a0 <myl_qbe_fail_overflow_op>
 10514ac:	mov    %rbp,%rdi
 10514af:	call   108af90 <myl_qbe_fail_normalized_index_bounds>
 10514b4:	mov    %rbp,%rdi
 10514b7:	xor    %esi,%esi
 10514b9:	mov    %r15,%rdx
 10514bc:	mov    %rax,%rcx
 10514bf:	call   108b0a0 <myl_qbe_fail_overflow_op>
 10514c4:	mov    %rbp,%rdi
 10514c7:	xor    %esi,%esi
 10514c9:	mov    0x10(%rsp),%rdx
 10514ce:	mov    %rbx,%rcx
 10514d1:	call   108b0a0 <myl_qbe_fail_overflow_op>
 10514d6:	mov    %rbp,%rdi
 10514d9:	xor    %esi,%esi
 10514db:	xor    %edx,%edx
 10514dd:	call   108af90 <myl_qbe_fail_normalized_index_bounds>
 10514e2:	mov    %rbp,%rdi
 10514e5:	xor    %esi,%esi
 10514e7:	mov    %r15,%rdx
 10514ea:	mov    %rax,%rcx
 10514ed:	call   108b0a0 <myl_qbe_fail_overflow_op>
 10514f2:	mov    %rbp,%rdi
 10514f5:	xor    %esi,%esi
 10514f7:	mov    0x10(%rsp),%rdx
 10514fc:	mov    %rbx,%rcx
 10514ff:	call   108b0a0 <myl_qbe_fail_overflow_op>
 1051504:	mov    %rbp,%rdi
 1051507:	xor    %esi,%esi
 1051509:	xor    %edx,%edx
 105150b:	call   108af90 <myl_qbe_fail_normalized_index_bounds>
 1051510:	mov    %rbp,%rdi
 1051513:	xor    %esi,%esi
 1051515:	mov    %r12,%rdx
 1051518:	mov    %rax,%rcx
 105151b:	call   108b0a0 <myl_qbe_fail_overflow_op>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
