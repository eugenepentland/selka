
.mylang-cache/goal110-search-align/runner/bin/text-my-llvm:     file format elf64-x86-64


Disassembly of section .text:

0000000001091d80 <myl_native_octets_find>:
 1091d80:	test   %rcx,%rcx
 1091d83:	je     1091dda <myl_native_octets_find+0x5a>
 1091d85:	push   %rbp
 1091d86:	mov    %rsp,%rbp
 1091d89:	push   %r15
 1091d8b:	push   %r14
 1091d8d:	push   %r13
 1091d8f:	push   %r12
 1091d91:	push   %rbx
 1091d92:	sub    $0x18,%rsp
 1091d96:	mov    $0xffffffffffffffff,%rax
 1091d9d:	mov    %rsi,%r14
 1091da0:	sub    %rcx,%r14
 1091da3:	jb     1092045 <myl_native_octets_find+0x2c5>
 1091da9:	mov    %rsi,%rbx
 1091dac:	cmp    $0x1,%rcx
 1091db0:	jne    1091ddd <myl_native_octets_find+0x5d>
 1091db2:	movzbl (%rdx),%esi
 1091db5:	mov    %rdi,%r14
 1091db8:	mov    %rbx,%rdx
 1091dbb:	call   10ab5e0 <memchr@plt>
 1091dc0:	mov    %rax,%rcx
 1091dc3:	mov    %rax,%rdx
 1091dc6:	sub    %r14,%rdx
 1091dc9:	xor    %eax,%eax
 1091dcb:	cmp    $0x1,%rcx
 1091dcf:	sbb    %rax,%rax
 1091dd2:	or     %rdx,%rax
 1091dd5:	jmp    1092045 <myl_native_octets_find+0x2c5>
 1091dda:	xor    %eax,%eax
 1091ddc:	ret
 1091ddd:	mov    %rcx,-0x30(%rbp)
 1091de1:	mov    %rdx,%r15
 1091de4:	movzbl (%rdx),%r12d
 1091de8:	lea    0x1(%r14),%rdx
 1091dec:	mov    %rdi,%r13
 1091def:	mov    %r12d,%esi
 1091df2:	call   10ab5e0 <memchr@plt>
 1091df7:	test   %rax,%rax
 1091dfa:	je     109203e <myl_native_octets_find+0x2be>
 1091e00:	mov    %r13,%rcx
 1091e03:	lea    (%r14,%r13,1),%r10
 1091e07:	lea    (%r14,%r13,1),%r11
 1091e0b:	inc    %r11
 1091e0e:	lea    0x1(%rax),%rdi
 1091e12:	mov    $0x1,%edx
 1091e17:	mov    -0x30(%rbp),%rsi
 1091e1b:	mov    %r15,%r8
 1091e1e:	xchg   %ax,%ax
 1091e20:	movzbl (%rax,%rdx,1),%r9d
 1091e25:	cmp    (%r8,%rdx,1),%r9b
 1091e29:	jne    1091e3b <myl_native_octets_find+0xbb>
 1091e2b:	inc    %rdx
 1091e2e:	cmp    %rdx,%rsi
 1091e31:	jne    1091e20 <myl_native_octets_find+0xa0>
 1091e33:	sub    %rcx,%rax
 1091e36:	jmp    1092045 <myl_native_octets_find+0x2c5>
 1091e3b:	cmp    %r10,%rax
 1091e3e:	je     109203e <myl_native_octets_find+0x2be>
 1091e44:	mov    %r10,-0x38(%rbp)
 1091e48:	mov    %r11,%r14
 1091e4b:	mov    %r11,%rdx
 1091e4e:	sub    %rdi,%rdx
 1091e51:	mov    %r12d,%esi
 1091e54:	call   10ab5e0 <memchr@plt>
 1091e59:	test   %rax,%rax
 1091e5c:	je     109203e <myl_native_octets_find+0x2be>
 1091e62:	lea    0x1(%rax),%rdi
 1091e66:	mov    $0x1,%edx
 1091e6b:	mov    %r13,%rcx
 1091e6e:	mov    -0x30(%rbp),%rsi
 1091e72:	mov    %r15,%r8
 1091e75:	mov    -0x38(%rbp),%r10
 1091e79:	mov    %r14,%r11
 1091e7c:	nopl   0x0(%rax)
 1091e80:	movzbl (%rax,%rdx,1),%r9d
 1091e85:	cmp    (%r8,%rdx,1),%r9b
 1091e89:	jne    1091e95 <myl_native_octets_find+0x115>
 1091e8b:	inc    %rdx
 1091e8e:	cmp    %rdx,%rsi
 1091e91:	jne    1091e80 <myl_native_octets_find+0x100>
 1091e93:	jmp    1091e33 <myl_native_octets_find+0xb3>
 1091e95:	cmp    %r10,%rax
 1091e98:	je     109203e <myl_native_octets_find+0x2be>
 1091e9e:	mov    %r11,%rdx
 1091ea1:	sub    %rdi,%rdx
 1091ea4:	mov    %r12d,%esi
 1091ea7:	call   10ab5e0 <memchr@plt>
 1091eac:	test   %rax,%rax
 1091eaf:	je     109203e <myl_native_octets_find+0x2be>
 1091eb5:	lea    0x1(%rax),%rdi
 1091eb9:	mov    $0x1,%edx
 1091ebe:	mov    %r13,%rcx
 1091ec1:	mov    -0x30(%rbp),%rsi
 1091ec5:	mov    %r15,%r8
 1091ec8:	mov    -0x38(%rbp),%r10
 1091ecc:	mov    %r14,%r11
 1091ecf:	movzbl (%rax,%rdx,1),%r9d
 1091ed4:	cmp    (%r8,%rdx,1),%r9b
 1091ed8:	jne    1091ee7 <myl_native_octets_find+0x167>
 1091eda:	inc    %rdx
 1091edd:	cmp    %rdx,%rsi
 1091ee0:	jne    1091ecf <myl_native_octets_find+0x14f>
 1091ee2:	jmp    1091e33 <myl_native_octets_find+0xb3>
 1091ee7:	cmp    %r10,%rax
 1091eea:	je     109203e <myl_native_octets_find+0x2be>
 1091ef0:	mov    %r11,%rdx
 1091ef3:	sub    %rdi,%rdx
 1091ef6:	mov    %r12d,%esi
 1091ef9:	call   10ab5e0 <memchr@plt>
 1091efe:	test   %rax,%rax
 1091f01:	je     109203e <myl_native_octets_find+0x2be>
 1091f07:	lea    0x1(%rax),%rdi
 1091f0b:	mov    $0x1,%edx
 1091f10:	mov    %r13,%rcx
 1091f13:	mov    -0x30(%rbp),%rsi
 1091f17:	mov    %r15,%r8
 1091f1a:	mov    -0x38(%rbp),%r10
 1091f1e:	mov    %r14,%r11
 1091f21:	movzbl (%rax,%rdx,1),%r9d
 1091f26:	cmp    (%r8,%rdx,1),%r9b
 1091f2a:	jne    1091f39 <myl_native_octets_find+0x1b9>
 1091f2c:	inc    %rdx
 1091f2f:	cmp    %rdx,%rsi
 1091f32:	jne    1091f21 <myl_native_octets_find+0x1a1>
 1091f34:	jmp    1091e33 <myl_native_octets_find+0xb3>
 1091f39:	cmp    %r10,%rax
 1091f3c:	je     109203e <myl_native_octets_find+0x2be>
 1091f42:	mov    %r11,%rdx
 1091f45:	sub    %rdi,%rdx
 1091f48:	mov    %r12d,%esi
 1091f4b:	call   10ab5e0 <memchr@plt>
 1091f50:	test   %rax,%rax
 1091f53:	je     109203e <myl_native_octets_find+0x2be>
 1091f59:	lea    0x1(%rax),%rdi
 1091f5d:	mov    $0x1,%ecx
 1091f62:	mov    -0x30(%rbp),%rdx
 1091f66:	mov    %r15,%rsi
 1091f69:	movzbl (%rax,%rcx,1),%r8d
 1091f6e:	cmp    (%rsi,%rcx,1),%r8b
 1091f72:	jne    1091f84 <myl_native_octets_find+0x204>
 1091f74:	inc    %rcx
 1091f77:	cmp    %rcx,%rdx
 1091f7a:	jne    1091f69 <myl_native_octets_find+0x1e9>
 1091f7c:	mov    %r13,%rcx
 1091f7f:	jmp    1091e33 <myl_native_octets_find+0xb3>
 1091f84:	cmp    -0x38(%rbp),%rax
 1091f88:	je     109203e <myl_native_octets_find+0x2be>
 1091f8e:	mov    %r14,%rdx
 1091f91:	sub    %rdi,%rdx
 1091f94:	mov    %r12d,%esi
 1091f97:	call   10ab5e0 <memchr@plt>
 1091f9c:	test   %rax,%rax
 1091f9f:	je     109203e <myl_native_octets_find+0x2be>
 1091fa5:	lea    0x1(%rax),%rdi
 1091fa9:	mov    $0x1,%ecx
 1091fae:	mov    -0x30(%rbp),%rdx
 1091fb2:	mov    %r15,%rsi
 1091fb5:	movzbl (%rax,%rcx,1),%r8d
 1091fba:	cmp    (%rsi,%rcx,1),%r8b
 1091fbe:	jne    1091fca <myl_native_octets_find+0x24a>
 1091fc0:	inc    %rcx
 1091fc3:	cmp    %rcx,%rdx
 1091fc6:	jne    1091fb5 <myl_native_octets_find+0x235>
 1091fc8:	jmp    1091f7c <myl_native_octets_find+0x1fc>
 1091fca:	cmp    -0x38(%rbp),%rax
 1091fce:	je     109203e <myl_native_octets_find+0x2be>
 1091fd0:	mov    %r14,%rdx
 1091fd3:	sub    %rdi,%rdx
 1091fd6:	mov    %r12d,%esi
 1091fd9:	call   10ab5e0 <memchr@plt>
 1091fde:	test   %rax,%rax
 1091fe1:	je     109203e <myl_native_octets_find+0x2be>
 1091fe3:	lea    0x1(%rax),%rdi
 1091fe7:	mov    $0x1,%ecx
 1091fec:	movzbl (%rax,%rcx,1),%edx
 1091ff0:	cmp    (%r15,%rcx,1),%dl
 1091ff4:	jne    1092004 <myl_native_octets_find+0x284>
 1091ff6:	inc    %rcx
 1091ff9:	cmp    %rcx,-0x30(%rbp)
 1091ffd:	jne    1091fec <myl_native_octets_find+0x26c>
 1091fff:	jmp    1091f7c <myl_native_octets_find+0x1fc>
 1092004:	cmp    -0x38(%rbp),%rax
 1092008:	je     109203e <myl_native_octets_find+0x2be>
 109200a:	sub    %rdi,%r14
 109200d:	mov    %r12d,%esi
 1092010:	mov    %r14,%rdx
 1092013:	call   10ab5e0 <memchr@plt>
 1092018:	test   %rax,%rax
 109201b:	je     109203e <myl_native_octets_find+0x2be>
 109201d:	lea    0x1(%rax),%rdi
 1092021:	mov    $0x1,%ecx
 1092026:	movzbl (%rax,%rcx,1),%edx
 109202a:	cmp    (%r15,%rcx,1),%dl
 109202e:	jne    1092054 <myl_native_octets_find+0x2d4>
 1092030:	inc    %rcx
 1092033:	cmp    %rcx,-0x30(%rbp)
 1092037:	jne    1092026 <myl_native_octets_find+0x2a6>
 1092039:	jmp    1091f7c <myl_native_octets_find+0x1fc>
 109203e:	mov    $0xffffffffffffffff,%rax
 1092045:	add    $0x18,%rsp
 1092049:	pop    %rbx
 109204a:	pop    %r12
 109204c:	pop    %r13
 109204e:	pop    %r14
 1092050:	pop    %r15
 1092052:	pop    %rbp
 1092053:	ret
 1092054:	cmp    -0x38(%rbp),%rax
 1092058:	mov    $0xffffffffffffffff,%rax
 109205f:	je     1092045 <myl_native_octets_find+0x2c5>
 1092061:	add    %r13,%rbx
 1092064:	sub    %rdi,%rbx
 1092067:	mov    %rbx,%rsi
 109206a:	mov    %r15,%rdx
 109206d:	mov    -0x30(%rbp),%rcx
 1092071:	call   10ab5f0 <memmem@plt>
 1092076:	mov    %rax,%rcx
 1092079:	mov    %rax,%rdx
 109207c:	sub    %r13,%rdx
 109207f:	jmp    1091dc9 <myl_native_octets_find+0x49>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
