
/home/epentland/ai/canopy/mylang-worktrees/goal110-int-parse-20261004/.mylang-cache/goal110-int-parse/runner/bin/text-my-llvm:     file format elf64-x86-64


Disassembly of section .text:

000000000108f740 <index_walk>:
 108f740:	push   %rbp
 108f741:	mov    %rsp,%rbp
 108f744:	push   %r15
 108f746:	push   %r14
 108f748:	push   %rbx
 108f749:	push   %rax
 108f74a:	mov    0x8(%rdi),%rdx
 108f74e:	mov    %rdx,%rax
 108f751:	sub    %rsi,%rax
 108f754:	jbe    108f7ba <index_walk+0x7a>
 108f756:	mov    0x10(%rdi),%r9d
 108f75a:	lea    0x18(%rdi),%r8
 108f75e:	mov    %r8,%rcx
 108f761:	test   $0x4,%r9b
 108f765:	je     108f776 <index_walk+0x36>
 108f767:	mov    0x18(%rdi),%rcx
 108f76b:	mov    0x14(%rdi),%r10d
 108f76f:	add    %r10,%rcx
 108f772:	add    $0x18,%rcx
 108f776:	cmp    %rax,%rsi
 108f779:	mov    %rax,%r10
 108f77c:	cmovb  %rsi,%r10
 108f780:	cmp    $0x401,%r10
 108f787:	jb     108f7a7 <index_walk+0x67>
 108f789:	test   $0x8,%r9b
 108f78d:	jne    108f7d5 <index_walk+0x95>
 108f78f:	test   $0x4,%r9b
 108f793:	je     108f7a7 <index_walk+0x67>
 108f795:	mov    (%r8),%rbx
 108f798:	test   %rbx,%rbx
 108f79b:	je     108f7a7 <index_walk+0x67>
 108f79d:	testb  $0x8,0x10(%rbx)
 108f7a1:	jne    108fd77 <index_walk+0x637>
 108f7a7:	cmp    %rax,%rsi
 108f7aa:	jbe    108f7c2 <index_walk+0x82>
 108f7ac:	lea    0x8(%rsi),%rax
 108f7b0:	cmp    %rdx,%rax
 108f7b3:	jbe    108f7e4 <index_walk+0xa4>
 108f7b5:	xor    %r8d,%r8d
 108f7b8:	jmp    108f836 <index_walk+0xf6>
 108f7ba:	mov    (%rdi),%rax
 108f7bd:	jmp    108fda0 <index_walk+0x660>
 108f7c2:	cmp    $0x8,%rsi
 108f7c6:	jae    108f861 <index_walk+0x121>
 108f7cc:	xor    %eax,%eax
 108f7ce:	xor    %edx,%edx
 108f7d0:	jmp    108fa89 <index_walk+0x349>
 108f7d5:	add    $0x8,%rsp
 108f7d9:	pop    %rbx
 108f7da:	pop    %r14
 108f7dc:	pop    %r15
 108f7de:	pop    %rbp
 108f7df:	jmp    108fdc0 <index_at>
 108f7e4:	movabs $0x101010101010101,%rax
 108f7ee:	xor    %r8d,%r8d
 108f7f1:	mov    %rsi,%r9
 108f7f4:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 108f800:	mov    (%rcx,%r9,1),%rsi
 108f804:	mov    %rsi,%r10
 108f807:	not    %r10
 108f80a:	add    %r10,%r10
 108f80d:	and    %rsi,%r10
 108f810:	shr    $0x7,%r10
 108f814:	and    %rax,%r10
 108f817:	imul   %rax,%r10
 108f81b:	shr    $0x38,%r10
 108f81f:	sub    %r10,%r8
 108f822:	add    $0x8,%r8
 108f826:	lea    0x8(%r9),%rsi
 108f82a:	add    $0x10,%r9
 108f82e:	cmp    %rdx,%r9
 108f831:	mov    %rsi,%r9
 108f834:	jbe    108f800 <index_walk+0xc0>
 108f836:	mov    (%rdi),%rax
 108f839:	mov    %rdx,%rdi
 108f83c:	sub    %rsi,%rdi
 108f83f:	jbe    108fc05 <index_walk+0x4c5>
 108f845:	cmp    $0x3,%rdi
 108f849:	jbe    108fbf0 <index_walk+0x4b0>
 108f84f:	cmp    $0x10,%rdi
 108f853:	jae    108fab1 <index_walk+0x371>
 108f859:	xor    %r9d,%r9d
 108f85c:	jmp    108fb8f <index_walk+0x44f>
 108f861:	lea    -0x8(%rsi),%r8
 108f865:	cmp    $0x78,%r8
 108f869:	jae    108f879 <index_walk+0x139>
 108f86b:	mov    $0x8,%edi
 108f870:	xor    %edx,%edx
 108f872:	xor    %eax,%eax
 108f874:	jmp    108fa41 <index_walk+0x301>
 108f879:	shr    $0x3,%r8
 108f87d:	inc    %r8
 108f880:	mov    %r8,%r9
 108f883:	and    $0xfffffffffffffff0,%r9
 108f887:	lea    0x0(,%r9,8),%rdx
 108f88f:	lea    0x8(,%r9,8),%rdi
 108f897:	vpxor  %xmm2,%xmm2,%xmm2
 108f89b:	xor    %eax,%eax
 108f89d:	vpbroadcastq -0x88766(%rip),%ymm0        # 1007140 <__abi_tag+0x6e44>
 108f8a6:	vpbroadcastq -0x88767(%rip),%ymm1        # 1007148 <__abi_tag+0x6e4c>
 108f8af:	vpbroadcastq -0x887e8(%rip),%ymm3        # 10070d0 <__abi_tag+0x6dd4>
 108f8b8:	vpcmpeqd %ymm4,%ymm4,%ymm4
 108f8bc:	vpxor  %xmm7,%xmm7,%xmm7
 108f8c0:	vpxor  %xmm6,%xmm6,%xmm6
 108f8c4:	vpxor  %xmm5,%xmm5,%xmm5
 108f8c8:	nopl   0x0(%rax,%rax,1)
 108f8d0:	vmovdqu (%rcx,%rax,8),%ymm8
 108f8d5:	vmovdqu 0x20(%rcx,%rax,8),%ymm9
 108f8db:	vmovdqu 0x40(%rcx,%rax,8),%ymm10
 108f8e1:	vmovdqu 0x60(%rcx,%rax,8),%ymm11
 108f8e7:	vpxor  %ymm4,%ymm8,%ymm12
 108f8eb:	vpaddq %ymm12,%ymm12,%ymm12
 108f8f0:	vpxor  %ymm4,%ymm9,%ymm13
 108f8f4:	vpaddq %ymm13,%ymm13,%ymm13
 108f8f9:	vpxor  %ymm4,%ymm10,%ymm14
 108f8fd:	vpaddq %ymm14,%ymm14,%ymm14
 108f902:	vpxor  %ymm4,%ymm11,%ymm15
 108f906:	vpaddq %ymm15,%ymm15,%ymm15
 108f90b:	vpand  %ymm12,%ymm8,%ymm8
 108f910:	vpand  %ymm13,%ymm9,%ymm9
 108f915:	vpand  %ymm14,%ymm10,%ymm10
 108f91a:	vpand  %ymm15,%ymm11,%ymm11
 108f91f:	vpsrlq $0x7,%ymm8,%ymm8
 108f925:	vpsrlq $0x7,%ymm9,%ymm9
 108f92b:	vpsrlq $0x7,%ymm10,%ymm10
 108f931:	vpsrlq $0x7,%ymm11,%ymm11
 108f937:	vpand  %ymm0,%ymm8,%ymm8
 108f93b:	vpand  %ymm0,%ymm9,%ymm9
 108f93f:	vpand  %ymm0,%ymm10,%ymm10
 108f943:	vpand  %ymm0,%ymm11,%ymm11
 108f947:	vpmuludq %ymm1,%ymm8,%ymm12
 108f94b:	vpsrlq $0x20,%ymm8,%ymm13
 108f951:	vpmuludq %ymm0,%ymm13,%ymm13
 108f955:	vpaddq %ymm13,%ymm12,%ymm12
 108f95a:	vpsllq $0x20,%ymm12,%ymm12
 108f960:	vpmuludq %ymm0,%ymm8,%ymm8
 108f964:	vpaddq %ymm12,%ymm8,%ymm8
 108f969:	vpmuludq %ymm1,%ymm9,%ymm12
 108f96d:	vpsrlq $0x20,%ymm9,%ymm13
 108f973:	vpmuludq %ymm0,%ymm13,%ymm13
 108f977:	vpaddq %ymm13,%ymm12,%ymm12
 108f97c:	vpsllq $0x20,%ymm12,%ymm12
 108f982:	vpmuludq %ymm0,%ymm9,%ymm9
 108f986:	vpaddq %ymm12,%ymm9,%ymm9
 108f98b:	vpmuludq %ymm1,%ymm10,%ymm12
 108f98f:	vpsrlq $0x20,%ymm10,%ymm13
 108f995:	vpmuludq %ymm0,%ymm13,%ymm13
 108f999:	vpaddq %ymm13,%ymm12,%ymm12
 108f99e:	vpsllq $0x20,%ymm12,%ymm12
 108f9a4:	vpmuludq %ymm0,%ymm10,%ymm10
 108f9a8:	vpaddq %ymm12,%ymm10,%ymm10
 108f9ad:	vpmuludq %ymm1,%ymm11,%ymm12
 108f9b1:	vpsrlq $0x20,%ymm11,%ymm13
 108f9b7:	vpmuludq %ymm0,%ymm13,%ymm13
 108f9bb:	vpaddq %ymm13,%ymm12,%ymm12
 108f9c0:	vpsllq $0x20,%ymm12,%ymm12
 108f9c6:	vpmuludq %ymm0,%ymm11,%ymm11
 108f9ca:	vpaddq %ymm12,%ymm11,%ymm11
 108f9cf:	vpsrlq $0x38,%ymm8,%ymm8
 108f9d5:	vpsubq %ymm8,%ymm2,%ymm2
 108f9da:	vpsrlq $0x38,%ymm9,%ymm8
 108f9e0:	vpsubq %ymm8,%ymm7,%ymm7
 108f9e5:	vpsrlq $0x38,%ymm10,%ymm8
 108f9eb:	vpsubq %ymm8,%ymm6,%ymm6
 108f9f0:	vpsrlq $0x38,%ymm11,%ymm8
 108f9f6:	vpsubq %ymm8,%ymm5,%ymm5
 108f9fb:	vpaddq %ymm3,%ymm2,%ymm2
 108f9ff:	vpaddq %ymm3,%ymm7,%ymm7
 108fa03:	vpaddq %ymm3,%ymm6,%ymm6
 108fa07:	vpaddq %ymm3,%ymm5,%ymm5
 108fa0b:	add    $0x10,%rax
 108fa0f:	cmp    %rax,%r9
 108fa12:	jne    108f8d0 <index_walk+0x190>
 108fa18:	vpaddq %ymm2,%ymm7,%ymm0
 108fa1c:	vpaddq %ymm0,%ymm6,%ymm0
 108fa20:	vpaddq %ymm0,%ymm5,%ymm0
 108fa24:	vextracti128 $0x1,%ymm0,%xmm1
 108fa2a:	vpaddq %xmm1,%xmm0,%xmm0
 108fa2e:	vpshufd $0xee,%xmm0,%xmm1
 108fa33:	vpaddq %xmm1,%xmm0,%xmm0
 108fa37:	vmovq  %xmm0,%rax
 108fa3c:	cmp    %r9,%r8
 108fa3f:	je     108fa89 <index_walk+0x349>
 108fa41:	movabs $0x101010101010101,%r8
 108fa4b:	nopl   0x0(%rax,%rax,1)
 108fa50:	mov    (%rcx,%rdx,1),%r9
 108fa54:	mov    %rdi,%rdx
 108fa57:	mov    %r9,%rdi
 108fa5a:	not    %rdi
 108fa5d:	add    %rdi,%rdi
 108fa60:	and    %r9,%rdi
 108fa63:	shr    $0x7,%rdi
 108fa67:	and    %r8,%rdi
 108fa6a:	imul   %r8,%rdi
 108fa6e:	shr    $0x38,%rdi
 108fa72:	sub    %rdi,%rax
 108fa75:	add    $0x8,%rax
 108fa79:	lea    0x8(%rdx),%rdi
 108fa7d:	cmp    %rsi,%rdi
 108fa80:	jbe    108fa50 <index_walk+0x310>
 108fa82:	add    $0xfffffffffffffff8,%rdi
 108fa86:	mov    %rdi,%rdx
 108fa89:	mov    %rsi,%rdi
 108fa8c:	sub    %rdx,%rdi
 108fa8f:	jbe    108fda0 <index_walk+0x660>
 108fa95:	cmp    $0x3,%rdi
 108fa99:	jbe    108fd60 <index_walk+0x620>
 108fa9f:	cmp    $0x10,%rdi
 108faa3:	jae    108fc0d <index_walk+0x4cd>
 108faa9:	xor    %r8d,%r8d
 108faac:	jmp    108fcef <index_walk+0x5af>
 108fab1:	mov    %rdi,%r9
 108fab4:	and    $0xfffffffffffffff0,%r9
 108fab8:	vmovq  %r8,%xmm0
 108fabd:	lea    (%rsi,%rcx,1),%r8
 108fac1:	add    $0xc,%r8
 108fac5:	vpxor  %xmm1,%xmm1,%xmm1
 108fac9:	xor    %r10d,%r10d
 108facc:	vmovdqa -0x8e0a4(%rip),%xmm2        # 1001a30 <__abi_tag+0x1734>
 108fad4:	vpbroadcastq -0x889c5(%rip),%ymm3        # 1007118 <__abi_tag+0x6e1c>
 108fadd:	vpxor  %xmm4,%xmm4,%xmm4
 108fae1:	vpxor  %xmm5,%xmm5,%xmm5
 108fae5:	data16 cs nopw 0x0(%rax,%rax,1)
 108faf0:	vmovd  -0xc(%r8,%r10,1),%xmm6
 108faf7:	vmovd  -0x8(%r8,%r10,1),%xmm7
 108fafe:	vmovd  -0x4(%r8,%r10,1),%xmm8
 108fb05:	vmovd  (%r8,%r10,1),%xmm9
 108fb0b:	vpcmpgtb %xmm2,%xmm6,%xmm6
 108fb0f:	vpmovzxbq %xmm6,%ymm6
 108fb14:	vpand  %ymm3,%ymm6,%ymm6
 108fb18:	vpaddq %ymm6,%ymm0,%ymm0
 108fb1c:	vpcmpgtb %xmm2,%xmm7,%xmm6
 108fb20:	vpmovzxbq %xmm6,%ymm6
 108fb25:	vpand  %ymm3,%ymm6,%ymm6
 108fb29:	vpaddq %ymm6,%ymm1,%ymm1
 108fb2d:	vpcmpgtb %xmm2,%xmm8,%xmm6
 108fb31:	vpmovzxbq %xmm6,%ymm6
 108fb36:	vpand  %ymm3,%ymm6,%ymm6
 108fb3a:	vpaddq %ymm6,%ymm4,%ymm4
 108fb3e:	vpcmpgtb %xmm2,%xmm9,%xmm6
 108fb42:	vpmovzxbq %xmm6,%ymm6
 108fb47:	vpand  %ymm3,%ymm6,%ymm6
 108fb4b:	vpaddq %ymm6,%ymm5,%ymm5
 108fb4f:	add    $0x10,%r10
 108fb53:	cmp    %r10,%r9
 108fb56:	jne    108faf0 <index_walk+0x3b0>
 108fb58:	vpaddq %ymm0,%ymm1,%ymm0
 108fb5c:	vpaddq %ymm0,%ymm4,%ymm0
 108fb60:	vpaddq %ymm0,%ymm5,%ymm0
 108fb64:	vextracti128 $0x1,%ymm0,%xmm1
 108fb6a:	vpaddq %xmm1,%xmm0,%xmm0
 108fb6e:	vpshufd $0xee,%xmm0,%xmm1
 108fb73:	vpaddq %xmm1,%xmm0,%xmm0
 108fb77:	vmovq  %xmm0,%r8
 108fb7c:	cmp    %r9,%rdi
 108fb7f:	je     108fc05 <index_walk+0x4c5>
 108fb85:	test   $0xc,%dil
 108fb89:	je     108fdae <index_walk+0x66e>
 108fb8f:	mov    %rdi,%r10
 108fb92:	and    $0xfffffffffffffffc,%r10
 108fb96:	vmovq  %r8,%xmm0
 108fb9b:	lea    (%rcx,%rsi,1),%r8
 108fb9f:	vmovdqa -0x8e177(%rip),%xmm1        # 1001a30 <__abi_tag+0x1734>
 108fba7:	vpbroadcastq -0x88a98(%rip),%ymm2        # 1007118 <__abi_tag+0x6e1c>
 108fbb0:	vmovd  (%r8,%r9,1),%xmm3
 108fbb6:	vpcmpgtb %xmm1,%xmm3,%xmm3
 108fbba:	vpmovzxbq %xmm3,%ymm3
 108fbbf:	vpand  %ymm2,%ymm3,%ymm3
 108fbc3:	vpaddq %ymm3,%ymm0,%ymm0
 108fbc7:	add    $0x4,%r9
 108fbcb:	cmp    %r9,%r10
 108fbce:	jne    108fbb0 <index_walk+0x470>
 108fbd0:	vextracti128 $0x1,%ymm0,%xmm1
 108fbd6:	vpaddq %xmm1,%xmm0,%xmm0
 108fbda:	vpshufd $0xee,%xmm0,%xmm1
 108fbdf:	vpaddq %xmm1,%xmm0,%xmm0
 108fbe3:	vmovq  %xmm0,%r8
 108fbe8:	cmp    %r10,%rdi
 108fbeb:	je     108fc05 <index_walk+0x4c5>
 108fbed:	add    %r10,%rsi
 108fbf0:	xor    %edi,%edi
 108fbf2:	cmpb   $0xc0,(%rcx,%rsi,1)
 108fbf6:	setge  %dil
 108fbfa:	add    %rdi,%r8
 108fbfd:	inc    %rsi
 108fc00:	cmp    %rsi,%rdx
 108fc03:	jne    108fbf0 <index_walk+0x4b0>
 108fc05:	sub    %r8,%rax
 108fc08:	jmp    108fda0 <index_walk+0x660>
 108fc0d:	mov    %rdi,%r8
 108fc10:	and    $0xfffffffffffffff0,%r8
 108fc14:	vmovq  %rax,%xmm0
 108fc19:	lea    (%rdx,%rcx,1),%rax
 108fc1d:	add    $0xc,%rax
 108fc21:	vpxor  %xmm1,%xmm1,%xmm1
 108fc25:	xor    %r9d,%r9d
 108fc28:	vmovdqa -0x8e200(%rip),%xmm2        # 1001a30 <__abi_tag+0x1734>
 108fc30:	vpbroadcastq -0x88b21(%rip),%ymm3        # 1007118 <__abi_tag+0x6e1c>
 108fc39:	vpxor  %xmm4,%xmm4,%xmm4
 108fc3d:	vpxor  %xmm5,%xmm5,%xmm5
 108fc41:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 108fc50:	vmovd  -0xc(%rax,%r9,1),%xmm6
 108fc57:	vmovd  -0x8(%rax,%r9,1),%xmm7
 108fc5e:	vmovd  -0x4(%rax,%r9,1),%xmm8
 108fc65:	vmovd  (%rax,%r9,1),%xmm9
 108fc6b:	vpcmpgtb %xmm2,%xmm6,%xmm6
 108fc6f:	vpmovzxbq %xmm6,%ymm6
 108fc74:	vpand  %ymm3,%ymm6,%ymm6
 108fc78:	vpaddq %ymm6,%ymm0,%ymm0
 108fc7c:	vpcmpgtb %xmm2,%xmm7,%xmm6
 108fc80:	vpmovzxbq %xmm6,%ymm6
 108fc85:	vpand  %ymm3,%ymm6,%ymm6
 108fc89:	vpaddq %ymm6,%ymm1,%ymm1
 108fc8d:	vpcmpgtb %xmm2,%xmm8,%xmm6
 108fc91:	vpmovzxbq %xmm6,%ymm6
 108fc96:	vpand  %ymm3,%ymm6,%ymm6
 108fc9a:	vpaddq %ymm6,%ymm4,%ymm4
 108fc9e:	vpcmpgtb %xmm2,%xmm9,%xmm6
 108fca2:	vpmovzxbq %xmm6,%ymm6
 108fca7:	vpand  %ymm3,%ymm6,%ymm6
 108fcab:	vpaddq %ymm6,%ymm5,%ymm5
 108fcaf:	add    $0x10,%r9
 108fcb3:	cmp    %r9,%r8
 108fcb6:	jne    108fc50 <index_walk+0x510>
 108fcb8:	vpaddq %ymm0,%ymm1,%ymm0
 108fcbc:	vpaddq %ymm0,%ymm4,%ymm0
 108fcc0:	vpaddq %ymm0,%ymm5,%ymm0
 108fcc4:	vextracti128 $0x1,%ymm0,%xmm1
 108fcca:	vpaddq %xmm1,%xmm0,%xmm0
 108fcce:	vpshufd $0xee,%xmm0,%xmm1
 108fcd3:	vpaddq %xmm1,%xmm0,%xmm0
 108fcd7:	vmovq  %xmm0,%rax
 108fcdc:	cmp    %r8,%rdi
 108fcdf:	je     108fda0 <index_walk+0x660>
 108fce5:	test   $0xc,%dil
 108fce9:	je     108fdb6 <index_walk+0x676>
 108fcef:	mov    %esi,%r9d
 108fcf2:	and    $0x3,%r9d
 108fcf6:	sub    %r9,%rdi
 108fcf9:	vmovq  %rax,%xmm0
 108fcfe:	mov    %rsi,%rax
 108fd01:	and    $0xfffffffffffffffc,%rax
 108fd05:	add    %rdx,%r8
 108fd08:	vmovdqa -0x8e2e0(%rip),%xmm1        # 1001a30 <__abi_tag+0x1734>
 108fd10:	vpbroadcastq -0x88c01(%rip),%ymm2        # 1007118 <__abi_tag+0x6e1c>
 108fd19:	nopl   0x0(%rax)
 108fd20:	vmovd  (%rcx,%r8,1),%xmm3
 108fd26:	vpcmpgtb %xmm1,%xmm3,%xmm3
 108fd2a:	vpmovzxbq %xmm3,%ymm3
 108fd2f:	vpand  %ymm2,%ymm3,%ymm3
 108fd33:	vpaddq %ymm3,%ymm0,%ymm0
 108fd37:	add    $0x4,%r8
 108fd3b:	cmp    %r8,%rax
 108fd3e:	jne    108fd20 <index_walk+0x5e0>
 108fd40:	vextracti128 $0x1,%ymm0,%xmm1
 108fd46:	vpaddq %xmm1,%xmm0,%xmm0
 108fd4a:	vpshufd $0xee,%xmm0,%xmm1
 108fd4f:	vpaddq %xmm1,%xmm0,%xmm0
 108fd53:	vmovq  %xmm0,%rax
 108fd58:	test   %r9,%r9
 108fd5b:	je     108fda0 <index_walk+0x660>
 108fd5d:	add    %rdi,%rdx
 108fd60:	xor    %edi,%edi
 108fd62:	cmpb   $0xc0,(%rcx,%rdx,1)
 108fd66:	setge  %dil
 108fd6a:	add    %rdi,%rax
 108fd6d:	inc    %rdx
 108fd70:	cmp    %rdx,%rsi
 108fd73:	jne    108fd60 <index_walk+0x620>
 108fd75:	jmp    108fda0 <index_walk+0x660>
 108fd77:	mov    0x14(%rdi),%eax
 108fd7a:	add    %rax,%rsi
 108fd7d:	mov    %rdi,%r15
 108fd80:	mov    %rbx,%rdi
 108fd83:	call   108fdc0 <index_at>
 108fd88:	mov    %rax,%r14
 108fd8b:	mov    0x14(%r15),%esi
 108fd8f:	mov    %rbx,%rdi
 108fd92:	call   108fdc0 <index_at>
 108fd97:	mov    %rax,%rcx
 108fd9a:	mov    %r14,%rax
 108fd9d:	sub    %rcx,%rax
 108fda0:	add    $0x8,%rsp
 108fda4:	pop    %rbx
 108fda5:	pop    %r14
 108fda7:	pop    %r15
 108fda9:	pop    %rbp
 108fdaa:	vzeroupper
 108fdad:	ret
 108fdae:	add    %r9,%rsi
 108fdb1:	jmp    108fbf0 <index_walk+0x4b0>
 108fdb6:	add    %r8,%rdx
 108fdb9:	jmp    108fd60 <index_walk+0x620>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
