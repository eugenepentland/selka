
.mylang-cache/goal110-search-align/runner/bin/text-my-llvm:     file format elf64-x86-64


Disassembly of section .text:

000000000108f770 <index_walk>:
 108f770:	push   %rbp
 108f771:	mov    %rsp,%rbp
 108f774:	push   %r15
 108f776:	push   %r14
 108f778:	push   %rbx
 108f779:	push   %rax
 108f77a:	mov    0x8(%rdi),%rdx
 108f77e:	mov    %rdx,%rax
 108f781:	sub    %rsi,%rax
 108f784:	jbe    108f7ea <index_walk+0x7a>
 108f786:	mov    0x10(%rdi),%r9d
 108f78a:	lea    0x18(%rdi),%r8
 108f78e:	mov    %r8,%rcx
 108f791:	test   $0x4,%r9b
 108f795:	je     108f7a6 <index_walk+0x36>
 108f797:	mov    0x18(%rdi),%rcx
 108f79b:	mov    0x14(%rdi),%r10d
 108f79f:	add    %r10,%rcx
 108f7a2:	add    $0x18,%rcx
 108f7a6:	cmp    %rax,%rsi
 108f7a9:	mov    %rax,%r10
 108f7ac:	cmovb  %rsi,%r10
 108f7b0:	cmp    $0x401,%r10
 108f7b7:	jb     108f7d7 <index_walk+0x67>
 108f7b9:	test   $0x8,%r9b
 108f7bd:	jne    108f805 <index_walk+0x95>
 108f7bf:	test   $0x4,%r9b
 108f7c3:	je     108f7d7 <index_walk+0x67>
 108f7c5:	mov    (%r8),%rbx
 108f7c8:	test   %rbx,%rbx
 108f7cb:	je     108f7d7 <index_walk+0x67>
 108f7cd:	testb  $0x8,0x10(%rbx)
 108f7d1:	jne    108fda7 <index_walk+0x637>
 108f7d7:	cmp    %rax,%rsi
 108f7da:	jbe    108f7f2 <index_walk+0x82>
 108f7dc:	lea    0x8(%rsi),%rax
 108f7e0:	cmp    %rdx,%rax
 108f7e3:	jbe    108f814 <index_walk+0xa4>
 108f7e5:	xor    %r8d,%r8d
 108f7e8:	jmp    108f866 <index_walk+0xf6>
 108f7ea:	mov    (%rdi),%rax
 108f7ed:	jmp    108fdd0 <index_walk+0x660>
 108f7f2:	cmp    $0x8,%rsi
 108f7f6:	jae    108f891 <index_walk+0x121>
 108f7fc:	xor    %eax,%eax
 108f7fe:	xor    %edx,%edx
 108f800:	jmp    108fab9 <index_walk+0x349>
 108f805:	add    $0x8,%rsp
 108f809:	pop    %rbx
 108f80a:	pop    %r14
 108f80c:	pop    %r15
 108f80e:	pop    %rbp
 108f80f:	jmp    108fdf0 <index_at>
 108f814:	movabs $0x101010101010101,%rax
 108f81e:	xor    %r8d,%r8d
 108f821:	mov    %rsi,%r9
 108f824:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 108f830:	mov    (%rcx,%r9,1),%rsi
 108f834:	mov    %rsi,%r10
 108f837:	not    %r10
 108f83a:	add    %r10,%r10
 108f83d:	and    %rsi,%r10
 108f840:	shr    $0x7,%r10
 108f844:	and    %rax,%r10
 108f847:	imul   %rax,%r10
 108f84b:	shr    $0x38,%r10
 108f84f:	sub    %r10,%r8
 108f852:	add    $0x8,%r8
 108f856:	lea    0x8(%r9),%rsi
 108f85a:	add    $0x10,%r9
 108f85e:	cmp    %rdx,%r9
 108f861:	mov    %rsi,%r9
 108f864:	jbe    108f830 <index_walk+0xc0>
 108f866:	mov    (%rdi),%rax
 108f869:	mov    %rdx,%rdi
 108f86c:	sub    %rsi,%rdi
 108f86f:	jbe    108fc35 <index_walk+0x4c5>
 108f875:	cmp    $0x3,%rdi
 108f879:	jbe    108fc20 <index_walk+0x4b0>
 108f87f:	cmp    $0x10,%rdi
 108f883:	jae    108fae1 <index_walk+0x371>
 108f889:	xor    %r9d,%r9d
 108f88c:	jmp    108fbbf <index_walk+0x44f>
 108f891:	lea    -0x8(%rsi),%r8
 108f895:	cmp    $0x78,%r8
 108f899:	jae    108f8a9 <index_walk+0x139>
 108f89b:	mov    $0x8,%edi
 108f8a0:	xor    %edx,%edx
 108f8a2:	xor    %eax,%eax
 108f8a4:	jmp    108fa71 <index_walk+0x301>
 108f8a9:	shr    $0x3,%r8
 108f8ad:	inc    %r8
 108f8b0:	mov    %r8,%r9
 108f8b3:	and    $0xfffffffffffffff0,%r9
 108f8b7:	lea    0x0(,%r9,8),%rdx
 108f8bf:	lea    0x8(,%r9,8),%rdi
 108f8c7:	vpxor  %xmm2,%xmm2,%xmm2
 108f8cb:	xor    %eax,%eax
 108f8cd:	vpbroadcastq -0x88796(%rip),%ymm0        # 1007140 <__abi_tag+0x6e44>
 108f8d6:	vpbroadcastq -0x88797(%rip),%ymm1        # 1007148 <__abi_tag+0x6e4c>
 108f8df:	vpbroadcastq -0x88818(%rip),%ymm3        # 10070d0 <__abi_tag+0x6dd4>
 108f8e8:	vpcmpeqd %ymm4,%ymm4,%ymm4
 108f8ec:	vpxor  %xmm7,%xmm7,%xmm7
 108f8f0:	vpxor  %xmm6,%xmm6,%xmm6
 108f8f4:	vpxor  %xmm5,%xmm5,%xmm5
 108f8f8:	nopl   0x0(%rax,%rax,1)
 108f900:	vmovdqu (%rcx,%rax,8),%ymm8
 108f905:	vmovdqu 0x20(%rcx,%rax,8),%ymm9
 108f90b:	vmovdqu 0x40(%rcx,%rax,8),%ymm10
 108f911:	vmovdqu 0x60(%rcx,%rax,8),%ymm11
 108f917:	vpxor  %ymm4,%ymm8,%ymm12
 108f91b:	vpaddq %ymm12,%ymm12,%ymm12
 108f920:	vpxor  %ymm4,%ymm9,%ymm13
 108f924:	vpaddq %ymm13,%ymm13,%ymm13
 108f929:	vpxor  %ymm4,%ymm10,%ymm14
 108f92d:	vpaddq %ymm14,%ymm14,%ymm14
 108f932:	vpxor  %ymm4,%ymm11,%ymm15
 108f936:	vpaddq %ymm15,%ymm15,%ymm15
 108f93b:	vpand  %ymm12,%ymm8,%ymm8
 108f940:	vpand  %ymm13,%ymm9,%ymm9
 108f945:	vpand  %ymm14,%ymm10,%ymm10
 108f94a:	vpand  %ymm15,%ymm11,%ymm11
 108f94f:	vpsrlq $0x7,%ymm8,%ymm8
 108f955:	vpsrlq $0x7,%ymm9,%ymm9
 108f95b:	vpsrlq $0x7,%ymm10,%ymm10
 108f961:	vpsrlq $0x7,%ymm11,%ymm11
 108f967:	vpand  %ymm0,%ymm8,%ymm8
 108f96b:	vpand  %ymm0,%ymm9,%ymm9
 108f96f:	vpand  %ymm0,%ymm10,%ymm10
 108f973:	vpand  %ymm0,%ymm11,%ymm11
 108f977:	vpmuludq %ymm1,%ymm8,%ymm12
 108f97b:	vpsrlq $0x20,%ymm8,%ymm13
 108f981:	vpmuludq %ymm0,%ymm13,%ymm13
 108f985:	vpaddq %ymm13,%ymm12,%ymm12
 108f98a:	vpsllq $0x20,%ymm12,%ymm12
 108f990:	vpmuludq %ymm0,%ymm8,%ymm8
 108f994:	vpaddq %ymm12,%ymm8,%ymm8
 108f999:	vpmuludq %ymm1,%ymm9,%ymm12
 108f99d:	vpsrlq $0x20,%ymm9,%ymm13
 108f9a3:	vpmuludq %ymm0,%ymm13,%ymm13
 108f9a7:	vpaddq %ymm13,%ymm12,%ymm12
 108f9ac:	vpsllq $0x20,%ymm12,%ymm12
 108f9b2:	vpmuludq %ymm0,%ymm9,%ymm9
 108f9b6:	vpaddq %ymm12,%ymm9,%ymm9
 108f9bb:	vpmuludq %ymm1,%ymm10,%ymm12
 108f9bf:	vpsrlq $0x20,%ymm10,%ymm13
 108f9c5:	vpmuludq %ymm0,%ymm13,%ymm13
 108f9c9:	vpaddq %ymm13,%ymm12,%ymm12
 108f9ce:	vpsllq $0x20,%ymm12,%ymm12
 108f9d4:	vpmuludq %ymm0,%ymm10,%ymm10
 108f9d8:	vpaddq %ymm12,%ymm10,%ymm10
 108f9dd:	vpmuludq %ymm1,%ymm11,%ymm12
 108f9e1:	vpsrlq $0x20,%ymm11,%ymm13
 108f9e7:	vpmuludq %ymm0,%ymm13,%ymm13
 108f9eb:	vpaddq %ymm13,%ymm12,%ymm12
 108f9f0:	vpsllq $0x20,%ymm12,%ymm12
 108f9f6:	vpmuludq %ymm0,%ymm11,%ymm11
 108f9fa:	vpaddq %ymm12,%ymm11,%ymm11
 108f9ff:	vpsrlq $0x38,%ymm8,%ymm8
 108fa05:	vpsubq %ymm8,%ymm2,%ymm2
 108fa0a:	vpsrlq $0x38,%ymm9,%ymm8
 108fa10:	vpsubq %ymm8,%ymm7,%ymm7
 108fa15:	vpsrlq $0x38,%ymm10,%ymm8
 108fa1b:	vpsubq %ymm8,%ymm6,%ymm6
 108fa20:	vpsrlq $0x38,%ymm11,%ymm8
 108fa26:	vpsubq %ymm8,%ymm5,%ymm5
 108fa2b:	vpaddq %ymm3,%ymm2,%ymm2
 108fa2f:	vpaddq %ymm3,%ymm7,%ymm7
 108fa33:	vpaddq %ymm3,%ymm6,%ymm6
 108fa37:	vpaddq %ymm3,%ymm5,%ymm5
 108fa3b:	add    $0x10,%rax
 108fa3f:	cmp    %rax,%r9
 108fa42:	jne    108f900 <index_walk+0x190>
 108fa48:	vpaddq %ymm2,%ymm7,%ymm0
 108fa4c:	vpaddq %ymm0,%ymm6,%ymm0
 108fa50:	vpaddq %ymm0,%ymm5,%ymm0
 108fa54:	vextracti128 $0x1,%ymm0,%xmm1
 108fa5a:	vpaddq %xmm1,%xmm0,%xmm0
 108fa5e:	vpshufd $0xee,%xmm0,%xmm1
 108fa63:	vpaddq %xmm1,%xmm0,%xmm0
 108fa67:	vmovq  %xmm0,%rax
 108fa6c:	cmp    %r9,%r8
 108fa6f:	je     108fab9 <index_walk+0x349>
 108fa71:	movabs $0x101010101010101,%r8
 108fa7b:	nopl   0x0(%rax,%rax,1)
 108fa80:	mov    (%rcx,%rdx,1),%r9
 108fa84:	mov    %rdi,%rdx
 108fa87:	mov    %r9,%rdi
 108fa8a:	not    %rdi
 108fa8d:	add    %rdi,%rdi
 108fa90:	and    %r9,%rdi
 108fa93:	shr    $0x7,%rdi
 108fa97:	and    %r8,%rdi
 108fa9a:	imul   %r8,%rdi
 108fa9e:	shr    $0x38,%rdi
 108faa2:	sub    %rdi,%rax
 108faa5:	add    $0x8,%rax
 108faa9:	lea    0x8(%rdx),%rdi
 108faad:	cmp    %rsi,%rdi
 108fab0:	jbe    108fa80 <index_walk+0x310>
 108fab2:	add    $0xfffffffffffffff8,%rdi
 108fab6:	mov    %rdi,%rdx
 108fab9:	mov    %rsi,%rdi
 108fabc:	sub    %rdx,%rdi
 108fabf:	jbe    108fdd0 <index_walk+0x660>
 108fac5:	cmp    $0x3,%rdi
 108fac9:	jbe    108fd90 <index_walk+0x620>
 108facf:	cmp    $0x10,%rdi
 108fad3:	jae    108fc3d <index_walk+0x4cd>
 108fad9:	xor    %r8d,%r8d
 108fadc:	jmp    108fd1f <index_walk+0x5af>
 108fae1:	mov    %rdi,%r9
 108fae4:	and    $0xfffffffffffffff0,%r9
 108fae8:	vmovq  %r8,%xmm0
 108faed:	lea    (%rsi,%rcx,1),%r8
 108faf1:	add    $0xc,%r8
 108faf5:	vpxor  %xmm1,%xmm1,%xmm1
 108faf9:	xor    %r10d,%r10d
 108fafc:	vmovdqa -0x8e0d4(%rip),%xmm2        # 1001a30 <__abi_tag+0x1734>
 108fb04:	vpbroadcastq -0x889f5(%rip),%ymm3        # 1007118 <__abi_tag+0x6e1c>
 108fb0d:	vpxor  %xmm4,%xmm4,%xmm4
 108fb11:	vpxor  %xmm5,%xmm5,%xmm5
 108fb15:	data16 cs nopw 0x0(%rax,%rax,1)
 108fb20:	vmovd  -0xc(%r8,%r10,1),%xmm6
 108fb27:	vmovd  -0x8(%r8,%r10,1),%xmm7
 108fb2e:	vmovd  -0x4(%r8,%r10,1),%xmm8
 108fb35:	vmovd  (%r8,%r10,1),%xmm9
 108fb3b:	vpcmpgtb %xmm2,%xmm6,%xmm6
 108fb3f:	vpmovzxbq %xmm6,%ymm6
 108fb44:	vpand  %ymm3,%ymm6,%ymm6
 108fb48:	vpaddq %ymm6,%ymm0,%ymm0
 108fb4c:	vpcmpgtb %xmm2,%xmm7,%xmm6
 108fb50:	vpmovzxbq %xmm6,%ymm6
 108fb55:	vpand  %ymm3,%ymm6,%ymm6
 108fb59:	vpaddq %ymm6,%ymm1,%ymm1
 108fb5d:	vpcmpgtb %xmm2,%xmm8,%xmm6
 108fb61:	vpmovzxbq %xmm6,%ymm6
 108fb66:	vpand  %ymm3,%ymm6,%ymm6
 108fb6a:	vpaddq %ymm6,%ymm4,%ymm4
 108fb6e:	vpcmpgtb %xmm2,%xmm9,%xmm6
 108fb72:	vpmovzxbq %xmm6,%ymm6
 108fb77:	vpand  %ymm3,%ymm6,%ymm6
 108fb7b:	vpaddq %ymm6,%ymm5,%ymm5
 108fb7f:	add    $0x10,%r10
 108fb83:	cmp    %r10,%r9
 108fb86:	jne    108fb20 <index_walk+0x3b0>
 108fb88:	vpaddq %ymm0,%ymm1,%ymm0
 108fb8c:	vpaddq %ymm0,%ymm4,%ymm0
 108fb90:	vpaddq %ymm0,%ymm5,%ymm0
 108fb94:	vextracti128 $0x1,%ymm0,%xmm1
 108fb9a:	vpaddq %xmm1,%xmm0,%xmm0
 108fb9e:	vpshufd $0xee,%xmm0,%xmm1
 108fba3:	vpaddq %xmm1,%xmm0,%xmm0
 108fba7:	vmovq  %xmm0,%r8
 108fbac:	cmp    %r9,%rdi
 108fbaf:	je     108fc35 <index_walk+0x4c5>
 108fbb5:	test   $0xc,%dil
 108fbb9:	je     108fdde <index_walk+0x66e>
 108fbbf:	mov    %rdi,%r10
 108fbc2:	and    $0xfffffffffffffffc,%r10
 108fbc6:	vmovq  %r8,%xmm0
 108fbcb:	lea    (%rcx,%rsi,1),%r8
 108fbcf:	vmovdqa -0x8e1a7(%rip),%xmm1        # 1001a30 <__abi_tag+0x1734>
 108fbd7:	vpbroadcastq -0x88ac8(%rip),%ymm2        # 1007118 <__abi_tag+0x6e1c>
 108fbe0:	vmovd  (%r8,%r9,1),%xmm3
 108fbe6:	vpcmpgtb %xmm1,%xmm3,%xmm3
 108fbea:	vpmovzxbq %xmm3,%ymm3
 108fbef:	vpand  %ymm2,%ymm3,%ymm3
 108fbf3:	vpaddq %ymm3,%ymm0,%ymm0
 108fbf7:	add    $0x4,%r9
 108fbfb:	cmp    %r9,%r10
 108fbfe:	jne    108fbe0 <index_walk+0x470>
 108fc00:	vextracti128 $0x1,%ymm0,%xmm1
 108fc06:	vpaddq %xmm1,%xmm0,%xmm0
 108fc0a:	vpshufd $0xee,%xmm0,%xmm1
 108fc0f:	vpaddq %xmm1,%xmm0,%xmm0
 108fc13:	vmovq  %xmm0,%r8
 108fc18:	cmp    %r10,%rdi
 108fc1b:	je     108fc35 <index_walk+0x4c5>
 108fc1d:	add    %r10,%rsi
 108fc20:	xor    %edi,%edi
 108fc22:	cmpb   $0xc0,(%rcx,%rsi,1)
 108fc26:	setge  %dil
 108fc2a:	add    %rdi,%r8
 108fc2d:	inc    %rsi
 108fc30:	cmp    %rsi,%rdx
 108fc33:	jne    108fc20 <index_walk+0x4b0>
 108fc35:	sub    %r8,%rax
 108fc38:	jmp    108fdd0 <index_walk+0x660>
 108fc3d:	mov    %rdi,%r8
 108fc40:	and    $0xfffffffffffffff0,%r8
 108fc44:	vmovq  %rax,%xmm0
 108fc49:	lea    (%rdx,%rcx,1),%rax
 108fc4d:	add    $0xc,%rax
 108fc51:	vpxor  %xmm1,%xmm1,%xmm1
 108fc55:	xor    %r9d,%r9d
 108fc58:	vmovdqa -0x8e230(%rip),%xmm2        # 1001a30 <__abi_tag+0x1734>
 108fc60:	vpbroadcastq -0x88b51(%rip),%ymm3        # 1007118 <__abi_tag+0x6e1c>
 108fc69:	vpxor  %xmm4,%xmm4,%xmm4
 108fc6d:	vpxor  %xmm5,%xmm5,%xmm5
 108fc71:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 108fc80:	vmovd  -0xc(%rax,%r9,1),%xmm6
 108fc87:	vmovd  -0x8(%rax,%r9,1),%xmm7
 108fc8e:	vmovd  -0x4(%rax,%r9,1),%xmm8
 108fc95:	vmovd  (%rax,%r9,1),%xmm9
 108fc9b:	vpcmpgtb %xmm2,%xmm6,%xmm6
 108fc9f:	vpmovzxbq %xmm6,%ymm6
 108fca4:	vpand  %ymm3,%ymm6,%ymm6
 108fca8:	vpaddq %ymm6,%ymm0,%ymm0
 108fcac:	vpcmpgtb %xmm2,%xmm7,%xmm6
 108fcb0:	vpmovzxbq %xmm6,%ymm6
 108fcb5:	vpand  %ymm3,%ymm6,%ymm6
 108fcb9:	vpaddq %ymm6,%ymm1,%ymm1
 108fcbd:	vpcmpgtb %xmm2,%xmm8,%xmm6
 108fcc1:	vpmovzxbq %xmm6,%ymm6
 108fcc6:	vpand  %ymm3,%ymm6,%ymm6
 108fcca:	vpaddq %ymm6,%ymm4,%ymm4
 108fcce:	vpcmpgtb %xmm2,%xmm9,%xmm6
 108fcd2:	vpmovzxbq %xmm6,%ymm6
 108fcd7:	vpand  %ymm3,%ymm6,%ymm6
 108fcdb:	vpaddq %ymm6,%ymm5,%ymm5
 108fcdf:	add    $0x10,%r9
 108fce3:	cmp    %r9,%r8
 108fce6:	jne    108fc80 <index_walk+0x510>
 108fce8:	vpaddq %ymm0,%ymm1,%ymm0
 108fcec:	vpaddq %ymm0,%ymm4,%ymm0
 108fcf0:	vpaddq %ymm0,%ymm5,%ymm0
 108fcf4:	vextracti128 $0x1,%ymm0,%xmm1
 108fcfa:	vpaddq %xmm1,%xmm0,%xmm0
 108fcfe:	vpshufd $0xee,%xmm0,%xmm1
 108fd03:	vpaddq %xmm1,%xmm0,%xmm0
 108fd07:	vmovq  %xmm0,%rax
 108fd0c:	cmp    %r8,%rdi
 108fd0f:	je     108fdd0 <index_walk+0x660>
 108fd15:	test   $0xc,%dil
 108fd19:	je     108fde6 <index_walk+0x676>
 108fd1f:	mov    %esi,%r9d
 108fd22:	and    $0x3,%r9d
 108fd26:	sub    %r9,%rdi
 108fd29:	vmovq  %rax,%xmm0
 108fd2e:	mov    %rsi,%rax
 108fd31:	and    $0xfffffffffffffffc,%rax
 108fd35:	add    %rdx,%r8
 108fd38:	vmovdqa -0x8e310(%rip),%xmm1        # 1001a30 <__abi_tag+0x1734>
 108fd40:	vpbroadcastq -0x88c31(%rip),%ymm2        # 1007118 <__abi_tag+0x6e1c>
 108fd49:	nopl   0x0(%rax)
 108fd50:	vmovd  (%rcx,%r8,1),%xmm3
 108fd56:	vpcmpgtb %xmm1,%xmm3,%xmm3
 108fd5a:	vpmovzxbq %xmm3,%ymm3
 108fd5f:	vpand  %ymm2,%ymm3,%ymm3
 108fd63:	vpaddq %ymm3,%ymm0,%ymm0
 108fd67:	add    $0x4,%r8
 108fd6b:	cmp    %r8,%rax
 108fd6e:	jne    108fd50 <index_walk+0x5e0>
 108fd70:	vextracti128 $0x1,%ymm0,%xmm1
 108fd76:	vpaddq %xmm1,%xmm0,%xmm0
 108fd7a:	vpshufd $0xee,%xmm0,%xmm1
 108fd7f:	vpaddq %xmm1,%xmm0,%xmm0
 108fd83:	vmovq  %xmm0,%rax
 108fd88:	test   %r9,%r9
 108fd8b:	je     108fdd0 <index_walk+0x660>
 108fd8d:	add    %rdi,%rdx
 108fd90:	xor    %edi,%edi
 108fd92:	cmpb   $0xc0,(%rcx,%rdx,1)
 108fd96:	setge  %dil
 108fd9a:	add    %rdi,%rax
 108fd9d:	inc    %rdx
 108fda0:	cmp    %rdx,%rsi
 108fda3:	jne    108fd90 <index_walk+0x620>
 108fda5:	jmp    108fdd0 <index_walk+0x660>
 108fda7:	mov    0x14(%rdi),%eax
 108fdaa:	add    %rax,%rsi
 108fdad:	mov    %rdi,%r15
 108fdb0:	mov    %rbx,%rdi
 108fdb3:	call   108fdf0 <index_at>
 108fdb8:	mov    %rax,%r14
 108fdbb:	mov    0x14(%r15),%esi
 108fdbf:	mov    %rbx,%rdi
 108fdc2:	call   108fdf0 <index_at>
 108fdc7:	mov    %rax,%rcx
 108fdca:	mov    %r14,%rax
 108fdcd:	sub    %rcx,%rax
 108fdd0:	add    $0x8,%rsp
 108fdd4:	pop    %rbx
 108fdd5:	pop    %r14
 108fdd7:	pop    %r15
 108fdd9:	pop    %rbp
 108fdda:	vzeroupper
 108fddd:	ret
 108fdde:	add    %r9,%rsi
 108fde1:	jmp    108fc20 <index_walk+0x4b0>
 108fde6:	add    %r8,%rdx
 108fde9:	jmp    108fd90 <index_walk+0x620>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
