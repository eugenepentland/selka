
/home/epentland/ai/canopy/mylang-worktrees/goal110-int-parse-20261004/.mylang-cache/goal110-int-parse/runner/bin/text-my-llvm:     file format elf64-x86-64


Disassembly of section .text:

0000000001091d20 <myl_native_octets_find>:
 1091d20:	test   %rcx,%rcx
 1091d23:	je     1091d7a <myl_native_octets_find+0x5a>
 1091d25:	push   %rbp
 1091d26:	mov    %rsp,%rbp
 1091d29:	push   %r15
 1091d2b:	push   %r14
 1091d2d:	push   %r13
 1091d2f:	push   %r12
 1091d31:	push   %rbx
 1091d32:	sub    $0x18,%rsp
 1091d36:	mov    $0xffffffffffffffff,%rax
 1091d3d:	mov    %rsi,%r14
 1091d40:	sub    %rcx,%r14
 1091d43:	jb     1091fe5 <myl_native_octets_find+0x2c5>
 1091d49:	mov    %rsi,%rbx
 1091d4c:	cmp    $0x1,%rcx
 1091d50:	jne    1091d7d <myl_native_octets_find+0x5d>
 1091d52:	movzbl (%rdx),%esi
 1091d55:	mov    %rdi,%r14
 1091d58:	mov    %rbx,%rdx
 1091d5b:	call   10ab580 <memchr@plt>
 1091d60:	mov    %rax,%rcx
 1091d63:	mov    %rax,%rdx
 1091d66:	sub    %r14,%rdx
 1091d69:	xor    %eax,%eax
 1091d6b:	cmp    $0x1,%rcx
 1091d6f:	sbb    %rax,%rax
 1091d72:	or     %rdx,%rax
 1091d75:	jmp    1091fe5 <myl_native_octets_find+0x2c5>
 1091d7a:	xor    %eax,%eax
 1091d7c:	ret
 1091d7d:	mov    %rcx,-0x30(%rbp)
 1091d81:	mov    %rdx,%r15
 1091d84:	movzbl (%rdx),%r12d
 1091d88:	lea    0x1(%r14),%rdx
 1091d8c:	mov    %rdi,%r13
 1091d8f:	mov    %r12d,%esi
 1091d92:	call   10ab580 <memchr@plt>
 1091d97:	test   %rax,%rax
 1091d9a:	je     1091fde <myl_native_octets_find+0x2be>
 1091da0:	mov    %r13,%rcx
 1091da3:	lea    (%r14,%r13,1),%r10
 1091da7:	lea    (%r14,%r13,1),%r11
 1091dab:	inc    %r11
 1091dae:	lea    0x1(%rax),%rdi
 1091db2:	mov    $0x1,%edx
 1091db7:	mov    -0x30(%rbp),%rsi
 1091dbb:	mov    %r15,%r8
 1091dbe:	xchg   %ax,%ax
 1091dc0:	movzbl (%rax,%rdx,1),%r9d
 1091dc5:	cmp    (%r8,%rdx,1),%r9b
 1091dc9:	jne    1091ddb <myl_native_octets_find+0xbb>
 1091dcb:	inc    %rdx
 1091dce:	cmp    %rdx,%rsi
 1091dd1:	jne    1091dc0 <myl_native_octets_find+0xa0>
 1091dd3:	sub    %rcx,%rax
 1091dd6:	jmp    1091fe5 <myl_native_octets_find+0x2c5>
 1091ddb:	cmp    %r10,%rax
 1091dde:	je     1091fde <myl_native_octets_find+0x2be>
 1091de4:	mov    %r10,-0x38(%rbp)
 1091de8:	mov    %r11,%r14
 1091deb:	mov    %r11,%rdx
 1091dee:	sub    %rdi,%rdx
 1091df1:	mov    %r12d,%esi
 1091df4:	call   10ab580 <memchr@plt>
 1091df9:	test   %rax,%rax
 1091dfc:	je     1091fde <myl_native_octets_find+0x2be>
 1091e02:	lea    0x1(%rax),%rdi
 1091e06:	mov    $0x1,%edx
 1091e0b:	mov    %r13,%rcx
 1091e0e:	mov    -0x30(%rbp),%rsi
 1091e12:	mov    %r15,%r8
 1091e15:	mov    -0x38(%rbp),%r10
 1091e19:	mov    %r14,%r11
 1091e1c:	nopl   0x0(%rax)
 1091e20:	movzbl (%rax,%rdx,1),%r9d
 1091e25:	cmp    (%r8,%rdx,1),%r9b
 1091e29:	jne    1091e35 <myl_native_octets_find+0x115>
 1091e2b:	inc    %rdx
 1091e2e:	cmp    %rdx,%rsi
 1091e31:	jne    1091e20 <myl_native_octets_find+0x100>
 1091e33:	jmp    1091dd3 <myl_native_octets_find+0xb3>
 1091e35:	cmp    %r10,%rax
 1091e38:	je     1091fde <myl_native_octets_find+0x2be>
 1091e3e:	mov    %r11,%rdx
 1091e41:	sub    %rdi,%rdx
 1091e44:	mov    %r12d,%esi
 1091e47:	call   10ab580 <memchr@plt>
 1091e4c:	test   %rax,%rax
 1091e4f:	je     1091fde <myl_native_octets_find+0x2be>
 1091e55:	lea    0x1(%rax),%rdi
 1091e59:	mov    $0x1,%edx
 1091e5e:	mov    %r13,%rcx
 1091e61:	mov    -0x30(%rbp),%rsi
 1091e65:	mov    %r15,%r8
 1091e68:	mov    -0x38(%rbp),%r10
 1091e6c:	mov    %r14,%r11
 1091e6f:	movzbl (%rax,%rdx,1),%r9d
 1091e74:	cmp    (%r8,%rdx,1),%r9b
 1091e78:	jne    1091e87 <myl_native_octets_find+0x167>
 1091e7a:	inc    %rdx
 1091e7d:	cmp    %rdx,%rsi
 1091e80:	jne    1091e6f <myl_native_octets_find+0x14f>
 1091e82:	jmp    1091dd3 <myl_native_octets_find+0xb3>
 1091e87:	cmp    %r10,%rax
 1091e8a:	je     1091fde <myl_native_octets_find+0x2be>
 1091e90:	mov    %r11,%rdx
 1091e93:	sub    %rdi,%rdx
 1091e96:	mov    %r12d,%esi
 1091e99:	call   10ab580 <memchr@plt>
 1091e9e:	test   %rax,%rax
 1091ea1:	je     1091fde <myl_native_octets_find+0x2be>
 1091ea7:	lea    0x1(%rax),%rdi
 1091eab:	mov    $0x1,%edx
 1091eb0:	mov    %r13,%rcx
 1091eb3:	mov    -0x30(%rbp),%rsi
 1091eb7:	mov    %r15,%r8
 1091eba:	mov    -0x38(%rbp),%r10
 1091ebe:	mov    %r14,%r11
 1091ec1:	movzbl (%rax,%rdx,1),%r9d
 1091ec6:	cmp    (%r8,%rdx,1),%r9b
 1091eca:	jne    1091ed9 <myl_native_octets_find+0x1b9>
 1091ecc:	inc    %rdx
 1091ecf:	cmp    %rdx,%rsi
 1091ed2:	jne    1091ec1 <myl_native_octets_find+0x1a1>
 1091ed4:	jmp    1091dd3 <myl_native_octets_find+0xb3>
 1091ed9:	cmp    %r10,%rax
 1091edc:	je     1091fde <myl_native_octets_find+0x2be>
 1091ee2:	mov    %r11,%rdx
 1091ee5:	sub    %rdi,%rdx
 1091ee8:	mov    %r12d,%esi
 1091eeb:	call   10ab580 <memchr@plt>
 1091ef0:	test   %rax,%rax
 1091ef3:	je     1091fde <myl_native_octets_find+0x2be>
 1091ef9:	lea    0x1(%rax),%rdi
 1091efd:	mov    $0x1,%ecx
 1091f02:	mov    -0x30(%rbp),%rdx
 1091f06:	mov    %r15,%rsi
 1091f09:	movzbl (%rax,%rcx,1),%r8d
 1091f0e:	cmp    (%rsi,%rcx,1),%r8b
 1091f12:	jne    1091f24 <myl_native_octets_find+0x204>
 1091f14:	inc    %rcx
 1091f17:	cmp    %rcx,%rdx
 1091f1a:	jne    1091f09 <myl_native_octets_find+0x1e9>
 1091f1c:	mov    %r13,%rcx
 1091f1f:	jmp    1091dd3 <myl_native_octets_find+0xb3>
 1091f24:	cmp    -0x38(%rbp),%rax
 1091f28:	je     1091fde <myl_native_octets_find+0x2be>
 1091f2e:	mov    %r14,%rdx
 1091f31:	sub    %rdi,%rdx
 1091f34:	mov    %r12d,%esi
 1091f37:	call   10ab580 <memchr@plt>
 1091f3c:	test   %rax,%rax
 1091f3f:	je     1091fde <myl_native_octets_find+0x2be>
 1091f45:	lea    0x1(%rax),%rdi
 1091f49:	mov    $0x1,%ecx
 1091f4e:	mov    -0x30(%rbp),%rdx
 1091f52:	mov    %r15,%rsi
 1091f55:	movzbl (%rax,%rcx,1),%r8d
 1091f5a:	cmp    (%rsi,%rcx,1),%r8b
 1091f5e:	jne    1091f6a <myl_native_octets_find+0x24a>
 1091f60:	inc    %rcx
 1091f63:	cmp    %rcx,%rdx
 1091f66:	jne    1091f55 <myl_native_octets_find+0x235>
 1091f68:	jmp    1091f1c <myl_native_octets_find+0x1fc>
 1091f6a:	cmp    -0x38(%rbp),%rax
 1091f6e:	je     1091fde <myl_native_octets_find+0x2be>
 1091f70:	mov    %r14,%rdx
 1091f73:	sub    %rdi,%rdx
 1091f76:	mov    %r12d,%esi
 1091f79:	call   10ab580 <memchr@plt>
 1091f7e:	test   %rax,%rax
 1091f81:	je     1091fde <myl_native_octets_find+0x2be>
 1091f83:	lea    0x1(%rax),%rdi
 1091f87:	mov    $0x1,%ecx
 1091f8c:	movzbl (%rax,%rcx,1),%edx
 1091f90:	cmp    (%r15,%rcx,1),%dl
 1091f94:	jne    1091fa4 <myl_native_octets_find+0x284>
 1091f96:	inc    %rcx
 1091f99:	cmp    %rcx,-0x30(%rbp)
 1091f9d:	jne    1091f8c <myl_native_octets_find+0x26c>
 1091f9f:	jmp    1091f1c <myl_native_octets_find+0x1fc>
 1091fa4:	cmp    -0x38(%rbp),%rax
 1091fa8:	je     1091fde <myl_native_octets_find+0x2be>
 1091faa:	sub    %rdi,%r14
 1091fad:	mov    %r12d,%esi
 1091fb0:	mov    %r14,%rdx
 1091fb3:	call   10ab580 <memchr@plt>
 1091fb8:	test   %rax,%rax
 1091fbb:	je     1091fde <myl_native_octets_find+0x2be>
 1091fbd:	lea    0x1(%rax),%rdi
 1091fc1:	mov    $0x1,%ecx
 1091fc6:	movzbl (%rax,%rcx,1),%edx
 1091fca:	cmp    (%r15,%rcx,1),%dl
 1091fce:	jne    1091ff4 <myl_native_octets_find+0x2d4>
 1091fd0:	inc    %rcx
 1091fd3:	cmp    %rcx,-0x30(%rbp)
 1091fd7:	jne    1091fc6 <myl_native_octets_find+0x2a6>
 1091fd9:	jmp    1091f1c <myl_native_octets_find+0x1fc>
 1091fde:	mov    $0xffffffffffffffff,%rax
 1091fe5:	add    $0x18,%rsp
 1091fe9:	pop    %rbx
 1091fea:	pop    %r12
 1091fec:	pop    %r13
 1091fee:	pop    %r14
 1091ff0:	pop    %r15
 1091ff2:	pop    %rbp
 1091ff3:	ret
 1091ff4:	cmp    -0x38(%rbp),%rax
 1091ff8:	mov    $0xffffffffffffffff,%rax
 1091fff:	je     1091fe5 <myl_native_octets_find+0x2c5>
 1092001:	add    %r13,%rbx
 1092004:	sub    %rdi,%rbx
 1092007:	mov    %rbx,%rsi
 109200a:	mov    %r15,%rdx
 109200d:	mov    -0x30(%rbp),%rcx
 1092011:	call   10ab590 <memmem@plt>
 1092016:	mov    %rax,%rcx
 1092019:	mov    %rax,%rdx
 109201c:	sub    %r13,%rdx
 109201f:	jmp    1091d69 <myl_native_octets_find+0x49>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
