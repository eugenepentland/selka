Juice: base → candidate
Baseline 100; lower means fewer instructions per completed unit, not proportionally less time.

| Workload | Juice | Assessment | Repeat range |
|---|---:|---|---|
| work | 226.159 | more-work | 226.159–226.159 |

Selected-scenario index: 226.159 (weighted geometric mean).
Coverage: selected scenarios only. Repeat ranges are observations, not confidence intervals.

- work: CPU cycle cost 2.250× baseline (maximum observed spread 2.55%).

- work: CPU runtime proxy uncertain; reference-cycle measurement spread exceeds 3%.

Instruction-calibrated runtime model: uncalibrated. See JSON for all semantic sites, functions and model details.
