Juice: base → candidate
Baseline 100; lower means fewer instructions per completed unit, not proportionally less time.

| Workload | Juice | Assessment | Repeat range |
|---|---:|---|---|
| work | 102.941 | more-work | 102.941–102.941 |

Selected-scenario index: 102.941 (weighted geometric mean).
Coverage: selected scenarios only. Repeat ranges are observations, not confidence intervals.

- work: CPU cycle cost 4.160× baseline (maximum observed spread 0.15%).

- work: CPU runtime proxy uncertain; reference-cycle measurement spread exceeds 3%.

- work: static atomic_sites increased; hotness unresolved

Instruction-calibrated runtime model: uncalibrated. See JSON for all semantic sites, functions and model details.
