Juice: base-aggregate → candidate-aggregate
Baseline 100; lower means fewer instructions per completed unit, not proportionally less time.

| Workload | Juice | Assessment | Repeat range |
|---|---:|---|---|
| work | 96.993 | less-work | 96.993–96.993 |

Selected-scenario index: 96.993 (weighted geometric mean).
Coverage: selected scenarios only. Repeat ranges are observations, not confidence intervals.

- work: CPU runtime proxy uncertain; reference-cycle spread exceeds 3%.

Runtime estimate: uncalibrated. See JSON for all semantic sites, functions and model details.
