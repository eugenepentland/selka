Juice: base → candidate
Baseline 100; lower means fewer instructions per completed unit, not proportionally less time.

| Workload | Juice | Assessment | Repeat range |
|---|---:|---|---|
| work | 100.000 | unchanged | 100.000–100.000 |

Selected-scenario index: 100.000 (weighted geometric mean).
Coverage: selected scenarios only. Repeat ranges are observations, not confidence intervals.

- work: CPU cycle cost 1.000× baseline (maximum observed spread 0.00%).

- work: CPU runtime proxy 1.002× baseline; 5% accuracy target is unvalidated.

Instruction-calibrated runtime model: uncalibrated. See JSON for all semantic sites, functions and model details.
