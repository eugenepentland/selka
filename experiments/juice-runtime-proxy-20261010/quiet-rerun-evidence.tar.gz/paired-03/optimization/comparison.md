Juice: base → candidate
Baseline 100; lower means fewer instructions per completed unit, not proportionally less time.

| Workload | Juice | Assessment | Repeat range |
|---|---:|---|---|
| work | 138.233 | more-work | 138.233–138.233 |

Selected-scenario index: 138.233 (weighted geometric mean).
Coverage: selected scenarios only. Repeat ranges are observations, not confidence intervals.

- work: CPU cycle cost 1.500× baseline (maximum observed spread 0.06%).

- work: CPU runtime proxy 1.527× baseline; 5% accuracy target is unvalidated.

Instruction-calibrated runtime model: uncalibrated. See JSON for all semantic sites, functions and model details.
