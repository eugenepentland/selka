Juice: base → candidate
Baseline 100; lower means fewer instructions per completed unit, not proportionally less time.

| Workload | Juice | Assessment | Repeat range |
|---|---:|---|---|
| work | 126.405 | more-work | 126.405–126.405 |

Selected-scenario index: 126.405 (weighted geometric mean).
Coverage: selected scenarios only. Repeat ranges are observations, not confidence intervals.

- work: CPU cycle cost 1.251× baseline (maximum observed spread 0.60%).

- work: CPU runtime proxy uncertain; reference-cycle measurement spread exceeds 3%.

Instruction-calibrated runtime model: uncalibrated. See JSON for all semantic sites, functions and model details.
