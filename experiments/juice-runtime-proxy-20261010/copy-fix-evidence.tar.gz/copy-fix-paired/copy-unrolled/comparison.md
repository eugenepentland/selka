Juice: base → candidate
Baseline 100; lower means fewer instructions per completed unit, not proportionally less time.

| Workload | Juice | Assessment | Repeat range |
|---|---:|---|---|
| work | 126.467 | more-work | 126.467–126.467 |

Selected-scenario index: 126.467 (weighted geometric mean).
Coverage: selected scenarios only. Repeat ranges are observations, not confidence intervals.

- work: CPU cycle cost 1.261× baseline (maximum observed spread 0.36%).

- work: CPU runtime proxy 1.283× baseline; 5% accuracy target is unvalidated.

Instruction-calibrated runtime model: uncalibrated. See JSON for all semantic sites, functions and model details.
