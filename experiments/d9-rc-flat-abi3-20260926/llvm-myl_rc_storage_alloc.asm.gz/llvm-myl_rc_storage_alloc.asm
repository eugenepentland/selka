
/home/epentland/ai/canopy/mylang-worktrees/d9-rc-flat-destruction-astra/.tmp-flat/cumulative-19e/llvm-rc-repeat:     file format elf64-x86-64


Disassembly of section .text:

000000000102a7c0 <myl_rc_storage_alloc>:
 102a7c0:	push   %rbp
 102a7c1:	mov    %rsp,%rbp
 102a7c4:	push   %r15
 102a7c6:	push   %r14
 102a7c8:	push   %r13
 102a7ca:	push   %r12
 102a7cc:	push   %rbx
 102a7cd:	sub    $0x28,%rsp
 102a7d1:	test   %rdi,%rdi
 102a7d4:	je     102a97b <myl_rc_storage_alloc+0x1bb>
 102a7da:	mov    %rsi,%r14
 102a7dd:	test   %rsi,%rsi
 102a7e0:	je     102a97b <myl_rc_storage_alloc+0x1bb>
 102a7e6:	mov    %rdi,%rbx
 102a7e9:	mov    0x1608(%rdi),%rax
 102a7f0:	test   %rax,%rax
 102a7f3:	je     102a97b <myl_rc_storage_alloc+0x1bb>
 102a7f9:	mov    %ecx,%r15d
 102a7fc:	mov    %rdx,%r12
 102a7ff:	test   %ecx,%ecx
 102a801:	setne  %cl
 102a804:	cmp    $0x1,%rdx
 102a808:	setne  %dl
 102a80b:	or     %cl,%dl
 102a80d:	jne    102a818 <myl_rc_storage_alloc+0x58>
 102a80f:	cmpq   $0x102a980,(%rax)
 102a816:	je     102a87d <myl_rc_storage_alloc+0xbd>
 102a818:	mov    %rbx,%rdi
 102a81b:	mov    %r14,%rsi
 102a81e:	call   102b630 <myl_rc_native_shape>
 102a823:	test   %rax,%rax
 102a826:	je     102a96a <myl_rc_storage_alloc+0x1aa>
 102a82c:	mov    %r14,-0x48(%rbp)
 102a830:	mov    %r12,-0x40(%rbp)
 102a834:	mov    %r15d,-0x38(%rbp)
 102a838:	movl   $0x0,-0x34(%rbp)
 102a83f:	movq   $0x0,-0x30(%rbp)
 102a847:	lea    -0x48(%rbp),%rsi
 102a84b:	lea    -0x30(%rbp),%rdx
 102a84f:	mov    %rbx,%rdi
 102a852:	call   1024330 <myl_rc_new>
 102a857:	test   %eax,%eax
 102a859:	je     102a874 <myl_rc_storage_alloc+0xb4>
 102a85b:	mov    0x1608(%rbx),%rcx
 102a862:	test   %rcx,%rcx
 102a865:	je     102a97b <myl_rc_storage_alloc+0x1bb>
 102a86b:	cmpl   $0x0,0x78(%rcx)
 102a86f:	jne    102a874 <myl_rc_storage_alloc+0xb4>
 102a871:	mov    %eax,0x78(%rcx)
 102a874:	mov    -0x30(%rbp),%rax
 102a878:	jmp    102a96c <myl_rc_storage_alloc+0x1ac>
 102a87d:	mov    0x18(%rax),%r13
 102a881:	cmp    %r14,0x210(%r13)
 102a888:	je     102a90a <myl_rc_storage_alloc+0x14a>
 102a88e:	mov    %rbx,%rdi
 102a891:	mov    %r14,%rsi
 102a894:	call   102b630 <myl_rc_native_shape>
 102a899:	test   %rax,%rax
 102a89c:	je     102a96a <myl_rc_storage_alloc+0x1aa>
 102a8a2:	cmpq   $0x10,0x8(%r14)
 102a8a7:	ja     102a82c <myl_rc_storage_alloc+0x6c>
 102a8a9:	mov    (%r14),%rax
 102a8ac:	cmp    $0x1fe0,%rax
 102a8b2:	ja     102a82c <myl_rc_storage_alloc+0x6c>
 102a8b8:	add    $0x20,%rax
 102a8bc:	mov    $0x20,%ecx
 102a8c1:	xor    %esi,%esi
 102a8c3:	jmp    102a8d8 <myl_rc_storage_alloc+0x118>
 102a8c5:	data16 cs nopw 0x0(%rax,%rax,1)
 102a8d0:	mov    %rdi,%rcx
 102a8d3:	cmp    %rcx,%rsi
 102a8d6:	jae    102a8fa <myl_rc_storage_alloc+0x13a>
 102a8d8:	mov    %rcx,%rdx
 102a8db:	sub    %rsi,%rdx
 102a8de:	shr    $1,%rdx
 102a8e1:	lea    (%rdx,%rsi,1),%rdi
 102a8e5:	cmp    %rax,0x100d690(,%rdi,8)
 102a8ed:	jae    102a8d0 <myl_rc_storage_alloc+0x110>
 102a8ef:	add    %rdx,%rsi
 102a8f2:	inc    %rsi
 102a8f5:	cmp    %rcx,%rsi
 102a8f8:	jb     102a8d8 <myl_rc_storage_alloc+0x118>
 102a8fa:	mov    %r14,0x210(%r13)
 102a901:	mov    %rsi,0x218(%r13)
 102a908:	jmp    102a911 <myl_rc_storage_alloc+0x151>
 102a90a:	mov    0x218(%r13),%rsi
 102a911:	mov    %rbx,%rdi
 102a914:	call   102ac00 <slab_take>
 102a919:	test   %rax,%rax
 102a91c:	je     102a951 <myl_rc_storage_alloc+0x191>
 102a91e:	movq   $0x1,(%rax)
 102a925:	movq   $0x0,0x8(%rax)
 102a92d:	movq   $0x4,0x10(%rax)
 102a935:	mov    %r14,0x18(%rax)
 102a939:	vmovdqu 0x40(%rbx),%xmm0
 102a93e:	vpcmpeqd %xmm1,%xmm1,%xmm1
 102a942:	vpsubq %xmm1,%xmm0,%xmm0
 102a946:	vmovdqu %xmm0,0x40(%rbx)
 102a94b:	add    $0x20,%rax
 102a94f:	jmp    102a96c <myl_rc_storage_alloc+0x1ac>
 102a951:	mov    0x1608(%rbx),%rax
 102a958:	test   %rax,%rax
 102a95b:	je     102a97b <myl_rc_storage_alloc+0x1bb>
 102a95d:	cmpl   $0x0,0x78(%rax)
 102a961:	jne    102a96a <myl_rc_storage_alloc+0x1aa>
 102a963:	movl   $0x1,0x78(%rax)
 102a96a:	xor    %eax,%eax
 102a96c:	add    $0x28,%rsp
 102a970:	pop    %rbx
 102a971:	pop    %r12
 102a973:	pop    %r13
 102a975:	pop    %r14
 102a977:	pop    %r15
 102a979:	pop    %rbp
 102a97a:	ret
 102a97b:	call   1024111 <myl_rc_invariant_failed>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
