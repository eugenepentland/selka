
/home/epentland/ai/canopy/mylang-worktrees/d9-rc-flat-destruction-astra/.tmp-flat/cumulative-19e/qbe-rc-repeat:     file format elf64-x86-64


Disassembly of section .text:

0000000001024280 <myl_rc_drain>:
 1024280:	push   %rbp
 1024281:	mov    %rsp,%rbp
 1024284:	push   %r15
 1024286:	push   %r14
 1024288:	push   %r13
 102428a:	push   %r12
 102428c:	push   %rbx
 102428d:	push   %rax
 102428e:	test   %rdi,%rdi
 1024291:	je     1024437 <myl_rc_drain+0x1b7>
 1024297:	mov    %rdi,%rbx
 102429a:	mov    0x1608(%rdi),%rax
 10242a1:	test   %rax,%rax
 10242a4:	je     1024437 <myl_rc_drain+0x1b7>
 10242aa:	cmpl   $0x0,0x68(%rax)
 10242ae:	jne    1024428 <myl_rc_drain+0x1a8>
 10242b4:	cmpq   $0x0,0x58(%rax)
 10242b9:	jne    1024428 <myl_rc_drain+0x1a8>
 10242bf:	movl   $0x1,0x68(%rax)
 10242c6:	mov    0x60(%rax),%r13
 10242ca:	test   %r13,%r13
 10242cd:	je     1024421 <myl_rc_drain+0x1a1>
 10242d3:	add    $0x60,%rax
 10242d7:	mov    %rax,%rcx
 10242da:	nopw   0x0(%rax,%rax,1)
 10242e0:	mov    0x0(%r13),%rax
 10242e4:	mov    %rax,(%rcx)
 10242e7:	mov    0x18(%r13),%rsi
 10242eb:	mov    %rbx,%rdi
 10242ee:	call   1022740 <myl_rc_descriptor_find>
 10242f3:	test   %rax,%rax
 10242f6:	je     1024437 <myl_rc_drain+0x1b7>
 10242fc:	mov    %rax,%r12
 10242ff:	mov    $0x3c,%eax
 1024304:	bzhi   %rax,0x10(%r13),%r15
 102430a:	lea    0x20(%r13),%r14
 102430e:	shr    $0x2,%r15
 1024312:	mov    0x78(%r12),%eax
 1024317:	cmp    $0x8,%eax
 102431a:	ja     1024370 <myl_rc_drain+0xf0>
 102431c:	cmp    $0x1,%r15
 1024320:	jne    10243c0 <myl_rc_drain+0x140>
 1024326:	test   %eax,%eax
 1024328:	je     10243f0 <myl_rc_drain+0x170>
 102432e:	xor    %r15d,%r15d
 1024331:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1024340:	mov    0x38(%r12,%r15,8),%rax
 1024345:	mov    (%r14,%rax,1),%rsi
 1024349:	movq   $0x0,(%r14,%rax,1)
 1024351:	mov    %rbx,%rdi
 1024354:	call   1021f60 <myl_rc_edge_release>
 1024359:	inc    %r15
 102435c:	mov    0x78(%r12),%eax
 1024361:	cmp    %rax,%r15
 1024364:	jb     1024340 <myl_rc_drain+0xc0>
 1024366:	jmp    10243f0 <myl_rc_drain+0x170>
 102436b:	nopl   0x0(%rax,%rax,1)
 1024370:	mov    0x18(%r12),%rax
 1024375:	test   %rax,%rax
 1024378:	je     1024382 <myl_rc_drain+0x102>
 102437a:	mov    %rbx,%rdi
 102437d:	mov    %r14,%rsi
 1024380:	call   *%rax
 1024382:	mov    0x18(%r13),%rsi
 1024386:	mov    %rbx,%rdi
 1024389:	call   1022740 <myl_rc_descriptor_find>
 102438e:	test   %rax,%rax
 1024391:	je     1024437 <myl_rc_drain+0x1b7>
 1024397:	mov    0x1608(%rbx),%rcx
 102439e:	cmpq   $0x0,0x58(%rcx)
 10243a3:	jne    1024437 <myl_rc_drain+0x1b7>
 10243a9:	mov    0x10(%rax),%rcx
 10243ad:	test   %rcx,%rcx
 10243b0:	je     10243d3 <myl_rc_drain+0x153>
 10243b2:	mov    %rbx,%rdi
 10243b5:	mov    %r14,%rsi
 10243b8:	mov    %r15,%rdx
 10243bb:	call   *%rcx
 10243bd:	jmp    10243f0 <myl_rc_drain+0x170>
 10243bf:	nop
 10243c0:	mov    %rbx,%rdi
 10243c3:	mov    %r12,%rsi
 10243c6:	mov    %r14,%rdx
 10243c9:	mov    %r15,%rcx
 10243cc:	call   1024180 <myl_rc_flat_edges_release>
 10243d1:	jmp    10243f0 <myl_rc_drain+0x170>
 10243d3:	mov    0x8(%rax),%rsi
 10243d7:	mov    %rbx,%rdi
 10243da:	mov    %r14,%rdx
 10243dd:	mov    %r15,%rcx
 10243e0:	call   1024070 <myl_rc_edges_release>
 10243e5:	data16 cs nopw 0x0(%rax,%rax,1)
 10243f0:	mov    0x1608(%rbx),%rax
 10243f7:	cmpq   $0x0,0x58(%rax)
 10243fc:	jne    1024437 <myl_rc_drain+0x1b7>
 10243fe:	mov    %rbx,%rdi
 1024401:	mov    %r14,%rsi
 1024404:	call   1021ec0 <myl_rc_allocator_retire>
 1024409:	mov    0x1608(%rbx),%rax
 1024410:	lea    0x60(%rax),%rcx
 1024414:	mov    0x60(%rax),%r13
 1024418:	test   %r13,%r13
 102441b:	jne    10242e0 <myl_rc_drain+0x60>
 1024421:	movl   $0x0,0x68(%rax)
 1024428:	add    $0x8,%rsp
 102442c:	pop    %rbx
 102442d:	pop    %r12
 102442f:	pop    %r13
 1024431:	pop    %r14
 1024433:	pop    %r15
 1024435:	pop    %rbp
 1024436:	ret
 1024437:	call   10219de <myl_rc_invariant_failed>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
