
/home/epentland/ai/canopy/mylang-worktrees/d9-rc-flat-destruction-astra/.tmp-flat/cumulative-19e/llvm-rc-repeat:     file format elf64-x86-64


Disassembly of section .text:

00000000010265f0 <myl_rc_drain>:
 10265f0:	push   %rbp
 10265f1:	mov    %rsp,%rbp
 10265f4:	push   %r15
 10265f6:	push   %r14
 10265f8:	push   %r13
 10265fa:	push   %r12
 10265fc:	push   %rbx
 10265fd:	push   %rax
 10265fe:	test   %rdi,%rdi
 1026601:	je     102691a <myl_rc_drain+0x32a>
 1026607:	mov    %rdi,%rbx
 102660a:	mov    0x1608(%rdi),%rax
 1026611:	test   %rax,%rax
 1026614:	je     102691a <myl_rc_drain+0x32a>
 102661a:	cmpl   $0x0,0x68(%rax)
 102661e:	jne    1026926 <myl_rc_drain+0x336>
 1026624:	cmpq   $0x0,0x58(%rax)
 1026629:	jne    1026926 <myl_rc_drain+0x336>
 102662f:	movl   $0x1,0x68(%rax)
 1026636:	mov    0x60(%rax),%r12
 102663a:	test   %r12,%r12
 102663d:	je     102691f <myl_rc_drain+0x32f>
 1026643:	movabs $0x4000000000000002,%r13
 102664d:	nopl   (%rax)
 1026650:	mov    (%r12),%rcx
 1026654:	mov    %rcx,0x60(%rax)
 1026658:	mov    0x18(%r12),%rcx
 102665d:	test   %rcx,%rcx
 1026660:	je     102691a <myl_rc_drain+0x32a>
 1026666:	test   %rax,%rax
 1026669:	je     102691a <myl_rc_drain+0x32a>
 102666f:	mov    0x40(%rax),%rdx
 1026673:	test   %rdx,%rdx
 1026676:	je     102691a <myl_rc_drain+0x32a>
 102667c:	mov    0x30(%rax),%rsi
 1026680:	mov    %rcx,%rdi
 1026683:	shr    $0x3,%rdi
 1026687:	mov    %rcx,%r8
 102668a:	shr    $0x21,%r8
 102668e:	xor    %rdi,%r8
 1026691:	movabs $0xbf58476d1ce4e5b9,%rdi
 102669b:	imul   %rdi,%r8
 102669f:	mov    %r8,%rdi
 10266a2:	shr    $0x1b,%rdi
 10266a6:	xor    %r8,%rdi
 10266a9:	xor    $0x2,%rdi
 10266ad:	dec    %rdx
 10266b0:	and    %rdx,%rdi
 10266b3:	lea    (%rdi,%rdi,4),%r8
 10266b7:	mov    (%rsi,%r8,8),%r8
 10266bb:	test   %r8,%r8
 10266be:	je     102691a <myl_rc_drain+0x32a>
 10266c4:	lea    0x20(%r12),%r14
 10266c9:	jmp    10266e7 <myl_rc_drain+0xf7>
 10266cb:	nopl   0x0(%rax,%rax,1)
 10266d0:	inc    %rdi
 10266d3:	and    %rdx,%rdi
 10266d6:	lea    (%rdi,%rdi,4),%r8
 10266da:	mov    (%rsi,%r8,8),%r8
 10266de:	test   %r8,%r8
 10266e1:	je     102691a <myl_rc_drain+0x32a>
 10266e7:	cmp    %rcx,%r8
 10266ea:	jne    10266d0 <myl_rc_drain+0xe0>
 10266ec:	lea    (%rdi,%rdi,4),%r8
 10266f0:	cmpl   $0x2,0x20(%rsi,%r8,8)
 10266f6:	jne    10266d0 <myl_rc_drain+0xe0>
 10266f8:	lea    (%rsi,%r8,8),%rdx
 10266fc:	mov    0x8(%rdx),%rsi
 1026700:	test   %rsi,%rsi
 1026703:	je     102691a <myl_rc_drain+0x32a>
 1026709:	mov    $0x3c,%edx
 102670e:	bzhi   %rdx,0x10(%r12),%r15
 1026715:	shr    $0x2,%r15
 1026719:	mov    0x78(%rsi),%edx
 102671c:	cmp    $0x8,%edx
 102671f:	ja     10267c0 <myl_rc_drain+0x1d0>
 1026725:	cmp    $0x1,%r15
 1026729:	jne    10268b0 <myl_rc_drain+0x2c0>
 102672f:	test   %edx,%edx
 1026731:	je     10268be <myl_rc_drain+0x2ce>
 1026737:	xor    %eax,%eax
 1026739:	jmp    102674f <myl_rc_drain+0x15f>
 102673b:	nopl   0x0(%rax,%rax,1)
 1026740:	inc    %rax
 1026743:	mov    0x78(%rsi),%ecx
 1026746:	cmp    %rcx,%rax
 1026749:	jae    10268be <myl_rc_drain+0x2ce>
 102674f:	mov    0x38(%rsi,%rax,8),%rdx
 1026754:	mov    (%r14,%rdx,1),%rcx
 1026758:	movq   $0x0,(%r14,%rdx,1)
 1026760:	test   %rcx,%rcx
 1026763:	je     1026740 <myl_rc_drain+0x150>
 1026765:	mov    -0x10(%rcx),%rdx
 1026769:	test   %r13,%rdx
 102676c:	jne    1026740 <myl_rc_drain+0x150>
 102676e:	mov    0x1608(%rbx),%rdi
 1026775:	test   %rdi,%rdi
 1026778:	je     102691a <myl_rc_drain+0x32a>
 102677e:	test   $0x1,%dl
 1026781:	jne    102691a <myl_rc_drain+0x32a>
 1026787:	lea    -0x20(%rcx),%r8
 102678b:	mov    (%r8),%r9
 102678e:	test   %r9,%r9
 1026791:	je     102691a <myl_rc_drain+0x32a>
 1026797:	dec    %r9
 102679a:	mov    %r9,(%r8)
 102679d:	jne    1026740 <myl_rc_drain+0x150>
 102679f:	cmpq   $0x0,-0x18(%rcx)
 10267a4:	jne    1026740 <myl_rc_drain+0x150>
 10267a6:	or     $0x1,%rdx
 10267aa:	mov    %rdx,-0x10(%rcx)
 10267ae:	mov    0x60(%rdi),%rdx
 10267b2:	mov    %rdx,-0x20(%rcx)
 10267b6:	mov    %r8,0x60(%rdi)
 10267ba:	jmp    1026740 <myl_rc_drain+0x150>
 10267bc:	nopl   0x0(%rax)
 10267c0:	mov    0x18(%rsi),%rdx
 10267c4:	test   %rdx,%rdx
 10267c7:	je     10267dd <myl_rc_drain+0x1ed>
 10267c9:	mov    %rbx,%rdi
 10267cc:	mov    %r14,%rsi
 10267cf:	call   *%rdx
 10267d1:	mov    0x18(%r12),%rcx
 10267d6:	mov    0x1608(%rbx),%rax
 10267dd:	test   %rcx,%rcx
 10267e0:	je     102691a <myl_rc_drain+0x32a>
 10267e6:	test   %rax,%rax
 10267e9:	je     102691a <myl_rc_drain+0x32a>
 10267ef:	mov    0x40(%rax),%rdx
 10267f3:	test   %rdx,%rdx
 10267f6:	je     102691a <myl_rc_drain+0x32a>
 10267fc:	mov    0x30(%rax),%rsi
 1026800:	mov    %rcx,%rdi
 1026803:	shr    $0x3,%rdi
 1026807:	mov    %rcx,%r8
 102680a:	shr    $0x21,%r8
 102680e:	xor    %rdi,%r8
 1026811:	movabs $0xbf58476d1ce4e5b9,%rdi
 102681b:	imul   %rdi,%r8
 102681f:	mov    %r8,%rdi
 1026822:	shr    $0x1b,%rdi
 1026826:	xor    %r8,%rdi
 1026829:	xor    $0x2,%rdi
 102682d:	dec    %rdx
 1026830:	jmp    1026843 <myl_rc_drain+0x253>
 1026832:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1026840:	inc    %rdi
 1026843:	and    %rdx,%rdi
 1026846:	lea    (%rdi,%rdi,4),%r8
 102684a:	mov    (%rsi,%r8,8),%r8
 102684e:	test   %r8,%r8
 1026851:	je     102691a <myl_rc_drain+0x32a>
 1026857:	cmp    %rcx,%r8
 102685a:	jne    1026840 <myl_rc_drain+0x250>
 102685c:	lea    (%rdi,%rdi,4),%r8
 1026860:	cmpl   $0x2,0x20(%rsi,%r8,8)
 1026866:	jne    1026840 <myl_rc_drain+0x250>
 1026868:	lea    (%rsi,%r8,8),%rcx
 102686c:	mov    0x8(%rcx),%rcx
 1026870:	test   %rcx,%rcx
 1026873:	je     102691a <myl_rc_drain+0x32a>
 1026879:	cmpq   $0x0,0x58(%rax)
 102687e:	jne    102691a <myl_rc_drain+0x32a>
 1026884:	mov    0x10(%rcx),%rax
 1026888:	test   %rax,%rax
 102688b:	je     10268fa <myl_rc_drain+0x30a>
 102688d:	mov    %rbx,%rdi
 1026890:	mov    %r14,%rsi
 1026893:	mov    %r15,%rdx
 1026896:	call   *%rax
 1026898:	mov    0x1608(%rbx),%rax
 102689f:	cmpq   $0x0,0x58(%rax)
 10268a4:	je     10268cc <myl_rc_drain+0x2dc>
 10268a6:	jmp    102691a <myl_rc_drain+0x32a>
 10268a8:	nopl   0x0(%rax,%rax,1)
 10268b0:	mov    %rbx,%rdi
 10268b3:	mov    %r14,%rdx
 10268b6:	mov    %r15,%rcx
 10268b9:	call   10264a0 <myl_rc_flat_edges_release>
 10268be:	mov    0x1608(%rbx),%rax
 10268c5:	cmpq   $0x0,0x58(%rax)
 10268ca:	jne    102691a <myl_rc_drain+0x32a>
 10268cc:	mov    0x10(%r12),%rcx
 10268d1:	test   %r13,%rcx
 10268d4:	jne    102691a <myl_rc_drain+0x32a>
 10268d6:	test   $0x1,%cl
 10268d9:	je     102691a <myl_rc_drain+0x32a>
 10268db:	mov    %rbx,%rdi
 10268de:	mov    %r14,%rsi
 10268e1:	call   *0x8(%rax)
 10268e4:	mov    0x1608(%rbx),%rax
 10268eb:	mov    0x60(%rax),%r12
 10268ef:	test   %r12,%r12
 10268f2:	jne    1026650 <myl_rc_drain+0x60>
 10268f8:	jmp    102691f <myl_rc_drain+0x32f>
 10268fa:	mov    0x8(%rcx),%rsi
 10268fe:	mov    %rbx,%rdi
 1026901:	mov    %r14,%rdx
 1026904:	mov    %r15,%rcx
 1026907:	call   1026100 <myl_rc_edges_release>
 102690c:	mov    0x1608(%rbx),%rax
 1026913:	cmpq   $0x0,0x58(%rax)
 1026918:	je     10268cc <myl_rc_drain+0x2dc>
 102691a:	call   1024111 <myl_rc_invariant_failed>
 102691f:	movl   $0x0,0x68(%rax)
 1026926:	add    $0x8,%rsp
 102692a:	pop    %rbx
 102692b:	pop    %r12
 102692d:	pop    %r13
 102692f:	pop    %r14
 1026931:	pop    %r15
 1026933:	pop    %rbp
 1026934:	ret

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
