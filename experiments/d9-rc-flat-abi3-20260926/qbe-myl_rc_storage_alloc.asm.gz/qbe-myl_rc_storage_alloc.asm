
/home/epentland/ai/canopy/mylang-worktrees/d9-rc-flat-destruction-astra/.tmp-flat/cumulative-19e/qbe-rc-repeat:     file format elf64-x86-64


Disassembly of section .text:

0000000001028ac0 <myl_rc_storage_alloc>:
 1028ac0:	push   %rbp
 1028ac1:	mov    %rsp,%rbp
 1028ac4:	push   %r15
 1028ac6:	push   %r14
 1028ac8:	push   %r13
 1028aca:	push   %r12
 1028acc:	push   %rbx
 1028acd:	sub    $0x28,%rsp
 1028ad1:	test   %rdi,%rdi
 1028ad4:	je     1028c5b <myl_rc_storage_alloc+0x19b>
 1028ada:	mov    %rsi,%r14
 1028add:	test   %rsi,%rsi
 1028ae0:	je     1028c5b <myl_rc_storage_alloc+0x19b>
 1028ae6:	mov    %rdi,%rbx
 1028ae9:	mov    0x1608(%rdi),%rax
 1028af0:	test   %rax,%rax
 1028af3:	je     1028c5b <myl_rc_storage_alloc+0x19b>
 1028af9:	mov    %ecx,%r15d
 1028afc:	mov    %rdx,%r12
 1028aff:	test   %ecx,%ecx
 1028b01:	setne  %cl
 1028b04:	cmp    $0x1,%rdx
 1028b08:	setne  %dl
 1028b0b:	or     %cl,%dl
 1028b0d:	jne    1028b1b <myl_rc_storage_alloc+0x5b>
 1028b0f:	lea    0x14a(%rip),%rcx        # 1028c60 <allocate>
 1028b16:	cmp    %rcx,(%rax)
 1028b19:	je     1028b71 <myl_rc_storage_alloc+0xb1>
 1028b1b:	mov    %rbx,%rdi
 1028b1e:	mov    %r14,%rsi
 1028b21:	call   1029790 <myl_rc_native_shape>
 1028b26:	test   %rax,%rax
 1028b29:	je     1028c4a <myl_rc_storage_alloc+0x18a>
 1028b2f:	mov    %r14,-0x48(%rbp)
 1028b33:	mov    %r12,-0x40(%rbp)
 1028b37:	mov    %r15d,-0x38(%rbp)
 1028b3b:	movl   $0x0,-0x34(%rbp)
 1028b42:	movq   $0x0,-0x30(%rbp)
 1028b4a:	lea    -0x48(%rbp),%rsi
 1028b4e:	lea    -0x30(%rbp),%rdx
 1028b52:	mov    %rbx,%rdi
 1028b55:	call   1021dc0 <myl_rc_new>
 1028b5a:	test   %eax,%eax
 1028b5c:	je     1028b68 <myl_rc_storage_alloc+0xa8>
 1028b5e:	mov    %rbx,%rdi
 1028b61:	mov    %eax,%esi
 1028b63:	call   1021b40 <myl_rc_record_failure>
 1028b68:	mov    -0x30(%rbp),%rax
 1028b6c:	jmp    1028c4c <myl_rc_storage_alloc+0x18c>
 1028b71:	mov    0x18(%rax),%r13
 1028b75:	cmp    %r14,0x210(%r13)
 1028b7c:	je     1028bf6 <myl_rc_storage_alloc+0x136>
 1028b7e:	mov    %rbx,%rdi
 1028b81:	mov    %r14,%rsi
 1028b84:	call   1029790 <myl_rc_native_shape>
 1028b89:	test   %rax,%rax
 1028b8c:	je     1028c4a <myl_rc_storage_alloc+0x18a>
 1028b92:	cmpq   $0x10,0x8(%r14)
 1028b97:	ja     1028b2f <myl_rc_storage_alloc+0x6f>
 1028b99:	mov    (%r14),%rax
 1028b9c:	cmp    $0x1fe0,%rax
 1028ba2:	ja     1028b2f <myl_rc_storage_alloc+0x6f>
 1028ba4:	add    $0x20,%rax
 1028ba8:	mov    $0x20,%ecx
 1028bad:	xor    %esi,%esi
 1028baf:	lea    -0x1de76(%rip),%rdx        # 100ad40 <strides>
 1028bb6:	jmp    1028bc8 <myl_rc_storage_alloc+0x108>
 1028bb8:	nopl   0x0(%rax,%rax,1)
 1028bc0:	mov    %r8,%rcx
 1028bc3:	cmp    %rcx,%rsi
 1028bc6:	jae    1028be6 <myl_rc_storage_alloc+0x126>
 1028bc8:	mov    %rcx,%rdi
 1028bcb:	sub    %rsi,%rdi
 1028bce:	shr    $1,%rdi
 1028bd1:	lea    (%rdi,%rsi,1),%r8
 1028bd5:	cmp    %rax,(%rdx,%r8,8)
 1028bd9:	jae    1028bc0 <myl_rc_storage_alloc+0x100>
 1028bdb:	add    %rdi,%rsi
 1028bde:	inc    %rsi
 1028be1:	cmp    %rcx,%rsi
 1028be4:	jb     1028bc8 <myl_rc_storage_alloc+0x108>
 1028be6:	mov    %r14,0x210(%r13)
 1028bed:	mov    %rsi,0x218(%r13)
 1028bf4:	jmp    1028bfd <myl_rc_storage_alloc+0x13d>
 1028bf6:	mov    0x218(%r13),%rsi
 1028bfd:	mov    %rbx,%rdi
 1028c00:	call   1028ee0 <slab_take>
 1028c05:	test   %rax,%rax
 1028c08:	je     1028c3d <myl_rc_storage_alloc+0x17d>
 1028c0a:	movq   $0x1,(%rax)
 1028c11:	movq   $0x0,0x8(%rax)
 1028c19:	movq   $0x4,0x10(%rax)
 1028c21:	mov    %r14,0x18(%rax)
 1028c25:	vmovdqu 0x40(%rbx),%xmm0
 1028c2a:	vpcmpeqd %xmm1,%xmm1,%xmm1
 1028c2e:	vpsubq %xmm1,%xmm0,%xmm0
 1028c32:	vmovdqu %xmm0,0x40(%rbx)
 1028c37:	add    $0x20,%rax
 1028c3b:	jmp    1028c4c <myl_rc_storage_alloc+0x18c>
 1028c3d:	mov    %rbx,%rdi
 1028c40:	mov    $0x1,%esi
 1028c45:	call   1021b40 <myl_rc_record_failure>
 1028c4a:	xor    %eax,%eax
 1028c4c:	add    $0x28,%rsp
 1028c50:	pop    %rbx
 1028c51:	pop    %r12
 1028c53:	pop    %r13
 1028c55:	pop    %r14
 1028c57:	pop    %r15
 1028c59:	pop    %rbp
 1028c5a:	ret
 1028c5b:	call   10219de <myl_rc_invariant_failed>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
