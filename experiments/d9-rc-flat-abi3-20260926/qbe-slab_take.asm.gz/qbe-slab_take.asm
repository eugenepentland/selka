
/home/epentland/ai/canopy/mylang-worktrees/d9-rc-flat-destruction-astra/.tmp-flat/cumulative-19e/qbe-rc-repeat:     file format elf64-x86-64


Disassembly of section .text:

0000000001028ee0 <slab_take>:
 1028ee0:	push   %rbp
 1028ee1:	mov    %rsp,%rbp
 1028ee4:	push   %r15
 1028ee6:	push   %r14
 1028ee8:	push   %r13
 1028eea:	push   %r12
 1028eec:	push   %rbx
 1028eed:	push   %rax
 1028eee:	test   %rdi,%rdi
 1028ef1:	je     10290f6 <slab_take+0x216>
 1028ef7:	mov    %rdi,%rbx
 1028efa:	mov    0x1608(%rdi),%rax
 1028f01:	test   %rax,%rax
 1028f04:	je     10290f6 <slab_take+0x216>
 1028f0a:	mov    0x18(%rax),%r14
 1028f0e:	mov    %rsi,%r15
 1028f11:	shl    $0x4,%r15
 1028f15:	mov    0x8(%r14,%r15,1),%rax
 1028f1a:	test   %rax,%rax
 1028f1d:	jne    1029063 <slab_take+0x183>
 1028f23:	mov    %rsi,%r12
 1028f26:	mov    $0x10000,%esi
 1028f2b:	mov    %rbx,%rdi
 1028f2e:	call   10293d0 <reserve>
 1028f33:	test   %eax,%eax
 1028f35:	je     1028ff1 <slab_take+0x111>
 1028f3b:	mov    $0x10000,%edi
 1028f40:	mov    $0x10000,%esi
 1028f45:	call   102ace0 <aligned_alloc@plt>
 1028f4a:	test   %rax,%rax
 1028f4d:	jne    1028fb0 <slab_take+0xd0>
 1028f4f:	xor    %r13d,%r13d
 1028f52:	jmp    1028f6d <slab_take+0x8d>
 1028f54:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 1028f60:	add    $0x10,%r13
 1028f64:	cmp    $0x200,%r13
 1028f6b:	je     1028f9c <slab_take+0xbc>
 1028f6d:	mov    0x1608(%rbx),%rax
 1028f74:	test   %rax,%rax
 1028f77:	je     10290f6 <slab_take+0x216>
 1028f7d:	mov    0x18(%rax),%rax
 1028f81:	mov    0x8(%rax,%r13,1),%rsi
 1028f86:	test   %rsi,%rsi
 1028f89:	je     1028f60 <slab_take+0x80>
 1028f8b:	cmpq   $0x0,0x30(%rsi)
 1028f90:	jne    1028f60 <slab_take+0x80>
 1028f92:	mov    %rbx,%rdi
 1028f95:	call   10294a0 <slab_free>
 1028f9a:	jmp    1028f60 <slab_take+0x80>
 1028f9c:	mov    $0x10000,%edi
 1028fa1:	mov    $0x10000,%esi
 1028fa6:	call   102ace0 <aligned_alloc@plt>
 1028fab:	test   %rax,%rax
 1028fae:	je     1028ff1 <slab_take+0x111>
 1028fb0:	vpxor  %xmm0,%xmm0,%xmm0
 1028fb4:	vmovdqa %ymm0,0x20(%rax)
 1028fb9:	vmovdqu %ymm0,0x30(%rax)
 1028fbe:	vmovdqa %ymm0,(%rax)
 1028fc2:	lea    -0x1e289(%rip),%rcx        # 100ad40 <strides>
 1028fc9:	mov    (%rcx,%r12,8),%rcx
 1028fcd:	mov    %rcx,0x20(%rax)
 1028fd1:	mov    %r12,0x40(%rax)
 1028fd5:	cmp    $0xffb0,%rcx
 1028fdc:	ja     1029002 <slab_take+0x122>
 1028fde:	mov    %rax,%rsi
 1028fe1:	mov    $0xffb0,%eax
 1028fe6:	xor    %edx,%edx
 1028fe8:	div    %ecx
 1028fea:	mov    %eax,%ecx
 1028fec:	mov    %rsi,%rax
 1028fef:	jmp    1029004 <slab_take+0x124>
 1028ff1:	xor    %eax,%eax
 1028ff3:	add    $0x8,%rsp
 1028ff7:	pop    %rbx
 1028ff8:	pop    %r12
 1028ffa:	pop    %r13
 1028ffc:	pop    %r14
 1028ffe:	pop    %r15
 1029000:	pop    %rbp
 1029001:	ret
 1029002:	xor    %ecx,%ecx
 1029004:	mov    %rcx,0x48(%rax)
 1029008:	mov    0x1608(%rbx),%rcx
 102900f:	test   %rcx,%rcx
 1029012:	je     10290f6 <slab_take+0x216>
 1029018:	mov    0x18(%rcx),%rcx
 102901c:	lea    (%rcx,%r15,1),%rdx
 1029020:	mov    (%rcx,%r15,1),%rsi
 1029024:	mov    %rsi,0x8(%rax)
 1029028:	test   %rsi,%rsi
 102902b:	je     1029030 <slab_take+0x150>
 102902d:	mov    %rax,(%rsi)
 1029030:	mov    %rax,(%rdx)
 1029033:	mov    0x8(%rdx),%rsi
 1029037:	movq   $0x0,0x10(%rax)
 102903f:	mov    %rsi,0x18(%rax)
 1029043:	test   %rsi,%rsi
 1029046:	je     102904c <slab_take+0x16c>
 1029048:	mov    %rax,0x10(%rsi)
 102904c:	mov    %rax,0x8(%rdx)
 1029050:	addq   $0x10000,0x18(%rbx)
 1029058:	addq   $0x10000,0x208(%rcx)
 1029063:	mov    0x38(%rax),%rdi
 1029067:	test   %rdi,%rdi
 102906a:	je     102907e <slab_take+0x19e>
 102906c:	mov    (%rdi),%rcx
 102906f:	mov    %rcx,0x38(%rax)
 1029073:	incq   0x30(%rax)
 1029077:	test   %rcx,%rcx
 102907a:	jne    10290da <slab_take+0x1fa>
 102907c:	jmp    10290a1 <slab_take+0x1c1>
 102907e:	vmovdqu 0x28(%rax),%xmm0
 1029083:	mov    0x28(%rax),%rcx
 1029087:	imul   0x20(%rax),%rcx
 102908c:	lea    (%rax,%rcx,1),%rdi
 1029090:	add    $0x50,%rdi
 1029094:	vpcmpeqd %xmm1,%xmm1,%xmm1
 1029098:	vpsubq %xmm1,%xmm0,%xmm0
 102909c:	vmovdqu %xmm0,0x28(%rax)
 10290a1:	mov    0x28(%rax),%rcx
 10290a5:	cmp    0x48(%rax),%rcx
 10290a9:	jne    10290da <slab_take+0x1fa>
 10290ab:	mov    0x10(%rax),%rcx
 10290af:	mov    0x18(%rax),%rdx
 10290b3:	test   %rcx,%rcx
 10290b6:	je     10290be <slab_take+0x1de>
 10290b8:	mov    %rdx,0x18(%rcx)
 10290bc:	jmp    10290c5 <slab_take+0x1e5>
 10290be:	add    %r15,%r14
 10290c1:	mov    %rdx,0x8(%r14)
 10290c5:	lea    0x10(%rax),%rsi
 10290c9:	test   %rdx,%rdx
 10290cc:	je     10290d2 <slab_take+0x1f2>
 10290ce:	mov    %rcx,0x10(%rdx)
 10290d2:	vpxor  %xmm0,%xmm0,%xmm0
 10290d6:	vmovdqu %xmm0,(%rsi)
 10290da:	mov    0x20(%rax),%rdx
 10290de:	xor    %esi,%esi
 10290e0:	add    $0x8,%rsp
 10290e4:	pop    %rbx
 10290e5:	pop    %r12
 10290e7:	pop    %r13
 10290e9:	pop    %r14
 10290eb:	pop    %r15
 10290ed:	pop    %rbp
 10290ee:	vzeroupper
 10290f1:	jmp    102a090 <compiler_rt.fastMemset>
 10290f6:	vzeroupper
 10290f9:	call   10219de <myl_rc_invariant_failed>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
