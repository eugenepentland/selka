
/home/epentland/ai/canopy/mylang-worktrees/d9-rc-flat-destruction-astra/.tmp-flat/cumulative-19e/llvm-rc-repeat:     file format elf64-x86-64


Disassembly of section .text:

000000000102ac00 <slab_take>:
 102ac00:	push   %rbp
 102ac01:	mov    %rsp,%rbp
 102ac04:	push   %r15
 102ac06:	push   %r14
 102ac08:	push   %r13
 102ac0a:	push   %r12
 102ac0c:	push   %rbx
 102ac0d:	push   %rax
 102ac0e:	test   %rdi,%rdi
 102ac11:	je     102aecb <slab_take+0x2cb>
 102ac17:	mov    %rdi,%rbx
 102ac1a:	mov    0x1608(%rdi),%rax
 102ac21:	test   %rax,%rax
 102ac24:	je     102aecb <slab_take+0x2cb>
 102ac2a:	mov    0x18(%rax),%r14
 102ac2e:	mov    %rsi,%r15
 102ac31:	shl    $0x4,%r15
 102ac35:	mov    0x8(%r14,%r15,1),%rax
 102ac3a:	test   %rax,%rax
 102ac3d:	je     102ac73 <slab_take+0x73>
 102ac3f:	mov    0x38(%rax),%rdi
 102ac43:	test   %rdi,%rdi
 102ac46:	je     102ae49 <slab_take+0x249>
 102ac4c:	mov    (%rdi),%rcx
 102ac4f:	mov    %rcx,0x38(%rax)
 102ac53:	incq   0x30(%rax)
 102ac57:	test   %rcx,%rcx
 102ac5a:	jne    102ae9d <slab_take+0x29d>
 102ac60:	mov    0x28(%rax),%rcx
 102ac64:	cmp    0x48(%rax),%rcx
 102ac68:	je     102ae77 <slab_take+0x277>
 102ac6e:	jmp    102ae9d <slab_take+0x29d>
 102ac73:	mov    %rsi,%r12
 102ac76:	mov    $0x10000,%esi
 102ac7b:	mov    %rbx,%rdi
 102ac7e:	call   102aee0 <reserve>
 102ac83:	test   %eax,%eax
 102ac85:	je     102adca <slab_take+0x1ca>
 102ac8b:	mov    $0x10000,%edi
 102ac90:	mov    $0x10000,%esi
 102ac95:	call   102fb40 <aligned_alloc@plt>
 102ac9a:	test   %rax,%rax
 102ac9d:	jne    102ad8c <slab_take+0x18c>
 102aca3:	xor    %r13d,%r13d
 102aca6:	jmp    102acc1 <slab_take+0xc1>
 102aca8:	nopl   0x0(%rax,%rax,1)
 102acb0:	add    $0x10,%r13
 102acb4:	cmp    $0x200,%r13
 102acbb:	je     102ad78 <slab_take+0x178>
 102acc1:	mov    0x1608(%rbx),%rax
 102acc8:	test   %rax,%rax
 102accb:	je     102aecb <slab_take+0x2cb>
 102acd1:	mov    0x18(%rax),%rax
 102acd5:	mov    0x8(%rax,%r13,1),%rdi
 102acda:	test   %rdi,%rdi
 102acdd:	je     102acb0 <slab_take+0xb0>
 102acdf:	cmpq   $0x0,0x30(%rdi)
 102ace4:	jne    102acb0 <slab_take+0xb0>
 102ace6:	mov    0x40(%rdi),%rcx
 102acea:	shl    $0x4,%rcx
 102acee:	add    %rcx,%rax
 102acf1:	mov    0x10(%rdi),%rcx
 102acf5:	mov    0x18(%rdi),%rdx
 102acf9:	test   %rcx,%rcx
 102acfc:	je     102ad63 <slab_take+0x163>
 102acfe:	mov    %rdx,0x18(%rcx)
 102ad02:	test   %rdx,%rdx
 102ad05:	je     102ad0b <slab_take+0x10b>
 102ad07:	mov    %rcx,0x10(%rdx)
 102ad0b:	lea    0x10(%rdi),%rcx
 102ad0f:	vpxor  %xmm0,%xmm0,%xmm0
 102ad13:	vmovdqu %xmm0,(%rcx)
 102ad17:	mov    (%rdi),%rdx
 102ad1a:	mov    0x8(%rdi),%rcx
 102ad1e:	test   %rdx,%rdx
 102ad21:	je     102ad6e <slab_take+0x16e>
 102ad23:	mov    %rcx,0x8(%rdx)
 102ad27:	test   %rcx,%rcx
 102ad2a:	je     102ad32 <slab_take+0x132>
 102ad2c:	mov    (%rdi),%rax
 102ad2f:	mov    %rax,(%rcx)
 102ad32:	addq   $0xffffffffffff0000,0x18(%rbx)
 102ad3a:	mov    0x1608(%rbx),%rax
 102ad41:	test   %rax,%rax
 102ad44:	je     102aecb <slab_take+0x2cb>
 102ad4a:	mov    0x18(%rax),%rax
 102ad4e:	addq   $0xffffffffffff0000,0x208(%rax)
 102ad59:	call   102f810 <free@plt>
 102ad5e:	jmp    102acb0 <slab_take+0xb0>
 102ad63:	mov    %rdx,0x8(%rax)
 102ad67:	test   %rdx,%rdx
 102ad6a:	jne    102ad07 <slab_take+0x107>
 102ad6c:	jmp    102ad0b <slab_take+0x10b>
 102ad6e:	mov    %rcx,(%rax)
 102ad71:	test   %rcx,%rcx
 102ad74:	jne    102ad2c <slab_take+0x12c>
 102ad76:	jmp    102ad32 <slab_take+0x132>
 102ad78:	mov    $0x10000,%edi
 102ad7d:	mov    $0x10000,%esi
 102ad82:	call   102fb40 <aligned_alloc@plt>
 102ad87:	test   %rax,%rax
 102ad8a:	je     102adca <slab_take+0x1ca>
 102ad8c:	vpxor  %xmm0,%xmm0,%xmm0
 102ad90:	vmovdqa %ymm0,0x20(%rax)
 102ad95:	vmovdqu %ymm0,0x30(%rax)
 102ad9a:	vmovdqa %ymm0,(%rax)
 102ad9e:	mov    0x100d690(,%r12,8),%rcx
 102ada6:	mov    %rcx,0x20(%rax)
 102adaa:	mov    %r12,0x40(%rax)
 102adae:	cmp    $0xffb0,%rcx
 102adb5:	ja     102addb <slab_take+0x1db>
 102adb7:	mov    %rax,%rsi
 102adba:	mov    $0xffb0,%eax
 102adbf:	xor    %edx,%edx
 102adc1:	div    %ecx
 102adc3:	mov    %eax,%ecx
 102adc5:	mov    %rsi,%rax
 102adc8:	jmp    102addd <slab_take+0x1dd>
 102adca:	xor    %eax,%eax
 102adcc:	add    $0x8,%rsp
 102add0:	pop    %rbx
 102add1:	pop    %r12
 102add3:	pop    %r13
 102add5:	pop    %r14
 102add7:	pop    %r15
 102add9:	pop    %rbp
 102adda:	ret
 102addb:	xor    %ecx,%ecx
 102addd:	mov    %rcx,0x48(%rax)
 102ade1:	mov    0x1608(%rbx),%rcx
 102ade8:	test   %rcx,%rcx
 102adeb:	je     102aecb <slab_take+0x2cb>
 102adf1:	mov    0x18(%rcx),%rcx
 102adf5:	lea    (%rcx,%r15,1),%rdx
 102adf9:	mov    (%rcx,%r15,1),%rsi
 102adfd:	mov    %rsi,0x8(%rax)
 102ae01:	test   %rsi,%rsi
 102ae04:	je     102ae09 <slab_take+0x209>
 102ae06:	mov    %rax,(%rsi)
 102ae09:	mov    %rax,(%rdx)
 102ae0c:	mov    0x8(%rdx),%rsi
 102ae10:	movq   $0x0,0x10(%rax)
 102ae18:	mov    %rsi,0x18(%rax)
 102ae1c:	test   %rsi,%rsi
 102ae1f:	je     102ae25 <slab_take+0x225>
 102ae21:	mov    %rax,0x10(%rsi)
 102ae25:	mov    %rax,0x8(%rdx)
 102ae29:	addq   $0x10000,0x18(%rbx)
 102ae31:	addq   $0x10000,0x208(%rcx)
 102ae3c:	mov    0x38(%rax),%rdi
 102ae40:	test   %rdi,%rdi
 102ae43:	jne    102ac4c <slab_take+0x4c>
 102ae49:	vmovdqu 0x28(%rax),%xmm0
 102ae4e:	mov    0x28(%rax),%rcx
 102ae52:	imul   0x20(%rax),%rcx
 102ae57:	lea    (%rax,%rcx,1),%rdi
 102ae5b:	add    $0x50,%rdi
 102ae5f:	vpcmpeqd %xmm1,%xmm1,%xmm1
 102ae63:	vpsubq %xmm1,%xmm0,%xmm0
 102ae67:	vmovdqu %xmm0,0x28(%rax)
 102ae6c:	vmovq  %xmm0,%rcx
 102ae71:	cmp    0x48(%rax),%rcx
 102ae75:	jne    102ae9d <slab_take+0x29d>
 102ae77:	mov    0x10(%rax),%rcx
 102ae7b:	mov    0x18(%rax),%rdx
 102ae7f:	test   %rcx,%rcx
 102ae82:	je     102aeb9 <slab_take+0x2b9>
 102ae84:	mov    %rdx,0x18(%rcx)
 102ae88:	lea    0x10(%rax),%rsi
 102ae8c:	test   %rdx,%rdx
 102ae8f:	je     102ae95 <slab_take+0x295>
 102ae91:	mov    %rcx,0x10(%rdx)
 102ae95:	vpxor  %xmm0,%xmm0,%xmm0
 102ae99:	vmovdqu %xmm0,(%rsi)
 102ae9d:	mov    0x20(%rax),%rdx
 102aea1:	xor    %esi,%esi
 102aea3:	add    $0x8,%rsp
 102aea7:	pop    %rbx
 102aea8:	pop    %r12
 102aeaa:	pop    %r13
 102aeac:	pop    %r14
 102aeae:	pop    %r15
 102aeb0:	pop    %rbp
 102aeb1:	vzeroupper
 102aeb4:	jmp    102f760 <memset@plt>
 102aeb9:	add    %r15,%r14
 102aebc:	mov    %rdx,0x8(%r14)
 102aec0:	lea    0x10(%rax),%rsi
 102aec4:	test   %rdx,%rdx
 102aec7:	jne    102ae91 <slab_take+0x291>
 102aec9:	jmp    102ae95 <slab_take+0x295>
 102aecb:	vzeroupper
 102aece:	call   1024111 <myl_rc_invariant_failed>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
