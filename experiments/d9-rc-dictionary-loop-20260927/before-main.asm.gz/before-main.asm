
/home/epentland/ai/canopy/mylang-worktrees/d9-rc-compiler-astra/.tmp-rc/dict-loop/full/before-qbe-rc:     file format elf64-x86-64


Disassembly of section .text:

000000000100efb0 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605>:
 100efb0:	f3 0f 1e fa          	endbr64
 100efb4:	55                   	push   %rbp
 100efb5:	48 89 e5             	mov    %rsp,%rbp
 100efb8:	48 81 ec f8 03 00 00 	sub    $0x3f8,%rsp
 100efbf:	53                   	push   %rbx
 100efc0:	41 54                	push   %r12
 100efc2:	41 55                	push   %r13
 100efc4:	41 56                	push   %r14
 100efc6:	41 57                	push   %r15
 100efc8:	48 89 b5 30 ff ff ff 	mov    %rsi,-0xd0(%rbp)
 100efcf:	ba 20 00 00 00       	mov    $0x20,%edx
 100efd4:	be 00 00 00 00       	mov    $0x0,%esi
 100efd9:	48 89 fb             	mov    %rdi,%rbx
 100efdc:	48 8d bd 68 fe ff ff 	lea    -0x198(%rbp),%rdi
 100efe3:	e8 58 d3 01 00       	call   102c340 <compiler_rt.fastMemset>
 100efe8:	48 89 df             	mov    %rbx,%rdi
 100efeb:	ba 20 00 00 00       	mov    $0x20,%edx
 100eff0:	be 00 00 00 00       	mov    $0x0,%esi
 100eff5:	48 89 fb             	mov    %rdi,%rbx
 100eff8:	48 8d bd 88 fe ff ff 	lea    -0x178(%rbp),%rdi
 100efff:	e8 3c d3 01 00       	call   102c340 <compiler_rt.fastMemset>
 100f004:	48 89 df             	mov    %rbx,%rdi
 100f007:	ba 20 00 00 00       	mov    $0x20,%edx
 100f00c:	be 00 00 00 00       	mov    $0x0,%esi
 100f011:	48 89 fb             	mov    %rdi,%rbx
 100f014:	48 8d bd a8 fe ff ff 	lea    -0x158(%rbp),%rdi
 100f01b:	e8 20 d3 01 00       	call   102c340 <compiler_rt.fastMemset>
 100f020:	48 89 df             	mov    %rbx,%rdi
 100f023:	48 c7 85 c8 fe ff ff 	movq   $0x0,-0x138(%rbp)
 100f02a:	00 00 00 00 
 100f02e:	48 c7 85 d0 fe ff ff 	movq   $0x0,-0x130(%rbp)
 100f035:	00 00 00 00 
 100f039:	48 c7 85 d8 fe ff ff 	movq   $0x0,-0x128(%rbp)
 100f040:	00 00 00 00 
 100f044:	48 c7 85 e0 fe ff ff 	movq   $0x0,-0x120(%rbp)
 100f04b:	00 00 00 00 
 100f04f:	48 c7 85 e8 fe ff ff 	movq   $0x0,-0x118(%rbp)
 100f056:	00 00 00 00 
 100f05a:	48 c7 85 f0 fe ff ff 	movq   $0x0,-0x110(%rbp)
 100f061:	00 00 00 00 
 100f065:	48 c7 85 f8 fe ff ff 	movq   $0x0,-0x108(%rbp)
 100f06c:	00 00 00 00 
 100f070:	48 c7 85 00 ff ff ff 	movq   $0x0,-0x100(%rbp)
 100f077:	00 00 00 00 
 100f07b:	48 89 fb             	mov    %rdi,%rbx
 100f07e:	e8 fd 80 00 00       	call   1017180 <myl_qbe_heap>
 100f083:	48 89 df             	mov    %rbx,%rdi
 100f086:	48 89 c3             	mov    %rax,%rbx
 100f089:	49 89 fc             	mov    %rdi,%r12
 100f08c:	e8 af 9c 00 00       	call   1018d40 <myl_qbe_region_mark>
 100f091:	4c 89 e7             	mov    %r12,%rdi
 100f094:	48 89 45 d8          	mov    %rax,-0x28(%rbp)
 100f098:	ba 68 00 00 00       	mov    $0x68,%edx
 100f09d:	be 00 00 00 00       	mov    $0x0,%esi
 100f0a2:	49 89 fc             	mov    %rdi,%r12
 100f0a5:	48 8d bd d8 fd ff ff 	lea    -0x228(%rbp),%rdi
 100f0ac:	e8 8f d2 01 00       	call   102c340 <compiler_rt.fastMemset>
 100f0b1:	4c 89 e7             	mov    %r12,%rdi
 100f0b4:	48 8d 05 05 fd 01 00 	lea    0x1fd05(%rip),%rax        # 102edc0 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b>
 100f0bb:	48 89 85 38 fc ff ff 	mov    %rax,-0x3c8(%rbp)
 100f0c2:	c7 85 50 fc ff ff 02 	movl   $0x2,-0x3b0(%rbp)
 100f0c9:	00 00 00 
 100f0cc:	48 8d 85 c8 fe ff ff 	lea    -0x138(%rbp),%rax
 100f0d3:	48 89 85 40 fc ff ff 	mov    %rax,-0x3c0(%rbp)
 100f0da:	48 8d 85 d8 fd ff ff 	lea    -0x228(%rbp),%rax
 100f0e1:	48 89 85 48 fc ff ff 	mov    %rax,-0x3b8(%rbp)
 100f0e8:	48 8d 85 38 fc ff ff 	lea    -0x3c8(%rbp),%rax
 100f0ef:	48 89 c6             	mov    %rax,%rsi
 100f0f2:	48 83 c6 20          	add    $0x20,%rsi
 100f0f6:	48 89 75 f0          	mov    %rsi,-0x10(%rbp)
 100f0fa:	48 8d 05 bf fc 01 00 	lea    0x1fcbf(%rip),%rax        # 102edc0 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b>
 100f101:	48 89 85 58 fc ff ff 	mov    %rax,-0x3a8(%rbp)
 100f108:	c7 85 70 fc ff ff 02 	movl   $0x2,-0x390(%rbp)
 100f10f:	00 00 00 
 100f112:	48 8d 85 d0 fe ff ff 	lea    -0x130(%rbp),%rax
 100f119:	48 89 85 60 fc ff ff 	mov    %rax,-0x3a0(%rbp)
 100f120:	48 8d 85 d8 fd ff ff 	lea    -0x228(%rbp),%rax
 100f127:	49 89 c6             	mov    %rax,%r14
 100f12a:	49 83 c6 08          	add    $0x8,%r14
 100f12e:	4c 89 b5 68 fc ff ff 	mov    %r14,-0x398(%rbp)
 100f135:	48 8d 85 38 fc ff ff 	lea    -0x3c8(%rbp),%rax
 100f13c:	48 89 c6             	mov    %rax,%rsi
 100f13f:	48 83 c6 40          	add    $0x40,%rsi
 100f143:	48 89 75 d0          	mov    %rsi,-0x30(%rbp)
 100f147:	48 8d 05 c2 fd 01 00 	lea    0x1fdc2(%rip),%rax        # 102ef10 <myl_t_db6bd58975531b7368ca22b8af460e2a11856412c594a38caca68120ceaa09fc>
 100f14e:	48 89 85 78 fc ff ff 	mov    %rax,-0x388(%rbp)
 100f155:	c7 85 90 fc ff ff 02 	movl   $0x2,-0x370(%rbp)
 100f15c:	00 00 00 
 100f15f:	48 8d 85 d8 fe ff ff 	lea    -0x128(%rbp),%rax
 100f166:	48 89 85 80 fc ff ff 	mov    %rax,-0x380(%rbp)
 100f16d:	48 8d 85 d8 fd ff ff 	lea    -0x228(%rbp),%rax
 100f174:	49 89 c4             	mov    %rax,%r12
 100f177:	49 83 c4 10          	add    $0x10,%r12
 100f17b:	4c 89 65 c8          	mov    %r12,-0x38(%rbp)
 100f17f:	4c 89 a5 88 fc ff ff 	mov    %r12,-0x378(%rbp)
 100f186:	48 8d 85 38 fc ff ff 	lea    -0x3c8(%rbp),%rax
 100f18d:	49 89 c7             	mov    %rax,%r15
 100f190:	49 83 c7 60          	add    $0x60,%r15
 100f194:	4c 89 7d b8          	mov    %r15,-0x48(%rbp)
 100f198:	48 8d 05 21 fc 01 00 	lea    0x1fc21(%rip),%rax        # 102edc0 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b>
 100f19f:	48 89 85 98 fc ff ff 	mov    %rax,-0x368(%rbp)
 100f1a6:	c7 85 b0 fc ff ff 02 	movl   $0x2,-0x350(%rbp)
 100f1ad:	00 00 00 
 100f1b0:	48 8d 85 e0 fe ff ff 	lea    -0x120(%rbp),%rax
 100f1b7:	48 89 85 a0 fc ff ff 	mov    %rax,-0x360(%rbp)
 100f1be:	48 8d 85 d8 fd ff ff 	lea    -0x228(%rbp),%rax
 100f1c5:	48 83 c0 18          	add    $0x18,%rax
 100f1c9:	48 89 85 a8 fc ff ff 	mov    %rax,-0x358(%rbp)
 100f1d0:	48 8d 05 79 fb 01 00 	lea    0x1fb79(%rip),%rax        # 102ed50 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a>
 100f1d7:	48 89 85 b8 fc ff ff 	mov    %rax,-0x348(%rbp)
 100f1de:	c7 85 d0 fc ff ff 02 	movl   $0x2,-0x330(%rbp)
 100f1e5:	00 00 00 
 100f1e8:	48 8d 85 e8 fe ff ff 	lea    -0x118(%rbp),%rax
 100f1ef:	48 89 85 c0 fc ff ff 	mov    %rax,-0x340(%rbp)
 100f1f6:	48 8d 85 d8 fd ff ff 	lea    -0x228(%rbp),%rax
 100f1fd:	48 83 c0 20          	add    $0x20,%rax
 100f201:	48 89 85 c8 fc ff ff 	mov    %rax,-0x338(%rbp)
 100f208:	48 8d 85 38 fc ff ff 	lea    -0x3c8(%rbp),%rax
 100f20f:	48 05 a0 00 00 00    	add    $0xa0,%rax
 100f215:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
 100f219:	48 8d 05 f0 fc 01 00 	lea    0x1fcf0(%rip),%rax        # 102ef10 <myl_t_db6bd58975531b7368ca22b8af460e2a11856412c594a38caca68120ceaa09fc>
 100f220:	48 89 85 d8 fc ff ff 	mov    %rax,-0x328(%rbp)
 100f227:	c7 85 f0 fc ff ff 02 	movl   $0x2,-0x310(%rbp)
 100f22e:	00 00 00 
 100f231:	48 8d 85 f0 fe ff ff 	lea    -0x110(%rbp),%rax
 100f238:	48 89 85 e0 fc ff ff 	mov    %rax,-0x320(%rbp)
 100f23f:	48 8d 85 d8 fd ff ff 	lea    -0x228(%rbp),%rax
 100f246:	48 83 c0 28          	add    $0x28,%rax
 100f24a:	48 89 85 e8 fc ff ff 	mov    %rax,-0x318(%rbp)
 100f251:	48 8d 85 38 fc ff ff 	lea    -0x3c8(%rbp),%rax
 100f258:	48 89 c6             	mov    %rax,%rsi
 100f25b:	48 81 c6 c0 00 00 00 	add    $0xc0,%rsi
 100f262:	48 89 75 a0          	mov    %rsi,-0x60(%rbp)
 100f266:	48 8d 05 53 fb 01 00 	lea    0x1fb53(%rip),%rax        # 102edc0 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b>
 100f26d:	48 89 85 f8 fc ff ff 	mov    %rax,-0x308(%rbp)
 100f274:	c7 85 10 fd ff ff 02 	movl   $0x2,-0x2f0(%rbp)
 100f27b:	00 00 00 
 100f27e:	48 8d 85 f8 fe ff ff 	lea    -0x108(%rbp),%rax
 100f285:	48 89 85 00 fd ff ff 	mov    %rax,-0x300(%rbp)
 100f28c:	48 8d 85 d8 fd ff ff 	lea    -0x228(%rbp),%rax
 100f293:	49 89 c4             	mov    %rax,%r12
 100f296:	49 83 c4 30          	add    $0x30,%r12
 100f29a:	4c 89 65 98          	mov    %r12,-0x68(%rbp)
 100f29e:	4c 89 a5 08 fd ff ff 	mov    %r12,-0x2f8(%rbp)
 100f2a5:	48 8d 85 38 fc ff ff 	lea    -0x3c8(%rbp),%rax
 100f2ac:	48 89 c6             	mov    %rax,%rsi
 100f2af:	48 81 c6 e0 00 00 00 	add    $0xe0,%rsi
 100f2b6:	48 89 b5 40 ff ff ff 	mov    %rsi,-0xc0(%rbp)
 100f2bd:	48 8d 05 8c fa 01 00 	lea    0x1fa8c(%rip),%rax        # 102ed50 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a>
 100f2c4:	48 89 85 18 fd ff ff 	mov    %rax,-0x2e8(%rbp)
 100f2cb:	c7 85 30 fd ff ff 02 	movl   $0x2,-0x2d0(%rbp)
 100f2d2:	00 00 00 
 100f2d5:	48 8d 85 00 ff ff ff 	lea    -0x100(%rbp),%rax
 100f2dc:	48 89 85 20 fd ff ff 	mov    %rax,-0x2e0(%rbp)
 100f2e3:	48 8d 85 d8 fd ff ff 	lea    -0x228(%rbp),%rax
 100f2ea:	49 89 c2             	mov    %rax,%r10
 100f2ed:	49 83 c2 38          	add    $0x38,%r10
 100f2f1:	4c 89 95 58 ff ff ff 	mov    %r10,-0xa8(%rbp)
 100f2f8:	4c 89 95 28 fd ff ff 	mov    %r10,-0x2d8(%rbp)
 100f2ff:	48 8d 85 38 fc ff ff 	lea    -0x3c8(%rbp),%rax
 100f306:	49 89 c5             	mov    %rax,%r13
 100f309:	49 81 c5 00 01 00 00 	add    $0x100,%r13
 100f310:	48 8d 05 a1 49 ff ff 	lea    -0xb65f(%rip),%rax        # 1003cb8 <myl_t_385cfdbc00ec32031699460779c15099b2bba3cad0e440fffb08e10df0acb9e1>
 100f317:	48 89 85 38 fd ff ff 	mov    %rax,-0x2c8(%rbp)
 100f31e:	c7 85 50 fd ff ff 00 	movl   $0x0,-0x2b0(%rbp)
 100f325:	00 00 00 
 100f328:	48 8d 85 40 fe ff ff 	lea    -0x1c0(%rbp),%rax
 100f32f:	48 89 85 40 fd ff ff 	mov    %rax,-0x2c0(%rbp)
 100f336:	48 8d 85 d8 fd ff ff 	lea    -0x228(%rbp),%rax
 100f33d:	49 89 c7             	mov    %rax,%r15
 100f340:	49 83 c7 40          	add    $0x40,%r15
 100f344:	4c 89 7d b0          	mov    %r15,-0x50(%rbp)
 100f348:	4c 89 bd 48 fd ff ff 	mov    %r15,-0x2b8(%rbp)
 100f34f:	48 8d 85 38 fc ff ff 	lea    -0x3c8(%rbp),%rax
 100f356:	49 89 c0             	mov    %rax,%r8
 100f359:	49 81 c0 20 01 00 00 	add    $0x120,%r8
 100f360:	4c 89 85 48 ff ff ff 	mov    %r8,-0xb8(%rbp)
 100f367:	48 8d 05 4a 49 ff ff 	lea    -0xb6b6(%rip),%rax        # 1003cb8 <myl_t_385cfdbc00ec32031699460779c15099b2bba3cad0e440fffb08e10df0acb9e1>
 100f36e:	48 89 85 58 fd ff ff 	mov    %rax,-0x2a8(%rbp)
 100f375:	c7 85 70 fd ff ff 00 	movl   $0x0,-0x290(%rbp)
 100f37c:	00 00 00 
 100f37f:	48 8d 85 48 fe ff ff 	lea    -0x1b8(%rbp),%rax
 100f386:	48 89 85 60 fd ff ff 	mov    %rax,-0x2a0(%rbp)
 100f38d:	48 8d 85 d8 fd ff ff 	lea    -0x228(%rbp),%rax
 100f394:	48 83 c0 48          	add    $0x48,%rax
 100f398:	48 89 85 68 fd ff ff 	mov    %rax,-0x298(%rbp)
 100f39f:	48 8d 85 38 fc ff ff 	lea    -0x3c8(%rbp),%rax
 100f3a6:	49 89 c1             	mov    %rax,%r9
 100f3a9:	49 81 c1 40 01 00 00 	add    $0x140,%r9
 100f3b0:	4c 89 8d 50 ff ff ff 	mov    %r9,-0xb0(%rbp)
 100f3b7:	48 8d 05 fa 48 ff ff 	lea    -0xb706(%rip),%rax        # 1003cb8 <myl_t_385cfdbc00ec32031699460779c15099b2bba3cad0e440fffb08e10df0acb9e1>
 100f3be:	48 89 85 78 fd ff ff 	mov    %rax,-0x288(%rbp)
 100f3c5:	c7 85 90 fd ff ff 00 	movl   $0x0,-0x270(%rbp)
 100f3cc:	00 00 00 
 100f3cf:	48 8d 85 50 fe ff ff 	lea    -0x1b0(%rbp),%rax
 100f3d6:	48 89 85 80 fd ff ff 	mov    %rax,-0x280(%rbp)
 100f3dd:	48 8d 85 d8 fd ff ff 	lea    -0x228(%rbp),%rax
 100f3e4:	48 83 c0 50          	add    $0x50,%rax
 100f3e8:	48 89 85 88 fd ff ff 	mov    %rax,-0x278(%rbp)
 100f3ef:	48 8d 05 c2 48 ff ff 	lea    -0xb73e(%rip),%rax        # 1003cb8 <myl_t_385cfdbc00ec32031699460779c15099b2bba3cad0e440fffb08e10df0acb9e1>
 100f3f6:	48 89 85 98 fd ff ff 	mov    %rax,-0x268(%rbp)
 100f3fd:	c7 85 b0 fd ff ff 00 	movl   $0x0,-0x250(%rbp)
 100f404:	00 00 00 
 100f407:	48 8d 85 58 fe ff ff 	lea    -0x1a8(%rbp),%rax
 100f40e:	48 89 85 a0 fd ff ff 	mov    %rax,-0x260(%rbp)
 100f415:	48 8d 85 d8 fd ff ff 	lea    -0x228(%rbp),%rax
 100f41c:	49 89 c4             	mov    %rax,%r12
 100f41f:	49 83 c4 58          	add    $0x58,%r12
 100f423:	4c 89 65 a8          	mov    %r12,-0x58(%rbp)
 100f427:	4c 89 a5 a8 fd ff ff 	mov    %r12,-0x258(%rbp)
 100f42e:	48 8d 05 83 48 ff ff 	lea    -0xb77d(%rip),%rax        # 1003cb8 <myl_t_385cfdbc00ec32031699460779c15099b2bba3cad0e440fffb08e10df0acb9e1>
 100f435:	48 89 85 b8 fd ff ff 	mov    %rax,-0x248(%rbp)
 100f43c:	c7 85 d0 fd ff ff 00 	movl   $0x0,-0x230(%rbp)
 100f443:	00 00 00 
 100f446:	48 8d 85 60 fe ff ff 	lea    -0x1a0(%rbp),%rax
 100f44d:	48 89 85 c0 fd ff ff 	mov    %rax,-0x240(%rbp)
 100f454:	48 8d 85 d8 fd ff ff 	lea    -0x228(%rbp),%rax
 100f45b:	48 89 c1             	mov    %rax,%rcx
 100f45e:	48 83 c1 60          	add    $0x60,%rcx
 100f462:	48 89 4d e0          	mov    %rcx,-0x20(%rbp)
 100f466:	48 89 8d c8 fd ff ff 	mov    %rcx,-0x238(%rbp)
 100f46d:	b9 0d 00 00 00       	mov    $0xd,%ecx
 100f472:	48 8d 95 38 fc ff ff 	lea    -0x3c8(%rbp),%rdx
 100f479:	48 8d b5 18 fc ff ff 	lea    -0x3e8(%rbp),%rsi
 100f480:	49 89 ff             	mov    %rdi,%r15
 100f483:	e8 c8 73 00 00       	call   1016850 <myl_qbe_rc_frame_enter>
 100f488:	4c 89 ff             	mov    %r15,%rdi
 100f48b:	49 89 ff             	mov    %rdi,%r15
 100f48e:	e8 fd 7c 00 00       	call   1017190 <myl_qbe_require_step_accounting>
 100f493:	4c 89 ff             	mov    %r15,%rdi
 100f496:	49 89 ff             	mov    %rdi,%r15
 100f499:	e8 52 7d 00 00       	call   10171f0 <myl_qbe_require_frame_accounting>
 100f49e:	4c 89 ff             	mov    %r15,%rdi
 100f4a1:	48 c7 85 08 ff ff ff 	movq   $0x0,-0xf8(%rbp)
 100f4a8:	00 00 00 00 
 100f4ac:	ba 00 00 00 00       	mov    $0x0,%edx
 100f4b1:	48 8d 35 98 f8 01 00 	lea    0x1f898(%rip),%rsi        # 102ed50 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a>
 100f4b8:	49 89 ff             	mov    %rdi,%r15
 100f4bb:	48 89 df             	mov    %rbx,%rdi
 100f4be:	e8 8d e2 00 00       	call   101d750 <myl_native_list_new>
 100f4c3:	4c 89 ff             	mov    %r15,%rdi
 100f4c6:	4c 8b 45 d8          	mov    -0x28(%rbp),%r8
 100f4ca:	83 f8 00             	cmp    $0x0,%eax
 100f4cd:	75 0a                	jne    100f4d9 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x529>
 100f4cf:	48 89 fb             	mov    %rdi,%rbx
 100f4d2:	e8 e9 79 00 00       	call   1016ec0 <myl_qbe_fail_allocation>
 100f4d7:	0f 0b                	ud2
 100f4d9:	48 87 fb             	xchg   %rdi,%rbx
 100f4dc:	48 89 85 08 ff ff ff 	mov    %rax,-0xf8(%rbp)
 100f4e3:	48 8b 8d 08 ff ff ff 	mov    -0xf8(%rbp),%rcx
 100f4ea:	48 89 8d 58 fe ff ff 	mov    %rcx,-0x1a8(%rbp)
 100f4f1:	48 8d 0d c8 f8 01 00 	lea    0x1f8c8(%rip),%rcx        # 102edc0 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b>
 100f4f8:	48 89 8d 98 fd ff ff 	mov    %rcx,-0x268(%rbp)
 100f4ff:	c7 85 b0 fd ff ff 02 	movl   $0x2,-0x250(%rbp)
 100f506:	00 00 00 
 100f509:	c7 85 30 fe ff ff 01 	movl   $0x1,-0x1d0(%rbp)
 100f510:	00 00 00 
 100f513:	48 8b 8d 58 fe ff ff 	mov    -0x1a8(%rbp),%rcx
 100f51a:	48 89 8d 40 fe ff ff 	mov    %rcx,-0x1c0(%rbp)
 100f521:	48 8d 0d 98 f8 01 00 	lea    0x1f898(%rip),%rcx        # 102edc0 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b>
 100f528:	48 89 8d 38 fd ff ff 	mov    %rcx,-0x2c8(%rbp)
 100f52f:	c7 85 50 fd ff ff 02 	movl   $0x2,-0x2b0(%rbp)
 100f536:	00 00 00 
 100f539:	c7 85 50 fd ff ff 02 	movl   $0x2,-0x2b0(%rbp)
 100f540:	00 00 00 
 100f543:	c7 85 30 fe ff ff 00 	movl   $0x0,-0x1d0(%rbp)
 100f54a:	00 00 00 
 100f54d:	c7 85 18 fe ff ff 01 	movl   $0x1,-0x1e8(%rbp)
 100f554:	00 00 00 
 100f557:	48 89 85 08 ff ff ff 	mov    %rax,-0xf8(%rbp)
 100f55e:	48 8d 95 58 fe ff ff 	lea    -0x1a8(%rbp),%rdx
 100f565:	48 8d 8d 08 ff ff ff 	lea    -0xf8(%rbp),%rcx
 100f56c:	48 29 d1             	sub    %rdx,%rcx
 100f56f:	48 8d b5 08 ff ff ff 	lea    -0xf8(%rbp),%rsi
 100f576:	48 8d 95 58 fe ff ff 	lea    -0x1a8(%rbp),%rdx
 100f57d:	48 29 f2             	sub    %rsi,%rdx
 100f580:	48 83 f9 08          	cmp    $0x8,%rcx
 100f584:	0f 92 c1             	setb   %cl
 100f587:	0f b6 c9             	movzbl %cl,%ecx
 100f58a:	89 4d e8             	mov    %ecx,-0x18(%rbp)
 100f58d:	48 83 fa 08          	cmp    $0x8,%rdx
 100f591:	0f 92 c2             	setb   %dl
 100f594:	0f b6 d2             	movzbl %dl,%edx
 100f597:	89 55 ec             	mov    %edx,-0x14(%rbp)
 100f59a:	09 d1                	or     %edx,%ecx
 100f59c:	75 5a                	jne    100f5f8 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x648>
 100f59e:	48 83 f8 00          	cmp    $0x0,%rax
 100f5a2:	74 1a                	je     100f5be <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x60e>
 100f5a4:	48 83 e8 10          	sub    $0x10,%rax
 100f5a8:	48 8b 00             	mov    (%rax),%rax
 100f5ab:	48 b9 01 00 00 00 00 	movabs $0x5000000000000001,%rcx
 100f5b2:	00 00 50 
 100f5b5:	48 21 c8             	and    %rcx,%rax
 100f5b8:	48 83 f8 00          	cmp    $0x0,%rax
 100f5bc:	75 3a                	jne    100f5f8 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x648>
 100f5be:	48 8b 85 08 ff ff ff 	mov    -0xf8(%rbp),%rax
 100f5c5:	48 89 85 58 fe ff ff 	mov    %rax,-0x1a8(%rbp)
 100f5cc:	ba 08 00 00 00       	mov    $0x8,%edx
 100f5d1:	be 00 00 00 00       	mov    $0x0,%esi
 100f5d6:	49 89 ff             	mov    %rdi,%r15
 100f5d9:	48 8d bd 08 ff ff ff 	lea    -0xf8(%rbp),%rdi
 100f5e0:	e8 5b cd 01 00       	call   102c340 <compiler_rt.fastMemset>
 100f5e5:	4c 89 ff             	mov    %r15,%rdi
 100f5e8:	8b 55 ec             	mov    -0x14(%rbp),%edx
 100f5eb:	8b 4d e8             	mov    -0x18(%rbp),%ecx
 100f5ee:	48 8b 75 f0          	mov    -0x10(%rbp),%rsi
 100f5f2:	4c 8b 45 d8          	mov    -0x28(%rbp),%r8
 100f5f6:	eb 4d                	jmp    100f645 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x695>
 100f5f8:	48 8d 8d 08 ff ff ff 	lea    -0xf8(%rbp),%rcx
 100f5ff:	48 8d 95 58 fe ff ff 	lea    -0x1a8(%rbp),%rdx
 100f606:	48 8d 35 b3 f7 01 00 	lea    0x1f7b3(%rip),%rsi        # 102edc0 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b>
 100f60d:	49 89 ff             	mov    %rdi,%r15
 100f610:	e8 cb c1 01 00       	call   102b7e0 <myl_rc_native_take>
 100f615:	4c 89 ff             	mov    %r15,%rdi
 100f618:	8b 55 ec             	mov    -0x14(%rbp),%edx
 100f61b:	8b 4d e8             	mov    -0x18(%rbp),%ecx
 100f61e:	48 8b 75 f0          	mov    -0x10(%rbp),%rsi
 100f622:	4c 8b 45 d8          	mov    -0x28(%rbp),%r8
 100f626:	83 f8 00             	cmp    $0x0,%eax
 100f629:	75 1a                	jne    100f645 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x695>
 100f62b:	e8 40 42 01 00       	call   1023870 <myl_rc_take_failure>
 100f630:	48 89 df             	mov    %rbx,%rdi
 100f633:	89 c6                	mov    %eax,%esi
 100f635:	48 89 fb             	mov    %rdi,%rbx
 100f638:	e8 23 71 00 00       	call   1016760 <myl_qbe_rc_status>
 100f63d:	48 89 df             	mov    %rbx,%rdi
 100f640:	e9 61 17 00 00       	jmp    1010da6 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1df6>
 100f645:	c7 85 18 fe ff ff 00 	movl   $0x0,-0x1e8(%rbp)
 100f64c:	00 00 00 
 100f64f:	48 8d 05 6a f7 01 00 	lea    0x1f76a(%rip),%rax        # 102edc0 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b>
 100f656:	48 89 85 98 fd ff ff 	mov    %rax,-0x268(%rbp)
 100f65d:	c7 85 b0 fd ff ff 02 	movl   $0x2,-0x250(%rbp)
 100f664:	00 00 00 
 100f667:	c7 85 30 fe ff ff 01 	movl   $0x1,-0x1d0(%rbp)
 100f66e:	00 00 00 
 100f671:	8b 85 d8 fd ff ff    	mov    -0x228(%rbp),%eax
 100f677:	83 f8 00             	cmp    $0x0,%eax
 100f67a:	74 23                	je     100f69f <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x6ef>
 100f67c:	48 8d b5 38 fc ff ff 	lea    -0x3c8(%rbp),%rsi
 100f683:	49 89 ff             	mov    %rdi,%r15
 100f686:	48 89 df             	mov    %rbx,%rdi
 100f689:	e8 a2 72 00 00       	call   1016930 <myl_qbe_rc_slot_drop>
 100f68e:	4c 89 ff             	mov    %r15,%rdi
 100f691:	8b 55 ec             	mov    -0x14(%rbp),%edx
 100f694:	8b 4d e8             	mov    -0x18(%rbp),%ecx
 100f697:	48 8b 75 f0          	mov    -0x10(%rbp),%rsi
 100f69b:	4c 8b 45 d8          	mov    -0x28(%rbp),%r8
 100f69f:	48 8b 85 58 fe ff ff 	mov    -0x1a8(%rbp),%rax
 100f6a6:	48 89 85 c8 fe ff ff 	mov    %rax,-0x138(%rbp)
 100f6ad:	c7 85 30 fe ff ff 00 	movl   $0x0,-0x1d0(%rbp)
 100f6b4:	00 00 00 
 100f6b7:	48 8d 05 02 f7 01 00 	lea    0x1f702(%rip),%rax        # 102edc0 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b>
 100f6be:	48 89 85 38 fc ff ff 	mov    %rax,-0x3c8(%rbp)
 100f6c5:	c7 85 50 fc ff ff 02 	movl   $0x2,-0x3b0(%rbp)
 100f6cc:	00 00 00 
 100f6cf:	48 8d 85 c8 fe ff ff 	lea    -0x138(%rbp),%rax
 100f6d6:	48 89 85 40 fc ff ff 	mov    %rax,-0x3c0(%rbp)
 100f6dd:	48 8d 85 d8 fd ff ff 	lea    -0x228(%rbp),%rax
 100f6e4:	48 89 85 48 fc ff ff 	mov    %rax,-0x3b8(%rbp)
 100f6eb:	8b 85 b0 fd ff ff    	mov    -0x250(%rbp),%eax
 100f6f1:	89 85 50 fc ff ff    	mov    %eax,-0x3b0(%rbp)
 100f6f7:	c7 85 d8 fd ff ff 01 	movl   $0x1,-0x228(%rbp)
 100f6fe:	00 00 00 
 100f701:	41 89 c1             	mov    %eax,%r9d
 100f704:	48 8b 85 c8 fe ff ff 	mov    -0x138(%rbp),%rax
 100f70b:	41 83 f9 08          	cmp    $0x8,%r9d
 100f70f:	74 0c                	je     100f71d <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x76d>
 100f711:	48 89 85 08 ff ff ff 	mov    %rax,-0xf8(%rbp)
 100f718:	e9 f0 00 00 00       	jmp    100f80d <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x85d>
 100f71d:	48 c7 85 58 fe ff ff 	movq   $0x0,-0x1a8(%rbp)
 100f724:	00 00 00 00 
 100f728:	48 8d 95 58 fe ff ff 	lea    -0x1a8(%rbp),%rdx
 100f72f:	48 89 c6             	mov    %rax,%rsi
 100f732:	49 89 ff             	mov    %rdi,%r15
 100f735:	e8 86 46 01 00       	call   1023dc0 <myl_rc_hold_acquire>
 100f73a:	4c 89 ff             	mov    %r15,%rdi
 100f73d:	89 c6                	mov    %eax,%esi
 100f73f:	49 89 ff             	mov    %rdi,%r15
 100f742:	48 89 df             	mov    %rbx,%rdi
 100f745:	e8 16 70 00 00       	call   1016760 <myl_qbe_rc_status>
 100f74a:	4c 89 ff             	mov    %r15,%rdi
 100f74d:	8b 55 ec             	mov    -0x14(%rbp),%edx
 100f750:	8b 4d e8             	mov    -0x18(%rbp),%ecx
 100f753:	4c 8b 7d b0          	mov    -0x50(%rbp),%r15
 100f757:	48 8b 75 f0          	mov    -0x10(%rbp),%rsi
 100f75b:	4c 8b 45 d8          	mov    -0x28(%rbp),%r8
 100f75f:	83 f8 00             	cmp    $0x0,%eax
 100f762:	75 08                	jne    100f76c <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x7bc>
 100f764:	48 89 df             	mov    %rbx,%rdi
 100f767:	e9 3a 16 00 00       	jmp    1010da6 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1df6>
 100f76c:	48 8d 05 4d f6 01 00 	lea    0x1f64d(%rip),%rax        # 102edc0 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b>
 100f773:	48 89 85 98 fd ff ff 	mov    %rax,-0x268(%rbp)
 100f77a:	c7 85 b0 fd ff ff 02 	movl   $0x2,-0x250(%rbp)
 100f781:	00 00 00 
 100f784:	48 8d 85 58 fe ff ff 	lea    -0x1a8(%rbp),%rax
 100f78b:	48 89 85 a0 fd ff ff 	mov    %rax,-0x260(%rbp)
 100f792:	4c 89 a5 a8 fd ff ff 	mov    %r12,-0x258(%rbp)
 100f799:	c7 85 b0 fd ff ff 08 	movl   $0x8,-0x250(%rbp)
 100f7a0:	00 00 00 
 100f7a3:	c7 85 30 fe ff ff 01 	movl   $0x1,-0x1d0(%rbp)
 100f7aa:	00 00 00 
 100f7ad:	48 8b 85 58 fe ff ff 	mov    -0x1a8(%rbp),%rax
 100f7b4:	48 89 85 40 fe ff ff 	mov    %rax,-0x1c0(%rbp)
 100f7bb:	4c 8d 0d fe f5 01 00 	lea    0x1f5fe(%rip),%r9        # 102edc0 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b>
 100f7c2:	4c 89 8d 38 fd ff ff 	mov    %r9,-0x2c8(%rbp)
 100f7c9:	c7 85 50 fd ff ff 02 	movl   $0x2,-0x2b0(%rbp)
 100f7d0:	00 00 00 
 100f7d3:	4c 8d 8d 40 fe ff ff 	lea    -0x1c0(%rbp),%r9
 100f7da:	4c 89 8d 40 fd ff ff 	mov    %r9,-0x2c0(%rbp)
 100f7e1:	4c 89 bd 48 fd ff ff 	mov    %r15,-0x2b8(%rbp)
 100f7e8:	c7 85 50 fd ff ff 08 	movl   $0x8,-0x2b0(%rbp)
 100f7ef:	00 00 00 
 100f7f2:	c7 85 18 fe ff ff 01 	movl   $0x1,-0x1e8(%rbp)
 100f7f9:	00 00 00 
 100f7fc:	c7 85 30 fe ff ff 00 	movl   $0x0,-0x1d0(%rbp)
 100f803:	00 00 00 
 100f806:	48 89 85 08 ff ff ff 	mov    %rax,-0xf8(%rbp)
 100f80d:	44 8b 8d 18 fe ff ff 	mov    -0x1e8(%rbp),%r9d
 100f814:	44 8b 95 50 fd ff ff 	mov    -0x2b0(%rbp),%r10d
 100f81b:	41 83 e2 18          	and    $0x18,%r10d
 100f81f:	41 83 fa 00          	cmp    $0x0,%r10d
 100f823:	41 0f 94 c2          	sete   %r10b
 100f827:	45 0f b6 d2          	movzbl %r10b,%r10d
 100f82b:	45 85 ca             	test   %r9d,%r10d
 100f82e:	0f 85 91 00 00 00    	jne    100f8c5 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x915>
 100f834:	48 8d 8d 08 ff ff ff 	lea    -0xf8(%rbp),%rcx
 100f83b:	48 8d 95 58 fe ff ff 	lea    -0x1a8(%rbp),%rdx
 100f842:	49 89 f7             	mov    %rsi,%r15
 100f845:	48 8d 35 74 f5 01 00 	lea    0x1f574(%rip),%rsi        # 102edc0 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b>
 100f84c:	49 89 fc             	mov    %rdi,%r12
 100f84f:	e8 ec c5 01 00       	call   102be40 <myl_rc_native_retain>
 100f854:	4c 89 fe             	mov    %r15,%rsi
 100f857:	4c 89 e7             	mov    %r12,%rdi
 100f85a:	83 f8 00             	cmp    $0x0,%eax
 100f85d:	75 1a                	jne    100f879 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x8c9>
 100f85f:	e8 0c 40 01 00       	call   1023870 <myl_rc_take_failure>
 100f864:	48 89 df             	mov    %rbx,%rdi
 100f867:	89 c6                	mov    %eax,%esi
 100f869:	48 89 fb             	mov    %rdi,%rbx
 100f86c:	e8 ef 6e 00 00       	call   1016760 <myl_qbe_rc_status>
 100f871:	48 89 df             	mov    %rbx,%rdi
 100f874:	e9 2d 15 00 00       	jmp    1010da6 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1df6>
 100f879:	48 8d 05 40 f5 01 00 	lea    0x1f540(%rip),%rax        # 102edc0 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b>
 100f880:	48 89 85 98 fd ff ff 	mov    %rax,-0x268(%rbp)
 100f887:	c7 85 b0 fd ff ff 02 	movl   $0x2,-0x250(%rbp)
 100f88e:	00 00 00 
 100f891:	c7 85 30 fe ff ff 01 	movl   $0x1,-0x1d0(%rbp)
 100f898:	00 00 00 
 100f89b:	8b 85 18 fe ff ff    	mov    -0x1e8(%rbp),%eax
 100f8a1:	83 f8 00             	cmp    $0x0,%eax
 100f8a4:	74 17                	je     100f8bd <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x90d>
 100f8a6:	49 89 f7             	mov    %rsi,%r15
 100f8a9:	4c 89 ee             	mov    %r13,%rsi
 100f8ac:	49 89 fc             	mov    %rdi,%r12
 100f8af:	48 89 df             	mov    %rbx,%rdi
 100f8b2:	e8 79 70 00 00       	call   1016930 <myl_qbe_rc_slot_drop>
 100f8b7:	4c 89 fe             	mov    %r15,%rsi
 100f8ba:	4c 89 e7             	mov    %r12,%rdi
 100f8bd:	48 87 df             	xchg   %rbx,%rdi
 100f8c0:	e9 cd 00 00 00       	jmp    100f992 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x9e2>
 100f8c5:	09 d1                	or     %edx,%ecx
 100f8c7:	75 55                	jne    100f91e <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x96e>
 100f8c9:	48 83 f8 00          	cmp    $0x0,%rax
 100f8cd:	74 1a                	je     100f8e9 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x939>
 100f8cf:	48 83 e8 10          	sub    $0x10,%rax
 100f8d3:	48 8b 00             	mov    (%rax),%rax
 100f8d6:	48 b9 01 00 00 00 00 	movabs $0x5000000000000001,%rcx
 100f8dd:	00 00 50 
 100f8e0:	48 21 c8             	and    %rcx,%rax
 100f8e3:	48 83 f8 00          	cmp    $0x0,%rax
 100f8e7:	75 35                	jne    100f91e <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x96e>
 100f8e9:	48 8b 85 08 ff ff ff 	mov    -0xf8(%rbp),%rax
 100f8f0:	48 89 85 58 fe ff ff 	mov    %rax,-0x1a8(%rbp)
 100f8f7:	ba 08 00 00 00       	mov    $0x8,%edx
 100f8fc:	49 89 f7             	mov    %rsi,%r15
 100f8ff:	be 00 00 00 00       	mov    $0x0,%esi
 100f904:	49 89 fc             	mov    %rdi,%r12
 100f907:	48 8d bd 08 ff ff ff 	lea    -0xf8(%rbp),%rdi
 100f90e:	e8 2d ca 01 00       	call   102c340 <compiler_rt.fastMemset>
 100f913:	4c 89 fe             	mov    %r15,%rsi
 100f916:	4c 89 e7             	mov    %r12,%rdi
 100f919:	48 87 df             	xchg   %rbx,%rdi
 100f91c:	eb 48                	jmp    100f966 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x9b6>
 100f91e:	48 8d 8d 08 ff ff ff 	lea    -0xf8(%rbp),%rcx
 100f925:	48 8d 95 58 fe ff ff 	lea    -0x1a8(%rbp),%rdx
 100f92c:	49 89 f7             	mov    %rsi,%r15
 100f92f:	48 8d 35 8a f4 01 00 	lea    0x1f48a(%rip),%rsi        # 102edc0 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b>
 100f936:	49 89 fc             	mov    %rdi,%r12
 100f939:	e8 a2 be 01 00       	call   102b7e0 <myl_rc_native_take>
 100f93e:	4c 89 fe             	mov    %r15,%rsi
 100f941:	4c 89 e7             	mov    %r12,%rdi
 100f944:	83 f8 00             	cmp    $0x0,%eax
 100f947:	75 1a                	jne    100f963 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x9b3>
 100f949:	e8 22 3f 01 00       	call   1023870 <myl_rc_take_failure>
 100f94e:	48 89 df             	mov    %rbx,%rdi
 100f951:	89 c6                	mov    %eax,%esi
 100f953:	48 89 fb             	mov    %rdi,%rbx
 100f956:	e8 05 6e 00 00       	call   1016760 <myl_qbe_rc_status>
 100f95b:	48 89 df             	mov    %rbx,%rdi
 100f95e:	e9 43 14 00 00       	jmp    1010da6 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1df6>
 100f963:	48 87 df             	xchg   %rbx,%rdi
 100f966:	c7 85 18 fe ff ff 00 	movl   $0x0,-0x1e8(%rbp)
 100f96d:	00 00 00 
 100f970:	48 8d 05 49 f4 01 00 	lea    0x1f449(%rip),%rax        # 102edc0 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b>
 100f977:	48 89 85 98 fd ff ff 	mov    %rax,-0x268(%rbp)
 100f97e:	c7 85 b0 fd ff ff 02 	movl   $0x2,-0x250(%rbp)
 100f985:	00 00 00 
 100f988:	c7 85 30 fe ff ff 01 	movl   $0x1,-0x1d0(%rbp)
 100f98f:	00 00 00 
 100f992:	8b 85 e0 fd ff ff    	mov    -0x220(%rbp),%eax
 100f998:	83 f8 00             	cmp    $0x0,%eax
 100f99b:	74 0b                	je     100f9a8 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x9f8>
 100f99d:	49 89 fc             	mov    %rdi,%r12
 100f9a0:	e8 8b 6f 00 00       	call   1016930 <myl_qbe_rc_slot_drop>
 100f9a5:	4c 89 e7             	mov    %r12,%rdi
 100f9a8:	48 8b 85 58 fe ff ff 	mov    -0x1a8(%rbp),%rax
 100f9af:	48 89 85 d0 fe ff ff 	mov    %rax,-0x130(%rbp)
 100f9b6:	c7 85 30 fe ff ff 00 	movl   $0x0,-0x1d0(%rbp)
 100f9bd:	00 00 00 
 100f9c0:	48 8d 05 f9 f3 01 00 	lea    0x1f3f9(%rip),%rax        # 102edc0 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b>
 100f9c7:	48 89 85 58 fc ff ff 	mov    %rax,-0x3a8(%rbp)
 100f9ce:	c7 85 70 fc ff ff 02 	movl   $0x2,-0x390(%rbp)
 100f9d5:	00 00 00 
 100f9d8:	48 8d 85 d0 fe ff ff 	lea    -0x130(%rbp),%rax
 100f9df:	48 89 85 60 fc ff ff 	mov    %rax,-0x3a0(%rbp)
 100f9e6:	4c 89 b5 68 fc ff ff 	mov    %r14,-0x398(%rbp)
 100f9ed:	8b 85 b0 fd ff ff    	mov    -0x250(%rbp),%eax
 100f9f3:	89 85 70 fc ff ff    	mov    %eax,-0x390(%rbp)
 100f9f9:	c7 85 e0 fd ff ff 01 	movl   $0x1,-0x220(%rbp)
 100fa00:	00 00 00 
 100fa03:	8b 85 d8 fd ff ff    	mov    -0x228(%rbp),%eax
 100fa09:	83 f8 00             	cmp    $0x0,%eax
 100fa0c:	74 12                	je     100fa20 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xa70>
 100fa0e:	48 8d b5 38 fc ff ff 	lea    -0x3c8(%rbp),%rsi
 100fa15:	49 89 fc             	mov    %rdi,%r12
 100fa18:	e8 13 6f 00 00       	call   1016930 <myl_qbe_rc_slot_drop>
 100fa1d:	4c 89 e7             	mov    %r12,%rdi
 100fa20:	48 c7 85 08 ff ff ff 	movq   $0x0,-0xf8(%rbp)
 100fa27:	00 00 00 00 
 100fa2b:	48 c7 85 08 ff ff ff 	movq   $0x3e8,-0xf8(%rbp)
 100fa32:	e8 03 00 00 
 100fa36:	41 bc 00 00 00 00    	mov    $0x0,%r12d
 100fa3c:	0f 1f 40 00          	nopl   0x0(%rax)
 100fa40:	4c 89 a5 08 ff ff ff 	mov    %r12,-0xf8(%rbp)
 100fa47:	48 c7 85 10 ff ff ff 	movq   $0x3e8,-0xf0(%rbp)
 100fa4e:	e8 03 00 00 
 100fa52:	49 81 fc e8 03 00 00 	cmp    $0x3e8,%r12
 100fa59:	0f 9c c0             	setl   %al
 100fa5c:	48 0f b6 c0          	movzbq %al,%rax
 100fa60:	48 89 85 08 ff ff ff 	mov    %rax,-0xf8(%rbp)
 100fa67:	0f 8d 43 03 00 00    	jge    100fdb0 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xe00>
 100fa6d:	48 c7 85 08 ff ff ff 	movq   $0x6b,-0xf8(%rbp)
 100fa74:	6b 00 00 00 
 100fa78:	48 c7 85 10 ff ff ff 	movq   $0x65,-0xf0(%rbp)
 100fa7f:	65 00 00 00 
 100fa83:	48 c7 85 18 ff ff ff 	movq   $0x79,-0xe8(%rbp)
 100fa8a:	79 00 00 00 
 100fa8e:	48 8b 05 43 fb 01 00 	mov    0x1fb43(%rip),%rax        # 102f5d8 <myl_lit_7c9ad5bce17f8d7309d981a8c987a567b0a2e56945e29fb3b883a7b4446dd143>
 100fa95:	48 89 85 08 ff ff ff 	mov    %rax,-0xf8(%rbp)
 100fa9c:	48 8b 8d 08 ff ff ff 	mov    -0xf8(%rbp),%rcx
 100faa3:	48 89 8d 58 fe ff ff 	mov    %rcx,-0x1a8(%rbp)
 100faaa:	48 8d 0d 9f f2 01 00 	lea    0x1f29f(%rip),%rcx        # 102ed50 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a>
 100fab1:	48 89 8d 98 fd ff ff 	mov    %rcx,-0x268(%rbp)
 100fab8:	c7 85 b0 fd ff ff 02 	movl   $0x2,-0x250(%rbp)
 100fabf:	00 00 00 
 100fac2:	c7 85 30 fe ff ff 01 	movl   $0x1,-0x1d0(%rbp)
 100fac9:	00 00 00 
 100facc:	48 8b 8d 58 fe ff ff 	mov    -0x1a8(%rbp),%rcx
 100fad3:	48 89 8d 40 fe ff ff 	mov    %rcx,-0x1c0(%rbp)
 100fada:	48 8d 0d 6f f2 01 00 	lea    0x1f26f(%rip),%rcx        # 102ed50 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a>
 100fae1:	48 89 8d 38 fd ff ff 	mov    %rcx,-0x2c8(%rbp)
 100fae8:	c7 85 50 fd ff ff 02 	movl   $0x2,-0x2b0(%rbp)
 100faef:	00 00 00 
 100faf2:	c7 85 50 fd ff ff 02 	movl   $0x2,-0x2b0(%rbp)
 100faf9:	00 00 00 
 100fafc:	c7 85 30 fe ff ff 00 	movl   $0x0,-0x1d0(%rbp)
 100fb03:	00 00 00 
 100fb06:	c7 85 18 fe ff ff 01 	movl   $0x1,-0x1e8(%rbp)
 100fb0d:	00 00 00 
 100fb10:	48 89 85 08 ff ff ff 	mov    %rax,-0xf8(%rbp)
 100fb17:	4c 89 a5 10 ff ff ff 	mov    %r12,-0xf0(%rbp)
 100fb1e:	ba 00 00 00 00       	mov    $0x0,%edx
 100fb23:	4c 89 e6             	mov    %r12,%rsi
 100fb26:	49 89 ff             	mov    %rdi,%r15
 100fb29:	48 89 df             	mov    %rbx,%rdi
 100fb2c:	e8 5f 15 00 00       	call   1011090 <myl_native_text_scalar>
 100fb31:	4c 89 ff             	mov    %r15,%rdi
 100fb34:	48 89 c2             	mov    %rax,%rdx
 100fb37:	83 fa 00             	cmp    $0x0,%edx
 100fb3a:	0f 84 69 02 00 00    	je     100fda9 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xdf9>
 100fb40:	48 89 95 10 ff ff ff 	mov    %rdx,-0xf0(%rbp)
 100fb47:	48 8b 85 10 ff ff ff 	mov    -0xf0(%rbp),%rax
 100fb4e:	48 89 85 58 fe ff ff 	mov    %rax,-0x1a8(%rbp)
 100fb55:	48 8d 05 f4 f1 01 00 	lea    0x1f1f4(%rip),%rax        # 102ed50 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a>
 100fb5c:	48 89 85 98 fd ff ff 	mov    %rax,-0x268(%rbp)
 100fb63:	c7 85 b0 fd ff ff 02 	movl   $0x2,-0x250(%rbp)
 100fb6a:	00 00 00 
 100fb6d:	c7 85 30 fe ff ff 01 	movl   $0x1,-0x1d0(%rbp)
 100fb74:	00 00 00 
 100fb77:	48 8b 85 58 fe ff ff 	mov    -0x1a8(%rbp),%rax
 100fb7e:	48 89 85 48 fe ff ff 	mov    %rax,-0x1b8(%rbp)
 100fb85:	48 8d 05 c4 f1 01 00 	lea    0x1f1c4(%rip),%rax        # 102ed50 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a>
 100fb8c:	48 89 85 58 fd ff ff 	mov    %rax,-0x2a8(%rbp)
 100fb93:	c7 85 70 fd ff ff 02 	movl   $0x2,-0x290(%rbp)
 100fb9a:	00 00 00 
 100fb9d:	c7 85 70 fd ff ff 02 	movl   $0x2,-0x290(%rbp)
 100fba4:	00 00 00 
 100fba7:	c7 85 30 fe ff ff 00 	movl   $0x0,-0x1d0(%rbp)
 100fbae:	00 00 00 
 100fbb1:	c7 85 20 fe ff ff 01 	movl   $0x1,-0x1e0(%rbp)
 100fbb8:	00 00 00 
 100fbbb:	48 89 95 10 ff ff ff 	mov    %rdx,-0xf0(%rbp)
 100fbc2:	48 8b b5 08 ff ff ff 	mov    -0xf8(%rbp),%rsi
 100fbc9:	49 89 ff             	mov    %rdi,%r15
 100fbcc:	48 89 df             	mov    %rbx,%rdi
 100fbcf:	e8 0c ec 00 00       	call   101e7e0 <myl_native_text_concat>
 100fbd4:	4c 89 ff             	mov    %r15,%rdi
 100fbd7:	4c 8b 85 48 ff ff ff 	mov    -0xb8(%rbp),%r8
 100fbde:	83 f8 00             	cmp    $0x0,%eax
 100fbe1:	0f 84 bb 01 00 00    	je     100fda2 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xdf2>
 100fbe7:	48 89 85 08 ff ff ff 	mov    %rax,-0xf8(%rbp)
 100fbee:	48 8b 85 08 ff ff ff 	mov    -0xf8(%rbp),%rax
 100fbf5:	48 89 85 58 fe ff ff 	mov    %rax,-0x1a8(%rbp)
 100fbfc:	48 8d 05 4d f1 01 00 	lea    0x1f14d(%rip),%rax        # 102ed50 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a>
 100fc03:	48 89 85 98 fd ff ff 	mov    %rax,-0x268(%rbp)
 100fc0a:	c7 85 b0 fd ff ff 02 	movl   $0x2,-0x250(%rbp)
 100fc11:	00 00 00 
 100fc14:	c7 85 30 fe ff ff 01 	movl   $0x1,-0x1d0(%rbp)
 100fc1b:	00 00 00 
 100fc1e:	8b 85 18 fe ff ff    	mov    -0x1e8(%rbp),%eax
 100fc24:	83 f8 00             	cmp    $0x0,%eax
 100fc27:	74 15                	je     100fc3e <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xc8e>
 100fc29:	4c 89 ee             	mov    %r13,%rsi
 100fc2c:	49 89 ff             	mov    %rdi,%r15
 100fc2f:	e8 fc 6c 00 00       	call   1016930 <myl_qbe_rc_slot_drop>
 100fc34:	4c 89 ff             	mov    %r15,%rdi
 100fc37:	4c 8b 85 48 ff ff ff 	mov    -0xb8(%rbp),%r8
 100fc3e:	8b 85 20 fe ff ff    	mov    -0x1e0(%rbp),%eax
 100fc44:	83 f8 00             	cmp    $0x0,%eax
 100fc47:	74 0e                	je     100fc57 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xca7>
 100fc49:	4c 89 c6             	mov    %r8,%rsi
 100fc4c:	49 89 ff             	mov    %rdi,%r15
 100fc4f:	e8 dc 6c 00 00       	call   1016930 <myl_qbe_rc_slot_drop>
 100fc54:	4c 89 ff             	mov    %r15,%rdi
 100fc57:	48 8b 85 58 fe ff ff 	mov    -0x1a8(%rbp),%rax
 100fc5e:	48 89 85 40 fe ff ff 	mov    %rax,-0x1c0(%rbp)
 100fc65:	48 8d 05 e4 f0 01 00 	lea    0x1f0e4(%rip),%rax        # 102ed50 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a>
 100fc6c:	48 89 85 38 fd ff ff 	mov    %rax,-0x2c8(%rbp)
 100fc73:	c7 85 50 fd ff ff 02 	movl   $0x2,-0x2b0(%rbp)
 100fc7a:	00 00 00 
 100fc7d:	8b 85 b0 fd ff ff    	mov    -0x250(%rbp),%eax
 100fc83:	89 85 50 fd ff ff    	mov    %eax,-0x2b0(%rbp)
 100fc89:	c7 85 30 fe ff ff 00 	movl   $0x0,-0x1d0(%rbp)
 100fc90:	00 00 00 
 100fc93:	c7 85 18 fe ff ff 01 	movl   $0x1,-0x1e8(%rbp)
 100fc9a:	00 00 00 
 100fc9d:	48 8b 85 40 fe ff ff 	mov    -0x1c0(%rbp),%rax
 100fca4:	48 89 85 08 ff ff ff 	mov    %rax,-0xf8(%rbp)
 100fcab:	48 8d 05 0e f1 01 00 	lea    0x1f10e(%rip),%rax        # 102edc0 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b>
 100fcb2:	48 89 85 58 fc ff ff 	mov    %rax,-0x3a8(%rbp)
 100fcb9:	c7 85 70 fc ff ff 02 	movl   $0x2,-0x390(%rbp)
 100fcc0:	00 00 00 
 100fcc3:	48 8d 85 d0 fe ff ff 	lea    -0x130(%rbp),%rax
 100fcca:	48 89 85 60 fc ff ff 	mov    %rax,-0x3a0(%rbp)
 100fcd1:	4c 89 b5 68 fc ff ff 	mov    %r14,-0x398(%rbp)
 100fcd8:	4c 89 f1             	mov    %r14,%rcx
 100fcdb:	48 8d 95 d0 fe ff ff 	lea    -0x130(%rbp),%rdx
 100fce2:	48 8d 35 d7 f0 01 00 	lea    0x1f0d7(%rip),%rsi        # 102edc0 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b>
 100fce9:	49 89 ff             	mov    %rdi,%r15
 100fcec:	e8 bf 6f 00 00       	call   1016cb0 <myl_qbe_rc_unique_local>
 100fcf1:	4c 89 ff             	mov    %r15,%rdi
 100fcf4:	83 f8 00             	cmp    $0x0,%eax
 100fcf7:	0f 84 a9 10 00 00    	je     1010da6 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1df6>
 100fcfd:	48 8b b5 d0 fe ff ff 	mov    -0x130(%rbp),%rsi
 100fd04:	48 8d 95 08 ff ff ff 	lea    -0xf8(%rbp),%rdx
 100fd0b:	49 89 ff             	mov    %rdi,%r15
 100fd0e:	48 89 df             	mov    %rbx,%rdi
 100fd11:	e8 ea de 00 00       	call   101dc00 <myl_rc_list_append>
 100fd16:	4c 89 ff             	mov    %r15,%rdi
 100fd19:	4c 8b 85 48 ff ff ff 	mov    -0xb8(%rbp),%r8
 100fd20:	83 f8 00             	cmp    $0x0,%eax
 100fd23:	74 76                	je     100fd9b <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xdeb>
 100fd25:	48 c7 85 08 ff ff ff 	movq   $0x0,-0xf8(%rbp)
 100fd2c:	00 00 00 00 
 100fd30:	8b 85 18 fe ff ff    	mov    -0x1e8(%rbp),%eax
 100fd36:	83 f8 00             	cmp    $0x0,%eax
 100fd39:	74 15                	je     100fd50 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xda0>
 100fd3b:	4c 89 ee             	mov    %r13,%rsi
 100fd3e:	49 89 ff             	mov    %rdi,%r15
 100fd41:	e8 ea 6b 00 00       	call   1016930 <myl_qbe_rc_slot_drop>
 100fd46:	4c 89 ff             	mov    %r15,%rdi
 100fd49:	4c 8b 85 48 ff ff ff 	mov    -0xb8(%rbp),%r8
 100fd50:	4c 89 a5 08 ff ff ff 	mov    %r12,-0xf8(%rbp)
 100fd57:	48 c7 85 10 ff ff ff 	movq   $0x1,-0xf0(%rbp)
 100fd5e:	01 00 00 00 
 100fd62:	48 b8 fe ff ff ff ff 	movabs $0x7ffffffffffffffe,%rax
 100fd69:	ff ff 7f 
 100fd6c:	49 39 c4             	cmp    %rax,%r12
 100fd6f:	7f 10                	jg     100fd81 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xdd1>
 100fd71:	49 83 c4 01          	add    $0x1,%r12
 100fd75:	4c 89 a5 08 ff ff ff 	mov    %r12,-0xf8(%rbp)
 100fd7c:	e9 bf fc ff ff       	jmp    100fa40 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xa90>
 100fd81:	4c 89 e2             	mov    %r12,%rdx
 100fd84:	41 b8 40 00 00 00    	mov    $0x40,%r8d
 100fd8a:	b9 01 00 00 00       	mov    $0x1,%ecx
 100fd8f:	be 00 00 00 00       	mov    $0x0,%esi
 100fd94:	e8 27 72 00 00       	call   1016fc0 <myl_qbe_fail_overflow_op>
 100fd99:	0f 0b                	ud2
 100fd9b:	e8 20 71 00 00       	call   1016ec0 <myl_qbe_fail_allocation>
 100fda0:	0f 0b                	ud2
 100fda2:	e8 19 71 00 00       	call   1016ec0 <myl_qbe_fail_allocation>
 100fda7:	0f 0b                	ud2
 100fda9:	e8 12 71 00 00       	call   1016ec0 <myl_qbe_fail_allocation>
 100fdae:	0f 0b                	ud2
 100fdb0:	4c 8b 7d b8          	mov    -0x48(%rbp),%r15
 100fdb4:	4c 8b 75 c8          	mov    -0x38(%rbp),%r14
 100fdb8:	b9 01 00 00 00       	mov    $0x1,%ecx
 100fdbd:	48 8d 15 a4 3d ff ff 	lea    -0xc25c(%rip),%rdx        # 1003b68 <myl_t_1a91deb3742283487d66c3b500f6effd7ef1170e6d4b4368fe9ec3c3f0354fda>
 100fdc4:	48 8d 35 85 ef 01 00 	lea    0x1ef85(%rip),%rsi        # 102ed50 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a>
 100fdcb:	49 89 fc             	mov    %rdi,%r12
 100fdce:	48 89 df             	mov    %rbx,%rdi
 100fdd1:	e8 ca eb 00 00       	call   101e9a0 <myl_native_dictionary_new>
 100fdd6:	4c 89 e7             	mov    %r12,%rdi
 100fdd9:	48 8b 4d e0          	mov    -0x20(%rbp),%rcx
 100fddd:	4c 8b 45 d8          	mov    -0x28(%rbp),%r8
 100fde1:	83 f8 00             	cmp    $0x0,%eax
 100fde4:	75 0a                	jne    100fdf0 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xe40>
 100fde6:	48 89 fb             	mov    %rdi,%rbx
 100fde9:	e8 d2 70 00 00       	call   1016ec0 <myl_qbe_fail_allocation>
 100fdee:	0f 0b                	ud2
 100fdf0:	48 87 fb             	xchg   %rdi,%rbx
 100fdf3:	48 89 85 60 fe ff ff 	mov    %rax,-0x1a0(%rbp)
 100fdfa:	48 8d 15 0f f1 01 00 	lea    0x1f10f(%rip),%rdx        # 102ef10 <myl_t_db6bd58975531b7368ca22b8af460e2a11856412c594a38caca68120ceaa09fc>
 100fe01:	48 89 95 b8 fd ff ff 	mov    %rdx,-0x248(%rbp)
 100fe08:	c7 85 d0 fd ff ff 02 	movl   $0x2,-0x230(%rbp)
 100fe0f:	00 00 00 
 100fe12:	48 8d 95 60 fe ff ff 	lea    -0x1a0(%rbp),%rdx
 100fe19:	48 89 95 c0 fd ff ff 	mov    %rdx,-0x240(%rbp)
 100fe20:	48 89 8d c8 fd ff ff 	mov    %rcx,-0x238(%rbp)
 100fe27:	c7 85 d0 fd ff ff 04 	movl   $0x4,-0x230(%rbp)
 100fe2e:	00 00 00 
 100fe31:	c7 85 38 fe ff ff 01 	movl   $0x1,-0x1c8(%rbp)
 100fe38:	00 00 00 
 100fe3b:	c7 85 38 fe ff ff 00 	movl   $0x0,-0x1c8(%rbp)
 100fe42:	00 00 00 
 100fe45:	48 89 85 08 ff ff ff 	mov    %rax,-0xf8(%rbp)
 100fe4c:	48 8b 8d 08 ff ff ff 	mov    -0xf8(%rbp),%rcx
 100fe53:	48 89 8d 58 fe ff ff 	mov    %rcx,-0x1a8(%rbp)
 100fe5a:	48 8d 0d af f0 01 00 	lea    0x1f0af(%rip),%rcx        # 102ef10 <myl_t_db6bd58975531b7368ca22b8af460e2a11856412c594a38caca68120ceaa09fc>
 100fe61:	48 89 8d 98 fd ff ff 	mov    %rcx,-0x268(%rbp)
 100fe68:	c7 85 b0 fd ff ff 02 	movl   $0x2,-0x250(%rbp)
 100fe6f:	00 00 00 
 100fe72:	c7 85 30 fe ff ff 01 	movl   $0x1,-0x1d0(%rbp)
 100fe79:	00 00 00 
 100fe7c:	48 8b 8d 58 fe ff ff 	mov    -0x1a8(%rbp),%rcx
 100fe83:	48 89 8d 40 fe ff ff 	mov    %rcx,-0x1c0(%rbp)
 100fe8a:	48 8d 0d 7f f0 01 00 	lea    0x1f07f(%rip),%rcx        # 102ef10 <myl_t_db6bd58975531b7368ca22b8af460e2a11856412c594a38caca68120ceaa09fc>
 100fe91:	48 89 8d 38 fd ff ff 	mov    %rcx,-0x2c8(%rbp)
 100fe98:	c7 85 50 fd ff ff 02 	movl   $0x2,-0x2b0(%rbp)
 100fe9f:	00 00 00 
 100fea2:	c7 85 50 fd ff ff 02 	movl   $0x2,-0x2b0(%rbp)
 100fea9:	00 00 00 
 100feac:	c7 85 30 fe ff ff 00 	movl   $0x0,-0x1d0(%rbp)
 100feb3:	00 00 00 
 100feb6:	c7 85 18 fe ff ff 01 	movl   $0x1,-0x1e8(%rbp)
 100febd:	00 00 00 
 100fec0:	48 89 85 08 ff ff ff 	mov    %rax,-0xf8(%rbp)
 100fec7:	48 83 f8 00          	cmp    $0x0,%rax
 100fecb:	74 1a                	je     100fee7 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xf37>
 100fecd:	48 83 e8 10          	sub    $0x10,%rax
 100fed1:	48 8b 00             	mov    (%rax),%rax
 100fed4:	48 b9 01 00 00 00 00 	movabs $0x5000000000000001,%rcx
 100fedb:	00 00 50 
 100fede:	48 21 c8             	and    %rcx,%rax
 100fee1:	48 83 f8 00          	cmp    $0x0,%rax
 100fee5:	75 33                	jne    100ff1a <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xf6a>
 100fee7:	48 8b 85 08 ff ff ff 	mov    -0xf8(%rbp),%rax
 100feee:	48 89 85 58 fe ff ff 	mov    %rax,-0x1a8(%rbp)
 100fef5:	ba 08 00 00 00       	mov    $0x8,%edx
 100fefa:	be 00 00 00 00       	mov    $0x0,%esi
 100feff:	49 89 fc             	mov    %rdi,%r12
 100ff02:	48 8d bd 08 ff ff ff 	lea    -0xf8(%rbp),%rdi
 100ff09:	e8 32 c4 01 00       	call   102c340 <compiler_rt.fastMemset>
 100ff0e:	4c 89 e7             	mov    %r12,%rdi
 100ff11:	48 8b 75 d0          	mov    -0x30(%rbp),%rsi
 100ff15:	48 87 df             	xchg   %rbx,%rdi
 100ff18:	eb 46                	jmp    100ff60 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xfb0>
 100ff1a:	48 8d 8d 08 ff ff ff 	lea    -0xf8(%rbp),%rcx
 100ff21:	48 8d 95 58 fe ff ff 	lea    -0x1a8(%rbp),%rdx
 100ff28:	48 8d 35 e1 ef 01 00 	lea    0x1efe1(%rip),%rsi        # 102ef10 <myl_t_db6bd58975531b7368ca22b8af460e2a11856412c594a38caca68120ceaa09fc>
 100ff2f:	49 89 fc             	mov    %rdi,%r12
 100ff32:	e8 a9 b8 01 00       	call   102b7e0 <myl_rc_native_take>
 100ff37:	4c 89 e7             	mov    %r12,%rdi
 100ff3a:	48 8b 75 d0          	mov    -0x30(%rbp),%rsi
 100ff3e:	83 f8 00             	cmp    $0x0,%eax
 100ff41:	75 1a                	jne    100ff5d <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xfad>
 100ff43:	e8 28 39 01 00       	call   1023870 <myl_rc_take_failure>
 100ff48:	48 89 df             	mov    %rbx,%rdi
 100ff4b:	89 c6                	mov    %eax,%esi
 100ff4d:	48 89 fb             	mov    %rdi,%rbx
 100ff50:	e8 0b 68 00 00       	call   1016760 <myl_qbe_rc_status>
 100ff55:	48 89 df             	mov    %rbx,%rdi
 100ff58:	e9 49 0e 00 00       	jmp    1010da6 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1df6>
 100ff5d:	48 87 df             	xchg   %rbx,%rdi
 100ff60:	c7 85 18 fe ff ff 00 	movl   $0x0,-0x1e8(%rbp)
 100ff67:	00 00 00 
 100ff6a:	48 8d 05 9f ef 01 00 	lea    0x1ef9f(%rip),%rax        # 102ef10 <myl_t_db6bd58975531b7368ca22b8af460e2a11856412c594a38caca68120ceaa09fc>
 100ff71:	48 89 85 98 fd ff ff 	mov    %rax,-0x268(%rbp)
 100ff78:	c7 85 b0 fd ff ff 02 	movl   $0x2,-0x250(%rbp)
 100ff7f:	00 00 00 
 100ff82:	c7 85 30 fe ff ff 01 	movl   $0x1,-0x1d0(%rbp)
 100ff89:	00 00 00 
 100ff8c:	8b 85 e8 fd ff ff    	mov    -0x218(%rbp),%eax
 100ff92:	83 f8 00             	cmp    $0x0,%eax
 100ff95:	74 0b                	je     100ffa2 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xff2>
 100ff97:	49 89 fc             	mov    %rdi,%r12
 100ff9a:	e8 91 69 00 00       	call   1016930 <myl_qbe_rc_slot_drop>
 100ff9f:	4c 89 e7             	mov    %r12,%rdi
 100ffa2:	48 8b 85 58 fe ff ff 	mov    -0x1a8(%rbp),%rax
 100ffa9:	48 89 85 d8 fe ff ff 	mov    %rax,-0x128(%rbp)
 100ffb0:	c7 85 30 fe ff ff 00 	movl   $0x0,-0x1d0(%rbp)
 100ffb7:	00 00 00 
 100ffba:	48 8d 05 4f ef 01 00 	lea    0x1ef4f(%rip),%rax        # 102ef10 <myl_t_db6bd58975531b7368ca22b8af460e2a11856412c594a38caca68120ceaa09fc>
 100ffc1:	48 89 85 78 fc ff ff 	mov    %rax,-0x388(%rbp)
 100ffc8:	c7 85 90 fc ff ff 02 	movl   $0x2,-0x370(%rbp)
 100ffcf:	00 00 00 
 100ffd2:	48 8d 85 d8 fe ff ff 	lea    -0x128(%rbp),%rax
 100ffd9:	48 89 85 80 fc ff ff 	mov    %rax,-0x380(%rbp)
 100ffe0:	4c 89 b5 88 fc ff ff 	mov    %r14,-0x378(%rbp)
 100ffe7:	8b 85 b0 fd ff ff    	mov    -0x250(%rbp),%eax
 100ffed:	89 85 90 fc ff ff    	mov    %eax,-0x370(%rbp)
 100fff3:	c7 85 e8 fd ff ff 01 	movl   $0x1,-0x218(%rbp)
 100fffa:	00 00 00 
 100fffd:	48 c7 85 08 ff ff ff 	movq   $0x0,-0xf8(%rbp)
 1010004:	00 00 00 00 
 1010008:	48 c7 85 08 ff ff ff 	movq   $0x1e8480,-0xf8(%rbp)
 101000f:	80 84 1e 00 
 1010013:	41 bc 00 00 00 00    	mov    $0x0,%r12d
 1010019:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
 1010020:	4c 89 a5 08 ff ff ff 	mov    %r12,-0xf8(%rbp)
 1010027:	48 c7 85 10 ff ff ff 	movq   $0x1e8480,-0xf0(%rbp)
 101002e:	80 84 1e 00 
 1010032:	49 81 fc 80 84 1e 00 	cmp    $0x1e8480,%r12
 1010039:	0f 9c c0             	setl   %al
 101003c:	48 0f b6 c0          	movzbq %al,%rax
 1010040:	48 89 85 08 ff ff ff 	mov    %rax,-0xf8(%rbp)
 1010047:	0f 8d 60 04 00 00    	jge    10104ad <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x14fd>
 101004d:	48 8b b5 d0 fe ff ff 	mov    -0x130(%rbp),%rsi
 1010054:	48 89 b5 08 ff ff ff 	mov    %rsi,-0xf8(%rbp)
 101005b:	48 89 b5 e0 fe ff ff 	mov    %rsi,-0x120(%rbp)
 1010062:	4c 89 a5 08 ff ff ff 	mov    %r12,-0xf8(%rbp)
 1010069:	48 c7 85 10 ff ff ff 	movq   $0x1eef,-0xf0(%rbp)
 1010070:	ef 1e 00 00 
 1010074:	49 69 c4 ef 1e 00 00 	imul   $0x1eef,%r12,%rax
 101007b:	b9 ff ff ff ff       	mov    $0xffffffff,%ecx
 1010080:	4d 89 e1             	mov    %r12,%r9
 1010083:	49 21 c9             	and    %rcx,%r9
 1010086:	4d 89 e0             	mov    %r12,%r8
 1010089:	49 c1 e8 20          	shr    $0x20,%r8
 101008d:	49 69 c9 ef 1e 00 00 	imul   $0x1eef,%r9,%rcx
 1010094:	48 c1 e9 20          	shr    $0x20,%rcx
 1010098:	49 69 d0 ef 1e 00 00 	imul   $0x1eef,%r8,%rdx
 101009f:	48 01 ca             	add    %rcx,%rdx
 10100a2:	b9 ff ff ff ff       	mov    $0xffffffff,%ecx
 10100a7:	48 21 d1             	and    %rdx,%rcx
 10100aa:	48 c1 ea 20          	shr    $0x20,%rdx
 10100ae:	4d 6b c9 00          	imul   $0x0,%r9,%r9
 10100b2:	4c 01 c9             	add    %r9,%rcx
 10100b5:	48 c1 e9 20          	shr    $0x20,%rcx
 10100b9:	4d 6b c0 00          	imul   $0x0,%r8,%r8
 10100bd:	4c 01 c2             	add    %r8,%rdx
 10100c0:	48 01 d1             	add    %rdx,%rcx
 10100c3:	49 83 fc 00          	cmp    $0x0,%r12
 10100c7:	0f 9c c2             	setl   %dl
 10100ca:	48 0f b6 d2          	movzbq %dl,%rdx
 10100ce:	48 f7 da             	neg    %rdx
 10100d1:	49 89 d0             	mov    %rdx,%r8
 10100d4:	49 81 e0 ef 1e 00 00 	and    $0x1eef,%r8
 10100db:	4c 89 e2             	mov    %r12,%rdx
 10100de:	48 83 e2 00          	and    $0x0,%rdx
 10100e2:	4c 29 c1             	sub    %r8,%rcx
 10100e5:	48 29 d1             	sub    %rdx,%rcx
 10100e8:	48 89 c2             	mov    %rax,%rdx
 10100eb:	48 c1 fa 3f          	sar    $0x3f,%rdx
 10100ef:	48 39 ca             	cmp    %rcx,%rdx
 10100f2:	0f 85 9b 03 00 00    	jne    1010493 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x14e3>
 10100f8:	48 89 85 08 ff ff ff 	mov    %rax,-0xf8(%rbp)
 10100ff:	48 c7 85 10 ff ff ff 	movq   $0x3e8,-0xf0(%rbp)
 1010106:	e8 03 00 00 
 101010a:	48 b9 00 00 00 00 00 	movabs $0x8000000000000000,%rcx
 1010111:	00 00 80 
 1010114:	48 39 c8             	cmp    %rcx,%rax
 1010117:	0f 94 c1             	sete   %cl
 101011a:	48 0f b6 c9          	movzbq %cl,%rcx
 101011e:	48 83 e1 00          	and    $0x0,%rcx
 1010122:	48 f7 d9             	neg    %rcx
 1010125:	48 81 e1 e9 03 00 00 	and    $0x3e9,%rcx
 101012c:	49 89 c8             	mov    %rcx,%r8
 101012f:	49 81 f0 e8 03 00 00 	xor    $0x3e8,%r8
 1010136:	48 99                	cqto
 1010138:	49 f7 f8             	idiv   %r8
 101013b:	48 89 d1             	mov    %rdx,%rcx
 101013e:	48 83 f9 00          	cmp    $0x0,%rcx
 1010142:	0f 95 c0             	setne  %al
 1010145:	48 0f b6 c0          	movzbq %al,%rax
 1010149:	4c 89 c2             	mov    %r8,%rdx
 101014c:	48 31 ca             	xor    %rcx,%rdx
 101014f:	48 83 fa 00          	cmp    $0x0,%rdx
 1010153:	0f 9c c2             	setl   %dl
 1010156:	48 0f b6 d2          	movzbq %dl,%rdx
 101015a:	48 21 d0             	and    %rdx,%rax
 101015d:	48 f7 d8             	neg    %rax
 1010160:	4c 21 c0             	and    %r8,%rax
 1010163:	48 01 c1             	add    %rax,%rcx
 1010166:	48 89 8d 08 ff ff ff 	mov    %rcx,-0xf8(%rbp)
 101016d:	48 89 8d 08 ff ff ff 	mov    %rcx,-0xf8(%rbp)
 1010174:	48 c7 85 10 ff ff ff 	movq   $0x0,-0xf0(%rbp)
 101017b:	00 00 00 00 
 101017f:	48 83 f9 00          	cmp    $0x0,%rcx
 1010183:	0f 9c c0             	setl   %al
 1010186:	48 0f b6 c0          	movzbq %al,%rax
 101018a:	48 89 85 08 ff ff ff 	mov    %rax,-0xf8(%rbp)
 1010191:	7d 51                	jge    10101e4 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1234>
 1010193:	4c 8b 0e             	mov    (%rsi),%r9
 1010196:	4c 89 8d 08 ff ff ff 	mov    %r9,-0xf8(%rbp)
 101019d:	48 b8 ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rax
 10101a4:	ff ff 7f 
 10101a7:	49 39 c1             	cmp    %rax,%r9
 10101aa:	0f 87 d4 02 00 00    	ja     1010484 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x14d4>
 10101b0:	4c 89 8d 08 ff ff ff 	mov    %r9,-0xf8(%rbp)
 10101b7:	48 89 8d 10 ff ff ff 	mov    %rcx,-0xf0(%rbp)
 10101be:	48 89 c8             	mov    %rcx,%rax
 10101c1:	4c 01 c9             	add    %r9,%rcx
 10101c4:	4c 89 ca             	mov    %r9,%rdx
 10101c7:	48 31 ca             	xor    %rcx,%rdx
 10101ca:	49 89 c0             	mov    %rax,%r8
 10101cd:	49 31 c8             	xor    %rcx,%r8
 10101d0:	4c 21 c2             	and    %r8,%rdx
 10101d3:	48 83 fa 00          	cmp    $0x0,%rdx
 10101d7:	0f 8c 8c 02 00 00    	jl     1010469 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x14b9>
 10101dd:	48 89 8d 08 ff ff ff 	mov    %rcx,-0xf8(%rbp)
 10101e4:	48 89 8d 08 ff ff ff 	mov    %rcx,-0xf8(%rbp)
 10101eb:	48 8b 06             	mov    (%rsi),%rax
 10101ee:	48 39 c1             	cmp    %rax,%rcx
 10101f1:	0f 83 65 02 00 00    	jae    101045c <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x14ac>
 10101f7:	48 8b 46 20          	mov    0x20(%rsi),%rax
 10101fb:	48 8b 04 c8          	mov    (%rax,%rcx,8),%rax
 10101ff:	48 89 85 08 ff ff ff 	mov    %rax,-0xf8(%rbp)
 1010206:	48 89 85 e8 fe ff ff 	mov    %rax,-0x118(%rbp)
 101020d:	8b 85 f0 fd ff ff    	mov    -0x210(%rbp),%eax
 1010213:	83 f8 00             	cmp    $0x0,%eax
 1010216:	74 0e                	je     1010226 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1276>
 1010218:	4c 89 fe             	mov    %r15,%rsi
 101021b:	49 89 ff             	mov    %rdi,%r15
 101021e:	e8 0d 67 00 00       	call   1016930 <myl_qbe_rc_slot_drop>
 1010223:	4c 89 ff             	mov    %r15,%rdi
 1010226:	48 8b 85 e8 fe ff ff 	mov    -0x118(%rbp),%rax
 101022d:	48 89 85 08 ff ff ff 	mov    %rax,-0xf8(%rbp)
 1010234:	48 c7 85 10 ff ff ff 	movq   $0x0,-0xf0(%rbp)
 101023b:	00 00 00 00 
 101023f:	49 89 ff             	mov    %rdi,%r15
 1010242:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
 1010249:	48 8d 95 28 ff ff ff 	lea    -0xd8(%rbp),%rdx
 1010250:	48 8d b5 08 ff ff ff 	lea    -0xf8(%rbp),%rsi
 1010257:	e8 54 ec 00 00       	call   101eeb0 <myl_native_dictionary_read>
 101025c:	4c 89 ff             	mov    %r15,%rdi
 101025f:	83 f8 00             	cmp    $0x0,%eax
 1010262:	75 10                	jne    1010274 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x12c4>
 1010264:	48 8b 85 10 ff ff ff 	mov    -0xf0(%rbp),%rax
 101026b:	48 89 85 08 ff ff ff 	mov    %rax,-0xf8(%rbp)
 1010272:	eb 0e                	jmp    1010282 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x12d2>
 1010274:	48 8b 85 28 ff ff ff 	mov    -0xd8(%rbp),%rax
 101027b:	48 89 85 08 ff ff ff 	mov    %rax,-0xf8(%rbp)
 1010282:	8b 85 18 fe ff ff    	mov    -0x1e8(%rbp),%eax
 1010288:	83 f8 00             	cmp    $0x0,%eax
 101028b:	74 0e                	je     101029b <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x12eb>
 101028d:	4c 89 ee             	mov    %r13,%rsi
 1010290:	49 89 ff             	mov    %rdi,%r15
 1010293:	e8 98 66 00 00       	call   1016930 <myl_qbe_rc_slot_drop>
 1010298:	4c 89 ff             	mov    %r15,%rdi
 101029b:	48 c7 85 10 ff ff ff 	movq   $0x1,-0xf0(%rbp)
 10102a2:	01 00 00 00 
 10102a6:	48 8b 85 08 ff ff ff 	mov    -0xf8(%rbp),%rax
 10102ad:	48 b9 fe ff ff ff ff 	movabs $0x7ffffffffffffffe,%rcx
 10102b4:	ff ff 7f 
 10102b7:	48 39 c8             	cmp    %rcx,%rax
 10102ba:	0f 8f 82 01 00 00    	jg     1010442 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1492>
 10102c0:	49 89 c7             	mov    %rax,%r15
 10102c3:	49 83 c7 01          	add    $0x1,%r15
 10102c7:	4c 89 bd 08 ff ff ff 	mov    %r15,-0xf8(%rbp)
 10102ce:	48 8d 05 3b ec 01 00 	lea    0x1ec3b(%rip),%rax        # 102ef10 <myl_t_db6bd58975531b7368ca22b8af460e2a11856412c594a38caca68120ceaa09fc>
 10102d5:	48 89 85 78 fc ff ff 	mov    %rax,-0x388(%rbp)
 10102dc:	c7 85 90 fc ff ff 02 	movl   $0x2,-0x370(%rbp)
 10102e3:	00 00 00 
 10102e6:	48 8d 85 d8 fe ff ff 	lea    -0x128(%rbp),%rax
 10102ed:	48 89 85 80 fc ff ff 	mov    %rax,-0x380(%rbp)
 10102f4:	4c 89 b5 88 fc ff ff 	mov    %r14,-0x378(%rbp)
 10102fb:	4c 89 f1             	mov    %r14,%rcx
 10102fe:	48 8d 95 d8 fe ff ff 	lea    -0x128(%rbp),%rdx
 1010305:	48 8d 35 04 ec 01 00 	lea    0x1ec04(%rip),%rsi        # 102ef10 <myl_t_db6bd58975531b7368ca22b8af460e2a11856412c594a38caca68120ceaa09fc>
 101030c:	49 89 fe             	mov    %rdi,%r14
 101030f:	e8 9c 69 00 00       	call   1016cb0 <myl_qbe_rc_unique_local>
 1010314:	4c 89 f7             	mov    %r14,%rdi
 1010317:	89 c1                	mov    %eax,%ecx
 1010319:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
 101031d:	4c 8b 75 c8          	mov    -0x38(%rbp),%r14
 1010321:	83 f9 00             	cmp    $0x0,%ecx
 1010324:	0f 84 7c 0a 00 00    	je     1010da6 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1df6>
 101032a:	48 8b 8d d8 fe ff ff 	mov    -0x128(%rbp),%rcx
 1010331:	48 89 8d 08 ff ff ff 	mov    %rcx,-0xf8(%rbp)
 1010338:	8b 8d 18 fe ff ff    	mov    -0x1e8(%rbp),%ecx
 101033e:	83 f9 00             	cmp    $0x0,%ecx
 1010341:	74 16                	je     1010359 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x13a9>
 1010343:	4c 89 ee             	mov    %r13,%rsi
 1010346:	49 89 fe             	mov    %rdi,%r14
 1010349:	e8 e2 65 00 00       	call   1016930 <myl_qbe_rc_slot_drop>
 101034e:	4c 89 f7             	mov    %r14,%rdi
 1010351:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
 1010355:	4c 8b 75 c8          	mov    -0x38(%rbp),%r14
 1010359:	8b 8d 00 fe ff ff    	mov    -0x200(%rbp),%ecx
 101035f:	83 f9 00             	cmp    $0x0,%ecx
 1010362:	74 12                	je     1010376 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x13c6>
 1010364:	48 89 c6             	mov    %rax,%rsi
 1010367:	49 89 fe             	mov    %rdi,%r14
 101036a:	e8 c1 65 00 00       	call   1016930 <myl_qbe_rc_slot_drop>
 101036f:	4c 89 f7             	mov    %r14,%rdi
 1010372:	4c 8b 75 c8          	mov    -0x38(%rbp),%r14
 1010376:	48 8b b5 d8 fe ff ff 	mov    -0x128(%rbp),%rsi
 101037d:	48 89 b5 f0 fe ff ff 	mov    %rsi,-0x110(%rbp)
 1010384:	48 8b 85 e8 fe ff ff 	mov    -0x118(%rbp),%rax
 101038b:	48 89 85 08 ff ff ff 	mov    %rax,-0xf8(%rbp)
 1010392:	4c 89 bd 10 ff ff ff 	mov    %r15,-0xf0(%rbp)
 1010399:	48 8d 8d 10 ff ff ff 	lea    -0xf0(%rbp),%rcx
 10103a0:	48 8d 95 08 ff ff ff 	lea    -0xf8(%rbp),%rdx
 10103a7:	49 89 ff             	mov    %rdi,%r15
 10103aa:	48 89 df             	mov    %rbx,%rdi
 10103ad:	e8 7e f0 00 00       	call   101f430 <myl_native_dictionary_write>
 10103b2:	4c 89 ff             	mov    %r15,%rdi
 10103b5:	89 c1                	mov    %eax,%ecx
 10103b7:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
 10103bb:	4c 8b 7d b8          	mov    -0x48(%rbp),%r15
 10103bf:	83 f9 00             	cmp    $0x0,%ecx
 10103c2:	74 77                	je     101043b <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x148b>
 10103c4:	48 c7 85 08 ff ff ff 	movq   $0x0,-0xf8(%rbp)
 10103cb:	00 00 00 00 
 10103cf:	8b 8d 18 fe ff ff    	mov    -0x1e8(%rbp),%ecx
 10103d5:	83 f9 00             	cmp    $0x0,%ecx
 10103d8:	74 16                	je     10103f0 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1440>
 10103da:	4c 89 ee             	mov    %r13,%rsi
 10103dd:	49 89 ff             	mov    %rdi,%r15
 10103e0:	e8 4b 65 00 00       	call   1016930 <myl_qbe_rc_slot_drop>
 10103e5:	4c 89 ff             	mov    %r15,%rdi
 10103e8:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
 10103ec:	4c 8b 7d b8          	mov    -0x48(%rbp),%r15
 10103f0:	4c 89 a5 08 ff ff ff 	mov    %r12,-0xf8(%rbp)
 10103f7:	48 c7 85 10 ff ff ff 	movq   $0x1,-0xf0(%rbp)
 10103fe:	01 00 00 00 
 1010402:	48 b9 fe ff ff ff ff 	movabs $0x7ffffffffffffffe,%rcx
 1010409:	ff ff 7f 
 101040c:	49 39 cc             	cmp    %rcx,%r12
 101040f:	7f 10                	jg     1010421 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1471>
 1010411:	49 83 c4 01          	add    $0x1,%r12
 1010415:	4c 89 a5 08 ff ff ff 	mov    %r12,-0xf8(%rbp)
 101041c:	e9 ff fb ff ff       	jmp    1010020 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1070>
 1010421:	4c 89 e2             	mov    %r12,%rdx
 1010424:	41 b8 40 00 00 00    	mov    $0x40,%r8d
 101042a:	b9 01 00 00 00       	mov    $0x1,%ecx
 101042f:	be 00 00 00 00       	mov    $0x0,%esi
 1010434:	e8 87 6b 00 00       	call   1016fc0 <myl_qbe_fail_overflow_op>
 1010439:	0f 0b                	ud2
 101043b:	e8 80 6a 00 00       	call   1016ec0 <myl_qbe_fail_allocation>
 1010440:	0f 0b                	ud2
 1010442:	48 89 c2             	mov    %rax,%rdx
 1010445:	41 b8 40 00 00 00    	mov    $0x40,%r8d
 101044b:	b9 01 00 00 00       	mov    $0x1,%ecx
 1010450:	be 00 00 00 00       	mov    $0x0,%esi
 1010455:	e8 66 6b 00 00       	call   1016fc0 <myl_qbe_fail_overflow_op>
 101045a:	0f 0b                	ud2
 101045c:	48 89 c2             	mov    %rax,%rdx
 101045f:	48 89 ce             	mov    %rcx,%rsi
 1010462:	e8 e9 6a 00 00       	call   1016f50 <myl_qbe_fail_normalized_index_bounds>
 1010467:	0f 0b                	ud2
 1010469:	48 89 c1             	mov    %rax,%rcx
 101046c:	4c 89 ce             	mov    %r9,%rsi
 101046f:	41 b8 40 00 00 00    	mov    $0x40,%r8d
 1010475:	48 89 f2             	mov    %rsi,%rdx
 1010478:	be 00 00 00 00       	mov    $0x0,%esi
 101047d:	e8 3e 6b 00 00       	call   1016fc0 <myl_qbe_fail_overflow_op>
 1010482:	0f 0b                	ud2
 1010484:	4c 89 ce             	mov    %r9,%rsi
 1010487:	ba 40 01 00 00       	mov    $0x140,%edx
 101048c:	e8 6f 6c 00 00       	call   1017100 <myl_qbe_fail_cast>
 1010491:	0f 0b                	ud2
 1010493:	4c 89 e2             	mov    %r12,%rdx
 1010496:	41 b8 40 00 00 00    	mov    $0x40,%r8d
 101049c:	b9 ef 1e 00 00       	mov    $0x1eef,%ecx
 10104a1:	be 02 00 00 00       	mov    $0x2,%esi
 10104a6:	e8 15 6b 00 00       	call   1016fc0 <myl_qbe_fail_overflow_op>
 10104ab:	0f 0b                	ud2
 10104ad:	4c 8b 75 a8          	mov    -0x58(%rbp),%r14
 10104b1:	4c 8b 7d b0          	mov    -0x50(%rbp),%r15
 10104b5:	48 c7 85 08 ff ff ff 	movq   $0x0,-0xf8(%rbp)
 10104bc:	00 00 00 00 
 10104c0:	48 8b b5 d0 fe ff ff 	mov    -0x130(%rbp),%rsi
 10104c7:	8b 85 70 fc ff ff    	mov    -0x390(%rbp),%eax
 10104cd:	83 f8 08             	cmp    $0x8,%eax
 10104d0:	0f 94 c0             	sete   %al
 10104d3:	0f b6 c0             	movzbl %al,%eax
 10104d6:	8b 8d e0 fd ff ff    	mov    -0x220(%rbp),%ecx
 10104dc:	85 c1                	test   %eax,%ecx
 10104de:	75 0c                	jne    10104ec <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x153c>
 10104e0:	48 89 b5 08 ff ff ff 	mov    %rsi,-0xf8(%rbp)
 10104e7:	e9 d7 00 00 00       	jmp    10105c3 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1613>
 10104ec:	48 c7 85 58 fe ff ff 	movq   $0x0,-0x1a8(%rbp)
 10104f3:	00 00 00 00 
 10104f7:	48 8d 95 58 fe ff ff 	lea    -0x1a8(%rbp),%rdx
 10104fe:	49 89 fc             	mov    %rdi,%r12
 1010501:	48 89 df             	mov    %rbx,%rdi
 1010504:	e8 b7 38 01 00       	call   1023dc0 <myl_rc_hold_acquire>
 1010509:	4c 89 e7             	mov    %r12,%rdi
 101050c:	89 c6                	mov    %eax,%esi
 101050e:	49 89 fc             	mov    %rdi,%r12
 1010511:	e8 4a 62 00 00       	call   1016760 <myl_qbe_rc_status>
 1010516:	4c 89 e7             	mov    %r12,%rdi
 1010519:	83 f8 00             	cmp    $0x0,%eax
 101051c:	0f 84 84 08 00 00    	je     1010da6 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1df6>
 1010522:	48 8d 05 97 e8 01 00 	lea    0x1e897(%rip),%rax        # 102edc0 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b>
 1010529:	48 89 85 98 fd ff ff 	mov    %rax,-0x268(%rbp)
 1010530:	c7 85 b0 fd ff ff 02 	movl   $0x2,-0x250(%rbp)
 1010537:	00 00 00 
 101053a:	48 8d 85 58 fe ff ff 	lea    -0x1a8(%rbp),%rax
 1010541:	48 89 85 a0 fd ff ff 	mov    %rax,-0x260(%rbp)
 1010548:	4c 89 b5 a8 fd ff ff 	mov    %r14,-0x258(%rbp)
 101054f:	c7 85 b0 fd ff ff 08 	movl   $0x8,-0x250(%rbp)
 1010556:	00 00 00 
 1010559:	c7 85 30 fe ff ff 01 	movl   $0x1,-0x1d0(%rbp)
 1010560:	00 00 00 
 1010563:	48 8b b5 58 fe ff ff 	mov    -0x1a8(%rbp),%rsi
 101056a:	48 89 b5 40 fe ff ff 	mov    %rsi,-0x1c0(%rbp)
 1010571:	48 8d 05 48 e8 01 00 	lea    0x1e848(%rip),%rax        # 102edc0 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b>
 1010578:	48 89 85 38 fd ff ff 	mov    %rax,-0x2c8(%rbp)
 101057f:	c7 85 50 fd ff ff 02 	movl   $0x2,-0x2b0(%rbp)
 1010586:	00 00 00 
 1010589:	48 8d 85 40 fe ff ff 	lea    -0x1c0(%rbp),%rax
 1010590:	48 89 85 40 fd ff ff 	mov    %rax,-0x2c0(%rbp)
 1010597:	4c 89 bd 48 fd ff ff 	mov    %r15,-0x2b8(%rbp)
 101059e:	c7 85 50 fd ff ff 08 	movl   $0x8,-0x2b0(%rbp)
 10105a5:	00 00 00 
 10105a8:	c7 85 18 fe ff ff 01 	movl   $0x1,-0x1e8(%rbp)
 10105af:	00 00 00 
 10105b2:	c7 85 30 fe ff ff 00 	movl   $0x0,-0x1d0(%rbp)
 10105b9:	00 00 00 
 10105bc:	48 89 b5 08 ff ff ff 	mov    %rsi,-0xf8(%rbp)
 10105c3:	48 c7 85 58 fe ff ff 	movq   $0x0,-0x1a8(%rbp)
 10105ca:	00 00 00 00 
 10105ce:	48 8d 95 58 fe ff ff 	lea    -0x1a8(%rbp),%rdx
 10105d5:	49 89 fc             	mov    %rdi,%r12
 10105d8:	48 89 df             	mov    %rbx,%rdi
 10105db:	e8 e0 37 01 00       	call   1023dc0 <myl_rc_hold_acquire>
 10105e0:	4c 89 e7             	mov    %r12,%rdi
 10105e3:	89 c6                	mov    %eax,%esi
 10105e5:	49 89 fc             	mov    %rdi,%r12
 10105e8:	e8 73 61 00 00       	call   1016760 <myl_qbe_rc_status>
 10105ed:	4c 89 e7             	mov    %r12,%rdi
 10105f0:	4c 8b 65 98          	mov    -0x68(%rbp),%r12
 10105f4:	48 8b 75 a0          	mov    -0x60(%rbp),%rsi
 10105f8:	83 f8 00             	cmp    $0x0,%eax
 10105fb:	0f 84 a5 07 00 00    	je     1010da6 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1df6>
 1010601:	48 8d 05 b8 e7 01 00 	lea    0x1e7b8(%rip),%rax        # 102edc0 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b>
 1010608:	48 89 85 98 fd ff ff 	mov    %rax,-0x268(%rbp)
 101060f:	c7 85 b0 fd ff ff 02 	movl   $0x2,-0x250(%rbp)
 1010616:	00 00 00 
 1010619:	48 8d 85 58 fe ff ff 	lea    -0x1a8(%rbp),%rax
 1010620:	48 89 85 a0 fd ff ff 	mov    %rax,-0x260(%rbp)
 1010627:	4c 89 b5 a8 fd ff ff 	mov    %r14,-0x258(%rbp)
 101062e:	c7 85 b0 fd ff ff 08 	movl   $0x8,-0x250(%rbp)
 1010635:	00 00 00 
 1010638:	c7 85 30 fe ff ff 01 	movl   $0x1,-0x1d0(%rbp)
 101063f:	00 00 00 
 1010642:	8b 85 18 fe ff ff    	mov    -0x1e8(%rbp),%eax
 1010648:	83 f8 00             	cmp    $0x0,%eax
 101064b:	74 16                	je     1010663 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x16b3>
 101064d:	4c 89 ee             	mov    %r13,%rsi
 1010650:	49 89 fc             	mov    %rdi,%r12
 1010653:	e8 d8 62 00 00       	call   1016930 <myl_qbe_rc_slot_drop>
 1010658:	4c 89 e7             	mov    %r12,%rdi
 101065b:	4c 8b 65 98          	mov    -0x68(%rbp),%r12
 101065f:	48 8b 75 a0          	mov    -0x60(%rbp),%rsi
 1010663:	48 8b 85 58 fe ff ff 	mov    -0x1a8(%rbp),%rax
 101066a:	48 89 85 40 fe ff ff 	mov    %rax,-0x1c0(%rbp)
 1010671:	48 8d 0d 48 e7 01 00 	lea    0x1e748(%rip),%rcx        # 102edc0 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b>
 1010678:	48 89 8d 38 fd ff ff 	mov    %rcx,-0x2c8(%rbp)
 101067f:	c7 85 50 fd ff ff 02 	movl   $0x2,-0x2b0(%rbp)
 1010686:	00 00 00 
 1010689:	48 8d 8d 40 fe ff ff 	lea    -0x1c0(%rbp),%rcx
 1010690:	48 89 8d 40 fd ff ff 	mov    %rcx,-0x2c0(%rbp)
 1010697:	4c 89 bd 48 fd ff ff 	mov    %r15,-0x2b8(%rbp)
 101069e:	c7 85 50 fd ff ff 08 	movl   $0x8,-0x2b0(%rbp)
 10106a5:	00 00 00 
 10106a8:	c7 85 18 fe ff ff 01 	movl   $0x1,-0x1e8(%rbp)
 10106af:	00 00 00 
 10106b2:	c7 85 30 fe ff ff 00 	movl   $0x0,-0x1d0(%rbp)
 10106b9:	00 00 00 
 10106bc:	48 89 85 08 ff ff ff 	mov    %rax,-0xf8(%rbp)
 10106c3:	48 89 85 58 fe ff ff 	mov    %rax,-0x1a8(%rbp)
 10106ca:	48 8d 05 ef e6 01 00 	lea    0x1e6ef(%rip),%rax        # 102edc0 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b>
 10106d1:	48 89 85 98 fd ff ff 	mov    %rax,-0x268(%rbp)
 10106d8:	c7 85 b0 fd ff ff 02 	movl   $0x2,-0x250(%rbp)
 10106df:	00 00 00 
 10106e2:	48 8d 85 58 fe ff ff 	lea    -0x1a8(%rbp),%rax
 10106e9:	48 89 85 a0 fd ff ff 	mov    %rax,-0x260(%rbp)
 10106f0:	4c 89 b5 a8 fd ff ff 	mov    %r14,-0x258(%rbp)
 10106f7:	c7 85 b0 fd ff ff 08 	movl   $0x8,-0x250(%rbp)
 10106fe:	00 00 00 
 1010701:	c7 85 30 fe ff ff 01 	movl   $0x1,-0x1d0(%rbp)
 1010708:	00 00 00 
 101070b:	c7 85 18 fe ff ff 00 	movl   $0x0,-0x1e8(%rbp)
 1010712:	00 00 00 
 1010715:	8b 85 08 fe ff ff    	mov    -0x1f8(%rbp),%eax
 101071b:	83 f8 00             	cmp    $0x0,%eax
 101071e:	74 0b                	je     101072b <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x177b>
 1010720:	49 89 fe             	mov    %rdi,%r14
 1010723:	e8 08 62 00 00       	call   1016930 <myl_qbe_rc_slot_drop>
 1010728:	4c 89 f7             	mov    %r14,%rdi
 101072b:	48 8b 85 58 fe ff ff 	mov    -0x1a8(%rbp),%rax
 1010732:	48 89 85 f8 fe ff ff 	mov    %rax,-0x108(%rbp)
 1010739:	48 8d 0d 80 e6 01 00 	lea    0x1e680(%rip),%rcx        # 102edc0 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b>
 1010740:	48 89 8d f8 fc ff ff 	mov    %rcx,-0x308(%rbp)
 1010747:	c7 85 10 fd ff ff 02 	movl   $0x2,-0x2f0(%rbp)
 101074e:	00 00 00 
 1010751:	48 8d 8d f8 fe ff ff 	lea    -0x108(%rbp),%rcx
 1010758:	48 89 8d 00 fd ff ff 	mov    %rcx,-0x300(%rbp)
 101075f:	4c 89 a5 08 fd ff ff 	mov    %r12,-0x2f8(%rbp)
 1010766:	c7 85 10 fd ff ff 08 	movl   $0x8,-0x2f0(%rbp)
 101076d:	00 00 00 
 1010770:	c7 85 08 fe ff ff 01 	movl   $0x1,-0x1f8(%rbp)
 1010777:	00 00 00 
 101077a:	c7 85 30 fe ff ff 00 	movl   $0x0,-0x1d0(%rbp)
 1010781:	00 00 00 
 1010784:	48 c7 85 08 ff ff ff 	movq   $0x0,-0xf8(%rbp)
 101078b:	00 00 00 00 
 101078f:	48 8b 30             	mov    (%rax),%rsi
 1010792:	48 89 b5 08 ff ff ff 	mov    %rsi,-0xf8(%rbp)
 1010799:	48 b9 ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rcx
 10107a0:	ff ff 7f 
 10107a3:	48 39 ce             	cmp    %rcx,%rsi
 10107a6:	0f 87 f1 06 00 00    	ja     1010e9d <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1eed>
 10107ac:	48 89 b5 08 ff ff ff 	mov    %rsi,-0xf8(%rbp)
 10107b3:	49 89 f4             	mov    %rsi,%r12
 10107b6:	48 c7 45 90 00 00 00 	movq   $0x0,-0x70(%rbp)
 10107bd:	00 
 10107be:	41 be 00 00 00 00    	mov    $0x0,%r14d
 10107c4:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
 10107cb:	00 00 00 
 10107ce:	66 90                	xchg   %ax,%ax
 10107d0:	4c 89 b5 08 ff ff ff 	mov    %r14,-0xf8(%rbp)
 10107d7:	4c 89 a5 10 ff ff ff 	mov    %r12,-0xf0(%rbp)
 10107de:	4d 39 e6             	cmp    %r12,%r14
 10107e1:	0f 9c c1             	setl   %cl
 10107e4:	48 0f b6 c9          	movzbq %cl,%rcx
 10107e8:	48 89 8d 08 ff ff ff 	mov    %rcx,-0xf8(%rbp)
 10107ef:	0f 8d ed 05 00 00    	jge    1010de2 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1e32>
 10107f5:	4c 89 a5 08 ff ff ff 	mov    %r12,-0xf8(%rbp)
 10107fc:	48 8b 08             	mov    (%rax),%rcx
 10107ff:	49 39 cc             	cmp    %rcx,%r12
 1010802:	0f 85 d3 05 00 00    	jne    1010ddb <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1e2b>
 1010808:	48 c7 85 08 ff ff ff 	movq   $0x0,-0xf8(%rbp)
 101080f:	00 00 00 00 
 1010813:	4c 89 b5 08 ff ff ff 	mov    %r14,-0xf8(%rbp)
 101081a:	48 8b 08             	mov    (%rax),%rcx
 101081d:	49 39 ce             	cmp    %rcx,%r14
 1010820:	0f 83 a8 05 00 00    	jae    1010dce <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1e1e>
 1010826:	48 8b 40 20          	mov    0x20(%rax),%rax
 101082a:	4a 8b 04 f0          	mov    (%rax,%r14,8),%rax
 101082e:	48 89 85 08 ff ff ff 	mov    %rax,-0xf8(%rbp)
 1010835:	48 8d 8d 08 ff ff ff 	lea    -0xf8(%rbp),%rcx
 101083c:	48 8d 95 58 fe ff ff 	lea    -0x1a8(%rbp),%rdx
 1010843:	48 8d 35 06 e5 01 00 	lea    0x1e506(%rip),%rsi        # 102ed50 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a>
 101084a:	49 89 ff             	mov    %rdi,%r15
 101084d:	48 89 df             	mov    %rbx,%rdi
 1010850:	e8 5b b2 01 00       	call   102bab0 <myl_rc_native_loan>
 1010855:	4c 89 ff             	mov    %r15,%rdi
 1010858:	83 f8 00             	cmp    $0x0,%eax
 101085b:	0f 84 2d 05 00 00    	je     1010d8e <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1dde>
 1010861:	48 8d 05 e8 e4 01 00 	lea    0x1e4e8(%rip),%rax        # 102ed50 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a>
 1010868:	48 89 85 98 fd ff ff 	mov    %rax,-0x268(%rbp)
 101086f:	c7 85 b0 fd ff ff 02 	movl   $0x2,-0x250(%rbp)
 1010876:	00 00 00 
 1010879:	c7 85 b0 fd ff ff 10 	movl   $0x10,-0x250(%rbp)
 1010880:	00 00 00 
 1010883:	c7 85 30 fe ff ff 01 	movl   $0x1,-0x1d0(%rbp)
 101088a:	00 00 00 
 101088d:	48 8b 85 58 fe ff ff 	mov    -0x1a8(%rbp),%rax
 1010894:	48 89 85 40 fe ff ff 	mov    %rax,-0x1c0(%rbp)
 101089b:	48 8d 05 ae e4 01 00 	lea    0x1e4ae(%rip),%rax        # 102ed50 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a>
 10108a2:	48 89 85 38 fd ff ff 	mov    %rax,-0x2c8(%rbp)
 10108a9:	c7 85 50 fd ff ff 02 	movl   $0x2,-0x2b0(%rbp)
 10108b0:	00 00 00 
 10108b3:	c7 85 50 fd ff ff 10 	movl   $0x10,-0x2b0(%rbp)
 10108ba:	00 00 00 
 10108bd:	c7 85 30 fe ff ff 00 	movl   $0x0,-0x1d0(%rbp)
 10108c4:	00 00 00 
 10108c7:	c7 85 18 fe ff ff 01 	movl   $0x1,-0x1e8(%rbp)
 10108ce:	00 00 00 
 10108d1:	48 8b 85 40 fe ff ff 	mov    -0x1c0(%rbp),%rax
 10108d8:	48 89 85 08 ff ff ff 	mov    %rax,-0xf8(%rbp)
 10108df:	48 8d 8d 08 ff ff ff 	lea    -0xf8(%rbp),%rcx
 10108e6:	48 8d 95 58 fe ff ff 	lea    -0x1a8(%rbp),%rdx
 10108ed:	48 8d 35 5c e4 01 00 	lea    0x1e45c(%rip),%rsi        # 102ed50 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a>
 10108f4:	49 89 ff             	mov    %rdi,%r15
 10108f7:	48 89 df             	mov    %rbx,%rdi
 10108fa:	e8 b1 b1 01 00       	call   102bab0 <myl_rc_native_loan>
 10108ff:	4c 89 ff             	mov    %r15,%rdi
 1010902:	48 8b 4d 90          	mov    -0x70(%rbp),%rcx
 1010906:	4c 8b 95 58 ff ff ff 	mov    -0xa8(%rbp),%r10
 101090d:	48 8b b5 40 ff ff ff 	mov    -0xc0(%rbp),%rsi
 1010914:	83 f8 00             	cmp    $0x0,%eax
 1010917:	0f 84 57 04 00 00    	je     1010d74 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1dc4>
 101091d:	48 8d 05 2c e4 01 00 	lea    0x1e42c(%rip),%rax        # 102ed50 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a>
 1010924:	48 89 85 98 fd ff ff 	mov    %rax,-0x268(%rbp)
 101092b:	c7 85 b0 fd ff ff 02 	movl   $0x2,-0x250(%rbp)
 1010932:	00 00 00 
 1010935:	c7 85 b0 fd ff ff 10 	movl   $0x10,-0x250(%rbp)
 101093c:	00 00 00 
 101093f:	c7 85 30 fe ff ff 01 	movl   $0x1,-0x1d0(%rbp)
 1010946:	00 00 00 
 1010949:	8b 85 18 fe ff ff    	mov    -0x1e8(%rbp),%eax
 101094f:	83 f8 00             	cmp    $0x0,%eax
 1010952:	74 20                	je     1010974 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x19c4>
 1010954:	4c 89 ee             	mov    %r13,%rsi
 1010957:	49 89 ff             	mov    %rdi,%r15
 101095a:	e8 d1 5f 00 00       	call   1016930 <myl_qbe_rc_slot_drop>
 101095f:	4c 89 ff             	mov    %r15,%rdi
 1010962:	48 8b 4d 90          	mov    -0x70(%rbp),%rcx
 1010966:	4c 8b 95 58 ff ff ff 	mov    -0xa8(%rbp),%r10
 101096d:	48 8b b5 40 ff ff ff 	mov    -0xc0(%rbp),%rsi
 1010974:	8b 85 10 fe ff ff    	mov    -0x1f0(%rbp),%eax
 101097a:	83 f8 00             	cmp    $0x0,%eax
 101097d:	74 16                	je     1010995 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x19e5>
 101097f:	49 89 ff             	mov    %rdi,%r15
 1010982:	e8 a9 5f 00 00       	call   1016930 <myl_qbe_rc_slot_drop>
 1010987:	4c 89 ff             	mov    %r15,%rdi
 101098a:	48 8b 4d 90          	mov    -0x70(%rbp),%rcx
 101098e:	4c 8b 95 58 ff ff ff 	mov    -0xa8(%rbp),%r10
 1010995:	48 8b 85 58 fe ff ff 	mov    -0x1a8(%rbp),%rax
 101099c:	48 89 85 00 ff ff ff 	mov    %rax,-0x100(%rbp)
 10109a3:	c7 85 30 fe ff ff 00 	movl   $0x0,-0x1d0(%rbp)
 10109aa:	00 00 00 
 10109ad:	48 8d 05 9c e3 01 00 	lea    0x1e39c(%rip),%rax        # 102ed50 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a>
 10109b4:	48 89 85 18 fd ff ff 	mov    %rax,-0x2e8(%rbp)
 10109bb:	c7 85 30 fd ff ff 02 	movl   $0x2,-0x2d0(%rbp)
 10109c2:	00 00 00 
 10109c5:	48 8d 85 00 ff ff ff 	lea    -0x100(%rbp),%rax
 10109cc:	48 89 85 20 fd ff ff 	mov    %rax,-0x2e0(%rbp)
 10109d3:	4c 89 95 28 fd ff ff 	mov    %r10,-0x2d8(%rbp)
 10109da:	8b 85 b0 fd ff ff    	mov    -0x250(%rbp),%eax
 10109e0:	89 85 30 fd ff ff    	mov    %eax,-0x2d0(%rbp)
 10109e6:	c7 85 10 fe ff ff 01 	movl   $0x1,-0x1f0(%rbp)
 10109ed:	00 00 00 
 10109f0:	48 89 8d 08 ff ff ff 	mov    %rcx,-0xf8(%rbp)
 10109f7:	49 89 ff             	mov    %rdi,%r15
 10109fa:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
 1010a01:	48 89 bd 10 ff ff ff 	mov    %rdi,-0xf0(%rbp)
 1010a08:	48 8b 85 00 ff ff ff 	mov    -0x100(%rbp),%rax
 1010a0f:	48 89 85 18 ff ff ff 	mov    %rax,-0xe8(%rbp)
 1010a16:	48 8d 95 20 ff ff ff 	lea    -0xe0(%rbp),%rdx
 1010a1d:	48 8d b5 18 ff ff ff 	lea    -0xe8(%rbp),%rsi
 1010a24:	e8 87 e4 00 00       	call   101eeb0 <myl_native_dictionary_read>
 1010a29:	4c 89 ff             	mov    %r15,%rdi
 1010a2c:	4c 8b 8d 50 ff ff ff 	mov    -0xb0(%rbp),%r9
 1010a33:	4c 8b 85 48 ff ff ff 	mov    -0xb8(%rbp),%r8
 1010a3a:	48 8b b5 40 ff ff ff 	mov    -0xc0(%rbp),%rsi
 1010a41:	83 f8 00             	cmp    $0x0,%eax
 1010a44:	0f 84 20 03 00 00    	je     1010d6a <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1dba>
 1010a4a:	48 8b 85 20 ff ff ff 	mov    -0xe0(%rbp),%rax
 1010a51:	48 89 85 10 ff ff ff 	mov    %rax,-0xf0(%rbp)
 1010a58:	8b 85 20 fe ff ff    	mov    -0x1e0(%rbp),%eax
 1010a5e:	83 f8 00             	cmp    $0x0,%eax
 1010a61:	74 1c                	je     1010a7f <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1acf>
 1010a63:	4c 89 c6             	mov    %r8,%rsi
 1010a66:	49 89 ff             	mov    %rdi,%r15
 1010a69:	e8 c2 5e 00 00       	call   1016930 <myl_qbe_rc_slot_drop>
 1010a6e:	4c 89 ff             	mov    %r15,%rdi
 1010a71:	4c 8b 8d 50 ff ff ff 	mov    -0xb0(%rbp),%r9
 1010a78:	48 8b b5 40 ff ff ff 	mov    -0xc0(%rbp),%rsi
 1010a7f:	8b 85 28 fe ff ff    	mov    -0x1d8(%rbp),%eax
 1010a85:	83 f8 00             	cmp    $0x0,%eax
 1010a88:	74 1c                	je     1010aa6 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1af6>
 1010a8a:	4c 89 ce             	mov    %r9,%rsi
 1010a8d:	49 89 ff             	mov    %rdi,%r15
 1010a90:	e8 9b 5e 00 00       	call   1016930 <myl_qbe_rc_slot_drop>
 1010a95:	4c 89 ff             	mov    %r15,%rdi
 1010a98:	4c 8b 8d 50 ff ff ff 	mov    -0xb0(%rbp),%r9
 1010a9f:	48 8b b5 40 ff ff ff 	mov    -0xc0(%rbp),%rsi
 1010aa6:	48 8b 85 00 ff ff ff 	mov    -0x100(%rbp),%rax
 1010aad:	48 89 85 18 ff ff ff 	mov    %rax,-0xe8(%rbp)
 1010ab4:	48 8b 00             	mov    (%rax),%rax
 1010ab7:	48 89 85 18 ff ff ff 	mov    %rax,-0xe8(%rbp)
 1010abe:	8b 85 28 fe ff ff    	mov    -0x1d8(%rbp),%eax
 1010ac4:	83 f8 00             	cmp    $0x0,%eax
 1010ac7:	74 15                	je     1010ade <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1b2e>
 1010ac9:	4c 89 ce             	mov    %r9,%rsi
 1010acc:	49 89 ff             	mov    %rdi,%r15
 1010acf:	e8 5c 5e 00 00       	call   1016930 <myl_qbe_rc_slot_drop>
 1010ad4:	4c 89 ff             	mov    %r15,%rdi
 1010ad7:	48 8b b5 40 ff ff ff 	mov    -0xc0(%rbp),%rsi
 1010ade:	48 8b 85 18 ff ff ff 	mov    -0xe8(%rbp),%rax
 1010ae5:	48 8b 95 10 ff ff ff 	mov    -0xf0(%rbp),%rdx
 1010aec:	48 89 c1             	mov    %rax,%rcx
 1010aef:	48 0f af ca          	imul   %rdx,%rcx
 1010af3:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
 1010af9:	49 89 d1             	mov    %rdx,%r9
 1010afc:	4d 21 c1             	and    %r8,%r9
 1010aff:	49 89 d2             	mov    %rdx,%r10
 1010b02:	49 c1 ea 20          	shr    $0x20,%r10
 1010b06:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
 1010b0c:	49 89 c3             	mov    %rax,%r11
 1010b0f:	4d 21 c3             	and    %r8,%r11
 1010b12:	49 89 c7             	mov    %rax,%r15
 1010b15:	49 c1 ef 20          	shr    $0x20,%r15
 1010b19:	4d 89 c8             	mov    %r9,%r8
 1010b1c:	4d 0f af c3          	imul   %r11,%r8
 1010b20:	49 c1 e8 20          	shr    $0x20,%r8
 1010b24:	4d 0f af da          	imul   %r10,%r11
 1010b28:	4d 01 d8             	add    %r11,%r8
 1010b2b:	41 bb ff ff ff ff    	mov    $0xffffffff,%r11d
 1010b31:	4c 89 5d 88          	mov    %r11,-0x78(%rbp)
 1010b35:	4d 89 c3             	mov    %r8,%r11
 1010b38:	4c 23 5d 88          	and    -0x78(%rbp),%r11
 1010b3c:	4c 89 9d 78 ff ff ff 	mov    %r11,-0x88(%rbp)
 1010b43:	4d 89 c3             	mov    %r8,%r11
 1010b46:	49 c1 eb 20          	shr    $0x20,%r11
 1010b4a:	4c 89 9d 68 ff ff ff 	mov    %r11,-0x98(%rbp)
 1010b51:	4c 8b 85 48 ff ff ff 	mov    -0xb8(%rbp),%r8
 1010b58:	4d 0f af cf          	imul   %r15,%r9
 1010b5c:	4c 89 4d 80          	mov    %r9,-0x80(%rbp)
 1010b60:	4c 8b 8d 50 ff ff ff 	mov    -0xb0(%rbp),%r9
 1010b67:	4c 8b 9d 78 ff ff ff 	mov    -0x88(%rbp),%r11
 1010b6e:	4c 03 5d 80          	add    -0x80(%rbp),%r11
 1010b72:	4c 89 9d 70 ff ff ff 	mov    %r11,-0x90(%rbp)
 1010b79:	4c 8b 9d 70 ff ff ff 	mov    -0x90(%rbp),%r11
 1010b80:	49 c1 eb 20          	shr    $0x20,%r11
 1010b84:	4c 89 9d 60 ff ff ff 	mov    %r11,-0xa0(%rbp)
 1010b8b:	4c 8b 9d 68 ff ff ff 	mov    -0x98(%rbp),%r11
 1010b92:	4d 0f af fa          	imul   %r10,%r15
 1010b96:	4c 8b 95 60 ff ff ff 	mov    -0xa0(%rbp),%r10
 1010b9d:	4d 01 fb             	add    %r15,%r11
 1010ba0:	4d 01 da             	add    %r11,%r10
 1010ba3:	48 83 fa 00          	cmp    $0x0,%rdx
 1010ba7:	41 0f 9c c3          	setl   %r11b
 1010bab:	4d 0f b6 db          	movzbq %r11b,%r11
 1010baf:	48 83 f8 00          	cmp    $0x0,%rax
 1010bb3:	41 0f 9c c7          	setl   %r15b
 1010bb7:	4d 0f b6 ff          	movzbq %r15b,%r15
 1010bbb:	49 f7 db             	neg    %r11
 1010bbe:	49 f7 df             	neg    %r15
 1010bc1:	49 21 c3             	and    %rax,%r11
 1010bc4:	49 21 d7             	and    %rdx,%r15
 1010bc7:	49 f7 db             	neg    %r11
 1010bca:	4d 01 d3             	add    %r10,%r11
 1010bcd:	4c 8b 95 58 ff ff ff 	mov    -0xa8(%rbp),%r10
 1010bd4:	4d 29 fb             	sub    %r15,%r11
 1010bd7:	49 89 cf             	mov    %rcx,%r15
 1010bda:	49 c1 ff 3f          	sar    $0x3f,%r15
 1010bde:	4d 39 df             	cmp    %r11,%r15
 1010be1:	0f 85 6e 01 00 00    	jne    1010d55 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1da5>
 1010be7:	48 89 8d 10 ff ff ff 	mov    %rcx,-0xf0(%rbp)
 1010bee:	48 8b 95 08 ff ff ff 	mov    -0xf8(%rbp),%rdx
 1010bf5:	48 89 c8             	mov    %rcx,%rax
 1010bf8:	48 01 d0             	add    %rdx,%rax
 1010bfb:	49 89 d3             	mov    %rdx,%r11
 1010bfe:	49 31 c3             	xor    %rax,%r11
 1010c01:	49 89 cf             	mov    %rcx,%r15
 1010c04:	49 31 c7             	xor    %rax,%r15
 1010c07:	4d 21 fb             	and    %r15,%r11
 1010c0a:	49 83 fb 00          	cmp    $0x0,%r11
 1010c0e:	0f 8c 2f 01 00 00    	jl     1010d43 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1d93>
 1010c14:	48 89 85 08 ff ff ff 	mov    %rax,-0xf8(%rbp)
 1010c1b:	48 c7 85 10 ff ff ff 	movq   $0xf4243,-0xf0(%rbp)
 1010c22:	43 42 0f 00 
 1010c26:	48 b9 00 00 00 00 00 	movabs $0x8000000000000000,%rcx
 1010c2d:	00 00 80 
 1010c30:	48 39 c8             	cmp    %rcx,%rax
 1010c33:	0f 94 c1             	sete   %cl
 1010c36:	48 0f b6 c9          	movzbq %cl,%rcx
 1010c3a:	48 83 e1 00          	and    $0x0,%rcx
 1010c3e:	48 f7 d9             	neg    %rcx
 1010c41:	48 81 e1 42 42 0f 00 	and    $0xf4242,%rcx
 1010c48:	49 89 cb             	mov    %rcx,%r11
 1010c4b:	49 81 f3 43 42 0f 00 	xor    $0xf4243,%r11
 1010c52:	48 99                	cqto
 1010c54:	49 f7 fb             	idiv   %r11
 1010c57:	48 89 d1             	mov    %rdx,%rcx
 1010c5a:	48 83 f9 00          	cmp    $0x0,%rcx
 1010c5e:	0f 95 c0             	setne  %al
 1010c61:	48 0f b6 c0          	movzbq %al,%rax
 1010c65:	4c 89 da             	mov    %r11,%rdx
 1010c68:	48 31 ca             	xor    %rcx,%rdx
 1010c6b:	48 83 fa 00          	cmp    $0x0,%rdx
 1010c6f:	0f 9c c2             	setl   %dl
 1010c72:	48 0f b6 d2          	movzbq %dl,%rdx
 1010c76:	48 21 d0             	and    %rdx,%rax
 1010c79:	48 f7 d8             	neg    %rax
 1010c7c:	4c 21 d8             	and    %r11,%rax
 1010c7f:	48 01 c1             	add    %rax,%rcx
 1010c82:	48 89 8d 38 ff ff ff 	mov    %rcx,-0xc8(%rbp)
 1010c89:	48 89 8d 08 ff ff ff 	mov    %rcx,-0xf8(%rbp)
 1010c90:	8b 85 10 fe ff ff    	mov    -0x1f0(%rbp),%eax
 1010c96:	83 f8 00             	cmp    $0x0,%eax
 1010c99:	74 2e                	je     1010cc9 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1d19>
 1010c9b:	49 89 ff             	mov    %rdi,%r15
 1010c9e:	e8 8d 5c 00 00       	call   1016930 <myl_qbe_rc_slot_drop>
 1010ca3:	4c 89 ff             	mov    %r15,%rdi
 1010ca6:	48 8b 8d 38 ff ff ff 	mov    -0xc8(%rbp),%rcx
 1010cad:	4c 8b 8d 50 ff ff ff 	mov    -0xb0(%rbp),%r9
 1010cb4:	4c 8b 85 48 ff ff ff 	mov    -0xb8(%rbp),%r8
 1010cbb:	4c 8b 95 58 ff ff ff 	mov    -0xa8(%rbp),%r10
 1010cc2:	48 8b b5 40 ff ff ff 	mov    -0xc0(%rbp),%rsi
 1010cc9:	4c 89 a5 08 ff ff ff 	mov    %r12,-0xf8(%rbp)
 1010cd0:	48 8b 85 f8 fe ff ff 	mov    -0x108(%rbp),%rax
 1010cd7:	48 8b 10             	mov    (%rax),%rdx
 1010cda:	49 39 d4             	cmp    %rdx,%r12
 1010cdd:	75 5d                	jne    1010d3c <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1d8c>
 1010cdf:	48 c7 85 08 ff ff ff 	movq   $0x0,-0xf8(%rbp)
 1010ce6:	00 00 00 00 
 1010cea:	4c 89 b5 08 ff ff ff 	mov    %r14,-0xf8(%rbp)
 1010cf1:	48 c7 85 10 ff ff ff 	movq   $0x1,-0xf0(%rbp)
 1010cf8:	01 00 00 00 
 1010cfc:	48 ba fe ff ff ff ff 	movabs $0x7ffffffffffffffe,%rdx
 1010d03:	ff ff 7f 
 1010d06:	49 39 d6             	cmp    %rdx,%r14
 1010d09:	7f 14                	jg     1010d1f <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1d6f>
 1010d0b:	49 83 c6 01          	add    $0x1,%r14
 1010d0f:	4c 89 b5 08 ff ff ff 	mov    %r14,-0xf8(%rbp)
 1010d16:	48 89 4d 90          	mov    %rcx,-0x70(%rbp)
 1010d1a:	e9 b1 fa ff ff       	jmp    10107d0 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1820>
 1010d1f:	4c 89 f6             	mov    %r14,%rsi
 1010d22:	41 b8 40 00 00 00    	mov    $0x40,%r8d
 1010d28:	b9 01 00 00 00       	mov    $0x1,%ecx
 1010d2d:	48 89 f2             	mov    %rsi,%rdx
 1010d30:	be 00 00 00 00       	mov    $0x0,%esi
 1010d35:	e8 86 62 00 00       	call   1016fc0 <myl_qbe_fail_overflow_op>
 1010d3a:	0f 0b                	ud2
 1010d3c:	e8 ff 61 00 00       	call   1016f40 <myl_qbe_fail_iteration>
 1010d41:	0f 0b                	ud2
 1010d43:	41 b8 40 00 00 00    	mov    $0x40,%r8d
 1010d49:	be 00 00 00 00       	mov    $0x0,%esi
 1010d4e:	e8 6d 62 00 00       	call   1016fc0 <myl_qbe_fail_overflow_op>
 1010d53:	0f 0b                	ud2
 1010d55:	48 89 c1             	mov    %rax,%rcx
 1010d58:	41 b8 40 00 00 00    	mov    $0x40,%r8d
 1010d5e:	be 02 00 00 00       	mov    $0x2,%esi
 1010d63:	e8 58 62 00 00       	call   1016fc0 <myl_qbe_fail_overflow_op>
 1010d68:	0f 0b                	ud2
 1010d6a:	48 89 fb             	mov    %rdi,%rbx
 1010d6d:	e8 be 61 00 00       	call   1016f30 <myl_qbe_fail_missing_key>
 1010d72:	0f 0b                	ud2
 1010d74:	48 87 fb             	xchg   %rdi,%rbx
 1010d77:	e8 f4 2a 01 00       	call   1023870 <myl_rc_take_failure>
 1010d7c:	48 89 df             	mov    %rbx,%rdi
 1010d7f:	89 c6                	mov    %eax,%esi
 1010d81:	48 89 fb             	mov    %rdi,%rbx
 1010d84:	e8 d7 59 00 00       	call   1016760 <myl_qbe_rc_status>
 1010d89:	48 89 df             	mov    %rbx,%rdi
 1010d8c:	eb 18                	jmp    1010da6 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1df6>
 1010d8e:	48 87 fb             	xchg   %rdi,%rbx
 1010d91:	e8 da 2a 01 00       	call   1023870 <myl_rc_take_failure>
 1010d96:	48 89 df             	mov    %rbx,%rdi
 1010d99:	89 c6                	mov    %eax,%esi
 1010d9b:	48 89 fb             	mov    %rdi,%rbx
 1010d9e:	e8 bd 59 00 00       	call   1016760 <myl_qbe_rc_status>
 1010da3:	48 89 df             	mov    %rbx,%rdi
 1010da6:	48 8d b5 18 fc ff ff 	lea    -0x3e8(%rbp),%rsi
 1010dad:	48 89 fb             	mov    %rdi,%rbx
 1010db0:	e8 ab 5c 00 00       	call   1016a60 <myl_qbe_rc_frame_cleanup>
 1010db5:	48 89 df             	mov    %rbx,%rdi
 1010db8:	48 8d b5 18 fc ff ff 	lea    -0x3e8(%rbp),%rsi
 1010dbf:	e8 0c 5b 00 00       	call   10168d0 <myl_qbe_rc_frame_leave>
 1010dc4:	b8 00 00 00 00       	mov    $0x0,%eax
 1010dc9:	e9 c4 00 00 00       	jmp    1010e92 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1ee2>
 1010dce:	48 89 ca             	mov    %rcx,%rdx
 1010dd1:	4c 89 f6             	mov    %r14,%rsi
 1010dd4:	e8 77 61 00 00       	call   1016f50 <myl_qbe_fail_normalized_index_bounds>
 1010dd9:	0f 0b                	ud2
 1010ddb:	e8 60 61 00 00       	call   1016f40 <myl_qbe_fail_iteration>
 1010de0:	0f 0b                	ud2
 1010de2:	48 8b 4d 90          	mov    -0x70(%rbp),%rcx
 1010de6:	4c 8b a5 30 ff ff ff 	mov    -0xd0(%rbp),%r12
 1010ded:	4c 89 a5 08 ff ff ff 	mov    %r12,-0xf8(%rbp)
 1010df4:	48 89 8d 10 ff ff ff 	mov    %rcx,-0xf0(%rbp)
 1010dfb:	4c 89 e6             	mov    %r12,%rsi
 1010dfe:	48 89 fb             	mov    %rdi,%rbx
 1010e01:	e8 fa 7f 00 00       	call   1018e00 <myl_qbe_stream_begin>
 1010e06:	4c 89 e2             	mov    %r12,%rdx
 1010e09:	48 89 df             	mov    %rbx,%rdi
 1010e0c:	48 89 c6             	mov    %rax,%rsi
 1010e0f:	49 89 d5             	mov    %rdx,%r13
 1010e12:	ba 00 00 00 00       	mov    $0x0,%edx
 1010e17:	49 89 f4             	mov    %rsi,%r12
 1010e1a:	48 8d b5 10 ff ff ff 	lea    -0xf0(%rbp),%rsi
 1010e21:	48 89 fb             	mov    %rdi,%rbx
 1010e24:	4c 89 e7             	mov    %r12,%rdi
 1010e27:	e8 84 00 00 00       	call   1010eb0 <myl_r_1a91deb3742283487d66c3b500f6effd7ef1170e6d4b4368fe9ec3c3f0354fda>
 1010e2c:	4c 89 e6             	mov    %r12,%rsi
 1010e2f:	48 89 df             	mov    %rbx,%rdi
 1010e32:	49 89 f4             	mov    %rsi,%r12
 1010e35:	be 0a 00 00 00       	mov    $0xa,%esi
 1010e3a:	48 89 fb             	mov    %rdi,%rbx
 1010e3d:	4c 89 e7             	mov    %r12,%rdi
 1010e40:	e8 0b 7f 00 00       	call   1018d50 <myl_qbe_print_byte>
 1010e45:	4c 89 ea             	mov    %r13,%rdx
 1010e48:	4c 89 e6             	mov    %r12,%rsi
 1010e4b:	48 89 df             	mov    %rbx,%rdi
 1010e4e:	48 89 fb             	mov    %rdi,%rbx
 1010e51:	e8 ea 7f 00 00       	call   1018e40 <myl_qbe_stream_finish>
 1010e56:	48 89 df             	mov    %rbx,%rdi
 1010e59:	48 c7 85 08 ff ff ff 	movq   $0x0,-0xf8(%rbp)
 1010e60:	00 00 00 00 
 1010e64:	48 c7 85 08 ff ff ff 	movq   $0x0,-0xf8(%rbp)
 1010e6b:	00 00 00 00 
 1010e6f:	48 8d b5 18 fc ff ff 	lea    -0x3e8(%rbp),%rsi
 1010e76:	48 89 fb             	mov    %rdi,%rbx
 1010e79:	e8 e2 5b 00 00       	call   1016a60 <myl_qbe_rc_frame_cleanup>
 1010e7e:	48 89 df             	mov    %rbx,%rdi
 1010e81:	48 8d b5 18 fc ff ff 	lea    -0x3e8(%rbp),%rsi
 1010e88:	e8 43 5a 00 00       	call   10168d0 <myl_qbe_rc_frame_leave>
 1010e8d:	b8 00 00 00 00       	mov    $0x0,%eax
 1010e92:	41 5f                	pop    %r15
 1010e94:	41 5e                	pop    %r14
 1010e96:	41 5d                	pop    %r13
 1010e98:	41 5c                	pop    %r12
 1010e9a:	5b                   	pop    %rbx
 1010e9b:	c9                   	leave
 1010e9c:	c3                   	ret
 1010e9d:	ba 40 01 00 00       	mov    $0x140,%edx
 1010ea2:	e8 59 62 00 00       	call   1017100 <myl_qbe_fail_cast>
 1010ea7:	0f 0b                	ud2

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
