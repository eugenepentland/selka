
/home/epentland/ai/canopy/mylang-worktrees/d9-rc-compiler-astra/.tmp-rc/dict-loop/full/after-qbe-rc:     file format elf64-x86-64


Disassembly of section .text:

000000000100efb0 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605>:
 100efb0:	f3 0f 1e fa          	endbr64
 100efb4:	55                   	push   %rbp
 100efb5:	48 89 e5             	mov    %rsp,%rbp
 100efb8:	48 81 ec f8 03 00 00 	sub    $0x3f8,%rsp
 100efbf:	53                   	push   %rbx
 100efc0:	41 54                	push   %r12
 100efc2:	41 55                	push   %r13
 100efc4:	41 56                	push   %r14
 100efc6:	41 57                	push   %r15
 100efc8:	48 89 b5 30 ff ff ff 	mov    %rsi,-0xd0(%rbp)
 100efcf:	ba 20 00 00 00       	mov    $0x20,%edx
 100efd4:	be 00 00 00 00       	mov    $0x0,%esi
 100efd9:	48 89 fb             	mov    %rdi,%rbx
 100efdc:	48 8d bd 68 fe ff ff 	lea    -0x198(%rbp),%rdi
 100efe3:	e8 68 d3 01 00       	call   102c350 <compiler_rt.fastMemset>
 100efe8:	48 89 df             	mov    %rbx,%rdi
 100efeb:	ba 20 00 00 00       	mov    $0x20,%edx
 100eff0:	be 00 00 00 00       	mov    $0x0,%esi
 100eff5:	48 89 fb             	mov    %rdi,%rbx
 100eff8:	48 8d bd 88 fe ff ff 	lea    -0x178(%rbp),%rdi
 100efff:	e8 4c d3 01 00       	call   102c350 <compiler_rt.fastMemset>
 100f004:	48 89 df             	mov    %rbx,%rdi
 100f007:	ba 20 00 00 00       	mov    $0x20,%edx
 100f00c:	be 00 00 00 00       	mov    $0x0,%esi
 100f011:	48 89 fb             	mov    %rdi,%rbx
 100f014:	48 8d bd a8 fe ff ff 	lea    -0x158(%rbp),%rdi
 100f01b:	e8 30 d3 01 00       	call   102c350 <compiler_rt.fastMemset>
 100f020:	48 89 df             	mov    %rbx,%rdi
 100f023:	48 c7 85 c8 fe ff ff 	movq   $0x0,-0x138(%rbp)
 100f02a:	00 00 00 00 
 100f02e:	48 c7 85 d0 fe ff ff 	movq   $0x0,-0x130(%rbp)
 100f035:	00 00 00 00 
 100f039:	48 c7 85 d8 fe ff ff 	movq   $0x0,-0x128(%rbp)
 100f040:	00 00 00 00 
 100f044:	48 c7 85 e0 fe ff ff 	movq   $0x0,-0x120(%rbp)
 100f04b:	00 00 00 00 
 100f04f:	48 c7 85 e8 fe ff ff 	movq   $0x0,-0x118(%rbp)
 100f056:	00 00 00 00 
 100f05a:	48 c7 85 f0 fe ff ff 	movq   $0x0,-0x110(%rbp)
 100f061:	00 00 00 00 
 100f065:	48 c7 85 f8 fe ff ff 	movq   $0x0,-0x108(%rbp)
 100f06c:	00 00 00 00 
 100f070:	48 c7 85 00 ff ff ff 	movq   $0x0,-0x100(%rbp)
 100f077:	00 00 00 00 
 100f07b:	48 89 fb             	mov    %rdi,%rbx
 100f07e:	e8 0d 81 00 00       	call   1017190 <myl_qbe_heap>
 100f083:	48 89 df             	mov    %rbx,%rdi
 100f086:	48 89 c3             	mov    %rax,%rbx
 100f089:	49 89 fc             	mov    %rdi,%r12
 100f08c:	e8 bf 9c 00 00       	call   1018d50 <myl_qbe_region_mark>
 100f091:	4c 89 e7             	mov    %r12,%rdi
 100f094:	48 89 45 e0          	mov    %rax,-0x20(%rbp)
 100f098:	ba 68 00 00 00       	mov    $0x68,%edx
 100f09d:	be 00 00 00 00       	mov    $0x0,%esi
 100f0a2:	49 89 fc             	mov    %rdi,%r12
 100f0a5:	48 8d bd d8 fd ff ff 	lea    -0x228(%rbp),%rdi
 100f0ac:	e8 9f d2 01 00       	call   102c350 <compiler_rt.fastMemset>
 100f0b1:	4c 89 e7             	mov    %r12,%rdi
 100f0b4:	48 8d 05 15 fd 01 00 	lea    0x1fd15(%rip),%rax        # 102edd0 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b>
 100f0bb:	48 89 85 38 fc ff ff 	mov    %rax,-0x3c8(%rbp)
 100f0c2:	c7 85 50 fc ff ff 02 	movl   $0x2,-0x3b0(%rbp)
 100f0c9:	00 00 00 
 100f0cc:	48 8d 85 c8 fe ff ff 	lea    -0x138(%rbp),%rax
 100f0d3:	48 89 85 40 fc ff ff 	mov    %rax,-0x3c0(%rbp)
 100f0da:	48 8d 85 d8 fd ff ff 	lea    -0x228(%rbp),%rax
 100f0e1:	48 89 85 48 fc ff ff 	mov    %rax,-0x3b8(%rbp)
 100f0e8:	48 8d 85 38 fc ff ff 	lea    -0x3c8(%rbp),%rax
 100f0ef:	48 89 c6             	mov    %rax,%rsi
 100f0f2:	48 83 c6 20          	add    $0x20,%rsi
 100f0f6:	48 89 75 f0          	mov    %rsi,-0x10(%rbp)
 100f0fa:	48 8d 05 cf fc 01 00 	lea    0x1fccf(%rip),%rax        # 102edd0 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b>
 100f101:	48 89 85 58 fc ff ff 	mov    %rax,-0x3a8(%rbp)
 100f108:	c7 85 70 fc ff ff 02 	movl   $0x2,-0x390(%rbp)
 100f10f:	00 00 00 
 100f112:	48 8d 85 d0 fe ff ff 	lea    -0x130(%rbp),%rax
 100f119:	48 89 85 60 fc ff ff 	mov    %rax,-0x3a0(%rbp)
 100f120:	48 8d 85 d8 fd ff ff 	lea    -0x228(%rbp),%rax
 100f127:	49 89 c6             	mov    %rax,%r14
 100f12a:	49 83 c6 08          	add    $0x8,%r14
 100f12e:	4c 89 b5 68 fc ff ff 	mov    %r14,-0x398(%rbp)
 100f135:	48 8d 85 38 fc ff ff 	lea    -0x3c8(%rbp),%rax
 100f13c:	48 89 c6             	mov    %rax,%rsi
 100f13f:	48 83 c6 40          	add    $0x40,%rsi
 100f143:	48 89 75 c8          	mov    %rsi,-0x38(%rbp)
 100f147:	48 8d 05 d2 fd 01 00 	lea    0x1fdd2(%rip),%rax        # 102ef20 <myl_t_db6bd58975531b7368ca22b8af460e2a11856412c594a38caca68120ceaa09fc>
 100f14e:	48 89 85 78 fc ff ff 	mov    %rax,-0x388(%rbp)
 100f155:	c7 85 90 fc ff ff 02 	movl   $0x2,-0x370(%rbp)
 100f15c:	00 00 00 
 100f15f:	48 8d 85 d8 fe ff ff 	lea    -0x128(%rbp),%rax
 100f166:	48 89 85 80 fc ff ff 	mov    %rax,-0x380(%rbp)
 100f16d:	48 8d 85 d8 fd ff ff 	lea    -0x228(%rbp),%rax
 100f174:	48 89 c1             	mov    %rax,%rcx
 100f177:	48 83 c1 10          	add    $0x10,%rcx
 100f17b:	48 89 4d d0          	mov    %rcx,-0x30(%rbp)
 100f17f:	48 89 8d 88 fc ff ff 	mov    %rcx,-0x378(%rbp)
 100f186:	48 8d 85 38 fc ff ff 	lea    -0x3c8(%rbp),%rax
 100f18d:	49 89 c4             	mov    %rax,%r12
 100f190:	49 83 c4 60          	add    $0x60,%r12
 100f194:	4c 89 65 c0          	mov    %r12,-0x40(%rbp)
 100f198:	48 8d 05 31 fc 01 00 	lea    0x1fc31(%rip),%rax        # 102edd0 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b>
 100f19f:	48 89 85 98 fc ff ff 	mov    %rax,-0x368(%rbp)
 100f1a6:	c7 85 b0 fc ff ff 02 	movl   $0x2,-0x350(%rbp)
 100f1ad:	00 00 00 
 100f1b0:	48 8d 85 e0 fe ff ff 	lea    -0x120(%rbp),%rax
 100f1b7:	48 89 85 a0 fc ff ff 	mov    %rax,-0x360(%rbp)
 100f1be:	48 8d 85 d8 fd ff ff 	lea    -0x228(%rbp),%rax
 100f1c5:	48 83 c0 18          	add    $0x18,%rax
 100f1c9:	48 89 85 a8 fc ff ff 	mov    %rax,-0x358(%rbp)
 100f1d0:	48 8d 05 89 fb 01 00 	lea    0x1fb89(%rip),%rax        # 102ed60 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a>
 100f1d7:	48 89 85 b8 fc ff ff 	mov    %rax,-0x348(%rbp)
 100f1de:	c7 85 d0 fc ff ff 02 	movl   $0x2,-0x330(%rbp)
 100f1e5:	00 00 00 
 100f1e8:	48 8d 85 e8 fe ff ff 	lea    -0x118(%rbp),%rax
 100f1ef:	48 89 85 c0 fc ff ff 	mov    %rax,-0x340(%rbp)
 100f1f6:	48 8d 85 d8 fd ff ff 	lea    -0x228(%rbp),%rax
 100f1fd:	48 83 c0 20          	add    $0x20,%rax
 100f201:	48 89 85 c8 fc ff ff 	mov    %rax,-0x338(%rbp)
 100f208:	48 8d 85 38 fc ff ff 	lea    -0x3c8(%rbp),%rax
 100f20f:	48 05 a0 00 00 00    	add    $0xa0,%rax
 100f215:	48 89 45 b8          	mov    %rax,-0x48(%rbp)
 100f219:	48 8d 05 00 fd 01 00 	lea    0x1fd00(%rip),%rax        # 102ef20 <myl_t_db6bd58975531b7368ca22b8af460e2a11856412c594a38caca68120ceaa09fc>
 100f220:	48 89 85 d8 fc ff ff 	mov    %rax,-0x328(%rbp)
 100f227:	c7 85 f0 fc ff ff 02 	movl   $0x2,-0x310(%rbp)
 100f22e:	00 00 00 
 100f231:	48 8d 85 f0 fe ff ff 	lea    -0x110(%rbp),%rax
 100f238:	48 89 85 e0 fc ff ff 	mov    %rax,-0x320(%rbp)
 100f23f:	48 8d 85 d8 fd ff ff 	lea    -0x228(%rbp),%rax
 100f246:	48 83 c0 28          	add    $0x28,%rax
 100f24a:	48 89 85 e8 fc ff ff 	mov    %rax,-0x318(%rbp)
 100f251:	48 8d 85 38 fc ff ff 	lea    -0x3c8(%rbp),%rax
 100f258:	48 89 c6             	mov    %rax,%rsi
 100f25b:	48 81 c6 c0 00 00 00 	add    $0xc0,%rsi
 100f262:	48 89 75 a0          	mov    %rsi,-0x60(%rbp)
 100f266:	48 8d 05 63 fb 01 00 	lea    0x1fb63(%rip),%rax        # 102edd0 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b>
 100f26d:	48 89 85 f8 fc ff ff 	mov    %rax,-0x308(%rbp)
 100f274:	c7 85 10 fd ff ff 02 	movl   $0x2,-0x2f0(%rbp)
 100f27b:	00 00 00 
 100f27e:	48 8d 85 f8 fe ff ff 	lea    -0x108(%rbp),%rax
 100f285:	48 89 85 00 fd ff ff 	mov    %rax,-0x300(%rbp)
 100f28c:	48 8d 85 d8 fd ff ff 	lea    -0x228(%rbp),%rax
 100f293:	49 89 c4             	mov    %rax,%r12
 100f296:	49 83 c4 30          	add    $0x30,%r12
 100f29a:	4c 89 65 98          	mov    %r12,-0x68(%rbp)
 100f29e:	4c 89 a5 08 fd ff ff 	mov    %r12,-0x2f8(%rbp)
 100f2a5:	48 8d 85 38 fc ff ff 	lea    -0x3c8(%rbp),%rax
 100f2ac:	48 89 c6             	mov    %rax,%rsi
 100f2af:	48 81 c6 e0 00 00 00 	add    $0xe0,%rsi
 100f2b6:	48 89 b5 40 ff ff ff 	mov    %rsi,-0xc0(%rbp)
 100f2bd:	48 8d 05 9c fa 01 00 	lea    0x1fa9c(%rip),%rax        # 102ed60 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a>
 100f2c4:	48 89 85 18 fd ff ff 	mov    %rax,-0x2e8(%rbp)
 100f2cb:	c7 85 30 fd ff ff 02 	movl   $0x2,-0x2d0(%rbp)
 100f2d2:	00 00 00 
 100f2d5:	48 8d 85 00 ff ff ff 	lea    -0x100(%rbp),%rax
 100f2dc:	48 89 85 20 fd ff ff 	mov    %rax,-0x2e0(%rbp)
 100f2e3:	48 8d 85 d8 fd ff ff 	lea    -0x228(%rbp),%rax
 100f2ea:	49 89 c2             	mov    %rax,%r10
 100f2ed:	49 83 c2 38          	add    $0x38,%r10
 100f2f1:	4c 89 95 58 ff ff ff 	mov    %r10,-0xa8(%rbp)
 100f2f8:	4c 89 95 28 fd ff ff 	mov    %r10,-0x2d8(%rbp)
 100f2ff:	48 8d 85 38 fc ff ff 	lea    -0x3c8(%rbp),%rax
 100f306:	49 89 c5             	mov    %rax,%r13
 100f309:	49 81 c5 00 01 00 00 	add    $0x100,%r13
 100f310:	48 8d 05 a1 49 ff ff 	lea    -0xb65f(%rip),%rax        # 1003cb8 <myl_t_385cfdbc00ec32031699460779c15099b2bba3cad0e440fffb08e10df0acb9e1>
 100f317:	48 89 85 38 fd ff ff 	mov    %rax,-0x2c8(%rbp)
 100f31e:	c7 85 50 fd ff ff 00 	movl   $0x0,-0x2b0(%rbp)
 100f325:	00 00 00 
 100f328:	48 8d 85 40 fe ff ff 	lea    -0x1c0(%rbp),%rax
 100f32f:	48 89 85 40 fd ff ff 	mov    %rax,-0x2c0(%rbp)
 100f336:	48 8d 85 d8 fd ff ff 	lea    -0x228(%rbp),%rax
 100f33d:	49 89 c7             	mov    %rax,%r15
 100f340:	49 83 c7 40          	add    $0x40,%r15
 100f344:	4c 89 7d b0          	mov    %r15,-0x50(%rbp)
 100f348:	4c 89 bd 48 fd ff ff 	mov    %r15,-0x2b8(%rbp)
 100f34f:	48 8d 85 38 fc ff ff 	lea    -0x3c8(%rbp),%rax
 100f356:	49 89 c0             	mov    %rax,%r8
 100f359:	49 81 c0 20 01 00 00 	add    $0x120,%r8
 100f360:	4c 89 85 48 ff ff ff 	mov    %r8,-0xb8(%rbp)
 100f367:	48 8d 05 4a 49 ff ff 	lea    -0xb6b6(%rip),%rax        # 1003cb8 <myl_t_385cfdbc00ec32031699460779c15099b2bba3cad0e440fffb08e10df0acb9e1>
 100f36e:	48 89 85 58 fd ff ff 	mov    %rax,-0x2a8(%rbp)
 100f375:	c7 85 70 fd ff ff 00 	movl   $0x0,-0x290(%rbp)
 100f37c:	00 00 00 
 100f37f:	48 8d 85 48 fe ff ff 	lea    -0x1b8(%rbp),%rax
 100f386:	48 89 85 60 fd ff ff 	mov    %rax,-0x2a0(%rbp)
 100f38d:	48 8d 85 d8 fd ff ff 	lea    -0x228(%rbp),%rax
 100f394:	48 83 c0 48          	add    $0x48,%rax
 100f398:	48 89 85 68 fd ff ff 	mov    %rax,-0x298(%rbp)
 100f39f:	48 8d 85 38 fc ff ff 	lea    -0x3c8(%rbp),%rax
 100f3a6:	49 89 c1             	mov    %rax,%r9
 100f3a9:	49 81 c1 40 01 00 00 	add    $0x140,%r9
 100f3b0:	4c 89 8d 50 ff ff ff 	mov    %r9,-0xb0(%rbp)
 100f3b7:	48 8d 05 fa 48 ff ff 	lea    -0xb706(%rip),%rax        # 1003cb8 <myl_t_385cfdbc00ec32031699460779c15099b2bba3cad0e440fffb08e10df0acb9e1>
 100f3be:	48 89 85 78 fd ff ff 	mov    %rax,-0x288(%rbp)
 100f3c5:	c7 85 90 fd ff ff 00 	movl   $0x0,-0x270(%rbp)
 100f3cc:	00 00 00 
 100f3cf:	48 8d 85 50 fe ff ff 	lea    -0x1b0(%rbp),%rax
 100f3d6:	48 89 85 80 fd ff ff 	mov    %rax,-0x280(%rbp)
 100f3dd:	48 8d 85 d8 fd ff ff 	lea    -0x228(%rbp),%rax
 100f3e4:	48 83 c0 50          	add    $0x50,%rax
 100f3e8:	48 89 85 88 fd ff ff 	mov    %rax,-0x278(%rbp)
 100f3ef:	48 8d 05 c2 48 ff ff 	lea    -0xb73e(%rip),%rax        # 1003cb8 <myl_t_385cfdbc00ec32031699460779c15099b2bba3cad0e440fffb08e10df0acb9e1>
 100f3f6:	48 89 85 98 fd ff ff 	mov    %rax,-0x268(%rbp)
 100f3fd:	c7 85 b0 fd ff ff 00 	movl   $0x0,-0x250(%rbp)
 100f404:	00 00 00 
 100f407:	48 8d 85 58 fe ff ff 	lea    -0x1a8(%rbp),%rax
 100f40e:	48 89 85 a0 fd ff ff 	mov    %rax,-0x260(%rbp)
 100f415:	48 8d 85 d8 fd ff ff 	lea    -0x228(%rbp),%rax
 100f41c:	49 89 c4             	mov    %rax,%r12
 100f41f:	49 83 c4 58          	add    $0x58,%r12
 100f423:	4c 89 65 a8          	mov    %r12,-0x58(%rbp)
 100f427:	4c 89 a5 a8 fd ff ff 	mov    %r12,-0x258(%rbp)
 100f42e:	48 8d 05 83 48 ff ff 	lea    -0xb77d(%rip),%rax        # 1003cb8 <myl_t_385cfdbc00ec32031699460779c15099b2bba3cad0e440fffb08e10df0acb9e1>
 100f435:	48 89 85 b8 fd ff ff 	mov    %rax,-0x248(%rbp)
 100f43c:	c7 85 d0 fd ff ff 00 	movl   $0x0,-0x230(%rbp)
 100f443:	00 00 00 
 100f446:	48 8d 85 60 fe ff ff 	lea    -0x1a0(%rbp),%rax
 100f44d:	48 89 85 c0 fd ff ff 	mov    %rax,-0x240(%rbp)
 100f454:	48 8d 85 d8 fd ff ff 	lea    -0x228(%rbp),%rax
 100f45b:	48 89 c2             	mov    %rax,%rdx
 100f45e:	48 83 c2 60          	add    $0x60,%rdx
 100f462:	48 89 55 d8          	mov    %rdx,-0x28(%rbp)
 100f466:	48 89 95 c8 fd ff ff 	mov    %rdx,-0x238(%rbp)
 100f46d:	b9 0d 00 00 00       	mov    $0xd,%ecx
 100f472:	48 8d 95 38 fc ff ff 	lea    -0x3c8(%rbp),%rdx
 100f479:	48 8d b5 18 fc ff ff 	lea    -0x3e8(%rbp),%rsi
 100f480:	49 89 ff             	mov    %rdi,%r15
 100f483:	e8 d8 73 00 00       	call   1016860 <myl_qbe_rc_frame_enter>
 100f488:	4c 89 ff             	mov    %r15,%rdi
 100f48b:	49 89 ff             	mov    %rdi,%r15
 100f48e:	e8 0d 7d 00 00       	call   10171a0 <myl_qbe_require_step_accounting>
 100f493:	4c 89 ff             	mov    %r15,%rdi
 100f496:	49 89 ff             	mov    %rdi,%r15
 100f499:	e8 62 7d 00 00       	call   1017200 <myl_qbe_require_frame_accounting>
 100f49e:	4c 89 ff             	mov    %r15,%rdi
 100f4a1:	48 c7 85 08 ff ff ff 	movq   $0x0,-0xf8(%rbp)
 100f4a8:	00 00 00 00 
 100f4ac:	ba 00 00 00 00       	mov    $0x0,%edx
 100f4b1:	48 8d 35 a8 f8 01 00 	lea    0x1f8a8(%rip),%rsi        # 102ed60 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a>
 100f4b8:	49 89 ff             	mov    %rdi,%r15
 100f4bb:	48 89 df             	mov    %rbx,%rdi
 100f4be:	e8 9d e2 00 00       	call   101d760 <myl_native_list_new>
 100f4c3:	4c 89 ff             	mov    %r15,%rdi
 100f4c6:	4c 8b 45 e0          	mov    -0x20(%rbp),%r8
 100f4ca:	83 f8 00             	cmp    $0x0,%eax
 100f4cd:	75 0a                	jne    100f4d9 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x529>
 100f4cf:	48 89 fb             	mov    %rdi,%rbx
 100f4d2:	e8 f9 79 00 00       	call   1016ed0 <myl_qbe_fail_allocation>
 100f4d7:	0f 0b                	ud2
 100f4d9:	48 87 fb             	xchg   %rdi,%rbx
 100f4dc:	48 89 85 08 ff ff ff 	mov    %rax,-0xf8(%rbp)
 100f4e3:	48 8b 8d 08 ff ff ff 	mov    -0xf8(%rbp),%rcx
 100f4ea:	48 89 8d 58 fe ff ff 	mov    %rcx,-0x1a8(%rbp)
 100f4f1:	48 8d 0d d8 f8 01 00 	lea    0x1f8d8(%rip),%rcx        # 102edd0 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b>
 100f4f8:	48 89 8d 98 fd ff ff 	mov    %rcx,-0x268(%rbp)
 100f4ff:	c7 85 b0 fd ff ff 02 	movl   $0x2,-0x250(%rbp)
 100f506:	00 00 00 
 100f509:	c7 85 30 fe ff ff 01 	movl   $0x1,-0x1d0(%rbp)
 100f510:	00 00 00 
 100f513:	48 8b 8d 58 fe ff ff 	mov    -0x1a8(%rbp),%rcx
 100f51a:	48 89 8d 40 fe ff ff 	mov    %rcx,-0x1c0(%rbp)
 100f521:	48 8d 0d a8 f8 01 00 	lea    0x1f8a8(%rip),%rcx        # 102edd0 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b>
 100f528:	48 89 8d 38 fd ff ff 	mov    %rcx,-0x2c8(%rbp)
 100f52f:	c7 85 50 fd ff ff 02 	movl   $0x2,-0x2b0(%rbp)
 100f536:	00 00 00 
 100f539:	c7 85 50 fd ff ff 02 	movl   $0x2,-0x2b0(%rbp)
 100f540:	00 00 00 
 100f543:	c7 85 30 fe ff ff 00 	movl   $0x0,-0x1d0(%rbp)
 100f54a:	00 00 00 
 100f54d:	c7 85 18 fe ff ff 01 	movl   $0x1,-0x1e8(%rbp)
 100f554:	00 00 00 
 100f557:	48 89 85 08 ff ff ff 	mov    %rax,-0xf8(%rbp)
 100f55e:	48 8d 95 58 fe ff ff 	lea    -0x1a8(%rbp),%rdx
 100f565:	48 8d 8d 08 ff ff ff 	lea    -0xf8(%rbp),%rcx
 100f56c:	48 29 d1             	sub    %rdx,%rcx
 100f56f:	48 8d b5 08 ff ff ff 	lea    -0xf8(%rbp),%rsi
 100f576:	48 8d 95 58 fe ff ff 	lea    -0x1a8(%rbp),%rdx
 100f57d:	48 29 f2             	sub    %rsi,%rdx
 100f580:	48 83 f9 08          	cmp    $0x8,%rcx
 100f584:	0f 92 c1             	setb   %cl
 100f587:	0f b6 c9             	movzbl %cl,%ecx
 100f58a:	89 4d e8             	mov    %ecx,-0x18(%rbp)
 100f58d:	48 83 fa 08          	cmp    $0x8,%rdx
 100f591:	0f 92 c2             	setb   %dl
 100f594:	0f b6 d2             	movzbl %dl,%edx
 100f597:	89 55 ec             	mov    %edx,-0x14(%rbp)
 100f59a:	09 d1                	or     %edx,%ecx
 100f59c:	75 5a                	jne    100f5f8 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x648>
 100f59e:	48 83 f8 00          	cmp    $0x0,%rax
 100f5a2:	74 1a                	je     100f5be <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x60e>
 100f5a4:	48 83 e8 10          	sub    $0x10,%rax
 100f5a8:	48 8b 00             	mov    (%rax),%rax
 100f5ab:	48 b9 01 00 00 00 00 	movabs $0x5000000000000001,%rcx
 100f5b2:	00 00 50 
 100f5b5:	48 21 c8             	and    %rcx,%rax
 100f5b8:	48 83 f8 00          	cmp    $0x0,%rax
 100f5bc:	75 3a                	jne    100f5f8 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x648>
 100f5be:	48 8b 85 08 ff ff ff 	mov    -0xf8(%rbp),%rax
 100f5c5:	48 89 85 58 fe ff ff 	mov    %rax,-0x1a8(%rbp)
 100f5cc:	ba 08 00 00 00       	mov    $0x8,%edx
 100f5d1:	be 00 00 00 00       	mov    $0x0,%esi
 100f5d6:	49 89 ff             	mov    %rdi,%r15
 100f5d9:	48 8d bd 08 ff ff ff 	lea    -0xf8(%rbp),%rdi
 100f5e0:	e8 6b cd 01 00       	call   102c350 <compiler_rt.fastMemset>
 100f5e5:	4c 89 ff             	mov    %r15,%rdi
 100f5e8:	8b 55 ec             	mov    -0x14(%rbp),%edx
 100f5eb:	8b 4d e8             	mov    -0x18(%rbp),%ecx
 100f5ee:	48 8b 75 f0          	mov    -0x10(%rbp),%rsi
 100f5f2:	4c 8b 45 e0          	mov    -0x20(%rbp),%r8
 100f5f6:	eb 4d                	jmp    100f645 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x695>
 100f5f8:	48 8d 8d 08 ff ff ff 	lea    -0xf8(%rbp),%rcx
 100f5ff:	48 8d 95 58 fe ff ff 	lea    -0x1a8(%rbp),%rdx
 100f606:	48 8d 35 c3 f7 01 00 	lea    0x1f7c3(%rip),%rsi        # 102edd0 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b>
 100f60d:	49 89 ff             	mov    %rdi,%r15
 100f610:	e8 db c1 01 00       	call   102b7f0 <myl_rc_native_take>
 100f615:	4c 89 ff             	mov    %r15,%rdi
 100f618:	8b 55 ec             	mov    -0x14(%rbp),%edx
 100f61b:	8b 4d e8             	mov    -0x18(%rbp),%ecx
 100f61e:	48 8b 75 f0          	mov    -0x10(%rbp),%rsi
 100f622:	4c 8b 45 e0          	mov    -0x20(%rbp),%r8
 100f626:	83 f8 00             	cmp    $0x0,%eax
 100f629:	75 1a                	jne    100f645 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x695>
 100f62b:	e8 50 42 01 00       	call   1023880 <myl_rc_take_failure>
 100f630:	48 89 df             	mov    %rbx,%rdi
 100f633:	89 c6                	mov    %eax,%esi
 100f635:	48 89 fb             	mov    %rdi,%rbx
 100f638:	e8 33 71 00 00       	call   1016770 <myl_qbe_rc_status>
 100f63d:	48 89 df             	mov    %rbx,%rdi
 100f640:	e9 4b 18 00 00       	jmp    1010e90 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1ee0>
 100f645:	c7 85 18 fe ff ff 00 	movl   $0x0,-0x1e8(%rbp)
 100f64c:	00 00 00 
 100f64f:	48 8d 05 7a f7 01 00 	lea    0x1f77a(%rip),%rax        # 102edd0 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b>
 100f656:	48 89 85 98 fd ff ff 	mov    %rax,-0x268(%rbp)
 100f65d:	c7 85 b0 fd ff ff 02 	movl   $0x2,-0x250(%rbp)
 100f664:	00 00 00 
 100f667:	c7 85 30 fe ff ff 01 	movl   $0x1,-0x1d0(%rbp)
 100f66e:	00 00 00 
 100f671:	8b 85 d8 fd ff ff    	mov    -0x228(%rbp),%eax
 100f677:	83 f8 00             	cmp    $0x0,%eax
 100f67a:	74 23                	je     100f69f <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x6ef>
 100f67c:	48 8d b5 38 fc ff ff 	lea    -0x3c8(%rbp),%rsi
 100f683:	49 89 ff             	mov    %rdi,%r15
 100f686:	48 89 df             	mov    %rbx,%rdi
 100f689:	e8 b2 72 00 00       	call   1016940 <myl_qbe_rc_slot_drop>
 100f68e:	4c 89 ff             	mov    %r15,%rdi
 100f691:	8b 55 ec             	mov    -0x14(%rbp),%edx
 100f694:	8b 4d e8             	mov    -0x18(%rbp),%ecx
 100f697:	48 8b 75 f0          	mov    -0x10(%rbp),%rsi
 100f69b:	4c 8b 45 e0          	mov    -0x20(%rbp),%r8
 100f69f:	48 8b 85 58 fe ff ff 	mov    -0x1a8(%rbp),%rax
 100f6a6:	48 89 85 c8 fe ff ff 	mov    %rax,-0x138(%rbp)
 100f6ad:	c7 85 30 fe ff ff 00 	movl   $0x0,-0x1d0(%rbp)
 100f6b4:	00 00 00 
 100f6b7:	48 8d 05 12 f7 01 00 	lea    0x1f712(%rip),%rax        # 102edd0 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b>
 100f6be:	48 89 85 38 fc ff ff 	mov    %rax,-0x3c8(%rbp)
 100f6c5:	c7 85 50 fc ff ff 02 	movl   $0x2,-0x3b0(%rbp)
 100f6cc:	00 00 00 
 100f6cf:	48 8d 85 c8 fe ff ff 	lea    -0x138(%rbp),%rax
 100f6d6:	48 89 85 40 fc ff ff 	mov    %rax,-0x3c0(%rbp)
 100f6dd:	48 8d 85 d8 fd ff ff 	lea    -0x228(%rbp),%rax
 100f6e4:	48 89 85 48 fc ff ff 	mov    %rax,-0x3b8(%rbp)
 100f6eb:	8b 85 b0 fd ff ff    	mov    -0x250(%rbp),%eax
 100f6f1:	89 85 50 fc ff ff    	mov    %eax,-0x3b0(%rbp)
 100f6f7:	c7 85 d8 fd ff ff 01 	movl   $0x1,-0x228(%rbp)
 100f6fe:	00 00 00 
 100f701:	41 89 c1             	mov    %eax,%r9d
 100f704:	48 8b 85 c8 fe ff ff 	mov    -0x138(%rbp),%rax
 100f70b:	41 83 f9 08          	cmp    $0x8,%r9d
 100f70f:	74 0c                	je     100f71d <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x76d>
 100f711:	48 89 85 08 ff ff ff 	mov    %rax,-0xf8(%rbp)
 100f718:	e9 f0 00 00 00       	jmp    100f80d <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x85d>
 100f71d:	48 c7 85 58 fe ff ff 	movq   $0x0,-0x1a8(%rbp)
 100f724:	00 00 00 00 
 100f728:	48 8d 95 58 fe ff ff 	lea    -0x1a8(%rbp),%rdx
 100f72f:	48 89 c6             	mov    %rax,%rsi
 100f732:	49 89 ff             	mov    %rdi,%r15
 100f735:	e8 96 46 01 00       	call   1023dd0 <myl_rc_hold_acquire>
 100f73a:	4c 89 ff             	mov    %r15,%rdi
 100f73d:	89 c6                	mov    %eax,%esi
 100f73f:	49 89 ff             	mov    %rdi,%r15
 100f742:	48 89 df             	mov    %rbx,%rdi
 100f745:	e8 26 70 00 00       	call   1016770 <myl_qbe_rc_status>
 100f74a:	4c 89 ff             	mov    %r15,%rdi
 100f74d:	8b 55 ec             	mov    -0x14(%rbp),%edx
 100f750:	8b 4d e8             	mov    -0x18(%rbp),%ecx
 100f753:	4c 8b 7d b0          	mov    -0x50(%rbp),%r15
 100f757:	48 8b 75 f0          	mov    -0x10(%rbp),%rsi
 100f75b:	4c 8b 45 e0          	mov    -0x20(%rbp),%r8
 100f75f:	83 f8 00             	cmp    $0x0,%eax
 100f762:	75 08                	jne    100f76c <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x7bc>
 100f764:	48 89 df             	mov    %rbx,%rdi
 100f767:	e9 24 17 00 00       	jmp    1010e90 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1ee0>
 100f76c:	48 8d 05 5d f6 01 00 	lea    0x1f65d(%rip),%rax        # 102edd0 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b>
 100f773:	48 89 85 98 fd ff ff 	mov    %rax,-0x268(%rbp)
 100f77a:	c7 85 b0 fd ff ff 02 	movl   $0x2,-0x250(%rbp)
 100f781:	00 00 00 
 100f784:	48 8d 85 58 fe ff ff 	lea    -0x1a8(%rbp),%rax
 100f78b:	48 89 85 a0 fd ff ff 	mov    %rax,-0x260(%rbp)
 100f792:	4c 89 a5 a8 fd ff ff 	mov    %r12,-0x258(%rbp)
 100f799:	c7 85 b0 fd ff ff 08 	movl   $0x8,-0x250(%rbp)
 100f7a0:	00 00 00 
 100f7a3:	c7 85 30 fe ff ff 01 	movl   $0x1,-0x1d0(%rbp)
 100f7aa:	00 00 00 
 100f7ad:	48 8b 85 58 fe ff ff 	mov    -0x1a8(%rbp),%rax
 100f7b4:	48 89 85 40 fe ff ff 	mov    %rax,-0x1c0(%rbp)
 100f7bb:	4c 8d 0d 0e f6 01 00 	lea    0x1f60e(%rip),%r9        # 102edd0 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b>
 100f7c2:	4c 89 8d 38 fd ff ff 	mov    %r9,-0x2c8(%rbp)
 100f7c9:	c7 85 50 fd ff ff 02 	movl   $0x2,-0x2b0(%rbp)
 100f7d0:	00 00 00 
 100f7d3:	4c 8d 8d 40 fe ff ff 	lea    -0x1c0(%rbp),%r9
 100f7da:	4c 89 8d 40 fd ff ff 	mov    %r9,-0x2c0(%rbp)
 100f7e1:	4c 89 bd 48 fd ff ff 	mov    %r15,-0x2b8(%rbp)
 100f7e8:	c7 85 50 fd ff ff 08 	movl   $0x8,-0x2b0(%rbp)
 100f7ef:	00 00 00 
 100f7f2:	c7 85 18 fe ff ff 01 	movl   $0x1,-0x1e8(%rbp)
 100f7f9:	00 00 00 
 100f7fc:	c7 85 30 fe ff ff 00 	movl   $0x0,-0x1d0(%rbp)
 100f803:	00 00 00 
 100f806:	48 89 85 08 ff ff ff 	mov    %rax,-0xf8(%rbp)
 100f80d:	44 8b 8d 18 fe ff ff 	mov    -0x1e8(%rbp),%r9d
 100f814:	44 8b 95 50 fd ff ff 	mov    -0x2b0(%rbp),%r10d
 100f81b:	41 83 e2 18          	and    $0x18,%r10d
 100f81f:	41 83 fa 00          	cmp    $0x0,%r10d
 100f823:	41 0f 94 c2          	sete   %r10b
 100f827:	45 0f b6 d2          	movzbl %r10b,%r10d
 100f82b:	45 85 ca             	test   %r9d,%r10d
 100f82e:	0f 85 91 00 00 00    	jne    100f8c5 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x915>
 100f834:	48 8d 8d 08 ff ff ff 	lea    -0xf8(%rbp),%rcx
 100f83b:	48 8d 95 58 fe ff ff 	lea    -0x1a8(%rbp),%rdx
 100f842:	49 89 f7             	mov    %rsi,%r15
 100f845:	48 8d 35 84 f5 01 00 	lea    0x1f584(%rip),%rsi        # 102edd0 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b>
 100f84c:	49 89 fc             	mov    %rdi,%r12
 100f84f:	e8 fc c5 01 00       	call   102be50 <myl_rc_native_retain>
 100f854:	4c 89 fe             	mov    %r15,%rsi
 100f857:	4c 89 e7             	mov    %r12,%rdi
 100f85a:	83 f8 00             	cmp    $0x0,%eax
 100f85d:	75 1a                	jne    100f879 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x8c9>
 100f85f:	e8 1c 40 01 00       	call   1023880 <myl_rc_take_failure>
 100f864:	48 89 df             	mov    %rbx,%rdi
 100f867:	89 c6                	mov    %eax,%esi
 100f869:	48 89 fb             	mov    %rdi,%rbx
 100f86c:	e8 ff 6e 00 00       	call   1016770 <myl_qbe_rc_status>
 100f871:	48 89 df             	mov    %rbx,%rdi
 100f874:	e9 17 16 00 00       	jmp    1010e90 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1ee0>
 100f879:	48 8d 05 50 f5 01 00 	lea    0x1f550(%rip),%rax        # 102edd0 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b>
 100f880:	48 89 85 98 fd ff ff 	mov    %rax,-0x268(%rbp)
 100f887:	c7 85 b0 fd ff ff 02 	movl   $0x2,-0x250(%rbp)
 100f88e:	00 00 00 
 100f891:	c7 85 30 fe ff ff 01 	movl   $0x1,-0x1d0(%rbp)
 100f898:	00 00 00 
 100f89b:	8b 85 18 fe ff ff    	mov    -0x1e8(%rbp),%eax
 100f8a1:	83 f8 00             	cmp    $0x0,%eax
 100f8a4:	74 17                	je     100f8bd <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x90d>
 100f8a6:	49 89 f7             	mov    %rsi,%r15
 100f8a9:	4c 89 ee             	mov    %r13,%rsi
 100f8ac:	49 89 fc             	mov    %rdi,%r12
 100f8af:	48 89 df             	mov    %rbx,%rdi
 100f8b2:	e8 89 70 00 00       	call   1016940 <myl_qbe_rc_slot_drop>
 100f8b7:	4c 89 fe             	mov    %r15,%rsi
 100f8ba:	4c 89 e7             	mov    %r12,%rdi
 100f8bd:	48 87 df             	xchg   %rbx,%rdi
 100f8c0:	e9 d0 00 00 00       	jmp    100f995 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x9e5>
 100f8c5:	09 d1                	or     %edx,%ecx
 100f8c7:	75 55                	jne    100f91e <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x96e>
 100f8c9:	48 83 f8 00          	cmp    $0x0,%rax
 100f8cd:	74 1a                	je     100f8e9 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x939>
 100f8cf:	48 83 e8 10          	sub    $0x10,%rax
 100f8d3:	48 8b 00             	mov    (%rax),%rax
 100f8d6:	48 b9 01 00 00 00 00 	movabs $0x5000000000000001,%rcx
 100f8dd:	00 00 50 
 100f8e0:	48 21 c8             	and    %rcx,%rax
 100f8e3:	48 83 f8 00          	cmp    $0x0,%rax
 100f8e7:	75 35                	jne    100f91e <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x96e>
 100f8e9:	48 8b 85 08 ff ff ff 	mov    -0xf8(%rbp),%rax
 100f8f0:	48 89 85 58 fe ff ff 	mov    %rax,-0x1a8(%rbp)
 100f8f7:	ba 08 00 00 00       	mov    $0x8,%edx
 100f8fc:	49 89 f7             	mov    %rsi,%r15
 100f8ff:	be 00 00 00 00       	mov    $0x0,%esi
 100f904:	49 89 fc             	mov    %rdi,%r12
 100f907:	48 8d bd 08 ff ff ff 	lea    -0xf8(%rbp),%rdi
 100f90e:	e8 3d ca 01 00       	call   102c350 <compiler_rt.fastMemset>
 100f913:	4c 89 fe             	mov    %r15,%rsi
 100f916:	4c 89 e7             	mov    %r12,%rdi
 100f919:	48 87 df             	xchg   %rbx,%rdi
 100f91c:	eb 4b                	jmp    100f969 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x9b9>
 100f91e:	4d 89 c7             	mov    %r8,%r15
 100f921:	48 8d 8d 08 ff ff ff 	lea    -0xf8(%rbp),%rcx
 100f928:	48 8d 95 58 fe ff ff 	lea    -0x1a8(%rbp),%rdx
 100f92f:	49 89 f7             	mov    %rsi,%r15
 100f932:	48 8d 35 97 f4 01 00 	lea    0x1f497(%rip),%rsi        # 102edd0 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b>
 100f939:	49 89 fc             	mov    %rdi,%r12
 100f93c:	e8 af be 01 00       	call   102b7f0 <myl_rc_native_take>
 100f941:	4c 89 fe             	mov    %r15,%rsi
 100f944:	4c 89 e7             	mov    %r12,%rdi
 100f947:	83 f8 00             	cmp    $0x0,%eax
 100f94a:	75 1a                	jne    100f966 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x9b6>
 100f94c:	e8 2f 3f 01 00       	call   1023880 <myl_rc_take_failure>
 100f951:	48 89 df             	mov    %rbx,%rdi
 100f954:	89 c6                	mov    %eax,%esi
 100f956:	48 89 fb             	mov    %rdi,%rbx
 100f959:	e8 12 6e 00 00       	call   1016770 <myl_qbe_rc_status>
 100f95e:	48 89 df             	mov    %rbx,%rdi
 100f961:	e9 2a 15 00 00       	jmp    1010e90 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1ee0>
 100f966:	48 87 df             	xchg   %rbx,%rdi
 100f969:	c7 85 18 fe ff ff 00 	movl   $0x0,-0x1e8(%rbp)
 100f970:	00 00 00 
 100f973:	48 8d 05 56 f4 01 00 	lea    0x1f456(%rip),%rax        # 102edd0 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b>
 100f97a:	48 89 85 98 fd ff ff 	mov    %rax,-0x268(%rbp)
 100f981:	c7 85 b0 fd ff ff 02 	movl   $0x2,-0x250(%rbp)
 100f988:	00 00 00 
 100f98b:	c7 85 30 fe ff ff 01 	movl   $0x1,-0x1d0(%rbp)
 100f992:	00 00 00 
 100f995:	8b 85 e0 fd ff ff    	mov    -0x220(%rbp),%eax
 100f99b:	83 f8 00             	cmp    $0x0,%eax
 100f99e:	74 0b                	je     100f9ab <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x9fb>
 100f9a0:	49 89 fc             	mov    %rdi,%r12
 100f9a3:	e8 98 6f 00 00       	call   1016940 <myl_qbe_rc_slot_drop>
 100f9a8:	4c 89 e7             	mov    %r12,%rdi
 100f9ab:	48 8b 85 58 fe ff ff 	mov    -0x1a8(%rbp),%rax
 100f9b2:	48 89 85 d0 fe ff ff 	mov    %rax,-0x130(%rbp)
 100f9b9:	c7 85 30 fe ff ff 00 	movl   $0x0,-0x1d0(%rbp)
 100f9c0:	00 00 00 
 100f9c3:	48 8d 05 06 f4 01 00 	lea    0x1f406(%rip),%rax        # 102edd0 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b>
 100f9ca:	48 89 85 58 fc ff ff 	mov    %rax,-0x3a8(%rbp)
 100f9d1:	c7 85 70 fc ff ff 02 	movl   $0x2,-0x390(%rbp)
 100f9d8:	00 00 00 
 100f9db:	48 8d 85 d0 fe ff ff 	lea    -0x130(%rbp),%rax
 100f9e2:	48 89 85 60 fc ff ff 	mov    %rax,-0x3a0(%rbp)
 100f9e9:	4c 89 b5 68 fc ff ff 	mov    %r14,-0x398(%rbp)
 100f9f0:	8b 85 b0 fd ff ff    	mov    -0x250(%rbp),%eax
 100f9f6:	89 85 70 fc ff ff    	mov    %eax,-0x390(%rbp)
 100f9fc:	c7 85 e0 fd ff ff 01 	movl   $0x1,-0x220(%rbp)
 100fa03:	00 00 00 
 100fa06:	8b 85 d8 fd ff ff    	mov    -0x228(%rbp),%eax
 100fa0c:	83 f8 00             	cmp    $0x0,%eax
 100fa0f:	74 12                	je     100fa23 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xa73>
 100fa11:	48 8d b5 38 fc ff ff 	lea    -0x3c8(%rbp),%rsi
 100fa18:	49 89 fc             	mov    %rdi,%r12
 100fa1b:	e8 20 6f 00 00       	call   1016940 <myl_qbe_rc_slot_drop>
 100fa20:	4c 89 e7             	mov    %r12,%rdi
 100fa23:	48 c7 85 08 ff ff ff 	movq   $0x0,-0xf8(%rbp)
 100fa2a:	00 00 00 00 
 100fa2e:	48 c7 85 08 ff ff ff 	movq   $0x3e8,-0xf8(%rbp)
 100fa35:	e8 03 00 00 
 100fa39:	41 bc 00 00 00 00    	mov    $0x0,%r12d
 100fa3f:	90                   	nop
 100fa40:	4c 89 a5 08 ff ff ff 	mov    %r12,-0xf8(%rbp)
 100fa47:	48 c7 85 10 ff ff ff 	movq   $0x3e8,-0xf0(%rbp)
 100fa4e:	e8 03 00 00 
 100fa52:	49 81 fc e8 03 00 00 	cmp    $0x3e8,%r12
 100fa59:	0f 9c c0             	setl   %al
 100fa5c:	48 0f b6 c0          	movzbq %al,%rax
 100fa60:	48 89 85 08 ff ff ff 	mov    %rax,-0xf8(%rbp)
 100fa67:	0f 8d 43 03 00 00    	jge    100fdb0 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xe00>
 100fa6d:	48 c7 85 08 ff ff ff 	movq   $0x6b,-0xf8(%rbp)
 100fa74:	6b 00 00 00 
 100fa78:	48 c7 85 10 ff ff ff 	movq   $0x65,-0xf0(%rbp)
 100fa7f:	65 00 00 00 
 100fa83:	48 c7 85 18 ff ff ff 	movq   $0x79,-0xe8(%rbp)
 100fa8a:	79 00 00 00 
 100fa8e:	48 8b 05 53 fb 01 00 	mov    0x1fb53(%rip),%rax        # 102f5e8 <myl_lit_7c9ad5bce17f8d7309d981a8c987a567b0a2e56945e29fb3b883a7b4446dd143>
 100fa95:	48 89 85 08 ff ff ff 	mov    %rax,-0xf8(%rbp)
 100fa9c:	48 8b 8d 08 ff ff ff 	mov    -0xf8(%rbp),%rcx
 100faa3:	48 89 8d 58 fe ff ff 	mov    %rcx,-0x1a8(%rbp)
 100faaa:	48 8d 0d af f2 01 00 	lea    0x1f2af(%rip),%rcx        # 102ed60 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a>
 100fab1:	48 89 8d 98 fd ff ff 	mov    %rcx,-0x268(%rbp)
 100fab8:	c7 85 b0 fd ff ff 02 	movl   $0x2,-0x250(%rbp)
 100fabf:	00 00 00 
 100fac2:	c7 85 30 fe ff ff 01 	movl   $0x1,-0x1d0(%rbp)
 100fac9:	00 00 00 
 100facc:	48 8b 8d 58 fe ff ff 	mov    -0x1a8(%rbp),%rcx
 100fad3:	48 89 8d 40 fe ff ff 	mov    %rcx,-0x1c0(%rbp)
 100fada:	48 8d 0d 7f f2 01 00 	lea    0x1f27f(%rip),%rcx        # 102ed60 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a>
 100fae1:	48 89 8d 38 fd ff ff 	mov    %rcx,-0x2c8(%rbp)
 100fae8:	c7 85 50 fd ff ff 02 	movl   $0x2,-0x2b0(%rbp)
 100faef:	00 00 00 
 100faf2:	c7 85 50 fd ff ff 02 	movl   $0x2,-0x2b0(%rbp)
 100faf9:	00 00 00 
 100fafc:	c7 85 30 fe ff ff 00 	movl   $0x0,-0x1d0(%rbp)
 100fb03:	00 00 00 
 100fb06:	c7 85 18 fe ff ff 01 	movl   $0x1,-0x1e8(%rbp)
 100fb0d:	00 00 00 
 100fb10:	48 89 85 08 ff ff ff 	mov    %rax,-0xf8(%rbp)
 100fb17:	4c 89 a5 10 ff ff ff 	mov    %r12,-0xf0(%rbp)
 100fb1e:	ba 00 00 00 00       	mov    $0x0,%edx
 100fb23:	4c 89 e6             	mov    %r12,%rsi
 100fb26:	49 89 ff             	mov    %rdi,%r15
 100fb29:	48 89 df             	mov    %rbx,%rdi
 100fb2c:	e8 6f 15 00 00       	call   10110a0 <myl_native_text_scalar>
 100fb31:	4c 89 ff             	mov    %r15,%rdi
 100fb34:	48 89 c2             	mov    %rax,%rdx
 100fb37:	83 fa 00             	cmp    $0x0,%edx
 100fb3a:	0f 84 69 02 00 00    	je     100fda9 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xdf9>
 100fb40:	48 89 95 10 ff ff ff 	mov    %rdx,-0xf0(%rbp)
 100fb47:	48 8b 85 10 ff ff ff 	mov    -0xf0(%rbp),%rax
 100fb4e:	48 89 85 58 fe ff ff 	mov    %rax,-0x1a8(%rbp)
 100fb55:	48 8d 05 04 f2 01 00 	lea    0x1f204(%rip),%rax        # 102ed60 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a>
 100fb5c:	48 89 85 98 fd ff ff 	mov    %rax,-0x268(%rbp)
 100fb63:	c7 85 b0 fd ff ff 02 	movl   $0x2,-0x250(%rbp)
 100fb6a:	00 00 00 
 100fb6d:	c7 85 30 fe ff ff 01 	movl   $0x1,-0x1d0(%rbp)
 100fb74:	00 00 00 
 100fb77:	48 8b 85 58 fe ff ff 	mov    -0x1a8(%rbp),%rax
 100fb7e:	48 89 85 48 fe ff ff 	mov    %rax,-0x1b8(%rbp)
 100fb85:	48 8d 05 d4 f1 01 00 	lea    0x1f1d4(%rip),%rax        # 102ed60 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a>
 100fb8c:	48 89 85 58 fd ff ff 	mov    %rax,-0x2a8(%rbp)
 100fb93:	c7 85 70 fd ff ff 02 	movl   $0x2,-0x290(%rbp)
 100fb9a:	00 00 00 
 100fb9d:	c7 85 70 fd ff ff 02 	movl   $0x2,-0x290(%rbp)
 100fba4:	00 00 00 
 100fba7:	c7 85 30 fe ff ff 00 	movl   $0x0,-0x1d0(%rbp)
 100fbae:	00 00 00 
 100fbb1:	c7 85 20 fe ff ff 01 	movl   $0x1,-0x1e0(%rbp)
 100fbb8:	00 00 00 
 100fbbb:	48 89 95 10 ff ff ff 	mov    %rdx,-0xf0(%rbp)
 100fbc2:	48 8b b5 08 ff ff ff 	mov    -0xf8(%rbp),%rsi
 100fbc9:	49 89 ff             	mov    %rdi,%r15
 100fbcc:	48 89 df             	mov    %rbx,%rdi
 100fbcf:	e8 1c ec 00 00       	call   101e7f0 <myl_native_text_concat>
 100fbd4:	4c 89 ff             	mov    %r15,%rdi
 100fbd7:	4c 8b 85 48 ff ff ff 	mov    -0xb8(%rbp),%r8
 100fbde:	83 f8 00             	cmp    $0x0,%eax
 100fbe1:	0f 84 bb 01 00 00    	je     100fda2 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xdf2>
 100fbe7:	48 89 85 08 ff ff ff 	mov    %rax,-0xf8(%rbp)
 100fbee:	48 8b 85 08 ff ff ff 	mov    -0xf8(%rbp),%rax
 100fbf5:	48 89 85 58 fe ff ff 	mov    %rax,-0x1a8(%rbp)
 100fbfc:	48 8d 05 5d f1 01 00 	lea    0x1f15d(%rip),%rax        # 102ed60 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a>
 100fc03:	48 89 85 98 fd ff ff 	mov    %rax,-0x268(%rbp)
 100fc0a:	c7 85 b0 fd ff ff 02 	movl   $0x2,-0x250(%rbp)
 100fc11:	00 00 00 
 100fc14:	c7 85 30 fe ff ff 01 	movl   $0x1,-0x1d0(%rbp)
 100fc1b:	00 00 00 
 100fc1e:	8b 85 18 fe ff ff    	mov    -0x1e8(%rbp),%eax
 100fc24:	83 f8 00             	cmp    $0x0,%eax
 100fc27:	74 15                	je     100fc3e <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xc8e>
 100fc29:	4c 89 ee             	mov    %r13,%rsi
 100fc2c:	49 89 ff             	mov    %rdi,%r15
 100fc2f:	e8 0c 6d 00 00       	call   1016940 <myl_qbe_rc_slot_drop>
 100fc34:	4c 89 ff             	mov    %r15,%rdi
 100fc37:	4c 8b 85 48 ff ff ff 	mov    -0xb8(%rbp),%r8
 100fc3e:	8b 85 20 fe ff ff    	mov    -0x1e0(%rbp),%eax
 100fc44:	83 f8 00             	cmp    $0x0,%eax
 100fc47:	74 0e                	je     100fc57 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xca7>
 100fc49:	4c 89 c6             	mov    %r8,%rsi
 100fc4c:	49 89 ff             	mov    %rdi,%r15
 100fc4f:	e8 ec 6c 00 00       	call   1016940 <myl_qbe_rc_slot_drop>
 100fc54:	4c 89 ff             	mov    %r15,%rdi
 100fc57:	48 8b 85 58 fe ff ff 	mov    -0x1a8(%rbp),%rax
 100fc5e:	48 89 85 40 fe ff ff 	mov    %rax,-0x1c0(%rbp)
 100fc65:	48 8d 05 f4 f0 01 00 	lea    0x1f0f4(%rip),%rax        # 102ed60 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a>
 100fc6c:	48 89 85 38 fd ff ff 	mov    %rax,-0x2c8(%rbp)
 100fc73:	c7 85 50 fd ff ff 02 	movl   $0x2,-0x2b0(%rbp)
 100fc7a:	00 00 00 
 100fc7d:	8b 85 b0 fd ff ff    	mov    -0x250(%rbp),%eax
 100fc83:	89 85 50 fd ff ff    	mov    %eax,-0x2b0(%rbp)
 100fc89:	c7 85 30 fe ff ff 00 	movl   $0x0,-0x1d0(%rbp)
 100fc90:	00 00 00 
 100fc93:	c7 85 18 fe ff ff 01 	movl   $0x1,-0x1e8(%rbp)
 100fc9a:	00 00 00 
 100fc9d:	48 8b 85 40 fe ff ff 	mov    -0x1c0(%rbp),%rax
 100fca4:	48 89 85 08 ff ff ff 	mov    %rax,-0xf8(%rbp)
 100fcab:	48 8d 05 1e f1 01 00 	lea    0x1f11e(%rip),%rax        # 102edd0 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b>
 100fcb2:	48 89 85 58 fc ff ff 	mov    %rax,-0x3a8(%rbp)
 100fcb9:	c7 85 70 fc ff ff 02 	movl   $0x2,-0x390(%rbp)
 100fcc0:	00 00 00 
 100fcc3:	48 8d 85 d0 fe ff ff 	lea    -0x130(%rbp),%rax
 100fcca:	48 89 85 60 fc ff ff 	mov    %rax,-0x3a0(%rbp)
 100fcd1:	4c 89 b5 68 fc ff ff 	mov    %r14,-0x398(%rbp)
 100fcd8:	4c 89 f1             	mov    %r14,%rcx
 100fcdb:	48 8d 95 d0 fe ff ff 	lea    -0x130(%rbp),%rdx
 100fce2:	48 8d 35 e7 f0 01 00 	lea    0x1f0e7(%rip),%rsi        # 102edd0 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b>
 100fce9:	49 89 ff             	mov    %rdi,%r15
 100fcec:	e8 cf 6f 00 00       	call   1016cc0 <myl_qbe_rc_unique_local>
 100fcf1:	4c 89 ff             	mov    %r15,%rdi
 100fcf4:	83 f8 00             	cmp    $0x0,%eax
 100fcf7:	0f 84 93 11 00 00    	je     1010e90 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1ee0>
 100fcfd:	48 8b b5 d0 fe ff ff 	mov    -0x130(%rbp),%rsi
 100fd04:	48 8d 95 08 ff ff ff 	lea    -0xf8(%rbp),%rdx
 100fd0b:	49 89 ff             	mov    %rdi,%r15
 100fd0e:	48 89 df             	mov    %rbx,%rdi
 100fd11:	e8 fa de 00 00       	call   101dc10 <myl_rc_list_append>
 100fd16:	4c 89 ff             	mov    %r15,%rdi
 100fd19:	4c 8b 85 48 ff ff ff 	mov    -0xb8(%rbp),%r8
 100fd20:	83 f8 00             	cmp    $0x0,%eax
 100fd23:	74 76                	je     100fd9b <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xdeb>
 100fd25:	48 c7 85 08 ff ff ff 	movq   $0x0,-0xf8(%rbp)
 100fd2c:	00 00 00 00 
 100fd30:	8b 85 18 fe ff ff    	mov    -0x1e8(%rbp),%eax
 100fd36:	83 f8 00             	cmp    $0x0,%eax
 100fd39:	74 15                	je     100fd50 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xda0>
 100fd3b:	4c 89 ee             	mov    %r13,%rsi
 100fd3e:	49 89 ff             	mov    %rdi,%r15
 100fd41:	e8 fa 6b 00 00       	call   1016940 <myl_qbe_rc_slot_drop>
 100fd46:	4c 89 ff             	mov    %r15,%rdi
 100fd49:	4c 8b 85 48 ff ff ff 	mov    -0xb8(%rbp),%r8
 100fd50:	4c 89 a5 08 ff ff ff 	mov    %r12,-0xf8(%rbp)
 100fd57:	48 c7 85 10 ff ff ff 	movq   $0x1,-0xf0(%rbp)
 100fd5e:	01 00 00 00 
 100fd62:	48 b8 fe ff ff ff ff 	movabs $0x7ffffffffffffffe,%rax
 100fd69:	ff ff 7f 
 100fd6c:	49 39 c4             	cmp    %rax,%r12
 100fd6f:	7f 10                	jg     100fd81 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xdd1>
 100fd71:	49 83 c4 01          	add    $0x1,%r12
 100fd75:	4c 89 a5 08 ff ff ff 	mov    %r12,-0xf8(%rbp)
 100fd7c:	e9 bf fc ff ff       	jmp    100fa40 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xa90>
 100fd81:	4c 89 e2             	mov    %r12,%rdx
 100fd84:	41 b8 40 00 00 00    	mov    $0x40,%r8d
 100fd8a:	b9 01 00 00 00       	mov    $0x1,%ecx
 100fd8f:	be 00 00 00 00       	mov    $0x0,%esi
 100fd94:	e8 37 72 00 00       	call   1016fd0 <myl_qbe_fail_overflow_op>
 100fd99:	0f 0b                	ud2
 100fd9b:	e8 30 71 00 00       	call   1016ed0 <myl_qbe_fail_allocation>
 100fda0:	0f 0b                	ud2
 100fda2:	e8 29 71 00 00       	call   1016ed0 <myl_qbe_fail_allocation>
 100fda7:	0f 0b                	ud2
 100fda9:	e8 22 71 00 00       	call   1016ed0 <myl_qbe_fail_allocation>
 100fdae:	0f 0b                	ud2
 100fdb0:	4c 8b 75 c0          	mov    -0x40(%rbp),%r14
 100fdb4:	4c 8b 7d e0          	mov    -0x20(%rbp),%r15
 100fdb8:	b9 01 00 00 00       	mov    $0x1,%ecx
 100fdbd:	48 8d 15 a4 3d ff ff 	lea    -0xc25c(%rip),%rdx        # 1003b68 <myl_t_1a91deb3742283487d66c3b500f6effd7ef1170e6d4b4368fe9ec3c3f0354fda>
 100fdc4:	48 8d 35 95 ef 01 00 	lea    0x1ef95(%rip),%rsi        # 102ed60 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a>
 100fdcb:	49 89 fc             	mov    %rdi,%r12
 100fdce:	48 89 df             	mov    %rbx,%rdi
 100fdd1:	e8 da eb 00 00       	call   101e9b0 <myl_native_dictionary_new>
 100fdd6:	4d 89 f8             	mov    %r15,%r8
 100fdd9:	4c 89 e7             	mov    %r12,%rdi
 100fddc:	48 8b 55 d8          	mov    -0x28(%rbp),%rdx
 100fde0:	48 8b 4d d0          	mov    -0x30(%rbp),%rcx
 100fde4:	83 f8 00             	cmp    $0x0,%eax
 100fde7:	75 0a                	jne    100fdf3 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xe43>
 100fde9:	48 89 fb             	mov    %rdi,%rbx
 100fdec:	e8 df 70 00 00       	call   1016ed0 <myl_qbe_fail_allocation>
 100fdf1:	0f 0b                	ud2
 100fdf3:	48 87 fb             	xchg   %rdi,%rbx
 100fdf6:	48 89 85 60 fe ff ff 	mov    %rax,-0x1a0(%rbp)
 100fdfd:	48 8d 35 1c f1 01 00 	lea    0x1f11c(%rip),%rsi        # 102ef20 <myl_t_db6bd58975531b7368ca22b8af460e2a11856412c594a38caca68120ceaa09fc>
 100fe04:	48 89 b5 b8 fd ff ff 	mov    %rsi,-0x248(%rbp)
 100fe0b:	c7 85 d0 fd ff ff 02 	movl   $0x2,-0x230(%rbp)
 100fe12:	00 00 00 
 100fe15:	48 8d b5 60 fe ff ff 	lea    -0x1a0(%rbp),%rsi
 100fe1c:	48 89 b5 c0 fd ff ff 	mov    %rsi,-0x240(%rbp)
 100fe23:	48 89 95 c8 fd ff ff 	mov    %rdx,-0x238(%rbp)
 100fe2a:	c7 85 d0 fd ff ff 04 	movl   $0x4,-0x230(%rbp)
 100fe31:	00 00 00 
 100fe34:	c7 85 38 fe ff ff 01 	movl   $0x1,-0x1c8(%rbp)
 100fe3b:	00 00 00 
 100fe3e:	c7 85 38 fe ff ff 00 	movl   $0x0,-0x1c8(%rbp)
 100fe45:	00 00 00 
 100fe48:	48 89 85 08 ff ff ff 	mov    %rax,-0xf8(%rbp)
 100fe4f:	48 8b 95 08 ff ff ff 	mov    -0xf8(%rbp),%rdx
 100fe56:	48 89 95 58 fe ff ff 	mov    %rdx,-0x1a8(%rbp)
 100fe5d:	48 8d 15 bc f0 01 00 	lea    0x1f0bc(%rip),%rdx        # 102ef20 <myl_t_db6bd58975531b7368ca22b8af460e2a11856412c594a38caca68120ceaa09fc>
 100fe64:	48 89 95 98 fd ff ff 	mov    %rdx,-0x268(%rbp)
 100fe6b:	c7 85 b0 fd ff ff 02 	movl   $0x2,-0x250(%rbp)
 100fe72:	00 00 00 
 100fe75:	c7 85 30 fe ff ff 01 	movl   $0x1,-0x1d0(%rbp)
 100fe7c:	00 00 00 
 100fe7f:	48 8b 95 58 fe ff ff 	mov    -0x1a8(%rbp),%rdx
 100fe86:	48 89 95 40 fe ff ff 	mov    %rdx,-0x1c0(%rbp)
 100fe8d:	48 8d 15 8c f0 01 00 	lea    0x1f08c(%rip),%rdx        # 102ef20 <myl_t_db6bd58975531b7368ca22b8af460e2a11856412c594a38caca68120ceaa09fc>
 100fe94:	48 89 95 38 fd ff ff 	mov    %rdx,-0x2c8(%rbp)
 100fe9b:	c7 85 50 fd ff ff 02 	movl   $0x2,-0x2b0(%rbp)
 100fea2:	00 00 00 
 100fea5:	c7 85 50 fd ff ff 02 	movl   $0x2,-0x2b0(%rbp)
 100feac:	00 00 00 
 100feaf:	c7 85 30 fe ff ff 00 	movl   $0x0,-0x1d0(%rbp)
 100feb6:	00 00 00 
 100feb9:	c7 85 18 fe ff ff 01 	movl   $0x1,-0x1e8(%rbp)
 100fec0:	00 00 00 
 100fec3:	48 89 85 08 ff ff ff 	mov    %rax,-0xf8(%rbp)
 100feca:	48 83 f8 00          	cmp    $0x0,%rax
 100fece:	75 05                	jne    100fed5 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xf25>
 100fed0:	49 89 cf             	mov    %rcx,%r15
 100fed3:	eb 1d                	jmp    100fef2 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xf42>
 100fed5:	48 83 e8 10          	sub    $0x10,%rax
 100fed9:	48 8b 00             	mov    (%rax),%rax
 100fedc:	49 89 cf             	mov    %rcx,%r15
 100fedf:	48 b9 01 00 00 00 00 	movabs $0x5000000000000001,%rcx
 100fee6:	00 00 50 
 100fee9:	48 21 c8             	and    %rcx,%rax
 100feec:	48 83 f8 00          	cmp    $0x0,%rax
 100fef0:	75 39                	jne    100ff2b <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xf7b>
 100fef2:	48 8b 85 08 ff ff ff 	mov    -0xf8(%rbp),%rax
 100fef9:	48 89 85 58 fe ff ff 	mov    %rax,-0x1a8(%rbp)
 100ff00:	ba 08 00 00 00       	mov    $0x8,%edx
 100ff05:	be 00 00 00 00       	mov    $0x0,%esi
 100ff0a:	49 89 fc             	mov    %rdi,%r12
 100ff0d:	48 8d bd 08 ff ff ff 	lea    -0xf8(%rbp),%rdi
 100ff14:	e8 37 c4 01 00       	call   102c350 <compiler_rt.fastMemset>
 100ff19:	4c 89 f9             	mov    %r15,%rcx
 100ff1c:	4c 89 e7             	mov    %r12,%rdi
 100ff1f:	48 8b 75 c8          	mov    -0x38(%rbp),%rsi
 100ff23:	49 89 cf             	mov    %rcx,%r15
 100ff26:	48 87 df             	xchg   %rbx,%rdi
 100ff29:	eb 4c                	jmp    100ff77 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xfc7>
 100ff2b:	4c 89 f9             	mov    %r15,%rcx
 100ff2e:	49 89 cf             	mov    %rcx,%r15
 100ff31:	48 8d 8d 08 ff ff ff 	lea    -0xf8(%rbp),%rcx
 100ff38:	48 8d 95 58 fe ff ff 	lea    -0x1a8(%rbp),%rdx
 100ff3f:	48 8d 35 da ef 01 00 	lea    0x1efda(%rip),%rsi        # 102ef20 <myl_t_db6bd58975531b7368ca22b8af460e2a11856412c594a38caca68120ceaa09fc>
 100ff46:	49 89 fc             	mov    %rdi,%r12
 100ff49:	e8 a2 b8 01 00       	call   102b7f0 <myl_rc_native_take>
 100ff4e:	4c 89 e7             	mov    %r12,%rdi
 100ff51:	48 8b 75 c8          	mov    -0x38(%rbp),%rsi
 100ff55:	83 f8 00             	cmp    $0x0,%eax
 100ff58:	75 1a                	jne    100ff74 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xfc4>
 100ff5a:	e8 21 39 01 00       	call   1023880 <myl_rc_take_failure>
 100ff5f:	48 89 df             	mov    %rbx,%rdi
 100ff62:	89 c6                	mov    %eax,%esi
 100ff64:	48 89 fb             	mov    %rdi,%rbx
 100ff67:	e8 04 68 00 00       	call   1016770 <myl_qbe_rc_status>
 100ff6c:	48 89 df             	mov    %rbx,%rdi
 100ff6f:	e9 1c 0f 00 00       	jmp    1010e90 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1ee0>
 100ff74:	48 87 df             	xchg   %rbx,%rdi
 100ff77:	c7 85 18 fe ff ff 00 	movl   $0x0,-0x1e8(%rbp)
 100ff7e:	00 00 00 
 100ff81:	48 8d 05 98 ef 01 00 	lea    0x1ef98(%rip),%rax        # 102ef20 <myl_t_db6bd58975531b7368ca22b8af460e2a11856412c594a38caca68120ceaa09fc>
 100ff88:	48 89 85 98 fd ff ff 	mov    %rax,-0x268(%rbp)
 100ff8f:	c7 85 b0 fd ff ff 02 	movl   $0x2,-0x250(%rbp)
 100ff96:	00 00 00 
 100ff99:	c7 85 30 fe ff ff 01 	movl   $0x1,-0x1d0(%rbp)
 100ffa0:	00 00 00 
 100ffa3:	8b 85 e8 fd ff ff    	mov    -0x218(%rbp),%eax
 100ffa9:	83 f8 00             	cmp    $0x0,%eax
 100ffac:	75 05                	jne    100ffb3 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1003>
 100ffae:	4c 89 f9             	mov    %r15,%rcx
 100ffb1:	eb 0e                	jmp    100ffc1 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1011>
 100ffb3:	49 89 fc             	mov    %rdi,%r12
 100ffb6:	e8 85 69 00 00       	call   1016940 <myl_qbe_rc_slot_drop>
 100ffbb:	4c 89 f9             	mov    %r15,%rcx
 100ffbe:	4c 89 e7             	mov    %r12,%rdi
 100ffc1:	48 8b 85 58 fe ff ff 	mov    -0x1a8(%rbp),%rax
 100ffc8:	48 89 85 d8 fe ff ff 	mov    %rax,-0x128(%rbp)
 100ffcf:	c7 85 30 fe ff ff 00 	movl   $0x0,-0x1d0(%rbp)
 100ffd6:	00 00 00 
 100ffd9:	48 8d 05 40 ef 01 00 	lea    0x1ef40(%rip),%rax        # 102ef20 <myl_t_db6bd58975531b7368ca22b8af460e2a11856412c594a38caca68120ceaa09fc>
 100ffe0:	48 89 85 78 fc ff ff 	mov    %rax,-0x388(%rbp)
 100ffe7:	c7 85 90 fc ff ff 02 	movl   $0x2,-0x370(%rbp)
 100ffee:	00 00 00 
 100fff1:	48 8d 85 d8 fe ff ff 	lea    -0x128(%rbp),%rax
 100fff8:	48 89 85 80 fc ff ff 	mov    %rax,-0x380(%rbp)
 100ffff:	48 89 8d 88 fc ff ff 	mov    %rcx,-0x378(%rbp)
 1010006:	8b 85 b0 fd ff ff    	mov    -0x250(%rbp),%eax
 101000c:	89 85 90 fc ff ff    	mov    %eax,-0x370(%rbp)
 1010012:	c7 85 e8 fd ff ff 01 	movl   $0x1,-0x218(%rbp)
 1010019:	00 00 00 
 101001c:	48 c7 85 08 ff ff ff 	movq   $0x0,-0xf8(%rbp)
 1010023:	00 00 00 00 
 1010027:	48 c7 85 08 ff ff ff 	movq   $0x1e8480,-0xf8(%rbp)
 101002e:	80 84 1e 00 
 1010032:	48 8d 05 e7 ee 01 00 	lea    0x1eee7(%rip),%rax        # 102ef20 <myl_t_db6bd58975531b7368ca22b8af460e2a11856412c594a38caca68120ceaa09fc>
 1010039:	48 89 85 78 fc ff ff 	mov    %rax,-0x388(%rbp)
 1010040:	c7 85 90 fc ff ff 02 	movl   $0x2,-0x370(%rbp)
 1010047:	00 00 00 
 101004a:	48 8d 85 d8 fe ff ff 	lea    -0x128(%rbp),%rax
 1010051:	48 89 85 80 fc ff ff 	mov    %rax,-0x380(%rbp)
 1010058:	48 89 8d 88 fc ff ff 	mov    %rcx,-0x378(%rbp)
 101005f:	48 8d 95 d8 fe ff ff 	lea    -0x128(%rbp),%rdx
 1010066:	48 8d 35 b3 ee 01 00 	lea    0x1eeb3(%rip),%rsi        # 102ef20 <myl_t_db6bd58975531b7368ca22b8af460e2a11856412c594a38caca68120ceaa09fc>
 101006d:	49 89 fc             	mov    %rdi,%r12
 1010070:	e8 4b 6c 00 00       	call   1016cc0 <myl_qbe_rc_unique_local>
 1010075:	4c 89 e7             	mov    %r12,%rdi
 1010078:	83 f8 00             	cmp    $0x0,%eax
 101007b:	0f 84 0f 0e 00 00    	je     1010e90 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1ee0>
 1010081:	41 bc 00 00 00 00    	mov    $0x0,%r12d
 1010087:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
 101008e:	00 00 
 1010090:	4c 89 a5 08 ff ff ff 	mov    %r12,-0xf8(%rbp)
 1010097:	48 c7 85 10 ff ff ff 	movq   $0x1e8480,-0xf0(%rbp)
 101009e:	80 84 1e 00 
 10100a2:	49 81 fc 80 84 1e 00 	cmp    $0x1e8480,%r12
 10100a9:	0f 9c c0             	setl   %al
 10100ac:	48 0f b6 c0          	movzbq %al,%rax
 10100b0:	48 89 85 08 ff ff ff 	mov    %rax,-0xf8(%rbp)
 10100b7:	0f 8d 03 04 00 00    	jge    10104c0 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1510>
 10100bd:	48 8b b5 d0 fe ff ff 	mov    -0x130(%rbp),%rsi
 10100c4:	48 89 b5 08 ff ff ff 	mov    %rsi,-0xf8(%rbp)
 10100cb:	48 89 b5 e0 fe ff ff 	mov    %rsi,-0x120(%rbp)
 10100d2:	4c 89 a5 08 ff ff ff 	mov    %r12,-0xf8(%rbp)
 10100d9:	48 c7 85 10 ff ff ff 	movq   $0x1eef,-0xf0(%rbp)
 10100e0:	ef 1e 00 00 
 10100e4:	49 69 c4 ef 1e 00 00 	imul   $0x1eef,%r12,%rax
 10100eb:	b9 ff ff ff ff       	mov    $0xffffffff,%ecx
 10100f0:	4d 89 e1             	mov    %r12,%r9
 10100f3:	49 21 c9             	and    %rcx,%r9
 10100f6:	4d 89 e0             	mov    %r12,%r8
 10100f9:	49 c1 e8 20          	shr    $0x20,%r8
 10100fd:	49 69 c9 ef 1e 00 00 	imul   $0x1eef,%r9,%rcx
 1010104:	48 c1 e9 20          	shr    $0x20,%rcx
 1010108:	49 69 d0 ef 1e 00 00 	imul   $0x1eef,%r8,%rdx
 101010f:	48 01 ca             	add    %rcx,%rdx
 1010112:	b9 ff ff ff ff       	mov    $0xffffffff,%ecx
 1010117:	48 21 d1             	and    %rdx,%rcx
 101011a:	48 c1 ea 20          	shr    $0x20,%rdx
 101011e:	4d 6b c9 00          	imul   $0x0,%r9,%r9
 1010122:	4c 01 c9             	add    %r9,%rcx
 1010125:	48 c1 e9 20          	shr    $0x20,%rcx
 1010129:	4d 6b c0 00          	imul   $0x0,%r8,%r8
 101012d:	4c 01 c2             	add    %r8,%rdx
 1010130:	48 01 d1             	add    %rdx,%rcx
 1010133:	49 83 fc 00          	cmp    $0x0,%r12
 1010137:	0f 9c c2             	setl   %dl
 101013a:	48 0f b6 d2          	movzbq %dl,%rdx
 101013e:	48 f7 da             	neg    %rdx
 1010141:	49 89 d0             	mov    %rdx,%r8
 1010144:	49 81 e0 ef 1e 00 00 	and    $0x1eef,%r8
 101014b:	4c 89 e2             	mov    %r12,%rdx
 101014e:	48 83 e2 00          	and    $0x0,%rdx
 1010152:	4c 29 c1             	sub    %r8,%rcx
 1010155:	48 29 d1             	sub    %rdx,%rcx
 1010158:	48 89 c2             	mov    %rax,%rdx
 101015b:	48 c1 fa 3f          	sar    $0x3f,%rdx
 101015f:	48 39 ca             	cmp    %rcx,%rdx
 1010162:	0f 85 3e 03 00 00    	jne    10104a6 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x14f6>
 1010168:	48 89 85 08 ff ff ff 	mov    %rax,-0xf8(%rbp)
 101016f:	48 c7 85 10 ff ff ff 	movq   $0x3e8,-0xf0(%rbp)
 1010176:	e8 03 00 00 
 101017a:	48 b9 00 00 00 00 00 	movabs $0x8000000000000000,%rcx
 1010181:	00 00 80 
 1010184:	48 39 c8             	cmp    %rcx,%rax
 1010187:	0f 94 c1             	sete   %cl
 101018a:	48 0f b6 c9          	movzbq %cl,%rcx
 101018e:	48 83 e1 00          	and    $0x0,%rcx
 1010192:	48 f7 d9             	neg    %rcx
 1010195:	48 81 e1 e9 03 00 00 	and    $0x3e9,%rcx
 101019c:	49 89 c8             	mov    %rcx,%r8
 101019f:	49 81 f0 e8 03 00 00 	xor    $0x3e8,%r8
 10101a6:	48 99                	cqto
 10101a8:	49 f7 f8             	idiv   %r8
 10101ab:	48 89 d1             	mov    %rdx,%rcx
 10101ae:	48 83 f9 00          	cmp    $0x0,%rcx
 10101b2:	0f 95 c0             	setne  %al
 10101b5:	48 0f b6 c0          	movzbq %al,%rax
 10101b9:	4c 89 c2             	mov    %r8,%rdx
 10101bc:	48 31 ca             	xor    %rcx,%rdx
 10101bf:	48 83 fa 00          	cmp    $0x0,%rdx
 10101c3:	0f 9c c2             	setl   %dl
 10101c6:	48 0f b6 d2          	movzbq %dl,%rdx
 10101ca:	48 21 d0             	and    %rdx,%rax
 10101cd:	48 f7 d8             	neg    %rax
 10101d0:	4c 21 c0             	and    %r8,%rax
 10101d3:	48 01 c1             	add    %rax,%rcx
 10101d6:	48 89 8d 08 ff ff ff 	mov    %rcx,-0xf8(%rbp)
 10101dd:	48 89 8d 08 ff ff ff 	mov    %rcx,-0xf8(%rbp)
 10101e4:	48 c7 85 10 ff ff ff 	movq   $0x0,-0xf0(%rbp)
 10101eb:	00 00 00 00 
 10101ef:	48 83 f9 00          	cmp    $0x0,%rcx
 10101f3:	0f 9c c0             	setl   %al
 10101f6:	48 0f b6 c0          	movzbq %al,%rax
 10101fa:	48 89 85 08 ff ff ff 	mov    %rax,-0xf8(%rbp)
 1010201:	7d 51                	jge    1010254 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x12a4>
 1010203:	4c 8b 0e             	mov    (%rsi),%r9
 1010206:	4c 89 8d 08 ff ff ff 	mov    %r9,-0xf8(%rbp)
 101020d:	48 b8 ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rax
 1010214:	ff ff 7f 
 1010217:	49 39 c1             	cmp    %rax,%r9
 101021a:	0f 87 77 02 00 00    	ja     1010497 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x14e7>
 1010220:	4c 89 8d 08 ff ff ff 	mov    %r9,-0xf8(%rbp)
 1010227:	48 89 8d 10 ff ff ff 	mov    %rcx,-0xf0(%rbp)
 101022e:	48 89 c8             	mov    %rcx,%rax
 1010231:	4c 01 c9             	add    %r9,%rcx
 1010234:	4c 89 ca             	mov    %r9,%rdx
 1010237:	48 31 ca             	xor    %rcx,%rdx
 101023a:	49 89 c0             	mov    %rax,%r8
 101023d:	49 31 c8             	xor    %rcx,%r8
 1010240:	4c 21 c2             	and    %r8,%rdx
 1010243:	48 83 fa 00          	cmp    $0x0,%rdx
 1010247:	0f 8c 2f 02 00 00    	jl     101047c <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x14cc>
 101024d:	48 89 8d 08 ff ff ff 	mov    %rcx,-0xf8(%rbp)
 1010254:	48 89 8d 08 ff ff ff 	mov    %rcx,-0xf8(%rbp)
 101025b:	48 8b 06             	mov    (%rsi),%rax
 101025e:	48 39 c1             	cmp    %rax,%rcx
 1010261:	0f 83 08 02 00 00    	jae    101046f <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x14bf>
 1010267:	48 8b 46 20          	mov    0x20(%rsi),%rax
 101026b:	48 8b 04 c8          	mov    (%rax,%rcx,8),%rax
 101026f:	48 89 85 08 ff ff ff 	mov    %rax,-0xf8(%rbp)
 1010276:	48 89 85 e8 fe ff ff 	mov    %rax,-0x118(%rbp)
 101027d:	8b 85 f0 fd ff ff    	mov    -0x210(%rbp),%eax
 1010283:	83 f8 00             	cmp    $0x0,%eax
 1010286:	74 0e                	je     1010296 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x12e6>
 1010288:	4c 89 f6             	mov    %r14,%rsi
 101028b:	49 89 ff             	mov    %rdi,%r15
 101028e:	e8 ad 66 00 00       	call   1016940 <myl_qbe_rc_slot_drop>
 1010293:	4c 89 ff             	mov    %r15,%rdi
 1010296:	48 8b 85 e8 fe ff ff 	mov    -0x118(%rbp),%rax
 101029d:	48 89 85 08 ff ff ff 	mov    %rax,-0xf8(%rbp)
 10102a4:	48 c7 85 10 ff ff ff 	movq   $0x0,-0xf0(%rbp)
 10102ab:	00 00 00 00 
 10102af:	49 89 ff             	mov    %rdi,%r15
 10102b2:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
 10102b9:	48 8d 95 28 ff ff ff 	lea    -0xd8(%rbp),%rdx
 10102c0:	48 8d b5 08 ff ff ff 	lea    -0xf8(%rbp),%rsi
 10102c7:	e8 f4 eb 00 00       	call   101eec0 <myl_native_dictionary_read>
 10102cc:	4c 89 ff             	mov    %r15,%rdi
 10102cf:	89 c1                	mov    %eax,%ecx
 10102d1:	48 8b 45 b8          	mov    -0x48(%rbp),%rax
 10102d5:	83 f9 00             	cmp    $0x0,%ecx
 10102d8:	75 10                	jne    10102ea <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x133a>
 10102da:	48 8b 8d 10 ff ff ff 	mov    -0xf0(%rbp),%rcx
 10102e1:	48 89 8d 08 ff ff ff 	mov    %rcx,-0xf8(%rbp)
 10102e8:	eb 0e                	jmp    10102f8 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1348>
 10102ea:	48 8b 8d 28 ff ff ff 	mov    -0xd8(%rbp),%rcx
 10102f1:	48 89 8d 08 ff ff ff 	mov    %rcx,-0xf8(%rbp)
 10102f8:	8b 8d 18 fe ff ff    	mov    -0x1e8(%rbp),%ecx
 10102fe:	83 f9 00             	cmp    $0x0,%ecx
 1010301:	74 12                	je     1010315 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1365>
 1010303:	4c 89 ee             	mov    %r13,%rsi
 1010306:	49 89 ff             	mov    %rdi,%r15
 1010309:	e8 32 66 00 00       	call   1016940 <myl_qbe_rc_slot_drop>
 101030e:	4c 89 ff             	mov    %r15,%rdi
 1010311:	48 8b 45 b8          	mov    -0x48(%rbp),%rax
 1010315:	48 c7 85 10 ff ff ff 	movq   $0x1,-0xf0(%rbp)
 101031c:	01 00 00 00 
 1010320:	48 8b 95 08 ff ff ff 	mov    -0xf8(%rbp),%rdx
 1010327:	48 b9 fe ff ff ff ff 	movabs $0x7ffffffffffffffe,%rcx
 101032e:	ff ff 7f 
 1010331:	48 39 ca             	cmp    %rcx,%rdx
 1010334:	0f 8f 1e 01 00 00    	jg     1010458 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x14a8>
 101033a:	49 89 d7             	mov    %rdx,%r15
 101033d:	49 83 c7 01          	add    $0x1,%r15
 1010341:	4c 89 bd 08 ff ff ff 	mov    %r15,-0xf8(%rbp)
 1010348:	48 8b 8d d8 fe ff ff 	mov    -0x128(%rbp),%rcx
 101034f:	48 89 8d 08 ff ff ff 	mov    %rcx,-0xf8(%rbp)
 1010356:	8b 8d 18 fe ff ff    	mov    -0x1e8(%rbp),%ecx
 101035c:	83 f9 00             	cmp    $0x0,%ecx
 101035f:	74 16                	je     1010377 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x13c7>
 1010361:	4c 89 ee             	mov    %r13,%rsi
 1010364:	49 89 fe             	mov    %rdi,%r14
 1010367:	e8 d4 65 00 00       	call   1016940 <myl_qbe_rc_slot_drop>
 101036c:	4c 89 f7             	mov    %r14,%rdi
 101036f:	48 8b 45 b8          	mov    -0x48(%rbp),%rax
 1010373:	4c 8b 75 c0          	mov    -0x40(%rbp),%r14
 1010377:	8b 8d 00 fe ff ff    	mov    -0x200(%rbp),%ecx
 101037d:	83 f9 00             	cmp    $0x0,%ecx
 1010380:	74 12                	je     1010394 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x13e4>
 1010382:	48 89 c6             	mov    %rax,%rsi
 1010385:	49 89 fe             	mov    %rdi,%r14
 1010388:	e8 b3 65 00 00       	call   1016940 <myl_qbe_rc_slot_drop>
 101038d:	4c 89 f7             	mov    %r14,%rdi
 1010390:	4c 8b 75 c0          	mov    -0x40(%rbp),%r14
 1010394:	48 8b b5 d8 fe ff ff 	mov    -0x128(%rbp),%rsi
 101039b:	48 89 b5 f0 fe ff ff 	mov    %rsi,-0x110(%rbp)
 10103a2:	48 8b 85 e8 fe ff ff 	mov    -0x118(%rbp),%rax
 10103a9:	48 89 85 08 ff ff ff 	mov    %rax,-0xf8(%rbp)
 10103b0:	4c 89 bd 10 ff ff ff 	mov    %r15,-0xf0(%rbp)
 10103b7:	48 8d 8d 10 ff ff ff 	lea    -0xf0(%rbp),%rcx
 10103be:	48 8d 95 08 ff ff ff 	lea    -0xf8(%rbp),%rdx
 10103c5:	49 89 ff             	mov    %rdi,%r15
 10103c8:	48 89 df             	mov    %rbx,%rdi
 10103cb:	e8 70 f0 00 00       	call   101f440 <myl_native_dictionary_write>
 10103d0:	4c 89 ff             	mov    %r15,%rdi
 10103d3:	89 c1                	mov    %eax,%ecx
 10103d5:	48 8b 45 b8          	mov    -0x48(%rbp),%rax
 10103d9:	83 f9 00             	cmp    $0x0,%ecx
 10103dc:	74 73                	je     1010451 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x14a1>
 10103de:	48 c7 85 08 ff ff ff 	movq   $0x0,-0xf8(%rbp)
 10103e5:	00 00 00 00 
 10103e9:	8b 8d 18 fe ff ff    	mov    -0x1e8(%rbp),%ecx
 10103ef:	83 f9 00             	cmp    $0x0,%ecx
 10103f2:	74 12                	je     1010406 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1456>
 10103f4:	4c 89 ee             	mov    %r13,%rsi
 10103f7:	49 89 ff             	mov    %rdi,%r15
 10103fa:	e8 41 65 00 00       	call   1016940 <myl_qbe_rc_slot_drop>
 10103ff:	4c 89 ff             	mov    %r15,%rdi
 1010402:	48 8b 45 b8          	mov    -0x48(%rbp),%rax
 1010406:	4c 89 a5 08 ff ff ff 	mov    %r12,-0xf8(%rbp)
 101040d:	48 c7 85 10 ff ff ff 	movq   $0x1,-0xf0(%rbp)
 1010414:	01 00 00 00 
 1010418:	48 b9 fe ff ff ff ff 	movabs $0x7ffffffffffffffe,%rcx
 101041f:	ff ff 7f 
 1010422:	49 39 cc             	cmp    %rcx,%r12
 1010425:	7f 10                	jg     1010437 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1487>
 1010427:	49 83 c4 01          	add    $0x1,%r12
 101042b:	4c 89 a5 08 ff ff ff 	mov    %r12,-0xf8(%rbp)
 1010432:	e9 59 fc ff ff       	jmp    1010090 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x10e0>
 1010437:	4c 89 e2             	mov    %r12,%rdx
 101043a:	41 b8 40 00 00 00    	mov    $0x40,%r8d
 1010440:	b9 01 00 00 00       	mov    $0x1,%ecx
 1010445:	be 00 00 00 00       	mov    $0x0,%esi
 101044a:	e8 81 6b 00 00       	call   1016fd0 <myl_qbe_fail_overflow_op>
 101044f:	0f 0b                	ud2
 1010451:	e8 7a 6a 00 00       	call   1016ed0 <myl_qbe_fail_allocation>
 1010456:	0f 0b                	ud2
 1010458:	41 b8 40 00 00 00    	mov    $0x40,%r8d
 101045e:	b9 01 00 00 00       	mov    $0x1,%ecx
 1010463:	be 00 00 00 00       	mov    $0x0,%esi
 1010468:	e8 63 6b 00 00       	call   1016fd0 <myl_qbe_fail_overflow_op>
 101046d:	0f 0b                	ud2
 101046f:	48 89 c2             	mov    %rax,%rdx
 1010472:	48 89 ce             	mov    %rcx,%rsi
 1010475:	e8 e6 6a 00 00       	call   1016f60 <myl_qbe_fail_normalized_index_bounds>
 101047a:	0f 0b                	ud2
 101047c:	48 89 c1             	mov    %rax,%rcx
 101047f:	4c 89 ce             	mov    %r9,%rsi
 1010482:	41 b8 40 00 00 00    	mov    $0x40,%r8d
 1010488:	48 89 f2             	mov    %rsi,%rdx
 101048b:	be 00 00 00 00       	mov    $0x0,%esi
 1010490:	e8 3b 6b 00 00       	call   1016fd0 <myl_qbe_fail_overflow_op>
 1010495:	0f 0b                	ud2
 1010497:	4c 89 ce             	mov    %r9,%rsi
 101049a:	ba 40 01 00 00       	mov    $0x140,%edx
 101049f:	e8 6c 6c 00 00       	call   1017110 <myl_qbe_fail_cast>
 10104a4:	0f 0b                	ud2
 10104a6:	4c 89 e2             	mov    %r12,%rdx
 10104a9:	41 b8 40 00 00 00    	mov    $0x40,%r8d
 10104af:	b9 ef 1e 00 00       	mov    $0x1eef,%ecx
 10104b4:	be 02 00 00 00       	mov    $0x2,%esi
 10104b9:	e8 12 6b 00 00       	call   1016fd0 <myl_qbe_fail_overflow_op>
 10104be:	0f 0b                	ud2
 10104c0:	4c 8b 75 a8          	mov    -0x58(%rbp),%r14
 10104c4:	4c 8b 7d b0          	mov    -0x50(%rbp),%r15
 10104c8:	48 c7 85 08 ff ff ff 	movq   $0x0,-0xf8(%rbp)
 10104cf:	00 00 00 00 
 10104d3:	48 8b b5 d0 fe ff ff 	mov    -0x130(%rbp),%rsi
 10104da:	8b 85 70 fc ff ff    	mov    -0x390(%rbp),%eax
 10104e0:	83 f8 08             	cmp    $0x8,%eax
 10104e3:	0f 94 c0             	sete   %al
 10104e6:	0f b6 c0             	movzbl %al,%eax
 10104e9:	8b 8d e0 fd ff ff    	mov    -0x220(%rbp),%ecx
 10104ef:	85 c1                	test   %eax,%ecx
 10104f1:	75 0c                	jne    10104ff <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x154f>
 10104f3:	48 89 b5 08 ff ff ff 	mov    %rsi,-0xf8(%rbp)
 10104fa:	e9 d7 00 00 00       	jmp    10105d6 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1626>
 10104ff:	48 c7 85 58 fe ff ff 	movq   $0x0,-0x1a8(%rbp)
 1010506:	00 00 00 00 
 101050a:	48 8d 95 58 fe ff ff 	lea    -0x1a8(%rbp),%rdx
 1010511:	49 89 fc             	mov    %rdi,%r12
 1010514:	48 89 df             	mov    %rbx,%rdi
 1010517:	e8 b4 38 01 00       	call   1023dd0 <myl_rc_hold_acquire>
 101051c:	4c 89 e7             	mov    %r12,%rdi
 101051f:	89 c6                	mov    %eax,%esi
 1010521:	49 89 fc             	mov    %rdi,%r12
 1010524:	e8 47 62 00 00       	call   1016770 <myl_qbe_rc_status>
 1010529:	4c 89 e7             	mov    %r12,%rdi
 101052c:	83 f8 00             	cmp    $0x0,%eax
 101052f:	0f 84 5b 09 00 00    	je     1010e90 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1ee0>
 1010535:	48 8d 05 94 e8 01 00 	lea    0x1e894(%rip),%rax        # 102edd0 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b>
 101053c:	48 89 85 98 fd ff ff 	mov    %rax,-0x268(%rbp)
 1010543:	c7 85 b0 fd ff ff 02 	movl   $0x2,-0x250(%rbp)
 101054a:	00 00 00 
 101054d:	48 8d 85 58 fe ff ff 	lea    -0x1a8(%rbp),%rax
 1010554:	48 89 85 a0 fd ff ff 	mov    %rax,-0x260(%rbp)
 101055b:	4c 89 b5 a8 fd ff ff 	mov    %r14,-0x258(%rbp)
 1010562:	c7 85 b0 fd ff ff 08 	movl   $0x8,-0x250(%rbp)
 1010569:	00 00 00 
 101056c:	c7 85 30 fe ff ff 01 	movl   $0x1,-0x1d0(%rbp)
 1010573:	00 00 00 
 1010576:	48 8b b5 58 fe ff ff 	mov    -0x1a8(%rbp),%rsi
 101057d:	48 89 b5 40 fe ff ff 	mov    %rsi,-0x1c0(%rbp)
 1010584:	48 8d 05 45 e8 01 00 	lea    0x1e845(%rip),%rax        # 102edd0 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b>
 101058b:	48 89 85 38 fd ff ff 	mov    %rax,-0x2c8(%rbp)
 1010592:	c7 85 50 fd ff ff 02 	movl   $0x2,-0x2b0(%rbp)
 1010599:	00 00 00 
 101059c:	48 8d 85 40 fe ff ff 	lea    -0x1c0(%rbp),%rax
 10105a3:	48 89 85 40 fd ff ff 	mov    %rax,-0x2c0(%rbp)
 10105aa:	4c 89 bd 48 fd ff ff 	mov    %r15,-0x2b8(%rbp)
 10105b1:	c7 85 50 fd ff ff 08 	movl   $0x8,-0x2b0(%rbp)
 10105b8:	00 00 00 
 10105bb:	c7 85 18 fe ff ff 01 	movl   $0x1,-0x1e8(%rbp)
 10105c2:	00 00 00 
 10105c5:	c7 85 30 fe ff ff 00 	movl   $0x0,-0x1d0(%rbp)
 10105cc:	00 00 00 
 10105cf:	48 89 b5 08 ff ff ff 	mov    %rsi,-0xf8(%rbp)
 10105d6:	48 c7 85 58 fe ff ff 	movq   $0x0,-0x1a8(%rbp)
 10105dd:	00 00 00 00 
 10105e1:	48 8d 95 58 fe ff ff 	lea    -0x1a8(%rbp),%rdx
 10105e8:	49 89 fc             	mov    %rdi,%r12
 10105eb:	48 89 df             	mov    %rbx,%rdi
 10105ee:	e8 dd 37 01 00       	call   1023dd0 <myl_rc_hold_acquire>
 10105f3:	4c 89 e7             	mov    %r12,%rdi
 10105f6:	89 c6                	mov    %eax,%esi
 10105f8:	49 89 fc             	mov    %rdi,%r12
 10105fb:	e8 70 61 00 00       	call   1016770 <myl_qbe_rc_status>
 1010600:	4c 89 e7             	mov    %r12,%rdi
 1010603:	4c 8b 65 98          	mov    -0x68(%rbp),%r12
 1010607:	48 8b 75 a0          	mov    -0x60(%rbp),%rsi
 101060b:	83 f8 00             	cmp    $0x0,%eax
 101060e:	0f 84 7c 08 00 00    	je     1010e90 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1ee0>
 1010614:	48 8d 05 b5 e7 01 00 	lea    0x1e7b5(%rip),%rax        # 102edd0 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b>
 101061b:	48 89 85 98 fd ff ff 	mov    %rax,-0x268(%rbp)
 1010622:	c7 85 b0 fd ff ff 02 	movl   $0x2,-0x250(%rbp)
 1010629:	00 00 00 
 101062c:	48 8d 85 58 fe ff ff 	lea    -0x1a8(%rbp),%rax
 1010633:	48 89 85 a0 fd ff ff 	mov    %rax,-0x260(%rbp)
 101063a:	4c 89 b5 a8 fd ff ff 	mov    %r14,-0x258(%rbp)
 1010641:	c7 85 b0 fd ff ff 08 	movl   $0x8,-0x250(%rbp)
 1010648:	00 00 00 
 101064b:	c7 85 30 fe ff ff 01 	movl   $0x1,-0x1d0(%rbp)
 1010652:	00 00 00 
 1010655:	8b 85 18 fe ff ff    	mov    -0x1e8(%rbp),%eax
 101065b:	83 f8 00             	cmp    $0x0,%eax
 101065e:	74 16                	je     1010676 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x16c6>
 1010660:	4c 89 ee             	mov    %r13,%rsi
 1010663:	49 89 fc             	mov    %rdi,%r12
 1010666:	e8 d5 62 00 00       	call   1016940 <myl_qbe_rc_slot_drop>
 101066b:	4c 89 e7             	mov    %r12,%rdi
 101066e:	4c 8b 65 98          	mov    -0x68(%rbp),%r12
 1010672:	48 8b 75 a0          	mov    -0x60(%rbp),%rsi
 1010676:	48 8b 85 58 fe ff ff 	mov    -0x1a8(%rbp),%rax
 101067d:	48 89 85 40 fe ff ff 	mov    %rax,-0x1c0(%rbp)
 1010684:	48 8d 0d 45 e7 01 00 	lea    0x1e745(%rip),%rcx        # 102edd0 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b>
 101068b:	48 89 8d 38 fd ff ff 	mov    %rcx,-0x2c8(%rbp)
 1010692:	c7 85 50 fd ff ff 02 	movl   $0x2,-0x2b0(%rbp)
 1010699:	00 00 00 
 101069c:	48 8d 8d 40 fe ff ff 	lea    -0x1c0(%rbp),%rcx
 10106a3:	48 89 8d 40 fd ff ff 	mov    %rcx,-0x2c0(%rbp)
 10106aa:	4c 89 bd 48 fd ff ff 	mov    %r15,-0x2b8(%rbp)
 10106b1:	c7 85 50 fd ff ff 08 	movl   $0x8,-0x2b0(%rbp)
 10106b8:	00 00 00 
 10106bb:	c7 85 18 fe ff ff 01 	movl   $0x1,-0x1e8(%rbp)
 10106c2:	00 00 00 
 10106c5:	c7 85 30 fe ff ff 00 	movl   $0x0,-0x1d0(%rbp)
 10106cc:	00 00 00 
 10106cf:	48 89 85 08 ff ff ff 	mov    %rax,-0xf8(%rbp)
 10106d6:	48 89 85 58 fe ff ff 	mov    %rax,-0x1a8(%rbp)
 10106dd:	48 8d 05 ec e6 01 00 	lea    0x1e6ec(%rip),%rax        # 102edd0 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b>
 10106e4:	48 89 85 98 fd ff ff 	mov    %rax,-0x268(%rbp)
 10106eb:	c7 85 b0 fd ff ff 02 	movl   $0x2,-0x250(%rbp)
 10106f2:	00 00 00 
 10106f5:	48 8d 85 58 fe ff ff 	lea    -0x1a8(%rbp),%rax
 10106fc:	48 89 85 a0 fd ff ff 	mov    %rax,-0x260(%rbp)
 1010703:	4c 89 b5 a8 fd ff ff 	mov    %r14,-0x258(%rbp)
 101070a:	c7 85 b0 fd ff ff 08 	movl   $0x8,-0x250(%rbp)
 1010711:	00 00 00 
 1010714:	c7 85 30 fe ff ff 01 	movl   $0x1,-0x1d0(%rbp)
 101071b:	00 00 00 
 101071e:	c7 85 18 fe ff ff 00 	movl   $0x0,-0x1e8(%rbp)
 1010725:	00 00 00 
 1010728:	8b 85 08 fe ff ff    	mov    -0x1f8(%rbp),%eax
 101072e:	83 f8 00             	cmp    $0x0,%eax
 1010731:	74 0b                	je     101073e <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x178e>
 1010733:	49 89 fe             	mov    %rdi,%r14
 1010736:	e8 05 62 00 00       	call   1016940 <myl_qbe_rc_slot_drop>
 101073b:	4c 89 f7             	mov    %r14,%rdi
 101073e:	48 8b 85 58 fe ff ff 	mov    -0x1a8(%rbp),%rax
 1010745:	48 89 85 f8 fe ff ff 	mov    %rax,-0x108(%rbp)
 101074c:	48 8d 0d 7d e6 01 00 	lea    0x1e67d(%rip),%rcx        # 102edd0 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b>
 1010753:	48 89 8d f8 fc ff ff 	mov    %rcx,-0x308(%rbp)
 101075a:	c7 85 10 fd ff ff 02 	movl   $0x2,-0x2f0(%rbp)
 1010761:	00 00 00 
 1010764:	48 8d 8d f8 fe ff ff 	lea    -0x108(%rbp),%rcx
 101076b:	48 89 8d 00 fd ff ff 	mov    %rcx,-0x300(%rbp)
 1010772:	4c 89 a5 08 fd ff ff 	mov    %r12,-0x2f8(%rbp)
 1010779:	c7 85 10 fd ff ff 08 	movl   $0x8,-0x2f0(%rbp)
 1010780:	00 00 00 
 1010783:	c7 85 08 fe ff ff 01 	movl   $0x1,-0x1f8(%rbp)
 101078a:	00 00 00 
 101078d:	c7 85 30 fe ff ff 00 	movl   $0x0,-0x1d0(%rbp)
 1010794:	00 00 00 
 1010797:	48 c7 85 08 ff ff ff 	movq   $0x0,-0xf8(%rbp)
 101079e:	00 00 00 00 
 10107a2:	48 8b 30             	mov    (%rax),%rsi
 10107a5:	48 89 b5 08 ff ff ff 	mov    %rsi,-0xf8(%rbp)
 10107ac:	48 b9 ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rcx
 10107b3:	ff ff 7f 
 10107b6:	48 39 ce             	cmp    %rcx,%rsi
 10107b9:	0f 87 c5 06 00 00    	ja     1010e84 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1ed4>
 10107bf:	48 89 b5 08 ff ff ff 	mov    %rsi,-0xf8(%rbp)
 10107c6:	49 89 f4             	mov    %rsi,%r12
 10107c9:	48 c7 45 90 00 00 00 	movq   $0x0,-0x70(%rbp)
 10107d0:	00 
 10107d1:	41 be 00 00 00 00    	mov    $0x0,%r14d
 10107d7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
 10107de:	00 00 
 10107e0:	4c 89 b5 08 ff ff ff 	mov    %r14,-0xf8(%rbp)
 10107e7:	4c 89 a5 10 ff ff ff 	mov    %r12,-0xf0(%rbp)
 10107ee:	4d 39 e6             	cmp    %r12,%r14
 10107f1:	0f 9c c1             	setl   %cl
 10107f4:	48 0f b6 c9          	movzbq %cl,%rcx
 10107f8:	48 89 8d 08 ff ff ff 	mov    %rcx,-0xf8(%rbp)
 10107ff:	0f 8d cd 05 00 00    	jge    1010dd2 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1e22>
 1010805:	4c 89 a5 08 ff ff ff 	mov    %r12,-0xf8(%rbp)
 101080c:	48 8b 08             	mov    (%rax),%rcx
 101080f:	49 39 cc             	cmp    %rcx,%r12
 1010812:	0f 85 b3 05 00 00    	jne    1010dcb <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1e1b>
 1010818:	48 c7 85 08 ff ff ff 	movq   $0x0,-0xf8(%rbp)
 101081f:	00 00 00 00 
 1010823:	4c 89 b5 08 ff ff ff 	mov    %r14,-0xf8(%rbp)
 101082a:	48 8b 08             	mov    (%rax),%rcx
 101082d:	49 39 ce             	cmp    %rcx,%r14
 1010830:	0f 83 88 05 00 00    	jae    1010dbe <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1e0e>
 1010836:	48 8b 40 20          	mov    0x20(%rax),%rax
 101083a:	4a 8b 04 f0          	mov    (%rax,%r14,8),%rax
 101083e:	48 89 85 08 ff ff ff 	mov    %rax,-0xf8(%rbp)
 1010845:	48 8d 8d 08 ff ff ff 	lea    -0xf8(%rbp),%rcx
 101084c:	48 8d 95 58 fe ff ff 	lea    -0x1a8(%rbp),%rdx
 1010853:	48 8d 35 06 e5 01 00 	lea    0x1e506(%rip),%rsi        # 102ed60 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a>
 101085a:	49 89 ff             	mov    %rdi,%r15
 101085d:	48 89 df             	mov    %rbx,%rdi
 1010860:	e8 5b b2 01 00       	call   102bac0 <myl_rc_native_loan>
 1010865:	4c 89 ff             	mov    %r15,%rdi
 1010868:	83 f8 00             	cmp    $0x0,%eax
 101086b:	0f 84 30 05 00 00    	je     1010da1 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1df1>
 1010871:	48 8d 05 e8 e4 01 00 	lea    0x1e4e8(%rip),%rax        # 102ed60 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a>
 1010878:	48 89 85 98 fd ff ff 	mov    %rax,-0x268(%rbp)
 101087f:	c7 85 b0 fd ff ff 02 	movl   $0x2,-0x250(%rbp)
 1010886:	00 00 00 
 1010889:	c7 85 b0 fd ff ff 10 	movl   $0x10,-0x250(%rbp)
 1010890:	00 00 00 
 1010893:	c7 85 30 fe ff ff 01 	movl   $0x1,-0x1d0(%rbp)
 101089a:	00 00 00 
 101089d:	48 8b 85 58 fe ff ff 	mov    -0x1a8(%rbp),%rax
 10108a4:	48 89 85 40 fe ff ff 	mov    %rax,-0x1c0(%rbp)
 10108ab:	48 8d 05 ae e4 01 00 	lea    0x1e4ae(%rip),%rax        # 102ed60 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a>
 10108b2:	48 89 85 38 fd ff ff 	mov    %rax,-0x2c8(%rbp)
 10108b9:	c7 85 50 fd ff ff 02 	movl   $0x2,-0x2b0(%rbp)
 10108c0:	00 00 00 
 10108c3:	c7 85 50 fd ff ff 10 	movl   $0x10,-0x2b0(%rbp)
 10108ca:	00 00 00 
 10108cd:	c7 85 30 fe ff ff 00 	movl   $0x0,-0x1d0(%rbp)
 10108d4:	00 00 00 
 10108d7:	c7 85 18 fe ff ff 01 	movl   $0x1,-0x1e8(%rbp)
 10108de:	00 00 00 
 10108e1:	48 8b 85 40 fe ff ff 	mov    -0x1c0(%rbp),%rax
 10108e8:	48 89 85 08 ff ff ff 	mov    %rax,-0xf8(%rbp)
 10108ef:	48 8d 8d 08 ff ff ff 	lea    -0xf8(%rbp),%rcx
 10108f6:	48 8d 95 58 fe ff ff 	lea    -0x1a8(%rbp),%rdx
 10108fd:	48 8d 35 5c e4 01 00 	lea    0x1e45c(%rip),%rsi        # 102ed60 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a>
 1010904:	49 89 ff             	mov    %rdi,%r15
 1010907:	48 89 df             	mov    %rbx,%rdi
 101090a:	e8 b1 b1 01 00       	call   102bac0 <myl_rc_native_loan>
 101090f:	4c 89 ff             	mov    %r15,%rdi
 1010912:	48 8b 4d 90          	mov    -0x70(%rbp),%rcx
 1010916:	4c 8b 95 58 ff ff ff 	mov    -0xa8(%rbp),%r10
 101091d:	48 8b b5 40 ff ff ff 	mov    -0xc0(%rbp),%rsi
 1010924:	83 f8 00             	cmp    $0x0,%eax
 1010927:	0f 84 57 04 00 00    	je     1010d84 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1dd4>
 101092d:	48 8d 05 2c e4 01 00 	lea    0x1e42c(%rip),%rax        # 102ed60 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a>
 1010934:	48 89 85 98 fd ff ff 	mov    %rax,-0x268(%rbp)
 101093b:	c7 85 b0 fd ff ff 02 	movl   $0x2,-0x250(%rbp)
 1010942:	00 00 00 
 1010945:	c7 85 b0 fd ff ff 10 	movl   $0x10,-0x250(%rbp)
 101094c:	00 00 00 
 101094f:	c7 85 30 fe ff ff 01 	movl   $0x1,-0x1d0(%rbp)
 1010956:	00 00 00 
 1010959:	8b 85 18 fe ff ff    	mov    -0x1e8(%rbp),%eax
 101095f:	83 f8 00             	cmp    $0x0,%eax
 1010962:	74 20                	je     1010984 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x19d4>
 1010964:	4c 89 ee             	mov    %r13,%rsi
 1010967:	49 89 ff             	mov    %rdi,%r15
 101096a:	e8 d1 5f 00 00       	call   1016940 <myl_qbe_rc_slot_drop>
 101096f:	4c 89 ff             	mov    %r15,%rdi
 1010972:	48 8b 4d 90          	mov    -0x70(%rbp),%rcx
 1010976:	4c 8b 95 58 ff ff ff 	mov    -0xa8(%rbp),%r10
 101097d:	48 8b b5 40 ff ff ff 	mov    -0xc0(%rbp),%rsi
 1010984:	8b 85 10 fe ff ff    	mov    -0x1f0(%rbp),%eax
 101098a:	83 f8 00             	cmp    $0x0,%eax
 101098d:	74 16                	je     10109a5 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x19f5>
 101098f:	49 89 ff             	mov    %rdi,%r15
 1010992:	e8 a9 5f 00 00       	call   1016940 <myl_qbe_rc_slot_drop>
 1010997:	4c 89 ff             	mov    %r15,%rdi
 101099a:	48 8b 4d 90          	mov    -0x70(%rbp),%rcx
 101099e:	4c 8b 95 58 ff ff ff 	mov    -0xa8(%rbp),%r10
 10109a5:	48 8b 85 58 fe ff ff 	mov    -0x1a8(%rbp),%rax
 10109ac:	48 89 85 00 ff ff ff 	mov    %rax,-0x100(%rbp)
 10109b3:	c7 85 30 fe ff ff 00 	movl   $0x0,-0x1d0(%rbp)
 10109ba:	00 00 00 
 10109bd:	48 8d 05 9c e3 01 00 	lea    0x1e39c(%rip),%rax        # 102ed60 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a>
 10109c4:	48 89 85 18 fd ff ff 	mov    %rax,-0x2e8(%rbp)
 10109cb:	c7 85 30 fd ff ff 02 	movl   $0x2,-0x2d0(%rbp)
 10109d2:	00 00 00 
 10109d5:	48 8d 85 00 ff ff ff 	lea    -0x100(%rbp),%rax
 10109dc:	48 89 85 20 fd ff ff 	mov    %rax,-0x2e0(%rbp)
 10109e3:	4c 89 95 28 fd ff ff 	mov    %r10,-0x2d8(%rbp)
 10109ea:	8b 85 b0 fd ff ff    	mov    -0x250(%rbp),%eax
 10109f0:	89 85 30 fd ff ff    	mov    %eax,-0x2d0(%rbp)
 10109f6:	c7 85 10 fe ff ff 01 	movl   $0x1,-0x1f0(%rbp)
 10109fd:	00 00 00 
 1010a00:	48 89 8d 08 ff ff ff 	mov    %rcx,-0xf8(%rbp)
 1010a07:	49 89 ff             	mov    %rdi,%r15
 1010a0a:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
 1010a11:	48 89 bd 10 ff ff ff 	mov    %rdi,-0xf0(%rbp)
 1010a18:	48 8b 85 00 ff ff ff 	mov    -0x100(%rbp),%rax
 1010a1f:	48 89 85 18 ff ff ff 	mov    %rax,-0xe8(%rbp)
 1010a26:	48 8d 95 20 ff ff ff 	lea    -0xe0(%rbp),%rdx
 1010a2d:	48 8d b5 18 ff ff ff 	lea    -0xe8(%rbp),%rsi
 1010a34:	e8 87 e4 00 00       	call   101eec0 <myl_native_dictionary_read>
 1010a39:	4c 89 ff             	mov    %r15,%rdi
 1010a3c:	4c 8b 8d 50 ff ff ff 	mov    -0xb0(%rbp),%r9
 1010a43:	4c 8b 85 48 ff ff ff 	mov    -0xb8(%rbp),%r8
 1010a4a:	48 8b b5 40 ff ff ff 	mov    -0xc0(%rbp),%rsi
 1010a51:	83 f8 00             	cmp    $0x0,%eax
 1010a54:	0f 84 20 03 00 00    	je     1010d7a <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1dca>
 1010a5a:	48 8b 85 20 ff ff ff 	mov    -0xe0(%rbp),%rax
 1010a61:	48 89 85 10 ff ff ff 	mov    %rax,-0xf0(%rbp)
 1010a68:	8b 85 20 fe ff ff    	mov    -0x1e0(%rbp),%eax
 1010a6e:	83 f8 00             	cmp    $0x0,%eax
 1010a71:	74 1c                	je     1010a8f <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1adf>
 1010a73:	4c 89 c6             	mov    %r8,%rsi
 1010a76:	49 89 ff             	mov    %rdi,%r15
 1010a79:	e8 c2 5e 00 00       	call   1016940 <myl_qbe_rc_slot_drop>
 1010a7e:	4c 89 ff             	mov    %r15,%rdi
 1010a81:	4c 8b 8d 50 ff ff ff 	mov    -0xb0(%rbp),%r9
 1010a88:	48 8b b5 40 ff ff ff 	mov    -0xc0(%rbp),%rsi
 1010a8f:	8b 85 28 fe ff ff    	mov    -0x1d8(%rbp),%eax
 1010a95:	83 f8 00             	cmp    $0x0,%eax
 1010a98:	74 1c                	je     1010ab6 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1b06>
 1010a9a:	4c 89 ce             	mov    %r9,%rsi
 1010a9d:	49 89 ff             	mov    %rdi,%r15
 1010aa0:	e8 9b 5e 00 00       	call   1016940 <myl_qbe_rc_slot_drop>
 1010aa5:	4c 89 ff             	mov    %r15,%rdi
 1010aa8:	4c 8b 8d 50 ff ff ff 	mov    -0xb0(%rbp),%r9
 1010aaf:	48 8b b5 40 ff ff ff 	mov    -0xc0(%rbp),%rsi
 1010ab6:	48 8b 85 00 ff ff ff 	mov    -0x100(%rbp),%rax
 1010abd:	48 89 85 18 ff ff ff 	mov    %rax,-0xe8(%rbp)
 1010ac4:	48 8b 00             	mov    (%rax),%rax
 1010ac7:	48 89 85 18 ff ff ff 	mov    %rax,-0xe8(%rbp)
 1010ace:	8b 85 28 fe ff ff    	mov    -0x1d8(%rbp),%eax
 1010ad4:	83 f8 00             	cmp    $0x0,%eax
 1010ad7:	74 15                	je     1010aee <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1b3e>
 1010ad9:	4c 89 ce             	mov    %r9,%rsi
 1010adc:	49 89 ff             	mov    %rdi,%r15
 1010adf:	e8 5c 5e 00 00       	call   1016940 <myl_qbe_rc_slot_drop>
 1010ae4:	4c 89 ff             	mov    %r15,%rdi
 1010ae7:	48 8b b5 40 ff ff ff 	mov    -0xc0(%rbp),%rsi
 1010aee:	48 8b 85 18 ff ff ff 	mov    -0xe8(%rbp),%rax
 1010af5:	48 8b 95 10 ff ff ff 	mov    -0xf0(%rbp),%rdx
 1010afc:	48 89 c1             	mov    %rax,%rcx
 1010aff:	48 0f af ca          	imul   %rdx,%rcx
 1010b03:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
 1010b09:	49 89 d1             	mov    %rdx,%r9
 1010b0c:	4d 21 c1             	and    %r8,%r9
 1010b0f:	49 89 d2             	mov    %rdx,%r10
 1010b12:	49 c1 ea 20          	shr    $0x20,%r10
 1010b16:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
 1010b1c:	49 89 c3             	mov    %rax,%r11
 1010b1f:	4d 21 c3             	and    %r8,%r11
 1010b22:	49 89 c7             	mov    %rax,%r15
 1010b25:	49 c1 ef 20          	shr    $0x20,%r15
 1010b29:	4d 89 c8             	mov    %r9,%r8
 1010b2c:	4d 0f af c3          	imul   %r11,%r8
 1010b30:	49 c1 e8 20          	shr    $0x20,%r8
 1010b34:	4d 0f af da          	imul   %r10,%r11
 1010b38:	4d 01 d8             	add    %r11,%r8
 1010b3b:	41 bb ff ff ff ff    	mov    $0xffffffff,%r11d
 1010b41:	4c 89 5d 88          	mov    %r11,-0x78(%rbp)
 1010b45:	4d 89 c3             	mov    %r8,%r11
 1010b48:	4c 23 5d 88          	and    -0x78(%rbp),%r11
 1010b4c:	4c 89 9d 78 ff ff ff 	mov    %r11,-0x88(%rbp)
 1010b53:	4d 89 c3             	mov    %r8,%r11
 1010b56:	49 c1 eb 20          	shr    $0x20,%r11
 1010b5a:	4c 89 9d 68 ff ff ff 	mov    %r11,-0x98(%rbp)
 1010b61:	4c 8b 85 48 ff ff ff 	mov    -0xb8(%rbp),%r8
 1010b68:	4d 0f af cf          	imul   %r15,%r9
 1010b6c:	4c 89 4d 80          	mov    %r9,-0x80(%rbp)
 1010b70:	4c 8b 8d 50 ff ff ff 	mov    -0xb0(%rbp),%r9
 1010b77:	4c 8b 9d 78 ff ff ff 	mov    -0x88(%rbp),%r11
 1010b7e:	4c 03 5d 80          	add    -0x80(%rbp),%r11
 1010b82:	4c 89 9d 70 ff ff ff 	mov    %r11,-0x90(%rbp)
 1010b89:	4c 8b 9d 70 ff ff ff 	mov    -0x90(%rbp),%r11
 1010b90:	49 c1 eb 20          	shr    $0x20,%r11
 1010b94:	4c 89 9d 60 ff ff ff 	mov    %r11,-0xa0(%rbp)
 1010b9b:	4c 8b 9d 68 ff ff ff 	mov    -0x98(%rbp),%r11
 1010ba2:	4d 0f af fa          	imul   %r10,%r15
 1010ba6:	4c 8b 95 60 ff ff ff 	mov    -0xa0(%rbp),%r10
 1010bad:	4d 01 fb             	add    %r15,%r11
 1010bb0:	4d 01 da             	add    %r11,%r10
 1010bb3:	48 83 fa 00          	cmp    $0x0,%rdx
 1010bb7:	41 0f 9c c3          	setl   %r11b
 1010bbb:	4d 0f b6 db          	movzbq %r11b,%r11
 1010bbf:	48 83 f8 00          	cmp    $0x0,%rax
 1010bc3:	41 0f 9c c7          	setl   %r15b
 1010bc7:	4d 0f b6 ff          	movzbq %r15b,%r15
 1010bcb:	49 f7 db             	neg    %r11
 1010bce:	49 f7 df             	neg    %r15
 1010bd1:	49 21 c3             	and    %rax,%r11
 1010bd4:	49 21 d7             	and    %rdx,%r15
 1010bd7:	49 f7 db             	neg    %r11
 1010bda:	4d 01 d3             	add    %r10,%r11
 1010bdd:	4c 8b 95 58 ff ff ff 	mov    -0xa8(%rbp),%r10
 1010be4:	4d 29 fb             	sub    %r15,%r11
 1010be7:	49 89 cf             	mov    %rcx,%r15
 1010bea:	49 c1 ff 3f          	sar    $0x3f,%r15
 1010bee:	4d 39 df             	cmp    %r11,%r15
 1010bf1:	0f 85 6e 01 00 00    	jne    1010d65 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1db5>
 1010bf7:	48 89 8d 10 ff ff ff 	mov    %rcx,-0xf0(%rbp)
 1010bfe:	48 8b 95 08 ff ff ff 	mov    -0xf8(%rbp),%rdx
 1010c05:	48 89 c8             	mov    %rcx,%rax
 1010c08:	48 01 d0             	add    %rdx,%rax
 1010c0b:	49 89 d3             	mov    %rdx,%r11
 1010c0e:	49 31 c3             	xor    %rax,%r11
 1010c11:	49 89 cf             	mov    %rcx,%r15
 1010c14:	49 31 c7             	xor    %rax,%r15
 1010c17:	4d 21 fb             	and    %r15,%r11
 1010c1a:	49 83 fb 00          	cmp    $0x0,%r11
 1010c1e:	0f 8c 2f 01 00 00    	jl     1010d53 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1da3>
 1010c24:	48 89 85 08 ff ff ff 	mov    %rax,-0xf8(%rbp)
 1010c2b:	48 c7 85 10 ff ff ff 	movq   $0xf4243,-0xf0(%rbp)
 1010c32:	43 42 0f 00 
 1010c36:	48 b9 00 00 00 00 00 	movabs $0x8000000000000000,%rcx
 1010c3d:	00 00 80 
 1010c40:	48 39 c8             	cmp    %rcx,%rax
 1010c43:	0f 94 c1             	sete   %cl
 1010c46:	48 0f b6 c9          	movzbq %cl,%rcx
 1010c4a:	48 83 e1 00          	and    $0x0,%rcx
 1010c4e:	48 f7 d9             	neg    %rcx
 1010c51:	48 81 e1 42 42 0f 00 	and    $0xf4242,%rcx
 1010c58:	49 89 cb             	mov    %rcx,%r11
 1010c5b:	49 81 f3 43 42 0f 00 	xor    $0xf4243,%r11
 1010c62:	48 99                	cqto
 1010c64:	49 f7 fb             	idiv   %r11
 1010c67:	48 89 d1             	mov    %rdx,%rcx
 1010c6a:	48 83 f9 00          	cmp    $0x0,%rcx
 1010c6e:	0f 95 c0             	setne  %al
 1010c71:	48 0f b6 c0          	movzbq %al,%rax
 1010c75:	4c 89 da             	mov    %r11,%rdx
 1010c78:	48 31 ca             	xor    %rcx,%rdx
 1010c7b:	48 83 fa 00          	cmp    $0x0,%rdx
 1010c7f:	0f 9c c2             	setl   %dl
 1010c82:	48 0f b6 d2          	movzbq %dl,%rdx
 1010c86:	48 21 d0             	and    %rdx,%rax
 1010c89:	48 f7 d8             	neg    %rax
 1010c8c:	4c 21 d8             	and    %r11,%rax
 1010c8f:	48 01 c1             	add    %rax,%rcx
 1010c92:	48 89 8d 38 ff ff ff 	mov    %rcx,-0xc8(%rbp)
 1010c99:	48 89 8d 08 ff ff ff 	mov    %rcx,-0xf8(%rbp)
 1010ca0:	8b 85 10 fe ff ff    	mov    -0x1f0(%rbp),%eax
 1010ca6:	83 f8 00             	cmp    $0x0,%eax
 1010ca9:	74 2e                	je     1010cd9 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1d29>
 1010cab:	49 89 ff             	mov    %rdi,%r15
 1010cae:	e8 8d 5c 00 00       	call   1016940 <myl_qbe_rc_slot_drop>
 1010cb3:	4c 89 ff             	mov    %r15,%rdi
 1010cb6:	48 8b 8d 38 ff ff ff 	mov    -0xc8(%rbp),%rcx
 1010cbd:	4c 8b 8d 50 ff ff ff 	mov    -0xb0(%rbp),%r9
 1010cc4:	4c 8b 85 48 ff ff ff 	mov    -0xb8(%rbp),%r8
 1010ccb:	4c 8b 95 58 ff ff ff 	mov    -0xa8(%rbp),%r10
 1010cd2:	48 8b b5 40 ff ff ff 	mov    -0xc0(%rbp),%rsi
 1010cd9:	4c 89 a5 08 ff ff ff 	mov    %r12,-0xf8(%rbp)
 1010ce0:	48 8b 85 f8 fe ff ff 	mov    -0x108(%rbp),%rax
 1010ce7:	48 8b 10             	mov    (%rax),%rdx
 1010cea:	49 39 d4             	cmp    %rdx,%r12
 1010ced:	75 5d                	jne    1010d4c <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1d9c>
 1010cef:	48 c7 85 08 ff ff ff 	movq   $0x0,-0xf8(%rbp)
 1010cf6:	00 00 00 00 
 1010cfa:	4c 89 b5 08 ff ff ff 	mov    %r14,-0xf8(%rbp)
 1010d01:	48 c7 85 10 ff ff ff 	movq   $0x1,-0xf0(%rbp)
 1010d08:	01 00 00 00 
 1010d0c:	48 ba fe ff ff ff ff 	movabs $0x7ffffffffffffffe,%rdx
 1010d13:	ff ff 7f 
 1010d16:	49 39 d6             	cmp    %rdx,%r14
 1010d19:	7f 14                	jg     1010d2f <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1d7f>
 1010d1b:	49 83 c6 01          	add    $0x1,%r14
 1010d1f:	4c 89 b5 08 ff ff ff 	mov    %r14,-0xf8(%rbp)
 1010d26:	48 89 4d 90          	mov    %rcx,-0x70(%rbp)
 1010d2a:	e9 b1 fa ff ff       	jmp    10107e0 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1830>
 1010d2f:	4c 89 f6             	mov    %r14,%rsi
 1010d32:	41 b8 40 00 00 00    	mov    $0x40,%r8d
 1010d38:	b9 01 00 00 00       	mov    $0x1,%ecx
 1010d3d:	48 89 f2             	mov    %rsi,%rdx
 1010d40:	be 00 00 00 00       	mov    $0x0,%esi
 1010d45:	e8 86 62 00 00       	call   1016fd0 <myl_qbe_fail_overflow_op>
 1010d4a:	0f 0b                	ud2
 1010d4c:	e8 ff 61 00 00       	call   1016f50 <myl_qbe_fail_iteration>
 1010d51:	0f 0b                	ud2
 1010d53:	41 b8 40 00 00 00    	mov    $0x40,%r8d
 1010d59:	be 00 00 00 00       	mov    $0x0,%esi
 1010d5e:	e8 6d 62 00 00       	call   1016fd0 <myl_qbe_fail_overflow_op>
 1010d63:	0f 0b                	ud2
 1010d65:	48 89 c1             	mov    %rax,%rcx
 1010d68:	41 b8 40 00 00 00    	mov    $0x40,%r8d
 1010d6e:	be 02 00 00 00       	mov    $0x2,%esi
 1010d73:	e8 58 62 00 00       	call   1016fd0 <myl_qbe_fail_overflow_op>
 1010d78:	0f 0b                	ud2
 1010d7a:	48 89 fb             	mov    %rdi,%rbx
 1010d7d:	e8 be 61 00 00       	call   1016f40 <myl_qbe_fail_missing_key>
 1010d82:	0f 0b                	ud2
 1010d84:	48 87 fb             	xchg   %rdi,%rbx
 1010d87:	e8 f4 2a 01 00       	call   1023880 <myl_rc_take_failure>
 1010d8c:	48 89 df             	mov    %rbx,%rdi
 1010d8f:	89 c6                	mov    %eax,%esi
 1010d91:	48 89 fb             	mov    %rdi,%rbx
 1010d94:	e8 d7 59 00 00       	call   1016770 <myl_qbe_rc_status>
 1010d99:	48 89 df             	mov    %rbx,%rdi
 1010d9c:	e9 ef 00 00 00       	jmp    1010e90 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1ee0>
 1010da1:	48 87 fb             	xchg   %rdi,%rbx
 1010da4:	e8 d7 2a 01 00       	call   1023880 <myl_rc_take_failure>
 1010da9:	48 89 df             	mov    %rbx,%rdi
 1010dac:	89 c6                	mov    %eax,%esi
 1010dae:	48 89 fb             	mov    %rdi,%rbx
 1010db1:	e8 ba 59 00 00       	call   1016770 <myl_qbe_rc_status>
 1010db6:	48 89 df             	mov    %rbx,%rdi
 1010db9:	e9 d2 00 00 00       	jmp    1010e90 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1ee0>
 1010dbe:	48 89 ca             	mov    %rcx,%rdx
 1010dc1:	4c 89 f6             	mov    %r14,%rsi
 1010dc4:	e8 97 61 00 00       	call   1016f60 <myl_qbe_fail_normalized_index_bounds>
 1010dc9:	0f 0b                	ud2
 1010dcb:	e8 80 61 00 00       	call   1016f50 <myl_qbe_fail_iteration>
 1010dd0:	0f 0b                	ud2
 1010dd2:	48 8b 4d 90          	mov    -0x70(%rbp),%rcx
 1010dd6:	4c 8b a5 30 ff ff ff 	mov    -0xd0(%rbp),%r12
 1010ddd:	4c 89 a5 08 ff ff ff 	mov    %r12,-0xf8(%rbp)
 1010de4:	48 89 8d 10 ff ff ff 	mov    %rcx,-0xf0(%rbp)
 1010deb:	4c 89 e6             	mov    %r12,%rsi
 1010dee:	48 89 fb             	mov    %rdi,%rbx
 1010df1:	e8 1a 80 00 00       	call   1018e10 <myl_qbe_stream_begin>
 1010df6:	4c 89 e2             	mov    %r12,%rdx
 1010df9:	48 89 df             	mov    %rbx,%rdi
 1010dfc:	48 89 c6             	mov    %rax,%rsi
 1010dff:	49 89 d5             	mov    %rdx,%r13
 1010e02:	ba 00 00 00 00       	mov    $0x0,%edx
 1010e07:	49 89 f4             	mov    %rsi,%r12
 1010e0a:	48 8d b5 10 ff ff ff 	lea    -0xf0(%rbp),%rsi
 1010e11:	48 89 fb             	mov    %rdi,%rbx
 1010e14:	4c 89 e7             	mov    %r12,%rdi
 1010e17:	e8 a4 00 00 00       	call   1010ec0 <myl_r_1a91deb3742283487d66c3b500f6effd7ef1170e6d4b4368fe9ec3c3f0354fda>
 1010e1c:	4c 89 e6             	mov    %r12,%rsi
 1010e1f:	48 89 df             	mov    %rbx,%rdi
 1010e22:	49 89 f4             	mov    %rsi,%r12
 1010e25:	be 0a 00 00 00       	mov    $0xa,%esi
 1010e2a:	48 89 fb             	mov    %rdi,%rbx
 1010e2d:	4c 89 e7             	mov    %r12,%rdi
 1010e30:	e8 2b 7f 00 00       	call   1018d60 <myl_qbe_print_byte>
 1010e35:	4c 89 ea             	mov    %r13,%rdx
 1010e38:	4c 89 e6             	mov    %r12,%rsi
 1010e3b:	48 89 df             	mov    %rbx,%rdi
 1010e3e:	48 89 fb             	mov    %rdi,%rbx
 1010e41:	e8 0a 80 00 00       	call   1018e50 <myl_qbe_stream_finish>
 1010e46:	48 89 df             	mov    %rbx,%rdi
 1010e49:	48 c7 85 08 ff ff ff 	movq   $0x0,-0xf8(%rbp)
 1010e50:	00 00 00 00 
 1010e54:	48 c7 85 08 ff ff ff 	movq   $0x0,-0xf8(%rbp)
 1010e5b:	00 00 00 00 
 1010e5f:	48 8d b5 18 fc ff ff 	lea    -0x3e8(%rbp),%rsi
 1010e66:	48 89 fb             	mov    %rdi,%rbx
 1010e69:	e8 02 5c 00 00       	call   1016a70 <myl_qbe_rc_frame_cleanup>
 1010e6e:	48 89 df             	mov    %rbx,%rdi
 1010e71:	48 8d b5 18 fc ff ff 	lea    -0x3e8(%rbp),%rsi
 1010e78:	e8 63 5a 00 00       	call   10168e0 <myl_qbe_rc_frame_leave>
 1010e7d:	b8 00 00 00 00       	mov    $0x0,%eax
 1010e82:	eb 2f                	jmp    1010eb3 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1f03>
 1010e84:	ba 40 01 00 00       	mov    $0x140,%edx
 1010e89:	e8 82 62 00 00       	call   1017110 <myl_qbe_fail_cast>
 1010e8e:	0f 0b                	ud2
 1010e90:	48 8d b5 18 fc ff ff 	lea    -0x3e8(%rbp),%rsi
 1010e97:	48 89 fb             	mov    %rdi,%rbx
 1010e9a:	e8 d1 5b 00 00       	call   1016a70 <myl_qbe_rc_frame_cleanup>
 1010e9f:	48 89 df             	mov    %rbx,%rdi
 1010ea2:	48 8d b5 18 fc ff ff 	lea    -0x3e8(%rbp),%rsi
 1010ea9:	e8 32 5a 00 00       	call   10168e0 <myl_qbe_rc_frame_leave>
 1010eae:	b8 00 00 00 00       	mov    $0x0,%eax
 1010eb3:	41 5f                	pop    %r15
 1010eb5:	41 5e                	pop    %r14
 1010eb7:	41 5d                	pop    %r13
 1010eb9:	41 5c                	pop    %r12
 1010ebb:	5b                   	pop    %rbx
 1010ebc:	c9                   	leave
 1010ebd:	c3                   	ret

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
