
.tmp-mut-argument/return-run/trees-llvm-after-rc:     file format elf64-x86-64


Disassembly of section .text:

000000000101a460 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531>:
 101a460:	55                   	push   %rbp
 101a461:	41 57                	push   %r15
 101a463:	41 56                	push   %r14
 101a465:	41 55                	push   %r13
 101a467:	41 54                	push   %r12
 101a469:	53                   	push   %rbx
 101a46a:	48 81 ec 18 01 00 00 	sub    $0x118,%rsp
 101a471:	48 89 fb             	mov    %rdi,%rbx
 101a474:	48 39 67 40          	cmp    %rsp,0x40(%rdi)
 101a478:	0f 87 2c 08 00 00    	ja     101acaa <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x84a>
 101a47e:	49 89 f7             	mov    %rsi,%r15
 101a481:	48 85 f6             	test   %rsi,%rsi
 101a484:	0f 84 4e 07 00 00    	je     101abd8 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x778>
 101a48a:	44 8b a3 c8 02 00 00 	mov    0x2c8(%rbx),%r12d
 101a491:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
 101a495:	c5 fc 11 44 24 10    	vmovups %ymm0,0x10(%rsp)
 101a49b:	c5 fc 11 44 24 78    	vmovups %ymm0,0x78(%rsp)
 101a4a1:	c5 fc 11 84 24 98 00 	vmovups %ymm0,0x98(%rsp)
 101a4a8:	00 00 
 101a4aa:	c5 fc 11 84 24 b8 00 	vmovups %ymm0,0xb8(%rsp)
 101a4b1:	00 00 
 101a4b3:	48 c7 84 24 d8 00 00 	movq   $0x0,0xd8(%rsp)
 101a4ba:	00 00 00 00 00 
 101a4bf:	48 c7 44 24 60 e8 9b 	movq   $0x1009be8,0x60(%rsp)
 101a4c6:	00 01 
 101a4c8:	48 8d 44 24 30       	lea    0x30(%rsp),%rax
 101a4cd:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
 101a4d2:	48 8d 44 24 10       	lea    0x10(%rsp),%rax
 101a4d7:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
 101a4dc:	48 c7 84 24 80 00 00 	movq   $0x1009be8,0x80(%rsp)
 101a4e3:	00 e8 9b 00 01 
 101a4e8:	48 8d 44 24 48       	lea    0x48(%rsp),%rax
 101a4ed:	48 89 84 24 88 00 00 	mov    %rax,0x88(%rsp)
 101a4f4:	00 
 101a4f5:	48 8d 44 24 18       	lea    0x18(%rsp),%rax
 101a4fa:	48 89 84 24 90 00 00 	mov    %rax,0x90(%rsp)
 101a501:	00 
 101a502:	48 c7 84 24 a0 00 00 	movq   $0x1009be8,0xa0(%rsp)
 101a509:	00 e8 9b 00 01 
 101a50e:	48 89 e0             	mov    %rsp,%rax
 101a511:	48 89 84 24 a8 00 00 	mov    %rax,0xa8(%rsp)
 101a518:	00 
 101a519:	48 8d 44 24 20       	lea    0x20(%rsp),%rax
 101a51e:	48 89 84 24 b0 00 00 	mov    %rax,0xb0(%rsp)
 101a525:	00 
 101a526:	48 c7 84 24 c0 00 00 	movq   $0x1009be8,0xc0(%rsp)
 101a52d:	00 e8 9b 00 01 
 101a532:	48 8d 44 24 58       	lea    0x58(%rsp),%rax
 101a537:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
 101a53e:	00 
 101a53f:	4c 8d 6c 24 28       	lea    0x28(%rsp),%r13
 101a544:	4c 89 ac 24 d0 00 00 	mov    %r13,0xd0(%rsp)
 101a54b:	00 
 101a54c:	48 85 db             	test   %rbx,%rbx
 101a54f:	0f 84 38 07 00 00    	je     101ac8d <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x82d>
 101a555:	48 8b 83 60 18 00 00 	mov    0x1860(%rbx),%rax
 101a55c:	48 85 c0             	test   %rax,%rax
 101a55f:	0f 84 28 07 00 00    	je     101ac8d <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x82d>
 101a565:	48 8b 8b 80 3d 00 00 	mov    0x3d80(%rbx),%rcx
 101a56c:	48 8b 40 70          	mov    0x70(%rax),%rax
 101a570:	48 89 8c 24 f0 00 00 	mov    %rcx,0xf0(%rsp)
 101a577:	00 
 101a578:	48 8d 4c 24 60       	lea    0x60(%rsp),%rcx
 101a57d:	48 89 8c 24 f8 00 00 	mov    %rcx,0xf8(%rsp)
 101a584:	00 
 101a585:	48 c7 84 24 00 01 00 	movq   $0x4,0x100(%rsp)
 101a58c:	00 04 00 00 00 
 101a591:	48 89 84 24 08 01 00 	mov    %rax,0x108(%rsp)
 101a598:	00 
 101a599:	4c 8d b4 24 f0 00 00 	lea    0xf0(%rsp),%r14
 101a5a0:	00 
 101a5a1:	4c 89 b3 80 3d 00 00 	mov    %r14,0x3d80(%rbx)
 101a5a8:	4c 89 f8             	mov    %r15,%rax
 101a5ab:	48 f7 d8             	neg    %rax
 101a5ae:	0f 80 fe 06 00 00    	jo     101acb2 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x852>
 101a5b4:	49 ff cf             	dec    %r15
 101a5b7:	48 89 df             	mov    %rbx,%rdi
 101a5ba:	4c 89 fe             	mov    %r15,%rsi
 101a5bd:	c5 f8 77             	vzeroupper
 101a5c0:	e8 9b fe ff ff       	call   101a460 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531>
 101a5c5:	48 89 04 24          	mov    %rax,(%rsp)
 101a5c9:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
 101a5ce:	48 c7 84 24 a0 00 00 	movq   $0x100a308,0xa0(%rsp)
 101a5d5:	00 08 a3 00 01 
 101a5da:	c7 84 24 b8 00 00 00 	movl   $0x2,0xb8(%rsp)
 101a5e1:	02 00 00 00 
 101a5e5:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
 101a5ea:	48 89 54 24 38       	mov    %rdx,0x38(%rsp)
 101a5ef:	48 c7 44 24 60 08 a3 	movq   $0x100a308,0x60(%rsp)
 101a5f6:	00 01 
 101a5f8:	c7 44 24 78 02 00 00 	movl   $0x2,0x78(%rsp)
 101a5ff:	00 
 101a600:	c7 44 24 20 00 00 00 	movl   $0x0,0x20(%rsp)
 101a607:	00 
 101a608:	c7 44 24 10 01 00 00 	movl   $0x1,0x10(%rsp)
 101a60f:	00 
 101a610:	48 83 bb 60 18 00 00 	cmpq   $0x0,0x1860(%rbx)
 101a617:	00 
 101a618:	0f 84 7c 06 00 00    	je     101ac9a <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x83a>
 101a61e:	48 8d ab 58 02 00 00 	lea    0x258(%rbx),%rbp
 101a625:	8b 8b c8 02 00 00    	mov    0x2c8(%rbx),%ecx
 101a62b:	be b8 98 00 01       	mov    $0x10098b8,%esi
 101a630:	ba 01 00 00 00       	mov    $0x1,%edx
 101a635:	48 89 ef             	mov    %rbp,%rdi
 101a638:	e8 23 f6 00 00       	call   1029c60 <myl_rc_storage_alloc>
 101a63d:	48 85 c0             	test   %rax,%rax
 101a640:	0f 84 54 06 00 00    	je     101ac9a <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x83a>
 101a646:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
 101a64b:	48 c7 84 24 c0 00 00 	movq   $0x1009928,0xc0(%rsp)
 101a652:	00 28 99 00 01 
 101a657:	48 8d 4c 24 58       	lea    0x58(%rsp),%rcx
 101a65c:	48 89 8c 24 c8 00 00 	mov    %rcx,0xc8(%rsp)
 101a663:	00 
 101a664:	4c 89 ac 24 d0 00 00 	mov    %r13,0xd0(%rsp)
 101a66b:	00 
 101a66c:	c7 84 24 d8 00 00 00 	movl   $0x4,0xd8(%rsp)
 101a673:	04 00 00 00 
 101a677:	c7 44 24 28 01 00 00 	movl   $0x1,0x28(%rsp)
 101a67e:	00 
 101a67f:	f6 44 24 78 18       	testb  $0x18,0x78(%rsp)
 101a684:	75 18                	jne    101a69e <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x23e>
 101a686:	8b 4c 24 10          	mov    0x10(%rsp),%ecx
 101a68a:	83 e1 01             	and    $0x1,%ecx
 101a68d:	74 0f                	je     101a69e <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x23e>
 101a68f:	c5 f8 10 44 24 30    	vmovups 0x30(%rsp),%xmm0
 101a695:	c5 f8 11 00          	vmovups %xmm0,(%rax)
 101a699:	e9 aa 00 00 00       	jmp    101a748 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x2e8>
 101a69e:	48 8b 4c 24 30       	mov    0x30(%rsp),%rcx
 101a6a3:	48 85 c9             	test   %rcx,%rcx
 101a6a6:	74 10                	je     101a6b8 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x258>
 101a6a8:	48 ba 01 00 00 00 00 	movabs $0x5000000000000001,%rdx
 101a6af:	00 00 50 
 101a6b2:	48 85 51 f0          	test   %rdx,-0x10(%rcx)
 101a6b6:	75 1a                	jne    101a6d2 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x272>
 101a6b8:	48 8b 4c 24 38       	mov    0x38(%rsp),%rcx
 101a6bd:	48 85 c9             	test   %rcx,%rcx
 101a6c0:	74 4a                	je     101a70c <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x2ac>
 101a6c2:	48 ba 01 00 00 00 00 	movabs $0x5000000000000001,%rdx
 101a6c9:	00 00 50 
 101a6cc:	48 85 51 f0          	test   %rdx,-0x10(%rcx)
 101a6d0:	74 3a                	je     101a70c <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x2ac>
 101a6d2:	48 89 e2             	mov    %rsp,%rdx
 101a6d5:	48 8d 4c 24 30       	lea    0x30(%rsp),%rcx
 101a6da:	be 08 a3 00 01       	mov    $0x100a308,%esi
 101a6df:	48 89 ef             	mov    %rbp,%rdi
 101a6e2:	45 89 e0             	mov    %r12d,%r8d
 101a6e5:	49 89 ed             	mov    %rbp,%r13
 101a6e8:	4c 89 f5             	mov    %r14,%rbp
 101a6eb:	49 89 c6             	mov    %rax,%r14
 101a6ee:	e8 5d 07 01 00       	call   102ae50 <myl_rc_native_take>
 101a6f3:	89 c1                	mov    %eax,%ecx
 101a6f5:	4c 89 f0             	mov    %r14,%rax
 101a6f8:	49 89 ee             	mov    %rbp,%r14
 101a6fb:	4c 89 ed             	mov    %r13,%rbp
 101a6fe:	4c 8d 6c 24 28       	lea    0x28(%rsp),%r13
 101a703:	85 c9                	test   %ecx,%ecx
 101a705:	75 19                	jne    101a720 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x2c0>
 101a707:	e9 9a 03 00 00       	jmp    101aaa6 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x646>
 101a70c:	c5 f8 10 44 24 30    	vmovups 0x30(%rsp),%xmm0
 101a712:	c5 f8 29 04 24       	vmovaps %xmm0,(%rsp)
 101a717:	48 c7 44 24 38 00 00 	movq   $0x0,0x38(%rsp)
 101a71e:	00 00 
 101a720:	48 c7 84 24 a0 00 00 	movq   $0x100a308,0xa0(%rsp)
 101a727:	00 08 a3 00 01 
 101a72c:	c7 84 24 b8 00 00 00 	movl   $0x2,0xb8(%rsp)
 101a733:	02 00 00 00 
 101a737:	c5 f8 28 04 24       	vmovaps (%rsp),%xmm0
 101a73c:	c5 f8 11 00          	vmovups %xmm0,(%rax)
 101a740:	c7 44 24 20 00 00 00 	movl   $0x0,0x20(%rsp)
 101a747:	00 
 101a748:	48 c7 84 24 c0 00 00 	movq   $0x1009fd8,0xc0(%rsp)
 101a74f:	00 d8 9f 00 01 
 101a754:	c7 84 24 d8 00 00 00 	movl   $0x2,0xd8(%rsp)
 101a75b:	02 00 00 00 
 101a75f:	48 8d 8c 24 10 01 00 	lea    0x110(%rsp),%rcx
 101a766:	00 
 101a767:	48 89 8c 24 c8 00 00 	mov    %rcx,0xc8(%rsp)
 101a76e:	00 
 101a76f:	4c 89 ac 24 d0 00 00 	mov    %r13,0xd0(%rsp)
 101a776:	00 
 101a777:	48 89 84 24 10 01 00 	mov    %rax,0x110(%rsp)
 101a77e:	00 
 101a77f:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
 101a784:	48 c7 44 24 60 d8 9f 	movq   $0x1009fd8,0x60(%rsp)
 101a78b:	00 01 
 101a78d:	c7 44 24 78 02 00 00 	movl   $0x2,0x78(%rsp)
 101a794:	00 
 101a795:	c7 44 24 10 01 00 00 	movl   $0x1,0x10(%rsp)
 101a79c:	00 
 101a79d:	c7 44 24 28 00 00 00 	movl   $0x0,0x28(%rsp)
 101a7a4:	00 
 101a7a5:	48 89 df             	mov    %rbx,%rdi
 101a7a8:	4c 89 fe             	mov    %r15,%rsi
 101a7ab:	e8 b0 fc ff ff       	call   101a460 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531>
 101a7b0:	48 89 04 24          	mov    %rax,(%rsp)
 101a7b4:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
 101a7b9:	48 c7 84 24 a0 00 00 	movq   $0x100a308,0xa0(%rsp)
 101a7c0:	00 08 a3 00 01 
 101a7c5:	c7 84 24 b8 00 00 00 	movl   $0x2,0xb8(%rsp)
 101a7cc:	02 00 00 00 
 101a7d0:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
 101a7d5:	48 89 54 24 50       	mov    %rdx,0x50(%rsp)
 101a7da:	48 c7 84 24 80 00 00 	movq   $0x100a308,0x80(%rsp)
 101a7e1:	00 08 a3 00 01 
 101a7e6:	c7 84 24 98 00 00 00 	movl   $0x2,0x98(%rsp)
 101a7ed:	02 00 00 00 
 101a7f1:	c7 44 24 20 00 00 00 	movl   $0x0,0x20(%rsp)
 101a7f8:	00 
 101a7f9:	c7 44 24 18 01 00 00 	movl   $0x1,0x18(%rsp)
 101a800:	00 
 101a801:	48 83 bb 60 18 00 00 	cmpq   $0x0,0x1860(%rbx)
 101a808:	00 
 101a809:	0f 84 93 04 00 00    	je     101aca2 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x842>
 101a80f:	8b 8b c8 02 00 00    	mov    0x2c8(%rbx),%ecx
 101a815:	be b8 98 00 01       	mov    $0x10098b8,%esi
 101a81a:	ba 01 00 00 00       	mov    $0x1,%edx
 101a81f:	48 89 ef             	mov    %rbp,%rdi
 101a822:	e8 39 f4 00 00       	call   1029c60 <myl_rc_storage_alloc>
 101a827:	48 85 c0             	test   %rax,%rax
 101a82a:	0f 84 72 04 00 00    	je     101aca2 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x842>
 101a830:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
 101a835:	48 c7 84 24 c0 00 00 	movq   $0x1009928,0xc0(%rsp)
 101a83c:	00 28 99 00 01 
 101a841:	48 8d 4c 24 58       	lea    0x58(%rsp),%rcx
 101a846:	48 89 8c 24 c8 00 00 	mov    %rcx,0xc8(%rsp)
 101a84d:	00 
 101a84e:	4c 89 ac 24 d0 00 00 	mov    %r13,0xd0(%rsp)
 101a855:	00 
 101a856:	c7 84 24 d8 00 00 00 	movl   $0x4,0xd8(%rsp)
 101a85d:	04 00 00 00 
 101a861:	c7 44 24 28 01 00 00 	movl   $0x1,0x28(%rsp)
 101a868:	00 
 101a869:	f6 84 24 98 00 00 00 	testb  $0x18,0x98(%rsp)
 101a870:	18 
 101a871:	75 18                	jne    101a88b <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x42b>
 101a873:	8b 4c 24 18          	mov    0x18(%rsp),%ecx
 101a877:	83 e1 01             	and    $0x1,%ecx
 101a87a:	74 0f                	je     101a88b <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x42b>
 101a87c:	c5 f8 10 44 24 48    	vmovups 0x48(%rsp),%xmm0
 101a882:	c5 f8 11 00          	vmovups %xmm0,(%rax)
 101a886:	e9 99 00 00 00       	jmp    101a924 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x4c4>
 101a88b:	48 8b 4c 24 48       	mov    0x48(%rsp),%rcx
 101a890:	48 85 c9             	test   %rcx,%rcx
 101a893:	74 10                	je     101a8a5 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x445>
 101a895:	48 ba 01 00 00 00 00 	movabs $0x5000000000000001,%rdx
 101a89c:	00 00 50 
 101a89f:	48 85 51 f0          	test   %rdx,-0x10(%rcx)
 101a8a3:	75 1a                	jne    101a8bf <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x45f>
 101a8a5:	48 8b 4c 24 50       	mov    0x50(%rsp),%rcx
 101a8aa:	48 85 c9             	test   %rcx,%rcx
 101a8ad:	74 39                	je     101a8e8 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x488>
 101a8af:	48 ba 01 00 00 00 00 	movabs $0x5000000000000001,%rdx
 101a8b6:	00 00 50 
 101a8b9:	48 85 51 f0          	test   %rdx,-0x10(%rcx)
 101a8bd:	74 29                	je     101a8e8 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x488>
 101a8bf:	48 89 e2             	mov    %rsp,%rdx
 101a8c2:	48 8d 4c 24 48       	lea    0x48(%rsp),%rcx
 101a8c7:	be 08 a3 00 01       	mov    $0x100a308,%esi
 101a8cc:	48 89 ef             	mov    %rbp,%rdi
 101a8cf:	45 89 e0             	mov    %r12d,%r8d
 101a8d2:	49 89 c7             	mov    %rax,%r15
 101a8d5:	e8 76 05 01 00       	call   102ae50 <myl_rc_native_take>
 101a8da:	89 c1                	mov    %eax,%ecx
 101a8dc:	4c 89 f8             	mov    %r15,%rax
 101a8df:	85 c9                	test   %ecx,%ecx
 101a8e1:	75 19                	jne    101a8fc <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x49c>
 101a8e3:	e9 be 01 00 00       	jmp    101aaa6 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x646>
 101a8e8:	c5 f8 10 44 24 48    	vmovups 0x48(%rsp),%xmm0
 101a8ee:	c5 f8 29 04 24       	vmovaps %xmm0,(%rsp)
 101a8f3:	48 c7 44 24 50 00 00 	movq   $0x0,0x50(%rsp)
 101a8fa:	00 00 
 101a8fc:	48 c7 84 24 a0 00 00 	movq   $0x100a308,0xa0(%rsp)
 101a903:	00 08 a3 00 01 
 101a908:	c7 84 24 b8 00 00 00 	movl   $0x2,0xb8(%rsp)
 101a90f:	02 00 00 00 
 101a913:	c5 f8 28 04 24       	vmovaps (%rsp),%xmm0
 101a918:	c5 f8 11 00          	vmovups %xmm0,(%rax)
 101a91c:	c7 44 24 20 00 00 00 	movl   $0x0,0x20(%rsp)
 101a923:	00 
 101a924:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
 101a929:	48 c7 84 24 80 00 00 	movq   $0x1009fd8,0x80(%rsp)
 101a930:	00 d8 9f 00 01 
 101a935:	c7 84 24 98 00 00 00 	movl   $0x2,0x98(%rsp)
 101a93c:	02 00 00 00 
 101a940:	c7 44 24 18 01 00 00 	movl   $0x1,0x18(%rsp)
 101a947:	00 
 101a948:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
 101a94c:	c5 f8 29 84 24 e0 00 	vmovaps %xmm0,0xe0(%rsp)
 101a953:	00 00 
 101a955:	48 c7 84 24 c0 00 00 	movq   $0x100a308,0xc0(%rsp)
 101a95c:	00 08 a3 00 01 
 101a961:	c7 84 24 d8 00 00 00 	movl   $0x2,0xd8(%rsp)
 101a968:	02 00 00 00 
 101a96c:	48 8d 8c 24 e0 00 00 	lea    0xe0(%rsp),%rcx
 101a973:	00 
 101a974:	48 89 8c 24 c8 00 00 	mov    %rcx,0xc8(%rsp)
 101a97b:	00 
 101a97c:	4c 89 ac 24 d0 00 00 	mov    %r13,0xd0(%rsp)
 101a983:	00 
 101a984:	c7 44 24 28 01 00 00 	movl   $0x1,0x28(%rsp)
 101a98b:	00 
 101a98c:	f6 44 24 78 18       	testb  $0x18,0x78(%rsp)
 101a991:	75 1b                	jne    101a9ae <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x54e>
 101a993:	8b 4c 24 10          	mov    0x10(%rsp),%ecx
 101a997:	83 e1 01             	and    $0x1,%ecx
 101a99a:	74 12                	je     101a9ae <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x54e>
 101a99c:	48 8b 4c 24 30       	mov    0x30(%rsp),%rcx
 101a9a1:	48 89 8c 24 e0 00 00 	mov    %rcx,0xe0(%rsp)
 101a9a8:	00 
 101a9a9:	e9 87 00 00 00       	jmp    101aa35 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x5d5>
 101a9ae:	48 89 e2             	mov    %rsp,%rdx
 101a9b1:	48 8d 4c 24 30       	lea    0x30(%rsp),%rcx
 101a9b6:	be d8 9f 00 01       	mov    $0x1009fd8,%esi
 101a9bb:	48 89 ef             	mov    %rbp,%rdi
 101a9be:	45 89 e0             	mov    %r12d,%r8d
 101a9c1:	e8 fa 09 01 00       	call   102b3c0 <myl_rc_native_retain>
 101a9c6:	85 c0                	test   %eax,%eax
 101a9c8:	0f 84 d8 00 00 00    	je     101aaa6 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x646>
 101a9ce:	48 c7 84 24 a0 00 00 	movq   $0x1009fd8,0xa0(%rsp)
 101a9d5:	00 d8 9f 00 01 
 101a9da:	c7 84 24 b8 00 00 00 	movl   $0x2,0xb8(%rsp)
 101a9e1:	02 00 00 00 
 101a9e5:	c7 44 24 20 01 00 00 	movl   $0x1,0x20(%rsp)
 101a9ec:	00 
 101a9ed:	83 7c 24 10 00       	cmpl   $0x0,0x10(%rsp)
 101a9f2:	74 0d                	je     101aa01 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x5a1>
 101a9f4:	48 8d 74 24 60       	lea    0x60(%rsp),%rsi
 101a9f9:	48 89 df             	mov    %rbx,%rdi
 101a9fc:	e8 2f 27 00 00       	call   101d130 <myl_qbe_rc_slot_drop>
 101aa01:	48 8b 04 24          	mov    (%rsp),%rax
 101aa05:	48 89 84 24 e0 00 00 	mov    %rax,0xe0(%rsp)
 101aa0c:	00 
 101aa0d:	c7 44 24 20 00 00 00 	movl   $0x0,0x20(%rsp)
 101aa14:	00 
 101aa15:	f6 84 24 98 00 00 00 	testb  $0x18,0x98(%rsp)
 101aa1c:	18 
 101aa1d:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
 101aa22:	0f 85 c6 01 00 00    	jne    101abee <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x78e>
 101aa28:	8b 4c 24 18          	mov    0x18(%rsp),%ecx
 101aa2c:	83 e1 01             	and    $0x1,%ecx
 101aa2f:	0f 84 b9 01 00 00    	je     101abee <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x78e>
 101aa35:	48 89 84 24 e8 00 00 	mov    %rax,0xe8(%rsp)
 101aa3c:	00 
 101aa3d:	c7 44 24 18 00 00 00 	movl   $0x0,0x18(%rsp)
 101aa44:	00 
 101aa45:	c5 f8 28 84 24 e0 00 	vmovaps 0xe0(%rsp),%xmm0
 101aa4c:	00 00 
 101aa4e:	c5 f8 29 44 24 30    	vmovaps %xmm0,0x30(%rsp)
 101aa54:	48 c7 44 24 60 08 a3 	movq   $0x100a308,0x60(%rsp)
 101aa5b:	00 01 
 101aa5d:	c7 44 24 78 02 00 00 	movl   $0x2,0x78(%rsp)
 101aa64:	00 
 101aa65:	c7 44 24 28 00 00 00 	movl   $0x0,0x28(%rsp)
 101aa6c:	00 
 101aa6d:	c5 f8 29 04 24       	vmovaps %xmm0,(%rsp)
 101aa72:	c7 44 24 10 00 00 00 	movl   $0x0,0x10(%rsp)
 101aa79:	00 
 101aa7a:	4c 39 b3 80 3d 00 00 	cmp    %r14,0x3d80(%rbx)
 101aa81:	0f 85 06 02 00 00    	jne    101ac8d <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x82d>
 101aa87:	48 8b 83 60 18 00 00 	mov    0x1860(%rbx),%rax
 101aa8e:	48 85 c0             	test   %rax,%rax
 101aa91:	74 47                	je     101aada <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x67a>
 101aa93:	48 8b 40 70          	mov    0x70(%rax),%rax
 101aa97:	48 3b 84 24 08 01 00 	cmp    0x108(%rsp),%rax
 101aa9e:	00 
 101aa9f:	74 49                	je     101aaea <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x68a>
 101aaa1:	e9 e7 01 00 00       	jmp    101ac8d <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x82d>
 101aaa6:	48 8b 8b 60 18 00 00 	mov    0x1860(%rbx),%rcx
 101aaad:	48 85 c9             	test   %rcx,%rcx
 101aab0:	0f 84 d7 01 00 00    	je     101ac8d <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x82d>
 101aab6:	8b 41 78             	mov    0x78(%rcx),%eax
 101aab9:	c7 41 78 00 00 00 00 	movl   $0x0,0x78(%rcx)
 101aac0:	48 85 c0             	test   %rax,%rax
 101aac3:	74 5b                	je     101ab20 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x6c0>
 101aac5:	83 f8 01             	cmp    $0x1,%eax
 101aac8:	75 3d                	jne    101ab07 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x6a7>
 101aaca:	be 60 74 00 01       	mov    $0x1007460,%esi
 101aacf:	83 bb c4 02 00 00 00 	cmpl   $0x0,0x2c4(%rbx)
 101aad6:	75 40                	jne    101ab18 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x6b8>
 101aad8:	eb 36                	jmp    101ab10 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x6b0>
 101aada:	31 c0                	xor    %eax,%eax
 101aadc:	48 3b 84 24 08 01 00 	cmp    0x108(%rsp),%rax
 101aae3:	00 
 101aae4:	0f 85 a3 01 00 00    	jne    101ac8d <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x82d>
 101aaea:	48 8b 84 24 f0 00 00 	mov    0xf0(%rsp),%rax
 101aaf1:	00 
 101aaf2:	48 89 83 80 3d 00 00 	mov    %rax,0x3d80(%rbx)
 101aaf9:	48 8b 04 24          	mov    (%rsp),%rax
 101aafd:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
 101ab02:	e9 d5 00 00 00       	jmp    101abdc <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x77c>
 101ab07:	83 f8 04             	cmp    $0x4,%eax
 101ab0a:	0f 83 85 01 00 00    	jae    101ac95 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x835>
 101ab10:	48 8b 34 c5 70 d4 00 	mov    0x100d470(,%rax,8),%rsi
 101ab17:	01 
 101ab18:	48 89 df             	mov    %rbx,%rdi
 101ab1b:	e8 a0 31 00 00       	call   101dcc0 <fail>
 101ab20:	4c 39 b3 80 3d 00 00 	cmp    %r14,0x3d80(%rbx)
 101ab27:	0f 85 60 01 00 00    	jne    101ac8d <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x82d>
 101ab2d:	4d 89 f4             	mov    %r14,%r12
 101ab30:	48 8b b4 24 08 01 00 	mov    0x108(%rsp),%rsi
 101ab37:	00 
 101ab38:	48 89 ef             	mov    %rbp,%rdi
 101ab3b:	e8 80 ce 00 00       	call   10279c0 <myl_rc_scope_unwind>
 101ab40:	4c 8b b4 24 00 01 00 	mov    0x100(%rsp),%r14
 101ab47:	00 
 101ab48:	4d 85 f6             	test   %r14,%r14
 101ab4b:	74 40                	je     101ab8d <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x72d>
 101ab4d:	4d 89 f7             	mov    %r14,%r15
 101ab50:	49 c1 e7 05          	shl    $0x5,%r15
 101ab54:	49 83 c7 e0          	add    $0xffffffffffffffe0,%r15
 101ab58:	eb 1a                	jmp    101ab74 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x714>
 101ab5a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
 101ab60:	4c 01 fe             	add    %r15,%rsi
 101ab63:	48 89 df             	mov    %rbx,%rdi
 101ab66:	e8 c5 25 00 00       	call   101d130 <myl_qbe_rc_slot_drop>
 101ab6b:	49 83 c7 e0          	add    $0xffffffffffffffe0,%r15
 101ab6f:	49 ff ce             	dec    %r14
 101ab72:	74 19                	je     101ab8d <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x72d>
 101ab74:	48 8b b4 24 f8 00 00 	mov    0xf8(%rsp),%rsi
 101ab7b:	00 
 101ab7c:	4a 8b 44 3e 10       	mov    0x10(%rsi,%r15,1),%rax
 101ab81:	48 85 c0             	test   %rax,%rax
 101ab84:	74 da                	je     101ab60 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x700>
 101ab86:	83 38 00             	cmpl   $0x0,(%rax)
 101ab89:	75 d5                	jne    101ab60 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x700>
 101ab8b:	eb de                	jmp    101ab6b <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x70b>
 101ab8d:	4c 39 a3 80 3d 00 00 	cmp    %r12,0x3d80(%rbx)
 101ab94:	0f 85 f3 00 00 00    	jne    101ac8d <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x82d>
 101ab9a:	48 8b 83 60 18 00 00 	mov    0x1860(%rbx),%rax
 101aba1:	48 85 c0             	test   %rax,%rax
 101aba4:	74 13                	je     101abb9 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x759>
 101aba6:	48 8b 40 70          	mov    0x70(%rax),%rax
 101abaa:	48 3b 84 24 08 01 00 	cmp    0x108(%rsp),%rax
 101abb1:	00 
 101abb2:	74 15                	je     101abc9 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x769>
 101abb4:	e9 d4 00 00 00       	jmp    101ac8d <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x82d>
 101abb9:	31 c0                	xor    %eax,%eax
 101abbb:	48 3b 84 24 08 01 00 	cmp    0x108(%rsp),%rax
 101abc2:	00 
 101abc3:	0f 85 c4 00 00 00    	jne    101ac8d <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x82d>
 101abc9:	48 8b 84 24 f0 00 00 	mov    0xf0(%rsp),%rax
 101abd0:	00 
 101abd1:	48 89 83 80 3d 00 00 	mov    %rax,0x3d80(%rbx)
 101abd8:	31 c0                	xor    %eax,%eax
 101abda:	31 d2                	xor    %edx,%edx
 101abdc:	48 81 c4 18 01 00 00 	add    $0x118,%rsp
 101abe3:	5b                   	pop    %rbx
 101abe4:	41 5c                	pop    %r12
 101abe6:	41 5d                	pop    %r13
 101abe8:	41 5e                	pop    %r14
 101abea:	41 5f                	pop    %r15
 101abec:	5d                   	pop    %rbp
 101abed:	c3                   	ret
 101abee:	48 85 c0             	test   %rax,%rax
 101abf1:	74 32                	je     101ac25 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x7c5>
 101abf3:	48 b9 01 00 00 00 00 	movabs $0x5000000000000001,%rcx
 101abfa:	00 00 50 
 101abfd:	48 85 48 f0          	test   %rcx,-0x10(%rax)
 101ac01:	74 22                	je     101ac25 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x7c5>
 101ac03:	48 89 e2             	mov    %rsp,%rdx
 101ac06:	48 8d 4c 24 48       	lea    0x48(%rsp),%rcx
 101ac0b:	be d8 9f 00 01       	mov    $0x1009fd8,%esi
 101ac10:	48 89 ef             	mov    %rbp,%rdi
 101ac13:	45 89 e0             	mov    %r12d,%r8d
 101ac16:	e8 35 02 01 00       	call   102ae50 <myl_rc_native_take>
 101ac1b:	85 c0                	test   %eax,%eax
 101ac1d:	74 43                	je     101ac62 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x802>
 101ac1f:	48 8b 04 24          	mov    (%rsp),%rax
 101ac23:	eb 09                	jmp    101ac2e <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x7ce>
 101ac25:	48 c7 44 24 48 00 00 	movq   $0x0,0x48(%rsp)
 101ac2c:	00 00 
 101ac2e:	c7 44 24 18 00 00 00 	movl   $0x0,0x18(%rsp)
 101ac35:	00 
 101ac36:	48 c7 84 24 a0 00 00 	movq   $0x1009fd8,0xa0(%rsp)
 101ac3d:	00 d8 9f 00 01 
 101ac42:	c7 84 24 b8 00 00 00 	movl   $0x2,0xb8(%rsp)
 101ac49:	02 00 00 00 
 101ac4d:	48 89 84 24 e8 00 00 	mov    %rax,0xe8(%rsp)
 101ac54:	00 
 101ac55:	c7 44 24 20 00 00 00 	movl   $0x0,0x20(%rsp)
 101ac5c:	00 
 101ac5d:	e9 e3 fd ff ff       	jmp    101aa45 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x5e5>
 101ac62:	48 8b 83 60 18 00 00 	mov    0x1860(%rbx),%rax
 101ac69:	48 85 c0             	test   %rax,%rax
 101ac6c:	74 1f                	je     101ac8d <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x82d>
 101ac6e:	8b 70 78             	mov    0x78(%rax),%esi
 101ac71:	c7 40 78 00 00 00 00 	movl   $0x0,0x78(%rax)
 101ac78:	48 89 df             	mov    %rbx,%rdi
 101ac7b:	e8 20 24 00 00       	call   101d0a0 <myl_qbe_rc_status>
 101ac80:	4c 39 b3 80 3d 00 00 	cmp    %r14,0x3d80(%rbx)
 101ac87:	0f 84 a0 fe ff ff    	je     101ab2d <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x6cd>
 101ac8d:	c5 f8 77             	vzeroupper
 101ac90:	e8 1c 89 00 00       	call   10235b1 <myl_rc_invariant_failed>
 101ac95:	e8 86 3f 01 00       	call   102ec20 <abort@plt>
 101ac9a:	48 89 df             	mov    %rbx,%rdi
 101ac9d:	e8 ce 36 00 00       	call   101e370 <myl_qbe_fail_allocation>
 101aca2:	48 89 df             	mov    %rbx,%rdi
 101aca5:	e8 c6 36 00 00       	call   101e370 <myl_qbe_fail_allocation>
 101acaa:	48 89 df             	mov    %rbx,%rdi
 101acad:	e8 be 37 00 00       	call   101e470 <myl_qbe_fail_frame>
 101acb2:	48 ba 00 00 00 00 00 	movabs $0x8000000000000000,%rdx
 101acb9:	00 00 80 
 101acbc:	be 01 00 00 00       	mov    $0x1,%esi
 101acc1:	b9 01 00 00 00       	mov    $0x1,%ecx
 101acc6:	48 89 df             	mov    %rbx,%rdi
 101acc9:	c5 f8 77             	vzeroupper
 101accc:	e8 2f 37 00 00       	call   101e400 <myl_qbe_fail_overflow_op>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
