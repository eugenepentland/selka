
.tmp-mut-argument/return-run/trees-qbe-before-rc:     file format elf64-x86-64


Disassembly of section .text:

0000000001012a80 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531>:
 1012a80:	f3 0f 1e fa          	endbr64
 1012a84:	55                   	push   %rbp
 1012a85:	48 89 e5             	mov    %rsp,%rbp
 1012a88:	48 81 ec 78 01 00 00 	sub    $0x178,%rsp
 1012a8f:	53                   	push   %rbx
 1012a90:	41 54                	push   %r12
 1012a92:	41 55                	push   %r13
 1012a94:	41 56                	push   %r14
 1012a96:	41 57                	push   %r15
 1012a98:	49 89 f5             	mov    %rsi,%r13
 1012a9b:	48 8b 47 40          	mov    0x40(%rdi),%rax
 1012a9f:	48 8d 4d e8          	lea    -0x18(%rbp),%rcx
 1012aa3:	48 39 c1             	cmp    %rax,%rcx
 1012aa6:	0f 82 4c 0e 00 00    	jb     10138f8 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xe78>
 1012aac:	49 83 fd 00          	cmp    $0x0,%r13
 1012ab0:	0f 84 13 0e 00 00    	je     10138c9 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xe49>
 1012ab6:	48 89 fb             	mov    %rdi,%rbx
 1012ab9:	e8 d2 70 00 00       	call   1019b90 <myl_qbe_heap>
 1012abe:	48 89 df             	mov    %rbx,%rdi
 1012ac1:	48 89 c3             	mov    %rax,%rbx
 1012ac4:	49 89 fc             	mov    %rdi,%r12
 1012ac7:	e8 04 94 00 00       	call   101bed0 <myl_qbe_region_mark>
 1012acc:	4c 89 ea             	mov    %r13,%rdx
 1012acf:	4c 89 e7             	mov    %r12,%rdi
 1012ad2:	49 89 c7             	mov    %rax,%r15
 1012ad5:	49 89 d5             	mov    %rdx,%r13
 1012ad8:	ba 20 00 00 00       	mov    $0x20,%edx
 1012add:	be 00 00 00 00       	mov    $0x0,%esi
 1012ae2:	49 89 fc             	mov    %rdi,%r12
 1012ae5:	48 8d bd 60 ff ff ff 	lea    -0xa0(%rbp),%rdi
 1012aec:	e8 0f 75 01 00       	call   102a000 <compiler_rt.fastMemset>
 1012af1:	4c 89 ea             	mov    %r13,%rdx
 1012af4:	4c 89 e7             	mov    %r12,%rdi
 1012af7:	49 89 d5             	mov    %rdx,%r13
 1012afa:	ba 80 00 00 00       	mov    $0x80,%edx
 1012aff:	be 00 00 00 00       	mov    $0x0,%esi
 1012b04:	49 89 fc             	mov    %rdi,%r12
 1012b07:	48 8d bd e0 fe ff ff 	lea    -0x120(%rbp),%rdi
 1012b0e:	e8 ed 74 01 00       	call   102a000 <compiler_rt.fastMemset>
 1012b13:	4c 89 ea             	mov    %r13,%rdx
 1012b16:	4c 89 e7             	mov    %r12,%rdi
 1012b19:	48 8d 05 98 19 ff ff 	lea    -0xe668(%rip),%rax        # 10044b8 <myl_t_385cfdbc00ec32031699460779c15099b2bba3cad0e440fffb08e10df0acb9e1>
 1012b20:	48 89 85 e0 fe ff ff 	mov    %rax,-0x120(%rbp)
 1012b27:	c7 85 f8 fe ff ff 00 	movl   $0x0,-0x108(%rbp)
 1012b2e:	00 00 00 
 1012b31:	48 8d 45 80          	lea    -0x80(%rbp),%rax
 1012b35:	48 89 85 e8 fe ff ff 	mov    %rax,-0x118(%rbp)
 1012b3c:	48 8d 85 60 ff ff ff 	lea    -0xa0(%rbp),%rax
 1012b43:	48 89 85 f0 fe ff ff 	mov    %rax,-0x110(%rbp)
 1012b4a:	48 8d 05 67 19 ff ff 	lea    -0xe699(%rip),%rax        # 10044b8 <myl_t_385cfdbc00ec32031699460779c15099b2bba3cad0e440fffb08e10df0acb9e1>
 1012b51:	48 89 85 00 ff ff ff 	mov    %rax,-0x100(%rbp)
 1012b58:	c7 85 18 ff ff ff 00 	movl   $0x0,-0xe8(%rbp)
 1012b5f:	00 00 00 
 1012b62:	48 8d 45 90          	lea    -0x70(%rbp),%rax
 1012b66:	48 89 85 08 ff ff ff 	mov    %rax,-0xf8(%rbp)
 1012b6d:	48 8d 85 60 ff ff ff 	lea    -0xa0(%rbp),%rax
 1012b74:	48 83 c0 08          	add    $0x8,%rax
 1012b78:	48 89 85 10 ff ff ff 	mov    %rax,-0xf0(%rbp)
 1012b7f:	48 8d 05 32 19 ff ff 	lea    -0xe6ce(%rip),%rax        # 10044b8 <myl_t_385cfdbc00ec32031699460779c15099b2bba3cad0e440fffb08e10df0acb9e1>
 1012b86:	48 89 85 20 ff ff ff 	mov    %rax,-0xe0(%rbp)
 1012b8d:	c7 85 38 ff ff ff 00 	movl   $0x0,-0xc8(%rbp)
 1012b94:	00 00 00 
 1012b97:	48 8d 45 a0          	lea    -0x60(%rbp),%rax
 1012b9b:	48 89 85 28 ff ff ff 	mov    %rax,-0xd8(%rbp)
 1012ba2:	48 8d 85 60 ff ff ff 	lea    -0xa0(%rbp),%rax
 1012ba9:	48 83 c0 10          	add    $0x10,%rax
 1012bad:	48 89 85 30 ff ff ff 	mov    %rax,-0xd0(%rbp)
 1012bb4:	48 8d 05 fd 18 ff ff 	lea    -0xe703(%rip),%rax        # 10044b8 <myl_t_385cfdbc00ec32031699460779c15099b2bba3cad0e440fffb08e10df0acb9e1>
 1012bbb:	48 89 85 40 ff ff ff 	mov    %rax,-0xc0(%rbp)
 1012bc2:	c7 85 58 ff ff ff 00 	movl   $0x0,-0xa8(%rbp)
 1012bc9:	00 00 00 
 1012bcc:	48 8d 45 b0          	lea    -0x50(%rbp),%rax
 1012bd0:	48 89 85 48 ff ff ff 	mov    %rax,-0xb8(%rbp)
 1012bd7:	48 8d 85 60 ff ff ff 	lea    -0xa0(%rbp),%rax
 1012bde:	49 89 c4             	mov    %rax,%r12
 1012be1:	49 83 c4 18          	add    $0x18,%r12
 1012be5:	4c 89 65 f8          	mov    %r12,-0x8(%rbp)
 1012be9:	4c 89 a5 50 ff ff ff 	mov    %r12,-0xb0(%rbp)
 1012bf0:	b9 04 00 00 00       	mov    $0x4,%ecx
 1012bf5:	49 89 d5             	mov    %rdx,%r13
 1012bf8:	48 8d 95 e0 fe ff ff 	lea    -0x120(%rbp),%rdx
 1012bff:	48 8d b5 c0 fe ff ff 	lea    -0x140(%rbp),%rsi
 1012c06:	49 89 fe             	mov    %rdi,%r14
 1012c09:	e8 92 66 00 00       	call   10192a0 <myl_qbe_rc_frame_enter>
 1012c0e:	4c 89 f7             	mov    %r14,%rdi
 1012c11:	4c 89 6d b8          	mov    %r13,-0x48(%rbp)
 1012c15:	48 c7 45 c0 01 00 00 	movq   $0x1,-0x40(%rbp)
 1012c1c:	00 
 1012c1d:	48 b8 01 00 00 00 00 	movabs $0x8000000000000001,%rax
 1012c24:	00 00 80 
 1012c27:	49 39 c5             	cmp    %rax,%r13
 1012c2a:	0f 8c 7f 0c 00 00    	jl     10138af <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xe2f>
 1012c30:	4c 89 ee             	mov    %r13,%rsi
 1012c33:	48 83 ee 01          	sub    $0x1,%rsi
 1012c37:	48 89 75 f0          	mov    %rsi,-0x10(%rbp)
 1012c3b:	48 89 75 b8          	mov    %rsi,-0x48(%rbp)
 1012c3f:	49 89 fe             	mov    %rdi,%r14
 1012c42:	e8 39 fe ff ff       	call   1012a80 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531>
 1012c47:	4c 89 f7             	mov    %r14,%rdi
 1012c4a:	48 89 c1             	mov    %rax,%rcx
 1012c4d:	48 89 d0             	mov    %rdx,%rax
 1012c50:	4c 89 ea             	mov    %r13,%rdx
 1012c53:	48 89 8d 90 fe ff ff 	mov    %rcx,-0x170(%rbp)
 1012c5a:	48 89 85 98 fe ff ff 	mov    %rax,-0x168(%rbp)
 1012c61:	48 8d 85 90 fe ff ff 	lea    -0x170(%rbp),%rax
 1012c68:	48 89 45 b8          	mov    %rax,-0x48(%rbp)
 1012c6c:	48 8b 85 90 fe ff ff 	mov    -0x170(%rbp),%rax
 1012c73:	48 89 45 a0          	mov    %rax,-0x60(%rbp)
 1012c77:	48 8b 85 98 fe ff ff 	mov    -0x168(%rbp),%rax
 1012c7e:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
 1012c82:	48 8d 05 17 b9 01 00 	lea    0x1b917(%rip),%rax        # 102e5a0 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 1012c89:	48 89 85 20 ff ff ff 	mov    %rax,-0xe0(%rbp)
 1012c90:	c7 85 38 ff ff ff 02 	movl   $0x2,-0xc8(%rbp)
 1012c97:	00 00 00 
 1012c9a:	c7 85 70 ff ff ff 01 	movl   $0x1,-0x90(%rbp)
 1012ca1:	00 00 00 
 1012ca4:	48 8b 45 a0          	mov    -0x60(%rbp),%rax
 1012ca8:	48 89 45 80          	mov    %rax,-0x80(%rbp)
 1012cac:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
 1012cb0:	48 89 45 88          	mov    %rax,-0x78(%rbp)
 1012cb4:	48 8d 05 e5 b8 01 00 	lea    0x1b8e5(%rip),%rax        # 102e5a0 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 1012cbb:	48 89 85 e0 fe ff ff 	mov    %rax,-0x120(%rbp)
 1012cc2:	c7 85 f8 fe ff ff 02 	movl   $0x2,-0x108(%rbp)
 1012cc9:	00 00 00 
 1012ccc:	c7 85 f8 fe ff ff 02 	movl   $0x2,-0x108(%rbp)
 1012cd3:	00 00 00 
 1012cd6:	c7 85 70 ff ff ff 00 	movl   $0x0,-0x90(%rbp)
 1012cdd:	00 00 00 
 1012ce0:	c7 85 60 ff ff ff 01 	movl   $0x1,-0xa0(%rbp)
 1012ce7:	00 00 00 
 1012cea:	48 8d 45 80          	lea    -0x80(%rbp),%rax
 1012cee:	48 89 45 b8          	mov    %rax,-0x48(%rbp)
 1012cf2:	49 89 d6             	mov    %rdx,%r14
 1012cf5:	ba 01 00 00 00       	mov    $0x1,%edx
 1012cfa:	48 8d 35 8f b5 01 00 	lea    0x1b58f(%rip),%rsi        # 102e290 <myl_t_1e414bd82e4b50b54939760a2d591f88da97e2f1c8252dbd7dcbc73438e46afb_body>
 1012d01:	49 89 fd             	mov    %rdi,%r13
 1012d04:	48 89 df             	mov    %rbx,%rdi
 1012d07:	e8 64 b5 00 00       	call   101e270 <myl_native_heap_alloc>
 1012d0c:	4c 89 f2             	mov    %r14,%rdx
 1012d0f:	4c 89 ef             	mov    %r13,%rdi
 1012d12:	49 89 c5             	mov    %rax,%r13
 1012d15:	41 83 fd 00          	cmp    $0x0,%r13d
 1012d19:	75 0a                	jne    1012d25 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x2a5>
 1012d1b:	48 89 fb             	mov    %rdi,%rbx
 1012d1e:	e8 ed 6b 00 00       	call   1019910 <myl_qbe_fail_allocation>
 1012d23:	0f 0b                	ud2
 1012d25:	48 87 fb             	xchg   %rdi,%rbx
 1012d28:	4c 89 6d b0          	mov    %r13,-0x50(%rbp)
 1012d2c:	48 8d 05 cd b5 01 00 	lea    0x1b5cd(%rip),%rax        # 102e300 <myl_t_1e414bd82e4b50b54939760a2d591f88da97e2f1c8252dbd7dcbc73438e46afb>
 1012d33:	48 89 85 40 ff ff ff 	mov    %rax,-0xc0(%rbp)
 1012d3a:	c7 85 58 ff ff ff 02 	movl   $0x2,-0xa8(%rbp)
 1012d41:	00 00 00 
 1012d44:	48 8d 45 b0          	lea    -0x50(%rbp),%rax
 1012d48:	48 89 85 48 ff ff ff 	mov    %rax,-0xb8(%rbp)
 1012d4f:	4c 89 a5 50 ff ff ff 	mov    %r12,-0xb0(%rbp)
 1012d56:	c7 85 58 ff ff ff 04 	movl   $0x4,-0xa8(%rbp)
 1012d5d:	00 00 00 
 1012d60:	c7 85 78 ff ff ff 01 	movl   $0x1,-0x88(%rbp)
 1012d67:	00 00 00 
 1012d6a:	48 8b 45 b8          	mov    -0x48(%rbp),%rax
 1012d6e:	8b 8d 60 ff ff ff    	mov    -0xa0(%rbp),%ecx
 1012d74:	8b b5 f8 fe ff ff    	mov    -0x108(%rbp),%esi
 1012d7a:	83 e6 18             	and    $0x18,%esi
 1012d7d:	83 fe 00             	cmp    $0x0,%esi
 1012d80:	40 0f 94 c6          	sete   %sil
 1012d84:	40 0f b6 f6          	movzbl %sil,%esi
 1012d88:	85 ce                	test   %ecx,%esi
 1012d8a:	0f 85 10 01 00 00    	jne    1012ea0 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x420>
 1012d90:	48 8b 08             	mov    (%rax),%rcx
 1012d93:	48 83 f9 00          	cmp    $0x0,%rcx
 1012d97:	74 1a                	je     1012db3 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x333>
 1012d99:	48 83 e9 10          	sub    $0x10,%rcx
 1012d9d:	48 8b 09             	mov    (%rcx),%rcx
 1012da0:	48 be 01 00 00 00 00 	movabs $0x5000000000000001,%rsi
 1012da7:	00 00 50 
 1012daa:	48 21 f1             	and    %rsi,%rcx
 1012dad:	48 83 f9 00          	cmp    $0x0,%rcx
 1012db1:	75 5d                	jne    1012e10 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x390>
 1012db3:	48 8b 48 08          	mov    0x8(%rax),%rcx
 1012db7:	48 83 f9 00          	cmp    $0x0,%rcx
 1012dbb:	74 1a                	je     1012dd7 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x357>
 1012dbd:	48 83 e9 10          	sub    $0x10,%rcx
 1012dc1:	48 8b 09             	mov    (%rcx),%rcx
 1012dc4:	48 be 01 00 00 00 00 	movabs $0x5000000000000001,%rsi
 1012dcb:	00 00 50 
 1012dce:	48 21 f1             	and    %rsi,%rcx
 1012dd1:	48 83 f9 00          	cmp    $0x0,%rcx
 1012dd5:	75 39                	jne    1012e10 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x390>
 1012dd7:	48 8b 08             	mov    (%rax),%rcx
 1012dda:	48 89 4d a0          	mov    %rcx,-0x60(%rbp)
 1012dde:	48 8b 48 08          	mov    0x8(%rax),%rcx
 1012de2:	48 89 4d a8          	mov    %rcx,-0x58(%rbp)
 1012de6:	49 89 d6             	mov    %rdx,%r14
 1012de9:	ba 10 00 00 00       	mov    $0x10,%edx
 1012dee:	be 00 00 00 00       	mov    $0x0,%esi
 1012df3:	49 89 fc             	mov    %rdi,%r12
 1012df6:	48 89 c7             	mov    %rax,%rdi
 1012df9:	e8 02 72 01 00       	call   102a000 <compiler_rt.fastMemset>
 1012dfe:	4d 89 f8             	mov    %r15,%r8
 1012e01:	4c 89 f2             	mov    %r14,%rdx
 1012e04:	4c 89 e7             	mov    %r12,%rdi
 1012e07:	4c 8b 65 f8          	mov    -0x8(%rbp),%r12
 1012e0b:	4d 89 c7             	mov    %r8,%r15
 1012e0e:	eb 48                	jmp    1012e58 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x3d8>
 1012e10:	4d 89 f8             	mov    %r15,%r8
 1012e13:	4d 89 c7             	mov    %r8,%r15
 1012e16:	48 89 c1             	mov    %rax,%rcx
 1012e19:	49 89 d6             	mov    %rdx,%r14
 1012e1c:	48 8d 55 a0          	lea    -0x60(%rbp),%rdx
 1012e20:	48 8d 35 79 b7 01 00 	lea    0x1b779(%rip),%rsi        # 102e5a0 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 1012e27:	49 89 fc             	mov    %rdi,%r12
 1012e2a:	e8 e1 6c 01 00       	call   1029b10 <myl_rc_native_take>
 1012e2f:	4c 89 f2             	mov    %r14,%rdx
 1012e32:	4c 89 e7             	mov    %r12,%rdi
 1012e35:	4c 8b 65 f8          	mov    -0x8(%rbp),%r12
 1012e39:	83 f8 00             	cmp    $0x0,%eax
 1012e3c:	75 1a                	jne    1012e58 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x3d8>
 1012e3e:	e8 9d ec 00 00       	call   1021ae0 <myl_rc_take_failure>
 1012e43:	48 89 df             	mov    %rbx,%rdi
 1012e46:	89 c6                	mov    %eax,%esi
 1012e48:	48 89 fb             	mov    %rdi,%rbx
 1012e4b:	e8 60 63 00 00       	call   10191b0 <myl_qbe_rc_status>
 1012e50:	48 89 df             	mov    %rbx,%rdi
 1012e53:	e9 af 09 00 00       	jmp    1013807 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xd87>
 1012e58:	c7 85 60 ff ff ff 00 	movl   $0x0,-0xa0(%rbp)
 1012e5f:	00 00 00 
 1012e62:	48 8d 05 37 b7 01 00 	lea    0x1b737(%rip),%rax        # 102e5a0 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 1012e69:	48 89 85 20 ff ff ff 	mov    %rax,-0xe0(%rbp)
 1012e70:	c7 85 38 ff ff ff 02 	movl   $0x2,-0xc8(%rbp)
 1012e77:	00 00 00 
 1012e7a:	c7 85 70 ff ff ff 01 	movl   $0x1,-0x90(%rbp)
 1012e81:	00 00 00 
 1012e84:	48 8b 45 a0          	mov    -0x60(%rbp),%rax
 1012e88:	49 89 45 00          	mov    %rax,0x0(%r13)
 1012e8c:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
 1012e90:	49 89 45 08          	mov    %rax,0x8(%r13)
 1012e94:	c7 85 70 ff ff ff 00 	movl   $0x0,-0x90(%rbp)
 1012e9b:	00 00 00 
 1012e9e:	eb 19                	jmp    1012eb9 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x439>
 1012ea0:	48 8b 08             	mov    (%rax),%rcx
 1012ea3:	49 89 4d 00          	mov    %rcx,0x0(%r13)
 1012ea7:	48 8b 40 08          	mov    0x8(%rax),%rax
 1012eab:	49 89 45 08          	mov    %rax,0x8(%r13)
 1012eaf:	c7 85 60 ff ff ff 00 	movl   $0x0,-0xa0(%rbp)
 1012eb6:	00 00 00 
 1012eb9:	4c 89 6d b8          	mov    %r13,-0x48(%rbp)
 1012ebd:	48 8b 45 b8          	mov    -0x48(%rbp),%rax
 1012ec1:	48 89 45 80          	mov    %rax,-0x80(%rbp)
 1012ec5:	48 8d 05 34 b4 01 00 	lea    0x1b434(%rip),%rax        # 102e300 <myl_t_1e414bd82e4b50b54939760a2d591f88da97e2f1c8252dbd7dcbc73438e46afb>
 1012ecc:	48 89 85 e0 fe ff ff 	mov    %rax,-0x120(%rbp)
 1012ed3:	c7 85 f8 fe ff ff 02 	movl   $0x2,-0x108(%rbp)
 1012eda:	00 00 00 
 1012edd:	c7 85 60 ff ff ff 01 	movl   $0x1,-0xa0(%rbp)
 1012ee4:	00 00 00 
 1012ee7:	4c 89 6d b8          	mov    %r13,-0x48(%rbp)
 1012eeb:	c7 85 78 ff ff ff 00 	movl   $0x0,-0x88(%rbp)
 1012ef2:	00 00 00 
 1012ef5:	49 89 d6             	mov    %rdx,%r14
 1012ef8:	ba 08 00 00 00       	mov    $0x8,%edx
 1012efd:	be 00 00 00 00       	mov    $0x0,%esi
 1012f02:	49 89 fd             	mov    %rdi,%r13
 1012f05:	48 8d 7d c8          	lea    -0x38(%rbp),%rdi
 1012f09:	e8 f2 70 01 00       	call   102a000 <compiler_rt.fastMemset>
 1012f0e:	4c 89 f2             	mov    %r14,%rdx
 1012f11:	4c 89 ef             	mov    %r13,%rdi
 1012f14:	48 8b 75 f0          	mov    -0x10(%rbp),%rsi
 1012f18:	48 8d 05 11 b6 01 00 	lea    0x1b611(%rip),%rax        # 102e530 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 1012f1f:	48 89 85 40 ff ff ff 	mov    %rax,-0xc0(%rbp)
 1012f26:	c7 85 58 ff ff ff 02 	movl   $0x2,-0xa8(%rbp)
 1012f2d:	00 00 00 
 1012f30:	48 8d 45 c8          	lea    -0x38(%rbp),%rax
 1012f34:	48 89 85 48 ff ff ff 	mov    %rax,-0xb8(%rbp)
 1012f3b:	4c 89 a5 50 ff ff ff 	mov    %r12,-0xb0(%rbp)
 1012f42:	c7 85 78 ff ff ff 01 	movl   $0x1,-0x88(%rbp)
 1012f49:	00 00 00 
 1012f4c:	8b 85 60 ff ff ff    	mov    -0xa0(%rbp),%eax
 1012f52:	8b 8d f8 fe ff ff    	mov    -0x108(%rbp),%ecx
 1012f58:	83 e1 18             	and    $0x18,%ecx
 1012f5b:	83 f9 00             	cmp    $0x0,%ecx
 1012f5e:	0f 94 c1             	sete   %cl
 1012f61:	0f b6 c9             	movzbl %cl,%ecx
 1012f64:	85 c1                	test   %eax,%ecx
 1012f66:	0f 85 e6 00 00 00    	jne    1013052 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x5d2>
 1012f6c:	48 8b 45 b8          	mov    -0x48(%rbp),%rax
 1012f70:	48 83 f8 00          	cmp    $0x0,%rax
 1012f74:	74 1a                	je     1012f90 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x510>
 1012f76:	48 83 e8 10          	sub    $0x10,%rax
 1012f7a:	48 8b 00             	mov    (%rax),%rax
 1012f7d:	48 b9 01 00 00 00 00 	movabs $0x5000000000000001,%rcx
 1012f84:	00 00 50 
 1012f87:	48 21 c8             	and    %rcx,%rax
 1012f8a:	48 83 f8 00          	cmp    $0x0,%rax
 1012f8e:	75 36                	jne    1012fc6 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x546>
 1012f90:	48 8b 45 b8          	mov    -0x48(%rbp),%rax
 1012f94:	48 89 45 a0          	mov    %rax,-0x60(%rbp)
 1012f98:	49 89 d6             	mov    %rdx,%r14
 1012f9b:	ba 08 00 00 00       	mov    $0x8,%edx
 1012fa0:	be 00 00 00 00       	mov    $0x0,%esi
 1012fa5:	49 89 fd             	mov    %rdi,%r13
 1012fa8:	48 8d 7d b8          	lea    -0x48(%rbp),%rdi
 1012fac:	e8 4f 70 01 00       	call   102a000 <compiler_rt.fastMemset>
 1012fb1:	4d 89 f8             	mov    %r15,%r8
 1012fb4:	4c 89 f2             	mov    %r14,%rdx
 1012fb7:	4c 89 ef             	mov    %r13,%rdi
 1012fba:	48 8b 75 f0          	mov    -0x10(%rbp),%rsi
 1012fbe:	4d 89 c7             	mov    %r8,%r15
 1012fc1:	48 87 df             	xchg   %rbx,%rdi
 1012fc4:	eb 4c                	jmp    1013012 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x592>
 1012fc6:	4d 89 f8             	mov    %r15,%r8
 1012fc9:	4d 89 c7             	mov    %r8,%r15
 1012fcc:	48 8d 4d b8          	lea    -0x48(%rbp),%rcx
 1012fd0:	49 89 d6             	mov    %rdx,%r14
 1012fd3:	48 8d 55 a0          	lea    -0x60(%rbp),%rdx
 1012fd7:	48 8d 35 22 b3 01 00 	lea    0x1b322(%rip),%rsi        # 102e300 <myl_t_1e414bd82e4b50b54939760a2d591f88da97e2f1c8252dbd7dcbc73438e46afb>
 1012fde:	49 89 fd             	mov    %rdi,%r13
 1012fe1:	e8 2a 6b 01 00       	call   1029b10 <myl_rc_native_take>
 1012fe6:	4c 89 f2             	mov    %r14,%rdx
 1012fe9:	4c 89 ef             	mov    %r13,%rdi
 1012fec:	48 8b 75 f0          	mov    -0x10(%rbp),%rsi
 1012ff0:	83 f8 00             	cmp    $0x0,%eax
 1012ff3:	75 1a                	jne    101300f <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x58f>
 1012ff5:	e8 e6 ea 00 00       	call   1021ae0 <myl_rc_take_failure>
 1012ffa:	48 89 df             	mov    %rbx,%rdi
 1012ffd:	89 c6                	mov    %eax,%esi
 1012fff:	48 89 fb             	mov    %rdi,%rbx
 1013002:	e8 a9 61 00 00       	call   10191b0 <myl_qbe_rc_status>
 1013007:	48 89 df             	mov    %rbx,%rdi
 101300a:	e9 f8 07 00 00       	jmp    1013807 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xd87>
 101300f:	48 87 df             	xchg   %rbx,%rdi
 1013012:	c7 85 60 ff ff ff 00 	movl   $0x0,-0xa0(%rbp)
 1013019:	00 00 00 
 101301c:	48 8d 05 dd b2 01 00 	lea    0x1b2dd(%rip),%rax        # 102e300 <myl_t_1e414bd82e4b50b54939760a2d591f88da97e2f1c8252dbd7dcbc73438e46afb>
 1013023:	48 89 85 20 ff ff ff 	mov    %rax,-0xe0(%rbp)
 101302a:	c7 85 38 ff ff ff 02 	movl   $0x2,-0xc8(%rbp)
 1013031:	00 00 00 
 1013034:	c7 85 70 ff ff ff 01 	movl   $0x1,-0x90(%rbp)
 101303b:	00 00 00 
 101303e:	48 8b 45 a0          	mov    -0x60(%rbp),%rax
 1013042:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
 1013046:	c7 85 70 ff ff ff 00 	movl   $0x0,-0x90(%rbp)
 101304d:	00 00 00 
 1013050:	eb 15                	jmp    1013067 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x5e7>
 1013052:	48 87 df             	xchg   %rbx,%rdi
 1013055:	48 8b 45 b8          	mov    -0x48(%rbp),%rax
 1013059:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
 101305d:	c7 85 60 ff ff ff 00 	movl   $0x0,-0xa0(%rbp)
 1013064:	00 00 00 
 1013067:	48 8d 45 c8          	lea    -0x38(%rbp),%rax
 101306b:	48 89 45 b8          	mov    %rax,-0x48(%rbp)
 101306f:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
 1013073:	48 89 45 80          	mov    %rax,-0x80(%rbp)
 1013077:	48 8d 05 b2 b4 01 00 	lea    0x1b4b2(%rip),%rax        # 102e530 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 101307e:	48 89 85 e0 fe ff ff 	mov    %rax,-0x120(%rbp)
 1013085:	c7 85 f8 fe ff ff 02 	movl   $0x2,-0x108(%rbp)
 101308c:	00 00 00 
 101308f:	c7 85 60 ff ff ff 01 	movl   $0x1,-0xa0(%rbp)
 1013096:	00 00 00 
 1013099:	48 8d 45 80          	lea    -0x80(%rbp),%rax
 101309d:	48 89 45 b8          	mov    %rax,-0x48(%rbp)
 10130a1:	c7 85 78 ff ff ff 00 	movl   $0x0,-0x88(%rbp)
 10130a8:	00 00 00 
 10130ab:	48 89 55 c0          	mov    %rdx,-0x40(%rbp)
 10130af:	48 89 75 c0          	mov    %rsi,-0x40(%rbp)
 10130b3:	49 89 fd             	mov    %rdi,%r13
 10130b6:	e8 c5 f9 ff ff       	call   1012a80 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531>
 10130bb:	4c 89 ef             	mov    %r13,%rdi
 10130be:	48 89 c1             	mov    %rax,%rcx
 10130c1:	48 89 d0             	mov    %rdx,%rax
 10130c4:	48 89 8d a0 fe ff ff 	mov    %rcx,-0x160(%rbp)
 10130cb:	48 89 85 a8 fe ff ff 	mov    %rax,-0x158(%rbp)
 10130d2:	48 8d 85 a0 fe ff ff 	lea    -0x160(%rbp),%rax
 10130d9:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
 10130dd:	48 8b 85 a0 fe ff ff 	mov    -0x160(%rbp),%rax
 10130e4:	48 89 45 a0          	mov    %rax,-0x60(%rbp)
 10130e8:	48 8b 85 a8 fe ff ff 	mov    -0x158(%rbp),%rax
 10130ef:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
 10130f3:	48 8d 05 a6 b4 01 00 	lea    0x1b4a6(%rip),%rax        # 102e5a0 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 10130fa:	48 89 85 20 ff ff ff 	mov    %rax,-0xe0(%rbp)
 1013101:	c7 85 38 ff ff ff 02 	movl   $0x2,-0xc8(%rbp)
 1013108:	00 00 00 
 101310b:	c7 85 70 ff ff ff 01 	movl   $0x1,-0x90(%rbp)
 1013112:	00 00 00 
 1013115:	48 8b 45 a0          	mov    -0x60(%rbp),%rax
 1013119:	48 89 45 90          	mov    %rax,-0x70(%rbp)
 101311d:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
 1013121:	48 89 45 98          	mov    %rax,-0x68(%rbp)
 1013125:	48 8d 05 74 b4 01 00 	lea    0x1b474(%rip),%rax        # 102e5a0 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 101312c:	48 89 85 00 ff ff ff 	mov    %rax,-0x100(%rbp)
 1013133:	c7 85 18 ff ff ff 02 	movl   $0x2,-0xe8(%rbp)
 101313a:	00 00 00 
 101313d:	c7 85 18 ff ff ff 02 	movl   $0x2,-0xe8(%rbp)
 1013144:	00 00 00 
 1013147:	c7 85 70 ff ff ff 00 	movl   $0x0,-0x90(%rbp)
 101314e:	00 00 00 
 1013151:	c7 85 68 ff ff ff 01 	movl   $0x1,-0x98(%rbp)
 1013158:	00 00 00 
 101315b:	48 8d 45 90          	lea    -0x70(%rbp),%rax
 101315f:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
 1013163:	ba 01 00 00 00       	mov    $0x1,%edx
 1013168:	48 8d 35 21 b1 01 00 	lea    0x1b121(%rip),%rsi        # 102e290 <myl_t_1e414bd82e4b50b54939760a2d591f88da97e2f1c8252dbd7dcbc73438e46afb_body>
 101316f:	49 89 fd             	mov    %rdi,%r13
 1013172:	48 89 df             	mov    %rbx,%rdi
 1013175:	e8 f6 b0 00 00       	call   101e270 <myl_native_heap_alloc>
 101317a:	4c 89 ef             	mov    %r13,%rdi
 101317d:	49 89 c5             	mov    %rax,%r13
 1013180:	41 83 fd 00          	cmp    $0x0,%r13d
 1013184:	75 0a                	jne    1013190 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x710>
 1013186:	48 89 fb             	mov    %rdi,%rbx
 1013189:	e8 82 67 00 00       	call   1019910 <myl_qbe_fail_allocation>
 101318e:	0f 0b                	ud2
 1013190:	48 87 fb             	xchg   %rdi,%rbx
 1013193:	4c 89 6d b0          	mov    %r13,-0x50(%rbp)
 1013197:	48 8d 05 62 b1 01 00 	lea    0x1b162(%rip),%rax        # 102e300 <myl_t_1e414bd82e4b50b54939760a2d591f88da97e2f1c8252dbd7dcbc73438e46afb>
 101319e:	48 89 85 40 ff ff ff 	mov    %rax,-0xc0(%rbp)
 10131a5:	c7 85 58 ff ff ff 02 	movl   $0x2,-0xa8(%rbp)
 10131ac:	00 00 00 
 10131af:	48 8d 45 b0          	lea    -0x50(%rbp),%rax
 10131b3:	48 89 85 48 ff ff ff 	mov    %rax,-0xb8(%rbp)
 10131ba:	4c 89 a5 50 ff ff ff 	mov    %r12,-0xb0(%rbp)
 10131c1:	c7 85 58 ff ff ff 04 	movl   $0x4,-0xa8(%rbp)
 10131c8:	00 00 00 
 10131cb:	c7 85 78 ff ff ff 01 	movl   $0x1,-0x88(%rbp)
 10131d2:	00 00 00 
 10131d5:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
 10131d9:	8b 8d 68 ff ff ff    	mov    -0x98(%rbp),%ecx
 10131df:	8b 95 18 ff ff ff    	mov    -0xe8(%rbp),%edx
 10131e5:	83 e2 18             	and    $0x18,%edx
 10131e8:	83 fa 00             	cmp    $0x0,%edx
 10131eb:	0f 94 c2             	sete   %dl
 10131ee:	0f b6 d2             	movzbl %dl,%edx
 10131f1:	85 ca                	test   %ecx,%edx
 10131f3:	0f 85 fc 00 00 00    	jne    10132f5 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x875>
 10131f9:	48 8b 08             	mov    (%rax),%rcx
 10131fc:	48 83 f9 00          	cmp    $0x0,%rcx
 1013200:	74 1a                	je     101321c <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x79c>
 1013202:	48 83 e9 10          	sub    $0x10,%rcx
 1013206:	48 8b 09             	mov    (%rcx),%rcx
 1013209:	48 ba 01 00 00 00 00 	movabs $0x5000000000000001,%rdx
 1013210:	00 00 50 
 1013213:	48 21 d1             	and    %rdx,%rcx
 1013216:	48 83 f9 00          	cmp    $0x0,%rcx
 101321a:	75 53                	jne    101326f <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x7ef>
 101321c:	48 8b 48 08          	mov    0x8(%rax),%rcx
 1013220:	48 83 f9 00          	cmp    $0x0,%rcx
 1013224:	74 1a                	je     1013240 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x7c0>
 1013226:	48 83 e9 10          	sub    $0x10,%rcx
 101322a:	48 8b 09             	mov    (%rcx),%rcx
 101322d:	48 ba 01 00 00 00 00 	movabs $0x5000000000000001,%rdx
 1013234:	00 00 50 
 1013237:	48 21 d1             	and    %rdx,%rcx
 101323a:	48 83 f9 00          	cmp    $0x0,%rcx
 101323e:	75 2f                	jne    101326f <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x7ef>
 1013240:	48 8b 08             	mov    (%rax),%rcx
 1013243:	48 89 4d a0          	mov    %rcx,-0x60(%rbp)
 1013247:	48 8b 48 08          	mov    0x8(%rax),%rcx
 101324b:	48 89 4d a8          	mov    %rcx,-0x58(%rbp)
 101324f:	ba 10 00 00 00       	mov    $0x10,%edx
 1013254:	be 00 00 00 00       	mov    $0x0,%esi
 1013259:	49 89 fe             	mov    %rdi,%r14
 101325c:	48 89 c7             	mov    %rax,%rdi
 101325f:	e8 9c 6d 01 00       	call   102a000 <compiler_rt.fastMemset>
 1013264:	4d 89 f8             	mov    %r15,%r8
 1013267:	4c 89 f7             	mov    %r14,%rdi
 101326a:	4d 89 c6             	mov    %r8,%r14
 101326d:	eb 3e                	jmp    10132ad <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x82d>
 101326f:	4d 89 f8             	mov    %r15,%r8
 1013272:	4d 89 c6             	mov    %r8,%r14
 1013275:	48 89 c1             	mov    %rax,%rcx
 1013278:	48 8d 55 a0          	lea    -0x60(%rbp),%rdx
 101327c:	48 8d 35 1d b3 01 00 	lea    0x1b31d(%rip),%rsi        # 102e5a0 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 1013283:	49 89 ff             	mov    %rdi,%r15
 1013286:	e8 85 68 01 00       	call   1029b10 <myl_rc_native_take>
 101328b:	4c 89 ff             	mov    %r15,%rdi
 101328e:	83 f8 00             	cmp    $0x0,%eax
 1013291:	75 1a                	jne    10132ad <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x82d>
 1013293:	e8 48 e8 00 00       	call   1021ae0 <myl_rc_take_failure>
 1013298:	48 89 df             	mov    %rbx,%rdi
 101329b:	89 c6                	mov    %eax,%esi
 101329d:	48 89 fb             	mov    %rdi,%rbx
 10132a0:	e8 0b 5f 00 00       	call   10191b0 <myl_qbe_rc_status>
 10132a5:	48 89 df             	mov    %rbx,%rdi
 10132a8:	e9 5a 05 00 00       	jmp    1013807 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xd87>
 10132ad:	c7 85 68 ff ff ff 00 	movl   $0x0,-0x98(%rbp)
 10132b4:	00 00 00 
 10132b7:	48 8d 05 e2 b2 01 00 	lea    0x1b2e2(%rip),%rax        # 102e5a0 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 10132be:	48 89 85 20 ff ff ff 	mov    %rax,-0xe0(%rbp)
 10132c5:	c7 85 38 ff ff ff 02 	movl   $0x2,-0xc8(%rbp)
 10132cc:	00 00 00 
 10132cf:	c7 85 70 ff ff ff 01 	movl   $0x1,-0x90(%rbp)
 10132d6:	00 00 00 
 10132d9:	48 8b 45 a0          	mov    -0x60(%rbp),%rax
 10132dd:	49 89 45 00          	mov    %rax,0x0(%r13)
 10132e1:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
 10132e5:	49 89 45 08          	mov    %rax,0x8(%r13)
 10132e9:	c7 85 70 ff ff ff 00 	movl   $0x0,-0x90(%rbp)
 10132f0:	00 00 00 
 10132f3:	eb 1c                	jmp    1013311 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x891>
 10132f5:	4d 89 fe             	mov    %r15,%r14
 10132f8:	48 8b 08             	mov    (%rax),%rcx
 10132fb:	49 89 4d 00          	mov    %rcx,0x0(%r13)
 10132ff:	48 8b 40 08          	mov    0x8(%rax),%rax
 1013303:	49 89 45 08          	mov    %rax,0x8(%r13)
 1013307:	c7 85 68 ff ff ff 00 	movl   $0x0,-0x98(%rbp)
 101330e:	00 00 00 
 1013311:	4c 89 6d c0          	mov    %r13,-0x40(%rbp)
 1013315:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
 1013319:	48 89 45 90          	mov    %rax,-0x70(%rbp)
 101331d:	48 8d 05 dc af 01 00 	lea    0x1afdc(%rip),%rax        # 102e300 <myl_t_1e414bd82e4b50b54939760a2d591f88da97e2f1c8252dbd7dcbc73438e46afb>
 1013324:	48 89 85 00 ff ff ff 	mov    %rax,-0x100(%rbp)
 101332b:	c7 85 18 ff ff ff 02 	movl   $0x2,-0xe8(%rbp)
 1013332:	00 00 00 
 1013335:	c7 85 68 ff ff ff 01 	movl   $0x1,-0x98(%rbp)
 101333c:	00 00 00 
 101333f:	4c 89 6d c0          	mov    %r13,-0x40(%rbp)
 1013343:	c7 85 78 ff ff ff 00 	movl   $0x0,-0x88(%rbp)
 101334a:	00 00 00 
 101334d:	ba 08 00 00 00       	mov    $0x8,%edx
 1013352:	be 00 00 00 00       	mov    $0x0,%esi
 1013357:	49 89 fd             	mov    %rdi,%r13
 101335a:	48 8d 7d d0          	lea    -0x30(%rbp),%rdi
 101335e:	e8 9d 6c 01 00       	call   102a000 <compiler_rt.fastMemset>
 1013363:	4c 89 ef             	mov    %r13,%rdi
 1013366:	48 8d 05 c3 b1 01 00 	lea    0x1b1c3(%rip),%rax        # 102e530 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 101336d:	48 89 85 40 ff ff ff 	mov    %rax,-0xc0(%rbp)
 1013374:	c7 85 58 ff ff ff 02 	movl   $0x2,-0xa8(%rbp)
 101337b:	00 00 00 
 101337e:	48 8d 45 d0          	lea    -0x30(%rbp),%rax
 1013382:	48 89 85 48 ff ff ff 	mov    %rax,-0xb8(%rbp)
 1013389:	4c 89 a5 50 ff ff ff 	mov    %r12,-0xb0(%rbp)
 1013390:	c7 85 78 ff ff ff 01 	movl   $0x1,-0x88(%rbp)
 1013397:	00 00 00 
 101339a:	8b 85 68 ff ff ff    	mov    -0x98(%rbp),%eax
 10133a0:	8b 8d 18 ff ff ff    	mov    -0xe8(%rbp),%ecx
 10133a6:	83 e1 18             	and    $0x18,%ecx
 10133a9:	83 f9 00             	cmp    $0x0,%ecx
 10133ac:	0f 94 c1             	sete   %cl
 10133af:	0f b6 c9             	movzbl %cl,%ecx
 10133b2:	85 c1                	test   %eax,%ecx
 10133b4:	0f 85 cc 00 00 00    	jne    1013486 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xa06>
 10133ba:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
 10133be:	48 83 f8 00          	cmp    $0x0,%rax
 10133c2:	74 1a                	je     10133de <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x95e>
 10133c4:	48 83 e8 10          	sub    $0x10,%rax
 10133c8:	48 8b 00             	mov    (%rax),%rax
 10133cb:	48 b9 01 00 00 00 00 	movabs $0x5000000000000001,%rcx
 10133d2:	00 00 50 
 10133d5:	48 21 c8             	and    %rcx,%rax
 10133d8:	48 83 f8 00          	cmp    $0x0,%rax
 10133dc:	75 29                	jne    1013407 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x987>
 10133de:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
 10133e2:	48 89 45 a0          	mov    %rax,-0x60(%rbp)
 10133e6:	ba 08 00 00 00       	mov    $0x8,%edx
 10133eb:	be 00 00 00 00       	mov    $0x0,%esi
 10133f0:	49 89 fd             	mov    %rdi,%r13
 10133f3:	48 8d 7d c0          	lea    -0x40(%rbp),%rdi
 10133f7:	e8 04 6c 01 00       	call   102a000 <compiler_rt.fastMemset>
 10133fc:	4d 89 f0             	mov    %r14,%r8
 10133ff:	4c 89 ef             	mov    %r13,%rdi
 1013402:	4d 89 c6             	mov    %r8,%r14
 1013405:	eb 3f                	jmp    1013446 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x9c6>
 1013407:	4d 89 f0             	mov    %r14,%r8
 101340a:	4d 89 c6             	mov    %r8,%r14
 101340d:	48 8d 4d c0          	lea    -0x40(%rbp),%rcx
 1013411:	48 8d 55 a0          	lea    -0x60(%rbp),%rdx
 1013415:	48 8d 35 e4 ae 01 00 	lea    0x1aee4(%rip),%rsi        # 102e300 <myl_t_1e414bd82e4b50b54939760a2d591f88da97e2f1c8252dbd7dcbc73438e46afb>
 101341c:	49 89 fd             	mov    %rdi,%r13
 101341f:	e8 ec 66 01 00       	call   1029b10 <myl_rc_native_take>
 1013424:	4c 89 ef             	mov    %r13,%rdi
 1013427:	83 f8 00             	cmp    $0x0,%eax
 101342a:	75 1a                	jne    1013446 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x9c6>
 101342c:	e8 af e6 00 00       	call   1021ae0 <myl_rc_take_failure>
 1013431:	48 89 df             	mov    %rbx,%rdi
 1013434:	89 c6                	mov    %eax,%esi
 1013436:	48 89 fb             	mov    %rdi,%rbx
 1013439:	e8 72 5d 00 00       	call   10191b0 <myl_qbe_rc_status>
 101343e:	48 89 df             	mov    %rbx,%rdi
 1013441:	e9 c1 03 00 00       	jmp    1013807 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xd87>
 1013446:	c7 85 68 ff ff ff 00 	movl   $0x0,-0x98(%rbp)
 101344d:	00 00 00 
 1013450:	48 8d 05 a9 ae 01 00 	lea    0x1aea9(%rip),%rax        # 102e300 <myl_t_1e414bd82e4b50b54939760a2d591f88da97e2f1c8252dbd7dcbc73438e46afb>
 1013457:	48 89 85 20 ff ff ff 	mov    %rax,-0xe0(%rbp)
 101345e:	c7 85 38 ff ff ff 02 	movl   $0x2,-0xc8(%rbp)
 1013465:	00 00 00 
 1013468:	c7 85 70 ff ff ff 01 	movl   $0x1,-0x90(%rbp)
 101346f:	00 00 00 
 1013472:	48 8b 45 a0          	mov    -0x60(%rbp),%rax
 1013476:	48 89 45 d0          	mov    %rax,-0x30(%rbp)
 101347a:	c7 85 70 ff ff ff 00 	movl   $0x0,-0x90(%rbp)
 1013481:	00 00 00 
 1013484:	eb 12                	jmp    1013498 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xa18>
 1013486:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
 101348a:	48 89 45 d0          	mov    %rax,-0x30(%rbp)
 101348e:	c7 85 68 ff ff ff 00 	movl   $0x0,-0x98(%rbp)
 1013495:	00 00 00 
 1013498:	48 8d 45 d0          	lea    -0x30(%rbp),%rax
 101349c:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
 10134a0:	48 8b 45 d0          	mov    -0x30(%rbp),%rax
 10134a4:	48 89 45 90          	mov    %rax,-0x70(%rbp)
 10134a8:	48 8d 05 81 b0 01 00 	lea    0x1b081(%rip),%rax        # 102e530 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 10134af:	48 89 85 00 ff ff ff 	mov    %rax,-0x100(%rbp)
 10134b6:	c7 85 18 ff ff ff 02 	movl   $0x2,-0xe8(%rbp)
 10134bd:	00 00 00 
 10134c0:	c7 85 68 ff ff ff 01 	movl   $0x1,-0x98(%rbp)
 10134c7:	00 00 00 
 10134ca:	48 8d 45 90          	lea    -0x70(%rbp),%rax
 10134ce:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
 10134d2:	c7 85 78 ff ff ff 00 	movl   $0x0,-0x88(%rbp)
 10134d9:	00 00 00 
 10134dc:	ba 10 00 00 00       	mov    $0x10,%edx
 10134e1:	be 00 00 00 00       	mov    $0x0,%esi
 10134e6:	49 89 fd             	mov    %rdi,%r13
 10134e9:	48 8d 7d d8          	lea    -0x28(%rbp),%rdi
 10134ed:	e8 0e 6b 01 00       	call   102a000 <compiler_rt.fastMemset>
 10134f2:	4d 89 f0             	mov    %r14,%r8
 10134f5:	4c 89 ef             	mov    %r13,%rdi
 10134f8:	48 8d 05 a1 b0 01 00 	lea    0x1b0a1(%rip),%rax        # 102e5a0 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 10134ff:	48 89 85 40 ff ff ff 	mov    %rax,-0xc0(%rbp)
 1013506:	c7 85 58 ff ff ff 02 	movl   $0x2,-0xa8(%rbp)
 101350d:	00 00 00 
 1013510:	48 8d 45 d8          	lea    -0x28(%rbp),%rax
 1013514:	48 89 85 48 ff ff ff 	mov    %rax,-0xb8(%rbp)
 101351b:	4c 89 a5 50 ff ff ff 	mov    %r12,-0xb0(%rbp)
 1013522:	c7 85 78 ff ff ff 01 	movl   $0x1,-0x88(%rbp)
 1013529:	00 00 00 
 101352c:	48 8b 45 b8          	mov    -0x48(%rbp),%rax
 1013530:	8b 8d 60 ff ff ff    	mov    -0xa0(%rbp),%ecx
 1013536:	8b 95 f8 fe ff ff    	mov    -0x108(%rbp),%edx
 101353c:	83 e2 18             	and    $0x18,%edx
 101353f:	83 fa 00             	cmp    $0x0,%edx
 1013542:	0f 94 c2             	sete   %dl
 1013545:	0f b6 d2             	movzbl %dl,%edx
 1013548:	85 ca                	test   %ecx,%edx
 101354a:	0f 85 91 00 00 00    	jne    10135e1 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xb61>
 1013550:	4d 89 c6             	mov    %r8,%r14
 1013553:	48 89 c1             	mov    %rax,%rcx
 1013556:	48 8d 55 a0          	lea    -0x60(%rbp),%rdx
 101355a:	48 8d 35 cf af 01 00 	lea    0x1afcf(%rip),%rsi        # 102e530 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 1013561:	49 89 fc             	mov    %rdi,%r12
 1013564:	e8 e7 68 01 00       	call   1029e50 <myl_rc_native_retain>
 1013569:	4c 89 e7             	mov    %r12,%rdi
 101356c:	83 f8 00             	cmp    $0x0,%eax
 101356f:	75 1a                	jne    101358b <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xb0b>
 1013571:	e8 6a e5 00 00       	call   1021ae0 <myl_rc_take_failure>
 1013576:	48 89 df             	mov    %rbx,%rdi
 1013579:	89 c6                	mov    %eax,%esi
 101357b:	48 89 fb             	mov    %rdi,%rbx
 101357e:	e8 2d 5c 00 00       	call   10191b0 <myl_qbe_rc_status>
 1013583:	48 89 df             	mov    %rbx,%rdi
 1013586:	e9 7c 02 00 00       	jmp    1013807 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xd87>
 101358b:	48 8d 05 9e af 01 00 	lea    0x1af9e(%rip),%rax        # 102e530 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 1013592:	48 89 85 20 ff ff ff 	mov    %rax,-0xe0(%rbp)
 1013599:	c7 85 38 ff ff ff 02 	movl   $0x2,-0xc8(%rbp)
 10135a0:	00 00 00 
 10135a3:	c7 85 70 ff ff ff 01 	movl   $0x1,-0x90(%rbp)
 10135aa:	00 00 00 
 10135ad:	8b 85 60 ff ff ff    	mov    -0xa0(%rbp),%eax
 10135b3:	83 f8 00             	cmp    $0x0,%eax
 10135b6:	74 15                	je     10135cd <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xb4d>
 10135b8:	48 8d b5 e0 fe ff ff 	lea    -0x120(%rbp),%rsi
 10135bf:	49 89 fc             	mov    %rdi,%r12
 10135c2:	48 89 df             	mov    %rbx,%rdi
 10135c5:	e8 b6 5d 00 00       	call   1019380 <myl_qbe_rc_slot_drop>
 10135ca:	4c 89 e7             	mov    %r12,%rdi
 10135cd:	48 8b 45 a0          	mov    -0x60(%rbp),%rax
 10135d1:	48 89 45 d8          	mov    %rax,-0x28(%rbp)
 10135d5:	c7 85 70 ff ff ff 00 	movl   $0x0,-0x90(%rbp)
 10135dc:	00 00 00 
 10135df:	eb 14                	jmp    10135f5 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xb75>
 10135e1:	4d 89 c6             	mov    %r8,%r14
 10135e4:	48 8b 00             	mov    (%rax),%rax
 10135e7:	48 89 45 d8          	mov    %rax,-0x28(%rbp)
 10135eb:	c7 85 60 ff ff ff 00 	movl   $0x0,-0xa0(%rbp)
 10135f2:	00 00 00 
 10135f5:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
 10135f9:	48 8d 4d d8          	lea    -0x28(%rbp),%rcx
 10135fd:	49 89 cc             	mov    %rcx,%r12
 1013600:	49 83 c4 08          	add    $0x8,%r12
 1013604:	8b 8d 68 ff ff ff    	mov    -0x98(%rbp),%ecx
 101360a:	8b 95 18 ff ff ff    	mov    -0xe8(%rbp),%edx
 1013610:	83 e2 18             	and    $0x18,%edx
 1013613:	83 fa 00             	cmp    $0x0,%edx
 1013616:	0f 94 c2             	sete   %dl
 1013619:	0f b6 d2             	movzbl %dl,%edx
 101361c:	85 ca                	test   %ecx,%edx
 101361e:	0f 85 ce 00 00 00    	jne    10136f2 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xc72>
 1013624:	48 8b 08             	mov    (%rax),%rcx
 1013627:	48 83 f9 00          	cmp    $0x0,%rcx
 101362b:	74 1a                	je     1013647 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xbc7>
 101362d:	48 83 e9 10          	sub    $0x10,%rcx
 1013631:	48 8b 09             	mov    (%rcx),%rcx
 1013634:	48 ba 01 00 00 00 00 	movabs $0x5000000000000001,%rdx
 101363b:	00 00 50 
 101363e:	48 21 d1             	and    %rdx,%rcx
 1013641:	48 83 f9 00          	cmp    $0x0,%rcx
 1013645:	75 27                	jne    101366e <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xbee>
 1013647:	48 8b 08             	mov    (%rax),%rcx
 101364a:	48 89 4d a0          	mov    %rcx,-0x60(%rbp)
 101364e:	ba 08 00 00 00       	mov    $0x8,%edx
 1013653:	be 00 00 00 00       	mov    $0x0,%esi
 1013658:	49 89 fd             	mov    %rdi,%r13
 101365b:	48 89 c7             	mov    %rax,%rdi
 101365e:	e8 9d 69 01 00       	call   102a000 <compiler_rt.fastMemset>
 1013663:	4d 89 f0             	mov    %r14,%r8
 1013666:	4c 89 ef             	mov    %r13,%rdi
 1013669:	48 87 df             	xchg   %rbx,%rdi
 101366c:	eb 44                	jmp    10136b2 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xc32>
 101366e:	4d 89 f0             	mov    %r14,%r8
 1013671:	4d 89 c6             	mov    %r8,%r14
 1013674:	48 89 c1             	mov    %rax,%rcx
 1013677:	48 8d 55 a0          	lea    -0x60(%rbp),%rdx
 101367b:	48 8d 35 ae ae 01 00 	lea    0x1aeae(%rip),%rsi        # 102e530 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 1013682:	49 89 fd             	mov    %rdi,%r13
 1013685:	e8 86 64 01 00       	call   1029b10 <myl_rc_native_take>
 101368a:	4d 89 f0             	mov    %r14,%r8
 101368d:	4c 89 ef             	mov    %r13,%rdi
 1013690:	83 f8 00             	cmp    $0x0,%eax
 1013693:	75 1a                	jne    10136af <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xc2f>
 1013695:	e8 46 e4 00 00       	call   1021ae0 <myl_rc_take_failure>
 101369a:	48 89 df             	mov    %rbx,%rdi
 101369d:	89 c6                	mov    %eax,%esi
 101369f:	48 89 fb             	mov    %rdi,%rbx
 10136a2:	e8 09 5b 00 00       	call   10191b0 <myl_qbe_rc_status>
 10136a7:	48 89 df             	mov    %rbx,%rdi
 10136aa:	e9 58 01 00 00       	jmp    1013807 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xd87>
 10136af:	48 87 df             	xchg   %rbx,%rdi
 10136b2:	c7 85 68 ff ff ff 00 	movl   $0x0,-0x98(%rbp)
 10136b9:	00 00 00 
 10136bc:	48 8d 05 6d ae 01 00 	lea    0x1ae6d(%rip),%rax        # 102e530 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 10136c3:	48 89 85 20 ff ff ff 	mov    %rax,-0xe0(%rbp)
 10136ca:	c7 85 38 ff ff ff 02 	movl   $0x2,-0xc8(%rbp)
 10136d1:	00 00 00 
 10136d4:	c7 85 70 ff ff ff 01 	movl   $0x1,-0x90(%rbp)
 10136db:	00 00 00 
 10136de:	48 8b 45 a0          	mov    -0x60(%rbp),%rax
 10136e2:	49 89 04 24          	mov    %rax,(%r12)
 10136e6:	c7 85 70 ff ff ff 00 	movl   $0x0,-0x90(%rbp)
 10136ed:	00 00 00 
 10136f0:	eb 17                	jmp    1013709 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xc89>
 10136f2:	4d 89 f0             	mov    %r14,%r8
 10136f5:	48 87 df             	xchg   %rbx,%rdi
 10136f8:	48 8b 00             	mov    (%rax),%rax
 10136fb:	49 89 04 24          	mov    %rax,(%r12)
 10136ff:	c7 85 68 ff ff ff 00 	movl   $0x0,-0x98(%rbp)
 1013706:	00 00 00 
 1013709:	48 8d 45 d8          	lea    -0x28(%rbp),%rax
 101370d:	48 89 45 b8          	mov    %rax,-0x48(%rbp)
 1013711:	48 8b 45 d8          	mov    -0x28(%rbp),%rax
 1013715:	48 89 45 80          	mov    %rax,-0x80(%rbp)
 1013719:	48 8b 45 e0          	mov    -0x20(%rbp),%rax
 101371d:	48 89 45 88          	mov    %rax,-0x78(%rbp)
 1013721:	48 8d 05 78 ae 01 00 	lea    0x1ae78(%rip),%rax        # 102e5a0 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 1013728:	48 89 85 e0 fe ff ff 	mov    %rax,-0x120(%rbp)
 101372f:	c7 85 f8 fe ff ff 02 	movl   $0x2,-0x108(%rbp)
 1013736:	00 00 00 
 1013739:	c7 85 60 ff ff ff 01 	movl   $0x1,-0xa0(%rbp)
 1013740:	00 00 00 
 1013743:	48 8d 45 80          	lea    -0x80(%rbp),%rax
 1013747:	48 89 45 b8          	mov    %rax,-0x48(%rbp)
 101374b:	c7 85 78 ff ff ff 00 	movl   $0x0,-0x88(%rbp)
 1013752:	00 00 00 
 1013755:	48 8b 45 80          	mov    -0x80(%rbp),%rax
 1013759:	48 83 f8 00          	cmp    $0x0,%rax
 101375d:	74 1a                	je     1013779 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xcf9>
 101375f:	48 83 e8 10          	sub    $0x10,%rax
 1013763:	48 8b 00             	mov    (%rax),%rax
 1013766:	48 b9 01 00 00 00 00 	movabs $0x5000000000000001,%rcx
 101376d:	00 00 50 
 1013770:	48 21 c8             	and    %rcx,%rax
 1013773:	48 83 f8 00          	cmp    $0x0,%rax
 1013777:	75 57                	jne    10137d0 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xd50>
 1013779:	48 8b 45 88          	mov    -0x78(%rbp),%rax
 101377d:	48 83 f8 00          	cmp    $0x0,%rax
 1013781:	74 1a                	je     101379d <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xd1d>
 1013783:	48 83 e8 10          	sub    $0x10,%rax
 1013787:	48 8b 00             	mov    (%rax),%rax
 101378a:	48 b9 01 00 00 00 00 	movabs $0x5000000000000001,%rcx
 1013791:	00 00 50 
 1013794:	48 21 c8             	and    %rcx,%rax
 1013797:	48 83 f8 00          	cmp    $0x0,%rax
 101379b:	75 2e                	jne    10137cb <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xd4b>
 101379d:	48 8b 45 80          	mov    -0x80(%rbp),%rax
 10137a1:	48 89 45 a0          	mov    %rax,-0x60(%rbp)
 10137a5:	48 8b 45 88          	mov    -0x78(%rbp),%rax
 10137a9:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
 10137ad:	ba 10 00 00 00       	mov    $0x10,%edx
 10137b2:	be 00 00 00 00       	mov    $0x0,%esi
 10137b7:	48 89 fb             	mov    %rdi,%rbx
 10137ba:	48 8d 7d 80          	lea    -0x80(%rbp),%rdi
 10137be:	e8 3d 68 01 00       	call   102a000 <compiler_rt.fastMemset>
 10137c3:	48 89 df             	mov    %rbx,%rdi
 10137c6:	e9 86 00 00 00       	jmp    1013851 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xdd1>
 10137cb:	48 87 fb             	xchg   %rdi,%rbx
 10137ce:	eb 03                	jmp    10137d3 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xd53>
 10137d0:	48 87 fb             	xchg   %rdi,%rbx
 10137d3:	48 8d 4d 80          	lea    -0x80(%rbp),%rcx
 10137d7:	48 8d 55 a0          	lea    -0x60(%rbp),%rdx
 10137db:	48 8d 35 be ad 01 00 	lea    0x1adbe(%rip),%rsi        # 102e5a0 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 10137e2:	49 89 fc             	mov    %rdi,%r12
 10137e5:	e8 26 63 01 00       	call   1029b10 <myl_rc_native_take>
 10137ea:	4c 89 e7             	mov    %r12,%rdi
 10137ed:	83 f8 00             	cmp    $0x0,%eax
 10137f0:	75 5c                	jne    101384e <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xdce>
 10137f2:	e8 e9 e2 00 00       	call   1021ae0 <myl_rc_take_failure>
 10137f7:	48 89 df             	mov    %rbx,%rdi
 10137fa:	89 c6                	mov    %eax,%esi
 10137fc:	48 89 fb             	mov    %rdi,%rbx
 10137ff:	e8 ac 59 00 00       	call   10191b0 <myl_qbe_rc_status>
 1013804:	48 89 df             	mov    %rbx,%rdi
 1013807:	48 8d b5 c0 fe ff ff 	lea    -0x140(%rbp),%rsi
 101380e:	48 89 fb             	mov    %rdi,%rbx
 1013811:	e8 9a 5c 00 00       	call   10194b0 <myl_qbe_rc_frame_cleanup>
 1013816:	48 89 df             	mov    %rbx,%rdi
 1013819:	48 8d b5 c0 fe ff ff 	lea    -0x140(%rbp),%rsi
 1013820:	e8 fb 5a 00 00       	call   1019320 <myl_qbe_rc_frame_leave>
 1013825:	ba 10 00 00 00       	mov    $0x10,%edx
 101382a:	be 00 00 00 00       	mov    $0x0,%esi
 101382f:	48 8d bd b0 fe ff ff 	lea    -0x150(%rbp),%rdi
 1013836:	e8 c5 67 01 00       	call   102a000 <compiler_rt.fastMemset>
 101383b:	48 8b 85 b0 fe ff ff 	mov    -0x150(%rbp),%rax
 1013842:	48 8b 95 b8 fe ff ff 	mov    -0x148(%rbp),%rdx
 1013849:	e9 9f 00 00 00       	jmp    10138ed <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xe6d>
 101384e:	48 89 df             	mov    %rbx,%rdi
 1013851:	c7 85 60 ff ff ff 00 	movl   $0x0,-0xa0(%rbp)
 1013858:	00 00 00 
 101385b:	48 8d 05 3e ad 01 00 	lea    0x1ad3e(%rip),%rax        # 102e5a0 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 1013862:	48 89 85 20 ff ff ff 	mov    %rax,-0xe0(%rbp)
 1013869:	c7 85 38 ff ff ff 02 	movl   $0x2,-0xc8(%rbp)
 1013870:	00 00 00 
 1013873:	c7 85 70 ff ff ff 01 	movl   $0x1,-0x90(%rbp)
 101387a:	00 00 00 
 101387d:	c7 85 70 ff ff ff 00 	movl   $0x0,-0x90(%rbp)
 1013884:	00 00 00 
 1013887:	48 8d b5 c0 fe ff ff 	lea    -0x140(%rbp),%rsi
 101388e:	48 89 fb             	mov    %rdi,%rbx
 1013891:	e8 1a 5c 00 00       	call   10194b0 <myl_qbe_rc_frame_cleanup>
 1013896:	48 89 df             	mov    %rbx,%rdi
 1013899:	48 8d b5 c0 fe ff ff 	lea    -0x140(%rbp),%rsi
 10138a0:	e8 7b 5a 00 00       	call   1019320 <myl_qbe_rc_frame_leave>
 10138a5:	48 8b 45 a0          	mov    -0x60(%rbp),%rax
 10138a9:	48 8b 55 a8          	mov    -0x58(%rbp),%rdx
 10138ad:	eb 3e                	jmp    10138ed <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xe6d>
 10138af:	4c 89 ea             	mov    %r13,%rdx
 10138b2:	41 b8 40 00 00 00    	mov    $0x40,%r8d
 10138b8:	b9 01 00 00 00       	mov    $0x1,%ecx
 10138bd:	be 01 00 00 00       	mov    $0x1,%esi
 10138c2:	e8 89 61 00 00       	call   1019a50 <myl_qbe_fail_overflow_op>
 10138c7:	0f 0b                	ud2
 10138c9:	48 c7 85 b0 fe ff ff 	movq   $0x0,-0x150(%rbp)
 10138d0:	00 00 00 00 
 10138d4:	48 c7 85 b8 fe ff ff 	movq   $0x0,-0x148(%rbp)
 10138db:	00 00 00 00 
 10138df:	48 8b 85 b0 fe ff ff 	mov    -0x150(%rbp),%rax
 10138e6:	48 8b 95 b8 fe ff ff 	mov    -0x148(%rbp),%rdx
 10138ed:	41 5f                	pop    %r15
 10138ef:	41 5e                	pop    %r14
 10138f1:	41 5d                	pop    %r13
 10138f3:	41 5c                	pop    %r12
 10138f5:	5b                   	pop    %rbx
 10138f6:	c9                   	leave
 10138f7:	c3                   	ret
 10138f8:	e8 a3 62 00 00       	call   1019ba0 <myl_qbe_fail_frame>
 10138fd:	0f 0b                	ud2

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
