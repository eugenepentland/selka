
.tmp-mut-argument/return-run/trees-qbe-after-rc:     file format elf64-x86-64


Disassembly of section .text:

0000000001012a40 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531>:
 1012a40:	f3 0f 1e fa          	endbr64
 1012a44:	55                   	push   %rbp
 1012a45:	48 89 e5             	mov    %rsp,%rbp
 1012a48:	48 81 ec 78 01 00 00 	sub    $0x178,%rsp
 1012a4f:	53                   	push   %rbx
 1012a50:	41 54                	push   %r12
 1012a52:	41 55                	push   %r13
 1012a54:	41 56                	push   %r14
 1012a56:	41 57                	push   %r15
 1012a58:	49 89 f5             	mov    %rsi,%r13
 1012a5b:	48 8b 47 40          	mov    0x40(%rdi),%rax
 1012a5f:	48 8d 4d e8          	lea    -0x18(%rbp),%rcx
 1012a63:	48 39 c1             	cmp    %rax,%rcx
 1012a66:	0f 82 64 0d 00 00    	jb     10137d0 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xd90>
 1012a6c:	49 83 fd 00          	cmp    $0x0,%r13
 1012a70:	0f 84 2b 0d 00 00    	je     10137a1 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xd61>
 1012a76:	48 89 fb             	mov    %rdi,%rbx
 1012a79:	e8 f2 6f 00 00       	call   1019a70 <myl_qbe_heap>
 1012a7e:	48 89 df             	mov    %rbx,%rdi
 1012a81:	48 89 c3             	mov    %rax,%rbx
 1012a84:	49 89 fc             	mov    %rdi,%r12
 1012a87:	e8 24 93 00 00       	call   101bdb0 <myl_qbe_region_mark>
 1012a8c:	4c 89 ea             	mov    %r13,%rdx
 1012a8f:	4c 89 e7             	mov    %r12,%rdi
 1012a92:	49 89 c7             	mov    %rax,%r15
 1012a95:	4c 89 7d f8          	mov    %r15,-0x8(%rbp)
 1012a99:	49 89 d5             	mov    %rdx,%r13
 1012a9c:	ba 20 00 00 00       	mov    $0x20,%edx
 1012aa1:	be 00 00 00 00       	mov    $0x0,%esi
 1012aa6:	49 89 fc             	mov    %rdi,%r12
 1012aa9:	48 8d bd 60 ff ff ff 	lea    -0xa0(%rbp),%rdi
 1012ab0:	e8 2b 74 01 00       	call   1029ee0 <compiler_rt.fastMemset>
 1012ab5:	4c 89 ea             	mov    %r13,%rdx
 1012ab8:	4c 89 e7             	mov    %r12,%rdi
 1012abb:	49 89 d5             	mov    %rdx,%r13
 1012abe:	ba 80 00 00 00       	mov    $0x80,%edx
 1012ac3:	be 00 00 00 00       	mov    $0x0,%esi
 1012ac8:	49 89 fc             	mov    %rdi,%r12
 1012acb:	48 8d bd e0 fe ff ff 	lea    -0x120(%rbp),%rdi
 1012ad2:	e8 09 74 01 00       	call   1029ee0 <compiler_rt.fastMemset>
 1012ad7:	4c 89 ea             	mov    %r13,%rdx
 1012ada:	4c 89 e7             	mov    %r12,%rdi
 1012add:	48 8d 05 94 19 ff ff 	lea    -0xe66c(%rip),%rax        # 1004478 <myl_t_385cfdbc00ec32031699460779c15099b2bba3cad0e440fffb08e10df0acb9e1>
 1012ae4:	48 89 85 e0 fe ff ff 	mov    %rax,-0x120(%rbp)
 1012aeb:	c7 85 f8 fe ff ff 00 	movl   $0x0,-0x108(%rbp)
 1012af2:	00 00 00 
 1012af5:	48 8d 45 80          	lea    -0x80(%rbp),%rax
 1012af9:	48 89 85 e8 fe ff ff 	mov    %rax,-0x118(%rbp)
 1012b00:	48 8d 85 60 ff ff ff 	lea    -0xa0(%rbp),%rax
 1012b07:	48 89 85 f0 fe ff ff 	mov    %rax,-0x110(%rbp)
 1012b0e:	48 8d 05 63 19 ff ff 	lea    -0xe69d(%rip),%rax        # 1004478 <myl_t_385cfdbc00ec32031699460779c15099b2bba3cad0e440fffb08e10df0acb9e1>
 1012b15:	48 89 85 00 ff ff ff 	mov    %rax,-0x100(%rbp)
 1012b1c:	c7 85 18 ff ff ff 00 	movl   $0x0,-0xe8(%rbp)
 1012b23:	00 00 00 
 1012b26:	48 8d 45 90          	lea    -0x70(%rbp),%rax
 1012b2a:	48 89 85 08 ff ff ff 	mov    %rax,-0xf8(%rbp)
 1012b31:	48 8d 85 60 ff ff ff 	lea    -0xa0(%rbp),%rax
 1012b38:	48 83 c0 08          	add    $0x8,%rax
 1012b3c:	48 89 85 10 ff ff ff 	mov    %rax,-0xf0(%rbp)
 1012b43:	48 8d 05 2e 19 ff ff 	lea    -0xe6d2(%rip),%rax        # 1004478 <myl_t_385cfdbc00ec32031699460779c15099b2bba3cad0e440fffb08e10df0acb9e1>
 1012b4a:	48 89 85 20 ff ff ff 	mov    %rax,-0xe0(%rbp)
 1012b51:	c7 85 38 ff ff ff 00 	movl   $0x0,-0xc8(%rbp)
 1012b58:	00 00 00 
 1012b5b:	48 8d 45 a0          	lea    -0x60(%rbp),%rax
 1012b5f:	48 89 85 28 ff ff ff 	mov    %rax,-0xd8(%rbp)
 1012b66:	48 8d 85 60 ff ff ff 	lea    -0xa0(%rbp),%rax
 1012b6d:	48 83 c0 10          	add    $0x10,%rax
 1012b71:	48 89 85 30 ff ff ff 	mov    %rax,-0xd0(%rbp)
 1012b78:	48 8d 05 f9 18 ff ff 	lea    -0xe707(%rip),%rax        # 1004478 <myl_t_385cfdbc00ec32031699460779c15099b2bba3cad0e440fffb08e10df0acb9e1>
 1012b7f:	48 89 85 40 ff ff ff 	mov    %rax,-0xc0(%rbp)
 1012b86:	c7 85 58 ff ff ff 00 	movl   $0x0,-0xa8(%rbp)
 1012b8d:	00 00 00 
 1012b90:	48 8d 45 b0          	lea    -0x50(%rbp),%rax
 1012b94:	48 89 85 48 ff ff ff 	mov    %rax,-0xb8(%rbp)
 1012b9b:	48 8d 85 60 ff ff ff 	lea    -0xa0(%rbp),%rax
 1012ba2:	49 89 c4             	mov    %rax,%r12
 1012ba5:	49 83 c4 18          	add    $0x18,%r12
 1012ba9:	4c 89 a5 50 ff ff ff 	mov    %r12,-0xb0(%rbp)
 1012bb0:	b9 04 00 00 00       	mov    $0x4,%ecx
 1012bb5:	49 89 d5             	mov    %rdx,%r13
 1012bb8:	48 8d 95 e0 fe ff ff 	lea    -0x120(%rbp),%rdx
 1012bbf:	48 8d b5 c0 fe ff ff 	lea    -0x140(%rbp),%rsi
 1012bc6:	49 89 fe             	mov    %rdi,%r14
 1012bc9:	e8 b2 65 00 00       	call   1019180 <myl_qbe_rc_frame_enter>
 1012bce:	4c 89 f7             	mov    %r14,%rdi
 1012bd1:	4c 89 6d b8          	mov    %r13,-0x48(%rbp)
 1012bd5:	48 c7 45 c0 01 00 00 	movq   $0x1,-0x40(%rbp)
 1012bdc:	00 
 1012bdd:	48 b8 01 00 00 00 00 	movabs $0x8000000000000001,%rax
 1012be4:	00 00 80 
 1012be7:	49 39 c5             	cmp    %rax,%r13
 1012bea:	0f 8c 97 0b 00 00    	jl     1013787 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xd47>
 1012bf0:	4c 89 ee             	mov    %r13,%rsi
 1012bf3:	48 83 ee 01          	sub    $0x1,%rsi
 1012bf7:	48 89 75 f0          	mov    %rsi,-0x10(%rbp)
 1012bfb:	48 89 75 b8          	mov    %rsi,-0x48(%rbp)
 1012bff:	49 89 fe             	mov    %rdi,%r14
 1012c02:	e8 39 fe ff ff       	call   1012a40 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531>
 1012c07:	4c 89 f7             	mov    %r14,%rdi
 1012c0a:	48 89 c1             	mov    %rax,%rcx
 1012c0d:	48 89 d0             	mov    %rdx,%rax
 1012c10:	4c 89 ea             	mov    %r13,%rdx
 1012c13:	48 89 8d 90 fe ff ff 	mov    %rcx,-0x170(%rbp)
 1012c1a:	48 89 85 98 fe ff ff 	mov    %rax,-0x168(%rbp)
 1012c21:	48 8d 85 90 fe ff ff 	lea    -0x170(%rbp),%rax
 1012c28:	48 89 45 b8          	mov    %rax,-0x48(%rbp)
 1012c2c:	48 8b 85 90 fe ff ff 	mov    -0x170(%rbp),%rax
 1012c33:	48 89 45 a0          	mov    %rax,-0x60(%rbp)
 1012c37:	48 8b 85 98 fe ff ff 	mov    -0x168(%rbp),%rax
 1012c3e:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
 1012c42:	48 8d 05 37 b8 01 00 	lea    0x1b837(%rip),%rax        # 102e480 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 1012c49:	48 89 85 20 ff ff ff 	mov    %rax,-0xe0(%rbp)
 1012c50:	c7 85 38 ff ff ff 02 	movl   $0x2,-0xc8(%rbp)
 1012c57:	00 00 00 
 1012c5a:	c7 85 70 ff ff ff 01 	movl   $0x1,-0x90(%rbp)
 1012c61:	00 00 00 
 1012c64:	48 8b 45 a0          	mov    -0x60(%rbp),%rax
 1012c68:	48 89 45 80          	mov    %rax,-0x80(%rbp)
 1012c6c:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
 1012c70:	48 89 45 88          	mov    %rax,-0x78(%rbp)
 1012c74:	48 8d 05 05 b8 01 00 	lea    0x1b805(%rip),%rax        # 102e480 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 1012c7b:	48 89 85 e0 fe ff ff 	mov    %rax,-0x120(%rbp)
 1012c82:	c7 85 f8 fe ff ff 02 	movl   $0x2,-0x108(%rbp)
 1012c89:	00 00 00 
 1012c8c:	c7 85 f8 fe ff ff 02 	movl   $0x2,-0x108(%rbp)
 1012c93:	00 00 00 
 1012c96:	c7 85 70 ff ff ff 00 	movl   $0x0,-0x90(%rbp)
 1012c9d:	00 00 00 
 1012ca0:	c7 85 60 ff ff ff 01 	movl   $0x1,-0xa0(%rbp)
 1012ca7:	00 00 00 
 1012caa:	48 8d 45 80          	lea    -0x80(%rbp),%rax
 1012cae:	48 89 45 b8          	mov    %rax,-0x48(%rbp)
 1012cb2:	49 89 d6             	mov    %rdx,%r14
 1012cb5:	ba 01 00 00 00       	mov    $0x1,%edx
 1012cba:	48 8d 35 af b4 01 00 	lea    0x1b4af(%rip),%rsi        # 102e170 <myl_t_1e414bd82e4b50b54939760a2d591f88da97e2f1c8252dbd7dcbc73438e46afb_body>
 1012cc1:	49 89 fd             	mov    %rdi,%r13
 1012cc4:	48 89 df             	mov    %rbx,%rdi
 1012cc7:	e8 84 b4 00 00       	call   101e150 <myl_native_heap_alloc>
 1012ccc:	4d 89 f8             	mov    %r15,%r8
 1012ccf:	4c 89 f2             	mov    %r14,%rdx
 1012cd2:	4c 89 ef             	mov    %r13,%rdi
 1012cd5:	49 89 c5             	mov    %rax,%r13
 1012cd8:	41 83 fd 00          	cmp    $0x0,%r13d
 1012cdc:	75 0a                	jne    1012ce8 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x2a8>
 1012cde:	48 89 fb             	mov    %rdi,%rbx
 1012ce1:	e8 0a 6b 00 00       	call   10197f0 <myl_qbe_fail_allocation>
 1012ce6:	0f 0b                	ud2
 1012ce8:	48 87 fb             	xchg   %rdi,%rbx
 1012ceb:	4c 89 6d b0          	mov    %r13,-0x50(%rbp)
 1012cef:	48 8d 05 ea b4 01 00 	lea    0x1b4ea(%rip),%rax        # 102e1e0 <myl_t_1e414bd82e4b50b54939760a2d591f88da97e2f1c8252dbd7dcbc73438e46afb>
 1012cf6:	48 89 85 40 ff ff ff 	mov    %rax,-0xc0(%rbp)
 1012cfd:	c7 85 58 ff ff ff 02 	movl   $0x2,-0xa8(%rbp)
 1012d04:	00 00 00 
 1012d07:	48 8d 45 b0          	lea    -0x50(%rbp),%rax
 1012d0b:	48 89 85 48 ff ff ff 	mov    %rax,-0xb8(%rbp)
 1012d12:	4c 89 a5 50 ff ff ff 	mov    %r12,-0xb0(%rbp)
 1012d19:	c7 85 58 ff ff ff 04 	movl   $0x4,-0xa8(%rbp)
 1012d20:	00 00 00 
 1012d23:	c7 85 78 ff ff ff 01 	movl   $0x1,-0x88(%rbp)
 1012d2a:	00 00 00 
 1012d2d:	48 8b 45 b8          	mov    -0x48(%rbp),%rax
 1012d31:	8b 8d 60 ff ff ff    	mov    -0xa0(%rbp),%ecx
 1012d37:	8b b5 f8 fe ff ff    	mov    -0x108(%rbp),%esi
 1012d3d:	83 e6 18             	and    $0x18,%esi
 1012d40:	83 fe 00             	cmp    $0x0,%esi
 1012d43:	40 0f 94 c6          	sete   %sil
 1012d47:	40 0f b6 f6          	movzbl %sil,%esi
 1012d4b:	85 ce                	test   %ecx,%esi
 1012d4d:	0f 85 0a 01 00 00    	jne    1012e5d <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x41d>
 1012d53:	48 8b 08             	mov    (%rax),%rcx
 1012d56:	48 83 f9 00          	cmp    $0x0,%rcx
 1012d5a:	74 1a                	je     1012d76 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x336>
 1012d5c:	48 83 e9 10          	sub    $0x10,%rcx
 1012d60:	48 8b 09             	mov    (%rcx),%rcx
 1012d63:	48 be 01 00 00 00 00 	movabs $0x5000000000000001,%rsi
 1012d6a:	00 00 50 
 1012d6d:	48 21 f1             	and    %rsi,%rcx
 1012d70:	48 83 f9 00          	cmp    $0x0,%rcx
 1012d74:	75 5a                	jne    1012dd0 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x390>
 1012d76:	48 8b 48 08          	mov    0x8(%rax),%rcx
 1012d7a:	48 83 f9 00          	cmp    $0x0,%rcx
 1012d7e:	74 1a                	je     1012d9a <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x35a>
 1012d80:	48 83 e9 10          	sub    $0x10,%rcx
 1012d84:	48 8b 09             	mov    (%rcx),%rcx
 1012d87:	48 be 01 00 00 00 00 	movabs $0x5000000000000001,%rsi
 1012d8e:	00 00 50 
 1012d91:	48 21 f1             	and    %rsi,%rcx
 1012d94:	48 83 f9 00          	cmp    $0x0,%rcx
 1012d98:	75 36                	jne    1012dd0 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x390>
 1012d9a:	48 8b 08             	mov    (%rax),%rcx
 1012d9d:	48 89 4d a0          	mov    %rcx,-0x60(%rbp)
 1012da1:	48 8b 48 08          	mov    0x8(%rax),%rcx
 1012da5:	48 89 4d a8          	mov    %rcx,-0x58(%rbp)
 1012da9:	49 89 d7             	mov    %rdx,%r15
 1012dac:	ba 10 00 00 00       	mov    $0x10,%edx
 1012db1:	be 00 00 00 00       	mov    $0x0,%esi
 1012db6:	49 89 fe             	mov    %rdi,%r14
 1012db9:	48 89 c7             	mov    %rax,%rdi
 1012dbc:	e8 1f 71 01 00       	call   1029ee0 <compiler_rt.fastMemset>
 1012dc1:	4c 89 fa             	mov    %r15,%rdx
 1012dc4:	4c 89 f7             	mov    %r14,%rdi
 1012dc7:	4c 8b 45 f8          	mov    -0x8(%rbp),%r8
 1012dcb:	4d 89 c7             	mov    %r8,%r15
 1012dce:	eb 45                	jmp    1012e15 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x3d5>
 1012dd0:	4d 89 c7             	mov    %r8,%r15
 1012dd3:	48 89 c1             	mov    %rax,%rcx
 1012dd6:	49 89 d7             	mov    %rdx,%r15
 1012dd9:	48 8d 55 a0          	lea    -0x60(%rbp),%rdx
 1012ddd:	48 8d 35 9c b6 01 00 	lea    0x1b69c(%rip),%rsi        # 102e480 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 1012de4:	49 89 fe             	mov    %rdi,%r14
 1012de7:	e8 04 6c 01 00       	call   10299f0 <myl_rc_native_take>
 1012dec:	4c 89 fa             	mov    %r15,%rdx
 1012def:	4c 89 f7             	mov    %r14,%rdi
 1012df2:	4c 8b 7d f8          	mov    -0x8(%rbp),%r15
 1012df6:	83 f8 00             	cmp    $0x0,%eax
 1012df9:	75 1a                	jne    1012e15 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x3d5>
 1012dfb:	e8 c0 eb 00 00       	call   10219c0 <myl_rc_take_failure>
 1012e00:	48 89 df             	mov    %rbx,%rdi
 1012e03:	89 c6                	mov    %eax,%esi
 1012e05:	48 89 fb             	mov    %rdi,%rbx
 1012e08:	e8 83 62 00 00       	call   1019090 <myl_qbe_rc_status>
 1012e0d:	48 89 df             	mov    %rbx,%rdi
 1012e10:	e9 57 08 00 00       	jmp    101366c <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xc2c>
 1012e15:	c7 85 60 ff ff ff 00 	movl   $0x0,-0xa0(%rbp)
 1012e1c:	00 00 00 
 1012e1f:	48 8d 05 5a b6 01 00 	lea    0x1b65a(%rip),%rax        # 102e480 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 1012e26:	48 89 85 20 ff ff ff 	mov    %rax,-0xe0(%rbp)
 1012e2d:	c7 85 38 ff ff ff 02 	movl   $0x2,-0xc8(%rbp)
 1012e34:	00 00 00 
 1012e37:	c7 85 70 ff ff ff 01 	movl   $0x1,-0x90(%rbp)
 1012e3e:	00 00 00 
 1012e41:	48 8b 45 a0          	mov    -0x60(%rbp),%rax
 1012e45:	49 89 45 00          	mov    %rax,0x0(%r13)
 1012e49:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
 1012e4d:	49 89 45 08          	mov    %rax,0x8(%r13)
 1012e51:	c7 85 70 ff ff ff 00 	movl   $0x0,-0x90(%rbp)
 1012e58:	00 00 00 
 1012e5b:	eb 1c                	jmp    1012e79 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x439>
 1012e5d:	4d 89 c7             	mov    %r8,%r15
 1012e60:	48 8b 08             	mov    (%rax),%rcx
 1012e63:	49 89 4d 00          	mov    %rcx,0x0(%r13)
 1012e67:	48 8b 40 08          	mov    0x8(%rax),%rax
 1012e6b:	49 89 45 08          	mov    %rax,0x8(%r13)
 1012e6f:	c7 85 60 ff ff ff 00 	movl   $0x0,-0xa0(%rbp)
 1012e76:	00 00 00 
 1012e79:	4c 89 6d b8          	mov    %r13,-0x48(%rbp)
 1012e7d:	48 8b 45 b8          	mov    -0x48(%rbp),%rax
 1012e81:	48 89 45 80          	mov    %rax,-0x80(%rbp)
 1012e85:	48 8d 05 54 b3 01 00 	lea    0x1b354(%rip),%rax        # 102e1e0 <myl_t_1e414bd82e4b50b54939760a2d591f88da97e2f1c8252dbd7dcbc73438e46afb>
 1012e8c:	48 89 85 e0 fe ff ff 	mov    %rax,-0x120(%rbp)
 1012e93:	c7 85 f8 fe ff ff 02 	movl   $0x2,-0x108(%rbp)
 1012e9a:	00 00 00 
 1012e9d:	c7 85 60 ff ff ff 01 	movl   $0x1,-0xa0(%rbp)
 1012ea4:	00 00 00 
 1012ea7:	4c 89 6d b8          	mov    %r13,-0x48(%rbp)
 1012eab:	c7 85 78 ff ff ff 00 	movl   $0x0,-0x88(%rbp)
 1012eb2:	00 00 00 
 1012eb5:	49 89 d6             	mov    %rdx,%r14
 1012eb8:	ba 08 00 00 00       	mov    $0x8,%edx
 1012ebd:	be 00 00 00 00       	mov    $0x0,%esi
 1012ec2:	49 89 fd             	mov    %rdi,%r13
 1012ec5:	48 8d 7d c8          	lea    -0x38(%rbp),%rdi
 1012ec9:	e8 12 70 01 00       	call   1029ee0 <compiler_rt.fastMemset>
 1012ece:	4c 89 f2             	mov    %r14,%rdx
 1012ed1:	4c 89 ef             	mov    %r13,%rdi
 1012ed4:	48 8b 75 f0          	mov    -0x10(%rbp),%rsi
 1012ed8:	48 8d 05 31 b5 01 00 	lea    0x1b531(%rip),%rax        # 102e410 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 1012edf:	48 89 85 40 ff ff ff 	mov    %rax,-0xc0(%rbp)
 1012ee6:	c7 85 58 ff ff ff 02 	movl   $0x2,-0xa8(%rbp)
 1012eed:	00 00 00 
 1012ef0:	48 8d 45 c8          	lea    -0x38(%rbp),%rax
 1012ef4:	48 89 85 48 ff ff ff 	mov    %rax,-0xb8(%rbp)
 1012efb:	4c 89 a5 50 ff ff ff 	mov    %r12,-0xb0(%rbp)
 1012f02:	c7 85 78 ff ff ff 01 	movl   $0x1,-0x88(%rbp)
 1012f09:	00 00 00 
 1012f0c:	8b 85 60 ff ff ff    	mov    -0xa0(%rbp),%eax
 1012f12:	8b 8d f8 fe ff ff    	mov    -0x108(%rbp),%ecx
 1012f18:	83 e1 18             	and    $0x18,%ecx
 1012f1b:	83 f9 00             	cmp    $0x0,%ecx
 1012f1e:	0f 94 c1             	sete   %cl
 1012f21:	0f b6 c9             	movzbl %cl,%ecx
 1012f24:	85 c1                	test   %eax,%ecx
 1012f26:	0f 85 e6 00 00 00    	jne    1013012 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x5d2>
 1012f2c:	48 8b 45 b8          	mov    -0x48(%rbp),%rax
 1012f30:	48 83 f8 00          	cmp    $0x0,%rax
 1012f34:	74 1a                	je     1012f50 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x510>
 1012f36:	48 83 e8 10          	sub    $0x10,%rax
 1012f3a:	48 8b 00             	mov    (%rax),%rax
 1012f3d:	48 b9 01 00 00 00 00 	movabs $0x5000000000000001,%rcx
 1012f44:	00 00 50 
 1012f47:	48 21 c8             	and    %rcx,%rax
 1012f4a:	48 83 f8 00          	cmp    $0x0,%rax
 1012f4e:	75 36                	jne    1012f86 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x546>
 1012f50:	48 8b 45 b8          	mov    -0x48(%rbp),%rax
 1012f54:	48 89 45 a0          	mov    %rax,-0x60(%rbp)
 1012f58:	49 89 d6             	mov    %rdx,%r14
 1012f5b:	ba 08 00 00 00       	mov    $0x8,%edx
 1012f60:	be 00 00 00 00       	mov    $0x0,%esi
 1012f65:	49 89 fd             	mov    %rdi,%r13
 1012f68:	48 8d 7d b8          	lea    -0x48(%rbp),%rdi
 1012f6c:	e8 6f 6f 01 00       	call   1029ee0 <compiler_rt.fastMemset>
 1012f71:	4d 89 f8             	mov    %r15,%r8
 1012f74:	4c 89 f2             	mov    %r14,%rdx
 1012f77:	4c 89 ef             	mov    %r13,%rdi
 1012f7a:	48 8b 75 f0          	mov    -0x10(%rbp),%rsi
 1012f7e:	4d 89 c7             	mov    %r8,%r15
 1012f81:	48 87 df             	xchg   %rbx,%rdi
 1012f84:	eb 4c                	jmp    1012fd2 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x592>
 1012f86:	4d 89 f8             	mov    %r15,%r8
 1012f89:	4d 89 c7             	mov    %r8,%r15
 1012f8c:	48 8d 4d b8          	lea    -0x48(%rbp),%rcx
 1012f90:	49 89 d6             	mov    %rdx,%r14
 1012f93:	48 8d 55 a0          	lea    -0x60(%rbp),%rdx
 1012f97:	48 8d 35 42 b2 01 00 	lea    0x1b242(%rip),%rsi        # 102e1e0 <myl_t_1e414bd82e4b50b54939760a2d591f88da97e2f1c8252dbd7dcbc73438e46afb>
 1012f9e:	49 89 fd             	mov    %rdi,%r13
 1012fa1:	e8 4a 6a 01 00       	call   10299f0 <myl_rc_native_take>
 1012fa6:	4c 89 f2             	mov    %r14,%rdx
 1012fa9:	4c 89 ef             	mov    %r13,%rdi
 1012fac:	48 8b 75 f0          	mov    -0x10(%rbp),%rsi
 1012fb0:	83 f8 00             	cmp    $0x0,%eax
 1012fb3:	75 1a                	jne    1012fcf <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x58f>
 1012fb5:	e8 06 ea 00 00       	call   10219c0 <myl_rc_take_failure>
 1012fba:	48 89 df             	mov    %rbx,%rdi
 1012fbd:	89 c6                	mov    %eax,%esi
 1012fbf:	48 89 fb             	mov    %rdi,%rbx
 1012fc2:	e8 c9 60 00 00       	call   1019090 <myl_qbe_rc_status>
 1012fc7:	48 89 df             	mov    %rbx,%rdi
 1012fca:	e9 9d 06 00 00       	jmp    101366c <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xc2c>
 1012fcf:	48 87 df             	xchg   %rbx,%rdi
 1012fd2:	c7 85 60 ff ff ff 00 	movl   $0x0,-0xa0(%rbp)
 1012fd9:	00 00 00 
 1012fdc:	48 8d 05 fd b1 01 00 	lea    0x1b1fd(%rip),%rax        # 102e1e0 <myl_t_1e414bd82e4b50b54939760a2d591f88da97e2f1c8252dbd7dcbc73438e46afb>
 1012fe3:	48 89 85 20 ff ff ff 	mov    %rax,-0xe0(%rbp)
 1012fea:	c7 85 38 ff ff ff 02 	movl   $0x2,-0xc8(%rbp)
 1012ff1:	00 00 00 
 1012ff4:	c7 85 70 ff ff ff 01 	movl   $0x1,-0x90(%rbp)
 1012ffb:	00 00 00 
 1012ffe:	48 8b 45 a0          	mov    -0x60(%rbp),%rax
 1013002:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
 1013006:	c7 85 70 ff ff ff 00 	movl   $0x0,-0x90(%rbp)
 101300d:	00 00 00 
 1013010:	eb 15                	jmp    1013027 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x5e7>
 1013012:	48 87 df             	xchg   %rbx,%rdi
 1013015:	48 8b 45 b8          	mov    -0x48(%rbp),%rax
 1013019:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
 101301d:	c7 85 60 ff ff ff 00 	movl   $0x0,-0xa0(%rbp)
 1013024:	00 00 00 
 1013027:	48 8d 45 c8          	lea    -0x38(%rbp),%rax
 101302b:	48 89 45 b8          	mov    %rax,-0x48(%rbp)
 101302f:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
 1013033:	48 89 45 80          	mov    %rax,-0x80(%rbp)
 1013037:	48 8d 05 d2 b3 01 00 	lea    0x1b3d2(%rip),%rax        # 102e410 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 101303e:	48 89 85 e0 fe ff ff 	mov    %rax,-0x120(%rbp)
 1013045:	c7 85 f8 fe ff ff 02 	movl   $0x2,-0x108(%rbp)
 101304c:	00 00 00 
 101304f:	c7 85 60 ff ff ff 01 	movl   $0x1,-0xa0(%rbp)
 1013056:	00 00 00 
 1013059:	48 8d 45 80          	lea    -0x80(%rbp),%rax
 101305d:	48 89 45 b8          	mov    %rax,-0x48(%rbp)
 1013061:	c7 85 78 ff ff ff 00 	movl   $0x0,-0x88(%rbp)
 1013068:	00 00 00 
 101306b:	48 89 55 c0          	mov    %rdx,-0x40(%rbp)
 101306f:	48 89 75 c0          	mov    %rsi,-0x40(%rbp)
 1013073:	49 89 fd             	mov    %rdi,%r13
 1013076:	e8 c5 f9 ff ff       	call   1012a40 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531>
 101307b:	4c 89 ef             	mov    %r13,%rdi
 101307e:	48 89 c1             	mov    %rax,%rcx
 1013081:	48 89 d0             	mov    %rdx,%rax
 1013084:	48 89 8d a0 fe ff ff 	mov    %rcx,-0x160(%rbp)
 101308b:	48 89 85 a8 fe ff ff 	mov    %rax,-0x158(%rbp)
 1013092:	48 8d 85 a0 fe ff ff 	lea    -0x160(%rbp),%rax
 1013099:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
 101309d:	48 8b 85 a0 fe ff ff 	mov    -0x160(%rbp),%rax
 10130a4:	48 89 45 a0          	mov    %rax,-0x60(%rbp)
 10130a8:	48 8b 85 a8 fe ff ff 	mov    -0x158(%rbp),%rax
 10130af:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
 10130b3:	48 8d 05 c6 b3 01 00 	lea    0x1b3c6(%rip),%rax        # 102e480 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 10130ba:	48 89 85 20 ff ff ff 	mov    %rax,-0xe0(%rbp)
 10130c1:	c7 85 38 ff ff ff 02 	movl   $0x2,-0xc8(%rbp)
 10130c8:	00 00 00 
 10130cb:	c7 85 70 ff ff ff 01 	movl   $0x1,-0x90(%rbp)
 10130d2:	00 00 00 
 10130d5:	48 8b 45 a0          	mov    -0x60(%rbp),%rax
 10130d9:	48 89 45 90          	mov    %rax,-0x70(%rbp)
 10130dd:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
 10130e1:	48 89 45 98          	mov    %rax,-0x68(%rbp)
 10130e5:	48 8d 05 94 b3 01 00 	lea    0x1b394(%rip),%rax        # 102e480 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 10130ec:	48 89 85 00 ff ff ff 	mov    %rax,-0x100(%rbp)
 10130f3:	c7 85 18 ff ff ff 02 	movl   $0x2,-0xe8(%rbp)
 10130fa:	00 00 00 
 10130fd:	c7 85 18 ff ff ff 02 	movl   $0x2,-0xe8(%rbp)
 1013104:	00 00 00 
 1013107:	c7 85 70 ff ff ff 00 	movl   $0x0,-0x90(%rbp)
 101310e:	00 00 00 
 1013111:	c7 85 68 ff ff ff 01 	movl   $0x1,-0x98(%rbp)
 1013118:	00 00 00 
 101311b:	48 8d 45 90          	lea    -0x70(%rbp),%rax
 101311f:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
 1013123:	ba 01 00 00 00       	mov    $0x1,%edx
 1013128:	48 8d 35 41 b0 01 00 	lea    0x1b041(%rip),%rsi        # 102e170 <myl_t_1e414bd82e4b50b54939760a2d591f88da97e2f1c8252dbd7dcbc73438e46afb_body>
 101312f:	49 89 fd             	mov    %rdi,%r13
 1013132:	48 89 df             	mov    %rbx,%rdi
 1013135:	e8 16 b0 00 00       	call   101e150 <myl_native_heap_alloc>
 101313a:	4c 89 ef             	mov    %r13,%rdi
 101313d:	49 89 c5             	mov    %rax,%r13
 1013140:	41 83 fd 00          	cmp    $0x0,%r13d
 1013144:	75 0a                	jne    1013150 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x710>
 1013146:	48 89 fb             	mov    %rdi,%rbx
 1013149:	e8 a2 66 00 00       	call   10197f0 <myl_qbe_fail_allocation>
 101314e:	0f 0b                	ud2
 1013150:	48 87 fb             	xchg   %rdi,%rbx
 1013153:	4c 89 6d b0          	mov    %r13,-0x50(%rbp)
 1013157:	48 8d 05 82 b0 01 00 	lea    0x1b082(%rip),%rax        # 102e1e0 <myl_t_1e414bd82e4b50b54939760a2d591f88da97e2f1c8252dbd7dcbc73438e46afb>
 101315e:	48 89 85 40 ff ff ff 	mov    %rax,-0xc0(%rbp)
 1013165:	c7 85 58 ff ff ff 02 	movl   $0x2,-0xa8(%rbp)
 101316c:	00 00 00 
 101316f:	48 8d 45 b0          	lea    -0x50(%rbp),%rax
 1013173:	48 89 85 48 ff ff ff 	mov    %rax,-0xb8(%rbp)
 101317a:	4c 89 a5 50 ff ff ff 	mov    %r12,-0xb0(%rbp)
 1013181:	c7 85 58 ff ff ff 04 	movl   $0x4,-0xa8(%rbp)
 1013188:	00 00 00 
 101318b:	c7 85 78 ff ff ff 01 	movl   $0x1,-0x88(%rbp)
 1013192:	00 00 00 
 1013195:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
 1013199:	8b 8d 68 ff ff ff    	mov    -0x98(%rbp),%ecx
 101319f:	8b 95 18 ff ff ff    	mov    -0xe8(%rbp),%edx
 10131a5:	83 e2 18             	and    $0x18,%edx
 10131a8:	83 fa 00             	cmp    $0x0,%edx
 10131ab:	0f 94 c2             	sete   %dl
 10131ae:	0f b6 d2             	movzbl %dl,%edx
 10131b1:	85 ca                	test   %ecx,%edx
 10131b3:	0f 85 fc 00 00 00    	jne    10132b5 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x875>
 10131b9:	48 8b 08             	mov    (%rax),%rcx
 10131bc:	48 83 f9 00          	cmp    $0x0,%rcx
 10131c0:	74 1a                	je     10131dc <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x79c>
 10131c2:	48 83 e9 10          	sub    $0x10,%rcx
 10131c6:	48 8b 09             	mov    (%rcx),%rcx
 10131c9:	48 ba 01 00 00 00 00 	movabs $0x5000000000000001,%rdx
 10131d0:	00 00 50 
 10131d3:	48 21 d1             	and    %rdx,%rcx
 10131d6:	48 83 f9 00          	cmp    $0x0,%rcx
 10131da:	75 53                	jne    101322f <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x7ef>
 10131dc:	48 8b 48 08          	mov    0x8(%rax),%rcx
 10131e0:	48 83 f9 00          	cmp    $0x0,%rcx
 10131e4:	74 1a                	je     1013200 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x7c0>
 10131e6:	48 83 e9 10          	sub    $0x10,%rcx
 10131ea:	48 8b 09             	mov    (%rcx),%rcx
 10131ed:	48 ba 01 00 00 00 00 	movabs $0x5000000000000001,%rdx
 10131f4:	00 00 50 
 10131f7:	48 21 d1             	and    %rdx,%rcx
 10131fa:	48 83 f9 00          	cmp    $0x0,%rcx
 10131fe:	75 2f                	jne    101322f <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x7ef>
 1013200:	48 8b 08             	mov    (%rax),%rcx
 1013203:	48 89 4d a0          	mov    %rcx,-0x60(%rbp)
 1013207:	48 8b 48 08          	mov    0x8(%rax),%rcx
 101320b:	48 89 4d a8          	mov    %rcx,-0x58(%rbp)
 101320f:	ba 10 00 00 00       	mov    $0x10,%edx
 1013214:	be 00 00 00 00       	mov    $0x0,%esi
 1013219:	49 89 fe             	mov    %rdi,%r14
 101321c:	48 89 c7             	mov    %rax,%rdi
 101321f:	e8 bc 6c 01 00       	call   1029ee0 <compiler_rt.fastMemset>
 1013224:	4d 89 f8             	mov    %r15,%r8
 1013227:	4c 89 f7             	mov    %r14,%rdi
 101322a:	4d 89 c6             	mov    %r8,%r14
 101322d:	eb 3e                	jmp    101326d <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x82d>
 101322f:	4d 89 f8             	mov    %r15,%r8
 1013232:	4d 89 c6             	mov    %r8,%r14
 1013235:	48 89 c1             	mov    %rax,%rcx
 1013238:	48 8d 55 a0          	lea    -0x60(%rbp),%rdx
 101323c:	48 8d 35 3d b2 01 00 	lea    0x1b23d(%rip),%rsi        # 102e480 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 1013243:	49 89 ff             	mov    %rdi,%r15
 1013246:	e8 a5 67 01 00       	call   10299f0 <myl_rc_native_take>
 101324b:	4c 89 ff             	mov    %r15,%rdi
 101324e:	83 f8 00             	cmp    $0x0,%eax
 1013251:	75 1a                	jne    101326d <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x82d>
 1013253:	e8 68 e7 00 00       	call   10219c0 <myl_rc_take_failure>
 1013258:	48 89 df             	mov    %rbx,%rdi
 101325b:	89 c6                	mov    %eax,%esi
 101325d:	48 89 fb             	mov    %rdi,%rbx
 1013260:	e8 2b 5e 00 00       	call   1019090 <myl_qbe_rc_status>
 1013265:	48 89 df             	mov    %rbx,%rdi
 1013268:	e9 ff 03 00 00       	jmp    101366c <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xc2c>
 101326d:	c7 85 68 ff ff ff 00 	movl   $0x0,-0x98(%rbp)
 1013274:	00 00 00 
 1013277:	48 8d 05 02 b2 01 00 	lea    0x1b202(%rip),%rax        # 102e480 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 101327e:	48 89 85 20 ff ff ff 	mov    %rax,-0xe0(%rbp)
 1013285:	c7 85 38 ff ff ff 02 	movl   $0x2,-0xc8(%rbp)
 101328c:	00 00 00 
 101328f:	c7 85 70 ff ff ff 01 	movl   $0x1,-0x90(%rbp)
 1013296:	00 00 00 
 1013299:	48 8b 45 a0          	mov    -0x60(%rbp),%rax
 101329d:	49 89 45 00          	mov    %rax,0x0(%r13)
 10132a1:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
 10132a5:	49 89 45 08          	mov    %rax,0x8(%r13)
 10132a9:	c7 85 70 ff ff ff 00 	movl   $0x0,-0x90(%rbp)
 10132b0:	00 00 00 
 10132b3:	eb 1c                	jmp    10132d1 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x891>
 10132b5:	4d 89 fe             	mov    %r15,%r14
 10132b8:	48 8b 08             	mov    (%rax),%rcx
 10132bb:	49 89 4d 00          	mov    %rcx,0x0(%r13)
 10132bf:	48 8b 40 08          	mov    0x8(%rax),%rax
 10132c3:	49 89 45 08          	mov    %rax,0x8(%r13)
 10132c7:	c7 85 68 ff ff ff 00 	movl   $0x0,-0x98(%rbp)
 10132ce:	00 00 00 
 10132d1:	4c 89 6d c0          	mov    %r13,-0x40(%rbp)
 10132d5:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
 10132d9:	48 89 45 90          	mov    %rax,-0x70(%rbp)
 10132dd:	48 8d 05 fc ae 01 00 	lea    0x1aefc(%rip),%rax        # 102e1e0 <myl_t_1e414bd82e4b50b54939760a2d591f88da97e2f1c8252dbd7dcbc73438e46afb>
 10132e4:	48 89 85 00 ff ff ff 	mov    %rax,-0x100(%rbp)
 10132eb:	c7 85 18 ff ff ff 02 	movl   $0x2,-0xe8(%rbp)
 10132f2:	00 00 00 
 10132f5:	c7 85 68 ff ff ff 01 	movl   $0x1,-0x98(%rbp)
 10132fc:	00 00 00 
 10132ff:	4c 89 6d c0          	mov    %r13,-0x40(%rbp)
 1013303:	c7 85 78 ff ff ff 00 	movl   $0x0,-0x88(%rbp)
 101330a:	00 00 00 
 101330d:	ba 08 00 00 00       	mov    $0x8,%edx
 1013312:	be 00 00 00 00       	mov    $0x0,%esi
 1013317:	49 89 fd             	mov    %rdi,%r13
 101331a:	48 8d 7d d0          	lea    -0x30(%rbp),%rdi
 101331e:	e8 bd 6b 01 00       	call   1029ee0 <compiler_rt.fastMemset>
 1013323:	4c 89 ef             	mov    %r13,%rdi
 1013326:	48 8d 05 e3 b0 01 00 	lea    0x1b0e3(%rip),%rax        # 102e410 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 101332d:	48 89 85 40 ff ff ff 	mov    %rax,-0xc0(%rbp)
 1013334:	c7 85 58 ff ff ff 02 	movl   $0x2,-0xa8(%rbp)
 101333b:	00 00 00 
 101333e:	48 8d 45 d0          	lea    -0x30(%rbp),%rax
 1013342:	48 89 85 48 ff ff ff 	mov    %rax,-0xb8(%rbp)
 1013349:	4c 89 a5 50 ff ff ff 	mov    %r12,-0xb0(%rbp)
 1013350:	c7 85 78 ff ff ff 01 	movl   $0x1,-0x88(%rbp)
 1013357:	00 00 00 
 101335a:	8b 85 68 ff ff ff    	mov    -0x98(%rbp),%eax
 1013360:	8b 8d 18 ff ff ff    	mov    -0xe8(%rbp),%ecx
 1013366:	83 e1 18             	and    $0x18,%ecx
 1013369:	83 f9 00             	cmp    $0x0,%ecx
 101336c:	0f 94 c1             	sete   %cl
 101336f:	0f b6 c9             	movzbl %cl,%ecx
 1013372:	85 c1                	test   %eax,%ecx
 1013374:	0f 85 cc 00 00 00    	jne    1013446 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xa06>
 101337a:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
 101337e:	48 83 f8 00          	cmp    $0x0,%rax
 1013382:	74 1a                	je     101339e <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x95e>
 1013384:	48 83 e8 10          	sub    $0x10,%rax
 1013388:	48 8b 00             	mov    (%rax),%rax
 101338b:	48 b9 01 00 00 00 00 	movabs $0x5000000000000001,%rcx
 1013392:	00 00 50 
 1013395:	48 21 c8             	and    %rcx,%rax
 1013398:	48 83 f8 00          	cmp    $0x0,%rax
 101339c:	75 29                	jne    10133c7 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x987>
 101339e:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
 10133a2:	48 89 45 a0          	mov    %rax,-0x60(%rbp)
 10133a6:	ba 08 00 00 00       	mov    $0x8,%edx
 10133ab:	be 00 00 00 00       	mov    $0x0,%esi
 10133b0:	49 89 fd             	mov    %rdi,%r13
 10133b3:	48 8d 7d c0          	lea    -0x40(%rbp),%rdi
 10133b7:	e8 24 6b 01 00       	call   1029ee0 <compiler_rt.fastMemset>
 10133bc:	4d 89 f0             	mov    %r14,%r8
 10133bf:	4c 89 ef             	mov    %r13,%rdi
 10133c2:	4d 89 c6             	mov    %r8,%r14
 10133c5:	eb 3f                	jmp    1013406 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x9c6>
 10133c7:	4d 89 f0             	mov    %r14,%r8
 10133ca:	4d 89 c6             	mov    %r8,%r14
 10133cd:	48 8d 4d c0          	lea    -0x40(%rbp),%rcx
 10133d1:	48 8d 55 a0          	lea    -0x60(%rbp),%rdx
 10133d5:	48 8d 35 04 ae 01 00 	lea    0x1ae04(%rip),%rsi        # 102e1e0 <myl_t_1e414bd82e4b50b54939760a2d591f88da97e2f1c8252dbd7dcbc73438e46afb>
 10133dc:	49 89 fd             	mov    %rdi,%r13
 10133df:	e8 0c 66 01 00       	call   10299f0 <myl_rc_native_take>
 10133e4:	4c 89 ef             	mov    %r13,%rdi
 10133e7:	83 f8 00             	cmp    $0x0,%eax
 10133ea:	75 1a                	jne    1013406 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x9c6>
 10133ec:	e8 cf e5 00 00       	call   10219c0 <myl_rc_take_failure>
 10133f1:	48 89 df             	mov    %rbx,%rdi
 10133f4:	89 c6                	mov    %eax,%esi
 10133f6:	48 89 fb             	mov    %rdi,%rbx
 10133f9:	e8 92 5c 00 00       	call   1019090 <myl_qbe_rc_status>
 10133fe:	48 89 df             	mov    %rbx,%rdi
 1013401:	e9 66 02 00 00       	jmp    101366c <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xc2c>
 1013406:	c7 85 68 ff ff ff 00 	movl   $0x0,-0x98(%rbp)
 101340d:	00 00 00 
 1013410:	48 8d 05 c9 ad 01 00 	lea    0x1adc9(%rip),%rax        # 102e1e0 <myl_t_1e414bd82e4b50b54939760a2d591f88da97e2f1c8252dbd7dcbc73438e46afb>
 1013417:	48 89 85 20 ff ff ff 	mov    %rax,-0xe0(%rbp)
 101341e:	c7 85 38 ff ff ff 02 	movl   $0x2,-0xc8(%rbp)
 1013425:	00 00 00 
 1013428:	c7 85 70 ff ff ff 01 	movl   $0x1,-0x90(%rbp)
 101342f:	00 00 00 
 1013432:	48 8b 45 a0          	mov    -0x60(%rbp),%rax
 1013436:	48 89 45 d0          	mov    %rax,-0x30(%rbp)
 101343a:	c7 85 70 ff ff ff 00 	movl   $0x0,-0x90(%rbp)
 1013441:	00 00 00 
 1013444:	eb 12                	jmp    1013458 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xa18>
 1013446:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
 101344a:	48 89 45 d0          	mov    %rax,-0x30(%rbp)
 101344e:	c7 85 68 ff ff ff 00 	movl   $0x0,-0x98(%rbp)
 1013455:	00 00 00 
 1013458:	48 8d 45 d0          	lea    -0x30(%rbp),%rax
 101345c:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
 1013460:	48 8b 45 d0          	mov    -0x30(%rbp),%rax
 1013464:	48 89 45 90          	mov    %rax,-0x70(%rbp)
 1013468:	48 8d 05 a1 af 01 00 	lea    0x1afa1(%rip),%rax        # 102e410 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 101346f:	48 89 85 00 ff ff ff 	mov    %rax,-0x100(%rbp)
 1013476:	c7 85 18 ff ff ff 02 	movl   $0x2,-0xe8(%rbp)
 101347d:	00 00 00 
 1013480:	c7 85 68 ff ff ff 01 	movl   $0x1,-0x98(%rbp)
 1013487:	00 00 00 
 101348a:	48 8d 45 90          	lea    -0x70(%rbp),%rax
 101348e:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
 1013492:	c7 85 78 ff ff ff 00 	movl   $0x0,-0x88(%rbp)
 1013499:	00 00 00 
 101349c:	ba 10 00 00 00       	mov    $0x10,%edx
 10134a1:	be 00 00 00 00       	mov    $0x0,%esi
 10134a6:	49 89 fd             	mov    %rdi,%r13
 10134a9:	48 8d 7d d8          	lea    -0x28(%rbp),%rdi
 10134ad:	e8 2e 6a 01 00       	call   1029ee0 <compiler_rt.fastMemset>
 10134b2:	4d 89 f0             	mov    %r14,%r8
 10134b5:	4c 89 ef             	mov    %r13,%rdi
 10134b8:	48 8d 05 c1 af 01 00 	lea    0x1afc1(%rip),%rax        # 102e480 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 10134bf:	48 89 85 40 ff ff ff 	mov    %rax,-0xc0(%rbp)
 10134c6:	c7 85 58 ff ff ff 02 	movl   $0x2,-0xa8(%rbp)
 10134cd:	00 00 00 
 10134d0:	48 8d 45 d8          	lea    -0x28(%rbp),%rax
 10134d4:	48 89 85 48 ff ff ff 	mov    %rax,-0xb8(%rbp)
 10134db:	4c 89 a5 50 ff ff ff 	mov    %r12,-0xb0(%rbp)
 10134e2:	c7 85 78 ff ff ff 01 	movl   $0x1,-0x88(%rbp)
 10134e9:	00 00 00 
 10134ec:	48 8b 45 b8          	mov    -0x48(%rbp),%rax
 10134f0:	8b 8d 60 ff ff ff    	mov    -0xa0(%rbp),%ecx
 10134f6:	8b 95 f8 fe ff ff    	mov    -0x108(%rbp),%edx
 10134fc:	83 e2 18             	and    $0x18,%edx
 10134ff:	83 fa 00             	cmp    $0x0,%edx
 1013502:	0f 94 c2             	sete   %dl
 1013505:	0f b6 d2             	movzbl %dl,%edx
 1013508:	85 ca                	test   %ecx,%edx
 101350a:	0f 85 99 00 00 00    	jne    10135a9 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xb69>
 1013510:	4d 89 c5             	mov    %r8,%r13
 1013513:	48 89 c1             	mov    %rax,%rcx
 1013516:	48 8d 55 a0          	lea    -0x60(%rbp),%rdx
 101351a:	48 8d 35 ef ae 01 00 	lea    0x1aeef(%rip),%rsi        # 102e410 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 1013521:	49 89 fc             	mov    %rdi,%r12
 1013524:	e8 07 68 01 00       	call   1029d30 <myl_rc_native_retain>
 1013529:	4c 89 e7             	mov    %r12,%rdi
 101352c:	83 f8 00             	cmp    $0x0,%eax
 101352f:	75 1a                	jne    101354b <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xb0b>
 1013531:	e8 8a e4 00 00       	call   10219c0 <myl_rc_take_failure>
 1013536:	48 89 df             	mov    %rbx,%rdi
 1013539:	89 c6                	mov    %eax,%esi
 101353b:	48 89 fb             	mov    %rdi,%rbx
 101353e:	e8 4d 5b 00 00       	call   1019090 <myl_qbe_rc_status>
 1013543:	48 89 df             	mov    %rbx,%rdi
 1013546:	e9 21 01 00 00       	jmp    101366c <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xc2c>
 101354b:	48 87 df             	xchg   %rbx,%rdi
 101354e:	48 8d 05 bb ae 01 00 	lea    0x1aebb(%rip),%rax        # 102e410 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 1013555:	48 89 85 20 ff ff ff 	mov    %rax,-0xe0(%rbp)
 101355c:	c7 85 38 ff ff ff 02 	movl   $0x2,-0xc8(%rbp)
 1013563:	00 00 00 
 1013566:	c7 85 70 ff ff ff 01 	movl   $0x1,-0x90(%rbp)
 101356d:	00 00 00 
 1013570:	8b 85 60 ff ff ff    	mov    -0xa0(%rbp),%eax
 1013576:	83 f8 00             	cmp    $0x0,%eax
 1013579:	75 05                	jne    1013580 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xb40>
 101357b:	4d 89 e8             	mov    %r13,%r8
 101357e:	eb 15                	jmp    1013595 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xb55>
 1013580:	48 8d b5 e0 fe ff ff 	lea    -0x120(%rbp),%rsi
 1013587:	49 89 fc             	mov    %rdi,%r12
 101358a:	e8 d1 5c 00 00       	call   1019260 <myl_qbe_rc_slot_drop>
 101358f:	4d 89 e8             	mov    %r13,%r8
 1013592:	4c 89 e7             	mov    %r12,%rdi
 1013595:	48 8b 45 a0          	mov    -0x60(%rbp),%rax
 1013599:	48 89 45 d8          	mov    %rax,-0x28(%rbp)
 101359d:	c7 85 70 ff ff ff 00 	movl   $0x0,-0x90(%rbp)
 10135a4:	00 00 00 
 10135a7:	eb 14                	jmp    10135bd <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xb7d>
 10135a9:	48 87 df             	xchg   %rbx,%rdi
 10135ac:	48 8b 00             	mov    (%rax),%rax
 10135af:	48 89 45 d8          	mov    %rax,-0x28(%rbp)
 10135b3:	c7 85 60 ff ff ff 00 	movl   $0x0,-0xa0(%rbp)
 10135ba:	00 00 00 
 10135bd:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
 10135c1:	48 8d 4d d8          	lea    -0x28(%rbp),%rcx
 10135c5:	49 89 cc             	mov    %rcx,%r12
 10135c8:	49 83 c4 08          	add    $0x8,%r12
 10135cc:	8b 8d 68 ff ff ff    	mov    -0x98(%rbp),%ecx
 10135d2:	8b 95 18 ff ff ff    	mov    -0xe8(%rbp),%edx
 10135d8:	83 e2 18             	and    $0x18,%edx
 10135db:	83 fa 00             	cmp    $0x0,%edx
 10135de:	0f 94 c2             	sete   %dl
 10135e1:	0f b6 d2             	movzbl %dl,%edx
 10135e4:	85 ca                	test   %ecx,%edx
 10135e6:	0f 85 0c 01 00 00    	jne    10136f8 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xcb8>
 10135ec:	48 8b 08             	mov    (%rax),%rcx
 10135ef:	48 83 f9 00          	cmp    $0x0,%rcx
 10135f3:	74 1a                	je     101360f <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xbcf>
 10135f5:	48 83 e9 10          	sub    $0x10,%rcx
 10135f9:	48 8b 09             	mov    (%rcx),%rcx
 10135fc:	48 ba 01 00 00 00 00 	movabs $0x5000000000000001,%rdx
 1013603:	00 00 50 
 1013606:	48 21 d1             	and    %rdx,%rcx
 1013609:	48 83 f9 00          	cmp    $0x0,%rcx
 101360d:	75 27                	jne    1013636 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xbf6>
 101360f:	48 8b 08             	mov    (%rax),%rcx
 1013612:	48 89 4d a0          	mov    %rcx,-0x60(%rbp)
 1013616:	ba 08 00 00 00       	mov    $0x8,%edx
 101361b:	be 00 00 00 00       	mov    $0x0,%esi
 1013620:	48 89 fb             	mov    %rdi,%rbx
 1013623:	48 89 c7             	mov    %rax,%rdi
 1013626:	e8 b5 68 01 00       	call   1029ee0 <compiler_rt.fastMemset>
 101362b:	48 89 df             	mov    %rbx,%rdi
 101362e:	4c 89 e3             	mov    %r12,%rbx
 1013631:	e9 83 00 00 00       	jmp    10136b9 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xc79>
 1013636:	48 87 fb             	xchg   %rdi,%rbx
 1013639:	48 89 c1             	mov    %rax,%rcx
 101363c:	48 8d 55 a0          	lea    -0x60(%rbp),%rdx
 1013640:	48 8d 35 c9 ad 01 00 	lea    0x1adc9(%rip),%rsi        # 102e410 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 1013647:	49 89 fd             	mov    %rdi,%r13
 101364a:	e8 a1 63 01 00       	call   10299f0 <myl_rc_native_take>
 101364f:	4c 89 ef             	mov    %r13,%rdi
 1013652:	83 f8 00             	cmp    $0x0,%eax
 1013655:	75 5c                	jne    10136b3 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xc73>
 1013657:	e8 64 e3 00 00       	call   10219c0 <myl_rc_take_failure>
 101365c:	48 89 df             	mov    %rbx,%rdi
 101365f:	89 c6                	mov    %eax,%esi
 1013661:	48 89 fb             	mov    %rdi,%rbx
 1013664:	e8 27 5a 00 00       	call   1019090 <myl_qbe_rc_status>
 1013669:	48 89 df             	mov    %rbx,%rdi
 101366c:	48 8d b5 c0 fe ff ff 	lea    -0x140(%rbp),%rsi
 1013673:	48 89 fb             	mov    %rdi,%rbx
 1013676:	e8 15 5d 00 00       	call   1019390 <myl_qbe_rc_frame_cleanup>
 101367b:	48 89 df             	mov    %rbx,%rdi
 101367e:	48 8d b5 c0 fe ff ff 	lea    -0x140(%rbp),%rsi
 1013685:	e8 76 5b 00 00       	call   1019200 <myl_qbe_rc_frame_leave>
 101368a:	ba 10 00 00 00       	mov    $0x10,%edx
 101368f:	be 00 00 00 00       	mov    $0x0,%esi
 1013694:	48 8d bd b0 fe ff ff 	lea    -0x150(%rbp),%rdi
 101369b:	e8 40 68 01 00       	call   1029ee0 <compiler_rt.fastMemset>
 10136a0:	48 8b 85 b0 fe ff ff 	mov    -0x150(%rbp),%rax
 10136a7:	48 8b 95 b8 fe ff ff 	mov    -0x148(%rbp),%rdx
 10136ae:	e9 12 01 00 00       	jmp    10137c5 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xd85>
 10136b3:	48 89 df             	mov    %rbx,%rdi
 10136b6:	4c 89 e3             	mov    %r12,%rbx
 10136b9:	c7 85 68 ff ff ff 00 	movl   $0x0,-0x98(%rbp)
 10136c0:	00 00 00 
 10136c3:	48 8d 05 46 ad 01 00 	lea    0x1ad46(%rip),%rax        # 102e410 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 10136ca:	48 89 85 20 ff ff ff 	mov    %rax,-0xe0(%rbp)
 10136d1:	c7 85 38 ff ff ff 02 	movl   $0x2,-0xc8(%rbp)
 10136d8:	00 00 00 
 10136db:	c7 85 70 ff ff ff 01 	movl   $0x1,-0x90(%rbp)
 10136e2:	00 00 00 
 10136e5:	48 8b 45 a0          	mov    -0x60(%rbp),%rax
 10136e9:	48 89 03             	mov    %rax,(%rbx)
 10136ec:	c7 85 70 ff ff ff 00 	movl   $0x0,-0x90(%rbp)
 10136f3:	00 00 00 
 10136f6:	eb 13                	jmp    101370b <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xccb>
 10136f8:	4c 89 e3             	mov    %r12,%rbx
 10136fb:	48 8b 00             	mov    (%rax),%rax
 10136fe:	48 89 03             	mov    %rax,(%rbx)
 1013701:	c7 85 68 ff ff ff 00 	movl   $0x0,-0x98(%rbp)
 1013708:	00 00 00 
 101370b:	48 8d 45 d8          	lea    -0x28(%rbp),%rax
 101370f:	48 89 45 b8          	mov    %rax,-0x48(%rbp)
 1013713:	48 8b 45 d8          	mov    -0x28(%rbp),%rax
 1013717:	48 89 45 80          	mov    %rax,-0x80(%rbp)
 101371b:	48 8b 45 e0          	mov    -0x20(%rbp),%rax
 101371f:	48 89 45 88          	mov    %rax,-0x78(%rbp)
 1013723:	48 8d 05 56 ad 01 00 	lea    0x1ad56(%rip),%rax        # 102e480 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 101372a:	48 89 85 e0 fe ff ff 	mov    %rax,-0x120(%rbp)
 1013731:	c7 85 f8 fe ff ff 02 	movl   $0x2,-0x108(%rbp)
 1013738:	00 00 00 
 101373b:	c7 85 60 ff ff ff 01 	movl   $0x1,-0xa0(%rbp)
 1013742:	00 00 00 
 1013745:	48 8d 45 80          	lea    -0x80(%rbp),%rax
 1013749:	48 89 45 b8          	mov    %rax,-0x48(%rbp)
 101374d:	c7 85 78 ff ff ff 00 	movl   $0x0,-0x88(%rbp)
 1013754:	00 00 00 
 1013757:	48 8b 45 80          	mov    -0x80(%rbp),%rax
 101375b:	48 89 45 a0          	mov    %rax,-0x60(%rbp)
 101375f:	48 8b 45 88          	mov    -0x78(%rbp),%rax
 1013763:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
 1013767:	c7 85 60 ff ff ff 00 	movl   $0x0,-0xa0(%rbp)
 101376e:	00 00 00 
 1013771:	48 8d b5 c0 fe ff ff 	lea    -0x140(%rbp),%rsi
 1013778:	e8 83 5a 00 00       	call   1019200 <myl_qbe_rc_frame_leave>
 101377d:	48 8b 45 a0          	mov    -0x60(%rbp),%rax
 1013781:	48 8b 55 a8          	mov    -0x58(%rbp),%rdx
 1013785:	eb 3e                	jmp    10137c5 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xd85>
 1013787:	4c 89 ea             	mov    %r13,%rdx
 101378a:	41 b8 40 00 00 00    	mov    $0x40,%r8d
 1013790:	b9 01 00 00 00       	mov    $0x1,%ecx
 1013795:	be 01 00 00 00       	mov    $0x1,%esi
 101379a:	e8 91 61 00 00       	call   1019930 <myl_qbe_fail_overflow_op>
 101379f:	0f 0b                	ud2
 10137a1:	48 c7 85 b0 fe ff ff 	movq   $0x0,-0x150(%rbp)
 10137a8:	00 00 00 00 
 10137ac:	48 c7 85 b8 fe ff ff 	movq   $0x0,-0x148(%rbp)
 10137b3:	00 00 00 00 
 10137b7:	48 8b 85 b0 fe ff ff 	mov    -0x150(%rbp),%rax
 10137be:	48 8b 95 b8 fe ff ff 	mov    -0x148(%rbp),%rdx
 10137c5:	41 5f                	pop    %r15
 10137c7:	41 5e                	pop    %r14
 10137c9:	41 5d                	pop    %r13
 10137cb:	41 5c                	pop    %r12
 10137cd:	5b                   	pop    %rbx
 10137ce:	c9                   	leave
 10137cf:	c3                   	ret
 10137d0:	e8 ab 62 00 00       	call   1019a80 <myl_qbe_fail_frame>
 10137d5:	0f 0b                	ud2

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
