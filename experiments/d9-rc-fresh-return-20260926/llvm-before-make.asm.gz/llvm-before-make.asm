
.tmp-mut-argument/return-run/trees-llvm-before-rc:     file format elf64-x86-64


Disassembly of section .text:

000000000101a490 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531>:
 101a490:	55                   	push   %rbp
 101a491:	41 57                	push   %r15
 101a493:	41 56                	push   %r14
 101a495:	41 55                	push   %r13
 101a497:	41 54                	push   %r12
 101a499:	53                   	push   %rbx
 101a49a:	48 81 ec 18 01 00 00 	sub    $0x118,%rsp
 101a4a1:	48 89 fb             	mov    %rdi,%rbx
 101a4a4:	48 39 67 40          	cmp    %rsp,0x40(%rdi)
 101a4a8:	0f 87 3f 09 00 00    	ja     101aded <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x95d>
 101a4ae:	49 89 f7             	mov    %rsi,%r15
 101a4b1:	48 85 f6             	test   %rsi,%rsi
 101a4b4:	0f 84 62 08 00 00    	je     101ad1c <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x88c>
 101a4ba:	8b ab c8 02 00 00    	mov    0x2c8(%rbx),%ebp
 101a4c0:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
 101a4c4:	c5 fc 11 44 24 20    	vmovups %ymm0,0x20(%rsp)
 101a4ca:	c5 fc 11 84 24 a8 00 	vmovups %ymm0,0xa8(%rsp)
 101a4d1:	00 00 
 101a4d3:	c5 fc 11 84 24 c8 00 	vmovups %ymm0,0xc8(%rsp)
 101a4da:	00 00 
 101a4dc:	c5 fc 11 84 24 e8 00 	vmovups %ymm0,0xe8(%rsp)
 101a4e3:	00 00 
 101a4e5:	48 c7 84 24 08 01 00 	movq   $0x0,0x108(%rsp)
 101a4ec:	00 00 00 00 00 
 101a4f1:	48 c7 84 24 90 00 00 	movq   $0x1009be8,0x90(%rsp)
 101a4f8:	00 e8 9b 00 01 
 101a4fd:	48 8d 44 24 10       	lea    0x10(%rsp),%rax
 101a502:	48 89 84 24 98 00 00 	mov    %rax,0x98(%rsp)
 101a509:	00 
 101a50a:	48 8d 44 24 20       	lea    0x20(%rsp),%rax
 101a50f:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
 101a516:	00 
 101a517:	48 c7 84 24 b0 00 00 	movq   $0x1009be8,0xb0(%rsp)
 101a51e:	00 e8 9b 00 01 
 101a523:	48 8d 44 24 48       	lea    0x48(%rsp),%rax
 101a528:	48 89 84 24 b8 00 00 	mov    %rax,0xb8(%rsp)
 101a52f:	00 
 101a530:	48 8d 44 24 28       	lea    0x28(%rsp),%rax
 101a535:	48 89 84 24 c0 00 00 	mov    %rax,0xc0(%rsp)
 101a53c:	00 
 101a53d:	48 c7 84 24 d0 00 00 	movq   $0x1009be8,0xd0(%rsp)
 101a544:	00 e8 9b 00 01 
 101a549:	48 89 e0             	mov    %rsp,%rax
 101a54c:	48 89 84 24 d8 00 00 	mov    %rax,0xd8(%rsp)
 101a553:	00 
 101a554:	48 8d 44 24 30       	lea    0x30(%rsp),%rax
 101a559:	48 89 84 24 e0 00 00 	mov    %rax,0xe0(%rsp)
 101a560:	00 
 101a561:	48 c7 84 24 f0 00 00 	movq   $0x1009be8,0xf0(%rsp)
 101a568:	00 e8 9b 00 01 
 101a56d:	48 8d 44 24 78       	lea    0x78(%rsp),%rax
 101a572:	48 89 84 24 f8 00 00 	mov    %rax,0xf8(%rsp)
 101a579:	00 
 101a57a:	4c 8d 64 24 38       	lea    0x38(%rsp),%r12
 101a57f:	4c 89 a4 24 00 01 00 	mov    %r12,0x100(%rsp)
 101a586:	00 
 101a587:	48 85 db             	test   %rbx,%rbx
 101a58a:	0f 84 40 08 00 00    	je     101add0 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x940>
 101a590:	48 8b 83 60 18 00 00 	mov    0x1860(%rbx),%rax
 101a597:	48 85 c0             	test   %rax,%rax
 101a59a:	0f 84 30 08 00 00    	je     101add0 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x940>
 101a5a0:	48 8b 8b 80 3d 00 00 	mov    0x3d80(%rbx),%rcx
 101a5a7:	48 8b 40 70          	mov    0x70(%rax),%rax
 101a5ab:	48 89 4c 24 58       	mov    %rcx,0x58(%rsp)
 101a5b0:	48 8d 8c 24 90 00 00 	lea    0x90(%rsp),%rcx
 101a5b7:	00 
 101a5b8:	48 89 4c 24 60       	mov    %rcx,0x60(%rsp)
 101a5bd:	48 c7 44 24 68 04 00 	movq   $0x4,0x68(%rsp)
 101a5c4:	00 00 
 101a5c6:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
 101a5cb:	48 8d 44 24 58       	lea    0x58(%rsp),%rax
 101a5d0:	48 89 83 80 3d 00 00 	mov    %rax,0x3d80(%rbx)
 101a5d7:	4c 89 f8             	mov    %r15,%rax
 101a5da:	48 f7 d8             	neg    %rax
 101a5dd:	0f 80 12 08 00 00    	jo     101adf5 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x965>
 101a5e3:	49 ff cf             	dec    %r15
 101a5e6:	48 89 df             	mov    %rbx,%rdi
 101a5e9:	4c 89 fe             	mov    %r15,%rsi
 101a5ec:	c5 f8 77             	vzeroupper
 101a5ef:	e8 9c fe ff ff       	call   101a490 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531>
 101a5f4:	48 89 04 24          	mov    %rax,(%rsp)
 101a5f8:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
 101a5fd:	48 c7 84 24 d0 00 00 	movq   $0x100a308,0xd0(%rsp)
 101a604:	00 08 a3 00 01 
 101a609:	c7 84 24 e8 00 00 00 	movl   $0x2,0xe8(%rsp)
 101a610:	02 00 00 00 
 101a614:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
 101a619:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
 101a61e:	48 c7 84 24 90 00 00 	movq   $0x100a308,0x90(%rsp)
 101a625:	00 08 a3 00 01 
 101a62a:	c7 84 24 a8 00 00 00 	movl   $0x2,0xa8(%rsp)
 101a631:	02 00 00 00 
 101a635:	c7 44 24 30 00 00 00 	movl   $0x0,0x30(%rsp)
 101a63c:	00 
 101a63d:	c7 44 24 20 01 00 00 	movl   $0x1,0x20(%rsp)
 101a644:	00 
 101a645:	48 83 bb 60 18 00 00 	cmpq   $0x0,0x1860(%rbx)
 101a64c:	00 
 101a64d:	0f 84 8a 07 00 00    	je     101addd <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x94d>
 101a653:	4c 8d b3 58 02 00 00 	lea    0x258(%rbx),%r14
 101a65a:	8b 8b c8 02 00 00    	mov    0x2c8(%rbx),%ecx
 101a660:	be b8 98 00 01       	mov    $0x10098b8,%esi
 101a665:	ba 01 00 00 00       	mov    $0x1,%edx
 101a66a:	4c 89 f7             	mov    %r14,%rdi
 101a66d:	e8 2e f7 00 00       	call   1029da0 <myl_rc_storage_alloc>
 101a672:	48 85 c0             	test   %rax,%rax
 101a675:	0f 84 62 07 00 00    	je     101addd <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x94d>
 101a67b:	49 bd 01 00 00 00 00 	movabs $0x5000000000000001,%r13
 101a682:	00 00 50 
 101a685:	48 89 44 24 78       	mov    %rax,0x78(%rsp)
 101a68a:	48 c7 84 24 f0 00 00 	movq   $0x1009928,0xf0(%rsp)
 101a691:	00 28 99 00 01 
 101a696:	48 8d 4c 24 78       	lea    0x78(%rsp),%rcx
 101a69b:	48 89 8c 24 f8 00 00 	mov    %rcx,0xf8(%rsp)
 101a6a2:	00 
 101a6a3:	4c 89 a4 24 00 01 00 	mov    %r12,0x100(%rsp)
 101a6aa:	00 
 101a6ab:	c7 84 24 08 01 00 00 	movl   $0x4,0x108(%rsp)
 101a6b2:	04 00 00 00 
 101a6b6:	c7 44 24 38 01 00 00 	movl   $0x1,0x38(%rsp)
 101a6bd:	00 
 101a6be:	f6 84 24 a8 00 00 00 	testb  $0x18,0xa8(%rsp)
 101a6c5:	18 
 101a6c6:	75 18                	jne    101a6e0 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x250>
 101a6c8:	8b 4c 24 20          	mov    0x20(%rsp),%ecx
 101a6cc:	83 e1 01             	and    $0x1,%ecx
 101a6cf:	74 0f                	je     101a6e0 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x250>
 101a6d1:	c5 f8 10 44 24 10    	vmovups 0x10(%rsp),%xmm0
 101a6d7:	c5 f8 11 00          	vmovups %xmm0,(%rax)
 101a6db:	e9 90 00 00 00       	jmp    101a770 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x2e0>
 101a6e0:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
 101a6e5:	48 85 c9             	test   %rcx,%rcx
 101a6e8:	74 06                	je     101a6f0 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x260>
 101a6ea:	4c 85 69 f0          	test   %r13,-0x10(%rcx)
 101a6ee:	75 10                	jne    101a700 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x270>
 101a6f0:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
 101a6f5:	48 85 c9             	test   %rcx,%rcx
 101a6f8:	74 3a                	je     101a734 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x2a4>
 101a6fa:	4c 85 69 f0          	test   %r13,-0x10(%rcx)
 101a6fe:	74 34                	je     101a734 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x2a4>
 101a700:	48 89 e2             	mov    %rsp,%rdx
 101a703:	48 8d 4c 24 10       	lea    0x10(%rsp),%rcx
 101a708:	be 08 a3 00 01       	mov    $0x100a308,%esi
 101a70d:	4c 89 f7             	mov    %r14,%rdi
 101a710:	41 89 e8             	mov    %ebp,%r8d
 101a713:	4d 89 f4             	mov    %r14,%r12
 101a716:	49 89 c6             	mov    %rax,%r14
 101a719:	e8 72 08 01 00       	call   102af90 <myl_rc_native_take>
 101a71e:	89 c1                	mov    %eax,%ecx
 101a720:	4c 89 f0             	mov    %r14,%rax
 101a723:	4d 89 e6             	mov    %r12,%r14
 101a726:	4c 8d 64 24 38       	lea    0x38(%rsp),%r12
 101a72b:	85 c9                	test   %ecx,%ecx
 101a72d:	75 19                	jne    101a748 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x2b8>
 101a72f:	e9 e3 03 00 00       	jmp    101ab17 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x687>
 101a734:	c5 f8 10 44 24 10    	vmovups 0x10(%rsp),%xmm0
 101a73a:	c5 f8 29 04 24       	vmovaps %xmm0,(%rsp)
 101a73f:	48 c7 44 24 18 00 00 	movq   $0x0,0x18(%rsp)
 101a746:	00 00 
 101a748:	48 c7 84 24 d0 00 00 	movq   $0x100a308,0xd0(%rsp)
 101a74f:	00 08 a3 00 01 
 101a754:	c7 84 24 e8 00 00 00 	movl   $0x2,0xe8(%rsp)
 101a75b:	02 00 00 00 
 101a75f:	c5 f8 28 04 24       	vmovaps (%rsp),%xmm0
 101a764:	c5 f8 11 00          	vmovups %xmm0,(%rax)
 101a768:	c7 44 24 30 00 00 00 	movl   $0x0,0x30(%rsp)
 101a76f:	00 
 101a770:	48 c7 84 24 f0 00 00 	movq   $0x1009fd8,0xf0(%rsp)
 101a777:	00 d8 9f 00 01 
 101a77c:	c7 84 24 08 01 00 00 	movl   $0x2,0x108(%rsp)
 101a783:	02 00 00 00 
 101a787:	48 8d 8c 24 10 01 00 	lea    0x110(%rsp),%rcx
 101a78e:	00 
 101a78f:	48 89 8c 24 f8 00 00 	mov    %rcx,0xf8(%rsp)
 101a796:	00 
 101a797:	4c 89 a4 24 00 01 00 	mov    %r12,0x100(%rsp)
 101a79e:	00 
 101a79f:	48 89 84 24 10 01 00 	mov    %rax,0x110(%rsp)
 101a7a6:	00 
 101a7a7:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
 101a7ac:	48 c7 84 24 90 00 00 	movq   $0x1009fd8,0x90(%rsp)
 101a7b3:	00 d8 9f 00 01 
 101a7b8:	c7 84 24 a8 00 00 00 	movl   $0x2,0xa8(%rsp)
 101a7bf:	02 00 00 00 
 101a7c3:	c7 44 24 20 01 00 00 	movl   $0x1,0x20(%rsp)
 101a7ca:	00 
 101a7cb:	c7 44 24 38 00 00 00 	movl   $0x0,0x38(%rsp)
 101a7d2:	00 
 101a7d3:	48 89 df             	mov    %rbx,%rdi
 101a7d6:	4c 89 fe             	mov    %r15,%rsi
 101a7d9:	e8 b2 fc ff ff       	call   101a490 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531>
 101a7de:	48 89 04 24          	mov    %rax,(%rsp)
 101a7e2:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
 101a7e7:	48 c7 84 24 d0 00 00 	movq   $0x100a308,0xd0(%rsp)
 101a7ee:	00 08 a3 00 01 
 101a7f3:	c7 84 24 e8 00 00 00 	movl   $0x2,0xe8(%rsp)
 101a7fa:	02 00 00 00 
 101a7fe:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
 101a803:	48 89 54 24 50       	mov    %rdx,0x50(%rsp)
 101a808:	48 c7 84 24 b0 00 00 	movq   $0x100a308,0xb0(%rsp)
 101a80f:	00 08 a3 00 01 
 101a814:	c7 84 24 c8 00 00 00 	movl   $0x2,0xc8(%rsp)
 101a81b:	02 00 00 00 
 101a81f:	c7 44 24 30 00 00 00 	movl   $0x0,0x30(%rsp)
 101a826:	00 
 101a827:	c7 44 24 28 01 00 00 	movl   $0x1,0x28(%rsp)
 101a82e:	00 
 101a82f:	48 83 bb 60 18 00 00 	cmpq   $0x0,0x1860(%rbx)
 101a836:	00 
 101a837:	0f 84 a8 05 00 00    	je     101ade5 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x955>
 101a83d:	8b 8b c8 02 00 00    	mov    0x2c8(%rbx),%ecx
 101a843:	be b8 98 00 01       	mov    $0x10098b8,%esi
 101a848:	ba 01 00 00 00       	mov    $0x1,%edx
 101a84d:	4c 89 f7             	mov    %r14,%rdi
 101a850:	e8 4b f5 00 00       	call   1029da0 <myl_rc_storage_alloc>
 101a855:	48 85 c0             	test   %rax,%rax
 101a858:	0f 84 87 05 00 00    	je     101ade5 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x955>
 101a85e:	48 89 44 24 78       	mov    %rax,0x78(%rsp)
 101a863:	48 c7 84 24 f0 00 00 	movq   $0x1009928,0xf0(%rsp)
 101a86a:	00 28 99 00 01 
 101a86f:	48 8d 4c 24 78       	lea    0x78(%rsp),%rcx
 101a874:	48 89 8c 24 f8 00 00 	mov    %rcx,0xf8(%rsp)
 101a87b:	00 
 101a87c:	4c 89 a4 24 00 01 00 	mov    %r12,0x100(%rsp)
 101a883:	00 
 101a884:	c7 84 24 08 01 00 00 	movl   $0x4,0x108(%rsp)
 101a88b:	04 00 00 00 
 101a88f:	c7 44 24 38 01 00 00 	movl   $0x1,0x38(%rsp)
 101a896:	00 
 101a897:	f6 84 24 c8 00 00 00 	testb  $0x18,0xc8(%rsp)
 101a89e:	18 
 101a89f:	75 18                	jne    101a8b9 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x429>
 101a8a1:	8b 4c 24 28          	mov    0x28(%rsp),%ecx
 101a8a5:	83 e1 01             	and    $0x1,%ecx
 101a8a8:	74 0f                	je     101a8b9 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x429>
 101a8aa:	c5 f8 10 44 24 48    	vmovups 0x48(%rsp),%xmm0
 101a8b0:	c5 f8 11 00          	vmovups %xmm0,(%rax)
 101a8b4:	e9 85 00 00 00       	jmp    101a93e <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x4ae>
 101a8b9:	48 8b 4c 24 48       	mov    0x48(%rsp),%rcx
 101a8be:	48 85 c9             	test   %rcx,%rcx
 101a8c1:	74 06                	je     101a8c9 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x439>
 101a8c3:	4c 85 69 f0          	test   %r13,-0x10(%rcx)
 101a8c7:	75 10                	jne    101a8d9 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x449>
 101a8c9:	48 8b 4c 24 50       	mov    0x50(%rsp),%rcx
 101a8ce:	48 85 c9             	test   %rcx,%rcx
 101a8d1:	74 2f                	je     101a902 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x472>
 101a8d3:	4c 85 69 f0          	test   %r13,-0x10(%rcx)
 101a8d7:	74 29                	je     101a902 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x472>
 101a8d9:	48 89 e2             	mov    %rsp,%rdx
 101a8dc:	48 8d 4c 24 48       	lea    0x48(%rsp),%rcx
 101a8e1:	be 08 a3 00 01       	mov    $0x100a308,%esi
 101a8e6:	4c 89 f7             	mov    %r14,%rdi
 101a8e9:	41 89 e8             	mov    %ebp,%r8d
 101a8ec:	49 89 c7             	mov    %rax,%r15
 101a8ef:	e8 9c 06 01 00       	call   102af90 <myl_rc_native_take>
 101a8f4:	89 c1                	mov    %eax,%ecx
 101a8f6:	4c 89 f8             	mov    %r15,%rax
 101a8f9:	85 c9                	test   %ecx,%ecx
 101a8fb:	75 19                	jne    101a916 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x486>
 101a8fd:	e9 15 02 00 00       	jmp    101ab17 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x687>
 101a902:	c5 f8 10 44 24 48    	vmovups 0x48(%rsp),%xmm0
 101a908:	c5 f8 29 04 24       	vmovaps %xmm0,(%rsp)
 101a90d:	48 c7 44 24 50 00 00 	movq   $0x0,0x50(%rsp)
 101a914:	00 00 
 101a916:	48 c7 84 24 d0 00 00 	movq   $0x100a308,0xd0(%rsp)
 101a91d:	00 08 a3 00 01 
 101a922:	c7 84 24 e8 00 00 00 	movl   $0x2,0xe8(%rsp)
 101a929:	02 00 00 00 
 101a92d:	c5 f8 28 04 24       	vmovaps (%rsp),%xmm0
 101a932:	c5 f8 11 00          	vmovups %xmm0,(%rax)
 101a936:	c7 44 24 30 00 00 00 	movl   $0x0,0x30(%rsp)
 101a93d:	00 
 101a93e:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
 101a943:	48 c7 84 24 b0 00 00 	movq   $0x1009fd8,0xb0(%rsp)
 101a94a:	00 d8 9f 00 01 
 101a94f:	c7 84 24 c8 00 00 00 	movl   $0x2,0xc8(%rsp)
 101a956:	02 00 00 00 
 101a95a:	c7 44 24 28 01 00 00 	movl   $0x1,0x28(%rsp)
 101a961:	00 
 101a962:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
 101a966:	c5 f8 29 84 24 80 00 	vmovaps %xmm0,0x80(%rsp)
 101a96d:	00 00 
 101a96f:	48 c7 84 24 f0 00 00 	movq   $0x100a308,0xf0(%rsp)
 101a976:	00 08 a3 00 01 
 101a97b:	c7 84 24 08 01 00 00 	movl   $0x2,0x108(%rsp)
 101a982:	02 00 00 00 
 101a986:	48 8d 8c 24 80 00 00 	lea    0x80(%rsp),%rcx
 101a98d:	00 
 101a98e:	48 89 8c 24 f8 00 00 	mov    %rcx,0xf8(%rsp)
 101a995:	00 
 101a996:	4c 89 a4 24 00 01 00 	mov    %r12,0x100(%rsp)
 101a99d:	00 
 101a99e:	c7 44 24 38 01 00 00 	movl   $0x1,0x38(%rsp)
 101a9a5:	00 
 101a9a6:	f6 84 24 a8 00 00 00 	testb  $0x18,0xa8(%rsp)
 101a9ad:	18 
 101a9ae:	75 1b                	jne    101a9cb <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x53b>
 101a9b0:	8b 4c 24 20          	mov    0x20(%rsp),%ecx
 101a9b4:	83 e1 01             	and    $0x1,%ecx
 101a9b7:	74 12                	je     101a9cb <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x53b>
 101a9b9:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
 101a9be:	48 89 8c 24 80 00 00 	mov    %rcx,0x80(%rsp)
 101a9c5:	00 
 101a9c6:	e9 8a 00 00 00       	jmp    101aa55 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x5c5>
 101a9cb:	48 89 e2             	mov    %rsp,%rdx
 101a9ce:	48 8d 4c 24 10       	lea    0x10(%rsp),%rcx
 101a9d3:	be d8 9f 00 01       	mov    $0x1009fd8,%esi
 101a9d8:	4c 89 f7             	mov    %r14,%rdi
 101a9db:	41 89 e8             	mov    %ebp,%r8d
 101a9de:	e8 1d 0b 01 00       	call   102b500 <myl_rc_native_retain>
 101a9e3:	85 c0                	test   %eax,%eax
 101a9e5:	0f 84 2c 01 00 00    	je     101ab17 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x687>
 101a9eb:	48 c7 84 24 d0 00 00 	movq   $0x1009fd8,0xd0(%rsp)
 101a9f2:	00 d8 9f 00 01 
 101a9f7:	c7 84 24 e8 00 00 00 	movl   $0x2,0xe8(%rsp)
 101a9fe:	02 00 00 00 
 101aa02:	c7 44 24 30 01 00 00 	movl   $0x1,0x30(%rsp)
 101aa09:	00 
 101aa0a:	83 7c 24 20 00       	cmpl   $0x0,0x20(%rsp)
 101aa0f:	74 10                	je     101aa21 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x591>
 101aa11:	48 8d b4 24 90 00 00 	lea    0x90(%rsp),%rsi
 101aa18:	00 
 101aa19:	48 89 df             	mov    %rbx,%rdi
 101aa1c:	e8 4f 28 00 00       	call   101d270 <myl_qbe_rc_slot_drop>
 101aa21:	48 8b 04 24          	mov    (%rsp),%rax
 101aa25:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
 101aa2c:	00 
 101aa2d:	c7 44 24 30 00 00 00 	movl   $0x0,0x30(%rsp)
 101aa34:	00 
 101aa35:	f6 84 24 c8 00 00 00 	testb  $0x18,0xc8(%rsp)
 101aa3c:	18 
 101aa3d:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
 101aa42:	0f 85 ea 02 00 00    	jne    101ad32 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x8a2>
 101aa48:	8b 4c 24 28          	mov    0x28(%rsp),%ecx
 101aa4c:	83 e1 01             	and    $0x1,%ecx
 101aa4f:	0f 84 dd 02 00 00    	je     101ad32 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x8a2>
 101aa55:	48 89 84 24 88 00 00 	mov    %rax,0x88(%rsp)
 101aa5c:	00 
 101aa5d:	c7 44 24 28 00 00 00 	movl   $0x0,0x28(%rsp)
 101aa64:	00 
 101aa65:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
 101aa6c:	00 
 101aa6d:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
 101aa72:	48 8b 84 24 88 00 00 	mov    0x88(%rsp),%rax
 101aa79:	00 
 101aa7a:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
 101aa7f:	48 c7 84 24 90 00 00 	movq   $0x100a308,0x90(%rsp)
 101aa86:	00 08 a3 00 01 
 101aa8b:	c7 84 24 a8 00 00 00 	movl   $0x2,0xa8(%rsp)
 101aa92:	02 00 00 00 
 101aa96:	c7 44 24 20 01 00 00 	movl   $0x1,0x20(%rsp)
 101aa9d:	00 
 101aa9e:	c7 44 24 38 00 00 00 	movl   $0x0,0x38(%rsp)
 101aaa5:	00 
 101aaa6:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
 101aaab:	48 85 c0             	test   %rax,%rax
 101aaae:	74 06                	je     101aab6 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x626>
 101aab0:	4c 85 68 f0          	test   %r13,-0x10(%rax)
 101aab4:	75 18                	jne    101aace <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x63e>
 101aab6:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
 101aabb:	48 85 c0             	test   %rax,%rax
 101aabe:	0f 84 9b 00 00 00    	je     101ab5f <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x6cf>
 101aac4:	4c 85 68 f0          	test   %r13,-0x10(%rax)
 101aac8:	0f 84 91 00 00 00    	je     101ab5f <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x6cf>
 101aace:	48 89 e2             	mov    %rsp,%rdx
 101aad1:	48 8d 4c 24 10       	lea    0x10(%rsp),%rcx
 101aad6:	be 08 a3 00 01       	mov    $0x100a308,%esi
 101aadb:	4c 89 f7             	mov    %r14,%rdi
 101aade:	41 89 e8             	mov    %ebp,%r8d
 101aae1:	e8 aa 04 01 00       	call   102af90 <myl_rc_native_take>
 101aae6:	85 c0                	test   %eax,%eax
 101aae8:	0f 85 89 00 00 00    	jne    101ab77 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x6e7>
 101aaee:	48 8b 8b 60 18 00 00 	mov    0x1860(%rbx),%rcx
 101aaf5:	48 85 c9             	test   %rcx,%rcx
 101aaf8:	4c 8d 64 24 58       	lea    0x58(%rsp),%r12
 101aafd:	0f 84 cd 02 00 00    	je     101add0 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x940>
 101ab03:	8b 41 78             	mov    0x78(%rcx),%eax
 101ab06:	c7 41 78 00 00 00 00 	movl   $0x0,0x78(%rcx)
 101ab0d:	48 85 c0             	test   %rax,%rax
 101ab10:	75 2d                	jne    101ab3f <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x6af>
 101ab12:	e9 5c 01 00 00       	jmp    101ac73 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x7e3>
 101ab17:	48 8b 8b 60 18 00 00 	mov    0x1860(%rbx),%rcx
 101ab1e:	48 85 c9             	test   %rcx,%rcx
 101ab21:	0f 84 a9 02 00 00    	je     101add0 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x940>
 101ab27:	8b 41 78             	mov    0x78(%rcx),%eax
 101ab2a:	c7 41 78 00 00 00 00 	movl   $0x0,0x78(%rcx)
 101ab31:	48 85 c0             	test   %rax,%rax
 101ab34:	4c 8d 64 24 58       	lea    0x58(%rsp),%r12
 101ab39:	0f 84 34 01 00 00    	je     101ac73 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x7e3>
 101ab3f:	83 f8 01             	cmp    $0x1,%eax
 101ab42:	0f 85 12 01 00 00    	jne    101ac5a <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x7ca>
 101ab48:	be 60 74 00 01       	mov    $0x1007460,%esi
 101ab4d:	83 bb c4 02 00 00 00 	cmpl   $0x0,0x2c4(%rbx)
 101ab54:	0f 85 11 01 00 00    	jne    101ac6b <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x7db>
 101ab5a:	e9 04 01 00 00       	jmp    101ac63 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x7d3>
 101ab5f:	c5 f8 28 84 24 80 00 	vmovaps 0x80(%rsp),%xmm0
 101ab66:	00 00 
 101ab68:	c5 f8 29 04 24       	vmovaps %xmm0,(%rsp)
 101ab6d:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
 101ab71:	c5 f8 29 44 24 10    	vmovaps %xmm0,0x10(%rsp)
 101ab77:	c7 44 24 20 00 00 00 	movl   $0x0,0x20(%rsp)
 101ab7e:	00 
 101ab7f:	48 c7 84 24 d0 00 00 	movq   $0x100a308,0xd0(%rsp)
 101ab86:	00 08 a3 00 01 
 101ab8b:	c7 84 24 e8 00 00 00 	movl   $0x2,0xe8(%rsp)
 101ab92:	02 00 00 00 
 101ab96:	c7 44 24 30 00 00 00 	movl   $0x0,0x30(%rsp)
 101ab9d:	00 
 101ab9e:	4c 8d 64 24 58       	lea    0x58(%rsp),%r12
 101aba3:	4c 39 a3 80 3d 00 00 	cmp    %r12,0x3d80(%rbx)
 101abaa:	0f 85 20 02 00 00    	jne    101add0 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x940>
 101abb0:	48 8b 74 24 70       	mov    0x70(%rsp),%rsi
 101abb5:	4c 89 f7             	mov    %r14,%rdi
 101abb8:	e8 43 cf 00 00       	call   1027b00 <myl_rc_scope_unwind>
 101abbd:	4c 8b 74 24 68       	mov    0x68(%rsp),%r14
 101abc2:	4d 85 f6             	test   %r14,%r14
 101abc5:	74 43                	je     101ac0a <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x77a>
 101abc7:	4d 89 f7             	mov    %r14,%r15
 101abca:	49 c1 e7 05          	shl    $0x5,%r15
 101abce:	49 83 c7 e0          	add    $0xffffffffffffffe0,%r15
 101abd2:	eb 20                	jmp    101abf4 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x764>
 101abd4:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
 101abdb:	00 00 00 00 00 
 101abe0:	4c 01 fe             	add    %r15,%rsi
 101abe3:	48 89 df             	mov    %rbx,%rdi
 101abe6:	e8 85 26 00 00       	call   101d270 <myl_qbe_rc_slot_drop>
 101abeb:	49 83 c7 e0          	add    $0xffffffffffffffe0,%r15
 101abef:	49 ff ce             	dec    %r14
 101abf2:	74 16                	je     101ac0a <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x77a>
 101abf4:	48 8b 74 24 60       	mov    0x60(%rsp),%rsi
 101abf9:	4a 8b 44 3e 10       	mov    0x10(%rsi,%r15,1),%rax
 101abfe:	48 85 c0             	test   %rax,%rax
 101ac01:	74 dd                	je     101abe0 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x750>
 101ac03:	83 38 00             	cmpl   $0x0,(%rax)
 101ac06:	75 d8                	jne    101abe0 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x750>
 101ac08:	eb e1                	jmp    101abeb <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x75b>
 101ac0a:	4c 39 a3 80 3d 00 00 	cmp    %r12,0x3d80(%rbx)
 101ac11:	0f 85 b9 01 00 00    	jne    101add0 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x940>
 101ac17:	48 8b 83 60 18 00 00 	mov    0x1860(%rbx),%rax
 101ac1e:	48 85 c0             	test   %rax,%rax
 101ac21:	74 10                	je     101ac33 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x7a3>
 101ac23:	48 8b 40 70          	mov    0x70(%rax),%rax
 101ac27:	48 3b 44 24 70       	cmp    0x70(%rsp),%rax
 101ac2c:	74 12                	je     101ac40 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x7b0>
 101ac2e:	e9 9d 01 00 00       	jmp    101add0 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x940>
 101ac33:	31 c0                	xor    %eax,%eax
 101ac35:	48 3b 44 24 70       	cmp    0x70(%rsp),%rax
 101ac3a:	0f 85 90 01 00 00    	jne    101add0 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x940>
 101ac40:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
 101ac45:	48 89 83 80 3d 00 00 	mov    %rax,0x3d80(%rbx)
 101ac4c:	48 8b 04 24          	mov    (%rsp),%rax
 101ac50:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
 101ac55:	e9 c6 00 00 00       	jmp    101ad20 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x890>
 101ac5a:	83 f8 04             	cmp    $0x4,%eax
 101ac5d:	0f 83 75 01 00 00    	jae    101add8 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x948>
 101ac63:	48 8b 34 c5 70 d4 00 	mov    0x100d470(,%rax,8),%rsi
 101ac6a:	01 
 101ac6b:	48 89 df             	mov    %rbx,%rdi
 101ac6e:	e8 8d 31 00 00       	call   101de00 <fail>
 101ac73:	4c 39 a3 80 3d 00 00 	cmp    %r12,0x3d80(%rbx)
 101ac7a:	0f 85 50 01 00 00    	jne    101add0 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x940>
 101ac80:	48 8b 74 24 70       	mov    0x70(%rsp),%rsi
 101ac85:	4c 89 f7             	mov    %r14,%rdi
 101ac88:	e8 73 ce 00 00       	call   1027b00 <myl_rc_scope_unwind>
 101ac8d:	4c 8b 74 24 68       	mov    0x68(%rsp),%r14
 101ac92:	4d 85 f6             	test   %r14,%r14
 101ac95:	74 43                	je     101acda <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x84a>
 101ac97:	4d 89 f7             	mov    %r14,%r15
 101ac9a:	49 c1 e7 05          	shl    $0x5,%r15
 101ac9e:	49 83 c7 e0          	add    $0xffffffffffffffe0,%r15
 101aca2:	eb 20                	jmp    101acc4 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x834>
 101aca4:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
 101acab:	00 00 00 00 00 
 101acb0:	4c 01 fe             	add    %r15,%rsi
 101acb3:	48 89 df             	mov    %rbx,%rdi
 101acb6:	e8 b5 25 00 00       	call   101d270 <myl_qbe_rc_slot_drop>
 101acbb:	49 83 c7 e0          	add    $0xffffffffffffffe0,%r15
 101acbf:	49 ff ce             	dec    %r14
 101acc2:	74 16                	je     101acda <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x84a>
 101acc4:	48 8b 74 24 60       	mov    0x60(%rsp),%rsi
 101acc9:	4a 8b 44 3e 10       	mov    0x10(%rsi,%r15,1),%rax
 101acce:	48 85 c0             	test   %rax,%rax
 101acd1:	74 dd                	je     101acb0 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x820>
 101acd3:	83 38 00             	cmpl   $0x0,(%rax)
 101acd6:	75 d8                	jne    101acb0 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x820>
 101acd8:	eb e1                	jmp    101acbb <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x82b>
 101acda:	4c 39 a3 80 3d 00 00 	cmp    %r12,0x3d80(%rbx)
 101ace1:	0f 85 e9 00 00 00    	jne    101add0 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x940>
 101ace7:	48 8b 83 60 18 00 00 	mov    0x1860(%rbx),%rax
 101acee:	48 85 c0             	test   %rax,%rax
 101acf1:	74 10                	je     101ad03 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x873>
 101acf3:	48 8b 40 70          	mov    0x70(%rax),%rax
 101acf7:	48 3b 44 24 70       	cmp    0x70(%rsp),%rax
 101acfc:	74 12                	je     101ad10 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x880>
 101acfe:	e9 cd 00 00 00       	jmp    101add0 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x940>
 101ad03:	31 c0                	xor    %eax,%eax
 101ad05:	48 3b 44 24 70       	cmp    0x70(%rsp),%rax
 101ad0a:	0f 85 c0 00 00 00    	jne    101add0 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x940>
 101ad10:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
 101ad15:	48 89 83 80 3d 00 00 	mov    %rax,0x3d80(%rbx)
 101ad1c:	31 c0                	xor    %eax,%eax
 101ad1e:	31 d2                	xor    %edx,%edx
 101ad20:	48 81 c4 18 01 00 00 	add    $0x118,%rsp
 101ad27:	5b                   	pop    %rbx
 101ad28:	41 5c                	pop    %r12
 101ad2a:	41 5d                	pop    %r13
 101ad2c:	41 5e                	pop    %r14
 101ad2e:	41 5f                	pop    %r15
 101ad30:	5d                   	pop    %rbp
 101ad31:	c3                   	ret
 101ad32:	48 85 c0             	test   %rax,%rax
 101ad35:	74 28                	je     101ad5f <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x8cf>
 101ad37:	4c 85 68 f0          	test   %r13,-0x10(%rax)
 101ad3b:	74 22                	je     101ad5f <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x8cf>
 101ad3d:	48 89 e2             	mov    %rsp,%rdx
 101ad40:	48 8d 4c 24 48       	lea    0x48(%rsp),%rcx
 101ad45:	be d8 9f 00 01       	mov    $0x1009fd8,%esi
 101ad4a:	4c 89 f7             	mov    %r14,%rdi
 101ad4d:	41 89 e8             	mov    %ebp,%r8d
 101ad50:	e8 3b 02 01 00       	call   102af90 <myl_rc_native_take>
 101ad55:	85 c0                	test   %eax,%eax
 101ad57:	74 47                	je     101ada0 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x910>
 101ad59:	48 8b 04 24          	mov    (%rsp),%rax
 101ad5d:	eb 0d                	jmp    101ad6c <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x8dc>
 101ad5f:	48 89 04 24          	mov    %rax,(%rsp)
 101ad63:	48 c7 44 24 48 00 00 	movq   $0x0,0x48(%rsp)
 101ad6a:	00 00 
 101ad6c:	c7 44 24 28 00 00 00 	movl   $0x0,0x28(%rsp)
 101ad73:	00 
 101ad74:	48 c7 84 24 d0 00 00 	movq   $0x1009fd8,0xd0(%rsp)
 101ad7b:	00 d8 9f 00 01 
 101ad80:	c7 84 24 e8 00 00 00 	movl   $0x2,0xe8(%rsp)
 101ad87:	02 00 00 00 
 101ad8b:	48 89 84 24 88 00 00 	mov    %rax,0x88(%rsp)
 101ad92:	00 
 101ad93:	c7 44 24 30 00 00 00 	movl   $0x0,0x30(%rsp)
 101ad9a:	00 
 101ad9b:	e9 c5 fc ff ff       	jmp    101aa65 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x5d5>
 101ada0:	48 8b 83 60 18 00 00 	mov    0x1860(%rbx),%rax
 101ada7:	48 85 c0             	test   %rax,%rax
 101adaa:	74 24                	je     101add0 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x940>
 101adac:	8b 70 78             	mov    0x78(%rax),%esi
 101adaf:	c7 40 78 00 00 00 00 	movl   $0x0,0x78(%rax)
 101adb6:	48 89 df             	mov    %rbx,%rdi
 101adb9:	e8 22 24 00 00       	call   101d1e0 <myl_qbe_rc_status>
 101adbe:	4c 8d 64 24 58       	lea    0x58(%rsp),%r12
 101adc3:	4c 39 a3 80 3d 00 00 	cmp    %r12,0x3d80(%rbx)
 101adca:	0f 84 b0 fe ff ff    	je     101ac80 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x7f0>
 101add0:	c5 f8 77             	vzeroupper
 101add3:	e8 19 89 00 00       	call   10236f1 <myl_rc_invariant_failed>
 101add8:	e8 83 3f 01 00       	call   102ed60 <abort@plt>
 101addd:	48 89 df             	mov    %rbx,%rdi
 101ade0:	e8 cb 36 00 00       	call   101e4b0 <myl_qbe_fail_allocation>
 101ade5:	48 89 df             	mov    %rbx,%rdi
 101ade8:	e8 c3 36 00 00       	call   101e4b0 <myl_qbe_fail_allocation>
 101aded:	48 89 df             	mov    %rbx,%rdi
 101adf0:	e8 bb 37 00 00       	call   101e5b0 <myl_qbe_fail_frame>
 101adf5:	48 ba 00 00 00 00 00 	movabs $0x8000000000000000,%rdx
 101adfc:	00 00 80 
 101adff:	be 01 00 00 00       	mov    $0x1,%esi
 101ae04:	b9 01 00 00 00       	mov    $0x1,%ecx
 101ae09:	48 89 df             	mov    %rbx,%rdi
 101ae0c:	c5 f8 77             	vzeroupper
 101ae0f:	e8 2c 37 00 00       	call   101e540 <myl_qbe_fail_overflow_op>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
