import hashlib,json,pathlib,subprocess
r=pathlib.Path.cwd();w=r/'.tmp-rc/empty-locals';c=r/'.tmp-rc/install-empty-locals/bin/mylang';rows=[]
for backend,name in [(b,n) for b in ['qbe','llvm'] for n in ['rc_inert_receivers','rc_read_loans','iteration_identity','rc_plain_aggregates']]:
 cmd=[str(c),'run',str(r/'tests/lang'/f'{name}.my'),'--cache-dir='+str(w/'test-cache'),'--rc-runtime=stats']
 if backend=='llvm':cmd+=['--release']
 p=subprocess.run(cmd,text=True,capture_output=True);row=dict(backend=backend,name=name,command=cmd,status=p.returncode,stdout=p.stdout,stderr=p.stderr);rows.append(row);(w/'standalone.json').write_text(json.dumps(rows,indent=2)+'\n');assert p.returncode==0,row
 counts=json.loads(next(line.removeprefix('MYLANG_RC_COUNTS ') for line in p.stderr.splitlines() if line.startswith('MYLANG_RC_COUNTS ')));assert counts['heap_allocate']==counts['retire'] and counts['owner_release']==counts['owner_acquire']+counts['heap_allocate'] and counts['hold_acquire']==counts['hold_release'],counts;print(backend,counts,flush=True)
