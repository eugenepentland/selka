
.mylang-cache/goal110-int-parse/runner/bin/text-my-llvm:     file format elf64-x86-64


Disassembly of section .text:

000000000104a0e0 <myl_native_bytes_number_parse>:
 104a0e0:	push   %rbp
 104a0e1:	mov    %rsp,%rbp
 104a0e4:	push   %r14
 104a0e6:	push   %rbx
 104a0e7:	mov    %rdi,%rax
 104a0ea:	test   %rdi,%rdi
 104a0ed:	mov    $0x1,%edi
 104a0f2:	cmovne %rax,%rdi
 104a0f6:	cmovne %rsi,%rax
 104a0fa:	test   %edx,%edx
 104a0fc:	je     104a10d <myl_native_bytes_number_parse+0x2d>
 104a0fe:	mov    %rax,%rsi
 104a101:	mov    %rcx,%rdx
 104a104:	pop    %rbx
 104a105:	pop    %r14
 104a107:	pop    %rbp
 104a108:	jmp    104b160 <myl_native_number_parse+0xee0>
 104a10d:	xor    %r8d,%r8d
 104a110:	test   %rax,%rax
 104a113:	je     104a150 <myl_native_bytes_number_parse+0x70>
 104a115:	vmovdqa -0x4876d(%rip),%xmm0        # 10019b0 <__abi_tag+0x16b4>
 104a11d:	jmp    104a128 <myl_native_bytes_number_parse+0x48>
 104a11f:	nop
 104a120:	inc    %r8
 104a123:	cmp    %r8,%rax
 104a126:	je     104a14d <myl_native_bytes_number_parse+0x6d>
 104a128:	movzbl (%rdi,%r8,1),%edx
 104a12d:	vmovd  %edx,%xmm1
 104a131:	vpbroadcastd %xmm1,%xmm1
 104a136:	vpcmpeqd %xmm0,%xmm1,%xmm1
 104a13a:	vmovmskps %xmm1,%r9d
 104a13e:	test   %r9d,%r9d
 104a141:	jne    104a120 <myl_native_bytes_number_parse+0x40>
 104a143:	add    $0xf5,%dl
 104a146:	cmp    $0x1,%dl
 104a149:	jbe    104a120 <myl_native_bytes_number_parse+0x40>
 104a14b:	jmp    104a150 <myl_native_bytes_number_parse+0x70>
 104a14d:	mov    %rsi,%r8
 104a150:	cmp    %rax,%r8
 104a153:	mov    %rax,%rdx
 104a156:	cmovb  %r8,%rdx
 104a15a:	vmovdqa -0x487b2(%rip),%xmm0        # 10019b0 <__abi_tag+0x16b4>
 104a162:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 104a170:	cmp    %r8,%rax
 104a173:	jbe    104a1a3 <myl_native_bytes_number_parse+0xc3>
 104a175:	movzbl -0x1(%rdi,%rax,1),%esi
 104a17a:	dec    %rax
 104a17d:	vmovd  %esi,%xmm1
 104a181:	vpbroadcastd %xmm1,%xmm1
 104a186:	vpcmpeqd %xmm0,%xmm1,%xmm1
 104a18a:	vmovmskps %xmm1,%r9d
 104a18e:	test   %r9d,%r9d
 104a191:	jne    104a170 <myl_native_bytes_number_parse+0x90>
 104a193:	add    $0xf5,%sil
 104a197:	cmp    $0x2,%sil
 104a19b:	jb     104a170 <myl_native_bytes_number_parse+0x90>
 104a19d:	inc    %rax
 104a1a0:	mov    %rax,%rdx
 104a1a3:	sub    %r8,%rdx
 104a1a6:	je     104a1c9 <myl_native_bytes_number_parse+0xe9>
 104a1a8:	add    %r8,%rdi
 104a1ab:	movzbl (%rdi),%eax
 104a1ae:	cmp    $0x2d,%eax
 104a1b1:	je     104a1b8 <myl_native_bytes_number_parse+0xd8>
 104a1b3:	cmp    $0x2b,%eax
 104a1b6:	jne    104a1d0 <myl_native_bytes_number_parse+0xf0>
 104a1b8:	cmp    $0x2d,%al
 104a1ba:	sete   %sil
 104a1be:	mov    $0x1,%r9d
 104a1c4:	cmp    %rdx,%r9
 104a1c7:	jne    104a1da <myl_native_bytes_number_parse+0xfa>
 104a1c9:	xor    %eax,%eax
 104a1cb:	pop    %rbx
 104a1cc:	pop    %r14
 104a1ce:	pop    %rbp
 104a1cf:	ret
 104a1d0:	xor    %r9d,%r9d
 104a1d3:	xor    %esi,%esi
 104a1d5:	cmp    %rdx,%r9
 104a1d8:	je     104a1c9 <myl_native_bytes_number_parse+0xe9>
 104a1da:	jae    104a249 <myl_native_bytes_number_parse+0x169>
 104a1dc:	movabs $0xccccccccccccccc,%r10
 104a1e6:	movzbl %sil,%r11d
 104a1ea:	add    $0x7,%r11
 104a1ee:	xor    %eax,%eax
 104a1f0:	xor    %r8d,%r8d
 104a1f3:	jmp    104a210 <myl_native_bytes_number_parse+0x130>
 104a1f5:	data16 cs nopw 0x0(%rax,%rax,1)
 104a200:	lea    (%r8,%r8,4),%r8
 104a204:	lea    (%rbx,%r8,2),%r8
 104a208:	mov    %r14,%r9
 104a20b:	cmp    %rdx,%r14
 104a20e:	jae    104a256 <myl_native_bytes_number_parse+0x176>
 104a210:	movzbl (%rdi,%r9,1),%ebx
 104a215:	add    $0xffffffd0,%ebx
 104a218:	cmp    $0x9,%ebx
 104a21b:	ja     104a1cb <myl_native_bytes_number_parse+0xeb>
 104a21d:	cmp    %r10,%r8
 104a220:	ja     104a1cb <myl_native_bytes_number_parse+0xeb>
 104a222:	mov    %ebx,%ebx
 104a224:	jne    104a22b <myl_native_bytes_number_parse+0x14b>
 104a226:	cmp    %ebx,%r11d
 104a229:	jb     104a1cb <myl_native_bytes_number_parse+0xeb>
 104a22b:	lea    0x1(%r9),%r14
 104a22f:	cmp    %rdx,%r14
 104a232:	jae    104a200 <myl_native_bytes_number_parse+0x120>
 104a234:	cmpb   $0x5f,(%rdi,%r14,1)
 104a239:	jne    104a200 <myl_native_bytes_number_parse+0x120>
 104a23b:	add    $0x2,%r9
 104a23f:	mov    %r9,%r14
 104a242:	cmp    %rdx,%r9
 104a245:	jne    104a200 <myl_native_bytes_number_parse+0x120>
 104a247:	jmp    104a1cb <myl_native_bytes_number_parse+0xeb>
 104a249:	xor    %r8d,%r8d
 104a24c:	test   %sil,%sil
 104a24f:	je     104a26d <myl_native_bytes_number_parse+0x18d>
 104a251:	neg    %r8
 104a254:	jmp    104a26d <myl_native_bytes_number_parse+0x18d>
 104a256:	test   %sil,%sil
 104a259:	je     104a26d <myl_native_bytes_number_parse+0x18d>
 104a25b:	mov    %r8,%rax
 104a25e:	neg    %rax
 104a261:	jno    104a251 <myl_native_bytes_number_parse+0x171>
 104a263:	movabs $0x8000000000000000,%r8
 104a26d:	mov    %r8,(%rcx)
 104a270:	mov    $0x1,%eax
 104a275:	pop    %rbx
 104a276:	pop    %r14
 104a278:	pop    %rbp
 104a279:	ret

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
