
/home/epentland/ai/canopy/mylang-worktrees/goal110-text-rf-host-20261004/.mylang-cache/goal110-join/join-runner/bin/text-my-llvm:     file format elf64-x86-64


Disassembly of section .text:

000000000108f6a0 <index_walk>:
 108f6a0:	push   %rbp
 108f6a1:	mov    %rsp,%rbp
 108f6a4:	push   %r15
 108f6a6:	push   %r14
 108f6a8:	push   %rbx
 108f6a9:	push   %rax
 108f6aa:	mov    0x8(%rdi),%rdx
 108f6ae:	mov    %rdx,%rax
 108f6b1:	sub    %rsi,%rax
 108f6b4:	jbe    108f71a <index_walk+0x7a>
 108f6b6:	mov    0x10(%rdi),%r9d
 108f6ba:	lea    0x18(%rdi),%r8
 108f6be:	mov    %r8,%rcx
 108f6c1:	test   $0x4,%r9b
 108f6c5:	je     108f6d6 <index_walk+0x36>
 108f6c7:	mov    0x18(%rdi),%rcx
 108f6cb:	mov    0x14(%rdi),%r10d
 108f6cf:	add    %r10,%rcx
 108f6d2:	add    $0x18,%rcx
 108f6d6:	cmp    %rax,%rsi
 108f6d9:	mov    %rax,%r10
 108f6dc:	cmovb  %rsi,%r10
 108f6e0:	cmp    $0x401,%r10
 108f6e7:	jb     108f707 <index_walk+0x67>
 108f6e9:	test   $0x8,%r9b
 108f6ed:	jne    108f735 <index_walk+0x95>
 108f6ef:	test   $0x4,%r9b
 108f6f3:	je     108f707 <index_walk+0x67>
 108f6f5:	mov    (%r8),%rbx
 108f6f8:	test   %rbx,%rbx
 108f6fb:	je     108f707 <index_walk+0x67>
 108f6fd:	testb  $0x8,0x10(%rbx)
 108f701:	jne    108fcd7 <index_walk+0x637>
 108f707:	cmp    %rax,%rsi
 108f70a:	jbe    108f722 <index_walk+0x82>
 108f70c:	lea    0x8(%rsi),%rax
 108f710:	cmp    %rdx,%rax
 108f713:	jbe    108f744 <index_walk+0xa4>
 108f715:	xor    %r8d,%r8d
 108f718:	jmp    108f796 <index_walk+0xf6>
 108f71a:	mov    (%rdi),%rax
 108f71d:	jmp    108fd00 <index_walk+0x660>
 108f722:	cmp    $0x8,%rsi
 108f726:	jae    108f7c1 <index_walk+0x121>
 108f72c:	xor    %eax,%eax
 108f72e:	xor    %edx,%edx
 108f730:	jmp    108f9e9 <index_walk+0x349>
 108f735:	add    $0x8,%rsp
 108f739:	pop    %rbx
 108f73a:	pop    %r14
 108f73c:	pop    %r15
 108f73e:	pop    %rbp
 108f73f:	jmp    108fd20 <index_at>
 108f744:	movabs $0x101010101010101,%rax
 108f74e:	xor    %r8d,%r8d
 108f751:	mov    %rsi,%r9
 108f754:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 108f760:	mov    (%rcx,%r9,1),%rsi
 108f764:	mov    %rsi,%r10
 108f767:	not    %r10
 108f76a:	add    %r10,%r10
 108f76d:	and    %rsi,%r10
 108f770:	shr    $0x7,%r10
 108f774:	and    %rax,%r10
 108f777:	imul   %rax,%r10
 108f77b:	shr    $0x38,%r10
 108f77f:	sub    %r10,%r8
 108f782:	add    $0x8,%r8
 108f786:	lea    0x8(%r9),%rsi
 108f78a:	add    $0x10,%r9
 108f78e:	cmp    %rdx,%r9
 108f791:	mov    %rsi,%r9
 108f794:	jbe    108f760 <index_walk+0xc0>
 108f796:	mov    (%rdi),%rax
 108f799:	mov    %rdx,%rdi
 108f79c:	sub    %rsi,%rdi
 108f79f:	jbe    108fb65 <index_walk+0x4c5>
 108f7a5:	cmp    $0x3,%rdi
 108f7a9:	jbe    108fb50 <index_walk+0x4b0>
 108f7af:	cmp    $0x10,%rdi
 108f7b3:	jae    108fa11 <index_walk+0x371>
 108f7b9:	xor    %r9d,%r9d
 108f7bc:	jmp    108faef <index_walk+0x44f>
 108f7c1:	lea    -0x8(%rsi),%r8
 108f7c5:	cmp    $0x78,%r8
 108f7c9:	jae    108f7d9 <index_walk+0x139>
 108f7cb:	mov    $0x8,%edi
 108f7d0:	xor    %edx,%edx
 108f7d2:	xor    %eax,%eax
 108f7d4:	jmp    108f9a1 <index_walk+0x301>
 108f7d9:	shr    $0x3,%r8
 108f7dd:	inc    %r8
 108f7e0:	mov    %r8,%r9
 108f7e3:	and    $0xfffffffffffffff0,%r9
 108f7e7:	lea    0x0(,%r9,8),%rdx
 108f7ef:	lea    0x8(,%r9,8),%rdi
 108f7f7:	vpxor  %xmm2,%xmm2,%xmm2
 108f7fb:	xor    %eax,%eax
 108f7fd:	vpbroadcastq -0x886c6(%rip),%ymm0        # 1007140 <__abi_tag+0x6e44>
 108f806:	vpbroadcastq -0x886c7(%rip),%ymm1        # 1007148 <__abi_tag+0x6e4c>
 108f80f:	vpbroadcastq -0x88748(%rip),%ymm3        # 10070d0 <__abi_tag+0x6dd4>
 108f818:	vpcmpeqd %ymm4,%ymm4,%ymm4
 108f81c:	vpxor  %xmm7,%xmm7,%xmm7
 108f820:	vpxor  %xmm6,%xmm6,%xmm6
 108f824:	vpxor  %xmm5,%xmm5,%xmm5
 108f828:	nopl   0x0(%rax,%rax,1)
 108f830:	vmovdqu (%rcx,%rax,8),%ymm8
 108f835:	vmovdqu 0x20(%rcx,%rax,8),%ymm9
 108f83b:	vmovdqu 0x40(%rcx,%rax,8),%ymm10
 108f841:	vmovdqu 0x60(%rcx,%rax,8),%ymm11
 108f847:	vpxor  %ymm4,%ymm8,%ymm12
 108f84b:	vpaddq %ymm12,%ymm12,%ymm12
 108f850:	vpxor  %ymm4,%ymm9,%ymm13
 108f854:	vpaddq %ymm13,%ymm13,%ymm13
 108f859:	vpxor  %ymm4,%ymm10,%ymm14
 108f85d:	vpaddq %ymm14,%ymm14,%ymm14
 108f862:	vpxor  %ymm4,%ymm11,%ymm15
 108f866:	vpaddq %ymm15,%ymm15,%ymm15
 108f86b:	vpand  %ymm12,%ymm8,%ymm8
 108f870:	vpand  %ymm13,%ymm9,%ymm9
 108f875:	vpand  %ymm14,%ymm10,%ymm10
 108f87a:	vpand  %ymm15,%ymm11,%ymm11
 108f87f:	vpsrlq $0x7,%ymm8,%ymm8
 108f885:	vpsrlq $0x7,%ymm9,%ymm9
 108f88b:	vpsrlq $0x7,%ymm10,%ymm10
 108f891:	vpsrlq $0x7,%ymm11,%ymm11
 108f897:	vpand  %ymm0,%ymm8,%ymm8
 108f89b:	vpand  %ymm0,%ymm9,%ymm9
 108f89f:	vpand  %ymm0,%ymm10,%ymm10
 108f8a3:	vpand  %ymm0,%ymm11,%ymm11
 108f8a7:	vpmuludq %ymm1,%ymm8,%ymm12
 108f8ab:	vpsrlq $0x20,%ymm8,%ymm13
 108f8b1:	vpmuludq %ymm0,%ymm13,%ymm13
 108f8b5:	vpaddq %ymm13,%ymm12,%ymm12
 108f8ba:	vpsllq $0x20,%ymm12,%ymm12
 108f8c0:	vpmuludq %ymm0,%ymm8,%ymm8
 108f8c4:	vpaddq %ymm12,%ymm8,%ymm8
 108f8c9:	vpmuludq %ymm1,%ymm9,%ymm12
 108f8cd:	vpsrlq $0x20,%ymm9,%ymm13
 108f8d3:	vpmuludq %ymm0,%ymm13,%ymm13
 108f8d7:	vpaddq %ymm13,%ymm12,%ymm12
 108f8dc:	vpsllq $0x20,%ymm12,%ymm12
 108f8e2:	vpmuludq %ymm0,%ymm9,%ymm9
 108f8e6:	vpaddq %ymm12,%ymm9,%ymm9
 108f8eb:	vpmuludq %ymm1,%ymm10,%ymm12
 108f8ef:	vpsrlq $0x20,%ymm10,%ymm13
 108f8f5:	vpmuludq %ymm0,%ymm13,%ymm13
 108f8f9:	vpaddq %ymm13,%ymm12,%ymm12
 108f8fe:	vpsllq $0x20,%ymm12,%ymm12
 108f904:	vpmuludq %ymm0,%ymm10,%ymm10
 108f908:	vpaddq %ymm12,%ymm10,%ymm10
 108f90d:	vpmuludq %ymm1,%ymm11,%ymm12
 108f911:	vpsrlq $0x20,%ymm11,%ymm13
 108f917:	vpmuludq %ymm0,%ymm13,%ymm13
 108f91b:	vpaddq %ymm13,%ymm12,%ymm12
 108f920:	vpsllq $0x20,%ymm12,%ymm12
 108f926:	vpmuludq %ymm0,%ymm11,%ymm11
 108f92a:	vpaddq %ymm12,%ymm11,%ymm11
 108f92f:	vpsrlq $0x38,%ymm8,%ymm8
 108f935:	vpsubq %ymm8,%ymm2,%ymm2
 108f93a:	vpsrlq $0x38,%ymm9,%ymm8
 108f940:	vpsubq %ymm8,%ymm7,%ymm7
 108f945:	vpsrlq $0x38,%ymm10,%ymm8
 108f94b:	vpsubq %ymm8,%ymm6,%ymm6
 108f950:	vpsrlq $0x38,%ymm11,%ymm8
 108f956:	vpsubq %ymm8,%ymm5,%ymm5
 108f95b:	vpaddq %ymm3,%ymm2,%ymm2
 108f95f:	vpaddq %ymm3,%ymm7,%ymm7
 108f963:	vpaddq %ymm3,%ymm6,%ymm6
 108f967:	vpaddq %ymm3,%ymm5,%ymm5
 108f96b:	add    $0x10,%rax
 108f96f:	cmp    %rax,%r9
 108f972:	jne    108f830 <index_walk+0x190>
 108f978:	vpaddq %ymm2,%ymm7,%ymm0
 108f97c:	vpaddq %ymm0,%ymm6,%ymm0
 108f980:	vpaddq %ymm0,%ymm5,%ymm0
 108f984:	vextracti128 $0x1,%ymm0,%xmm1
 108f98a:	vpaddq %xmm1,%xmm0,%xmm0
 108f98e:	vpshufd $0xee,%xmm0,%xmm1
 108f993:	vpaddq %xmm1,%xmm0,%xmm0
 108f997:	vmovq  %xmm0,%rax
 108f99c:	cmp    %r9,%r8
 108f99f:	je     108f9e9 <index_walk+0x349>
 108f9a1:	movabs $0x101010101010101,%r8
 108f9ab:	nopl   0x0(%rax,%rax,1)
 108f9b0:	mov    (%rcx,%rdx,1),%r9
 108f9b4:	mov    %rdi,%rdx
 108f9b7:	mov    %r9,%rdi
 108f9ba:	not    %rdi
 108f9bd:	add    %rdi,%rdi
 108f9c0:	and    %r9,%rdi
 108f9c3:	shr    $0x7,%rdi
 108f9c7:	and    %r8,%rdi
 108f9ca:	imul   %r8,%rdi
 108f9ce:	shr    $0x38,%rdi
 108f9d2:	sub    %rdi,%rax
 108f9d5:	add    $0x8,%rax
 108f9d9:	lea    0x8(%rdx),%rdi
 108f9dd:	cmp    %rsi,%rdi
 108f9e0:	jbe    108f9b0 <index_walk+0x310>
 108f9e2:	add    $0xfffffffffffffff8,%rdi
 108f9e6:	mov    %rdi,%rdx
 108f9e9:	mov    %rsi,%rdi
 108f9ec:	sub    %rdx,%rdi
 108f9ef:	jbe    108fd00 <index_walk+0x660>
 108f9f5:	cmp    $0x3,%rdi
 108f9f9:	jbe    108fcc0 <index_walk+0x620>
 108f9ff:	cmp    $0x10,%rdi
 108fa03:	jae    108fb6d <index_walk+0x4cd>
 108fa09:	xor    %r8d,%r8d
 108fa0c:	jmp    108fc4f <index_walk+0x5af>
 108fa11:	mov    %rdi,%r9
 108fa14:	and    $0xfffffffffffffff0,%r9
 108fa18:	vmovq  %r8,%xmm0
 108fa1d:	lea    (%rsi,%rcx,1),%r8
 108fa21:	add    $0xc,%r8
 108fa25:	vpxor  %xmm1,%xmm1,%xmm1
 108fa29:	xor    %r10d,%r10d
 108fa2c:	vmovdqa -0x8e004(%rip),%xmm2        # 1001a30 <__abi_tag+0x1734>
 108fa34:	vpbroadcastq -0x88925(%rip),%ymm3        # 1007118 <__abi_tag+0x6e1c>
 108fa3d:	vpxor  %xmm4,%xmm4,%xmm4
 108fa41:	vpxor  %xmm5,%xmm5,%xmm5
 108fa45:	data16 cs nopw 0x0(%rax,%rax,1)
 108fa50:	vmovd  -0xc(%r8,%r10,1),%xmm6
 108fa57:	vmovd  -0x8(%r8,%r10,1),%xmm7
 108fa5e:	vmovd  -0x4(%r8,%r10,1),%xmm8
 108fa65:	vmovd  (%r8,%r10,1),%xmm9
 108fa6b:	vpcmpgtb %xmm2,%xmm6,%xmm6
 108fa6f:	vpmovzxbq %xmm6,%ymm6
 108fa74:	vpand  %ymm3,%ymm6,%ymm6
 108fa78:	vpaddq %ymm6,%ymm0,%ymm0
 108fa7c:	vpcmpgtb %xmm2,%xmm7,%xmm6
 108fa80:	vpmovzxbq %xmm6,%ymm6
 108fa85:	vpand  %ymm3,%ymm6,%ymm6
 108fa89:	vpaddq %ymm6,%ymm1,%ymm1
 108fa8d:	vpcmpgtb %xmm2,%xmm8,%xmm6
 108fa91:	vpmovzxbq %xmm6,%ymm6
 108fa96:	vpand  %ymm3,%ymm6,%ymm6
 108fa9a:	vpaddq %ymm6,%ymm4,%ymm4
 108fa9e:	vpcmpgtb %xmm2,%xmm9,%xmm6
 108faa2:	vpmovzxbq %xmm6,%ymm6
 108faa7:	vpand  %ymm3,%ymm6,%ymm6
 108faab:	vpaddq %ymm6,%ymm5,%ymm5
 108faaf:	add    $0x10,%r10
 108fab3:	cmp    %r10,%r9
 108fab6:	jne    108fa50 <index_walk+0x3b0>
 108fab8:	vpaddq %ymm0,%ymm1,%ymm0
 108fabc:	vpaddq %ymm0,%ymm4,%ymm0
 108fac0:	vpaddq %ymm0,%ymm5,%ymm0
 108fac4:	vextracti128 $0x1,%ymm0,%xmm1
 108faca:	vpaddq %xmm1,%xmm0,%xmm0
 108face:	vpshufd $0xee,%xmm0,%xmm1
 108fad3:	vpaddq %xmm1,%xmm0,%xmm0
 108fad7:	vmovq  %xmm0,%r8
 108fadc:	cmp    %r9,%rdi
 108fadf:	je     108fb65 <index_walk+0x4c5>
 108fae5:	test   $0xc,%dil
 108fae9:	je     108fd0e <index_walk+0x66e>
 108faef:	mov    %rdi,%r10
 108faf2:	and    $0xfffffffffffffffc,%r10
 108faf6:	vmovq  %r8,%xmm0
 108fafb:	lea    (%rcx,%rsi,1),%r8
 108faff:	vmovdqa -0x8e0d7(%rip),%xmm1        # 1001a30 <__abi_tag+0x1734>
 108fb07:	vpbroadcastq -0x889f8(%rip),%ymm2        # 1007118 <__abi_tag+0x6e1c>
 108fb10:	vmovd  (%r8,%r9,1),%xmm3
 108fb16:	vpcmpgtb %xmm1,%xmm3,%xmm3
 108fb1a:	vpmovzxbq %xmm3,%ymm3
 108fb1f:	vpand  %ymm2,%ymm3,%ymm3
 108fb23:	vpaddq %ymm3,%ymm0,%ymm0
 108fb27:	add    $0x4,%r9
 108fb2b:	cmp    %r9,%r10
 108fb2e:	jne    108fb10 <index_walk+0x470>
 108fb30:	vextracti128 $0x1,%ymm0,%xmm1
 108fb36:	vpaddq %xmm1,%xmm0,%xmm0
 108fb3a:	vpshufd $0xee,%xmm0,%xmm1
 108fb3f:	vpaddq %xmm1,%xmm0,%xmm0
 108fb43:	vmovq  %xmm0,%r8
 108fb48:	cmp    %r10,%rdi
 108fb4b:	je     108fb65 <index_walk+0x4c5>
 108fb4d:	add    %r10,%rsi
 108fb50:	xor    %edi,%edi
 108fb52:	cmpb   $0xc0,(%rcx,%rsi,1)
 108fb56:	setge  %dil
 108fb5a:	add    %rdi,%r8
 108fb5d:	inc    %rsi
 108fb60:	cmp    %rsi,%rdx
 108fb63:	jne    108fb50 <index_walk+0x4b0>
 108fb65:	sub    %r8,%rax
 108fb68:	jmp    108fd00 <index_walk+0x660>
 108fb6d:	mov    %rdi,%r8
 108fb70:	and    $0xfffffffffffffff0,%r8
 108fb74:	vmovq  %rax,%xmm0
 108fb79:	lea    (%rdx,%rcx,1),%rax
 108fb7d:	add    $0xc,%rax
 108fb81:	vpxor  %xmm1,%xmm1,%xmm1
 108fb85:	xor    %r9d,%r9d
 108fb88:	vmovdqa -0x8e160(%rip),%xmm2        # 1001a30 <__abi_tag+0x1734>
 108fb90:	vpbroadcastq -0x88a81(%rip),%ymm3        # 1007118 <__abi_tag+0x6e1c>
 108fb99:	vpxor  %xmm4,%xmm4,%xmm4
 108fb9d:	vpxor  %xmm5,%xmm5,%xmm5
 108fba1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 108fbb0:	vmovd  -0xc(%rax,%r9,1),%xmm6
 108fbb7:	vmovd  -0x8(%rax,%r9,1),%xmm7
 108fbbe:	vmovd  -0x4(%rax,%r9,1),%xmm8
 108fbc5:	vmovd  (%rax,%r9,1),%xmm9
 108fbcb:	vpcmpgtb %xmm2,%xmm6,%xmm6
 108fbcf:	vpmovzxbq %xmm6,%ymm6
 108fbd4:	vpand  %ymm3,%ymm6,%ymm6
 108fbd8:	vpaddq %ymm6,%ymm0,%ymm0
 108fbdc:	vpcmpgtb %xmm2,%xmm7,%xmm6
 108fbe0:	vpmovzxbq %xmm6,%ymm6
 108fbe5:	vpand  %ymm3,%ymm6,%ymm6
 108fbe9:	vpaddq %ymm6,%ymm1,%ymm1
 108fbed:	vpcmpgtb %xmm2,%xmm8,%xmm6
 108fbf1:	vpmovzxbq %xmm6,%ymm6
 108fbf6:	vpand  %ymm3,%ymm6,%ymm6
 108fbfa:	vpaddq %ymm6,%ymm4,%ymm4
 108fbfe:	vpcmpgtb %xmm2,%xmm9,%xmm6
 108fc02:	vpmovzxbq %xmm6,%ymm6
 108fc07:	vpand  %ymm3,%ymm6,%ymm6
 108fc0b:	vpaddq %ymm6,%ymm5,%ymm5
 108fc0f:	add    $0x10,%r9
 108fc13:	cmp    %r9,%r8
 108fc16:	jne    108fbb0 <index_walk+0x510>
 108fc18:	vpaddq %ymm0,%ymm1,%ymm0
 108fc1c:	vpaddq %ymm0,%ymm4,%ymm0
 108fc20:	vpaddq %ymm0,%ymm5,%ymm0
 108fc24:	vextracti128 $0x1,%ymm0,%xmm1
 108fc2a:	vpaddq %xmm1,%xmm0,%xmm0
 108fc2e:	vpshufd $0xee,%xmm0,%xmm1
 108fc33:	vpaddq %xmm1,%xmm0,%xmm0
 108fc37:	vmovq  %xmm0,%rax
 108fc3c:	cmp    %r8,%rdi
 108fc3f:	je     108fd00 <index_walk+0x660>
 108fc45:	test   $0xc,%dil
 108fc49:	je     108fd16 <index_walk+0x676>
 108fc4f:	mov    %esi,%r9d
 108fc52:	and    $0x3,%r9d
 108fc56:	sub    %r9,%rdi
 108fc59:	vmovq  %rax,%xmm0
 108fc5e:	mov    %rsi,%rax
 108fc61:	and    $0xfffffffffffffffc,%rax
 108fc65:	add    %rdx,%r8
 108fc68:	vmovdqa -0x8e240(%rip),%xmm1        # 1001a30 <__abi_tag+0x1734>
 108fc70:	vpbroadcastq -0x88b61(%rip),%ymm2        # 1007118 <__abi_tag+0x6e1c>
 108fc79:	nopl   0x0(%rax)
 108fc80:	vmovd  (%rcx,%r8,1),%xmm3
 108fc86:	vpcmpgtb %xmm1,%xmm3,%xmm3
 108fc8a:	vpmovzxbq %xmm3,%ymm3
 108fc8f:	vpand  %ymm2,%ymm3,%ymm3
 108fc93:	vpaddq %ymm3,%ymm0,%ymm0
 108fc97:	add    $0x4,%r8
 108fc9b:	cmp    %r8,%rax
 108fc9e:	jne    108fc80 <index_walk+0x5e0>
 108fca0:	vextracti128 $0x1,%ymm0,%xmm1
 108fca6:	vpaddq %xmm1,%xmm0,%xmm0
 108fcaa:	vpshufd $0xee,%xmm0,%xmm1
 108fcaf:	vpaddq %xmm1,%xmm0,%xmm0
 108fcb3:	vmovq  %xmm0,%rax
 108fcb8:	test   %r9,%r9
 108fcbb:	je     108fd00 <index_walk+0x660>
 108fcbd:	add    %rdi,%rdx
 108fcc0:	xor    %edi,%edi
 108fcc2:	cmpb   $0xc0,(%rcx,%rdx,1)
 108fcc6:	setge  %dil
 108fcca:	add    %rdi,%rax
 108fccd:	inc    %rdx
 108fcd0:	cmp    %rdx,%rsi
 108fcd3:	jne    108fcc0 <index_walk+0x620>
 108fcd5:	jmp    108fd00 <index_walk+0x660>
 108fcd7:	mov    0x14(%rdi),%eax
 108fcda:	add    %rax,%rsi
 108fcdd:	mov    %rdi,%r15
 108fce0:	mov    %rbx,%rdi
 108fce3:	call   108fd20 <index_at>
 108fce8:	mov    %rax,%r14
 108fceb:	mov    0x14(%r15),%esi
 108fcef:	mov    %rbx,%rdi
 108fcf2:	call   108fd20 <index_at>
 108fcf7:	mov    %rax,%rcx
 108fcfa:	mov    %r14,%rax
 108fcfd:	sub    %rcx,%rax
 108fd00:	add    $0x8,%rsp
 108fd04:	pop    %rbx
 108fd05:	pop    %r14
 108fd07:	pop    %r15
 108fd09:	pop    %rbp
 108fd0a:	vzeroupper
 108fd0d:	ret
 108fd0e:	add    %r9,%rsi
 108fd11:	jmp    108fb50 <index_walk+0x4b0>
 108fd16:	add    %r8,%rdx
 108fd19:	jmp    108fcc0 <index_walk+0x620>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
