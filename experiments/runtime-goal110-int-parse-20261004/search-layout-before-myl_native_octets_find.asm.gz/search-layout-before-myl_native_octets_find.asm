
/home/epentland/ai/canopy/mylang-worktrees/goal110-text-rf-host-20261004/.mylang-cache/goal110-join/join-runner/bin/text-my-llvm:     file format elf64-x86-64


Disassembly of section .text:

0000000001091c80 <myl_native_octets_find>:
 1091c80:	test   %rcx,%rcx
 1091c83:	je     1091cda <myl_native_octets_find+0x5a>
 1091c85:	push   %rbp
 1091c86:	mov    %rsp,%rbp
 1091c89:	push   %r15
 1091c8b:	push   %r14
 1091c8d:	push   %r13
 1091c8f:	push   %r12
 1091c91:	push   %rbx
 1091c92:	sub    $0x18,%rsp
 1091c96:	mov    $0xffffffffffffffff,%rax
 1091c9d:	mov    %rsi,%r14
 1091ca0:	sub    %rcx,%r14
 1091ca3:	jb     1091f45 <myl_native_octets_find+0x2c5>
 1091ca9:	mov    %rsi,%rbx
 1091cac:	cmp    $0x1,%rcx
 1091cb0:	jne    1091cdd <myl_native_octets_find+0x5d>
 1091cb2:	movzbl (%rdx),%esi
 1091cb5:	mov    %rdi,%r14
 1091cb8:	mov    %rbx,%rdx
 1091cbb:	call   10ab4e0 <memchr@plt>
 1091cc0:	mov    %rax,%rcx
 1091cc3:	mov    %rax,%rdx
 1091cc6:	sub    %r14,%rdx
 1091cc9:	xor    %eax,%eax
 1091ccb:	cmp    $0x1,%rcx
 1091ccf:	sbb    %rax,%rax
 1091cd2:	or     %rdx,%rax
 1091cd5:	jmp    1091f45 <myl_native_octets_find+0x2c5>
 1091cda:	xor    %eax,%eax
 1091cdc:	ret
 1091cdd:	mov    %rcx,-0x30(%rbp)
 1091ce1:	mov    %rdx,%r15
 1091ce4:	movzbl (%rdx),%r12d
 1091ce8:	lea    0x1(%r14),%rdx
 1091cec:	mov    %rdi,%r13
 1091cef:	mov    %r12d,%esi
 1091cf2:	call   10ab4e0 <memchr@plt>
 1091cf7:	test   %rax,%rax
 1091cfa:	je     1091f3e <myl_native_octets_find+0x2be>
 1091d00:	mov    %r13,%rcx
 1091d03:	lea    (%r14,%r13,1),%r10
 1091d07:	lea    (%r14,%r13,1),%r11
 1091d0b:	inc    %r11
 1091d0e:	lea    0x1(%rax),%rdi
 1091d12:	mov    $0x1,%edx
 1091d17:	mov    -0x30(%rbp),%rsi
 1091d1b:	mov    %r15,%r8
 1091d1e:	xchg   %ax,%ax
 1091d20:	movzbl (%rax,%rdx,1),%r9d
 1091d25:	cmp    (%r8,%rdx,1),%r9b
 1091d29:	jne    1091d3b <myl_native_octets_find+0xbb>
 1091d2b:	inc    %rdx
 1091d2e:	cmp    %rdx,%rsi
 1091d31:	jne    1091d20 <myl_native_octets_find+0xa0>
 1091d33:	sub    %rcx,%rax
 1091d36:	jmp    1091f45 <myl_native_octets_find+0x2c5>
 1091d3b:	cmp    %r10,%rax
 1091d3e:	je     1091f3e <myl_native_octets_find+0x2be>
 1091d44:	mov    %r10,-0x38(%rbp)
 1091d48:	mov    %r11,%r14
 1091d4b:	mov    %r11,%rdx
 1091d4e:	sub    %rdi,%rdx
 1091d51:	mov    %r12d,%esi
 1091d54:	call   10ab4e0 <memchr@plt>
 1091d59:	test   %rax,%rax
 1091d5c:	je     1091f3e <myl_native_octets_find+0x2be>
 1091d62:	lea    0x1(%rax),%rdi
 1091d66:	mov    $0x1,%edx
 1091d6b:	mov    %r13,%rcx
 1091d6e:	mov    -0x30(%rbp),%rsi
 1091d72:	mov    %r15,%r8
 1091d75:	mov    -0x38(%rbp),%r10
 1091d79:	mov    %r14,%r11
 1091d7c:	nopl   0x0(%rax)
 1091d80:	movzbl (%rax,%rdx,1),%r9d
 1091d85:	cmp    (%r8,%rdx,1),%r9b
 1091d89:	jne    1091d95 <myl_native_octets_find+0x115>
 1091d8b:	inc    %rdx
 1091d8e:	cmp    %rdx,%rsi
 1091d91:	jne    1091d80 <myl_native_octets_find+0x100>
 1091d93:	jmp    1091d33 <myl_native_octets_find+0xb3>
 1091d95:	cmp    %r10,%rax
 1091d98:	je     1091f3e <myl_native_octets_find+0x2be>
 1091d9e:	mov    %r11,%rdx
 1091da1:	sub    %rdi,%rdx
 1091da4:	mov    %r12d,%esi
 1091da7:	call   10ab4e0 <memchr@plt>
 1091dac:	test   %rax,%rax
 1091daf:	je     1091f3e <myl_native_octets_find+0x2be>
 1091db5:	lea    0x1(%rax),%rdi
 1091db9:	mov    $0x1,%edx
 1091dbe:	mov    %r13,%rcx
 1091dc1:	mov    -0x30(%rbp),%rsi
 1091dc5:	mov    %r15,%r8
 1091dc8:	mov    -0x38(%rbp),%r10
 1091dcc:	mov    %r14,%r11
 1091dcf:	movzbl (%rax,%rdx,1),%r9d
 1091dd4:	cmp    (%r8,%rdx,1),%r9b
 1091dd8:	jne    1091de7 <myl_native_octets_find+0x167>
 1091dda:	inc    %rdx
 1091ddd:	cmp    %rdx,%rsi
 1091de0:	jne    1091dcf <myl_native_octets_find+0x14f>
 1091de2:	jmp    1091d33 <myl_native_octets_find+0xb3>
 1091de7:	cmp    %r10,%rax
 1091dea:	je     1091f3e <myl_native_octets_find+0x2be>
 1091df0:	mov    %r11,%rdx
 1091df3:	sub    %rdi,%rdx
 1091df6:	mov    %r12d,%esi
 1091df9:	call   10ab4e0 <memchr@plt>
 1091dfe:	test   %rax,%rax
 1091e01:	je     1091f3e <myl_native_octets_find+0x2be>
 1091e07:	lea    0x1(%rax),%rdi
 1091e0b:	mov    $0x1,%edx
 1091e10:	mov    %r13,%rcx
 1091e13:	mov    -0x30(%rbp),%rsi
 1091e17:	mov    %r15,%r8
 1091e1a:	mov    -0x38(%rbp),%r10
 1091e1e:	mov    %r14,%r11
 1091e21:	movzbl (%rax,%rdx,1),%r9d
 1091e26:	cmp    (%r8,%rdx,1),%r9b
 1091e2a:	jne    1091e39 <myl_native_octets_find+0x1b9>
 1091e2c:	inc    %rdx
 1091e2f:	cmp    %rdx,%rsi
 1091e32:	jne    1091e21 <myl_native_octets_find+0x1a1>
 1091e34:	jmp    1091d33 <myl_native_octets_find+0xb3>
 1091e39:	cmp    %r10,%rax
 1091e3c:	je     1091f3e <myl_native_octets_find+0x2be>
 1091e42:	mov    %r11,%rdx
 1091e45:	sub    %rdi,%rdx
 1091e48:	mov    %r12d,%esi
 1091e4b:	call   10ab4e0 <memchr@plt>
 1091e50:	test   %rax,%rax
 1091e53:	je     1091f3e <myl_native_octets_find+0x2be>
 1091e59:	lea    0x1(%rax),%rdi
 1091e5d:	mov    $0x1,%ecx
 1091e62:	mov    -0x30(%rbp),%rdx
 1091e66:	mov    %r15,%rsi
 1091e69:	movzbl (%rax,%rcx,1),%r8d
 1091e6e:	cmp    (%rsi,%rcx,1),%r8b
 1091e72:	jne    1091e84 <myl_native_octets_find+0x204>
 1091e74:	inc    %rcx
 1091e77:	cmp    %rcx,%rdx
 1091e7a:	jne    1091e69 <myl_native_octets_find+0x1e9>
 1091e7c:	mov    %r13,%rcx
 1091e7f:	jmp    1091d33 <myl_native_octets_find+0xb3>
 1091e84:	cmp    -0x38(%rbp),%rax
 1091e88:	je     1091f3e <myl_native_octets_find+0x2be>
 1091e8e:	mov    %r14,%rdx
 1091e91:	sub    %rdi,%rdx
 1091e94:	mov    %r12d,%esi
 1091e97:	call   10ab4e0 <memchr@plt>
 1091e9c:	test   %rax,%rax
 1091e9f:	je     1091f3e <myl_native_octets_find+0x2be>
 1091ea5:	lea    0x1(%rax),%rdi
 1091ea9:	mov    $0x1,%ecx
 1091eae:	mov    -0x30(%rbp),%rdx
 1091eb2:	mov    %r15,%rsi
 1091eb5:	movzbl (%rax,%rcx,1),%r8d
 1091eba:	cmp    (%rsi,%rcx,1),%r8b
 1091ebe:	jne    1091eca <myl_native_octets_find+0x24a>
 1091ec0:	inc    %rcx
 1091ec3:	cmp    %rcx,%rdx
 1091ec6:	jne    1091eb5 <myl_native_octets_find+0x235>
 1091ec8:	jmp    1091e7c <myl_native_octets_find+0x1fc>
 1091eca:	cmp    -0x38(%rbp),%rax
 1091ece:	je     1091f3e <myl_native_octets_find+0x2be>
 1091ed0:	mov    %r14,%rdx
 1091ed3:	sub    %rdi,%rdx
 1091ed6:	mov    %r12d,%esi
 1091ed9:	call   10ab4e0 <memchr@plt>
 1091ede:	test   %rax,%rax
 1091ee1:	je     1091f3e <myl_native_octets_find+0x2be>
 1091ee3:	lea    0x1(%rax),%rdi
 1091ee7:	mov    $0x1,%ecx
 1091eec:	movzbl (%rax,%rcx,1),%edx
 1091ef0:	cmp    (%r15,%rcx,1),%dl
 1091ef4:	jne    1091f04 <myl_native_octets_find+0x284>
 1091ef6:	inc    %rcx
 1091ef9:	cmp    %rcx,-0x30(%rbp)
 1091efd:	jne    1091eec <myl_native_octets_find+0x26c>
 1091eff:	jmp    1091e7c <myl_native_octets_find+0x1fc>
 1091f04:	cmp    -0x38(%rbp),%rax
 1091f08:	je     1091f3e <myl_native_octets_find+0x2be>
 1091f0a:	sub    %rdi,%r14
 1091f0d:	mov    %r12d,%esi
 1091f10:	mov    %r14,%rdx
 1091f13:	call   10ab4e0 <memchr@plt>
 1091f18:	test   %rax,%rax
 1091f1b:	je     1091f3e <myl_native_octets_find+0x2be>
 1091f1d:	lea    0x1(%rax),%rdi
 1091f21:	mov    $0x1,%ecx
 1091f26:	movzbl (%rax,%rcx,1),%edx
 1091f2a:	cmp    (%r15,%rcx,1),%dl
 1091f2e:	jne    1091f54 <myl_native_octets_find+0x2d4>
 1091f30:	inc    %rcx
 1091f33:	cmp    %rcx,-0x30(%rbp)
 1091f37:	jne    1091f26 <myl_native_octets_find+0x2a6>
 1091f39:	jmp    1091e7c <myl_native_octets_find+0x1fc>
 1091f3e:	mov    $0xffffffffffffffff,%rax
 1091f45:	add    $0x18,%rsp
 1091f49:	pop    %rbx
 1091f4a:	pop    %r12
 1091f4c:	pop    %r13
 1091f4e:	pop    %r14
 1091f50:	pop    %r15
 1091f52:	pop    %rbp
 1091f53:	ret
 1091f54:	cmp    -0x38(%rbp),%rax
 1091f58:	mov    $0xffffffffffffffff,%rax
 1091f5f:	je     1091f45 <myl_native_octets_find+0x2c5>
 1091f61:	add    %r13,%rbx
 1091f64:	sub    %rdi,%rbx
 1091f67:	mov    %rbx,%rsi
 1091f6a:	mov    %r15,%rdx
 1091f6d:	mov    -0x30(%rbp),%rcx
 1091f71:	call   10ab4f0 <memmem@plt>
 1091f76:	mov    %rax,%rcx
 1091f79:	mov    %rax,%rdx
 1091f7c:	sub    %r13,%rdx
 1091f7f:	jmp    1091cc9 <myl_native_octets_find+0x49>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
