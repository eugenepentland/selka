
/home/epentland/ai/canopy/mylang-worktrees/goal110-text-rf-host-20261004/.mylang-cache/goal110-join/join-runner/bin/text-my-llvm:     file format elf64-x86-64


Disassembly of section .text:

000000000104a070 <myl_native_bytes_number_parse>:
 104a070:	push   %rbp
 104a071:	mov    %rsp,%rbp
 104a074:	push   %r15
 104a076:	push   %r14
 104a078:	push   %r13
 104a07a:	push   %r12
 104a07c:	push   %rbx
 104a07d:	sub    $0x3b8,%rsp
 104a084:	mov    %rcx,%r14
 104a087:	test   %rdi,%rdi
 104a08a:	mov    $0x1,%r8d
 104a090:	cmovne %rdi,%r8
 104a094:	cmovne %rsi,%rdi
 104a098:	test   %edx,%edx
 104a09a:	je     104a0ea <myl_native_bytes_number_parse+0x7a>
 104a09c:	xor    %r9d,%r9d
 104a09f:	test   %rdi,%rdi
 104a0a2:	je     104a136 <myl_native_bytes_number_parse+0xc6>
 104a0a8:	vmovdqa -0x48700(%rip),%xmm0        # 10019b0 <__abi_tag+0x16b4>
 104a0b0:	jmp    104a0c8 <myl_native_bytes_number_parse+0x58>
 104a0b2:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 104a0c0:	inc    %r9
 104a0c3:	cmp    %r9,%rdi
 104a0c6:	je     104a133 <myl_native_bytes_number_parse+0xc3>
 104a0c8:	movzbl (%r8,%r9,1),%eax
 104a0cd:	vmovd  %eax,%xmm1
 104a0d1:	vpbroadcastd %xmm1,%xmm1
 104a0d6:	vpcmpeqd %xmm0,%xmm1,%xmm1
 104a0da:	vmovmskps %xmm1,%ecx
 104a0de:	test   %ecx,%ecx
 104a0e0:	jne    104a0c0 <myl_native_bytes_number_parse+0x50>
 104a0e2:	add    $0xf5,%al
 104a0e4:	cmp    $0x1,%al
 104a0e6:	jbe    104a0c0 <myl_native_bytes_number_parse+0x50>
 104a0e8:	jmp    104a136 <myl_native_bytes_number_parse+0xc6>
 104a0ea:	xor    %eax,%eax
 104a0ec:	test   %rdi,%rdi
 104a0ef:	je     104a367 <myl_native_bytes_number_parse+0x2f7>
 104a0f5:	vmovdqa -0x4874d(%rip),%xmm0        # 10019b0 <__abi_tag+0x16b4>
 104a0fd:	jmp    104a10c <myl_native_bytes_number_parse+0x9c>
 104a0ff:	nop
 104a100:	inc    %rax
 104a103:	cmp    %rax,%rdi
 104a106:	je     104a364 <myl_native_bytes_number_parse+0x2f4>
 104a10c:	movzbl (%r8,%rax,1),%ecx
 104a111:	vmovd  %ecx,%xmm1
 104a115:	vpbroadcastd %xmm1,%xmm1
 104a11a:	vpcmpeqd %xmm0,%xmm1,%xmm1
 104a11e:	vmovmskps %xmm1,%edx
 104a122:	test   %edx,%edx
 104a124:	jne    104a100 <myl_native_bytes_number_parse+0x90>
 104a126:	add    $0xf5,%cl
 104a129:	cmp    $0x1,%cl
 104a12c:	jbe    104a100 <myl_native_bytes_number_parse+0x90>
 104a12e:	jmp    104a367 <myl_native_bytes_number_parse+0x2f7>
 104a133:	mov    %rsi,%r9
 104a136:	cmp    %rdi,%r9
 104a139:	mov    %rdi,%r13
 104a13c:	cmovb  %r9,%r13
 104a140:	vmovdqa -0x48798(%rip),%xmm0        # 10019b0 <__abi_tag+0x16b4>
 104a148:	nopl   0x0(%rax,%rax,1)
 104a150:	cmp    %r9,%rdi
 104a153:	jbe    104a17f <myl_native_bytes_number_parse+0x10f>
 104a155:	movzbl -0x1(%r8,%rdi,1),%eax
 104a15b:	dec    %rdi
 104a15e:	vmovd  %eax,%xmm1
 104a162:	vpbroadcastd %xmm1,%xmm1
 104a167:	vpcmpeqd %xmm0,%xmm1,%xmm1
 104a16b:	vmovmskps %xmm1,%ecx
 104a16f:	test   %ecx,%ecx
 104a171:	jne    104a150 <myl_native_bytes_number_parse+0xe0>
 104a173:	add    $0xf5,%al
 104a175:	cmp    $0x2,%al
 104a177:	jb     104a150 <myl_native_bytes_number_parse+0xe0>
 104a179:	inc    %rdi
 104a17c:	mov    %rdi,%r13
 104a17f:	lea    (%r8,%r9,1),%r15
 104a183:	sub    %r9,%r13
 104a186:	je     104a1a4 <myl_native_bytes_number_parse+0x134>
 104a188:	movzbl (%r15),%eax
 104a18c:	cmp    $0x2d,%eax
 104a18f:	je     104a196 <myl_native_bytes_number_parse+0x126>
 104a191:	cmp    $0x2b,%eax
 104a194:	jne    104a1a4 <myl_native_bytes_number_parse+0x134>
 104a196:	cmp    $0x2d,%al
 104a198:	sete   %dil
 104a19c:	mov    $0x1,%r11d
 104a1a2:	jmp    104a1a9 <myl_native_bytes_number_parse+0x139>
 104a1a4:	xor    %r11d,%r11d
 104a1a7:	xor    %edi,%edi
 104a1a9:	lea    (%r15,%r11,1),%rsi
 104a1ad:	mov    %r13,%rax
 104a1b0:	sub    %r11,%rax
 104a1b3:	cmp    $0x8,%rax
 104a1b7:	je     104a248 <myl_native_bytes_number_parse+0x1d8>
 104a1bd:	cmp    $0x3,%rax
 104a1c1:	jne    104a4da <myl_native_bytes_number_parse+0x46a>
 104a1c7:	movzbl (%rsi),%eax
 104a1ca:	test   %al,%al
 104a1cc:	js     104a4da <myl_native_bytes_number_parse+0x46a>
 104a1d2:	lea    -0x41(%rax),%ecx
 104a1d5:	cmp    $0x1a,%cl
 104a1d8:	setb   %cl
 104a1db:	shl    $0x5,%cl
 104a1de:	or     %al,%cl
 104a1e0:	cmp    $0x69,%cl
 104a1e3:	je     104a482 <myl_native_bytes_number_parse+0x412>
 104a1e9:	movzbl %cl,%eax
 104a1ec:	cmp    $0x6e,%eax
 104a1ef:	jne    104a4da <myl_native_bytes_number_parse+0x46a>
 104a1f5:	movzbl 0x1(%rsi),%eax
 104a1f9:	test   %al,%al
 104a1fb:	js     104a4da <myl_native_bytes_number_parse+0x46a>
 104a201:	lea    -0x41(%rax),%ecx
 104a204:	cmp    $0x1a,%cl
 104a207:	setb   %cl
 104a20a:	shl    $0x5,%cl
 104a20d:	or     %al,%cl
 104a20f:	cmp    $0x61,%cl
 104a212:	jne    104a4da <myl_native_bytes_number_parse+0x46a>
 104a218:	movzbl 0x2(%rsi),%eax
 104a21c:	test   %al,%al
 104a21e:	js     104a4da <myl_native_bytes_number_parse+0x46a>
 104a224:	lea    -0x41(%rax),%ecx
 104a227:	cmp    $0x1a,%cl
 104a22a:	setb   %cl
 104a22d:	shl    $0x5,%cl
 104a230:	or     %al,%cl
 104a232:	cmp    $0x6e,%cl
 104a235:	jne    104a4da <myl_native_bytes_number_parse+0x46a>
 104a23b:	vmovq  -0x4310b(%rip),%xmm0        # 1007138 <__abi_tag+0x6e3c>
 104a243:	jmp    104a4c0 <myl_native_bytes_number_parse+0x450>
 104a248:	movzbl (%rsi),%eax
 104a24b:	test   %al,%al
 104a24d:	js     104a4da <myl_native_bytes_number_parse+0x46a>
 104a253:	lea    -0x41(%rax),%ecx
 104a256:	cmp    $0x1a,%cl
 104a259:	setb   %cl
 104a25c:	shl    $0x5,%cl
 104a25f:	or     %al,%cl
 104a261:	cmp    $0x69,%cl
 104a264:	jne    104a4da <myl_native_bytes_number_parse+0x46a>
 104a26a:	movzbl 0x1(%rsi),%eax
 104a26e:	test   %al,%al
 104a270:	js     104a4da <myl_native_bytes_number_parse+0x46a>
 104a276:	lea    -0x41(%rax),%ecx
 104a279:	cmp    $0x1a,%cl
 104a27c:	setb   %cl
 104a27f:	shl    $0x5,%cl
 104a282:	or     %al,%cl
 104a284:	cmp    $0x6e,%cl
 104a287:	jne    104a4da <myl_native_bytes_number_parse+0x46a>
 104a28d:	movzbl 0x2(%rsi),%eax
 104a291:	test   %al,%al
 104a293:	js     104a4da <myl_native_bytes_number_parse+0x46a>
 104a299:	lea    -0x41(%rax),%ecx
 104a29c:	cmp    $0x1a,%cl
 104a29f:	setb   %cl
 104a2a2:	shl    $0x5,%cl
 104a2a5:	or     %al,%cl
 104a2a7:	cmp    $0x66,%cl
 104a2aa:	jne    104a4da <myl_native_bytes_number_parse+0x46a>
 104a2b0:	movzbl 0x3(%rsi),%eax
 104a2b4:	test   %al,%al
 104a2b6:	js     104a4da <myl_native_bytes_number_parse+0x46a>
 104a2bc:	lea    -0x41(%rax),%ecx
 104a2bf:	cmp    $0x1a,%cl
 104a2c2:	setb   %cl
 104a2c5:	shl    $0x5,%cl
 104a2c8:	or     %al,%cl
 104a2ca:	cmp    $0x69,%cl
 104a2cd:	jne    104a4da <myl_native_bytes_number_parse+0x46a>
 104a2d3:	movzbl 0x4(%rsi),%eax
 104a2d7:	test   %al,%al
 104a2d9:	js     104a4da <myl_native_bytes_number_parse+0x46a>
 104a2df:	lea    -0x41(%rax),%ecx
 104a2e2:	cmp    $0x1a,%cl
 104a2e5:	setb   %cl
 104a2e8:	shl    $0x5,%cl
 104a2eb:	or     %al,%cl
 104a2ed:	cmp    $0x6e,%cl
 104a2f0:	jne    104a4da <myl_native_bytes_number_parse+0x46a>
 104a2f6:	movzbl 0x5(%rsi),%eax
 104a2fa:	test   %al,%al
 104a2fc:	js     104a4da <myl_native_bytes_number_parse+0x46a>
 104a302:	lea    -0x41(%rax),%ecx
 104a305:	cmp    $0x1a,%cl
 104a308:	setb   %cl
 104a30b:	shl    $0x5,%cl
 104a30e:	or     %al,%cl
 104a310:	cmp    $0x69,%cl
 104a313:	jne    104a4da <myl_native_bytes_number_parse+0x46a>
 104a319:	movzbl 0x6(%rsi),%eax
 104a31d:	test   %al,%al
 104a31f:	js     104a4da <myl_native_bytes_number_parse+0x46a>
 104a325:	lea    -0x41(%rax),%ecx
 104a328:	cmp    $0x1a,%cl
 104a32b:	setb   %cl
 104a32e:	shl    $0x5,%cl
 104a331:	or     %al,%cl
 104a333:	cmp    $0x74,%cl
 104a336:	jne    104a4da <myl_native_bytes_number_parse+0x46a>
 104a33c:	movzbl 0x7(%rsi),%eax
 104a340:	test   %al,%al
 104a342:	js     104a4da <myl_native_bytes_number_parse+0x46a>
 104a348:	lea    -0x41(%rax),%ecx
 104a34b:	cmp    $0x1a,%cl
 104a34e:	setb   %cl
 104a351:	shl    $0x5,%cl
 104a354:	or     %al,%cl
 104a356:	cmp    $0x79,%cl
 104a359:	je     104a4b8 <myl_native_bytes_number_parse+0x448>
 104a35f:	jmp    104a4da <myl_native_bytes_number_parse+0x46a>
 104a364:	mov    %rsi,%rax
 104a367:	cmp    %rdi,%rax
 104a36a:	mov    %rdi,%rcx
 104a36d:	cmovb  %rax,%rcx
 104a371:	vmovdqa -0x489c9(%rip),%xmm0        # 10019b0 <__abi_tag+0x16b4>
 104a379:	nopl   0x0(%rax)
 104a380:	cmp    %rax,%rdi
 104a383:	jbe    104a3b1 <myl_native_bytes_number_parse+0x341>
 104a385:	movzbl -0x1(%r8,%rdi,1),%edx
 104a38b:	dec    %rdi
 104a38e:	vmovd  %edx,%xmm1
 104a392:	vpbroadcastd %xmm1,%xmm1
 104a397:	vpcmpeqd %xmm0,%xmm1,%xmm1
 104a39b:	vmovmskps %xmm1,%esi
 104a39f:	test   %esi,%esi
 104a3a1:	jne    104a380 <myl_native_bytes_number_parse+0x310>
 104a3a3:	add    $0xf5,%dl
 104a3a6:	cmp    $0x2,%dl
 104a3a9:	jb     104a380 <myl_native_bytes_number_parse+0x310>
 104a3ab:	inc    %rdi
 104a3ae:	mov    %rdi,%rcx
 104a3b1:	sub    %rax,%rcx
 104a3b4:	je     104a8e9 <myl_native_bytes_number_parse+0x879>
 104a3ba:	add    %rax,%r8
 104a3bd:	movzbl (%r8),%eax
 104a3c1:	cmp    $0x2d,%eax
 104a3c4:	je     104a3cb <myl_native_bytes_number_parse+0x35b>
 104a3c6:	cmp    $0x2b,%eax
 104a3c9:	jne    104a3e0 <myl_native_bytes_number_parse+0x370>
 104a3cb:	cmp    $0x2d,%al
 104a3cd:	sete   %sil
 104a3d1:	mov    $0x1,%edi
 104a3d6:	cmp    %rcx,%rdi
 104a3d9:	jne    104a3ed <myl_native_bytes_number_parse+0x37d>
 104a3db:	jmp    104a8e9 <myl_native_bytes_number_parse+0x879>
 104a3e0:	xor    %edi,%edi
 104a3e2:	xor    %esi,%esi
 104a3e4:	cmp    %rcx,%rdi
 104a3e7:	je     104a8e9 <myl_native_bytes_number_parse+0x879>
 104a3ed:	jae    104a46f <myl_native_bytes_number_parse+0x3ff>
 104a3f3:	movabs $0xccccccccccccccc,%r9
 104a3fd:	movzbl %sil,%r10d
 104a401:	add    $0x7,%r10
 104a405:	xor    %eax,%eax
 104a407:	xor    %edx,%edx
 104a409:	jmp    104a424 <myl_native_bytes_number_parse+0x3b4>
 104a40b:	nopl   0x0(%rax,%rax,1)
 104a410:	lea    (%rdx,%rdx,4),%rdx
 104a414:	lea    (%r11,%rdx,2),%rdx
 104a418:	mov    %rbx,%rdi
 104a41b:	cmp    %rcx,%rbx
 104a41e:	jae    104a79f <myl_native_bytes_number_parse+0x72f>
 104a424:	movzbl (%r8,%rdi,1),%r11d
 104a429:	add    $0xffffffd0,%r11d
 104a42d:	cmp    $0x9,%r11d
 104a431:	ja     104a8eb <myl_native_bytes_number_parse+0x87b>
 104a437:	cmp    %r9,%rdx
 104a43a:	ja     104a8eb <myl_native_bytes_number_parse+0x87b>
 104a440:	mov    %r11d,%r11d
 104a443:	jne    104a44e <myl_native_bytes_number_parse+0x3de>
 104a445:	cmp    %r11d,%r10d
 104a448:	jb     104a8eb <myl_native_bytes_number_parse+0x87b>
 104a44e:	lea    0x1(%rdi),%rbx
 104a452:	cmp    %rcx,%rbx
 104a455:	jae    104a410 <myl_native_bytes_number_parse+0x3a0>
 104a457:	cmpb   $0x5f,(%r8,%rbx,1)
 104a45c:	jne    104a410 <myl_native_bytes_number_parse+0x3a0>
 104a45e:	add    $0x2,%rdi
 104a462:	mov    %rdi,%rbx
 104a465:	cmp    %rcx,%rdi
 104a468:	jne    104a410 <myl_native_bytes_number_parse+0x3a0>
 104a46a:	jmp    104a8eb <myl_native_bytes_number_parse+0x87b>
 104a46f:	xor    %edx,%edx
 104a471:	test   %sil,%sil
 104a474:	je     104a7ba <myl_native_bytes_number_parse+0x74a>
 104a47a:	neg    %rdx
 104a47d:	jmp    104a7ba <myl_native_bytes_number_parse+0x74a>
 104a482:	movzbl 0x1(%rsi),%eax
 104a486:	test   %al,%al
 104a488:	js     104a4da <myl_native_bytes_number_parse+0x46a>
 104a48a:	lea    -0x41(%rax),%ecx
 104a48d:	cmp    $0x1a,%cl
 104a490:	setb   %cl
 104a493:	shl    $0x5,%cl
 104a496:	or     %al,%cl
 104a498:	cmp    $0x6e,%cl
 104a49b:	jne    104a4da <myl_native_bytes_number_parse+0x46a>
 104a49d:	movzbl 0x2(%rsi),%eax
 104a4a1:	test   %al,%al
 104a4a3:	js     104a4da <myl_native_bytes_number_parse+0x46a>
 104a4a5:	lea    -0x41(%rax),%ecx
 104a4a8:	cmp    $0x1a,%cl
 104a4ab:	setb   %cl
 104a4ae:	shl    $0x5,%cl
 104a4b1:	or     %al,%cl
 104a4b3:	cmp    $0x66,%cl
 104a4b6:	jne    104a4da <myl_native_bytes_number_parse+0x46a>
 104a4b8:	vmovq  -0x433b0(%rip),%xmm0        # 1007110 <__abi_tag+0x6e14>
 104a4c0:	test   %dil,%dil
 104a4c3:	je     104a4cd <myl_native_bytes_number_parse+0x45d>
 104a4c5:	vpxor  -0x48aad(%rip),%xmm0,%xmm0        # 1001a20 <__abi_tag+0x1724>
 104a4cd:	lea    -0x40(%rbp),%rcx
 104a4d1:	lea    -0x48(%rbp),%rax
 104a4d5:	jmp    104a91e <myl_native_bytes_number_parse+0x8ae>
 104a4da:	lea    -0x3d8(%rbp),%rax
 104a4e1:	mov    %rax,-0x90(%rbp)
 104a4e8:	movq   $0x320,-0x88(%rbp)
 104a4f3:	vpxor  %xmm0,%xmm0,%xmm0
 104a4f7:	vmovdqu %xmm0,-0x80(%rbp)
 104a4fc:	movw   $0x0,-0x70(%rbp)
 104a502:	cmp    %r11,%r13
 104a505:	mov    %r15,-0xa0(%rbp)
 104a50c:	mov    %rdi,-0xa8(%rbp)
 104a513:	jne    104a521 <myl_native_bytes_number_parse+0x4b1>
 104a515:	xor    %ecx,%ecx
 104a517:	mov    %r13,%r15
 104a51a:	xor    %esi,%esi
 104a51c:	jmp    104a830 <myl_native_bytes_number_parse+0x7c0>
 104a521:	movzbl (%rsi),%eax
 104a524:	add    $0xd0,%al
 104a526:	cmp    $0xa,%al
 104a528:	setb   %cl
 104a52b:	xor    %edx,%edx
 104a52d:	cmp    %r11,%r13
 104a530:	jbe    104a5d1 <myl_native_bytes_number_parse+0x561>
 104a536:	cmp    $0x9,%al
 104a538:	ja     104a5d1 <myl_native_bytes_number_parse+0x561>
 104a53e:	mov    %rcx,-0x38(%rbp)
 104a542:	lea    (%r9,%r8,1),%rdx
 104a546:	inc    %rdx
 104a549:	lea    0x1(%r11),%rcx
 104a54d:	xor    %eax,%eax
 104a54f:	mov    %r13,%r10
 104a552:	mov    %r11,%r12
 104a555:	jmp    104a575 <myl_native_bytes_number_parse+0x505>
 104a557:	nopw   0x0(%rax,%rax,1)
 104a560:	inc    %r12
 104a563:	inc    %rax
 104a566:	dec    %r10
 104a569:	inc    %rdx
 104a56c:	cmp    %r10,%r11
 104a56f:	je     104a5f7 <myl_native_bytes_number_parse+0x587>
 104a575:	movzbl -0x1(%rdx,%r11,1),%ebx
 104a57b:	lea    -0x30(%rbx),%edi
 104a57e:	cmp    $0xa,%dil
 104a582:	jb     104a560 <myl_native_bytes_number_parse+0x4f0>
 104a584:	cmp    $0x5f,%bl
 104a587:	jne    104a5a1 <myl_native_bytes_number_parse+0x531>
 104a589:	cmp    %r10,%rcx
 104a58c:	je     104a780 <myl_native_bytes_number_parse+0x710>
 104a592:	movzbl (%rdx,%r11,1),%edi
 104a597:	add    $0xd0,%dil
 104a59b:	cmp    $0xa,%dil
 104a59f:	jb     104a560 <myl_native_bytes_number_parse+0x4f0>
 104a5a1:	mov    %r12,%rax
 104a5a4:	mov    %r13,%r10
 104a5a7:	sub    %r11,%rax
 104a5aa:	jne    104a605 <myl_native_bytes_number_parse+0x595>
 104a5ac:	movq   $0x0,-0x30(%rbp)
 104a5b4:	mov    %r11,%r12
 104a5b7:	xor    %edx,%edx
 104a5b9:	xor    %r11d,%r11d
 104a5bc:	xor    %r13d,%r13d
 104a5bf:	mov    -0x38(%rbp),%rcx
 104a5c3:	cmp    %r10,%r12
 104a5c6:	jb     104a80c <myl_native_bytes_number_parse+0x79c>
 104a5cc:	jmp    104a828 <myl_native_bytes_number_parse+0x7b8>
 104a5d1:	mov    $0x0,%eax
 104a5d6:	mov    %rax,-0x30(%rbp)
 104a5da:	mov    %r13,%r10
 104a5dd:	mov    %r11,%r12
 104a5e0:	xor    %r11d,%r11d
 104a5e3:	mov    $0x0,%r13d
 104a5e9:	cmp    %r10,%r12
 104a5ec:	jb     104a80c <myl_native_bytes_number_parse+0x79c>
 104a5f2:	jmp    104a828 <myl_native_bytes_number_parse+0x7b8>
 104a5f7:	mov    %r13,%r12
 104a5fa:	mov    %r12,%rax
 104a5fd:	mov    %r13,%r10
 104a600:	sub    %r11,%rax
 104a603:	je     104a5ac <myl_native_bytes_number_parse+0x53c>
 104a605:	mov    %r14,-0x68(%rbp)
 104a609:	cmp    %rcx,%r12
 104a60c:	jne    104a62a <myl_native_bytes_number_parse+0x5ba>
 104a60e:	movq   $0x0,-0x30(%rbp)
 104a616:	xor    %edx,%edx
 104a618:	xor    %r11d,%r11d
 104a61b:	xor    %r13d,%r13d
 104a61e:	xor    %r14d,%r14d
 104a621:	mov    -0x38(%rbp),%rcx
 104a625:	jmp    104a74c <myl_native_bytes_number_parse+0x6dc>
 104a62a:	mov    %rax,%r15
 104a62d:	and    $0xfffffffffffffffe,%r15
 104a631:	add    %r9,%r11
 104a634:	lea    (%r8,%r11,1),%rcx
 104a638:	inc    %rcx
 104a63b:	movq   $0x0,-0x30(%rbp)
 104a643:	xor    %edx,%edx
 104a645:	xor    %r11d,%r11d
 104a648:	xor    %r13d,%r13d
 104a64b:	xor    %r14d,%r14d
 104a64e:	jmp    104a660 <myl_native_bytes_number_parse+0x5f0>
 104a650:	xor    %r13d,%r13d
 104a653:	add    $0x2,%r14
 104a657:	cmp    %r14,%r15
 104a65a:	je     104a73c <myl_native_bytes_number_parse+0x6cc>
 104a660:	movzbl -0x1(%rcx,%r14,1),%ebx
 104a666:	cmp    $0x5f,%bl
 104a669:	je     104a6a3 <myl_native_bytes_number_parse+0x633>
 104a66b:	xor    $0x1,%r13b
 104a66f:	cmp    $0x30,%bl
 104a672:	sete   %dil
 104a676:	test   %r13b,%dil
 104a679:	jne    104a6a0 <myl_native_bytes_number_parse+0x630>
 104a67b:	cmp    $0x2ff,%r11
 104a682:	ja     104a6d9 <myl_native_bytes_number_parse+0x669>
 104a684:	mov    %bl,-0x3d8(%rbp,%r11,1)
 104a68c:	inc    %r11
 104a68f:	mov    $0x1,%r13b
 104a692:	movzbl (%rcx,%r14,1),%ebx
 104a697:	cmp    $0x5f,%bl
 104a69a:	je     104a653 <myl_native_bytes_number_parse+0x5e3>
 104a69c:	jmp    104a6ad <myl_native_bytes_number_parse+0x63d>
 104a69e:	xchg   %ax,%ax
 104a6a0:	xor    %r13d,%r13d
 104a6a3:	movzbl (%rcx,%r14,1),%ebx
 104a6a8:	cmp    $0x5f,%bl
 104a6ab:	je     104a653 <myl_native_bytes_number_parse+0x5e3>
 104a6ad:	xor    $0x1,%r13b
 104a6b1:	cmp    $0x30,%bl
 104a6b4:	sete   %dil
 104a6b8:	test   %r13b,%dil
 104a6bb:	jne    104a650 <myl_native_bytes_number_parse+0x5e0>
 104a6bd:	cmp    $0x300,%r11
 104a6c4:	jae    104a710 <myl_native_bytes_number_parse+0x6a0>
 104a6c6:	mov    %bl,-0x3d8(%rbp,%r11,1)
 104a6ce:	inc    %r11
 104a6d1:	mov    $0x1,%r13b
 104a6d4:	jmp    104a653 <myl_native_bytes_number_parse+0x5e3>
 104a6d9:	cmp    $0x30,%bl
 104a6dc:	setne  %dil
 104a6e0:	inc    %rdx
 104a6e3:	movabs $0x7fffffffffffffff,%rbx
 104a6ed:	cmovo  %rbx,%rdx
 104a6f1:	or     -0x30(%rbp),%dil
 104a6f5:	and    $0x1,%dil
 104a6f9:	mov    $0x1,%r13b
 104a6fc:	mov    %rdi,-0x30(%rbp)
 104a700:	movzbl (%rcx,%r14,1),%ebx
 104a705:	cmp    $0x5f,%bl
 104a708:	je     104a653 <myl_native_bytes_number_parse+0x5e3>
 104a70e:	jmp    104a6ad <myl_native_bytes_number_parse+0x63d>
 104a710:	cmp    $0x30,%bl
 104a713:	setne  %dil
 104a717:	inc    %rdx
 104a71a:	movabs $0x7fffffffffffffff,%rbx
 104a724:	cmovo  %rbx,%rdx
 104a728:	or     -0x30(%rbp),%dil
 104a72c:	and    $0x1,%dil
 104a730:	mov    $0x1,%r13b
 104a733:	mov    %rdi,-0x30(%rbp)
 104a737:	jmp    104a653 <myl_native_bytes_number_parse+0x5e3>
 104a73c:	test   $0x1,%al
 104a73e:	lea    (%r8,%r9,1),%r15
 104a742:	mov    -0x38(%rbp),%rcx
 104a746:	je     104a7f0 <myl_native_bytes_number_parse+0x780>
 104a74c:	movzbl (%rsi,%r14,1),%eax
 104a751:	cmp    $0x5f,%al
 104a753:	je     104a7f0 <myl_native_bytes_number_parse+0x780>
 104a759:	xor    $0x1,%r13b
 104a75d:	cmp    $0x30,%al
 104a75f:	sete   %cl
 104a762:	test   %r13b,%cl
 104a765:	jne    104a79a <myl_native_bytes_number_parse+0x72a>
 104a767:	cmp    $0x300,%r11
 104a76e:	jae    104a7c7 <myl_native_bytes_number_parse+0x757>
 104a770:	mov    %al,-0x3d8(%rbp,%r11,1)
 104a778:	inc    %r11
 104a77b:	mov    $0x1,%r13b
 104a77e:	jmp    104a7ec <myl_native_bytes_number_parse+0x77c>
 104a780:	add    %r11,%rax
 104a783:	mov    %rax,%r12
 104a786:	mov    %r12,%rax
 104a789:	mov    %r13,%r10
 104a78c:	sub    %r11,%rax
 104a78f:	je     104a5ac <myl_native_bytes_number_parse+0x53c>
 104a795:	jmp    104a605 <myl_native_bytes_number_parse+0x595>
 104a79a:	xor    %r13d,%r13d
 104a79d:	jmp    104a7ec <myl_native_bytes_number_parse+0x77c>
 104a79f:	test   %sil,%sil
 104a7a2:	je     104a7ba <myl_native_bytes_number_parse+0x74a>
 104a7a4:	mov    %rdx,%rax
 104a7a7:	neg    %rax
 104a7aa:	jno    104a47a <myl_native_bytes_number_parse+0x40a>
 104a7b0:	movabs $0x8000000000000000,%rdx
 104a7ba:	mov    %rdx,(%r14)
 104a7bd:	mov    $0x1,%eax
 104a7c2:	jmp    104a8eb <myl_native_bytes_number_parse+0x87b>
 104a7c7:	cmp    $0x30,%al
 104a7c9:	setne  %al
 104a7cc:	mov    %rdx,%rcx
 104a7cf:	inc    %rcx
 104a7d2:	movabs $0x7fffffffffffffff,%rdx
 104a7dc:	cmovno %rcx,%rdx
 104a7e0:	or     -0x30(%rbp),%al
 104a7e3:	and    $0x1,%al
 104a7e5:	mov    $0x1,%r13b
 104a7e8:	mov    %rax,-0x30(%rbp)
 104a7ec:	mov    -0x38(%rbp),%rcx
 104a7f0:	mov    %r13b,-0x70(%rbp)
 104a7f4:	mov    %r11,-0x80(%rbp)
 104a7f8:	mov    %rdx,-0x78(%rbp)
 104a7fc:	mov    -0x30(%rbp),%rax
 104a800:	mov    %al,-0x6f(%rbp)
 104a803:	mov    -0x68(%rbp),%r14
 104a807:	cmp    %r10,%r12
 104a80a:	jae    104a828 <myl_native_bytes_number_parse+0x7b8>
 104a80c:	cmpb   $0x2e,(%r15,%r12,1)
 104a811:	jne    104a828 <myl_native_bytes_number_parse+0x7b8>
 104a813:	lea    0x1(%r12),%rax
 104a818:	xor    %esi,%esi
 104a81a:	cmp    %r10,%rax
 104a81d:	jne    104a931 <myl_native_bytes_number_parse+0x8c1>
 104a823:	mov    %r10,%r15
 104a826:	jmp    104a82d <myl_native_bytes_number_parse+0x7bd>
 104a828:	xor    %esi,%esi
 104a82a:	mov    %r12,%r15
 104a82d:	mov    %r10,%r13
 104a830:	test   %cl,%cl
 104a832:	jne    104a845 <myl_native_bytes_number_parse+0x7d5>
 104a834:	xor    %eax,%eax
 104a836:	test   %rsi,%rsi
 104a839:	jne    104a845 <myl_native_bytes_number_parse+0x7d5>
 104a83b:	mov    %r15,%r11
 104a83e:	xor    %edx,%edx
 104a840:	jmp    104a8c6 <myl_native_bytes_number_parse+0x856>
 104a845:	cmp    %r13,%r15
 104a848:	jae    104a896 <myl_native_bytes_number_parse+0x826>
 104a84a:	lea    (%r8,%r9,1),%rax
 104a84e:	movzbl (%rax,%r15,1),%eax
 104a853:	or     $0x20,%eax
 104a856:	cmp    $0x65,%eax
 104a859:	jne    104a896 <myl_native_bytes_number_parse+0x826>
 104a85b:	lea    0x1(%r15),%rcx
 104a85f:	xor    %eax,%eax
 104a861:	mov    %r13,%r11
 104a864:	mov    $0x0,%edx
 104a869:	cmp    %r13,%rcx
 104a86c:	je     104a8c6 <myl_native_bytes_number_parse+0x856>
 104a86e:	lea    (%r8,%r9,1),%rax
 104a872:	movzbl (%rax,%rcx,1),%eax
 104a876:	cmp    $0x2d,%eax
 104a879:	je     104a884 <myl_native_bytes_number_parse+0x814>
 104a87b:	cmp    $0x2b,%eax
 104a87e:	jne    104a9d3 <myl_native_bytes_number_parse+0x963>
 104a884:	add    $0x2,%r15
 104a888:	cmp    $0x2d,%al
 104a88a:	sete   %r10b
 104a88e:	mov    %r15,%rcx
 104a891:	jmp    104a9d6 <myl_native_bytes_number_parse+0x966>
 104a896:	xor    %edx,%edx
 104a898:	neg    %rsi
 104a89b:	lea    (%rdx,%rsi,1),%rax
 104a89f:	sar    $0x3f,%rax
 104a8a3:	movabs $0x8000000000000000,%rcx
 104a8ad:	xor    %rax,%rcx
 104a8b0:	add    %rdx,%rsi
 104a8b3:	cmovo  %rcx,%rsi
 104a8b7:	lea    -0x90(%rbp),%rdi
 104a8be:	call   104b8a0 <myl_native_number_parse+0xc10>
 104a8c3:	mov    %r15,%r11
 104a8c6:	cmp    %r13,%r11
 104a8c9:	jne    104a8e9 <myl_native_bytes_number_parse+0x879>
 104a8cb:	test   %rax,%rax
 104a8ce:	je     104a8e9 <myl_native_bytes_number_parse+0x879>
 104a8d0:	lea    -0xb8(%rbp),%rdi
 104a8d7:	mov    %rax,%rsi
 104a8da:	call   1042bd0 <myl_native_float_round+0x750>
 104a8df:	cmpw   $0x0,-0xb0(%rbp)
 104a8e7:	je     104a8fd <myl_native_bytes_number_parse+0x88d>
 104a8e9:	xor    %eax,%eax
 104a8eb:	add    $0x3b8,%rsp
 104a8f2:	pop    %rbx
 104a8f3:	pop    %r12
 104a8f5:	pop    %r13
 104a8f7:	pop    %r14
 104a8f9:	pop    %r15
 104a8fb:	pop    %rbp
 104a8fc:	ret
 104a8fd:	vmovq  -0xb8(%rbp),%xmm0
 104a905:	cmpb   $0x0,-0xa8(%rbp)
 104a90c:	je     104a916 <myl_native_bytes_number_parse+0x8a6>
 104a90e:	vpxor  -0x48ef6(%rip),%xmm0,%xmm0        # 1001a20 <__abi_tag+0x1724>
 104a916:	lea    -0x50(%rbp),%rcx
 104a91a:	lea    -0x58(%rbp),%rax
 104a91e:	cmovne %rcx,%rax
 104a922:	movb   $0x1,(%rax)
 104a925:	vmovq  %xmm0,(%r14)
 104a92a:	mov    $0x1,%eax
 104a92f:	jmp    104a8eb <myl_native_bytes_number_parse+0x87b>
 104a931:	mov    %r10,-0x60(%rbp)
 104a935:	cmp    %r10,%rax
 104a938:	jae    104aa9c <myl_native_bytes_number_parse+0xa2c>
 104a93e:	mov    %rcx,-0x38(%rbp)
 104a942:	movzbl (%r15,%rax,1),%ecx
 104a947:	add    $0xd0,%cl
 104a94a:	cmp    $0x9,%cl
 104a94d:	ja     104aa69 <myl_native_bytes_number_parse+0x9f9>
 104a953:	mov    %r14,-0x68(%rbp)
 104a957:	lea    (%r15,%rax,1),%rcx
 104a95b:	mov    %rcx,-0x98(%rbp)
 104a962:	lea    (%r9,%r8,1),%r14
 104a966:	add    $0x2,%r14
 104a96a:	mov    $0x1,%ecx
 104a96f:	xor    %esi,%esi
 104a971:	mov    -0x60(%rbp),%rbx
 104a975:	mov    %rax,%r15
 104a978:	jmp    104a997 <myl_native_bytes_number_parse+0x927>
 104a97a:	inc    %rsi
 104a97d:	inc    %r15
 104a980:	inc    %rcx
 104a983:	dec    %rbx
 104a986:	inc    %r14
 104a989:	lea    0x1(%r12),%rdi
 104a98e:	cmp    %rbx,%rdi
 104a991:	je     104aa79 <myl_native_bytes_number_parse+0xa09>
 104a997:	movzbl -0x1(%r14,%r12,1),%edi
 104a99d:	lea    -0x30(%rdi),%r10d
 104a9a1:	cmp    $0xa,%r10b
 104a9a5:	jb     104a97a <myl_native_bytes_number_parse+0x90a>
 104a9a7:	cmp    $0x5f,%dil
 104a9ab:	jne    104aa8c <myl_native_bytes_number_parse+0xa1c>
 104a9b1:	lea    0x2(%r12),%rdi
 104a9b6:	cmp    %rbx,%rdi
 104a9b9:	je     104aa86 <myl_native_bytes_number_parse+0xa16>
 104a9bf:	movzbl (%r14,%r12,1),%edi
 104a9c4:	add    $0xd0,%dil
 104a9c8:	cmp    $0xa,%dil
 104a9cc:	jb     104a97d <myl_native_bytes_number_parse+0x90d>
 104a9ce:	jmp    104aa8c <myl_native_bytes_number_parse+0xa1c>
 104a9d3:	xor    %r10d,%r10d
 104a9d6:	xor    %eax,%eax
 104a9d8:	mov    %r13,%r11
 104a9db:	mov    $0x0,%edx
 104a9e0:	cmp    %r13,%rcx
 104a9e3:	je     104a8c6 <myl_native_bytes_number_parse+0x856>
 104a9e9:	lea    (%r8,%r9,1),%rax
 104a9ed:	movzbl (%rax,%rcx,1),%edx
 104a9f1:	add    $0xd0,%dl
 104a9f4:	xor    %eax,%eax
 104a9f6:	cmp    $0x9,%dl
 104a9f9:	ja     104aa5f <myl_native_bytes_number_parse+0x9ef>
 104a9fb:	cmp    %r13,%rcx
 104a9fe:	jae    104aa7f <myl_native_bytes_number_parse+0xa0f>
 104aa00:	lea    (%r9,%r8,1),%rdx
 104aa04:	inc    %rdx
 104aa07:	lea    0x1(%rcx),%r8
 104aa0b:	xor    %eax,%eax
 104aa0d:	mov    %r13,%r9
 104aa10:	mov    %rcx,%r15
 104aa13:	jmp    104aa2a <myl_native_bytes_number_parse+0x9ba>
 104aa15:	inc    %r15
 104aa18:	inc    %rax
 104aa1b:	dec    %r9
 104aa1e:	inc    %rdx
 104aa21:	cmp    %r9,%rcx
 104aa24:	je     104abc2 <myl_native_bytes_number_parse+0xb52>
 104aa2a:	movzbl -0x1(%rdx,%rcx,1),%edi
 104aa2f:	lea    -0x30(%rdi),%r11d
 104aa33:	cmp    $0xa,%r11b
 104aa37:	jb     104aa15 <myl_native_bytes_number_parse+0x9a5>
 104aa39:	cmp    $0x5f,%dil
 104aa3d:	jne    104abe9 <myl_native_bytes_number_parse+0xb79>
 104aa43:	cmp    %r9,%r8
 104aa46:	je     104abe3 <myl_native_bytes_number_parse+0xb73>
 104aa4c:	movzbl (%rdx,%rcx,1),%edi
 104aa50:	add    $0xd0,%dil
 104aa54:	cmp    $0xa,%dil
 104aa58:	jb     104aa15 <myl_native_bytes_number_parse+0x9a5>
 104aa5a:	jmp    104abe9 <myl_native_bytes_number_parse+0xb79>
 104aa5f:	mov    %rcx,%r11
 104aa62:	xor    %edx,%edx
 104aa64:	jmp    104a8c6 <myl_native_bytes_number_parse+0x856>
 104aa69:	mov    %rax,%r15
 104aa6c:	mov    -0x60(%rbp),%r13
 104aa70:	mov    -0x38(%rbp),%rcx
 104aa74:	jmp    104a830 <myl_native_bytes_number_parse+0x7c0>
 104aa79:	mov    -0x60(%rbp),%r15
 104aa7d:	jmp    104aa8c <myl_native_bytes_number_parse+0xa1c>
 104aa7f:	xor    %eax,%eax
 104aa81:	jmp    104ac36 <myl_native_bytes_number_parse+0xbc6>
 104aa86:	add    %r12,%rcx
 104aa89:	mov    %rcx,%r15
 104aa8c:	mov    %r15,%r10
 104aa8f:	sub    %rax,%r10
 104aa92:	mov    -0x68(%rbp),%r14
 104aa96:	mov    -0x38(%rbp),%rcx
 104aa9a:	jne    104aaa4 <myl_native_bytes_number_parse+0xa34>
 104aa9c:	mov    %rax,%r15
 104aa9f:	jmp    104ac87 <myl_native_bytes_number_parse+0xc17>
 104aaa4:	lea    -0x2(%r15),%rax
 104aaa8:	cmp    %r12,%rax
 104aaab:	jne    104aab5 <myl_native_bytes_number_parse+0xa45>
 104aaad:	xor    %r12d,%r12d
 104aab0:	jmp    104ab9c <myl_native_bytes_number_parse+0xb2c>
 104aab5:	mov    %r10,%rax
 104aab8:	and    $0xfffffffffffffffe,%rax
 104aabc:	add    %r9,%r12
 104aabf:	lea    (%r8,%r12,1),%rcx
 104aac3:	add    $0x2,%rcx
 104aac7:	xor    %r12d,%r12d
 104aaca:	movabs $0x7fffffffffffffff,%r14
 104aad4:	jmp    104aae6 <myl_native_bytes_number_parse+0xa76>
 104aad6:	xor    %r13d,%r13d
 104aad9:	add    $0x2,%r12
 104aadd:	cmp    %r12,%rax
 104aae0:	je     104ab8a <myl_native_bytes_number_parse+0xb1a>
 104aae6:	movzbl -0x1(%rcx,%r12,1),%ebx
 104aaec:	cmp    $0x5f,%bl
 104aaef:	je     104ab37 <myl_native_bytes_number_parse+0xac7>
 104aaf1:	cmp    $0x30,%bl
 104aaf4:	jne    104ab01 <myl_native_bytes_number_parse+0xa91>
 104aaf6:	test   $0x1,%r13b
 104aafa:	jne    104ab01 <myl_native_bytes_number_parse+0xa91>
 104aafc:	xor    %r13d,%r13d
 104aaff:	jmp    104ab37 <myl_native_bytes_number_parse+0xac7>
 104ab01:	cmp    $0x2ff,%r11
 104ab08:	ja     104ab1a <myl_native_bytes_number_parse+0xaaa>
 104ab0a:	mov    %bl,-0x3d8(%rbp,%r11,1)
 104ab12:	inc    %r11
 104ab15:	mov    $0x1,%r13b
 104ab18:	jmp    104ab37 <myl_native_bytes_number_parse+0xac7>
 104ab1a:	cmp    $0x30,%bl
 104ab1d:	setne  %dil
 104ab21:	inc    %rdx
 104ab24:	cmovo  %r14,%rdx
 104ab28:	or     -0x30(%rbp),%dil
 104ab2c:	and    $0x1,%dil
 104ab30:	mov    $0x1,%r13b
 104ab33:	mov    %rdi,-0x30(%rbp)
 104ab37:	movzbl (%rcx,%r12,1),%ebx
 104ab3c:	cmp    $0x5f,%bl
 104ab3f:	je     104aad9 <myl_native_bytes_number_parse+0xa69>
 104ab41:	cmp    $0x30,%bl
 104ab44:	jne    104ab4c <myl_native_bytes_number_parse+0xadc>
 104ab46:	test   $0x1,%r13b
 104ab4a:	je     104aad6 <myl_native_bytes_number_parse+0xa66>
 104ab4c:	cmp    $0x300,%r11
 104ab53:	jae    104ab68 <myl_native_bytes_number_parse+0xaf8>
 104ab55:	mov    %bl,-0x3d8(%rbp,%r11,1)
 104ab5d:	inc    %r11
 104ab60:	mov    $0x1,%r13b
 104ab63:	jmp    104aad9 <myl_native_bytes_number_parse+0xa69>
 104ab68:	cmp    $0x30,%bl
 104ab6b:	setne  %dil
 104ab6f:	inc    %rdx
 104ab72:	cmovo  %r14,%rdx
 104ab76:	or     -0x30(%rbp),%dil
 104ab7a:	and    $0x1,%dil
 104ab7e:	mov    $0x1,%r13b
 104ab81:	mov    %rdi,-0x30(%rbp)
 104ab85:	jmp    104aad9 <myl_native_bytes_number_parse+0xa69>
 104ab8a:	test   $0x1,%r10b
 104ab8e:	mov    -0x68(%rbp),%r14
 104ab92:	mov    -0x38(%rbp),%rcx
 104ab96:	je     104ac74 <myl_native_bytes_number_parse+0xc04>
 104ab9c:	mov    -0x98(%rbp),%rax
 104aba3:	movzbl (%rax,%r12,1),%eax
 104aba8:	cmp    $0x5f,%al
 104abaa:	je     104ac74 <myl_native_bytes_number_parse+0xc04>
 104abb0:	cmp    $0x30,%al
 104abb2:	jne    104abc7 <myl_native_bytes_number_parse+0xb57>
 104abb4:	test   $0x1,%r13b
 104abb8:	jne    104abc7 <myl_native_bytes_number_parse+0xb57>
 104abba:	xor    %r13d,%r13d
 104abbd:	jmp    104ac74 <myl_native_bytes_number_parse+0xc04>
 104abc2:	mov    %r13,%r15
 104abc5:	jmp    104abe9 <myl_native_bytes_number_parse+0xb79>
 104abc7:	cmp    $0x300,%r11
 104abce:	jae    104ac4b <myl_native_bytes_number_parse+0xbdb>
 104abd0:	mov    %al,-0x3d8(%rbp,%r11,1)
 104abd8:	inc    %r11
 104abdb:	mov    $0x1,%r13b
 104abde:	jmp    104ac74 <myl_native_bytes_number_parse+0xc04>
 104abe3:	add    %rcx,%rax
 104abe6:	mov    %rax,%r15
 104abe9:	xor    %eax,%eax
 104abeb:	cmp    %rcx,%r15
 104abee:	jne    104abfa <myl_native_bytes_number_parse+0xb8a>
 104abf0:	jmp    104ac36 <myl_native_bytes_number_parse+0xbc6>
 104abf2:	inc    %rcx
 104abf5:	cmp    %rcx,%r15
 104abf8:	je     104ac33 <myl_native_bytes_number_parse+0xbc3>
 104abfa:	mov    -0xa0(%rbp),%rdx
 104ac01:	movzbl (%rdx,%rcx,1),%edx
 104ac05:	cmp    $0x5f,%rdx
 104ac09:	je     104abf2 <myl_native_bytes_number_parse+0xb82>
 104ac0b:	imul   $0xa,%rax,%rax
 104ac0f:	jo     104ac19 <myl_native_bytes_number_parse+0xba9>
 104ac11:	add    $0xffffffd0,%edx
 104ac14:	add    %rdx,%rax
 104ac17:	jno    104abf2 <myl_native_bytes_number_parse+0xb82>
 104ac19:	movabs $0x8000000000000000,%rax
 104ac23:	lea    -0x1(%rax),%rdx
 104ac27:	test   %r10b,%r10b
 104ac2a:	cmovne %rax,%rdx
 104ac2e:	jmp    104a898 <myl_native_bytes_number_parse+0x828>
 104ac33:	mov    %r15,%rcx
 104ac36:	mov    %rax,%rdx
 104ac39:	neg    %rdx
 104ac3c:	test   %r10b,%r10b
 104ac3f:	cmove  %rax,%rdx
 104ac43:	mov    %rcx,%r15
 104ac46:	jmp    104a898 <myl_native_bytes_number_parse+0x828>
 104ac4b:	cmp    $0x30,%al
 104ac4d:	setne  %al
 104ac50:	mov    %rdx,%rcx
 104ac53:	inc    %rcx
 104ac56:	movabs $0x7fffffffffffffff,%rdx
 104ac60:	cmovno %rcx,%rdx
 104ac64:	mov    -0x38(%rbp),%rcx
 104ac68:	or     -0x30(%rbp),%al
 104ac6b:	and    $0x1,%al
 104ac6d:	mov    $0x1,%r13b
 104ac70:	mov    %rax,-0x30(%rbp)
 104ac74:	mov    %r13b,-0x70(%rbp)
 104ac78:	mov    %r11,-0x80(%rbp)
 104ac7c:	mov    %rdx,-0x78(%rbp)
 104ac80:	mov    -0x30(%rbp),%rax
 104ac84:	mov    %al,-0x6f(%rbp)
 104ac87:	mov    -0x60(%rbp),%r13
 104ac8b:	jmp    104a830 <myl_native_bytes_number_parse+0x7c0>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
