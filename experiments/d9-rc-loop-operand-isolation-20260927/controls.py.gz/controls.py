from pathlib import Path
import os,subprocess,json,hashlib,resource
r=Path.cwd();w=r/'.tmp-rc/loop-operands';s=w/'controls.my'
e={k:v for k,v in os.environ.items() if not k.startswith('MYLANG_') and k!='LD_PRELOAD'};e['TMPDIR']=str(r/'.tmp-rc/tmp')
cs={'before':r/'.tmp-rc/install-loop-guard-pc/bin/mylang','after':r/'.tmp-rc/install-loop-operands-prototype/bin/mylang'}
base=(r/'tests/lang/rc_loop_operand_isolation.my').read_text().split('def main(')[0]
overflow=base.split('def real_iterator')[0].replace('def scan(', 'def overflow(').replace('    hits = 0','    hits = 9223372036854775807')
heap='''def heap(values: [4096]int, count: int) -> int:
    padding = replace(values, 0, 7)
    data = b"mylang micro benchmark kernel payload 0123456789 abcdefghijklmno"
    hits = 0
    for i in range(count):
        if data[i] == 109:
            hits += 1
    return hits + padding[0]
def descend(depth: int) -> int:
    result = scan(64, 1)
    return result + descend(depth + 1)
'''
main='''def main(args: list[str], out: Stream) -> int:
    if len(args) == 0:
        assert test_isolated_words_cover_zero_both_branches_and_outer_reentry()
        assert test_isolated_words_keep_real_iterator_tokens_and_snapshots()
        assert test_isolated_words_keep_inherited_arena_lifetime()
        out.print(12)
    elif args[0] == "bounds":
        out.print(scan(65, 1))
    elif args[0] == "overflow":
        out.print(overflow(1, 1))
    elif args[0] == "frames":
        out.print(descend(0))
    else:
        values: [4096]int = [ZEROS]
        count = 64
        if len(args) > 1:
            count = 65
        out.print(heap(values, count))
    return 0
'''.replace('ZEROS',','.join(['0']*4096))
s.write_text(base+overflow+heap+main)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
d={'source':{'path':str(s),'sha256':sha(s)},'compilers':{k:{'path':str(c),'sha256':sha(c)} for k,c in cs.items()},'emission':[],'builds':[],'runs':[]}
def save():(w/'controls.json').write_text(json.dumps(d,indent=2)+'\n')
def counts(p):
 lines=[x.removeprefix('MYLANG_RC_COUNTS ') for x in p.stderr.splitlines() if x.startswith('MYLANG_RC_COUNTS ')];assert len(lines)==1,p.stderr
 c=json.loads(lines[0]);assert c['heap_allocate']==c['retire'] and c['hold_acquire']==c['hold_release'] and c['owner_acquire']+c['heap_allocate']==c['owner_release'],c
 return c
def smallstack():resource.setrlimit(resource.RLIMIT_STACK,(262144,262144))
for side,c in cs.items():
 cmd=[str(r/'scripts/build-slot.sh'),'build',str(c),'emit-qbe',str(s),'--rc-runtime','--drop-step-checks','--drop-frame-checks','--drop-debug'];p=subprocess.run(cmd,env=e,text=True,capture_output=True);assert not p.returncode,p.stderr
 (w/(side+'-controls-emission.json')).write_text(p.stdout);m=json.loads(p.stdout);f={x['name']:x['il'] for x in m['functions']};assert 'myl_qbe_frame_allocate' in f['heap'] and 'RC-LOOP-OPERANDS-ISOLATED' not in f['heap'];assert f['scan'].count('RC-LOOP-OPERANDS-ISOLATED')==(1 if side=='after' else 0)
 d['emission'].append(dict(side=side,command=cmd,hash=hashlib.sha256(p.stdout.encode()).hexdigest(),scan_isolated=f['scan'].count('RC-LOOP-OPERANDS-ISOLATED'),heap_isolated=f['heap'].count('RC-LOOP-OPERANDS-ISOLATED'),iterator_isolated=f['real_iterator'].count('RC-LOOP-OPERANDS-ISOLATED')));save()
 for backend in ['qbe','llvm']:
  for accounted in [False,True]:
   b=w/f'control-{side}-{backend}-{int(accounted)}';cmd=[str(r/'scripts/build-slot.sh'),'build',str(c),'build',str(s),'-o',str(b),'--cache-dir='+str(w/f'cache-{side}'),'--backend='+backend,'--mode=ReleaseFast','--rc-runtime=stats']
   if backend=='llvm':cmd+=['--llvm-opt=3','--lto=full']
   if accounted:cmd+=['--step-accounting','--max-frames=64']
   p=subprocess.run(cmd,env=e,text=True,capture_output=True);row=dict(side=side,backend=backend,accounted=accounted,command=cmd,status=p.returncode,stdout=p.stdout,stderr=p.stderr);d['builds'].append(row);save();assert not p.returncode,row
   row['binary_sha256']=sha(b);row['manifest']=json.loads(Path(str(b)+'.qbe-manifest.json').read_text());assert row['manifest']['backend']==backend;save()
   runs=[('steps',[],'--max-steps=100','R_STEP_LIMIT'),('frames',['frames'],'--max-frames=8','R_FRAME_LIMIT')] if accounted else [('positive',[],'',None),('bounds',['bounds'],'','R_LIST_BOUNDS'),('overflow',['overflow'],'','R_OVERFLOW'),('heap',['heap'],'',None),('heap-bounds',['heap','fail'],'','R_LIST_BOUNDS'),('floor',['frames'],'','R_FRAME_LIMIT')]
   for name,args,opt,expected in runs:
    env=dict(e);env['MYLANG_OPTIONS']=opt
    p=subprocess.run([str(b)]+args,env=env,text=True,capture_output=True,timeout=60,preexec_fn=smallstack if name=='floor' else None)
    run=dict(side=side,backend=backend,case=name,accounted=accounted,args=args,options=opt,status=p.returncode,stdout=p.stdout,stderr=p.stderr);d['runs'].append(run);save()
    assert p.returncode==(1 if expected else 0),run
    if expected:assert expected in p.stderr,run
    elif name=='positive':assert p.stdout=='12\n',run
    elif name=='heap':assert p.stdout=='11\n',run
    run['counts']=counts(p);save();print(side,backend,name,'pass',flush=True)
for a in d['runs']:
 if a['side']!='before':continue
 b=next(x for x in d['runs'] if x['side']=='after' and all(x[k]==a[k] for k in ['backend','case','accounted']))
 trace=lambda row:'\n'.join(x for x in row['stderr'].splitlines() if not x.startswith('MYLANG_RC_COUNTS '))
 assert (a['status'],a['stdout'],trace(a))==(b['status'],b['stdout'],trace(b)),(a,b)
 if a['case']!='floor':assert a['counts']==b['counts'],(a,b)
print('all32 paired controls pass',flush=True)
