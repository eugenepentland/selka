
/home/epentland/ai/canopy/mylang-worktrees/d9-rc-compiler-astra/.tmp-rc/loop-operands/before-qbe-rc:     file format elf64-x86-64


Disassembly of section .text:

0000000001007150 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605>:
 1007150:	f3 0f 1e fa          	endbr64
 1007154:	55                   	push   %rbp
 1007155:	48 89 e5             	mov    %rsp,%rbp
 1007158:	48 81 ec 38 02 00 00 	sub    $0x238,%rsp
 100715f:	53                   	push   %rbx
 1007160:	41 54                	push   %r12
 1007162:	41 55                	push   %r13
 1007164:	41 56                	push   %r14
 1007166:	41 57                	push   %r15
 1007168:	48 89 75 80          	mov    %rsi,-0x80(%rbp)
 100716c:	48 c7 85 48 ff ff ff 	movq   $0x0,-0xb8(%rbp)
 1007173:	00 00 00 00 
 1007177:	48 c7 85 50 ff ff ff 	movq   $0x0,-0xb0(%rbp)
 100717e:	00 00 00 00 
 1007182:	48 c7 85 58 ff ff ff 	movq   $0x0,-0xa8(%rbp)
 1007189:	00 00 00 00 
 100718d:	48 c7 85 60 ff ff ff 	movq   $0x0,-0xa0(%rbp)
 1007194:	00 00 00 00 
 1007198:	48 c7 85 68 ff ff ff 	movq   $0x0,-0x98(%rbp)
 100719f:	00 00 00 00 
 10071a3:	48 89 fb             	mov    %rdi,%rbx
 10071a6:	e8 05 21 00 00       	call   10092b0 <myl_qbe_heap>
 10071ab:	48 89 df             	mov    %rbx,%rdi
 10071ae:	48 89 c3             	mov    %rax,%rbx
 10071b1:	49 89 fc             	mov    %rdi,%r12
 10071b4:	e8 67 3d 00 00       	call   100af20 <myl_qbe_region_mark>
 10071b9:	4c 89 e7             	mov    %r12,%rdi
 10071bc:	49 89 c7             	mov    %rax,%r15
 10071bf:	4c 89 7d c0          	mov    %r15,-0x40(%rbp)
 10071c3:	ba 40 00 00 00       	mov    $0x40,%edx
 10071c8:	be 00 00 00 00       	mov    $0x0,%esi
 10071cd:	49 89 fc             	mov    %rdi,%r12
 10071d0:	48 8d bd f0 fe ff ff 	lea    -0x110(%rbp),%rdi
 10071d7:	e8 b4 1d 01 00       	call   1018f90 <compiler_rt.fastMemset>
 10071dc:	4c 89 e7             	mov    %r12,%rdi
 10071df:	48 8d 05 ea 4b 01 00 	lea    0x14bea(%rip),%rax        # 101bdd0 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527>
 10071e6:	48 89 85 f0 fd ff ff 	mov    %rax,-0x210(%rbp)
 10071ed:	c7 85 08 fe ff ff 02 	movl   $0x2,-0x1f8(%rbp)
 10071f4:	00 00 00 
 10071f7:	48 8d 85 48 ff ff ff 	lea    -0xb8(%rbp),%rax
 10071fe:	48 89 85 f8 fd ff ff 	mov    %rax,-0x208(%rbp)
 1007205:	48 8d 85 f0 fe ff ff 	lea    -0x110(%rbp),%rax
 100720c:	48 89 85 00 fe ff ff 	mov    %rax,-0x200(%rbp)
 1007213:	48 8d 85 f0 fd ff ff 	lea    -0x210(%rbp),%rax
 100721a:	48 89 c6             	mov    %rax,%rsi
 100721d:	48 83 c6 20          	add    $0x20,%rsi
 1007221:	48 89 75 f0          	mov    %rsi,-0x10(%rbp)
 1007225:	48 8d 05 a4 4b 01 00 	lea    0x14ba4(%rip),%rax        # 101bdd0 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527>
 100722c:	48 89 85 10 fe ff ff 	mov    %rax,-0x1f0(%rbp)
 1007233:	c7 85 28 fe ff ff 02 	movl   $0x2,-0x1d8(%rbp)
 100723a:	00 00 00 
 100723d:	48 8d 85 50 ff ff ff 	lea    -0xb0(%rbp),%rax
 1007244:	48 89 85 18 fe ff ff 	mov    %rax,-0x1e8(%rbp)
 100724b:	48 8d 85 f0 fe ff ff 	lea    -0x110(%rbp),%rax
 1007252:	48 83 c0 08          	add    $0x8,%rax
 1007256:	48 89 45 e8          	mov    %rax,-0x18(%rbp)
 100725a:	48 89 85 20 fe ff ff 	mov    %rax,-0x1e0(%rbp)
 1007261:	48 8d 85 f0 fd ff ff 	lea    -0x210(%rbp),%rax
 1007268:	48 89 c6             	mov    %rax,%rsi
 100726b:	48 83 c6 40          	add    $0x40,%rsi
 100726f:	48 89 75 d8          	mov    %rsi,-0x28(%rbp)
 1007273:	48 8d 05 e6 4a 01 00 	lea    0x14ae6(%rip),%rax        # 101bd60 <myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7>
 100727a:	48 89 85 30 fe ff ff 	mov    %rax,-0x1d0(%rbp)
 1007281:	c7 85 48 fe ff ff 02 	movl   $0x2,-0x1b8(%rbp)
 1007288:	00 00 00 
 100728b:	48 8d 85 58 ff ff ff 	lea    -0xa8(%rbp),%rax
 1007292:	48 89 85 38 fe ff ff 	mov    %rax,-0x1c8(%rbp)
 1007299:	48 8d 85 f0 fe ff ff 	lea    -0x110(%rbp),%rax
 10072a0:	49 89 c6             	mov    %rax,%r14
 10072a3:	49 83 c6 10          	add    $0x10,%r14
 10072a7:	4c 89 b5 40 fe ff ff 	mov    %r14,-0x1c0(%rbp)
 10072ae:	48 8d 85 f0 fd ff ff 	lea    -0x210(%rbp),%rax
 10072b5:	48 89 c6             	mov    %rax,%rsi
 10072b8:	48 83 c6 60          	add    $0x60,%rsi
 10072bc:	48 89 75 c8          	mov    %rsi,-0x38(%rbp)
 10072c0:	48 8d 05 79 4b 01 00 	lea    0x14b79(%rip),%rax        # 101be40 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9>
 10072c7:	48 89 85 50 fe ff ff 	mov    %rax,-0x1b0(%rbp)
 10072ce:	c7 85 68 fe ff ff 02 	movl   $0x2,-0x198(%rbp)
 10072d5:	00 00 00 
 10072d8:	48 8d 85 60 ff ff ff 	lea    -0xa0(%rbp),%rax
 10072df:	48 89 85 58 fe ff ff 	mov    %rax,-0x1a8(%rbp)
 10072e6:	48 8d 85 f0 fe ff ff 	lea    -0x110(%rbp),%rax
 10072ed:	49 89 c4             	mov    %rax,%r12
 10072f0:	49 83 c4 18          	add    $0x18,%r12
 10072f4:	4c 89 65 d0          	mov    %r12,-0x30(%rbp)
 10072f8:	4c 89 a5 60 fe ff ff 	mov    %r12,-0x1a0(%rbp)
 10072ff:	48 8d 85 f0 fd ff ff 	lea    -0x210(%rbp),%rax
 1007306:	48 89 c6             	mov    %rax,%rsi
 1007309:	48 81 c6 80 00 00 00 	add    $0x80,%rsi
 1007310:	48 89 75 a8          	mov    %rsi,-0x58(%rbp)
 1007314:	48 8d 05 25 4b 01 00 	lea    0x14b25(%rip),%rax        # 101be40 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9>
 100731b:	48 89 85 70 fe ff ff 	mov    %rax,-0x190(%rbp)
 1007322:	c7 85 88 fe ff ff 02 	movl   $0x2,-0x178(%rbp)
 1007329:	00 00 00 
 100732c:	48 8d 85 68 ff ff ff 	lea    -0x98(%rbp),%rax
 1007333:	48 89 85 78 fe ff ff 	mov    %rax,-0x188(%rbp)
 100733a:	48 8d 85 f0 fe ff ff 	lea    -0x110(%rbp),%rax
 1007341:	49 89 c4             	mov    %rax,%r12
 1007344:	49 83 c4 20          	add    $0x20,%r12
 1007348:	4c 89 65 b8          	mov    %r12,-0x48(%rbp)
 100734c:	4c 89 a5 80 fe ff ff 	mov    %r12,-0x180(%rbp)
 1007353:	48 8d 85 f0 fd ff ff 	lea    -0x210(%rbp),%rax
 100735a:	49 89 c5             	mov    %rax,%r13
 100735d:	49 81 c5 a0 00 00 00 	add    $0xa0,%r13
 1007364:	48 8d 05 55 b0 ff ff 	lea    -0x4fab(%rip),%rax        # 10023c0 <myl_t_385cfdbc00ec32031699460779c15099b2bba3cad0e440fffb08e10df0acb9e1>
 100736b:	48 89 85 90 fe ff ff 	mov    %rax,-0x170(%rbp)
 1007372:	c7 85 a8 fe ff ff 00 	movl   $0x0,-0x158(%rbp)
 1007379:	00 00 00 
 100737c:	48 8d 85 30 ff ff ff 	lea    -0xd0(%rbp),%rax
 1007383:	48 89 85 98 fe ff ff 	mov    %rax,-0x168(%rbp)
 100738a:	48 8d 85 f0 fe ff ff 	lea    -0x110(%rbp),%rax
 1007391:	48 83 c0 28          	add    $0x28,%rax
 1007395:	48 89 85 a0 fe ff ff 	mov    %rax,-0x160(%rbp)
 100739c:	48 8d 05 1d b0 ff ff 	lea    -0x4fe3(%rip),%rax        # 10023c0 <myl_t_385cfdbc00ec32031699460779c15099b2bba3cad0e440fffb08e10df0acb9e1>
 10073a3:	48 89 85 b0 fe ff ff 	mov    %rax,-0x150(%rbp)
 10073aa:	c7 85 c8 fe ff ff 00 	movl   $0x0,-0x138(%rbp)
 10073b1:	00 00 00 
 10073b4:	48 8d 85 38 ff ff ff 	lea    -0xc8(%rbp),%rax
 10073bb:	48 89 85 b8 fe ff ff 	mov    %rax,-0x148(%rbp)
 10073c2:	48 8d 85 f0 fe ff ff 	lea    -0x110(%rbp),%rax
 10073c9:	48 83 c0 30          	add    $0x30,%rax
 10073cd:	48 89 85 c0 fe ff ff 	mov    %rax,-0x140(%rbp)
 10073d4:	48 8d 05 e5 af ff ff 	lea    -0x501b(%rip),%rax        # 10023c0 <myl_t_385cfdbc00ec32031699460779c15099b2bba3cad0e440fffb08e10df0acb9e1>
 10073db:	48 89 85 d0 fe ff ff 	mov    %rax,-0x130(%rbp)
 10073e2:	c7 85 e8 fe ff ff 00 	movl   $0x0,-0x118(%rbp)
 10073e9:	00 00 00 
 10073ec:	48 8d 85 40 ff ff ff 	lea    -0xc0(%rbp),%rax
 10073f3:	48 89 85 d8 fe ff ff 	mov    %rax,-0x128(%rbp)
 10073fa:	48 8d 85 f0 fe ff ff 	lea    -0x110(%rbp),%rax
 1007401:	48 83 c0 38          	add    $0x38,%rax
 1007405:	48 89 85 e0 fe ff ff 	mov    %rax,-0x120(%rbp)
 100740c:	b9 08 00 00 00       	mov    $0x8,%ecx
 1007411:	48 8d 95 f0 fd ff ff 	lea    -0x210(%rbp),%rdx
 1007418:	48 8d b5 d0 fd ff ff 	lea    -0x230(%rbp),%rsi
 100741f:	49 89 fc             	mov    %rdi,%r12
 1007422:	e8 f9 15 00 00       	call   1008a20 <myl_qbe_rc_frame_enter>
 1007427:	4c 89 e7             	mov    %r12,%rdi
 100742a:	49 89 fc             	mov    %rdi,%r12
 100742d:	e8 8e 1e 00 00       	call   10092c0 <myl_qbe_require_step_accounting>
 1007432:	4c 89 e7             	mov    %r12,%rdi
 1007435:	49 89 fc             	mov    %rdi,%r12
 1007438:	e8 e3 1e 00 00       	call   1009320 <myl_qbe_require_frame_accounting>
 100743d:	4c 89 e7             	mov    %r12,%rdi
 1007440:	48 c7 85 70 ff ff ff 	movq   $0x0,-0x90(%rbp)
 1007447:	00 00 00 00 
 100744b:	ba 00 00 00 00       	mov    $0x0,%edx
 1007450:	48 8d 35 89 ae ff ff 	lea    -0x5177(%rip),%rsi        # 10022e0 <myl_t_1a91deb3742283487d66c3b500f6effd7ef1170e6d4b4368fe9ec3c3f0354fda>
 1007457:	49 89 fc             	mov    %rdi,%r12
 100745a:	48 89 df             	mov    %rbx,%rdi
 100745d:	e8 0e 84 00 00       	call   100f870 <myl_native_list_new>
 1007462:	4c 89 e7             	mov    %r12,%rdi
 1007465:	83 f8 00             	cmp    $0x0,%eax
 1007468:	75 0a                	jne    1007474 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x324>
 100746a:	48 89 fb             	mov    %rdi,%rbx
 100746d:	e8 1e 1c 00 00       	call   1009090 <myl_qbe_fail_allocation>
 1007472:	0f 0b                	ud2
 1007474:	48 87 fb             	xchg   %rdi,%rbx
 1007477:	48 89 85 70 ff ff ff 	mov    %rax,-0x90(%rbp)
 100747e:	48 8b 8d 70 ff ff ff 	mov    -0x90(%rbp),%rcx
 1007485:	48 89 8d 38 ff ff ff 	mov    %rcx,-0xc8(%rbp)
 100748c:	48 8d 0d 3d 49 01 00 	lea    0x1493d(%rip),%rcx        # 101bdd0 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527>
 1007493:	48 89 8d b0 fe ff ff 	mov    %rcx,-0x150(%rbp)
 100749a:	c7 85 c8 fe ff ff 02 	movl   $0x2,-0x138(%rbp)
 10074a1:	00 00 00 
 10074a4:	c7 85 20 ff ff ff 01 	movl   $0x1,-0xe0(%rbp)
 10074ab:	00 00 00 
 10074ae:	48 8b 8d 38 ff ff ff 	mov    -0xc8(%rbp),%rcx
 10074b5:	48 89 8d 30 ff ff ff 	mov    %rcx,-0xd0(%rbp)
 10074bc:	48 8d 0d 0d 49 01 00 	lea    0x1490d(%rip),%rcx        # 101bdd0 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527>
 10074c3:	48 89 8d 90 fe ff ff 	mov    %rcx,-0x170(%rbp)
 10074ca:	c7 85 a8 fe ff ff 02 	movl   $0x2,-0x158(%rbp)
 10074d1:	00 00 00 
 10074d4:	c7 85 a8 fe ff ff 02 	movl   $0x2,-0x158(%rbp)
 10074db:	00 00 00 
 10074de:	c7 85 20 ff ff ff 00 	movl   $0x0,-0xe0(%rbp)
 10074e5:	00 00 00 
 10074e8:	c7 85 18 ff ff ff 01 	movl   $0x1,-0xe8(%rbp)
 10074ef:	00 00 00 
 10074f2:	48 89 85 70 ff ff ff 	mov    %rax,-0x90(%rbp)
 10074f9:	48 8d 95 38 ff ff ff 	lea    -0xc8(%rbp),%rdx
 1007500:	48 8d 8d 70 ff ff ff 	lea    -0x90(%rbp),%rcx
 1007507:	48 29 d1             	sub    %rdx,%rcx
 100750a:	48 8d b5 70 ff ff ff 	lea    -0x90(%rbp),%rsi
 1007511:	48 8d 95 38 ff ff ff 	lea    -0xc8(%rbp),%rdx
 1007518:	48 29 f2             	sub    %rsi,%rdx
 100751b:	48 83 f9 08          	cmp    $0x8,%rcx
 100751f:	0f 92 c1             	setb   %cl
 1007522:	0f b6 c9             	movzbl %cl,%ecx
 1007525:	89 4d b0             	mov    %ecx,-0x50(%rbp)
 1007528:	48 83 fa 08          	cmp    $0x8,%rdx
 100752c:	41 0f 92 c1          	setb   %r9b
 1007530:	45 0f b6 c9          	movzbl %r9b,%r9d
 1007534:	44 89 4d b4          	mov    %r9d,-0x4c(%rbp)
 1007538:	44 09 c9             	or     %r9d,%ecx
 100753b:	75 59                	jne    1007596 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x446>
 100753d:	48 83 f8 00          	cmp    $0x0,%rax
 1007541:	74 1a                	je     100755d <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x40d>
 1007543:	48 83 e8 10          	sub    $0x10,%rax
 1007547:	48 8b 00             	mov    (%rax),%rax
 100754a:	48 b9 01 00 00 00 00 	movabs $0x5000000000000001,%rcx
 1007551:	00 00 50 
 1007554:	48 21 c8             	and    %rcx,%rax
 1007557:	48 83 f8 00          	cmp    $0x0,%rax
 100755b:	75 39                	jne    1007596 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x446>
 100755d:	48 8b 85 70 ff ff ff 	mov    -0x90(%rbp),%rax
 1007564:	48 89 85 38 ff ff ff 	mov    %rax,-0xc8(%rbp)
 100756b:	ba 08 00 00 00       	mov    $0x8,%edx
 1007570:	be 00 00 00 00       	mov    $0x0,%esi
 1007575:	49 89 fc             	mov    %rdi,%r12
 1007578:	48 8d bd 70 ff ff ff 	lea    -0x90(%rbp),%rdi
 100757f:	e8 0c 1a 01 00       	call   1018f90 <compiler_rt.fastMemset>
 1007584:	4d 89 f8             	mov    %r15,%r8
 1007587:	4c 89 e7             	mov    %r12,%rdi
 100758a:	44 8b 4d b4          	mov    -0x4c(%rbp),%r9d
 100758e:	8b 4d b0             	mov    -0x50(%rbp),%ecx
 1007591:	4d 89 c7             	mov    %r8,%r15
 1007594:	eb 4c                	jmp    10075e2 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x492>
 1007596:	4d 89 f8             	mov    %r15,%r8
 1007599:	4d 89 c7             	mov    %r8,%r15
 100759c:	48 8d 8d 70 ff ff ff 	lea    -0x90(%rbp),%rcx
 10075a3:	48 8d 95 38 ff ff ff 	lea    -0xc8(%rbp),%rdx
 10075aa:	48 8d 35 1f 48 01 00 	lea    0x1481f(%rip),%rsi        # 101bdd0 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527>
 10075b1:	49 89 fc             	mov    %rdi,%r12
 10075b4:	e8 e7 10 01 00       	call   10186a0 <myl_rc_native_take>
 10075b9:	4c 89 e7             	mov    %r12,%rdi
 10075bc:	44 8b 4d b4          	mov    -0x4c(%rbp),%r9d
 10075c0:	8b 4d b0             	mov    -0x50(%rbp),%ecx
 10075c3:	83 f8 00             	cmp    $0x0,%eax
 10075c6:	75 1a                	jne    10075e2 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x492>
 10075c8:	e8 d3 92 00 00       	call   10108a0 <myl_rc_take_failure>
 10075cd:	48 89 df             	mov    %rbx,%rdi
 10075d0:	89 c6                	mov    %eax,%esi
 10075d2:	48 89 fb             	mov    %rdi,%rbx
 10075d5:	e8 56 13 00 00       	call   1008930 <myl_qbe_rc_status>
 10075da:	48 89 df             	mov    %rbx,%rdi
 10075dd:	e9 b3 0b 00 00       	jmp    1008195 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1045>
 10075e2:	c7 85 18 ff ff ff 00 	movl   $0x0,-0xe8(%rbp)
 10075e9:	00 00 00 
 10075ec:	48 8d 05 dd 47 01 00 	lea    0x147dd(%rip),%rax        # 101bdd0 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527>
 10075f3:	48 89 85 b0 fe ff ff 	mov    %rax,-0x150(%rbp)
 10075fa:	c7 85 c8 fe ff ff 02 	movl   $0x2,-0x138(%rbp)
 1007601:	00 00 00 
 1007604:	c7 85 20 ff ff ff 01 	movl   $0x1,-0xe0(%rbp)
 100760b:	00 00 00 
 100760e:	8b 85 f0 fe ff ff    	mov    -0x110(%rbp),%eax
 1007614:	83 f8 00             	cmp    $0x0,%eax
 1007617:	75 05                	jne    100761e <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x4ce>
 1007619:	4d 89 f8             	mov    %r15,%r8
 100761c:	eb 1f                	jmp    100763d <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x4ed>
 100761e:	48 8d b5 f0 fd ff ff 	lea    -0x210(%rbp),%rsi
 1007625:	49 89 fc             	mov    %rdi,%r12
 1007628:	48 89 df             	mov    %rbx,%rdi
 100762b:	e8 d0 14 00 00       	call   1008b00 <myl_qbe_rc_slot_drop>
 1007630:	4d 89 f8             	mov    %r15,%r8
 1007633:	4c 89 e7             	mov    %r12,%rdi
 1007636:	44 8b 4d b4          	mov    -0x4c(%rbp),%r9d
 100763a:	8b 4d b0             	mov    -0x50(%rbp),%ecx
 100763d:	48 8b 85 38 ff ff ff 	mov    -0xc8(%rbp),%rax
 1007644:	48 89 85 48 ff ff ff 	mov    %rax,-0xb8(%rbp)
 100764b:	c7 85 20 ff ff ff 00 	movl   $0x0,-0xe0(%rbp)
 1007652:	00 00 00 
 1007655:	48 8d 05 74 47 01 00 	lea    0x14774(%rip),%rax        # 101bdd0 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527>
 100765c:	48 89 85 f0 fd ff ff 	mov    %rax,-0x210(%rbp)
 1007663:	c7 85 08 fe ff ff 02 	movl   $0x2,-0x1f8(%rbp)
 100766a:	00 00 00 
 100766d:	48 8d 85 48 ff ff ff 	lea    -0xb8(%rbp),%rax
 1007674:	48 89 85 f8 fd ff ff 	mov    %rax,-0x208(%rbp)
 100767b:	48 8d 85 f0 fe ff ff 	lea    -0x110(%rbp),%rax
 1007682:	48 89 85 00 fe ff ff 	mov    %rax,-0x200(%rbp)
 1007689:	8b 85 c8 fe ff ff    	mov    -0x138(%rbp),%eax
 100768f:	89 85 08 fe ff ff    	mov    %eax,-0x1f8(%rbp)
 1007695:	c7 85 f0 fe ff ff 01 	movl   $0x1,-0x110(%rbp)
 100769c:	00 00 00 
 100769f:	48 8b 85 48 ff ff ff 	mov    -0xb8(%rbp),%rax
 10076a6:	48 89 85 70 ff ff ff 	mov    %rax,-0x90(%rbp)
 10076ad:	8b 95 18 ff ff ff    	mov    -0xe8(%rbp),%edx
 10076b3:	8b b5 a8 fe ff ff    	mov    -0x158(%rbp),%esi
 10076b9:	83 e6 18             	and    $0x18,%esi
 10076bc:	83 fe 00             	cmp    $0x0,%esi
 10076bf:	40 0f 94 c6          	sete   %sil
 10076c3:	40 0f b6 f6          	movzbl %sil,%esi
 10076c7:	85 d6                	test   %edx,%esi
 10076c9:	0f 85 9b 00 00 00    	jne    100776a <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x61a>
 10076cf:	4d 89 c7             	mov    %r8,%r15
 10076d2:	48 8d 8d 70 ff ff ff 	lea    -0x90(%rbp),%rcx
 10076d9:	48 8d 95 38 ff ff ff 	lea    -0xc8(%rbp),%rdx
 10076e0:	48 8d 35 e9 46 01 00 	lea    0x146e9(%rip),%rsi        # 101bdd0 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527>
 10076e7:	49 89 fc             	mov    %rdi,%r12
 10076ea:	e8 b1 14 01 00       	call   1018ba0 <myl_rc_native_retain>
 10076ef:	4c 89 e7             	mov    %r12,%rdi
 10076f2:	89 c1                	mov    %eax,%ecx
 10076f4:	48 8b 45 e8          	mov    -0x18(%rbp),%rax
 10076f8:	48 8b 75 f0          	mov    -0x10(%rbp),%rsi
 10076fc:	83 f9 00             	cmp    $0x0,%ecx
 10076ff:	75 1a                	jne    100771b <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x5cb>
 1007701:	e8 9a 91 00 00       	call   10108a0 <myl_rc_take_failure>
 1007706:	48 89 df             	mov    %rbx,%rdi
 1007709:	89 c6                	mov    %eax,%esi
 100770b:	48 89 fb             	mov    %rdi,%rbx
 100770e:	e8 1d 12 00 00       	call   1008930 <myl_qbe_rc_status>
 1007713:	48 89 df             	mov    %rbx,%rdi
 1007716:	e9 7a 0a 00 00       	jmp    1008195 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1045>
 100771b:	48 8d 0d ae 46 01 00 	lea    0x146ae(%rip),%rcx        # 101bdd0 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527>
 1007722:	48 89 8d b0 fe ff ff 	mov    %rcx,-0x150(%rbp)
 1007729:	c7 85 c8 fe ff ff 02 	movl   $0x2,-0x138(%rbp)
 1007730:	00 00 00 
 1007733:	c7 85 20 ff ff ff 01 	movl   $0x1,-0xe0(%rbp)
 100773a:	00 00 00 
 100773d:	8b 8d 18 ff ff ff    	mov    -0xe8(%rbp),%ecx
 1007743:	83 f9 00             	cmp    $0x0,%ecx
 1007746:	0f 84 fb 00 00 00    	je     1007847 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x6f7>
 100774c:	4c 89 ee             	mov    %r13,%rsi
 100774f:	49 89 fc             	mov    %rdi,%r12
 1007752:	48 89 df             	mov    %rbx,%rdi
 1007755:	e8 a6 13 00 00       	call   1008b00 <myl_qbe_rc_slot_drop>
 100775a:	4c 89 e7             	mov    %r12,%rdi
 100775d:	48 8b 45 e8          	mov    -0x18(%rbp),%rax
 1007761:	48 8b 75 f0          	mov    -0x10(%rbp),%rsi
 1007765:	e9 dd 00 00 00       	jmp    1007847 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x6f7>
 100776a:	4d 89 c7             	mov    %r8,%r15
 100776d:	44 09 c9             	or     %r9d,%ecx
 1007770:	75 5a                	jne    10077cc <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x67c>
 1007772:	48 83 f8 00          	cmp    $0x0,%rax
 1007776:	74 1a                	je     1007792 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x642>
 1007778:	48 83 e8 10          	sub    $0x10,%rax
 100777c:	48 8b 00             	mov    (%rax),%rax
 100777f:	48 b9 01 00 00 00 00 	movabs $0x5000000000000001,%rcx
 1007786:	00 00 50 
 1007789:	48 21 c8             	and    %rcx,%rax
 100778c:	48 83 f8 00          	cmp    $0x0,%rax
 1007790:	75 3a                	jne    10077cc <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x67c>
 1007792:	48 8b 85 70 ff ff ff 	mov    -0x90(%rbp),%rax
 1007799:	48 89 85 38 ff ff ff 	mov    %rax,-0xc8(%rbp)
 10077a0:	ba 08 00 00 00       	mov    $0x8,%edx
 10077a5:	be 00 00 00 00       	mov    $0x0,%esi
 10077aa:	49 89 fc             	mov    %rdi,%r12
 10077ad:	48 8d bd 70 ff ff ff 	lea    -0x90(%rbp),%rdi
 10077b4:	e8 d7 17 01 00       	call   1018f90 <compiler_rt.fastMemset>
 10077b9:	4d 89 f8             	mov    %r15,%r8
 10077bc:	4c 89 e7             	mov    %r12,%rdi
 10077bf:	48 8b 45 e8          	mov    -0x18(%rbp),%rax
 10077c3:	48 8b 75 f0          	mov    -0x10(%rbp),%rsi
 10077c7:	4d 89 c7             	mov    %r8,%r15
 10077ca:	eb 4f                	jmp    100781b <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x6cb>
 10077cc:	4d 89 f8             	mov    %r15,%r8
 10077cf:	4d 89 c7             	mov    %r8,%r15
 10077d2:	48 8d 8d 70 ff ff ff 	lea    -0x90(%rbp),%rcx
 10077d9:	48 8d 95 38 ff ff ff 	lea    -0xc8(%rbp),%rdx
 10077e0:	48 8d 35 e9 45 01 00 	lea    0x145e9(%rip),%rsi        # 101bdd0 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527>
 10077e7:	49 89 fc             	mov    %rdi,%r12
 10077ea:	e8 b1 0e 01 00       	call   10186a0 <myl_rc_native_take>
 10077ef:	4c 89 e7             	mov    %r12,%rdi
 10077f2:	89 c1                	mov    %eax,%ecx
 10077f4:	48 8b 45 e8          	mov    -0x18(%rbp),%rax
 10077f8:	48 8b 75 f0          	mov    -0x10(%rbp),%rsi
 10077fc:	83 f9 00             	cmp    $0x0,%ecx
 10077ff:	75 1a                	jne    100781b <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x6cb>
 1007801:	e8 9a 90 00 00       	call   10108a0 <myl_rc_take_failure>
 1007806:	48 89 df             	mov    %rbx,%rdi
 1007809:	89 c6                	mov    %eax,%esi
 100780b:	48 89 fb             	mov    %rdi,%rbx
 100780e:	e8 1d 11 00 00       	call   1008930 <myl_qbe_rc_status>
 1007813:	48 89 df             	mov    %rbx,%rdi
 1007816:	e9 7a 09 00 00       	jmp    1008195 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1045>
 100781b:	c7 85 18 ff ff ff 00 	movl   $0x0,-0xe8(%rbp)
 1007822:	00 00 00 
 1007825:	48 8d 0d a4 45 01 00 	lea    0x145a4(%rip),%rcx        # 101bdd0 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527>
 100782c:	48 89 8d b0 fe ff ff 	mov    %rcx,-0x150(%rbp)
 1007833:	c7 85 c8 fe ff ff 02 	movl   $0x2,-0x138(%rbp)
 100783a:	00 00 00 
 100783d:	c7 85 20 ff ff ff 01 	movl   $0x1,-0xe0(%rbp)
 1007844:	00 00 00 
 1007847:	8b 8d f8 fe ff ff    	mov    -0x108(%rbp),%ecx
 100784d:	83 f9 00             	cmp    $0x0,%ecx
 1007850:	74 12                	je     1007864 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x714>
 1007852:	49 89 fc             	mov    %rdi,%r12
 1007855:	48 89 df             	mov    %rbx,%rdi
 1007858:	e8 a3 12 00 00       	call   1008b00 <myl_qbe_rc_slot_drop>
 100785d:	4c 89 e7             	mov    %r12,%rdi
 1007860:	48 8b 45 e8          	mov    -0x18(%rbp),%rax
 1007864:	48 8b 8d 38 ff ff ff 	mov    -0xc8(%rbp),%rcx
 100786b:	48 89 8d 50 ff ff ff 	mov    %rcx,-0xb0(%rbp)
 1007872:	c7 85 20 ff ff ff 00 	movl   $0x0,-0xe0(%rbp)
 1007879:	00 00 00 
 100787c:	48 8d 0d 4d 45 01 00 	lea    0x1454d(%rip),%rcx        # 101bdd0 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527>
 1007883:	48 89 8d 10 fe ff ff 	mov    %rcx,-0x1f0(%rbp)
 100788a:	c7 85 28 fe ff ff 02 	movl   $0x2,-0x1d8(%rbp)
 1007891:	00 00 00 
 1007894:	48 8d 8d 50 ff ff ff 	lea    -0xb0(%rbp),%rcx
 100789b:	48 89 8d 18 fe ff ff 	mov    %rcx,-0x1e8(%rbp)
 10078a2:	48 89 85 20 fe ff ff 	mov    %rax,-0x1e0(%rbp)
 10078a9:	8b 85 c8 fe ff ff    	mov    -0x138(%rbp),%eax
 10078af:	89 85 28 fe ff ff    	mov    %eax,-0x1d8(%rbp)
 10078b5:	c7 85 f8 fe ff ff 01 	movl   $0x1,-0x108(%rbp)
 10078bc:	00 00 00 
 10078bf:	8b 85 f0 fe ff ff    	mov    -0x110(%rbp),%eax
 10078c5:	83 f8 00             	cmp    $0x0,%eax
 10078c8:	74 15                	je     10078df <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x78f>
 10078ca:	48 8d b5 f0 fd ff ff 	lea    -0x210(%rbp),%rsi
 10078d1:	49 89 fc             	mov    %rdi,%r12
 10078d4:	48 89 df             	mov    %rbx,%rdi
 10078d7:	e8 24 12 00 00       	call   1008b00 <myl_qbe_rc_slot_drop>
 10078dc:	4c 89 e7             	mov    %r12,%rdi
 10078df:	48 8b b5 50 ff ff ff 	mov    -0xb0(%rbp),%rsi
 10078e6:	48 89 b5 70 ff ff ff 	mov    %rsi,-0x90(%rbp)
 10078ed:	49 89 fc             	mov    %rdi,%r12
 10078f0:	48 89 df             	mov    %rbx,%rdi
 10078f3:	e8 78 35 00 00       	call   100ae70 <myl_qbe_bytes_from_list>
 10078f8:	4c 89 e7             	mov    %r12,%rdi
 10078fb:	48 89 85 70 ff ff ff 	mov    %rax,-0x90(%rbp)
 1007902:	48 8b 85 70 ff ff ff 	mov    -0x90(%rbp),%rax
 1007909:	48 89 85 38 ff ff ff 	mov    %rax,-0xc8(%rbp)
 1007910:	48 8d 05 49 44 01 00 	lea    0x14449(%rip),%rax        # 101bd60 <myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7>
 1007917:	48 89 85 b0 fe ff ff 	mov    %rax,-0x150(%rbp)
 100791e:	c7 85 c8 fe ff ff 02 	movl   $0x2,-0x138(%rbp)
 1007925:	00 00 00 
 1007928:	c7 85 20 ff ff ff 01 	movl   $0x1,-0xe0(%rbp)
 100792f:	00 00 00 
 1007932:	8b 85 18 ff ff ff    	mov    -0xe8(%rbp),%eax
 1007938:	83 f8 00             	cmp    $0x0,%eax
 100793b:	75 05                	jne    1007942 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x7f2>
 100793d:	4d 89 f8             	mov    %r15,%r8
 1007940:	eb 14                	jmp    1007956 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x806>
 1007942:	4c 89 ee             	mov    %r13,%rsi
 1007945:	49 89 fc             	mov    %rdi,%r12
 1007948:	48 89 df             	mov    %rbx,%rdi
 100794b:	e8 b0 11 00 00       	call   1008b00 <myl_qbe_rc_slot_drop>
 1007950:	4d 89 f8             	mov    %r15,%r8
 1007953:	4c 89 e7             	mov    %r12,%rdi
 1007956:	48 8b 85 38 ff ff ff 	mov    -0xc8(%rbp),%rax
 100795d:	48 89 85 30 ff ff ff 	mov    %rax,-0xd0(%rbp)
 1007964:	48 8d 05 f5 43 01 00 	lea    0x143f5(%rip),%rax        # 101bd60 <myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7>
 100796b:	48 89 85 90 fe ff ff 	mov    %rax,-0x170(%rbp)
 1007972:	c7 85 a8 fe ff ff 02 	movl   $0x2,-0x158(%rbp)
 1007979:	00 00 00 
 100797c:	8b 85 c8 fe ff ff    	mov    -0x138(%rbp),%eax
 1007982:	89 85 a8 fe ff ff    	mov    %eax,-0x158(%rbp)
 1007988:	c7 85 20 ff ff ff 00 	movl   $0x0,-0xe0(%rbp)
 100798f:	00 00 00 
 1007992:	c7 85 18 ff ff ff 01 	movl   $0x1,-0xe8(%rbp)
 1007999:	00 00 00 
 100799c:	48 8b 8d 30 ff ff ff 	mov    -0xd0(%rbp),%rcx
 10079a3:	48 89 8d 70 ff ff ff 	mov    %rcx,-0x90(%rbp)
 10079aa:	83 e0 18             	and    $0x18,%eax
 10079ad:	89 45 e0             	mov    %eax,-0x20(%rbp)
 10079b0:	83 f8 00             	cmp    $0x0,%eax
 10079b3:	0f 94 c0             	sete   %al
 10079b6:	0f b6 c0             	movzbl %al,%eax
 10079b9:	44 6b c8 04          	imul   $0x4,%eax,%r9d
 10079bd:	4d 89 c7             	mov    %r8,%r15
 10079c0:	48 8d 8d 70 ff ff ff 	lea    -0x90(%rbp),%rcx
 10079c7:	48 8d 95 38 ff ff ff 	lea    -0xc8(%rbp),%rdx
 10079ce:	48 8d 35 8b 43 01 00 	lea    0x1438b(%rip),%rsi        # 101bd60 <myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7>
 10079d5:	49 89 fc             	mov    %rdi,%r12
 10079d8:	e8 a3 10 01 00       	call   1018a80 <myl_rc_native_publish>
 10079dd:	4c 89 e7             	mov    %r12,%rdi
 10079e0:	89 c1                	mov    %eax,%ecx
 10079e2:	8b 45 e0             	mov    -0x20(%rbp),%eax
 10079e5:	83 f9 00             	cmp    $0x0,%ecx
 10079e8:	75 1a                	jne    1007a04 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x8b4>
 10079ea:	e8 b1 8e 00 00       	call   10108a0 <myl_rc_take_failure>
 10079ef:	48 89 df             	mov    %rbx,%rdi
 10079f2:	89 c6                	mov    %eax,%esi
 10079f4:	48 89 fb             	mov    %rdi,%rbx
 10079f7:	e8 34 0f 00 00       	call   1008930 <myl_qbe_rc_status>
 10079fc:	48 89 df             	mov    %rbx,%rdi
 10079ff:	e9 91 07 00 00       	jmp    1008195 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1045>
 1007a04:	83 f8 00             	cmp    $0x0,%eax
 1007a07:	74 1e                	je     1007a27 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x8d7>
 1007a09:	8b 85 18 ff ff ff    	mov    -0xe8(%rbp),%eax
 1007a0f:	83 f8 00             	cmp    $0x0,%eax
 1007a12:	74 1d                	je     1007a31 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x8e1>
 1007a14:	4c 89 ee             	mov    %r13,%rsi
 1007a17:	49 89 fc             	mov    %rdi,%r12
 1007a1a:	48 89 df             	mov    %rbx,%rdi
 1007a1d:	e8 de 10 00 00       	call   1008b00 <myl_qbe_rc_slot_drop>
 1007a22:	4c 89 e7             	mov    %r12,%rdi
 1007a25:	eb 0a                	jmp    1007a31 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x8e1>
 1007a27:	c7 85 18 ff ff ff 00 	movl   $0x0,-0xe8(%rbp)
 1007a2e:	00 00 00 
 1007a31:	48 8d 05 28 43 01 00 	lea    0x14328(%rip),%rax        # 101bd60 <myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7>
 1007a38:	48 89 85 b0 fe ff ff 	mov    %rax,-0x150(%rbp)
 1007a3f:	c7 85 c8 fe ff ff 02 	movl   $0x2,-0x138(%rbp)
 1007a46:	00 00 00 
 1007a49:	c7 85 20 ff ff ff 01 	movl   $0x1,-0xe0(%rbp)
 1007a50:	00 00 00 
 1007a53:	48 8b 85 38 ff ff ff 	mov    -0xc8(%rbp),%rax
 1007a5a:	48 89 85 30 ff ff ff 	mov    %rax,-0xd0(%rbp)
 1007a61:	48 8d 05 f8 42 01 00 	lea    0x142f8(%rip),%rax        # 101bd60 <myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7>
 1007a68:	48 89 85 90 fe ff ff 	mov    %rax,-0x170(%rbp)
 1007a6f:	c7 85 a8 fe ff ff 02 	movl   $0x2,-0x158(%rbp)
 1007a76:	00 00 00 
 1007a79:	c7 85 a8 fe ff ff 02 	movl   $0x2,-0x158(%rbp)
 1007a80:	00 00 00 
 1007a83:	c7 85 20 ff ff ff 00 	movl   $0x0,-0xe0(%rbp)
 1007a8a:	00 00 00 
 1007a8d:	c7 85 18 ff ff ff 01 	movl   $0x1,-0xe8(%rbp)
 1007a94:	00 00 00 
 1007a97:	48 8b 85 30 ff ff ff 	mov    -0xd0(%rbp),%rax
 1007a9e:	48 89 85 70 ff ff ff 	mov    %rax,-0x90(%rbp)
 1007aa5:	48 83 f8 00          	cmp    $0x0,%rax
 1007aa9:	74 1a                	je     1007ac5 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x975>
 1007aab:	48 83 e8 10          	sub    $0x10,%rax
 1007aaf:	48 8b 00             	mov    (%rax),%rax
 1007ab2:	48 b9 01 00 00 00 00 	movabs $0x5000000000000001,%rcx
 1007ab9:	00 00 50 
 1007abc:	48 21 c8             	and    %rcx,%rax
 1007abf:	48 83 f8 00          	cmp    $0x0,%rax
 1007ac3:	75 3a                	jne    1007aff <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x9af>
 1007ac5:	48 8b 85 70 ff ff ff 	mov    -0x90(%rbp),%rax
 1007acc:	48 89 85 38 ff ff ff 	mov    %rax,-0xc8(%rbp)
 1007ad3:	ba 08 00 00 00       	mov    $0x8,%edx
 1007ad8:	be 00 00 00 00       	mov    $0x0,%esi
 1007add:	49 89 fc             	mov    %rdi,%r12
 1007ae0:	48 8d bd 70 ff ff ff 	lea    -0x90(%rbp),%rdi
 1007ae7:	e8 a4 14 01 00       	call   1018f90 <compiler_rt.fastMemset>
 1007aec:	4d 89 f8             	mov    %r15,%r8
 1007aef:	4c 89 e7             	mov    %r12,%rdi
 1007af2:	4c 8b 65 d0          	mov    -0x30(%rbp),%r12
 1007af6:	48 8b 75 d8          	mov    -0x28(%rbp),%rsi
 1007afa:	4d 89 c7             	mov    %r8,%r15
 1007afd:	eb 4d                	jmp    1007b4c <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x9fc>
 1007aff:	4d 89 f8             	mov    %r15,%r8
 1007b02:	4d 89 c7             	mov    %r8,%r15
 1007b05:	48 8d 8d 70 ff ff ff 	lea    -0x90(%rbp),%rcx
 1007b0c:	48 8d 95 38 ff ff ff 	lea    -0xc8(%rbp),%rdx
 1007b13:	48 8d 35 46 42 01 00 	lea    0x14246(%rip),%rsi        # 101bd60 <myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7>
 1007b1a:	49 89 fc             	mov    %rdi,%r12
 1007b1d:	e8 7e 0b 01 00       	call   10186a0 <myl_rc_native_take>
 1007b22:	4c 89 e7             	mov    %r12,%rdi
 1007b25:	4c 8b 65 d0          	mov    -0x30(%rbp),%r12
 1007b29:	48 8b 75 d8          	mov    -0x28(%rbp),%rsi
 1007b2d:	83 f8 00             	cmp    $0x0,%eax
 1007b30:	75 1a                	jne    1007b4c <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x9fc>
 1007b32:	e8 69 8d 00 00       	call   10108a0 <myl_rc_take_failure>
 1007b37:	48 89 df             	mov    %rbx,%rdi
 1007b3a:	89 c6                	mov    %eax,%esi
 1007b3c:	48 89 fb             	mov    %rdi,%rbx
 1007b3f:	e8 ec 0d 00 00       	call   1008930 <myl_qbe_rc_status>
 1007b44:	48 89 df             	mov    %rbx,%rdi
 1007b47:	e9 49 06 00 00       	jmp    1008195 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1045>
 1007b4c:	c7 85 18 ff ff ff 00 	movl   $0x0,-0xe8(%rbp)
 1007b53:	00 00 00 
 1007b56:	48 8d 05 03 42 01 00 	lea    0x14203(%rip),%rax        # 101bd60 <myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7>
 1007b5d:	48 89 85 b0 fe ff ff 	mov    %rax,-0x150(%rbp)
 1007b64:	c7 85 c8 fe ff ff 02 	movl   $0x2,-0x138(%rbp)
 1007b6b:	00 00 00 
 1007b6e:	c7 85 20 ff ff ff 01 	movl   $0x1,-0xe0(%rbp)
 1007b75:	00 00 00 
 1007b78:	8b 85 00 ff ff ff    	mov    -0x100(%rbp),%eax
 1007b7e:	83 f8 00             	cmp    $0x0,%eax
 1007b81:	75 05                	jne    1007b88 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xa38>
 1007b83:	4d 89 f8             	mov    %r15,%r8
 1007b86:	eb 15                	jmp    1007b9d <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xa4d>
 1007b88:	49 89 fc             	mov    %rdi,%r12
 1007b8b:	48 89 df             	mov    %rbx,%rdi
 1007b8e:	e8 6d 0f 00 00       	call   1008b00 <myl_qbe_rc_slot_drop>
 1007b93:	4d 89 f8             	mov    %r15,%r8
 1007b96:	4c 89 e7             	mov    %r12,%rdi
 1007b99:	4c 8b 65 d0          	mov    -0x30(%rbp),%r12
 1007b9d:	48 8b 85 38 ff ff ff 	mov    -0xc8(%rbp),%rax
 1007ba4:	48 89 85 58 ff ff ff 	mov    %rax,-0xa8(%rbp)
 1007bab:	c7 85 20 ff ff ff 00 	movl   $0x0,-0xe0(%rbp)
 1007bb2:	00 00 00 
 1007bb5:	48 8d 05 a4 41 01 00 	lea    0x141a4(%rip),%rax        # 101bd60 <myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7>
 1007bbc:	48 89 85 30 fe ff ff 	mov    %rax,-0x1d0(%rbp)
 1007bc3:	c7 85 48 fe ff ff 02 	movl   $0x2,-0x1b8(%rbp)
 1007bca:	00 00 00 
 1007bcd:	48 8d 85 58 ff ff ff 	lea    -0xa8(%rbp),%rax
 1007bd4:	48 89 85 38 fe ff ff 	mov    %rax,-0x1c8(%rbp)
 1007bdb:	4c 89 b5 40 fe ff ff 	mov    %r14,-0x1c0(%rbp)
 1007be2:	8b 85 c8 fe ff ff    	mov    -0x138(%rbp),%eax
 1007be8:	89 85 48 fe ff ff    	mov    %eax,-0x1b8(%rbp)
 1007bee:	c7 85 00 ff ff ff 01 	movl   $0x1,-0x100(%rbp)
 1007bf5:	00 00 00 
 1007bf8:	48 c7 85 70 ff ff ff 	movq   $0x6d,-0x90(%rbp)
 1007bff:	6d 00 00 00 
 1007c03:	48 c7 85 78 ff ff ff 	movq   $0x79,-0x88(%rbp)
 1007c0a:	79 00 00 00 
 1007c0e:	48 8b 05 ab 4a 01 00 	mov    0x14aab(%rip),%rax        # 101c6c0 <myl_lit_3a31048ef22d5766c70d678fc1c59ca587d84f11b25c84fb64cb1eb13678199d>
 1007c15:	48 89 85 70 ff ff ff 	mov    %rax,-0x90(%rbp)
 1007c1c:	48 8b 8d 70 ff ff ff 	mov    -0x90(%rbp),%rcx
 1007c23:	48 89 8d 38 ff ff ff 	mov    %rcx,-0xc8(%rbp)
 1007c2a:	48 8d 0d 0f 42 01 00 	lea    0x1420f(%rip),%rcx        # 101be40 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9>
 1007c31:	48 89 8d b0 fe ff ff 	mov    %rcx,-0x150(%rbp)
 1007c38:	c7 85 c8 fe ff ff 02 	movl   $0x2,-0x138(%rbp)
 1007c3f:	00 00 00 
 1007c42:	c7 85 20 ff ff ff 01 	movl   $0x1,-0xe0(%rbp)
 1007c49:	00 00 00 
 1007c4c:	48 8b 8d 38 ff ff ff 	mov    -0xc8(%rbp),%rcx
 1007c53:	48 89 8d 30 ff ff ff 	mov    %rcx,-0xd0(%rbp)
 1007c5a:	48 8d 0d df 41 01 00 	lea    0x141df(%rip),%rcx        # 101be40 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9>
 1007c61:	48 89 8d 90 fe ff ff 	mov    %rcx,-0x170(%rbp)
 1007c68:	c7 85 a8 fe ff ff 02 	movl   $0x2,-0x158(%rbp)
 1007c6f:	00 00 00 
 1007c72:	c7 85 a8 fe ff ff 02 	movl   $0x2,-0x158(%rbp)
 1007c79:	00 00 00 
 1007c7c:	c7 85 20 ff ff ff 00 	movl   $0x0,-0xe0(%rbp)
 1007c83:	00 00 00 
 1007c86:	c7 85 18 ff ff ff 01 	movl   $0x1,-0xe8(%rbp)
 1007c8d:	00 00 00 
 1007c90:	48 89 85 70 ff ff ff 	mov    %rax,-0x90(%rbp)
 1007c97:	48 83 f8 00          	cmp    $0x0,%rax
 1007c9b:	74 1a                	je     1007cb7 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xb67>
 1007c9d:	48 83 e8 10          	sub    $0x10,%rax
 1007ca1:	48 8b 00             	mov    (%rax),%rax
 1007ca4:	48 b9 01 00 00 00 00 	movabs $0x5000000000000001,%rcx
 1007cab:	00 00 50 
 1007cae:	48 21 c8             	and    %rcx,%rax
 1007cb1:	48 83 f8 00          	cmp    $0x0,%rax
 1007cb5:	75 33                	jne    1007cea <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xb9a>
 1007cb7:	48 8b 85 70 ff ff ff 	mov    -0x90(%rbp),%rax
 1007cbe:	48 89 85 38 ff ff ff 	mov    %rax,-0xc8(%rbp)
 1007cc5:	ba 08 00 00 00       	mov    $0x8,%edx
 1007cca:	be 00 00 00 00       	mov    $0x0,%esi
 1007ccf:	49 89 ff             	mov    %rdi,%r15
 1007cd2:	48 8d bd 70 ff ff ff 	lea    -0x90(%rbp),%rdi
 1007cd9:	e8 b2 12 01 00       	call   1018f90 <compiler_rt.fastMemset>
 1007cde:	4c 89 ff             	mov    %r15,%rdi
 1007ce1:	48 8b 75 c8          	mov    -0x38(%rbp),%rsi
 1007ce5:	48 87 df             	xchg   %rbx,%rdi
 1007ce8:	eb 49                	jmp    1007d33 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xbe3>
 1007cea:	4d 89 c7             	mov    %r8,%r15
 1007ced:	48 8d 8d 70 ff ff ff 	lea    -0x90(%rbp),%rcx
 1007cf4:	48 8d 95 38 ff ff ff 	lea    -0xc8(%rbp),%rdx
 1007cfb:	48 8d 35 3e 41 01 00 	lea    0x1413e(%rip),%rsi        # 101be40 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9>
 1007d02:	49 89 ff             	mov    %rdi,%r15
 1007d05:	e8 96 09 01 00       	call   10186a0 <myl_rc_native_take>
 1007d0a:	4c 89 ff             	mov    %r15,%rdi
 1007d0d:	48 8b 75 c8          	mov    -0x38(%rbp),%rsi
 1007d11:	83 f8 00             	cmp    $0x0,%eax
 1007d14:	75 1a                	jne    1007d30 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xbe0>
 1007d16:	e8 85 8b 00 00       	call   10108a0 <myl_rc_take_failure>
 1007d1b:	48 89 df             	mov    %rbx,%rdi
 1007d1e:	89 c6                	mov    %eax,%esi
 1007d20:	48 89 fb             	mov    %rdi,%rbx
 1007d23:	e8 08 0c 00 00       	call   1008930 <myl_qbe_rc_status>
 1007d28:	48 89 df             	mov    %rbx,%rdi
 1007d2b:	e9 65 04 00 00       	jmp    1008195 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1045>
 1007d30:	48 87 df             	xchg   %rbx,%rdi
 1007d33:	c7 85 18 ff ff ff 00 	movl   $0x0,-0xe8(%rbp)
 1007d3a:	00 00 00 
 1007d3d:	48 8d 05 fc 40 01 00 	lea    0x140fc(%rip),%rax        # 101be40 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9>
 1007d44:	48 89 85 b0 fe ff ff 	mov    %rax,-0x150(%rbp)
 1007d4b:	c7 85 c8 fe ff ff 02 	movl   $0x2,-0x138(%rbp)
 1007d52:	00 00 00 
 1007d55:	c7 85 20 ff ff ff 01 	movl   $0x1,-0xe0(%rbp)
 1007d5c:	00 00 00 
 1007d5f:	8b 85 08 ff ff ff    	mov    -0xf8(%rbp),%eax
 1007d65:	83 f8 00             	cmp    $0x0,%eax
 1007d68:	74 0b                	je     1007d75 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xc25>
 1007d6a:	49 89 ff             	mov    %rdi,%r15
 1007d6d:	e8 8e 0d 00 00       	call   1008b00 <myl_qbe_rc_slot_drop>
 1007d72:	4c 89 ff             	mov    %r15,%rdi
 1007d75:	48 8b 85 38 ff ff ff 	mov    -0xc8(%rbp),%rax
 1007d7c:	48 89 85 60 ff ff ff 	mov    %rax,-0xa0(%rbp)
 1007d83:	c7 85 20 ff ff ff 00 	movl   $0x0,-0xe0(%rbp)
 1007d8a:	00 00 00 
 1007d8d:	48 8d 05 ac 40 01 00 	lea    0x140ac(%rip),%rax        # 101be40 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9>
 1007d94:	48 89 85 50 fe ff ff 	mov    %rax,-0x1b0(%rbp)
 1007d9b:	c7 85 68 fe ff ff 02 	movl   $0x2,-0x198(%rbp)
 1007da2:	00 00 00 
 1007da5:	48 8d 85 60 ff ff ff 	lea    -0xa0(%rbp),%rax
 1007dac:	48 89 85 58 fe ff ff 	mov    %rax,-0x1a8(%rbp)
 1007db3:	4c 89 a5 60 fe ff ff 	mov    %r12,-0x1a0(%rbp)
 1007dba:	8b 85 c8 fe ff ff    	mov    -0x138(%rbp),%eax
 1007dc0:	89 85 68 fe ff ff    	mov    %eax,-0x198(%rbp)
 1007dc6:	c7 85 08 ff ff ff 01 	movl   $0x1,-0xf8(%rbp)
 1007dcd:	00 00 00 
 1007dd0:	48 c7 85 70 ff ff ff 	movq   $0x0,-0x90(%rbp)
 1007dd7:	00 00 00 00 
 1007ddb:	48 c7 85 70 ff ff ff 	movq   $0x20000,-0x90(%rbp)
 1007de2:	00 00 02 00 
 1007de6:	49 89 dc             	mov    %rbx,%r12
 1007de9:	bb 00 00 00 00       	mov    $0x0,%ebx
 1007dee:	66 90                	xchg   %ax,%ax
 1007df0:	48 89 9d 70 ff ff ff 	mov    %rbx,-0x90(%rbp)
 1007df7:	48 c7 85 78 ff ff ff 	movq   $0x20000,-0x88(%rbp)
 1007dfe:	00 00 02 00 
 1007e02:	48 81 fb 00 00 02 00 	cmp    $0x20000,%rbx
 1007e09:	0f 9c c0             	setl   %al
 1007e0c:	48 0f b6 c0          	movzbq %al,%rax
 1007e10:	48 89 85 70 ff ff ff 	mov    %rax,-0x90(%rbp)
 1007e17:	0f 8d 1c 01 00 00    	jge    1007f39 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xde9>
 1007e1d:	48 8b 85 60 ff ff ff 	mov    -0xa0(%rbp),%rax
 1007e24:	48 89 85 70 ff ff ff 	mov    %rax,-0x90(%rbp)
 1007e2b:	48 c7 85 78 ff ff ff 	movq   $0x0,-0x88(%rbp)
 1007e32:	00 00 00 00 
 1007e36:	48 8d 05 23 3f 01 00 	lea    0x13f23(%rip),%rax        # 101bd60 <myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7>
 1007e3d:	48 89 85 30 fe ff ff 	mov    %rax,-0x1d0(%rbp)
 1007e44:	c7 85 48 fe ff ff 02 	movl   $0x2,-0x1b8(%rbp)
 1007e4b:	00 00 00 
 1007e4e:	48 8d 85 58 ff ff ff 	lea    -0xa8(%rbp),%rax
 1007e55:	48 89 85 38 fe ff ff 	mov    %rax,-0x1c8(%rbp)
 1007e5c:	4c 89 b5 40 fe ff ff 	mov    %r14,-0x1c0(%rbp)
 1007e63:	4c 89 f1             	mov    %r14,%rcx
 1007e66:	48 8d 95 58 ff ff ff 	lea    -0xa8(%rbp),%rdx
 1007e6d:	48 8d 35 ec 3e 01 00 	lea    0x13eec(%rip),%rsi        # 101bd60 <myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7>
 1007e74:	49 89 ff             	mov    %rdi,%r15
 1007e77:	e8 04 10 00 00       	call   1008e80 <myl_qbe_rc_unique_local>
 1007e7c:	4c 89 ff             	mov    %r15,%rdi
 1007e7f:	83 f8 00             	cmp    $0x0,%eax
 1007e82:	0f 84 0d 03 00 00    	je     1008195 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1045>
 1007e88:	48 8b b5 58 ff ff ff 	mov    -0xa8(%rbp),%rsi
 1007e8f:	48 8b 95 70 ff ff ff 	mov    -0x90(%rbp),%rdx
 1007e96:	48 8b 8d 78 ff ff ff 	mov    -0x88(%rbp),%rcx
 1007e9d:	41 b8 40 00 00 00    	mov    $0x40,%r8d
 1007ea3:	49 89 ff             	mov    %rdi,%r15
 1007ea6:	4c 89 e7             	mov    %r12,%rdi
 1007ea9:	e8 02 87 00 00       	call   10105b0 <myl_native_bytes_buffer_append_range>
 1007eae:	4c 89 ff             	mov    %r15,%rdi
 1007eb1:	89 c1                	mov    %eax,%ecx
 1007eb3:	48 83 f9 00          	cmp    $0x0,%rcx
 1007eb7:	74 76                	je     1007f2f <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xddf>
 1007eb9:	83 f8 01             	cmp    $0x1,%eax
 1007ebc:	0f 94 c0             	sete   %al
 1007ebf:	0f b6 c0             	movzbl %al,%eax
 1007ec2:	89 c0                	mov    %eax,%eax
 1007ec4:	48 89 85 70 ff ff ff 	mov    %rax,-0x90(%rbp)
 1007ecb:	8b 85 18 ff ff ff    	mov    -0xe8(%rbp),%eax
 1007ed1:	83 f8 00             	cmp    $0x0,%eax
 1007ed4:	74 0e                	je     1007ee4 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xd94>
 1007ed6:	4c 89 ee             	mov    %r13,%rsi
 1007ed9:	49 89 ff             	mov    %rdi,%r15
 1007edc:	e8 1f 0c 00 00       	call   1008b00 <myl_qbe_rc_slot_drop>
 1007ee1:	4c 89 ff             	mov    %r15,%rdi
 1007ee4:	48 89 9d 70 ff ff ff 	mov    %rbx,-0x90(%rbp)
 1007eeb:	48 c7 85 78 ff ff ff 	movq   $0x1,-0x88(%rbp)
 1007ef2:	01 00 00 00 
 1007ef6:	48 b8 fe ff ff ff ff 	movabs $0x7ffffffffffffffe,%rax
 1007efd:	ff ff 7f 
 1007f00:	48 39 c3             	cmp    %rax,%rbx
 1007f03:	7f 10                	jg     1007f15 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xdc5>
 1007f05:	48 83 c3 01          	add    $0x1,%rbx
 1007f09:	48 89 9d 70 ff ff ff 	mov    %rbx,-0x90(%rbp)
 1007f10:	e9 db fe ff ff       	jmp    1007df0 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xca0>
 1007f15:	48 89 da             	mov    %rbx,%rdx
 1007f18:	41 b8 40 00 00 00    	mov    $0x40,%r8d
 1007f1e:	b9 01 00 00 00       	mov    $0x1,%ecx
 1007f23:	be 00 00 00 00       	mov    $0x0,%esi
 1007f28:	e8 43 12 00 00       	call   1009170 <myl_qbe_fail_overflow_op>
 1007f2d:	0f 0b                	ud2
 1007f2f:	48 89 fb             	mov    %rdi,%rbx
 1007f32:	e8 59 11 00 00       	call   1009090 <myl_qbe_fail_allocation>
 1007f37:	0f 0b                	ud2
 1007f39:	4c 8b 7d c0          	mov    -0x40(%rbp),%r15
 1007f3d:	4c 8b 75 80          	mov    -0x80(%rbp),%r14
 1007f41:	48 89 fb             	mov    %rdi,%rbx
 1007f44:	4c 89 e7             	mov    %r12,%rdi
 1007f47:	48 8b b5 58 ff ff ff 	mov    -0xa8(%rbp),%rsi
 1007f4e:	48 89 b5 70 ff ff ff 	mov    %rsi,-0x90(%rbp)
 1007f55:	49 89 fc             	mov    %rdi,%r12
 1007f58:	48 89 df             	mov    %rbx,%rdi
 1007f5b:	e8 80 2f 00 00       	call   100aee0 <myl_qbe_bytes_snapshot>
 1007f60:	4c 89 e7             	mov    %r12,%rdi
 1007f63:	44 8b 4d b4          	mov    -0x4c(%rbp),%r9d
 1007f67:	8b 4d b0             	mov    -0x50(%rbp),%ecx
 1007f6a:	4c 8b 65 b8          	mov    -0x48(%rbp),%r12
 1007f6e:	48 8b 75 a8          	mov    -0x58(%rbp),%rsi
 1007f72:	48 89 85 70 ff ff ff 	mov    %rax,-0x90(%rbp)
 1007f79:	48 8b 85 70 ff ff ff 	mov    -0x90(%rbp),%rax
 1007f80:	48 89 85 38 ff ff ff 	mov    %rax,-0xc8(%rbp)
 1007f87:	48 8d 05 b2 3e 01 00 	lea    0x13eb2(%rip),%rax        # 101be40 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9>
 1007f8e:	48 89 85 b0 fe ff ff 	mov    %rax,-0x150(%rbp)
 1007f95:	c7 85 c8 fe ff ff 02 	movl   $0x2,-0x138(%rbp)
 1007f9c:	00 00 00 
 1007f9f:	c7 85 20 ff ff ff 01 	movl   $0x1,-0xe0(%rbp)
 1007fa6:	00 00 00 
 1007fa9:	8b 85 18 ff ff ff    	mov    -0xe8(%rbp),%eax
 1007faf:	83 f8 00             	cmp    $0x0,%eax
 1007fb2:	75 0b                	jne    1007fbf <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xe6f>
 1007fb4:	4d 89 f8             	mov    %r15,%r8
 1007fb7:	4c 89 f2             	mov    %r14,%rdx
 1007fba:	4d 89 e6             	mov    %r12,%r14
 1007fbd:	eb 26                	jmp    1007fe5 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xe95>
 1007fbf:	4c 89 ee             	mov    %r13,%rsi
 1007fc2:	49 89 fc             	mov    %rdi,%r12
 1007fc5:	48 89 df             	mov    %rbx,%rdi
 1007fc8:	e8 33 0b 00 00       	call   1008b00 <myl_qbe_rc_slot_drop>
 1007fcd:	4d 89 f8             	mov    %r15,%r8
 1007fd0:	4c 89 f2             	mov    %r14,%rdx
 1007fd3:	4c 89 e7             	mov    %r12,%rdi
 1007fd6:	44 8b 4d b4          	mov    -0x4c(%rbp),%r9d
 1007fda:	8b 4d b0             	mov    -0x50(%rbp),%ecx
 1007fdd:	4c 8b 75 b8          	mov    -0x48(%rbp),%r14
 1007fe1:	48 8b 75 a8          	mov    -0x58(%rbp),%rsi
 1007fe5:	48 8b 85 38 ff ff ff 	mov    -0xc8(%rbp),%rax
 1007fec:	48 89 85 30 ff ff ff 	mov    %rax,-0xd0(%rbp)
 1007ff3:	48 8d 05 46 3e 01 00 	lea    0x13e46(%rip),%rax        # 101be40 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9>
 1007ffa:	48 89 85 90 fe ff ff 	mov    %rax,-0x170(%rbp)
 1008001:	c7 85 a8 fe ff ff 02 	movl   $0x2,-0x158(%rbp)
 1008008:	00 00 00 
 100800b:	44 8b 95 c8 fe ff ff 	mov    -0x138(%rbp),%r10d
 1008012:	44 89 95 a8 fe ff ff 	mov    %r10d,-0x158(%rbp)
 1008019:	c7 85 20 ff ff ff 00 	movl   $0x0,-0xe0(%rbp)
 1008020:	00 00 00 
 1008023:	c7 85 18 ff ff ff 01 	movl   $0x1,-0xe8(%rbp)
 100802a:	00 00 00 
 100802d:	48 8b 85 30 ff ff ff 	mov    -0xd0(%rbp),%rax
 1008034:	48 89 85 70 ff ff ff 	mov    %rax,-0x90(%rbp)
 100803b:	41 83 e2 18          	and    $0x18,%r10d
 100803f:	41 83 fa 00          	cmp    $0x0,%r10d
 1008043:	0f 84 9d 00 00 00    	je     10080e6 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xf96>
 1008049:	48 8d 8d 70 ff ff ff 	lea    -0x90(%rbp),%rcx
 1008050:	49 89 d7             	mov    %rdx,%r15
 1008053:	48 8d 95 38 ff ff ff 	lea    -0xc8(%rbp),%rdx
 100805a:	48 8d 35 df 3d 01 00 	lea    0x13ddf(%rip),%rsi        # 101be40 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9>
 1008061:	49 89 fc             	mov    %rdi,%r12
 1008064:	e8 37 0b 01 00       	call   1018ba0 <myl_rc_native_retain>
 1008069:	4c 89 e7             	mov    %r12,%rdi
 100806c:	48 8b 75 a8          	mov    -0x58(%rbp),%rsi
 1008070:	83 f8 00             	cmp    $0x0,%eax
 1008073:	75 1a                	jne    100808f <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xf3f>
 1008075:	e8 26 88 00 00       	call   10108a0 <myl_rc_take_failure>
 100807a:	48 89 df             	mov    %rbx,%rdi
 100807d:	89 c6                	mov    %eax,%esi
 100807f:	48 89 fb             	mov    %rdi,%rbx
 1008082:	e8 a9 08 00 00       	call   1008930 <myl_qbe_rc_status>
 1008087:	48 89 df             	mov    %rbx,%rdi
 100808a:	e9 06 01 00 00       	jmp    1008195 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1045>
 100808f:	48 89 df             	mov    %rbx,%rdi
 1008092:	48 8d 05 a7 3d 01 00 	lea    0x13da7(%rip),%rax        # 101be40 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9>
 1008099:	48 89 85 b0 fe ff ff 	mov    %rax,-0x150(%rbp)
 10080a0:	c7 85 c8 fe ff ff 02 	movl   $0x2,-0x138(%rbp)
 10080a7:	00 00 00 
 10080aa:	c7 85 20 ff ff ff 01 	movl   $0x1,-0xe0(%rbp)
 10080b1:	00 00 00 
 10080b4:	8b 85 18 ff ff ff    	mov    -0xe8(%rbp),%eax
 10080ba:	83 f8 00             	cmp    $0x0,%eax
 10080bd:	75 05                	jne    10080c4 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xf74>
 10080bf:	4c 89 fa             	mov    %r15,%rdx
 10080c2:	eb 17                	jmp    10080db <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xf8b>
 10080c4:	49 89 f4             	mov    %rsi,%r12
 10080c7:	4c 89 ee             	mov    %r13,%rsi
 10080ca:	48 89 fb             	mov    %rdi,%rbx
 10080cd:	e8 2e 0a 00 00       	call   1008b00 <myl_qbe_rc_slot_drop>
 10080d2:	4c 89 fa             	mov    %r15,%rdx
 10080d5:	4c 89 e6             	mov    %r12,%rsi
 10080d8:	48 89 df             	mov    %rbx,%rdi
 10080db:	4c 89 f3             	mov    %r14,%rbx
 10080de:	49 89 d4             	mov    %rdx,%r12
 10080e1:	e9 09 01 00 00       	jmp    10081ef <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x109f>
 10080e6:	48 87 df             	xchg   %rbx,%rdi
 10080e9:	44 09 c9             	or     %r9d,%ecx
 10080ec:	75 63                	jne    1008151 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1001>
 10080ee:	48 83 f8 00          	cmp    $0x0,%rax
 10080f2:	74 1a                	je     100810e <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xfbe>
 10080f4:	48 83 e8 10          	sub    $0x10,%rax
 10080f8:	48 8b 00             	mov    (%rax),%rax
 10080fb:	48 b9 01 00 00 00 00 	movabs $0x5000000000000001,%rcx
 1008102:	00 00 50 
 1008105:	48 21 c8             	and    %rcx,%rax
 1008108:	48 83 f8 00          	cmp    $0x0,%rax
 100810c:	75 3e                	jne    100814c <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xffc>
 100810e:	48 8b 85 70 ff ff ff 	mov    -0x90(%rbp),%rax
 1008115:	48 89 85 38 ff ff ff 	mov    %rax,-0xc8(%rbp)
 100811c:	49 89 d7             	mov    %rdx,%r15
 100811f:	ba 08 00 00 00       	mov    $0x8,%edx
 1008124:	49 89 f4             	mov    %rsi,%r12
 1008127:	be 00 00 00 00       	mov    $0x0,%esi
 100812c:	48 89 fb             	mov    %rdi,%rbx
 100812f:	48 8d bd 70 ff ff ff 	lea    -0x90(%rbp),%rdi
 1008136:	e8 55 0e 01 00       	call   1018f90 <compiler_rt.fastMemset>
 100813b:	4c 89 fa             	mov    %r15,%rdx
 100813e:	4c 89 e6             	mov    %r12,%rsi
 1008141:	49 89 d4             	mov    %rdx,%r12
 1008144:	48 89 df             	mov    %rbx,%rdi
 1008147:	4c 89 f3             	mov    %r14,%rbx
 100814a:	eb 77                	jmp    10081c3 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1073>
 100814c:	48 87 fb             	xchg   %rdi,%rbx
 100814f:	eb 03                	jmp    1008154 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1004>
 1008151:	48 87 fb             	xchg   %rdi,%rbx
 1008154:	48 8d 8d 70 ff ff ff 	lea    -0x90(%rbp),%rcx
 100815b:	49 89 d4             	mov    %rdx,%r12
 100815e:	48 8d 95 38 ff ff ff 	lea    -0xc8(%rbp),%rdx
 1008165:	48 8d 35 d4 3c 01 00 	lea    0x13cd4(%rip),%rsi        # 101be40 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9>
 100816c:	49 89 ff             	mov    %rdi,%r15
 100816f:	e8 2c 05 01 00       	call   10186a0 <myl_rc_native_take>
 1008174:	4c 89 ff             	mov    %r15,%rdi
 1008177:	48 8b 75 a8          	mov    -0x58(%rbp),%rsi
 100817b:	83 f8 00             	cmp    $0x0,%eax
 100817e:	75 3d                	jne    10081bd <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x106d>
 1008180:	e8 1b 87 00 00       	call   10108a0 <myl_rc_take_failure>
 1008185:	48 89 df             	mov    %rbx,%rdi
 1008188:	89 c6                	mov    %eax,%esi
 100818a:	48 89 fb             	mov    %rdi,%rbx
 100818d:	e8 9e 07 00 00       	call   1008930 <myl_qbe_rc_status>
 1008192:	48 89 df             	mov    %rbx,%rdi
 1008195:	48 8d b5 d0 fd ff ff 	lea    -0x230(%rbp),%rsi
 100819c:	48 89 fb             	mov    %rdi,%rbx
 100819f:	e8 8c 0a 00 00       	call   1008c30 <myl_qbe_rc_frame_cleanup>
 10081a4:	48 89 df             	mov    %rbx,%rdi
 10081a7:	48 8d b5 d0 fd ff ff 	lea    -0x230(%rbp),%rsi
 10081ae:	e8 ed 08 00 00       	call   1008aa0 <myl_qbe_rc_frame_leave>
 10081b3:	b8 00 00 00 00       	mov    $0x0,%eax
 10081b8:	e9 84 05 00 00       	jmp    1008741 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x15f1>
 10081bd:	48 89 df             	mov    %rbx,%rdi
 10081c0:	4c 89 f3             	mov    %r14,%rbx
 10081c3:	c7 85 18 ff ff ff 00 	movl   $0x0,-0xe8(%rbp)
 10081ca:	00 00 00 
 10081cd:	48 8d 05 6c 3c 01 00 	lea    0x13c6c(%rip),%rax        # 101be40 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9>
 10081d4:	48 89 85 b0 fe ff ff 	mov    %rax,-0x150(%rbp)
 10081db:	c7 85 c8 fe ff ff 02 	movl   $0x2,-0x138(%rbp)
 10081e2:	00 00 00 
 10081e5:	c7 85 20 ff ff ff 01 	movl   $0x1,-0xe0(%rbp)
 10081ec:	00 00 00 
 10081ef:	8b 85 10 ff ff ff    	mov    -0xf0(%rbp),%eax
 10081f5:	83 f8 00             	cmp    $0x0,%eax
 10081f8:	74 0b                	je     1008205 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x10b5>
 10081fa:	49 89 fe             	mov    %rdi,%r14
 10081fd:	e8 fe 08 00 00       	call   1008b00 <myl_qbe_rc_slot_drop>
 1008202:	4c 89 f7             	mov    %r14,%rdi
 1008205:	48 8b 85 38 ff ff ff 	mov    -0xc8(%rbp),%rax
 100820c:	48 89 85 68 ff ff ff 	mov    %rax,-0x98(%rbp)
 1008213:	c7 85 20 ff ff ff 00 	movl   $0x0,-0xe0(%rbp)
 100821a:	00 00 00 
 100821d:	48 8d 05 1c 3c 01 00 	lea    0x13c1c(%rip),%rax        # 101be40 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9>
 1008224:	48 89 85 70 fe ff ff 	mov    %rax,-0x190(%rbp)
 100822b:	c7 85 88 fe ff ff 02 	movl   $0x2,-0x178(%rbp)
 1008232:	00 00 00 
 1008235:	48 8d 85 68 ff ff ff 	lea    -0x98(%rbp),%rax
 100823c:	48 89 85 78 fe ff ff 	mov    %rax,-0x188(%rbp)
 1008243:	48 89 9d 80 fe ff ff 	mov    %rbx,-0x180(%rbp)
 100824a:	8b 85 c8 fe ff ff    	mov    -0x138(%rbp),%eax
 1008250:	89 85 88 fe ff ff    	mov    %eax,-0x178(%rbp)
 1008256:	c7 85 10 ff ff ff 01 	movl   $0x1,-0xf0(%rbp)
 100825d:	00 00 00 
 1008260:	48 8b 85 68 ff ff ff 	mov    -0x98(%rbp),%rax
 1008267:	48 89 85 70 ff ff ff 	mov    %rax,-0x90(%rbp)
 100826e:	48 8b 00             	mov    (%rax),%rax
 1008271:	48 89 85 70 ff ff ff 	mov    %rax,-0x90(%rbp)
 1008278:	8b 85 18 ff ff ff    	mov    -0xe8(%rbp),%eax
 100827e:	83 f8 00             	cmp    $0x0,%eax
 1008281:	74 0e                	je     1008291 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1141>
 1008283:	4c 89 ee             	mov    %r13,%rsi
 1008286:	48 89 fb             	mov    %rdi,%rbx
 1008289:	e8 72 08 00 00       	call   1008b00 <myl_qbe_rc_slot_drop>
 100828e:	48 89 df             	mov    %rbx,%rdi
 1008291:	48 8b 9d 70 ff ff ff 	mov    -0x90(%rbp),%rbx
 1008298:	48 c7 85 70 ff ff ff 	movq   $0x0,-0x90(%rbp)
 100829f:	00 00 00 00 
 10082a3:	48 c7 85 70 ff ff ff 	movq   $0x0,-0x90(%rbp)
 10082aa:	00 00 00 00 
 10082ae:	48 c7 85 70 ff ff ff 	movq   $0x10,-0x90(%rbp)
 10082b5:	10 00 00 00 
 10082b9:	48 83 fb 00          	cmp    $0x0,%rbx
 10082bd:	41 0f 9f c0          	setg   %r8b
 10082c1:	4d 0f b6 c0          	movzbq %r8b,%r8
 10082c5:	4c 89 45 90          	mov    %r8,-0x70(%rbp)
 10082c9:	48 83 fb 10          	cmp    $0x10,%rbx
 10082cd:	41 0f 93 c2          	setae  %r10b
 10082d1:	4d 0f b6 d2          	movzbq %r10b,%r10
 10082d5:	4c 89 55 98          	mov    %r10,-0x68(%rbp)
 10082d9:	48 b8 00 00 00 00 00 	movabs $0x1000000000000000,%rax
 10082e0:	00 00 10 
 10082e3:	49 89 db             	mov    %rbx,%r11
 10082e6:	49 01 c3             	add    %rax,%r11
 10082e9:	4c 89 5d a0          	mov    %r11,-0x60(%rbp)
 10082ed:	4c 89 e6             	mov    %r12,%rsi
 10082f0:	41 bc 00 00 00 00    	mov    $0x0,%r12d
 10082f6:	41 b9 00 00 00 00    	mov    $0x0,%r9d
 10082fc:	0f 1f 40 00          	nopl   0x0(%rax)
 1008300:	4c 89 4d 88          	mov    %r9,-0x78(%rbp)
 1008304:	4c 89 8d 70 ff ff ff 	mov    %r9,-0x90(%rbp)
 100830b:	48 c7 85 78 ff ff ff 	movq   $0x10,-0x88(%rbp)
 1008312:	10 00 00 00 
 1008316:	49 83 f9 10          	cmp    $0x10,%r9
 100831a:	0f 9c c0             	setl   %al
 100831d:	48 0f b6 c0          	movzbq %al,%rax
 1008321:	48 89 85 70 ff ff ff 	mov    %rax,-0x90(%rbp)
 1008328:	0f 8d 68 03 00 00    	jge    1008696 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1546>
 100832e:	4c 89 a5 70 ff ff ff 	mov    %r12,-0x90(%rbp)
 1008335:	4c 89 8d 78 ff ff ff 	mov    %r9,-0x88(%rbp)
 100833c:	4d 89 e6             	mov    %r12,%r14
 100833f:	4d 01 cc             	add    %r9,%r12
 1008342:	4c 89 f0             	mov    %r14,%rax
 1008345:	4c 31 e0             	xor    %r12,%rax
 1008348:	4c 89 c9             	mov    %r9,%rcx
 100834b:	4c 31 e1             	xor    %r12,%rcx
 100834e:	48 21 c8             	and    %rcx,%rax
 1008351:	48 83 f8 00          	cmp    $0x0,%rax
 1008355:	0f 8c 20 03 00 00    	jl     100867b <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x152b>
 100835b:	4c 89 a5 70 ff ff ff 	mov    %r12,-0x90(%rbp)
 1008362:	48 c7 85 70 ff ff ff 	movq   $0x0,-0x90(%rbp)
 1008369:	00 00 00 00 
 100836d:	48 89 9d 70 ff ff ff 	mov    %rbx,-0x90(%rbp)
 1008374:	8b 85 10 ff ff ff    	mov    -0xf0(%rbp),%eax
 100837a:	8b 8d 88 fe ff ff    	mov    -0x178(%rbp),%ecx
 1008380:	83 f9 02             	cmp    $0x2,%ecx
 1008383:	0f 94 c1             	sete   %cl
 1008386:	0f b6 c9             	movzbl %cl,%ecx
 1008389:	85 c1                	test   %eax,%ecx
 100838b:	75 08                	jne    1008395 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1245>
 100838d:	41 be 00 00 00 00    	mov    $0x0,%r14d
 1008393:	eb 7b                	jmp    1008410 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x12c0>
 1008395:	8b 85 18 ff ff ff    	mov    -0xe8(%rbp),%eax
 100839b:	83 f8 00             	cmp    $0x0,%eax
 100839e:	74 08                	je     10083a8 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1258>
 10083a0:	41 be 00 00 00 00    	mov    $0x0,%r14d
 10083a6:	eb 68                	jmp    1008410 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x12c0>
 10083a8:	4d 85 c2             	test   %r8,%r10
 10083ab:	75 08                	jne    10083b5 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1265>
 10083ad:	41 be 00 00 00 00    	mov    $0x0,%r14d
 10083b3:	eb 5b                	jmp    1008410 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x12c0>
 10083b5:	48 b8 00 00 00 00 00 	movabs $0x2000000000000000,%rax
 10083bc:	00 00 20 
 10083bf:	49 39 c3             	cmp    %rax,%r11
 10083c2:	76 08                	jbe    10083cc <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x127c>
 10083c4:	41 be 00 00 00 00    	mov    $0x0,%r14d
 10083ca:	eb 44                	jmp    1008410 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x12c0>
 10083cc:	48 b8 00 00 00 00 00 	movabs $0x1000000000000000,%rax
 10083d3:	00 00 10 
 10083d6:	4c 89 e1             	mov    %r12,%rcx
 10083d9:	48 01 c1             	add    %rax,%rcx
 10083dc:	48 b8 00 00 00 00 00 	movabs $0x2000000000000000,%rax
 10083e3:	00 00 20 
 10083e6:	48 39 c1             	cmp    %rax,%rcx
 10083e9:	76 08                	jbe    10083f3 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x12a3>
 10083eb:	41 be 00 00 00 00    	mov    $0x0,%r14d
 10083f1:	eb 1d                	jmp    1008410 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x12c0>
 10083f3:	48 8b 85 68 ff ff ff 	mov    -0x98(%rbp),%rax
 10083fa:	48 8b 08             	mov    (%rax),%rcx
 10083fd:	48 39 cb             	cmp    %rcx,%rbx
 1008400:	0f 8e 66 01 00 00    	jle    100856c <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x141c>
 1008406:	41 be 00 00 00 00    	mov    $0x0,%r14d
 100840c:	0f 1f 40 00          	nopl   0x0(%rax)
 1008410:	4c 89 b5 70 ff ff ff 	mov    %r14,-0x90(%rbp)
 1008417:	48 89 9d 78 ff ff ff 	mov    %rbx,-0x88(%rbp)
 100841e:	49 39 de             	cmp    %rbx,%r14
 1008421:	0f 9c c0             	setl   %al
 1008424:	48 0f b6 c0          	movzbq %al,%rax
 1008428:	48 89 85 70 ff ff ff 	mov    %rax,-0x90(%rbp)
 100842f:	0f 8d 22 01 00 00    	jge    1008557 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1407>
 1008435:	48 8b 85 68 ff ff ff 	mov    -0x98(%rbp),%rax
 100843c:	48 89 85 70 ff ff ff 	mov    %rax,-0x90(%rbp)
 1008443:	4c 89 b5 78 ff ff ff 	mov    %r14,-0x88(%rbp)
 100844a:	48 8b 10             	mov    (%rax),%rdx
 100844d:	4c 89 f1             	mov    %r14,%rcx
 1008450:	48 c1 f9 3f          	sar    $0x3f,%rcx
 1008454:	48 21 d1             	and    %rdx,%rcx
 1008457:	4c 01 f1             	add    %r14,%rcx
 100845a:	48 39 d1             	cmp    %rdx,%rcx
 100845d:	0f 83 ea 00 00 00    	jae    100854d <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x13fd>
 1008463:	48 8b 40 20          	mov    0x20(%rax),%rax
 1008467:	48 0f b6 04 08       	movzbq (%rax,%rcx,1),%rax
 100846c:	48 89 85 70 ff ff ff 	mov    %rax,-0x90(%rbp)
 1008473:	8b 85 18 ff ff ff    	mov    -0xe8(%rbp),%eax
 1008479:	83 f8 00             	cmp    $0x0,%eax
 100847c:	74 0e                	je     100848c <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x133c>
 100847e:	4c 89 ee             	mov    %r13,%rsi
 1008481:	49 89 ff             	mov    %rdi,%r15
 1008484:	e8 77 06 00 00       	call   1008b00 <myl_qbe_rc_slot_drop>
 1008489:	4c 89 ff             	mov    %r15,%rdi
 100848c:	48 8b 85 70 ff ff ff 	mov    -0x90(%rbp),%rax
 1008493:	48 89 85 70 ff ff ff 	mov    %rax,-0x90(%rbp)
 100849a:	48 c7 85 78 ff ff ff 	movq   $0x6d,-0x88(%rbp)
 10084a1:	6d 00 00 00 
 10084a5:	48 83 f8 6d          	cmp    $0x6d,%rax
 10084a9:	0f 94 c0             	sete   %al
 10084ac:	48 0f b6 c0          	movzbq %al,%rax
 10084b0:	48 89 85 70 ff ff ff 	mov    %rax,-0x90(%rbp)
 10084b7:	75 2c                	jne    10084e5 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1395>
 10084b9:	4c 89 a5 70 ff ff ff 	mov    %r12,-0x90(%rbp)
 10084c0:	48 c7 85 78 ff ff ff 	movq   $0x1,-0x88(%rbp)
 10084c7:	01 00 00 00 
 10084cb:	48 b8 fe ff ff ff ff 	movabs $0x7ffffffffffffffe,%rax
 10084d2:	ff ff 7f 
 10084d5:	49 39 c4             	cmp    %rax,%r12
 10084d8:	7f 59                	jg     1008533 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x13e3>
 10084da:	49 83 c4 01          	add    $0x1,%r12
 10084de:	4c 89 a5 70 ff ff ff 	mov    %r12,-0x90(%rbp)
 10084e5:	4c 89 b5 70 ff ff ff 	mov    %r14,-0x90(%rbp)
 10084ec:	48 c7 85 78 ff ff ff 	movq   $0x1,-0x88(%rbp)
 10084f3:	01 00 00 00 
 10084f7:	48 b8 fe ff ff ff ff 	movabs $0x7ffffffffffffffe,%rax
 10084fe:	ff ff 7f 
 1008501:	49 39 c6             	cmp    %rax,%r14
 1008504:	7f 10                	jg     1008516 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x13c6>
 1008506:	49 83 c6 01          	add    $0x1,%r14
 100850a:	4c 89 b5 70 ff ff ff 	mov    %r14,-0x90(%rbp)
 1008511:	e9 fa fe ff ff       	jmp    1008410 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x12c0>
 1008516:	4c 89 f6             	mov    %r14,%rsi
 1008519:	41 b8 40 00 00 00    	mov    $0x40,%r8d
 100851f:	b9 01 00 00 00       	mov    $0x1,%ecx
 1008524:	48 89 f2             	mov    %rsi,%rdx
 1008527:	be 00 00 00 00       	mov    $0x0,%esi
 100852c:	e8 3f 0c 00 00       	call   1009170 <myl_qbe_fail_overflow_op>
 1008531:	0f 0b                	ud2
 1008533:	41 b8 40 00 00 00    	mov    $0x40,%r8d
 1008539:	b9 01 00 00 00       	mov    $0x1,%ecx
 100853e:	4c 89 e2             	mov    %r12,%rdx
 1008541:	be 00 00 00 00       	mov    $0x0,%esi
 1008546:	e8 25 0c 00 00       	call   1009170 <myl_qbe_fail_overflow_op>
 100854b:	0f 0b                	ud2
 100854d:	4c 89 f6             	mov    %r14,%rsi
 1008550:	e8 ab 0b 00 00       	call   1009100 <myl_qbe_fail_index_bounds>
 1008555:	0f 0b                	ud2
 1008557:	4c 8b 4d 88          	mov    -0x78(%rbp),%r9
 100855b:	4c 8b 5d a0          	mov    -0x60(%rbp),%r11
 100855f:	4c 8b 55 98          	mov    -0x68(%rbp),%r10
 1008563:	4c 8b 45 90          	mov    -0x70(%rbp),%r8
 1008567:	e9 ba 00 00 00       	jmp    1008626 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x14d6>
 100856c:	48 8b 50 20          	mov    0x20(%rax),%rdx
 1008570:	b9 00 00 00 00       	mov    $0x0,%ecx
 1008575:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
 100857c:	00 00 00 
 100857f:	90                   	nop
 1008580:	48 89 8d 70 ff ff ff 	mov    %rcx,-0x90(%rbp)
 1008587:	48 89 9d 78 ff ff ff 	mov    %rbx,-0x88(%rbp)
 100858e:	48 39 d9             	cmp    %rbx,%rcx
 1008591:	41 0f 9c c6          	setl   %r14b
 1008595:	4d 0f b6 f6          	movzbq %r14b,%r14
 1008599:	4c 89 b5 70 ff ff ff 	mov    %r14,-0x90(%rbp)
 10085a0:	0f 8d 80 00 00 00    	jge    1008626 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x14d6>
 10085a6:	48 89 85 70 ff ff ff 	mov    %rax,-0x90(%rbp)
 10085ad:	48 89 8d 78 ff ff ff 	mov    %rcx,-0x88(%rbp)
 10085b4:	4c 0f b6 34 0a       	movzbq (%rdx,%rcx,1),%r14
 10085b9:	4c 89 b5 70 ff ff ff 	mov    %r14,-0x90(%rbp)
 10085c0:	4c 89 b5 70 ff ff ff 	mov    %r14,-0x90(%rbp)
 10085c7:	48 c7 85 78 ff ff ff 	movq   $0x6d,-0x88(%rbp)
 10085ce:	6d 00 00 00 
 10085d2:	49 83 fe 6d          	cmp    $0x6d,%r14
 10085d6:	41 0f 94 c6          	sete   %r14b
 10085da:	4d 0f b6 f6          	movzbq %r14b,%r14
 10085de:	4c 89 b5 70 ff ff ff 	mov    %r14,-0x90(%rbp)
 10085e5:	75 1d                	jne    1008604 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x14b4>
 10085e7:	4c 89 a5 70 ff ff ff 	mov    %r12,-0x90(%rbp)
 10085ee:	48 c7 85 78 ff ff ff 	movq   $0x1,-0x88(%rbp)
 10085f5:	01 00 00 00 
 10085f9:	49 83 c4 01          	add    $0x1,%r12
 10085fd:	4c 89 a5 70 ff ff ff 	mov    %r12,-0x90(%rbp)
 1008604:	48 89 8d 70 ff ff ff 	mov    %rcx,-0x90(%rbp)
 100860b:	48 c7 85 78 ff ff ff 	movq   $0x1,-0x88(%rbp)
 1008612:	01 00 00 00 
 1008616:	48 83 c1 01          	add    $0x1,%rcx
 100861a:	48 89 8d 70 ff ff ff 	mov    %rcx,-0x90(%rbp)
 1008621:	e9 5a ff ff ff       	jmp    1008580 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1430>
 1008626:	4c 89 8d 70 ff ff ff 	mov    %r9,-0x90(%rbp)
 100862d:	48 c7 85 78 ff ff ff 	movq   $0x1,-0x88(%rbp)
 1008634:	01 00 00 00 
 1008638:	48 b8 fe ff ff ff ff 	movabs $0x7ffffffffffffffe,%rax
 100863f:	ff ff 7f 
 1008642:	49 39 c1             	cmp    %rax,%r9
 1008645:	7f 14                	jg     100865b <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x150b>
 1008647:	49 83 c1 01          	add    $0x1,%r9
 100864b:	4c 89 8d 70 ff ff ff 	mov    %r9,-0x90(%rbp)
 1008652:	48 8b 75 80          	mov    -0x80(%rbp),%rsi
 1008656:	e9 a5 fc ff ff       	jmp    1008300 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x11b0>
 100865b:	4c 89 c9             	mov    %r9,%rcx
 100865e:	41 b8 40 00 00 00    	mov    $0x40,%r8d
 1008664:	48 89 c8             	mov    %rcx,%rax
 1008667:	b9 01 00 00 00       	mov    $0x1,%ecx
 100866c:	48 89 c2             	mov    %rax,%rdx
 100866f:	be 00 00 00 00       	mov    $0x0,%esi
 1008674:	e8 f7 0a 00 00       	call   1009170 <myl_qbe_fail_overflow_op>
 1008679:	0f 0b                	ud2
 100867b:	4c 89 f3             	mov    %r14,%rbx
 100867e:	4c 89 c9             	mov    %r9,%rcx
 1008681:	41 b8 40 00 00 00    	mov    $0x40,%r8d
 1008687:	48 89 da             	mov    %rbx,%rdx
 100868a:	be 00 00 00 00       	mov    $0x0,%esi
 100868f:	e8 dc 0a 00 00       	call   1009170 <myl_qbe_fail_overflow_op>
 1008694:	0f 0b                	ud2
 1008696:	4c 89 e3             	mov    %r12,%rbx
 1008699:	49 89 f4             	mov    %rsi,%r12
 100869c:	4c 89 a5 70 ff ff ff 	mov    %r12,-0x90(%rbp)
 10086a3:	48 89 9d 78 ff ff ff 	mov    %rbx,-0x88(%rbp)
 10086aa:	4c 89 e6             	mov    %r12,%rsi
 10086ad:	48 89 fb             	mov    %rdi,%rbx
 10086b0:	e8 2b 29 00 00       	call   100afe0 <myl_qbe_stream_begin>
 10086b5:	4c 89 e2             	mov    %r12,%rdx
 10086b8:	48 89 df             	mov    %rbx,%rdi
 10086bb:	48 89 c6             	mov    %rax,%rsi
 10086be:	49 89 d5             	mov    %rdx,%r13
 10086c1:	ba 00 00 00 00       	mov    $0x0,%edx
 10086c6:	49 89 f4             	mov    %rsi,%r12
 10086c9:	48 8d b5 78 ff ff ff 	lea    -0x88(%rbp),%rsi
 10086d0:	48 89 fb             	mov    %rdi,%rbx
 10086d3:	4c 89 e7             	mov    %r12,%rdi
 10086d6:	e8 75 00 00 00       	call   1008750 <myl_r_1a91deb3742283487d66c3b500f6effd7ef1170e6d4b4368fe9ec3c3f0354fda>
 10086db:	4c 89 e6             	mov    %r12,%rsi
 10086de:	48 89 df             	mov    %rbx,%rdi
 10086e1:	49 89 f4             	mov    %rsi,%r12
 10086e4:	be 0a 00 00 00       	mov    $0xa,%esi
 10086e9:	48 89 fb             	mov    %rdi,%rbx
 10086ec:	4c 89 e7             	mov    %r12,%rdi
 10086ef:	e8 3c 28 00 00       	call   100af30 <myl_qbe_print_byte>
 10086f4:	4c 89 ea             	mov    %r13,%rdx
 10086f7:	4c 89 e6             	mov    %r12,%rsi
 10086fa:	48 89 df             	mov    %rbx,%rdi
 10086fd:	48 89 fb             	mov    %rdi,%rbx
 1008700:	e8 1b 29 00 00       	call   100b020 <myl_qbe_stream_finish>
 1008705:	48 89 df             	mov    %rbx,%rdi
 1008708:	48 c7 85 70 ff ff ff 	movq   $0x0,-0x90(%rbp)
 100870f:	00 00 00 00 
 1008713:	48 c7 85 70 ff ff ff 	movq   $0x0,-0x90(%rbp)
 100871a:	00 00 00 00 
 100871e:	48 8d b5 d0 fd ff ff 	lea    -0x230(%rbp),%rsi
 1008725:	48 89 fb             	mov    %rdi,%rbx
 1008728:	e8 03 05 00 00       	call   1008c30 <myl_qbe_rc_frame_cleanup>
 100872d:	48 89 df             	mov    %rbx,%rdi
 1008730:	48 8d b5 d0 fd ff ff 	lea    -0x230(%rbp),%rsi
 1008737:	e8 64 03 00 00       	call   1008aa0 <myl_qbe_rc_frame_leave>
 100873c:	b8 00 00 00 00       	mov    $0x0,%eax
 1008741:	41 5f                	pop    %r15
 1008743:	41 5e                	pop    %r14
 1008745:	41 5d                	pop    %r13
 1008747:	41 5c                	pop    %r12
 1008749:	5b                   	pop    %rbx
 100874a:	c9                   	leave
 100874b:	c3                   	ret

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
