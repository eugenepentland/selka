from pathlib import Path
import os,subprocess,json,hashlib
r=Path.cwd();w=r/'.tmp-rc/loop-operands';e={k:v for k,v in os.environ.items() if not k.startswith('MYLANG_') and k!='LD_PRELOAD'};e['TMPDIR']=str(r/'.tmp-rc/tmp')
cs={side:r/('.tmp-rc/install-loop-guard-pc/bin/mylang' if side=='before' else '.tmp-rc/install-loop-operands-prototype/bin/mylang') for side in ['before','after']};sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();d={'emission':[],'runs':[]}
def save():(w/'guests.json').write_text(json.dumps(d,indent=2)+'\n')
for name,expected in [('rc_loop_operand_isolation','12\n'),('rc_loop_guard_context','220\n')]:
 s=r/'tests/lang'/f'{name}.my';em=[]
 for side,c in cs.items():
  cmd=[str(r/'scripts/build-slot.sh'),'build',str(c),'emit-qbe',str(s),'--gc-runtime','--drop-step-checks','--drop-frame-checks','--drop-debug'];p=subprocess.run(cmd,env=e,text=True,capture_output=True);assert not p.returncode,p.stderr;em.append(p.stdout);(w/f'{name}-{side}-gc-emission.json').write_text(p.stdout)
  d['emission'].append(dict(source=str(s),source_sha256=sha(s),side=side,command=cmd,compiler_sha256=sha(c),sha256=hashlib.sha256(p.stdout.encode()).hexdigest()));save()
 assert em[0]==em[1]
 for backend in ['qbe','llvm']:
  for mode in ['gc','rc']:
   c=cs['after'];b=w/f'guest-{name}-{backend}-{mode}';cmd=[str(r/'scripts/build-slot.sh'),'build',str(c),'build',str(s),'-o',str(b),'--mode=ReleaseFast','--backend='+backend,'--gc-runtime' if mode=='gc' else '--rc-runtime=stats','--cache-dir='+str(w/'cache-after')]
   if backend=='llvm':cmd+=['--llvm-opt=3','--lto=full']
   p=subprocess.run(cmd,env=e,text=True,capture_output=True);row=dict(source=str(s),source_sha256=sha(s),backend=backend,mode=mode,build=cmd,build_status=p.returncode,build_stderr=p.stderr);d['runs'].append(row);save();assert not p.returncode,row
   row['manifest']=json.loads(Path(str(b)+'.qbe-manifest.json').read_text());assert row['manifest']['backend']==backend;row['binary_sha256']=sha(b)
   p=subprocess.run([str(b)],env=e,text=True,capture_output=True,timeout=60);row.update(command=[str(b)],status=p.returncode,stdout=p.stdout,stderr=p.stderr);save();assert not p.returncode and p.stdout==expected,row
   if mode=='rc':
    c=json.loads(next(x.removeprefix('MYLANG_RC_COUNTS ') for x in p.stderr.splitlines() if x.startswith('MYLANG_RC_COUNTS ')));row['counts']=c;assert c['heap_allocate']==c['retire'] and c['hold_acquire']==c['hold_release'] and c['owner_acquire']+c['heap_allocate']==c['owner_release'],row
   save();print(name,backend,mode,'pass',flush=True)
