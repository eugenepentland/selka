from pathlib import Path
import os,json,hashlib,subprocess
r=Path.cwd();w=r/'.tmp-rc/loop-operands';e={k:v for k,v in os.environ.items() if not k.startswith('MYLANG_') and k!='LD_PRELOAD'};e['TMPDIR']=str(r/'.tmp-rc/tmp')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
cmd=['cc','-O2','-I',str(r/'src'),str(w/'reentrant.c'),'-ldl','-o',str(w/'reentrant')];p=subprocess.run(cmd,text=True,capture_output=True);assert p.returncode==0,p.stderr
d={'harness_command':cmd,'harness_sha256':sha(w/'reentrant.c'),'source_sha256':sha(w/'reentrant.my'),'runs':[]}
def save():(w/'reentrant.json').write_text(json.dumps(d,indent=2)+'\n')
for side in ('before','after'):
 c=r/('.tmp-rc/install-loop-guard-pc/bin/mylang' if side=='before' else '.tmp-rc/install-loop-operands-prototype/bin/mylang')
 manifest=w/f'reentrant-{side}.json';cmd=[str(r/'scripts/build-slot.sh'),'build',str(c),'emit-qbe',str(w/'reentrant.my'),'--rc-runtime=stats','--drop-step-checks','--drop-debug'];p=subprocess.run(cmd,env=e,text=True,capture_output=True);assert p.returncode==0,p.stderr;manifest.write_text(p.stdout)
 m=json.loads(p.stdout);il=next(f['il'] for f in m['functions'] if f['name']=='update');assert il.count('RC-LOOP-OPERANDS-ISOLATED')==(1 if side=='after' else 0);(w/f'reentrant-{side}.ssa').write_text(il)
 for backend in ('qbe','llvm'):
  b=w/f'reentrant-{side}-{backend}.so';cmd=[str(r/'scripts/build-slot.sh'),'build',str(c),'build',str(w/'reentrant.my'),'--library','--rc-runtime=stats','--backend='+backend,'--mode=ReleaseFast','--manifest-file='+str(manifest),'-o',str(b),'--cache-dir='+str(w/f'cache-{side}')]
  if backend=='llvm':cmd+=['--llvm-opt=3','--lto=full']
  p=subprocess.run(cmd,env=e,text=True,capture_output=True);row=dict(side=side,backend=backend,compiler_sha256=sha(c),build=cmd,build_status=p.returncode,build_stderr=p.stderr);d['runs'].append(row);save();assert p.returncode==0,row
  native=json.loads(Path(str(b)+'.qbe-manifest.json').read_text());assert native['backend']==backend;row['manifest']=native
  symbol=next(x['symbol'] for x in native['functions'] if x['name']=='update');cmd=[str(w/'reentrant'),str(b),symbol];p=subprocess.run(cmd,env=e,text=True,capture_output=True,timeout=30)
  row.update(command=cmd,status=p.returncode,stdout=p.stdout,stderr=p.stderr,binary_sha256=sha(b));save();assert p.returncode==0,row
  counts=json.loads(next(x.removeprefix('MYLANG_RC_COUNTS ') for x in p.stderr.splitlines() if x.startswith('MYLANG_RC_COUNTS ')));row['counts']=counts;assert counts['heap_allocate']==counts['retire'] and counts['hold_acquire']==counts['hold_release'] and counts['owner_acquire']+counts['heap_allocate']==counts['owner_release'],row
  save();print(side,backend,p.stdout,flush=True)
assert all(x['counts']==d['runs'][0]['counts'] for x in d['runs'])
