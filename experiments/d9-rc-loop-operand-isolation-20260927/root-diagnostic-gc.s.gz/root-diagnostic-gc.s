.file 1 "myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605"
.text
.balign 16
.globl myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605
myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605:
	endbr64
	pushq %rbp
	movq %rsp, %rbp
	subq $184, %rsp
	pushq %rbx
	pushq %r12
	pushq %r13
	pushq %r14
	pushq %r15
	movq %rsi, -40(%rbp)
	movq %rdi, -48(%rbp)
	.loc 1 1
	movq %rdi, %rbx
	callq myl_qbe_require_step_accounting
	movq %rbx, %rdi
	.loc 1 1
	movq %rdi, %rbx
	callq myl_qbe_require_frame_accounting
	movq %rbx, %rdi
	.loc 1 1
	movq %rdi, %rbx
	callq myl_qbe_heap
	movq %rbx, %rdi
	movq %rax, %rbx
	.loc 1 1
	movq %rdi, %r12
	callq myl_qbe_root_mark
	movq %r12, %rdi
	movq %rax, %r15
	movq %r15, -32(%rbp)
	.loc 1 2
	movl $0, %edx
	movq myl_t_1a91deb3742283487d66c3b500f6effd7ef1170e6d4b4368fe9ec3c3f0354fda@gotpcrel(%rip), %rsi
	movq %rdi, %r12
	movq %rbx, %rdi
	callq myl_native_list_new
	movq %r12, %rdi
	movq %rax, %rsi
	cmpl $0, %esi
	jnz .Lbb2
	.loc 1 2
	callq myl_qbe_fail_allocation
	ud2
.Lbb2:
	movq 16(%rbx), %rax
	movq %rax, -152(%rbp)
	leaq -152(%rbp), %rax
	addq $24, %rax
	movq %rax, -24(%rbp)
	movq %rsi, -128(%rbp)
	movq %rax, -144(%rbp)
	movq myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527@gotpcrel(%rip), %rcx
	movq %rcx, -136(%rbp)
	movq %rax, %r12
	leaq -152(%rbp), %rax
	movq %rax, 16(%rbx)
	.loc 1 8
	movq %rdi, %r13
	callq myl_qbe_bytes_from_list
	movq %r13, %rdi
	movq %rax, %rcx
	movq %r12, %rax
	movq %rcx, -168(%rbp)
	movq %r15, 16(%rbx)
	movq -168(%rbp), %rdx
	movq %rdx, -56(%rbp)
	cmpl $0, %ecx
	jz .Lbb6
	movq %rcx, %rdx
	subq $16, %rcx
	movq (%rcx), %rcx
	movq $1152921504606846978, %rsi
	testq %rsi, %rcx
	jnz .Lbb5
	movq $2305843009213693952, %rsi
	orq %rsi, %rcx
	subq $16, %rdx
	movq %rcx, (%rdx)
	jmp .Lbb7
.Lbb5:
	movq %rdx, %rcx
.Lbb6:
	movq 16(%rbx), %rdx
	movq %rdx, -152(%rbp)
	movq %rcx, -128(%rbp)
	movq %rax, -144(%rbp)
	movq myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7@gotpcrel(%rip), %rcx
	movq %rcx, -136(%rbp)
	movq %rax, %r12
	leaq -152(%rbp), %rax
	movq %rax, 16(%rbx)
	.loc 1 9
	movl $0, %r8d
	leaq -56(%rbp), %rcx
	leaq -56(%rbp), %rdx
	movq myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7@gotpcrel(%rip), %rsi
	movq %rdi, %r13
	callq myl_qbe_cow_transfer
	movq %r13, %rdi
	movq %r12, %rax
	movq %r15, 16(%rbx)
.Lbb7:
	movq -56(%rbp), %rsi
	movq $121, -160(%rbp)
	movq myl_lit_3a31048ef22d5766c70d678fc1c59ca587d84f11b25c84fb64cb1eb13678199d(%rip), %r13
	movq %rsi, %rcx
	subq $16, %rcx
	movq (%rcx), %rcx
	shrq $61, %rcx
	movq %rcx, %rdx
	andq $1, %rdx
	leaq -120(%rbp), %rcx
	addq $24, %rcx
	movq %rcx, -16(%rbp)
	cmpl $0, %edx
	jz .Lbb10
	movq 16(%rbx), %rdx
	movq %rdx, -152(%rbp)
	movq %rsi, -128(%rbp)
	movq %rax, -144(%rbp)
	movq myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7@gotpcrel(%rip), %rdx
	movq %rdx, -136(%rbp)
	leaq -152(%rbp), %rdx
	movq %rdx, 16(%rbx)
	leaq -152(%rbp), %rdx
	movq %rdx, -120(%rbp)
	movq %r13, -96(%rbp)
	movq %rcx, -112(%rbp)
	movq myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9@gotpcrel(%rip), %rcx
	movq %rcx, -104(%rbp)
	movq %rax, %r12
	leaq -120(%rbp), %rax
	movq %rax, 16(%rbx)
	.loc 1 81
	movq %rdi, %r14
	movq %rbx, %rdi
	callq myl_native_cow_unique
	movq %r14, %rdi
	movq %rax, %rsi
	movq %r12, %rax
	movq -16(%rbp), %rcx
	movq %r15, 16(%rbx)
	cmpl $0, %esi
	jnz .Lbb10
	.loc 1 81
	callq myl_qbe_fail_allocation
	ud2
.Lbb10:
	leaq -88(%rbp), %rdx
	addq $24, %rdx
	movq %rdx, -8(%rbp)
	movq %rsi, %r12
	movl $0, %r14d
.p2align 4
.Lbb12:
	movq $131072, -160(%rbp)
	cmpq $131072, %r14
	jge .Lbb23
	movq $0, -160(%rbp)
	movq (%r13), %rsi
	cmpq $64, %rsi
	jb .Lbb19
	movq (%r12), %rsi
	movq 8(%r12), %rdi
	subq %rsi, %rdi
	cmpq $64, %rdi
	ja .Lbb18
	movq 16(%rbx), %rsi
	movq %rsi, -152(%rbp)
	movq %r12, -128(%rbp)
	movq %rax, -144(%rbp)
	movq myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7@gotpcrel(%rip), %rax
	movq %rax, -136(%rbp)
	leaq -152(%rbp), %rax
	movq %rax, 16(%rbx)
	leaq -152(%rbp), %rax
	movq %rax, -120(%rbp)
	movq %r13, -96(%rbp)
	movq %rcx, -112(%rbp)
	movq myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9@gotpcrel(%rip), %rax
	movq %rax, -104(%rbp)
	leaq -120(%rbp), %rax
	movq %rax, 16(%rbx)
	leaq -120(%rbp), %rax
	movq %rax, -88(%rbp)
	movq %r13, -64(%rbp)
	movq %rdx, -80(%rbp)
	movq myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9@gotpcrel(%rip), %rax
	movq %rax, -72(%rbp)
	leaq -88(%rbp), %rax
	movq %rax, 16(%rbx)
	.loc 1 88
	movl $64, %r8d
	movl $0, %ecx
	movq %r13, %rdx
	movq %r12, %rsi
	movq %rbx, %rdi
	callq myl_native_bytes_buffer_append_range
	movl %eax, %esi
	movq -8(%rbp), %rdx
	movq -16(%rbp), %rcx
	movq -24(%rbp), %rax
	movq %r15, 16(%rbx)
	movl %esi, %esi
	cmpq $0, %rsi
	jnz .Lbb19
	movq -48(%rbp), %rdi
	.loc 1 88
	callq myl_qbe_fail_allocation
	ud2
.Lbb18:
	movq 32(%r12), %rax
	movq %rax, %rdi
	addq %rsi, %rdi
	movq %rsi, %r15
	movq 32(%r13), %rsi
	.loc 1 88
	movl $64, %edx
	callq myl_native_bytes_copy_octets
	movq %r15, %rsi
	movq -8(%rbp), %rdx
	movq -16(%rbp), %rcx
	movq -24(%rbp), %rax
	movq -32(%rbp), %r15
	addq $64, %rsi
	movq %rsi, (%r12)
.Lbb19:
	movq $1, -160(%rbp)
	movq $9223372036854775806, %rsi
	cmpq %rsi, %r14
	jg .Lbb21
	addq $1, %r14
	jmp .Lbb12
.Lbb21:
	movq %r14, %rdx
	movq -48(%rbp), %rdi
	.loc 1 92
	movl $64, %r8d
	movl $1, %ecx
	movl $0, %esi
	callq myl_qbe_fail_overflow_op
	ud2
.Lbb23:
	movq %r12, %rsi
	movq -40(%rbp), %r13
	movq -48(%rbp), %rdi
	movq 16(%rbx), %rcx
	movq %rcx, -152(%rbp)
	movq %rsi, -128(%rbp)
	movq %rax, -144(%rbp)
	movq myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7@gotpcrel(%rip), %rax
	movq %rax, -136(%rbp)
	leaq -152(%rbp), %rax
	movq %rax, 16(%rbx)
	.loc 1 96
	movq %rdi, %r12
	callq myl_qbe_bytes_snapshot
	movq %r13, %rdx
	movq %r12, %rdi
	movq %rax, %rcx
	movq %r15, 16(%rbx)
	movq (%rcx), %rax
	cmpq $0, %rax
	setg %r11b
	movzbq %r11b, %r11
	cmpq $16, %rax
	setae %bl
	movzbq %bl, %rbx
	movq $1152921504606846976, %rsi
	movq %rax, %r12
	addq %rsi, %r12
	movq %rdx, %rsi
	movl $0, %edx
	movl $0, %r10d
.p2align 4
.Lbb26:
	movq $16, -160(%rbp)
	cmpq $16, %r10
	jge .Lbb60
	movq %r10, -160(%rbp)
	movq %rdx, %r9
	addq %r10, %rdx
	movq %r9, %r8
	xorq %rdx, %r8
	movq %r10, %r13
	xorq %rdx, %r13
	andq %r13, %r8
	cmpq $0, %r8
	jl .Lbb58
	testq %r11, %rbx
	jnz .Lbb30
	movl $0, %r9d
	jmp .Lbb36
.Lbb30:
	movq $2305843009213693952, %r8
	cmpq %r8, %r12
	jbe .Lbb32
	movl $0, %r9d
	jmp .Lbb36
.Lbb32:
	movq $1152921504606846976, %r8
	movq %rdx, %r9
	addq %r8, %r9
	movq $2305843009213693952, %r8
	cmpq %r8, %r9
	jbe .Lbb34
	movl $0, %r9d
	jmp .Lbb36
.Lbb34:
	movq (%rcx), %r8
	cmpq %r8, %rax
	jle .Lbb48
	movl $0, %r9d
.p2align 4
.Lbb36:
	movq %rax, -160(%rbp)
	cmpq %rax, %r9
	jge .Lbb54
	movq %r9, -160(%rbp)
	movq (%rcx), %r8
	movq %r9, %r13
	sarq $63, %r13
	andq %r8, %r13
	addq %r9, %r13
	cmpq %r8, %r13
	jae .Lbb46
	movq 32(%rcx), %r8
	movzbq (%r8, %r13, 1), %r8
	movq $109, -160(%rbp)
	cmpq $109, %r8
	jnz .Lbb41
	movq $1, -160(%rbp)
	movq $9223372036854775806, %r8
	cmpq %r8, %rdx
	jg .Lbb45
	addq $1, %rdx
.Lbb41:
	movq $1, -160(%rbp)
	movq $9223372036854775806, %r8
	cmpq %r8, %r9
	jg .Lbb43
	addq $1, %r9
	jmp .Lbb36
.Lbb43:
	movq %r9, %rsi
	.loc 1 136
	movl $64, %r8d
	movl $1, %ecx
	movq %rsi, %rdx
	movl $0, %esi
	callq myl_qbe_fail_overflow_op
	ud2
.Lbb45:
	.loc 1 132
	movl $64, %r8d
	movl $1, %ecx
	movl $0, %esi
	callq myl_qbe_fail_overflow_op
	ud2
.Lbb46:
	movq %r8, %rdx
	movq %r9, %rsi
	.loc 1 125
	callq myl_qbe_fail_index_bounds
	ud2
.Lbb48:
	movq 32(%rcx), %r9
	movl $0, %r8d
.p2align 4
.Lbb50:
	movq %rax, -160(%rbp)
	cmpq %rax, %r8
	jge .Lbb54
	movq %r8, -160(%rbp)
	movzbq (%r9, %r8, 1), %r13
	movq $109, -160(%rbp)
	cmpq $109, %r13
	jnz .Lbb53
	movq $1, -160(%rbp)
	addq $1, %rdx
.Lbb53:
	movq $1, -160(%rbp)
	addq $1, %r8
	jmp .Lbb50
.Lbb54:
	movq $1, -160(%rbp)
	movq $9223372036854775806, %r8
	cmpq %r8, %r10
	jg .Lbb56
	addq $1, %r10
	jmp .Lbb26
.Lbb56:
	movq %r10, %rcx
	.loc 1 141
	movl $64, %r8d
	movq %rcx, %rax
	movl $1, %ecx
	movq %rax, %rdx
	movl $0, %esi
	callq myl_qbe_fail_overflow_op
	ud2
.Lbb58:
	movq %r9, %rdx
	movq %r10, %rcx
	.loc 1 113
	movl $64, %r8d
	movl $0, %esi
	callq myl_qbe_fail_overflow_op
	ud2
.Lbb60:
	movq %rsi, %r12
	movq %rdx, -160(%rbp)
	.loc 1 146
	movq %r12, %rsi
	movq %rdi, %rbx
	callq myl_qbe_stream_begin
	movq %r12, %rdx
	movq %rbx, %rdi
	movq %rax, %rsi
	.loc 1 146
	movq %rdx, %r13
	movl $0, %edx
	movq %rsi, %r12
	leaq -160(%rbp), %rsi
	movq %rdi, %rbx
	movq %r12, %rdi
	callq myl_r_1a91deb3742283487d66c3b500f6effd7ef1170e6d4b4368fe9ec3c3f0354fda
	movq %r12, %rsi
	movq %rbx, %rdi
	.loc 1 146
	movq %rsi, %r12
	movl $10, %esi
	movq %rdi, %rbx
	movq %r12, %rdi
	callq myl_qbe_print_byte
	movq %r13, %rdx
	movq %r12, %rsi
	movq %rbx, %rdi
	.loc 1 146
	callq myl_qbe_stream_finish
	movl $0, %eax
	popq %r15
	popq %r14
	popq %r13
	popq %r12
	popq %rbx
	leave
	ret
.type myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605, @function
.size myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605, .-myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605
/* end function myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605 */

.section .note.GNU-stack,"",@progbits
