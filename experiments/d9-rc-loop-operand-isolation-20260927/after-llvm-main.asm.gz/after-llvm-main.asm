
/home/epentland/ai/canopy/mylang-worktrees/d9-rc-compiler-astra/.tmp-rc/loop-operands/after-llvm-rc:     file format elf64-x86-64


Disassembly of section .text:

000000000100b240 <entry_run>:
 100b240:	55                   	push   %rbp
 100b241:	48 89 e5             	mov    %rsp,%rbp
 100b244:	41 57                	push   %r15
 100b246:	41 56                	push   %r14
 100b248:	41 55                	push   %r13
 100b24a:	41 54                	push   %r12
 100b24c:	53                   	push   %rbx
 100b24d:	48 83 e4 e0          	and    $0xffffffffffffffe0,%rsp
 100b251:	48 81 ec a0 02 00 00 	sub    $0x2a0,%rsp
 100b258:	48 89 fb             	mov    %rdi,%rbx
 100b25b:	48 83 bf a0 38 00 00 	cmpq   $0x0,0x38a0(%rdi)
 100b262:	00 
 100b263:	74 10                	je     100b275 <entry_run+0x35>
 100b265:	48 83 7b 20 00       	cmpq   $0x0,0x20(%rbx)
 100b26a:	0f 85 f0 21 00 00    	jne    100d460 <entry_run+0x2220>
 100b270:	e9 10 01 00 00       	jmp    100b385 <entry_run+0x145>
 100b275:	bf 01 00 00 00       	mov    $0x1,%edi
 100b27a:	be 40 00 00 00       	mov    $0x40,%esi
 100b27f:	e8 4c 39 01 00       	call   101ebd0 <calloc@plt>
 100b284:	48 85 c0             	test   %rax,%rax
 100b287:	0f 84 c7 00 00 00    	je     100b354 <entry_run+0x114>
 100b28d:	48 89 83 a0 38 00 00 	mov    %rax,0x38a0(%rbx)
 100b294:	48 8b 8b 70 38 00 00 	mov    0x3870(%rbx),%rcx
 100b29b:	48 8d 91 a0 00 00 00 	lea    0xa0(%rcx),%rdx
 100b2a2:	48 85 c9             	test   %rcx,%rcx
 100b2a5:	b9 18 2f 00 01       	mov    $0x1002f18,%ecx
 100b2aa:	48 0f 45 ca          	cmovne %rdx,%rcx
 100b2ae:	48 89 08             	mov    %rcx,(%rax)
 100b2b1:	48 83 79 08 00       	cmpq   $0x0,0x8(%rcx)
 100b2b6:	74 0a                	je     100b2c2 <entry_run+0x82>
 100b2b8:	48 83 39 00          	cmpq   $0x0,(%rcx)
 100b2bc:	0f 84 99 00 00 00    	je     100b35b <entry_run+0x11b>
 100b2c2:	48 8b 51 10          	mov    0x10(%rcx),%rdx
 100b2c6:	48 85 d2             	test   %rdx,%rdx
 100b2c9:	be 10 27 00 00       	mov    $0x2710,%esi
 100b2ce:	48 0f 45 f2          	cmovne %rdx,%rsi
 100b2d2:	48 89 70 18          	mov    %rsi,0x18(%rax)
 100b2d6:	48 8b 51 18          	mov    0x18(%rcx),%rdx
 100b2da:	48 85 d2             	test   %rdx,%rdx
 100b2dd:	be 40 42 0f 00       	mov    $0xf4240,%esi
 100b2e2:	48 0f 45 f2          	cmovne %rdx,%rsi
 100b2e6:	48 89 70 10          	mov    %rsi,0x10(%rax)
 100b2ea:	48 8b 51 20          	mov    0x20(%rcx),%rdx
 100b2ee:	48 85 d2             	test   %rdx,%rdx
 100b2f1:	bf 00 00 01 00       	mov    $0x10000,%edi
 100b2f6:	48 0f 45 fa          	cmovne %rdx,%rdi
 100b2fa:	48 89 78 20          	mov    %rdi,0x20(%rax)
 100b2fe:	48 8b 71 28          	mov    0x28(%rcx),%rsi
 100b302:	48 85 f6             	test   %rsi,%rsi
 100b305:	ba 40 00 00 00       	mov    $0x40,%edx
 100b30a:	48 0f 45 d6          	cmovne %rsi,%rdx
 100b30e:	48 89 50 28          	mov    %rdx,0x28(%rax)
 100b312:	4c 8b 41 30          	mov    0x30(%rcx),%r8
 100b316:	4d 85 c0             	test   %r8,%r8
 100b319:	be 00 00 10 00       	mov    $0x100000,%esi
 100b31e:	49 0f 45 f0          	cmovne %r8,%rsi
 100b322:	48 89 70 30          	mov    %rsi,0x30(%rax)
 100b326:	48 81 ff a0 86 01 00 	cmp    $0x186a0,%rdi
 100b32d:	77 1e                	ja     100b34d <entry_run+0x10d>
 100b32f:	48 81 fa 81 00 00 00 	cmp    $0x81,%rdx
 100b336:	0f 93 c2             	setae  %dl
 100b339:	48 81 fe 01 00 00 04 	cmp    $0x4000001,%rsi
 100b340:	40 0f 93 c6          	setae  %sil
 100b344:	40 08 d6             	or     %dl,%sil
 100b347:	40 80 fe 01          	cmp    $0x1,%sil
 100b34b:	75 15                	jne    100b362 <entry_run+0x122>
 100b34d:	be a2 30 00 01       	mov    $0x10030a2,%esi
 100b352:	eb 1e                	jmp    100b372 <entry_run+0x132>
 100b354:	be 52 2f 00 01       	mov    $0x1002f52,%esi
 100b359:	eb 17                	jmp    100b372 <entry_run+0x132>
 100b35b:	be f3 31 00 01       	mov    $0x10031f3,%esi
 100b360:	eb 10                	jmp    100b372 <entry_run+0x132>
 100b362:	48 83 79 08 00       	cmpq   $0x0,0x8(%rcx)
 100b367:	0f 84 5d 09 00 00    	je     100bcca <entry_run+0xa8a>
 100b36d:	be df 31 00 01       	mov    $0x10031df,%esi
 100b372:	48 89 df             	mov    %rbx,%rdi
 100b375:	e8 e6 2a 00 00       	call   100de60 <fail>
 100b37a:	48 83 7b 20 00       	cmpq   $0x0,0x20(%rbx)
 100b37f:	0f 85 db 20 00 00    	jne    100d460 <entry_run+0x2220>
 100b385:	48 c7 84 24 60 02 00 	movq   $0x0,0x260(%rsp)
 100b38c:	00 00 00 00 00 
 100b391:	48 c7 84 24 f8 00 00 	movq   $0x0,0xf8(%rsp)
 100b398:	00 00 00 00 00 
 100b39d:	48 c7 44 24 38 00 00 	movq   $0x0,0x38(%rsp)
 100b3a4:	00 00 
 100b3a6:	48 c7 84 24 b8 00 00 	movq   $0x0,0xb8(%rsp)
 100b3ad:	00 00 00 00 00 
 100b3b2:	48 c7 84 24 a8 00 00 	movq   $0x0,0xa8(%rsp)
 100b3b9:	00 00 00 00 00 
 100b3be:	8b 83 c8 02 00 00    	mov    0x2c8(%rbx),%eax
 100b3c4:	89 84 24 00 02 00 00 	mov    %eax,0x200(%rsp)
 100b3cb:	c5 f9 ef c0          	vpxor  %xmm0,%xmm0,%xmm0
 100b3cf:	c5 fe 7f 84 24 80 00 	vmovdqu %ymm0,0x80(%rsp)
 100b3d6:	00 00 
 100b3d8:	c5 fe 7f 44 24 60    	vmovdqu %ymm0,0x60(%rsp)
 100b3de:	48 8d 84 24 80 00 00 	lea    0x80(%rsp),%rax
 100b3e5:	00 
 100b3e6:	48 c7 84 24 00 01 00 	movq   $0x1001bb8,0x100(%rsp)
 100b3ed:	00 b8 1b 00 01 
 100b3f2:	c7 84 24 18 01 00 00 	movl   $0x2,0x118(%rsp)
 100b3f9:	02 00 00 00 
 100b3fd:	4c 8d bc 24 60 02 00 	lea    0x260(%rsp),%r15
 100b404:	00 
 100b405:	4c 89 bc 24 08 01 00 	mov    %r15,0x108(%rsp)
 100b40c:	00 
 100b40d:	4c 8d 6c 24 60       	lea    0x60(%rsp),%r13
 100b412:	4c 89 ac 24 10 01 00 	mov    %r13,0x110(%rsp)
 100b419:	00 
 100b41a:	48 c7 84 24 20 01 00 	movq   $0x1001bb8,0x120(%rsp)
 100b421:	00 b8 1b 00 01 
 100b426:	c7 84 24 38 01 00 00 	movl   $0x2,0x138(%rsp)
 100b42d:	02 00 00 00 
 100b431:	4c 8d a4 24 f8 00 00 	lea    0xf8(%rsp),%r12
 100b438:	00 
 100b439:	4c 89 a4 24 28 01 00 	mov    %r12,0x128(%rsp)
 100b440:	00 
 100b441:	4c 8d 74 24 68       	lea    0x68(%rsp),%r14
 100b446:	4c 89 b4 24 30 01 00 	mov    %r14,0x130(%rsp)
 100b44d:	00 
 100b44e:	48 c7 84 24 40 01 00 	movq   $0x1001a68,0x140(%rsp)
 100b455:	00 68 1a 00 01 
 100b45a:	c7 84 24 58 01 00 00 	movl   $0x2,0x158(%rsp)
 100b461:	02 00 00 00 
 100b465:	48 8d 4c 24 38       	lea    0x38(%rsp),%rcx
 100b46a:	48 89 8c 24 48 01 00 	mov    %rcx,0x148(%rsp)
 100b471:	00 
 100b472:	48 8d 4c 24 70       	lea    0x70(%rsp),%rcx
 100b477:	48 89 8c 24 50 01 00 	mov    %rcx,0x150(%rsp)
 100b47e:	00 
 100b47f:	48 c7 84 24 60 01 00 	movq   $0x1001c28,0x160(%rsp)
 100b486:	00 28 1c 00 01 
 100b48b:	c7 84 24 78 01 00 00 	movl   $0x2,0x178(%rsp)
 100b492:	02 00 00 00 
 100b496:	48 8d 8c 24 b8 00 00 	lea    0xb8(%rsp),%rcx
 100b49d:	00 
 100b49e:	48 89 8c 24 68 01 00 	mov    %rcx,0x168(%rsp)
 100b4a5:	00 
 100b4a6:	48 8d 4c 24 78       	lea    0x78(%rsp),%rcx
 100b4ab:	48 89 8c 24 70 01 00 	mov    %rcx,0x170(%rsp)
 100b4b2:	00 
 100b4b3:	48 c7 84 24 80 01 00 	movq   $0x1001c28,0x180(%rsp)
 100b4ba:	00 28 1c 00 01 
 100b4bf:	c7 84 24 98 01 00 00 	movl   $0x2,0x198(%rsp)
 100b4c6:	02 00 00 00 
 100b4ca:	48 8d 8c 24 a8 00 00 	lea    0xa8(%rsp),%rcx
 100b4d1:	00 
 100b4d2:	48 89 8c 24 88 01 00 	mov    %rcx,0x188(%rsp)
 100b4d9:	00 
 100b4da:	48 89 84 24 90 01 00 	mov    %rax,0x190(%rsp)
 100b4e1:	00 
 100b4e2:	48 c7 84 24 a0 01 00 	movq   $0x1001d08,0x1a0(%rsp)
 100b4e9:	00 08 1d 00 01 
 100b4ee:	c7 84 24 b8 01 00 00 	movl   $0x0,0x1b8(%rsp)
 100b4f5:	00 00 00 00 
 100b4f9:	48 8d 84 24 b0 00 00 	lea    0xb0(%rsp),%rax
 100b500:	00 
 100b501:	48 89 84 24 a8 01 00 	mov    %rax,0x1a8(%rsp)
 100b508:	00 
 100b509:	48 8d 84 24 88 00 00 	lea    0x88(%rsp),%rax
 100b510:	00 
 100b511:	48 89 84 24 b0 01 00 	mov    %rax,0x1b0(%rsp)
 100b518:	00 
 100b519:	48 c7 84 24 c0 01 00 	movq   $0x1001d08,0x1c0(%rsp)
 100b520:	00 08 1d 00 01 
 100b525:	c7 84 24 d8 01 00 00 	movl   $0x0,0x1d8(%rsp)
 100b52c:	00 00 00 00 
 100b530:	48 8d 44 24 20       	lea    0x20(%rsp),%rax
 100b535:	48 89 84 24 c8 01 00 	mov    %rax,0x1c8(%rsp)
 100b53c:	00 
 100b53d:	48 8d 84 24 90 00 00 	lea    0x90(%rsp),%rax
 100b544:	00 
 100b545:	48 89 84 24 d0 01 00 	mov    %rax,0x1d0(%rsp)
 100b54c:	00 
 100b54d:	48 c7 84 24 e0 01 00 	movq   $0x1001d08,0x1e0(%rsp)
 100b554:	00 08 1d 00 01 
 100b559:	c7 84 24 f8 01 00 00 	movl   $0x0,0x1f8(%rsp)
 100b560:	00 00 00 00 
 100b564:	48 8d 84 24 80 02 00 	lea    0x280(%rsp),%rax
 100b56b:	00 
 100b56c:	48 89 84 24 e8 01 00 	mov    %rax,0x1e8(%rsp)
 100b573:	00 
 100b574:	48 8d 84 24 98 00 00 	lea    0x98(%rsp),%rax
 100b57b:	00 
 100b57c:	48 89 84 24 f0 01 00 	mov    %rax,0x1f0(%rsp)
 100b583:	00 
 100b584:	48 8b 83 60 18 00 00 	mov    0x1860(%rbx),%rax
 100b58b:	48 85 c0             	test   %rax,%rax
 100b58e:	0f 84 f5 1f 00 00    	je     100d589 <entry_run+0x2349>
 100b594:	48 8b 8b 80 3d 00 00 	mov    0x3d80(%rbx),%rcx
 100b59b:	48 8b 40 70          	mov    0x70(%rax),%rax
 100b59f:	48 89 8c 24 c0 00 00 	mov    %rcx,0xc0(%rsp)
 100b5a6:	00 
 100b5a7:	48 8d 8c 24 00 01 00 	lea    0x100(%rsp),%rcx
 100b5ae:	00 
 100b5af:	48 89 8c 24 c8 00 00 	mov    %rcx,0xc8(%rsp)
 100b5b6:	00 
 100b5b7:	48 c7 84 24 d0 00 00 	movq   $0x8,0xd0(%rsp)
 100b5be:	00 08 00 00 00 
 100b5c3:	48 89 84 24 d8 00 00 	mov    %rax,0xd8(%rsp)
 100b5ca:	00 
 100b5cb:	48 8d 84 24 c0 00 00 	lea    0xc0(%rsp),%rax
 100b5d2:	00 
 100b5d3:	48 89 83 80 3d 00 00 	mov    %rax,0x3d80(%rbx)
 100b5da:	48 83 7b 10 ff       	cmpq   $0xffffffffffffffff,0x10(%rbx)
 100b5df:	74 3c                	je     100b61d <entry_run+0x3dd>
 100b5e1:	48 83 7b 20 00       	cmpq   $0x0,0x20(%rbx)
 100b5e6:	75 25                	jne    100b60d <entry_run+0x3cd>
 100b5e8:	c7 83 e0 38 00 00 01 	movl   $0x1,0x38e0(%rbx)
 100b5ef:	00 00 00 
 100b5f2:	c5 fe 7f 83 e4 38 00 	vmovdqu %ymm0,0x38e4(%rbx)
 100b5f9:	00 
 100b5fa:	c5 fe 7f 83 f0 38 00 	vmovdqu %ymm0,0x38f0(%rbx)
 100b601:	00 
 100b602:	48 c7 83 10 39 00 00 	movq   $0x10032e2,0x3910(%rbx)
 100b609:	e2 32 00 01 
 100b60d:	be 43 37 00 01       	mov    $0x1003743,%esi
 100b612:	48 89 df             	mov    %rbx,%rdi
 100b615:	c5 f8 77             	vzeroupper
 100b618:	e8 43 28 00 00       	call   100de60 <fail>
 100b61d:	48 8d 83 58 02 00 00 	lea    0x258(%rbx),%rax
 100b624:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
 100b629:	48 83 7b 38 ff       	cmpq   $0xffffffffffffffff,0x38(%rbx)
 100b62e:	74 40                	je     100b670 <entry_run+0x430>
 100b630:	48 83 7b 20 00       	cmpq   $0x0,0x20(%rbx)
 100b635:	75 29                	jne    100b660 <entry_run+0x420>
 100b637:	c7 83 e0 38 00 00 01 	movl   $0x1,0x38e0(%rbx)
 100b63e:	00 00 00 
 100b641:	c5 f9 ef c0          	vpxor  %xmm0,%xmm0,%xmm0
 100b645:	c5 fe 7f 83 e4 38 00 	vmovdqu %ymm0,0x38e4(%rbx)
 100b64c:	00 
 100b64d:	c5 fe 7f 83 f0 38 00 	vmovdqu %ymm0,0x38f0(%rbx)
 100b654:	00 
 100b655:	48 c7 83 10 39 00 00 	movq   $0x100332b,0x3910(%rbx)
 100b65c:	2b 33 00 01 
 100b660:	be 58 37 00 01       	mov    $0x1003758,%esi
 100b665:	48 89 df             	mov    %rbx,%rdi
 100b668:	c5 f8 77             	vzeroupper
 100b66b:	e8 f0 27 00 00       	call   100de60 <fail>
 100b670:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
 100b675:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
 100b67c:	00 00 
 100b67e:	be 48 1b 00 01       	mov    $0x1001b48,%esi
 100b683:	48 8b 5c 24 28       	mov    0x28(%rsp),%rbx
 100b688:	48 89 df             	mov    %rbx,%rdi
 100b68b:	31 d2                	xor    %edx,%edx
 100b68d:	c5 f8 77             	vzeroupper
 100b690:	e8 6b 65 00 00       	call   1011c00 <myl_native_list_new>
 100b695:	48 85 c0             	test   %rax,%rax
 100b698:	0f 84 3b 1f 00 00    	je     100d5d9 <entry_run+0x2399>
 100b69e:	48 b9 01 00 00 00 00 	movabs $0x5000000000000001,%rcx
 100b6a5:	00 00 50 
 100b6a8:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
 100b6ad:	48 c7 84 24 c0 01 00 	movq   $0x1001bb8,0x1c0(%rsp)
 100b6b4:	00 b8 1b 00 01 
 100b6b9:	c7 84 24 d8 01 00 00 	movl   $0x2,0x1d8(%rsp)
 100b6c0:	02 00 00 00 
 100b6c4:	48 89 84 24 b0 00 00 	mov    %rax,0xb0(%rsp)
 100b6cb:	00 
 100b6cc:	48 c7 84 24 a0 01 00 	movq   $0x1001bb8,0x1a0(%rsp)
 100b6d3:	00 b8 1b 00 01 
 100b6d8:	c7 84 24 b8 01 00 00 	movl   $0x2,0x1b8(%rsp)
 100b6df:	02 00 00 00 
 100b6e3:	c7 84 24 90 00 00 00 	movl   $0x0,0x90(%rsp)
 100b6ea:	00 00 00 00 
 100b6ee:	c7 84 24 88 00 00 00 	movl   $0x1,0x88(%rsp)
 100b6f5:	01 00 00 00 
 100b6f9:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
 100b6fe:	48 85 48 f0          	test   %rcx,-0x10(%rax)
 100b702:	74 2d                	je     100b731 <entry_run+0x4f1>
 100b704:	48 8d 54 24 20       	lea    0x20(%rsp),%rdx
 100b709:	48 8d 4c 24 10       	lea    0x10(%rsp),%rcx
 100b70e:	be b8 1b 00 01       	mov    $0x1001bb8,%esi
 100b713:	48 89 df             	mov    %rbx,%rdi
 100b716:	44 8b 84 24 00 02 00 	mov    0x200(%rsp),%r8d
 100b71d:	00 
 100b71e:	e8 5d f5 00 00       	call   101ac80 <myl_rc_native_take>
 100b723:	85 c0                	test   %eax,%eax
 100b725:	75 13                	jne    100b73a <entry_run+0x4fa>
 100b727:	4c 8b 6c 24 18       	mov    0x18(%rsp),%r13
 100b72c:	e9 41 13 00 00       	jmp    100ca72 <entry_run+0x1832>
 100b731:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
 100b738:	00 00 
 100b73a:	c7 84 24 88 00 00 00 	movl   $0x0,0x88(%rsp)
 100b741:	00 00 00 00 
 100b745:	48 c7 84 24 c0 01 00 	movq   $0x1001bb8,0x1c0(%rsp)
 100b74c:	00 b8 1b 00 01 
 100b751:	c7 84 24 d8 01 00 00 	movl   $0x2,0x1d8(%rsp)
 100b758:	02 00 00 00 
 100b75c:	c7 84 24 90 00 00 00 	movl   $0x1,0x90(%rsp)
 100b763:	01 00 00 00 
 100b767:	83 7c 24 60 00       	cmpl   $0x0,0x60(%rsp)
 100b76c:	74 26                	je     100b794 <entry_run+0x554>
 100b76e:	48 8d b4 24 00 01 00 	lea    0x100(%rsp),%rsi
 100b775:	00 
 100b776:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
 100b77b:	e8 b0 1e 00 00       	call   100d630 <myl_qbe_rc_slot_drop>
 100b780:	8b 94 24 d8 01 00 00 	mov    0x1d8(%rsp),%edx
 100b787:	f6 84 24 88 00 00 00 	testb  $0x1,0x88(%rsp)
 100b78e:	01 
 100b78f:	0f 94 c0             	sete   %al
 100b792:	eb 07                	jmp    100b79b <entry_run+0x55b>
 100b794:	ba 02 00 00 00       	mov    $0x2,%edx
 100b799:	b0 01                	mov    $0x1,%al
 100b79b:	48 8b 4c 24 20       	mov    0x20(%rsp),%rcx
 100b7a0:	48 89 8c 24 60 02 00 	mov    %rcx,0x260(%rsp)
 100b7a7:	00 
 100b7a8:	c7 84 24 90 00 00 00 	movl   $0x0,0x90(%rsp)
 100b7af:	00 00 00 00 
 100b7b3:	48 c7 84 24 00 01 00 	movq   $0x1001bb8,0x100(%rsp)
 100b7ba:	00 b8 1b 00 01 
 100b7bf:	4c 89 bc 24 08 01 00 	mov    %r15,0x108(%rsp)
 100b7c6:	00 
 100b7c7:	4c 89 ac 24 10 01 00 	mov    %r13,0x110(%rsp)
 100b7ce:	00 
 100b7cf:	89 94 24 18 01 00 00 	mov    %edx,0x118(%rsp)
 100b7d6:	c7 44 24 60 01 00 00 	movl   $0x1,0x60(%rsp)
 100b7dd:	00 
 100b7de:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
 100b7e3:	f6 84 24 b8 01 00 00 	testb  $0x18,0x1b8(%rsp)
 100b7ea:	18 
 100b7eb:	75 4e                	jne    100b83b <entry_run+0x5fb>
 100b7ed:	84 c0                	test   %al,%al
 100b7ef:	75 4a                	jne    100b83b <entry_run+0x5fb>
 100b7f1:	48 85 c9             	test   %rcx,%rcx
 100b7f4:	4c 8b 6c 24 18       	mov    0x18(%rsp),%r13
 100b7f9:	0f 84 a6 00 00 00    	je     100b8a5 <entry_run+0x665>
 100b7ff:	48 b8 01 00 00 00 00 	movabs $0x5000000000000001,%rax
 100b806:	00 00 50 
 100b809:	48 85 41 f0          	test   %rax,-0x10(%rcx)
 100b80d:	0f 84 92 00 00 00    	je     100b8a5 <entry_run+0x665>
 100b813:	48 8d 54 24 20       	lea    0x20(%rsp),%rdx
 100b818:	48 8d 4c 24 10       	lea    0x10(%rsp),%rcx
 100b81d:	be b8 1b 00 01       	mov    $0x1001bb8,%esi
 100b822:	48 89 df             	mov    %rbx,%rdi
 100b825:	44 8b 84 24 00 02 00 	mov    0x200(%rsp),%r8d
 100b82c:	00 
 100b82d:	e8 4e f4 00 00       	call   101ac80 <myl_rc_native_take>
 100b832:	85 c0                	test   %eax,%eax
 100b834:	75 78                	jne    100b8ae <entry_run+0x66e>
 100b836:	e9 37 12 00 00       	jmp    100ca72 <entry_run+0x1832>
 100b83b:	48 8d 54 24 20       	lea    0x20(%rsp),%rdx
 100b840:	48 8d 4c 24 10       	lea    0x10(%rsp),%rcx
 100b845:	be b8 1b 00 01       	mov    $0x1001bb8,%esi
 100b84a:	48 89 df             	mov    %rbx,%rdi
 100b84d:	44 8b 84 24 00 02 00 	mov    0x200(%rsp),%r8d
 100b854:	00 
 100b855:	e8 a6 f9 00 00       	call   101b200 <myl_rc_native_retain>
 100b85a:	85 c0                	test   %eax,%eax
 100b85c:	4c 8b 6c 24 18       	mov    0x18(%rsp),%r13
 100b861:	0f 84 0b 12 00 00    	je     100ca72 <entry_run+0x1832>
 100b867:	48 c7 84 24 c0 01 00 	movq   $0x1001bb8,0x1c0(%rsp)
 100b86e:	00 b8 1b 00 01 
 100b873:	c7 84 24 d8 01 00 00 	movl   $0x2,0x1d8(%rsp)
 100b87a:	02 00 00 00 
 100b87e:	c7 84 24 90 00 00 00 	movl   $0x1,0x90(%rsp)
 100b885:	01 00 00 00 
 100b889:	83 bc 24 88 00 00 00 	cmpl   $0x0,0x88(%rsp)
 100b890:	00 
 100b891:	74 48                	je     100b8db <entry_run+0x69b>
 100b893:	4c 89 ef             	mov    %r13,%rdi
 100b896:	48 8d b4 24 a0 01 00 	lea    0x1a0(%rsp),%rsi
 100b89d:	00 
 100b89e:	e8 8d 1d 00 00       	call   100d630 <myl_qbe_rc_slot_drop>
 100b8a3:	eb 36                	jmp    100b8db <entry_run+0x69b>
 100b8a5:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
 100b8ac:	00 00 
 100b8ae:	c7 84 24 88 00 00 00 	movl   $0x0,0x88(%rsp)
 100b8b5:	00 00 00 00 
 100b8b9:	48 c7 84 24 c0 01 00 	movq   $0x1001bb8,0x1c0(%rsp)
 100b8c0:	00 b8 1b 00 01 
 100b8c5:	c7 84 24 d8 01 00 00 	movl   $0x2,0x1d8(%rsp)
 100b8cc:	02 00 00 00 
 100b8d0:	c7 84 24 90 00 00 00 	movl   $0x1,0x90(%rsp)
 100b8d7:	01 00 00 00 
 100b8db:	83 7c 24 68 00       	cmpl   $0x0,0x68(%rsp)
 100b8e0:	74 10                	je     100b8f2 <entry_run+0x6b2>
 100b8e2:	48 8d b4 24 20 01 00 	lea    0x120(%rsp),%rsi
 100b8e9:	00 
 100b8ea:	4c 89 ef             	mov    %r13,%rdi
 100b8ed:	e8 3e 1d 00 00       	call   100d630 <myl_qbe_rc_slot_drop>
 100b8f2:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
 100b8f7:	48 89 84 24 f8 00 00 	mov    %rax,0xf8(%rsp)
 100b8fe:	00 
 100b8ff:	c7 84 24 90 00 00 00 	movl   $0x0,0x90(%rsp)
 100b906:	00 00 00 00 
 100b90a:	48 c7 84 24 20 01 00 	movq   $0x1001bb8,0x120(%rsp)
 100b911:	00 b8 1b 00 01 
 100b916:	4c 89 a4 24 28 01 00 	mov    %r12,0x128(%rsp)
 100b91d:	00 
 100b91e:	4c 89 b4 24 30 01 00 	mov    %r14,0x130(%rsp)
 100b925:	00 
 100b926:	8b 8c 24 d8 01 00 00 	mov    0x1d8(%rsp),%ecx
 100b92d:	89 8c 24 38 01 00 00 	mov    %ecx,0x138(%rsp)
 100b934:	c7 44 24 68 01 00 00 	movl   $0x1,0x68(%rsp)
 100b93b:	00 
 100b93c:	83 7c 24 60 00       	cmpl   $0x0,0x60(%rsp)
 100b941:	74 18                	je     100b95b <entry_run+0x71b>
 100b943:	48 8d b4 24 00 01 00 	lea    0x100(%rsp),%rsi
 100b94a:	00 
 100b94b:	4c 89 ef             	mov    %r13,%rdi
 100b94e:	e8 dd 1c 00 00       	call   100d630 <myl_qbe_rc_slot_drop>
 100b953:	48 8b 84 24 f8 00 00 	mov    0xf8(%rsp),%rax
 100b95a:	00 
 100b95b:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
 100b960:	48 89 84 24 38 02 00 	mov    %rax,0x238(%rsp)
 100b967:	00 
 100b968:	48 8b 10             	mov    (%rax),%rdx
 100b96b:	48 85 d2             	test   %rdx,%rdx
 100b96e:	74 26                	je     100b996 <entry_run+0x756>
 100b970:	48 8b 40 20          	mov    0x20(%rax),%rax
 100b974:	31 c9                	xor    %ecx,%ecx
 100b976:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
 100b97d:	00 00 00 
 100b980:	48 81 3c c8 00 01 00 	cmpq   $0x100,(%rax,%rcx,8)
 100b987:	00 
 100b988:	0f 83 7f 00 00 00    	jae    100ba0d <entry_run+0x7cd>
 100b98e:	48 ff c1             	inc    %rcx
 100b991:	48 39 ca             	cmp    %rcx,%rdx
 100b994:	75 ea                	jne    100b980 <entry_run+0x740>
 100b996:	49 8b 85 68 02 00 00 	mov    0x268(%r13),%rax
 100b99d:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
 100b9a2:	48 8d 84 24 38 02 00 	lea    0x238(%rsp),%rax
 100b9a9:	00 
 100b9aa:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
 100b9af:	48 c7 44 24 50 c0 55 	movq   $0x10055c0,0x50(%rsp)
 100b9b6:	00 01 
 100b9b8:	48 89 df             	mov    %rbx,%rdi
 100b9bb:	48 8d 5c 24 40       	lea    0x40(%rsp),%rbx
 100b9c0:	49 89 9d 68 02 00 00 	mov    %rbx,0x268(%r13)
 100b9c7:	be 50 55 00 01       	mov    $0x1005550,%esi
 100b9cc:	e8 2f 62 00 00       	call   1011c00 <myl_native_list_new>
 100b9d1:	48 85 c0             	test   %rax,%rax
 100b9d4:	74 4b                	je     100ba21 <entry_run+0x7e1>
 100b9d6:	48 8b 8c 24 38 02 00 	mov    0x238(%rsp),%rcx
 100b9dd:	00 
 100b9de:	48 83 39 00          	cmpq   $0x0,(%rcx)
 100b9e2:	74 38                	je     100ba1c <entry_run+0x7dc>
 100b9e4:	48 8b 49 20          	mov    0x20(%rcx),%rcx
 100b9e8:	48 8b 50 20          	mov    0x20(%rax),%rdx
 100b9ec:	31 f6                	xor    %esi,%esi
 100b9ee:	66 90                	xchg   %ax,%ax
 100b9f0:	0f b6 3c f1          	movzbl (%rcx,%rsi,8),%edi
 100b9f4:	40 88 3c 32          	mov    %dil,(%rdx,%rsi,1)
 100b9f8:	48 ff c6             	inc    %rsi
 100b9fb:	48 8b bc 24 38 02 00 	mov    0x238(%rsp),%rdi
 100ba02:	00 
 100ba03:	48 8b 3f             	mov    (%rdi),%rdi
 100ba06:	48 39 fe             	cmp    %rdi,%rsi
 100ba09:	72 e5                	jb     100b9f0 <entry_run+0x7b0>
 100ba0b:	eb 11                	jmp    100ba1e <entry_run+0x7de>
 100ba0d:	be 91 37 00 01       	mov    $0x1003791,%esi
 100ba12:	4c 89 ef             	mov    %r13,%rdi
 100ba15:	e8 46 24 00 00       	call   100de60 <fail>
 100ba1a:	eb 27                	jmp    100ba43 <entry_run+0x803>
 100ba1c:	31 ff                	xor    %edi,%edi
 100ba1e:	48 89 38             	mov    %rdi,(%rax)
 100ba21:	49 39 9d 68 02 00 00 	cmp    %rbx,0x268(%r13)
 100ba28:	75 0c                	jne    100ba36 <entry_run+0x7f6>
 100ba2a:	48 8b 4c 24 40       	mov    0x40(%rsp),%rcx
 100ba2f:	49 89 8d 68 02 00 00 	mov    %rcx,0x268(%r13)
 100ba36:	48 85 c0             	test   %rax,%rax
 100ba39:	75 0a                	jne    100ba45 <entry_run+0x805>
 100ba3b:	4c 89 ef             	mov    %r13,%rdi
 100ba3e:	e8 cd 2a 00 00       	call   100e510 <myl_qbe_fail_allocation>
 100ba43:	31 c0                	xor    %eax,%eax
 100ba45:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
 100ba4a:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
 100ba4f:	48 c7 84 24 c0 01 00 	movq   $0x1001a68,0x1c0(%rsp)
 100ba56:	00 68 1a 00 01 
 100ba5b:	c7 84 24 d8 01 00 00 	movl   $0x2,0x1d8(%rsp)
 100ba62:	02 00 00 00 
 100ba66:	c7 84 24 90 00 00 00 	movl   $0x1,0x90(%rsp)
 100ba6d:	01 00 00 00 
 100ba71:	83 bc 24 88 00 00 00 	cmpl   $0x0,0x88(%rsp)
 100ba78:	00 
 100ba79:	74 1e                	je     100ba99 <entry_run+0x859>
 100ba7b:	4c 89 ef             	mov    %r13,%rdi
 100ba7e:	48 8d b4 24 a0 01 00 	lea    0x1a0(%rsp),%rsi
 100ba85:	00 
 100ba86:	e8 a5 1b 00 00       	call   100d630 <myl_qbe_rc_slot_drop>
 100ba8b:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
 100ba90:	8b 9c 24 d8 01 00 00 	mov    0x1d8(%rsp),%ebx
 100ba97:	eb 05                	jmp    100ba9e <entry_run+0x85e>
 100ba99:	bb 02 00 00 00       	mov    $0x2,%ebx
 100ba9e:	48 89 84 24 b0 00 00 	mov    %rax,0xb0(%rsp)
 100baa5:	00 
 100baa6:	48 c7 84 24 a0 01 00 	movq   $0x1001a68,0x1a0(%rsp)
 100baad:	00 68 1a 00 01 
 100bab2:	89 9c 24 b8 01 00 00 	mov    %ebx,0x1b8(%rsp)
 100bab9:	c7 84 24 90 00 00 00 	movl   $0x0,0x90(%rsp)
 100bac0:	00 00 00 00 
 100bac4:	c7 84 24 88 00 00 00 	movl   $0x1,0x88(%rsp)
 100bacb:	01 00 00 00 
 100bacf:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
 100bad4:	45 31 f6             	xor    %r14d,%r14d
 100bad7:	f6 c3 18             	test   $0x18,%bl
 100bada:	41 0f 94 c5          	sete   %r13b
 100bade:	be 68 1a 00 01       	mov    $0x1001a68,%esi
 100bae3:	4c 8b 64 24 28       	mov    0x28(%rsp),%r12
 100bae8:	4c 89 e7             	mov    %r12,%rdi
 100baeb:	e8 10 ee 00 00       	call   101a900 <myl_rc_native_shape>
 100baf0:	48 85 c0             	test   %rax,%rax
 100baf3:	0f 84 94 00 00 00    	je     100bb8d <entry_run+0x94d>
 100baf9:	49 89 c7             	mov    %rax,%r15
 100bafc:	be 68 1a 00 01       	mov    $0x1001a68,%esi
 100bb01:	4c 89 e7             	mov    %r12,%rdi
 100bb04:	e8 67 9b 00 00       	call   1015670 <myl_rc_native_has_unique>
 100bb09:	85 c0                	test   %eax,%eax
 100bb0b:	0f 85 78 1a 00 00    	jne    100d589 <entry_run+0x2349>
 100bb11:	45 88 ee             	mov    %r13b,%r14b
 100bb14:	4c 89 7c 24 40       	mov    %r15,0x40(%rsp)
 100bb19:	48 8d 44 24 20       	lea    0x20(%rsp),%rax
 100bb1e:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
 100bb23:	48 c7 44 24 50 00 00 	movq   $0x0,0x50(%rsp)
 100bb2a:	00 00 
 100bb2c:	8b 84 24 00 02 00 00 	mov    0x200(%rsp),%eax
 100bb33:	89 44 24 58          	mov    %eax,0x58(%rsp)
 100bb37:	c7 44 24 5c 00 00 00 	movl   $0x0,0x5c(%rsp)
 100bb3e:	00 
 100bb3f:	48 8d 74 24 40       	lea    0x40(%rsp),%rsi
 100bb44:	48 8d 4c 24 10       	lea    0x10(%rsp),%rcx
 100bb49:	4c 89 e7             	mov    %r12,%rdi
 100bb4c:	4c 89 fa             	mov    %r15,%rdx
 100bb4f:	45 89 f0             	mov    %r14d,%r8d
 100bb52:	41 b9 01 00 00 00    	mov    $0x1,%r9d
 100bb58:	e8 d3 b9 00 00       	call   1017530 <transfer>
 100bb5d:	85 c0                	test   %eax,%eax
 100bb5f:	74 52                	je     100bbb3 <entry_run+0x973>
 100bb61:	4c 8b 6c 24 18       	mov    0x18(%rsp),%r13
 100bb66:	49 8b 8d 60 18 00 00 	mov    0x1860(%r13),%rcx
 100bb6d:	48 85 c9             	test   %rcx,%rcx
 100bb70:	0f 84 13 1a 00 00    	je     100d589 <entry_run+0x2349>
 100bb76:	83 79 78 00          	cmpl   $0x0,0x78(%rcx)
 100bb7a:	48 8b 5c 24 28       	mov    0x28(%rsp),%rbx
 100bb7f:	0f 85 fd 0e 00 00    	jne    100ca82 <entry_run+0x1842>
 100bb85:	89 41 78             	mov    %eax,0x78(%rcx)
 100bb88:	e9 f5 0e 00 00       	jmp    100ca82 <entry_run+0x1842>
 100bb8d:	48 c7 44 24 20 00 00 	movq   $0x0,0x20(%rsp)
 100bb94:	00 00 
 100bb96:	4c 8b 6c 24 18       	mov    0x18(%rsp),%r13
 100bb9b:	49 8b 8d 60 18 00 00 	mov    0x1860(%r13),%rcx
 100bba2:	48 85 c9             	test   %rcx,%rcx
 100bba5:	4c 89 e3             	mov    %r12,%rbx
 100bba8:	0f 85 d4 0e 00 00    	jne    100ca82 <entry_run+0x1842>
 100bbae:	e9 d6 19 00 00       	jmp    100d589 <entry_run+0x2349>
 100bbb3:	f6 c3 18             	test   $0x18,%bl
 100bbb6:	4c 8b 6c 24 18       	mov    0x18(%rsp),%r13
 100bbbb:	74 1a                	je     100bbd7 <entry_run+0x997>
 100bbbd:	83 bc 24 88 00 00 00 	cmpl   $0x0,0x88(%rsp)
 100bbc4:	00 
 100bbc5:	74 10                	je     100bbd7 <entry_run+0x997>
 100bbc7:	4c 89 ef             	mov    %r13,%rdi
 100bbca:	48 8d b4 24 a0 01 00 	lea    0x1a0(%rsp),%rsi
 100bbd1:	00 
 100bbd2:	e8 59 1a 00 00       	call   100d630 <myl_qbe_rc_slot_drop>
 100bbd7:	48 c7 84 24 c0 01 00 	movq   $0x1001a68,0x1c0(%rsp)
 100bbde:	00 68 1a 00 01 
 100bbe3:	c7 84 24 d8 01 00 00 	movl   $0x2,0x1d8(%rsp)
 100bbea:	02 00 00 00 
 100bbee:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
 100bbf3:	48 89 84 24 b0 00 00 	mov    %rax,0xb0(%rsp)
 100bbfa:	00 
 100bbfb:	48 c7 84 24 a0 01 00 	movq   $0x1001a68,0x1a0(%rsp)
 100bc02:	00 68 1a 00 01 
 100bc07:	c7 84 24 b8 01 00 00 	movl   $0x2,0x1b8(%rsp)
 100bc0e:	02 00 00 00 
 100bc12:	c7 84 24 90 00 00 00 	movl   $0x0,0x90(%rsp)
 100bc19:	00 00 00 00 
 100bc1d:	c7 84 24 88 00 00 00 	movl   $0x1,0x88(%rsp)
 100bc24:	01 00 00 00 
 100bc28:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
 100bc2d:	48 85 c0             	test   %rax,%rax
 100bc30:	48 8b 5c 24 28       	mov    0x28(%rsp),%rbx
 100bc35:	4c 8d 74 24 38       	lea    0x38(%rsp),%r14
 100bc3a:	74 38                	je     100bc74 <entry_run+0xa34>
 100bc3c:	48 b9 01 00 00 00 00 	movabs $0x5000000000000001,%rcx
 100bc43:	00 00 50 
 100bc46:	48 85 48 f0          	test   %rcx,-0x10(%rax)
 100bc4a:	74 28                	je     100bc74 <entry_run+0xa34>
 100bc4c:	48 8d 54 24 20       	lea    0x20(%rsp),%rdx
 100bc51:	48 8d 4c 24 10       	lea    0x10(%rsp),%rcx
 100bc56:	be 68 1a 00 01       	mov    $0x1001a68,%esi
 100bc5b:	48 89 df             	mov    %rbx,%rdi
 100bc5e:	44 8b 84 24 00 02 00 	mov    0x200(%rsp),%r8d
 100bc65:	00 
 100bc66:	e8 15 f0 00 00       	call   101ac80 <myl_rc_native_take>
 100bc6b:	85 c0                	test   %eax,%eax
 100bc6d:	75 0e                	jne    100bc7d <entry_run+0xa3d>
 100bc6f:	e9 fe 0d 00 00       	jmp    100ca72 <entry_run+0x1832>
 100bc74:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
 100bc7b:	00 00 
 100bc7d:	c7 84 24 88 00 00 00 	movl   $0x0,0x88(%rsp)
 100bc84:	00 00 00 00 
 100bc88:	48 c7 84 24 c0 01 00 	movq   $0x1001a68,0x1c0(%rsp)
 100bc8f:	00 68 1a 00 01 
 100bc94:	c7 84 24 d8 01 00 00 	movl   $0x2,0x1d8(%rsp)
 100bc9b:	02 00 00 00 
 100bc9f:	c7 84 24 90 00 00 00 	movl   $0x1,0x90(%rsp)
 100bca6:	01 00 00 00 
 100bcaa:	83 7c 24 70 00       	cmpl   $0x0,0x70(%rsp)
 100bcaf:	74 30                	je     100bce1 <entry_run+0xaa1>
 100bcb1:	48 8d b4 24 40 01 00 	lea    0x140(%rsp),%rsi
 100bcb8:	00 
 100bcb9:	4c 89 ef             	mov    %r13,%rdi
 100bcbc:	e8 6f 19 00 00       	call   100d630 <myl_qbe_rc_slot_drop>
 100bcc1:	8b 84 24 d8 01 00 00 	mov    0x1d8(%rsp),%eax
 100bcc8:	eb 1c                	jmp    100bce6 <entry_run+0xaa6>
 100bcca:	c7 40 38 01 00 00 00 	movl   $0x1,0x38(%rax)
 100bcd1:	48 83 7b 20 00       	cmpq   $0x0,0x20(%rbx)
 100bcd6:	0f 85 84 17 00 00    	jne    100d460 <entry_run+0x2220>
 100bcdc:	e9 a4 f6 ff ff       	jmp    100b385 <entry_run+0x145>
 100bce1:	b8 02 00 00 00       	mov    $0x2,%eax
 100bce6:	48 8b 4c 24 20       	mov    0x20(%rsp),%rcx
 100bceb:	48 89 4c 24 38       	mov    %rcx,0x38(%rsp)
 100bcf0:	48 c7 84 24 40 01 00 	movq   $0x1001a68,0x140(%rsp)
 100bcf7:	00 68 1a 00 01 
 100bcfc:	4c 89 b4 24 48 01 00 	mov    %r14,0x148(%rsp)
 100bd03:	00 
 100bd04:	48 8d 4c 24 70       	lea    0x70(%rsp),%rcx
 100bd09:	48 89 8c 24 50 01 00 	mov    %rcx,0x150(%rsp)
 100bd10:	00 
 100bd11:	89 84 24 58 01 00 00 	mov    %eax,0x158(%rsp)
 100bd18:	c7 44 24 70 01 00 00 	movl   $0x1,0x70(%rsp)
 100bd1f:	00 
 100bd20:	48 c7 44 24 20 a0 04 	movq   $0x10204a0,0x20(%rsp)
 100bd27:	02 01 
 100bd29:	48 c7 84 24 c0 01 00 	movq   $0x1001c28,0x1c0(%rsp)
 100bd30:	00 28 1c 00 01 
 100bd35:	c7 84 24 d8 01 00 00 	movl   $0x2,0x1d8(%rsp)
 100bd3c:	02 00 00 00 
 100bd40:	48 c7 84 24 b0 00 00 	movq   $0x10204a0,0xb0(%rsp)
 100bd47:	00 a0 04 02 01 
 100bd4c:	48 c7 84 24 a0 01 00 	movq   $0x1001c28,0x1a0(%rsp)
 100bd53:	00 28 1c 00 01 
 100bd58:	c7 84 24 b8 01 00 00 	movl   $0x2,0x1b8(%rsp)
 100bd5f:	02 00 00 00 
 100bd63:	c7 84 24 90 00 00 00 	movl   $0x0,0x90(%rsp)
 100bd6a:	00 00 00 00 
 100bd6e:	c7 84 24 88 00 00 00 	movl   $0x1,0x88(%rsp)
 100bd75:	01 00 00 00 
 100bd79:	48 c7 44 24 10 a0 04 	movq   $0x10204a0,0x10(%rsp)
 100bd80:	02 01 
 100bd82:	48 b8 01 00 00 00 00 	movabs $0x5000000000000001,%rax
 100bd89:	00 00 50 
 100bd8c:	48 85 05 fd 46 01 00 	test   %rax,0x146fd(%rip)        # 1020490 <myl_lit_3a31048ef22d5766c70d678fc1c59ca587d84f11b25c84fb64cb1eb13678199d_instance>
 100bd93:	74 28                	je     100bdbd <entry_run+0xb7d>
 100bd95:	48 8d 54 24 20       	lea    0x20(%rsp),%rdx
 100bd9a:	48 8d 4c 24 10       	lea    0x10(%rsp),%rcx
 100bd9f:	be 28 1c 00 01       	mov    $0x1001c28,%esi
 100bda4:	48 89 df             	mov    %rbx,%rdi
 100bda7:	44 8b 84 24 00 02 00 	mov    0x200(%rsp),%r8d
 100bdae:	00 
 100bdaf:	e8 cc ee 00 00       	call   101ac80 <myl_rc_native_take>
 100bdb4:	85 c0                	test   %eax,%eax
 100bdb6:	75 0e                	jne    100bdc6 <entry_run+0xb86>
 100bdb8:	e9 b5 0c 00 00       	jmp    100ca72 <entry_run+0x1832>
 100bdbd:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
 100bdc4:	00 00 
 100bdc6:	c7 84 24 88 00 00 00 	movl   $0x0,0x88(%rsp)
 100bdcd:	00 00 00 00 
 100bdd1:	48 c7 84 24 c0 01 00 	movq   $0x1001c28,0x1c0(%rsp)
 100bdd8:	00 28 1c 00 01 
 100bddd:	c7 84 24 d8 01 00 00 	movl   $0x2,0x1d8(%rsp)
 100bde4:	02 00 00 00 
 100bde8:	c7 84 24 90 00 00 00 	movl   $0x1,0x90(%rsp)
 100bdef:	01 00 00 00 
 100bdf3:	83 7c 24 78 00       	cmpl   $0x0,0x78(%rsp)
 100bdf8:	74 19                	je     100be13 <entry_run+0xbd3>
 100bdfa:	48 8d b4 24 60 01 00 	lea    0x160(%rsp),%rsi
 100be01:	00 
 100be02:	4c 89 ef             	mov    %r13,%rdi
 100be05:	e8 26 18 00 00       	call   100d630 <myl_qbe_rc_slot_drop>
 100be0a:	8b 84 24 d8 01 00 00 	mov    0x1d8(%rsp),%eax
 100be11:	eb 05                	jmp    100be18 <entry_run+0xbd8>
 100be13:	b8 02 00 00 00       	mov    $0x2,%eax
 100be18:	48 ba b9 e5 e4 1c 6d 	movabs $0xbf58476d1ce4e5b9,%rdx
 100be1f:	47 58 bf 
 100be22:	48 8b 4c 24 20       	mov    0x20(%rsp),%rcx
 100be27:	48 89 8c 24 b8 00 00 	mov    %rcx,0xb8(%rsp)
 100be2e:	00 
 100be2f:	c7 84 24 90 00 00 00 	movl   $0x0,0x90(%rsp)
 100be36:	00 00 00 00 
 100be3a:	48 c7 84 24 60 01 00 	movq   $0x1001c28,0x160(%rsp)
 100be41:	00 28 1c 00 01 
 100be46:	48 8d 8c 24 b8 00 00 	lea    0xb8(%rsp),%rcx
 100be4d:	00 
 100be4e:	48 89 8c 24 68 01 00 	mov    %rcx,0x168(%rsp)
 100be55:	00 
 100be56:	48 8d 4c 24 78       	lea    0x78(%rsp),%rcx
 100be5b:	48 89 8c 24 70 01 00 	mov    %rcx,0x170(%rsp)
 100be62:	00 
 100be63:	89 84 24 78 01 00 00 	mov    %eax,0x178(%rsp)
 100be6a:	c7 44 24 78 01 00 00 	movl   $0x1,0x78(%rsp)
 100be71:	00 
 100be72:	b8 68 1a 00 01       	mov    $0x1001a68,%eax
 100be77:	b9 68 1a 00 01       	mov    $0x1001a68,%ecx
 100be7c:	48 c1 e9 03          	shr    $0x3,%rcx
 100be80:	48 c1 e8 21          	shr    $0x21,%rax
 100be84:	48 31 c8             	xor    %rcx,%rax
 100be87:	48 0f af c2          	imul   %rdx,%rax
 100be8b:	48 89 c1             	mov    %rax,%rcx
 100be8e:	48 c1 e9 1b          	shr    $0x1b,%rcx
 100be92:	48 31 c1             	xor    %rax,%rcx
 100be95:	48 83 f1 02          	xor    $0x2,%rcx
 100be99:	48 89 8c 24 f0 00 00 	mov    %rcx,0xf0(%rsp)
 100bea0:	00 
 100bea1:	45 31 ff             	xor    %r15d,%r15d
 100bea4:	eb 2c                	jmp    100bed2 <entry_run+0xc92>
 100bea6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
 100bead:	00 00 00 
 100beb0:	31 c0                	xor    %eax,%eax
 100beb2:	49 81 ff ff ff 01 00 	cmp    $0x1ffff,%r15
 100beb9:	4d 8d 7f 01          	lea    0x1(%r15),%r15
 100bebd:	0f 92 c0             	setb   %al
 100bec0:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
 100bec5:	49 81 ff 00 00 02 00 	cmp    $0x20000,%r15
 100becc:	0f 84 bf 09 00 00    	je     100c891 <entry_run+0x1651>
 100bed2:	48 8b 84 24 b8 00 00 	mov    0xb8(%rsp),%rax
 100bed9:	00 
 100beda:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
 100bedf:	48 c7 84 24 40 01 00 	movq   $0x1001a68,0x140(%rsp)
 100bee6:	00 68 1a 00 01 
 100beeb:	c7 84 24 58 01 00 00 	movl   $0x2,0x158(%rsp)
 100bef2:	02 00 00 00 
 100bef6:	4c 89 b4 24 48 01 00 	mov    %r14,0x148(%rsp)
 100befd:	00 
 100befe:	48 8d 44 24 70       	lea    0x70(%rsp),%rax
 100bf03:	48 89 84 24 50 01 00 	mov    %rax,0x150(%rsp)
 100bf0a:	00 
 100bf0b:	49 8b 8d 60 18 00 00 	mov    0x1860(%r13),%rcx
 100bf12:	48 85 c9             	test   %rcx,%rcx
 100bf15:	0f 84 6e 16 00 00    	je     100d589 <entry_run+0x2349>
 100bf1b:	48 8b 41 40          	mov    0x40(%rcx),%rax
 100bf1f:	48 85 c0             	test   %rax,%rax
 100bf22:	0f 84 61 16 00 00    	je     100d589 <entry_run+0x2349>
 100bf28:	48 8b 49 30          	mov    0x30(%rcx),%rcx
 100bf2c:	48 ff c8             	dec    %rax
 100bf2f:	48 89 c2             	mov    %rax,%rdx
 100bf32:	48 23 94 24 f0 00 00 	and    0xf0(%rsp),%rdx
 100bf39:	00 
 100bf3a:	eb 0a                	jmp    100bf46 <entry_run+0xd06>
 100bf3c:	0f 1f 40 00          	nopl   0x0(%rax)
 100bf40:	48 ff c2             	inc    %rdx
 100bf43:	48 21 c2             	and    %rax,%rdx
 100bf46:	48 8d 34 92          	lea    (%rdx,%rdx,4),%rsi
 100bf4a:	48 8b 34 f1          	mov    (%rcx,%rsi,8),%rsi
 100bf4e:	48 85 f6             	test   %rsi,%rsi
 100bf51:	0f 84 32 16 00 00    	je     100d589 <entry_run+0x2349>
 100bf57:	48 81 fe 68 1a 00 01 	cmp    $0x1001a68,%rsi
 100bf5e:	75 e0                	jne    100bf40 <entry_run+0xd00>
 100bf60:	48 8d 34 92          	lea    (%rdx,%rdx,4),%rsi
 100bf64:	83 7c f1 20 02       	cmpl   $0x2,0x20(%rcx,%rsi,8)
 100bf69:	75 d5                	jne    100bf40 <entry_run+0xd00>
 100bf6b:	48 8d 14 f1          	lea    (%rcx,%rsi,8),%rdx
 100bf6f:	48 8b 52 08          	mov    0x8(%rdx),%rdx
 100bf73:	48 85 d2             	test   %rdx,%rdx
 100bf76:	0f 84 0d 16 00 00    	je     100d589 <entry_run+0x2349>
 100bf7c:	48 8b 72 08          	mov    0x8(%rdx),%rsi
 100bf80:	83 7e 08 01          	cmpl   $0x1,0x8(%rsi)
 100bf84:	0f 85 ff 15 00 00    	jne    100d589 <entry_run+0x2349>
 100bf8a:	4c 8b 6c 24 38       	mov    0x38(%rsp),%r13
 100bf8f:	4d 85 ed             	test   %r13,%r13
 100bf92:	74 2c                	je     100bfc0 <entry_run+0xd80>
 100bf94:	49 8b 7d f0          	mov    -0x10(%r13),%rdi
 100bf98:	48 89 fa             	mov    %rdi,%rdx
 100bf9b:	48 c1 ea 28          	shr    $0x28,%rdx
 100bf9f:	81 e2 ff ff 0f 00    	and    $0xfffff,%edx
 100bfa5:	49 b8 00 00 00 00 00 	movabs $0x4000000000000000,%r8
 100bfac:	00 00 40 
 100bfaf:	4c 85 c7             	test   %r8,%rdi
 100bfb2:	bf 00 00 00 00       	mov    $0x0,%edi
 100bfb7:	0f 44 d7             	cmove  %edi,%edx
 100bfba:	eb 06                	jmp    100bfc2 <entry_run+0xd82>
 100bfbc:	0f 1f 40 00          	nopl   0x0(%rax)
 100bfc0:	31 d2                	xor    %edx,%edx
 100bfc2:	48 89 f7             	mov    %rsi,%rdi
 100bfc5:	48 c1 ef 03          	shr    $0x3,%rdi
 100bfc9:	49 89 f0             	mov    %rsi,%r8
 100bfcc:	49 c1 e8 21          	shr    $0x21,%r8
 100bfd0:	49 31 f8             	xor    %rdi,%r8
 100bfd3:	48 bf b9 e5 e4 1c 6d 	movabs $0xbf58476d1ce4e5b9,%rdi
 100bfda:	47 58 bf 
 100bfdd:	4c 0f af c7          	imul   %rdi,%r8
 100bfe1:	4c 89 c7             	mov    %r8,%rdi
 100bfe4:	48 c1 ef 1b          	shr    $0x1b,%rdi
 100bfe8:	4c 31 c7             	xor    %r8,%rdi
 100bfeb:	48 83 f7 01          	xor    $0x1,%rdi
 100bfef:	48 21 c7             	and    %rax,%rdi
 100bff2:	83 7c 24 70 00       	cmpl   $0x0,0x70(%rsp)
 100bff7:	4c 8d 04 bf          	lea    (%rdi,%rdi,4),%r8
 100bffb:	4e 8b 04 c1          	mov    (%rcx,%r8,8),%r8
 100bfff:	75 1d                	jne    100c01e <entry_run+0xdde>
 100c001:	e9 28 01 00 00       	jmp    100c12e <entry_run+0xeee>
 100c006:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
 100c00d:	00 00 00 
 100c010:	48 ff c7             	inc    %rdi
 100c013:	48 21 c7             	and    %rax,%rdi
 100c016:	4c 8d 04 bf          	lea    (%rdi,%rdi,4),%r8
 100c01a:	4e 8b 04 c1          	mov    (%rcx,%r8,8),%r8
 100c01e:	4d 85 c0             	test   %r8,%r8
 100c021:	0f 84 62 15 00 00    	je     100d589 <entry_run+0x2349>
 100c027:	49 39 f0             	cmp    %rsi,%r8
 100c02a:	75 e4                	jne    100c010 <entry_run+0xdd0>
 100c02c:	4c 8d 04 bf          	lea    (%rdi,%rdi,4),%r8
 100c030:	42 83 7c c1 20 01    	cmpl   $0x1,0x20(%rcx,%r8,8)
 100c036:	75 d8                	jne    100c010 <entry_run+0xdd0>
 100c038:	4a 8d 04 c1          	lea    (%rcx,%r8,8),%rax
 100c03c:	48 83 78 08 00       	cmpq   $0x0,0x8(%rax)
 100c041:	0f 84 42 15 00 00    	je     100d589 <entry_run+0x2349>
 100c047:	48 83 3e 08          	cmpq   $0x8,(%rsi)
 100c04b:	0f 85 38 15 00 00    	jne    100d589 <entry_run+0x2349>
 100c051:	4d 85 ed             	test   %r13,%r13
 100c054:	0f 84 c6 01 00 00    	je     100c220 <entry_run+0xfe0>
 100c05a:	49 8b 45 f0          	mov    -0x10(%r13),%rax
 100c05e:	48 b9 02 00 00 00 00 	movabs $0x2000000000000002,%rcx
 100c065:	00 00 20 
 100c068:	48 85 c8             	test   %rcx,%rax
 100c06b:	0f 84 44 01 00 00    	je     100c1b5 <entry_run+0xf75>
 100c071:	48 c7 44 24 40 00 00 	movq   $0x0,0x40(%rsp)
 100c078:	00 00 
 100c07a:	48 89 df             	mov    %rbx,%rdi
 100c07d:	4c 89 ee             	mov    %r13,%rsi
 100c080:	48 8d 4c 24 40       	lea    0x40(%rsp),%rcx
 100c085:	c5 f8 77             	vzeroupper
 100c088:	e8 43 d7 00 00       	call   10197d0 <clone_payload>
 100c08d:	85 c0                	test   %eax,%eax
 100c08f:	0f 85 53 08 00 00    	jne    100c8e8 <entry_run+0x16a8>
 100c095:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
 100c09a:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
 100c09f:	49 8b 45 f0          	mov    -0x10(%r13),%rax
 100c0a3:	48 b9 00 00 00 00 00 	movabs $0x4000000000000000,%rcx
 100c0aa:	00 00 40 
 100c0ad:	48 83 c1 02          	add    $0x2,%rcx
 100c0b1:	48 85 c8             	test   %rcx,%rax
 100c0b4:	75 50                	jne    100c106 <entry_run+0xec6>
 100c0b6:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
 100c0bb:	48 8b 89 60 18 00 00 	mov    0x1860(%rcx),%rcx
 100c0c2:	48 85 c9             	test   %rcx,%rcx
 100c0c5:	0f 84 be 14 00 00    	je     100d589 <entry_run+0x2349>
 100c0cb:	a8 01                	test   $0x1,%al
 100c0cd:	0f 85 b6 14 00 00    	jne    100d589 <entry_run+0x2349>
 100c0d3:	49 8d 55 e0          	lea    -0x20(%r13),%rdx
 100c0d7:	48 8b 32             	mov    (%rdx),%rsi
 100c0da:	48 85 f6             	test   %rsi,%rsi
 100c0dd:	0f 84 a6 14 00 00    	je     100d589 <entry_run+0x2349>
 100c0e3:	48 ff ce             	dec    %rsi
 100c0e6:	48 89 32             	mov    %rsi,(%rdx)
 100c0e9:	75 1b                	jne    100c106 <entry_run+0xec6>
 100c0eb:	49 83 7d e8 00       	cmpq   $0x0,-0x18(%r13)
 100c0f0:	75 14                	jne    100c106 <entry_run+0xec6>
 100c0f2:	48 83 c8 01          	or     $0x1,%rax
 100c0f6:	49 89 45 f0          	mov    %rax,-0x10(%r13)
 100c0fa:	48 8b 41 60          	mov    0x60(%rcx),%rax
 100c0fe:	49 89 45 e0          	mov    %rax,-0x20(%r13)
 100c102:	48 89 51 60          	mov    %rdx,0x60(%rcx)
 100c106:	48 89 df             	mov    %rbx,%rdi
 100c109:	e8 c2 91 00 00       	call   10152d0 <myl_rc_drain>
 100c10e:	e9 0d 01 00 00       	jmp    100c220 <entry_run+0xfe0>
 100c113:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 100c11a:	84 00 00 00 00 00 
 100c120:	48 ff c7             	inc    %rdi
 100c123:	48 21 c7             	and    %rax,%rdi
 100c126:	4c 8d 04 bf          	lea    (%rdi,%rdi,4),%r8
 100c12a:	4e 8b 04 c1          	mov    (%rcx,%r8,8),%r8
 100c12e:	4d 85 c0             	test   %r8,%r8
 100c131:	0f 84 52 14 00 00    	je     100d589 <entry_run+0x2349>
 100c137:	49 39 f0             	cmp    %rsi,%r8
 100c13a:	75 e4                	jne    100c120 <entry_run+0xee0>
 100c13c:	4c 8d 04 bf          	lea    (%rdi,%rdi,4),%r8
 100c140:	42 83 7c c1 20 01    	cmpl   $0x1,0x20(%rcx,%r8,8)
 100c146:	75 d8                	jne    100c120 <entry_run+0xee0>
 100c148:	4a 8d 04 c1          	lea    (%rcx,%r8,8),%rax
 100c14c:	48 83 78 08 00       	cmpq   $0x0,0x8(%rax)
 100c151:	0f 84 32 14 00 00    	je     100d589 <entry_run+0x2349>
 100c157:	48 83 3e 08          	cmpq   $0x8,(%rsi)
 100c15b:	0f 85 28 14 00 00    	jne    100d589 <entry_run+0x2349>
 100c161:	4d 85 ed             	test   %r13,%r13
 100c164:	0f 84 b6 00 00 00    	je     100c220 <entry_run+0xfe0>
 100c16a:	49 8b 45 f0          	mov    -0x10(%r13),%rax
 100c16e:	48 b9 02 00 00 00 00 	movabs $0x2000000000000002,%rcx
 100c175:	00 00 20 
 100c178:	48 85 c8             	test   %rcx,%rax
 100c17b:	74 63                	je     100c1e0 <entry_run+0xfa0>
 100c17d:	48 c7 44 24 40 00 00 	movq   $0x0,0x40(%rsp)
 100c184:	00 00 
 100c186:	48 89 df             	mov    %rbx,%rdi
 100c189:	4c 89 ee             	mov    %r13,%rsi
 100c18c:	48 8d 4c 24 40       	lea    0x40(%rsp),%rcx
 100c191:	c5 f8 77             	vzeroupper
 100c194:	e8 37 d6 00 00       	call   10197d0 <clone_payload>
 100c199:	85 c0                	test   %eax,%eax
 100c19b:	0f 85 a3 00 00 00    	jne    100c244 <entry_run+0x1004>
 100c1a1:	4c 8b 64 24 40       	mov    0x40(%rsp),%r12
 100c1a6:	0f 84 a4 00 00 00    	je     100c250 <entry_run+0x1010>
 100c1ac:	85 c0                	test   %eax,%eax
 100c1ae:	74 70                	je     100c220 <entry_run+0xfe0>
 100c1b0:	e9 33 07 00 00       	jmp    100c8e8 <entry_run+0x16a8>
 100c1b5:	48 b9 00 00 00 00 00 	movabs $0x4000000000000000,%rcx
 100c1bc:	00 00 40 
 100c1bf:	48 85 c8             	test   %rcx,%rax
 100c1c2:	75 5c                	jne    100c220 <entry_run+0xfe0>
 100c1c4:	a8 01                	test   $0x1,%al
 100c1c6:	0f 85 bd 13 00 00    	jne    100d589 <entry_run+0x2349>
 100c1cc:	49 8b 45 e0          	mov    -0x20(%r13),%rax
 100c1d0:	48 83 f8 01          	cmp    $0x1,%rax
 100c1d4:	74 4a                	je     100c220 <entry_run+0xfe0>
 100c1d6:	48 85 c0             	test   %rax,%rax
 100c1d9:	74 2f                	je     100c20a <entry_run+0xfca>
 100c1db:	e9 91 fe ff ff       	jmp    100c071 <entry_run+0xe31>
 100c1e0:	48 b9 00 00 00 00 00 	movabs $0x4000000000000000,%rcx
 100c1e7:	00 00 40 
 100c1ea:	48 85 c8             	test   %rcx,%rax
 100c1ed:	75 31                	jne    100c220 <entry_run+0xfe0>
 100c1ef:	a8 01                	test   $0x1,%al
 100c1f1:	0f 85 92 13 00 00    	jne    100d589 <entry_run+0x2349>
 100c1f7:	49 8b 45 e0          	mov    -0x20(%r13),%rax
 100c1fb:	48 83 f8 01          	cmp    $0x1,%rax
 100c1ff:	74 1f                	je     100c220 <entry_run+0xfe0>
 100c201:	48 85 c0             	test   %rax,%rax
 100c204:	0f 85 73 ff ff ff    	jne    100c17d <entry_run+0xf3d>
 100c20a:	49 83 7d e8 00       	cmpq   $0x0,-0x18(%r13)
 100c20f:	0f 84 74 13 00 00    	je     100d589 <entry_run+0x2349>
 100c215:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
 100c21c:	00 00 00 00 
 100c220:	4c 8b 64 24 38       	mov    0x38(%rsp),%r12
 100c225:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
 100c22a:	48 89 84 24 68 02 00 	mov    %rax,0x268(%rsp)
 100c231:	00 
 100c232:	48 83 38 40          	cmpq   $0x40,(%rax)
 100c236:	73 38                	jae    100c270 <entry_run+0x1030>
 100c238:	31 c0                	xor    %eax,%eax
 100c23a:	4c 8b 6c 24 18       	mov    0x18(%rsp),%r13
 100c23f:	e9 f6 03 00 00       	jmp    100c63a <entry_run+0x13fa>
 100c244:	41 bc 00 00 00 00    	mov    $0x0,%r12d
 100c24a:	0f 85 5c ff ff ff    	jne    100c1ac <entry_run+0xf6c>
 100c250:	4c 89 64 24 38       	mov    %r12,0x38(%rsp)
 100c255:	c7 44 24 70 01 00 00 	movl   $0x1,0x70(%rsp)
 100c25c:	00 
 100c25d:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
 100c262:	48 89 84 24 68 02 00 	mov    %rax,0x268(%rsp)
 100c269:	00 
 100c26a:	48 83 38 40          	cmpq   $0x40,(%rax)
 100c26e:	72 c8                	jb     100c238 <entry_run+0xff8>
 100c270:	4d 85 e4             	test   %r12,%r12
 100c273:	4c 8b 6c 24 18       	mov    0x18(%rsp),%r13
 100c278:	74 0c                	je     100c286 <entry_run+0x1046>
 100c27a:	41 f6 44 24 f0 02    	testb  $0x2,-0x10(%r12)
 100c280:	0f 85 43 02 00 00    	jne    100c4c9 <entry_run+0x1289>
 100c286:	4d 8b 34 24          	mov    (%r12),%r14
 100c28a:	49 83 fe bf          	cmp    $0xffffffffffffffbf,%r14
 100c28e:	0f 87 3a 13 00 00    	ja     100d5ce <entry_run+0x238e>
 100c294:	49 8d 5e 40          	lea    0x40(%r14),%rbx
 100c298:	4c 89 a4 24 78 02 00 	mov    %r12,0x278(%rsp)
 100c29f:	00 
 100c2a0:	4d 8b 6c 24 08       	mov    0x8(%r12),%r13
 100c2a5:	4c 39 eb             	cmp    %r13,%rbx
 100c2a8:	77 0c                	ja     100c2b6 <entry_run+0x1076>
 100c2aa:	49 83 7c 24 38 00    	cmpq   $0x0,0x38(%r12)
 100c2b0:	0f 84 1a 02 00 00    	je     100c4d0 <entry_run+0x1290>
 100c2b6:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
 100c2bb:	48 8b 81 68 02 00 00 	mov    0x268(%rcx),%rax
 100c2c2:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
 100c2c7:	48 8d 84 24 78 02 00 	lea    0x278(%rsp),%rax
 100c2ce:	00 
 100c2cf:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
 100c2d4:	48 c7 44 24 50 c0 55 	movq   $0x10055c0,0x50(%rsp)
 100c2db:	00 01 
 100c2dd:	48 8d 44 24 40       	lea    0x40(%rsp),%rax
 100c2e2:	48 89 84 24 38 02 00 	mov    %rax,0x238(%rsp)
 100c2e9:	00 
 100c2ea:	48 8d 84 24 68 02 00 	lea    0x268(%rsp),%rax
 100c2f1:	00 
 100c2f2:	48 89 84 24 40 02 00 	mov    %rax,0x240(%rsp)
 100c2f9:	00 
 100c2fa:	48 c7 84 24 48 02 00 	movq   $0x10055c0,0x248(%rsp)
 100c301:	00 c0 55 00 01 
 100c306:	48 8d 84 24 38 02 00 	lea    0x238(%rsp),%rax
 100c30d:	00 
 100c30e:	48 89 81 68 02 00 00 	mov    %rax,0x268(%rcx)
 100c315:	49 83 7c 24 38 00    	cmpq   $0x0,0x38(%r12)
 100c31b:	0f 84 3e 01 00 00    	je     100c45f <entry_run+0x121f>
 100c321:	49 83 fe 41          	cmp    $0x41,%r14
 100c325:	41 bd 40 00 00 00    	mov    $0x40,%r13d
 100c32b:	4d 0f 43 ee          	cmovae %r14,%r13
 100c32f:	4d 85 f6             	test   %r14,%r14
 100c332:	74 1d                	je     100c351 <entry_run+0x1111>
 100c334:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
 100c33b:	00 00 00 00 00 
 100c340:	4d 85 ed             	test   %r13,%r13
 100c343:	0f 88 54 02 00 00    	js     100c59d <entry_run+0x135d>
 100c349:	4d 01 ed             	add    %r13,%r13
 100c34c:	49 39 dd             	cmp    %rbx,%r13
 100c34f:	72 ef                	jb     100c340 <entry_run+0x1100>
 100c351:	b2 01                	mov    $0x1,%dl
 100c353:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
 100c358:	48 83 b8 60 18 00 00 	cmpq   $0x0,0x1860(%rax)
 100c35f:	00 
 100c360:	0f 84 39 02 00 00    	je     100c59f <entry_run+0x135f>
 100c366:	49 8b 44 24 f0       	mov    -0x10(%r12),%rax
 100c36b:	49 8b 74 24 18       	mov    0x18(%r12),%rsi
 100c370:	48 89 c1             	mov    %rax,%rcx
 100c373:	48 c1 e9 28          	shr    $0x28,%rcx
 100c377:	81 e1 ff ff 0f 00    	and    $0xfffff,%ecx
 100c37d:	48 ba 00 00 00 00 00 	movabs $0x4000000000000000,%rdx
 100c384:	00 00 40 
 100c387:	48 85 d0             	test   %rdx,%rax
 100c38a:	b8 00 00 00 00       	mov    $0x0,%eax
 100c38f:	0f 44 c8             	cmove  %eax,%ecx
 100c392:	48 8b 7c 24 28       	mov    0x28(%rsp),%rdi
 100c397:	4c 89 ea             	mov    %r13,%rdx
 100c39a:	c5 f8 77             	vzeroupper
 100c39d:	e8 ee d6 00 00       	call   1019a90 <myl_rc_storage_alloc>
 100c3a2:	b2 01                	mov    $0x1,%dl
 100c3a4:	48 85 c0             	test   %rax,%rax
 100c3a7:	0f 84 f2 01 00 00    	je     100c59f <entry_run+0x135f>
 100c3ad:	49 8b 14 24          	mov    (%r12),%rdx
 100c3b1:	48 85 d2             	test   %rdx,%rdx
 100c3b4:	74 19                	je     100c3cf <entry_run+0x118f>
 100c3b6:	49 8b 74 24 20       	mov    0x20(%r12),%rsi
 100c3bb:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
 100c3c0:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
 100c3c5:	e8 16 28 01 00       	call   101ebe0 <memcpy@plt>
 100c3ca:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
 100c3cf:	4d 8b 44 24 20       	mov    0x20(%r12),%r8
 100c3d4:	49 89 44 24 20       	mov    %rax,0x20(%r12)
 100c3d9:	4d 89 6c 24 08       	mov    %r13,0x8(%r12)
 100c3de:	49 c7 44 24 38 00 00 	movq   $0x0,0x38(%r12)
 100c3e5:	00 00 
 100c3e7:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
 100c3ec:	48 8b 89 60 18 00 00 	mov    0x1860(%rcx),%rcx
 100c3f3:	48 85 c9             	test   %rcx,%rcx
 100c3f6:	74 67                	je     100c45f <entry_run+0x121f>
 100c3f8:	4d 85 c0             	test   %r8,%r8
 100c3fb:	74 53                	je     100c450 <entry_run+0x1210>
 100c3fd:	49 8b 50 f0          	mov    -0x10(%r8),%rdx
 100c401:	48 be 00 00 00 00 00 	movabs $0x4000000000000000,%rsi
 100c408:	00 00 40 
 100c40b:	48 83 c6 02          	add    $0x2,%rsi
 100c40f:	48 85 f2             	test   %rsi,%rdx
 100c412:	75 3c                	jne    100c450 <entry_run+0x1210>
 100c414:	f6 c2 01             	test   $0x1,%dl
 100c417:	0f 85 6c 11 00 00    	jne    100d589 <entry_run+0x2349>
 100c41d:	49 8d 70 e0          	lea    -0x20(%r8),%rsi
 100c421:	48 8b 3e             	mov    (%rsi),%rdi
 100c424:	48 85 ff             	test   %rdi,%rdi
 100c427:	0f 84 5c 11 00 00    	je     100d589 <entry_run+0x2349>
 100c42d:	48 ff cf             	dec    %rdi
 100c430:	48 89 3e             	mov    %rdi,(%rsi)
 100c433:	75 1b                	jne    100c450 <entry_run+0x1210>
 100c435:	49 83 78 e8 00       	cmpq   $0x0,-0x18(%r8)
 100c43a:	75 14                	jne    100c450 <entry_run+0x1210>
 100c43c:	48 83 ca 01          	or     $0x1,%rdx
 100c440:	49 89 50 f0          	mov    %rdx,-0x10(%r8)
 100c444:	48 8b 51 60          	mov    0x60(%rcx),%rdx
 100c448:	49 89 50 e0          	mov    %rdx,-0x20(%r8)
 100c44c:	48 89 71 60          	mov    %rsi,0x60(%rcx)
 100c450:	48 8b 7c 24 28       	mov    0x28(%rsp),%rdi
 100c455:	e8 76 8e 00 00       	call   10152d0 <myl_rc_drain>
 100c45a:	4d 8b 6c 24 08       	mov    0x8(%r12),%r13
 100c45f:	4c 39 eb             	cmp    %r13,%rbx
 100c462:	0f 86 31 01 00 00    	jbe    100c599 <entry_run+0x1359>
 100c468:	49 83 fd 41          	cmp    $0x41,%r13
 100c46c:	b8 40 00 00 00       	mov    $0x40,%eax
 100c471:	4c 0f 42 e8          	cmovb  %rax,%r13
 100c475:	4d 85 f6             	test   %r14,%r14
 100c478:	74 17                	je     100c491 <entry_run+0x1251>
 100c47a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
 100c480:	4d 85 ed             	test   %r13,%r13
 100c483:	0f 88 14 01 00 00    	js     100c59d <entry_run+0x135d>
 100c489:	4d 01 ed             	add    %r13,%r13
 100c48c:	49 39 dd             	cmp    %rbx,%r13
 100c48f:	72 ef                	jb     100c480 <entry_run+0x1240>
 100c491:	49 8b 74 24 20       	mov    0x20(%r12),%rsi
 100c496:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
 100c49b:	48 83 b8 60 18 00 00 	cmpq   $0x0,0x1860(%rax)
 100c4a2:	00 
 100c4a3:	74 3a                	je     100c4df <entry_run+0x129f>
 100c4a5:	48 8b 7c 24 28       	mov    0x28(%rsp),%rdi
 100c4aa:	4c 89 ea             	mov    %r13,%rdx
 100c4ad:	c5 f8 77             	vzeroupper
 100c4b0:	e8 bb e2 00 00       	call   101a770 <myl_rc_storage_extend>
 100c4b5:	48 85 c0             	test   %rax,%rax
 100c4b8:	74 46                	je     100c500 <entry_run+0x12c0>
 100c4ba:	49 89 44 24 20       	mov    %rax,0x20(%r12)
 100c4bf:	4d 89 6c 24 08       	mov    %r13,0x8(%r12)
 100c4c4:	e9 d0 00 00 00       	jmp    100c599 <entry_run+0x1359>
 100c4c9:	31 c0                	xor    %eax,%eax
 100c4cb:	e9 6a 01 00 00       	jmp    100c63a <entry_run+0x13fa>
 100c4d0:	4c 8b 6c 24 18       	mov    0x18(%rsp),%r13
 100c4d5:	48 8b 5c 24 28       	mov    0x28(%rsp),%rbx
 100c4da:	e9 2b 01 00 00       	jmp    100c60a <entry_run+0x13ca>
 100c4df:	48 85 f6             	test   %rsi,%rsi
 100c4e2:	0f 84 b5 00 00 00    	je     100c59d <entry_run+0x135d>
 100c4e8:	48 b8 00 00 00 00 00 	movabs $0x4000000000000000,%rax
 100c4ef:	00 00 40 
 100c4f2:	48 83 c0 02          	add    $0x2,%rax
 100c4f6:	48 85 46 f0          	test   %rax,-0x10(%rsi)
 100c4fa:	0f 84 65 01 00 00    	je     100c665 <entry_run+0x1425>
 100c500:	b2 01                	mov    $0x1,%dl
 100c502:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
 100c507:	48 83 b8 60 18 00 00 	cmpq   $0x0,0x1860(%rax)
 100c50e:	00 
 100c50f:	0f 84 8a 00 00 00    	je     100c59f <entry_run+0x135f>
 100c515:	49 8b 44 24 f0       	mov    -0x10(%r12),%rax
 100c51a:	49 8b 74 24 18       	mov    0x18(%r12),%rsi
 100c51f:	48 89 c1             	mov    %rax,%rcx
 100c522:	48 c1 e9 28          	shr    $0x28,%rcx
 100c526:	81 e1 ff ff 0f 00    	and    $0xfffff,%ecx
 100c52c:	48 ba 00 00 00 00 00 	movabs $0x4000000000000000,%rdx
 100c533:	00 00 40 
 100c536:	48 85 d0             	test   %rdx,%rax
 100c539:	b8 00 00 00 00       	mov    $0x0,%eax
 100c53e:	0f 44 c8             	cmove  %eax,%ecx
 100c541:	48 8b 7c 24 28       	mov    0x28(%rsp),%rdi
 100c546:	4c 89 ea             	mov    %r13,%rdx
 100c549:	c5 f8 77             	vzeroupper
 100c54c:	e8 3f d5 00 00       	call   1019a90 <myl_rc_storage_alloc>
 100c551:	b2 01                	mov    $0x1,%dl
 100c553:	48 85 c0             	test   %rax,%rax
 100c556:	74 47                	je     100c59f <entry_run+0x135f>
 100c558:	49 89 c6             	mov    %rax,%r14
 100c55b:	49 8b 14 24          	mov    (%r12),%rdx
 100c55f:	49 8b 74 24 20       	mov    0x20(%r12),%rsi
 100c564:	48 85 d2             	test   %rdx,%rdx
 100c567:	74 0d                	je     100c576 <entry_run+0x1336>
 100c569:	4c 89 f7             	mov    %r14,%rdi
 100c56c:	e8 6f 26 01 00       	call   101ebe0 <memcpy@plt>
 100c571:	49 8b 74 24 20       	mov    0x20(%r12),%rsi
 100c576:	48 8b 7c 24 28       	mov    0x28(%rsp),%rdi
 100c57b:	4d 89 74 24 20       	mov    %r14,0x20(%r12)
 100c580:	4d 89 6c 24 08       	mov    %r13,0x8(%r12)
 100c585:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
 100c58a:	48 83 b8 60 18 00 00 	cmpq   $0x0,0x1860(%rax)
 100c591:	00 
 100c592:	74 05                	je     100c599 <entry_run+0x1359>
 100c594:	e8 f7 6a 00 00       	call   1013090 <myl_rc_owner_release>
 100c599:	31 d2                	xor    %edx,%edx
 100c59b:	eb 02                	jmp    100c59f <entry_run+0x135f>
 100c59d:	b2 01                	mov    $0x1,%dl
 100c59f:	4c 8b 6c 24 18       	mov    0x18(%rsp),%r13
 100c5a4:	49 8b 85 68 02 00 00 	mov    0x268(%r13),%rax
 100c5ab:	48 8d 8c 24 38 02 00 	lea    0x238(%rsp),%rcx
 100c5b2:	00 
 100c5b3:	48 39 c8             	cmp    %rcx,%rax
 100c5b6:	74 18                	je     100c5d0 <entry_run+0x1390>
 100c5b8:	48 8d 4c 24 40       	lea    0x40(%rsp),%rcx
 100c5bd:	48 39 c8             	cmp    %rcx,%rax
 100c5c0:	48 8b 5c 24 28       	mov    0x28(%rsp),%rbx
 100c5c5:	74 27                	je     100c5ee <entry_run+0x13ae>
 100c5c7:	84 d2                	test   %dl,%dl
 100c5c9:	74 37                	je     100c602 <entry_run+0x13c2>
 100c5cb:	e9 fe 0f 00 00       	jmp    100d5ce <entry_run+0x238e>
 100c5d0:	48 8b 84 24 38 02 00 	mov    0x238(%rsp),%rax
 100c5d7:	00 
 100c5d8:	49 89 85 68 02 00 00 	mov    %rax,0x268(%r13)
 100c5df:	48 8d 4c 24 40       	lea    0x40(%rsp),%rcx
 100c5e4:	48 39 c8             	cmp    %rcx,%rax
 100c5e7:	48 8b 5c 24 28       	mov    0x28(%rsp),%rbx
 100c5ec:	75 d9                	jne    100c5c7 <entry_run+0x1387>
 100c5ee:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
 100c5f3:	49 89 85 68 02 00 00 	mov    %rax,0x268(%r13)
 100c5fa:	84 d2                	test   %dl,%dl
 100c5fc:	0f 85 cc 0f 00 00    	jne    100d5ce <entry_run+0x238e>
 100c602:	48 8b 84 24 68 02 00 	mov    0x268(%rsp),%rax
 100c609:	00 
 100c60a:	49 8b 0c 24          	mov    (%r12),%rcx
 100c60e:	49 8b 54 24 20       	mov    0x20(%r12),%rdx
 100c613:	48 8b 40 20          	mov    0x20(%rax),%rax
 100c617:	c5 fe 6f 00          	vmovdqu (%rax),%ymm0
 100c61b:	c5 fe 6f 48 20       	vmovdqu 0x20(%rax),%ymm1
 100c620:	c5 fe 7f 4c 0a 20    	vmovdqu %ymm1,0x20(%rdx,%rcx,1)
 100c626:	c5 fe 7f 04 0a       	vmovdqu %ymm0,(%rdx,%rcx,1)
 100c62b:	49 83 04 24 40       	addq   $0x40,(%r12)
 100c630:	b8 01 00 00 00       	mov    $0x1,%eax
 100c635:	4c 8d 74 24 38       	lea    0x38(%rsp),%r14
 100c63a:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
 100c63f:	83 bc 24 88 00 00 00 	cmpl   $0x0,0x88(%rsp)
 100c646:	00 
 100c647:	0f 84 63 f8 ff ff    	je     100beb0 <entry_run+0xc70>
 100c64d:	4c 89 ef             	mov    %r13,%rdi
 100c650:	48 8d b4 24 a0 01 00 	lea    0x1a0(%rsp),%rsi
 100c657:	00 
 100c658:	c5 f8 77             	vzeroupper
 100c65b:	e8 d0 0f 00 00       	call   100d630 <myl_qbe_rc_slot_drop>
 100c660:	e9 4b f8 ff ff       	jmp    100beb0 <entry_run+0xc70>
 100c665:	4c 8b 46 f8          	mov    -0x8(%rsi),%r8
 100c669:	4d 85 c0             	test   %r8,%r8
 100c66c:	0f 84 8e fe ff ff    	je     100c500 <entry_run+0x12c0>
 100c672:	4c 89 e8             	mov    %r13,%rax
 100c675:	48 c1 e8 3a          	shr    $0x3a,%rax
 100c679:	0f 85 81 fe ff ff    	jne    100c500 <entry_run+0x12c0>
 100c67f:	4d 8b 08             	mov    (%r8),%r9
 100c682:	4d 85 c9             	test   %r9,%r9
 100c685:	0f 84 75 fe ff ff    	je     100c500 <entry_run+0x12c0>
 100c68b:	48 c7 c0 ef ff ff ff 	mov    $0xffffffffffffffef,%rax
 100c692:	31 d2                	xor    %edx,%edx
 100c694:	49 f7 f1             	div    %r9
 100c697:	49 39 c5             	cmp    %rax,%r13
 100c69a:	0f 87 60 fe ff ff    	ja     100c500 <entry_run+0x12c0>
 100c6a0:	4d 0f af cd          	imul   %r13,%r9
 100c6a4:	49 83 c1 1f          	add    $0x1f,%r9
 100c6a8:	49 83 e1 f0          	and    $0xfffffffffffffff0,%r9
 100c6ac:	0f 84 4e fe ff ff    	je     100c500 <entry_run+0x12c0>
 100c6b2:	b9 34 00 00 00       	mov    $0x34,%ecx
 100c6b7:	31 c0                	xor    %eax,%eax
 100c6b9:	eb 08                	jmp    100c6c3 <entry_run+0x1483>
 100c6bb:	48 89 f9             	mov    %rdi,%rcx
 100c6be:	48 39 c8             	cmp    %rcx,%rax
 100c6c1:	73 22                	jae    100c6e5 <entry_run+0x14a5>
 100c6c3:	48 89 ca             	mov    %rcx,%rdx
 100c6c6:	48 29 c2             	sub    %rax,%rdx
 100c6c9:	48 d1 ea             	shr    $1,%rdx
 100c6cc:	48 8d 3c 02          	lea    (%rdx,%rax,1),%rdi
 100c6d0:	4c 39 0c fd d0 4f 00 	cmp    %r9,0x1004fd0(,%rdi,8)
 100c6d7:	01 
 100c6d8:	73 e1                	jae    100c6bb <entry_run+0x147b>
 100c6da:	48 01 d0             	add    %rdx,%rax
 100c6dd:	48 ff c0             	inc    %rax
 100c6e0:	48 39 c8             	cmp    %rcx,%rax
 100c6e3:	72 de                	jb     100c6c3 <entry_run+0x1483>
 100c6e5:	48 83 f8 34          	cmp    $0x34,%rax
 100c6e9:	0f 82 11 fe ff ff    	jb     100c500 <entry_run+0x12c0>
 100c6ef:	4c 8b 74 24 28       	mov    0x28(%rsp),%r14
 100c6f4:	4c 89 f3             	mov    %r14,%rbx
 100c6f7:	4d 8b 36             	mov    (%r14),%r14
 100c6fa:	4d 85 f6             	test   %r14,%r14
 100c6fd:	0f 84 fd fd ff ff    	je     100c500 <entry_run+0x12c0>
 100c703:	49 83 7e 20 34       	cmpq   $0x34,0x20(%r14)
 100c708:	72 ea                	jb     100c6f4 <entry_run+0x14b4>
 100c70a:	49 8d 86 80 04 00 00 	lea    0x480(%r14),%rax
 100c711:	48 39 f0             	cmp    %rsi,%rax
 100c714:	75 de                	jne    100c6f4 <entry_run+0x14b4>
 100c716:	49 8b 4e 08          	mov    0x8(%r14),%rcx
 100c71a:	4c 89 c8             	mov    %r9,%rax
 100c71d:	48 89 8c 24 e8 00 00 	mov    %rcx,0xe8(%rsp)
 100c724:	00 
 100c725:	48 29 c8             	sub    %rcx,%rax
 100c728:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
 100c72d:	0f 86 cd fd ff ff    	jbe    100c500 <entry_run+0x12c0>
 100c733:	48 8b 7c 24 28       	mov    0x28(%rsp),%rdi
 100c738:	48 89 b4 24 70 02 00 	mov    %rsi,0x270(%rsp)
 100c73f:	00 
 100c740:	48 8b 74 24 30       	mov    0x30(%rsp),%rsi
 100c745:	4c 89 84 24 e0 00 00 	mov    %r8,0xe0(%rsp)
 100c74c:	00 
 100c74d:	4c 89 8c 24 58 02 00 	mov    %r9,0x258(%rsp)
 100c754:	00 
 100c755:	c5 f8 77             	vzeroupper
 100c758:	e8 93 41 00 00       	call   10108f0 <allocation_due>
 100c75d:	85 c0                	test   %eax,%eax
 100c75f:	74 3c                	je     100c79d <entry_run+0x155d>
 100c761:	4c 8b 74 24 28       	mov    0x28(%rsp),%r14
 100c766:	4c 89 f7             	mov    %r14,%rdi
 100c769:	48 8b 74 24 30       	mov    0x30(%rsp),%rsi
 100c76e:	e8 ad 3f 00 00       	call   1010720 <prepare>
 100c773:	48 8b 84 24 70 02 00 	mov    0x270(%rsp),%rax
 100c77a:	00 
 100c77b:	4c 89 f3             	mov    %r14,%rbx
 100c77e:	4d 8b 36             	mov    (%r14),%r14
 100c781:	4d 85 f6             	test   %r14,%r14
 100c784:	0f 84 76 fd ff ff    	je     100c500 <entry_run+0x12c0>
 100c78a:	49 83 7e 20 34       	cmpq   $0x34,0x20(%r14)
 100c78f:	72 ea                	jb     100c77b <entry_run+0x153b>
 100c791:	49 8d 8e 80 04 00 00 	lea    0x480(%r14),%rcx
 100c798:	48 39 c1             	cmp    %rax,%rcx
 100c79b:	75 de                	jne    100c77b <entry_run+0x153b>
 100c79d:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
 100c7a2:	83 b8 50 07 00 00 00 	cmpl   $0x0,0x750(%rax)
 100c7a9:	74 14                	je     100c7bf <entry_run+0x157f>
 100c7ab:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
 100c7b0:	c7 80 c4 02 00 00 01 	movl   $0x1,0x2c4(%rax)
 100c7b7:	00 00 00 
 100c7ba:	e9 41 fd ff ff       	jmp    100c500 <entry_run+0x12c0>
 100c7bf:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
 100c7c4:	48 8b 81 b0 02 00 00 	mov    0x2b0(%rcx),%rax
 100c7cb:	48 2b 81 70 02 00 00 	sub    0x270(%rcx),%rax
 100c7d2:	72 d7                	jb     100c7ab <entry_run+0x156b>
 100c7d4:	48 39 44 24 30       	cmp    %rax,0x30(%rsp)
 100c7d9:	77 d0                	ja     100c7ab <entry_run+0x156b>
 100c7db:	48 8b 84 24 58 02 00 	mov    0x258(%rsp),%rax
 100c7e2:	00 
 100c7e3:	48 8d b0 70 04 00 00 	lea    0x470(%rax),%rsi
 100c7ea:	4c 89 f7             	mov    %r14,%rdi
 100c7ed:	e8 0e 25 01 00       	call   101ed00 <realloc@plt>
 100c7f2:	48 8b 94 24 58 02 00 	mov    0x258(%rsp),%rdx
 100c7f9:	00 
 100c7fa:	48 85 c0             	test   %rax,%rax
 100c7fd:	48 8b 8c 24 e0 00 00 	mov    0xe0(%rsp),%rcx
 100c804:	00 
 100c805:	0f 84 f5 fc ff ff    	je     100c500 <entry_run+0x12c0>
 100c80b:	48 89 50 08          	mov    %rdx,0x8(%rax)
 100c80f:	49 89 c6             	mov    %rax,%r14
 100c812:	48 89 03             	mov    %rax,(%rbx)
 100c815:	83 79 30 00          	cmpl   $0x0,0x30(%rcx)
 100c819:	74 29                	je     100c844 <entry_run+0x1604>
 100c81b:	48 8b 84 24 e0 00 00 	mov    0xe0(%rsp),%rax
 100c822:	00 
 100c823:	83 78 58 01          	cmpl   $0x1,0x58(%rax)
 100c827:	74 1b                	je     100c844 <entry_run+0x1604>
 100c829:	49 8d be 70 04 00 00 	lea    0x470(%r14),%rdi
 100c830:	48 03 bc 24 e8 00 00 	add    0xe8(%rsp),%rdi
 100c837:	00 
 100c838:	31 f6                	xor    %esi,%esi
 100c83a:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
 100c83f:	e8 4c 23 01 00       	call   101eb90 <memset@plt>
 100c844:	4c 89 f0             	mov    %r14,%rax
 100c847:	49 8b 8e 70 04 00 00 	mov    0x470(%r14),%rcx
 100c84e:	48 ba 01 00 00 00 00 	movabs $0xb000000000000001,%rdx
 100c855:	00 00 b0 
 100c858:	48 21 d1             	and    %rdx,%rcx
 100c85b:	4a 8d 0c a9          	lea    (%rcx,%r13,4),%rcx
 100c85f:	49 89 8e 70 04 00 00 	mov    %rcx,0x470(%r14)
 100c866:	48 8b 8c 24 e0 00 00 	mov    0xe0(%rsp),%rcx
 100c86d:	00 
 100c86e:	49 89 8e 78 04 00 00 	mov    %rcx,0x478(%r14)
 100c875:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
 100c87a:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
 100c87f:	48 01 91 70 02 00 00 	add    %rdx,0x270(%rcx)
 100c886:	48 05 80 04 00 00    	add    $0x480,%rax
 100c88c:	e9 29 fc ff ff       	jmp    100c4ba <entry_run+0x127a>
 100c891:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
 100c896:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
 100c89b:	48 89 84 24 38 02 00 	mov    %rax,0x238(%rsp)
 100c8a2:	00 
 100c8a3:	49 83 bd 60 18 00 00 	cmpq   $0x0,0x1860(%r13)
 100c8aa:	00 
 100c8ab:	74 68                	je     100c915 <entry_run+0x16d5>
 100c8ad:	be d8 56 00 01       	mov    $0x10056d8,%esi
 100c8b2:	48 89 df             	mov    %rbx,%rdi
 100c8b5:	c5 f8 77             	vzeroupper
 100c8b8:	e8 f3 68 00 00       	call   10131b0 <myl_rc_module_register>
 100c8bd:	49 8b 8d 60 18 00 00 	mov    0x1860(%r13),%rcx
 100c8c4:	85 c0                	test   %eax,%eax
 100c8c6:	0f 84 f8 02 00 00    	je     100cbc4 <entry_run+0x1984>
 100c8cc:	48 85 c9             	test   %rcx,%rcx
 100c8cf:	0f 84 b4 0c 00 00    	je     100d589 <entry_run+0x2349>
 100c8d5:	83 79 78 00          	cmpl   $0x0,0x78(%rcx)
 100c8d9:	0f 85 80 00 00 00    	jne    100c95f <entry_run+0x171f>
 100c8df:	c7 41 78 01 00 00 00 	movl   $0x1,0x78(%rcx)
 100c8e6:	eb 77                	jmp    100c95f <entry_run+0x171f>
 100c8e8:	83 f8 01             	cmp    $0x1,%eax
 100c8eb:	0f 85 bf 09 00 00    	jne    100d2b0 <entry_run+0x2070>
 100c8f1:	be 6a 36 00 01       	mov    $0x100366a,%esi
 100c8f6:	4c 8b 6c 24 18       	mov    0x18(%rsp),%r13
 100c8fb:	41 83 bd c4 02 00 00 	cmpl   $0x0,0x2c4(%r13)
 100c902:	00 
 100c903:	0f 85 af 01 00 00    	jne    100cab8 <entry_run+0x1878>
 100c909:	b8 01 00 00 00       	mov    $0x1,%eax
 100c90e:	89 c0                	mov    %eax,%eax
 100c910:	e9 9b 01 00 00       	jmp    100cab0 <entry_run+0x1870>
 100c915:	49 8b 85 68 02 00 00 	mov    0x268(%r13),%rax
 100c91c:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
 100c921:	48 8d 84 24 38 02 00 	lea    0x238(%rsp),%rax
 100c928:	00 
 100c929:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
 100c92e:	48 c7 44 24 50 c0 55 	movq   $0x10055c0,0x50(%rsp)
 100c935:	00 01 
 100c937:	48 8d 4c 24 40       	lea    0x40(%rsp),%rcx
 100c93c:	49 89 8d 68 02 00 00 	mov    %rcx,0x268(%r13)
 100c943:	31 c0                	xor    %eax,%eax
 100c945:	49 39 8d 68 02 00 00 	cmp    %rcx,0x268(%r13)
 100c94c:	75 0c                	jne    100c95a <entry_run+0x171a>
 100c94e:	48 8b 4c 24 40       	mov    0x40(%rsp),%rcx
 100c953:	49 89 8d 68 02 00 00 	mov    %rcx,0x268(%r13)
 100c95a:	48 85 c0             	test   %rax,%rax
 100c95d:	75 0d                	jne    100c96c <entry_run+0x172c>
 100c95f:	4c 89 ef             	mov    %r13,%rdi
 100c962:	c5 f8 77             	vzeroupper
 100c965:	e8 a6 1b 00 00       	call   100e510 <myl_qbe_fail_allocation>
 100c96a:	31 c0                	xor    %eax,%eax
 100c96c:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
 100c971:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
 100c976:	48 c7 84 24 c0 01 00 	movq   $0x1001c28,0x1c0(%rsp)
 100c97d:	00 28 1c 00 01 
 100c982:	c7 84 24 d8 01 00 00 	movl   $0x2,0x1d8(%rsp)
 100c989:	02 00 00 00 
 100c98d:	c7 84 24 90 00 00 00 	movl   $0x1,0x90(%rsp)
 100c994:	01 00 00 00 
 100c998:	83 bc 24 88 00 00 00 	cmpl   $0x0,0x88(%rsp)
 100c99f:	00 
 100c9a0:	74 21                	je     100c9c3 <entry_run+0x1783>
 100c9a2:	4c 89 ef             	mov    %r13,%rdi
 100c9a5:	48 8d b4 24 a0 01 00 	lea    0x1a0(%rsp),%rsi
 100c9ac:	00 
 100c9ad:	c5 f8 77             	vzeroupper
 100c9b0:	e8 7b 0c 00 00       	call   100d630 <myl_qbe_rc_slot_drop>
 100c9b5:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
 100c9ba:	8b 8c 24 d8 01 00 00 	mov    0x1d8(%rsp),%ecx
 100c9c1:	eb 05                	jmp    100c9c8 <entry_run+0x1788>
 100c9c3:	b9 02 00 00 00       	mov    $0x2,%ecx
 100c9c8:	48 89 84 24 b0 00 00 	mov    %rax,0xb0(%rsp)
 100c9cf:	00 
 100c9d0:	48 c7 84 24 a0 01 00 	movq   $0x1001c28,0x1a0(%rsp)
 100c9d7:	00 28 1c 00 01 
 100c9dc:	89 8c 24 b8 01 00 00 	mov    %ecx,0x1b8(%rsp)
 100c9e3:	c7 84 24 90 00 00 00 	movl   $0x0,0x90(%rsp)
 100c9ea:	00 00 00 00 
 100c9ee:	c7 84 24 88 00 00 00 	movl   $0x1,0x88(%rsp)
 100c9f5:	01 00 00 00 
 100c9f9:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
 100c9fe:	f6 c1 18             	test   $0x18,%cl
 100ca01:	0f 84 3a 01 00 00    	je     100cb41 <entry_run+0x1901>
 100ca07:	48 8d 54 24 20       	lea    0x20(%rsp),%rdx
 100ca0c:	48 8d 4c 24 10       	lea    0x10(%rsp),%rcx
 100ca11:	be 28 1c 00 01       	mov    $0x1001c28,%esi
 100ca16:	48 89 df             	mov    %rbx,%rdi
 100ca19:	44 8b 84 24 00 02 00 	mov    0x200(%rsp),%r8d
 100ca20:	00 
 100ca21:	c5 f8 77             	vzeroupper
 100ca24:	e8 d7 e7 00 00       	call   101b200 <myl_rc_native_retain>
 100ca29:	85 c0                	test   %eax,%eax
 100ca2b:	74 45                	je     100ca72 <entry_run+0x1832>
 100ca2d:	48 c7 84 24 c0 01 00 	movq   $0x1001c28,0x1c0(%rsp)
 100ca34:	00 28 1c 00 01 
 100ca39:	c7 84 24 d8 01 00 00 	movl   $0x2,0x1d8(%rsp)
 100ca40:	02 00 00 00 
 100ca44:	c7 84 24 90 00 00 00 	movl   $0x1,0x90(%rsp)
 100ca4b:	01 00 00 00 
 100ca4f:	83 bc 24 88 00 00 00 	cmpl   $0x0,0x88(%rsp)
 100ca56:	00 
 100ca57:	0f 84 22 02 00 00    	je     100cc7f <entry_run+0x1a3f>
 100ca5d:	4c 89 ef             	mov    %r13,%rdi
 100ca60:	48 8d b4 24 a0 01 00 	lea    0x1a0(%rsp),%rsi
 100ca67:	00 
 100ca68:	e8 c3 0b 00 00       	call   100d630 <myl_qbe_rc_slot_drop>
 100ca6d:	e9 0d 02 00 00       	jmp    100cc7f <entry_run+0x1a3f>
 100ca72:	49 8b 8d 60 18 00 00 	mov    0x1860(%r13),%rcx
 100ca79:	48 85 c9             	test   %rcx,%rcx
 100ca7c:	0f 84 07 0b 00 00    	je     100d589 <entry_run+0x2349>
 100ca82:	8b 41 78             	mov    0x78(%rcx),%eax
 100ca85:	c7 41 78 00 00 00 00 	movl   $0x0,0x78(%rcx)
 100ca8c:	48 85 c0             	test   %rax,%rax
 100ca8f:	74 2f                	je     100cac0 <entry_run+0x1880>
 100ca91:	83 f8 01             	cmp    $0x1,%eax
 100ca94:	75 11                	jne    100caa7 <entry_run+0x1867>
 100ca96:	be 6a 36 00 01       	mov    $0x100366a,%esi
 100ca9b:	41 83 bd c4 02 00 00 	cmpl   $0x0,0x2c4(%r13)
 100caa2:	00 
 100caa3:	75 13                	jne    100cab8 <entry_run+0x1878>
 100caa5:	eb 09                	jmp    100cab0 <entry_run+0x1870>
 100caa7:	83 f8 04             	cmp    $0x4,%eax
 100caaa:	0f 83 e1 0a 00 00    	jae    100d591 <entry_run+0x2351>
 100cab0:	48 8b 34 c5 58 57 00 	mov    0x1005758(,%rax,8),%rsi
 100cab7:	01 
 100cab8:	4c 89 ef             	mov    %r13,%rdi
 100cabb:	e8 a0 13 00 00       	call   100de60 <fail>
 100cac0:	48 8d 84 24 c0 00 00 	lea    0xc0(%rsp),%rax
 100cac7:	00 
 100cac8:	49 39 85 80 3d 00 00 	cmp    %rax,0x3d80(%r13)
 100cacf:	0f 85 b4 0a 00 00    	jne    100d589 <entry_run+0x2349>
 100cad5:	48 8b b4 24 d8 00 00 	mov    0xd8(%rsp),%rsi
 100cadc:	00 
 100cadd:	48 89 df             	mov    %rbx,%rdi
 100cae0:	e8 bb a7 00 00       	call   10172a0 <myl_rc_scope_unwind>
 100cae5:	48 8b 9c 24 d0 00 00 	mov    0xd0(%rsp),%rbx
 100caec:	00 
 100caed:	48 85 db             	test   %rbx,%rbx
 100caf0:	0f 84 17 09 00 00    	je     100d40d <entry_run+0x21cd>
 100caf6:	49 89 de             	mov    %rbx,%r14
 100caf9:	49 c1 e6 05          	shl    $0x5,%r14
 100cafd:	49 83 c6 e0          	add    $0xffffffffffffffe0,%r14
 100cb01:	eb 25                	jmp    100cb28 <entry_run+0x18e8>
 100cb03:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 100cb0a:	84 00 00 00 00 00 
 100cb10:	4c 01 f6             	add    %r14,%rsi
 100cb13:	4c 89 ef             	mov    %r13,%rdi
 100cb16:	e8 15 0b 00 00       	call   100d630 <myl_qbe_rc_slot_drop>
 100cb1b:	49 83 c6 e0          	add    $0xffffffffffffffe0,%r14
 100cb1f:	48 ff cb             	dec    %rbx
 100cb22:	0f 84 e5 08 00 00    	je     100d40d <entry_run+0x21cd>
 100cb28:	48 8b b4 24 c8 00 00 	mov    0xc8(%rsp),%rsi
 100cb2f:	00 
 100cb30:	4a 8b 44 36 10       	mov    0x10(%rsi,%r14,1),%rax
 100cb35:	48 85 c0             	test   %rax,%rax
 100cb38:	74 d6                	je     100cb10 <entry_run+0x18d0>
 100cb3a:	83 38 00             	cmpl   $0x0,(%rax)
 100cb3d:	75 d1                	jne    100cb10 <entry_run+0x18d0>
 100cb3f:	eb da                	jmp    100cb1b <entry_run+0x18db>
 100cb41:	48 85 c0             	test   %rax,%rax
 100cb44:	0f 84 ff 00 00 00    	je     100cc49 <entry_run+0x1a09>
 100cb4a:	48 b9 01 00 00 00 00 	movabs $0x5000000000000001,%rcx
 100cb51:	00 00 50 
 100cb54:	48 85 48 f0          	test   %rcx,-0x10(%rax)
 100cb58:	0f 84 eb 00 00 00    	je     100cc49 <entry_run+0x1a09>
 100cb5e:	48 8d 54 24 20       	lea    0x20(%rsp),%rdx
 100cb63:	48 8d 4c 24 10       	lea    0x10(%rsp),%rcx
 100cb68:	be 28 1c 00 01       	mov    $0x1001c28,%esi
 100cb6d:	48 89 df             	mov    %rbx,%rdi
 100cb70:	44 8b 84 24 00 02 00 	mov    0x200(%rsp),%r8d
 100cb77:	00 
 100cb78:	c5 f8 77             	vzeroupper
 100cb7b:	e8 00 e1 00 00       	call   101ac80 <myl_rc_native_take>
 100cb80:	85 c0                	test   %eax,%eax
 100cb82:	0f 85 ca 00 00 00    	jne    100cc52 <entry_run+0x1a12>
 100cb88:	49 8b 85 60 18 00 00 	mov    0x1860(%r13),%rax
 100cb8f:	48 85 c0             	test   %rax,%rax
 100cb92:	0f 84 f1 09 00 00    	je     100d589 <entry_run+0x2349>
 100cb98:	8b 70 78             	mov    0x78(%rax),%esi
 100cb9b:	c7 40 78 00 00 00 00 	movl   $0x0,0x78(%rax)
 100cba2:	4c 89 ef             	mov    %r13,%rdi
 100cba5:	e8 46 0a 00 00       	call   100d5f0 <myl_qbe_rc_status>
 100cbaa:	48 8d 84 24 c0 00 00 	lea    0xc0(%rsp),%rax
 100cbb1:	00 
 100cbb2:	49 39 85 80 3d 00 00 	cmp    %rax,0x3d80(%r13)
 100cbb9:	0f 84 16 ff ff ff    	je     100cad5 <entry_run+0x1895>
 100cbbf:	e9 c5 09 00 00       	jmp    100d589 <entry_run+0x2349>
 100cbc4:	49 8b 85 68 02 00 00 	mov    0x268(%r13),%rax
 100cbcb:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
 100cbd0:	48 8d 84 24 38 02 00 	lea    0x238(%rsp),%rax
 100cbd7:	00 
 100cbd8:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
 100cbdd:	48 c7 44 24 50 c0 55 	movq   $0x10055c0,0x50(%rsp)
 100cbe4:	00 01 
 100cbe6:	48 8d 44 24 40       	lea    0x40(%rsp),%rax
 100cbeb:	49 89 85 68 02 00 00 	mov    %rax,0x268(%r13)
 100cbf2:	48 85 c9             	test   %rcx,%rcx
 100cbf5:	0f 84 e3 06 00 00    	je     100d2de <entry_run+0x209e>
 100cbfb:	41 8b 8d c8 02 00 00 	mov    0x2c8(%r13),%ecx
 100cc02:	be 30 56 00 01       	mov    $0x1005630,%esi
 100cc07:	ba 01 00 00 00       	mov    $0x1,%edx
 100cc0c:	48 89 df             	mov    %rbx,%rdi
 100cc0f:	e8 7c ce 00 00       	call   1019a90 <myl_rc_storage_alloc>
 100cc14:	48 85 c0             	test   %rax,%rax
 100cc17:	0f 84 c1 06 00 00    	je     100d2de <entry_run+0x209e>
 100cc1d:	48 8b 8c 24 38 02 00 	mov    0x238(%rsp),%rcx
 100cc24:	00 
 100cc25:	48 85 c9             	test   %rcx,%rcx
 100cc28:	0f 84 43 08 00 00    	je     100d471 <entry_run+0x2231>
 100cc2e:	48 81 79 f8 30 56 00 	cmpq   $0x1005630,-0x8(%rcx)
 100cc35:	01 
 100cc36:	be 38 00 00 00       	mov    $0x38,%esi
 100cc3b:	ba 20 00 00 00       	mov    $0x20,%edx
 100cc40:	48 0f 44 d6          	cmove  %rsi,%rdx
 100cc44:	e9 2d 08 00 00       	jmp    100d476 <entry_run+0x2236>
 100cc49:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
 100cc50:	00 00 
 100cc52:	c7 84 24 88 00 00 00 	movl   $0x0,0x88(%rsp)
 100cc59:	00 00 00 00 
 100cc5d:	48 c7 84 24 c0 01 00 	movq   $0x1001c28,0x1c0(%rsp)
 100cc64:	00 28 1c 00 01 
 100cc69:	c7 84 24 d8 01 00 00 	movl   $0x2,0x1d8(%rsp)
 100cc70:	02 00 00 00 
 100cc74:	c7 84 24 90 00 00 00 	movl   $0x1,0x90(%rsp)
 100cc7b:	01 00 00 00 
 100cc7f:	83 bc 24 80 00 00 00 	cmpl   $0x0,0x80(%rsp)
 100cc86:	00 
 100cc87:	74 13                	je     100cc9c <entry_run+0x1a5c>
 100cc89:	4c 89 ef             	mov    %r13,%rdi
 100cc8c:	48 8d b4 24 80 01 00 	lea    0x180(%rsp),%rsi
 100cc93:	00 
 100cc94:	c5 f8 77             	vzeroupper
 100cc97:	e8 94 09 00 00       	call   100d630 <myl_qbe_rc_slot_drop>
 100cc9c:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
 100cca1:	48 89 84 24 a8 00 00 	mov    %rax,0xa8(%rsp)
 100cca8:	00 
 100cca9:	c7 84 24 90 00 00 00 	movl   $0x0,0x90(%rsp)
 100ccb0:	00 00 00 00 
 100ccb4:	48 c7 84 24 80 01 00 	movq   $0x1001c28,0x180(%rsp)
 100ccbb:	00 28 1c 00 01 
 100ccc0:	48 8d 8c 24 a8 00 00 	lea    0xa8(%rsp),%rcx
 100ccc7:	00 
 100ccc8:	48 89 8c 24 88 01 00 	mov    %rcx,0x188(%rsp)
 100cccf:	00 
 100ccd0:	48 8d 8c 24 80 00 00 	lea    0x80(%rsp),%rcx
 100ccd7:	00 
 100ccd8:	48 89 8c 24 90 01 00 	mov    %rcx,0x190(%rsp)
 100ccdf:	00 
 100cce0:	8b 8c 24 d8 01 00 00 	mov    0x1d8(%rsp),%ecx
 100cce7:	89 8c 24 98 01 00 00 	mov    %ecx,0x198(%rsp)
 100ccee:	c7 84 24 80 00 00 00 	movl   $0x1,0x80(%rsp)
 100ccf5:	01 00 00 00 
 100ccf9:	48 8b 18             	mov    (%rax),%rbx
 100ccfc:	48 89 5c 24 10       	mov    %rbx,0x10(%rsp)
 100cd01:	83 bc 24 88 00 00 00 	cmpl   $0x0,0x88(%rsp)
 100cd08:	00 
 100cd09:	74 18                	je     100cd23 <entry_run+0x1ae3>
 100cd0b:	4c 89 ef             	mov    %r13,%rdi
 100cd0e:	48 8d b4 24 a0 01 00 	lea    0x1a0(%rsp),%rsi
 100cd15:	00 
 100cd16:	c5 f8 77             	vzeroupper
 100cd19:	e8 12 09 00 00       	call   100d630 <myl_qbe_rc_slot_drop>
 100cd1e:	48 8b 5c 24 10       	mov    0x10(%rsp),%rbx
 100cd23:	49 bc ff ff ff ff ff 	movabs $0x7fffffffffffffff,%r12
 100cd2a:	ff ff 7f 
 100cd2d:	48 b8 02 00 00 00 00 	movabs $0x2000000000000002,%rax
 100cd34:	00 00 20 
 100cd37:	48 8d 48 ee          	lea    -0x12(%rax),%rcx
 100cd3b:	48 21 d9             	and    %rbx,%rcx
 100cd3e:	48 89 4c 24 30       	mov    %rcx,0x30(%rsp)
 100cd43:	48 8d 48 fa          	lea    -0x6(%rax),%rcx
 100cd47:	48 21 d9             	and    %rbx,%rcx
 100cd4a:	48 89 8c 24 e8 00 00 	mov    %rcx,0xe8(%rsp)
 100cd51:	00 
 100cd52:	45 31 f6             	xor    %r14d,%r14d
 100cd55:	48 ff c8             	dec    %rax
 100cd58:	48 89 84 24 f0 00 00 	mov    %rax,0xf0(%rsp)
 100cd5f:	00 
 100cd60:	c5 79 6f 05 b8 4a ff 	vmovdqa -0xb548(%rip),%xmm8        # 1001820 <__abi_tag+0x1524>
 100cd67:	ff 
 100cd68:	c4 62 7d 59 0d d7 4a 	vpbroadcastq -0xb529(%rip),%ymm9        # 1001848 <__abi_tag+0x154c>
 100cd6f:	ff ff 
 100cd71:	c5 79 6f 15 a7 4a ff 	vmovdqa -0xb559(%rip),%xmm10        # 1001820 <__abi_tag+0x1524>
 100cd78:	ff 
 100cd79:	45 31 ed             	xor    %r13d,%r13d
 100cd7c:	c5 7d 7f 8c 24 00 02 	vmovdqa %ymm9,0x200(%rsp)
 100cd83:	00 00 
 100cd85:	eb 1f                	jmp    100cda6 <entry_run+0x1b66>
 100cd87:	49 89 ce             	mov    %rcx,%r14
 100cd8a:	31 c0                	xor    %eax,%eax
 100cd8c:	49 83 fd 0f          	cmp    $0xf,%r13
 100cd90:	4d 8d 6d 01          	lea    0x1(%r13),%r13
 100cd94:	0f 92 c0             	setb   %al
 100cd97:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
 100cd9c:	49 83 fd 10          	cmp    $0x10,%r13
 100cda0:	0f 84 73 02 00 00    	je     100d019 <entry_run+0x1dd9>
 100cda6:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
 100cdab:	4c 89 f1             	mov    %r14,%rcx
 100cdae:	4c 01 e9             	add    %r13,%rcx
 100cdb1:	0f 80 04 08 00 00    	jo     100d5bb <entry_run+0x237b>
 100cdb7:	83 bc 24 98 01 00 00 	cmpl   $0x2,0x198(%rsp)
 100cdbe:	02 
 100cdbf:	0f 85 7b 01 00 00    	jne    100cf40 <entry_run+0x1d00>
 100cdc5:	8b 84 24 80 00 00 00 	mov    0x80(%rsp),%eax
 100cdcc:	83 e0 01             	and    $0x1,%eax
 100cdcf:	0f 84 6b 01 00 00    	je     100cf40 <entry_run+0x1d00>
 100cdd5:	83 bc 24 88 00 00 00 	cmpl   $0x0,0x88(%rsp)
 100cddc:	00 
 100cddd:	0f 85 5d 01 00 00    	jne    100cf40 <entry_run+0x1d00>
 100cde3:	48 b8 f1 ff ff ff ff 	movabs $0xffffffffffffff1,%rax
 100cdea:	ff ff 0f 
 100cded:	48 8d 53 f0          	lea    -0x10(%rbx),%rdx
 100cdf1:	48 39 c2             	cmp    %rax,%rdx
 100cdf4:	0f 83 46 01 00 00    	jae    100cf40 <entry_run+0x1d00>
 100cdfa:	48 01 c8             	add    %rcx,%rax
 100cdfd:	48 83 c0 0f          	add    $0xf,%rax
 100ce01:	48 3b 84 24 f0 00 00 	cmp    0xf0(%rsp),%rax
 100ce08:	00 
 100ce09:	0f 83 31 01 00 00    	jae    100cf40 <entry_run+0x1d00>
 100ce0f:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
 100ce16:	00 
 100ce17:	48 3b 18             	cmp    (%rax),%rbx
 100ce1a:	0f 8f 29 01 00 00    	jg     100cf49 <entry_run+0x1d09>
 100ce20:	48 8b 40 20          	mov    0x20(%rax),%rax
 100ce24:	c4 e1 f9 6e c1       	vmovq  %rcx,%xmm0
 100ce29:	c5 f1 ef c9          	vpxor  %xmm1,%xmm1,%xmm1
 100ce2d:	31 c9                	xor    %ecx,%ecx
 100ce2f:	c5 e9 ef d2          	vpxor  %xmm2,%xmm2,%xmm2
 100ce33:	c5 e1 ef db          	vpxor  %xmm3,%xmm3,%xmm3
 100ce37:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
 100ce3c:	0f 1f 40 00          	nopl   0x0(%rax)
 100ce40:	c5 f9 6e 24 08       	vmovd  (%rax,%rcx,1),%xmm4
 100ce45:	c5 f9 6e 6c 08 04    	vmovd  0x4(%rax,%rcx,1),%xmm5
 100ce4b:	c5 f9 6e 74 08 08    	vmovd  0x8(%rax,%rcx,1),%xmm6
 100ce51:	c5 f9 6e 7c 08 0c    	vmovd  0xc(%rax,%rcx,1),%xmm7
 100ce57:	c5 b9 74 e4          	vpcmpeqb %xmm4,%xmm8,%xmm4
 100ce5b:	c4 e2 7d 32 e4       	vpmovzxbq %xmm4,%ymm4
 100ce60:	c5 b5 db e4          	vpand  %ymm4,%ymm9,%ymm4
 100ce64:	c5 fd d4 c4          	vpaddq %ymm4,%ymm0,%ymm0
 100ce68:	c5 b9 74 e5          	vpcmpeqb %xmm5,%xmm8,%xmm4
 100ce6c:	c4 e2 7d 32 e4       	vpmovzxbq %xmm4,%ymm4
 100ce71:	c5 b5 db e4          	vpand  %ymm4,%ymm9,%ymm4
 100ce75:	c5 f5 d4 cc          	vpaddq %ymm4,%ymm1,%ymm1
 100ce79:	c5 b9 74 e6          	vpcmpeqb %xmm6,%xmm8,%xmm4
 100ce7d:	c4 e2 7d 32 e4       	vpmovzxbq %xmm4,%ymm4
 100ce82:	c5 b5 db e4          	vpand  %ymm4,%ymm9,%ymm4
 100ce86:	c5 ed d4 d4          	vpaddq %ymm4,%ymm2,%ymm2
 100ce8a:	c5 b9 74 e7          	vpcmpeqb %xmm7,%xmm8,%xmm4
 100ce8e:	c4 e2 7d 32 e4       	vpmovzxbq %xmm4,%ymm4
 100ce93:	c5 b5 db e4          	vpand  %ymm4,%ymm9,%ymm4
 100ce97:	c5 e5 d4 dc          	vpaddq %ymm4,%ymm3,%ymm3
 100ce9b:	48 83 c1 10          	add    $0x10,%rcx
 100ce9f:	48 39 ca             	cmp    %rcx,%rdx
 100cea2:	75 9c                	jne    100ce40 <entry_run+0x1c00>
 100cea4:	c5 f5 d4 c0          	vpaddq %ymm0,%ymm1,%ymm0
 100cea8:	c5 ed d4 c0          	vpaddq %ymm0,%ymm2,%ymm0
 100ceac:	c5 e5 d4 c0          	vpaddq %ymm0,%ymm3,%ymm0
 100ceb0:	c4 e3 7d 39 c1 01    	vextracti128 $0x1,%ymm0,%xmm1
 100ceb6:	c5 f9 d4 c1          	vpaddq %xmm1,%xmm0,%xmm0
 100ceba:	c5 f9 70 c8 ee       	vpshufd $0xee,%xmm0,%xmm1
 100cebf:	c5 f9 d4 c1          	vpaddq %xmm1,%xmm0,%xmm0
 100cec3:	c4 c1 f9 7e c6       	vmovq  %xmm0,%r14
 100cec8:	48 39 d3             	cmp    %rdx,%rbx
 100cecb:	0f 84 b9 fe ff ff    	je     100cd8a <entry_run+0x1b4a>
 100ced1:	f6 c3 0c             	test   $0xc,%bl
 100ced4:	0f 84 1c 01 00 00    	je     100cff6 <entry_run+0x1db6>
 100ceda:	c4 c1 f9 6e c6       	vmovq  %r14,%xmm0
 100cedf:	48 8b 4c 24 30       	mov    0x30(%rsp),%rcx
 100cee4:	48 8b 94 24 e8 00 00 	mov    0xe8(%rsp),%rdx
 100ceeb:	00 
 100ceec:	0f 1f 40 00          	nopl   0x0(%rax)
 100cef0:	c5 f9 6e 0c 08       	vmovd  (%rax,%rcx,1),%xmm1
 100cef5:	c5 a9 74 c9          	vpcmpeqb %xmm1,%xmm10,%xmm1
 100cef9:	c4 e2 7d 32 c9       	vpmovzxbq %xmm1,%ymm1
 100cefe:	c5 b5 db c9          	vpand  %ymm1,%ymm9,%ymm1
 100cf02:	c5 fd d4 c1          	vpaddq %ymm1,%ymm0,%ymm0
 100cf06:	48 83 c1 04          	add    $0x4,%rcx
 100cf0a:	48 39 ca             	cmp    %rcx,%rdx
 100cf0d:	75 e1                	jne    100cef0 <entry_run+0x1cb0>
 100cf0f:	c4 e3 7d 39 c1 01    	vextracti128 $0x1,%ymm0,%xmm1
 100cf15:	c5 f9 d4 c1          	vpaddq %xmm1,%xmm0,%xmm0
 100cf19:	c5 f9 70 c8 ee       	vpshufd $0xee,%xmm0,%xmm1
 100cf1e:	c5 f9 d4 c1          	vpaddq %xmm1,%xmm0,%xmm0
 100cf22:	c4 c1 f9 7e c6       	vmovq  %xmm0,%r14
 100cf27:	48 89 d1             	mov    %rdx,%rcx
 100cf2a:	48 39 d3             	cmp    %rdx,%rbx
 100cf2d:	0f 85 cd 00 00 00    	jne    100d000 <entry_run+0x1dc0>
 100cf33:	e9 52 fe ff ff       	jmp    100cd8a <entry_run+0x1b4a>
 100cf38:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
 100cf3f:	00 
 100cf40:	48 85 db             	test   %rbx,%rbx
 100cf43:	0f 8e 3e fe ff ff    	jle    100cd87 <entry_run+0x1b47>
 100cf49:	45 31 ff             	xor    %r15d,%r15d
 100cf4c:	49 89 ce             	mov    %rcx,%r14
 100cf4f:	eb 25                	jmp    100cf76 <entry_run+0x1d36>
 100cf51:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 100cf58:	0f 1f 84 00 00 00 00 
 100cf5f:	00 
 100cf60:	49 ff c7             	inc    %r15
 100cf63:	31 c0                	xor    %eax,%eax
 100cf65:	49 39 df             	cmp    %rbx,%r15
 100cf68:	0f 9c c0             	setl   %al
 100cf6b:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
 100cf70:	0f 84 14 fe ff ff    	je     100cd8a <entry_run+0x1b4a>
 100cf76:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
 100cf7d:	00 
 100cf7e:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
 100cf83:	48 8b 10             	mov    (%rax),%rdx
 100cf86:	49 39 d7             	cmp    %rdx,%r15
 100cf89:	0f 83 07 06 00 00    	jae    100d596 <entry_run+0x2356>
 100cf8f:	48 8b 40 20          	mov    0x20(%rax),%rax
 100cf93:	42 0f b6 04 38       	movzbl (%rax,%r15,1),%eax
 100cf98:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
 100cf9d:	83 bc 24 88 00 00 00 	cmpl   $0x0,0x88(%rsp)
 100cfa4:	00 
 100cfa5:	74 33                	je     100cfda <entry_run+0x1d9a>
 100cfa7:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
 100cfac:	48 8d b4 24 a0 01 00 	lea    0x1a0(%rsp),%rsi
 100cfb3:	00 
 100cfb4:	c5 f8 77             	vzeroupper
 100cfb7:	e8 74 06 00 00       	call   100d630 <myl_qbe_rc_slot_drop>
 100cfbc:	c5 79 6f 15 5c 48 ff 	vmovdqa -0xb7a4(%rip),%xmm10        # 1001820 <__abi_tag+0x1524>
 100cfc3:	ff 
 100cfc4:	c5 7d 6f 8c 24 00 02 	vmovdqa 0x200(%rsp),%ymm9
 100cfcb:	00 00 
 100cfcd:	c5 79 6f 05 4b 48 ff 	vmovdqa -0xb7b5(%rip),%xmm8        # 1001820 <__abi_tag+0x1524>
 100cfd4:	ff 
 100cfd5:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
 100cfda:	48 83 f8 6d          	cmp    $0x6d,%rax
 100cfde:	75 80                	jne    100cf60 <entry_run+0x1d20>
 100cfe0:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
 100cfe5:	4d 39 e6             	cmp    %r12,%r14
 100cfe8:	0f 84 b8 05 00 00    	je     100d5a6 <entry_run+0x2366>
 100cfee:	49 ff c6             	inc    %r14
 100cff1:	e9 6a ff ff ff       	jmp    100cf60 <entry_run+0x1d20>
 100cff6:	48 8b 4c 24 30       	mov    0x30(%rsp),%rcx
 100cffb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
 100d000:	31 d2                	xor    %edx,%edx
 100d002:	80 3c 08 6d          	cmpb   $0x6d,(%rax,%rcx,1)
 100d006:	0f 94 c2             	sete   %dl
 100d009:	49 01 d6             	add    %rdx,%r14
 100d00c:	48 ff c1             	inc    %rcx
 100d00f:	48 39 cb             	cmp    %rcx,%rbx
 100d012:	75 ec                	jne    100d000 <entry_run+0x1dc0>
 100d014:	e9 71 fd ff ff       	jmp    100cd8a <entry_run+0x1b4a>
 100d019:	48 c7 44 24 10 01 00 	movq   $0x1,0x10(%rsp)
 100d020:	00 00 
 100d022:	bf 01 00 00 00       	mov    $0x1,%edi
 100d027:	be 20 00 00 00       	mov    $0x20,%esi
 100d02c:	c5 f8 77             	vzeroupper
 100d02f:	e8 9c 1b 01 00       	call   101ebd0 <calloc@plt>
 100d034:	49 89 c7             	mov    %rax,%r15
 100d037:	48 85 c0             	test   %rax,%rax
 100d03a:	75 0a                	jne    100d046 <entry_run+0x1e06>
 100d03c:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
 100d041:	e8 ca 14 00 00       	call   100e510 <myl_qbe_fail_allocation>
 100d046:	48 8d 7c 24 40       	lea    0x40(%rsp),%rdi
 100d04b:	be 18 00 00 00       	mov    $0x18,%esi
 100d050:	ba 3a 34 00 01       	mov    $0x100343a,%edx
 100d055:	4c 89 f1             	mov    %r14,%rcx
 100d058:	31 c0                	xor    %eax,%eax
 100d05a:	e8 b1 1c 01 00       	call   101ed10 <snprintf@plt>
 100d05f:	85 c0                	test   %eax,%eax
 100d061:	0f 8e 1c 02 00 00    	jle    100d283 <entry_run+0x2043>
 100d067:	41 89 c5             	mov    %eax,%r13d
 100d06a:	41 bc 40 00 00 00    	mov    $0x40,%r12d
 100d070:	83 f8 41             	cmp    $0x41,%eax
 100d073:	0f 82 b2 01 00 00    	jb     100d22b <entry_run+0x1feb>
 100d079:	41 bc 80 00 00 00    	mov    $0x80,%r12d
 100d07f:	41 81 fd 81 00 00 00 	cmp    $0x81,%r13d
 100d086:	0f 82 9f 01 00 00    	jb     100d22b <entry_run+0x1feb>
 100d08c:	41 bc 00 01 00 00    	mov    $0x100,%r12d
 100d092:	41 81 fd 01 01 00 00 	cmp    $0x101,%r13d
 100d099:	0f 82 8c 01 00 00    	jb     100d22b <entry_run+0x1feb>
 100d09f:	41 bc 00 02 00 00    	mov    $0x200,%r12d
 100d0a5:	41 81 fd 01 02 00 00 	cmp    $0x201,%r13d
 100d0ac:	0f 82 79 01 00 00    	jb     100d22b <entry_run+0x1feb>
 100d0b2:	41 bc 00 04 00 00    	mov    $0x400,%r12d
 100d0b8:	41 81 fd 01 04 00 00 	cmp    $0x401,%r13d
 100d0bf:	0f 82 66 01 00 00    	jb     100d22b <entry_run+0x1feb>
 100d0c5:	41 bc 00 08 00 00    	mov    $0x800,%r12d
 100d0cb:	41 81 fd 01 08 00 00 	cmp    $0x801,%r13d
 100d0d2:	0f 82 53 01 00 00    	jb     100d22b <entry_run+0x1feb>
 100d0d8:	41 bc 00 10 00 00    	mov    $0x1000,%r12d
 100d0de:	41 81 fd 01 10 00 00 	cmp    $0x1001,%r13d
 100d0e5:	0f 82 40 01 00 00    	jb     100d22b <entry_run+0x1feb>
 100d0eb:	41 bc 00 20 00 00    	mov    $0x2000,%r12d
 100d0f1:	41 81 fd 01 20 00 00 	cmp    $0x2001,%r13d
 100d0f8:	0f 82 2d 01 00 00    	jb     100d22b <entry_run+0x1feb>
 100d0fe:	41 bc 00 40 00 00    	mov    $0x4000,%r12d
 100d104:	41 81 fd 01 40 00 00 	cmp    $0x4001,%r13d
 100d10b:	0f 82 1a 01 00 00    	jb     100d22b <entry_run+0x1feb>
 100d111:	41 bc 00 80 00 00    	mov    $0x8000,%r12d
 100d117:	41 81 fd 01 80 00 00 	cmp    $0x8001,%r13d
 100d11e:	0f 82 07 01 00 00    	jb     100d22b <entry_run+0x1feb>
 100d124:	41 bc 00 00 01 00    	mov    $0x10000,%r12d
 100d12a:	41 81 fd 01 00 01 00 	cmp    $0x10001,%r13d
 100d131:	0f 82 f4 00 00 00    	jb     100d22b <entry_run+0x1feb>
 100d137:	41 bc 00 00 02 00    	mov    $0x20000,%r12d
 100d13d:	41 81 fd 01 00 02 00 	cmp    $0x20001,%r13d
 100d144:	0f 82 e1 00 00 00    	jb     100d22b <entry_run+0x1feb>
 100d14a:	41 bc 00 00 04 00    	mov    $0x40000,%r12d
 100d150:	41 81 fd 01 00 04 00 	cmp    $0x40001,%r13d
 100d157:	0f 82 ce 00 00 00    	jb     100d22b <entry_run+0x1feb>
 100d15d:	41 bc 00 00 08 00    	mov    $0x80000,%r12d
 100d163:	41 81 fd 01 00 08 00 	cmp    $0x80001,%r13d
 100d16a:	0f 82 bb 00 00 00    	jb     100d22b <entry_run+0x1feb>
 100d170:	41 bc 00 00 10 00    	mov    $0x100000,%r12d
 100d176:	41 81 fd 01 00 10 00 	cmp    $0x100001,%r13d
 100d17d:	0f 82 a8 00 00 00    	jb     100d22b <entry_run+0x1feb>
 100d183:	41 bc 00 00 20 00    	mov    $0x200000,%r12d
 100d189:	41 81 fd 01 00 20 00 	cmp    $0x200001,%r13d
 100d190:	0f 82 95 00 00 00    	jb     100d22b <entry_run+0x1feb>
 100d196:	41 bc 00 00 40 00    	mov    $0x400000,%r12d
 100d19c:	41 81 fd 01 00 40 00 	cmp    $0x400001,%r13d
 100d1a3:	0f 82 82 00 00 00    	jb     100d22b <entry_run+0x1feb>
 100d1a9:	41 bc 00 00 80 00    	mov    $0x800000,%r12d
 100d1af:	41 81 fd 01 00 80 00 	cmp    $0x800001,%r13d
 100d1b6:	72 73                	jb     100d22b <entry_run+0x1feb>
 100d1b8:	41 bc 00 00 00 01    	mov    $0x1000000,%r12d
 100d1be:	41 81 fd 01 00 00 01 	cmp    $0x1000001,%r13d
 100d1c5:	72 64                	jb     100d22b <entry_run+0x1feb>
 100d1c7:	41 bc 00 00 00 02    	mov    $0x2000000,%r12d
 100d1cd:	41 81 fd 01 00 00 02 	cmp    $0x2000001,%r13d
 100d1d4:	72 55                	jb     100d22b <entry_run+0x1feb>
 100d1d6:	41 bc 00 00 00 04    	mov    $0x4000000,%r12d
 100d1dc:	41 81 fd 01 00 00 04 	cmp    $0x4000001,%r13d
 100d1e3:	72 46                	jb     100d22b <entry_run+0x1feb>
 100d1e5:	41 bc 00 00 00 08    	mov    $0x8000000,%r12d
 100d1eb:	41 81 fd 01 00 00 08 	cmp    $0x8000001,%r13d
 100d1f2:	72 37                	jb     100d22b <entry_run+0x1feb>
 100d1f4:	41 bc 00 00 00 10    	mov    $0x10000000,%r12d
 100d1fa:	41 81 fd 01 00 00 10 	cmp    $0x10000001,%r13d
 100d201:	72 28                	jb     100d22b <entry_run+0x1feb>
 100d203:	41 bc 00 00 00 20    	mov    $0x20000000,%r12d
 100d209:	41 81 fd 01 00 00 20 	cmp    $0x20000001,%r13d
 100d210:	72 19                	jb     100d22b <entry_run+0x1feb>
 100d212:	45 31 e4             	xor    %r12d,%r12d
 100d215:	41 81 fd 01 00 00 40 	cmp    $0x40000001,%r13d
 100d21c:	41 0f 93 c4          	setae  %r12b
 100d220:	41 c1 e4 1e          	shl    $0x1e,%r12d
 100d224:	49 81 c4 00 00 00 40 	add    $0x40000000,%r12
 100d22b:	4c 89 e7             	mov    %r12,%rdi
 100d22e:	e8 8d 19 01 00       	call   101ebc0 <malloc@plt>
 100d233:	48 85 c0             	test   %rax,%rax
 100d236:	0f 84 89 00 00 00    	je     100d2c5 <entry_run+0x2085>
 100d23c:	45 89 ee             	mov    %r13d,%r14d
 100d23f:	49 89 07             	mov    %rax,(%r15)
 100d242:	4d 89 67 10          	mov    %r12,0x10(%r15)
 100d246:	48 8d 74 24 40       	lea    0x40(%rsp),%rsi
 100d24b:	48 89 84 24 00 02 00 	mov    %rax,0x200(%rsp)
 100d252:	00 
 100d253:	48 89 c7             	mov    %rax,%rdi
 100d256:	4c 89 f2             	mov    %r14,%rdx
 100d259:	e8 82 19 01 00       	call   101ebe0 <memcpy@plt>
 100d25e:	4d 8d 6f 08          	lea    0x8(%r15),%r13
 100d262:	4d 89 77 08          	mov    %r14,0x8(%r15)
 100d266:	4c 89 fb             	mov    %r15,%rbx
 100d269:	48 83 c3 18          	add    $0x18,%rbx
 100d26d:	4d 39 f4             	cmp    %r14,%r12
 100d270:	0f 85 81 00 00 00    	jne    100d2f7 <entry_run+0x20b7>
 100d276:	4d 01 e4             	add    %r12,%r12
 100d279:	48 8b bc 24 00 02 00 	mov    0x200(%rsp),%rdi
 100d280:	00 
 100d281:	eb 13                	jmp    100d296 <entry_run+0x2056>
 100d283:	49 8d 5f 18          	lea    0x18(%r15),%rbx
 100d287:	4d 89 fd             	mov    %r15,%r13
 100d28a:	49 83 c5 08          	add    $0x8,%r13
 100d28e:	41 bc 40 00 00 00    	mov    $0x40,%r12d
 100d294:	31 ff                	xor    %edi,%edi
 100d296:	4c 89 e6             	mov    %r12,%rsi
 100d299:	e8 62 1a 01 00       	call   101ed00 <realloc@plt>
 100d29e:	48 85 c0             	test   %rax,%rax
 100d2a1:	74 33                	je     100d2d6 <entry_run+0x2096>
 100d2a3:	49 89 07             	mov    %rax,(%r15)
 100d2a6:	4d 89 67 10          	mov    %r12,0x10(%r15)
 100d2aa:	4d 8b 77 08          	mov    0x8(%r15),%r14
 100d2ae:	eb 4f                	jmp    100d2ff <entry_run+0x20bf>
 100d2b0:	83 f8 04             	cmp    $0x4,%eax
 100d2b3:	4c 8b 6c 24 18       	mov    0x18(%rsp),%r13
 100d2b8:	0f 83 d3 02 00 00    	jae    100d591 <entry_run+0x2351>
 100d2be:	89 c0                	mov    %eax,%eax
 100d2c0:	e9 eb f7 ff ff       	jmp    100cab0 <entry_run+0x1870>
 100d2c5:	4c 89 fb             	mov    %r15,%rbx
 100d2c8:	48 83 c3 18          	add    $0x18,%rbx
 100d2cc:	41 c7 47 18 01 00 00 	movl   $0x1,0x18(%r15)
 100d2d3:	00 
 100d2d4:	eb 32                	jmp    100d308 <entry_run+0x20c8>
 100d2d6:	c7 03 01 00 00 00    	movl   $0x1,(%rbx)
 100d2dc:	eb 2a                	jmp    100d308 <entry_run+0x20c8>
 100d2de:	31 c0                	xor    %eax,%eax
 100d2e0:	48 8d 4c 24 40       	lea    0x40(%rsp),%rcx
 100d2e5:	49 39 8d 68 02 00 00 	cmp    %rcx,0x268(%r13)
 100d2ec:	0f 85 68 f6 ff ff    	jne    100c95a <entry_run+0x171a>
 100d2f2:	e9 57 f6 ff ff       	jmp    100c94e <entry_run+0x170e>
 100d2f7:	48 8b 84 24 00 02 00 	mov    0x200(%rsp),%rax
 100d2fe:	00 
 100d2ff:	42 c6 04 30 0a       	movb   $0xa,(%rax,%r14,1)
 100d304:	49 ff 45 00          	incq   0x0(%r13)
 100d308:	41 83 7f 1c 00       	cmpl   $0x0,0x1c(%r15)
 100d30d:	4c 8b 6c 24 18       	mov    0x18(%rsp),%r13
 100d312:	74 14                	je     100d328 <entry_run+0x20e8>
 100d314:	be fa 30 00 01       	mov    $0x10030fa,%esi
 100d319:	4c 89 ef             	mov    %r13,%rdi
 100d31c:	e8 3f 0b 00 00       	call   100de60 <fail>
 100d321:	48 8b 5c 24 28       	mov    0x28(%rsp),%rbx
 100d326:	eb 5d                	jmp    100d385 <entry_run+0x2145>
 100d328:	83 3b 00             	cmpl   $0x0,(%rbx)
 100d32b:	74 0f                	je     100d33c <entry_run+0x20fc>
 100d32d:	4c 89 ef             	mov    %r13,%rdi
 100d330:	e8 db 11 00 00       	call   100e510 <myl_qbe_fail_allocation>
 100d335:	48 8b 5c 24 28       	mov    0x28(%rsp),%rbx
 100d33a:	eb 49                	jmp    100d385 <entry_run+0x2145>
 100d33c:	48 8b 05 ed 1e 01 00 	mov    0x11eed(%rip),%rax        # 101f230 <stdout@GLIBC_2.2.5>
 100d343:	4c 8b 30             	mov    (%rax),%r14
 100d346:	4d 8b 67 08          	mov    0x8(%r15),%r12
 100d34a:	4d 85 e4             	test   %r12,%r12
 100d34d:	48 8b 5c 24 28       	mov    0x28(%rsp),%rbx
 100d352:	74 18                	je     100d36c <entry_run+0x212c>
 100d354:	49 8b 3f             	mov    (%r15),%rdi
 100d357:	be 01 00 00 00       	mov    $0x1,%esi
 100d35c:	4c 89 e2             	mov    %r12,%rdx
 100d35f:	4c 89 f1             	mov    %r14,%rcx
 100d362:	e8 29 19 01 00       	call   101ec90 <fwrite@plt>
 100d367:	4c 39 e0             	cmp    %r12,%rax
 100d36a:	75 0c                	jne    100d378 <entry_run+0x2138>
 100d36c:	4c 89 f7             	mov    %r14,%rdi
 100d36f:	e8 ac 19 01 00       	call   101ed20 <fflush@plt>
 100d374:	85 c0                	test   %eax,%eax
 100d376:	74 0d                	je     100d385 <entry_run+0x2145>
 100d378:	be fa 35 00 01       	mov    $0x10035fa,%esi
 100d37d:	4c 89 ef             	mov    %r13,%rdi
 100d380:	e8 db 0a 00 00       	call   100de60 <fail>
 100d385:	49 8b 3f             	mov    (%r15),%rdi
 100d388:	e8 a3 18 01 00       	call   101ec30 <free@plt>
 100d38d:	4c 89 ff             	mov    %r15,%rdi
 100d390:	e8 9b 18 01 00       	call   101ec30 <free@plt>
 100d395:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
 100d39c:	00 00 
 100d39e:	48 8d 84 24 c0 00 00 	lea    0xc0(%rsp),%rax
 100d3a5:	00 
 100d3a6:	49 39 85 80 3d 00 00 	cmp    %rax,0x3d80(%r13)
 100d3ad:	0f 85 d6 01 00 00    	jne    100d589 <entry_run+0x2349>
 100d3b3:	48 8b b4 24 d8 00 00 	mov    0xd8(%rsp),%rsi
 100d3ba:	00 
 100d3bb:	48 89 df             	mov    %rbx,%rdi
 100d3be:	e8 dd 9e 00 00       	call   10172a0 <myl_rc_scope_unwind>
 100d3c3:	48 8b 9c 24 d0 00 00 	mov    0xd0(%rsp),%rbx
 100d3ca:	00 
 100d3cb:	48 85 db             	test   %rbx,%rbx
 100d3ce:	74 3d                	je     100d40d <entry_run+0x21cd>
 100d3d0:	49 89 de             	mov    %rbx,%r14
 100d3d3:	49 c1 e6 05          	shl    $0x5,%r14
 100d3d7:	49 83 c6 e0          	add    $0xffffffffffffffe0,%r14
 100d3db:	eb 17                	jmp    100d3f4 <entry_run+0x21b4>
 100d3dd:	0f 1f 00             	nopl   (%rax)
 100d3e0:	4c 01 f6             	add    %r14,%rsi
 100d3e3:	4c 89 ef             	mov    %r13,%rdi
 100d3e6:	e8 45 02 00 00       	call   100d630 <myl_qbe_rc_slot_drop>
 100d3eb:	49 83 c6 e0          	add    $0xffffffffffffffe0,%r14
 100d3ef:	48 ff cb             	dec    %rbx
 100d3f2:	74 19                	je     100d40d <entry_run+0x21cd>
 100d3f4:	48 8b b4 24 c8 00 00 	mov    0xc8(%rsp),%rsi
 100d3fb:	00 
 100d3fc:	4a 8b 44 36 10       	mov    0x10(%rsi,%r14,1),%rax
 100d401:	48 85 c0             	test   %rax,%rax
 100d404:	74 da                	je     100d3e0 <entry_run+0x21a0>
 100d406:	83 38 00             	cmpl   $0x0,(%rax)
 100d409:	75 d5                	jne    100d3e0 <entry_run+0x21a0>
 100d40b:	eb de                	jmp    100d3eb <entry_run+0x21ab>
 100d40d:	48 8d 84 24 c0 00 00 	lea    0xc0(%rsp),%rax
 100d414:	00 
 100d415:	49 39 85 80 3d 00 00 	cmp    %rax,0x3d80(%r13)
 100d41c:	0f 85 67 01 00 00    	jne    100d589 <entry_run+0x2349>
 100d422:	49 8b 85 60 18 00 00 	mov    0x1860(%r13),%rax
 100d429:	48 85 c0             	test   %rax,%rax
 100d42c:	74 13                	je     100d441 <entry_run+0x2201>
 100d42e:	48 8b 40 70          	mov    0x70(%rax),%rax
 100d432:	48 3b 84 24 d8 00 00 	cmp    0xd8(%rsp),%rax
 100d439:	00 
 100d43a:	74 15                	je     100d451 <entry_run+0x2211>
 100d43c:	e9 48 01 00 00       	jmp    100d589 <entry_run+0x2349>
 100d441:	31 c0                	xor    %eax,%eax
 100d443:	48 3b 84 24 d8 00 00 	cmp    0xd8(%rsp),%rax
 100d44a:	00 
 100d44b:	0f 85 38 01 00 00    	jne    100d589 <entry_run+0x2349>
 100d451:	48 8b 84 24 c0 00 00 	mov    0xc0(%rsp),%rax
 100d458:	00 
 100d459:	49 89 85 80 3d 00 00 	mov    %rax,0x3d80(%r13)
 100d460:	31 c0                	xor    %eax,%eax
 100d462:	48 8d 65 d8          	lea    -0x28(%rbp),%rsp
 100d466:	5b                   	pop    %rbx
 100d467:	41 5c                	pop    %r12
 100d469:	41 5d                	pop    %r13
 100d46b:	41 5e                	pop    %r14
 100d46d:	41 5f                	pop    %r15
 100d46f:	5d                   	pop    %rbp
 100d470:	c3                   	ret
 100d471:	ba 20 00 00 00       	mov    $0x20,%edx
 100d476:	48 8b 34 11          	mov    (%rcx,%rdx,1),%rsi
 100d47a:	48 c7 40 18 50 55 00 	movq   $0x1005550,0x18(%rax)
 100d481:	01 
 100d482:	48 8b 11             	mov    (%rcx),%rdx
 100d485:	48 89 10             	mov    %rdx,(%rax)
 100d488:	48 89 50 08          	mov    %rdx,0x8(%rax)
 100d48c:	48 8b 51 20          	mov    0x20(%rcx),%rdx
 100d490:	48 89 50 20          	mov    %rdx,0x20(%rax)
 100d494:	49 8b 95 60 18 00 00 	mov    0x1860(%r13),%rdx
 100d49b:	48 85 d2             	test   %rdx,%rdx
 100d49e:	74 47                	je     100d4e7 <entry_run+0x22a7>
 100d4a0:	48 85 f6             	test   %rsi,%rsi
 100d4a3:	74 42                	je     100d4e7 <entry_run+0x22a7>
 100d4a5:	48 8b 7e f0          	mov    -0x10(%rsi),%rdi
 100d4a9:	49 b9 00 00 00 00 00 	movabs $0x4000000000000000,%r9
 100d4b0:	00 00 40 
 100d4b3:	49 83 c1 02          	add    $0x2,%r9
 100d4b7:	4c 85 cf             	test   %r9,%rdi
 100d4ba:	75 2b                	jne    100d4e7 <entry_run+0x22a7>
 100d4bc:	40 f6 c7 01          	test   $0x1,%dil
 100d4c0:	0f 85 c3 00 00 00    	jne    100d589 <entry_run+0x2349>
 100d4c6:	48 8b 7e e0          	mov    -0x20(%rsi),%rdi
 100d4ca:	48 83 ff ff          	cmp    $0xffffffffffffffff,%rdi
 100d4ce:	74 3e                	je     100d50e <entry_run+0x22ce>
 100d4d0:	48 85 ff             	test   %rdi,%rdi
 100d4d3:	75 0b                	jne    100d4e0 <entry_run+0x22a0>
 100d4d5:	48 83 7e e8 00       	cmpq   $0x0,-0x18(%rsi)
 100d4da:	0f 84 a9 00 00 00    	je     100d589 <entry_run+0x2349>
 100d4e0:	48 ff c7             	inc    %rdi
 100d4e3:	48 89 7e e0          	mov    %rdi,-0x20(%rsi)
 100d4e7:	48 89 70 38          	mov    %rsi,0x38(%rax)
 100d4eb:	48 89 71 38          	mov    %rsi,0x38(%rcx)
 100d4ef:	48 c7 41 08 00 00 00 	movq   $0x0,0x8(%rcx)
 100d4f6:	00 
 100d4f7:	48 8d 4c 24 40       	lea    0x40(%rsp),%rcx
 100d4fc:	49 39 8d 68 02 00 00 	cmp    %rcx,0x268(%r13)
 100d503:	0f 85 51 f4 ff ff    	jne    100c95a <entry_run+0x171a>
 100d509:	e9 40 f4 ff ff       	jmp    100c94e <entry_run+0x170e>
 100d50e:	4d 89 c8             	mov    %r9,%r8
 100d511:	83 7a 78 00          	cmpl   $0x0,0x78(%rdx)
 100d515:	75 07                	jne    100d51e <entry_run+0x22de>
 100d517:	c7 42 78 02 00 00 00 	movl   $0x2,0x78(%rdx)
 100d51e:	48 8b 48 f0          	mov    -0x10(%rax),%rcx
 100d522:	4c 85 c1             	test   %r8,%rcx
 100d525:	75 41                	jne    100d568 <entry_run+0x2328>
 100d527:	f6 c1 01             	test   $0x1,%cl
 100d52a:	75 5d                	jne    100d589 <entry_run+0x2349>
 100d52c:	48 89 c6             	mov    %rax,%rsi
 100d52f:	48 83 c6 e0          	add    $0xffffffffffffffe0,%rsi
 100d533:	48 8b 3e             	mov    (%rsi),%rdi
 100d536:	48 85 ff             	test   %rdi,%rdi
 100d539:	74 4e                	je     100d589 <entry_run+0x2349>
 100d53b:	48 ff cf             	dec    %rdi
 100d53e:	48 89 3e             	mov    %rdi,(%rsi)
 100d541:	4c 8b 6c 24 18       	mov    0x18(%rsp),%r13
 100d546:	48 8b 5c 24 28       	mov    0x28(%rsp),%rbx
 100d54b:	75 1b                	jne    100d568 <entry_run+0x2328>
 100d54d:	48 83 78 e8 00       	cmpq   $0x0,-0x18(%rax)
 100d552:	75 14                	jne    100d568 <entry_run+0x2328>
 100d554:	48 83 c9 01          	or     $0x1,%rcx
 100d558:	48 89 48 f0          	mov    %rcx,-0x10(%rax)
 100d55c:	48 8b 4a 60          	mov    0x60(%rdx),%rcx
 100d560:	48 89 48 e0          	mov    %rcx,-0x20(%rax)
 100d564:	48 89 72 60          	mov    %rsi,0x60(%rdx)
 100d568:	48 89 df             	mov    %rbx,%rdi
 100d56b:	e8 60 7d 00 00       	call   10152d0 <myl_rc_drain>
 100d570:	31 c0                	xor    %eax,%eax
 100d572:	48 8d 4c 24 40       	lea    0x40(%rsp),%rcx
 100d577:	49 39 8d 68 02 00 00 	cmp    %rcx,0x268(%r13)
 100d57e:	0f 85 d6 f3 ff ff    	jne    100c95a <entry_run+0x171a>
 100d584:	e9 c5 f3 ff ff       	jmp    100c94e <entry_run+0x170e>
 100d589:	c5 f8 77             	vzeroupper
 100d58c:	e8 24 57 00 00       	call   1012cb5 <myl_rc_invariant_failed>
 100d591:	e8 9a 17 01 00       	call   101ed30 <abort@plt>
 100d596:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
 100d59b:	4c 89 fe             	mov    %r15,%rsi
 100d59e:	c5 f8 77             	vzeroupper
 100d5a1:	e8 fa 0f 00 00       	call   100e5a0 <myl_qbe_fail_index_bounds>
 100d5a6:	ba 01 00 00 00       	mov    $0x1,%edx
 100d5ab:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
 100d5b0:	4c 89 e6             	mov    %r12,%rsi
 100d5b3:	c5 f8 77             	vzeroupper
 100d5b6:	e8 45 10 00 00       	call   100e600 <myl_qbe_fail_overflow_op>
 100d5bb:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
 100d5c0:	4c 89 f6             	mov    %r14,%rsi
 100d5c3:	4c 89 ea             	mov    %r13,%rdx
 100d5c6:	c5 f8 77             	vzeroupper
 100d5c9:	e8 32 10 00 00       	call   100e600 <myl_qbe_fail_overflow_op>
 100d5ce:	4c 89 ef             	mov    %r13,%rdi
 100d5d1:	c5 f8 77             	vzeroupper
 100d5d4:	e8 37 0f 00 00       	call   100e510 <myl_qbe_fail_allocation>
 100d5d9:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
 100d5de:	e8 2d 0f 00 00       	call   100e510 <myl_qbe_fail_allocation>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
