.file 1 "myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605"
.text
.balign 16
.globl myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605
myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605:
	endbr64
	pushq %rbp
	movq %rsp, %rbp
	subq $568, %rsp
	pushq %rbx
	pushq %r12
	pushq %r13
	pushq %r14
	pushq %r15
	movq %rsi, -128(%rbp)
	movq $0, -184(%rbp)
	movq $0, -176(%rbp)
	movq $0, -168(%rbp)
	movq $0, -160(%rbp)
	movq $0, -152(%rbp)
	.loc 1 1
	movq %rdi, %rbx
	callq myl_qbe_heap
	movq %rbx, %rdi
	movq %rax, %rbx
	.loc 1 1
	movq %rdi, %r12
	callq myl_qbe_region_mark
	movq %r12, %rdi
	movq %rax, %r15
	movq %r15, -64(%rbp)
	.loc 1 1
	movl $64, %edx
	movl $0, %esi
	movq %rdi, %r12
	leaq -272(%rbp), %rdi
	callq memset
	movq %r12, %rdi
	movq myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527@gotpcrel(%rip), %rax
	movq %rax, -528(%rbp)
	movl $2, -504(%rbp)
	leaq -184(%rbp), %rax
	movq %rax, -520(%rbp)
	leaq -272(%rbp), %rax
	movq %rax, -512(%rbp)
	leaq -528(%rbp), %rax
	movq %rax, %rsi
	addq $32, %rsi
	movq %rsi, -16(%rbp)
	movq myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527@gotpcrel(%rip), %rax
	movq %rax, -496(%rbp)
	movl $2, -472(%rbp)
	leaq -176(%rbp), %rax
	movq %rax, -488(%rbp)
	leaq -272(%rbp), %rax
	addq $8, %rax
	movq %rax, -24(%rbp)
	movq %rax, -480(%rbp)
	leaq -528(%rbp), %rax
	movq %rax, %rsi
	addq $64, %rsi
	movq %rsi, -40(%rbp)
	movq myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7@gotpcrel(%rip), %rax
	movq %rax, -464(%rbp)
	movl $2, -440(%rbp)
	leaq -168(%rbp), %rax
	movq %rax, -456(%rbp)
	leaq -272(%rbp), %rax
	movq %rax, %r14
	addq $16, %r14
	movq %r14, -448(%rbp)
	leaq -528(%rbp), %rax
	movq %rax, %rsi
	addq $96, %rsi
	movq %rsi, -56(%rbp)
	movq myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9@gotpcrel(%rip), %rax
	movq %rax, -432(%rbp)
	movl $2, -408(%rbp)
	leaq -160(%rbp), %rax
	movq %rax, -424(%rbp)
	leaq -272(%rbp), %rax
	movq %rax, %r12
	addq $24, %r12
	movq %r12, -48(%rbp)
	movq %r12, -416(%rbp)
	leaq -528(%rbp), %rax
	movq %rax, %rsi
	addq $128, %rsi
	movq %rsi, -88(%rbp)
	movq myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9@gotpcrel(%rip), %rax
	movq %rax, -400(%rbp)
	movl $2, -376(%rbp)
	leaq -152(%rbp), %rax
	movq %rax, -392(%rbp)
	leaq -272(%rbp), %rax
	movq %rax, %r12
	addq $32, %r12
	movq %r12, -72(%rbp)
	movq %r12, -384(%rbp)
	leaq -528(%rbp), %rax
	movq %rax, %r13
	addq $160, %r13
	movq myl_t_385cfdbc00ec32031699460779c15099b2bba3cad0e440fffb08e10df0acb9e1@gotpcrel(%rip), %rax
	movq %rax, -368(%rbp)
	movl $0, -344(%rbp)
	leaq -208(%rbp), %rax
	movq %rax, -360(%rbp)
	leaq -272(%rbp), %rax
	addq $40, %rax
	movq %rax, -352(%rbp)
	movq myl_t_385cfdbc00ec32031699460779c15099b2bba3cad0e440fffb08e10df0acb9e1@gotpcrel(%rip), %rax
	movq %rax, -336(%rbp)
	movl $0, -312(%rbp)
	leaq -200(%rbp), %rax
	movq %rax, -328(%rbp)
	leaq -272(%rbp), %rax
	addq $48, %rax
	movq %rax, -320(%rbp)
	movq myl_t_385cfdbc00ec32031699460779c15099b2bba3cad0e440fffb08e10df0acb9e1@gotpcrel(%rip), %rax
	movq %rax, -304(%rbp)
	movl $0, -280(%rbp)
	leaq -192(%rbp), %rax
	movq %rax, -296(%rbp)
	leaq -272(%rbp), %rax
	addq $56, %rax
	movq %rax, -288(%rbp)
	.loc 1 1
	movl $8, %ecx
	leaq -528(%rbp), %rdx
	leaq -560(%rbp), %rsi
	movq %rdi, %r12
	callq myl_qbe_rc_frame_enter
	movq %r12, %rdi
	.loc 1 1
	movq %rdi, %r12
	callq myl_qbe_require_step_accounting
	movq %r12, %rdi
	.loc 1 1
	movq %rdi, %r12
	callq myl_qbe_require_frame_accounting
	movq %r12, %rdi
	movq $0, -144(%rbp)
	.loc 1 2
	movl $0, %edx
	movq myl_t_1a91deb3742283487d66c3b500f6effd7ef1170e6d4b4368fe9ec3c3f0354fda@gotpcrel(%rip), %rsi
	movq %rdi, %r12
	movq %rbx, %rdi
	callq myl_native_list_new
	movq %r12, %rdi
	cmpl $0, %eax
	jnz .Lbb2
	.loc 1 2
	movq %rdi, %rbx
	callq myl_qbe_fail_allocation
	ud2
.Lbb2:
	xchgq %rbx, %rdi
	movq %rax, -144(%rbp)
	movq -144(%rbp), %rcx
	movq %rcx, -200(%rbp)
	movq myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527@gotpcrel(%rip), %rcx
	movq %rcx, -336(%rbp)
	movl $2, -312(%rbp)
	movl $1, -224(%rbp)
	movq -200(%rbp), %rcx
	movq %rcx, -208(%rbp)
	movq myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527@gotpcrel(%rip), %rcx
	movq %rcx, -368(%rbp)
	movl $2, -344(%rbp)
	movl $2, -344(%rbp)
	movl $0, -224(%rbp)
	movl $1, -232(%rbp)
	movq %rax, -144(%rbp)
	leaq -200(%rbp), %rdx
	leaq -144(%rbp), %rcx
	subq %rdx, %rcx
	leaq -144(%rbp), %rsi
	leaq -200(%rbp), %rdx
	subq %rsi, %rdx
	cmpq $8, %rcx
	setb %cl
	movzbl %cl, %ecx
	movl %ecx, -80(%rbp)
	cmpq $8, %rdx
	setb %r9b
	movzbl %r9b, %r9d
	movl %r9d, -76(%rbp)
	orl %r9d, %ecx
	jnz .Lbb8
	cmpq $0, %rax
	jz .Lbb6
	subq $16, %rax
	movq (%rax), %rax
	movq $5764607523034234881, %rcx
	andq %rcx, %rax
	cmpq $0, %rax
	jnz .Lbb8
.Lbb6:
	movq -144(%rbp), %rax
	movq %rax, -200(%rbp)
	.loc 1 3
	movl $8, %edx
	movl $0, %esi
	movq %rdi, %r12
	leaq -144(%rbp), %rdi
	callq memset
	movq %r15, %r8
	movq %r12, %rdi
	movl -76(%rbp), %r9d
	movl -80(%rbp), %ecx
	movq %r8, %r15
	jmp .Lbb11
.Lbb8:
	movq %r15, %r8
	.loc 1 3
	movq %r8, %r15
	leaq -144(%rbp), %rcx
	leaq -200(%rbp), %rdx
	movq myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527@gotpcrel(%rip), %rsi
	movq %rdi, %r12
	callq myl_rc_native_take
	movq %r12, %rdi
	movl -76(%rbp), %r9d
	movl -80(%rbp), %ecx
	cmpl $0, %eax
	jnz .Lbb11
	.loc 1 3
	callq myl_rc_take_failure
	movq %rbx, %rdi
	movl %eax, %esi
	.loc 1 3
	movq %rdi, %rbx
	callq myl_qbe_rc_status
	movq %rbx, %rdi
	jmp .Lbb98
.Lbb11:
	movl $0, -232(%rbp)
	movq myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527@gotpcrel(%rip), %rax
	movq %rax, -336(%rbp)
	movl $2, -312(%rbp)
	movl $1, -224(%rbp)
	movl -272(%rbp), %eax
	cmpl $0, %eax
	jnz .Lbb13
	movq %r15, %r8
	jmp .Lbb14
.Lbb13:
	.loc 1 3
	leaq -528(%rbp), %rsi
	movq %rdi, %r12
	movq %rbx, %rdi
	callq myl_qbe_rc_slot_drop
	movq %r15, %r8
	movq %r12, %rdi
	movl -76(%rbp), %r9d
	movl -80(%rbp), %ecx
.Lbb14:
	movq -200(%rbp), %rax
	movq %rax, -184(%rbp)
	movl $0, -224(%rbp)
	movq myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527@gotpcrel(%rip), %rax
	movq %rax, -528(%rbp)
	movl $2, -504(%rbp)
	leaq -184(%rbp), %rax
	movq %rax, -520(%rbp)
	leaq -272(%rbp), %rax
	movq %rax, -512(%rbp)
	movl -312(%rbp), %eax
	movl %eax, -504(%rbp)
	movl $1, -272(%rbp)
	movq -184(%rbp), %rax
	movq %rax, -144(%rbp)
	movl -232(%rbp), %edx
	movl -344(%rbp), %esi
	andl $24, %esi
	cmpl $0, %esi
	setz %sil
	movzbl %sil, %esi
	testl %edx, %esi
	jnz .Lbb20
	.loc 1 6
	movq %r8, %r15
	leaq -144(%rbp), %rcx
	leaq -200(%rbp), %rdx
	movq myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527@gotpcrel(%rip), %rsi
	movq %rdi, %r12
	callq myl_rc_native_retain
	movq %r12, %rdi
	movl %eax, %ecx
	movq -24(%rbp), %rax
	movq -16(%rbp), %rsi
	cmpl $0, %ecx
	jnz .Lbb18
	.loc 1 6
	callq myl_rc_take_failure
	movq %rbx, %rdi
	movl %eax, %esi
	.loc 1 6
	movq %rdi, %rbx
	callq myl_qbe_rc_status
	movq %rbx, %rdi
	jmp .Lbb98
.Lbb18:
	movq myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527@gotpcrel(%rip), %rcx
	movq %rcx, -336(%rbp)
	movl $2, -312(%rbp)
	movl $1, -224(%rbp)
	movl -232(%rbp), %ecx
	cmpl $0, %ecx
	jz .Lbb30
	.loc 1 6
	movq %r13, %rsi
	movq %rdi, %r12
	movq %rbx, %rdi
	callq myl_qbe_rc_slot_drop
	movq %r12, %rdi
	movq -24(%rbp), %rax
	movq -16(%rbp), %rsi
	jmp .Lbb30
.Lbb20:
	movq %r8, %r15
	orl %r9d, %ecx
	jnz .Lbb26
	cmpq $0, %rax
	jz .Lbb24
	subq $16, %rax
	movq (%rax), %rax
	movq $5764607523034234881, %rcx
	andq %rcx, %rax
	cmpq $0, %rax
	jnz .Lbb26
.Lbb24:
	movq -144(%rbp), %rax
	movq %rax, -200(%rbp)
	.loc 1 6
	movl $8, %edx
	movl $0, %esi
	movq %rdi, %r12
	leaq -144(%rbp), %rdi
	callq memset
	movq %r15, %r8
	movq %r12, %rdi
	movq -24(%rbp), %rax
	movq -16(%rbp), %rsi
	movq %r8, %r15
	jmp .Lbb29
.Lbb26:
	movq %r15, %r8
	.loc 1 6
	movq %r8, %r15
	leaq -144(%rbp), %rcx
	leaq -200(%rbp), %rdx
	movq myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527@gotpcrel(%rip), %rsi
	movq %rdi, %r12
	callq myl_rc_native_take
	movq %r12, %rdi
	movl %eax, %ecx
	movq -24(%rbp), %rax
	movq -16(%rbp), %rsi
	cmpl $0, %ecx
	jnz .Lbb29
	.loc 1 6
	callq myl_rc_take_failure
	movq %rbx, %rdi
	movl %eax, %esi
	.loc 1 6
	movq %rdi, %rbx
	callq myl_qbe_rc_status
	movq %rbx, %rdi
	jmp .Lbb98
.Lbb29:
	movl $0, -232(%rbp)
	movq myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527@gotpcrel(%rip), %rcx
	movq %rcx, -336(%rbp)
	movl $2, -312(%rbp)
	movl $1, -224(%rbp)
.Lbb30:
	movl -264(%rbp), %ecx
	cmpl $0, %ecx
	jz .Lbb32
	.loc 1 6
	movq %rdi, %r12
	movq %rbx, %rdi
	callq myl_qbe_rc_slot_drop
	movq %r12, %rdi
	movq -24(%rbp), %rax
.Lbb32:
	movq -200(%rbp), %rcx
	movq %rcx, -176(%rbp)
	movl $0, -224(%rbp)
	movq myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527@gotpcrel(%rip), %rcx
	movq %rcx, -496(%rbp)
	movl $2, -472(%rbp)
	leaq -176(%rbp), %rcx
	movq %rcx, -488(%rbp)
	movq %rax, -480(%rbp)
	movl -312(%rbp), %eax
	movl %eax, -472(%rbp)
	movl $1, -264(%rbp)
	movl -272(%rbp), %eax
	cmpl $0, %eax
	jz .Lbb34
	.loc 1 6
	leaq -528(%rbp), %rsi
	movq %rdi, %r12
	movq %rbx, %rdi
	callq myl_qbe_rc_slot_drop
	movq %r12, %rdi
.Lbb34:
	movq -176(%rbp), %rsi
	movq %rsi, -144(%rbp)
	.loc 1 8
	movq %rdi, %r12
	movq %rbx, %rdi
	callq myl_qbe_bytes_from_list
	movq %r12, %rdi
	movq %rax, -144(%rbp)
	movq -144(%rbp), %rax
	movq %rax, -200(%rbp)
	movq myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7@gotpcrel(%rip), %rax
	movq %rax, -336(%rbp)
	movl $2, -312(%rbp)
	movl $1, -224(%rbp)
	movl -232(%rbp), %eax
	cmpl $0, %eax
	jnz .Lbb36
	movq %r15, %r8
	jmp .Lbb37
.Lbb36:
	.loc 1 8
	movq %r13, %rsi
	movq %rdi, %r12
	movq %rbx, %rdi
	callq myl_qbe_rc_slot_drop
	movq %r15, %r8
	movq %r12, %rdi
.Lbb37:
	movq -200(%rbp), %rax
	movq %rax, -208(%rbp)
	movq myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7@gotpcrel(%rip), %rax
	movq %rax, -368(%rbp)
	movl $2, -344(%rbp)
	movl -312(%rbp), %eax
	movl %eax, -344(%rbp)
	movl $0, -224(%rbp)
	movl $1, -232(%rbp)
	movq -208(%rbp), %rcx
	movq %rcx, -144(%rbp)
	andl $24, %eax
	movl %eax, -32(%rbp)
	cmpl $0, %eax
	setz %al
	movzbl %al, %eax
	imull $4, %eax, %r9d
	.loc 1 9
	movq %r8, %r15
	leaq -144(%rbp), %rcx
	leaq -200(%rbp), %rdx
	movq myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7@gotpcrel(%rip), %rsi
	movq %rdi, %r12
	callq myl_rc_native_publish
	movq %r12, %rdi
	movl %eax, %ecx
	movl -32(%rbp), %eax
	cmpl $0, %ecx
	jnz .Lbb40
	.loc 1 9
	callq myl_rc_take_failure
	movq %rbx, %rdi
	movl %eax, %esi
	.loc 1 9
	movq %rdi, %rbx
	callq myl_qbe_rc_status
	movq %rbx, %rdi
	jmp .Lbb98
.Lbb40:
	cmpl $0, %eax
	jz .Lbb43
	movl -232(%rbp), %eax
	cmpl $0, %eax
	jz .Lbb44
	.loc 1 9
	movq %r13, %rsi
	movq %rdi, %r12
	movq %rbx, %rdi
	callq myl_qbe_rc_slot_drop
	movq %r12, %rdi
	jmp .Lbb44
.Lbb43:
	movl $0, -232(%rbp)
.Lbb44:
	movq myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7@gotpcrel(%rip), %rax
	movq %rax, -336(%rbp)
	movl $2, -312(%rbp)
	movl $1, -224(%rbp)
	movq -200(%rbp), %rax
	movq %rax, -208(%rbp)
	movq myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7@gotpcrel(%rip), %rax
	movq %rax, -368(%rbp)
	movl $2, -344(%rbp)
	movl $2, -344(%rbp)
	movl $0, -224(%rbp)
	movl $1, -232(%rbp)
	movq -208(%rbp), %rax
	movq %rax, -144(%rbp)
	cmpq $0, %rax
	jz .Lbb46
	subq $16, %rax
	movq (%rax), %rax
	movq $5764607523034234881, %rcx
	andq %rcx, %rax
	cmpq $0, %rax
	jnz .Lbb48
.Lbb46:
	movq -144(%rbp), %rax
	movq %rax, -200(%rbp)
	.loc 1 10
	movl $8, %edx
	movl $0, %esi
	movq %rdi, %r12
	leaq -144(%rbp), %rdi
	callq memset
	movq %r15, %r8
	movq %r12, %rdi
	movq -48(%rbp), %r12
	movq -40(%rbp), %rsi
	movq %r8, %r15
	jmp .Lbb52
.Lbb48:
	movq %r15, %r8
	.loc 1 10
	movq %r8, %r15
	leaq -144(%rbp), %rcx
	leaq -200(%rbp), %rdx
	movq myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7@gotpcrel(%rip), %rsi
	movq %rdi, %r12
	callq myl_rc_native_take
	movq %r12, %rdi
	movq -48(%rbp), %r12
	movq -40(%rbp), %rsi
	cmpl $0, %eax
	jnz .Lbb52
	.loc 1 10
	callq myl_rc_take_failure
	movq %rbx, %rdi
	movl %eax, %esi
	.loc 1 10
	movq %rdi, %rbx
	callq myl_qbe_rc_status
	movq %rbx, %rdi
	jmp .Lbb98
.Lbb52:
	movl $0, -232(%rbp)
	movq myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7@gotpcrel(%rip), %rax
	movq %rax, -336(%rbp)
	movl $2, -312(%rbp)
	movl $1, -224(%rbp)
	movl -256(%rbp), %eax
	cmpl $0, %eax
	jnz .Lbb54
	movq %r15, %r8
	jmp .Lbb55
.Lbb54:
	.loc 1 10
	movq %rdi, %r12
	movq %rbx, %rdi
	callq myl_qbe_rc_slot_drop
	movq %r15, %r8
	movq %r12, %rdi
	movq -48(%rbp), %r12
.Lbb55:
	movq -200(%rbp), %rax
	movq %rax, -168(%rbp)
	movl $0, -224(%rbp)
	movq myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7@gotpcrel(%rip), %rax
	movq %rax, -464(%rbp)
	movl $2, -440(%rbp)
	leaq -168(%rbp), %rax
	movq %rax, -456(%rbp)
	movq %r14, -448(%rbp)
	movl -312(%rbp), %eax
	movl %eax, -440(%rbp)
	movl $1, -256(%rbp)
	movq $109, -144(%rbp)
	movq $121, -136(%rbp)
	movq myl_lit_3a31048ef22d5766c70d678fc1c59ca587d84f11b25c84fb64cb1eb13678199d(%rip), %rax
	movq %rax, -144(%rbp)
	movq -144(%rbp), %rcx
	movq %rcx, -200(%rbp)
	movq myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9@gotpcrel(%rip), %rcx
	movq %rcx, -336(%rbp)
	movl $2, -312(%rbp)
	movl $1, -224(%rbp)
	movq -200(%rbp), %rcx
	movq %rcx, -208(%rbp)
	movq myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9@gotpcrel(%rip), %rcx
	movq %rcx, -368(%rbp)
	movl $2, -344(%rbp)
	movl $2, -344(%rbp)
	movl $0, -224(%rbp)
	movl $1, -232(%rbp)
	movq %rax, -144(%rbp)
	cmpq $0, %rax
	jz .Lbb57
	subq $16, %rax
	movq (%rax), %rax
	movq $5764607523034234881, %rcx
	andq %rcx, %rax
	cmpq $0, %rax
	jnz .Lbb59
.Lbb57:
	movq -144(%rbp), %rax
	movq %rax, -200(%rbp)
	.loc 1 76
	movl $8, %edx
	movl $0, %esi
	movq %rdi, %r15
	leaq -144(%rbp), %rdi
	callq memset
	movq %r15, %rdi
	movq -56(%rbp), %rsi
	xchgq %rdi, %rbx
	jmp .Lbb62
.Lbb59:
	.loc 1 76
	movq %r8, %r15
	leaq -144(%rbp), %rcx
	leaq -200(%rbp), %rdx
	movq myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9@gotpcrel(%rip), %rsi
	movq %rdi, %r15
	callq myl_rc_native_take
	movq %r15, %rdi
	movq -56(%rbp), %rsi
	cmpl $0, %eax
	jnz .Lbb61
	.loc 1 76
	callq myl_rc_take_failure
	movq %rbx, %rdi
	movl %eax, %esi
	.loc 1 76
	movq %rdi, %rbx
	callq myl_qbe_rc_status
	movq %rbx, %rdi
	jmp .Lbb98
.Lbb61:
	xchgq %rdi, %rbx
.Lbb62:
	movl $0, -232(%rbp)
	movq myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9@gotpcrel(%rip), %rax
	movq %rax, -336(%rbp)
	movl $2, -312(%rbp)
	movl $1, -224(%rbp)
	movl -248(%rbp), %eax
	cmpl $0, %eax
	jz .Lbb64
	.loc 1 76
	movq %rdi, %r15
	callq myl_qbe_rc_slot_drop
	movq %r15, %rdi
.Lbb64:
	movq -200(%rbp), %rax
	movq %rax, -160(%rbp)
	movl $0, -224(%rbp)
	movq myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9@gotpcrel(%rip), %rax
	movq %rax, -432(%rbp)
	movl $2, -408(%rbp)
	leaq -160(%rbp), %rax
	movq %rax, -424(%rbp)
	movq %r12, -416(%rbp)
	movl -312(%rbp), %eax
	movl %eax, -408(%rbp)
	movl $1, -248(%rbp)
	movq $0, -144(%rbp)
	movq $131072, -144(%rbp)
	movq %rbx, %r12
	movl $0, %ebx
.p2align 4
.Lbb66:
	movq %rbx, -144(%rbp)
	movq $131072, -136(%rbp)
	cmpq $131072, %rbx
	setl %al
	movzbq %al, %rax
	movq %rax, -144(%rbp)
	jge .Lbb76
	movq -160(%rbp), %rax
	movq %rax, -144(%rbp)
	movq $0, -136(%rbp)
	movq myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7@gotpcrel(%rip), %rax
	movq %rax, -464(%rbp)
	movl $2, -440(%rbp)
	leaq -168(%rbp), %rax
	movq %rax, -456(%rbp)
	movq %r14, -448(%rbp)
	.loc 1 88
	movq %r14, %rcx
	leaq -168(%rbp), %rdx
	movq myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7@gotpcrel(%rip), %rsi
	movq %rdi, %r15
	callq myl_qbe_rc_unique_local
	movq %r15, %rdi
	cmpl $0, %eax
	jz .Lbb98
	movq -168(%rbp), %rsi
	movq -144(%rbp), %rdx
	movq -136(%rbp), %rcx
	.loc 1 88
	movl $64, %r8d
	movq %rdi, %r15
	movq %r12, %rdi
	callq myl_native_bytes_buffer_append_range
	movq %r15, %rdi
	movl %eax, %ecx
	cmpq $0, %rcx
	jz .Lbb75
	cmpl $1, %eax
	setz %al
	movzbl %al, %eax
	movl %eax, %eax
	movq %rax, -144(%rbp)
	movl -232(%rbp), %eax
	cmpl $0, %eax
	jz .Lbb71
	.loc 1 88
	movq %r13, %rsi
	movq %rdi, %r15
	callq myl_qbe_rc_slot_drop
	movq %r15, %rdi
.Lbb71:
	movq %rbx, -144(%rbp)
	movq $1, -136(%rbp)
	movq $9223372036854775806, %rax
	cmpq %rax, %rbx
	jg .Lbb73
	addq $1, %rbx
	movq %rbx, -144(%rbp)
	jmp .Lbb66
.Lbb73:
	movq %rbx, %rdx
	.loc 1 92
	movl $64, %r8d
	movl $1, %ecx
	movl $0, %esi
	callq myl_qbe_fail_overflow_op
	ud2
.Lbb75:
	.loc 1 88
	movq %rdi, %rbx
	callq myl_qbe_fail_allocation
	ud2
.Lbb76:
	movq -64(%rbp), %r15
	movq -128(%rbp), %r14
	movq %rdi, %rbx
	movq %r12, %rdi
	movq -168(%rbp), %rsi
	movq %rsi, -144(%rbp)
	.loc 1 96
	movq %rdi, %r12
	movq %rbx, %rdi
	callq myl_qbe_bytes_snapshot
	movq %r12, %rdi
	movl -76(%rbp), %r9d
	movl -80(%rbp), %ecx
	movq -72(%rbp), %r12
	movq -88(%rbp), %rsi
	movq %rax, -144(%rbp)
	movq -144(%rbp), %rax
	movq %rax, -200(%rbp)
	movq myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9@gotpcrel(%rip), %rax
	movq %rax, -336(%rbp)
	movl $2, -312(%rbp)
	movl $1, -224(%rbp)
	movl -232(%rbp), %eax
	cmpl $0, %eax
	jnz .Lbb79
	movq %r15, %r8
	movq %r14, %rdx
	movq %r12, %r14
	jmp .Lbb80
.Lbb79:
	.loc 1 96
	movq %r13, %rsi
	movq %rdi, %r12
	movq %rbx, %rdi
	callq myl_qbe_rc_slot_drop
	movq %r15, %r8
	movq %r14, %rdx
	movq %r12, %rdi
	movl -76(%rbp), %r9d
	movl -80(%rbp), %ecx
	movq -72(%rbp), %r14
	movq -88(%rbp), %rsi
.Lbb80:
	movq -200(%rbp), %rax
	movq %rax, -208(%rbp)
	movq myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9@gotpcrel(%rip), %rax
	movq %rax, -368(%rbp)
	movl $2, -344(%rbp)
	movl -312(%rbp), %r10d
	movl %r10d, -344(%rbp)
	movl $0, -224(%rbp)
	movl $1, -232(%rbp)
	movq -208(%rbp), %rax
	movq %rax, -144(%rbp)
	andl $24, %r10d
	cmpl $0, %r10d
	jz .Lbb88
	.loc 1 97
	leaq -144(%rbp), %rcx
	movq %rdx, %r15
	leaq -200(%rbp), %rdx
	movq myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9@gotpcrel(%rip), %rsi
	movq %rdi, %r12
	callq myl_rc_native_retain
	movq %r12, %rdi
	movq -88(%rbp), %rsi
	cmpl $0, %eax
	jnz .Lbb83
	.loc 1 97
	callq myl_rc_take_failure
	movq %rbx, %rdi
	movl %eax, %esi
	.loc 1 97
	movq %rdi, %rbx
	callq myl_qbe_rc_status
	movq %rbx, %rdi
	jmp .Lbb98
.Lbb83:
	movq %rbx, %rdi
	movq myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9@gotpcrel(%rip), %rax
	movq %rax, -336(%rbp)
	movl $2, -312(%rbp)
	movl $1, -224(%rbp)
	movl -232(%rbp), %eax
	cmpl $0, %eax
	jnz .Lbb86
	movq %r15, %rdx
	jmp .Lbb87
.Lbb86:
	.loc 1 97
	movq %rsi, %r12
	movq %r13, %rsi
	movq %rdi, %rbx
	callq myl_qbe_rc_slot_drop
	movq %r15, %rdx
	movq %r12, %rsi
	movq %rbx, %rdi
.Lbb87:
	movq %r14, %rbx
	movq %rdx, %r12
	jmp .Lbb101
.Lbb88:
	xchgq %rdi, %rbx
	orl %r9d, %ecx
	jnz .Lbb95
	cmpq $0, %rax
	jz .Lbb92
	subq $16, %rax
	movq (%rax), %rax
	movq $5764607523034234881, %rcx
	andq %rcx, %rax
	cmpq $0, %rax
	jnz .Lbb94
.Lbb92:
	movq -144(%rbp), %rax
	movq %rax, -200(%rbp)
	.loc 1 97
	movq %rdx, %r15
	movl $8, %edx
	movq %rsi, %r12
	movl $0, %esi
	movq %rdi, %rbx
	leaq -144(%rbp), %rdi
	callq memset
	movq %r15, %rdx
	movq %r12, %rsi
	movq %rdx, %r12
	movq %rbx, %rdi
	movq %r14, %rbx
	jmp .Lbb100
.Lbb94:
	xchgq %rbx, %rdi
	jmp .Lbb96
.Lbb95:
	xchgq %rbx, %rdi
.Lbb96:
	.loc 1 97
	leaq -144(%rbp), %rcx
	movq %rdx, %r12
	leaq -200(%rbp), %rdx
	movq myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9@gotpcrel(%rip), %rsi
	movq %rdi, %r15
	callq myl_rc_native_take
	movq %r15, %rdi
	movq -88(%rbp), %rsi
	cmpl $0, %eax
	jnz .Lbb99
	.loc 1 97
	callq myl_rc_take_failure
	movq %rbx, %rdi
	movl %eax, %esi
	.loc 1 97
	movq %rdi, %rbx
	callq myl_qbe_rc_status
	movq %rbx, %rdi
.Lbb98:
	.loc 1 149
	leaq -560(%rbp), %rsi
	movq %rdi, %rbx
	callq myl_qbe_rc_frame_cleanup
	movq %rbx, %rdi
	.loc 1 149
	leaq -560(%rbp), %rsi
	callq myl_qbe_rc_frame_leave
	movl $0, %eax
	jmp .Lbb150
.Lbb99:
	movq %rbx, %rdi
	movq %r14, %rbx
.Lbb100:
	movl $0, -232(%rbp)
	movq myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9@gotpcrel(%rip), %rax
	movq %rax, -336(%rbp)
	movl $2, -312(%rbp)
	movl $1, -224(%rbp)
.Lbb101:
	movl -240(%rbp), %eax
	cmpl $0, %eax
	jz .Lbb103
	.loc 1 97
	movq %rdi, %r14
	callq myl_qbe_rc_slot_drop
	movq %r14, %rdi
.Lbb103:
	movq -200(%rbp), %rax
	movq %rax, -152(%rbp)
	movl $0, -224(%rbp)
	movq myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9@gotpcrel(%rip), %rax
	movq %rax, -400(%rbp)
	movl $2, -376(%rbp)
	leaq -152(%rbp), %rax
	movq %rax, -392(%rbp)
	movq %rbx, -384(%rbp)
	movl -312(%rbp), %eax
	movl %eax, -376(%rbp)
	movl $1, -240(%rbp)
	movq -152(%rbp), %rax
	movq %rax, -144(%rbp)
	movq (%rax), %rax
	movq %rax, -144(%rbp)
	movl -232(%rbp), %eax
	cmpl $0, %eax
	jz .Lbb105
	.loc 1 99
	movq %r13, %rsi
	movq %rdi, %rbx
	callq myl_qbe_rc_slot_drop
	movq %rbx, %rdi
.Lbb105:
	movq -144(%rbp), %rbx
	movq $0, -144(%rbp)
	movq $0, -144(%rbp)
	movq $16, -144(%rbp)
	cmpq $0, %rbx
	setg %r8b
	movzbq %r8b, %r8
	movq %r8, -112(%rbp)
	cmpq $16, %rbx
	setae %r10b
	movzbq %r10b, %r10
	movq %r10, -104(%rbp)
	movq $1152921504606846976, %rax
	movq %rbx, %r11
	addq %rax, %r11
	movq %r11, -96(%rbp)
	movq %r12, %rsi
	movl $0, %r12d
	movl $0, %r9d
.p2align 4
.Lbb107:
	movq %r9, -120(%rbp)
	movq %r9, -144(%rbp)
	movq $16, -136(%rbp)
	cmpq $16, %r9
	setl %al
	movzbq %al, %rax
	movq %rax, -144(%rbp)
	jge .Lbb148
	movq %r12, -144(%rbp)
	movq %r9, -136(%rbp)
	movq %r12, %r14
	addq %r9, %r12
	movq %r14, %rax
	xorq %r12, %rax
	movq %r9, %rcx
	xorq %r12, %rcx
	andq %rcx, %rax
	cmpq $0, %rax
	jl .Lbb146
	movq %r12, -144(%rbp)
	movq $0, -144(%rbp)
	movq %rbx, -144(%rbp)
	movl -240(%rbp), %eax
	movl -376(%rbp), %ecx
	cmpl $2, %ecx
	setz %cl
	movzbl %cl, %ecx
	testl %eax, %ecx
	jnz .Lbb111
	movl $0, %r14d
	jmp .Lbb121
.Lbb111:
	movl -232(%rbp), %eax
	cmpl $0, %eax
	jz .Lbb113
	movl $0, %r14d
	jmp .Lbb121
.Lbb113:
	testq %r8, %r10
	jnz .Lbb115
	movl $0, %r14d
	jmp .Lbb121
.Lbb115:
	movq $2305843009213693952, %rax
	cmpq %rax, %r11
	jbe .Lbb117
	movl $0, %r14d
	jmp .Lbb121
.Lbb117:
	movq $1152921504606846976, %rax
	movq %r12, %rcx
	addq %rax, %rcx
	movq $2305843009213693952, %rax
	cmpq %rax, %rcx
	jbe .Lbb119
	movl $0, %r14d
	jmp .Lbb121
.Lbb119:
	movq -152(%rbp), %rax
	movq (%rax), %rcx
	cmpq %rcx, %rbx
	jle .Lbb136
	movl $0, %r14d
.p2align 4
.Lbb121:
	movq %r14, -144(%rbp)
	movq %rbx, -136(%rbp)
	cmpq %rbx, %r14
	setl %al
	movzbq %al, %rax
	movq %rax, -144(%rbp)
	jge .Lbb135
	movq -152(%rbp), %rax
	movq %rax, -144(%rbp)
	movq %r14, -136(%rbp)
	movq (%rax), %rdx
	movq %r14, %rcx
	sarq $63, %rcx
	andq %rdx, %rcx
	addq %r14, %rcx
	cmpq %rdx, %rcx
	jae .Lbb133
	movq 32(%rax), %rax
	movzbq (%rax, %rcx, 1), %rax
	movq %rax, -144(%rbp)
	movl -232(%rbp), %eax
	cmpl $0, %eax
	jz .Lbb125
	.loc 1 125
	movq %r13, %rsi
	movq %rdi, %r15
	callq myl_qbe_rc_slot_drop
	movq %r15, %rdi
.Lbb125:
	movq -144(%rbp), %rax
	movq %rax, -144(%rbp)
	movq $109, -136(%rbp)
	cmpq $109, %rax
	setz %al
	movzbq %al, %rax
	movq %rax, -144(%rbp)
	jnz .Lbb128
	movq %r12, -144(%rbp)
	movq $1, -136(%rbp)
	movq $9223372036854775806, %rax
	cmpq %rax, %r12
	jg .Lbb132
	addq $1, %r12
	movq %r12, -144(%rbp)
.Lbb128:
	movq %r14, -144(%rbp)
	movq $1, -136(%rbp)
	movq $9223372036854775806, %rax
	cmpq %rax, %r14
	jg .Lbb130
	addq $1, %r14
	movq %r14, -144(%rbp)
	jmp .Lbb121
.Lbb130:
	movq %r14, %rsi
	.loc 1 136
	movl $64, %r8d
	movl $1, %ecx
	movq %rsi, %rdx
	movl $0, %esi
	callq myl_qbe_fail_overflow_op
	ud2
.Lbb132:
	.loc 1 132
	movl $64, %r8d
	movl $1, %ecx
	movq %r12, %rdx
	movl $0, %esi
	callq myl_qbe_fail_overflow_op
	ud2
.Lbb133:
	movq %r14, %rsi
	.loc 1 125
	callq myl_qbe_fail_index_bounds
	ud2
.Lbb135:
	movq -120(%rbp), %r9
	movq -96(%rbp), %r11
	movq -104(%rbp), %r10
	movq -112(%rbp), %r8
	jmp .Lbb141
.Lbb136:
	movq 32(%rax), %rdx
	movl $0, %ecx
.p2align 4
.Lbb138:
	cmpq %rbx, %rcx
	jge .Lbb141
	movzbq (%rdx, %rcx, 1), %r14
	cmpq $109, %r14
	setz %r15b
	movzbq %r15b, %r15
	movq %r12, %r14
	addq $1, %r14
	cmpl $0, %r15d
	cmovnz %r14, %r12
	addq $1, %rcx
	jmp .Lbb138
.Lbb141:
	movq %r9, -144(%rbp)
	movq $1, -136(%rbp)
	movq $9223372036854775806, %rax
	cmpq %rax, %r9
	jg .Lbb144
	addq $1, %r9
	movq %r9, -144(%rbp)
	movq -128(%rbp), %rsi
	jmp .Lbb107
.Lbb144:
	movq %r9, %rcx
	.loc 1 141
	movl $64, %r8d
	movq %rcx, %rax
	movl $1, %ecx
	movq %rax, %rdx
	movl $0, %esi
	callq myl_qbe_fail_overflow_op
	ud2
.Lbb146:
	movq %r14, %rbx
	movq %r9, %rcx
	.loc 1 113
	movl $64, %r8d
	movq %rbx, %rdx
	movl $0, %esi
	callq myl_qbe_fail_overflow_op
	ud2
.Lbb148:
	movq %r12, %rbx
	movq %rsi, %r12
	movq %r12, -144(%rbp)
	movq %rbx, -136(%rbp)
	.loc 1 146
	movq %r12, %rsi
	movq %rdi, %rbx
	callq myl_qbe_stream_begin
	movq %r12, %rdx
	movq %rbx, %rdi
	movq %rax, %rsi
	.loc 1 146
	movq %rdx, %r13
	movl $0, %edx
	movq %rsi, %r12
	leaq -136(%rbp), %rsi
	movq %rdi, %rbx
	movq %r12, %rdi
	callq myl_r_1a91deb3742283487d66c3b500f6effd7ef1170e6d4b4368fe9ec3c3f0354fda
	movq %r12, %rsi
	movq %rbx, %rdi
	.loc 1 146
	movq %rsi, %r12
	movl $10, %esi
	movq %rdi, %rbx
	movq %r12, %rdi
	callq myl_qbe_print_byte
	movq %r13, %rdx
	movq %r12, %rsi
	movq %rbx, %rdi
	.loc 1 146
	movq %rdi, %rbx
	callq myl_qbe_stream_finish
	movq %rbx, %rdi
	movq $0, -144(%rbp)
	movq $0, -144(%rbp)
	.loc 1 149
	leaq -560(%rbp), %rsi
	movq %rdi, %rbx
	callq myl_qbe_rc_frame_cleanup
	movq %rbx, %rdi
	.loc 1 149
	leaq -560(%rbp), %rsi
	callq myl_qbe_rc_frame_leave
	movl $0, %eax
.Lbb150:
	popq %r15
	popq %r14
	popq %r13
	popq %r12
	popq %rbx
	leave
	ret
.type myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605, @function
.size myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605, .-myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605
/* end function myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605 */

.section .note.GNU-stack,"",@progbits
