
/home/epentland/ai/canopy/mylang-worktrees/goal110-equality-bounded-20261004/.mylang-cache/goal110-floor-range-ir/floor-range.so:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .text:

00000000000035d0 <loop_seeded_bool_select_assume_d1000000007>:
    35d0:	mov    %rdx,%rax
    35d3:	movl   $0x0,(%rcx)
    35d9:	test   %rsi,%rsi
    35dc:	je     363d <loop_seeded_bool_select_assume_d1000000007+0x6d>
    35de:	movabs $0x89705f3112a28fe5,%r9
    35e8:	nopl   0x0(%rax,%rax,1)
    35f0:	xor    %r8d,%r8d
    35f3:	cmpb   $0x0,(%rdi)
    35f6:	setne  %r8b
    35fa:	add    %rax,%r8
    35fd:	jo     363e <loop_seeded_bool_select_assume_d1000000007+0x6e>
    35ff:	mov    %r8,%rax
    3602:	imul   %r9
    3605:	add    %r8,%rdx
    3608:	mov    %rdx,%rax
    360b:	shr    $0x3f,%rax
    360f:	sar    $0x1d,%rdx
    3613:	add    %rax,%rdx
    3616:	imul   $0x3b9aca07,%rdx,%rax
    361d:	mov    %r8,%rdx
    3620:	sub    %rax,%rdx
    3623:	neg    %rax
    3626:	test   %rdx,%rdx
    3629:	lea    0x3b9aca07(%r8,%rax,1),%rax
    3631:	cmovns %rdx,%rax
    3635:	inc    %rdi
    3638:	dec    %rsi
    363b:	jne    35f0 <loop_seeded_bool_select_assume_d1000000007+0x20>
    363d:	ret
    363e:	movl   $0x1,(%rcx)
    3644:	xor    %eax,%eax
    3646:	ret
