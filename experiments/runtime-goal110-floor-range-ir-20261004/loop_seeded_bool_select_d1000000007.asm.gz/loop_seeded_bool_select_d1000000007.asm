
/home/epentland/ai/canopy/mylang-worktrees/goal110-equality-bounded-20261004/.mylang-cache/goal110-floor-range-ir/floor-range.so:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .text:

0000000000003550 <loop_seeded_bool_select_d1000000007>:
    3550:	mov    %rdx,%rax
    3553:	movl   $0x0,(%rcx)
    3559:	test   %rsi,%rsi
    355c:	je     35bd <loop_seeded_bool_select_d1000000007+0x6d>
    355e:	movabs $0x89705f3112a28fe5,%r9
    3568:	nopl   0x0(%rax,%rax,1)
    3570:	xor    %r8d,%r8d
    3573:	cmpb   $0x0,(%rdi)
    3576:	setne  %r8b
    357a:	add    %rax,%r8
    357d:	jo     35be <loop_seeded_bool_select_d1000000007+0x6e>
    357f:	mov    %r8,%rax
    3582:	imul   %r9
    3585:	add    %r8,%rdx
    3588:	mov    %rdx,%rax
    358b:	shr    $0x3f,%rax
    358f:	sar    $0x1d,%rdx
    3593:	add    %rax,%rdx
    3596:	imul   $0x3b9aca07,%rdx,%rax
    359d:	mov    %r8,%rdx
    35a0:	sub    %rax,%rdx
    35a3:	neg    %rax
    35a6:	test   %rdx,%rdx
    35a9:	lea    0x3b9aca07(%r8,%rax,1),%rax
    35b1:	cmovns %rdx,%rax
    35b5:	inc    %rdi
    35b8:	dec    %rsi
    35bb:	jne    3570 <loop_seeded_bool_select_d1000000007+0x20>
    35bd:	ret
    35be:	movl   $0x1,(%rcx)
    35c4:	xor    %eax,%eax
    35c6:	ret
