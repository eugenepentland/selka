
/home/epentland/ai/canopy/mylang-worktrees/goal110-equality-bounded-20261004/.mylang-cache/goal110-floor-range-ir/floor-range.so:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .text:

00000000000024f0 <scalar_baseline_d9223372036854775807>:
    24f0:	movabs $0x4000000000000001,%rcx
    24fa:	mov    %rdi,%rax
    24fd:	imul   %rcx
    2500:	mov    %rdx,%rcx
    2503:	shr    $0x3f,%rcx
    2507:	sar    $0x3d,%rdx
    250b:	add    %rdx,%rcx
    250e:	lea    (%rdi,%rcx,1),%rax
    2512:	shl    $0x3f,%rcx
    2516:	add    %rax,%rcx
    2519:	mov    %rcx,%rdx
    251c:	sar    $0x3f,%rdx
    2520:	movabs $0x7fffffffffffffff,%rax
    252a:	and    %rdx,%rax
    252d:	add    %rcx,%rax
    2530:	ret
