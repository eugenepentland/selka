
/home/epentland/ai/canopy/mylang-worktrees/goal110-equality-bounded-20261004/.mylang-cache/goal110-floor-range-ir/floor-range.so:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .text:

00000000000024a0 <scalar_select_assume_d1000000007>:
    24a0:	movabs $0x89705f3112a28fe5,%rcx
    24aa:	mov    %rdi,%rax
    24ad:	imul   %rcx
    24b0:	add    %rdi,%rdx
    24b3:	mov    %rdx,%rax
    24b6:	shr    $0x3f,%rax
    24ba:	sar    $0x1d,%rdx
    24be:	add    %rax,%rdx
    24c1:	imul   $0x3b9aca07,%rdx,%rax
    24c8:	mov    %rdi,%rcx
    24cb:	sub    %rax,%rcx
    24ce:	neg    %rax
    24d1:	test   %rcx,%rcx
    24d4:	lea    0x3b9aca07(%rdi,%rax,1),%rax
    24dc:	cmovns %rcx,%rax
    24e0:	ret
