define i64 @loop_seeded_bool_select_assume_d3(ptr readonly captures(none) %data, i64 %count, i64 %seed, ptr writeonly captures(none) initializes((0, 4)) %status) local_unnamed_addr #5 {
entry:
  store i32 0, ptr %status, align 4
  %empty = icmp eq i64 %count, 0
  br i1 %empty, label %common.ret, label %loop

common.ret:                                       ; preds = %success, %entry, %failure
  %common.ret.op = phi i64 [ %seed, %entry ], [ 0, %failure ], [ %result, %success ]
  ret i64 %common.ret.op

loop:                                             ; preds = %entry, %success
  %index = phi i64 [ %next, %success ], [ 0, %entry ]
  %checksum = phi i64 [ %result, %success ], [ %seed, %entry ]
  %address = getelementptr i8, ptr %data, i64 %index
  %flag = load i8, ptr %address, align 1
  %truth = icmp ne i8 %flag, 0
  %increment = zext i1 %truth to i64
  %addition = tail call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %checksum, i64 %increment)
  %overflow = extractvalue { i64, i1 } %addition, 1
  br i1 %overflow, label %failure, label %success

failure:                                          ; preds = %loop
  store i32 1, ptr %status, align 4
  br label %common.ret

success:                                          ; preds = %loop
  %sum = extractvalue { i64, i1 } %addition, 0
  %rem = srem i64 %sum, 3
  %negative = icmp slt i64 %rem, 0
  %shifted = add nsw i64 %rem, 3
  %result = select i1 %negative, i64 %shifted, i64 %rem
  %bounded = icmp ult i64 %result, 3
  tail call void @llvm.assume(i1 %bounded)
  %next = add nuw i64 %index, 1
  %done = icmp eq i64 %next, %count
  br i1 %done, label %common.ret, label %loop
}
