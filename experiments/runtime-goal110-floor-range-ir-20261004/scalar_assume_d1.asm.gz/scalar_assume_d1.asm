
/home/epentland/ai/canopy/mylang-worktrees/goal110-equality-bounded-20261004/.mylang-cache/goal110-floor-range-ir/floor-range.so:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .text:

0000000000002280 <scalar_assume_d1>:
    2280:	xor    %eax,%eax
    2282:	ret
