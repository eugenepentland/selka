
/home/epentland/ai/canopy/mylang-worktrees/goal110-equality-bounded-20261004/.mylang-cache/goal110-floor-range-ir/floor-range.so:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .text:

0000000000002d50 <loop_signed_updates_select_d3>:
    2d50:	movl   $0x0,(%rcx)
    2d56:	xor    %r8d,%r8d
    2d59:	test   %rsi,%rsi
    2d5c:	je     2da7 <loop_signed_updates_select_d3+0x57>
    2d5e:	movabs $0x5555555555555556,%r9
    2d68:	nopl   0x0(%rax,%rax,1)
    2d70:	add    (%rdi),%r8
    2d73:	jo     2dab <loop_signed_updates_select_d3+0x5b>
    2d75:	mov    %r8,%rax
    2d78:	imul   %r9
    2d7b:	mov    %rdx,%rax
    2d7e:	shr    $0x3f,%rax
    2d82:	add    %rdx,%rax
    2d85:	lea    (%rax,%rax,2),%rax
    2d89:	mov    %r8,%rdx
    2d8c:	sub    %rax,%rdx
    2d8f:	neg    %rax
    2d92:	test   %rdx,%rdx
    2d95:	lea    0x3(%r8,%rax,1),%r8
    2d9a:	cmovns %rdx,%r8
    2d9e:	add    $0x8,%rdi
    2da2:	dec    %rsi
    2da5:	jne    2d70 <loop_signed_updates_select_d3+0x20>
    2da7:	mov    %r8,%rax
    2daa:	ret
    2dab:	movl   $0x1,(%rcx)
    2db1:	xor    %r8d,%r8d
    2db4:	mov    %r8,%rax
    2db7:	ret
