
/home/epentland/ai/canopy/mylang-worktrees/goal110-equality-bounded-20261004/.mylang-cache/goal110-floor-range-ir/floor-range.so:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .text:

0000000000002b40 <loop_seeded_bool_assume_d3>:
    2b40:	mov    %rdx,%rax
    2b43:	movl   $0x0,(%rcx)
    2b49:	test   %rsi,%rsi
    2b4c:	je     2b9b <loop_seeded_bool_assume_d3+0x5b>
    2b4e:	movabs $0x5555555555555556,%r9
    2b58:	nopl   0x0(%rax,%rax,1)
    2b60:	xor    %r8d,%r8d
    2b63:	cmpb   $0x0,(%rdi)
    2b66:	setne  %r8b
    2b6a:	add    %rax,%r8
    2b6d:	jo     2b9c <loop_seeded_bool_assume_d3+0x5c>
    2b6f:	mov    %r8,%rax
    2b72:	imul   %r9
    2b75:	mov    %rdx,%rax
    2b78:	shr    $0x3f,%rax
    2b7c:	add    %rdx,%rax
    2b7f:	lea    (%rax,%rax,2),%rax
    2b83:	sub    %rax,%r8
    2b86:	mov    %r8,%rax
    2b89:	sar    $0x3f,%rax
    2b8d:	and    $0x3,%eax
    2b90:	add    %r8,%rax
    2b93:	inc    %rdi
    2b96:	dec    %rsi
    2b99:	jne    2b60 <loop_seeded_bool_assume_d3+0x20>
    2b9b:	ret
    2b9c:	movl   $0x1,(%rcx)
    2ba2:	xor    %eax,%eax
    2ba4:	ret
