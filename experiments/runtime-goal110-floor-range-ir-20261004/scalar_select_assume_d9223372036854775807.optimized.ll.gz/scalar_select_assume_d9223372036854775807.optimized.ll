define range(i64 0, 9223372036854775807) i64 @scalar_select_assume_d9223372036854775807(i64 %value) local_unnamed_addr #3 {
entry:
  %rem = srem i64 %value, 9223372036854775807
  %negative = icmp slt i64 %rem, 0
  %shifted = add i64 %rem, 9223372036854775807
  %result = select i1 %negative, i64 %shifted, i64 %rem
  %bounded = icmp ult i64 %result, 9223372036854775807
  tail call void @llvm.assume(i1 %bounded)
  ret i64 %result
}
