define range(i64 -2, 6) i64 @scalar_baseline_d3(i64 %value) local_unnamed_addr #2 {
entry:
  %rem = srem i64 %value, 3
  %isneg = icmp slt i64 %rem, 0
  %delta = select i1 %isneg, i64 3, i64 0
  %result = add nsw i64 %delta, %rem
  ret i64 %result
}
