
/home/epentland/ai/canopy/mylang-worktrees/goal110-equality-bounded-20261004/.mylang-cache/goal110-floor-range-ir/floor-range.so:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .text:

00000000000022a0 <scalar_select_assume_d1>:
    22a0:	xor    %eax,%eax
    22a2:	ret
