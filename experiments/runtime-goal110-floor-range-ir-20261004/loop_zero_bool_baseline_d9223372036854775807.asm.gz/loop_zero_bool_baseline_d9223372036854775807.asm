
/home/epentland/ai/canopy/mylang-worktrees/goal110-equality-bounded-20261004/.mylang-cache/goal110-floor-range-ir/floor-range.so:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .text:

0000000000003830 <loop_zero_bool_baseline_d9223372036854775807>:
    3830:	movl   $0x0,(%rcx)
    3836:	xor    %eax,%eax
    3838:	test   %rsi,%rsi
    383b:	je     38a5 <loop_zero_bool_baseline_d9223372036854775807+0x75>
    383d:	movabs $0x4000000000000001,%r9
    3847:	movabs $0x7fffffffffffffff,%r10
    3851:	cs nopw 0x0(%rax,%rax,1)
    385b:	nopl   0x0(%rax,%rax,1)
    3860:	xor    %r8d,%r8d
    3863:	cmpb   $0x0,(%rdi)
    3866:	setne  %r8b
    386a:	add    %rax,%r8
    386d:	jo     38a6 <loop_zero_bool_baseline_d9223372036854775807+0x76>
    386f:	mov    %r8,%rax
    3872:	imul   %r9
    3875:	mov    %rdx,%rax
    3878:	shr    $0x3f,%rax
    387c:	sar    $0x3d,%rdx
    3880:	add    %rax,%rdx
    3883:	mov    %rdx,%r11
    3886:	shl    $0x3f,%r11
    388a:	add    %rdx,%r11
    388d:	add    %r8,%r11
    3890:	mov    %r11,%rax
    3893:	sar    $0x3f,%rax
    3897:	and    %r10,%rax
    389a:	add    %r11,%rax
    389d:	inc    %rdi
    38a0:	dec    %rsi
    38a3:	jne    3860 <loop_zero_bool_baseline_d9223372036854775807+0x30>
    38a5:	ret
    38a6:	movl   $0x1,(%rcx)
    38ac:	xor    %eax,%eax
    38ae:	ret
