
/home/epentland/ai/canopy/mylang-worktrees/goal110-equality-bounded-20261004/.mylang-cache/goal110-floor-range-ir/floor-range.so:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .text:

0000000000003730 <loop_signed_updates_select_d1000000007>:
    3730:	movl   $0x0,(%rcx)
    3736:	xor    %r8d,%r8d
    3739:	test   %rsi,%rsi
    373c:	je     3794 <loop_signed_updates_select_d1000000007+0x64>
    373e:	movabs $0x89705f3112a28fe5,%r9
    3748:	nopl   0x0(%rax,%rax,1)
    3750:	add    (%rdi),%r8
    3753:	jo     3798 <loop_signed_updates_select_d1000000007+0x68>
    3755:	mov    %r8,%rax
    3758:	imul   %r9
    375b:	add    %r8,%rdx
    375e:	mov    %rdx,%rax
    3761:	shr    $0x3f,%rax
    3765:	sar    $0x1d,%rdx
    3769:	add    %rax,%rdx
    376c:	imul   $0x3b9aca07,%rdx,%rax
    3773:	mov    %r8,%rdx
    3776:	sub    %rax,%rdx
    3779:	neg    %rax
    377c:	test   %rdx,%rdx
    377f:	lea    0x3b9aca07(%r8,%rax,1),%r8
    3787:	cmovns %rdx,%r8
    378b:	add    $0x8,%rdi
    378f:	dec    %rsi
    3792:	jne    3750 <loop_signed_updates_select_d1000000007+0x20>
    3794:	mov    %r8,%rax
    3797:	ret
    3798:	movl   $0x1,(%rcx)
    379e:	xor    %r8d,%r8d
    37a1:	mov    %r8,%rax
    37a4:	ret
