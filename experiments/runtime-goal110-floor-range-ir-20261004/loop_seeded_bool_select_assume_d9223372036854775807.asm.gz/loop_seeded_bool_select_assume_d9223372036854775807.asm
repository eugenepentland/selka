
/home/epentland/ai/canopy/mylang-worktrees/goal110-equality-bounded-20261004/.mylang-cache/goal110-floor-range-ir/floor-range.so:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .text:

0000000000003bb0 <loop_seeded_bool_select_assume_d9223372036854775807>:
    3bb0:	mov    %rdx,%rax
    3bb3:	movl   $0x0,(%rcx)
    3bb9:	test   %rsi,%rsi
    3bbc:	je     3c23 <loop_seeded_bool_select_assume_d9223372036854775807+0x73>
    3bbe:	movabs $0x7fffffffffffffff,%r9
    3bc8:	movabs $0x4000000000000001,%r10
    3bd2:	cs nopw 0x0(%rax,%rax,1)
    3bdc:	nopl   0x0(%rax)
    3be0:	xor    %r8d,%r8d
    3be3:	cmpb   $0x0,(%rdi)
    3be6:	setne  %r8b
    3bea:	add    %rax,%r8
    3bed:	jo     3c24 <loop_seeded_bool_select_assume_d9223372036854775807+0x74>
    3bef:	mov    %r8,%rax
    3bf2:	imul   %r10
    3bf5:	mov    %rdx,%rax
    3bf8:	shr    $0x3f,%rax
    3bfc:	sar    $0x3d,%rdx
    3c00:	add    %rax,%rdx
    3c03:	mov    %rdx,%r11
    3c06:	shl    $0x3f,%r11
    3c0a:	add    %rdx,%r11
    3c0d:	add    %r8,%r11
    3c10:	lea    (%r11,%r9,1),%rax
    3c14:	test   %r11,%r11
    3c17:	cmovns %r11,%rax
    3c1b:	inc    %rdi
    3c1e:	dec    %rsi
    3c21:	jne    3be0 <loop_seeded_bool_select_assume_d9223372036854775807+0x30>
    3c23:	ret
    3c24:	movl   $0x1,(%rcx)
    3c2a:	xor    %eax,%eax
    3c2c:	ret
