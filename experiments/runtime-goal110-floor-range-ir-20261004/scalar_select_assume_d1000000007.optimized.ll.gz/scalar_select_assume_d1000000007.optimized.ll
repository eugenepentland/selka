define range(i64 0, 1000000007) i64 @scalar_select_assume_d1000000007(i64 %value) local_unnamed_addr #3 {
entry:
  %rem = srem i64 %value, 1000000007
  %negative = icmp slt i64 %rem, 0
  %shifted = add nsw i64 %rem, 1000000007
  %result = select i1 %negative, i64 %shifted, i64 %rem
  %bounded = icmp ult i64 %result, 1000000007
  tail call void @llvm.assume(i1 %bounded)
  ret i64 %result
}
