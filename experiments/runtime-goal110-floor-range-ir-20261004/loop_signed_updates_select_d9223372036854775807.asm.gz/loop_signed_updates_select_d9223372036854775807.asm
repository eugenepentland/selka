
/home/epentland/ai/canopy/mylang-worktrees/goal110-equality-bounded-20261004/.mylang-cache/goal110-floor-range-ir/floor-range.so:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .text:

0000000000003d30 <loop_signed_updates_select_d9223372036854775807>:
    3d30:	movl   $0x0,(%rcx)
    3d36:	xor    %r8d,%r8d
    3d39:	test   %rsi,%rsi
    3d3c:	je     3d97 <loop_signed_updates_select_d9223372036854775807+0x67>
    3d3e:	movabs $0x4000000000000001,%r9
    3d48:	movabs $0x7fffffffffffffff,%r10
    3d52:	cs nopw 0x0(%rax,%rax,1)
    3d5c:	nopl   0x0(%rax)
    3d60:	add    (%rdi),%r8
    3d63:	jo     3d9b <loop_signed_updates_select_d9223372036854775807+0x6b>
    3d65:	mov    %r8,%rax
    3d68:	imul   %r9
    3d6b:	mov    %rdx,%rax
    3d6e:	shr    $0x3f,%rax
    3d72:	sar    $0x3d,%rdx
    3d76:	add    %rax,%rdx
    3d79:	add    %rdx,%r8
    3d7c:	shl    $0x3f,%rdx
    3d80:	add    %r8,%rdx
    3d83:	lea    (%rdx,%r10,1),%r8
    3d87:	test   %rdx,%rdx
    3d8a:	cmovns %rdx,%r8
    3d8e:	add    $0x8,%rdi
    3d92:	dec    %rsi
    3d95:	jne    3d60 <loop_signed_updates_select_d9223372036854775807+0x30>
    3d97:	mov    %r8,%rax
    3d9a:	ret
    3d9b:	movl   $0x1,(%rcx)
    3da1:	xor    %r8d,%r8d
    3da4:	mov    %r8,%rax
    3da7:	ret
