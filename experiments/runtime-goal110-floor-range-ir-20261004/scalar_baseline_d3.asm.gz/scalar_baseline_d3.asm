
/home/epentland/ai/canopy/mylang-worktrees/goal110-equality-bounded-20261004/.mylang-cache/goal110-floor-range-ir/floor-range.so:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .text:

00000000000022f0 <scalar_baseline_d3>:
    22f0:	movabs $0x5555555555555556,%rcx
    22fa:	mov    %rdi,%rax
    22fd:	imul   %rcx
    2300:	mov    %rdx,%rax
    2303:	shr    $0x3f,%rax
    2307:	add    %rdx,%rax
    230a:	lea    (%rax,%rax,2),%rax
    230e:	sub    %rax,%rdi
    2311:	mov    %rdi,%rax
    2314:	sar    $0x3f,%rax
    2318:	and    $0x3,%eax
    231b:	add    %rdi,%rax
    231e:	ret
