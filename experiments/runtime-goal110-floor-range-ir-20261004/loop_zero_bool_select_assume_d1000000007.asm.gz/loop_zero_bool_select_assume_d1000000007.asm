
/home/epentland/ai/canopy/mylang-worktrees/goal110-equality-bounded-20261004/.mylang-cache/goal110-floor-range-ir/floor-range.so:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .text:

0000000000003310 <loop_zero_bool_select_assume_d1000000007>:
    3310:	movl   $0x0,(%rcx)
    3316:	test   %rsi,%rsi
    3319:	je     3343 <loop_zero_bool_select_assume_d1000000007+0x33>
    331b:	push   %rbp
    331c:	push   %r15
    331e:	push   %r14
    3320:	push   %r12
    3322:	push   %rbx
    3323:	mov    %esi,%r9d
    3326:	and    $0x3,%r9d
    332a:	cmp    $0x4,%rsi
    332e:	movabs $0x89705f3112a28fe5,%r10
    3338:	jae    3349 <loop_zero_bool_select_assume_d1000000007+0x39>
    333a:	xor    %esi,%esi
    333c:	xor    %ecx,%ecx
    333e:	jmp    3417 <loop_zero_bool_select_assume_d1000000007+0x107>
    3343:	xor    %ecx,%ecx
    3345:	mov    %rcx,%rax
    3348:	ret
    3349:	and    $0xfffffffffffffffc,%rsi
    334d:	xor    %ecx,%ecx
    334f:	pxor   %xmm0,%xmm0
    3353:	movabs $0x44b82f989,%r11
    335d:	mov    %rdi,%rbx
    3360:	mov    %rsi,%r14
    3363:	cs nopw 0x0(%rax,%rax,1)
    336d:	nopl   (%rax)
    3370:	movd   (%rbx),%xmm1
    3374:	punpcklbw %xmm1,%xmm1
    3378:	punpcklwd %xmm1,%xmm1
    337c:	pcmpeqb %xmm0,%xmm1
    3380:	movmskps %xmm1,%r8d
    3384:	xor    $0xf,%r8d
    3388:	mov    %r8d,%ebp
    338b:	shr    $0x3,%bpl
    338f:	mov    %r8d,%r15d
    3392:	and    $0x4,%r15b
    3396:	shr    $0x2,%r15b
    339a:	mov    %r8d,%r12d
    339d:	and    $0x2,%r12b
    33a1:	shr    $1,%r12b
    33a4:	and    $0x1,%r8d
    33a8:	add    %rcx,%r8
    33ab:	mov    %r8,%rax
    33ae:	mul    %r10
    33b1:	shr    $0x1d,%rdx
    33b5:	imul   $0x3b9aca07,%rdx,%rax
    33bc:	sub    %rax,%r8
    33bf:	movzbl %r12b,%ecx
    33c3:	add    %r8,%rcx
    33c6:	mov    %rcx,%rax
    33c9:	mul    %r11
    33cc:	imul   $0x3b9aca07,%rdx,%rax
    33d3:	sub    %rax,%rcx
    33d6:	movzbl %r15b,%r8d
    33da:	add    %rcx,%r8
    33dd:	mov    %r8,%rax
    33e0:	mul    %r11
    33e3:	imul   $0x3b9aca07,%rdx,%rax
    33ea:	sub    %rax,%r8
    33ed:	movzbl %bpl,%ecx
    33f1:	add    %r8,%rcx
    33f4:	mov    %rcx,%rax
    33f7:	mul    %r11
    33fa:	imul   $0x3b9aca07,%rdx,%rax
    3401:	sub    %rax,%rcx
    3404:	add    $0x4,%rbx
    3408:	add    $0xfffffffffffffffc,%r14
    340c:	jne    3370 <loop_zero_bool_select_assume_d1000000007+0x60>
    3412:	test   %r9,%r9
    3415:	je     3443 <loop_zero_bool_select_assume_d1000000007+0x133>
    3417:	add    %rsi,%rdi
    341a:	nopw   0x0(%rax,%rax,1)
    3420:	cmpb   $0x1,(%rdi)
    3423:	sbb    $0xffffffffffffffff,%rcx
    3427:	mov    %rcx,%rax
    342a:	mul    %r10
    342d:	shr    $0x1d,%rdx
    3431:	imul   $0x3b9aca07,%rdx,%rax
    3438:	sub    %rax,%rcx
    343b:	inc    %rdi
    343e:	dec    %r9
    3441:	jne    3420 <loop_zero_bool_select_assume_d1000000007+0x110>
    3443:	pop    %rbx
    3444:	pop    %r12
    3446:	pop    %r14
    3448:	pop    %r15
    344a:	pop    %rbp
    344b:	mov    %rcx,%rax
    344e:	ret
