
/home/epentland/ai/canopy/mylang-worktrees/goal110-equality-bounded-20261004/.mylang-cache/goal110-floor-range-ir/floor-range.so:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .text:

0000000000002e30 <loop_zero_bool_baseline_d1000000007>:
    2e30:	movl   $0x0,(%rcx)
    2e36:	test   %rsi,%rsi
    2e39:	je     2e61 <loop_zero_bool_baseline_d1000000007+0x31>
    2e3b:	push   %rbp
    2e3c:	push   %r15
    2e3e:	push   %r14
    2e40:	push   %rbx
    2e41:	mov    %esi,%r10d
    2e44:	and    $0x3,%r10d
    2e48:	cmp    $0x4,%rsi
    2e4c:	movabs $0x89705f3112a28fe5,%r11
    2e56:	jae    2e67 <loop_zero_bool_baseline_d1000000007+0x37>
    2e58:	xor    %esi,%esi
    2e5a:	xor    %ecx,%ecx
    2e5c:	jmp    2fa0 <loop_zero_bool_baseline_d1000000007+0x170>
    2e61:	xor    %ecx,%ecx
    2e63:	mov    %rcx,%rax
    2e66:	ret
    2e67:	and    $0xfffffffffffffffc,%rsi
    2e6b:	xor    %ecx,%ecx
    2e6d:	pxor   %xmm0,%xmm0
    2e71:	mov    %rdi,%rbx
    2e74:	mov    %rsi,%r14
    2e77:	nopw   0x0(%rax,%rax,1)
    2e80:	movd   (%rbx),%xmm1
    2e84:	punpcklbw %xmm1,%xmm1
    2e88:	punpcklwd %xmm1,%xmm1
    2e8c:	pcmpeqb %xmm0,%xmm1
    2e90:	movmskps %xmm1,%r8d
    2e94:	xor    $0xf,%r8d
    2e98:	mov    %r8d,%r9d
    2e9b:	shr    $0x3,%r9b
    2e9f:	mov    %r8d,%ebp
    2ea2:	and    $0x4,%bpl
    2ea6:	shr    $0x2,%bpl
    2eaa:	mov    %r8d,%r15d
    2ead:	and    $0x2,%r15b
    2eb1:	shr    $1,%r15b
    2eb4:	and    $0x1,%r8d
    2eb8:	add    %rcx,%r8
    2ebb:	mov    %r8,%rax
    2ebe:	imul   %r11
    2ec1:	add    %r8,%rdx
    2ec4:	mov    %rdx,%rax
    2ec7:	shr    $0x3f,%rax
    2ecb:	sar    $0x1d,%rdx
    2ecf:	add    %rax,%rdx
    2ed2:	imul   $0x3b9aca07,%rdx,%rax
    2ed9:	sub    %rax,%r8
    2edc:	movzbl %r15b,%ecx
    2ee0:	add    %r8,%rcx
    2ee3:	sar    $0x3f,%r8
    2ee7:	and    $0x3b9aca07,%r8d
    2eee:	add    %r8,%rcx
    2ef1:	mov    %rcx,%rax
    2ef4:	imul   %r11
    2ef7:	add    %rcx,%rdx
    2efa:	mov    %rdx,%rax
    2efd:	shr    $0x3f,%rax
    2f01:	sar    $0x1d,%rdx
    2f05:	add    %rax,%rdx
    2f08:	imul   $0x3b9aca07,%rdx,%rax
    2f0f:	sub    %rax,%rcx
    2f12:	movzbl %bpl,%r8d
    2f16:	add    %rcx,%r8
    2f19:	sar    $0x3f,%rcx
    2f1d:	and    $0x3b9aca07,%ecx
    2f23:	add    %rcx,%r8
    2f26:	mov    %r8,%rax
    2f29:	imul   %r11
    2f2c:	add    %r8,%rdx
    2f2f:	mov    %rdx,%rax
    2f32:	shr    $0x3f,%rax
    2f36:	sar    $0x1d,%rdx
    2f3a:	add    %rax,%rdx
    2f3d:	imul   $0x3b9aca07,%rdx,%rax
    2f44:	sub    %rax,%r8
    2f47:	movzbl %r9b,%r9d
    2f4b:	add    %r8,%r9
    2f4e:	sar    $0x3f,%r8
    2f52:	and    $0x3b9aca07,%r8d
    2f59:	add    %r8,%r9
    2f5c:	mov    %r9,%rax
    2f5f:	imul   %r11
    2f62:	add    %r9,%rdx
    2f65:	mov    %rdx,%rax
    2f68:	shr    $0x3f,%rax
    2f6c:	sar    $0x1d,%rdx
    2f70:	add    %rax,%rdx
    2f73:	imul   $0x3b9aca07,%rdx,%rax
    2f7a:	sub    %rax,%r9
    2f7d:	mov    %r9,%rcx
    2f80:	sar    $0x3f,%rcx
    2f84:	and    $0x3b9aca07,%ecx
    2f8a:	add    %r9,%rcx
    2f8d:	add    $0x4,%rbx
    2f91:	add    $0xfffffffffffffffc,%r14
    2f95:	jne    2e80 <loop_zero_bool_baseline_d1000000007+0x50>
    2f9b:	test   %r10,%r10
    2f9e:	je     2fef <loop_zero_bool_baseline_d1000000007+0x1bf>
    2fa0:	add    %rsi,%rdi
    2fa3:	cs nopw 0x0(%rax,%rax,1)
    2fad:	nopl   (%rax)
    2fb0:	cmpb   $0x1,(%rdi)
    2fb3:	sbb    $0xffffffffffffffff,%rcx
    2fb7:	mov    %rcx,%rax
    2fba:	imul   %r11
    2fbd:	add    %rcx,%rdx
    2fc0:	mov    %rdx,%rax
    2fc3:	shr    $0x3f,%rax
    2fc7:	sar    $0x1d,%rdx
    2fcb:	add    %rax,%rdx
    2fce:	imul   $0x3b9aca07,%rdx,%rax
    2fd5:	sub    %rax,%rcx
    2fd8:	mov    %rcx,%rax
    2fdb:	sar    $0x3f,%rax
    2fdf:	and    $0x3b9aca07,%eax
    2fe4:	add    %rax,%rcx
    2fe7:	inc    %rdi
    2fea:	dec    %r10
    2fed:	jne    2fb0 <loop_zero_bool_baseline_d1000000007+0x180>
    2fef:	pop    %rbx
    2ff0:	pop    %r14
    2ff2:	pop    %r15
    2ff4:	pop    %rbp
    2ff5:	mov    %rcx,%rax
    2ff8:	ret
