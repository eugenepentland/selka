
/home/epentland/ai/canopy/mylang-worktrees/goal110-equality-bounded-20261004/.mylang-cache/goal110-floor-range-ir/floor-range.so:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .text:

0000000000003c30 <loop_signed_updates_baseline_d9223372036854775807>:
    3c30:	movl   $0x0,(%rcx)
    3c36:	xor    %r8d,%r8d
    3c39:	test   %rsi,%rsi
    3c3c:	je     3c99 <loop_signed_updates_baseline_d9223372036854775807+0x69>
    3c3e:	movabs $0x4000000000000001,%r9
    3c48:	movabs $0x7fffffffffffffff,%r10
    3c52:	cs nopw 0x0(%rax,%rax,1)
    3c5c:	nopl   0x0(%rax)
    3c60:	add    (%rdi),%r8
    3c63:	jo     3c9d <loop_signed_updates_baseline_d9223372036854775807+0x6d>
    3c65:	mov    %r8,%rax
    3c68:	imul   %r9
    3c6b:	mov    %rdx,%rax
    3c6e:	shr    $0x3f,%rax
    3c72:	sar    $0x3d,%rdx
    3c76:	add    %rax,%rdx
    3c79:	add    %rdx,%r8
    3c7c:	shl    $0x3f,%rdx
    3c80:	add    %r8,%rdx
    3c83:	mov    %rdx,%r8
    3c86:	sar    $0x3f,%r8
    3c8a:	and    %r10,%r8
    3c8d:	add    %rdx,%r8
    3c90:	add    $0x8,%rdi
    3c94:	dec    %rsi
    3c97:	jne    3c60 <loop_signed_updates_baseline_d9223372036854775807+0x30>
    3c99:	mov    %r8,%rax
    3c9c:	ret
    3c9d:	movl   $0x1,(%rcx)
    3ca3:	xor    %r8d,%r8d
    3ca6:	mov    %r8,%rax
    3ca9:	ret
