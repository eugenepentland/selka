
/home/epentland/ai/canopy/mylang-worktrees/goal110-equality-bounded-20261004/.mylang-cache/goal110-floor-range-ir/floor-range.so:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .text:

00000000000036c0 <loop_signed_updates_assume_d1000000007>:
    36c0:	movl   $0x0,(%rcx)
    36c6:	test   %rsi,%rsi
    36c9:	je     3728 <loop_signed_updates_assume_d1000000007+0x68>
    36cb:	xor    %r8d,%r8d
    36ce:	movabs $0x89705f3112a28fe5,%r9
    36d8:	nopl   0x0(%rax,%rax,1)
    36e0:	add    (%rdi),%r8
    36e3:	jo     3722 <loop_signed_updates_assume_d1000000007+0x62>
    36e5:	mov    %r8,%rax
    36e8:	imul   %r9
    36eb:	add    %r8,%rdx
    36ee:	mov    %rdx,%rax
    36f1:	shr    $0x3f,%rax
    36f5:	sar    $0x1d,%rdx
    36f9:	add    %rax,%rdx
    36fc:	imul   $0x3b9aca07,%rdx,%rax
    3703:	sub    %rax,%r8
    3706:	mov    %r8,%rax
    3709:	sar    $0x3f,%rax
    370d:	and    $0x3b9aca07,%eax
    3712:	add    %r8,%rax
    3715:	add    $0x8,%rdi
    3719:	dec    %rsi
    371c:	mov    %rax,%r8
    371f:	jne    36e0 <loop_signed_updates_assume_d1000000007+0x20>
    3721:	ret
    3722:	movl   $0x1,(%rcx)
    3728:	xor    %eax,%eax
    372a:	ret
