
/home/epentland/ai/canopy/mylang-worktrees/goal110-equality-bounded-20261004/.mylang-cache/goal110-floor-range-ir/floor-range.so:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .text:

0000000000003db0 <loop_signed_updates_select_assume_d9223372036854775807>:
    3db0:	movl   $0x0,(%rcx)
    3db6:	test   %rsi,%rsi
    3db9:	je     3e21 <loop_signed_updates_select_assume_d9223372036854775807+0x71>
    3dbb:	movabs $0x7fffffffffffffff,%r9
    3dc5:	xor    %r8d,%r8d
    3dc8:	movabs $0x4000000000000001,%r10
    3dd2:	cs nopw 0x0(%rax,%rax,1)
    3ddc:	nopl   0x0(%rax)
    3de0:	add    (%rdi),%r8
    3de3:	jo     3e1b <loop_signed_updates_select_assume_d9223372036854775807+0x6b>
    3de5:	mov    %r8,%rax
    3de8:	imul   %r10
    3deb:	mov    %rdx,%rax
    3dee:	shr    $0x3f,%rax
    3df2:	sar    $0x3d,%rdx
    3df6:	add    %rax,%rdx
    3df9:	add    %rdx,%r8
    3dfc:	shl    $0x3f,%rdx
    3e00:	add    %r8,%rdx
    3e03:	lea    (%rdx,%r9,1),%r8
    3e07:	test   %rdx,%rdx
    3e0a:	cmovns %rdx,%r8
    3e0e:	add    $0x8,%rdi
    3e12:	dec    %rsi
    3e15:	jne    3de0 <loop_signed_updates_select_assume_d9223372036854775807+0x30>
    3e17:	mov    %r8,%rax
    3e1a:	ret
    3e1b:	movl   $0x1,(%rcx)
    3e21:	xor    %r8d,%r8d
    3e24:	mov    %r8,%rax
    3e27:	ret
