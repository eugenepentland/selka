
/home/epentland/ai/canopy/mylang-worktrees/goal110-equality-bounded-20261004/.mylang-cache/goal110-floor-range-ir/floor-range.so:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .text:

00000000000037b0 <loop_signed_updates_select_assume_d1000000007>:
    37b0:	movl   $0x0,(%rcx)
    37b6:	xor    %r8d,%r8d
    37b9:	test   %rsi,%rsi
    37bc:	je     3814 <loop_signed_updates_select_assume_d1000000007+0x64>
    37be:	movabs $0x89705f3112a28fe5,%r9
    37c8:	nopl   0x0(%rax,%rax,1)
    37d0:	add    (%rdi),%r8
    37d3:	jo     3818 <loop_signed_updates_select_assume_d1000000007+0x68>
    37d5:	mov    %r8,%rax
    37d8:	imul   %r9
    37db:	add    %r8,%rdx
    37de:	mov    %rdx,%rax
    37e1:	shr    $0x3f,%rax
    37e5:	sar    $0x1d,%rdx
    37e9:	add    %rax,%rdx
    37ec:	imul   $0x3b9aca07,%rdx,%rax
    37f3:	mov    %r8,%rdx
    37f6:	sub    %rax,%rdx
    37f9:	neg    %rax
    37fc:	test   %rdx,%rdx
    37ff:	lea    0x3b9aca07(%r8,%rax,1),%r8
    3807:	cmovns %rdx,%r8
    380b:	add    $0x8,%rdi
    380f:	dec    %rsi
    3812:	jne    37d0 <loop_signed_updates_select_assume_d1000000007+0x20>
    3814:	mov    %r8,%rax
    3817:	ret
    3818:	movl   $0x1,(%rcx)
    381e:	xor    %r8d,%r8d
    3821:	mov    %r8,%rax
    3824:	ret
