define range(i64 -1000000006, 2000000014) i64 @loop_signed_updates_baseline_d1000000007(ptr readonly captures(none) %data, i64 %count, i64 %seed, ptr writeonly captures(none) initializes((0, 4)) %status) local_unnamed_addr #4 {
entry:
  store i32 0, ptr %status, align 4
  %empty = icmp eq i64 %count, 0
  br i1 %empty, label %common.ret, label %loop

common.ret:                                       ; preds = %success, %entry, %failure
  %common.ret.op = phi i64 [ 0, %entry ], [ 0, %failure ], [ %result, %success ]
  ret i64 %common.ret.op

loop:                                             ; preds = %entry, %success
  %index = phi i64 [ %next, %success ], [ 0, %entry ]
  %checksum = phi i64 [ %result, %success ], [ 0, %entry ]
  %address = getelementptr i64, ptr %data, i64 %index
  %increment = load i64, ptr %address, align 8
  %addition = tail call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %checksum, i64 %increment)
  %overflow = extractvalue { i64, i1 } %addition, 1
  br i1 %overflow, label %failure, label %success

failure:                                          ; preds = %loop
  store i32 1, ptr %status, align 4
  br label %common.ret

success:                                          ; preds = %loop
  %sum = extractvalue { i64, i1 } %addition, 0
  %rem = srem i64 %sum, 1000000007
  %isneg = icmp slt i64 %rem, 0
  %delta = select i1 %isneg, i64 1000000007, i64 0
  %result = add nsw i64 %delta, %rem
  %next = add nuw i64 %index, 1
  %done = icmp eq i64 %next, %count
  br i1 %done, label %common.ret, label %loop
}
