define range(i64 -1000000006, 2000000014) i64 @scalar_baseline_d1000000007(i64 %value) local_unnamed_addr #2 {
entry:
  %rem = srem i64 %value, 1000000007
  %isneg = icmp slt i64 %rem, 0
  %delta = select i1 %isneg, i64 1000000007, i64 0
  %result = add nsw i64 %delta, %rem
  ret i64 %result
}
