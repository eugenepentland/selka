
/home/epentland/ai/canopy/mylang-worktrees/goal110-equality-bounded-20261004/.mylang-cache/goal110-floor-range-ir/floor-range.so:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .text:

0000000000003000 <loop_zero_bool_assume_d1000000007>:
    3000:	movl   $0x0,(%rcx)
    3006:	test   %rsi,%rsi
    3009:	je     3033 <loop_zero_bool_assume_d1000000007+0x33>
    300b:	push   %rbp
    300c:	push   %r15
    300e:	push   %r14
    3010:	push   %r12
    3012:	push   %rbx
    3013:	mov    %esi,%r9d
    3016:	and    $0x3,%r9d
    301a:	cmp    $0x4,%rsi
    301e:	movabs $0x89705f3112a28fe5,%r10
    3028:	jae    3039 <loop_zero_bool_assume_d1000000007+0x39>
    302a:	xor    %esi,%esi
    302c:	xor    %ecx,%ecx
    302e:	jmp    3107 <loop_zero_bool_assume_d1000000007+0x107>
    3033:	xor    %ecx,%ecx
    3035:	mov    %rcx,%rax
    3038:	ret
    3039:	and    $0xfffffffffffffffc,%rsi
    303d:	xor    %ecx,%ecx
    303f:	pxor   %xmm0,%xmm0
    3043:	movabs $0x44b82f989,%r11
    304d:	mov    %rdi,%rbx
    3050:	mov    %rsi,%r14
    3053:	cs nopw 0x0(%rax,%rax,1)
    305d:	nopl   (%rax)
    3060:	movd   (%rbx),%xmm1
    3064:	punpcklbw %xmm1,%xmm1
    3068:	punpcklwd %xmm1,%xmm1
    306c:	pcmpeqb %xmm0,%xmm1
    3070:	movmskps %xmm1,%r8d
    3074:	xor    $0xf,%r8d
    3078:	mov    %r8d,%ebp
    307b:	shr    $0x3,%bpl
    307f:	mov    %r8d,%r15d
    3082:	and    $0x4,%r15b
    3086:	shr    $0x2,%r15b
    308a:	mov    %r8d,%r12d
    308d:	and    $0x2,%r12b
    3091:	shr    $1,%r12b
    3094:	and    $0x1,%r8d
    3098:	add    %rcx,%r8
    309b:	mov    %r8,%rax
    309e:	mul    %r10
    30a1:	shr    $0x1d,%rdx
    30a5:	imul   $0x3b9aca07,%rdx,%rax
    30ac:	sub    %rax,%r8
    30af:	movzbl %r12b,%ecx
    30b3:	add    %r8,%rcx
    30b6:	mov    %rcx,%rax
    30b9:	mul    %r11
    30bc:	imul   $0x3b9aca07,%rdx,%rax
    30c3:	sub    %rax,%rcx
    30c6:	movzbl %r15b,%r8d
    30ca:	add    %rcx,%r8
    30cd:	mov    %r8,%rax
    30d0:	mul    %r11
    30d3:	imul   $0x3b9aca07,%rdx,%rax
    30da:	sub    %rax,%r8
    30dd:	movzbl %bpl,%ecx
    30e1:	add    %r8,%rcx
    30e4:	mov    %rcx,%rax
    30e7:	mul    %r11
    30ea:	imul   $0x3b9aca07,%rdx,%rax
    30f1:	sub    %rax,%rcx
    30f4:	add    $0x4,%rbx
    30f8:	add    $0xfffffffffffffffc,%r14
    30fc:	jne    3060 <loop_zero_bool_assume_d1000000007+0x60>
    3102:	test   %r9,%r9
    3105:	je     3133 <loop_zero_bool_assume_d1000000007+0x133>
    3107:	add    %rsi,%rdi
    310a:	nopw   0x0(%rax,%rax,1)
    3110:	cmpb   $0x1,(%rdi)
    3113:	sbb    $0xffffffffffffffff,%rcx
    3117:	mov    %rcx,%rax
    311a:	mul    %r10
    311d:	shr    $0x1d,%rdx
    3121:	imul   $0x3b9aca07,%rdx,%rax
    3128:	sub    %rax,%rcx
    312b:	inc    %rdi
    312e:	dec    %r9
    3131:	jne    3110 <loop_zero_bool_assume_d1000000007+0x110>
    3133:	pop    %rbx
    3134:	pop    %r12
    3136:	pop    %r14
    3138:	pop    %r15
    313a:	pop    %rbp
    313b:	mov    %rcx,%rax
    313e:	ret
