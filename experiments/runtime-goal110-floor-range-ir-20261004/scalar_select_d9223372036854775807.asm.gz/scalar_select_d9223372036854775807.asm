
/home/epentland/ai/canopy/mylang-worktrees/goal110-equality-bounded-20261004/.mylang-cache/goal110-floor-range-ir/floor-range.so:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .text:

0000000000002590 <scalar_select_d9223372036854775807>:
    2590:	movabs $0x4000000000000001,%rcx
    259a:	mov    %rdi,%rax
    259d:	imul   %rcx
    25a0:	mov    %rdx,%rcx
    25a3:	shr    $0x3f,%rcx
    25a7:	sar    $0x3d,%rdx
    25ab:	add    %rdx,%rcx
    25ae:	lea    (%rdi,%rcx,1),%rax
    25b2:	shl    $0x3f,%rcx
    25b6:	add    %rax,%rcx
    25b9:	movabs $0x7fffffffffffffff,%rax
    25c3:	add    %rcx,%rax
    25c6:	test   %rcx,%rcx
    25c9:	cmovns %rcx,%rax
    25cd:	ret
