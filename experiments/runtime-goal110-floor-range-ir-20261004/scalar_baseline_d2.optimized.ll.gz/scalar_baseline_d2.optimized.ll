define range(i64 0, 2) i64 @scalar_baseline_d2(i64 %value) local_unnamed_addr #2 {
entry:
  %result = and i64 %value, 1
  ret i64 %result
}
