
/home/epentland/ai/canopy/mylang-worktrees/goal110-equality-bounded-20261004/.mylang-cache/goal110-floor-range-ir/floor-range.so:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .text:

00000000000029a0 <loop_zero_bool_select_assume_d3>:
    29a0:	movl   $0x0,(%rcx)
    29a6:	test   %rsi,%rsi
    29a9:	je     29d3 <loop_zero_bool_select_assume_d3+0x33>
    29ab:	push   %rbp
    29ac:	push   %r15
    29ae:	push   %r14
    29b0:	push   %r12
    29b2:	push   %rbx
    29b3:	mov    %esi,%r9d
    29b6:	and    $0x3,%r9d
    29ba:	cmp    $0x4,%rsi
    29be:	movabs $0xaaaaaaaaaaaaaaab,%r10
    29c8:	jae    29d9 <loop_zero_bool_select_assume_d3+0x39>
    29ca:	xor    %esi,%esi
    29cc:	xor    %ecx,%ecx
    29ce:	jmp    2a9a <loop_zero_bool_select_assume_d3+0xfa>
    29d3:	xor    %ecx,%ecx
    29d5:	mov    %rcx,%rax
    29d8:	ret
    29d9:	and    $0xfffffffffffffffc,%rsi
    29dd:	xor    %ecx,%ecx
    29df:	pxor   %xmm0,%xmm0
    29e3:	movabs $0x5555555555555556,%r11
    29ed:	mov    %rdi,%rbx
    29f0:	mov    %rsi,%r14
    29f3:	cs nopw 0x0(%rax,%rax,1)
    29fd:	nopl   (%rax)
    2a00:	movd   (%rbx),%xmm1
    2a04:	punpcklbw %xmm1,%xmm1
    2a08:	punpcklwd %xmm1,%xmm1
    2a0c:	pcmpeqb %xmm0,%xmm1
    2a10:	movmskps %xmm1,%r8d
    2a14:	xor    $0xf,%r8d
    2a18:	mov    %r8d,%ebp
    2a1b:	shr    $0x3,%bpl
    2a1f:	mov    %r8d,%r15d
    2a22:	and    $0x4,%r15b
    2a26:	shr    $0x2,%r15b
    2a2a:	mov    %r8d,%r12d
    2a2d:	and    $0x2,%r12b
    2a31:	shr    $1,%r12b
    2a34:	and    $0x1,%r8d
    2a38:	add    %rcx,%r8
    2a3b:	mov    %r8,%rax
    2a3e:	mul    %r10
    2a41:	shr    $1,%rdx
    2a44:	lea    (%rdx,%rdx,2),%rax
    2a48:	sub    %rax,%r8
    2a4b:	movzbl %r12b,%ecx
    2a4f:	add    %r8,%rcx
    2a52:	mov    %rcx,%rax
    2a55:	mul    %r11
    2a58:	lea    (%rdx,%rdx,2),%rax
    2a5c:	sub    %rax,%rcx
    2a5f:	movzbl %r15b,%r8d
    2a63:	add    %rcx,%r8
    2a66:	mov    %r8,%rax
    2a69:	mul    %r11
    2a6c:	lea    (%rdx,%rdx,2),%rax
    2a70:	sub    %rax,%r8
    2a73:	movzbl %bpl,%ecx
    2a77:	add    %r8,%rcx
    2a7a:	mov    %rcx,%rax
    2a7d:	mul    %r11
    2a80:	lea    (%rdx,%rdx,2),%rax
    2a84:	sub    %rax,%rcx
    2a87:	add    $0x4,%rbx
    2a8b:	add    $0xfffffffffffffffc,%r14
    2a8f:	jne    2a00 <loop_zero_bool_select_assume_d3+0x60>
    2a95:	test   %r9,%r9
    2a98:	je     2abf <loop_zero_bool_select_assume_d3+0x11f>
    2a9a:	add    %rsi,%rdi
    2a9d:	nopl   (%rax)
    2aa0:	cmpb   $0x1,(%rdi)
    2aa3:	sbb    $0xffffffffffffffff,%rcx
    2aa7:	mov    %rcx,%rax
    2aaa:	mul    %r10
    2aad:	shr    $1,%rdx
    2ab0:	lea    (%rdx,%rdx,2),%rax
    2ab4:	sub    %rax,%rcx
    2ab7:	inc    %rdi
    2aba:	dec    %r9
    2abd:	jne    2aa0 <loop_zero_bool_select_assume_d3+0x100>
    2abf:	pop    %rbx
    2ac0:	pop    %r12
    2ac2:	pop    %r14
    2ac4:	pop    %r15
    2ac6:	pop    %rbp
    2ac7:	mov    %rcx,%rax
    2aca:	ret
