
/home/epentland/ai/canopy/mylang-worktrees/goal110-equality-bounded-20261004/.mylang-cache/goal110-floor-range-ir/floor-range.so:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .text:

0000000000003140 <loop_zero_bool_select_d1000000007>:
    3140:	movl   $0x0,(%rcx)
    3146:	test   %rsi,%rsi
    3149:	je     3171 <loop_zero_bool_select_d1000000007+0x31>
    314b:	push   %rbp
    314c:	push   %r15
    314e:	push   %r14
    3150:	push   %rbx
    3151:	mov    %esi,%r9d
    3154:	and    $0x3,%r9d
    3158:	cmp    $0x4,%rsi
    315c:	movabs $0x89705f3112a28fe5,%r10
    3166:	jae    3177 <loop_zero_bool_select_d1000000007+0x37>
    3168:	xor    %esi,%esi
    316a:	xor    %ecx,%ecx
    316c:	jmp    32b0 <loop_zero_bool_select_d1000000007+0x170>
    3171:	xor    %ecx,%ecx
    3173:	mov    %rcx,%rax
    3176:	ret
    3177:	and    $0xfffffffffffffffc,%rsi
    317b:	xor    %ecx,%ecx
    317d:	pxor   %xmm0,%xmm0
    3181:	mov    %rdi,%r11
    3184:	mov    %rsi,%rbx
    3187:	nopw   0x0(%rax,%rax,1)
    3190:	movd   (%r11),%xmm1
    3195:	punpcklbw %xmm1,%xmm1
    3199:	punpcklwd %xmm1,%xmm1
    319d:	pcmpeqb %xmm0,%xmm1
    31a1:	movmskps %xmm1,%r8d
    31a5:	xor    $0xf,%r8d
    31a9:	mov    %r8d,%ebp
    31ac:	shr    $0x3,%bpl
    31b0:	mov    %r8d,%r14d
    31b3:	and    $0x4,%r14b
    31b7:	shr    $0x2,%r14b
    31bb:	mov    %r8d,%r15d
    31be:	and    $0x2,%r15b
    31c2:	shr    $1,%r15b
    31c5:	and    $0x1,%r8d
    31c9:	add    %rcx,%r8
    31cc:	mov    %r8,%rax
    31cf:	imul   %r10
    31d2:	add    %r8,%rdx
    31d5:	mov    %rdx,%rax
    31d8:	shr    $0x3f,%rax
    31dc:	sar    $0x1d,%rdx
    31e0:	add    %rax,%rdx
    31e3:	imul   $0x3b9aca07,%rdx,%rax
    31ea:	sub    %rax,%r8
    31ed:	lea    0x3b9aca07(%r8),%rax
    31f4:	test   %r8,%r8
    31f7:	cmovns %r8,%rax
    31fb:	movzbl %r15b,%ecx
    31ff:	add    %rax,%rcx
    3202:	mov    %rcx,%rax
    3205:	imul   %r10
    3208:	add    %rcx,%rdx
    320b:	mov    %rdx,%rax
    320e:	shr    $0x3f,%rax
    3212:	sar    $0x1d,%rdx
    3216:	add    %rax,%rdx
    3219:	imul   $0x3b9aca07,%rdx,%rax
    3220:	sub    %rax,%rcx
    3223:	lea    0x3b9aca07(%rcx),%rax
    322a:	test   %rcx,%rcx
    322d:	cmovns %rcx,%rax
    3231:	movzbl %r14b,%ecx
    3235:	add    %rax,%rcx
    3238:	mov    %rcx,%rax
    323b:	imul   %r10
    323e:	add    %rcx,%rdx
    3241:	mov    %rdx,%rax
    3244:	shr    $0x3f,%rax
    3248:	sar    $0x1d,%rdx
    324c:	add    %rax,%rdx
    324f:	imul   $0x3b9aca07,%rdx,%rax
    3256:	sub    %rax,%rcx
    3259:	lea    0x3b9aca07(%rcx),%rax
    3260:	test   %rcx,%rcx
    3263:	cmovns %rcx,%rax
    3267:	movzbl %bpl,%r8d
    326b:	add    %rax,%r8
    326e:	mov    %r8,%rax
    3271:	imul   %r10
    3274:	add    %r8,%rdx
    3277:	mov    %rdx,%rax
    327a:	shr    $0x3f,%rax
    327e:	sar    $0x1d,%rdx
    3282:	add    %rax,%rdx
    3285:	imul   $0x3b9aca07,%rdx,%rax
    328c:	sub    %rax,%r8
    328f:	lea    0x3b9aca07(%r8),%rcx
    3296:	test   %r8,%r8
    3299:	cmovns %r8,%rcx
    329d:	add    $0x4,%r11
    32a1:	add    $0xfffffffffffffffc,%rbx
    32a5:	jne    3190 <loop_zero_bool_select_d1000000007+0x50>
    32ab:	test   %r9,%r9
    32ae:	je     3305 <loop_zero_bool_select_d1000000007+0x1c5>
    32b0:	add    %rsi,%rdi
    32b3:	cs nopw 0x0(%rax,%rax,1)
    32bd:	nopl   (%rax)
    32c0:	cmpb   $0x1,(%rdi)
    32c3:	sbb    $0xffffffffffffffff,%rcx
    32c7:	mov    %rcx,%rax
    32ca:	imul   %r10
    32cd:	add    %rcx,%rdx
    32d0:	mov    %rdx,%rax
    32d3:	shr    $0x3f,%rax
    32d7:	sar    $0x1d,%rdx
    32db:	add    %rax,%rdx
    32de:	imul   $0x3b9aca07,%rdx,%rax
    32e5:	mov    %rcx,%rdx
    32e8:	sub    %rax,%rdx
    32eb:	neg    %rax
    32ee:	test   %rdx,%rdx
    32f1:	lea    0x3b9aca07(%rcx,%rax,1),%rcx
    32f9:	cmovns %rdx,%rcx
    32fd:	inc    %rdi
    3300:	dec    %r9
    3303:	jne    32c0 <loop_zero_bool_select_d1000000007+0x180>
    3305:	pop    %rbx
    3306:	pop    %r14
    3308:	pop    %r15
    330a:	pop    %rbp
    330b:	mov    %rcx,%rax
    330e:	ret
