
/home/epentland/ai/canopy/mylang-worktrees/goal110-equality-bounded-20261004/.mylang-cache/goal110-floor-range-ir/floor-range.so:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .text:

0000000000002320 <scalar_assume_d3>:
    2320:	movabs $0x5555555555555556,%rcx
    232a:	mov    %rdi,%rax
    232d:	imul   %rcx
    2330:	mov    %rdx,%rax
    2333:	shr    $0x3f,%rax
    2337:	add    %rdx,%rax
    233a:	lea    (%rax,%rax,2),%rax
    233e:	sub    %rax,%rdi
    2341:	mov    %rdi,%rax
    2344:	sar    $0x3f,%rax
    2348:	and    $0x3,%eax
    234b:	add    %rdi,%rax
    234e:	ret
