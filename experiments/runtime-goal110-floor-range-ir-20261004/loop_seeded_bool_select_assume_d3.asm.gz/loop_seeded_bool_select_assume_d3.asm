
/home/epentland/ai/canopy/mylang-worktrees/goal110-equality-bounded-20261004/.mylang-cache/goal110-floor-range-ir/floor-range.so:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .text:

0000000000002c20 <loop_seeded_bool_select_assume_d3>:
    2c20:	mov    %rdx,%rax
    2c23:	movl   $0x0,(%rcx)
    2c29:	test   %rsi,%rsi
    2c2c:	je     2c80 <loop_seeded_bool_select_assume_d3+0x60>
    2c2e:	movabs $0x5555555555555556,%r9
    2c38:	nopl   0x0(%rax,%rax,1)
    2c40:	xor    %r8d,%r8d
    2c43:	cmpb   $0x0,(%rdi)
    2c46:	setne  %r8b
    2c4a:	add    %rax,%r8
    2c4d:	jo     2c81 <loop_seeded_bool_select_assume_d3+0x61>
    2c4f:	mov    %r8,%rax
    2c52:	imul   %r9
    2c55:	mov    %rdx,%rax
    2c58:	shr    $0x3f,%rax
    2c5c:	add    %rdx,%rax
    2c5f:	lea    (%rax,%rax,2),%rax
    2c63:	mov    %r8,%rdx
    2c66:	sub    %rax,%rdx
    2c69:	neg    %rax
    2c6c:	test   %rdx,%rdx
    2c6f:	lea    0x3(%r8,%rax,1),%rax
    2c74:	cmovns %rdx,%rax
    2c78:	inc    %rdi
    2c7b:	dec    %rsi
    2c7e:	jne    2c40 <loop_seeded_bool_select_assume_d3+0x20>
    2c80:	ret
    2c81:	movl   $0x1,(%rcx)
    2c87:	xor    %eax,%eax
    2c89:	ret
