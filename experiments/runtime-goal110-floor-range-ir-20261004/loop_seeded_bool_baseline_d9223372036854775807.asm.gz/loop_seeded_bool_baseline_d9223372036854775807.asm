
/home/epentland/ai/canopy/mylang-worktrees/goal110-equality-bounded-20261004/.mylang-cache/goal110-floor-range-ir/floor-range.so:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .text:

0000000000003a30 <loop_seeded_bool_baseline_d9223372036854775807>:
    3a30:	mov    %rdx,%rax
    3a33:	movl   $0x0,(%rcx)
    3a39:	test   %rsi,%rsi
    3a3c:	je     3aa5 <loop_seeded_bool_baseline_d9223372036854775807+0x75>
    3a3e:	movabs $0x4000000000000001,%r9
    3a48:	movabs $0x7fffffffffffffff,%r10
    3a52:	cs nopw 0x0(%rax,%rax,1)
    3a5c:	nopl   0x0(%rax)
    3a60:	xor    %r8d,%r8d
    3a63:	cmpb   $0x0,(%rdi)
    3a66:	setne  %r8b
    3a6a:	add    %rax,%r8
    3a6d:	jo     3aa6 <loop_seeded_bool_baseline_d9223372036854775807+0x76>
    3a6f:	mov    %r8,%rax
    3a72:	imul   %r9
    3a75:	mov    %rdx,%rax
    3a78:	shr    $0x3f,%rax
    3a7c:	sar    $0x3d,%rdx
    3a80:	add    %rax,%rdx
    3a83:	mov    %rdx,%r11
    3a86:	shl    $0x3f,%r11
    3a8a:	add    %rdx,%r11
    3a8d:	add    %r8,%r11
    3a90:	mov    %r11,%rax
    3a93:	sar    $0x3f,%rax
    3a97:	and    %r10,%rax
    3a9a:	add    %r11,%rax
    3a9d:	inc    %rdi
    3aa0:	dec    %rsi
    3aa3:	jne    3a60 <loop_seeded_bool_baseline_d9223372036854775807+0x30>
    3aa5:	ret
    3aa6:	movl   $0x1,(%rcx)
    3aac:	xor    %eax,%eax
    3aae:	ret
