
/home/epentland/ai/canopy/mylang-worktrees/goal110-equality-bounded-20261004/.mylang-cache/goal110-floor-range-ir/floor-range.so:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .text:

0000000000002350 <scalar_select_d3>:
    2350:	movabs $0x5555555555555556,%rcx
    235a:	mov    %rdi,%rax
    235d:	imul   %rcx
    2360:	mov    %rdx,%rax
    2363:	shr    $0x3f,%rax
    2367:	add    %rdx,%rax
    236a:	lea    (%rax,%rax,2),%rax
    236e:	mov    %rdi,%rcx
    2371:	sub    %rax,%rcx
    2374:	neg    %rax
    2377:	test   %rcx,%rcx
    237a:	lea    0x3(%rdi,%rax,1),%rax
    237f:	cmovns %rcx,%rax
    2383:	ret
