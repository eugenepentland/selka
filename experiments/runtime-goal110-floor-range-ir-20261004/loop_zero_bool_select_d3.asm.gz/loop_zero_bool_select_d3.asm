
/home/epentland/ai/canopy/mylang-worktrees/goal110-equality-bounded-20261004/.mylang-cache/goal110-floor-range-ir/floor-range.so:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .text:

0000000000002870 <loop_zero_bool_select_d3>:
    2870:	movl   $0x0,(%rcx)
    2876:	test   %rsi,%rsi
    2879:	je     28a3 <loop_zero_bool_select_d3+0x33>
    287b:	push   %rbp
    287c:	push   %r15
    287e:	push   %r14
    2880:	push   %r12
    2882:	push   %rbx
    2883:	mov    %esi,%r9d
    2886:	and    $0x3,%r9d
    288a:	cmp    $0x4,%rsi
    288e:	movabs $0xaaaaaaaaaaaaaaab,%r10
    2898:	jae    28a9 <loop_zero_bool_select_d3+0x39>
    289a:	xor    %esi,%esi
    289c:	xor    %ecx,%ecx
    289e:	jmp    296a <loop_zero_bool_select_d3+0xfa>
    28a3:	xor    %ecx,%ecx
    28a5:	mov    %rcx,%rax
    28a8:	ret
    28a9:	and    $0xfffffffffffffffc,%rsi
    28ad:	xor    %ecx,%ecx
    28af:	pxor   %xmm0,%xmm0
    28b3:	movabs $0x5555555555555556,%r11
    28bd:	mov    %rdi,%rbx
    28c0:	mov    %rsi,%r14
    28c3:	cs nopw 0x0(%rax,%rax,1)
    28cd:	nopl   (%rax)
    28d0:	movd   (%rbx),%xmm1
    28d4:	punpcklbw %xmm1,%xmm1
    28d8:	punpcklwd %xmm1,%xmm1
    28dc:	pcmpeqb %xmm0,%xmm1
    28e0:	movmskps %xmm1,%r8d
    28e4:	xor    $0xf,%r8d
    28e8:	mov    %r8d,%ebp
    28eb:	shr    $0x3,%bpl
    28ef:	mov    %r8d,%r15d
    28f2:	and    $0x4,%r15b
    28f6:	shr    $0x2,%r15b
    28fa:	mov    %r8d,%r12d
    28fd:	and    $0x2,%r12b
    2901:	shr    $1,%r12b
    2904:	and    $0x1,%r8d
    2908:	add    %rcx,%r8
    290b:	mov    %r8,%rax
    290e:	mul    %r10
    2911:	shr    $1,%rdx
    2914:	lea    (%rdx,%rdx,2),%rax
    2918:	sub    %rax,%r8
    291b:	movzbl %r12b,%ecx
    291f:	add    %r8,%rcx
    2922:	mov    %rcx,%rax
    2925:	mul    %r11
    2928:	lea    (%rdx,%rdx,2),%rax
    292c:	sub    %rax,%rcx
    292f:	movzbl %r15b,%r8d
    2933:	add    %rcx,%r8
    2936:	mov    %r8,%rax
    2939:	mul    %r11
    293c:	lea    (%rdx,%rdx,2),%rax
    2940:	sub    %rax,%r8
    2943:	movzbl %bpl,%ecx
    2947:	add    %r8,%rcx
    294a:	mov    %rcx,%rax
    294d:	mul    %r11
    2950:	lea    (%rdx,%rdx,2),%rax
    2954:	sub    %rax,%rcx
    2957:	add    $0x4,%rbx
    295b:	add    $0xfffffffffffffffc,%r14
    295f:	jne    28d0 <loop_zero_bool_select_d3+0x60>
    2965:	test   %r9,%r9
    2968:	je     298f <loop_zero_bool_select_d3+0x11f>
    296a:	add    %rsi,%rdi
    296d:	nopl   (%rax)
    2970:	cmpb   $0x1,(%rdi)
    2973:	sbb    $0xffffffffffffffff,%rcx
    2977:	mov    %rcx,%rax
    297a:	mul    %r10
    297d:	shr    $1,%rdx
    2980:	lea    (%rdx,%rdx,2),%rax
    2984:	sub    %rax,%rcx
    2987:	inc    %rdi
    298a:	dec    %r9
    298d:	jne    2970 <loop_zero_bool_select_d3+0x100>
    298f:	pop    %rbx
    2990:	pop    %r12
    2992:	pop    %r14
    2994:	pop    %r15
    2996:	pop    %rbp
    2997:	mov    %rcx,%rax
    299a:	ret
