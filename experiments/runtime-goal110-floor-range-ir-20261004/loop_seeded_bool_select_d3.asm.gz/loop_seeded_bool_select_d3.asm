
/home/epentland/ai/canopy/mylang-worktrees/goal110-equality-bounded-20261004/.mylang-cache/goal110-floor-range-ir/floor-range.so:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .text:

0000000000002bb0 <loop_seeded_bool_select_d3>:
    2bb0:	mov    %rdx,%rax
    2bb3:	movl   $0x0,(%rcx)
    2bb9:	test   %rsi,%rsi
    2bbc:	je     2c10 <loop_seeded_bool_select_d3+0x60>
    2bbe:	movabs $0x5555555555555556,%r9
    2bc8:	nopl   0x0(%rax,%rax,1)
    2bd0:	xor    %r8d,%r8d
    2bd3:	cmpb   $0x0,(%rdi)
    2bd6:	setne  %r8b
    2bda:	add    %rax,%r8
    2bdd:	jo     2c11 <loop_seeded_bool_select_d3+0x61>
    2bdf:	mov    %r8,%rax
    2be2:	imul   %r9
    2be5:	mov    %rdx,%rax
    2be8:	shr    $0x3f,%rax
    2bec:	add    %rdx,%rax
    2bef:	lea    (%rax,%rax,2),%rax
    2bf3:	mov    %r8,%rdx
    2bf6:	sub    %rax,%rdx
    2bf9:	neg    %rax
    2bfc:	test   %rdx,%rdx
    2bff:	lea    0x3(%r8,%rax,1),%rax
    2c04:	cmovns %rdx,%rax
    2c08:	inc    %rdi
    2c0b:	dec    %rsi
    2c0e:	jne    2bd0 <loop_seeded_bool_select_d3+0x20>
    2c10:	ret
    2c11:	movl   $0x1,(%rcx)
    2c17:	xor    %eax,%eax
    2c19:	ret
