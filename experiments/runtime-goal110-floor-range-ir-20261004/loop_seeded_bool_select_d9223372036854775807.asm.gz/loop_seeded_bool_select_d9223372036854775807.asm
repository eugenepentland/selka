
/home/epentland/ai/canopy/mylang-worktrees/goal110-equality-bounded-20261004/.mylang-cache/goal110-floor-range-ir/floor-range.so:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .text:

0000000000003b30 <loop_seeded_bool_select_d9223372036854775807>:
    3b30:	mov    %rdx,%rax
    3b33:	movl   $0x0,(%rcx)
    3b39:	test   %rsi,%rsi
    3b3c:	je     3ba3 <loop_seeded_bool_select_d9223372036854775807+0x73>
    3b3e:	movabs $0x4000000000000001,%r9
    3b48:	movabs $0x7fffffffffffffff,%r10
    3b52:	cs nopw 0x0(%rax,%rax,1)
    3b5c:	nopl   0x0(%rax)
    3b60:	xor    %r8d,%r8d
    3b63:	cmpb   $0x0,(%rdi)
    3b66:	setne  %r8b
    3b6a:	add    %rax,%r8
    3b6d:	jo     3ba4 <loop_seeded_bool_select_d9223372036854775807+0x74>
    3b6f:	mov    %r8,%rax
    3b72:	imul   %r9
    3b75:	mov    %rdx,%rax
    3b78:	shr    $0x3f,%rax
    3b7c:	sar    $0x3d,%rdx
    3b80:	add    %rax,%rdx
    3b83:	mov    %rdx,%r11
    3b86:	shl    $0x3f,%r11
    3b8a:	add    %rdx,%r11
    3b8d:	add    %r8,%r11
    3b90:	lea    (%r11,%r10,1),%rax
    3b94:	test   %r11,%r11
    3b97:	cmovns %r11,%rax
    3b9b:	inc    %rdi
    3b9e:	dec    %rsi
    3ba1:	jne    3b60 <loop_seeded_bool_select_d9223372036854775807+0x30>
    3ba3:	ret
    3ba4:	movl   $0x1,(%rcx)
    3baa:	xor    %eax,%eax
    3bac:	ret
