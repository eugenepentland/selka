
/home/epentland/ai/canopy/mylang-worktrees/goal110-equality-bounded-20261004/.mylang-cache/goal110-floor-range-ir/floor-range.so:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .text:

0000000000002cf0 <loop_signed_updates_assume_d3>:
    2cf0:	movl   $0x0,(%rcx)
    2cf6:	test   %rsi,%rsi
    2cf9:	je     2d4c <loop_signed_updates_assume_d3+0x5c>
    2cfb:	xor    %r8d,%r8d
    2cfe:	movabs $0x5555555555555556,%r9
    2d08:	nopl   0x0(%rax,%rax,1)
    2d10:	add    (%rdi),%r8
    2d13:	jo     2d46 <loop_signed_updates_assume_d3+0x56>
    2d15:	mov    %r8,%rax
    2d18:	imul   %r9
    2d1b:	mov    %rdx,%rax
    2d1e:	shr    $0x3f,%rax
    2d22:	add    %rdx,%rax
    2d25:	lea    (%rax,%rax,2),%rax
    2d29:	sub    %rax,%r8
    2d2c:	mov    %r8,%rax
    2d2f:	sar    $0x3f,%rax
    2d33:	and    $0x3,%eax
    2d36:	add    %r8,%rax
    2d39:	add    $0x8,%rdi
    2d3d:	dec    %rsi
    2d40:	mov    %rax,%r8
    2d43:	jne    2d10 <loop_signed_updates_assume_d3+0x20>
    2d45:	ret
    2d46:	movl   $0x1,(%rcx)
    2d4c:	xor    %eax,%eax
    2d4e:	ret
