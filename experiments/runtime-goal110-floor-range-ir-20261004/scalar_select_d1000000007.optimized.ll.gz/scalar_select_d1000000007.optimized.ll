define range(i64 -1000000006, 2000000014) i64 @scalar_select_d1000000007(i64 %value) local_unnamed_addr #2 {
entry:
  %rem = srem i64 %value, 1000000007
  %negative = icmp slt i64 %rem, 0
  %shifted = add nsw i64 %rem, 1000000007
  %result = select i1 %negative, i64 %shifted, i64 %rem
  ret i64 %result
}
