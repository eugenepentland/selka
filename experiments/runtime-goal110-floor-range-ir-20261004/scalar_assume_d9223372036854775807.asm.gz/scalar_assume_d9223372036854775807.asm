
/home/epentland/ai/canopy/mylang-worktrees/goal110-equality-bounded-20261004/.mylang-cache/goal110-floor-range-ir/floor-range.so:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .text:

0000000000002540 <scalar_assume_d9223372036854775807>:
    2540:	movabs $0x4000000000000001,%rcx
    254a:	mov    %rdi,%rax
    254d:	imul   %rcx
    2550:	mov    %rdx,%rcx
    2553:	shr    $0x3f,%rcx
    2557:	sar    $0x3d,%rdx
    255b:	add    %rdx,%rcx
    255e:	lea    (%rdi,%rcx,1),%rax
    2562:	shl    $0x3f,%rcx
    2566:	add    %rax,%rcx
    2569:	mov    %rcx,%rdx
    256c:	sar    $0x3f,%rdx
    2570:	movabs $0x7fffffffffffffff,%rax
    257a:	and    %rdx,%rax
    257d:	add    %rcx,%rax
    2580:	ret
