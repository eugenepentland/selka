
/home/epentland/ai/canopy/mylang-worktrees/goal110-equality-bounded-20261004/.mylang-cache/goal110-floor-range-ir/floor-range.so:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .text:

00000000000025d0 <scalar_select_assume_d9223372036854775807>:
    25d0:	movabs $0x4000000000000001,%rcx
    25da:	mov    %rdi,%rax
    25dd:	imul   %rcx
    25e0:	mov    %rdx,%rcx
    25e3:	shr    $0x3f,%rcx
    25e7:	sar    $0x3d,%rdx
    25eb:	add    %rdx,%rcx
    25ee:	lea    (%rdi,%rcx,1),%rax
    25f2:	shl    $0x3f,%rcx
    25f6:	add    %rax,%rcx
    25f9:	movabs $0x7fffffffffffffff,%rax
    2603:	add    %rcx,%rax
    2606:	test   %rcx,%rcx
    2609:	cmovns %rcx,%rax
    260d:	ret
