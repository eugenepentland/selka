
/home/epentland/ai/canopy/mylang-worktrees/goal110-equality-bounded-20261004/.mylang-cache/goal110-floor-range-ir/floor-range.so:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .text:

0000000000002ad0 <loop_seeded_bool_baseline_d3>:
    2ad0:	mov    %rdx,%rax
    2ad3:	movl   $0x0,(%rcx)
    2ad9:	test   %rsi,%rsi
    2adc:	je     2b2b <loop_seeded_bool_baseline_d3+0x5b>
    2ade:	movabs $0x5555555555555556,%r9
    2ae8:	nopl   0x0(%rax,%rax,1)
    2af0:	xor    %r8d,%r8d
    2af3:	cmpb   $0x0,(%rdi)
    2af6:	setne  %r8b
    2afa:	add    %rax,%r8
    2afd:	jo     2b2c <loop_seeded_bool_baseline_d3+0x5c>
    2aff:	mov    %r8,%rax
    2b02:	imul   %r9
    2b05:	mov    %rdx,%rax
    2b08:	shr    $0x3f,%rax
    2b0c:	add    %rdx,%rax
    2b0f:	lea    (%rax,%rax,2),%rax
    2b13:	sub    %rax,%r8
    2b16:	mov    %r8,%rax
    2b19:	sar    $0x3f,%rax
    2b1d:	and    $0x3,%eax
    2b20:	add    %r8,%rax
    2b23:	inc    %rdi
    2b26:	dec    %rsi
    2b29:	jne    2af0 <loop_seeded_bool_baseline_d3+0x20>
    2b2b:	ret
    2b2c:	movl   $0x1,(%rcx)
    2b32:	xor    %eax,%eax
    2b34:	ret
