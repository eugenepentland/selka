
/home/epentland/ai/canopy/mylang-worktrees/goal110-equality-bounded-20261004/.mylang-cache/goal110-floor-range-ir/floor-range.so:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .text:

00000000000022d0 <scalar_select_d2>:
    22d0:	mov    %rdi,%rax
    22d3:	and    $0x1,%eax
    22d6:	ret
