
/home/epentland/ai/canopy/mylang-worktrees/goal110-equality-bounded-20261004/.mylang-cache/goal110-floor-range-ir/floor-range.so:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .text:

0000000000002610 <loop_zero_bool_baseline_d3>:
    2610:	movl   $0x0,(%rcx)
    2616:	test   %rsi,%rsi
    2619:	je     2643 <loop_zero_bool_baseline_d3+0x33>
    261b:	push   %rbp
    261c:	push   %r15
    261e:	push   %r14
    2620:	push   %r12
    2622:	push   %rbx
    2623:	mov    %esi,%r9d
    2626:	and    $0x3,%r9d
    262a:	cmp    $0x4,%rsi
    262e:	movabs $0xaaaaaaaaaaaaaaab,%r10
    2638:	jae    2649 <loop_zero_bool_baseline_d3+0x39>
    263a:	xor    %esi,%esi
    263c:	xor    %ecx,%ecx
    263e:	jmp    270a <loop_zero_bool_baseline_d3+0xfa>
    2643:	xor    %ecx,%ecx
    2645:	mov    %rcx,%rax
    2648:	ret
    2649:	and    $0xfffffffffffffffc,%rsi
    264d:	xor    %ecx,%ecx
    264f:	pxor   %xmm0,%xmm0
    2653:	movabs $0x5555555555555556,%r11
    265d:	mov    %rdi,%rbx
    2660:	mov    %rsi,%r14
    2663:	cs nopw 0x0(%rax,%rax,1)
    266d:	nopl   (%rax)
    2670:	movd   (%rbx),%xmm1
    2674:	punpcklbw %xmm1,%xmm1
    2678:	punpcklwd %xmm1,%xmm1
    267c:	pcmpeqb %xmm0,%xmm1
    2680:	movmskps %xmm1,%r8d
    2684:	xor    $0xf,%r8d
    2688:	mov    %r8d,%ebp
    268b:	shr    $0x3,%bpl
    268f:	mov    %r8d,%r15d
    2692:	and    $0x4,%r15b
    2696:	shr    $0x2,%r15b
    269a:	mov    %r8d,%r12d
    269d:	and    $0x2,%r12b
    26a1:	shr    $1,%r12b
    26a4:	and    $0x1,%r8d
    26a8:	add    %rcx,%r8
    26ab:	mov    %r8,%rax
    26ae:	mul    %r10
    26b1:	shr    $1,%rdx
    26b4:	lea    (%rdx,%rdx,2),%rax
    26b8:	sub    %rax,%r8
    26bb:	movzbl %r12b,%ecx
    26bf:	add    %r8,%rcx
    26c2:	mov    %rcx,%rax
    26c5:	mul    %r11
    26c8:	lea    (%rdx,%rdx,2),%rax
    26cc:	sub    %rax,%rcx
    26cf:	movzbl %r15b,%r8d
    26d3:	add    %rcx,%r8
    26d6:	mov    %r8,%rax
    26d9:	mul    %r11
    26dc:	lea    (%rdx,%rdx,2),%rax
    26e0:	sub    %rax,%r8
    26e3:	movzbl %bpl,%ecx
    26e7:	add    %r8,%rcx
    26ea:	mov    %rcx,%rax
    26ed:	mul    %r11
    26f0:	lea    (%rdx,%rdx,2),%rax
    26f4:	sub    %rax,%rcx
    26f7:	add    $0x4,%rbx
    26fb:	add    $0xfffffffffffffffc,%r14
    26ff:	jne    2670 <loop_zero_bool_baseline_d3+0x60>
    2705:	test   %r9,%r9
    2708:	je     272f <loop_zero_bool_baseline_d3+0x11f>
    270a:	add    %rsi,%rdi
    270d:	nopl   (%rax)
    2710:	cmpb   $0x1,(%rdi)
    2713:	sbb    $0xffffffffffffffff,%rcx
    2717:	mov    %rcx,%rax
    271a:	mul    %r10
    271d:	shr    $1,%rdx
    2720:	lea    (%rdx,%rdx,2),%rax
    2724:	sub    %rax,%rcx
    2727:	inc    %rdi
    272a:	dec    %r9
    272d:	jne    2710 <loop_zero_bool_baseline_d3+0x100>
    272f:	pop    %rbx
    2730:	pop    %r12
    2732:	pop    %r14
    2734:	pop    %r15
    2736:	pop    %rbp
    2737:	mov    %rcx,%rax
    273a:	ret
