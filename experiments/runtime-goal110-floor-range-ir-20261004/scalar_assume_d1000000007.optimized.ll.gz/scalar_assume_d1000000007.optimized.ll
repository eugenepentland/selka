define range(i64 0, 1000000007) i64 @scalar_assume_d1000000007(i64 %value) local_unnamed_addr #3 {
entry:
  %rem = srem i64 %value, 1000000007
  %isneg = icmp slt i64 %rem, 0
  %delta = select i1 %isneg, i64 1000000007, i64 0
  %result = add nsw i64 %delta, %rem
  %bounded = icmp ult i64 %result, 1000000007
  tail call void @llvm.assume(i1 %bounded)
  ret i64 %result
}
