
/home/epentland/ai/canopy/mylang-worktrees/goal110-equality-bounded-20261004/.mylang-cache/goal110-floor-range-ir/floor-range.so:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .text:

00000000000023d0 <scalar_baseline_d1000000007>:
    23d0:	movabs $0x89705f3112a28fe5,%rcx
    23da:	mov    %rdi,%rax
    23dd:	imul   %rcx
    23e0:	add    %rdi,%rdx
    23e3:	mov    %rdx,%rax
    23e6:	shr    $0x3f,%rax
    23ea:	sar    $0x1d,%rdx
    23ee:	add    %rax,%rdx
    23f1:	imul   $0x3b9aca07,%rdx,%rax
    23f8:	sub    %rax,%rdi
    23fb:	mov    %rdi,%rax
    23fe:	sar    $0x3f,%rax
    2402:	and    $0x3b9aca07,%eax
    2407:	add    %rdi,%rax
    240a:	ret
