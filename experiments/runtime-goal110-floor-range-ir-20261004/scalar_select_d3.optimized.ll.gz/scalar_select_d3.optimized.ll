define range(i64 -2, 6) i64 @scalar_select_d3(i64 %value) local_unnamed_addr #2 {
entry:
  %rem = srem i64 %value, 3
  %negative = icmp slt i64 %rem, 0
  %shifted = add nsw i64 %rem, 3
  %result = select i1 %negative, i64 %shifted, i64 %rem
  ret i64 %result
}
