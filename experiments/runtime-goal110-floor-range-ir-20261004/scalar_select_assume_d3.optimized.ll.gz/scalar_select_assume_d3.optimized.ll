define range(i64 0, 3) i64 @scalar_select_assume_d3(i64 %value) local_unnamed_addr #3 {
entry:
  %rem = srem i64 %value, 3
  %negative = icmp slt i64 %rem, 0
  %shifted = add nsw i64 %rem, 3
  %result = select i1 %negative, i64 %shifted, i64 %rem
  %bounded = icmp ult i64 %result, 3
  tail call void @llvm.assume(i1 %bounded)
  ret i64 %result
}
