
/home/epentland/ai/canopy/mylang-worktrees/goal110-equality-bounded-20261004/.mylang-cache/goal110-floor-range-ir/floor-range.so:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .text:

00000000000038b0 <loop_zero_bool_assume_d9223372036854775807>:
    38b0:	movl   $0x0,(%rcx)
    38b6:	test   %rsi,%rsi
    38b9:	je     392c <loop_zero_bool_assume_d9223372036854775807+0x7c>
    38bb:	movabs $0x7fffffffffffffff,%r9
    38c5:	xor    %eax,%eax
    38c7:	movabs $0x4000000000000001,%r10
    38d1:	cs nopw 0x0(%rax,%rax,1)
    38db:	nopl   0x0(%rax,%rax,1)
    38e0:	xor    %r8d,%r8d
    38e3:	cmpb   $0x0,(%rdi)
    38e6:	setne  %r8b
    38ea:	add    %rax,%r8
    38ed:	jo     3926 <loop_zero_bool_assume_d9223372036854775807+0x76>
    38ef:	mov    %r8,%rax
    38f2:	imul   %r10
    38f5:	mov    %rdx,%rax
    38f8:	shr    $0x3f,%rax
    38fc:	sar    $0x3d,%rdx
    3900:	add    %rax,%rdx
    3903:	mov    %rdx,%r11
    3906:	shl    $0x3f,%r11
    390a:	add    %rdx,%r11
    390d:	add    %r8,%r11
    3910:	mov    %r11,%rax
    3913:	sar    $0x3f,%rax
    3917:	and    %r9,%rax
    391a:	add    %r11,%rax
    391d:	inc    %rdi
    3920:	dec    %rsi
    3923:	jne    38e0 <loop_zero_bool_assume_d9223372036854775807+0x30>
    3925:	ret
    3926:	movl   $0x1,(%rcx)
    392c:	xor    %eax,%eax
    392e:	ret
