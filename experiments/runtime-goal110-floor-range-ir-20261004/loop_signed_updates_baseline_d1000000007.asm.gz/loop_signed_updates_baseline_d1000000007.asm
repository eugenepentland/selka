
/home/epentland/ai/canopy/mylang-worktrees/goal110-equality-bounded-20261004/.mylang-cache/goal110-floor-range-ir/floor-range.so:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .text:

0000000000003650 <loop_signed_updates_baseline_d1000000007>:
    3650:	movl   $0x0,(%rcx)
    3656:	test   %rsi,%rsi
    3659:	je     36b8 <loop_signed_updates_baseline_d1000000007+0x68>
    365b:	xor    %r8d,%r8d
    365e:	movabs $0x89705f3112a28fe5,%r9
    3668:	nopl   0x0(%rax,%rax,1)
    3670:	add    (%rdi),%r8
    3673:	jo     36b2 <loop_signed_updates_baseline_d1000000007+0x62>
    3675:	mov    %r8,%rax
    3678:	imul   %r9
    367b:	add    %r8,%rdx
    367e:	mov    %rdx,%rax
    3681:	shr    $0x3f,%rax
    3685:	sar    $0x1d,%rdx
    3689:	add    %rax,%rdx
    368c:	imul   $0x3b9aca07,%rdx,%rax
    3693:	sub    %rax,%r8
    3696:	mov    %r8,%rax
    3699:	sar    $0x3f,%rax
    369d:	and    $0x3b9aca07,%eax
    36a2:	add    %r8,%rax
    36a5:	add    $0x8,%rdi
    36a9:	dec    %rsi
    36ac:	mov    %rax,%r8
    36af:	jne    3670 <loop_signed_updates_baseline_d1000000007+0x20>
    36b1:	ret
    36b2:	movl   $0x1,(%rcx)
    36b8:	xor    %eax,%eax
    36ba:	ret
