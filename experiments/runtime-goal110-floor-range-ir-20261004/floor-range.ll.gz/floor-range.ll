; Isolated experiment. No production or benchmark changes.
; Positive literal divisors; assumptions only after floor correction.
declare void @llvm.assume(i1)
declare {i64, i1} @llvm.sadd.with.overflow.i64(i64, i64)

define i64 @scalar_baseline_d1(i64 %value) nounwind noinline {
entry:
  %rem = srem i64 %value, 1
  %nonzero = icmp ne i64 %rem, 0
  %difference = xor i64 %rem, 1
  %negative = icmp slt i64 %difference, 0
  %condition = and i1 %nonzero, %negative
  %wide = zext i1 %condition to i64
  %mask = sub i64 0, %wide
  %delta = and i64 1, %mask
  %result = add i64 %rem, %delta
  ret i64 %result
}

define i64 @scalar_assume_d1(i64 %value) nounwind noinline {
entry:
  %rem = srem i64 %value, 1
  %nonzero = icmp ne i64 %rem, 0
  %difference = xor i64 %rem, 1
  %negative = icmp slt i64 %difference, 0
  %condition = and i1 %nonzero, %negative
  %wide = zext i1 %condition to i64
  %mask = sub i64 0, %wide
  %delta = and i64 1, %mask
  %result = add i64 %rem, %delta
  %bounded = icmp ult i64 %result, 1
  call void @llvm.assume(i1 %bounded)
  ret i64 %result
}

define i64 @scalar_select_d1(i64 %value) nounwind noinline {
entry:
  %rem = srem i64 %value, 1
  %nonzero = icmp ne i64 %rem, 0
  %difference = xor i64 %rem, 1
  %negative = icmp slt i64 %difference, 0
  %condition = and i1 %nonzero, %negative
  %shifted = add i64 %rem, 1
  %result = select i1 %condition, i64 %shifted, i64 %rem
  ret i64 %result
}

define i64 @scalar_select_assume_d1(i64 %value) nounwind noinline {
entry:
  %rem = srem i64 %value, 1
  %nonzero = icmp ne i64 %rem, 0
  %difference = xor i64 %rem, 1
  %negative = icmp slt i64 %difference, 0
  %condition = and i1 %nonzero, %negative
  %shifted = add i64 %rem, 1
  %result = select i1 %condition, i64 %shifted, i64 %rem
  %bounded = icmp ult i64 %result, 1
  call void @llvm.assume(i1 %bounded)
  ret i64 %result
}

define i64 @scalar_baseline_d2(i64 %value) nounwind noinline {
entry:
  %rem = srem i64 %value, 2
  %nonzero = icmp ne i64 %rem, 0
  %difference = xor i64 %rem, 2
  %negative = icmp slt i64 %difference, 0
  %condition = and i1 %nonzero, %negative
  %wide = zext i1 %condition to i64
  %mask = sub i64 0, %wide
  %delta = and i64 2, %mask
  %result = add i64 %rem, %delta
  ret i64 %result
}

define i64 @scalar_assume_d2(i64 %value) nounwind noinline {
entry:
  %rem = srem i64 %value, 2
  %nonzero = icmp ne i64 %rem, 0
  %difference = xor i64 %rem, 2
  %negative = icmp slt i64 %difference, 0
  %condition = and i1 %nonzero, %negative
  %wide = zext i1 %condition to i64
  %mask = sub i64 0, %wide
  %delta = and i64 2, %mask
  %result = add i64 %rem, %delta
  %bounded = icmp ult i64 %result, 2
  call void @llvm.assume(i1 %bounded)
  ret i64 %result
}

define i64 @scalar_select_d2(i64 %value) nounwind noinline {
entry:
  %rem = srem i64 %value, 2
  %nonzero = icmp ne i64 %rem, 0
  %difference = xor i64 %rem, 2
  %negative = icmp slt i64 %difference, 0
  %condition = and i1 %nonzero, %negative
  %shifted = add i64 %rem, 2
  %result = select i1 %condition, i64 %shifted, i64 %rem
  ret i64 %result
}

define i64 @scalar_select_assume_d2(i64 %value) nounwind noinline {
entry:
  %rem = srem i64 %value, 2
  %nonzero = icmp ne i64 %rem, 0
  %difference = xor i64 %rem, 2
  %negative = icmp slt i64 %difference, 0
  %condition = and i1 %nonzero, %negative
  %shifted = add i64 %rem, 2
  %result = select i1 %condition, i64 %shifted, i64 %rem
  %bounded = icmp ult i64 %result, 2
  call void @llvm.assume(i1 %bounded)
  ret i64 %result
}

define i64 @scalar_baseline_d3(i64 %value) nounwind noinline {
entry:
  %rem = srem i64 %value, 3
  %nonzero = icmp ne i64 %rem, 0
  %difference = xor i64 %rem, 3
  %negative = icmp slt i64 %difference, 0
  %condition = and i1 %nonzero, %negative
  %wide = zext i1 %condition to i64
  %mask = sub i64 0, %wide
  %delta = and i64 3, %mask
  %result = add i64 %rem, %delta
  ret i64 %result
}

define i64 @scalar_assume_d3(i64 %value) nounwind noinline {
entry:
  %rem = srem i64 %value, 3
  %nonzero = icmp ne i64 %rem, 0
  %difference = xor i64 %rem, 3
  %negative = icmp slt i64 %difference, 0
  %condition = and i1 %nonzero, %negative
  %wide = zext i1 %condition to i64
  %mask = sub i64 0, %wide
  %delta = and i64 3, %mask
  %result = add i64 %rem, %delta
  %bounded = icmp ult i64 %result, 3
  call void @llvm.assume(i1 %bounded)
  ret i64 %result
}

define i64 @scalar_select_d3(i64 %value) nounwind noinline {
entry:
  %rem = srem i64 %value, 3
  %nonzero = icmp ne i64 %rem, 0
  %difference = xor i64 %rem, 3
  %negative = icmp slt i64 %difference, 0
  %condition = and i1 %nonzero, %negative
  %shifted = add i64 %rem, 3
  %result = select i1 %condition, i64 %shifted, i64 %rem
  ret i64 %result
}

define i64 @scalar_select_assume_d3(i64 %value) nounwind noinline {
entry:
  %rem = srem i64 %value, 3
  %nonzero = icmp ne i64 %rem, 0
  %difference = xor i64 %rem, 3
  %negative = icmp slt i64 %difference, 0
  %condition = and i1 %nonzero, %negative
  %shifted = add i64 %rem, 3
  %result = select i1 %condition, i64 %shifted, i64 %rem
  %bounded = icmp ult i64 %result, 3
  call void @llvm.assume(i1 %bounded)
  ret i64 %result
}

define i64 @scalar_baseline_d1000000007(i64 %value) nounwind noinline {
entry:
  %rem = srem i64 %value, 1000000007
  %nonzero = icmp ne i64 %rem, 0
  %difference = xor i64 %rem, 1000000007
  %negative = icmp slt i64 %difference, 0
  %condition = and i1 %nonzero, %negative
  %wide = zext i1 %condition to i64
  %mask = sub i64 0, %wide
  %delta = and i64 1000000007, %mask
  %result = add i64 %rem, %delta
  ret i64 %result
}

define i64 @scalar_assume_d1000000007(i64 %value) nounwind noinline {
entry:
  %rem = srem i64 %value, 1000000007
  %nonzero = icmp ne i64 %rem, 0
  %difference = xor i64 %rem, 1000000007
  %negative = icmp slt i64 %difference, 0
  %condition = and i1 %nonzero, %negative
  %wide = zext i1 %condition to i64
  %mask = sub i64 0, %wide
  %delta = and i64 1000000007, %mask
  %result = add i64 %rem, %delta
  %bounded = icmp ult i64 %result, 1000000007
  call void @llvm.assume(i1 %bounded)
  ret i64 %result
}

define i64 @scalar_select_d1000000007(i64 %value) nounwind noinline {
entry:
  %rem = srem i64 %value, 1000000007
  %nonzero = icmp ne i64 %rem, 0
  %difference = xor i64 %rem, 1000000007
  %negative = icmp slt i64 %difference, 0
  %condition = and i1 %nonzero, %negative
  %shifted = add i64 %rem, 1000000007
  %result = select i1 %condition, i64 %shifted, i64 %rem
  ret i64 %result
}

define i64 @scalar_select_assume_d1000000007(i64 %value) nounwind noinline {
entry:
  %rem = srem i64 %value, 1000000007
  %nonzero = icmp ne i64 %rem, 0
  %difference = xor i64 %rem, 1000000007
  %negative = icmp slt i64 %difference, 0
  %condition = and i1 %nonzero, %negative
  %shifted = add i64 %rem, 1000000007
  %result = select i1 %condition, i64 %shifted, i64 %rem
  %bounded = icmp ult i64 %result, 1000000007
  call void @llvm.assume(i1 %bounded)
  ret i64 %result
}

define i64 @scalar_baseline_d9223372036854775807(i64 %value) nounwind noinline {
entry:
  %rem = srem i64 %value, 9223372036854775807
  %nonzero = icmp ne i64 %rem, 0
  %difference = xor i64 %rem, 9223372036854775807
  %negative = icmp slt i64 %difference, 0
  %condition = and i1 %nonzero, %negative
  %wide = zext i1 %condition to i64
  %mask = sub i64 0, %wide
  %delta = and i64 9223372036854775807, %mask
  %result = add i64 %rem, %delta
  ret i64 %result
}

define i64 @scalar_assume_d9223372036854775807(i64 %value) nounwind noinline {
entry:
  %rem = srem i64 %value, 9223372036854775807
  %nonzero = icmp ne i64 %rem, 0
  %difference = xor i64 %rem, 9223372036854775807
  %negative = icmp slt i64 %difference, 0
  %condition = and i1 %nonzero, %negative
  %wide = zext i1 %condition to i64
  %mask = sub i64 0, %wide
  %delta = and i64 9223372036854775807, %mask
  %result = add i64 %rem, %delta
  %bounded = icmp ult i64 %result, 9223372036854775807
  call void @llvm.assume(i1 %bounded)
  ret i64 %result
}

define i64 @scalar_select_d9223372036854775807(i64 %value) nounwind noinline {
entry:
  %rem = srem i64 %value, 9223372036854775807
  %nonzero = icmp ne i64 %rem, 0
  %difference = xor i64 %rem, 9223372036854775807
  %negative = icmp slt i64 %difference, 0
  %condition = and i1 %nonzero, %negative
  %shifted = add i64 %rem, 9223372036854775807
  %result = select i1 %condition, i64 %shifted, i64 %rem
  ret i64 %result
}

define i64 @scalar_select_assume_d9223372036854775807(i64 %value) nounwind noinline {
entry:
  %rem = srem i64 %value, 9223372036854775807
  %nonzero = icmp ne i64 %rem, 0
  %difference = xor i64 %rem, 9223372036854775807
  %negative = icmp slt i64 %difference, 0
  %condition = and i1 %nonzero, %negative
  %shifted = add i64 %rem, 9223372036854775807
  %result = select i1 %condition, i64 %shifted, i64 %rem
  %bounded = icmp ult i64 %result, 9223372036854775807
  call void @llvm.assume(i1 %bounded)
  ret i64 %result
}

define i64 @loop_zero_bool_baseline_d3(ptr %data, i64 %count, i64 %seed, ptr %status) nounwind noinline {
entry:
  store i32 0, ptr %status, align 4
  %empty = icmp eq i64 %count, 0
  br i1 %empty, label %empty_exit, label %loop
empty_exit:
  ret i64 0
loop:
  %index = phi i64 [0, %entry], [%next, %success]
  %checksum = phi i64 [0, %entry], [%result, %success]
  %address = getelementptr i8, ptr %data, i64 %index
  %flag = load i8, ptr %address, align 1
  %truth = icmp ne i8 %flag, 0
  %increment = zext i1 %truth to i64
  %addition = call {i64, i1} @llvm.sadd.with.overflow.i64(i64 %checksum, i64 %increment)
  %sum = extractvalue {i64, i1} %addition, 0
  %overflow = extractvalue {i64, i1} %addition, 1
  br i1 %overflow, label %failure, label %success
failure:
  store i32 1, ptr %status, align 4
  ret i64 0
success:
  %rem = srem i64 %sum, 3
  %nonzero = icmp ne i64 %rem, 0
  %difference = xor i64 %rem, 3
  %negative = icmp slt i64 %difference, 0
  %condition = and i1 %nonzero, %negative
  %wide = zext i1 %condition to i64
  %mask = sub i64 0, %wide
  %delta = and i64 3, %mask
  %result = add i64 %rem, %delta
  %next = add i64 %index, 1
  %done = icmp eq i64 %next, %count
  br i1 %done, label %exit, label %loop
exit:
  ret i64 %result
}

define i64 @loop_zero_bool_assume_d3(ptr %data, i64 %count, i64 %seed, ptr %status) nounwind noinline {
entry:
  store i32 0, ptr %status, align 4
  %empty = icmp eq i64 %count, 0
  br i1 %empty, label %empty_exit, label %loop
empty_exit:
  ret i64 0
loop:
  %index = phi i64 [0, %entry], [%next, %success]
  %checksum = phi i64 [0, %entry], [%result, %success]
  %address = getelementptr i8, ptr %data, i64 %index
  %flag = load i8, ptr %address, align 1
  %truth = icmp ne i8 %flag, 0
  %increment = zext i1 %truth to i64
  %addition = call {i64, i1} @llvm.sadd.with.overflow.i64(i64 %checksum, i64 %increment)
  %sum = extractvalue {i64, i1} %addition, 0
  %overflow = extractvalue {i64, i1} %addition, 1
  br i1 %overflow, label %failure, label %success
failure:
  store i32 1, ptr %status, align 4
  ret i64 0
success:
  %rem = srem i64 %sum, 3
  %nonzero = icmp ne i64 %rem, 0
  %difference = xor i64 %rem, 3
  %negative = icmp slt i64 %difference, 0
  %condition = and i1 %nonzero, %negative
  %wide = zext i1 %condition to i64
  %mask = sub i64 0, %wide
  %delta = and i64 3, %mask
  %result = add i64 %rem, %delta
  %bounded = icmp ult i64 %result, 3
  call void @llvm.assume(i1 %bounded)
  %next = add i64 %index, 1
  %done = icmp eq i64 %next, %count
  br i1 %done, label %exit, label %loop
exit:
  ret i64 %result
}

define i64 @loop_zero_bool_select_d3(ptr %data, i64 %count, i64 %seed, ptr %status) nounwind noinline {
entry:
  store i32 0, ptr %status, align 4
  %empty = icmp eq i64 %count, 0
  br i1 %empty, label %empty_exit, label %loop
empty_exit:
  ret i64 0
loop:
  %index = phi i64 [0, %entry], [%next, %success]
  %checksum = phi i64 [0, %entry], [%result, %success]
  %address = getelementptr i8, ptr %data, i64 %index
  %flag = load i8, ptr %address, align 1
  %truth = icmp ne i8 %flag, 0
  %increment = zext i1 %truth to i64
  %addition = call {i64, i1} @llvm.sadd.with.overflow.i64(i64 %checksum, i64 %increment)
  %sum = extractvalue {i64, i1} %addition, 0
  %overflow = extractvalue {i64, i1} %addition, 1
  br i1 %overflow, label %failure, label %success
failure:
  store i32 1, ptr %status, align 4
  ret i64 0
success:
  %rem = srem i64 %sum, 3
  %nonzero = icmp ne i64 %rem, 0
  %difference = xor i64 %rem, 3
  %negative = icmp slt i64 %difference, 0
  %condition = and i1 %nonzero, %negative
  %shifted = add i64 %rem, 3
  %result = select i1 %condition, i64 %shifted, i64 %rem
  %next = add i64 %index, 1
  %done = icmp eq i64 %next, %count
  br i1 %done, label %exit, label %loop
exit:
  ret i64 %result
}

define i64 @loop_zero_bool_select_assume_d3(ptr %data, i64 %count, i64 %seed, ptr %status) nounwind noinline {
entry:
  store i32 0, ptr %status, align 4
  %empty = icmp eq i64 %count, 0
  br i1 %empty, label %empty_exit, label %loop
empty_exit:
  ret i64 0
loop:
  %index = phi i64 [0, %entry], [%next, %success]
  %checksum = phi i64 [0, %entry], [%result, %success]
  %address = getelementptr i8, ptr %data, i64 %index
  %flag = load i8, ptr %address, align 1
  %truth = icmp ne i8 %flag, 0
  %increment = zext i1 %truth to i64
  %addition = call {i64, i1} @llvm.sadd.with.overflow.i64(i64 %checksum, i64 %increment)
  %sum = extractvalue {i64, i1} %addition, 0
  %overflow = extractvalue {i64, i1} %addition, 1
  br i1 %overflow, label %failure, label %success
failure:
  store i32 1, ptr %status, align 4
  ret i64 0
success:
  %rem = srem i64 %sum, 3
  %nonzero = icmp ne i64 %rem, 0
  %difference = xor i64 %rem, 3
  %negative = icmp slt i64 %difference, 0
  %condition = and i1 %nonzero, %negative
  %shifted = add i64 %rem, 3
  %result = select i1 %condition, i64 %shifted, i64 %rem
  %bounded = icmp ult i64 %result, 3
  call void @llvm.assume(i1 %bounded)
  %next = add i64 %index, 1
  %done = icmp eq i64 %next, %count
  br i1 %done, label %exit, label %loop
exit:
  ret i64 %result
}

define i64 @loop_seeded_bool_baseline_d3(ptr %data, i64 %count, i64 %seed, ptr %status) nounwind noinline {
entry:
  store i32 0, ptr %status, align 4
  %empty = icmp eq i64 %count, 0
  br i1 %empty, label %empty_exit, label %loop
empty_exit:
  ret i64 %seed
loop:
  %index = phi i64 [0, %entry], [%next, %success]
  %checksum = phi i64 [%seed, %entry], [%result, %success]
  %address = getelementptr i8, ptr %data, i64 %index
  %flag = load i8, ptr %address, align 1
  %truth = icmp ne i8 %flag, 0
  %increment = zext i1 %truth to i64
  %addition = call {i64, i1} @llvm.sadd.with.overflow.i64(i64 %checksum, i64 %increment)
  %sum = extractvalue {i64, i1} %addition, 0
  %overflow = extractvalue {i64, i1} %addition, 1
  br i1 %overflow, label %failure, label %success
failure:
  store i32 1, ptr %status, align 4
  ret i64 0
success:
  %rem = srem i64 %sum, 3
  %nonzero = icmp ne i64 %rem, 0
  %difference = xor i64 %rem, 3
  %negative = icmp slt i64 %difference, 0
  %condition = and i1 %nonzero, %negative
  %wide = zext i1 %condition to i64
  %mask = sub i64 0, %wide
  %delta = and i64 3, %mask
  %result = add i64 %rem, %delta
  %next = add i64 %index, 1
  %done = icmp eq i64 %next, %count
  br i1 %done, label %exit, label %loop
exit:
  ret i64 %result
}

define i64 @loop_seeded_bool_assume_d3(ptr %data, i64 %count, i64 %seed, ptr %status) nounwind noinline {
entry:
  store i32 0, ptr %status, align 4
  %empty = icmp eq i64 %count, 0
  br i1 %empty, label %empty_exit, label %loop
empty_exit:
  ret i64 %seed
loop:
  %index = phi i64 [0, %entry], [%next, %success]
  %checksum = phi i64 [%seed, %entry], [%result, %success]
  %address = getelementptr i8, ptr %data, i64 %index
  %flag = load i8, ptr %address, align 1
  %truth = icmp ne i8 %flag, 0
  %increment = zext i1 %truth to i64
  %addition = call {i64, i1} @llvm.sadd.with.overflow.i64(i64 %checksum, i64 %increment)
  %sum = extractvalue {i64, i1} %addition, 0
  %overflow = extractvalue {i64, i1} %addition, 1
  br i1 %overflow, label %failure, label %success
failure:
  store i32 1, ptr %status, align 4
  ret i64 0
success:
  %rem = srem i64 %sum, 3
  %nonzero = icmp ne i64 %rem, 0
  %difference = xor i64 %rem, 3
  %negative = icmp slt i64 %difference, 0
  %condition = and i1 %nonzero, %negative
  %wide = zext i1 %condition to i64
  %mask = sub i64 0, %wide
  %delta = and i64 3, %mask
  %result = add i64 %rem, %delta
  %bounded = icmp ult i64 %result, 3
  call void @llvm.assume(i1 %bounded)
  %next = add i64 %index, 1
  %done = icmp eq i64 %next, %count
  br i1 %done, label %exit, label %loop
exit:
  ret i64 %result
}

define i64 @loop_seeded_bool_select_d3(ptr %data, i64 %count, i64 %seed, ptr %status) nounwind noinline {
entry:
  store i32 0, ptr %status, align 4
  %empty = icmp eq i64 %count, 0
  br i1 %empty, label %empty_exit, label %loop
empty_exit:
  ret i64 %seed
loop:
  %index = phi i64 [0, %entry], [%next, %success]
  %checksum = phi i64 [%seed, %entry], [%result, %success]
  %address = getelementptr i8, ptr %data, i64 %index
  %flag = load i8, ptr %address, align 1
  %truth = icmp ne i8 %flag, 0
  %increment = zext i1 %truth to i64
  %addition = call {i64, i1} @llvm.sadd.with.overflow.i64(i64 %checksum, i64 %increment)
  %sum = extractvalue {i64, i1} %addition, 0
  %overflow = extractvalue {i64, i1} %addition, 1
  br i1 %overflow, label %failure, label %success
failure:
  store i32 1, ptr %status, align 4
  ret i64 0
success:
  %rem = srem i64 %sum, 3
  %nonzero = icmp ne i64 %rem, 0
  %difference = xor i64 %rem, 3
  %negative = icmp slt i64 %difference, 0
  %condition = and i1 %nonzero, %negative
  %shifted = add i64 %rem, 3
  %result = select i1 %condition, i64 %shifted, i64 %rem
  %next = add i64 %index, 1
  %done = icmp eq i64 %next, %count
  br i1 %done, label %exit, label %loop
exit:
  ret i64 %result
}

define i64 @loop_seeded_bool_select_assume_d3(ptr %data, i64 %count, i64 %seed, ptr %status) nounwind noinline {
entry:
  store i32 0, ptr %status, align 4
  %empty = icmp eq i64 %count, 0
  br i1 %empty, label %empty_exit, label %loop
empty_exit:
  ret i64 %seed
loop:
  %index = phi i64 [0, %entry], [%next, %success]
  %checksum = phi i64 [%seed, %entry], [%result, %success]
  %address = getelementptr i8, ptr %data, i64 %index
  %flag = load i8, ptr %address, align 1
  %truth = icmp ne i8 %flag, 0
  %increment = zext i1 %truth to i64
  %addition = call {i64, i1} @llvm.sadd.with.overflow.i64(i64 %checksum, i64 %increment)
  %sum = extractvalue {i64, i1} %addition, 0
  %overflow = extractvalue {i64, i1} %addition, 1
  br i1 %overflow, label %failure, label %success
failure:
  store i32 1, ptr %status, align 4
  ret i64 0
success:
  %rem = srem i64 %sum, 3
  %nonzero = icmp ne i64 %rem, 0
  %difference = xor i64 %rem, 3
  %negative = icmp slt i64 %difference, 0
  %condition = and i1 %nonzero, %negative
  %shifted = add i64 %rem, 3
  %result = select i1 %condition, i64 %shifted, i64 %rem
  %bounded = icmp ult i64 %result, 3
  call void @llvm.assume(i1 %bounded)
  %next = add i64 %index, 1
  %done = icmp eq i64 %next, %count
  br i1 %done, label %exit, label %loop
exit:
  ret i64 %result
}

define i64 @loop_signed_updates_baseline_d3(ptr %data, i64 %count, i64 %seed, ptr %status) nounwind noinline {
entry:
  store i32 0, ptr %status, align 4
  %empty = icmp eq i64 %count, 0
  br i1 %empty, label %empty_exit, label %loop
empty_exit:
  ret i64 0
loop:
  %index = phi i64 [0, %entry], [%next, %success]
  %checksum = phi i64 [0, %entry], [%result, %success]
  %address = getelementptr i64, ptr %data, i64 %index
  %increment = load i64, ptr %address, align 8
  %addition = call {i64, i1} @llvm.sadd.with.overflow.i64(i64 %checksum, i64 %increment)
  %sum = extractvalue {i64, i1} %addition, 0
  %overflow = extractvalue {i64, i1} %addition, 1
  br i1 %overflow, label %failure, label %success
failure:
  store i32 1, ptr %status, align 4
  ret i64 0
success:
  %rem = srem i64 %sum, 3
  %nonzero = icmp ne i64 %rem, 0
  %difference = xor i64 %rem, 3
  %negative = icmp slt i64 %difference, 0
  %condition = and i1 %nonzero, %negative
  %wide = zext i1 %condition to i64
  %mask = sub i64 0, %wide
  %delta = and i64 3, %mask
  %result = add i64 %rem, %delta
  %next = add i64 %index, 1
  %done = icmp eq i64 %next, %count
  br i1 %done, label %exit, label %loop
exit:
  ret i64 %result
}

define i64 @loop_signed_updates_assume_d3(ptr %data, i64 %count, i64 %seed, ptr %status) nounwind noinline {
entry:
  store i32 0, ptr %status, align 4
  %empty = icmp eq i64 %count, 0
  br i1 %empty, label %empty_exit, label %loop
empty_exit:
  ret i64 0
loop:
  %index = phi i64 [0, %entry], [%next, %success]
  %checksum = phi i64 [0, %entry], [%result, %success]
  %address = getelementptr i64, ptr %data, i64 %index
  %increment = load i64, ptr %address, align 8
  %addition = call {i64, i1} @llvm.sadd.with.overflow.i64(i64 %checksum, i64 %increment)
  %sum = extractvalue {i64, i1} %addition, 0
  %overflow = extractvalue {i64, i1} %addition, 1
  br i1 %overflow, label %failure, label %success
failure:
  store i32 1, ptr %status, align 4
  ret i64 0
success:
  %rem = srem i64 %sum, 3
  %nonzero = icmp ne i64 %rem, 0
  %difference = xor i64 %rem, 3
  %negative = icmp slt i64 %difference, 0
  %condition = and i1 %nonzero, %negative
  %wide = zext i1 %condition to i64
  %mask = sub i64 0, %wide
  %delta = and i64 3, %mask
  %result = add i64 %rem, %delta
  %bounded = icmp ult i64 %result, 3
  call void @llvm.assume(i1 %bounded)
  %next = add i64 %index, 1
  %done = icmp eq i64 %next, %count
  br i1 %done, label %exit, label %loop
exit:
  ret i64 %result
}

define i64 @loop_signed_updates_select_d3(ptr %data, i64 %count, i64 %seed, ptr %status) nounwind noinline {
entry:
  store i32 0, ptr %status, align 4
  %empty = icmp eq i64 %count, 0
  br i1 %empty, label %empty_exit, label %loop
empty_exit:
  ret i64 0
loop:
  %index = phi i64 [0, %entry], [%next, %success]
  %checksum = phi i64 [0, %entry], [%result, %success]
  %address = getelementptr i64, ptr %data, i64 %index
  %increment = load i64, ptr %address, align 8
  %addition = call {i64, i1} @llvm.sadd.with.overflow.i64(i64 %checksum, i64 %increment)
  %sum = extractvalue {i64, i1} %addition, 0
  %overflow = extractvalue {i64, i1} %addition, 1
  br i1 %overflow, label %failure, label %success
failure:
  store i32 1, ptr %status, align 4
  ret i64 0
success:
  %rem = srem i64 %sum, 3
  %nonzero = icmp ne i64 %rem, 0
  %difference = xor i64 %rem, 3
  %negative = icmp slt i64 %difference, 0
  %condition = and i1 %nonzero, %negative
  %shifted = add i64 %rem, 3
  %result = select i1 %condition, i64 %shifted, i64 %rem
  %next = add i64 %index, 1
  %done = icmp eq i64 %next, %count
  br i1 %done, label %exit, label %loop
exit:
  ret i64 %result
}

define i64 @loop_signed_updates_select_assume_d3(ptr %data, i64 %count, i64 %seed, ptr %status) nounwind noinline {
entry:
  store i32 0, ptr %status, align 4
  %empty = icmp eq i64 %count, 0
  br i1 %empty, label %empty_exit, label %loop
empty_exit:
  ret i64 0
loop:
  %index = phi i64 [0, %entry], [%next, %success]
  %checksum = phi i64 [0, %entry], [%result, %success]
  %address = getelementptr i64, ptr %data, i64 %index
  %increment = load i64, ptr %address, align 8
  %addition = call {i64, i1} @llvm.sadd.with.overflow.i64(i64 %checksum, i64 %increment)
  %sum = extractvalue {i64, i1} %addition, 0
  %overflow = extractvalue {i64, i1} %addition, 1
  br i1 %overflow, label %failure, label %success
failure:
  store i32 1, ptr %status, align 4
  ret i64 0
success:
  %rem = srem i64 %sum, 3
  %nonzero = icmp ne i64 %rem, 0
  %difference = xor i64 %rem, 3
  %negative = icmp slt i64 %difference, 0
  %condition = and i1 %nonzero, %negative
  %shifted = add i64 %rem, 3
  %result = select i1 %condition, i64 %shifted, i64 %rem
  %bounded = icmp ult i64 %result, 3
  call void @llvm.assume(i1 %bounded)
  %next = add i64 %index, 1
  %done = icmp eq i64 %next, %count
  br i1 %done, label %exit, label %loop
exit:
  ret i64 %result
}

define i64 @loop_zero_bool_baseline_d1000000007(ptr %data, i64 %count, i64 %seed, ptr %status) nounwind noinline {
entry:
  store i32 0, ptr %status, align 4
  %empty = icmp eq i64 %count, 0
  br i1 %empty, label %empty_exit, label %loop
empty_exit:
  ret i64 0
loop:
  %index = phi i64 [0, %entry], [%next, %success]
  %checksum = phi i64 [0, %entry], [%result, %success]
  %address = getelementptr i8, ptr %data, i64 %index
  %flag = load i8, ptr %address, align 1
  %truth = icmp ne i8 %flag, 0
  %increment = zext i1 %truth to i64
  %addition = call {i64, i1} @llvm.sadd.with.overflow.i64(i64 %checksum, i64 %increment)
  %sum = extractvalue {i64, i1} %addition, 0
  %overflow = extractvalue {i64, i1} %addition, 1
  br i1 %overflow, label %failure, label %success
failure:
  store i32 1, ptr %status, align 4
  ret i64 0
success:
  %rem = srem i64 %sum, 1000000007
  %nonzero = icmp ne i64 %rem, 0
  %difference = xor i64 %rem, 1000000007
  %negative = icmp slt i64 %difference, 0
  %condition = and i1 %nonzero, %negative
  %wide = zext i1 %condition to i64
  %mask = sub i64 0, %wide
  %delta = and i64 1000000007, %mask
  %result = add i64 %rem, %delta
  %next = add i64 %index, 1
  %done = icmp eq i64 %next, %count
  br i1 %done, label %exit, label %loop
exit:
  ret i64 %result
}

define i64 @loop_zero_bool_assume_d1000000007(ptr %data, i64 %count, i64 %seed, ptr %status) nounwind noinline {
entry:
  store i32 0, ptr %status, align 4
  %empty = icmp eq i64 %count, 0
  br i1 %empty, label %empty_exit, label %loop
empty_exit:
  ret i64 0
loop:
  %index = phi i64 [0, %entry], [%next, %success]
  %checksum = phi i64 [0, %entry], [%result, %success]
  %address = getelementptr i8, ptr %data, i64 %index
  %flag = load i8, ptr %address, align 1
  %truth = icmp ne i8 %flag, 0
  %increment = zext i1 %truth to i64
  %addition = call {i64, i1} @llvm.sadd.with.overflow.i64(i64 %checksum, i64 %increment)
  %sum = extractvalue {i64, i1} %addition, 0
  %overflow = extractvalue {i64, i1} %addition, 1
  br i1 %overflow, label %failure, label %success
failure:
  store i32 1, ptr %status, align 4
  ret i64 0
success:
  %rem = srem i64 %sum, 1000000007
  %nonzero = icmp ne i64 %rem, 0
  %difference = xor i64 %rem, 1000000007
  %negative = icmp slt i64 %difference, 0
  %condition = and i1 %nonzero, %negative
  %wide = zext i1 %condition to i64
  %mask = sub i64 0, %wide
  %delta = and i64 1000000007, %mask
  %result = add i64 %rem, %delta
  %bounded = icmp ult i64 %result, 1000000007
  call void @llvm.assume(i1 %bounded)
  %next = add i64 %index, 1
  %done = icmp eq i64 %next, %count
  br i1 %done, label %exit, label %loop
exit:
  ret i64 %result
}

define i64 @loop_zero_bool_select_d1000000007(ptr %data, i64 %count, i64 %seed, ptr %status) nounwind noinline {
entry:
  store i32 0, ptr %status, align 4
  %empty = icmp eq i64 %count, 0
  br i1 %empty, label %empty_exit, label %loop
empty_exit:
  ret i64 0
loop:
  %index = phi i64 [0, %entry], [%next, %success]
  %checksum = phi i64 [0, %entry], [%result, %success]
  %address = getelementptr i8, ptr %data, i64 %index
  %flag = load i8, ptr %address, align 1
  %truth = icmp ne i8 %flag, 0
  %increment = zext i1 %truth to i64
  %addition = call {i64, i1} @llvm.sadd.with.overflow.i64(i64 %checksum, i64 %increment)
  %sum = extractvalue {i64, i1} %addition, 0
  %overflow = extractvalue {i64, i1} %addition, 1
  br i1 %overflow, label %failure, label %success
failure:
  store i32 1, ptr %status, align 4
  ret i64 0
success:
  %rem = srem i64 %sum, 1000000007
  %nonzero = icmp ne i64 %rem, 0
  %difference = xor i64 %rem, 1000000007
  %negative = icmp slt i64 %difference, 0
  %condition = and i1 %nonzero, %negative
  %shifted = add i64 %rem, 1000000007
  %result = select i1 %condition, i64 %shifted, i64 %rem
  %next = add i64 %index, 1
  %done = icmp eq i64 %next, %count
  br i1 %done, label %exit, label %loop
exit:
  ret i64 %result
}

define i64 @loop_zero_bool_select_assume_d1000000007(ptr %data, i64 %count, i64 %seed, ptr %status) nounwind noinline {
entry:
  store i32 0, ptr %status, align 4
  %empty = icmp eq i64 %count, 0
  br i1 %empty, label %empty_exit, label %loop
empty_exit:
  ret i64 0
loop:
  %index = phi i64 [0, %entry], [%next, %success]
  %checksum = phi i64 [0, %entry], [%result, %success]
  %address = getelementptr i8, ptr %data, i64 %index
  %flag = load i8, ptr %address, align 1
  %truth = icmp ne i8 %flag, 0
  %increment = zext i1 %truth to i64
  %addition = call {i64, i1} @llvm.sadd.with.overflow.i64(i64 %checksum, i64 %increment)
  %sum = extractvalue {i64, i1} %addition, 0
  %overflow = extractvalue {i64, i1} %addition, 1
  br i1 %overflow, label %failure, label %success
failure:
  store i32 1, ptr %status, align 4
  ret i64 0
success:
  %rem = srem i64 %sum, 1000000007
  %nonzero = icmp ne i64 %rem, 0
  %difference = xor i64 %rem, 1000000007
  %negative = icmp slt i64 %difference, 0
  %condition = and i1 %nonzero, %negative
  %shifted = add i64 %rem, 1000000007
  %result = select i1 %condition, i64 %shifted, i64 %rem
  %bounded = icmp ult i64 %result, 1000000007
  call void @llvm.assume(i1 %bounded)
  %next = add i64 %index, 1
  %done = icmp eq i64 %next, %count
  br i1 %done, label %exit, label %loop
exit:
  ret i64 %result
}

define i64 @loop_seeded_bool_baseline_d1000000007(ptr %data, i64 %count, i64 %seed, ptr %status) nounwind noinline {
entry:
  store i32 0, ptr %status, align 4
  %empty = icmp eq i64 %count, 0
  br i1 %empty, label %empty_exit, label %loop
empty_exit:
  ret i64 %seed
loop:
  %index = phi i64 [0, %entry], [%next, %success]
  %checksum = phi i64 [%seed, %entry], [%result, %success]
  %address = getelementptr i8, ptr %data, i64 %index
  %flag = load i8, ptr %address, align 1
  %truth = icmp ne i8 %flag, 0
  %increment = zext i1 %truth to i64
  %addition = call {i64, i1} @llvm.sadd.with.overflow.i64(i64 %checksum, i64 %increment)
  %sum = extractvalue {i64, i1} %addition, 0
  %overflow = extractvalue {i64, i1} %addition, 1
  br i1 %overflow, label %failure, label %success
failure:
  store i32 1, ptr %status, align 4
  ret i64 0
success:
  %rem = srem i64 %sum, 1000000007
  %nonzero = icmp ne i64 %rem, 0
  %difference = xor i64 %rem, 1000000007
  %negative = icmp slt i64 %difference, 0
  %condition = and i1 %nonzero, %negative
  %wide = zext i1 %condition to i64
  %mask = sub i64 0, %wide
  %delta = and i64 1000000007, %mask
  %result = add i64 %rem, %delta
  %next = add i64 %index, 1
  %done = icmp eq i64 %next, %count
  br i1 %done, label %exit, label %loop
exit:
  ret i64 %result
}

define i64 @loop_seeded_bool_assume_d1000000007(ptr %data, i64 %count, i64 %seed, ptr %status) nounwind noinline {
entry:
  store i32 0, ptr %status, align 4
  %empty = icmp eq i64 %count, 0
  br i1 %empty, label %empty_exit, label %loop
empty_exit:
  ret i64 %seed
loop:
  %index = phi i64 [0, %entry], [%next, %success]
  %checksum = phi i64 [%seed, %entry], [%result, %success]
  %address = getelementptr i8, ptr %data, i64 %index
  %flag = load i8, ptr %address, align 1
  %truth = icmp ne i8 %flag, 0
  %increment = zext i1 %truth to i64
  %addition = call {i64, i1} @llvm.sadd.with.overflow.i64(i64 %checksum, i64 %increment)
  %sum = extractvalue {i64, i1} %addition, 0
  %overflow = extractvalue {i64, i1} %addition, 1
  br i1 %overflow, label %failure, label %success
failure:
  store i32 1, ptr %status, align 4
  ret i64 0
success:
  %rem = srem i64 %sum, 1000000007
  %nonzero = icmp ne i64 %rem, 0
  %difference = xor i64 %rem, 1000000007
  %negative = icmp slt i64 %difference, 0
  %condition = and i1 %nonzero, %negative
  %wide = zext i1 %condition to i64
  %mask = sub i64 0, %wide
  %delta = and i64 1000000007, %mask
  %result = add i64 %rem, %delta
  %bounded = icmp ult i64 %result, 1000000007
  call void @llvm.assume(i1 %bounded)
  %next = add i64 %index, 1
  %done = icmp eq i64 %next, %count
  br i1 %done, label %exit, label %loop
exit:
  ret i64 %result
}

define i64 @loop_seeded_bool_select_d1000000007(ptr %data, i64 %count, i64 %seed, ptr %status) nounwind noinline {
entry:
  store i32 0, ptr %status, align 4
  %empty = icmp eq i64 %count, 0
  br i1 %empty, label %empty_exit, label %loop
empty_exit:
  ret i64 %seed
loop:
  %index = phi i64 [0, %entry], [%next, %success]
  %checksum = phi i64 [%seed, %entry], [%result, %success]
  %address = getelementptr i8, ptr %data, i64 %index
  %flag = load i8, ptr %address, align 1
  %truth = icmp ne i8 %flag, 0
  %increment = zext i1 %truth to i64
  %addition = call {i64, i1} @llvm.sadd.with.overflow.i64(i64 %checksum, i64 %increment)
  %sum = extractvalue {i64, i1} %addition, 0
  %overflow = extractvalue {i64, i1} %addition, 1
  br i1 %overflow, label %failure, label %success
failure:
  store i32 1, ptr %status, align 4
  ret i64 0
success:
  %rem = srem i64 %sum, 1000000007
  %nonzero = icmp ne i64 %rem, 0
  %difference = xor i64 %rem, 1000000007
  %negative = icmp slt i64 %difference, 0
  %condition = and i1 %nonzero, %negative
  %shifted = add i64 %rem, 1000000007
  %result = select i1 %condition, i64 %shifted, i64 %rem
  %next = add i64 %index, 1
  %done = icmp eq i64 %next, %count
  br i1 %done, label %exit, label %loop
exit:
  ret i64 %result
}

define i64 @loop_seeded_bool_select_assume_d1000000007(ptr %data, i64 %count, i64 %seed, ptr %status) nounwind noinline {
entry:
  store i32 0, ptr %status, align 4
  %empty = icmp eq i64 %count, 0
  br i1 %empty, label %empty_exit, label %loop
empty_exit:
  ret i64 %seed
loop:
  %index = phi i64 [0, %entry], [%next, %success]
  %checksum = phi i64 [%seed, %entry], [%result, %success]
  %address = getelementptr i8, ptr %data, i64 %index
  %flag = load i8, ptr %address, align 1
  %truth = icmp ne i8 %flag, 0
  %increment = zext i1 %truth to i64
  %addition = call {i64, i1} @llvm.sadd.with.overflow.i64(i64 %checksum, i64 %increment)
  %sum = extractvalue {i64, i1} %addition, 0
  %overflow = extractvalue {i64, i1} %addition, 1
  br i1 %overflow, label %failure, label %success
failure:
  store i32 1, ptr %status, align 4
  ret i64 0
success:
  %rem = srem i64 %sum, 1000000007
  %nonzero = icmp ne i64 %rem, 0
  %difference = xor i64 %rem, 1000000007
  %negative = icmp slt i64 %difference, 0
  %condition = and i1 %nonzero, %negative
  %shifted = add i64 %rem, 1000000007
  %result = select i1 %condition, i64 %shifted, i64 %rem
  %bounded = icmp ult i64 %result, 1000000007
  call void @llvm.assume(i1 %bounded)
  %next = add i64 %index, 1
  %done = icmp eq i64 %next, %count
  br i1 %done, label %exit, label %loop
exit:
  ret i64 %result
}

define i64 @loop_signed_updates_baseline_d1000000007(ptr %data, i64 %count, i64 %seed, ptr %status) nounwind noinline {
entry:
  store i32 0, ptr %status, align 4
  %empty = icmp eq i64 %count, 0
  br i1 %empty, label %empty_exit, label %loop
empty_exit:
  ret i64 0
loop:
  %index = phi i64 [0, %entry], [%next, %success]
  %checksum = phi i64 [0, %entry], [%result, %success]
  %address = getelementptr i64, ptr %data, i64 %index
  %increment = load i64, ptr %address, align 8
  %addition = call {i64, i1} @llvm.sadd.with.overflow.i64(i64 %checksum, i64 %increment)
  %sum = extractvalue {i64, i1} %addition, 0
  %overflow = extractvalue {i64, i1} %addition, 1
  br i1 %overflow, label %failure, label %success
failure:
  store i32 1, ptr %status, align 4
  ret i64 0
success:
  %rem = srem i64 %sum, 1000000007
  %nonzero = icmp ne i64 %rem, 0
  %difference = xor i64 %rem, 1000000007
  %negative = icmp slt i64 %difference, 0
  %condition = and i1 %nonzero, %negative
  %wide = zext i1 %condition to i64
  %mask = sub i64 0, %wide
  %delta = and i64 1000000007, %mask
  %result = add i64 %rem, %delta
  %next = add i64 %index, 1
  %done = icmp eq i64 %next, %count
  br i1 %done, label %exit, label %loop
exit:
  ret i64 %result
}

define i64 @loop_signed_updates_assume_d1000000007(ptr %data, i64 %count, i64 %seed, ptr %status) nounwind noinline {
entry:
  store i32 0, ptr %status, align 4
  %empty = icmp eq i64 %count, 0
  br i1 %empty, label %empty_exit, label %loop
empty_exit:
  ret i64 0
loop:
  %index = phi i64 [0, %entry], [%next, %success]
  %checksum = phi i64 [0, %entry], [%result, %success]
  %address = getelementptr i64, ptr %data, i64 %index
  %increment = load i64, ptr %address, align 8
  %addition = call {i64, i1} @llvm.sadd.with.overflow.i64(i64 %checksum, i64 %increment)
  %sum = extractvalue {i64, i1} %addition, 0
  %overflow = extractvalue {i64, i1} %addition, 1
  br i1 %overflow, label %failure, label %success
failure:
  store i32 1, ptr %status, align 4
  ret i64 0
success:
  %rem = srem i64 %sum, 1000000007
  %nonzero = icmp ne i64 %rem, 0
  %difference = xor i64 %rem, 1000000007
  %negative = icmp slt i64 %difference, 0
  %condition = and i1 %nonzero, %negative
  %wide = zext i1 %condition to i64
  %mask = sub i64 0, %wide
  %delta = and i64 1000000007, %mask
  %result = add i64 %rem, %delta
  %bounded = icmp ult i64 %result, 1000000007
  call void @llvm.assume(i1 %bounded)
  %next = add i64 %index, 1
  %done = icmp eq i64 %next, %count
  br i1 %done, label %exit, label %loop
exit:
  ret i64 %result
}

define i64 @loop_signed_updates_select_d1000000007(ptr %data, i64 %count, i64 %seed, ptr %status) nounwind noinline {
entry:
  store i32 0, ptr %status, align 4
  %empty = icmp eq i64 %count, 0
  br i1 %empty, label %empty_exit, label %loop
empty_exit:
  ret i64 0
loop:
  %index = phi i64 [0, %entry], [%next, %success]
  %checksum = phi i64 [0, %entry], [%result, %success]
  %address = getelementptr i64, ptr %data, i64 %index
  %increment = load i64, ptr %address, align 8
  %addition = call {i64, i1} @llvm.sadd.with.overflow.i64(i64 %checksum, i64 %increment)
  %sum = extractvalue {i64, i1} %addition, 0
  %overflow = extractvalue {i64, i1} %addition, 1
  br i1 %overflow, label %failure, label %success
failure:
  store i32 1, ptr %status, align 4
  ret i64 0
success:
  %rem = srem i64 %sum, 1000000007
  %nonzero = icmp ne i64 %rem, 0
  %difference = xor i64 %rem, 1000000007
  %negative = icmp slt i64 %difference, 0
  %condition = and i1 %nonzero, %negative
  %shifted = add i64 %rem, 1000000007
  %result = select i1 %condition, i64 %shifted, i64 %rem
  %next = add i64 %index, 1
  %done = icmp eq i64 %next, %count
  br i1 %done, label %exit, label %loop
exit:
  ret i64 %result
}

define i64 @loop_signed_updates_select_assume_d1000000007(ptr %data, i64 %count, i64 %seed, ptr %status) nounwind noinline {
entry:
  store i32 0, ptr %status, align 4
  %empty = icmp eq i64 %count, 0
  br i1 %empty, label %empty_exit, label %loop
empty_exit:
  ret i64 0
loop:
  %index = phi i64 [0, %entry], [%next, %success]
  %checksum = phi i64 [0, %entry], [%result, %success]
  %address = getelementptr i64, ptr %data, i64 %index
  %increment = load i64, ptr %address, align 8
  %addition = call {i64, i1} @llvm.sadd.with.overflow.i64(i64 %checksum, i64 %increment)
  %sum = extractvalue {i64, i1} %addition, 0
  %overflow = extractvalue {i64, i1} %addition, 1
  br i1 %overflow, label %failure, label %success
failure:
  store i32 1, ptr %status, align 4
  ret i64 0
success:
  %rem = srem i64 %sum, 1000000007
  %nonzero = icmp ne i64 %rem, 0
  %difference = xor i64 %rem, 1000000007
  %negative = icmp slt i64 %difference, 0
  %condition = and i1 %nonzero, %negative
  %shifted = add i64 %rem, 1000000007
  %result = select i1 %condition, i64 %shifted, i64 %rem
  %bounded = icmp ult i64 %result, 1000000007
  call void @llvm.assume(i1 %bounded)
  %next = add i64 %index, 1
  %done = icmp eq i64 %next, %count
  br i1 %done, label %exit, label %loop
exit:
  ret i64 %result
}

define i64 @loop_zero_bool_baseline_d9223372036854775807(ptr %data, i64 %count, i64 %seed, ptr %status) nounwind noinline {
entry:
  store i32 0, ptr %status, align 4
  %empty = icmp eq i64 %count, 0
  br i1 %empty, label %empty_exit, label %loop
empty_exit:
  ret i64 0
loop:
  %index = phi i64 [0, %entry], [%next, %success]
  %checksum = phi i64 [0, %entry], [%result, %success]
  %address = getelementptr i8, ptr %data, i64 %index
  %flag = load i8, ptr %address, align 1
  %truth = icmp ne i8 %flag, 0
  %increment = zext i1 %truth to i64
  %addition = call {i64, i1} @llvm.sadd.with.overflow.i64(i64 %checksum, i64 %increment)
  %sum = extractvalue {i64, i1} %addition, 0
  %overflow = extractvalue {i64, i1} %addition, 1
  br i1 %overflow, label %failure, label %success
failure:
  store i32 1, ptr %status, align 4
  ret i64 0
success:
  %rem = srem i64 %sum, 9223372036854775807
  %nonzero = icmp ne i64 %rem, 0
  %difference = xor i64 %rem, 9223372036854775807
  %negative = icmp slt i64 %difference, 0
  %condition = and i1 %nonzero, %negative
  %wide = zext i1 %condition to i64
  %mask = sub i64 0, %wide
  %delta = and i64 9223372036854775807, %mask
  %result = add i64 %rem, %delta
  %next = add i64 %index, 1
  %done = icmp eq i64 %next, %count
  br i1 %done, label %exit, label %loop
exit:
  ret i64 %result
}

define i64 @loop_zero_bool_assume_d9223372036854775807(ptr %data, i64 %count, i64 %seed, ptr %status) nounwind noinline {
entry:
  store i32 0, ptr %status, align 4
  %empty = icmp eq i64 %count, 0
  br i1 %empty, label %empty_exit, label %loop
empty_exit:
  ret i64 0
loop:
  %index = phi i64 [0, %entry], [%next, %success]
  %checksum = phi i64 [0, %entry], [%result, %success]
  %address = getelementptr i8, ptr %data, i64 %index
  %flag = load i8, ptr %address, align 1
  %truth = icmp ne i8 %flag, 0
  %increment = zext i1 %truth to i64
  %addition = call {i64, i1} @llvm.sadd.with.overflow.i64(i64 %checksum, i64 %increment)
  %sum = extractvalue {i64, i1} %addition, 0
  %overflow = extractvalue {i64, i1} %addition, 1
  br i1 %overflow, label %failure, label %success
failure:
  store i32 1, ptr %status, align 4
  ret i64 0
success:
  %rem = srem i64 %sum, 9223372036854775807
  %nonzero = icmp ne i64 %rem, 0
  %difference = xor i64 %rem, 9223372036854775807
  %negative = icmp slt i64 %difference, 0
  %condition = and i1 %nonzero, %negative
  %wide = zext i1 %condition to i64
  %mask = sub i64 0, %wide
  %delta = and i64 9223372036854775807, %mask
  %result = add i64 %rem, %delta
  %bounded = icmp ult i64 %result, 9223372036854775807
  call void @llvm.assume(i1 %bounded)
  %next = add i64 %index, 1
  %done = icmp eq i64 %next, %count
  br i1 %done, label %exit, label %loop
exit:
  ret i64 %result
}

define i64 @loop_zero_bool_select_d9223372036854775807(ptr %data, i64 %count, i64 %seed, ptr %status) nounwind noinline {
entry:
  store i32 0, ptr %status, align 4
  %empty = icmp eq i64 %count, 0
  br i1 %empty, label %empty_exit, label %loop
empty_exit:
  ret i64 0
loop:
  %index = phi i64 [0, %entry], [%next, %success]
  %checksum = phi i64 [0, %entry], [%result, %success]
  %address = getelementptr i8, ptr %data, i64 %index
  %flag = load i8, ptr %address, align 1
  %truth = icmp ne i8 %flag, 0
  %increment = zext i1 %truth to i64
  %addition = call {i64, i1} @llvm.sadd.with.overflow.i64(i64 %checksum, i64 %increment)
  %sum = extractvalue {i64, i1} %addition, 0
  %overflow = extractvalue {i64, i1} %addition, 1
  br i1 %overflow, label %failure, label %success
failure:
  store i32 1, ptr %status, align 4
  ret i64 0
success:
  %rem = srem i64 %sum, 9223372036854775807
  %nonzero = icmp ne i64 %rem, 0
  %difference = xor i64 %rem, 9223372036854775807
  %negative = icmp slt i64 %difference, 0
  %condition = and i1 %nonzero, %negative
  %shifted = add i64 %rem, 9223372036854775807
  %result = select i1 %condition, i64 %shifted, i64 %rem
  %next = add i64 %index, 1
  %done = icmp eq i64 %next, %count
  br i1 %done, label %exit, label %loop
exit:
  ret i64 %result
}

define i64 @loop_zero_bool_select_assume_d9223372036854775807(ptr %data, i64 %count, i64 %seed, ptr %status) nounwind noinline {
entry:
  store i32 0, ptr %status, align 4
  %empty = icmp eq i64 %count, 0
  br i1 %empty, label %empty_exit, label %loop
empty_exit:
  ret i64 0
loop:
  %index = phi i64 [0, %entry], [%next, %success]
  %checksum = phi i64 [0, %entry], [%result, %success]
  %address = getelementptr i8, ptr %data, i64 %index
  %flag = load i8, ptr %address, align 1
  %truth = icmp ne i8 %flag, 0
  %increment = zext i1 %truth to i64
  %addition = call {i64, i1} @llvm.sadd.with.overflow.i64(i64 %checksum, i64 %increment)
  %sum = extractvalue {i64, i1} %addition, 0
  %overflow = extractvalue {i64, i1} %addition, 1
  br i1 %overflow, label %failure, label %success
failure:
  store i32 1, ptr %status, align 4
  ret i64 0
success:
  %rem = srem i64 %sum, 9223372036854775807
  %nonzero = icmp ne i64 %rem, 0
  %difference = xor i64 %rem, 9223372036854775807
  %negative = icmp slt i64 %difference, 0
  %condition = and i1 %nonzero, %negative
  %shifted = add i64 %rem, 9223372036854775807
  %result = select i1 %condition, i64 %shifted, i64 %rem
  %bounded = icmp ult i64 %result, 9223372036854775807
  call void @llvm.assume(i1 %bounded)
  %next = add i64 %index, 1
  %done = icmp eq i64 %next, %count
  br i1 %done, label %exit, label %loop
exit:
  ret i64 %result
}

define i64 @loop_seeded_bool_baseline_d9223372036854775807(ptr %data, i64 %count, i64 %seed, ptr %status) nounwind noinline {
entry:
  store i32 0, ptr %status, align 4
  %empty = icmp eq i64 %count, 0
  br i1 %empty, label %empty_exit, label %loop
empty_exit:
  ret i64 %seed
loop:
  %index = phi i64 [0, %entry], [%next, %success]
  %checksum = phi i64 [%seed, %entry], [%result, %success]
  %address = getelementptr i8, ptr %data, i64 %index
  %flag = load i8, ptr %address, align 1
  %truth = icmp ne i8 %flag, 0
  %increment = zext i1 %truth to i64
  %addition = call {i64, i1} @llvm.sadd.with.overflow.i64(i64 %checksum, i64 %increment)
  %sum = extractvalue {i64, i1} %addition, 0
  %overflow = extractvalue {i64, i1} %addition, 1
  br i1 %overflow, label %failure, label %success
failure:
  store i32 1, ptr %status, align 4
  ret i64 0
success:
  %rem = srem i64 %sum, 9223372036854775807
  %nonzero = icmp ne i64 %rem, 0
  %difference = xor i64 %rem, 9223372036854775807
  %negative = icmp slt i64 %difference, 0
  %condition = and i1 %nonzero, %negative
  %wide = zext i1 %condition to i64
  %mask = sub i64 0, %wide
  %delta = and i64 9223372036854775807, %mask
  %result = add i64 %rem, %delta
  %next = add i64 %index, 1
  %done = icmp eq i64 %next, %count
  br i1 %done, label %exit, label %loop
exit:
  ret i64 %result
}

define i64 @loop_seeded_bool_assume_d9223372036854775807(ptr %data, i64 %count, i64 %seed, ptr %status) nounwind noinline {
entry:
  store i32 0, ptr %status, align 4
  %empty = icmp eq i64 %count, 0
  br i1 %empty, label %empty_exit, label %loop
empty_exit:
  ret i64 %seed
loop:
  %index = phi i64 [0, %entry], [%next, %success]
  %checksum = phi i64 [%seed, %entry], [%result, %success]
  %address = getelementptr i8, ptr %data, i64 %index
  %flag = load i8, ptr %address, align 1
  %truth = icmp ne i8 %flag, 0
  %increment = zext i1 %truth to i64
  %addition = call {i64, i1} @llvm.sadd.with.overflow.i64(i64 %checksum, i64 %increment)
  %sum = extractvalue {i64, i1} %addition, 0
  %overflow = extractvalue {i64, i1} %addition, 1
  br i1 %overflow, label %failure, label %success
failure:
  store i32 1, ptr %status, align 4
  ret i64 0
success:
  %rem = srem i64 %sum, 9223372036854775807
  %nonzero = icmp ne i64 %rem, 0
  %difference = xor i64 %rem, 9223372036854775807
  %negative = icmp slt i64 %difference, 0
  %condition = and i1 %nonzero, %negative
  %wide = zext i1 %condition to i64
  %mask = sub i64 0, %wide
  %delta = and i64 9223372036854775807, %mask
  %result = add i64 %rem, %delta
  %bounded = icmp ult i64 %result, 9223372036854775807
  call void @llvm.assume(i1 %bounded)
  %next = add i64 %index, 1
  %done = icmp eq i64 %next, %count
  br i1 %done, label %exit, label %loop
exit:
  ret i64 %result
}

define i64 @loop_seeded_bool_select_d9223372036854775807(ptr %data, i64 %count, i64 %seed, ptr %status) nounwind noinline {
entry:
  store i32 0, ptr %status, align 4
  %empty = icmp eq i64 %count, 0
  br i1 %empty, label %empty_exit, label %loop
empty_exit:
  ret i64 %seed
loop:
  %index = phi i64 [0, %entry], [%next, %success]
  %checksum = phi i64 [%seed, %entry], [%result, %success]
  %address = getelementptr i8, ptr %data, i64 %index
  %flag = load i8, ptr %address, align 1
  %truth = icmp ne i8 %flag, 0
  %increment = zext i1 %truth to i64
  %addition = call {i64, i1} @llvm.sadd.with.overflow.i64(i64 %checksum, i64 %increment)
  %sum = extractvalue {i64, i1} %addition, 0
  %overflow = extractvalue {i64, i1} %addition, 1
  br i1 %overflow, label %failure, label %success
failure:
  store i32 1, ptr %status, align 4
  ret i64 0
success:
  %rem = srem i64 %sum, 9223372036854775807
  %nonzero = icmp ne i64 %rem, 0
  %difference = xor i64 %rem, 9223372036854775807
  %negative = icmp slt i64 %difference, 0
  %condition = and i1 %nonzero, %negative
  %shifted = add i64 %rem, 9223372036854775807
  %result = select i1 %condition, i64 %shifted, i64 %rem
  %next = add i64 %index, 1
  %done = icmp eq i64 %next, %count
  br i1 %done, label %exit, label %loop
exit:
  ret i64 %result
}

define i64 @loop_seeded_bool_select_assume_d9223372036854775807(ptr %data, i64 %count, i64 %seed, ptr %status) nounwind noinline {
entry:
  store i32 0, ptr %status, align 4
  %empty = icmp eq i64 %count, 0
  br i1 %empty, label %empty_exit, label %loop
empty_exit:
  ret i64 %seed
loop:
  %index = phi i64 [0, %entry], [%next, %success]
  %checksum = phi i64 [%seed, %entry], [%result, %success]
  %address = getelementptr i8, ptr %data, i64 %index
  %flag = load i8, ptr %address, align 1
  %truth = icmp ne i8 %flag, 0
  %increment = zext i1 %truth to i64
  %addition = call {i64, i1} @llvm.sadd.with.overflow.i64(i64 %checksum, i64 %increment)
  %sum = extractvalue {i64, i1} %addition, 0
  %overflow = extractvalue {i64, i1} %addition, 1
  br i1 %overflow, label %failure, label %success
failure:
  store i32 1, ptr %status, align 4
  ret i64 0
success:
  %rem = srem i64 %sum, 9223372036854775807
  %nonzero = icmp ne i64 %rem, 0
  %difference = xor i64 %rem, 9223372036854775807
  %negative = icmp slt i64 %difference, 0
  %condition = and i1 %nonzero, %negative
  %shifted = add i64 %rem, 9223372036854775807
  %result = select i1 %condition, i64 %shifted, i64 %rem
  %bounded = icmp ult i64 %result, 9223372036854775807
  call void @llvm.assume(i1 %bounded)
  %next = add i64 %index, 1
  %done = icmp eq i64 %next, %count
  br i1 %done, label %exit, label %loop
exit:
  ret i64 %result
}

define i64 @loop_signed_updates_baseline_d9223372036854775807(ptr %data, i64 %count, i64 %seed, ptr %status) nounwind noinline {
entry:
  store i32 0, ptr %status, align 4
  %empty = icmp eq i64 %count, 0
  br i1 %empty, label %empty_exit, label %loop
empty_exit:
  ret i64 0
loop:
  %index = phi i64 [0, %entry], [%next, %success]
  %checksum = phi i64 [0, %entry], [%result, %success]
  %address = getelementptr i64, ptr %data, i64 %index
  %increment = load i64, ptr %address, align 8
  %addition = call {i64, i1} @llvm.sadd.with.overflow.i64(i64 %checksum, i64 %increment)
  %sum = extractvalue {i64, i1} %addition, 0
  %overflow = extractvalue {i64, i1} %addition, 1
  br i1 %overflow, label %failure, label %success
failure:
  store i32 1, ptr %status, align 4
  ret i64 0
success:
  %rem = srem i64 %sum, 9223372036854775807
  %nonzero = icmp ne i64 %rem, 0
  %difference = xor i64 %rem, 9223372036854775807
  %negative = icmp slt i64 %difference, 0
  %condition = and i1 %nonzero, %negative
  %wide = zext i1 %condition to i64
  %mask = sub i64 0, %wide
  %delta = and i64 9223372036854775807, %mask
  %result = add i64 %rem, %delta
  %next = add i64 %index, 1
  %done = icmp eq i64 %next, %count
  br i1 %done, label %exit, label %loop
exit:
  ret i64 %result
}

define i64 @loop_signed_updates_assume_d9223372036854775807(ptr %data, i64 %count, i64 %seed, ptr %status) nounwind noinline {
entry:
  store i32 0, ptr %status, align 4
  %empty = icmp eq i64 %count, 0
  br i1 %empty, label %empty_exit, label %loop
empty_exit:
  ret i64 0
loop:
  %index = phi i64 [0, %entry], [%next, %success]
  %checksum = phi i64 [0, %entry], [%result, %success]
  %address = getelementptr i64, ptr %data, i64 %index
  %increment = load i64, ptr %address, align 8
  %addition = call {i64, i1} @llvm.sadd.with.overflow.i64(i64 %checksum, i64 %increment)
  %sum = extractvalue {i64, i1} %addition, 0
  %overflow = extractvalue {i64, i1} %addition, 1
  br i1 %overflow, label %failure, label %success
failure:
  store i32 1, ptr %status, align 4
  ret i64 0
success:
  %rem = srem i64 %sum, 9223372036854775807
  %nonzero = icmp ne i64 %rem, 0
  %difference = xor i64 %rem, 9223372036854775807
  %negative = icmp slt i64 %difference, 0
  %condition = and i1 %nonzero, %negative
  %wide = zext i1 %condition to i64
  %mask = sub i64 0, %wide
  %delta = and i64 9223372036854775807, %mask
  %result = add i64 %rem, %delta
  %bounded = icmp ult i64 %result, 9223372036854775807
  call void @llvm.assume(i1 %bounded)
  %next = add i64 %index, 1
  %done = icmp eq i64 %next, %count
  br i1 %done, label %exit, label %loop
exit:
  ret i64 %result
}

define i64 @loop_signed_updates_select_d9223372036854775807(ptr %data, i64 %count, i64 %seed, ptr %status) nounwind noinline {
entry:
  store i32 0, ptr %status, align 4
  %empty = icmp eq i64 %count, 0
  br i1 %empty, label %empty_exit, label %loop
empty_exit:
  ret i64 0
loop:
  %index = phi i64 [0, %entry], [%next, %success]
  %checksum = phi i64 [0, %entry], [%result, %success]
  %address = getelementptr i64, ptr %data, i64 %index
  %increment = load i64, ptr %address, align 8
  %addition = call {i64, i1} @llvm.sadd.with.overflow.i64(i64 %checksum, i64 %increment)
  %sum = extractvalue {i64, i1} %addition, 0
  %overflow = extractvalue {i64, i1} %addition, 1
  br i1 %overflow, label %failure, label %success
failure:
  store i32 1, ptr %status, align 4
  ret i64 0
success:
  %rem = srem i64 %sum, 9223372036854775807
  %nonzero = icmp ne i64 %rem, 0
  %difference = xor i64 %rem, 9223372036854775807
  %negative = icmp slt i64 %difference, 0
  %condition = and i1 %nonzero, %negative
  %shifted = add i64 %rem, 9223372036854775807
  %result = select i1 %condition, i64 %shifted, i64 %rem
  %next = add i64 %index, 1
  %done = icmp eq i64 %next, %count
  br i1 %done, label %exit, label %loop
exit:
  ret i64 %result
}

define i64 @loop_signed_updates_select_assume_d9223372036854775807(ptr %data, i64 %count, i64 %seed, ptr %status) nounwind noinline {
entry:
  store i32 0, ptr %status, align 4
  %empty = icmp eq i64 %count, 0
  br i1 %empty, label %empty_exit, label %loop
empty_exit:
  ret i64 0
loop:
  %index = phi i64 [0, %entry], [%next, %success]
  %checksum = phi i64 [0, %entry], [%result, %success]
  %address = getelementptr i64, ptr %data, i64 %index
  %increment = load i64, ptr %address, align 8
  %addition = call {i64, i1} @llvm.sadd.with.overflow.i64(i64 %checksum, i64 %increment)
  %sum = extractvalue {i64, i1} %addition, 0
  %overflow = extractvalue {i64, i1} %addition, 1
  br i1 %overflow, label %failure, label %success
failure:
  store i32 1, ptr %status, align 4
  ret i64 0
success:
  %rem = srem i64 %sum, 9223372036854775807
  %nonzero = icmp ne i64 %rem, 0
  %difference = xor i64 %rem, 9223372036854775807
  %negative = icmp slt i64 %difference, 0
  %condition = and i1 %nonzero, %negative
  %shifted = add i64 %rem, 9223372036854775807
  %result = select i1 %condition, i64 %shifted, i64 %rem
  %bounded = icmp ult i64 %result, 9223372036854775807
  call void @llvm.assume(i1 %bounded)
  %next = add i64 %index, 1
  %done = icmp eq i64 %next, %count
  br i1 %done, label %exit, label %loop
exit:
  ret i64 %result
}
