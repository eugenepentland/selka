
/home/epentland/ai/canopy/mylang-worktrees/goal110-equality-bounded-20261004/.mylang-cache/goal110-floor-range-ir/floor-range.so:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .text:

0000000000002410 <scalar_assume_d1000000007>:
    2410:	movabs $0x89705f3112a28fe5,%rcx
    241a:	mov    %rdi,%rax
    241d:	imul   %rcx
    2420:	add    %rdi,%rdx
    2423:	mov    %rdx,%rax
    2426:	shr    $0x3f,%rax
    242a:	sar    $0x1d,%rdx
    242e:	add    %rax,%rdx
    2431:	imul   $0x3b9aca07,%rdx,%rax
    2438:	sub    %rax,%rdi
    243b:	mov    %rdi,%rax
    243e:	sar    $0x3f,%rax
    2442:	and    $0x3b9aca07,%eax
    2447:	add    %rdi,%rax
    244a:	ret
