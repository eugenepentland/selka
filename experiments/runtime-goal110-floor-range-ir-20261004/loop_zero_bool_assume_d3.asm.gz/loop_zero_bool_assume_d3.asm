
/home/epentland/ai/canopy/mylang-worktrees/goal110-equality-bounded-20261004/.mylang-cache/goal110-floor-range-ir/floor-range.so:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .text:

0000000000002740 <loop_zero_bool_assume_d3>:
    2740:	movl   $0x0,(%rcx)
    2746:	test   %rsi,%rsi
    2749:	je     2773 <loop_zero_bool_assume_d3+0x33>
    274b:	push   %rbp
    274c:	push   %r15
    274e:	push   %r14
    2750:	push   %r12
    2752:	push   %rbx
    2753:	mov    %esi,%r9d
    2756:	and    $0x3,%r9d
    275a:	cmp    $0x4,%rsi
    275e:	movabs $0xaaaaaaaaaaaaaaab,%r10
    2768:	jae    2779 <loop_zero_bool_assume_d3+0x39>
    276a:	xor    %esi,%esi
    276c:	xor    %ecx,%ecx
    276e:	jmp    283a <loop_zero_bool_assume_d3+0xfa>
    2773:	xor    %ecx,%ecx
    2775:	mov    %rcx,%rax
    2778:	ret
    2779:	and    $0xfffffffffffffffc,%rsi
    277d:	xor    %ecx,%ecx
    277f:	pxor   %xmm0,%xmm0
    2783:	movabs $0x5555555555555556,%r11
    278d:	mov    %rdi,%rbx
    2790:	mov    %rsi,%r14
    2793:	cs nopw 0x0(%rax,%rax,1)
    279d:	nopl   (%rax)
    27a0:	movd   (%rbx),%xmm1
    27a4:	punpcklbw %xmm1,%xmm1
    27a8:	punpcklwd %xmm1,%xmm1
    27ac:	pcmpeqb %xmm0,%xmm1
    27b0:	movmskps %xmm1,%r8d
    27b4:	xor    $0xf,%r8d
    27b8:	mov    %r8d,%ebp
    27bb:	shr    $0x3,%bpl
    27bf:	mov    %r8d,%r15d
    27c2:	and    $0x4,%r15b
    27c6:	shr    $0x2,%r15b
    27ca:	mov    %r8d,%r12d
    27cd:	and    $0x2,%r12b
    27d1:	shr    $1,%r12b
    27d4:	and    $0x1,%r8d
    27d8:	add    %rcx,%r8
    27db:	mov    %r8,%rax
    27de:	mul    %r10
    27e1:	shr    $1,%rdx
    27e4:	lea    (%rdx,%rdx,2),%rax
    27e8:	sub    %rax,%r8
    27eb:	movzbl %r12b,%ecx
    27ef:	add    %r8,%rcx
    27f2:	mov    %rcx,%rax
    27f5:	mul    %r11
    27f8:	lea    (%rdx,%rdx,2),%rax
    27fc:	sub    %rax,%rcx
    27ff:	movzbl %r15b,%r8d
    2803:	add    %rcx,%r8
    2806:	mov    %r8,%rax
    2809:	mul    %r11
    280c:	lea    (%rdx,%rdx,2),%rax
    2810:	sub    %rax,%r8
    2813:	movzbl %bpl,%ecx
    2817:	add    %r8,%rcx
    281a:	mov    %rcx,%rax
    281d:	mul    %r11
    2820:	lea    (%rdx,%rdx,2),%rax
    2824:	sub    %rax,%rcx
    2827:	add    $0x4,%rbx
    282b:	add    $0xfffffffffffffffc,%r14
    282f:	jne    27a0 <loop_zero_bool_assume_d3+0x60>
    2835:	test   %r9,%r9
    2838:	je     285f <loop_zero_bool_assume_d3+0x11f>
    283a:	add    %rsi,%rdi
    283d:	nopl   (%rax)
    2840:	cmpb   $0x1,(%rdi)
    2843:	sbb    $0xffffffffffffffff,%rcx
    2847:	mov    %rcx,%rax
    284a:	mul    %r10
    284d:	shr    $1,%rdx
    2850:	lea    (%rdx,%rdx,2),%rax
    2854:	sub    %rax,%rcx
    2857:	inc    %rdi
    285a:	dec    %r9
    285d:	jne    2840 <loop_zero_bool_assume_d3+0x100>
    285f:	pop    %rbx
    2860:	pop    %r12
    2862:	pop    %r14
    2864:	pop    %r15
    2866:	pop    %rbp
    2867:	mov    %rcx,%rax
    286a:	ret
