
/home/epentland/ai/canopy/mylang-worktrees/goal110-equality-bounded-20261004/.mylang-cache/goal110-floor-range-ir/floor-range.so:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .text:

0000000000002dc0 <loop_signed_updates_select_assume_d3>:
    2dc0:	movl   $0x0,(%rcx)
    2dc6:	xor    %r8d,%r8d
    2dc9:	test   %rsi,%rsi
    2dcc:	je     2e17 <loop_signed_updates_select_assume_d3+0x57>
    2dce:	movabs $0x5555555555555556,%r9
    2dd8:	nopl   0x0(%rax,%rax,1)
    2de0:	add    (%rdi),%r8
    2de3:	jo     2e1b <loop_signed_updates_select_assume_d3+0x5b>
    2de5:	mov    %r8,%rax
    2de8:	imul   %r9
    2deb:	mov    %rdx,%rax
    2dee:	shr    $0x3f,%rax
    2df2:	add    %rdx,%rax
    2df5:	lea    (%rax,%rax,2),%rax
    2df9:	mov    %r8,%rdx
    2dfc:	sub    %rax,%rdx
    2dff:	neg    %rax
    2e02:	test   %rdx,%rdx
    2e05:	lea    0x3(%r8,%rax,1),%r8
    2e0a:	cmovns %rdx,%r8
    2e0e:	add    $0x8,%rdi
    2e12:	dec    %rsi
    2e15:	jne    2de0 <loop_signed_updates_select_assume_d3+0x20>
    2e17:	mov    %r8,%rax
    2e1a:	ret
    2e1b:	movl   $0x1,(%rcx)
    2e21:	xor    %r8d,%r8d
    2e24:	mov    %r8,%rax
    2e27:	ret
