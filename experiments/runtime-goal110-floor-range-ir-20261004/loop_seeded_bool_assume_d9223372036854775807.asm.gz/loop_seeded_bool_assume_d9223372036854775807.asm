
/home/epentland/ai/canopy/mylang-worktrees/goal110-equality-bounded-20261004/.mylang-cache/goal110-floor-range-ir/floor-range.so:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .text:

0000000000003ab0 <loop_seeded_bool_assume_d9223372036854775807>:
    3ab0:	mov    %rdx,%rax
    3ab3:	movl   $0x0,(%rcx)
    3ab9:	test   %rsi,%rsi
    3abc:	je     3b25 <loop_seeded_bool_assume_d9223372036854775807+0x75>
    3abe:	movabs $0x7fffffffffffffff,%r9
    3ac8:	movabs $0x4000000000000001,%r10
    3ad2:	cs nopw 0x0(%rax,%rax,1)
    3adc:	nopl   0x0(%rax)
    3ae0:	xor    %r8d,%r8d
    3ae3:	cmpb   $0x0,(%rdi)
    3ae6:	setne  %r8b
    3aea:	add    %rax,%r8
    3aed:	jo     3b26 <loop_seeded_bool_assume_d9223372036854775807+0x76>
    3aef:	mov    %r8,%rax
    3af2:	imul   %r10
    3af5:	mov    %rdx,%rax
    3af8:	shr    $0x3f,%rax
    3afc:	sar    $0x3d,%rdx
    3b00:	add    %rax,%rdx
    3b03:	mov    %rdx,%r11
    3b06:	shl    $0x3f,%r11
    3b0a:	add    %rdx,%r11
    3b0d:	add    %r8,%r11
    3b10:	mov    %r11,%rax
    3b13:	sar    $0x3f,%rax
    3b17:	and    %r9,%rax
    3b1a:	add    %r11,%rax
    3b1d:	inc    %rdi
    3b20:	dec    %rsi
    3b23:	jne    3ae0 <loop_seeded_bool_assume_d9223372036854775807+0x30>
    3b25:	ret
    3b26:	movl   $0x1,(%rcx)
    3b2c:	xor    %eax,%eax
    3b2e:	ret
