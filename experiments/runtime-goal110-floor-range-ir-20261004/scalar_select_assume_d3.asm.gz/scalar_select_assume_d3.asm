
/home/epentland/ai/canopy/mylang-worktrees/goal110-equality-bounded-20261004/.mylang-cache/goal110-floor-range-ir/floor-range.so:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .text:

0000000000002390 <scalar_select_assume_d3>:
    2390:	movabs $0x5555555555555556,%rcx
    239a:	mov    %rdi,%rax
    239d:	imul   %rcx
    23a0:	mov    %rdx,%rax
    23a3:	shr    $0x3f,%rax
    23a7:	add    %rdx,%rax
    23aa:	lea    (%rax,%rax,2),%rax
    23ae:	mov    %rdi,%rcx
    23b1:	sub    %rax,%rcx
    23b4:	neg    %rax
    23b7:	test   %rcx,%rcx
    23ba:	lea    0x3(%rdi,%rax,1),%rax
    23bf:	cmovns %rcx,%rax
    23c3:	ret
