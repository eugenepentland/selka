define range(i64 0, 1000000007) i64 @loop_zero_bool_select_assume_d1000000007(ptr readonly captures(none) %data, i64 %count, i64 %seed, ptr writeonly captures(none) initializes((0, 4)) %status) local_unnamed_addr #4 {
entry:
  store i32 0, ptr %status, align 4
  %empty = icmp eq i64 %count, 0
  br i1 %empty, label %common.ret, label %loop.preheader

loop.preheader:                                   ; preds = %entry
  %xtraiter = and i64 %count, 3
  %0 = icmp ult i64 %count, 4
  br i1 %0, label %loop.epil.preheader, label %loop.preheader.new

loop.preheader.new:                               ; preds = %loop.preheader
  %unroll_iter = and i64 %count, -4
  br label %loop

common.ret.loopexit.unr-lcssa:                    ; preds = %loop
  %lcmp.mod.not = icmp eq i64 %xtraiter, 0
  br i1 %lcmp.mod.not, label %common.ret, label %loop.epil.preheader

loop.epil.preheader:                              ; preds = %common.ret.loopexit.unr-lcssa, %loop.preheader
  %index.epil.init = phi i64 [ 0, %loop.preheader ], [ %next.3, %common.ret.loopexit.unr-lcssa ]
  %checksum.epil.init = phi i64 [ 0, %loop.preheader ], [ %rem.3, %common.ret.loopexit.unr-lcssa ]
  %lcmp.mod2 = icmp ne i64 %xtraiter, 0
  tail call void @llvm.assume(i1 %lcmp.mod2)
  br label %loop.epil

loop.epil:                                        ; preds = %loop.epil, %loop.epil.preheader
  %index.epil = phi i64 [ %next.epil, %loop.epil ], [ %index.epil.init, %loop.epil.preheader ]
  %checksum.epil = phi i64 [ %rem.epil, %loop.epil ], [ %checksum.epil.init, %loop.epil.preheader ]
  %epil.iter = phi i64 [ %epil.iter.next, %loop.epil ], [ 0, %loop.epil.preheader ]
  %address.epil = getelementptr i8, ptr %data, i64 %index.epil
  %flag.epil = load i8, ptr %address.epil, align 1
  %truth.epil = icmp ne i8 %flag.epil, 0
  %increment.epil = zext i1 %truth.epil to i64
  %addition.epil = add nuw nsw i64 %checksum.epil, %increment.epil
  %rem.epil = urem i64 %addition.epil, 1000000007
  %next.epil = add nuw i64 %index.epil, 1
  %epil.iter.next = add i64 %epil.iter, 1
  %epil.iter.cmp.not = icmp eq i64 %epil.iter.next, %xtraiter
  br i1 %epil.iter.cmp.not, label %common.ret, label %loop.epil, !llvm.loop !8

common.ret:                                       ; preds = %common.ret.loopexit.unr-lcssa, %loop.epil, %entry
  %common.ret.op = phi i64 [ 0, %entry ], [ %rem.3, %common.ret.loopexit.unr-lcssa ], [ %rem.epil, %loop.epil ]
  ret i64 %common.ret.op

loop:                                             ; preds = %loop, %loop.preheader.new
  %index = phi i64 [ 0, %loop.preheader.new ], [ %next.3, %loop ]
  %checksum = phi i64 [ 0, %loop.preheader.new ], [ %rem.3, %loop ]
  %niter = phi i64 [ 0, %loop.preheader.new ], [ %niter.next.3, %loop ]
  %address = getelementptr i8, ptr %data, i64 %index
  %flag = load i8, ptr %address, align 1
  %truth = icmp ne i8 %flag, 0
  %increment = zext i1 %truth to i64
  %addition = add nuw nsw i64 %checksum, %increment
  %rem = urem i64 %addition, 1000000007
  %1 = getelementptr i8, ptr %data, i64 %index
  %address.1 = getelementptr i8, ptr %1, i64 1
  %flag.1 = load i8, ptr %address.1, align 1
  %truth.1 = icmp ne i8 %flag.1, 0
  %increment.1 = zext i1 %truth.1 to i64
  %addition.1 = add nuw nsw i64 %rem, %increment.1
  %rem.1 = urem i64 %addition.1, 1000000007
  %2 = getelementptr i8, ptr %data, i64 %index
  %address.2 = getelementptr i8, ptr %2, i64 2
  %flag.2 = load i8, ptr %address.2, align 1
  %truth.2 = icmp ne i8 %flag.2, 0
  %increment.2 = zext i1 %truth.2 to i64
  %addition.2 = add nuw nsw i64 %rem.1, %increment.2
  %rem.2 = urem i64 %addition.2, 1000000007
  %3 = getelementptr i8, ptr %data, i64 %index
  %address.3 = getelementptr i8, ptr %3, i64 3
  %flag.3 = load i8, ptr %address.3, align 1
  %truth.3 = icmp ne i8 %flag.3, 0
  %increment.3 = zext i1 %truth.3 to i64
  %addition.3 = add nuw nsw i64 %rem.2, %increment.3
  %rem.3 = urem i64 %addition.3, 1000000007
  %next.3 = add nuw i64 %index, 4
  %niter.next.3 = add i64 %niter, 4
  %niter.ncmp.3 = icmp eq i64 %niter.next.3, %unroll_iter
  br i1 %niter.ncmp.3, label %common.ret.loopexit.unr-lcssa, label %loop
}
