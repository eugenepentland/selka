
/home/epentland/ai/canopy/mylang-worktrees/goal110-equality-bounded-20261004/.mylang-cache/goal110-floor-range-ir/floor-range.so:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .text:

0000000000003cb0 <loop_signed_updates_assume_d9223372036854775807>:
    3cb0:	movl   $0x0,(%rcx)
    3cb6:	test   %rsi,%rsi
    3cb9:	je     3d23 <loop_signed_updates_assume_d9223372036854775807+0x73>
    3cbb:	movabs $0x7fffffffffffffff,%r9
    3cc5:	xor    %r8d,%r8d
    3cc8:	movabs $0x4000000000000001,%r10
    3cd2:	cs nopw 0x0(%rax,%rax,1)
    3cdc:	nopl   0x0(%rax)
    3ce0:	add    (%rdi),%r8
    3ce3:	jo     3d1d <loop_signed_updates_assume_d9223372036854775807+0x6d>
    3ce5:	mov    %r8,%rax
    3ce8:	imul   %r10
    3ceb:	mov    %rdx,%rax
    3cee:	shr    $0x3f,%rax
    3cf2:	sar    $0x3d,%rdx
    3cf6:	add    %rax,%rdx
    3cf9:	add    %rdx,%r8
    3cfc:	shl    $0x3f,%rdx
    3d00:	add    %r8,%rdx
    3d03:	mov    %rdx,%r8
    3d06:	sar    $0x3f,%r8
    3d0a:	and    %r9,%r8
    3d0d:	add    %rdx,%r8
    3d10:	add    $0x8,%rdi
    3d14:	dec    %rsi
    3d17:	jne    3ce0 <loop_signed_updates_assume_d9223372036854775807+0x30>
    3d19:	mov    %r8,%rax
    3d1c:	ret
    3d1d:	movl   $0x1,(%rcx)
    3d23:	xor    %r8d,%r8d
    3d26:	mov    %r8,%rax
    3d29:	ret
