
/home/epentland/ai/canopy/mylang-worktrees/goal110-equality-bounded-20261004/.mylang-cache/goal110-floor-range-ir/floor-range.so:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .text:

0000000000002450 <scalar_select_d1000000007>:
    2450:	movabs $0x89705f3112a28fe5,%rcx
    245a:	mov    %rdi,%rax
    245d:	imul   %rcx
    2460:	add    %rdi,%rdx
    2463:	mov    %rdx,%rax
    2466:	shr    $0x3f,%rax
    246a:	sar    $0x1d,%rdx
    246e:	add    %rax,%rdx
    2471:	imul   $0x3b9aca07,%rdx,%rax
    2478:	mov    %rdi,%rcx
    247b:	sub    %rax,%rcx
    247e:	neg    %rax
    2481:	test   %rcx,%rcx
    2484:	lea    0x3b9aca07(%rdi,%rax,1),%rax
    248c:	cmovns %rcx,%rax
    2490:	ret
