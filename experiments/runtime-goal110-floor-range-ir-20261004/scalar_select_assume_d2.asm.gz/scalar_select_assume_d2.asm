
/home/epentland/ai/canopy/mylang-worktrees/goal110-equality-bounded-20261004/.mylang-cache/goal110-floor-range-ir/floor-range.so:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .text:

00000000000022e0 <scalar_select_assume_d2>:
    22e0:	mov    %rdi,%rax
    22e3:	and    $0x1,%eax
    22e6:	ret
