
/home/epentland/ai/canopy/mylang-worktrees/goal110-equality-bounded-20261004/.mylang-cache/goal110-floor-range-ir/floor-range.so:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .text:

0000000000003450 <loop_seeded_bool_baseline_d1000000007>:
    3450:	mov    %rdx,%rax
    3453:	movl   $0x0,(%rcx)
    3459:	test   %rsi,%rsi
    345c:	je     34b7 <loop_seeded_bool_baseline_d1000000007+0x67>
    345e:	movabs $0x89705f3112a28fe5,%r9
    3468:	nopl   0x0(%rax,%rax,1)
    3470:	xor    %r8d,%r8d
    3473:	cmpb   $0x0,(%rdi)
    3476:	setne  %r8b
    347a:	add    %rax,%r8
    347d:	jo     34b8 <loop_seeded_bool_baseline_d1000000007+0x68>
    347f:	mov    %r8,%rax
    3482:	imul   %r9
    3485:	add    %r8,%rdx
    3488:	mov    %rdx,%rax
    348b:	shr    $0x3f,%rax
    348f:	sar    $0x1d,%rdx
    3493:	add    %rax,%rdx
    3496:	imul   $0x3b9aca07,%rdx,%rax
    349d:	sub    %rax,%r8
    34a0:	mov    %r8,%rax
    34a3:	sar    $0x3f,%rax
    34a7:	and    $0x3b9aca07,%eax
    34ac:	add    %r8,%rax
    34af:	inc    %rdi
    34b2:	dec    %rsi
    34b5:	jne    3470 <loop_seeded_bool_baseline_d1000000007+0x20>
    34b7:	ret
    34b8:	movl   $0x1,(%rcx)
    34be:	xor    %eax,%eax
    34c0:	ret
