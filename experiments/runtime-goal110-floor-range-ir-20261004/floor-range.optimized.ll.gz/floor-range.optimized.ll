; ModuleID = '.mylang-cache/goal110-floor-range-ir/floor-range.ll'
source_filename = ".mylang-cache/goal110-floor-range-ir/floor-range.ll"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-unknown-linux7.0.0-gnu2.43.0"

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: write)
declare void @llvm.assume(i1 noundef) #0

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64) #1

; Function Attrs: mustprogress nofree noinline norecurse nosync nounwind willreturn memory(none)
define noundef i64 @scalar_baseline_d1(i64 %value) local_unnamed_addr #2 {
entry:
  ret i64 0
}

; Function Attrs: mustprogress nofree noinline norecurse nosync nounwind willreturn memory(none)
define noundef i64 @scalar_assume_d1(i64 %value) local_unnamed_addr #2 {
entry:
  ret i64 0
}

; Function Attrs: mustprogress nofree noinline norecurse nosync nounwind willreturn memory(none)
define noundef i64 @scalar_select_d1(i64 %value) local_unnamed_addr #2 {
entry:
  ret i64 0
}

; Function Attrs: mustprogress nofree noinline norecurse nosync nounwind willreturn memory(none)
define noundef i64 @scalar_select_assume_d1(i64 %value) local_unnamed_addr #2 {
entry:
  ret i64 0
}

; Function Attrs: mustprogress nofree noinline norecurse nosync nounwind willreturn memory(none)
define range(i64 0, 2) i64 @scalar_baseline_d2(i64 %value) local_unnamed_addr #2 {
entry:
  %result = and i64 %value, 1
  ret i64 %result
}

; Function Attrs: mustprogress nofree noinline norecurse nosync nounwind willreturn memory(none)
define range(i64 0, 2) i64 @scalar_assume_d2(i64 %value) local_unnamed_addr #2 {
entry:
  %result = and i64 %value, 1
  ret i64 %result
}

; Function Attrs: mustprogress nofree noinline norecurse nosync nounwind willreturn memory(none)
define range(i64 0, 2) i64 @scalar_select_d2(i64 %value) local_unnamed_addr #2 {
entry:
  %result = and i64 %value, 1
  ret i64 %result
}

; Function Attrs: mustprogress nofree noinline norecurse nosync nounwind willreturn memory(none)
define range(i64 0, 2) i64 @scalar_select_assume_d2(i64 %value) local_unnamed_addr #2 {
entry:
  %result = and i64 %value, 1
  ret i64 %result
}

; Function Attrs: mustprogress nofree noinline norecurse nosync nounwind willreturn memory(none)
define range(i64 -2, 6) i64 @scalar_baseline_d3(i64 %value) local_unnamed_addr #2 {
entry:
  %rem = srem i64 %value, 3
  %isneg = icmp slt i64 %rem, 0
  %delta = select i1 %isneg, i64 3, i64 0
  %result = add nsw i64 %delta, %rem
  ret i64 %result
}

; Function Attrs: mustprogress nofree noinline norecurse nosync nounwind willreturn memory(inaccessiblemem: write)
define range(i64 0, 3) i64 @scalar_assume_d3(i64 %value) local_unnamed_addr #3 {
entry:
  %rem = srem i64 %value, 3
  %isneg = icmp slt i64 %rem, 0
  %delta = select i1 %isneg, i64 3, i64 0
  %result = add nsw i64 %delta, %rem
  %bounded = icmp ult i64 %result, 3
  tail call void @llvm.assume(i1 %bounded)
  ret i64 %result
}

; Function Attrs: mustprogress nofree noinline norecurse nosync nounwind willreturn memory(none)
define range(i64 -2, 6) i64 @scalar_select_d3(i64 %value) local_unnamed_addr #2 {
entry:
  %rem = srem i64 %value, 3
  %negative = icmp slt i64 %rem, 0
  %shifted = add nsw i64 %rem, 3
  %result = select i1 %negative, i64 %shifted, i64 %rem
  ret i64 %result
}

; Function Attrs: mustprogress nofree noinline norecurse nosync nounwind willreturn memory(inaccessiblemem: write)
define range(i64 0, 3) i64 @scalar_select_assume_d3(i64 %value) local_unnamed_addr #3 {
entry:
  %rem = srem i64 %value, 3
  %negative = icmp slt i64 %rem, 0
  %shifted = add nsw i64 %rem, 3
  %result = select i1 %negative, i64 %shifted, i64 %rem
  %bounded = icmp ult i64 %result, 3
  tail call void @llvm.assume(i1 %bounded)
  ret i64 %result
}

; Function Attrs: mustprogress nofree noinline norecurse nosync nounwind willreturn memory(none)
define range(i64 -1000000006, 2000000014) i64 @scalar_baseline_d1000000007(i64 %value) local_unnamed_addr #2 {
entry:
  %rem = srem i64 %value, 1000000007
  %isneg = icmp slt i64 %rem, 0
  %delta = select i1 %isneg, i64 1000000007, i64 0
  %result = add nsw i64 %delta, %rem
  ret i64 %result
}

; Function Attrs: mustprogress nofree noinline norecurse nosync nounwind willreturn memory(inaccessiblemem: write)
define range(i64 0, 1000000007) i64 @scalar_assume_d1000000007(i64 %value) local_unnamed_addr #3 {
entry:
  %rem = srem i64 %value, 1000000007
  %isneg = icmp slt i64 %rem, 0
  %delta = select i1 %isneg, i64 1000000007, i64 0
  %result = add nsw i64 %delta, %rem
  %bounded = icmp ult i64 %result, 1000000007
  tail call void @llvm.assume(i1 %bounded)
  ret i64 %result
}

; Function Attrs: mustprogress nofree noinline norecurse nosync nounwind willreturn memory(none)
define range(i64 -1000000006, 2000000014) i64 @scalar_select_d1000000007(i64 %value) local_unnamed_addr #2 {
entry:
  %rem = srem i64 %value, 1000000007
  %negative = icmp slt i64 %rem, 0
  %shifted = add nsw i64 %rem, 1000000007
  %result = select i1 %negative, i64 %shifted, i64 %rem
  ret i64 %result
}

; Function Attrs: mustprogress nofree noinline norecurse nosync nounwind willreturn memory(inaccessiblemem: write)
define range(i64 0, 1000000007) i64 @scalar_select_assume_d1000000007(i64 %value) local_unnamed_addr #3 {
entry:
  %rem = srem i64 %value, 1000000007
  %negative = icmp slt i64 %rem, 0
  %shifted = add nsw i64 %rem, 1000000007
  %result = select i1 %negative, i64 %shifted, i64 %rem
  %bounded = icmp ult i64 %result, 1000000007
  tail call void @llvm.assume(i1 %bounded)
  ret i64 %result
}

; Function Attrs: mustprogress nofree noinline norecurse nosync nounwind willreturn memory(none)
define i64 @scalar_baseline_d9223372036854775807(i64 %value) local_unnamed_addr #2 {
entry:
  %rem = srem i64 %value, 9223372036854775807
  %isneg = icmp slt i64 %rem, 0
  %delta = select i1 %isneg, i64 9223372036854775807, i64 0
  %result = add i64 %delta, %rem
  ret i64 %result
}

; Function Attrs: mustprogress nofree noinline norecurse nosync nounwind willreturn memory(inaccessiblemem: write)
define range(i64 0, 9223372036854775807) i64 @scalar_assume_d9223372036854775807(i64 %value) local_unnamed_addr #3 {
entry:
  %rem = srem i64 %value, 9223372036854775807
  %isneg = icmp slt i64 %rem, 0
  %delta = select i1 %isneg, i64 9223372036854775807, i64 0
  %result = add i64 %delta, %rem
  %bounded = icmp ult i64 %result, 9223372036854775807
  tail call void @llvm.assume(i1 %bounded)
  ret i64 %result
}

; Function Attrs: mustprogress nofree noinline norecurse nosync nounwind willreturn memory(none)
define i64 @scalar_select_d9223372036854775807(i64 %value) local_unnamed_addr #2 {
entry:
  %rem = srem i64 %value, 9223372036854775807
  %negative = icmp slt i64 %rem, 0
  %shifted = add i64 %rem, 9223372036854775807
  %result = select i1 %negative, i64 %shifted, i64 %rem
  ret i64 %result
}

; Function Attrs: mustprogress nofree noinline norecurse nosync nounwind willreturn memory(inaccessiblemem: write)
define range(i64 0, 9223372036854775807) i64 @scalar_select_assume_d9223372036854775807(i64 %value) local_unnamed_addr #3 {
entry:
  %rem = srem i64 %value, 9223372036854775807
  %negative = icmp slt i64 %rem, 0
  %shifted = add i64 %rem, 9223372036854775807
  %result = select i1 %negative, i64 %shifted, i64 %rem
  %bounded = icmp ult i64 %result, 9223372036854775807
  tail call void @llvm.assume(i1 %bounded)
  ret i64 %result
}

; Function Attrs: nofree noinline norecurse nosync nounwind memory(argmem: readwrite)
define range(i64 0, 3) i64 @loop_zero_bool_baseline_d3(ptr readonly captures(none) %data, i64 %count, i64 %seed, ptr writeonly captures(none) initializes((0, 4)) %status) local_unnamed_addr #4 {
entry:
  store i32 0, ptr %status, align 4
  %empty = icmp eq i64 %count, 0
  br i1 %empty, label %common.ret, label %loop.preheader

loop.preheader:                                   ; preds = %entry
  %xtraiter = and i64 %count, 3
  %0 = icmp ult i64 %count, 4
  br i1 %0, label %loop.epil.preheader, label %loop.preheader.new

loop.preheader.new:                               ; preds = %loop.preheader
  %unroll_iter = and i64 %count, -4
  br label %loop

common.ret.loopexit.unr-lcssa:                    ; preds = %loop
  %lcmp.mod.not = icmp eq i64 %xtraiter, 0
  br i1 %lcmp.mod.not, label %common.ret, label %loop.epil.preheader

loop.epil.preheader:                              ; preds = %common.ret.loopexit.unr-lcssa, %loop.preheader
  %index.epil.init = phi i64 [ 0, %loop.preheader ], [ %next.3, %common.ret.loopexit.unr-lcssa ]
  %checksum.epil.init = phi i64 [ 0, %loop.preheader ], [ %rem.3, %common.ret.loopexit.unr-lcssa ]
  %lcmp.mod2 = icmp ne i64 %xtraiter, 0
  tail call void @llvm.assume(i1 %lcmp.mod2)
  br label %loop.epil

loop.epil:                                        ; preds = %loop.epil, %loop.epil.preheader
  %index.epil = phi i64 [ %next.epil, %loop.epil ], [ %index.epil.init, %loop.epil.preheader ]
  %checksum.epil = phi i64 [ %rem.epil, %loop.epil ], [ %checksum.epil.init, %loop.epil.preheader ]
  %epil.iter = phi i64 [ %epil.iter.next, %loop.epil ], [ 0, %loop.epil.preheader ]
  %address.epil = getelementptr i8, ptr %data, i64 %index.epil
  %flag.epil = load i8, ptr %address.epil, align 1
  %truth.epil = icmp ne i8 %flag.epil, 0
  %increment.epil = zext i1 %truth.epil to i64
  %addition.epil = add nuw nsw i64 %checksum.epil, %increment.epil
  %rem.epil = urem i64 %addition.epil, 3
  %next.epil = add nuw i64 %index.epil, 1
  %epil.iter.next = add i64 %epil.iter, 1
  %epil.iter.cmp.not = icmp eq i64 %epil.iter.next, %xtraiter
  br i1 %epil.iter.cmp.not, label %common.ret, label %loop.epil, !llvm.loop !0

common.ret:                                       ; preds = %common.ret.loopexit.unr-lcssa, %loop.epil, %entry
  %common.ret.op = phi i64 [ 0, %entry ], [ %rem.3, %common.ret.loopexit.unr-lcssa ], [ %rem.epil, %loop.epil ]
  ret i64 %common.ret.op

loop:                                             ; preds = %loop, %loop.preheader.new
  %index = phi i64 [ 0, %loop.preheader.new ], [ %next.3, %loop ]
  %checksum = phi i64 [ 0, %loop.preheader.new ], [ %rem.3, %loop ]
  %niter = phi i64 [ 0, %loop.preheader.new ], [ %niter.next.3, %loop ]
  %address = getelementptr i8, ptr %data, i64 %index
  %flag = load i8, ptr %address, align 1
  %truth = icmp ne i8 %flag, 0
  %increment = zext i1 %truth to i64
  %addition = add nuw nsw i64 %checksum, %increment
  %rem = urem i64 %addition, 3
  %1 = getelementptr i8, ptr %data, i64 %index
  %address.1 = getelementptr i8, ptr %1, i64 1
  %flag.1 = load i8, ptr %address.1, align 1
  %truth.1 = icmp ne i8 %flag.1, 0
  %increment.1 = zext i1 %truth.1 to i64
  %addition.1 = add nuw nsw i64 %rem, %increment.1
  %rem.1 = urem i64 %addition.1, 3
  %2 = getelementptr i8, ptr %data, i64 %index
  %address.2 = getelementptr i8, ptr %2, i64 2
  %flag.2 = load i8, ptr %address.2, align 1
  %truth.2 = icmp ne i8 %flag.2, 0
  %increment.2 = zext i1 %truth.2 to i64
  %addition.2 = add nuw nsw i64 %rem.1, %increment.2
  %rem.2 = urem i64 %addition.2, 3
  %3 = getelementptr i8, ptr %data, i64 %index
  %address.3 = getelementptr i8, ptr %3, i64 3
  %flag.3 = load i8, ptr %address.3, align 1
  %truth.3 = icmp ne i8 %flag.3, 0
  %increment.3 = zext i1 %truth.3 to i64
  %addition.3 = add nuw nsw i64 %rem.2, %increment.3
  %rem.3 = urem i64 %addition.3, 3
  %next.3 = add nuw i64 %index, 4
  %niter.next.3 = add i64 %niter, 4
  %niter.ncmp.3 = icmp eq i64 %niter.next.3, %unroll_iter
  br i1 %niter.ncmp.3, label %common.ret.loopexit.unr-lcssa, label %loop
}

; Function Attrs: nofree noinline norecurse nosync nounwind memory(argmem: readwrite)
define range(i64 0, 3) i64 @loop_zero_bool_assume_d3(ptr readonly captures(none) %data, i64 %count, i64 %seed, ptr writeonly captures(none) initializes((0, 4)) %status) local_unnamed_addr #4 {
entry:
  store i32 0, ptr %status, align 4
  %empty = icmp eq i64 %count, 0
  br i1 %empty, label %common.ret, label %loop.preheader

loop.preheader:                                   ; preds = %entry
  %xtraiter = and i64 %count, 3
  %0 = icmp ult i64 %count, 4
  br i1 %0, label %loop.epil.preheader, label %loop.preheader.new

loop.preheader.new:                               ; preds = %loop.preheader
  %unroll_iter = and i64 %count, -4
  br label %loop

common.ret.loopexit.unr-lcssa:                    ; preds = %loop
  %lcmp.mod.not = icmp eq i64 %xtraiter, 0
  br i1 %lcmp.mod.not, label %common.ret, label %loop.epil.preheader

loop.epil.preheader:                              ; preds = %common.ret.loopexit.unr-lcssa, %loop.preheader
  %index.epil.init = phi i64 [ 0, %loop.preheader ], [ %next.3, %common.ret.loopexit.unr-lcssa ]
  %checksum.epil.init = phi i64 [ 0, %loop.preheader ], [ %rem.3, %common.ret.loopexit.unr-lcssa ]
  %lcmp.mod2 = icmp ne i64 %xtraiter, 0
  tail call void @llvm.assume(i1 %lcmp.mod2)
  br label %loop.epil

loop.epil:                                        ; preds = %loop.epil, %loop.epil.preheader
  %index.epil = phi i64 [ %next.epil, %loop.epil ], [ %index.epil.init, %loop.epil.preheader ]
  %checksum.epil = phi i64 [ %rem.epil, %loop.epil ], [ %checksum.epil.init, %loop.epil.preheader ]
  %epil.iter = phi i64 [ %epil.iter.next, %loop.epil ], [ 0, %loop.epil.preheader ]
  %address.epil = getelementptr i8, ptr %data, i64 %index.epil
  %flag.epil = load i8, ptr %address.epil, align 1
  %truth.epil = icmp ne i8 %flag.epil, 0
  %increment.epil = zext i1 %truth.epil to i64
  %addition.epil = add nuw nsw i64 %checksum.epil, %increment.epil
  %rem.epil = urem i64 %addition.epil, 3
  %next.epil = add nuw i64 %index.epil, 1
  %epil.iter.next = add i64 %epil.iter, 1
  %epil.iter.cmp.not = icmp eq i64 %epil.iter.next, %xtraiter
  br i1 %epil.iter.cmp.not, label %common.ret, label %loop.epil, !llvm.loop !2

common.ret:                                       ; preds = %common.ret.loopexit.unr-lcssa, %loop.epil, %entry
  %common.ret.op = phi i64 [ 0, %entry ], [ %rem.3, %common.ret.loopexit.unr-lcssa ], [ %rem.epil, %loop.epil ]
  ret i64 %common.ret.op

loop:                                             ; preds = %loop, %loop.preheader.new
  %index = phi i64 [ 0, %loop.preheader.new ], [ %next.3, %loop ]
  %checksum = phi i64 [ 0, %loop.preheader.new ], [ %rem.3, %loop ]
  %niter = phi i64 [ 0, %loop.preheader.new ], [ %niter.next.3, %loop ]
  %address = getelementptr i8, ptr %data, i64 %index
  %flag = load i8, ptr %address, align 1
  %truth = icmp ne i8 %flag, 0
  %increment = zext i1 %truth to i64
  %addition = add nuw nsw i64 %checksum, %increment
  %rem = urem i64 %addition, 3
  %1 = getelementptr i8, ptr %data, i64 %index
  %address.1 = getelementptr i8, ptr %1, i64 1
  %flag.1 = load i8, ptr %address.1, align 1
  %truth.1 = icmp ne i8 %flag.1, 0
  %increment.1 = zext i1 %truth.1 to i64
  %addition.1 = add nuw nsw i64 %rem, %increment.1
  %rem.1 = urem i64 %addition.1, 3
  %2 = getelementptr i8, ptr %data, i64 %index
  %address.2 = getelementptr i8, ptr %2, i64 2
  %flag.2 = load i8, ptr %address.2, align 1
  %truth.2 = icmp ne i8 %flag.2, 0
  %increment.2 = zext i1 %truth.2 to i64
  %addition.2 = add nuw nsw i64 %rem.1, %increment.2
  %rem.2 = urem i64 %addition.2, 3
  %3 = getelementptr i8, ptr %data, i64 %index
  %address.3 = getelementptr i8, ptr %3, i64 3
  %flag.3 = load i8, ptr %address.3, align 1
  %truth.3 = icmp ne i8 %flag.3, 0
  %increment.3 = zext i1 %truth.3 to i64
  %addition.3 = add nuw nsw i64 %rem.2, %increment.3
  %rem.3 = urem i64 %addition.3, 3
  %next.3 = add nuw i64 %index, 4
  %niter.next.3 = add i64 %niter, 4
  %niter.ncmp.3 = icmp eq i64 %niter.next.3, %unroll_iter
  br i1 %niter.ncmp.3, label %common.ret.loopexit.unr-lcssa, label %loop
}

; Function Attrs: nofree noinline norecurse nosync nounwind memory(argmem: readwrite)
define range(i64 0, 3) i64 @loop_zero_bool_select_d3(ptr readonly captures(none) %data, i64 %count, i64 %seed, ptr writeonly captures(none) initializes((0, 4)) %status) local_unnamed_addr #4 {
entry:
  store i32 0, ptr %status, align 4
  %empty = icmp eq i64 %count, 0
  br i1 %empty, label %common.ret, label %loop.preheader

loop.preheader:                                   ; preds = %entry
  %xtraiter = and i64 %count, 3
  %0 = icmp ult i64 %count, 4
  br i1 %0, label %loop.epil.preheader, label %loop.preheader.new

loop.preheader.new:                               ; preds = %loop.preheader
  %unroll_iter = and i64 %count, -4
  br label %loop

common.ret.loopexit.unr-lcssa:                    ; preds = %loop
  %lcmp.mod.not = icmp eq i64 %xtraiter, 0
  br i1 %lcmp.mod.not, label %common.ret, label %loop.epil.preheader

loop.epil.preheader:                              ; preds = %common.ret.loopexit.unr-lcssa, %loop.preheader
  %index.epil.init = phi i64 [ 0, %loop.preheader ], [ %next.3, %common.ret.loopexit.unr-lcssa ]
  %checksum.epil.init = phi i64 [ 0, %loop.preheader ], [ %rem.3, %common.ret.loopexit.unr-lcssa ]
  %lcmp.mod2 = icmp ne i64 %xtraiter, 0
  tail call void @llvm.assume(i1 %lcmp.mod2)
  br label %loop.epil

loop.epil:                                        ; preds = %loop.epil, %loop.epil.preheader
  %index.epil = phi i64 [ %next.epil, %loop.epil ], [ %index.epil.init, %loop.epil.preheader ]
  %checksum.epil = phi i64 [ %rem.epil, %loop.epil ], [ %checksum.epil.init, %loop.epil.preheader ]
  %epil.iter = phi i64 [ %epil.iter.next, %loop.epil ], [ 0, %loop.epil.preheader ]
  %address.epil = getelementptr i8, ptr %data, i64 %index.epil
  %flag.epil = load i8, ptr %address.epil, align 1
  %truth.epil = icmp ne i8 %flag.epil, 0
  %increment.epil = zext i1 %truth.epil to i64
  %addition.epil = add nuw nsw i64 %checksum.epil, %increment.epil
  %rem.epil = urem i64 %addition.epil, 3
  %next.epil = add nuw i64 %index.epil, 1
  %epil.iter.next = add i64 %epil.iter, 1
  %epil.iter.cmp.not = icmp eq i64 %epil.iter.next, %xtraiter
  br i1 %epil.iter.cmp.not, label %common.ret, label %loop.epil, !llvm.loop !3

common.ret:                                       ; preds = %common.ret.loopexit.unr-lcssa, %loop.epil, %entry
  %common.ret.op = phi i64 [ 0, %entry ], [ %rem.3, %common.ret.loopexit.unr-lcssa ], [ %rem.epil, %loop.epil ]
  ret i64 %common.ret.op

loop:                                             ; preds = %loop, %loop.preheader.new
  %index = phi i64 [ 0, %loop.preheader.new ], [ %next.3, %loop ]
  %checksum = phi i64 [ 0, %loop.preheader.new ], [ %rem.3, %loop ]
  %niter = phi i64 [ 0, %loop.preheader.new ], [ %niter.next.3, %loop ]
  %address = getelementptr i8, ptr %data, i64 %index
  %flag = load i8, ptr %address, align 1
  %truth = icmp ne i8 %flag, 0
  %increment = zext i1 %truth to i64
  %addition = add nuw nsw i64 %checksum, %increment
  %rem = urem i64 %addition, 3
  %1 = getelementptr i8, ptr %data, i64 %index
  %address.1 = getelementptr i8, ptr %1, i64 1
  %flag.1 = load i8, ptr %address.1, align 1
  %truth.1 = icmp ne i8 %flag.1, 0
  %increment.1 = zext i1 %truth.1 to i64
  %addition.1 = add nuw nsw i64 %rem, %increment.1
  %rem.1 = urem i64 %addition.1, 3
  %2 = getelementptr i8, ptr %data, i64 %index
  %address.2 = getelementptr i8, ptr %2, i64 2
  %flag.2 = load i8, ptr %address.2, align 1
  %truth.2 = icmp ne i8 %flag.2, 0
  %increment.2 = zext i1 %truth.2 to i64
  %addition.2 = add nuw nsw i64 %rem.1, %increment.2
  %rem.2 = urem i64 %addition.2, 3
  %3 = getelementptr i8, ptr %data, i64 %index
  %address.3 = getelementptr i8, ptr %3, i64 3
  %flag.3 = load i8, ptr %address.3, align 1
  %truth.3 = icmp ne i8 %flag.3, 0
  %increment.3 = zext i1 %truth.3 to i64
  %addition.3 = add nuw nsw i64 %rem.2, %increment.3
  %rem.3 = urem i64 %addition.3, 3
  %next.3 = add nuw i64 %index, 4
  %niter.next.3 = add i64 %niter, 4
  %niter.ncmp.3 = icmp eq i64 %niter.next.3, %unroll_iter
  br i1 %niter.ncmp.3, label %common.ret.loopexit.unr-lcssa, label %loop
}

; Function Attrs: nofree noinline norecurse nosync nounwind memory(argmem: readwrite)
define range(i64 0, 3) i64 @loop_zero_bool_select_assume_d3(ptr readonly captures(none) %data, i64 %count, i64 %seed, ptr writeonly captures(none) initializes((0, 4)) %status) local_unnamed_addr #4 {
entry:
  store i32 0, ptr %status, align 4
  %empty = icmp eq i64 %count, 0
  br i1 %empty, label %common.ret, label %loop.preheader

loop.preheader:                                   ; preds = %entry
  %xtraiter = and i64 %count, 3
  %0 = icmp ult i64 %count, 4
  br i1 %0, label %loop.epil.preheader, label %loop.preheader.new

loop.preheader.new:                               ; preds = %loop.preheader
  %unroll_iter = and i64 %count, -4
  br label %loop

common.ret.loopexit.unr-lcssa:                    ; preds = %loop
  %lcmp.mod.not = icmp eq i64 %xtraiter, 0
  br i1 %lcmp.mod.not, label %common.ret, label %loop.epil.preheader

loop.epil.preheader:                              ; preds = %common.ret.loopexit.unr-lcssa, %loop.preheader
  %index.epil.init = phi i64 [ 0, %loop.preheader ], [ %next.3, %common.ret.loopexit.unr-lcssa ]
  %checksum.epil.init = phi i64 [ 0, %loop.preheader ], [ %rem.3, %common.ret.loopexit.unr-lcssa ]
  %lcmp.mod2 = icmp ne i64 %xtraiter, 0
  tail call void @llvm.assume(i1 %lcmp.mod2)
  br label %loop.epil

loop.epil:                                        ; preds = %loop.epil, %loop.epil.preheader
  %index.epil = phi i64 [ %next.epil, %loop.epil ], [ %index.epil.init, %loop.epil.preheader ]
  %checksum.epil = phi i64 [ %rem.epil, %loop.epil ], [ %checksum.epil.init, %loop.epil.preheader ]
  %epil.iter = phi i64 [ %epil.iter.next, %loop.epil ], [ 0, %loop.epil.preheader ]
  %address.epil = getelementptr i8, ptr %data, i64 %index.epil
  %flag.epil = load i8, ptr %address.epil, align 1
  %truth.epil = icmp ne i8 %flag.epil, 0
  %increment.epil = zext i1 %truth.epil to i64
  %addition.epil = add nuw nsw i64 %checksum.epil, %increment.epil
  %rem.epil = urem i64 %addition.epil, 3
  %next.epil = add nuw i64 %index.epil, 1
  %epil.iter.next = add i64 %epil.iter, 1
  %epil.iter.cmp.not = icmp eq i64 %epil.iter.next, %xtraiter
  br i1 %epil.iter.cmp.not, label %common.ret, label %loop.epil, !llvm.loop !4

common.ret:                                       ; preds = %common.ret.loopexit.unr-lcssa, %loop.epil, %entry
  %common.ret.op = phi i64 [ 0, %entry ], [ %rem.3, %common.ret.loopexit.unr-lcssa ], [ %rem.epil, %loop.epil ]
  ret i64 %common.ret.op

loop:                                             ; preds = %loop, %loop.preheader.new
  %index = phi i64 [ 0, %loop.preheader.new ], [ %next.3, %loop ]
  %checksum = phi i64 [ 0, %loop.preheader.new ], [ %rem.3, %loop ]
  %niter = phi i64 [ 0, %loop.preheader.new ], [ %niter.next.3, %loop ]
  %address = getelementptr i8, ptr %data, i64 %index
  %flag = load i8, ptr %address, align 1
  %truth = icmp ne i8 %flag, 0
  %increment = zext i1 %truth to i64
  %addition = add nuw nsw i64 %checksum, %increment
  %rem = urem i64 %addition, 3
  %1 = getelementptr i8, ptr %data, i64 %index
  %address.1 = getelementptr i8, ptr %1, i64 1
  %flag.1 = load i8, ptr %address.1, align 1
  %truth.1 = icmp ne i8 %flag.1, 0
  %increment.1 = zext i1 %truth.1 to i64
  %addition.1 = add nuw nsw i64 %rem, %increment.1
  %rem.1 = urem i64 %addition.1, 3
  %2 = getelementptr i8, ptr %data, i64 %index
  %address.2 = getelementptr i8, ptr %2, i64 2
  %flag.2 = load i8, ptr %address.2, align 1
  %truth.2 = icmp ne i8 %flag.2, 0
  %increment.2 = zext i1 %truth.2 to i64
  %addition.2 = add nuw nsw i64 %rem.1, %increment.2
  %rem.2 = urem i64 %addition.2, 3
  %3 = getelementptr i8, ptr %data, i64 %index
  %address.3 = getelementptr i8, ptr %3, i64 3
  %flag.3 = load i8, ptr %address.3, align 1
  %truth.3 = icmp ne i8 %flag.3, 0
  %increment.3 = zext i1 %truth.3 to i64
  %addition.3 = add nuw nsw i64 %rem.2, %increment.3
  %rem.3 = urem i64 %addition.3, 3
  %next.3 = add nuw i64 %index, 4
  %niter.next.3 = add i64 %niter, 4
  %niter.ncmp.3 = icmp eq i64 %niter.next.3, %unroll_iter
  br i1 %niter.ncmp.3, label %common.ret.loopexit.unr-lcssa, label %loop
}

; Function Attrs: nofree noinline norecurse nosync nounwind memory(argmem: readwrite)
define i64 @loop_seeded_bool_baseline_d3(ptr readonly captures(none) %data, i64 %count, i64 %seed, ptr writeonly captures(none) initializes((0, 4)) %status) local_unnamed_addr #4 {
entry:
  store i32 0, ptr %status, align 4
  %empty = icmp eq i64 %count, 0
  br i1 %empty, label %common.ret, label %loop

common.ret:                                       ; preds = %success, %entry, %failure
  %common.ret.op = phi i64 [ %seed, %entry ], [ 0, %failure ], [ %result, %success ]
  ret i64 %common.ret.op

loop:                                             ; preds = %entry, %success
  %index = phi i64 [ %next, %success ], [ 0, %entry ]
  %checksum = phi i64 [ %result, %success ], [ %seed, %entry ]
  %address = getelementptr i8, ptr %data, i64 %index
  %flag = load i8, ptr %address, align 1
  %truth = icmp ne i8 %flag, 0
  %increment = zext i1 %truth to i64
  %addition = tail call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %checksum, i64 %increment)
  %overflow = extractvalue { i64, i1 } %addition, 1
  br i1 %overflow, label %failure, label %success

failure:                                          ; preds = %loop
  store i32 1, ptr %status, align 4
  br label %common.ret

success:                                          ; preds = %loop
  %sum = extractvalue { i64, i1 } %addition, 0
  %rem = srem i64 %sum, 3
  %isneg = icmp slt i64 %rem, 0
  %delta = select i1 %isneg, i64 3, i64 0
  %result = add nsw i64 %delta, %rem
  %next = add nuw i64 %index, 1
  %done = icmp eq i64 %next, %count
  br i1 %done, label %common.ret, label %loop
}

; Function Attrs: nofree noinline norecurse nosync nounwind memory(argmem: readwrite, inaccessiblemem: write)
define i64 @loop_seeded_bool_assume_d3(ptr readonly captures(none) %data, i64 %count, i64 %seed, ptr writeonly captures(none) initializes((0, 4)) %status) local_unnamed_addr #5 {
entry:
  store i32 0, ptr %status, align 4
  %empty = icmp eq i64 %count, 0
  br i1 %empty, label %common.ret, label %loop

common.ret:                                       ; preds = %success, %entry, %failure
  %common.ret.op = phi i64 [ %seed, %entry ], [ 0, %failure ], [ %result, %success ]
  ret i64 %common.ret.op

loop:                                             ; preds = %entry, %success
  %index = phi i64 [ %next, %success ], [ 0, %entry ]
  %checksum = phi i64 [ %result, %success ], [ %seed, %entry ]
  %address = getelementptr i8, ptr %data, i64 %index
  %flag = load i8, ptr %address, align 1
  %truth = icmp ne i8 %flag, 0
  %increment = zext i1 %truth to i64
  %addition = tail call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %checksum, i64 %increment)
  %overflow = extractvalue { i64, i1 } %addition, 1
  br i1 %overflow, label %failure, label %success

failure:                                          ; preds = %loop
  store i32 1, ptr %status, align 4
  br label %common.ret

success:                                          ; preds = %loop
  %sum = extractvalue { i64, i1 } %addition, 0
  %rem = srem i64 %sum, 3
  %isneg = icmp slt i64 %rem, 0
  %delta = select i1 %isneg, i64 3, i64 0
  %result = add nsw i64 %delta, %rem
  %bounded = icmp ult i64 %result, 3
  tail call void @llvm.assume(i1 %bounded)
  %next = add nuw i64 %index, 1
  %done = icmp eq i64 %next, %count
  br i1 %done, label %common.ret, label %loop
}

; Function Attrs: nofree noinline norecurse nosync nounwind memory(argmem: readwrite)
define i64 @loop_seeded_bool_select_d3(ptr readonly captures(none) %data, i64 %count, i64 %seed, ptr writeonly captures(none) initializes((0, 4)) %status) local_unnamed_addr #4 {
entry:
  store i32 0, ptr %status, align 4
  %empty = icmp eq i64 %count, 0
  br i1 %empty, label %common.ret, label %loop

common.ret:                                       ; preds = %success, %entry, %failure
  %common.ret.op = phi i64 [ %seed, %entry ], [ 0, %failure ], [ %result, %success ]
  ret i64 %common.ret.op

loop:                                             ; preds = %entry, %success
  %index = phi i64 [ %next, %success ], [ 0, %entry ]
  %checksum = phi i64 [ %result, %success ], [ %seed, %entry ]
  %address = getelementptr i8, ptr %data, i64 %index
  %flag = load i8, ptr %address, align 1
  %truth = icmp ne i8 %flag, 0
  %increment = zext i1 %truth to i64
  %addition = tail call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %checksum, i64 %increment)
  %overflow = extractvalue { i64, i1 } %addition, 1
  br i1 %overflow, label %failure, label %success

failure:                                          ; preds = %loop
  store i32 1, ptr %status, align 4
  br label %common.ret

success:                                          ; preds = %loop
  %sum = extractvalue { i64, i1 } %addition, 0
  %rem = srem i64 %sum, 3
  %negative = icmp slt i64 %rem, 0
  %shifted = add nsw i64 %rem, 3
  %result = select i1 %negative, i64 %shifted, i64 %rem
  %next = add nuw i64 %index, 1
  %done = icmp eq i64 %next, %count
  br i1 %done, label %common.ret, label %loop
}

; Function Attrs: nofree noinline norecurse nosync nounwind memory(argmem: readwrite, inaccessiblemem: write)
define i64 @loop_seeded_bool_select_assume_d3(ptr readonly captures(none) %data, i64 %count, i64 %seed, ptr writeonly captures(none) initializes((0, 4)) %status) local_unnamed_addr #5 {
entry:
  store i32 0, ptr %status, align 4
  %empty = icmp eq i64 %count, 0
  br i1 %empty, label %common.ret, label %loop

common.ret:                                       ; preds = %success, %entry, %failure
  %common.ret.op = phi i64 [ %seed, %entry ], [ 0, %failure ], [ %result, %success ]
  ret i64 %common.ret.op

loop:                                             ; preds = %entry, %success
  %index = phi i64 [ %next, %success ], [ 0, %entry ]
  %checksum = phi i64 [ %result, %success ], [ %seed, %entry ]
  %address = getelementptr i8, ptr %data, i64 %index
  %flag = load i8, ptr %address, align 1
  %truth = icmp ne i8 %flag, 0
  %increment = zext i1 %truth to i64
  %addition = tail call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %checksum, i64 %increment)
  %overflow = extractvalue { i64, i1 } %addition, 1
  br i1 %overflow, label %failure, label %success

failure:                                          ; preds = %loop
  store i32 1, ptr %status, align 4
  br label %common.ret

success:                                          ; preds = %loop
  %sum = extractvalue { i64, i1 } %addition, 0
  %rem = srem i64 %sum, 3
  %negative = icmp slt i64 %rem, 0
  %shifted = add nsw i64 %rem, 3
  %result = select i1 %negative, i64 %shifted, i64 %rem
  %bounded = icmp ult i64 %result, 3
  tail call void @llvm.assume(i1 %bounded)
  %next = add nuw i64 %index, 1
  %done = icmp eq i64 %next, %count
  br i1 %done, label %common.ret, label %loop
}

; Function Attrs: nofree noinline norecurse nosync nounwind memory(argmem: readwrite)
define range(i64 -2, 6) i64 @loop_signed_updates_baseline_d3(ptr readonly captures(none) %data, i64 %count, i64 %seed, ptr writeonly captures(none) initializes((0, 4)) %status) local_unnamed_addr #4 {
entry:
  store i32 0, ptr %status, align 4
  %empty = icmp eq i64 %count, 0
  br i1 %empty, label %common.ret, label %loop

common.ret:                                       ; preds = %success, %entry, %failure
  %common.ret.op = phi i64 [ 0, %entry ], [ 0, %failure ], [ %result, %success ]
  ret i64 %common.ret.op

loop:                                             ; preds = %entry, %success
  %index = phi i64 [ %next, %success ], [ 0, %entry ]
  %checksum = phi i64 [ %result, %success ], [ 0, %entry ]
  %address = getelementptr i64, ptr %data, i64 %index
  %increment = load i64, ptr %address, align 8
  %addition = tail call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %checksum, i64 %increment)
  %overflow = extractvalue { i64, i1 } %addition, 1
  br i1 %overflow, label %failure, label %success

failure:                                          ; preds = %loop
  store i32 1, ptr %status, align 4
  br label %common.ret

success:                                          ; preds = %loop
  %sum = extractvalue { i64, i1 } %addition, 0
  %rem = srem i64 %sum, 3
  %isneg = icmp slt i64 %rem, 0
  %delta = select i1 %isneg, i64 3, i64 0
  %result = add nsw i64 %delta, %rem
  %next = add nuw i64 %index, 1
  %done = icmp eq i64 %next, %count
  br i1 %done, label %common.ret, label %loop
}

; Function Attrs: nofree noinline norecurse nosync nounwind memory(argmem: readwrite, inaccessiblemem: write)
define range(i64 0, 3) i64 @loop_signed_updates_assume_d3(ptr readonly captures(none) %data, i64 %count, i64 %seed, ptr writeonly captures(none) initializes((0, 4)) %status) local_unnamed_addr #5 {
entry:
  store i32 0, ptr %status, align 4
  %empty = icmp eq i64 %count, 0
  br i1 %empty, label %common.ret, label %loop

common.ret:                                       ; preds = %success, %entry, %failure
  %common.ret.op = phi i64 [ 0, %entry ], [ 0, %failure ], [ %result, %success ]
  ret i64 %common.ret.op

loop:                                             ; preds = %entry, %success
  %index = phi i64 [ %next, %success ], [ 0, %entry ]
  %checksum = phi i64 [ %result, %success ], [ 0, %entry ]
  %address = getelementptr i64, ptr %data, i64 %index
  %increment = load i64, ptr %address, align 8
  %addition = tail call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %checksum, i64 %increment)
  %overflow = extractvalue { i64, i1 } %addition, 1
  br i1 %overflow, label %failure, label %success

failure:                                          ; preds = %loop
  store i32 1, ptr %status, align 4
  br label %common.ret

success:                                          ; preds = %loop
  %sum = extractvalue { i64, i1 } %addition, 0
  %rem = srem i64 %sum, 3
  %isneg = icmp slt i64 %rem, 0
  %delta = select i1 %isneg, i64 3, i64 0
  %result = add nsw i64 %delta, %rem
  %bounded = icmp ult i64 %result, 3
  tail call void @llvm.assume(i1 %bounded)
  %next = add nuw i64 %index, 1
  %done = icmp eq i64 %next, %count
  br i1 %done, label %common.ret, label %loop
}

; Function Attrs: nofree noinline norecurse nosync nounwind memory(argmem: readwrite)
define range(i64 -2, 6) i64 @loop_signed_updates_select_d3(ptr readonly captures(none) %data, i64 %count, i64 %seed, ptr writeonly captures(none) initializes((0, 4)) %status) local_unnamed_addr #4 {
entry:
  store i32 0, ptr %status, align 4
  %empty = icmp eq i64 %count, 0
  br i1 %empty, label %common.ret, label %loop

common.ret:                                       ; preds = %success, %entry, %failure
  %common.ret.op = phi i64 [ 0, %entry ], [ 0, %failure ], [ %result, %success ]
  ret i64 %common.ret.op

loop:                                             ; preds = %entry, %success
  %index = phi i64 [ %next, %success ], [ 0, %entry ]
  %checksum = phi i64 [ %result, %success ], [ 0, %entry ]
  %address = getelementptr i64, ptr %data, i64 %index
  %increment = load i64, ptr %address, align 8
  %addition = tail call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %checksum, i64 %increment)
  %overflow = extractvalue { i64, i1 } %addition, 1
  br i1 %overflow, label %failure, label %success

failure:                                          ; preds = %loop
  store i32 1, ptr %status, align 4
  br label %common.ret

success:                                          ; preds = %loop
  %sum = extractvalue { i64, i1 } %addition, 0
  %rem = srem i64 %sum, 3
  %negative = icmp slt i64 %rem, 0
  %shifted = add nsw i64 %rem, 3
  %result = select i1 %negative, i64 %shifted, i64 %rem
  %next = add nuw i64 %index, 1
  %done = icmp eq i64 %next, %count
  br i1 %done, label %common.ret, label %loop
}

; Function Attrs: nofree noinline norecurse nosync nounwind memory(argmem: readwrite, inaccessiblemem: write)
define range(i64 0, 3) i64 @loop_signed_updates_select_assume_d3(ptr readonly captures(none) %data, i64 %count, i64 %seed, ptr writeonly captures(none) initializes((0, 4)) %status) local_unnamed_addr #5 {
entry:
  store i32 0, ptr %status, align 4
  %empty = icmp eq i64 %count, 0
  br i1 %empty, label %common.ret, label %loop

common.ret:                                       ; preds = %success, %entry, %failure
  %common.ret.op = phi i64 [ 0, %entry ], [ 0, %failure ], [ %result, %success ]
  ret i64 %common.ret.op

loop:                                             ; preds = %entry, %success
  %index = phi i64 [ %next, %success ], [ 0, %entry ]
  %checksum = phi i64 [ %result, %success ], [ 0, %entry ]
  %address = getelementptr i64, ptr %data, i64 %index
  %increment = load i64, ptr %address, align 8
  %addition = tail call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %checksum, i64 %increment)
  %overflow = extractvalue { i64, i1 } %addition, 1
  br i1 %overflow, label %failure, label %success

failure:                                          ; preds = %loop
  store i32 1, ptr %status, align 4
  br label %common.ret

success:                                          ; preds = %loop
  %sum = extractvalue { i64, i1 } %addition, 0
  %rem = srem i64 %sum, 3
  %negative = icmp slt i64 %rem, 0
  %shifted = add nsw i64 %rem, 3
  %result = select i1 %negative, i64 %shifted, i64 %rem
  %bounded = icmp ult i64 %result, 3
  tail call void @llvm.assume(i1 %bounded)
  %next = add nuw i64 %index, 1
  %done = icmp eq i64 %next, %count
  br i1 %done, label %common.ret, label %loop
}

; Function Attrs: nofree noinline norecurse nosync nounwind memory(argmem: readwrite)
define range(i64 -1000000006, 2000000014) i64 @loop_zero_bool_baseline_d1000000007(ptr readonly captures(none) %data, i64 %count, i64 %seed, ptr writeonly captures(none) initializes((0, 4)) %status) local_unnamed_addr #4 {
entry:
  store i32 0, ptr %status, align 4
  %empty = icmp eq i64 %count, 0
  br i1 %empty, label %common.ret, label %loop.preheader

loop.preheader:                                   ; preds = %entry
  %xtraiter = and i64 %count, 3
  %0 = icmp ult i64 %count, 4
  br i1 %0, label %loop.epil.preheader, label %loop.preheader.new

loop.preheader.new:                               ; preds = %loop.preheader
  %unroll_iter = and i64 %count, -4
  br label %loop

common.ret.loopexit.unr-lcssa:                    ; preds = %loop
  %lcmp.mod.not = icmp eq i64 %xtraiter, 0
  br i1 %lcmp.mod.not, label %common.ret, label %loop.epil.preheader

loop.epil.preheader:                              ; preds = %common.ret.loopexit.unr-lcssa, %loop.preheader
  %index.epil.init = phi i64 [ 0, %loop.preheader ], [ %next.3, %common.ret.loopexit.unr-lcssa ]
  %checksum.epil.init = phi i64 [ 0, %loop.preheader ], [ %result.3, %common.ret.loopexit.unr-lcssa ]
  %lcmp.mod2 = icmp ne i64 %xtraiter, 0
  tail call void @llvm.assume(i1 %lcmp.mod2)
  br label %loop.epil

loop.epil:                                        ; preds = %loop.epil, %loop.epil.preheader
  %index.epil = phi i64 [ %next.epil, %loop.epil ], [ %index.epil.init, %loop.epil.preheader ]
  %checksum.epil = phi i64 [ %result.epil, %loop.epil ], [ %checksum.epil.init, %loop.epil.preheader ]
  %epil.iter = phi i64 [ %epil.iter.next, %loop.epil ], [ 0, %loop.epil.preheader ]
  %address.epil = getelementptr i8, ptr %data, i64 %index.epil
  %flag.epil = load i8, ptr %address.epil, align 1
  %truth.epil = icmp ne i8 %flag.epil, 0
  %increment.epil = zext i1 %truth.epil to i64
  %addition.epil = add nsw i64 %checksum.epil, %increment.epil
  %rem.epil = srem i64 %addition.epil, 1000000007
  %isneg.epil = icmp slt i64 %rem.epil, 0
  %delta.epil = select i1 %isneg.epil, i64 1000000007, i64 0
  %result.epil = add nsw i64 %delta.epil, %rem.epil
  %next.epil = add nuw i64 %index.epil, 1
  %epil.iter.next = add i64 %epil.iter, 1
  %epil.iter.cmp.not = icmp eq i64 %epil.iter.next, %xtraiter
  br i1 %epil.iter.cmp.not, label %common.ret, label %loop.epil, !llvm.loop !5

common.ret:                                       ; preds = %common.ret.loopexit.unr-lcssa, %loop.epil, %entry
  %common.ret.op = phi i64 [ 0, %entry ], [ %result.3, %common.ret.loopexit.unr-lcssa ], [ %result.epil, %loop.epil ]
  ret i64 %common.ret.op

loop:                                             ; preds = %loop, %loop.preheader.new
  %index = phi i64 [ 0, %loop.preheader.new ], [ %next.3, %loop ]
  %checksum = phi i64 [ 0, %loop.preheader.new ], [ %result.3, %loop ]
  %niter = phi i64 [ 0, %loop.preheader.new ], [ %niter.next.3, %loop ]
  %address = getelementptr i8, ptr %data, i64 %index
  %flag = load i8, ptr %address, align 1
  %truth = icmp ne i8 %flag, 0
  %increment = zext i1 %truth to i64
  %addition = add nsw i64 %checksum, %increment
  %rem = srem i64 %addition, 1000000007
  %isneg = icmp slt i64 %rem, 0
  %delta = select i1 %isneg, i64 1000000007, i64 0
  %result = add nsw i64 %delta, %rem
  %1 = getelementptr i8, ptr %data, i64 %index
  %address.1 = getelementptr i8, ptr %1, i64 1
  %flag.1 = load i8, ptr %address.1, align 1
  %truth.1 = icmp ne i8 %flag.1, 0
  %increment.1 = zext i1 %truth.1 to i64
  %addition.1 = add nsw i64 %result, %increment.1
  %rem.1 = srem i64 %addition.1, 1000000007
  %isneg.1 = icmp slt i64 %rem.1, 0
  %delta.1 = select i1 %isneg.1, i64 1000000007, i64 0
  %result.1 = add nsw i64 %delta.1, %rem.1
  %2 = getelementptr i8, ptr %data, i64 %index
  %address.2 = getelementptr i8, ptr %2, i64 2
  %flag.2 = load i8, ptr %address.2, align 1
  %truth.2 = icmp ne i8 %flag.2, 0
  %increment.2 = zext i1 %truth.2 to i64
  %addition.2 = add nsw i64 %result.1, %increment.2
  %rem.2 = srem i64 %addition.2, 1000000007
  %isneg.2 = icmp slt i64 %rem.2, 0
  %delta.2 = select i1 %isneg.2, i64 1000000007, i64 0
  %result.2 = add nsw i64 %delta.2, %rem.2
  %3 = getelementptr i8, ptr %data, i64 %index
  %address.3 = getelementptr i8, ptr %3, i64 3
  %flag.3 = load i8, ptr %address.3, align 1
  %truth.3 = icmp ne i8 %flag.3, 0
  %increment.3 = zext i1 %truth.3 to i64
  %addition.3 = add nsw i64 %result.2, %increment.3
  %rem.3 = srem i64 %addition.3, 1000000007
  %isneg.3 = icmp slt i64 %rem.3, 0
  %delta.3 = select i1 %isneg.3, i64 1000000007, i64 0
  %result.3 = add nsw i64 %delta.3, %rem.3
  %next.3 = add nuw i64 %index, 4
  %niter.next.3 = add i64 %niter, 4
  %niter.ncmp.3 = icmp eq i64 %niter.next.3, %unroll_iter
  br i1 %niter.ncmp.3, label %common.ret.loopexit.unr-lcssa, label %loop
}

; Function Attrs: nofree noinline norecurse nosync nounwind memory(argmem: readwrite)
define range(i64 0, 1000000007) i64 @loop_zero_bool_assume_d1000000007(ptr readonly captures(none) %data, i64 %count, i64 %seed, ptr writeonly captures(none) initializes((0, 4)) %status) local_unnamed_addr #4 {
entry:
  store i32 0, ptr %status, align 4
  %empty = icmp eq i64 %count, 0
  br i1 %empty, label %common.ret, label %loop.preheader

loop.preheader:                                   ; preds = %entry
  %xtraiter = and i64 %count, 3
  %0 = icmp ult i64 %count, 4
  br i1 %0, label %loop.epil.preheader, label %loop.preheader.new

loop.preheader.new:                               ; preds = %loop.preheader
  %unroll_iter = and i64 %count, -4
  br label %loop

common.ret.loopexit.unr-lcssa:                    ; preds = %loop
  %lcmp.mod.not = icmp eq i64 %xtraiter, 0
  br i1 %lcmp.mod.not, label %common.ret, label %loop.epil.preheader

loop.epil.preheader:                              ; preds = %common.ret.loopexit.unr-lcssa, %loop.preheader
  %index.epil.init = phi i64 [ 0, %loop.preheader ], [ %next.3, %common.ret.loopexit.unr-lcssa ]
  %checksum.epil.init = phi i64 [ 0, %loop.preheader ], [ %rem.3, %common.ret.loopexit.unr-lcssa ]
  %lcmp.mod2 = icmp ne i64 %xtraiter, 0
  tail call void @llvm.assume(i1 %lcmp.mod2)
  br label %loop.epil

loop.epil:                                        ; preds = %loop.epil, %loop.epil.preheader
  %index.epil = phi i64 [ %next.epil, %loop.epil ], [ %index.epil.init, %loop.epil.preheader ]
  %checksum.epil = phi i64 [ %rem.epil, %loop.epil ], [ %checksum.epil.init, %loop.epil.preheader ]
  %epil.iter = phi i64 [ %epil.iter.next, %loop.epil ], [ 0, %loop.epil.preheader ]
  %address.epil = getelementptr i8, ptr %data, i64 %index.epil
  %flag.epil = load i8, ptr %address.epil, align 1
  %truth.epil = icmp ne i8 %flag.epil, 0
  %increment.epil = zext i1 %truth.epil to i64
  %addition.epil = add nuw nsw i64 %checksum.epil, %increment.epil
  %rem.epil = urem i64 %addition.epil, 1000000007
  %next.epil = add nuw i64 %index.epil, 1
  %epil.iter.next = add i64 %epil.iter, 1
  %epil.iter.cmp.not = icmp eq i64 %epil.iter.next, %xtraiter
  br i1 %epil.iter.cmp.not, label %common.ret, label %loop.epil, !llvm.loop !6

common.ret:                                       ; preds = %common.ret.loopexit.unr-lcssa, %loop.epil, %entry
  %common.ret.op = phi i64 [ 0, %entry ], [ %rem.3, %common.ret.loopexit.unr-lcssa ], [ %rem.epil, %loop.epil ]
  ret i64 %common.ret.op

loop:                                             ; preds = %loop, %loop.preheader.new
  %index = phi i64 [ 0, %loop.preheader.new ], [ %next.3, %loop ]
  %checksum = phi i64 [ 0, %loop.preheader.new ], [ %rem.3, %loop ]
  %niter = phi i64 [ 0, %loop.preheader.new ], [ %niter.next.3, %loop ]
  %address = getelementptr i8, ptr %data, i64 %index
  %flag = load i8, ptr %address, align 1
  %truth = icmp ne i8 %flag, 0
  %increment = zext i1 %truth to i64
  %addition = add nuw nsw i64 %checksum, %increment
  %rem = urem i64 %addition, 1000000007
  %1 = getelementptr i8, ptr %data, i64 %index
  %address.1 = getelementptr i8, ptr %1, i64 1
  %flag.1 = load i8, ptr %address.1, align 1
  %truth.1 = icmp ne i8 %flag.1, 0
  %increment.1 = zext i1 %truth.1 to i64
  %addition.1 = add nuw nsw i64 %rem, %increment.1
  %rem.1 = urem i64 %addition.1, 1000000007
  %2 = getelementptr i8, ptr %data, i64 %index
  %address.2 = getelementptr i8, ptr %2, i64 2
  %flag.2 = load i8, ptr %address.2, align 1
  %truth.2 = icmp ne i8 %flag.2, 0
  %increment.2 = zext i1 %truth.2 to i64
  %addition.2 = add nuw nsw i64 %rem.1, %increment.2
  %rem.2 = urem i64 %addition.2, 1000000007
  %3 = getelementptr i8, ptr %data, i64 %index
  %address.3 = getelementptr i8, ptr %3, i64 3
  %flag.3 = load i8, ptr %address.3, align 1
  %truth.3 = icmp ne i8 %flag.3, 0
  %increment.3 = zext i1 %truth.3 to i64
  %addition.3 = add nuw nsw i64 %rem.2, %increment.3
  %rem.3 = urem i64 %addition.3, 1000000007
  %next.3 = add nuw i64 %index, 4
  %niter.next.3 = add i64 %niter, 4
  %niter.ncmp.3 = icmp eq i64 %niter.next.3, %unroll_iter
  br i1 %niter.ncmp.3, label %common.ret.loopexit.unr-lcssa, label %loop
}

; Function Attrs: nofree noinline norecurse nosync nounwind memory(argmem: readwrite)
define range(i64 -1000000006, 2000000014) i64 @loop_zero_bool_select_d1000000007(ptr readonly captures(none) %data, i64 %count, i64 %seed, ptr writeonly captures(none) initializes((0, 4)) %status) local_unnamed_addr #4 {
entry:
  store i32 0, ptr %status, align 4
  %empty = icmp eq i64 %count, 0
  br i1 %empty, label %common.ret, label %loop.preheader

loop.preheader:                                   ; preds = %entry
  %xtraiter = and i64 %count, 3
  %0 = icmp ult i64 %count, 4
  br i1 %0, label %loop.epil.preheader, label %loop.preheader.new

loop.preheader.new:                               ; preds = %loop.preheader
  %unroll_iter = and i64 %count, -4
  br label %loop

common.ret.loopexit.unr-lcssa:                    ; preds = %loop
  %lcmp.mod.not = icmp eq i64 %xtraiter, 0
  br i1 %lcmp.mod.not, label %common.ret, label %loop.epil.preheader

loop.epil.preheader:                              ; preds = %common.ret.loopexit.unr-lcssa, %loop.preheader
  %index.epil.init = phi i64 [ 0, %loop.preheader ], [ %next.3, %common.ret.loopexit.unr-lcssa ]
  %checksum.epil.init = phi i64 [ 0, %loop.preheader ], [ %result.3, %common.ret.loopexit.unr-lcssa ]
  %lcmp.mod2 = icmp ne i64 %xtraiter, 0
  tail call void @llvm.assume(i1 %lcmp.mod2)
  br label %loop.epil

loop.epil:                                        ; preds = %loop.epil, %loop.epil.preheader
  %index.epil = phi i64 [ %next.epil, %loop.epil ], [ %index.epil.init, %loop.epil.preheader ]
  %checksum.epil = phi i64 [ %result.epil, %loop.epil ], [ %checksum.epil.init, %loop.epil.preheader ]
  %epil.iter = phi i64 [ %epil.iter.next, %loop.epil ], [ 0, %loop.epil.preheader ]
  %address.epil = getelementptr i8, ptr %data, i64 %index.epil
  %flag.epil = load i8, ptr %address.epil, align 1
  %truth.epil = icmp ne i8 %flag.epil, 0
  %increment.epil = zext i1 %truth.epil to i64
  %addition.epil = add nsw i64 %checksum.epil, %increment.epil
  %rem.epil = srem i64 %addition.epil, 1000000007
  %negative.epil = icmp slt i64 %rem.epil, 0
  %shifted.epil = add nsw i64 %rem.epil, 1000000007
  %result.epil = select i1 %negative.epil, i64 %shifted.epil, i64 %rem.epil
  %next.epil = add nuw i64 %index.epil, 1
  %epil.iter.next = add i64 %epil.iter, 1
  %epil.iter.cmp.not = icmp eq i64 %epil.iter.next, %xtraiter
  br i1 %epil.iter.cmp.not, label %common.ret, label %loop.epil, !llvm.loop !7

common.ret:                                       ; preds = %common.ret.loopexit.unr-lcssa, %loop.epil, %entry
  %common.ret.op = phi i64 [ 0, %entry ], [ %result.3, %common.ret.loopexit.unr-lcssa ], [ %result.epil, %loop.epil ]
  ret i64 %common.ret.op

loop:                                             ; preds = %loop, %loop.preheader.new
  %index = phi i64 [ 0, %loop.preheader.new ], [ %next.3, %loop ]
  %checksum = phi i64 [ 0, %loop.preheader.new ], [ %result.3, %loop ]
  %niter = phi i64 [ 0, %loop.preheader.new ], [ %niter.next.3, %loop ]
  %address = getelementptr i8, ptr %data, i64 %index
  %flag = load i8, ptr %address, align 1
  %truth = icmp ne i8 %flag, 0
  %increment = zext i1 %truth to i64
  %addition = add nsw i64 %checksum, %increment
  %rem = srem i64 %addition, 1000000007
  %negative = icmp slt i64 %rem, 0
  %shifted = add nsw i64 %rem, 1000000007
  %result = select i1 %negative, i64 %shifted, i64 %rem
  %1 = getelementptr i8, ptr %data, i64 %index
  %address.1 = getelementptr i8, ptr %1, i64 1
  %flag.1 = load i8, ptr %address.1, align 1
  %truth.1 = icmp ne i8 %flag.1, 0
  %increment.1 = zext i1 %truth.1 to i64
  %addition.1 = add nsw i64 %result, %increment.1
  %rem.1 = srem i64 %addition.1, 1000000007
  %negative.1 = icmp slt i64 %rem.1, 0
  %shifted.1 = add nsw i64 %rem.1, 1000000007
  %result.1 = select i1 %negative.1, i64 %shifted.1, i64 %rem.1
  %2 = getelementptr i8, ptr %data, i64 %index
  %address.2 = getelementptr i8, ptr %2, i64 2
  %flag.2 = load i8, ptr %address.2, align 1
  %truth.2 = icmp ne i8 %flag.2, 0
  %increment.2 = zext i1 %truth.2 to i64
  %addition.2 = add nsw i64 %result.1, %increment.2
  %rem.2 = srem i64 %addition.2, 1000000007
  %negative.2 = icmp slt i64 %rem.2, 0
  %shifted.2 = add nsw i64 %rem.2, 1000000007
  %result.2 = select i1 %negative.2, i64 %shifted.2, i64 %rem.2
  %3 = getelementptr i8, ptr %data, i64 %index
  %address.3 = getelementptr i8, ptr %3, i64 3
  %flag.3 = load i8, ptr %address.3, align 1
  %truth.3 = icmp ne i8 %flag.3, 0
  %increment.3 = zext i1 %truth.3 to i64
  %addition.3 = add nsw i64 %result.2, %increment.3
  %rem.3 = srem i64 %addition.3, 1000000007
  %negative.3 = icmp slt i64 %rem.3, 0
  %shifted.3 = add nsw i64 %rem.3, 1000000007
  %result.3 = select i1 %negative.3, i64 %shifted.3, i64 %rem.3
  %next.3 = add nuw i64 %index, 4
  %niter.next.3 = add i64 %niter, 4
  %niter.ncmp.3 = icmp eq i64 %niter.next.3, %unroll_iter
  br i1 %niter.ncmp.3, label %common.ret.loopexit.unr-lcssa, label %loop
}

; Function Attrs: nofree noinline norecurse nosync nounwind memory(argmem: readwrite)
define range(i64 0, 1000000007) i64 @loop_zero_bool_select_assume_d1000000007(ptr readonly captures(none) %data, i64 %count, i64 %seed, ptr writeonly captures(none) initializes((0, 4)) %status) local_unnamed_addr #4 {
entry:
  store i32 0, ptr %status, align 4
  %empty = icmp eq i64 %count, 0
  br i1 %empty, label %common.ret, label %loop.preheader

loop.preheader:                                   ; preds = %entry
  %xtraiter = and i64 %count, 3
  %0 = icmp ult i64 %count, 4
  br i1 %0, label %loop.epil.preheader, label %loop.preheader.new

loop.preheader.new:                               ; preds = %loop.preheader
  %unroll_iter = and i64 %count, -4
  br label %loop

common.ret.loopexit.unr-lcssa:                    ; preds = %loop
  %lcmp.mod.not = icmp eq i64 %xtraiter, 0
  br i1 %lcmp.mod.not, label %common.ret, label %loop.epil.preheader

loop.epil.preheader:                              ; preds = %common.ret.loopexit.unr-lcssa, %loop.preheader
  %index.epil.init = phi i64 [ 0, %loop.preheader ], [ %next.3, %common.ret.loopexit.unr-lcssa ]
  %checksum.epil.init = phi i64 [ 0, %loop.preheader ], [ %rem.3, %common.ret.loopexit.unr-lcssa ]
  %lcmp.mod2 = icmp ne i64 %xtraiter, 0
  tail call void @llvm.assume(i1 %lcmp.mod2)
  br label %loop.epil

loop.epil:                                        ; preds = %loop.epil, %loop.epil.preheader
  %index.epil = phi i64 [ %next.epil, %loop.epil ], [ %index.epil.init, %loop.epil.preheader ]
  %checksum.epil = phi i64 [ %rem.epil, %loop.epil ], [ %checksum.epil.init, %loop.epil.preheader ]
  %epil.iter = phi i64 [ %epil.iter.next, %loop.epil ], [ 0, %loop.epil.preheader ]
  %address.epil = getelementptr i8, ptr %data, i64 %index.epil
  %flag.epil = load i8, ptr %address.epil, align 1
  %truth.epil = icmp ne i8 %flag.epil, 0
  %increment.epil = zext i1 %truth.epil to i64
  %addition.epil = add nuw nsw i64 %checksum.epil, %increment.epil
  %rem.epil = urem i64 %addition.epil, 1000000007
  %next.epil = add nuw i64 %index.epil, 1
  %epil.iter.next = add i64 %epil.iter, 1
  %epil.iter.cmp.not = icmp eq i64 %epil.iter.next, %xtraiter
  br i1 %epil.iter.cmp.not, label %common.ret, label %loop.epil, !llvm.loop !8

common.ret:                                       ; preds = %common.ret.loopexit.unr-lcssa, %loop.epil, %entry
  %common.ret.op = phi i64 [ 0, %entry ], [ %rem.3, %common.ret.loopexit.unr-lcssa ], [ %rem.epil, %loop.epil ]
  ret i64 %common.ret.op

loop:                                             ; preds = %loop, %loop.preheader.new
  %index = phi i64 [ 0, %loop.preheader.new ], [ %next.3, %loop ]
  %checksum = phi i64 [ 0, %loop.preheader.new ], [ %rem.3, %loop ]
  %niter = phi i64 [ 0, %loop.preheader.new ], [ %niter.next.3, %loop ]
  %address = getelementptr i8, ptr %data, i64 %index
  %flag = load i8, ptr %address, align 1
  %truth = icmp ne i8 %flag, 0
  %increment = zext i1 %truth to i64
  %addition = add nuw nsw i64 %checksum, %increment
  %rem = urem i64 %addition, 1000000007
  %1 = getelementptr i8, ptr %data, i64 %index
  %address.1 = getelementptr i8, ptr %1, i64 1
  %flag.1 = load i8, ptr %address.1, align 1
  %truth.1 = icmp ne i8 %flag.1, 0
  %increment.1 = zext i1 %truth.1 to i64
  %addition.1 = add nuw nsw i64 %rem, %increment.1
  %rem.1 = urem i64 %addition.1, 1000000007
  %2 = getelementptr i8, ptr %data, i64 %index
  %address.2 = getelementptr i8, ptr %2, i64 2
  %flag.2 = load i8, ptr %address.2, align 1
  %truth.2 = icmp ne i8 %flag.2, 0
  %increment.2 = zext i1 %truth.2 to i64
  %addition.2 = add nuw nsw i64 %rem.1, %increment.2
  %rem.2 = urem i64 %addition.2, 1000000007
  %3 = getelementptr i8, ptr %data, i64 %index
  %address.3 = getelementptr i8, ptr %3, i64 3
  %flag.3 = load i8, ptr %address.3, align 1
  %truth.3 = icmp ne i8 %flag.3, 0
  %increment.3 = zext i1 %truth.3 to i64
  %addition.3 = add nuw nsw i64 %rem.2, %increment.3
  %rem.3 = urem i64 %addition.3, 1000000007
  %next.3 = add nuw i64 %index, 4
  %niter.next.3 = add i64 %niter, 4
  %niter.ncmp.3 = icmp eq i64 %niter.next.3, %unroll_iter
  br i1 %niter.ncmp.3, label %common.ret.loopexit.unr-lcssa, label %loop
}

; Function Attrs: nofree noinline norecurse nosync nounwind memory(argmem: readwrite)
define i64 @loop_seeded_bool_baseline_d1000000007(ptr readonly captures(none) %data, i64 %count, i64 %seed, ptr writeonly captures(none) initializes((0, 4)) %status) local_unnamed_addr #4 {
entry:
  store i32 0, ptr %status, align 4
  %empty = icmp eq i64 %count, 0
  br i1 %empty, label %common.ret, label %loop

common.ret:                                       ; preds = %success, %entry, %failure
  %common.ret.op = phi i64 [ %seed, %entry ], [ 0, %failure ], [ %result, %success ]
  ret i64 %common.ret.op

loop:                                             ; preds = %entry, %success
  %index = phi i64 [ %next, %success ], [ 0, %entry ]
  %checksum = phi i64 [ %result, %success ], [ %seed, %entry ]
  %address = getelementptr i8, ptr %data, i64 %index
  %flag = load i8, ptr %address, align 1
  %truth = icmp ne i8 %flag, 0
  %increment = zext i1 %truth to i64
  %addition = tail call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %checksum, i64 %increment)
  %overflow = extractvalue { i64, i1 } %addition, 1
  br i1 %overflow, label %failure, label %success

failure:                                          ; preds = %loop
  store i32 1, ptr %status, align 4
  br label %common.ret

success:                                          ; preds = %loop
  %sum = extractvalue { i64, i1 } %addition, 0
  %rem = srem i64 %sum, 1000000007
  %isneg = icmp slt i64 %rem, 0
  %delta = select i1 %isneg, i64 1000000007, i64 0
  %result = add nsw i64 %delta, %rem
  %next = add nuw i64 %index, 1
  %done = icmp eq i64 %next, %count
  br i1 %done, label %common.ret, label %loop
}

; Function Attrs: nofree noinline norecurse nosync nounwind memory(argmem: readwrite, inaccessiblemem: write)
define i64 @loop_seeded_bool_assume_d1000000007(ptr readonly captures(none) %data, i64 %count, i64 %seed, ptr writeonly captures(none) initializes((0, 4)) %status) local_unnamed_addr #5 {
entry:
  store i32 0, ptr %status, align 4
  %empty = icmp eq i64 %count, 0
  br i1 %empty, label %common.ret, label %loop

common.ret:                                       ; preds = %success, %entry, %failure
  %common.ret.op = phi i64 [ %seed, %entry ], [ 0, %failure ], [ %result, %success ]
  ret i64 %common.ret.op

loop:                                             ; preds = %entry, %success
  %index = phi i64 [ %next, %success ], [ 0, %entry ]
  %checksum = phi i64 [ %result, %success ], [ %seed, %entry ]
  %address = getelementptr i8, ptr %data, i64 %index
  %flag = load i8, ptr %address, align 1
  %truth = icmp ne i8 %flag, 0
  %increment = zext i1 %truth to i64
  %addition = tail call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %checksum, i64 %increment)
  %overflow = extractvalue { i64, i1 } %addition, 1
  br i1 %overflow, label %failure, label %success

failure:                                          ; preds = %loop
  store i32 1, ptr %status, align 4
  br label %common.ret

success:                                          ; preds = %loop
  %sum = extractvalue { i64, i1 } %addition, 0
  %rem = srem i64 %sum, 1000000007
  %isneg = icmp slt i64 %rem, 0
  %delta = select i1 %isneg, i64 1000000007, i64 0
  %result = add nsw i64 %delta, %rem
  %bounded = icmp ult i64 %result, 1000000007
  tail call void @llvm.assume(i1 %bounded)
  %next = add nuw i64 %index, 1
  %done = icmp eq i64 %next, %count
  br i1 %done, label %common.ret, label %loop
}

; Function Attrs: nofree noinline norecurse nosync nounwind memory(argmem: readwrite)
define i64 @loop_seeded_bool_select_d1000000007(ptr readonly captures(none) %data, i64 %count, i64 %seed, ptr writeonly captures(none) initializes((0, 4)) %status) local_unnamed_addr #4 {
entry:
  store i32 0, ptr %status, align 4
  %empty = icmp eq i64 %count, 0
  br i1 %empty, label %common.ret, label %loop

common.ret:                                       ; preds = %success, %entry, %failure
  %common.ret.op = phi i64 [ %seed, %entry ], [ 0, %failure ], [ %result, %success ]
  ret i64 %common.ret.op

loop:                                             ; preds = %entry, %success
  %index = phi i64 [ %next, %success ], [ 0, %entry ]
  %checksum = phi i64 [ %result, %success ], [ %seed, %entry ]
  %address = getelementptr i8, ptr %data, i64 %index
  %flag = load i8, ptr %address, align 1
  %truth = icmp ne i8 %flag, 0
  %increment = zext i1 %truth to i64
  %addition = tail call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %checksum, i64 %increment)
  %overflow = extractvalue { i64, i1 } %addition, 1
  br i1 %overflow, label %failure, label %success

failure:                                          ; preds = %loop
  store i32 1, ptr %status, align 4
  br label %common.ret

success:                                          ; preds = %loop
  %sum = extractvalue { i64, i1 } %addition, 0
  %rem = srem i64 %sum, 1000000007
  %negative = icmp slt i64 %rem, 0
  %shifted = add nsw i64 %rem, 1000000007
  %result = select i1 %negative, i64 %shifted, i64 %rem
  %next = add nuw i64 %index, 1
  %done = icmp eq i64 %next, %count
  br i1 %done, label %common.ret, label %loop
}

; Function Attrs: nofree noinline norecurse nosync nounwind memory(argmem: readwrite, inaccessiblemem: write)
define i64 @loop_seeded_bool_select_assume_d1000000007(ptr readonly captures(none) %data, i64 %count, i64 %seed, ptr writeonly captures(none) initializes((0, 4)) %status) local_unnamed_addr #5 {
entry:
  store i32 0, ptr %status, align 4
  %empty = icmp eq i64 %count, 0
  br i1 %empty, label %common.ret, label %loop

common.ret:                                       ; preds = %success, %entry, %failure
  %common.ret.op = phi i64 [ %seed, %entry ], [ 0, %failure ], [ %result, %success ]
  ret i64 %common.ret.op

loop:                                             ; preds = %entry, %success
  %index = phi i64 [ %next, %success ], [ 0, %entry ]
  %checksum = phi i64 [ %result, %success ], [ %seed, %entry ]
  %address = getelementptr i8, ptr %data, i64 %index
  %flag = load i8, ptr %address, align 1
  %truth = icmp ne i8 %flag, 0
  %increment = zext i1 %truth to i64
  %addition = tail call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %checksum, i64 %increment)
  %overflow = extractvalue { i64, i1 } %addition, 1
  br i1 %overflow, label %failure, label %success

failure:                                          ; preds = %loop
  store i32 1, ptr %status, align 4
  br label %common.ret

success:                                          ; preds = %loop
  %sum = extractvalue { i64, i1 } %addition, 0
  %rem = srem i64 %sum, 1000000007
  %negative = icmp slt i64 %rem, 0
  %shifted = add nsw i64 %rem, 1000000007
  %result = select i1 %negative, i64 %shifted, i64 %rem
  %bounded = icmp ult i64 %result, 1000000007
  tail call void @llvm.assume(i1 %bounded)
  %next = add nuw i64 %index, 1
  %done = icmp eq i64 %next, %count
  br i1 %done, label %common.ret, label %loop
}

; Function Attrs: nofree noinline norecurse nosync nounwind memory(argmem: readwrite)
define range(i64 -1000000006, 2000000014) i64 @loop_signed_updates_baseline_d1000000007(ptr readonly captures(none) %data, i64 %count, i64 %seed, ptr writeonly captures(none) initializes((0, 4)) %status) local_unnamed_addr #4 {
entry:
  store i32 0, ptr %status, align 4
  %empty = icmp eq i64 %count, 0
  br i1 %empty, label %common.ret, label %loop

common.ret:                                       ; preds = %success, %entry, %failure
  %common.ret.op = phi i64 [ 0, %entry ], [ 0, %failure ], [ %result, %success ]
  ret i64 %common.ret.op

loop:                                             ; preds = %entry, %success
  %index = phi i64 [ %next, %success ], [ 0, %entry ]
  %checksum = phi i64 [ %result, %success ], [ 0, %entry ]
  %address = getelementptr i64, ptr %data, i64 %index
  %increment = load i64, ptr %address, align 8
  %addition = tail call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %checksum, i64 %increment)
  %overflow = extractvalue { i64, i1 } %addition, 1
  br i1 %overflow, label %failure, label %success

failure:                                          ; preds = %loop
  store i32 1, ptr %status, align 4
  br label %common.ret

success:                                          ; preds = %loop
  %sum = extractvalue { i64, i1 } %addition, 0
  %rem = srem i64 %sum, 1000000007
  %isneg = icmp slt i64 %rem, 0
  %delta = select i1 %isneg, i64 1000000007, i64 0
  %result = add nsw i64 %delta, %rem
  %next = add nuw i64 %index, 1
  %done = icmp eq i64 %next, %count
  br i1 %done, label %common.ret, label %loop
}

; Function Attrs: nofree noinline norecurse nosync nounwind memory(argmem: readwrite, inaccessiblemem: write)
define range(i64 0, 1000000007) i64 @loop_signed_updates_assume_d1000000007(ptr readonly captures(none) %data, i64 %count, i64 %seed, ptr writeonly captures(none) initializes((0, 4)) %status) local_unnamed_addr #5 {
entry:
  store i32 0, ptr %status, align 4
  %empty = icmp eq i64 %count, 0
  br i1 %empty, label %common.ret, label %loop

common.ret:                                       ; preds = %success, %entry, %failure
  %common.ret.op = phi i64 [ 0, %entry ], [ 0, %failure ], [ %result, %success ]
  ret i64 %common.ret.op

loop:                                             ; preds = %entry, %success
  %index = phi i64 [ %next, %success ], [ 0, %entry ]
  %checksum = phi i64 [ %result, %success ], [ 0, %entry ]
  %address = getelementptr i64, ptr %data, i64 %index
  %increment = load i64, ptr %address, align 8
  %addition = tail call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %checksum, i64 %increment)
  %overflow = extractvalue { i64, i1 } %addition, 1
  br i1 %overflow, label %failure, label %success

failure:                                          ; preds = %loop
  store i32 1, ptr %status, align 4
  br label %common.ret

success:                                          ; preds = %loop
  %sum = extractvalue { i64, i1 } %addition, 0
  %rem = srem i64 %sum, 1000000007
  %isneg = icmp slt i64 %rem, 0
  %delta = select i1 %isneg, i64 1000000007, i64 0
  %result = add nsw i64 %delta, %rem
  %bounded = icmp ult i64 %result, 1000000007
  tail call void @llvm.assume(i1 %bounded)
  %next = add nuw i64 %index, 1
  %done = icmp eq i64 %next, %count
  br i1 %done, label %common.ret, label %loop
}

; Function Attrs: nofree noinline norecurse nosync nounwind memory(argmem: readwrite)
define range(i64 -1000000006, 2000000014) i64 @loop_signed_updates_select_d1000000007(ptr readonly captures(none) %data, i64 %count, i64 %seed, ptr writeonly captures(none) initializes((0, 4)) %status) local_unnamed_addr #4 {
entry:
  store i32 0, ptr %status, align 4
  %empty = icmp eq i64 %count, 0
  br i1 %empty, label %common.ret, label %loop

common.ret:                                       ; preds = %success, %entry, %failure
  %common.ret.op = phi i64 [ 0, %entry ], [ 0, %failure ], [ %result, %success ]
  ret i64 %common.ret.op

loop:                                             ; preds = %entry, %success
  %index = phi i64 [ %next, %success ], [ 0, %entry ]
  %checksum = phi i64 [ %result, %success ], [ 0, %entry ]
  %address = getelementptr i64, ptr %data, i64 %index
  %increment = load i64, ptr %address, align 8
  %addition = tail call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %checksum, i64 %increment)
  %overflow = extractvalue { i64, i1 } %addition, 1
  br i1 %overflow, label %failure, label %success

failure:                                          ; preds = %loop
  store i32 1, ptr %status, align 4
  br label %common.ret

success:                                          ; preds = %loop
  %sum = extractvalue { i64, i1 } %addition, 0
  %rem = srem i64 %sum, 1000000007
  %negative = icmp slt i64 %rem, 0
  %shifted = add nsw i64 %rem, 1000000007
  %result = select i1 %negative, i64 %shifted, i64 %rem
  %next = add nuw i64 %index, 1
  %done = icmp eq i64 %next, %count
  br i1 %done, label %common.ret, label %loop
}

; Function Attrs: nofree noinline norecurse nosync nounwind memory(argmem: readwrite, inaccessiblemem: write)
define range(i64 0, 1000000007) i64 @loop_signed_updates_select_assume_d1000000007(ptr readonly captures(none) %data, i64 %count, i64 %seed, ptr writeonly captures(none) initializes((0, 4)) %status) local_unnamed_addr #5 {
entry:
  store i32 0, ptr %status, align 4
  %empty = icmp eq i64 %count, 0
  br i1 %empty, label %common.ret, label %loop

common.ret:                                       ; preds = %success, %entry, %failure
  %common.ret.op = phi i64 [ 0, %entry ], [ 0, %failure ], [ %result, %success ]
  ret i64 %common.ret.op

loop:                                             ; preds = %entry, %success
  %index = phi i64 [ %next, %success ], [ 0, %entry ]
  %checksum = phi i64 [ %result, %success ], [ 0, %entry ]
  %address = getelementptr i64, ptr %data, i64 %index
  %increment = load i64, ptr %address, align 8
  %addition = tail call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %checksum, i64 %increment)
  %overflow = extractvalue { i64, i1 } %addition, 1
  br i1 %overflow, label %failure, label %success

failure:                                          ; preds = %loop
  store i32 1, ptr %status, align 4
  br label %common.ret

success:                                          ; preds = %loop
  %sum = extractvalue { i64, i1 } %addition, 0
  %rem = srem i64 %sum, 1000000007
  %negative = icmp slt i64 %rem, 0
  %shifted = add nsw i64 %rem, 1000000007
  %result = select i1 %negative, i64 %shifted, i64 %rem
  %bounded = icmp ult i64 %result, 1000000007
  tail call void @llvm.assume(i1 %bounded)
  %next = add nuw i64 %index, 1
  %done = icmp eq i64 %next, %count
  br i1 %done, label %common.ret, label %loop
}

; Function Attrs: nofree noinline norecurse nosync nounwind memory(argmem: readwrite)
define i64 @loop_zero_bool_baseline_d9223372036854775807(ptr readonly captures(none) %data, i64 %count, i64 %seed, ptr writeonly captures(none) initializes((0, 4)) %status) local_unnamed_addr #4 {
entry:
  store i32 0, ptr %status, align 4
  %empty = icmp eq i64 %count, 0
  br i1 %empty, label %common.ret, label %loop

common.ret:                                       ; preds = %success, %entry, %failure
  %common.ret.op = phi i64 [ 0, %entry ], [ 0, %failure ], [ %result, %success ]
  ret i64 %common.ret.op

loop:                                             ; preds = %entry, %success
  %index = phi i64 [ %next, %success ], [ 0, %entry ]
  %checksum = phi i64 [ %result, %success ], [ 0, %entry ]
  %address = getelementptr i8, ptr %data, i64 %index
  %flag = load i8, ptr %address, align 1
  %truth = icmp ne i8 %flag, 0
  %increment = zext i1 %truth to i64
  %addition = tail call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %checksum, i64 %increment)
  %overflow = extractvalue { i64, i1 } %addition, 1
  br i1 %overflow, label %failure, label %success

failure:                                          ; preds = %loop
  store i32 1, ptr %status, align 4
  br label %common.ret

success:                                          ; preds = %loop
  %sum = extractvalue { i64, i1 } %addition, 0
  %rem = srem i64 %sum, 9223372036854775807
  %isneg = icmp slt i64 %rem, 0
  %delta = select i1 %isneg, i64 9223372036854775807, i64 0
  %result = add i64 %delta, %rem
  %next = add nuw i64 %index, 1
  %done = icmp eq i64 %next, %count
  br i1 %done, label %common.ret, label %loop
}

; Function Attrs: nofree noinline norecurse nosync nounwind memory(argmem: readwrite, inaccessiblemem: write)
define range(i64 0, 9223372036854775807) i64 @loop_zero_bool_assume_d9223372036854775807(ptr readonly captures(none) %data, i64 %count, i64 %seed, ptr writeonly captures(none) initializes((0, 4)) %status) local_unnamed_addr #5 {
entry:
  store i32 0, ptr %status, align 4
  %empty = icmp eq i64 %count, 0
  br i1 %empty, label %common.ret, label %loop

common.ret:                                       ; preds = %success, %entry, %failure
  %common.ret.op = phi i64 [ 0, %entry ], [ 0, %failure ], [ %result, %success ]
  ret i64 %common.ret.op

loop:                                             ; preds = %entry, %success
  %index = phi i64 [ %next, %success ], [ 0, %entry ]
  %checksum = phi i64 [ %result, %success ], [ 0, %entry ]
  %address = getelementptr i8, ptr %data, i64 %index
  %flag = load i8, ptr %address, align 1
  %truth = icmp ne i8 %flag, 0
  %increment = zext i1 %truth to i64
  %addition = tail call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %checksum, i64 %increment)
  %overflow = extractvalue { i64, i1 } %addition, 1
  br i1 %overflow, label %failure, label %success

failure:                                          ; preds = %loop
  store i32 1, ptr %status, align 4
  br label %common.ret

success:                                          ; preds = %loop
  %sum = extractvalue { i64, i1 } %addition, 0
  %rem = srem i64 %sum, 9223372036854775807
  %isneg = icmp slt i64 %rem, 0
  %delta = select i1 %isneg, i64 9223372036854775807, i64 0
  %result = add i64 %delta, %rem
  %bounded = icmp ult i64 %result, 9223372036854775807
  tail call void @llvm.assume(i1 %bounded)
  %next = add nuw i64 %index, 1
  %done = icmp eq i64 %next, %count
  br i1 %done, label %common.ret, label %loop
}

; Function Attrs: nofree noinline norecurse nosync nounwind memory(argmem: readwrite)
define i64 @loop_zero_bool_select_d9223372036854775807(ptr readonly captures(none) %data, i64 %count, i64 %seed, ptr writeonly captures(none) initializes((0, 4)) %status) local_unnamed_addr #4 {
entry:
  store i32 0, ptr %status, align 4
  %empty = icmp eq i64 %count, 0
  br i1 %empty, label %common.ret, label %loop

common.ret:                                       ; preds = %success, %entry, %failure
  %common.ret.op = phi i64 [ 0, %entry ], [ 0, %failure ], [ %result, %success ]
  ret i64 %common.ret.op

loop:                                             ; preds = %entry, %success
  %index = phi i64 [ %next, %success ], [ 0, %entry ]
  %checksum = phi i64 [ %result, %success ], [ 0, %entry ]
  %address = getelementptr i8, ptr %data, i64 %index
  %flag = load i8, ptr %address, align 1
  %truth = icmp ne i8 %flag, 0
  %increment = zext i1 %truth to i64
  %addition = tail call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %checksum, i64 %increment)
  %overflow = extractvalue { i64, i1 } %addition, 1
  br i1 %overflow, label %failure, label %success

failure:                                          ; preds = %loop
  store i32 1, ptr %status, align 4
  br label %common.ret

success:                                          ; preds = %loop
  %sum = extractvalue { i64, i1 } %addition, 0
  %rem = srem i64 %sum, 9223372036854775807
  %negative = icmp slt i64 %rem, 0
  %shifted = add i64 %rem, 9223372036854775807
  %result = select i1 %negative, i64 %shifted, i64 %rem
  %next = add nuw i64 %index, 1
  %done = icmp eq i64 %next, %count
  br i1 %done, label %common.ret, label %loop
}

; Function Attrs: nofree noinline norecurse nosync nounwind memory(argmem: readwrite, inaccessiblemem: write)
define range(i64 0, 9223372036854775807) i64 @loop_zero_bool_select_assume_d9223372036854775807(ptr readonly captures(none) %data, i64 %count, i64 %seed, ptr writeonly captures(none) initializes((0, 4)) %status) local_unnamed_addr #5 {
entry:
  store i32 0, ptr %status, align 4
  %empty = icmp eq i64 %count, 0
  br i1 %empty, label %common.ret, label %loop

common.ret:                                       ; preds = %success, %entry, %failure
  %common.ret.op = phi i64 [ 0, %entry ], [ 0, %failure ], [ %result, %success ]
  ret i64 %common.ret.op

loop:                                             ; preds = %entry, %success
  %index = phi i64 [ %next, %success ], [ 0, %entry ]
  %checksum = phi i64 [ %result, %success ], [ 0, %entry ]
  %address = getelementptr i8, ptr %data, i64 %index
  %flag = load i8, ptr %address, align 1
  %truth = icmp ne i8 %flag, 0
  %increment = zext i1 %truth to i64
  %addition = tail call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %checksum, i64 %increment)
  %overflow = extractvalue { i64, i1 } %addition, 1
  br i1 %overflow, label %failure, label %success

failure:                                          ; preds = %loop
  store i32 1, ptr %status, align 4
  br label %common.ret

success:                                          ; preds = %loop
  %sum = extractvalue { i64, i1 } %addition, 0
  %rem = srem i64 %sum, 9223372036854775807
  %negative = icmp slt i64 %rem, 0
  %shifted = add i64 %rem, 9223372036854775807
  %result = select i1 %negative, i64 %shifted, i64 %rem
  %bounded = icmp ult i64 %result, 9223372036854775807
  tail call void @llvm.assume(i1 %bounded)
  %next = add nuw i64 %index, 1
  %done = icmp eq i64 %next, %count
  br i1 %done, label %common.ret, label %loop
}

; Function Attrs: nofree noinline norecurse nosync nounwind memory(argmem: readwrite)
define i64 @loop_seeded_bool_baseline_d9223372036854775807(ptr readonly captures(none) %data, i64 %count, i64 %seed, ptr writeonly captures(none) initializes((0, 4)) %status) local_unnamed_addr #4 {
entry:
  store i32 0, ptr %status, align 4
  %empty = icmp eq i64 %count, 0
  br i1 %empty, label %common.ret, label %loop

common.ret:                                       ; preds = %success, %entry, %failure
  %common.ret.op = phi i64 [ %seed, %entry ], [ 0, %failure ], [ %result, %success ]
  ret i64 %common.ret.op

loop:                                             ; preds = %entry, %success
  %index = phi i64 [ %next, %success ], [ 0, %entry ]
  %checksum = phi i64 [ %result, %success ], [ %seed, %entry ]
  %address = getelementptr i8, ptr %data, i64 %index
  %flag = load i8, ptr %address, align 1
  %truth = icmp ne i8 %flag, 0
  %increment = zext i1 %truth to i64
  %addition = tail call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %checksum, i64 %increment)
  %overflow = extractvalue { i64, i1 } %addition, 1
  br i1 %overflow, label %failure, label %success

failure:                                          ; preds = %loop
  store i32 1, ptr %status, align 4
  br label %common.ret

success:                                          ; preds = %loop
  %sum = extractvalue { i64, i1 } %addition, 0
  %rem = srem i64 %sum, 9223372036854775807
  %isneg = icmp slt i64 %rem, 0
  %delta = select i1 %isneg, i64 9223372036854775807, i64 0
  %result = add i64 %delta, %rem
  %next = add nuw i64 %index, 1
  %done = icmp eq i64 %next, %count
  br i1 %done, label %common.ret, label %loop
}

; Function Attrs: nofree noinline norecurse nosync nounwind memory(argmem: readwrite, inaccessiblemem: write)
define i64 @loop_seeded_bool_assume_d9223372036854775807(ptr readonly captures(none) %data, i64 %count, i64 %seed, ptr writeonly captures(none) initializes((0, 4)) %status) local_unnamed_addr #5 {
entry:
  store i32 0, ptr %status, align 4
  %empty = icmp eq i64 %count, 0
  br i1 %empty, label %common.ret, label %loop

common.ret:                                       ; preds = %success, %entry, %failure
  %common.ret.op = phi i64 [ %seed, %entry ], [ 0, %failure ], [ %result, %success ]
  ret i64 %common.ret.op

loop:                                             ; preds = %entry, %success
  %index = phi i64 [ %next, %success ], [ 0, %entry ]
  %checksum = phi i64 [ %result, %success ], [ %seed, %entry ]
  %address = getelementptr i8, ptr %data, i64 %index
  %flag = load i8, ptr %address, align 1
  %truth = icmp ne i8 %flag, 0
  %increment = zext i1 %truth to i64
  %addition = tail call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %checksum, i64 %increment)
  %overflow = extractvalue { i64, i1 } %addition, 1
  br i1 %overflow, label %failure, label %success

failure:                                          ; preds = %loop
  store i32 1, ptr %status, align 4
  br label %common.ret

success:                                          ; preds = %loop
  %sum = extractvalue { i64, i1 } %addition, 0
  %rem = srem i64 %sum, 9223372036854775807
  %isneg = icmp slt i64 %rem, 0
  %delta = select i1 %isneg, i64 9223372036854775807, i64 0
  %result = add i64 %delta, %rem
  %bounded = icmp ult i64 %result, 9223372036854775807
  tail call void @llvm.assume(i1 %bounded)
  %next = add nuw i64 %index, 1
  %done = icmp eq i64 %next, %count
  br i1 %done, label %common.ret, label %loop
}

; Function Attrs: nofree noinline norecurse nosync nounwind memory(argmem: readwrite)
define i64 @loop_seeded_bool_select_d9223372036854775807(ptr readonly captures(none) %data, i64 %count, i64 %seed, ptr writeonly captures(none) initializes((0, 4)) %status) local_unnamed_addr #4 {
entry:
  store i32 0, ptr %status, align 4
  %empty = icmp eq i64 %count, 0
  br i1 %empty, label %common.ret, label %loop

common.ret:                                       ; preds = %success, %entry, %failure
  %common.ret.op = phi i64 [ %seed, %entry ], [ 0, %failure ], [ %result, %success ]
  ret i64 %common.ret.op

loop:                                             ; preds = %entry, %success
  %index = phi i64 [ %next, %success ], [ 0, %entry ]
  %checksum = phi i64 [ %result, %success ], [ %seed, %entry ]
  %address = getelementptr i8, ptr %data, i64 %index
  %flag = load i8, ptr %address, align 1
  %truth = icmp ne i8 %flag, 0
  %increment = zext i1 %truth to i64
  %addition = tail call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %checksum, i64 %increment)
  %overflow = extractvalue { i64, i1 } %addition, 1
  br i1 %overflow, label %failure, label %success

failure:                                          ; preds = %loop
  store i32 1, ptr %status, align 4
  br label %common.ret

success:                                          ; preds = %loop
  %sum = extractvalue { i64, i1 } %addition, 0
  %rem = srem i64 %sum, 9223372036854775807
  %negative = icmp slt i64 %rem, 0
  %shifted = add i64 %rem, 9223372036854775807
  %result = select i1 %negative, i64 %shifted, i64 %rem
  %next = add nuw i64 %index, 1
  %done = icmp eq i64 %next, %count
  br i1 %done, label %common.ret, label %loop
}

; Function Attrs: nofree noinline norecurse nosync nounwind memory(argmem: readwrite, inaccessiblemem: write)
define i64 @loop_seeded_bool_select_assume_d9223372036854775807(ptr readonly captures(none) %data, i64 %count, i64 %seed, ptr writeonly captures(none) initializes((0, 4)) %status) local_unnamed_addr #5 {
entry:
  store i32 0, ptr %status, align 4
  %empty = icmp eq i64 %count, 0
  br i1 %empty, label %common.ret, label %loop

common.ret:                                       ; preds = %success, %entry, %failure
  %common.ret.op = phi i64 [ %seed, %entry ], [ 0, %failure ], [ %result, %success ]
  ret i64 %common.ret.op

loop:                                             ; preds = %entry, %success
  %index = phi i64 [ %next, %success ], [ 0, %entry ]
  %checksum = phi i64 [ %result, %success ], [ %seed, %entry ]
  %address = getelementptr i8, ptr %data, i64 %index
  %flag = load i8, ptr %address, align 1
  %truth = icmp ne i8 %flag, 0
  %increment = zext i1 %truth to i64
  %addition = tail call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %checksum, i64 %increment)
  %overflow = extractvalue { i64, i1 } %addition, 1
  br i1 %overflow, label %failure, label %success

failure:                                          ; preds = %loop
  store i32 1, ptr %status, align 4
  br label %common.ret

success:                                          ; preds = %loop
  %sum = extractvalue { i64, i1 } %addition, 0
  %rem = srem i64 %sum, 9223372036854775807
  %negative = icmp slt i64 %rem, 0
  %shifted = add i64 %rem, 9223372036854775807
  %result = select i1 %negative, i64 %shifted, i64 %rem
  %bounded = icmp ult i64 %result, 9223372036854775807
  tail call void @llvm.assume(i1 %bounded)
  %next = add nuw i64 %index, 1
  %done = icmp eq i64 %next, %count
  br i1 %done, label %common.ret, label %loop
}

; Function Attrs: nofree noinline norecurse nosync nounwind memory(argmem: readwrite)
define i64 @loop_signed_updates_baseline_d9223372036854775807(ptr readonly captures(none) %data, i64 %count, i64 %seed, ptr writeonly captures(none) initializes((0, 4)) %status) local_unnamed_addr #4 {
entry:
  store i32 0, ptr %status, align 4
  %empty = icmp eq i64 %count, 0
  br i1 %empty, label %common.ret, label %loop

common.ret:                                       ; preds = %success, %entry, %failure
  %common.ret.op = phi i64 [ 0, %entry ], [ 0, %failure ], [ %result, %success ]
  ret i64 %common.ret.op

loop:                                             ; preds = %entry, %success
  %index = phi i64 [ %next, %success ], [ 0, %entry ]
  %checksum = phi i64 [ %result, %success ], [ 0, %entry ]
  %address = getelementptr i64, ptr %data, i64 %index
  %increment = load i64, ptr %address, align 8
  %addition = tail call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %checksum, i64 %increment)
  %overflow = extractvalue { i64, i1 } %addition, 1
  br i1 %overflow, label %failure, label %success

failure:                                          ; preds = %loop
  store i32 1, ptr %status, align 4
  br label %common.ret

success:                                          ; preds = %loop
  %sum = extractvalue { i64, i1 } %addition, 0
  %rem = srem i64 %sum, 9223372036854775807
  %isneg = icmp slt i64 %rem, 0
  %delta = select i1 %isneg, i64 9223372036854775807, i64 0
  %result = add i64 %delta, %rem
  %next = add nuw i64 %index, 1
  %done = icmp eq i64 %next, %count
  br i1 %done, label %common.ret, label %loop
}

; Function Attrs: nofree noinline norecurse nosync nounwind memory(argmem: readwrite, inaccessiblemem: write)
define range(i64 0, 9223372036854775807) i64 @loop_signed_updates_assume_d9223372036854775807(ptr readonly captures(none) %data, i64 %count, i64 %seed, ptr writeonly captures(none) initializes((0, 4)) %status) local_unnamed_addr #5 {
entry:
  store i32 0, ptr %status, align 4
  %empty = icmp eq i64 %count, 0
  br i1 %empty, label %common.ret, label %loop

common.ret:                                       ; preds = %success, %entry, %failure
  %common.ret.op = phi i64 [ 0, %entry ], [ 0, %failure ], [ %result, %success ]
  ret i64 %common.ret.op

loop:                                             ; preds = %entry, %success
  %index = phi i64 [ %next, %success ], [ 0, %entry ]
  %checksum = phi i64 [ %result, %success ], [ 0, %entry ]
  %address = getelementptr i64, ptr %data, i64 %index
  %increment = load i64, ptr %address, align 8
  %addition = tail call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %checksum, i64 %increment)
  %overflow = extractvalue { i64, i1 } %addition, 1
  br i1 %overflow, label %failure, label %success

failure:                                          ; preds = %loop
  store i32 1, ptr %status, align 4
  br label %common.ret

success:                                          ; preds = %loop
  %sum = extractvalue { i64, i1 } %addition, 0
  %rem = srem i64 %sum, 9223372036854775807
  %isneg = icmp slt i64 %rem, 0
  %delta = select i1 %isneg, i64 9223372036854775807, i64 0
  %result = add i64 %delta, %rem
  %bounded = icmp ult i64 %result, 9223372036854775807
  tail call void @llvm.assume(i1 %bounded)
  %next = add nuw i64 %index, 1
  %done = icmp eq i64 %next, %count
  br i1 %done, label %common.ret, label %loop
}

; Function Attrs: nofree noinline norecurse nosync nounwind memory(argmem: readwrite)
define i64 @loop_signed_updates_select_d9223372036854775807(ptr readonly captures(none) %data, i64 %count, i64 %seed, ptr writeonly captures(none) initializes((0, 4)) %status) local_unnamed_addr #4 {
entry:
  store i32 0, ptr %status, align 4
  %empty = icmp eq i64 %count, 0
  br i1 %empty, label %common.ret, label %loop

common.ret:                                       ; preds = %success, %entry, %failure
  %common.ret.op = phi i64 [ 0, %entry ], [ 0, %failure ], [ %result, %success ]
  ret i64 %common.ret.op

loop:                                             ; preds = %entry, %success
  %index = phi i64 [ %next, %success ], [ 0, %entry ]
  %checksum = phi i64 [ %result, %success ], [ 0, %entry ]
  %address = getelementptr i64, ptr %data, i64 %index
  %increment = load i64, ptr %address, align 8
  %addition = tail call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %checksum, i64 %increment)
  %overflow = extractvalue { i64, i1 } %addition, 1
  br i1 %overflow, label %failure, label %success

failure:                                          ; preds = %loop
  store i32 1, ptr %status, align 4
  br label %common.ret

success:                                          ; preds = %loop
  %sum = extractvalue { i64, i1 } %addition, 0
  %rem = srem i64 %sum, 9223372036854775807
  %negative = icmp slt i64 %rem, 0
  %shifted = add i64 %rem, 9223372036854775807
  %result = select i1 %negative, i64 %shifted, i64 %rem
  %next = add nuw i64 %index, 1
  %done = icmp eq i64 %next, %count
  br i1 %done, label %common.ret, label %loop
}

; Function Attrs: nofree noinline norecurse nosync nounwind memory(argmem: readwrite, inaccessiblemem: write)
define range(i64 0, 9223372036854775807) i64 @loop_signed_updates_select_assume_d9223372036854775807(ptr readonly captures(none) %data, i64 %count, i64 %seed, ptr writeonly captures(none) initializes((0, 4)) %status) local_unnamed_addr #5 {
entry:
  store i32 0, ptr %status, align 4
  %empty = icmp eq i64 %count, 0
  br i1 %empty, label %common.ret, label %loop

common.ret:                                       ; preds = %success, %entry, %failure
  %common.ret.op = phi i64 [ 0, %entry ], [ 0, %failure ], [ %result, %success ]
  ret i64 %common.ret.op

loop:                                             ; preds = %entry, %success
  %index = phi i64 [ %next, %success ], [ 0, %entry ]
  %checksum = phi i64 [ %result, %success ], [ 0, %entry ]
  %address = getelementptr i64, ptr %data, i64 %index
  %increment = load i64, ptr %address, align 8
  %addition = tail call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %checksum, i64 %increment)
  %overflow = extractvalue { i64, i1 } %addition, 1
  br i1 %overflow, label %failure, label %success

failure:                                          ; preds = %loop
  store i32 1, ptr %status, align 4
  br label %common.ret

success:                                          ; preds = %loop
  %sum = extractvalue { i64, i1 } %addition, 0
  %rem = srem i64 %sum, 9223372036854775807
  %negative = icmp slt i64 %rem, 0
  %shifted = add i64 %rem, 9223372036854775807
  %result = select i1 %negative, i64 %shifted, i64 %rem
  %bounded = icmp ult i64 %result, 9223372036854775807
  tail call void @llvm.assume(i1 %bounded)
  %next = add nuw i64 %index, 1
  %done = icmp eq i64 %next, %count
  br i1 %done, label %common.ret, label %loop
}

attributes #0 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: write) }
attributes #1 = { mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #2 = { mustprogress nofree noinline norecurse nosync nounwind willreturn memory(none) }
attributes #3 = { mustprogress nofree noinline norecurse nosync nounwind willreturn memory(inaccessiblemem: write) }
attributes #4 = { nofree noinline norecurse nosync nounwind memory(argmem: readwrite) }
attributes #5 = { nofree noinline norecurse nosync nounwind memory(argmem: readwrite, inaccessiblemem: write) }

!0 = distinct !{!0, !1}
!1 = !{!"llvm.loop.unroll.disable"}
!2 = distinct !{!2, !1}
!3 = distinct !{!3, !1}
!4 = distinct !{!4, !1}
!5 = distinct !{!5, !1}
!6 = distinct !{!6, !1}
!7 = distinct !{!7, !1}
!8 = distinct !{!8, !1}
