
/home/epentland/ai/canopy/mylang-worktrees/goal110-equality-bounded-20261004/.mylang-cache/goal110-floor-range-ir/floor-range.so:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .text:

00000000000039b0 <loop_zero_bool_select_assume_d9223372036854775807>:
    39b0:	movl   $0x0,(%rcx)
    39b6:	test   %rsi,%rsi
    39b9:	je     3a2a <loop_zero_bool_select_assume_d9223372036854775807+0x7a>
    39bb:	movabs $0x7fffffffffffffff,%r9
    39c5:	xor    %eax,%eax
    39c7:	movabs $0x4000000000000001,%r10
    39d1:	cs nopw 0x0(%rax,%rax,1)
    39db:	nopl   0x0(%rax,%rax,1)
    39e0:	xor    %r8d,%r8d
    39e3:	cmpb   $0x0,(%rdi)
    39e6:	setne  %r8b
    39ea:	add    %rax,%r8
    39ed:	jo     3a24 <loop_zero_bool_select_assume_d9223372036854775807+0x74>
    39ef:	mov    %r8,%rax
    39f2:	imul   %r10
    39f5:	mov    %rdx,%rax
    39f8:	shr    $0x3f,%rax
    39fc:	sar    $0x3d,%rdx
    3a00:	add    %rax,%rdx
    3a03:	mov    %rdx,%r11
    3a06:	shl    $0x3f,%r11
    3a0a:	add    %rdx,%r11
    3a0d:	add    %r8,%r11
    3a10:	lea    (%r11,%r9,1),%rax
    3a14:	test   %r11,%r11
    3a17:	cmovns %r11,%rax
    3a1b:	inc    %rdi
    3a1e:	dec    %rsi
    3a21:	jne    39e0 <loop_zero_bool_select_assume_d9223372036854775807+0x30>
    3a23:	ret
    3a24:	movl   $0x1,(%rcx)
    3a2a:	xor    %eax,%eax
    3a2c:	ret
