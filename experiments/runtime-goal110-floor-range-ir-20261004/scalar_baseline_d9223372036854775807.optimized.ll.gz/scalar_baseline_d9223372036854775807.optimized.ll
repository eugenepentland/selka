define i64 @scalar_baseline_d9223372036854775807(i64 %value) local_unnamed_addr #2 {
entry:
  %rem = srem i64 %value, 9223372036854775807
  %isneg = icmp slt i64 %rem, 0
  %delta = select i1 %isneg, i64 9223372036854775807, i64 0
  %result = add i64 %delta, %rem
  ret i64 %result
}
