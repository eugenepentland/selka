define noundef i64 @scalar_baseline_d1(i64 %value) local_unnamed_addr #2 {
entry:
  ret i64 0
}
