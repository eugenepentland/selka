
/home/epentland/ai/canopy/mylang-worktrees/goal110-equality-bounded-20261004/.mylang-cache/goal110-floor-range-ir/floor-range.so:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .text:

00000000000034d0 <loop_seeded_bool_assume_d1000000007>:
    34d0:	mov    %rdx,%rax
    34d3:	movl   $0x0,(%rcx)
    34d9:	test   %rsi,%rsi
    34dc:	je     3537 <loop_seeded_bool_assume_d1000000007+0x67>
    34de:	movabs $0x89705f3112a28fe5,%r9
    34e8:	nopl   0x0(%rax,%rax,1)
    34f0:	xor    %r8d,%r8d
    34f3:	cmpb   $0x0,(%rdi)
    34f6:	setne  %r8b
    34fa:	add    %rax,%r8
    34fd:	jo     3538 <loop_seeded_bool_assume_d1000000007+0x68>
    34ff:	mov    %r8,%rax
    3502:	imul   %r9
    3505:	add    %r8,%rdx
    3508:	mov    %rdx,%rax
    350b:	shr    $0x3f,%rax
    350f:	sar    $0x1d,%rdx
    3513:	add    %rax,%rdx
    3516:	imul   $0x3b9aca07,%rdx,%rax
    351d:	sub    %rax,%r8
    3520:	mov    %r8,%rax
    3523:	sar    $0x3f,%rax
    3527:	and    $0x3b9aca07,%eax
    352c:	add    %r8,%rax
    352f:	inc    %rdi
    3532:	dec    %rsi
    3535:	jne    34f0 <loop_seeded_bool_assume_d1000000007+0x20>
    3537:	ret
    3538:	movl   $0x1,(%rcx)
    353e:	xor    %eax,%eax
    3540:	ret
