
/home/epentland/ai/canopy/mylang-worktrees/goal110-equality-bounded-20261004/.mylang-cache/goal110-floor-range-ir/floor-range.so:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .text:

0000000000003930 <loop_zero_bool_select_d9223372036854775807>:
    3930:	movl   $0x0,(%rcx)
    3936:	xor    %eax,%eax
    3938:	test   %rsi,%rsi
    393b:	je     39a3 <loop_zero_bool_select_d9223372036854775807+0x73>
    393d:	movabs $0x4000000000000001,%r9
    3947:	movabs $0x7fffffffffffffff,%r10
    3951:	cs nopw 0x0(%rax,%rax,1)
    395b:	nopl   0x0(%rax,%rax,1)
    3960:	xor    %r8d,%r8d
    3963:	cmpb   $0x0,(%rdi)
    3966:	setne  %r8b
    396a:	add    %rax,%r8
    396d:	jo     39a4 <loop_zero_bool_select_d9223372036854775807+0x74>
    396f:	mov    %r8,%rax
    3972:	imul   %r9
    3975:	mov    %rdx,%rax
    3978:	shr    $0x3f,%rax
    397c:	sar    $0x3d,%rdx
    3980:	add    %rax,%rdx
    3983:	mov    %rdx,%r11
    3986:	shl    $0x3f,%r11
    398a:	add    %rdx,%r11
    398d:	add    %r8,%r11
    3990:	lea    (%r11,%r10,1),%rax
    3994:	test   %r11,%r11
    3997:	cmovns %r11,%rax
    399b:	inc    %rdi
    399e:	dec    %rsi
    39a1:	jne    3960 <loop_zero_bool_select_d9223372036854775807+0x30>
    39a3:	ret
    39a4:	movl   $0x1,(%rcx)
    39aa:	xor    %eax,%eax
    39ac:	ret
