
/home/epentland/ai/canopy/mylang-worktrees/goal110-equality-bounded-20261004/.mylang-cache/goal110-floor-range-ir/floor-range.so:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .text:

0000000000002c90 <loop_signed_updates_baseline_d3>:
    2c90:	movl   $0x0,(%rcx)
    2c96:	test   %rsi,%rsi
    2c99:	je     2cec <loop_signed_updates_baseline_d3+0x5c>
    2c9b:	xor    %r8d,%r8d
    2c9e:	movabs $0x5555555555555556,%r9
    2ca8:	nopl   0x0(%rax,%rax,1)
    2cb0:	add    (%rdi),%r8
    2cb3:	jo     2ce6 <loop_signed_updates_baseline_d3+0x56>
    2cb5:	mov    %r8,%rax
    2cb8:	imul   %r9
    2cbb:	mov    %rdx,%rax
    2cbe:	shr    $0x3f,%rax
    2cc2:	add    %rdx,%rax
    2cc5:	lea    (%rax,%rax,2),%rax
    2cc9:	sub    %rax,%r8
    2ccc:	mov    %r8,%rax
    2ccf:	sar    $0x3f,%rax
    2cd3:	and    $0x3,%eax
    2cd6:	add    %r8,%rax
    2cd9:	add    $0x8,%rdi
    2cdd:	dec    %rsi
    2ce0:	mov    %rax,%r8
    2ce3:	jne    2cb0 <loop_signed_updates_baseline_d3+0x20>
    2ce5:	ret
    2ce6:	movl   $0x1,(%rcx)
    2cec:	xor    %eax,%eax
    2cee:	ret
