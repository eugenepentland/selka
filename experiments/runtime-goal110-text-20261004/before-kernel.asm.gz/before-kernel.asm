
/home/epentland/ai/canopy/mylang-worktrees/runtime-parity-harness-20261003/.mylang-cache/runtime-candidate-730a86e6-releasefast/runner/bin/text-my-llvm:     file format elf64-x86-64


Disassembly of section .text:

000000000104e580 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76>:
 104e580:	55                   	push   %rbp
 104e581:	41 57                	push   %r15
 104e583:	41 56                	push   %r14
 104e585:	41 55                	push   %r13
 104e587:	41 54                	push   %r12
 104e589:	53                   	push   %rbx
 104e58a:	48 81 ec 58 02 00 00 	sub    $0x258,%rsp
 104e591:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
 104e596:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
 104e59b:	48 89 fd             	mov    %rdi,%rbp
 104e59e:	48 39 67 40          	cmp    %rsp,0x40(%rdi)
 104e5a2:	0f 87 78 2d 00 00    	ja     1051320 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2da0>
 104e5a8:	49 89 d7             	mov    %rdx,%r15
 104e5ab:	49 89 f6             	mov    %rsi,%r14
 104e5ae:	48 c7 84 24 a8 00 00 	movq   $0x0,0xa8(%rsp)
 104e5b5:	00 00 00 00 00 
 104e5ba:	48 c7 84 24 a0 00 00 	movq   $0x0,0xa0(%rsp)
 104e5c1:	00 00 00 00 00 
 104e5c6:	8b 85 c8 02 00 00    	mov    0x2c8(%rbp),%eax
 104e5cc:	89 44 24 44          	mov    %eax,0x44(%rsp)
 104e5d0:	48 c7 44 24 38 a0 94 	movq   $0x10b94a0,0x38(%rsp)
 104e5d7:	0b 01 
 104e5d9:	48 c7 44 24 70 a0 94 	movq   $0x10b94a0,0x70(%rsp)
 104e5e0:	0b 01 
 104e5e2:	48 81 fe a0 94 0b 01 	cmp    $0x10b94a0,%rsi
 104e5e9:	75 04                	jne    104e5ef <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x6f>
 104e5eb:	31 db                	xor    %ebx,%ebx
 104e5ed:	eb 62                	jmp    104e651 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xd1>
 104e5ef:	b3 01                	mov    $0x1,%bl
 104e5f1:	4d 85 f6             	test   %r14,%r14
 104e5f4:	74 5b                	je     104e651 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xd1>
 104e5f6:	49 8b 56 08          	mov    0x8(%r14),%rdx
 104e5fa:	48 3b 15 a7 ae 06 00 	cmp    0x6aea7(%rip),%rdx        # 10b94a8 <myl_lit_d666bf92bda1d63f03bf95c09e1bffde05f85315fdade322db024e5b0244b85a_instance+0x18>
 104e601:	75 4e                	jne    104e651 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xd1>
 104e603:	48 85 d2             	test   %rdx,%rdx
 104e606:	74 e3                	je     104e5eb <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x6b>
 104e608:	41 f6 46 10 04       	testb  $0x4,0x10(%r14)
 104e60d:	75 06                	jne    104e615 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x95>
 104e60f:	49 8d 7e 18          	lea    0x18(%r14),%rdi
 104e613:	eb 10                	jmp    104e625 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xa5>
 104e615:	49 8b 46 18          	mov    0x18(%r14),%rax
 104e619:	41 8b 4e 14          	mov    0x14(%r14),%ecx
 104e61d:	48 8d 3c 08          	lea    (%rax,%rcx,1),%rdi
 104e621:	48 83 c7 18          	add    $0x18,%rdi
 104e625:	f6 05 84 ae 06 00 04 	testb  $0x4,0x6ae84(%rip)        # 10b94b0 <myl_lit_d666bf92bda1d63f03bf95c09e1bffde05f85315fdade322db024e5b0244b85a_instance+0x20>
 104e62c:	48 8b 05 85 ae 06 00 	mov    0x6ae85(%rip),%rax        # 10b94b8 <myl_lit_d666bf92bda1d63f03bf95c09e1bffde05f85315fdade322db024e5b0244b85a_instance+0x28>
 104e633:	8b 0d 7b ae 06 00    	mov    0x6ae7b(%rip),%ecx        # 10b94b4 <myl_lit_d666bf92bda1d63f03bf95c09e1bffde05f85315fdade322db024e5b0244b85a_instance+0x24>
 104e639:	48 8d 44 08 18       	lea    0x18(%rax,%rcx,1),%rax
 104e63e:	be b8 94 0b 01       	mov    $0x10b94b8,%esi
 104e643:	48 0f 45 f0          	cmovne %rax,%rsi
 104e647:	e8 f4 ca 05 00       	call   10ab140 <bcmp@plt>
 104e64c:	85 c0                	test   %eax,%eax
 104e64e:	0f 95 c3             	setne  %bl
 104e651:	48 8d 85 58 02 00 00 	lea    0x258(%rbp),%rax
 104e658:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
 104e65d:	49 bd 02 00 00 00 00 	movabs $0x4000000000000002,%r13
 104e664:	00 00 40 
 104e667:	4c 85 2d 22 ae 06 00 	test   %r13,0x6ae22(%rip)        # 10b9490 <myl_lit_d666bf92bda1d63f03bf95c09e1bffde05f85315fdade322db024e5b0244b85a_instance>
 104e66e:	75 21                	jne    104e691 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x111>
 104e670:	48 8b 05 09 ae 06 00 	mov    0x6ae09(%rip),%rax        # 10b9480 <myl_lit_d3cafad273dd497c488894ca58a5701d146f3969ca50fbb18df3109543cd07e8_instance+0x60>
 104e677:	48 ff c8             	dec    %rax
 104e67a:	75 0e                	jne    104e68a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x10a>
 104e67c:	48 83 3d 04 ae 06 00 	cmpq   $0x0,0x6ae04(%rip)        # 10b9488 <myl_lit_d3cafad273dd497c488894ca58a5701d146f3969ca50fbb18df3109543cd07e8_instance+0x68>
 104e683:	00 
 104e684:	0f 84 88 00 00 00    	je     104e712 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x192>
 104e68a:	48 89 05 ef ad 06 00 	mov    %rax,0x6adef(%rip)        # 10b9480 <myl_lit_d3cafad273dd497c488894ca58a5701d146f3969ca50fbb18df3109543cd07e8_instance+0x60>
 104e691:	48 c7 84 24 d0 00 00 	movq   $0x0,0xd0(%rsp)
 104e698:	00 00 00 00 00 
 104e69d:	84 db                	test   %bl,%bl
 104e69f:	48 89 6c 24 20       	mov    %rbp,0x20(%rsp)
 104e6a4:	4c 89 7c 24 30       	mov    %r15,0x30(%rsp)
 104e6a9:	0f 84 9d 00 00 00    	je     104e74c <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1cc>
 104e6af:	48 c7 44 24 38 b0 8f 	movq   $0x10b8fb0,0x38(%rsp)
 104e6b6:	0b 01 
 104e6b8:	48 c7 44 24 70 b0 8f 	movq   $0x10b8fb0,0x70(%rsp)
 104e6bf:	0b 01 
 104e6c1:	48 c7 84 24 d0 00 00 	movq   $0x10b8fb0,0xd0(%rsp)
 104e6c8:	00 b0 8f 0b 01 
 104e6cd:	49 81 fe b0 8f 0b 01 	cmp    $0x10b8fb0,%r14
 104e6d4:	75 07                	jne    104e6dd <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x15d>
 104e6d6:	31 db                	xor    %ebx,%ebx
 104e6d8:	e9 44 06 00 00       	jmp    104ed21 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x7a1>
 104e6dd:	b3 01                	mov    $0x1,%bl
 104e6df:	4d 85 f6             	test   %r14,%r14
 104e6e2:	0f 84 39 06 00 00    	je     104ed21 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x7a1>
 104e6e8:	49 8b 56 08          	mov    0x8(%r14),%rdx
 104e6ec:	48 3b 15 c5 a8 06 00 	cmp    0x6a8c5(%rip),%rdx        # 10b8fb8 <myl_lit_8c12e724a44132b907ad7be4d7bffd05d284ce5c644f94f5ab8dbc188941e631_instance+0x18>
 104e6f3:	0f 85 28 06 00 00    	jne    104ed21 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x7a1>
 104e6f9:	48 85 d2             	test   %rdx,%rdx
 104e6fc:	74 d8                	je     104e6d6 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x156>
 104e6fe:	41 f6 46 10 04       	testb  $0x4,0x10(%r14)
 104e703:	0f 85 dc 05 00 00    	jne    104ece5 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x765>
 104e709:	49 8d 7e 18          	lea    0x18(%r14),%rdi
 104e70d:	e9 e3 05 00 00       	jmp    104ecf5 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x775>
 104e712:	be a0 94 0b 01       	mov    $0x10b94a0,%esi
 104e717:	4c 8d a5 58 02 00 00 	lea    0x258(%rbp),%r12
 104e71e:	4c 89 e7             	mov    %r12,%rdi
 104e721:	e8 2a b2 04 00       	call   1099950 <myl_rc_edge_release>
 104e726:	48 c7 84 24 d0 00 00 	movq   $0x0,0xd0(%rsp)
 104e72d:	00 00 00 00 00 
 104e732:	4c 89 e7             	mov    %r12,%rdi
 104e735:	e8 96 e3 04 00       	call   109cad0 <myl_rc_drain>
 104e73a:	84 db                	test   %bl,%bl
 104e73c:	48 89 6c 24 20       	mov    %rbp,0x20(%rsp)
 104e741:	4c 89 7c 24 30       	mov    %r15,0x30(%rsp)
 104e746:	0f 85 63 ff ff ff    	jne    104e6af <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x12f>
 104e74c:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
 104e753:	00 00 
 104e755:	49 bf e5 8f a2 12 31 	movabs $0x89705f3112a28fe5,%r15
 104e75c:	5f 70 89 
 104e75f:	49 bc f0 ff ff ff ff 	movabs $0xffffffffffffff0,%r12
 104e766:	ff ff 0f 
 104e769:	c4 41 21 ef db       	vpxor  %xmm11,%xmm11,%xmm11
 104e76e:	c5 79 6e 25 2a 32 fb 	vmovd  -0x4cdd6(%rip),%xmm12        # 10019a0 <__abi_tag+0x16a4>
 104e775:	ff 
 104e776:	c5 79 6e 2d 72 32 fb 	vmovd  -0x4cd8e(%rip),%xmm13        # 10019f0 <__abi_tag+0x16f4>
 104e77d:	ff 
 104e77e:	c5 79 6e 35 fa 31 fb 	vmovd  -0x4ce06(%rip),%xmm14        # 1001980 <__abi_tag+0x1684>
 104e785:	ff 
 104e786:	c5 79 6e 3d 92 31 fb 	vmovd  -0x4ce6e(%rip),%xmm15        # 1001920 <__abi_tag+0x1624>
 104e78d:	ff 
 104e78e:	45 31 f6             	xor    %r14d,%r14d
 104e791:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 104e798:	0f 1f 84 00 00 00 00 
 104e79f:	00 
 104e7a0:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
 104e7a5:	4c 01 f2             	add    %r14,%rdx
 104e7a8:	0f 80 73 2a 00 00    	jo     1051221 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2ca1>
 104e7ae:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
 104e7b3:	48 8b 30             	mov    (%rax),%rsi
 104e7b6:	48 8b 46 f0          	mov    -0x10(%rsi),%rax
 104e7ba:	49 bd 02 00 00 00 00 	movabs $0x4000000000000002,%r13
 104e7c1:	00 00 40 
 104e7c4:	4c 85 e8             	test   %r13,%rax
 104e7c7:	75 11                	jne    104e7da <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x25a>
 104e7c9:	48 8b 4e e8          	mov    -0x18(%rsi),%rcx
 104e7cd:	48 ff c1             	inc    %rcx
 104e7d0:	0f 84 ce 04 00 00    	je     104eca4 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x724>
 104e7d6:	48 89 4e e8          	mov    %rcx,-0x18(%rsi)
 104e7da:	44 0f b6 c2          	movzbl %dl,%r8d
 104e7de:	48 8b 3e             	mov    (%rsi),%rdi
 104e7e1:	4c 8d 4f f0          	lea    -0x10(%rdi),%r9
 104e7e5:	4d 39 e1             	cmp    %r12,%r9
 104e7e8:	77 36                	ja     104e820 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2a0>
 104e7ea:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
 104e7ee:	49 ba 80 80 80 80 80 	movabs $0x80808080808080,%r10
 104e7f5:	80 80 00 
 104e7f8:	4c 39 d7             	cmp    %r10,%rdi
 104e7fb:	77 53                	ja     104e850 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2d0>
 104e7fd:	c5 f9 6e c2          	vmovd  %edx,%xmm0
 104e801:	c4 e2 79 78 c0       	vpbroadcastb %xmm0,%xmm0
 104e806:	45 89 c8             	mov    %r9d,%r8d
 104e809:	41 f7 d0             	not    %r8d
 104e80c:	41 f6 c0 30          	test   $0x30,%r8b
 104e810:	0f 85 72 01 00 00    	jne    104e988 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x408>
 104e816:	c5 f1 ef c9          	vpxor  %xmm1,%xmm1,%xmm1
 104e81a:	e9 b1 01 00 00       	jmp    104e9d0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x450>
 104e81f:	90                   	nop
 104e820:	48 85 ff             	test   %rdi,%rdi
 104e823:	0f 8e 58 01 00 00    	jle    104e981 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x401>
 104e829:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
 104e82d:	48 83 ff 08          	cmp    $0x8,%rdi
 104e831:	73 1d                	jae    104e850 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2d0>
 104e833:	41 ba 01 00 00 00    	mov    $0x1,%r10d
 104e839:	45 31 c9             	xor    %r9d,%r9d
 104e83c:	31 d2                	xor    %edx,%edx
 104e83e:	31 db                	xor    %ebx,%ebx
 104e840:	e9 b2 00 00 00       	jmp    104e8f7 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x377>
 104e845:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
 104e84c:	00 00 00 00 
 104e850:	48 89 fa             	mov    %rdi,%rdx
 104e853:	48 83 e2 f8          	and    $0xfffffffffffffff8,%rdx
 104e857:	c4 c1 f9 6e c0       	vmovq  %r8,%xmm0
 104e85c:	c4 e2 7d 59 d8       	vpbroadcastq %xmm0,%ymm3
 104e861:	c5 e9 ef d2          	vpxor  %xmm2,%xmm2,%xmm2
 104e865:	45 31 c9             	xor    %r9d,%r9d
 104e868:	c5 d9 ef e4          	vpxor  %xmm4,%xmm4,%xmm4
 104e86c:	c5 f9 ef c0          	vpxor  %xmm0,%xmm0,%xmm0
 104e870:	c5 f1 ef c9          	vpxor  %xmm1,%xmm1,%xmm1
 104e874:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
 104e87b:	00 00 00 00 00 
 104e880:	c4 a2 7d 32 2c 09    	vpmovzxbq (%rcx,%r9,1),%ymm5
 104e886:	c4 a2 7d 32 74 09 04 	vpmovzxbq 0x4(%rcx,%r9,1),%ymm6
 104e88d:	c5 e5 ef ed          	vpxor  %ymm5,%ymm3,%ymm5
 104e891:	c5 e5 ef f6          	vpxor  %ymm6,%ymm3,%ymm6
 104e895:	c5 d5 d4 d2          	vpaddq %ymm2,%ymm5,%ymm2
 104e899:	c5 cd d4 e4          	vpaddq %ymm4,%ymm6,%ymm4
 104e89d:	c5 d5 d4 c0          	vpaddq %ymm0,%ymm5,%ymm0
 104e8a1:	c5 cd d4 c9          	vpaddq %ymm1,%ymm6,%ymm1
 104e8a5:	49 83 c1 08          	add    $0x8,%r9
 104e8a9:	4c 39 ca             	cmp    %r9,%rdx
 104e8ac:	75 d2                	jne    104e880 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x300>
 104e8ae:	c5 dd d4 d2          	vpaddq %ymm2,%ymm4,%ymm2
 104e8b2:	c4 e3 7d 39 d3 01    	vextracti128 $0x1,%ymm2,%xmm3
 104e8b8:	c5 e9 d4 d3          	vpaddq %xmm3,%xmm2,%xmm2
 104e8bc:	c5 f9 70 da ee       	vpshufd $0xee,%xmm2,%xmm3
 104e8c1:	c5 e9 d4 d3          	vpaddq %xmm3,%xmm2,%xmm2
 104e8c5:	c4 c1 f9 7e d1       	vmovq  %xmm2,%r9
 104e8ca:	c5 f5 d4 c0          	vpaddq %ymm0,%ymm1,%ymm0
 104e8ce:	c4 e3 7d 39 c1 01    	vextracti128 $0x1,%ymm0,%xmm1
 104e8d4:	c5 f9 d4 c1          	vpaddq %xmm1,%xmm0,%xmm0
 104e8d8:	c5 f9 70 c8 ee       	vpshufd $0xee,%xmm0,%xmm1
 104e8dd:	c5 f9 d4 c1          	vpaddq %xmm1,%xmm0,%xmm0
 104e8e1:	c4 e1 f9 7e c3       	vmovq  %xmm0,%rbx
 104e8e6:	48 39 d7             	cmp    %rdx,%rdi
 104e8e9:	75 05                	jne    104e8f0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x370>
 104e8eb:	48 89 f9             	mov    %rdi,%rcx
 104e8ee:	eb 41                	jmp    104e931 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3b1>
 104e8f0:	49 89 d2             	mov    %rdx,%r10
 104e8f3:	49 83 ca 01          	or     $0x1,%r10
 104e8f7:	48 01 d1             	add    %rdx,%rcx
 104e8fa:	49 89 fb             	mov    %rdi,%r11
 104e8fd:	49 29 d3             	sub    %rdx,%r11
 104e900:	31 d2                	xor    %edx,%edx
 104e902:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 104e909:	1f 84 00 00 00 00 00 
 104e910:	0f b6 2c 11          	movzbl (%rcx,%rdx,1),%ebp
 104e914:	4c 31 c5             	xor    %r8,%rbp
 104e917:	49 01 e9             	add    %rbp,%r9
 104e91a:	48 01 eb             	add    %rbp,%rbx
 104e91d:	48 ff c2             	inc    %rdx
 104e920:	49 39 d3             	cmp    %rdx,%r11
 104e923:	75 eb                	jne    104e910 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x390>
 104e925:	49 8d 0c 12          	lea    (%r10,%rdx,1),%rcx
 104e929:	48 ff c9             	dec    %rcx
 104e92c:	48 8b 6c 24 20       	mov    0x20(%rsp),%rbp
 104e931:	ba ff ff ff ff       	mov    $0xffffffff,%edx
 104e936:	48 39 d1             	cmp    %rdx,%rcx
 104e939:	0f 92 c1             	setb   %cl
 104e93c:	4d 85 c9             	test   %r9,%r9
 104e93f:	0f 99 c2             	setns  %dl
 104e942:	84 d1                	test   %dl,%cl
 104e944:	0f 85 96 02 00 00    	jne    104ebe0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x660>
 104e94a:	4c 8b 4e 20          	mov    0x20(%rsi),%r9
 104e94e:	45 31 d2             	xor    %r10d,%r10d
 104e951:	31 d2                	xor    %edx,%edx
 104e953:	31 db                	xor    %ebx,%ebx
 104e955:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
 104e95c:	00 00 00 00 
 104e960:	43 0f b6 0c 11       	movzbl (%r9,%r10,1),%ecx
 104e965:	4c 31 c1             	xor    %r8,%rcx
 104e968:	48 01 cb             	add    %rcx,%rbx
 104e96b:	0f 80 84 28 00 00    	jo     10511f5 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2c75>
 104e971:	49 ff c2             	inc    %r10
 104e974:	48 89 da             	mov    %rbx,%rdx
 104e977:	4c 39 d7             	cmp    %r10,%rdi
 104e97a:	75 e4                	jne    104e960 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3e0>
 104e97c:	e9 5f 02 00 00       	jmp    104ebe0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x660>
 104e981:	31 db                	xor    %ebx,%ebx
 104e983:	e9 58 02 00 00       	jmp    104ebe0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x660>
 104e988:	45 89 c8             	mov    %r9d,%r8d
 104e98b:	41 c1 e8 04          	shr    $0x4,%r8d
 104e98f:	41 ff c0             	inc    %r8d
 104e992:	41 83 e0 03          	and    $0x3,%r8d
 104e996:	c5 f1 ef c9          	vpxor  %xmm1,%xmm1,%xmm1
 104e99a:	4d 89 c2             	mov    %r8,%r10
 104e99d:	49 89 cb             	mov    %rcx,%r11
 104e9a0:	c4 c1 79 ef 13       	vpxor  (%r11),%xmm0,%xmm2
 104e9a5:	c5 a1 f6 d2          	vpsadbw %xmm2,%xmm11,%xmm2
 104e9a9:	c5 e9 d4 c9          	vpaddq %xmm1,%xmm2,%xmm1
 104e9ad:	49 83 c3 10          	add    $0x10,%r11
 104e9b1:	49 ff ca             	dec    %r10
 104e9b4:	75 ea                	jne    104e9a0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x420>
 104e9b6:	41 c1 e0 04          	shl    $0x4,%r8d
 104e9ba:	4c 01 c1             	add    %r8,%rcx
 104e9bd:	4c 29 c7             	sub    %r8,%rdi
 104e9c0:	49 83 f9 30          	cmp    $0x30,%r9
 104e9c4:	72 4b                	jb     104ea11 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x491>
 104e9c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
 104e9cd:	00 00 00 
 104e9d0:	c5 f9 ef 11          	vpxor  (%rcx),%xmm0,%xmm2
 104e9d4:	c5 a1 f6 d2          	vpsadbw %xmm2,%xmm11,%xmm2
 104e9d8:	c5 e9 d4 c9          	vpaddq %xmm1,%xmm2,%xmm1
 104e9dc:	c5 f9 ef 51 10       	vpxor  0x10(%rcx),%xmm0,%xmm2
 104e9e1:	c5 a1 f6 d2          	vpsadbw %xmm2,%xmm11,%xmm2
 104e9e5:	c5 f9 ef 59 20       	vpxor  0x20(%rcx),%xmm0,%xmm3
 104e9ea:	c5 a1 f6 db          	vpsadbw %xmm3,%xmm11,%xmm3
 104e9ee:	c5 e1 d4 d2          	vpaddq %xmm2,%xmm3,%xmm2
 104e9f2:	c5 e9 d4 c9          	vpaddq %xmm1,%xmm2,%xmm1
 104e9f6:	c5 f9 ef 51 30       	vpxor  0x30(%rcx),%xmm0,%xmm2
 104e9fb:	c5 a1 f6 d2          	vpsadbw %xmm2,%xmm11,%xmm2
 104e9ff:	c5 e9 d4 c9          	vpaddq %xmm1,%xmm2,%xmm1
 104ea03:	48 83 c1 40          	add    $0x40,%rcx
 104ea07:	48 83 c7 c0          	add    $0xffffffffffffffc0,%rdi
 104ea0b:	48 83 ff 0f          	cmp    $0xf,%rdi
 104ea0f:	77 bf                	ja     104e9d0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x450>
 104ea11:	c5 f9 70 c1 ee       	vpshufd $0xee,%xmm1,%xmm0
 104ea16:	c5 f1 d4 c0          	vpaddq %xmm0,%xmm1,%xmm0
 104ea1a:	c4 e1 f9 7e c3       	vmovq  %xmm0,%rbx
 104ea1f:	48 85 ff             	test   %rdi,%rdi
 104ea22:	0f 84 b8 01 00 00    	je     104ebe0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x660>
 104ea28:	49 89 fb             	mov    %rdi,%r11
 104ea2b:	49 83 e3 03          	and    $0x3,%r11
 104ea2f:	74 3c                	je     104ea6d <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x4ed>
 104ea31:	45 31 c0             	xor    %r8d,%r8d
 104ea34:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
 104ea3b:	00 00 00 00 00 
 104ea40:	46 0f b6 0c 01       	movzbl (%rcx,%r8,1),%r9d
 104ea45:	41 30 d1             	xor    %dl,%r9b
 104ea48:	45 0f b6 c9          	movzbl %r9b,%r9d
 104ea4c:	4c 01 cb             	add    %r9,%rbx
 104ea4f:	49 ff c0             	inc    %r8
 104ea52:	4d 39 c3             	cmp    %r8,%r11
 104ea55:	75 e9                	jne    104ea40 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x4c0>
 104ea57:	49 89 f8             	mov    %rdi,%r8
 104ea5a:	49 83 e0 fc          	and    $0xfffffffffffffffc,%r8
 104ea5e:	4e 8d 0c 19          	lea    (%rcx,%r11,1),%r9
 104ea62:	48 83 ff 04          	cmp    $0x4,%rdi
 104ea66:	73 15                	jae    104ea7d <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x4fd>
 104ea68:	e9 73 01 00 00       	jmp    104ebe0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x660>
 104ea6d:	49 89 c9             	mov    %rcx,%r9
 104ea70:	49 89 f8             	mov    %rdi,%r8
 104ea73:	48 83 ff 04          	cmp    $0x4,%rdi
 104ea77:	0f 82 63 01 00 00    	jb     104ebe0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x660>
 104ea7d:	49 8d 78 fc          	lea    -0x4(%r8),%rdi
 104ea81:	48 83 ff 1c          	cmp    $0x1c,%rdi
 104ea85:	0f 82 15 01 00 00    	jb     104eba0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x620>
 104ea8b:	48 c1 ef 02          	shr    $0x2,%rdi
 104ea8f:	48 ff c7             	inc    %rdi
 104ea92:	49 89 fa             	mov    %rdi,%r10
 104ea95:	49 83 e2 f8          	and    $0xfffffffffffffff8,%r10
 104ea99:	4a 8d 2c 95 00 00 00 	lea    0x0(,%r10,4),%rbp
 104eaa0:	00 
 104eaa1:	4f 8d 0c 91          	lea    (%r9,%r10,4),%r9
 104eaa5:	49 29 e8             	sub    %rbp,%r8
 104eaa8:	c4 e1 f9 6e cb       	vmovq  %rbx,%xmm1
 104eaad:	c5 f9 6e c2          	vmovd  %edx,%xmm0
 104eab1:	c4 e2 79 78 c0       	vpbroadcastb %xmm0,%xmm0
 104eab6:	4c 01 d9             	add    %r11,%rcx
 104eab9:	48 83 c1 10          	add    $0x10,%rcx
 104eabd:	c5 e9 ef d2          	vpxor  %xmm2,%xmm2,%xmm2
 104eac1:	45 31 db             	xor    %r11d,%r11d
 104eac4:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
 104eacb:	00 00 00 00 00 
 104ead0:	c4 a1 7a 6f 5c 99 f0 	vmovdqu -0x10(%rcx,%r11,4),%xmm3
 104ead7:	c4 a1 7a 6f 24 99    	vmovdqu (%rcx,%r11,4),%xmm4
 104eadd:	c4 c2 61 00 ec       	vpshufb %xmm12,%xmm3,%xmm5
 104eae2:	c4 c2 61 00 f5       	vpshufb %xmm13,%xmm3,%xmm6
 104eae7:	c4 c2 61 00 fe       	vpshufb %xmm14,%xmm3,%xmm7
 104eaec:	c4 c2 61 00 df       	vpshufb %xmm15,%xmm3,%xmm3
 104eaf1:	c4 42 59 00 c4       	vpshufb %xmm12,%xmm4,%xmm8
 104eaf6:	c4 42 59 00 cd       	vpshufb %xmm13,%xmm4,%xmm9
 104eafb:	c4 42 59 00 d6       	vpshufb %xmm14,%xmm4,%xmm10
 104eb00:	c4 c2 59 00 e7       	vpshufb %xmm15,%xmm4,%xmm4
 104eb05:	c5 d1 ef e8          	vpxor  %xmm0,%xmm5,%xmm5
 104eb09:	c5 39 ef c0          	vpxor  %xmm0,%xmm8,%xmm8
 104eb0d:	c4 e2 7d 32 ed       	vpmovzxbq %xmm5,%ymm5
 104eb12:	c5 f5 d4 cd          	vpaddq %ymm5,%ymm1,%ymm1
 104eb16:	c4 c2 7d 32 e8       	vpmovzxbq %xmm8,%ymm5
 104eb1b:	c5 ed d4 d5          	vpaddq %ymm5,%ymm2,%ymm2
 104eb1f:	c5 c9 ef e8          	vpxor  %xmm0,%xmm6,%xmm5
 104eb23:	c5 b1 ef f0          	vpxor  %xmm0,%xmm9,%xmm6
 104eb27:	c4 e2 7d 32 ed       	vpmovzxbq %xmm5,%ymm5
 104eb2c:	c4 e2 7d 32 f6       	vpmovzxbq %xmm6,%ymm6
 104eb31:	c5 c1 ef f8          	vpxor  %xmm0,%xmm7,%xmm7
 104eb35:	c5 29 ef c0          	vpxor  %xmm0,%xmm10,%xmm8
 104eb39:	c4 e2 7d 32 ff       	vpmovzxbq %xmm7,%ymm7
 104eb3e:	c5 d5 d4 ef          	vpaddq %ymm7,%ymm5,%ymm5
 104eb42:	c5 f5 d4 cd          	vpaddq %ymm5,%ymm1,%ymm1
 104eb46:	c4 c2 7d 32 e8       	vpmovzxbq %xmm8,%ymm5
 104eb4b:	c5 cd d4 ed          	vpaddq %ymm5,%ymm6,%ymm5
 104eb4f:	c5 ed d4 d5          	vpaddq %ymm5,%ymm2,%ymm2
 104eb53:	c5 e1 ef d8          	vpxor  %xmm0,%xmm3,%xmm3
 104eb57:	c5 d9 ef e0          	vpxor  %xmm0,%xmm4,%xmm4
 104eb5b:	c4 e2 7d 32 db       	vpmovzxbq %xmm3,%ymm3
 104eb60:	c5 f5 d4 cb          	vpaddq %ymm3,%ymm1,%ymm1
 104eb64:	c4 e2 7d 32 dc       	vpmovzxbq %xmm4,%ymm3
 104eb69:	c5 ed d4 d3          	vpaddq %ymm3,%ymm2,%ymm2
 104eb6d:	49 83 c3 08          	add    $0x8,%r11
 104eb71:	4d 39 da             	cmp    %r11,%r10
 104eb74:	0f 85 56 ff ff ff    	jne    104ead0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x550>
 104eb7a:	c5 ed d4 c1          	vpaddq %ymm1,%ymm2,%ymm0
 104eb7e:	c4 e3 7d 39 c1 01    	vextracti128 $0x1,%ymm0,%xmm1
 104eb84:	c5 f9 d4 c1          	vpaddq %xmm1,%xmm0,%xmm0
 104eb88:	c5 f9 70 c8 ee       	vpshufd $0xee,%xmm0,%xmm1
 104eb8d:	c5 f9 d4 c1          	vpaddq %xmm1,%xmm0,%xmm0
 104eb91:	c4 e1 f9 7e c3       	vmovq  %xmm0,%rbx
 104eb96:	4c 39 d7             	cmp    %r10,%rdi
 104eb99:	48 8b 6c 24 20       	mov    0x20(%rsp),%rbp
 104eb9e:	74 40                	je     104ebe0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x660>
 104eba0:	c5 f9 6e c2          	vmovd  %edx,%xmm0
 104eba4:	c4 e2 79 78 c0       	vpbroadcastb %xmm0,%xmm0
 104eba9:	31 c9                	xor    %ecx,%ecx
 104ebab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
 104ebb0:	c4 c1 79 6e 0c 09    	vmovd  (%r9,%rcx,1),%xmm1
 104ebb6:	c5 f1 ef c8          	vpxor  %xmm0,%xmm1,%xmm1
 104ebba:	c4 e3 21 02 c9 01    	vpblendd $0x1,%xmm1,%xmm11,%xmm1
 104ebc0:	c5 a1 f6 c9          	vpsadbw %xmm1,%xmm11,%xmm1
 104ebc4:	c4 e1 f9 7e ca       	vmovq  %xmm1,%rdx
 104ebc9:	48 01 d3             	add    %rdx,%rbx
 104ebcc:	48 83 c1 04          	add    $0x4,%rcx
 104ebd0:	49 39 c8             	cmp    %rcx,%r8
 104ebd3:	75 db                	jne    104ebb0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x630>
 104ebd5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
 104ebdc:	00 00 00 00 
 104ebe0:	4c 85 e8             	test   %r13,%rax
 104ebe3:	74 0b                	je     104ebf0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x670>
 104ebe5:	4c 8b 6c 24 08       	mov    0x8(%rsp),%r13
 104ebea:	eb 1d                	jmp    104ec09 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x689>
 104ebec:	0f 1f 40 00          	nopl   0x0(%rax)
 104ebf0:	48 8b 46 e8          	mov    -0x18(%rsi),%rax
 104ebf4:	48 ff c8             	dec    %rax
 104ebf7:	4c 8b 6c 24 08       	mov    0x8(%rsp),%r13
 104ebfc:	75 07                	jne    104ec05 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x685>
 104ebfe:	48 83 7e e0 00       	cmpq   $0x0,-0x20(%rsi)
 104ec03:	74 58                	je     104ec5d <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x6dd>
 104ec05:	48 89 46 e8          	mov    %rax,-0x18(%rsi)
 104ec09:	4c 89 e9             	mov    %r13,%rcx
 104ec0c:	48 01 d9             	add    %rbx,%rcx
 104ec0f:	0f 80 21 26 00 00    	jo     1051236 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2cb6>
 104ec15:	48 89 c8             	mov    %rcx,%rax
 104ec18:	49 f7 ef             	imul   %r15
 104ec1b:	48 01 ca             	add    %rcx,%rdx
 104ec1e:	48 89 d0             	mov    %rdx,%rax
 104ec21:	48 c1 e8 3f          	shr    $0x3f,%rax
 104ec25:	48 c1 fa 1d          	sar    $0x1d,%rdx
 104ec29:	48 01 c2             	add    %rax,%rdx
 104ec2c:	48 69 c2 07 ca 9a 3b 	imul   $0x3b9aca07,%rdx,%rax
 104ec33:	48 29 c1             	sub    %rax,%rcx
 104ec36:	48 89 c8             	mov    %rcx,%rax
 104ec39:	48 c1 f8 3f          	sar    $0x3f,%rax
 104ec3d:	25 07 ca 9a 3b       	and    $0x3b9aca07,%eax
 104ec42:	48 01 c8             	add    %rcx,%rax
 104ec45:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
 104ec4a:	49 ff c6             	inc    %r14
 104ec4d:	4c 3b 74 24 28       	cmp    0x28(%rsp),%r14
 104ec52:	0f 85 48 fb ff ff    	jne    104e7a0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x220>
 104ec58:	e9 75 01 00 00       	jmp    104edd2 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x852>
 104ec5d:	4c 8b 6c 24 18       	mov    0x18(%rsp),%r13
 104ec62:	4c 89 ef             	mov    %r13,%rdi
 104ec65:	c5 f8 77             	vzeroupper
 104ec68:	e8 43 ae 04 00       	call   1099ab0 <myl_rc_hold_edge_release>
 104ec6d:	4c 89 ef             	mov    %r13,%rdi
 104ec70:	4c 8b 6c 24 08       	mov    0x8(%rsp),%r13
 104ec75:	e8 56 de 04 00       	call   109cad0 <myl_rc_drain>
 104ec7a:	c5 79 6e 3d 9e 2c fb 	vmovd  -0x4d362(%rip),%xmm15        # 1001920 <__abi_tag+0x1624>
 104ec81:	ff 
 104ec82:	c5 79 6e 35 f6 2c fb 	vmovd  -0x4d30a(%rip),%xmm14        # 1001980 <__abi_tag+0x1684>
 104ec89:	ff 
 104ec8a:	c5 79 6e 2d 5e 2d fb 	vmovd  -0x4d2a2(%rip),%xmm13        # 10019f0 <__abi_tag+0x16f4>
 104ec91:	ff 
 104ec92:	c5 79 6e 25 06 2d fb 	vmovd  -0x4d2fa(%rip),%xmm12        # 10019a0 <__abi_tag+0x16a4>
 104ec99:	ff 
 104ec9a:	c4 41 21 ef db       	vpxor  %xmm11,%xmm11,%xmm11
 104ec9f:	e9 65 ff ff ff       	jmp    104ec09 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x689>
 104eca4:	be bf 7d 00 01       	mov    $0x1007dbf,%esi
 104eca9:	48 89 ef             	mov    %rbp,%rdi
 104ecac:	c5 f8 77             	vzeroupper
 104ecaf:	e8 0a b9 03 00       	call   108a5be <fail>
 104ecb4:	c5 79 6e 3d 64 2c fb 	vmovd  -0x4d39c(%rip),%xmm15        # 1001920 <__abi_tag+0x1624>
 104ecbb:	ff 
 104ecbc:	c5 79 6e 35 bc 2c fb 	vmovd  -0x4d344(%rip),%xmm14        # 1001980 <__abi_tag+0x1684>
 104ecc3:	ff 
 104ecc4:	c5 79 6e 2d 24 2d fb 	vmovd  -0x4d2dc(%rip),%xmm13        # 10019f0 <__abi_tag+0x16f4>
 104eccb:	ff 
 104eccc:	c5 79 6e 25 cc 2c fb 	vmovd  -0x4d334(%rip),%xmm12        # 10019a0 <__abi_tag+0x16a4>
 104ecd3:	ff 
 104ecd4:	c4 41 21 ef db       	vpxor  %xmm11,%xmm11,%xmm11
 104ecd9:	31 db                	xor    %ebx,%ebx
 104ecdb:	4c 8b 6c 24 08       	mov    0x8(%rsp),%r13
 104ece0:	e9 24 ff ff ff       	jmp    104ec09 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x689>
 104ece5:	49 8b 46 18          	mov    0x18(%r14),%rax
 104ece9:	41 8b 4e 14          	mov    0x14(%r14),%ecx
 104eced:	48 8d 3c 08          	lea    (%rax,%rcx,1),%rdi
 104ecf1:	48 83 c7 18          	add    $0x18,%rdi
 104ecf5:	f6 05 c4 a2 06 00 04 	testb  $0x4,0x6a2c4(%rip)        # 10b8fc0 <myl_lit_8c12e724a44132b907ad7be4d7bffd05d284ce5c644f94f5ab8dbc188941e631_instance+0x20>
 104ecfc:	48 8b 05 c5 a2 06 00 	mov    0x6a2c5(%rip),%rax        # 10b8fc8 <myl_lit_8c12e724a44132b907ad7be4d7bffd05d284ce5c644f94f5ab8dbc188941e631_instance+0x28>
 104ed03:	8b 0d bb a2 06 00    	mov    0x6a2bb(%rip),%ecx        # 10b8fc4 <myl_lit_8c12e724a44132b907ad7be4d7bffd05d284ce5c644f94f5ab8dbc188941e631_instance+0x24>
 104ed09:	48 8d 44 08 18       	lea    0x18(%rax,%rcx,1),%rax
 104ed0e:	be c8 8f 0b 01       	mov    $0x10b8fc8,%esi
 104ed13:	48 0f 45 f0          	cmovne %rax,%rsi
 104ed17:	e8 24 c4 05 00       	call   10ab140 <bcmp@plt>
 104ed1c:	85 c0                	test   %eax,%eax
 104ed1e:	0f 95 c3             	setne  %bl
 104ed21:	4c 85 2d 78 a2 06 00 	test   %r13,0x6a278(%rip)        # 10b8fa0 <myl_lit_8c12e724a44132b907ad7be4d7bffd05d284ce5c644f94f5ab8dbc188941e631_instance>
 104ed28:	74 2d                	je     104ed57 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x7d7>
 104ed2a:	84 db                	test   %bl,%bl
 104ed2c:	74 4e                	je     104ed7c <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x7fc>
 104ed2e:	48 c7 44 24 70 00 8e 	movq   $0x10b8e00,0x70(%rsp)
 104ed35:	0b 01 
 104ed37:	48 c7 84 24 d0 00 00 	movq   $0x10b8e00,0xd0(%rsp)
 104ed3e:	00 00 8e 0b 01 
 104ed43:	49 81 fe 00 8e 0b 01 	cmp    $0x10b8e00,%r14
 104ed4a:	0f 85 9c 00 00 00    	jne    104edec <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x86c>
 104ed50:	31 db                	xor    %ebx,%ebx
 104ed52:	e9 af 02 00 00       	jmp    104f006 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xa86>
 104ed57:	48 8b 05 32 a2 06 00 	mov    0x6a232(%rip),%rax        # 10b8f90 <myl_lit_842ab9229ccb9156d5ed82c31992b7b48b2d840046545e9d568e989652f87fd6_instance+0x20>
 104ed5e:	48 ff c8             	dec    %rax
 104ed61:	75 0e                	jne    104ed71 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x7f1>
 104ed63:	48 83 3d 2d a2 06 00 	cmpq   $0x0,0x6a22d(%rip)        # 10b8f98 <myl_lit_842ab9229ccb9156d5ed82c31992b7b48b2d840046545e9d568e989652f87fd6_instance+0x28>
 104ed6a:	00 
 104ed6b:	0f 84 38 02 00 00    	je     104efa9 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xa29>
 104ed71:	48 89 05 18 a2 06 00 	mov    %rax,0x6a218(%rip)        # 10b8f90 <myl_lit_842ab9229ccb9156d5ed82c31992b7b48b2d840046545e9d568e989652f87fd6_instance+0x20>
 104ed78:	84 db                	test   %bl,%bl
 104ed7a:	75 b2                	jne    104ed2e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x7ae>
 104ed7c:	49 8b 47 08          	mov    0x8(%r15),%rax
 104ed80:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
 104ed85:	83 e6 03             	and    $0x3,%esi
 104ed88:	48 8b 10             	mov    (%rax),%rdx
 104ed8b:	48 39 d6             	cmp    %rdx,%rsi
 104ed8e:	0f 83 b5 24 00 00    	jae    1051249 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2cc9>
 104ed94:	49 8b 4f 10          	mov    0x10(%r15),%rcx
 104ed98:	48 8b 11             	mov    (%rcx),%rdx
 104ed9b:	48 39 d6             	cmp    %rdx,%rsi
 104ed9e:	0f 83 af 24 00 00    	jae    1051253 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2cd3>
 104eda4:	48 8b 40 20          	mov    0x20(%rax),%rax
 104eda8:	c1 e6 03             	shl    $0x3,%esi
 104edab:	48 8b 3c 30          	mov    (%rax,%rsi,1),%rdi
 104edaf:	48 8b 41 20          	mov    0x20(%rcx),%rax
 104edb3:	48 8b 34 30          	mov    (%rax,%rsi,1),%rsi
 104edb7:	b9 01 00 00 00       	mov    $0x1,%ecx
 104edbc:	48 39 f7             	cmp    %rsi,%rdi
 104edbf:	75 64                	jne    104ee25 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x8a5>
 104edc1:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
 104edc6:	48 83 7c 24 28 01    	cmpq   $0x1,0x28(%rsp)
 104edcc:	0f 85 8e 00 00 00    	jne    104ee60 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x8e0>
 104edd2:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
 104edd7:	48 81 c4 58 02 00 00 	add    $0x258,%rsp
 104edde:	5b                   	pop    %rbx
 104eddf:	41 5c                	pop    %r12
 104ede1:	41 5d                	pop    %r13
 104ede3:	41 5e                	pop    %r14
 104ede5:	41 5f                	pop    %r15
 104ede7:	5d                   	pop    %rbp
 104ede8:	c5 f8 77             	vzeroupper
 104edeb:	c3                   	ret
 104edec:	b3 01                	mov    $0x1,%bl
 104edee:	4d 85 f6             	test   %r14,%r14
 104edf1:	0f 84 0f 02 00 00    	je     104f006 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xa86>
 104edf7:	49 8b 56 08          	mov    0x8(%r14),%rdx
 104edfb:	48 3b 15 06 a0 06 00 	cmp    0x6a006(%rip),%rdx        # 10b8e08 <myl_lit_7afa21b5dfd0bec52f3c46b131c861acf738a60d12be67523b48ae28324a1934_instance+0x18>
 104ee02:	0f 85 fe 01 00 00    	jne    104f006 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xa86>
 104ee08:	48 85 d2             	test   %rdx,%rdx
 104ee0b:	0f 84 3f ff ff ff    	je     104ed50 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x7d0>
 104ee11:	41 f6 46 10 04       	testb  $0x4,0x10(%r14)
 104ee16:	0f 85 ae 01 00 00    	jne    104efca <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xa4a>
 104ee1c:	49 8d 7e 18          	lea    0x18(%r14),%rdi
 104ee20:	e9 b5 01 00 00       	jmp    104efda <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xa5a>
 104ee25:	31 c9                	xor    %ecx,%ecx
 104ee27:	48 85 ff             	test   %rdi,%rdi
 104ee2a:	74 95                	je     104edc1 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x841>
 104ee2c:	48 85 f6             	test   %rsi,%rsi
 104ee2f:	74 90                	je     104edc1 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x841>
 104ee31:	48 8b 57 08          	mov    0x8(%rdi),%rdx
 104ee35:	48 3b 56 08          	cmp    0x8(%rsi),%rdx
 104ee39:	0f 85 63 01 00 00    	jne    104efa2 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xa22>
 104ee3f:	b9 01 00 00 00       	mov    $0x1,%ecx
 104ee44:	48 85 d2             	test   %rdx,%rdx
 104ee47:	0f 84 74 ff ff ff    	je     104edc1 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x841>
 104ee4d:	f6 47 10 04          	testb  $0x4,0x10(%rdi)
 104ee51:	0f 85 3d 04 00 00    	jne    104f294 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xd14>
 104ee57:	48 83 c7 18          	add    $0x18,%rdi
 104ee5b:	e9 43 04 00 00       	jmp    104f2a3 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xd23>
 104ee60:	bb 01 00 00 00       	mov    $0x1,%ebx
 104ee65:	49 be e5 8f a2 12 31 	movabs $0x89705f3112a28fe5,%r14
 104ee6c:	5f 70 89 
 104ee6f:	eb 57                	jmp    104eec8 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x948>
 104ee71:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 104ee78:	0f 1f 84 00 00 00 00 
 104ee7f:	00 
 104ee80:	31 c9                	xor    %ecx,%ecx
 104ee82:	49 01 cf             	add    %rcx,%r15
 104ee85:	4c 89 f8             	mov    %r15,%rax
 104ee88:	49 f7 ee             	imul   %r14
 104ee8b:	4c 01 fa             	add    %r15,%rdx
 104ee8e:	48 89 d0             	mov    %rdx,%rax
 104ee91:	48 c1 e8 3f          	shr    $0x3f,%rax
 104ee95:	48 c1 fa 1d          	sar    $0x1d,%rdx
 104ee99:	48 01 c2             	add    %rax,%rdx
 104ee9c:	48 69 c2 07 ca 9a 3b 	imul   $0x3b9aca07,%rdx,%rax
 104eea3:	49 29 c7             	sub    %rax,%r15
 104eea6:	4c 89 f8             	mov    %r15,%rax
 104eea9:	48 c1 f8 3f          	sar    $0x3f,%rax
 104eead:	25 07 ca 9a 3b       	and    $0x3b9aca07,%eax
 104eeb2:	49 01 c7             	add    %rax,%r15
 104eeb5:	4c 89 7c 24 08       	mov    %r15,0x8(%rsp)
 104eeba:	48 ff c3             	inc    %rbx
 104eebd:	48 39 5c 24 28       	cmp    %rbx,0x28(%rsp)
 104eec2:	0f 84 0a ff ff ff    	je     104edd2 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x852>
 104eec8:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
 104eecd:	48 01 de             	add    %rbx,%rsi
 104eed0:	0f 80 87 23 00 00    	jo     105125d <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2cdd>
 104eed6:	48 8b 4c 24 30       	mov    0x30(%rsp),%rcx
 104eedb:	48 8b 41 08          	mov    0x8(%rcx),%rax
 104eedf:	83 e6 03             	and    $0x3,%esi
 104eee2:	48 8b 10             	mov    (%rax),%rdx
 104eee5:	48 39 d6             	cmp    %rdx,%rsi
 104eee8:	4c 8b 7c 24 08       	mov    0x8(%rsp),%r15
 104eeed:	0f 83 56 23 00 00    	jae    1051249 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2cc9>
 104eef3:	48 8b 49 10          	mov    0x10(%rcx),%rcx
 104eef7:	48 8b 11             	mov    (%rcx),%rdx
 104eefa:	48 39 d6             	cmp    %rdx,%rsi
 104eefd:	0f 83 50 23 00 00    	jae    1051253 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2cd3>
 104ef03:	48 8b 40 20          	mov    0x20(%rax),%rax
 104ef07:	c1 e6 03             	shl    $0x3,%esi
 104ef0a:	48 8b 3c 30          	mov    (%rax,%rsi,1),%rdi
 104ef0e:	48 8b 41 20          	mov    0x20(%rcx),%rax
 104ef12:	48 8b 34 30          	mov    (%rax,%rsi,1),%rsi
 104ef16:	b9 01 00 00 00       	mov    $0x1,%ecx
 104ef1b:	48 39 f7             	cmp    %rsi,%rdi
 104ef1e:	0f 84 5e ff ff ff    	je     104ee82 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x902>
 104ef24:	48 85 ff             	test   %rdi,%rdi
 104ef27:	0f 84 53 ff ff ff    	je     104ee80 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x900>
 104ef2d:	b9 00 00 00 00       	mov    $0x0,%ecx
 104ef32:	48 85 f6             	test   %rsi,%rsi
 104ef35:	0f 84 47 ff ff ff    	je     104ee82 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x902>
 104ef3b:	48 8b 57 08          	mov    0x8(%rdi),%rdx
 104ef3f:	48 3b 56 08          	cmp    0x8(%rsi),%rdx
 104ef43:	0f 85 37 ff ff ff    	jne    104ee80 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x900>
 104ef49:	b9 01 00 00 00       	mov    $0x1,%ecx
 104ef4e:	48 85 d2             	test   %rdx,%rdx
 104ef51:	0f 84 2b ff ff ff    	je     104ee82 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x902>
 104ef57:	f6 47 10 04          	testb  $0x4,0x10(%rdi)
 104ef5b:	75 1b                	jne    104ef78 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x9f8>
 104ef5d:	48 83 c7 18          	add    $0x18,%rdi
 104ef61:	f6 46 10 04          	testb  $0x4,0x10(%rsi)
 104ef65:	74 26                	je     104ef8d <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xa0d>
 104ef67:	48 8b 46 18          	mov    0x18(%rsi),%rax
 104ef6b:	8b 4e 14             	mov    0x14(%rsi),%ecx
 104ef6e:	48 8d 34 08          	lea    (%rax,%rcx,1),%rsi
 104ef72:	48 83 c6 18          	add    $0x18,%rsi
 104ef76:	eb 19                	jmp    104ef91 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xa11>
 104ef78:	48 8b 47 18          	mov    0x18(%rdi),%rax
 104ef7c:	8b 4f 14             	mov    0x14(%rdi),%ecx
 104ef7f:	48 8d 3c 08          	lea    (%rax,%rcx,1),%rdi
 104ef83:	48 83 c7 18          	add    $0x18,%rdi
 104ef87:	f6 46 10 04          	testb  $0x4,0x10(%rsi)
 104ef8b:	75 da                	jne    104ef67 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x9e7>
 104ef8d:	48 83 c6 18          	add    $0x18,%rsi
 104ef91:	e8 aa c1 05 00       	call   10ab140 <bcmp@plt>
 104ef96:	31 c9                	xor    %ecx,%ecx
 104ef98:	85 c0                	test   %eax,%eax
 104ef9a:	0f 94 c1             	sete   %cl
 104ef9d:	e9 e0 fe ff ff       	jmp    104ee82 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x902>
 104efa2:	31 c9                	xor    %ecx,%ecx
 104efa4:	e9 18 fe ff ff       	jmp    104edc1 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x841>
 104efa9:	48 8d b4 24 d0 00 00 	lea    0xd0(%rsp),%rsi
 104efb0:	00 
 104efb1:	48 8d bd 58 02 00 00 	lea    0x258(%rbp),%rdi
 104efb8:	e8 b3 70 03 00       	call   1086070 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop>
 104efbd:	84 db                	test   %bl,%bl
 104efbf:	0f 85 69 fd ff ff    	jne    104ed2e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x7ae>
 104efc5:	e9 b2 fd ff ff       	jmp    104ed7c <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x7fc>
 104efca:	49 8b 46 18          	mov    0x18(%r14),%rax
 104efce:	41 8b 4e 14          	mov    0x14(%r14),%ecx
 104efd2:	48 8d 3c 08          	lea    (%rax,%rcx,1),%rdi
 104efd6:	48 83 c7 18          	add    $0x18,%rdi
 104efda:	f6 05 2f 9e 06 00 04 	testb  $0x4,0x69e2f(%rip)        # 10b8e10 <myl_lit_7afa21b5dfd0bec52f3c46b131c861acf738a60d12be67523b48ae28324a1934_instance+0x20>
 104efe1:	48 8b 05 30 9e 06 00 	mov    0x69e30(%rip),%rax        # 10b8e18 <myl_lit_7afa21b5dfd0bec52f3c46b131c861acf738a60d12be67523b48ae28324a1934_instance+0x28>
 104efe8:	8b 0d 26 9e 06 00    	mov    0x69e26(%rip),%ecx        # 10b8e14 <myl_lit_7afa21b5dfd0bec52f3c46b131c861acf738a60d12be67523b48ae28324a1934_instance+0x24>
 104efee:	48 8d 44 08 18       	lea    0x18(%rax,%rcx,1),%rax
 104eff3:	be 18 8e 0b 01       	mov    $0x10b8e18,%esi
 104eff8:	48 0f 45 f0          	cmovne %rax,%rsi
 104effc:	e8 3f c1 05 00       	call   10ab140 <bcmp@plt>
 104f001:	85 c0                	test   %eax,%eax
 104f003:	0f 95 c3             	setne  %bl
 104f006:	4c 85 2d e3 9d 06 00 	test   %r13,0x69de3(%rip)        # 10b8df0 <myl_lit_7afa21b5dfd0bec52f3c46b131c861acf738a60d12be67523b48ae28324a1934_instance>
 104f00d:	74 36                	je     104f045 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xac5>
 104f00f:	84 db                	test   %bl,%bl
 104f011:	74 57                	je     104f06a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xaea>
 104f013:	48 c7 44 24 38 88 8a 	movq   $0x10b8a88,0x38(%rsp)
 104f01a:	0b 01 
 104f01c:	48 c7 44 24 70 88 8a 	movq   $0x10b8a88,0x70(%rsp)
 104f023:	0b 01 
 104f025:	48 c7 84 24 d0 00 00 	movq   $0x10b8a88,0xd0(%rsp)
 104f02c:	00 88 8a 0b 01 
 104f031:	49 81 fe 88 8a 0b 01 	cmp    $0x10b8a88,%r14
 104f038:	0f 85 03 02 00 00    	jne    104f241 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xcc1>
 104f03e:	31 db                	xor    %ebx,%ebx
 104f040:	e9 c6 02 00 00       	jmp    104f30b <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xd8b>
 104f045:	48 8b 05 94 9d 06 00 	mov    0x69d94(%rip),%rax        # 10b8de0 <myl_lit_7a43bb86b2bccf6ad7e922d1f9ee2e9c1abbad0e5e2f1aa80d1ed73fc964ae92_instance+0x20>
 104f04c:	48 ff c8             	dec    %rax
 104f04f:	75 0e                	jne    104f05f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xadf>
 104f051:	48 83 3d 8f 9d 06 00 	cmpq   $0x0,0x69d8f(%rip)        # 10b8de8 <myl_lit_7a43bb86b2bccf6ad7e922d1f9ee2e9c1abbad0e5e2f1aa80d1ed73fc964ae92_instance+0x28>
 104f058:	00 
 104f059:	0f 84 14 02 00 00    	je     104f273 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xcf3>
 104f05f:	48 89 05 7a 9d 06 00 	mov    %rax,0x69d7a(%rip)        # 10b8de0 <myl_lit_7a43bb86b2bccf6ad7e922d1f9ee2e9c1abbad0e5e2f1aa80d1ed73fc964ae92_instance+0x20>
 104f066:	84 db                	test   %bl,%bl
 104f068:	75 a9                	jne    104f013 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xa93>
 104f06a:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
 104f071:	00 00 
 104f073:	49 bd e5 8f a2 12 31 	movabs $0x89705f3112a28fe5,%r13
 104f07a:	5f 70 89 
 104f07d:	31 db                	xor    %ebx,%ebx
 104f07f:	90                   	nop
 104f080:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
 104f085:	48 01 de             	add    %rbx,%rsi
 104f088:	0f 80 e1 21 00 00    	jo     105126f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2cef>
 104f08e:	48 8b 4c 24 30       	mov    0x30(%rsp),%rcx
 104f093:	48 8b 41 08          	mov    0x8(%rcx),%rax
 104f097:	48 83 38 00          	cmpq   $0x0,(%rax)
 104f09b:	0f 84 e0 21 00 00    	je     1051281 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2d01>
 104f0a1:	48 8b 40 20          	mov    0x20(%rax),%rax
 104f0a5:	4c 8b 30             	mov    (%rax),%r14
 104f0a8:	4d 85 f6             	test   %r14,%r14
 104f0ab:	74 21                	je     104f0ce <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xb4e>
 104f0ad:	48 b8 02 00 00 00 00 	movabs $0x4000000000000002,%rax
 104f0b4:	00 00 40 
 104f0b7:	49 85 46 f0          	test   %rax,-0x10(%r14)
 104f0bb:	75 11                	jne    104f0ce <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xb4e>
 104f0bd:	49 8b 46 e8          	mov    -0x18(%r14),%rax
 104f0c1:	48 ff c0             	inc    %rax
 104f0c4:	0f 84 7f 1b 00 00    	je     1050c49 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x26c9>
 104f0ca:	49 89 46 e8          	mov    %rax,-0x18(%r14)
 104f0ce:	4c 89 74 24 70       	mov    %r14,0x70(%rsp)
 104f0d3:	48 8b 41 10          	mov    0x10(%rcx),%rax
 104f0d7:	83 e6 03             	and    $0x3,%esi
 104f0da:	48 8b 10             	mov    (%rax),%rdx
 104f0dd:	48 39 d6             	cmp    %rdx,%rsi
 104f0e0:	0f 83 a7 21 00 00    	jae    105128d <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2d0d>
 104f0e6:	48 8b 40 20          	mov    0x20(%rax),%rax
 104f0ea:	48 8b 04 f0          	mov    (%rax,%rsi,8),%rax
 104f0ee:	48 8b 08             	mov    (%rax),%rcx
 104f0f1:	48 85 c9             	test   %rcx,%rcx
 104f0f4:	74 3a                	je     104f130 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xbb0>
 104f0f6:	49 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%r15
 104f0fd:	49 3b 0e             	cmp    (%r14),%rcx
 104f100:	77 7e                	ja     104f180 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xc00>
 104f102:	41 8b 6e 10          	mov    0x10(%r14),%ebp
 104f106:	40 f6 c5 04          	test   $0x4,%bpl
 104f10a:	75 29                	jne    104f135 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xbb5>
 104f10c:	49 8d 7e 18          	lea    0x18(%r14),%rdi
 104f110:	f6 40 10 04          	testb  $0x4,0x10(%rax)
 104f114:	74 35                	je     104f14b <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xbcb>
 104f116:	48 8b 48 18          	mov    0x18(%rax),%rcx
 104f11a:	8b 50 14             	mov    0x14(%rax),%edx
 104f11d:	48 01 ca             	add    %rcx,%rdx
 104f120:	48 83 c2 18          	add    $0x18,%rdx
 104f124:	eb 29                	jmp    104f14f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xbcf>
 104f126:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
 104f12d:	00 00 00 
 104f130:	45 31 ff             	xor    %r15d,%r15d
 104f133:	eb 4b                	jmp    104f180 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xc00>
 104f135:	49 8b 4e 18          	mov    0x18(%r14),%rcx
 104f139:	41 8b 56 14          	mov    0x14(%r14),%edx
 104f13d:	48 8d 3c 11          	lea    (%rcx,%rdx,1),%rdi
 104f141:	48 83 c7 18          	add    $0x18,%rdi
 104f145:	f6 40 10 04          	testb  $0x4,0x10(%rax)
 104f149:	75 cb                	jne    104f116 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xb96>
 104f14b:	48 8d 50 18          	lea    0x18(%rax),%rdx
 104f14f:	49 8b 76 08          	mov    0x8(%r14),%rsi
 104f153:	48 8b 48 08          	mov    0x8(%rax),%rcx
 104f157:	e8 24 2b 04 00       	call   1091c80 <myl_native_octets_find>
 104f15c:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
 104f160:	74 1e                	je     104f180 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xc00>
 104f162:	40 f6 c5 01          	test   $0x1,%bpl
 104f166:	75 0b                	jne    104f173 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xbf3>
 104f168:	4c 89 f7             	mov    %r14,%rdi
 104f16b:	48 89 c6             	mov    %rax,%rsi
 104f16e:	e8 2d 05 04 00       	call   108f6a0 <index_walk>
 104f173:	49 89 c7             	mov    %rax,%r15
 104f176:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
 104f17d:	00 00 00 
 104f180:	4d 89 fc             	mov    %r15,%r12
 104f183:	49 ff c4             	inc    %r12
 104f186:	0f 80 09 21 00 00    	jo     1051295 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2d15>
 104f18c:	4d 85 f6             	test   %r14,%r14
 104f18f:	48 8b 6c 24 20       	mov    0x20(%rsp),%rbp
 104f194:	74 24                	je     104f1ba <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xc3a>
 104f196:	48 b8 02 00 00 00 00 	movabs $0x4000000000000002,%rax
 104f19d:	00 00 40 
 104f1a0:	49 85 46 f0          	test   %rax,-0x10(%r14)
 104f1a4:	75 14                	jne    104f1ba <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xc3a>
 104f1a6:	49 8b 46 e8          	mov    -0x18(%r14),%rax
 104f1aa:	48 ff c8             	dec    %rax
 104f1ad:	75 07                	jne    104f1b6 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xc36>
 104f1af:	49 83 7e e0 00       	cmpq   $0x0,-0x20(%r14)
 104f1b4:	74 59                	je     104f20f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xc8f>
 104f1b6:	49 89 46 e8          	mov    %rax,-0x18(%r14)
 104f1ba:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
 104f1bf:	48 89 d1             	mov    %rdx,%rcx
 104f1c2:	4c 01 e1             	add    %r12,%rcx
 104f1c5:	70 6d                	jo     104f234 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xcb4>
 104f1c7:	48 89 c8             	mov    %rcx,%rax
 104f1ca:	49 f7 ed             	imul   %r13
 104f1cd:	48 01 ca             	add    %rcx,%rdx
 104f1d0:	48 89 d0             	mov    %rdx,%rax
 104f1d3:	48 c1 e8 3f          	shr    $0x3f,%rax
 104f1d7:	48 c1 fa 1d          	sar    $0x1d,%rdx
 104f1db:	48 01 c2             	add    %rax,%rdx
 104f1de:	48 69 c2 07 ca 9a 3b 	imul   $0x3b9aca07,%rdx,%rax
 104f1e5:	48 29 c1             	sub    %rax,%rcx
 104f1e8:	48 89 c8             	mov    %rcx,%rax
 104f1eb:	48 c1 f8 3f          	sar    $0x3f,%rax
 104f1ef:	25 07 ca 9a 3b       	and    $0x3b9aca07,%eax
 104f1f4:	48 01 c8             	add    %rcx,%rax
 104f1f7:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
 104f1fc:	48 ff c3             	inc    %rbx
 104f1ff:	48 39 5c 24 28       	cmp    %rbx,0x28(%rsp)
 104f204:	0f 85 76 fe ff ff    	jne    104f080 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xb00>
 104f20a:	e9 c3 fb ff ff       	jmp    104edd2 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x852>
 104f20f:	4c 8b 7c 24 18       	mov    0x18(%rsp),%r15
 104f214:	4c 89 ff             	mov    %r15,%rdi
 104f217:	4c 89 f6             	mov    %r14,%rsi
 104f21a:	e8 91 a8 04 00       	call   1099ab0 <myl_rc_hold_edge_release>
 104f21f:	4c 89 ff             	mov    %r15,%rdi
 104f222:	e8 a9 d8 04 00       	call   109cad0 <myl_rc_drain>
 104f227:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
 104f22c:	48 89 d1             	mov    %rdx,%rcx
 104f22f:	4c 01 e1             	add    %r12,%rcx
 104f232:	71 93                	jno    104f1c7 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xc47>
 104f234:	48 89 ef             	mov    %rbp,%rdi
 104f237:	31 f6                	xor    %esi,%esi
 104f239:	4c 89 e1             	mov    %r12,%rcx
 104f23c:	e8 8f bd 03 00       	call   108afd0 <myl_qbe_fail_overflow_op>
 104f241:	b3 01                	mov    $0x1,%bl
 104f243:	4d 85 f6             	test   %r14,%r14
 104f246:	0f 84 bf 00 00 00    	je     104f30b <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xd8b>
 104f24c:	49 8b 56 08          	mov    0x8(%r14),%rdx
 104f250:	48 3b 15 39 98 06 00 	cmp    0x69839(%rip),%rdx        # 10b8a90 <myl_lit_4d6ff6f7284ab5ea56c67ebc627dbe0fd0bb153a04fdd105bd867658d486b6d7_instance+0x18>
 104f257:	0f 85 ae 00 00 00    	jne    104f30b <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xd8b>
 104f25d:	48 85 d2             	test   %rdx,%rdx
 104f260:	0f 84 d8 fd ff ff    	je     104f03e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xabe>
 104f266:	41 f6 46 10 04       	testb  $0x4,0x10(%r14)
 104f26b:	75 62                	jne    104f2cf <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xd4f>
 104f26d:	49 8d 7e 18          	lea    0x18(%r14),%rdi
 104f271:	eb 6c                	jmp    104f2df <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xd5f>
 104f273:	48 8d b4 24 d0 00 00 	lea    0xd0(%rsp),%rsi
 104f27a:	00 
 104f27b:	48 8d bd 58 02 00 00 	lea    0x258(%rbp),%rdi
 104f282:	e8 e9 6d 03 00       	call   1086070 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop>
 104f287:	84 db                	test   %bl,%bl
 104f289:	0f 85 84 fd ff ff    	jne    104f013 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xa93>
 104f28f:	e9 d6 fd ff ff       	jmp    104f06a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xaea>
 104f294:	48 8b 47 18          	mov    0x18(%rdi),%rax
 104f298:	8b 4f 14             	mov    0x14(%rdi),%ecx
 104f29b:	48 8d 3c 08          	lea    (%rax,%rcx,1),%rdi
 104f29f:	48 83 c7 18          	add    $0x18,%rdi
 104f2a3:	f6 46 10 04          	testb  $0x4,0x10(%rsi)
 104f2a7:	75 06                	jne    104f2af <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xd2f>
 104f2a9:	48 83 c6 18          	add    $0x18,%rsi
 104f2ad:	eb 0f                	jmp    104f2be <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xd3e>
 104f2af:	48 8b 46 18          	mov    0x18(%rsi),%rax
 104f2b3:	8b 4e 14             	mov    0x14(%rsi),%ecx
 104f2b6:	48 8d 34 08          	lea    (%rax,%rcx,1),%rsi
 104f2ba:	48 83 c6 18          	add    $0x18,%rsi
 104f2be:	e8 7d be 05 00       	call   10ab140 <bcmp@plt>
 104f2c3:	31 c9                	xor    %ecx,%ecx
 104f2c5:	85 c0                	test   %eax,%eax
 104f2c7:	0f 94 c1             	sete   %cl
 104f2ca:	e9 f2 fa ff ff       	jmp    104edc1 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x841>
 104f2cf:	49 8b 46 18          	mov    0x18(%r14),%rax
 104f2d3:	41 8b 4e 14          	mov    0x14(%r14),%ecx
 104f2d7:	48 8d 3c 08          	lea    (%rax,%rcx,1),%rdi
 104f2db:	48 83 c7 18          	add    $0x18,%rdi
 104f2df:	f6 05 b2 97 06 00 04 	testb  $0x4,0x697b2(%rip)        # 10b8a98 <myl_lit_4d6ff6f7284ab5ea56c67ebc627dbe0fd0bb153a04fdd105bd867658d486b6d7_instance+0x20>
 104f2e6:	48 8b 05 b3 97 06 00 	mov    0x697b3(%rip),%rax        # 10b8aa0 <myl_lit_4d6ff6f7284ab5ea56c67ebc627dbe0fd0bb153a04fdd105bd867658d486b6d7_instance+0x28>
 104f2ed:	8b 0d a9 97 06 00    	mov    0x697a9(%rip),%ecx        # 10b8a9c <myl_lit_4d6ff6f7284ab5ea56c67ebc627dbe0fd0bb153a04fdd105bd867658d486b6d7_instance+0x24>
 104f2f3:	48 8d 44 08 18       	lea    0x18(%rax,%rcx,1),%rax
 104f2f8:	be a0 8a 0b 01       	mov    $0x10b8aa0,%esi
 104f2fd:	48 0f 45 f0          	cmovne %rax,%rsi
 104f301:	e8 3a be 05 00       	call   10ab140 <bcmp@plt>
 104f306:	85 c0                	test   %eax,%eax
 104f308:	0f 95 c3             	setne  %bl
 104f30b:	4c 85 2d 66 97 06 00 	test   %r13,0x69766(%rip)        # 10b8a78 <myl_lit_4d6ff6f7284ab5ea56c67ebc627dbe0fd0bb153a04fdd105bd867658d486b6d7_instance>
 104f312:	0f 84 2d 04 00 00    	je     104f745 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x11c5>
 104f318:	84 db                	test   %bl,%bl
 104f31a:	0f 84 4e 04 00 00    	je     104f76e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x11ee>
 104f320:	48 c7 44 24 70 50 89 	movq   $0x10b8950,0x70(%rsp)
 104f327:	0b 01 
 104f329:	48 c7 84 24 d0 00 00 	movq   $0x10b8950,0xd0(%rsp)
 104f330:	00 50 89 0b 01 
 104f335:	be 50 89 0b 01       	mov    $0x10b8950,%esi
 104f33a:	4c 89 f7             	mov    %r14,%rdi
 104f33d:	e8 be 28 04 00       	call   1091c00 <myl_native_text_equal>
 104f342:	4c 85 2d f7 95 06 00 	test   %r13,0x695f7(%rip)        # 10b8940 <myl_lit_4a11bea7b5a6ce8d077c05a11569e05d5d64f10b6601437976e3917dc8273132_instance>
 104f349:	75 21                	jne    104f36c <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xdec>
 104f34b:	48 8b 0d de 95 06 00 	mov    0x695de(%rip),%rcx        # 10b8930 <myl_lit_49ddcee716aac9f3632795416226e674fb40f0332dabf1de33fc7f8b34af0696_instance+0x38>
 104f352:	48 ff c9             	dec    %rcx
 104f355:	75 0e                	jne    104f365 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xde5>
 104f357:	48 83 3d d9 95 06 00 	cmpq   $0x0,0x695d9(%rip)        # 10b8938 <myl_lit_49ddcee716aac9f3632795416226e674fb40f0332dabf1de33fc7f8b34af0696_instance+0x40>
 104f35e:	00 
 104f35f:	0f 84 15 16 00 00    	je     105097a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x23fa>
 104f365:	48 89 0d c4 95 06 00 	mov    %rcx,0x695c4(%rip)        # 10b8930 <myl_lit_49ddcee716aac9f3632795416226e674fb40f0332dabf1de33fc7f8b34af0696_instance+0x38>
 104f36c:	85 c0                	test   %eax,%eax
 104f36e:	0f 84 26 16 00 00    	je     105099a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x241a>
 104f374:	4c 8d 74 24 48       	lea    0x48(%rsp),%r14
 104f379:	48 8d 4c 24 70       	lea    0x70(%rsp),%rcx
 104f37e:	48 89 c8             	mov    %rcx,%rax
 104f381:	4c 29 f0             	sub    %r14,%rax
 104f384:	49 29 ce             	sub    %rcx,%r14
 104f387:	4c 0f 42 f0          	cmovb  %rax,%r14
 104f38b:	48 b8 00 00 00 00 00 	movabs $0x5000000000000000,%rax
 104f392:	00 00 50 
 104f395:	45 31 ff             	xor    %r15d,%r15d
 104f398:	48 ff c0             	inc    %rax
 104f39b:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
 104f3a0:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
 104f3a7:	00 00 
 104f3a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
 104f3b0:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
 104f3b5:	4c 01 f8             	add    %r15,%rax
 104f3b8:	0f 80 7f 1f 00 00    	jo     105133d <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2dbd>
 104f3be:	a8 01                	test   $0x1,%al
 104f3c0:	48 bb 02 00 00 00 00 	movabs $0x4000000000000002,%rbx
 104f3c7:	00 00 40 
 104f3ca:	0f 85 80 00 00 00    	jne    104f450 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xed0>
 104f3d0:	48 c7 44 24 70 a0 97 	movq   $0x10b97a0,0x70(%rsp)
 104f3d7:	0b 01 
 104f3d9:	48 c7 84 24 c8 01 00 	movq   $0x10b97a0,0x1c8(%rsp)
 104f3e0:	00 a0 97 0b 01 
 104f3e5:	48 c7 44 24 48 a0 97 	movq   $0x10b97a0,0x48(%rsp)
 104f3ec:	0b 01 
 104f3ee:	48 8b 05 9b a3 06 00 	mov    0x6a39b(%rip),%rax        # 10b9790 <myl_lit_f3eaad558815542caf7da2bdfda9d4cabeaf9c2200b79ab8ff85b21b8470fac6_instance>
 104f3f5:	48 85 44 24 50       	test   %rax,0x50(%rsp)
 104f3fa:	0f 84 fa 00 00 00    	je     104f4fa <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xf7a>
 104f400:	4d 85 f6             	test   %r14,%r14
 104f403:	0f 94 c1             	sete   %cl
 104f406:	48 ba 00 00 00 00 00 	movabs $0x5000000000000000,%rdx
 104f40d:	00 00 50 
 104f410:	48 85 d0             	test   %rdx,%rax
 104f413:	0f 95 c0             	setne  %al
 104f416:	08 c8                	or     %cl,%al
 104f418:	0f 84 f8 00 00 00    	je     104f516 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xf96>
 104f41e:	be 78 0c 03 01       	mov    $0x1030c78,%esi
 104f423:	48 8d bd 58 02 00 00 	lea    0x258(%rbp),%rdi
 104f42a:	48 8d 54 24 70       	lea    0x70(%rsp),%rdx
 104f42f:	48 8d 4c 24 48       	lea    0x48(%rsp),%rcx
 104f434:	44 8b 44 24 44       	mov    0x44(%rsp),%r8d
 104f439:	e8 b2 6a 05 00       	call   10a5ef0 <myl_rc_native_take>
 104f43e:	85 c0                	test   %eax,%eax
 104f440:	0f 85 80 00 00 00    	jne    104f4c6 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xf46>
 104f446:	e9 c3 14 00 00       	jmp    105090e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x238e>
 104f44b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
 104f450:	48 c7 44 24 70 10 8b 	movq   $0x10b8b10,0x70(%rsp)
 104f457:	0b 01 
 104f459:	48 c7 84 24 c8 01 00 	movq   $0x10b8b10,0x1c8(%rsp)
 104f460:	00 10 8b 0b 01 
 104f465:	48 c7 44 24 48 10 8b 	movq   $0x10b8b10,0x48(%rsp)
 104f46c:	0b 01 
 104f46e:	48 8b 05 8b 96 06 00 	mov    0x6968b(%rip),%rax        # 10b8b00 <myl_lit_54807ae7ae90f7f8ab8705f04b17dcd2d77e7355f27b7f7252156b0c234f7d3f_instance>
 104f475:	48 85 44 24 50       	test   %rax,0x50(%rsp)
 104f47a:	0f 84 c4 00 00 00    	je     104f544 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xfc4>
 104f480:	4d 85 f6             	test   %r14,%r14
 104f483:	0f 94 c1             	sete   %cl
 104f486:	48 ba 00 00 00 00 00 	movabs $0x5000000000000000,%rdx
 104f48d:	00 00 50 
 104f490:	48 85 d0             	test   %rdx,%rax
 104f493:	0f 95 c0             	setne  %al
 104f496:	08 c8                	or     %cl,%al
 104f498:	0f 84 9d 00 00 00    	je     104f53b <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xfbb>
 104f49e:	be 78 0c 03 01       	mov    $0x1030c78,%esi
 104f4a3:	48 8d bd 58 02 00 00 	lea    0x258(%rbp),%rdi
 104f4aa:	48 8d 54 24 70       	lea    0x70(%rsp),%rdx
 104f4af:	48 8d 4c 24 48       	lea    0x48(%rsp),%rcx
 104f4b4:	44 8b 44 24 44       	mov    0x44(%rsp),%r8d
 104f4b9:	e8 32 6a 05 00       	call   10a5ef0 <myl_rc_native_take>
 104f4be:	85 c0                	test   %eax,%eax
 104f4c0:	0f 84 7e 14 00 00    	je     1050944 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x23c4>
 104f4c6:	4c 8b 64 24 70       	mov    0x70(%rsp),%r12
 104f4cb:	4c 89 a4 24 a8 00 00 	mov    %r12,0xa8(%rsp)
 104f4d2:	00 
 104f4d3:	4c 89 64 24 48       	mov    %r12,0x48(%rsp)
 104f4d8:	4d 85 e4             	test   %r12,%r12
 104f4db:	0f 84 f3 01 00 00    	je     104f6d4 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1154>
 104f4e1:	49 85 5c 24 f0       	test   %rbx,-0x10(%r12)
 104f4e6:	74 76                	je     104f55e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xfde>
 104f4e8:	4c 89 64 24 70       	mov    %r12,0x70(%rsp)
 104f4ed:	4c 89 a4 24 a0 00 00 	mov    %r12,0xa0(%rsp)
 104f4f4:	00 
 104f4f5:	e9 9f 00 00 00       	jmp    104f599 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1019>
 104f4fa:	41 bc a0 97 0b 01    	mov    $0x10b97a0,%r12d
 104f500:	4c 89 a4 24 a8 00 00 	mov    %r12,0xa8(%rsp)
 104f507:	00 
 104f508:	4c 89 64 24 48       	mov    %r12,0x48(%rsp)
 104f50d:	49 85 5c 24 f0       	test   %rbx,-0x10(%r12)
 104f512:	75 d4                	jne    104f4e8 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xf68>
 104f514:	eb 48                	jmp    104f55e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xfde>
 104f516:	48 c7 44 24 70 a0 97 	movq   $0x10b97a0,0x70(%rsp)
 104f51d:	0b 01 
 104f51f:	41 bc a0 97 0b 01    	mov    $0x10b97a0,%r12d
 104f525:	4c 89 a4 24 a8 00 00 	mov    %r12,0xa8(%rsp)
 104f52c:	00 
 104f52d:	4c 89 64 24 48       	mov    %r12,0x48(%rsp)
 104f532:	49 85 5c 24 f0       	test   %rbx,-0x10(%r12)
 104f537:	75 af                	jne    104f4e8 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xf68>
 104f539:	eb 23                	jmp    104f55e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xfde>
 104f53b:	48 c7 44 24 70 10 8b 	movq   $0x10b8b10,0x70(%rsp)
 104f542:	0b 01 
 104f544:	41 bc 10 8b 0b 01    	mov    $0x10b8b10,%r12d
 104f54a:	4c 89 a4 24 a8 00 00 	mov    %r12,0xa8(%rsp)
 104f551:	00 
 104f552:	4c 89 64 24 48       	mov    %r12,0x48(%rsp)
 104f557:	49 85 5c 24 f0       	test   %rbx,-0x10(%r12)
 104f55c:	75 8a                	jne    104f4e8 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xf68>
 104f55e:	49 8b 44 24 e8       	mov    -0x18(%r12),%rax
 104f563:	48 ff c0             	inc    %rax
 104f566:	0f 84 dd 16 00 00    	je     1050c49 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x26c9>
 104f56c:	49 89 44 24 e8       	mov    %rax,-0x18(%r12)
 104f571:	4c 89 64 24 70       	mov    %r12,0x70(%rsp)
 104f576:	4c 89 a4 24 a0 00 00 	mov    %r12,0xa0(%rsp)
 104f57d:	00 
 104f57e:	49 8b 44 24 e0       	mov    -0x20(%r12),%rax
 104f583:	48 ff c8             	dec    %rax
 104f586:	75 0c                	jne    104f594 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1014>
 104f588:	49 83 7c 24 e8 00    	cmpq   $0x0,-0x18(%r12)
 104f58e:	0f 84 7f 01 00 00    	je     104f713 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1193>
 104f594:	49 89 44 24 e0       	mov    %rax,-0x20(%r12)
 104f599:	48 c7 84 24 a8 00 00 	movq   $0x0,0xa8(%rsp)
 104f5a0:	00 00 00 00 00 
 104f5a5:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
 104f5aa:	48 8b 50 20          	mov    0x20(%rax),%rdx
 104f5ae:	48 8d bd 58 02 00 00 	lea    0x258(%rbp),%rdi
 104f5b5:	4c 89 e6             	mov    %r12,%rsi
 104f5b8:	e8 d3 29 04 00       	call   1091f90 <myl_native_text_join>
 104f5bd:	48 85 c0             	test   %rax,%rax
 104f5c0:	0f 84 62 1d 00 00    	je     1051328 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2da8>
 104f5c6:	48 89 c3             	mov    %rax,%rbx
 104f5c9:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
 104f5ce:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
 104f5d3:	48 89 84 24 c8 01 00 	mov    %rax,0x1c8(%rsp)
 104f5da:	00 
 104f5db:	48 89 ef             	mov    %rbp,%rdi
 104f5de:	48 89 c6             	mov    %rax,%rsi
 104f5e1:	e8 ea 49 02 00       	call   1073fd0 <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85>
 104f5e6:	49 89 c5             	mov    %rax,%r13
 104f5e9:	48 b8 02 00 00 00 00 	movabs $0x4000000000000002,%rax
 104f5f0:	00 00 40 
 104f5f3:	48 85 43 f0          	test   %rax,-0x10(%rbx)
 104f5f7:	74 17                	je     104f610 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1090>
 104f5f9:	48 c7 84 24 c8 01 00 	movq   $0x0,0x1c8(%rsp)
 104f600:	00 00 00 00 00 
 104f605:	4d 85 e4             	test   %r12,%r12
 104f608:	75 2f                	jne    104f639 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x10b9>
 104f60a:	eb 65                	jmp    104f671 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x10f1>
 104f60c:	0f 1f 40 00          	nopl   0x0(%rax)
 104f610:	48 8b 43 e0          	mov    -0x20(%rbx),%rax
 104f614:	48 ff c8             	dec    %rax
 104f617:	75 0b                	jne    104f624 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x10a4>
 104f619:	48 83 7b e8 00       	cmpq   $0x0,-0x18(%rbx)
 104f61e:	0f 84 cd 00 00 00    	je     104f6f1 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1171>
 104f624:	48 89 43 e0          	mov    %rax,-0x20(%rbx)
 104f628:	48 c7 84 24 c8 01 00 	movq   $0x0,0x1c8(%rsp)
 104f62f:	00 00 00 00 00 
 104f634:	4d 85 e4             	test   %r12,%r12
 104f637:	74 38                	je     104f671 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x10f1>
 104f639:	48 b8 02 00 00 00 00 	movabs $0x4000000000000002,%rax
 104f640:	00 00 40 
 104f643:	49 85 44 24 f0       	test   %rax,-0x10(%r12)
 104f648:	75 1b                	jne    104f665 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x10e5>
 104f64a:	49 8b 44 24 e8       	mov    -0x18(%r12),%rax
 104f64f:	48 ff c8             	dec    %rax
 104f652:	75 0c                	jne    104f660 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x10e0>
 104f654:	49 83 7c 24 e0 00    	cmpq   $0x0,-0x20(%r12)
 104f65a:	0f 84 cc 00 00 00    	je     104f72c <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x11ac>
 104f660:	49 89 44 24 e8       	mov    %rax,-0x18(%r12)
 104f665:	48 c7 84 24 a0 00 00 	movq   $0x0,0xa0(%rsp)
 104f66c:	00 00 00 00 00 
 104f671:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
 104f676:	48 89 d1             	mov    %rdx,%rcx
 104f679:	4c 01 e9             	add    %r13,%rcx
 104f67c:	0f 80 ae 1c 00 00    	jo     1051330 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2db0>
 104f682:	48 89 c8             	mov    %rcx,%rax
 104f685:	48 ba e5 8f a2 12 31 	movabs $0x89705f3112a28fe5,%rdx
 104f68c:	5f 70 89 
 104f68f:	48 f7 ea             	imul   %rdx
 104f692:	48 01 ca             	add    %rcx,%rdx
 104f695:	48 89 d0             	mov    %rdx,%rax
 104f698:	48 c1 e8 3f          	shr    $0x3f,%rax
 104f69c:	48 c1 fa 1d          	sar    $0x1d,%rdx
 104f6a0:	48 01 c2             	add    %rax,%rdx
 104f6a3:	48 69 c2 07 ca 9a 3b 	imul   $0x3b9aca07,%rdx,%rax
 104f6aa:	48 29 c1             	sub    %rax,%rcx
 104f6ad:	48 89 c8             	mov    %rcx,%rax
 104f6b0:	48 c1 f8 3f          	sar    $0x3f,%rax
 104f6b4:	25 07 ca 9a 3b       	and    $0x3b9aca07,%eax
 104f6b9:	48 01 c8             	add    %rcx,%rax
 104f6bc:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
 104f6c1:	49 ff c7             	inc    %r15
 104f6c4:	4c 39 7c 24 28       	cmp    %r15,0x28(%rsp)
 104f6c9:	0f 85 e1 fc ff ff    	jne    104f3b0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xe30>
 104f6cf:	e9 fe f6 ff ff       	jmp    104edd2 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x852>
 104f6d4:	48 c7 44 24 70 00 00 	movq   $0x0,0x70(%rsp)
 104f6db:	00 00 
 104f6dd:	48 c7 84 24 a0 00 00 	movq   $0x0,0xa0(%rsp)
 104f6e4:	00 00 00 00 00 
 104f6e9:	45 31 e4             	xor    %r12d,%r12d
 104f6ec:	e9 b4 fe ff ff       	jmp    104f5a5 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1025>
 104f6f1:	48 8d bd 58 02 00 00 	lea    0x258(%rbp),%rdi
 104f6f8:	48 8d b4 24 c8 01 00 	lea    0x1c8(%rsp),%rsi
 104f6ff:	00 
 104f700:	e8 6b 69 03 00       	call   1086070 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop>
 104f705:	4d 85 e4             	test   %r12,%r12
 104f708:	0f 85 2b ff ff ff    	jne    104f639 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x10b9>
 104f70e:	e9 5e ff ff ff       	jmp    104f671 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x10f1>
 104f713:	48 8d bd 58 02 00 00 	lea    0x258(%rbp),%rdi
 104f71a:	48 8d b4 24 a8 00 00 	lea    0xa8(%rsp),%rsi
 104f721:	00 
 104f722:	e8 49 69 03 00       	call   1086070 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop>
 104f727:	e9 79 fe ff ff       	jmp    104f5a5 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1025>
 104f72c:	48 8d bd 58 02 00 00 	lea    0x258(%rbp),%rdi
 104f733:	48 8d b4 24 a0 00 00 	lea    0xa0(%rsp),%rsi
 104f73a:	00 
 104f73b:	e8 c0 68 03 00       	call   1086000 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan>
 104f740:	e9 2c ff ff ff       	jmp    104f671 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x10f1>
 104f745:	48 8b 05 1c 93 06 00 	mov    0x6931c(%rip),%rax        # 10b8a68 <myl_lit_4b4df4d43798003d79847faa0fc7a8aff0b04bace93d5fc2cc109ef7308827f6_instance+0x38>
 104f74c:	48 ff c8             	dec    %rax
 104f74f:	75 0e                	jne    104f75f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x11df>
 104f751:	48 83 3d 17 93 06 00 	cmpq   $0x0,0x69317(%rip)        # 10b8a70 <myl_lit_4b4df4d43798003d79847faa0fc7a8aff0b04bace93d5fc2cc109ef7308827f6_instance+0x40>
 104f758:	00 
 104f759:	0f 84 8e 11 00 00    	je     10508ed <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x236d>
 104f75f:	48 89 05 02 93 06 00 	mov    %rax,0x69302(%rip)        # 10b8a68 <myl_lit_4b4df4d43798003d79847faa0fc7a8aff0b04bace93d5fc2cc109ef7308827f6_instance+0x38>
 104f766:	84 db                	test   %bl,%bl
 104f768:	0f 85 b2 fb ff ff    	jne    104f320 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xda0>
 104f76e:	48 b9 00 00 00 00 00 	movabs $0x5000000000000000,%rcx
 104f775:	00 00 50 
 104f778:	49 bf 01 01 01 01 01 	movabs $0x101010101010101,%r15
 104f77f:	01 01 01 
 104f782:	48 8d 54 24 38       	lea    0x38(%rsp),%rdx
 104f787:	48 8d 74 24 70       	lea    0x70(%rsp),%rsi
 104f78c:	48 89 f0             	mov    %rsi,%rax
 104f78f:	48 29 d0             	sub    %rdx,%rax
 104f792:	48 29 f2             	sub    %rsi,%rdx
 104f795:	48 0f 42 d0          	cmovb  %rax,%rdx
 104f799:	48 89 94 24 30 01 00 	mov    %rdx,0x130(%rsp)
 104f7a0:	00 
 104f7a1:	48 8d 54 24 68       	lea    0x68(%rsp),%rdx
 104f7a6:	48 8d 74 24 60       	lea    0x60(%rsp),%rsi
 104f7ab:	48 89 f0             	mov    %rsi,%rax
 104f7ae:	48 29 d0             	sub    %rdx,%rax
 104f7b1:	48 29 f2             	sub    %rsi,%rdx
 104f7b4:	48 0f 42 d0          	cmovb  %rax,%rdx
 104f7b8:	48 89 94 24 88 01 00 	mov    %rdx,0x188(%rsp)
 104f7bf:	00 
 104f7c0:	45 31 ed             	xor    %r13d,%r13d
 104f7c3:	48 8d 41 01          	lea    0x1(%rcx),%rax
 104f7c7:	48 89 84 24 f8 00 00 	mov    %rax,0xf8(%rsp)
 104f7ce:	00 
 104f7cf:	c4 62 79 58 0d ac 79 	vpbroadcastd -0x48654(%rip),%xmm9        # 1007184 <__abi_tag+0x6e88>
 104f7d6:	fb ff 
 104f7d8:	c4 62 7d 58 15 a3 79 	vpbroadcastd -0x4865d(%rip),%ymm10        # 1007184 <__abi_tag+0x6e88>
 104f7df:	fb ff 
 104f7e1:	c4 e2 7d 59 05 2e 79 	vpbroadcastq -0x486d2(%rip),%ymm0        # 1007118 <__abi_tag+0x6e1c>
 104f7e8:	fb ff 
 104f7ea:	c5 fe 7f 84 24 f0 01 	vmovdqu %ymm0,0x1f0(%rsp)
 104f7f1:	00 00 
 104f7f3:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
 104f7fa:	00 00 
 104f7fc:	c5 79 7f 4c 24 50    	vmovdqa %xmm9,0x50(%rsp)
 104f802:	c5 7e 7f 94 24 10 01 	vmovdqu %ymm10,0x110(%rsp)
 104f809:	00 00 
 104f80b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
 104f810:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
 104f815:	4c 01 ee             	add    %r13,%rsi
 104f818:	0f 80 96 1a 00 00    	jo     10512b4 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2d34>
 104f81e:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
 104f823:	48 8b 40 08          	mov    0x8(%rax),%rax
 104f827:	83 e6 01             	and    $0x1,%esi
 104f82a:	48 8b 10             	mov    (%rax),%rdx
 104f82d:	48 39 d6             	cmp    %rdx,%rsi
 104f830:	0f 83 73 1a 00 00    	jae    10512a9 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2d29>
 104f836:	48 8b 40 20          	mov    0x20(%rax),%rax
 104f83a:	4c 8b 34 f0          	mov    (%rax,%rsi,8),%r14
 104f83e:	48 85 f6             	test   %rsi,%rsi
 104f841:	0f 85 99 00 00 00    	jne    104f8e0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1360>
 104f847:	48 c7 44 24 70 a0 97 	movq   $0x10b97a0,0x70(%rsp)
 104f84e:	0b 01 
 104f850:	48 c7 84 24 d0 00 00 	movq   $0x10b97a0,0xd0(%rsp)
 104f857:	00 a0 97 0b 01 
 104f85c:	48 c7 44 24 38 a0 97 	movq   $0x10b97a0,0x38(%rsp)
 104f863:	0b 01 
 104f865:	48 8b 05 24 9f 06 00 	mov    0x69f24(%rip),%rax        # 10b9790 <myl_lit_f3eaad558815542caf7da2bdfda9d4cabeaf9c2200b79ab8ff85b21b8470fac6_instance>
 104f86c:	48 85 84 24 f8 00 00 	test   %rax,0xf8(%rsp)
 104f873:	00 
 104f874:	0f 84 fb 00 00 00    	je     104f975 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x13f5>
 104f87a:	48 83 bc 24 30 01 00 	cmpq   $0x0,0x130(%rsp)
 104f881:	00 00 
 104f883:	0f 95 c1             	setne  %cl
 104f886:	48 ba 00 00 00 00 00 	movabs $0x5000000000000000,%rdx
 104f88d:	00 00 50 
 104f890:	48 85 d0             	test   %rdx,%rax
 104f893:	0f 94 c2             	sete   %dl
 104f896:	b8 a0 97 0b 01       	mov    $0x10b97a0,%eax
 104f89b:	84 ca                	test   %cl,%dl
 104f89d:	0f 85 cd 00 00 00    	jne    104f970 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x13f0>
 104f8a3:	be 78 0c 03 01       	mov    $0x1030c78,%esi
 104f8a8:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
 104f8ad:	48 8d 54 24 70       	lea    0x70(%rsp),%rdx
 104f8b2:	48 8d 4c 24 38       	lea    0x38(%rsp),%rcx
 104f8b7:	44 8b 44 24 44       	mov    0x44(%rsp),%r8d
 104f8bc:	c5 f8 77             	vzeroupper
 104f8bf:	e8 2c 66 05 00       	call   10a5ef0 <myl_rc_native_take>
 104f8c4:	c5 7e 6f 94 24 10 01 	vmovdqu 0x110(%rsp),%ymm10
 104f8cb:	00 00 
 104f8cd:	c5 79 6f 4c 24 50    	vmovdqa 0x50(%rsp),%xmm9
 104f8d3:	85 c0                	test   %eax,%eax
 104f8d5:	0f 85 a3 00 00 00    	jne    104f97e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x13fe>
 104f8db:	e9 9b 0f 00 00       	jmp    105087b <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x22fb>
 104f8e0:	48 c7 44 24 70 10 8b 	movq   $0x10b8b10,0x70(%rsp)
 104f8e7:	0b 01 
 104f8e9:	48 c7 84 24 d0 00 00 	movq   $0x10b8b10,0xd0(%rsp)
 104f8f0:	00 10 8b 0b 01 
 104f8f5:	48 c7 44 24 38 10 8b 	movq   $0x10b8b10,0x38(%rsp)
 104f8fc:	0b 01 
 104f8fe:	48 8b 05 fb 91 06 00 	mov    0x691fb(%rip),%rax        # 10b8b00 <myl_lit_54807ae7ae90f7f8ab8705f04b17dcd2d77e7355f27b7f7252156b0c234f7d3f_instance>
 104f905:	48 85 84 24 f8 00 00 	test   %rax,0xf8(%rsp)
 104f90c:	00 
 104f90d:	74 66                	je     104f975 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x13f5>
 104f90f:	48 83 bc 24 30 01 00 	cmpq   $0x0,0x130(%rsp)
 104f916:	00 00 
 104f918:	0f 95 c1             	setne  %cl
 104f91b:	48 ba 00 00 00 00 00 	movabs $0x5000000000000000,%rdx
 104f922:	00 00 50 
 104f925:	48 85 d0             	test   %rdx,%rax
 104f928:	0f 94 c2             	sete   %dl
 104f92b:	b8 10 8b 0b 01       	mov    $0x10b8b10,%eax
 104f930:	84 ca                	test   %cl,%dl
 104f932:	75 3c                	jne    104f970 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x13f0>
 104f934:	be 78 0c 03 01       	mov    $0x1030c78,%esi
 104f939:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
 104f93e:	48 8d 54 24 70       	lea    0x70(%rsp),%rdx
 104f943:	48 8d 4c 24 38       	lea    0x38(%rsp),%rcx
 104f948:	44 8b 44 24 44       	mov    0x44(%rsp),%r8d
 104f94d:	c5 f8 77             	vzeroupper
 104f950:	e8 9b 65 05 00       	call   10a5ef0 <myl_rc_native_take>
 104f955:	c5 7e 6f 94 24 10 01 	vmovdqu 0x110(%rsp),%ymm10
 104f95c:	00 00 
 104f95e:	c5 79 6f 4c 24 50    	vmovdqa 0x50(%rsp),%xmm9
 104f964:	85 c0                	test   %eax,%eax
 104f966:	75 16                	jne    104f97e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x13fe>
 104f968:	e9 47 0f 00 00       	jmp    10508b4 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2334>
 104f96d:	0f 1f 00             	nopl   (%rax)
 104f970:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
 104f975:	48 c7 44 24 38 00 00 	movq   $0x0,0x38(%rsp)
 104f97c:	00 00 
 104f97e:	48 8b 54 24 70       	mov    0x70(%rsp),%rdx
 104f983:	48 c7 84 24 50 02 00 	movq   $0x0,0x250(%rsp)
 104f98a:	00 00 00 00 00 
 104f98f:	48 c7 84 24 30 02 00 	movq   $0x0,0x230(%rsp)
 104f996:	00 00 00 00 00 
 104f99b:	48 39 65 40          	cmp    %rsp,0x40(%rbp)
 104f99f:	0f 87 24 19 00 00    	ja     10512c9 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2d49>
 104f9a5:	48 83 3a 00          	cmpq   $0x0,(%rdx)
 104f9a9:	0f 84 25 19 00 00    	je     10512d4 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2d54>
 104f9af:	8b b5 c8 02 00 00    	mov    0x2c8(%rbp),%esi
 104f9b5:	4c 89 b4 24 c8 00 00 	mov    %r14,0xc8(%rsp)
 104f9bc:	00 
 104f9bd:	48 89 94 24 40 01 00 	mov    %rdx,0x140(%rsp)
 104f9c4:	00 
 104f9c5:	41 f6 46 10 04       	testb  $0x4,0x10(%r14)
 104f9ca:	75 24                	jne    104f9f0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1470>
 104f9cc:	49 8d 5e 18          	lea    0x18(%r14),%rbx
 104f9d0:	f6 42 10 04          	testb  $0x4,0x10(%rdx)
 104f9d4:	74 30                	je     104fa06 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1486>
 104f9d6:	48 8b 42 18          	mov    0x18(%rdx),%rax
 104f9da:	8b 4a 14             	mov    0x14(%rdx),%ecx
 104f9dd:	4c 8d 24 08          	lea    (%rax,%rcx,1),%r12
 104f9e1:	49 83 c4 18          	add    $0x18,%r12
 104f9e5:	eb 23                	jmp    104fa0a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x148a>
 104f9e7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
 104f9ee:	00 00 
 104f9f0:	49 8b 46 18          	mov    0x18(%r14),%rax
 104f9f4:	41 8b 4e 14          	mov    0x14(%r14),%ecx
 104f9f8:	48 8d 1c 08          	lea    (%rax,%rcx,1),%rbx
 104f9fc:	48 83 c3 18          	add    $0x18,%rbx
 104fa00:	f6 42 10 04          	testb  $0x4,0x10(%rdx)
 104fa04:	75 d0                	jne    104f9d6 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1456>
 104fa06:	4c 8d 62 18          	lea    0x18(%rdx),%r12
 104fa0a:	48 89 94 24 b8 00 00 	mov    %rdx,0xb8(%rsp)
 104fa11:	00 
 104fa12:	48 8b 4a 08          	mov    0x8(%rdx),%rcx
 104fa16:	4d 8b 76 08          	mov    0x8(%r14),%r14
 104fa1a:	48 8d 41 ff          	lea    -0x1(%rcx),%rax
 104fa1e:	4c 39 f0             	cmp    %r14,%rax
 104fa21:	48 89 8c 24 00 01 00 	mov    %rcx,0x100(%rsp)
 104fa28:	00 
 104fa29:	4c 89 ac 24 98 01 00 	mov    %r13,0x198(%rsp)
 104fa30:	00 
 104fa31:	89 b4 24 0c 01 00 00 	mov    %esi,0x10c(%rsp)
 104fa38:	0f 83 f2 01 00 00    	jae    104fc30 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x16b0>
 104fa3e:	48 83 f9 01          	cmp    $0x1,%rcx
 104fa42:	0f 85 f8 01 00 00    	jne    104fc40 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x16c0>
 104fa48:	41 0f b6 04 24       	movzbl (%r12),%eax
 104fa4d:	c5 f9 6e c0          	vmovd  %eax,%xmm0
 104fa51:	c4 e2 79 78 c0       	vpbroadcastb %xmm0,%xmm0
 104fa56:	48 8d 4b 18          	lea    0x18(%rbx),%rcx
 104fa5a:	45 31 ed             	xor    %r13d,%r13d
 104fa5d:	31 d2                	xor    %edx,%edx
 104fa5f:	41 bb 00 00 01 00    	mov    $0x10000,%r11d
 104fa65:	eb 1b                	jmp    104fa82 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1502>
 104fa67:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
 104fa6e:	00 00 
 104fa70:	44 89 cf             	mov    %r9d,%edi
 104fa73:	49 01 fd             	add    %rdi,%r13
 104fa76:	48 01 f2             	add    %rsi,%rdx
 104fa79:	4c 39 f2             	cmp    %r14,%rdx
 104fa7c:	0f 83 11 02 00 00    	jae    104fc93 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1713>
 104fa82:	4c 89 f6             	mov    %r14,%rsi
 104fa85:	48 29 d6             	sub    %rdx,%rsi
 104fa88:	48 81 fe 00 00 01 00 	cmp    $0x10000,%rsi
 104fa8f:	49 0f 43 f3          	cmovae %r11,%rsi
 104fa93:	4d 89 f0             	mov    %r14,%r8
 104fa96:	49 29 d0             	sub    %rdx,%r8
 104fa99:	75 15                	jne    104fab0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1530>
 104fa9b:	31 ff                	xor    %edi,%edi
 104fa9d:	49 01 fd             	add    %rdi,%r13
 104faa0:	48 01 f2             	add    %rsi,%rdx
 104faa3:	4c 39 f2             	cmp    %r14,%rdx
 104faa6:	72 da                	jb     104fa82 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1502>
 104faa8:	e9 e6 01 00 00       	jmp    104fc93 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1713>
 104faad:	0f 1f 00             	nopl   (%rax)
 104fab0:	48 8d 3c 13          	lea    (%rbx,%rdx,1),%rdi
 104fab4:	49 83 f8 03          	cmp    $0x3,%r8
 104fab8:	77 16                	ja     104fad0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1550>
 104faba:	45 31 c0             	xor    %r8d,%r8d
 104fabd:	45 31 c9             	xor    %r9d,%r9d
 104fac0:	e9 4b 01 00 00       	jmp    104fc10 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1690>
 104fac5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
 104facc:	00 00 00 00 
 104fad0:	49 83 f8 20          	cmp    $0x20,%r8
 104fad4:	73 0b                	jae    104fae1 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1561>
 104fad6:	45 31 c0             	xor    %r8d,%r8d
 104fad9:	45 31 c9             	xor    %r9d,%r9d
 104fadc:	e9 d3 00 00 00       	jmp    104fbb4 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1634>
 104fae1:	41 89 f0             	mov    %esi,%r8d
 104fae4:	41 81 e0 e0 ff 01 00 	and    $0x1ffe0,%r8d
 104faeb:	4c 8d 0c 11          	lea    (%rcx,%rdx,1),%r9
 104faef:	c5 f1 ef c9          	vpxor  %xmm1,%xmm1,%xmm1
 104faf3:	45 31 d2             	xor    %r10d,%r10d
 104faf6:	c5 e9 ef d2          	vpxor  %xmm2,%xmm2,%xmm2
 104fafa:	c5 e1 ef db          	vpxor  %xmm3,%xmm3,%xmm3
 104fafe:	c5 d9 ef e4          	vpxor  %xmm4,%xmm4,%xmm4
 104fb02:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 104fb09:	1f 84 00 00 00 00 00 
 104fb10:	c4 81 7a 7e 6c 11 e8 	vmovq  -0x18(%r9,%r10,1),%xmm5
 104fb17:	c4 81 7a 7e 74 11 f0 	vmovq  -0x10(%r9,%r10,1),%xmm6
 104fb1e:	c4 81 7a 7e 7c 11 f8 	vmovq  -0x8(%r9,%r10,1),%xmm7
 104fb25:	c4 01 7a 7e 04 11    	vmovq  (%r9,%r10,1),%xmm8
 104fb2b:	c5 d1 74 e8          	vpcmpeqb %xmm0,%xmm5,%xmm5
 104fb2f:	c4 e2 7d 31 ed       	vpmovzxbd %xmm5,%ymm5
 104fb34:	c5 ad db ed          	vpand  %ymm5,%ymm10,%ymm5
 104fb38:	c5 f5 fe cd          	vpaddd %ymm5,%ymm1,%ymm1
 104fb3c:	c5 c9 74 e8          	vpcmpeqb %xmm0,%xmm6,%xmm5
 104fb40:	c4 e2 7d 31 ed       	vpmovzxbd %xmm5,%ymm5
 104fb45:	c5 ad db ed          	vpand  %ymm5,%ymm10,%ymm5
 104fb49:	c5 ed fe d5          	vpaddd %ymm5,%ymm2,%ymm2
 104fb4d:	c5 c1 74 e8          	vpcmpeqb %xmm0,%xmm7,%xmm5
 104fb51:	c4 e2 7d 31 ed       	vpmovzxbd %xmm5,%ymm5
 104fb56:	c5 ad db ed          	vpand  %ymm5,%ymm10,%ymm5
 104fb5a:	c5 e5 fe dd          	vpaddd %ymm5,%ymm3,%ymm3
 104fb5e:	c5 b9 74 e8          	vpcmpeqb %xmm0,%xmm8,%xmm5
 104fb62:	c4 e2 7d 31 ed       	vpmovzxbd %xmm5,%ymm5
 104fb67:	c5 ad db ed          	vpand  %ymm5,%ymm10,%ymm5
 104fb6b:	c5 dd fe e5          	vpaddd %ymm5,%ymm4,%ymm4
 104fb6f:	49 83 c2 20          	add    $0x20,%r10
 104fb73:	4d 39 d0             	cmp    %r10,%r8
 104fb76:	75 98                	jne    104fb10 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1590>
 104fb78:	c5 ed fe c9          	vpaddd %ymm1,%ymm2,%ymm1
 104fb7c:	c5 e5 fe c9          	vpaddd %ymm1,%ymm3,%ymm1
 104fb80:	c5 dd fe c9          	vpaddd %ymm1,%ymm4,%ymm1
 104fb84:	c4 e3 7d 39 ca 01    	vextracti128 $0x1,%ymm1,%xmm2
 104fb8a:	c5 f1 fe ca          	vpaddd %xmm2,%xmm1,%xmm1
 104fb8e:	c5 f9 70 d1 ee       	vpshufd $0xee,%xmm1,%xmm2
 104fb93:	c5 f1 fe ca          	vpaddd %xmm2,%xmm1,%xmm1
 104fb97:	c5 f9 70 d1 55       	vpshufd $0x55,%xmm1,%xmm2
 104fb9c:	c5 f1 fe ca          	vpaddd %xmm2,%xmm1,%xmm1
 104fba0:	c4 c1 79 7e c9       	vmovd  %xmm1,%r9d
 104fba5:	4c 39 c6             	cmp    %r8,%rsi
 104fba8:	0f 84 c2 fe ff ff    	je     104fa70 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x14f0>
 104fbae:	40 f6 c6 1c          	test   $0x1c,%sil
 104fbb2:	74 5c                	je     104fc10 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1690>
 104fbb4:	4d 89 c2             	mov    %r8,%r10
 104fbb7:	41 89 f0             	mov    %esi,%r8d
 104fbba:	41 81 e0 fc ff 01 00 	and    $0x1fffc,%r8d
 104fbc1:	c4 c1 79 6e c9       	vmovd  %r9d,%xmm1
 104fbc6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
 104fbcd:	00 00 00 
 104fbd0:	c4 a1 79 6e 14 17    	vmovd  (%rdi,%r10,1),%xmm2
 104fbd6:	c5 e9 74 d0          	vpcmpeqb %xmm0,%xmm2,%xmm2
 104fbda:	c4 e2 79 31 d2       	vpmovzxbd %xmm2,%xmm2
 104fbdf:	c5 b1 db d2          	vpand  %xmm2,%xmm9,%xmm2
 104fbe3:	c5 f1 fe ca          	vpaddd %xmm2,%xmm1,%xmm1
 104fbe7:	49 83 c2 04          	add    $0x4,%r10
 104fbeb:	4d 39 d0             	cmp    %r10,%r8
 104fbee:	75 e0                	jne    104fbd0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1650>
 104fbf0:	c5 f9 70 d1 ee       	vpshufd $0xee,%xmm1,%xmm2
 104fbf5:	c5 f1 fe ca          	vpaddd %xmm2,%xmm1,%xmm1
 104fbf9:	c5 f9 70 d1 55       	vpshufd $0x55,%xmm1,%xmm2
 104fbfe:	c5 f1 fe ca          	vpaddd %xmm2,%xmm1,%xmm1
 104fc02:	c4 c1 79 7e c9       	vmovd  %xmm1,%r9d
 104fc07:	eb 18                	jmp    104fc21 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x16a1>
 104fc09:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
 104fc10:	45 31 d2             	xor    %r10d,%r10d
 104fc13:	42 38 04 07          	cmp    %al,(%rdi,%r8,1)
 104fc17:	41 0f 94 c2          	sete   %r10b
 104fc1b:	45 01 d1             	add    %r10d,%r9d
 104fc1e:	49 ff c0             	inc    %r8
 104fc21:	4c 39 c6             	cmp    %r8,%rsi
 104fc24:	75 ea                	jne    104fc10 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1690>
 104fc26:	e9 45 fe ff ff       	jmp    104fa70 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x14f0>
 104fc2b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
 104fc30:	45 31 ed             	xor    %r13d,%r13d
 104fc33:	eb 5e                	jmp    104fc93 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1713>
 104fc35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
 104fc3c:	00 00 00 00 
 104fc40:	48 89 df             	mov    %rbx,%rdi
 104fc43:	4c 89 f6             	mov    %r14,%rsi
 104fc46:	4c 89 e2             	mov    %r12,%rdx
 104fc49:	c5 f8 77             	vzeroupper
 104fc4c:	e8 2f 20 04 00       	call   1091c80 <myl_native_octets_find>
 104fc51:	45 31 ed             	xor    %r13d,%r13d
 104fc54:	45 31 ff             	xor    %r15d,%r15d
 104fc57:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
 104fc5b:	74 2c                	je     104fc89 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1709>
 104fc5d:	0f 1f 00             	nopl   (%rax)
 104fc60:	48 8b 8c 24 00 01 00 	mov    0x100(%rsp),%rcx
 104fc67:	00 
 104fc68:	49 01 cf             	add    %rcx,%r15
 104fc6b:	49 01 c7             	add    %rax,%r15
 104fc6e:	49 ff c5             	inc    %r13
 104fc71:	4a 8d 3c 3b          	lea    (%rbx,%r15,1),%rdi
 104fc75:	4c 89 f6             	mov    %r14,%rsi
 104fc78:	4c 29 fe             	sub    %r15,%rsi
 104fc7b:	4c 89 e2             	mov    %r12,%rdx
 104fc7e:	e8 fd 1f 04 00       	call   1091c80 <myl_native_octets_find>
 104fc83:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
 104fc87:	75 d7                	jne    104fc60 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x16e0>
 104fc89:	49 bf 01 01 01 01 01 	movabs $0x101010101010101,%r15
 104fc90:	01 01 01 
 104fc93:	49 ff c5             	inc    %r13
 104fc96:	4c 8b 74 24 20       	mov    0x20(%rsp),%r14
 104fc9b:	49 8b 86 68 02 00 00 	mov    0x268(%r14),%rax
 104fca2:	48 89 84 24 a8 01 00 	mov    %rax,0x1a8(%rsp)
 104fca9:	00 
 104fcaa:	48 8d 84 24 c8 00 00 	lea    0xc8(%rsp),%rax
 104fcb1:	00 
 104fcb2:	48 89 84 24 b0 01 00 	mov    %rax,0x1b0(%rsp)
 104fcb9:	00 
 104fcba:	48 c7 84 24 b8 01 00 	movq   $0x1031628,0x1b8(%rsp)
 104fcc1:	00 28 16 03 01 
 104fcc6:	48 8d 84 24 a8 01 00 	lea    0x1a8(%rsp),%rax
 104fccd:	00 
 104fcce:	48 89 84 24 68 01 00 	mov    %rax,0x168(%rsp)
 104fcd5:	00 
 104fcd6:	48 8d 84 24 40 01 00 	lea    0x140(%rsp),%rax
 104fcdd:	00 
 104fcde:	48 89 84 24 70 01 00 	mov    %rax,0x170(%rsp)
 104fce5:	00 
 104fce6:	48 c7 84 24 78 01 00 	movq   $0x1031628,0x178(%rsp)
 104fced:	00 28 16 03 01 
 104fcf2:	48 8d 84 24 68 01 00 	lea    0x168(%rsp),%rax
 104fcf9:	00 
 104fcfa:	49 89 86 68 02 00 00 	mov    %rax,0x268(%r14)
 104fd01:	be 28 16 03 01       	mov    $0x1031628,%esi
 104fd06:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
 104fd0b:	4c 89 ea             	mov    %r13,%rdx
 104fd0e:	c5 f8 77             	vzeroupper
 104fd11:	e8 2a e0 03 00       	call   108dd40 <myl_native_list_new>
 104fd16:	48 89 c3             	mov    %rax,%rbx
 104fd19:	48 89 84 24 c0 00 00 	mov    %rax,0xc0(%rsp)
 104fd20:	00 
 104fd21:	49 8b 86 68 02 00 00 	mov    0x268(%r14),%rax
 104fd28:	48 89 84 24 48 01 00 	mov    %rax,0x148(%rsp)
 104fd2f:	00 
 104fd30:	48 8d 84 24 c0 00 00 	lea    0xc0(%rsp),%rax
 104fd37:	00 
 104fd38:	48 89 84 24 50 01 00 	mov    %rax,0x150(%rsp)
 104fd3f:	00 
 104fd40:	48 c7 84 24 58 01 00 	movq   $0x1031628,0x158(%rsp)
 104fd47:	00 28 16 03 01 
 104fd4c:	48 8d 84 24 48 01 00 	lea    0x148(%rsp),%rax
 104fd53:	00 
 104fd54:	49 89 86 68 02 00 00 	mov    %rax,0x268(%r14)
 104fd5b:	48 85 db             	test   %rbx,%rbx
 104fd5e:	0f 84 48 05 00 00    	je     10502ac <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1d2c>
 104fd64:	4c 8b a4 24 c8 00 00 	mov    0xc8(%rsp),%r12
 104fd6b:	00 
 104fd6c:	41 8b 4c 24 10       	mov    0x10(%r12),%ecx
 104fd71:	49 8d 44 24 18       	lea    0x18(%r12),%rax
 104fd76:	48 89 84 24 98 00 00 	mov    %rax,0x98(%rsp)
 104fd7d:	00 
 104fd7e:	89 8c 24 b4 00 00 00 	mov    %ecx,0xb4(%rsp)
 104fd85:	f6 c1 04             	test   $0x4,%cl
 104fd88:	c5 79 6f 05 a0 1c fb 	vmovdqa -0x4e360(%rip),%xmm8        # 1001a30 <__abi_tag+0x1734>
 104fd8f:	ff 
 104fd90:	c5 7e 6f 8c 24 f0 01 	vmovdqu 0x1f0(%rsp),%ymm9
 104fd97:	00 00 
 104fd99:	c5 79 6f 15 8f 1c fb 	vmovdqa -0x4e371(%rip),%xmm10        # 1001a30 <__abi_tag+0x1734>
 104fda0:	ff 
 104fda1:	74 19                	je     104fdbc <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x183c>
 104fda3:	49 8b 4c 24 18       	mov    0x18(%r12),%rcx
 104fda8:	41 8b 54 24 14       	mov    0x14(%r12),%edx
 104fdad:	48 01 d1             	add    %rdx,%rcx
 104fdb0:	48 83 c1 18          	add    $0x18,%rcx
 104fdb4:	48 89 8c 24 98 00 00 	mov    %rcx,0x98(%rsp)
 104fdbb:	00 
 104fdbc:	48 8b 8c 24 40 01 00 	mov    0x140(%rsp),%rcx
 104fdc3:	00 
 104fdc4:	f6 41 10 04          	testb  $0x4,0x10(%rcx)
 104fdc8:	75 26                	jne    104fdf0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1870>
 104fdca:	48 83 c1 18          	add    $0x18,%rcx
 104fdce:	48 89 8c 24 38 01 00 	mov    %rcx,0x138(%rsp)
 104fdd5:	00 
 104fdd6:	4c 89 e1             	mov    %r12,%rcx
 104fdd9:	f6 84 24 b4 00 00 00 	testb  $0x4,0xb4(%rsp)
 104fde0:	04 
 104fde1:	75 33                	jne    104fe16 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1896>
 104fde3:	eb 34                	jmp    104fe19 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1899>
 104fde5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
 104fdec:	00 00 00 00 
 104fdf0:	48 89 ca             	mov    %rcx,%rdx
 104fdf3:	48 8b 49 18          	mov    0x18(%rcx),%rcx
 104fdf7:	8b 52 14             	mov    0x14(%rdx),%edx
 104fdfa:	48 01 d1             	add    %rdx,%rcx
 104fdfd:	48 83 c1 18          	add    $0x18,%rcx
 104fe01:	48 89 8c 24 38 01 00 	mov    %rcx,0x138(%rsp)
 104fe08:	00 
 104fe09:	4c 89 e1             	mov    %r12,%rcx
 104fe0c:	f6 84 24 b4 00 00 00 	testb  $0x4,0xb4(%rsp)
 104fe13:	04 
 104fe14:	74 03                	je     104fe19 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1899>
 104fe16:	48 8b 08             	mov    (%rax),%rcx
 104fe19:	48 8b 49 08          	mov    0x8(%rcx),%rcx
 104fe1d:	48 c1 e9 02          	shr    $0x2,%rcx
 104fe21:	48 83 f9 0a          	cmp    $0xa,%rcx
 104fe25:	b8 09 00 00 00       	mov    $0x9,%eax
 104fe2a:	48 0f 42 c8          	cmovb  %rax,%rcx
 104fe2e:	48 89 8c 24 a0 01 00 	mov    %rcx,0x1a0(%rsp)
 104fe35:	00 
 104fe36:	48 8b 84 24 98 00 00 	mov    0x98(%rsp),%rax
 104fe3d:	00 
 104fe3e:	48 83 c0 0c          	add    $0xc,%rax
 104fe42:	48 89 84 24 90 01 00 	mov    %rax,0x190(%rsp)
 104fe49:	00 
 104fe4a:	31 ed                	xor    %ebp,%ebp
 104fe4c:	48 8b 8c 24 00 01 00 	mov    0x100(%rsp),%rcx
 104fe53:	00 
 104fe54:	49 83 fd 01          	cmp    $0x1,%r13
 104fe58:	0f 84 a2 00 00 00    	je     104ff00 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1980>
 104fe5e:	66 90                	xchg   %ax,%ax
 104fe60:	4d 85 ed             	test   %r13,%r13
 104fe63:	0f 84 45 04 00 00    	je     10502ae <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1d2e>
 104fe69:	48 8b 84 24 98 00 00 	mov    0x98(%rsp),%rax
 104fe70:	00 
 104fe71:	48 8d 3c 28          	lea    (%rax,%rbp,1),%rdi
 104fe75:	49 8b 5c 24 08       	mov    0x8(%r12),%rbx
 104fe7a:	48 89 de             	mov    %rbx,%rsi
 104fe7d:	48 29 ee             	sub    %rbp,%rsi
 104fe80:	48 8b 94 24 38 01 00 	mov    0x138(%rsp),%rdx
 104fe87:	00 
 104fe88:	c5 f8 77             	vzeroupper
 104fe8b:	e8 f0 1d 04 00       	call   1091c80 <myl_native_octets_find>
 104fe90:	c5 79 6f 15 98 1b fb 	vmovdqa -0x4e468(%rip),%xmm10        # 1001a30 <__abi_tag+0x1734>
 104fe97:	ff 
 104fe98:	c5 7e 6f 8c 24 f0 01 	vmovdqu 0x1f0(%rsp),%ymm9
 104fe9f:	00 00 
 104fea1:	c5 79 6f 05 87 1b fb 	vmovdqa -0x4e479(%rip),%xmm8        # 1001a30 <__abi_tag+0x1734>
 104fea8:	ff 
 104fea9:	4c 8d 34 28          	lea    (%rax,%rbp,1),%r14
 104fead:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
 104feb1:	4c 0f 44 f3          	cmove  %rbx,%r14
 104feb5:	4c 89 f3             	mov    %r14,%rbx
 104feb8:	48 29 eb             	sub    %rbp,%rbx
 104febb:	48 3b 9c 24 a0 01 00 	cmp    0x1a0(%rsp),%rbx
 104fec2:	00 
 104fec3:	72 50                	jb     104ff15 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1995>
 104fec5:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
 104feca:	4c 89 e6             	mov    %r12,%rsi
 104fecd:	48 89 ea             	mov    %rbp,%rdx
 104fed0:	48 89 d9             	mov    %rbx,%rcx
 104fed3:	49 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%r8
 104feda:	c5 f8 77             	vzeroupper
 104fedd:	e8 1e 07 04 00       	call   1090600 <long_piece>
 104fee2:	49 89 c7             	mov    %rax,%r15
 104fee5:	48 85 c0             	test   %rax,%rax
 104fee8:	0f 85 a2 02 00 00    	jne    1050190 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1c10>
 104feee:	e9 2d 03 00 00       	jmp    1050220 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1ca0>
 104fef3:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 104fefa:	84 00 00 00 00 00 
 104ff00:	4d 8b 74 24 08       	mov    0x8(%r12),%r14
 104ff05:	4c 89 f3             	mov    %r14,%rbx
 104ff08:	48 29 eb             	sub    %rbp,%rbx
 104ff0b:	48 3b 9c 24 a0 01 00 	cmp    0x1a0(%rsp),%rbx
 104ff12:	00 
 104ff13:	73 b0                	jae    104fec5 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1945>
 104ff15:	48 8b 84 24 98 00 00 	mov    0x98(%rsp),%rax
 104ff1c:	00 
 104ff1d:	4c 8d 24 28          	lea    (%rax,%rbp,1),%r12
 104ff21:	f6 84 24 b4 00 00 00 	testb  $0x1,0xb4(%rsp)
 104ff28:	01 
 104ff29:	0f 85 cb 01 00 00    	jne    10500fa <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1b7a>
 104ff2f:	48 83 fb 08          	cmp    $0x8,%rbx
 104ff33:	73 0b                	jae    104ff40 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x19c0>
 104ff35:	31 c9                	xor    %ecx,%ecx
 104ff37:	31 c0                	xor    %eax,%eax
 104ff39:	eb 4b                	jmp    104ff86 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1a06>
 104ff3b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
 104ff40:	31 d2                	xor    %edx,%edx
 104ff42:	31 c9                	xor    %ecx,%ecx
 104ff44:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
 104ff4b:	00 00 00 00 00 
 104ff50:	49 8b 04 14          	mov    (%r12,%rdx,1),%rax
 104ff54:	48 89 c6             	mov    %rax,%rsi
 104ff57:	48 f7 d6             	not    %rsi
 104ff5a:	48 01 f6             	add    %rsi,%rsi
 104ff5d:	48 21 c6             	and    %rax,%rsi
 104ff60:	48 c1 ee 07          	shr    $0x7,%rsi
 104ff64:	4c 21 fe             	and    %r15,%rsi
 104ff67:	49 0f af f7          	imul   %r15,%rsi
 104ff6b:	48 c1 ee 38          	shr    $0x38,%rsi
 104ff6f:	48 29 f1             	sub    %rsi,%rcx
 104ff72:	48 83 c1 08          	add    $0x8,%rcx
 104ff76:	48 8d 42 08          	lea    0x8(%rdx),%rax
 104ff7a:	48 83 c2 10          	add    $0x10,%rdx
 104ff7e:	48 39 da             	cmp    %rbx,%rdx
 104ff81:	48 89 c2             	mov    %rax,%rdx
 104ff84:	76 ca                	jbe    104ff50 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x19d0>
 104ff86:	48 39 d8             	cmp    %rbx,%rax
 104ff89:	0f 83 66 01 00 00    	jae    10500f5 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1b75>
 104ff8f:	48 8d 3c 28          	lea    (%rax,%rbp,1),%rdi
 104ff93:	4c 89 f2             	mov    %r14,%rdx
 104ff96:	48 29 fa             	sub    %rdi,%rdx
 104ff99:	48 83 fa 03          	cmp    $0x3,%rdx
 104ff9d:	4c 8b 84 24 98 00 00 	mov    0x98(%rsp),%r8
 104ffa4:	00 
 104ffa5:	0f 86 25 01 00 00    	jbe    10500d0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1b50>
 104ffab:	48 83 fa 10          	cmp    $0x10,%rdx
 104ffaf:	73 07                	jae    104ffb8 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1a38>
 104ffb1:	31 f6                	xor    %esi,%esi
 104ffb3:	e9 c6 00 00 00       	jmp    105007e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1afe>
 104ffb8:	48 89 d6             	mov    %rdx,%rsi
 104ffbb:	48 83 e6 f0          	and    $0xfffffffffffffff0,%rsi
 104ffbf:	c4 e1 f9 6e c1       	vmovq  %rcx,%xmm0
 104ffc4:	48 03 bc 24 90 01 00 	add    0x190(%rsp),%rdi
 104ffcb:	00 
 104ffcc:	c5 f1 ef c9          	vpxor  %xmm1,%xmm1,%xmm1
 104ffd0:	31 c9                	xor    %ecx,%ecx
 104ffd2:	c5 e9 ef d2          	vpxor  %xmm2,%xmm2,%xmm2
 104ffd6:	c5 e1 ef db          	vpxor  %xmm3,%xmm3,%xmm3
 104ffda:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
 104ffe0:	c5 f9 6e 64 0f f4    	vmovd  -0xc(%rdi,%rcx,1),%xmm4
 104ffe6:	c5 f9 6e 6c 0f f8    	vmovd  -0x8(%rdi,%rcx,1),%xmm5
 104ffec:	c5 f9 6e 74 0f fc    	vmovd  -0x4(%rdi,%rcx,1),%xmm6
 104fff2:	c5 f9 6e 3c 0f       	vmovd  (%rdi,%rcx,1),%xmm7
 104fff7:	c4 c1 59 64 e2       	vpcmpgtb %xmm10,%xmm4,%xmm4
 104fffc:	c4 e2 7d 32 e4       	vpmovzxbq %xmm4,%ymm4
 1050001:	c5 b5 db e4          	vpand  %ymm4,%ymm9,%ymm4
 1050005:	c5 fd d4 c4          	vpaddq %ymm4,%ymm0,%ymm0
 1050009:	c4 c1 51 64 e2       	vpcmpgtb %xmm10,%xmm5,%xmm4
 105000e:	c4 e2 7d 32 e4       	vpmovzxbq %xmm4,%ymm4
 1050013:	c5 b5 db e4          	vpand  %ymm4,%ymm9,%ymm4
 1050017:	c5 f5 d4 cc          	vpaddq %ymm4,%ymm1,%ymm1
 105001b:	c4 c1 49 64 e2       	vpcmpgtb %xmm10,%xmm6,%xmm4
 1050020:	c4 e2 7d 32 e4       	vpmovzxbq %xmm4,%ymm4
 1050025:	c5 b5 db e4          	vpand  %ymm4,%ymm9,%ymm4
 1050029:	c5 ed d4 d4          	vpaddq %ymm4,%ymm2,%ymm2
 105002d:	c4 c1 41 64 e2       	vpcmpgtb %xmm10,%xmm7,%xmm4
 1050032:	c4 e2 7d 32 e4       	vpmovzxbq %xmm4,%ymm4
 1050037:	c5 b5 db e4          	vpand  %ymm4,%ymm9,%ymm4
 105003b:	c5 e5 d4 dc          	vpaddq %ymm4,%ymm3,%ymm3
 105003f:	48 83 c1 10          	add    $0x10,%rcx
 1050043:	48 39 ce             	cmp    %rcx,%rsi
 1050046:	75 98                	jne    104ffe0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1a60>
 1050048:	c5 f5 d4 c0          	vpaddq %ymm0,%ymm1,%ymm0
 105004c:	c5 ed d4 c0          	vpaddq %ymm0,%ymm2,%ymm0
 1050050:	c5 e5 d4 c0          	vpaddq %ymm0,%ymm3,%ymm0
 1050054:	c4 e3 7d 39 c1 01    	vextracti128 $0x1,%ymm0,%xmm1
 105005a:	c5 f9 d4 c1          	vpaddq %xmm1,%xmm0,%xmm0
 105005e:	c5 f9 70 c8 ee       	vpshufd $0xee,%xmm0,%xmm1
 1050063:	c5 f9 d4 c1          	vpaddq %xmm1,%xmm0,%xmm0
 1050067:	c4 e1 f9 7e c1       	vmovq  %xmm0,%rcx
 105006c:	48 39 f2             	cmp    %rsi,%rdx
 105006f:	0f 84 80 00 00 00    	je     10500f5 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1b75>
 1050075:	f6 c2 0c             	test   $0xc,%dl
 1050078:	0f 84 8e 01 00 00    	je     105020c <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1c8c>
 105007e:	48 89 d7             	mov    %rdx,%rdi
 1050081:	48 83 e7 fc          	and    $0xfffffffffffffffc,%rdi
 1050085:	c4 e1 f9 6e c1       	vmovq  %rcx,%xmm0
 105008a:	49 8d 0c 04          	lea    (%r12,%rax,1),%rcx
 105008e:	66 90                	xchg   %ax,%ax
 1050090:	c5 f9 6e 0c 31       	vmovd  (%rcx,%rsi,1),%xmm1
 1050095:	c4 c1 71 64 c8       	vpcmpgtb %xmm8,%xmm1,%xmm1
 105009a:	c4 e2 7d 32 c9       	vpmovzxbq %xmm1,%ymm1
 105009f:	c5 b5 db c9          	vpand  %ymm1,%ymm9,%ymm1
 10500a3:	c5 fd d4 c1          	vpaddq %ymm1,%ymm0,%ymm0
 10500a7:	48 83 c6 04          	add    $0x4,%rsi
 10500ab:	48 39 f7             	cmp    %rsi,%rdi
 10500ae:	75 e0                	jne    1050090 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1b10>
 10500b0:	c4 e3 7d 39 c1 01    	vextracti128 $0x1,%ymm0,%xmm1
 10500b6:	c5 f9 d4 c1          	vpaddq %xmm1,%xmm0,%xmm0
 10500ba:	c5 f9 70 c8 ee       	vpshufd $0xee,%xmm0,%xmm1
 10500bf:	c5 f9 d4 c1          	vpaddq %xmm1,%xmm0,%xmm0
 10500c3:	c4 e1 f9 7e c1       	vmovq  %xmm0,%rcx
 10500c8:	48 39 fa             	cmp    %rdi,%rdx
 10500cb:	74 28                	je     10500f5 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1b75>
 10500cd:	48 01 f8             	add    %rdi,%rax
 10500d0:	48 01 e8             	add    %rbp,%rax
 10500d3:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 10500da:	84 00 00 00 00 00 
 10500e0:	31 d2                	xor    %edx,%edx
 10500e2:	41 80 3c 00 c0       	cmpb   $0xc0,(%r8,%rax,1)
 10500e7:	0f 9d c2             	setge  %dl
 10500ea:	48 01 d1             	add    %rdx,%rcx
 10500ed:	48 ff c0             	inc    %rax
 10500f0:	49 39 c6             	cmp    %rax,%r14
 10500f3:	75 eb                	jne    10500e0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1b60>
 10500f5:	48 39 d9             	cmp    %rbx,%rcx
 10500f8:	75 76                	jne    1050170 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1bf0>
 10500fa:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
 10500ff:	48 83 b8 60 18 00 00 	cmpq   $0x0,0x1860(%rax)
 1050106:	00 
 1050107:	0f 84 9f 01 00 00    	je     10502ac <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1d2c>
 105010d:	48 8d 73 18          	lea    0x18(%rbx),%rsi
 1050111:	8b 90 c8 02 00 00    	mov    0x2c8(%rax),%edx
 1050117:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
 105011c:	31 c9                	xor    %ecx,%ecx
 105011e:	c5 f8 77             	vzeroupper
 1050121:	e8 6a 55 05 00       	call   10a5690 <raw_bytes>
 1050126:	48 85 c0             	test   %rax,%rax
 1050129:	0f 84 f1 00 00 00    	je     1050220 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1ca0>
 105012f:	49 89 c7             	mov    %rax,%r15
 1050132:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
 1050139:	48 89 58 08          	mov    %rbx,0x8(%rax)
 105013d:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
 1050144:	00 
 1050145:	49 39 ee             	cmp    %rbp,%r14
 1050148:	74 12                	je     105015c <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1bdc>
 105014a:	4c 89 ff             	mov    %r15,%rdi
 105014d:	48 83 c7 18          	add    $0x18,%rdi
 1050151:	4c 89 e6             	mov    %r12,%rsi
 1050154:	48 89 da             	mov    %rbx,%rdx
 1050157:	e8 a4 af 05 00       	call   10ab100 <memcpy@plt>
 105015c:	49 89 1f             	mov    %rbx,(%r15)
 105015f:	41 c7 47 10 01 00 00 	movl   $0x1,0x10(%r15)
 1050166:	00 
 1050167:	eb 27                	jmp    1050190 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1c10>
 1050169:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
 1050170:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
 1050175:	4c 89 e6             	mov    %r12,%rsi
 1050178:	48 89 da             	mov    %rbx,%rdx
 105017b:	c5 f8 77             	vzeroupper
 105017e:	e8 dd f3 03 00       	call   108f560 <build_wide>
 1050183:	49 89 c7             	mov    %rax,%r15
 1050186:	48 85 c0             	test   %rax,%rax
 1050189:	0f 84 91 00 00 00    	je     1050220 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1ca0>
 105018f:	90                   	nop
 1050190:	48 8b 84 24 c0 00 00 	mov    0xc0(%rsp),%rax
 1050197:	00 
 1050198:	48 8b 08             	mov    (%rax),%rcx
 105019b:	48 8b 50 20          	mov    0x20(%rax),%rdx
 105019f:	48 8d 71 01          	lea    0x1(%rcx),%rsi
 10501a3:	48 89 30             	mov    %rsi,(%rax)
 10501a6:	4c 89 3c ca          	mov    %r15,(%rdx,%rcx,8)
 10501aa:	48 8b 9c 24 c0 00 00 	mov    0xc0(%rsp),%rbx
 10501b1:	00 
 10501b2:	48 ff 43 10          	incq   0x10(%rbx)
 10501b6:	4c 8b a4 24 c8 00 00 	mov    0xc8(%rsp),%r12
 10501bd:	00 
 10501be:	4d 3b 74 24 08       	cmp    0x8(%r12),%r14
 10501c3:	0f 84 e5 00 00 00    	je     10502ae <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1d2e>
 10501c9:	48 8b 8c 24 00 01 00 	mov    0x100(%rsp),%rcx
 10501d0:	00 
 10501d1:	49 01 ce             	add    %rcx,%r14
 10501d4:	49 ff cd             	dec    %r13
 10501d7:	4c 89 f5             	mov    %r14,%rbp
 10501da:	49 bf 01 01 01 01 01 	movabs $0x101010101010101,%r15
 10501e1:	01 01 01 
 10501e4:	c5 79 6f 05 44 18 fb 	vmovdqa -0x4e7bc(%rip),%xmm8        # 1001a30 <__abi_tag+0x1734>
 10501eb:	ff 
 10501ec:	c5 7e 6f 8c 24 f0 01 	vmovdqu 0x1f0(%rsp),%ymm9
 10501f3:	00 00 
 10501f5:	c5 79 6f 15 33 18 fb 	vmovdqa -0x4e7cd(%rip),%xmm10        # 1001a30 <__abi_tag+0x1734>
 10501fc:	ff 
 10501fd:	49 83 fd 01          	cmp    $0x1,%r13
 1050201:	0f 85 59 fc ff ff    	jne    104fe60 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x18e0>
 1050207:	e9 f4 fc ff ff       	jmp    104ff00 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1980>
 105020c:	48 01 f0             	add    %rsi,%rax
 105020f:	e9 bc fe ff ff       	jmp    10500d0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1b50>
 1050214:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
 105021b:	00 00 00 00 00 
 1050220:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
 1050225:	48 83 b8 60 18 00 00 	cmpq   $0x0,0x1860(%rax)
 105022c:	00 
 105022d:	49 bd 02 00 00 00 00 	movabs $0x4000000000000002,%r13
 1050234:	00 00 40 
 1050237:	74 73                	je     10502ac <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1d2c>
 1050239:	48 8b 9c 24 c0 00 00 	mov    0xc0(%rsp),%rbx
 1050240:	00 
 1050241:	48 8b 43 18          	mov    0x18(%rbx),%rax
 1050245:	66 83 78 30 01       	cmpw   $0x1,0x30(%rax)
 105024a:	0f 85 95 0f 00 00    	jne    10511e5 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2c65>
 1050250:	48 8b 03             	mov    (%rbx),%rax
 1050253:	48 85 c0             	test   %rax,%rax
 1050256:	74 47                	je     105029f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1d1f>
 1050258:	4c 8b b4 24 c8 00 00 	mov    0xc8(%rsp),%r14
 105025f:	00 
 1050260:	4c 8b 7b 20          	mov    0x20(%rbx),%r15
 1050264:	45 31 e4             	xor    %r12d,%r12d
 1050267:	eb 0f                	jmp    1050278 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1cf8>
 1050269:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
 1050270:	49 ff c4             	inc    %r12
 1050273:	49 39 c4             	cmp    %rax,%r12
 1050276:	73 27                	jae    105029f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1d1f>
 1050278:	4b 8b 34 e7          	mov    (%r15,%r12,8),%rsi
 105027c:	48 85 f6             	test   %rsi,%rsi
 105027f:	74 ef                	je     1050270 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1cf0>
 1050281:	4c 39 f6             	cmp    %r14,%rsi
 1050284:	74 ea                	je     1050270 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1cf0>
 1050286:	49 8d 4d fe          	lea    -0x2(%r13),%rcx
 105028a:	48 85 4e f0          	test   %rcx,-0x10(%rsi)
 105028e:	74 e0                	je     1050270 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1cf0>
 1050290:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
 1050295:	e8 76 d8 04 00       	call   109db10 <myl_rc_construction_abort>
 105029a:	48 8b 03             	mov    (%rbx),%rax
 105029d:	eb d1                	jmp    1050270 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1cf0>
 105029f:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
 10502a4:	48 89 de             	mov    %rbx,%rsi
 10502a7:	e8 64 d8 04 00       	call   109db10 <myl_rc_construction_abort>
 10502ac:	31 db                	xor    %ebx,%ebx
 10502ae:	48 8b 6c 24 20       	mov    0x20(%rsp),%rbp
 10502b3:	48 8b 85 68 02 00 00 	mov    0x268(%rbp),%rax
 10502ba:	48 8d 8c 24 48 01 00 	lea    0x148(%rsp),%rcx
 10502c1:	00 
 10502c2:	48 39 c8             	cmp    %rcx,%rax
 10502c5:	74 39                	je     1050300 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1d80>
 10502c7:	48 8d 8c 24 68 01 00 	lea    0x168(%rsp),%rcx
 10502ce:	00 
 10502cf:	48 39 c8             	cmp    %rcx,%rax
 10502d2:	4c 8b a4 24 b8 00 00 	mov    0xb8(%rsp),%r12
 10502d9:	00 
 10502da:	74 48                	je     1050324 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1da4>
 10502dc:	48 8d 8c 24 a8 01 00 	lea    0x1a8(%rsp),%rcx
 10502e3:	00 
 10502e4:	48 39 c8             	cmp    %rcx,%rax
 10502e7:	74 57                	je     1050340 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1dc0>
 10502e9:	48 85 db             	test   %rbx,%rbx
 10502ec:	49 bd 02 00 00 00 00 	movabs $0x4000000000000002,%r13
 10502f3:	00 00 40 
 10502f6:	75 6a                	jne    1050362 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1de2>
 10502f8:	e9 e2 0f 00 00       	jmp    10512df <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2d5f>
 10502fd:	0f 1f 00             	nopl   (%rax)
 1050300:	48 8b 84 24 48 01 00 	mov    0x148(%rsp),%rax
 1050307:	00 
 1050308:	48 89 85 68 02 00 00 	mov    %rax,0x268(%rbp)
 105030f:	48 8d 8c 24 68 01 00 	lea    0x168(%rsp),%rcx
 1050316:	00 
 1050317:	48 39 c8             	cmp    %rcx,%rax
 105031a:	4c 8b a4 24 b8 00 00 	mov    0xb8(%rsp),%r12
 1050321:	00 
 1050322:	75 b8                	jne    10502dc <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1d5c>
 1050324:	48 8b 84 24 68 01 00 	mov    0x168(%rsp),%rax
 105032b:	00 
 105032c:	48 89 85 68 02 00 00 	mov    %rax,0x268(%rbp)
 1050333:	48 8d 8c 24 a8 01 00 	lea    0x1a8(%rsp),%rcx
 105033a:	00 
 105033b:	48 39 c8             	cmp    %rcx,%rax
 105033e:	75 a9                	jne    10502e9 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1d69>
 1050340:	48 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%rax
 1050347:	00 
 1050348:	48 89 85 68 02 00 00 	mov    %rax,0x268(%rbp)
 105034f:	48 85 db             	test   %rbx,%rbx
 1050352:	49 bd 02 00 00 00 00 	movabs $0x4000000000000002,%r13
 1050359:	00 00 40 
 105035c:	0f 84 7d 0f 00 00    	je     10512df <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2d5f>
 1050362:	48 89 5c 24 60       	mov    %rbx,0x60(%rsp)
 1050367:	48 89 5c 24 68       	mov    %rbx,0x68(%rsp)
 105036c:	48 8b 43 f0          	mov    -0x10(%rbx),%rax
 1050370:	48 85 84 24 f8 00 00 	test   %rax,0xf8(%rsp)
 1050377:	00 
 1050378:	74 1f                	je     1050399 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1e19>
 105037a:	48 b9 00 00 00 00 00 	movabs $0x5000000000000000,%rcx
 1050381:	00 00 50 
 1050384:	48 85 c8             	test   %rcx,%rax
 1050387:	75 27                	jne    10503b0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1e30>
 1050389:	48 83 bc 24 88 01 00 	cmpq   $0x0,0x188(%rsp)
 1050390:	00 00 
 1050392:	74 1c                	je     10503b0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1e30>
 1050394:	48 89 5c 24 60       	mov    %rbx,0x60(%rsp)
 1050399:	48 c7 44 24 68 00 00 	movq   $0x0,0x68(%rsp)
 10503a0:	00 00 
 10503a2:	4c 8b 3b             	mov    (%rbx),%r15
 10503a5:	4d 85 ff             	test   %r15,%r15
 10503a8:	79 43                	jns    10503ed <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1e6d>
 10503aa:	e9 4b 0f 00 00       	jmp    10512fa <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2d7a>
 10503af:	90                   	nop
 10503b0:	be 48 ba 00 01       	mov    $0x100ba48,%esi
 10503b5:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
 10503ba:	48 8d 54 24 60       	lea    0x60(%rsp),%rdx
 10503bf:	48 8d 4c 24 68       	lea    0x68(%rsp),%rcx
 10503c4:	44 8b 84 24 0c 01 00 	mov    0x10c(%rsp),%r8d
 10503cb:	00 
 10503cc:	c5 f8 77             	vzeroupper
 10503cf:	e8 1c 5b 05 00       	call   10a5ef0 <myl_rc_native_take>
 10503d4:	85 c0                	test   %eax,%eax
 10503d6:	0f 84 3c 02 00 00    	je     1050618 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2098>
 10503dc:	48 8b 5c 24 60       	mov    0x60(%rsp),%rbx
 10503e1:	4c 8b 3b             	mov    (%rbx),%r15
 10503e4:	4d 85 ff             	test   %r15,%r15
 10503e7:	0f 88 0d 0f 00 00    	js     10512fa <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2d7a>
 10503ed:	4d 6b e7 07          	imul   $0x7,%r15,%r12
 10503f1:	c5 79 6f 4c 24 50    	vmovdqa 0x50(%rsp),%xmm9
 10503f7:	c5 7e 6f 94 24 10 01 	vmovdqu 0x110(%rsp),%ymm10
 10503fe:	00 00 
 1050400:	0f 80 02 0f 00 00    	jo     1051308 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2d88>
 1050406:	48 85 db             	test   %rbx,%rbx
 1050409:	74 0a                	je     1050415 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1e95>
 105040b:	4c 85 6b f0          	test   %r13,-0x10(%rbx)
 105040f:	0f 84 0b 01 00 00    	je     1050520 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1fa0>
 1050415:	48 89 5c 24 60       	mov    %rbx,0x60(%rsp)
 105041a:	4d 85 ff             	test   %r15,%r15
 105041d:	0f 84 1c 01 00 00    	je     105053f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1fbf>
 1050423:	31 ed                	xor    %ebp,%ebp
 1050425:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
 105042c:	00 00 00 00 
 1050430:	48 8b 43 20          	mov    0x20(%rbx),%rax
 1050434:	4c 8b 2c e8          	mov    (%rax,%rbp,8),%r13
 1050438:	4c 89 6c 24 68       	mov    %r13,0x68(%rsp)
 105043d:	4d 85 ed             	test   %r13,%r13
 1050440:	74 21                	je     1050463 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1ee3>
 1050442:	48 b8 02 00 00 00 00 	movabs $0x4000000000000002,%rax
 1050449:	00 00 40 
 105044c:	49 85 45 f0          	test   %rax,-0x10(%r13)
 1050450:	75 11                	jne    1050463 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1ee3>
 1050452:	49 8b 45 e8          	mov    -0x18(%r13),%rax
 1050456:	48 ff c0             	inc    %rax
 1050459:	0f 84 c2 02 00 00    	je     1050721 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x21a1>
 105045f:	49 89 45 e8          	mov    %rax,-0x18(%r13)
 1050463:	4c 89 6c 24 60       	mov    %r13,0x60(%rsp)
 1050468:	48 c7 44 24 68 00 00 	movq   $0x0,0x68(%rsp)
 105046f:	00 00 
 1050471:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
 1050476:	4c 89 ee             	mov    %r13,%rsi
 1050479:	c5 f8 77             	vzeroupper
 105047c:	e8 4f 3b 02 00       	call   1073fd0 <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85>
 1050481:	4d 89 e6             	mov    %r12,%r14
 1050484:	49 01 c6             	add    %rax,%r14
 1050487:	0f 80 75 0d 00 00    	jo     1051202 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2c82>
 105048d:	4d 85 ed             	test   %r13,%r13
 1050490:	c5 79 6f 4c 24 50    	vmovdqa 0x50(%rsp),%xmm9
 1050496:	c5 7e 6f 94 24 10 01 	vmovdqu 0x110(%rsp),%ymm10
 105049d:	00 00 
 105049f:	74 24                	je     10504c5 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1f45>
 10504a1:	48 b8 02 00 00 00 00 	movabs $0x4000000000000002,%rax
 10504a8:	00 00 40 
 10504ab:	49 85 45 f0          	test   %rax,-0x10(%r13)
 10504af:	75 14                	jne    10504c5 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1f45>
 10504b1:	49 8b 45 e8          	mov    -0x18(%r13),%rax
 10504b5:	48 ff c8             	dec    %rax
 10504b8:	75 07                	jne    10504c1 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1f41>
 10504ba:	49 83 7d e0 00       	cmpq   $0x0,-0x20(%r13)
 10504bf:	74 1e                	je     10504df <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1f5f>
 10504c1:	49 89 45 e8          	mov    %rax,-0x18(%r13)
 10504c5:	4c 39 3b             	cmp    %r15,(%rbx)
 10504c8:	0f 85 46 0d 00 00    	jne    1051214 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2c94>
 10504ce:	48 ff c5             	inc    %rbp
 10504d1:	4d 89 f4             	mov    %r14,%r12
 10504d4:	49 39 ef             	cmp    %rbp,%r15
 10504d7:	0f 85 53 ff ff ff    	jne    1050430 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1eb0>
 10504dd:	eb 63                	jmp    1050542 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1fc2>
 10504df:	4c 8b 64 24 18       	mov    0x18(%rsp),%r12
 10504e4:	4c 89 e7             	mov    %r12,%rdi
 10504e7:	4c 89 ee             	mov    %r13,%rsi
 10504ea:	c5 f8 77             	vzeroupper
 10504ed:	e8 be 95 04 00       	call   1099ab0 <myl_rc_hold_edge_release>
 10504f2:	4c 89 e7             	mov    %r12,%rdi
 10504f5:	e8 d6 c5 04 00       	call   109cad0 <myl_rc_drain>
 10504fa:	c5 7e 6f 94 24 10 01 	vmovdqu 0x110(%rsp),%ymm10
 1050501:	00 00 
 1050503:	c5 79 6f 4c 24 50    	vmovdqa 0x50(%rsp),%xmm9
 1050509:	4c 39 3b             	cmp    %r15,(%rbx)
 105050c:	74 c0                	je     10504ce <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1f4e>
 105050e:	e9 01 0d 00 00       	jmp    1051214 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2c94>
 1050513:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 105051a:	84 00 00 00 00 00 
 1050520:	48 8b 43 e8          	mov    -0x18(%rbx),%rax
 1050524:	48 ff c0             	inc    %rax
 1050527:	0f 84 d0 01 00 00    	je     10506fd <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x217d>
 105052d:	48 89 43 e8          	mov    %rax,-0x18(%rbx)
 1050531:	48 89 5c 24 60       	mov    %rbx,0x60(%rsp)
 1050536:	4d 85 ff             	test   %r15,%r15
 1050539:	0f 85 e4 fe ff ff    	jne    1050423 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1ea3>
 105053f:	4d 89 e6             	mov    %r12,%r14
 1050542:	8b 84 24 30 02 00 00 	mov    0x230(%rsp),%eax
 1050549:	0b 84 24 50 02 00 00 	or     0x250(%rsp),%eax
 1050550:	48 8b 6c 24 20       	mov    0x20(%rsp),%rbp
 1050555:	49 bd 02 00 00 00 00 	movabs $0x4000000000000002,%r13
 105055c:	00 00 40 
 105055f:	49 bf 01 01 01 01 01 	movabs $0x101010101010101,%r15
 1050566:	01 01 01 
 1050569:	4c 8b a4 24 b8 00 00 	mov    0xb8(%rsp),%r12
 1050570:	00 
 1050571:	74 3b                	je     10505ae <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x202e>
 1050573:	48 8b 85 60 18 00 00 	mov    0x1860(%rbp),%rax
 105057a:	48 85 c0             	test   %rax,%rax
 105057d:	74 11                	je     1050590 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2010>
 105057f:	48 8b b0 f8 00 00 00 	mov    0xf8(%rax),%rsi
 1050586:	eb 0a                	jmp    1050592 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2012>
 1050588:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
 105058f:	00 
 1050590:	31 f6                	xor    %esi,%esi
 1050592:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
 1050597:	c5 f8 77             	vzeroupper
 105059a:	e8 61 fb 04 00       	call   10a0100 <myl_rc_scope_unwind>
 105059f:	c5 79 6f 4c 24 50    	vmovdqa 0x50(%rsp),%xmm9
 10505a5:	c5 7e 6f 94 24 10 01 	vmovdqu 0x110(%rsp),%ymm10
 10505ac:	00 00 
 10505ae:	48 85 db             	test   %rbx,%rbx
 10505b1:	0f 84 b9 01 00 00    	je     1050770 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x21f0>
 10505b7:	4c 85 6b f0          	test   %r13,-0x10(%rbx)
 10505bb:	74 13                	je     10505d0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2050>
 10505bd:	4c 85 6b f0          	test   %r13,-0x10(%rbx)
 10505c1:	0f 85 a9 01 00 00    	jne    1050770 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x21f0>
 10505c7:	eb 29                	jmp    10505f2 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2072>
 10505c9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
 10505d0:	48 8b 43 e8          	mov    -0x18(%rbx),%rax
 10505d4:	48 ff c8             	dec    %rax
 10505d7:	75 0b                	jne    10505e4 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2064>
 10505d9:	48 83 7b e0 00       	cmpq   $0x0,-0x20(%rbx)
 10505de:	0f 84 98 00 00 00    	je     105067c <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x20fc>
 10505e4:	48 89 43 e8          	mov    %rax,-0x18(%rbx)
 10505e8:	4c 85 6b f0          	test   %r13,-0x10(%rbx)
 10505ec:	0f 85 7e 01 00 00    	jne    1050770 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x21f0>
 10505f2:	48 8b 43 e0          	mov    -0x20(%rbx),%rax
 10505f6:	48 ff c8             	dec    %rax
 10505f9:	75 0b                	jne    1050606 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2086>
 10505fb:	48 83 7b e8 00       	cmpq   $0x0,-0x18(%rbx)
 1050600:	0f 84 b9 00 00 00    	je     10506bf <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x213f>
 1050606:	48 89 43 e0          	mov    %rax,-0x20(%rbx)
 105060a:	4d 85 e4             	test   %r12,%r12
 105060d:	0f 85 62 01 00 00    	jne    1050775 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x21f5>
 1050613:	e9 7b 01 00 00       	jmp    1050793 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2213>
 1050618:	48 8b 85 60 18 00 00 	mov    0x1860(%rbp),%rax
 105061f:	48 85 c0             	test   %rax,%rax
 1050622:	c5 79 6f 4c 24 50    	vmovdqa 0x50(%rsp),%xmm9
 1050628:	c5 7e 6f 94 24 10 01 	vmovdqu 0x110(%rsp),%ymm10
 105062f:	00 00 
 1050631:	0f 84 b6 0b 00 00    	je     10511ed <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2c6d>
 1050637:	44 8b b0 24 01 00 00 	mov    0x124(%rax),%r14d
 105063e:	c7 80 24 01 00 00 00 	movl   $0x0,0x124(%rax)
 1050645:	00 00 00 
 1050648:	4d 85 f6             	test   %r14,%r14
 105064b:	49 bf 01 01 01 01 01 	movabs $0x101010101010101,%r15
 1050652:	01 01 01 
 1050655:	0f 84 15 01 00 00    	je     1050770 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x21f0>
 105065b:	41 83 fe 01          	cmp    $0x1,%r14d
 105065f:	0f 85 d9 01 00 00    	jne    105083e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x22be>
 1050665:	be f2 7d 00 01       	mov    $0x1007df2,%esi
 105066a:	83 bd c4 02 00 00 00 	cmpl   $0x0,0x2c4(%rbp)
 1050671:	0f 84 d1 01 00 00    	je     1050848 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x22c8>
 1050677:	e9 d4 01 00 00       	jmp    1050850 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x22d0>
 105067c:	4c 8b 7c 24 18       	mov    0x18(%rsp),%r15
 1050681:	4c 89 ff             	mov    %r15,%rdi
 1050684:	48 89 de             	mov    %rbx,%rsi
 1050687:	c5 f8 77             	vzeroupper
 105068a:	e8 21 94 04 00       	call   1099ab0 <myl_rc_hold_edge_release>
 105068f:	4c 89 ff             	mov    %r15,%rdi
 1050692:	49 bf 01 01 01 01 01 	movabs $0x101010101010101,%r15
 1050699:	01 01 01 
 105069c:	e8 2f c4 04 00       	call   109cad0 <myl_rc_drain>
 10506a1:	c5 7e 6f 94 24 10 01 	vmovdqu 0x110(%rsp),%ymm10
 10506a8:	00 00 
 10506aa:	c5 79 6f 4c 24 50    	vmovdqa 0x50(%rsp),%xmm9
 10506b0:	4c 85 6b f0          	test   %r13,-0x10(%rbx)
 10506b4:	0f 85 b6 00 00 00    	jne    1050770 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x21f0>
 10506ba:	e9 33 ff ff ff       	jmp    10505f2 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2072>
 10506bf:	4c 8b 7c 24 18       	mov    0x18(%rsp),%r15
 10506c4:	4c 89 ff             	mov    %r15,%rdi
 10506c7:	48 89 de             	mov    %rbx,%rsi
 10506ca:	c5 f8 77             	vzeroupper
 10506cd:	e8 7e 92 04 00       	call   1099950 <myl_rc_edge_release>
 10506d2:	4c 89 ff             	mov    %r15,%rdi
 10506d5:	49 bf 01 01 01 01 01 	movabs $0x101010101010101,%r15
 10506dc:	01 01 01 
 10506df:	e8 ec c3 04 00       	call   109cad0 <myl_rc_drain>
 10506e4:	c5 7e 6f 94 24 10 01 	vmovdqu 0x110(%rsp),%ymm10
 10506eb:	00 00 
 10506ed:	c5 79 6f 4c 24 50    	vmovdqa 0x50(%rsp),%xmm9
 10506f3:	4d 85 e4             	test   %r12,%r12
 10506f6:	75 7d                	jne    1050775 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x21f5>
 10506f8:	e9 96 00 00 00       	jmp    1050793 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2213>
 10506fd:	be bf 7d 00 01       	mov    $0x1007dbf,%esi
 1050702:	48 89 ef             	mov    %rbp,%rdi
 1050705:	c5 f8 77             	vzeroupper
 1050708:	e8 b1 9e 03 00       	call   108a5be <fail>
 105070d:	c5 7e 6f 94 24 10 01 	vmovdqu 0x110(%rsp),%ymm10
 1050714:	00 00 
 1050716:	c5 79 6f 4c 24 50    	vmovdqa 0x50(%rsp),%xmm9
 105071c:	45 31 f6             	xor    %r14d,%r14d
 105071f:	eb 31                	jmp    1050752 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x21d2>
 1050721:	be bf 7d 00 01       	mov    $0x1007dbf,%esi
 1050726:	48 8b 6c 24 20       	mov    0x20(%rsp),%rbp
 105072b:	48 89 ef             	mov    %rbp,%rdi
 105072e:	c5 f8 77             	vzeroupper
 1050731:	e8 88 9e 03 00       	call   108a5be <fail>
 1050736:	c5 7e 6f 94 24 10 01 	vmovdqu 0x110(%rsp),%ymm10
 105073d:	00 00 
 105073f:	c5 79 6f 4c 24 50    	vmovdqa 0x50(%rsp),%xmm9
 1050745:	45 31 f6             	xor    %r14d,%r14d
 1050748:	49 bd 02 00 00 00 00 	movabs $0x4000000000000002,%r13
 105074f:	00 00 40 
 1050752:	49 bf 01 01 01 01 01 	movabs $0x101010101010101,%r15
 1050759:	01 01 01 
 105075c:	4c 8b a4 24 b8 00 00 	mov    0xb8(%rsp),%r12
 1050763:	00 
 1050764:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
 105076b:	00 00 00 00 00 
 1050770:	4d 85 e4             	test   %r12,%r12
 1050773:	74 1e                	je     1050793 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2213>
 1050775:	4d 85 6c 24 f0       	test   %r13,-0x10(%r12)
 105077a:	75 17                	jne    1050793 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2213>
 105077c:	49 8b 44 24 e0       	mov    -0x20(%r12),%rax
 1050781:	48 ff c8             	dec    %rax
 1050784:	75 08                	jne    105078e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x220e>
 1050786:	49 83 7c 24 e8 00    	cmpq   $0x0,-0x18(%r12)
 105078c:	74 70                	je     10507fe <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x227e>
 105078e:	49 89 44 24 e0       	mov    %rax,-0x20(%r12)
 1050793:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
 1050798:	48 89 d1             	mov    %rdx,%rcx
 105079b:	4c 01 f1             	add    %r14,%rcx
 105079e:	0f 80 46 0b 00 00    	jo     10512ea <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2d6a>
 10507a4:	48 89 c8             	mov    %rcx,%rax
 10507a7:	48 ba e5 8f a2 12 31 	movabs $0x89705f3112a28fe5,%rdx
 10507ae:	5f 70 89 
 10507b1:	48 f7 ea             	imul   %rdx
 10507b4:	48 01 ca             	add    %rcx,%rdx
 10507b7:	48 89 d0             	mov    %rdx,%rax
 10507ba:	48 c1 e8 3f          	shr    $0x3f,%rax
 10507be:	48 c1 fa 1d          	sar    $0x1d,%rdx
 10507c2:	48 01 c2             	add    %rax,%rdx
 10507c5:	48 69 c2 07 ca 9a 3b 	imul   $0x3b9aca07,%rdx,%rax
 10507cc:	48 29 c1             	sub    %rax,%rcx
 10507cf:	48 89 c8             	mov    %rcx,%rax
 10507d2:	48 c1 f8 3f          	sar    $0x3f,%rax
 10507d6:	25 07 ca 9a 3b       	and    $0x3b9aca07,%eax
 10507db:	48 01 c8             	add    %rcx,%rax
 10507de:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
 10507e3:	4c 8b ac 24 98 01 00 	mov    0x198(%rsp),%r13
 10507ea:	00 
 10507eb:	49 ff c5             	inc    %r13
 10507ee:	4c 3b 6c 24 28       	cmp    0x28(%rsp),%r13
 10507f3:	0f 85 17 f0 ff ff    	jne    104f810 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1290>
 10507f9:	e9 d4 e5 ff ff       	jmp    104edd2 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x852>
 10507fe:	48 8b 5c 24 18       	mov    0x18(%rsp),%rbx
 1050803:	48 89 df             	mov    %rbx,%rdi
 1050806:	4c 89 e6             	mov    %r12,%rsi
 1050809:	c5 f8 77             	vzeroupper
 105080c:	e8 3f 91 04 00       	call   1099950 <myl_rc_edge_release>
 1050811:	48 89 df             	mov    %rbx,%rdi
 1050814:	e8 b7 c2 04 00       	call   109cad0 <myl_rc_drain>
 1050819:	c5 7e 6f 94 24 10 01 	vmovdqu 0x110(%rsp),%ymm10
 1050820:	00 00 
 1050822:	c5 79 6f 4c 24 50    	vmovdqa 0x50(%rsp),%xmm9
 1050828:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
 105082d:	48 89 d1             	mov    %rdx,%rcx
 1050830:	4c 01 f1             	add    %r14,%rcx
 1050833:	0f 81 6b ff ff ff    	jno    10507a4 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2224>
 1050839:	e9 ac 0a 00 00       	jmp    10512ea <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2d6a>
 105083e:	41 83 fe 04          	cmp    $0x4,%r14d
 1050842:	0f 83 9d 09 00 00    	jae    10511e5 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2c65>
 1050848:	4a 8b 34 f5 e0 15 03 	mov    0x10315e0(,%r14,8),%rsi
 105084f:	01 
 1050850:	48 89 ef             	mov    %rbp,%rdi
 1050853:	c5 f8 77             	vzeroupper
 1050856:	e8 63 9d 03 00       	call   108a5be <fail>
 105085b:	45 31 f6             	xor    %r14d,%r14d
 105085e:	c5 79 6f 4c 24 50    	vmovdqa 0x50(%rsp),%xmm9
 1050864:	c5 7e 6f 94 24 10 01 	vmovdqu 0x110(%rsp),%ymm10
 105086b:	00 00 
 105086d:	4d 85 e4             	test   %r12,%r12
 1050870:	0f 85 ff fe ff ff    	jne    1050775 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x21f5>
 1050876:	e9 18 ff ff ff       	jmp    1050793 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2213>
 105087b:	48 8b 85 60 18 00 00 	mov    0x1860(%rbp),%rax
 1050882:	48 85 c0             	test   %rax,%rax
 1050885:	0f 84 62 09 00 00    	je     10511ed <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2c6d>
 105088b:	8b b0 24 01 00 00    	mov    0x124(%rax),%esi
 1050891:	c7 80 24 01 00 00 00 	movl   $0x0,0x124(%rax)
 1050898:	00 00 00 
 105089b:	48 89 ef             	mov    %rbp,%rdi
 105089e:	c5 f8 77             	vzeroupper
 10508a1:	e8 ba 94 03 00       	call   1089d60 <myl_qbe_rc_status>
 10508a6:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
 10508ad:	00 00 
 10508af:	e9 1e e5 ff ff       	jmp    104edd2 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x852>
 10508b4:	48 8b 85 60 18 00 00 	mov    0x1860(%rbp),%rax
 10508bb:	48 85 c0             	test   %rax,%rax
 10508be:	0f 84 29 09 00 00    	je     10511ed <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2c6d>
 10508c4:	8b b0 24 01 00 00    	mov    0x124(%rax),%esi
 10508ca:	c7 80 24 01 00 00 00 	movl   $0x0,0x124(%rax)
 10508d1:	00 00 00 
 10508d4:	48 89 ef             	mov    %rbp,%rdi
 10508d7:	c5 f8 77             	vzeroupper
 10508da:	e8 81 94 03 00       	call   1089d60 <myl_qbe_rc_status>
 10508df:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
 10508e6:	00 00 
 10508e8:	e9 e5 e4 ff ff       	jmp    104edd2 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x852>
 10508ed:	48 8d b4 24 d0 00 00 	lea    0xd0(%rsp),%rsi
 10508f4:	00 
 10508f5:	48 8d bd 58 02 00 00 	lea    0x258(%rbp),%rdi
 10508fc:	e8 6f 57 03 00       	call   1086070 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop>
 1050901:	84 db                	test   %bl,%bl
 1050903:	0f 85 17 ea ff ff    	jne    104f320 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xda0>
 1050909:	e9 60 ee ff ff       	jmp    104f76e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x11ee>
 105090e:	48 8b 85 60 18 00 00 	mov    0x1860(%rbp),%rax
 1050915:	48 85 c0             	test   %rax,%rax
 1050918:	0f 84 cf 08 00 00    	je     10511ed <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2c6d>
 105091e:	8b b0 24 01 00 00    	mov    0x124(%rax),%esi
 1050924:	c7 80 24 01 00 00 00 	movl   $0x0,0x124(%rax)
 105092b:	00 00 00 
 105092e:	48 89 ef             	mov    %rbp,%rdi
 1050931:	e8 2a 94 03 00       	call   1089d60 <myl_qbe_rc_status>
 1050936:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
 105093d:	00 00 
 105093f:	e9 8e e4 ff ff       	jmp    104edd2 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x852>
 1050944:	48 8b 85 60 18 00 00 	mov    0x1860(%rbp),%rax
 105094b:	48 85 c0             	test   %rax,%rax
 105094e:	0f 84 99 08 00 00    	je     10511ed <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2c6d>
 1050954:	8b b0 24 01 00 00    	mov    0x124(%rax),%esi
 105095a:	c7 80 24 01 00 00 00 	movl   $0x0,0x124(%rax)
 1050961:	00 00 00 
 1050964:	48 89 ef             	mov    %rbp,%rdi
 1050967:	e8 f4 93 03 00       	call   1089d60 <myl_qbe_rc_status>
 105096c:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
 1050973:	00 00 
 1050975:	e9 58 e4 ff ff       	jmp    104edd2 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x852>
 105097a:	48 8d b4 24 d0 00 00 	lea    0xd0(%rsp),%rsi
 1050981:	00 
 1050982:	48 8d bd 58 02 00 00 	lea    0x258(%rbp),%rdi
 1050989:	89 c3                	mov    %eax,%ebx
 105098b:	e8 e0 56 03 00       	call   1086070 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop>
 1050990:	89 d8                	mov    %ebx,%eax
 1050992:	85 c0                	test   %eax,%eax
 1050994:	0f 85 da e9 ff ff    	jne    104f374 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xdf4>
 105099a:	48 c7 44 24 38 f0 87 	movq   $0x10b87f0,0x38(%rsp)
 10509a1:	0b 01 
 10509a3:	48 c7 44 24 70 f0 87 	movq   $0x10b87f0,0x70(%rsp)
 10509aa:	0b 01 
 10509ac:	48 c7 84 24 d0 00 00 	movq   $0x10b87f0,0xd0(%rsp)
 10509b3:	00 f0 87 0b 01 
 10509b8:	be f0 87 0b 01       	mov    $0x10b87f0,%esi
 10509bd:	4c 89 f7             	mov    %r14,%rdi
 10509c0:	e8 3b 12 04 00       	call   1091c00 <myl_native_text_equal>
 10509c5:	4c 85 2d 14 7e 06 00 	test   %r13,0x67e14(%rip)        # 10b87e0 <myl_lit_3b82d7fd89ea641dc3c74175c3081dd70840c2be20de843e08a42204e3d9c4cc_instance>
 10509cc:	75 21                	jne    10509ef <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x246f>
 10509ce:	48 8b 0d fb 7d 06 00 	mov    0x67dfb(%rip),%rcx        # 10b87d0 <myl_lit_3b2e9d8953e261b03d089bbc831cd3b7c9a128df1fa9770dfd3ff0548594ae5c_instance+0x20>
 10509d5:	48 ff c9             	dec    %rcx
 10509d8:	75 0e                	jne    10509e8 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2468>
 10509da:	48 83 3d f6 7d 06 00 	cmpq   $0x0,0x67df6(%rip)        # 10b87d8 <myl_lit_3b2e9d8953e261b03d089bbc831cd3b7c9a128df1fa9770dfd3ff0548594ae5c_instance+0x28>
 10509e1:	00 
 10509e2:	0f 84 7c 02 00 00    	je     1050c64 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x26e4>
 10509e8:	48 89 0d e1 7d 06 00 	mov    %rcx,0x67de1(%rip)        # 10b87d0 <myl_lit_3b2e9d8953e261b03d089bbc831cd3b7c9a128df1fa9770dfd3ff0548594ae5c_instance+0x20>
 10509ef:	48 c7 84 24 d0 00 00 	movq   $0x0,0xd0(%rsp)
 10509f6:	00 00 00 00 00 
 10509fb:	85 c0                	test   %eax,%eax
 10509fd:	0f 84 81 02 00 00    	je     1050c84 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2704>
 1050a03:	31 db                	xor    %ebx,%ebx
 1050a05:	4c 8d b4 24 a8 01 00 	lea    0x1a8(%rsp),%r14
 1050a0c:	00 
 1050a0d:	4c 8d bc 24 48 01 00 	lea    0x148(%rsp),%r15
 1050a14:	00 
 1050a15:	49 bd e5 8f a2 12 31 	movabs $0x89705f3112a28fe5,%r13
 1050a1c:	5f 70 89 
 1050a1f:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
 1050a26:	00 00 
 1050a28:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
 1050a2f:	00 
 1050a30:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
 1050a35:	48 01 d8             	add    %rbx,%rax
 1050a38:	0f 80 11 09 00 00    	jo     105134f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2dcf>
 1050a3e:	48 8b 4c 24 30       	mov    0x30(%rsp),%rcx
 1050a43:	48 8b 79 08          	mov    0x8(%rcx),%rdi
 1050a47:	48 8b 0f             	mov    (%rdi),%rcx
 1050a4a:	48 85 c9             	test   %rcx,%rcx
 1050a4d:	0f 88 0e 09 00 00    	js     1051361 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2de1>
 1050a53:	0f 84 13 09 00 00    	je     105136c <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2dec>
 1050a59:	48 89 c2             	mov    %rax,%rdx
 1050a5c:	48 09 ca             	or     %rcx,%rdx
 1050a5f:	48 c1 ea 20          	shr    $0x20,%rdx
 1050a63:	74 07                	je     1050a6c <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x24ec>
 1050a65:	48 99                	cqto
 1050a67:	48 f7 f9             	idiv   %rcx
 1050a6a:	eb 04                	jmp    1050a70 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x24f0>
 1050a6c:	31 d2                	xor    %edx,%edx
 1050a6e:	f7 f1                	div    %ecx
 1050a70:	48 89 d0             	mov    %rdx,%rax
 1050a73:	48 c1 f8 3f          	sar    $0x3f,%rax
 1050a77:	48 21 c8             	and    %rcx,%rax
 1050a7a:	48 01 d0             	add    %rdx,%rax
 1050a7d:	48 89 c6             	mov    %rax,%rsi
 1050a80:	48 c1 fe 3f          	sar    $0x3f,%rsi
 1050a84:	48 21 ce             	and    %rcx,%rsi
 1050a87:	48 01 c6             	add    %rax,%rsi
 1050a8a:	48 39 ce             	cmp    %rcx,%rsi
 1050a8d:	0f 83 e4 08 00 00    	jae    1051377 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2df7>
 1050a93:	48 8b 47 20          	mov    0x20(%rdi),%rax
 1050a97:	48 8b 04 f0          	mov    (%rax,%rsi,8),%rax
 1050a9b:	48 85 c0             	test   %rax,%rax
 1050a9e:	74 2b                	je     1050acb <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x254b>
 1050aa0:	48 89 c7             	mov    %rax,%rdi
 1050aa3:	48 b9 02 00 00 00 00 	movabs $0x4000000000000002,%rcx
 1050aaa:	00 00 40 
 1050aad:	48 85 48 f0          	test   %rcx,-0x10(%rax)
 1050ab1:	0f 84 42 01 00 00    	je     1050bf9 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2679>
 1050ab7:	48 89 84 24 48 01 00 	mov    %rax,0x148(%rsp)
 1050abe:	00 
 1050abf:	f6 47 10 04          	testb  $0x4,0x10(%rdi)
 1050ac3:	75 16                	jne    1050adb <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x255b>
 1050ac5:	48 83 c7 18          	add    $0x18,%rdi
 1050ac9:	eb 1f                	jmp    1050aea <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x256a>
 1050acb:	31 ff                	xor    %edi,%edi
 1050acd:	48 89 84 24 48 01 00 	mov    %rax,0x148(%rsp)
 1050ad4:	00 
 1050ad5:	f6 47 10 04          	testb  $0x4,0x10(%rdi)
 1050ad9:	74 ea                	je     1050ac5 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2545>
 1050adb:	48 8b 4f 18          	mov    0x18(%rdi),%rcx
 1050adf:	8b 57 14             	mov    0x14(%rdi),%edx
 1050ae2:	48 8d 3c 11          	lea    (%rcx,%rdx,1),%rdi
 1050ae6:	48 83 c7 18          	add    $0x18,%rdi
 1050aea:	48 8b 70 08          	mov    0x8(%rax),%rsi
 1050aee:	31 d2                	xor    %edx,%edx
 1050af0:	4c 89 f1             	mov    %r14,%rcx
 1050af3:	e8 78 95 ff ff       	call   104a070 <myl_native_bytes_number_parse>
 1050af8:	85 c0                	test   %eax,%eax
 1050afa:	74 5d                	je     1050b59 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x25d9>
 1050afc:	4c 8b a4 24 a8 01 00 	mov    0x1a8(%rsp),%r12
 1050b03:	00 
 1050b04:	c7 84 24 68 01 00 00 	movl   $0x1,0x168(%rsp)
 1050b0b:	01 00 00 00 
 1050b0f:	4c 89 a4 24 70 01 00 	mov    %r12,0x170(%rsp)
 1050b16:	00 
 1050b17:	48 8b 84 24 48 01 00 	mov    0x148(%rsp),%rax
 1050b1e:	00 
 1050b1f:	48 85 c0             	test   %rax,%rax
 1050b22:	0f 84 78 00 00 00    	je     1050ba0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2620>
 1050b28:	48 b9 02 00 00 00 00 	movabs $0x4000000000000002,%rcx
 1050b2f:	00 00 40 
 1050b32:	48 85 48 f0          	test   %rcx,-0x10(%rax)
 1050b36:	75 68                	jne    1050ba0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2620>
 1050b38:	48 8b 48 e8          	mov    -0x18(%rax),%rcx
 1050b3c:	48 ff c9             	dec    %rcx
 1050b3f:	75 5a                	jne    1050b9b <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x261b>
 1050b41:	48 83 78 e0 00       	cmpq   $0x0,-0x20(%rax)
 1050b46:	75 53                	jne    1050b9b <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x261b>
 1050b48:	48 8d bd 58 02 00 00 	lea    0x258(%rbp),%rdi
 1050b4f:	4c 89 fe             	mov    %r15,%rsi
 1050b52:	e8 a9 54 03 00       	call   1086000 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan>
 1050b57:	eb 47                	jmp    1050ba0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2620>
 1050b59:	c7 84 24 68 01 00 00 	movl   $0x0,0x168(%rsp)
 1050b60:	00 00 00 00 
 1050b64:	48 8b 84 24 48 01 00 	mov    0x148(%rsp),%rax
 1050b6b:	00 
 1050b6c:	41 bc 61 00 00 00    	mov    $0x61,%r12d
 1050b72:	48 85 c0             	test   %rax,%rax
 1050b75:	74 29                	je     1050ba0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2620>
 1050b77:	48 b9 02 00 00 00 00 	movabs $0x4000000000000002,%rcx
 1050b7e:	00 00 40 
 1050b81:	48 85 48 f0          	test   %rcx,-0x10(%rax)
 1050b85:	75 19                	jne    1050ba0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2620>
 1050b87:	48 8b 48 e8          	mov    -0x18(%rax),%rcx
 1050b8b:	48 ff c9             	dec    %rcx
 1050b8e:	75 0b                	jne    1050b9b <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x261b>
 1050b90:	48 83 78 e0 00       	cmpq   $0x0,-0x20(%rax)
 1050b95:	0f 84 9a 00 00 00    	je     1050c35 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x26b5>
 1050b9b:	48 89 48 e8          	mov    %rcx,-0x18(%rax)
 1050b9f:	90                   	nop
 1050ba0:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
 1050ba5:	48 89 d1             	mov    %rdx,%rcx
 1050ba8:	4c 01 e1             	add    %r12,%rcx
 1050bab:	0f 80 d1 07 00 00    	jo     1051382 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2e02>
 1050bb1:	48 89 c8             	mov    %rcx,%rax
 1050bb4:	49 f7 ed             	imul   %r13
 1050bb7:	48 01 ca             	add    %rcx,%rdx
 1050bba:	48 89 d0             	mov    %rdx,%rax
 1050bbd:	48 c1 e8 3f          	shr    $0x3f,%rax
 1050bc1:	48 c1 fa 1d          	sar    $0x1d,%rdx
 1050bc5:	48 01 c2             	add    %rax,%rdx
 1050bc8:	48 69 c2 07 ca 9a 3b 	imul   $0x3b9aca07,%rdx,%rax
 1050bcf:	48 29 c1             	sub    %rax,%rcx
 1050bd2:	48 89 c8             	mov    %rcx,%rax
 1050bd5:	48 c1 f8 3f          	sar    $0x3f,%rax
 1050bd9:	25 07 ca 9a 3b       	and    $0x3b9aca07,%eax
 1050bde:	48 01 c8             	add    %rcx,%rax
 1050be1:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
 1050be6:	48 ff c3             	inc    %rbx
 1050be9:	48 39 5c 24 28       	cmp    %rbx,0x28(%rsp)
 1050bee:	0f 85 3c fe ff ff    	jne    1050a30 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x24b0>
 1050bf4:	e9 d9 e1 ff ff       	jmp    104edd2 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x852>
 1050bf9:	48 8b 48 e8          	mov    -0x18(%rax),%rcx
 1050bfd:	48 ff c1             	inc    %rcx
 1050c00:	74 1e                	je     1050c20 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x26a0>
 1050c02:	48 89 48 e8          	mov    %rcx,-0x18(%rax)
 1050c06:	48 89 c7             	mov    %rax,%rdi
 1050c09:	48 89 84 24 48 01 00 	mov    %rax,0x148(%rsp)
 1050c10:	00 
 1050c11:	f6 47 10 04          	testb  $0x4,0x10(%rdi)
 1050c15:	0f 85 c0 fe ff ff    	jne    1050adb <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x255b>
 1050c1b:	e9 a5 fe ff ff       	jmp    1050ac5 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2545>
 1050c20:	be bf 7d 00 01       	mov    $0x1007dbf,%esi
 1050c25:	48 89 ef             	mov    %rbp,%rdi
 1050c28:	e8 91 99 03 00       	call   108a5be <fail>
 1050c2d:	45 31 e4             	xor    %r12d,%r12d
 1050c30:	e9 6b ff ff ff       	jmp    1050ba0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2620>
 1050c35:	48 8d bd 58 02 00 00 	lea    0x258(%rbp),%rdi
 1050c3c:	4c 89 fe             	mov    %r15,%rsi
 1050c3f:	e8 bc 53 03 00       	call   1086000 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan>
 1050c44:	e9 57 ff ff ff       	jmp    1050ba0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2620>
 1050c49:	be bf 7d 00 01       	mov    $0x1007dbf,%esi
 1050c4e:	48 89 ef             	mov    %rbp,%rdi
 1050c51:	e8 68 99 03 00       	call   108a5be <fail>
 1050c56:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
 1050c5d:	00 00 
 1050c5f:	e9 6e e1 ff ff       	jmp    104edd2 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x852>
 1050c64:	48 8d b4 24 d0 00 00 	lea    0xd0(%rsp),%rsi
 1050c6b:	00 
 1050c6c:	48 8d bd 58 02 00 00 	lea    0x258(%rbp),%rdi
 1050c73:	89 c3                	mov    %eax,%ebx
 1050c75:	e8 f6 53 03 00       	call   1086070 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop>
 1050c7a:	89 d8                	mov    %ebx,%eax
 1050c7c:	85 c0                	test   %eax,%eax
 1050c7e:	0f 85 7f fd ff ff    	jne    1050a03 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2483>
 1050c84:	48 c7 44 24 70 f8 8c 	movq   $0x10b8cf8,0x70(%rsp)
 1050c8b:	0b 01 
 1050c8d:	48 c7 84 24 d0 00 00 	movq   $0x10b8cf8,0xd0(%rsp)
 1050c94:	00 f8 8c 0b 01 
 1050c99:	be f8 8c 0b 01       	mov    $0x10b8cf8,%esi
 1050c9e:	4c 89 f7             	mov    %r14,%rdi
 1050ca1:	e8 5a 0f 04 00       	call   1091c00 <myl_native_text_equal>
 1050ca6:	4c 85 2d 3b 80 06 00 	test   %r13,0x6803b(%rip)        # 10b8ce8 <myl_lit_626da83bb2caf4205ae415768034d7bb2b32d76c3b0b29af95ab0567cf1d3ca9_instance>
 1050cad:	75 21                	jne    1050cd0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2750>
 1050caf:	48 8b 0d 22 80 06 00 	mov    0x68022(%rip),%rcx        # 10b8cd8 <myl_lit_5ffcfeefbc77603111eb9faae2375c1bd71d00fc5610c522261905cf007d59b3_instance+0x60>
 1050cb6:	48 ff c9             	dec    %rcx
 1050cb9:	75 0e                	jne    1050cc9 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2749>
 1050cbb:	48 83 3d 1d 80 06 00 	cmpq   $0x0,0x6801d(%rip)        # 10b8ce0 <myl_lit_5ffcfeefbc77603111eb9faae2375c1bd71d00fc5610c522261905cf007d59b3_instance+0x68>
 1050cc2:	00 
 1050cc3:	0f 84 7e 01 00 00    	je     1050e47 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x28c7>
 1050cc9:	48 89 0d 08 80 06 00 	mov    %rcx,0x68008(%rip)        # 10b8cd8 <myl_lit_5ffcfeefbc77603111eb9faae2375c1bd71d00fc5610c522261905cf007d59b3_instance+0x60>
 1050cd0:	85 c0                	test   %eax,%eax
 1050cd2:	0f 84 8f 01 00 00    	je     1050e67 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x28e7>
 1050cd8:	31 db                	xor    %ebx,%ebx
 1050cda:	4c 8d b4 24 c8 01 00 	lea    0x1c8(%rsp),%r14
 1050ce1:	00 
 1050ce2:	49 bc e5 8f a2 12 31 	movabs $0x89705f3112a28fe5,%r12
 1050ce9:	5f 70 89 
 1050cec:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
 1050cf3:	00 00 
 1050cf5:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
 1050cfa:	48 01 d8             	add    %rbx,%rax
 1050cfd:	0f 80 8c 06 00 00    	jo     105138f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2e0f>
 1050d03:	48 8b 4c 24 30       	mov    0x30(%rsp),%rcx
 1050d08:	48 8b 79 18          	mov    0x18(%rcx),%rdi
 1050d0c:	48 8b 0f             	mov    (%rdi),%rcx
 1050d0f:	48 85 c9             	test   %rcx,%rcx
 1050d12:	49 bd 02 00 00 00 00 	movabs $0x4000000000000002,%r13
 1050d19:	00 00 40 
 1050d1c:	0f 88 7f 06 00 00    	js     10513a1 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2e21>
 1050d22:	0f 84 84 06 00 00    	je     10513ac <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2e2c>
 1050d28:	48 89 c2             	mov    %rax,%rdx
 1050d2b:	48 09 ca             	or     %rcx,%rdx
 1050d2e:	48 c1 ea 20          	shr    $0x20,%rdx
 1050d32:	74 07                	je     1050d3b <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x27bb>
 1050d34:	48 99                	cqto
 1050d36:	48 f7 f9             	idiv   %rcx
 1050d39:	eb 04                	jmp    1050d3f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x27bf>
 1050d3b:	31 d2                	xor    %edx,%edx
 1050d3d:	f7 f1                	div    %ecx
 1050d3f:	48 89 d6             	mov    %rdx,%rsi
 1050d42:	48 c1 fe 3f          	sar    $0x3f,%rsi
 1050d46:	48 21 ce             	and    %rcx,%rsi
 1050d49:	48 01 d6             	add    %rdx,%rsi
 1050d4c:	48 39 ce             	cmp    %rcx,%rsi
 1050d4f:	72 16                	jb     1050d67 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x27e7>
 1050d51:	48 89 f0             	mov    %rsi,%rax
 1050d54:	48 c1 f8 3f          	sar    $0x3f,%rax
 1050d58:	48 21 c8             	and    %rcx,%rax
 1050d5b:	48 01 c6             	add    %rax,%rsi
 1050d5e:	48 39 ce             	cmp    %rcx,%rsi
 1050d61:	0f 83 58 06 00 00    	jae    10513bf <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2e3f>
 1050d67:	48 8b 47 20          	mov    0x20(%rdi),%rax
 1050d6b:	48 8b 34 f0          	mov    (%rax,%rsi,8),%rsi
 1050d6f:	48 8d bd 58 02 00 00 	lea    0x258(%rbp),%rdi
 1050d76:	e8 25 ae ff ff       	call   104bba0 <myl_native_text_integer>
 1050d7b:	48 85 c0             	test   %rax,%rax
 1050d7e:	0f 84 33 06 00 00    	je     10513b7 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2e37>
 1050d84:	49 89 c7             	mov    %rax,%r15
 1050d87:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
 1050d8c:	48 89 84 24 c8 01 00 	mov    %rax,0x1c8(%rsp)
 1050d93:	00 
 1050d94:	48 89 ef             	mov    %rbp,%rdi
 1050d97:	48 89 c6             	mov    %rax,%rsi
 1050d9a:	e8 31 32 02 00       	call   1073fd0 <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85>
 1050d9f:	4d 85 6f f0          	test   %r13,-0x10(%r15)
 1050da3:	4c 8b 6c 24 08       	mov    0x8(%rsp),%r13
 1050da8:	75 14                	jne    1050dbe <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x283e>
 1050daa:	49 8b 4f e0          	mov    -0x20(%r15),%rcx
 1050dae:	48 ff c9             	dec    %rcx
 1050db1:	75 07                	jne    1050dba <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x283a>
 1050db3:	49 83 7f e8 00       	cmpq   $0x0,-0x18(%r15)
 1050db8:	74 60                	je     1050e1a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x289a>
 1050dba:	49 89 4f e0          	mov    %rcx,-0x20(%r15)
 1050dbe:	48 c7 84 24 c8 01 00 	movq   $0x0,0x1c8(%rsp)
 1050dc5:	00 00 00 00 00 
 1050dca:	4c 89 e9             	mov    %r13,%rcx
 1050dcd:	48 01 c1             	add    %rax,%rcx
 1050dd0:	70 65                	jo     1050e37 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x28b7>
 1050dd2:	48 89 c8             	mov    %rcx,%rax
 1050dd5:	49 f7 ec             	imul   %r12
 1050dd8:	48 01 ca             	add    %rcx,%rdx
 1050ddb:	48 89 d0             	mov    %rdx,%rax
 1050dde:	48 c1 e8 3f          	shr    $0x3f,%rax
 1050de2:	48 c1 fa 1d          	sar    $0x1d,%rdx
 1050de6:	48 01 c2             	add    %rax,%rdx
 1050de9:	48 69 c2 07 ca 9a 3b 	imul   $0x3b9aca07,%rdx,%rax
 1050df0:	48 29 c1             	sub    %rax,%rcx
 1050df3:	48 89 c8             	mov    %rcx,%rax
 1050df6:	48 c1 f8 3f          	sar    $0x3f,%rax
 1050dfa:	25 07 ca 9a 3b       	and    $0x3b9aca07,%eax
 1050dff:	48 01 c8             	add    %rcx,%rax
 1050e02:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
 1050e07:	48 ff c3             	inc    %rbx
 1050e0a:	48 39 5c 24 28       	cmp    %rbx,0x28(%rsp)
 1050e0f:	0f 85 e0 fe ff ff    	jne    1050cf5 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2775>
 1050e15:	e9 b8 df ff ff       	jmp    104edd2 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x852>
 1050e1a:	48 8d bd 58 02 00 00 	lea    0x258(%rbp),%rdi
 1050e21:	4c 89 f6             	mov    %r14,%rsi
 1050e24:	49 89 c7             	mov    %rax,%r15
 1050e27:	e8 44 52 03 00       	call   1086070 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop>
 1050e2c:	4c 89 f8             	mov    %r15,%rax
 1050e2f:	4c 89 e9             	mov    %r13,%rcx
 1050e32:	48 01 c1             	add    %rax,%rcx
 1050e35:	71 9b                	jno    1050dd2 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2852>
 1050e37:	48 89 ef             	mov    %rbp,%rdi
 1050e3a:	31 f6                	xor    %esi,%esi
 1050e3c:	4c 89 ea             	mov    %r13,%rdx
 1050e3f:	48 89 c1             	mov    %rax,%rcx
 1050e42:	e8 89 a1 03 00       	call   108afd0 <myl_qbe_fail_overflow_op>
 1050e47:	48 8d b4 24 d0 00 00 	lea    0xd0(%rsp),%rsi
 1050e4e:	00 
 1050e4f:	48 8d bd 58 02 00 00 	lea    0x258(%rbp),%rdi
 1050e56:	89 c3                	mov    %eax,%ebx
 1050e58:	e8 13 52 03 00       	call   1086070 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop>
 1050e5d:	89 d8                	mov    %ebx,%eax
 1050e5f:	85 c0                	test   %eax,%eax
 1050e61:	0f 85 71 fe ff ff    	jne    1050cd8 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2758>
 1050e67:	48 c7 44 24 70 10 91 	movq   $0x10b9110,0x70(%rsp)
 1050e6e:	0b 01 
 1050e70:	48 c7 84 24 d0 00 00 	movq   $0x10b9110,0xd0(%rsp)
 1050e77:	00 10 91 0b 01 
 1050e7c:	be 10 91 0b 01       	mov    $0x10b9110,%esi
 1050e81:	4c 89 f7             	mov    %r14,%rdi
 1050e84:	e8 77 0d 04 00       	call   1091c00 <myl_native_text_equal>
 1050e89:	4c 85 2d 70 82 06 00 	test   %r13,0x68270(%rip)        # 10b9100 <myl_lit_a35604ac3394cc7d310962e0ecc5dd785c46f6dc02140680027413a7b439bcdd_instance>
 1050e90:	75 21                	jne    1050eb3 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2933>
 1050e92:	48 8b 0d 57 82 06 00 	mov    0x68257(%rip),%rcx        # 10b90f0 <myl_lit_9d259d114fa076e260ed1d46f937777788fb8ac5c28077065c4fa3e2a22cd22a_instance+0x38>
 1050e99:	48 ff c9             	dec    %rcx
 1050e9c:	75 0e                	jne    1050eac <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x292c>
 1050e9e:	48 83 3d 52 82 06 00 	cmpq   $0x0,0x68252(%rip)        # 10b90f8 <myl_lit_9d259d114fa076e260ed1d46f937777788fb8ac5c28077065c4fa3e2a22cd22a_instance+0x40>
 1050ea5:	00 
 1050ea6:	0f 84 b3 00 00 00    	je     1050f5f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x29df>
 1050eac:	48 89 0d 3d 82 06 00 	mov    %rcx,0x6823d(%rip)        # 10b90f0 <myl_lit_9d259d114fa076e260ed1d46f937777788fb8ac5c28077065c4fa3e2a22cd22a_instance+0x38>
 1050eb3:	85 c0                	test   %eax,%eax
 1050eb5:	0f 84 c4 00 00 00    	je     1050f7f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x29ff>
 1050ebb:	31 db                	xor    %ebx,%ebx
 1050ebd:	49 be e5 8f a2 12 31 	movabs $0x89705f3112a28fe5,%r14
 1050ec4:	5f 70 89 
 1050ec7:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
 1050ece:	00 00 
 1050ed0:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
 1050ed5:	48 01 de             	add    %rbx,%rsi
 1050ed8:	0f 80 ec 04 00 00    	jo     10513ca <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2e4a>
 1050ede:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
 1050ee3:	48 8b 40 08          	mov    0x8(%rax),%rax
 1050ee7:	83 e6 01             	and    $0x1,%esi
 1050eea:	48 8b 10             	mov    (%rax),%rdx
 1050eed:	48 39 d6             	cmp    %rdx,%rsi
 1050ef0:	4c 8b 7c 24 08       	mov    0x8(%rsp),%r15
 1050ef5:	0f 83 e1 04 00 00    	jae    10513dc <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2e5c>
 1050efb:	48 8b 40 20          	mov    0x20(%rax),%rax
 1050eff:	48 8b 34 f0          	mov    (%rax,%rsi,8),%rsi
 1050f03:	48 89 ef             	mov    %rbp,%rdi
 1050f06:	e8 a5 98 01 00       	call   106a7b0 <myl_f_ad1ca9f864adc8c89d572ada651cc6dc28bc6d83eeae5c5fc70bc26744bcdb57>
 1050f0b:	4c 89 f9             	mov    %r15,%rcx
 1050f0e:	48 01 c1             	add    %rax,%rcx
 1050f11:	0f 80 cd 04 00 00    	jo     10513e4 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2e64>
 1050f17:	48 89 c8             	mov    %rcx,%rax
 1050f1a:	49 f7 ee             	imul   %r14
 1050f1d:	48 01 ca             	add    %rcx,%rdx
 1050f20:	48 89 d0             	mov    %rdx,%rax
 1050f23:	48 c1 e8 3f          	shr    $0x3f,%rax
 1050f27:	48 c1 fa 1d          	sar    $0x1d,%rdx
 1050f2b:	48 01 c2             	add    %rax,%rdx
 1050f2e:	48 69 c2 07 ca 9a 3b 	imul   $0x3b9aca07,%rdx,%rax
 1050f35:	48 29 c1             	sub    %rax,%rcx
 1050f38:	48 89 c8             	mov    %rcx,%rax
 1050f3b:	48 c1 f8 3f          	sar    $0x3f,%rax
 1050f3f:	25 07 ca 9a 3b       	and    $0x3b9aca07,%eax
 1050f44:	48 01 c8             	add    %rcx,%rax
 1050f47:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
 1050f4c:	48 ff c3             	inc    %rbx
 1050f4f:	48 39 5c 24 28       	cmp    %rbx,0x28(%rsp)
 1050f54:	0f 85 76 ff ff ff    	jne    1050ed0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2950>
 1050f5a:	e9 73 de ff ff       	jmp    104edd2 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x852>
 1050f5f:	48 8d b4 24 d0 00 00 	lea    0xd0(%rsp),%rsi
 1050f66:	00 
 1050f67:	48 8d bd 58 02 00 00 	lea    0x258(%rbp),%rdi
 1050f6e:	89 c3                	mov    %eax,%ebx
 1050f70:	e8 fb 50 03 00       	call   1086070 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop>
 1050f75:	89 d8                	mov    %ebx,%eax
 1050f77:	85 c0                	test   %eax,%eax
 1050f79:	0f 85 3c ff ff ff    	jne    1050ebb <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x293b>
 1050f7f:	48 c7 44 24 70 a8 85 	movq   $0x10b85a8,0x70(%rsp)
 1050f86:	0b 01 
 1050f88:	48 c7 84 24 d0 00 00 	movq   $0x10b85a8,0xd0(%rsp)
 1050f8f:	00 a8 85 0b 01 
 1050f94:	be a8 85 0b 01       	mov    $0x10b85a8,%esi
 1050f99:	4c 89 f7             	mov    %r14,%rdi
 1050f9c:	e8 5f 0c 04 00       	call   1091c00 <myl_native_text_equal>
 1050fa1:	4c 85 2d f0 75 06 00 	test   %r13,0x675f0(%rip)        # 10b8598 <myl_lit_20a5074191baf0b9771e8515f87070a522415c098c80effc97a3fee2e9d89d03_instance>
 1050fa8:	75 21                	jne    1050fcb <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2a4b>
 1050faa:	48 8b 0d d7 75 06 00 	mov    0x675d7(%rip),%rcx        # 10b8588 <myl_lit_1ad4f10fd641593331eda3448c74a0b009c6527a19d75e6283c9d7ef74595fd2_instance+0x38>
 1050fb1:	48 ff c9             	dec    %rcx
 1050fb4:	75 0e                	jne    1050fc4 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2a44>
 1050fb6:	48 83 3d d2 75 06 00 	cmpq   $0x0,0x675d2(%rip)        # 10b8590 <myl_lit_1ad4f10fd641593331eda3448c74a0b009c6527a19d75e6283c9d7ef74595fd2_instance+0x40>
 1050fbd:	00 
 1050fbe:	0f 84 a9 00 00 00    	je     105106d <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2aed>
 1050fc4:	48 89 0d bd 75 06 00 	mov    %rcx,0x675bd(%rip)        # 10b8588 <myl_lit_1ad4f10fd641593331eda3448c74a0b009c6527a19d75e6283c9d7ef74595fd2_instance+0x38>
 1050fcb:	85 c0                	test   %eax,%eax
 1050fcd:	0f 84 ba 00 00 00    	je     105108d <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2b0d>
 1050fd3:	31 db                	xor    %ebx,%ebx
 1050fd5:	49 be e5 8f a2 12 31 	movabs $0x89705f3112a28fe5,%r14
 1050fdc:	5f 70 89 
 1050fdf:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
 1050fe6:	00 00 
 1050fe8:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
 1050fed:	48 01 d8             	add    %rbx,%rax
 1050ff0:	0f 80 fe 03 00 00    	jo     10513f4 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2e74>
 1050ff6:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
 1050ffb:	48 8b 40 08          	mov    0x8(%rax),%rax
 1050fff:	48 83 38 00          	cmpq   $0x0,(%rax)
 1051003:	4c 8b 7c 24 08       	mov    0x8(%rsp),%r15
 1051008:	0f 84 f8 03 00 00    	je     1051406 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2e86>
 105100e:	48 8b 40 20          	mov    0x20(%rax),%rax
 1051012:	48 8b 30             	mov    (%rax),%rsi
 1051015:	48 89 ef             	mov    %rbp,%rdi
 1051018:	e8 13 0d 02 00       	call   1071d30 <myl_f_bc9060da36c8e282f8d98349f6541aa0f2c1802b8a99e1d4c2ef7b134103c5e2>
 105101d:	4c 89 f9             	mov    %r15,%rcx
 1051020:	48 01 c1             	add    %rax,%rcx
 1051023:	0f 80 e9 03 00 00    	jo     1051412 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2e92>
 1051029:	48 89 c8             	mov    %rcx,%rax
 105102c:	49 f7 ee             	imul   %r14
 105102f:	48 01 ca             	add    %rcx,%rdx
 1051032:	48 89 d0             	mov    %rdx,%rax
 1051035:	48 c1 e8 3f          	shr    $0x3f,%rax
 1051039:	48 c1 fa 1d          	sar    $0x1d,%rdx
 105103d:	48 01 c2             	add    %rax,%rdx
 1051040:	48 69 c2 07 ca 9a 3b 	imul   $0x3b9aca07,%rdx,%rax
 1051047:	48 29 c1             	sub    %rax,%rcx
 105104a:	48 89 c8             	mov    %rcx,%rax
 105104d:	48 c1 f8 3f          	sar    $0x3f,%rax
 1051051:	25 07 ca 9a 3b       	and    $0x3b9aca07,%eax
 1051056:	48 01 c8             	add    %rcx,%rax
 1051059:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
 105105e:	48 ff c3             	inc    %rbx
 1051061:	48 39 5c 24 28       	cmp    %rbx,0x28(%rsp)
 1051066:	75 80                	jne    1050fe8 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2a68>
 1051068:	e9 65 dd ff ff       	jmp    104edd2 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x852>
 105106d:	48 8d b4 24 d0 00 00 	lea    0xd0(%rsp),%rsi
 1051074:	00 
 1051075:	48 8d bd 58 02 00 00 	lea    0x258(%rbp),%rdi
 105107c:	89 c3                	mov    %eax,%ebx
 105107e:	e8 ed 4f 03 00       	call   1086070 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop>
 1051083:	89 d8                	mov    %ebx,%eax
 1051085:	85 c0                	test   %eax,%eax
 1051087:	0f 85 46 ff ff ff    	jne    1050fd3 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2a53>
 105108d:	48 c7 44 24 70 78 86 	movq   $0x10b8678,0x70(%rsp)
 1051094:	0b 01 
 1051096:	48 c7 84 24 d0 00 00 	movq   $0x10b8678,0xd0(%rsp)
 105109d:	00 78 86 0b 01 
 10510a2:	be 78 86 0b 01       	mov    $0x10b8678,%esi
 10510a7:	4c 89 f7             	mov    %r14,%rdi
 10510aa:	e8 51 0b 04 00       	call   1091c00 <myl_native_text_equal>
 10510af:	4c 85 2d b2 75 06 00 	test   %r13,0x675b2(%rip)        # 10b8668 <myl_lit_2cecebef85ac89e87c0bdc9d723015d4a10a29fb007a542e0de04f511346a3b5_instance>
 10510b6:	75 21                	jne    10510d9 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2b59>
 10510b8:	48 8b 0d 99 75 06 00 	mov    0x67599(%rip),%rcx        # 10b8658 <myl_lit_2ac6840555c10725b6640492294f67393cd0d698e5786fc4e12cdb1cc9a394a2_instance+0x38>
 10510bf:	48 ff c9             	dec    %rcx
 10510c2:	75 0e                	jne    10510d2 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2b52>
 10510c4:	48 83 3d 94 75 06 00 	cmpq   $0x0,0x67594(%rip)        # 10b8660 <myl_lit_2ac6840555c10725b6640492294f67393cd0d698e5786fc4e12cdb1cc9a394a2_instance+0x40>
 10510cb:	00 
 10510cc:	0f 84 e5 00 00 00    	je     10511b7 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2c37>
 10510d2:	48 89 0d 7f 75 06 00 	mov    %rcx,0x6757f(%rip)        # 10b8658 <myl_lit_2ac6840555c10725b6640492294f67393cd0d698e5786fc4e12cdb1cc9a394a2_instance+0x38>
 10510d9:	85 c0                	test   %eax,%eax
 10510db:	0f 84 f6 00 00 00    	je     10511d7 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2c57>
 10510e1:	31 db                	xor    %ebx,%ebx
 10510e3:	49 be 79 78 78 78 78 	movabs $0x7878787878787879,%r14
 10510ea:	78 78 78 
 10510ed:	49 bf e5 8f a2 12 31 	movabs $0x89705f3112a28fe5,%r15
 10510f4:	5f 70 89 
 10510f7:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
 10510fe:	00 00 
 1051100:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
 1051105:	48 01 d9             	add    %rbx,%rcx
 1051108:	0f 80 14 03 00 00    	jo     1051422 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2ea2>
 105110e:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
 1051113:	48 8b 40 08          	mov    0x8(%rax),%rax
 1051117:	48 83 38 00          	cmpq   $0x0,(%rax)
 105111b:	4c 8b 64 24 08       	mov    0x8(%rsp),%r12
 1051120:	0f 84 0e 03 00 00    	je     1051434 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2eb4>
 1051126:	48 8b 40 20          	mov    0x20(%rax),%rax
 105112a:	48 8b 30             	mov    (%rax),%rsi
 105112d:	48 89 c8             	mov    %rcx,%rax
 1051130:	49 f7 ee             	imul   %r14
 1051133:	48 89 d0             	mov    %rdx,%rax
 1051136:	48 c1 e8 3f          	shr    $0x3f,%rax
 105113a:	48 c1 fa 03          	sar    $0x3,%rdx
 105113e:	48 01 c2             	add    %rax,%rdx
 1051141:	48 89 d0             	mov    %rdx,%rax
 1051144:	48 c1 e0 04          	shl    $0x4,%rax
 1051148:	48 01 d0             	add    %rdx,%rax
 105114b:	48 29 c1             	sub    %rax,%rcx
 105114e:	48 89 ca             	mov    %rcx,%rdx
 1051151:	48 c1 fa 3f          	sar    $0x3f,%rdx
 1051155:	83 e2 11             	and    $0x11,%edx
 1051158:	48 01 ca             	add    %rcx,%rdx
 105115b:	48 89 ef             	mov    %rbp,%rdi
 105115e:	e8 9d 6a 00 00       	call   1057c00 <myl_f_47022dd26e980fcb99b6abeb2cfdf289edce3d6955dda89c0a131b73692c5f56>
 1051163:	4c 89 e1             	mov    %r12,%rcx
 1051166:	48 01 c1             	add    %rax,%rcx
 1051169:	0f 80 d1 02 00 00    	jo     1051440 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2ec0>
 105116f:	48 89 c8             	mov    %rcx,%rax
 1051172:	49 f7 ef             	imul   %r15
 1051175:	48 01 ca             	add    %rcx,%rdx
 1051178:	48 89 d0             	mov    %rdx,%rax
 105117b:	48 c1 e8 3f          	shr    $0x3f,%rax
 105117f:	48 c1 fa 1d          	sar    $0x1d,%rdx
 1051183:	48 01 c2             	add    %rax,%rdx
 1051186:	48 69 c2 07 ca 9a 3b 	imul   $0x3b9aca07,%rdx,%rax
 105118d:	48 29 c1             	sub    %rax,%rcx
 1051190:	48 89 c8             	mov    %rcx,%rax
 1051193:	48 c1 f8 3f          	sar    $0x3f,%rax
 1051197:	25 07 ca 9a 3b       	and    $0x3b9aca07,%eax
 105119c:	48 01 c8             	add    %rcx,%rax
 105119f:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
 10511a4:	48 ff c3             	inc    %rbx
 10511a7:	48 39 5c 24 28       	cmp    %rbx,0x28(%rsp)
 10511ac:	0f 85 4e ff ff ff    	jne    1051100 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2b80>
 10511b2:	e9 1b dc ff ff       	jmp    104edd2 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x852>
 10511b7:	48 8d b4 24 d0 00 00 	lea    0xd0(%rsp),%rsi
 10511be:	00 
 10511bf:	48 8d bd 58 02 00 00 	lea    0x258(%rbp),%rdi
 10511c6:	89 c3                	mov    %eax,%ebx
 10511c8:	e8 a3 4e 03 00       	call   1086070 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop>
 10511cd:	89 d8                	mov    %ebx,%eax
 10511cf:	85 c0                	test   %eax,%eax
 10511d1:	0f 85 0a ff ff ff    	jne    10510e1 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2b61>
 10511d7:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
 10511de:	00 00 
 10511e0:	e9 ed db ff ff       	jmp    104edd2 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x852>
 10511e5:	c5 f8 77             	vzeroupper
 10511e8:	e8 33 9f 05 00       	call   10ab120 <abort@plt>
 10511ed:	c5 f8 77             	vzeroupper
 10511f0:	e8 b2 82 04 00       	call   10994a7 <myl_rc_invariant_failed>
 10511f5:	48 89 ef             	mov    %rbp,%rdi
 10511f8:	31 f6                	xor    %esi,%esi
 10511fa:	c5 f8 77             	vzeroupper
 10511fd:	e8 ce 9d 03 00       	call   108afd0 <myl_qbe_fail_overflow_op>
 1051202:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
 1051207:	31 f6                	xor    %esi,%esi
 1051209:	4c 89 e2             	mov    %r12,%rdx
 105120c:	48 89 c1             	mov    %rax,%rcx
 105120f:	e8 bc 9d 03 00       	call   108afd0 <myl_qbe_fail_overflow_op>
 1051214:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
 1051219:	c5 f8 77             	vzeroupper
 105121c:	e8 5f 9b 03 00       	call   108ad80 <myl_qbe_fail_iteration>
 1051221:	48 89 ef             	mov    %rbp,%rdi
 1051224:	31 f6                	xor    %esi,%esi
 1051226:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
 105122b:	4c 89 f1             	mov    %r14,%rcx
 105122e:	c5 f8 77             	vzeroupper
 1051231:	e8 9a 9d 03 00       	call   108afd0 <myl_qbe_fail_overflow_op>
 1051236:	48 89 ef             	mov    %rbp,%rdi
 1051239:	31 f6                	xor    %esi,%esi
 105123b:	4c 89 ea             	mov    %r13,%rdx
 105123e:	48 89 d9             	mov    %rbx,%rcx
 1051241:	c5 f8 77             	vzeroupper
 1051244:	e8 87 9d 03 00       	call   108afd0 <myl_qbe_fail_overflow_op>
 1051249:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
 105124e:	e8 6d 9c 03 00       	call   108aec0 <myl_qbe_fail_normalized_index_bounds>
 1051253:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
 1051258:	e8 63 9c 03 00       	call   108aec0 <myl_qbe_fail_normalized_index_bounds>
 105125d:	48 89 ef             	mov    %rbp,%rdi
 1051260:	31 f6                	xor    %esi,%esi
 1051262:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
 1051267:	48 89 d9             	mov    %rbx,%rcx
 105126a:	e8 61 9d 03 00       	call   108afd0 <myl_qbe_fail_overflow_op>
 105126f:	48 89 ef             	mov    %rbp,%rdi
 1051272:	31 f6                	xor    %esi,%esi
 1051274:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
 1051279:	48 89 d9             	mov    %rbx,%rcx
 105127c:	e8 4f 9d 03 00       	call   108afd0 <myl_qbe_fail_overflow_op>
 1051281:	48 89 ef             	mov    %rbp,%rdi
 1051284:	31 f6                	xor    %esi,%esi
 1051286:	31 d2                	xor    %edx,%edx
 1051288:	e8 33 9c 03 00       	call   108aec0 <myl_qbe_fail_normalized_index_bounds>
 105128d:	48 89 ef             	mov    %rbp,%rdi
 1051290:	e8 2b 9c 03 00       	call   108aec0 <myl_qbe_fail_normalized_index_bounds>
 1051295:	b9 01 00 00 00       	mov    $0x1,%ecx
 105129a:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
 105129f:	31 f6                	xor    %esi,%esi
 10512a1:	4c 89 fa             	mov    %r15,%rdx
 10512a4:	e8 27 9d 03 00       	call   108afd0 <myl_qbe_fail_overflow_op>
 10512a9:	48 89 ef             	mov    %rbp,%rdi
 10512ac:	c5 f8 77             	vzeroupper
 10512af:	e8 0c 9c 03 00       	call   108aec0 <myl_qbe_fail_normalized_index_bounds>
 10512b4:	48 89 ef             	mov    %rbp,%rdi
 10512b7:	31 f6                	xor    %esi,%esi
 10512b9:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
 10512be:	4c 89 e9             	mov    %r13,%rcx
 10512c1:	c5 f8 77             	vzeroupper
 10512c4:	e8 07 9d 03 00       	call   108afd0 <myl_qbe_fail_overflow_op>
 10512c9:	48 89 ef             	mov    %rbp,%rdi
 10512cc:	c5 f8 77             	vzeroupper
 10512cf:	e8 bc 9d 03 00       	call   108b090 <myl_qbe_fail_frame>
 10512d4:	48 89 ef             	mov    %rbp,%rdi
 10512d7:	c5 f8 77             	vzeroupper
 10512da:	e8 91 9a 03 00       	call   108ad70 <myl_qbe_fail_empty_separator>
 10512df:	48 89 ef             	mov    %rbp,%rdi
 10512e2:	c5 f8 77             	vzeroupper
 10512e5:	e8 96 99 03 00       	call   108ac80 <myl_qbe_fail_allocation>
 10512ea:	48 89 ef             	mov    %rbp,%rdi
 10512ed:	31 f6                	xor    %esi,%esi
 10512ef:	4c 89 f1             	mov    %r14,%rcx
 10512f2:	c5 f8 77             	vzeroupper
 10512f5:	e8 d6 9c 03 00       	call   108afd0 <myl_qbe_fail_overflow_op>
 10512fa:	48 89 ef             	mov    %rbp,%rdi
 10512fd:	4c 89 fe             	mov    %r15,%rsi
 1051300:	c5 f8 77             	vzeroupper
 1051303:	e8 28 9d 03 00       	call   108b030 <myl_qbe_fail_cast>
 1051308:	be 02 00 00 00       	mov    $0x2,%esi
 105130d:	b9 07 00 00 00       	mov    $0x7,%ecx
 1051312:	48 89 ef             	mov    %rbp,%rdi
 1051315:	4c 89 fa             	mov    %r15,%rdx
 1051318:	c5 f8 77             	vzeroupper
 105131b:	e8 b0 9c 03 00       	call   108afd0 <myl_qbe_fail_overflow_op>
 1051320:	48 89 ef             	mov    %rbp,%rdi
 1051323:	e8 68 9d 03 00       	call   108b090 <myl_qbe_fail_frame>
 1051328:	48 89 ef             	mov    %rbp,%rdi
 105132b:	e8 50 99 03 00       	call   108ac80 <myl_qbe_fail_allocation>
 1051330:	48 89 ef             	mov    %rbp,%rdi
 1051333:	31 f6                	xor    %esi,%esi
 1051335:	4c 89 e9             	mov    %r13,%rcx
 1051338:	e8 93 9c 03 00       	call   108afd0 <myl_qbe_fail_overflow_op>
 105133d:	48 89 ef             	mov    %rbp,%rdi
 1051340:	31 f6                	xor    %esi,%esi
 1051342:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
 1051347:	4c 89 f9             	mov    %r15,%rcx
 105134a:	e8 81 9c 03 00       	call   108afd0 <myl_qbe_fail_overflow_op>
 105134f:	48 89 ef             	mov    %rbp,%rdi
 1051352:	31 f6                	xor    %esi,%esi
 1051354:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
 1051359:	48 89 d9             	mov    %rbx,%rcx
 105135c:	e8 6f 9c 03 00       	call   108afd0 <myl_qbe_fail_overflow_op>
 1051361:	48 89 ef             	mov    %rbp,%rdi
 1051364:	48 89 ce             	mov    %rcx,%rsi
 1051367:	e8 c4 9c 03 00       	call   108b030 <myl_qbe_fail_cast>
 105136c:	48 89 ef             	mov    %rbp,%rdi
 105136f:	48 89 c6             	mov    %rax,%rsi
 1051372:	e8 09 9c 03 00       	call   108af80 <myl_qbe_fail_division>
 1051377:	48 89 ef             	mov    %rbp,%rdi
 105137a:	48 89 ca             	mov    %rcx,%rdx
 105137d:	e8 3e 9b 03 00       	call   108aec0 <myl_qbe_fail_normalized_index_bounds>
 1051382:	48 89 ef             	mov    %rbp,%rdi
 1051385:	31 f6                	xor    %esi,%esi
 1051387:	4c 89 e1             	mov    %r12,%rcx
 105138a:	e8 41 9c 03 00       	call   108afd0 <myl_qbe_fail_overflow_op>
 105138f:	48 89 ef             	mov    %rbp,%rdi
 1051392:	31 f6                	xor    %esi,%esi
 1051394:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
 1051399:	48 89 d9             	mov    %rbx,%rcx
 105139c:	e8 2f 9c 03 00       	call   108afd0 <myl_qbe_fail_overflow_op>
 10513a1:	48 89 ef             	mov    %rbp,%rdi
 10513a4:	48 89 ce             	mov    %rcx,%rsi
 10513a7:	e8 84 9c 03 00       	call   108b030 <myl_qbe_fail_cast>
 10513ac:	48 89 ef             	mov    %rbp,%rdi
 10513af:	48 89 c6             	mov    %rax,%rsi
 10513b2:	e8 c9 9b 03 00       	call   108af80 <myl_qbe_fail_division>
 10513b7:	48 89 ef             	mov    %rbp,%rdi
 10513ba:	e8 c1 98 03 00       	call   108ac80 <myl_qbe_fail_allocation>
 10513bf:	48 89 ef             	mov    %rbp,%rdi
 10513c2:	48 89 ca             	mov    %rcx,%rdx
 10513c5:	e8 f6 9a 03 00       	call   108aec0 <myl_qbe_fail_normalized_index_bounds>
 10513ca:	48 89 ef             	mov    %rbp,%rdi
 10513cd:	31 f6                	xor    %esi,%esi
 10513cf:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
 10513d4:	48 89 d9             	mov    %rbx,%rcx
 10513d7:	e8 f4 9b 03 00       	call   108afd0 <myl_qbe_fail_overflow_op>
 10513dc:	48 89 ef             	mov    %rbp,%rdi
 10513df:	e8 dc 9a 03 00       	call   108aec0 <myl_qbe_fail_normalized_index_bounds>
 10513e4:	48 89 ef             	mov    %rbp,%rdi
 10513e7:	31 f6                	xor    %esi,%esi
 10513e9:	4c 89 fa             	mov    %r15,%rdx
 10513ec:	48 89 c1             	mov    %rax,%rcx
 10513ef:	e8 dc 9b 03 00       	call   108afd0 <myl_qbe_fail_overflow_op>
 10513f4:	48 89 ef             	mov    %rbp,%rdi
 10513f7:	31 f6                	xor    %esi,%esi
 10513f9:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
 10513fe:	48 89 d9             	mov    %rbx,%rcx
 1051401:	e8 ca 9b 03 00       	call   108afd0 <myl_qbe_fail_overflow_op>
 1051406:	48 89 ef             	mov    %rbp,%rdi
 1051409:	31 f6                	xor    %esi,%esi
 105140b:	31 d2                	xor    %edx,%edx
 105140d:	e8 ae 9a 03 00       	call   108aec0 <myl_qbe_fail_normalized_index_bounds>
 1051412:	48 89 ef             	mov    %rbp,%rdi
 1051415:	31 f6                	xor    %esi,%esi
 1051417:	4c 89 fa             	mov    %r15,%rdx
 105141a:	48 89 c1             	mov    %rax,%rcx
 105141d:	e8 ae 9b 03 00       	call   108afd0 <myl_qbe_fail_overflow_op>
 1051422:	48 89 ef             	mov    %rbp,%rdi
 1051425:	31 f6                	xor    %esi,%esi
 1051427:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
 105142c:	48 89 d9             	mov    %rbx,%rcx
 105142f:	e8 9c 9b 03 00       	call   108afd0 <myl_qbe_fail_overflow_op>
 1051434:	48 89 ef             	mov    %rbp,%rdi
 1051437:	31 f6                	xor    %esi,%esi
 1051439:	31 d2                	xor    %edx,%edx
 105143b:	e8 80 9a 03 00       	call   108aec0 <myl_qbe_fail_normalized_index_bounds>
 1051440:	48 89 ef             	mov    %rbp,%rdi
 1051443:	31 f6                	xor    %esi,%esi
 1051445:	4c 89 e2             	mov    %r12,%rdx
 1051448:	48 89 c1             	mov    %rax,%rcx
 105144b:	e8 80 9b 03 00       	call   108afd0 <myl_qbe_fail_overflow_op>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
