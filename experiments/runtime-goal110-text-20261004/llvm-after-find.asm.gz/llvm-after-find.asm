
.mylang-cache/goal110-text/equality-runner/bin/text-my-llvm:     file format elf64-x86-64


Disassembly of section .text:

0000000001091e30 <myl_native_octets_find>:
 1091e30:	test   %rcx,%rcx
 1091e33:	je     1091e8a <myl_native_octets_find+0x5a>
 1091e35:	push   %rbp
 1091e36:	mov    %rsp,%rbp
 1091e39:	push   %r15
 1091e3b:	push   %r14
 1091e3d:	push   %r13
 1091e3f:	push   %r12
 1091e41:	push   %rbx
 1091e42:	sub    $0x18,%rsp
 1091e46:	mov    $0xffffffffffffffff,%rax
 1091e4d:	mov    %rsi,%r14
 1091e50:	sub    %rcx,%r14
 1091e53:	jb     10920f5 <myl_native_octets_find+0x2c5>
 1091e59:	mov    %rsi,%rbx
 1091e5c:	cmp    $0x1,%rcx
 1091e60:	jne    1091e8d <myl_native_octets_find+0x5d>
 1091e62:	movzbl (%rdx),%esi
 1091e65:	mov    %rdi,%r14
 1091e68:	mov    %rbx,%rdx
 1091e6b:	call   10ab430 <memchr@plt>
 1091e70:	mov    %rax,%rcx
 1091e73:	mov    %rax,%rdx
 1091e76:	sub    %r14,%rdx
 1091e79:	xor    %eax,%eax
 1091e7b:	cmp    $0x1,%rcx
 1091e7f:	sbb    %rax,%rax
 1091e82:	or     %rdx,%rax
 1091e85:	jmp    10920f5 <myl_native_octets_find+0x2c5>
 1091e8a:	xor    %eax,%eax
 1091e8c:	ret
 1091e8d:	mov    %rcx,-0x30(%rbp)
 1091e91:	mov    %rdx,%r15
 1091e94:	movzbl (%rdx),%r12d
 1091e98:	lea    0x1(%r14),%rdx
 1091e9c:	mov    %rdi,%r13
 1091e9f:	mov    %r12d,%esi
 1091ea2:	call   10ab430 <memchr@plt>
 1091ea7:	test   %rax,%rax
 1091eaa:	je     10920ee <myl_native_octets_find+0x2be>
 1091eb0:	mov    %r13,%rcx
 1091eb3:	lea    (%r14,%r13,1),%r10
 1091eb7:	lea    (%r14,%r13,1),%r11
 1091ebb:	inc    %r11
 1091ebe:	lea    0x1(%rax),%rdi
 1091ec2:	mov    $0x1,%edx
 1091ec7:	mov    -0x30(%rbp),%rsi
 1091ecb:	mov    %r15,%r8
 1091ece:	xchg   %ax,%ax
 1091ed0:	movzbl (%rax,%rdx,1),%r9d
 1091ed5:	cmp    (%r8,%rdx,1),%r9b
 1091ed9:	jne    1091eeb <myl_native_octets_find+0xbb>
 1091edb:	inc    %rdx
 1091ede:	cmp    %rdx,%rsi
 1091ee1:	jne    1091ed0 <myl_native_octets_find+0xa0>
 1091ee3:	sub    %rcx,%rax
 1091ee6:	jmp    10920f5 <myl_native_octets_find+0x2c5>
 1091eeb:	cmp    %r10,%rax
 1091eee:	je     10920ee <myl_native_octets_find+0x2be>
 1091ef4:	mov    %r10,-0x38(%rbp)
 1091ef8:	mov    %r11,%r14
 1091efb:	mov    %r11,%rdx
 1091efe:	sub    %rdi,%rdx
 1091f01:	mov    %r12d,%esi
 1091f04:	call   10ab430 <memchr@plt>
 1091f09:	test   %rax,%rax
 1091f0c:	je     10920ee <myl_native_octets_find+0x2be>
 1091f12:	lea    0x1(%rax),%rdi
 1091f16:	mov    $0x1,%edx
 1091f1b:	mov    %r13,%rcx
 1091f1e:	mov    -0x30(%rbp),%rsi
 1091f22:	mov    %r15,%r8
 1091f25:	mov    -0x38(%rbp),%r10
 1091f29:	mov    %r14,%r11
 1091f2c:	nopl   0x0(%rax)
 1091f30:	movzbl (%rax,%rdx,1),%r9d
 1091f35:	cmp    (%r8,%rdx,1),%r9b
 1091f39:	jne    1091f45 <myl_native_octets_find+0x115>
 1091f3b:	inc    %rdx
 1091f3e:	cmp    %rdx,%rsi
 1091f41:	jne    1091f30 <myl_native_octets_find+0x100>
 1091f43:	jmp    1091ee3 <myl_native_octets_find+0xb3>
 1091f45:	cmp    %r10,%rax
 1091f48:	je     10920ee <myl_native_octets_find+0x2be>
 1091f4e:	mov    %r11,%rdx
 1091f51:	sub    %rdi,%rdx
 1091f54:	mov    %r12d,%esi
 1091f57:	call   10ab430 <memchr@plt>
 1091f5c:	test   %rax,%rax
 1091f5f:	je     10920ee <myl_native_octets_find+0x2be>
 1091f65:	lea    0x1(%rax),%rdi
 1091f69:	mov    $0x1,%edx
 1091f6e:	mov    %r13,%rcx
 1091f71:	mov    -0x30(%rbp),%rsi
 1091f75:	mov    %r15,%r8
 1091f78:	mov    -0x38(%rbp),%r10
 1091f7c:	mov    %r14,%r11
 1091f7f:	movzbl (%rax,%rdx,1),%r9d
 1091f84:	cmp    (%r8,%rdx,1),%r9b
 1091f88:	jne    1091f97 <myl_native_octets_find+0x167>
 1091f8a:	inc    %rdx
 1091f8d:	cmp    %rdx,%rsi
 1091f90:	jne    1091f7f <myl_native_octets_find+0x14f>
 1091f92:	jmp    1091ee3 <myl_native_octets_find+0xb3>
 1091f97:	cmp    %r10,%rax
 1091f9a:	je     10920ee <myl_native_octets_find+0x2be>
 1091fa0:	mov    %r11,%rdx
 1091fa3:	sub    %rdi,%rdx
 1091fa6:	mov    %r12d,%esi
 1091fa9:	call   10ab430 <memchr@plt>
 1091fae:	test   %rax,%rax
 1091fb1:	je     10920ee <myl_native_octets_find+0x2be>
 1091fb7:	lea    0x1(%rax),%rdi
 1091fbb:	mov    $0x1,%edx
 1091fc0:	mov    %r13,%rcx
 1091fc3:	mov    -0x30(%rbp),%rsi
 1091fc7:	mov    %r15,%r8
 1091fca:	mov    -0x38(%rbp),%r10
 1091fce:	mov    %r14,%r11
 1091fd1:	movzbl (%rax,%rdx,1),%r9d
 1091fd6:	cmp    (%r8,%rdx,1),%r9b
 1091fda:	jne    1091fe9 <myl_native_octets_find+0x1b9>
 1091fdc:	inc    %rdx
 1091fdf:	cmp    %rdx,%rsi
 1091fe2:	jne    1091fd1 <myl_native_octets_find+0x1a1>
 1091fe4:	jmp    1091ee3 <myl_native_octets_find+0xb3>
 1091fe9:	cmp    %r10,%rax
 1091fec:	je     10920ee <myl_native_octets_find+0x2be>
 1091ff2:	mov    %r11,%rdx
 1091ff5:	sub    %rdi,%rdx
 1091ff8:	mov    %r12d,%esi
 1091ffb:	call   10ab430 <memchr@plt>
 1092000:	test   %rax,%rax
 1092003:	je     10920ee <myl_native_octets_find+0x2be>
 1092009:	lea    0x1(%rax),%rdi
 109200d:	mov    $0x1,%ecx
 1092012:	mov    -0x30(%rbp),%rdx
 1092016:	mov    %r15,%rsi
 1092019:	movzbl (%rax,%rcx,1),%r8d
 109201e:	cmp    (%rsi,%rcx,1),%r8b
 1092022:	jne    1092034 <myl_native_octets_find+0x204>
 1092024:	inc    %rcx
 1092027:	cmp    %rcx,%rdx
 109202a:	jne    1092019 <myl_native_octets_find+0x1e9>
 109202c:	mov    %r13,%rcx
 109202f:	jmp    1091ee3 <myl_native_octets_find+0xb3>
 1092034:	cmp    -0x38(%rbp),%rax
 1092038:	je     10920ee <myl_native_octets_find+0x2be>
 109203e:	mov    %r14,%rdx
 1092041:	sub    %rdi,%rdx
 1092044:	mov    %r12d,%esi
 1092047:	call   10ab430 <memchr@plt>
 109204c:	test   %rax,%rax
 109204f:	je     10920ee <myl_native_octets_find+0x2be>
 1092055:	lea    0x1(%rax),%rdi
 1092059:	mov    $0x1,%ecx
 109205e:	mov    -0x30(%rbp),%rdx
 1092062:	mov    %r15,%rsi
 1092065:	movzbl (%rax,%rcx,1),%r8d
 109206a:	cmp    (%rsi,%rcx,1),%r8b
 109206e:	jne    109207a <myl_native_octets_find+0x24a>
 1092070:	inc    %rcx
 1092073:	cmp    %rcx,%rdx
 1092076:	jne    1092065 <myl_native_octets_find+0x235>
 1092078:	jmp    109202c <myl_native_octets_find+0x1fc>
 109207a:	cmp    -0x38(%rbp),%rax
 109207e:	je     10920ee <myl_native_octets_find+0x2be>
 1092080:	mov    %r14,%rdx
 1092083:	sub    %rdi,%rdx
 1092086:	mov    %r12d,%esi
 1092089:	call   10ab430 <memchr@plt>
 109208e:	test   %rax,%rax
 1092091:	je     10920ee <myl_native_octets_find+0x2be>
 1092093:	lea    0x1(%rax),%rdi
 1092097:	mov    $0x1,%ecx
 109209c:	movzbl (%rax,%rcx,1),%edx
 10920a0:	cmp    (%r15,%rcx,1),%dl
 10920a4:	jne    10920b4 <myl_native_octets_find+0x284>
 10920a6:	inc    %rcx
 10920a9:	cmp    %rcx,-0x30(%rbp)
 10920ad:	jne    109209c <myl_native_octets_find+0x26c>
 10920af:	jmp    109202c <myl_native_octets_find+0x1fc>
 10920b4:	cmp    -0x38(%rbp),%rax
 10920b8:	je     10920ee <myl_native_octets_find+0x2be>
 10920ba:	sub    %rdi,%r14
 10920bd:	mov    %r12d,%esi
 10920c0:	mov    %r14,%rdx
 10920c3:	call   10ab430 <memchr@plt>
 10920c8:	test   %rax,%rax
 10920cb:	je     10920ee <myl_native_octets_find+0x2be>
 10920cd:	lea    0x1(%rax),%rdi
 10920d1:	mov    $0x1,%ecx
 10920d6:	movzbl (%rax,%rcx,1),%edx
 10920da:	cmp    (%r15,%rcx,1),%dl
 10920de:	jne    1092104 <myl_native_octets_find+0x2d4>
 10920e0:	inc    %rcx
 10920e3:	cmp    %rcx,-0x30(%rbp)
 10920e7:	jne    10920d6 <myl_native_octets_find+0x2a6>
 10920e9:	jmp    109202c <myl_native_octets_find+0x1fc>
 10920ee:	mov    $0xffffffffffffffff,%rax
 10920f5:	add    $0x18,%rsp
 10920f9:	pop    %rbx
 10920fa:	pop    %r12
 10920fc:	pop    %r13
 10920fe:	pop    %r14
 1092100:	pop    %r15
 1092102:	pop    %rbp
 1092103:	ret
 1092104:	cmp    -0x38(%rbp),%rax
 1092108:	mov    $0xffffffffffffffff,%rax
 109210f:	je     10920f5 <myl_native_octets_find+0x2c5>
 1092111:	add    %r13,%rbx
 1092114:	sub    %rdi,%rbx
 1092117:	mov    %rbx,%rsi
 109211a:	mov    %r15,%rdx
 109211d:	mov    -0x30(%rbp),%rcx
 1092121:	call   10ab440 <memmem@plt>
 1092126:	mov    %rax,%rcx
 1092129:	mov    %rax,%rdx
 109212c:	sub    %r13,%rdx
 109212f:	jmp    1091e79 <myl_native_octets_find+0x49>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
