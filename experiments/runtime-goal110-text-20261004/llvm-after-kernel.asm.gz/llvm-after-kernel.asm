
.mylang-cache/goal110-text/equality-runner/bin/text-my-llvm:     file format elf64-x86-64


Disassembly of section .text:

000000000104ea40 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76>:
 104ea40:	push   %rbp
 104ea41:	push   %r15
 104ea43:	push   %r14
 104ea45:	push   %r13
 104ea47:	push   %r12
 104ea49:	push   %rbx
 104ea4a:	sub    $0x258,%rsp
 104ea51:	mov    %r8,0x18(%rsp)
 104ea56:	mov    %rcx,0x20(%rsp)
 104ea5b:	mov    %rdi,%r14
 104ea5e:	cmp    %rsp,0x40(%rdi)
 104ea62:	ja     105141a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x29da>
 104ea68:	mov    %rdx,%r15
 104ea6b:	mov    %rsi,%rbx
 104ea6e:	movabs $0x4000000000000002,%r12
 104ea78:	movq   $0x0,0xa0(%rsp)
 104ea84:	movq   $0x0,0x98(%rsp)
 104ea90:	lea    0x258(%r14),%rax
 104ea97:	mov    %rax,0x10(%rsp)
 104ea9c:	mov    0x2c8(%r14),%ebp
 104eaa3:	movq   $0x10b95b0,0x40(%rsp)
 104eaac:	movq   $0x10b95b0,0x70(%rsp)
 104eab5:	mov    $0x10b95b0,%esi
 104eaba:	mov    %rbx,%rdi
 104eabd:	call   1091d30 <myl_native_text_equal>
 104eac2:	test   %r12,0x6aad7(%rip)        # 10b95a0 <myl_lit_d666bf92bda1d63f03bf95c09e1bffde05f85315fdade322db024e5b0244b85a_instance>
 104eac9:	mov    %r14,0x8(%rsp)
 104eace:	jne    104eaf1 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xb1>
 104ead0:	mov    0x6aab9(%rip),%rcx        # 10b9590 <myl_lit_d3cafad273dd497c488894ca58a5701d146f3969ca50fbb18df3109543cd07e8_instance+0x60>
 104ead7:	dec    %rcx
 104eada:	jne    104eaea <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xaa>
 104eadc:	cmpq   $0x0,0x6aab4(%rip)        # 10b9598 <myl_lit_d3cafad273dd497c488894ca58a5701d146f3969ca50fbb18df3109543cd07e8_instance+0x68>
 104eae4:	je     104f0b8 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x678>
 104eaea:	mov    %rcx,0x6aa9f(%rip)        # 10b9590 <myl_lit_d3cafad273dd497c488894ca58a5701d146f3969ca50fbb18df3109543cd07e8_instance+0x60>
 104eaf1:	movq   $0x0,0xc8(%rsp)
 104eafd:	test   %eax,%eax
 104eaff:	mov    %r15,0x30(%rsp)
 104eb04:	je     104f0f5 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x6b5>
 104eb0a:	xor    %ebp,%ebp
 104eb0c:	movabs $0x89705f3112a28fe5,%r15
 104eb16:	movabs $0xffffffffffffff0,%r12
 104eb20:	vpxor  %xmm11,%xmm11,%xmm11
 104eb25:	vmovd  -0x4d18d(%rip),%xmm12        # 10019a0 <__abi_tag+0x16a4>
 104eb2d:	vmovd  -0x4d145(%rip),%xmm13        # 10019f0 <__abi_tag+0x16f4>
 104eb35:	vmovd  -0x4d1bd(%rip),%xmm14        # 1001980 <__abi_tag+0x1684>
 104eb3d:	vmovd  -0x4d225(%rip),%xmm15        # 1001920 <__abi_tag+0x1624>
 104eb45:	xor    %ebx,%ebx
 104eb47:	movabs $0x4000000000000002,%rdi
 104eb51:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 104eb60:	mov    0x18(%rsp),%rdx
 104eb65:	add    %rbx,%rdx
 104eb68:	jo     1051367 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2927>
 104eb6e:	mov    0x30(%rsp),%rax
 104eb73:	mov    (%rax),%rsi
 104eb76:	mov    -0x10(%rsi),%rax
 104eb7a:	test   %rdi,%rax
 104eb7d:	jne    104eb90 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x150>
 104eb7f:	mov    -0x18(%rsi),%rcx
 104eb83:	inc    %rcx
 104eb86:	je     104f06f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x62f>
 104eb8c:	mov    %rcx,-0x18(%rsi)
 104eb90:	movzbl %dl,%r8d
 104eb94:	mov    (%rsi),%rdi
 104eb97:	lea    -0x10(%rdi),%r9
 104eb9b:	cmp    %r12,%r9
 104eb9e:	ja     104ebe0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1a0>
 104eba0:	mov    0x20(%rsi),%rcx
 104eba4:	movabs $0x80808080808080,%r10
 104ebae:	cmp    %r10,%rdi
 104ebb1:	ja     104ec10 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1d0>
 104ebb3:	vmovd  %edx,%xmm0
 104ebb7:	vpbroadcastb %xmm0,%xmm0
 104ebbc:	mov    %r9d,%r8d
 104ebbf:	not    %r8d
 104ebc2:	test   $0x30,%r8b
 104ebc6:	jne    104ed49 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x309>
 104ebcc:	vpxor  %xmm1,%xmm1,%xmm1
 104ebd0:	jmp    104eda0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x360>
 104ebd5:	data16 cs nopw 0x0(%rax,%rax,1)
 104ebe0:	test   %rdi,%rdi
 104ebe3:	jle    104ed41 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x301>
 104ebe9:	mov    0x20(%rsi),%rcx
 104ebed:	cmp    $0x8,%rdi
 104ebf1:	jae    104ec10 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1d0>
 104ebf3:	mov    $0x1,%r10d
 104ebf9:	xor    %r9d,%r9d
 104ebfc:	xor    %edx,%edx
 104ebfe:	xor    %r14d,%r14d
 104ec01:	jmp    104ecb7 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x277>
 104ec06:	cs nopw 0x0(%rax,%rax,1)
 104ec10:	mov    %rdi,%rdx
 104ec13:	and    $0xfffffffffffffff8,%rdx
 104ec17:	vmovq  %r8,%xmm0
 104ec1c:	vpbroadcastq %xmm0,%ymm3
 104ec21:	vpxor  %xmm2,%xmm2,%xmm2
 104ec25:	xor    %r9d,%r9d
 104ec28:	vpxor  %xmm4,%xmm4,%xmm4
 104ec2c:	vpxor  %xmm0,%xmm0,%xmm0
 104ec30:	vpxor  %xmm1,%xmm1,%xmm1
 104ec34:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 104ec40:	vpmovzxbq (%rcx,%r9,1),%ymm5
 104ec46:	vpmovzxbq 0x4(%rcx,%r9,1),%ymm6
 104ec4d:	vpxor  %ymm5,%ymm3,%ymm5
 104ec51:	vpxor  %ymm6,%ymm3,%ymm6
 104ec55:	vpaddq %ymm2,%ymm5,%ymm2
 104ec59:	vpaddq %ymm4,%ymm6,%ymm4
 104ec5d:	vpaddq %ymm0,%ymm5,%ymm0
 104ec61:	vpaddq %ymm1,%ymm6,%ymm1
 104ec65:	add    $0x8,%r9
 104ec69:	cmp    %r9,%rdx
 104ec6c:	jne    104ec40 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x200>
 104ec6e:	vpaddq %ymm2,%ymm4,%ymm2
 104ec72:	vextracti128 $0x1,%ymm2,%xmm3
 104ec78:	vpaddq %xmm3,%xmm2,%xmm2
 104ec7c:	vpshufd $0xee,%xmm2,%xmm3
 104ec81:	vpaddq %xmm3,%xmm2,%xmm2
 104ec85:	vmovq  %xmm2,%r9
 104ec8a:	vpaddq %ymm0,%ymm1,%ymm0
 104ec8e:	vextracti128 $0x1,%ymm0,%xmm1
 104ec94:	vpaddq %xmm1,%xmm0,%xmm0
 104ec98:	vpshufd $0xee,%xmm0,%xmm1
 104ec9d:	vpaddq %xmm1,%xmm0,%xmm0
 104eca1:	vmovq  %xmm0,%r14
 104eca6:	cmp    %rdx,%rdi
 104eca9:	jne    104ecb0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x270>
 104ecab:	mov    %rdi,%rcx
 104ecae:	jmp    104eced <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2ad>
 104ecb0:	mov    %rdx,%r10
 104ecb3:	or     $0x1,%r10
 104ecb7:	add    %rdx,%rcx
 104ecba:	mov    %rdi,%r11
 104ecbd:	sub    %rdx,%r11
 104ecc0:	xor    %edx,%edx
 104ecc2:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 104ecd0:	movzbl (%rcx,%rdx,1),%r13d
 104ecd5:	xor    %r8,%r13
 104ecd8:	add    %r13,%r9
 104ecdb:	add    %r13,%r14
 104ecde:	inc    %rdx
 104ece1:	cmp    %rdx,%r11
 104ece4:	jne    104ecd0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x290>
 104ece6:	lea    (%r10,%rdx,1),%rcx
 104ecea:	dec    %rcx
 104eced:	mov    $0xffffffff,%edx
 104ecf2:	cmp    %rdx,%rcx
 104ecf5:	setb   %cl
 104ecf8:	test   %r9,%r9
 104ecfb:	setns  %dl
 104ecfe:	test   %dl,%cl
 104ed00:	jne    104efb0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x570>
 104ed06:	mov    0x20(%rsi),%r9
 104ed0a:	xor    %r10d,%r10d
 104ed0d:	xor    %edx,%edx
 104ed0f:	xor    %r14d,%r14d
 104ed12:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 104ed20:	movzbl (%r9,%r10,1),%ecx
 104ed25:	xor    %r8,%rcx
 104ed28:	add    %rcx,%r14
 104ed2b:	jo     1051358 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2918>
 104ed31:	inc    %r10
 104ed34:	mov    %r14,%rdx
 104ed37:	cmp    %r10,%rdi
 104ed3a:	jne    104ed20 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2e0>
 104ed3c:	jmp    104efb0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x570>
 104ed41:	xor    %r14d,%r14d
 104ed44:	jmp    104efb0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x570>
 104ed49:	mov    %r9d,%r8d
 104ed4c:	shr    $0x4,%r8d
 104ed50:	inc    %r8d
 104ed53:	and    $0x3,%r8d
 104ed57:	vpxor  %xmm1,%xmm1,%xmm1
 104ed5b:	mov    %r8,%r10
 104ed5e:	mov    %rcx,%r11
 104ed61:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 104ed70:	vpxor  (%r11),%xmm0,%xmm2
 104ed75:	vpsadbw %xmm2,%xmm11,%xmm2
 104ed79:	vpaddq %xmm1,%xmm2,%xmm1
 104ed7d:	add    $0x10,%r11
 104ed81:	dec    %r10
 104ed84:	jne    104ed70 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x330>
 104ed86:	shl    $0x4,%r8d
 104ed8a:	add    %r8,%rcx
 104ed8d:	sub    %r8,%rdi
 104ed90:	cmp    $0x30,%r9
 104ed94:	jb     104ede1 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3a1>
 104ed96:	cs nopw 0x0(%rax,%rax,1)
 104eda0:	vpxor  (%rcx),%xmm0,%xmm2
 104eda4:	vpsadbw %xmm2,%xmm11,%xmm2
 104eda8:	vpaddq %xmm1,%xmm2,%xmm1
 104edac:	vpxor  0x10(%rcx),%xmm0,%xmm2
 104edb1:	vpsadbw %xmm2,%xmm11,%xmm2
 104edb5:	vpxor  0x20(%rcx),%xmm0,%xmm3
 104edba:	vpsadbw %xmm3,%xmm11,%xmm3
 104edbe:	vpaddq %xmm2,%xmm3,%xmm2
 104edc2:	vpaddq %xmm1,%xmm2,%xmm1
 104edc6:	vpxor  0x30(%rcx),%xmm0,%xmm2
 104edcb:	vpsadbw %xmm2,%xmm11,%xmm2
 104edcf:	vpaddq %xmm1,%xmm2,%xmm1
 104edd3:	add    $0x40,%rcx
 104edd7:	add    $0xffffffffffffffc0,%rdi
 104eddb:	cmp    $0xf,%rdi
 104eddf:	ja     104eda0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x360>
 104ede1:	vpshufd $0xee,%xmm1,%xmm0
 104ede6:	vpaddq %xmm0,%xmm1,%xmm0
 104edea:	vmovq  %xmm0,%r14
 104edef:	test   %rdi,%rdi
 104edf2:	je     104efb0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x570>
 104edf8:	mov    %rdi,%r11
 104edfb:	and    $0x3,%r11
 104edff:	je     104ee3d <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3fd>
 104ee01:	xor    %r8d,%r8d
 104ee04:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 104ee10:	movzbl (%rcx,%r8,1),%r9d
 104ee15:	xor    %dl,%r9b
 104ee18:	movzbl %r9b,%r9d
 104ee1c:	add    %r9,%r14
 104ee1f:	inc    %r8
 104ee22:	cmp    %r8,%r11
 104ee25:	jne    104ee10 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3d0>
 104ee27:	mov    %rdi,%r8
 104ee2a:	and    $0xfffffffffffffffc,%r8
 104ee2e:	lea    (%rcx,%r11,1),%r9
 104ee32:	cmp    $0x4,%rdi
 104ee36:	jae    104ee4d <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x40d>
 104ee38:	jmp    104efb0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x570>
 104ee3d:	mov    %rcx,%r9
 104ee40:	mov    %rdi,%r8
 104ee43:	cmp    $0x4,%rdi
 104ee47:	jb     104efb0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x570>
 104ee4d:	lea    -0x4(%r8),%rdi
 104ee51:	cmp    $0x1c,%rdi
 104ee55:	jb     104ef6b <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x52b>
 104ee5b:	shr    $0x2,%rdi
 104ee5f:	inc    %rdi
 104ee62:	mov    %rdi,%r10
 104ee65:	and    $0xfffffffffffffff8,%r10
 104ee69:	lea    0x0(,%r10,4),%r13
 104ee71:	lea    (%r9,%r10,4),%r9
 104ee75:	sub    %r13,%r8
 104ee78:	vmovq  %r14,%xmm1
 104ee7d:	vmovd  %edx,%xmm0
 104ee81:	vpbroadcastb %xmm0,%xmm0
 104ee86:	add    %r11,%rcx
 104ee89:	add    $0x10,%rcx
 104ee8d:	vpxor  %xmm2,%xmm2,%xmm2
 104ee91:	xor    %r11d,%r11d
 104ee94:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 104eea0:	vmovdqu -0x10(%rcx,%r11,4),%xmm3
 104eea7:	vmovdqu (%rcx,%r11,4),%xmm4
 104eead:	vpshufb %xmm12,%xmm3,%xmm5
 104eeb2:	vpshufb %xmm13,%xmm3,%xmm6
 104eeb7:	vpshufb %xmm14,%xmm3,%xmm7
 104eebc:	vpshufb %xmm15,%xmm3,%xmm3
 104eec1:	vpshufb %xmm12,%xmm4,%xmm8
 104eec6:	vpshufb %xmm13,%xmm4,%xmm9
 104eecb:	vpshufb %xmm14,%xmm4,%xmm10
 104eed0:	vpshufb %xmm15,%xmm4,%xmm4
 104eed5:	vpxor  %xmm0,%xmm5,%xmm5
 104eed9:	vpxor  %xmm0,%xmm8,%xmm8
 104eedd:	vpmovzxbq %xmm5,%ymm5
 104eee2:	vpaddq %ymm5,%ymm1,%ymm1
 104eee6:	vpmovzxbq %xmm8,%ymm5
 104eeeb:	vpaddq %ymm5,%ymm2,%ymm2
 104eeef:	vpxor  %xmm0,%xmm6,%xmm5
 104eef3:	vpxor  %xmm0,%xmm9,%xmm6
 104eef7:	vpmovzxbq %xmm5,%ymm5
 104eefc:	vpmovzxbq %xmm6,%ymm6
 104ef01:	vpxor  %xmm0,%xmm7,%xmm7
 104ef05:	vpxor  %xmm0,%xmm10,%xmm8
 104ef09:	vpmovzxbq %xmm7,%ymm7
 104ef0e:	vpaddq %ymm7,%ymm5,%ymm5
 104ef12:	vpaddq %ymm5,%ymm1,%ymm1
 104ef16:	vpmovzxbq %xmm8,%ymm5
 104ef1b:	vpaddq %ymm5,%ymm6,%ymm5
 104ef1f:	vpaddq %ymm5,%ymm2,%ymm2
 104ef23:	vpxor  %xmm0,%xmm3,%xmm3
 104ef27:	vpxor  %xmm0,%xmm4,%xmm4
 104ef2b:	vpmovzxbq %xmm3,%ymm3
 104ef30:	vpaddq %ymm3,%ymm1,%ymm1
 104ef34:	vpmovzxbq %xmm4,%ymm3
 104ef39:	vpaddq %ymm3,%ymm2,%ymm2
 104ef3d:	add    $0x8,%r11
 104ef41:	cmp    %r11,%r10
 104ef44:	jne    104eea0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x460>
 104ef4a:	vpaddq %ymm1,%ymm2,%ymm0
 104ef4e:	vextracti128 $0x1,%ymm0,%xmm1
 104ef54:	vpaddq %xmm1,%xmm0,%xmm0
 104ef58:	vpshufd $0xee,%xmm0,%xmm1
 104ef5d:	vpaddq %xmm1,%xmm0,%xmm0
 104ef61:	vmovq  %xmm0,%r14
 104ef66:	cmp    %r10,%rdi
 104ef69:	je     104efb0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x570>
 104ef6b:	vmovd  %edx,%xmm0
 104ef6f:	vpbroadcastb %xmm0,%xmm0
 104ef74:	xor    %ecx,%ecx
 104ef76:	cs nopw 0x0(%rax,%rax,1)
 104ef80:	vmovd  (%r9,%rcx,1),%xmm1
 104ef86:	vpxor  %xmm0,%xmm1,%xmm1
 104ef8a:	vpblendd $0x1,%xmm1,%xmm11,%xmm1
 104ef90:	vpsadbw %xmm1,%xmm11,%xmm1
 104ef94:	vmovq  %xmm1,%rdx
 104ef99:	add    %rdx,%r14
 104ef9c:	add    $0x4,%rcx
 104efa0:	cmp    %rcx,%r8
 104efa3:	jne    104ef80 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x540>
 104efa5:	data16 cs nopw 0x0(%rax,%rax,1)
 104efb0:	movabs $0x4000000000000002,%rdi
 104efba:	test   %rdi,%rax
 104efbd:	jne    104efd3 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x593>
 104efbf:	mov    -0x18(%rsi),%rax
 104efc3:	dec    %rax
 104efc6:	jne    104efcf <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x58f>
 104efc8:	cmpq   $0x0,-0x20(%rsi)
 104efcd:	je     104f023 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x5e3>
 104efcf:	mov    %rax,-0x18(%rsi)
 104efd3:	mov    %rbp,%rcx
 104efd6:	add    %r14,%rcx
 104efd9:	jo     105137e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x293e>
 104efdf:	mov    %rcx,%rax
 104efe2:	imul   %r15
 104efe5:	add    %rcx,%rdx
 104efe8:	mov    %rdx,%rax
 104efeb:	shr    $0x3f,%rax
 104efef:	sar    $0x1d,%rdx
 104eff3:	add    %rax,%rdx
 104eff6:	imul   $0x3b9aca07,%rdx,%rax
 104effd:	sub    %rax,%rcx
 104f000:	mov    %rcx,%rbp
 104f003:	sar    $0x3f,%rbp
 104f007:	and    $0x3b9aca07,%ebp
 104f00d:	add    %rcx,%rbp
 104f010:	inc    %rbx
 104f013:	cmp    0x20(%rsp),%rbx
 104f018:	jne    104eb60 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x120>
 104f01e:	jmp    104f251 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x811>
 104f023:	mov    0x10(%rsp),%r13
 104f028:	mov    %r13,%rdi
 104f02b:	vzeroupper
 104f02e:	call   1099bc0 <myl_rc_hold_edge_release>
 104f033:	mov    %r13,%rdi
 104f036:	call   109cbe0 <myl_rc_drain>
 104f03b:	vmovd  -0x4d723(%rip),%xmm15        # 1001920 <__abi_tag+0x1624>
 104f043:	vmovd  -0x4d6cb(%rip),%xmm14        # 1001980 <__abi_tag+0x1684>
 104f04b:	vmovd  -0x4d663(%rip),%xmm13        # 10019f0 <__abi_tag+0x16f4>
 104f053:	vmovd  -0x4d6bb(%rip),%xmm12        # 10019a0 <__abi_tag+0x16a4>
 104f05b:	vpxor  %xmm11,%xmm11,%xmm11
 104f060:	movabs $0x4000000000000002,%rdi
 104f06a:	jmp    104efd3 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x593>
 104f06f:	mov    $0x1007dbf,%esi
 104f074:	mov    0x8(%rsp),%rdi
 104f079:	vzeroupper
 104f07c:	call   108a6ee <fail>
 104f081:	vmovd  -0x4d769(%rip),%xmm15        # 1001920 <__abi_tag+0x1624>
 104f089:	vmovd  -0x4d711(%rip),%xmm14        # 1001980 <__abi_tag+0x1684>
 104f091:	vmovd  -0x4d6a9(%rip),%xmm13        # 10019f0 <__abi_tag+0x16f4>
 104f099:	vmovd  -0x4d701(%rip),%xmm12        # 10019a0 <__abi_tag+0x16a4>
 104f0a1:	vpxor  %xmm11,%xmm11,%xmm11
 104f0a6:	movabs $0x4000000000000002,%rdi
 104f0b0:	xor    %r14d,%r14d
 104f0b3:	jmp    104efd3 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x593>
 104f0b8:	mov    $0x10b95b0,%esi
 104f0bd:	mov    0x10(%rsp),%r14
 104f0c2:	mov    %r14,%rdi
 104f0c5:	mov    %ebp,%r12d
 104f0c8:	mov    %eax,%ebp
 104f0ca:	call   1099a60 <myl_rc_edge_release>
 104f0cf:	movq   $0x0,0xc8(%rsp)
 104f0db:	mov    %r14,%rdi
 104f0de:	call   109cbe0 <myl_rc_drain>
 104f0e3:	mov    %ebp,%eax
 104f0e5:	mov    %r12d,%ebp
 104f0e8:	test   %eax,%eax
 104f0ea:	mov    %r15,0x30(%rsp)
 104f0ef:	jne    104eb0a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xca>
 104f0f5:	movq   $0x10b90c0,0x40(%rsp)
 104f0fe:	movq   $0x10b90c0,0x70(%rsp)
 104f107:	movq   $0x10b90c0,0xc8(%rsp)
 104f113:	mov    $0x10b90c0,%esi
 104f118:	mov    %rbx,%rdi
 104f11b:	call   1091d30 <myl_native_text_equal>
 104f120:	movabs $0x4000000000000002,%rcx
 104f12a:	test   %rcx,0x69f7f(%rip)        # 10b90b0 <myl_lit_8c12e724a44132b907ad7be4d7bffd05d284ce5c644f94f5ab8dbc188941e631_instance>
 104f131:	jne    104f154 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x714>
 104f133:	mov    0x69f66(%rip),%rcx        # 10b90a0 <myl_lit_842ab9229ccb9156d5ed82c31992b7b48b2d840046545e9d568e989652f87fd6_instance+0x20>
 104f13a:	dec    %rcx
 104f13d:	jne    104f14d <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x70d>
 104f13f:	cmpq   $0x0,0x69f61(%rip)        # 10b90a8 <myl_lit_842ab9229ccb9156d5ed82c31992b7b48b2d840046545e9d568e989652f87fd6_instance+0x28>
 104f147:	je     104f269 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x829>
 104f14d:	mov    %rcx,0x69f4c(%rip)        # 10b90a0 <myl_lit_842ab9229ccb9156d5ed82c31992b7b48b2d840046545e9d568e989652f87fd6_instance+0x20>
 104f154:	test   %eax,%eax
 104f156:	je     104f28d <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x84d>
 104f15c:	mov    0x8(%r15),%rax
 104f160:	mov    0x18(%rsp),%rsi
 104f165:	and    $0x3,%esi
 104f168:	mov    (%rax),%rdx
 104f16b:	cmp    %rdx,%rsi
 104f16e:	jae    10513b2 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2972>
 104f174:	mov    0x10(%r15),%rcx
 104f178:	mov    (%rcx),%rdx
 104f17b:	cmp    %rdx,%rsi
 104f17e:	jae    10513bc <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x297c>
 104f184:	mov    0x20(%rax),%rax
 104f188:	shl    $0x3,%esi
 104f18b:	mov    (%rax,%rsi,1),%rdi
 104f18f:	mov    0x20(%rcx),%rax
 104f193:	mov    (%rax,%rsi,1),%rsi
 104f197:	call   1091d30 <myl_native_text_equal>
 104f19c:	mov    %eax,%ebp
 104f19e:	cmpq   $0x1,0x20(%rsp)
 104f1a4:	je     104f251 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x811>
 104f1aa:	mov    $0x1,%ebx
 104f1af:	movabs $0x89705f3112a28fe5,%r14
 104f1b9:	nopl   0x0(%rax)
 104f1c0:	mov    0x18(%rsp),%rsi
 104f1c5:	add    %rbx,%rsi
 104f1c8:	jo     10513c6 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2986>
 104f1ce:	mov    0x30(%rsp),%rcx
 104f1d3:	mov    0x8(%rcx),%rax
 104f1d7:	and    $0x3,%esi
 104f1da:	mov    (%rax),%rdx
 104f1dd:	cmp    %rdx,%rsi
 104f1e0:	jae    10513b2 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2972>
 104f1e6:	mov    0x10(%rcx),%rcx
 104f1ea:	mov    (%rcx),%rdx
 104f1ed:	cmp    %rdx,%rsi
 104f1f0:	jae    10513bc <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x297c>
 104f1f6:	mov    0x20(%rax),%rax
 104f1fa:	shl    $0x3,%esi
 104f1fd:	mov    (%rax,%rsi,1),%rdi
 104f201:	mov    0x20(%rcx),%rax
 104f205:	mov    (%rax,%rsi,1),%rsi
 104f209:	call   1091d30 <myl_native_text_equal>
 104f20e:	mov    %eax,%eax
 104f210:	add    %rax,%rbp
 104f213:	mov    %rbp,%rax
 104f216:	imul   %r14
 104f219:	add    %rbp,%rdx
 104f21c:	mov    %rdx,%rax
 104f21f:	shr    $0x3f,%rax
 104f223:	sar    $0x1d,%rdx
 104f227:	add    %rax,%rdx
 104f22a:	imul   $0x3b9aca07,%rdx,%rax
 104f231:	sub    %rax,%rbp
 104f234:	mov    %rbp,%rax
 104f237:	sar    $0x3f,%rax
 104f23b:	and    $0x3b9aca07,%eax
 104f240:	add    %rax,%rbp
 104f243:	inc    %rbx
 104f246:	cmp    %rbx,0x20(%rsp)
 104f24b:	jne    104f1c0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x780>
 104f251:	mov    %rbp,%rax
 104f254:	add    $0x258,%rsp
 104f25b:	pop    %rbx
 104f25c:	pop    %r12
 104f25e:	pop    %r13
 104f260:	pop    %r14
 104f262:	pop    %r15
 104f264:	pop    %rbp
 104f265:	vzeroupper
 104f268:	ret
 104f269:	lea    0xc8(%rsp),%rsi
 104f271:	mov    0x10(%rsp),%rdi
 104f276:	mov    %ebp,%r14d
 104f279:	mov    %eax,%ebp
 104f27b:	call   10861a0 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop>
 104f280:	mov    %ebp,%eax
 104f282:	mov    %r14d,%ebp
 104f285:	test   %eax,%eax
 104f287:	jne    104f15c <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x71c>
 104f28d:	movq   $0x10b8f10,0x70(%rsp)
 104f296:	movq   $0x10b8f10,0xc8(%rsp)
 104f2a2:	mov    $0x10b8f10,%esi
 104f2a7:	mov    %rbx,%rdi
 104f2aa:	call   1091d30 <myl_native_text_equal>
 104f2af:	movabs $0x4000000000000002,%rdi
 104f2b9:	test   %rdi,0x69c40(%rip)        # 10b8f00 <myl_lit_7afa21b5dfd0bec52f3c46b131c861acf738a60d12be67523b48ae28324a1934_instance>
 104f2c0:	jne    104f2e3 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x8a3>
 104f2c2:	mov    0x69c27(%rip),%rcx        # 10b8ef0 <myl_lit_7a43bb86b2bccf6ad7e922d1f9ee2e9c1abbad0e5e2f1aa80d1ed73fc964ae92_instance+0x20>
 104f2c9:	dec    %rcx
 104f2cc:	jne    104f2dc <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x89c>
 104f2ce:	cmpq   $0x0,0x69c22(%rip)        # 10b8ef8 <myl_lit_7a43bb86b2bccf6ad7e922d1f9ee2e9c1abbad0e5e2f1aa80d1ed73fc964ae92_instance+0x28>
 104f2d6:	je     104f4b3 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xa73>
 104f2dc:	mov    %rcx,0x69c0d(%rip)        # 10b8ef0 <myl_lit_7a43bb86b2bccf6ad7e922d1f9ee2e9c1abbad0e5e2f1aa80d1ed73fc964ae92_instance+0x20>
 104f2e3:	test   %eax,%eax
 104f2e5:	je     104f4e1 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xaa1>
 104f2eb:	xor    %ebp,%ebp
 104f2ed:	movabs $0x89705f3112a28fe5,%r13
 104f2f7:	xor    %ebx,%ebx
 104f2f9:	nopl   0x0(%rax)
 104f300:	mov    0x18(%rsp),%rsi
 104f305:	add    %rbx,%rsi
 104f308:	jo     10513da <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x299a>
 104f30e:	mov    0x30(%rsp),%rcx
 104f313:	mov    0x8(%rcx),%rax
 104f317:	cmpq   $0x0,(%rax)
 104f31b:	je     10513ee <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x29ae>
 104f321:	mov    0x20(%rax),%rax
 104f325:	mov    (%rax),%r14
 104f328:	test   %r14,%r14
 104f32b:	je     104f344 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x904>
 104f32d:	test   %rdi,-0x10(%r14)
 104f331:	jne    104f344 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x904>
 104f333:	mov    -0x18(%r14),%rax
 104f337:	inc    %rax
 104f33a:	je     1050aae <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x206e>
 104f340:	mov    %rax,-0x18(%r14)
 104f344:	mov    %r14,0x70(%rsp)
 104f349:	mov    0x10(%rcx),%rax
 104f34d:	and    $0x3,%esi
 104f350:	mov    (%rax),%rdx
 104f353:	cmp    %rdx,%rsi
 104f356:	jae    10513fc <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x29bc>
 104f35c:	mov    0x20(%rax),%rax
 104f360:	mov    (%rax,%rsi,8),%rax
 104f364:	mov    (%rax),%rcx
 104f367:	test   %rcx,%rcx
 104f36a:	je     104f3a0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x960>
 104f36c:	mov    $0xffffffffffffffff,%r15
 104f373:	cmp    (%r14),%rcx
 104f376:	ja     104f400 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x9c0>
 104f37c:	mov    0x10(%r14),%r12d
 104f380:	test   $0x4,%r12b
 104f384:	jne    104f3a5 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x965>
 104f386:	lea    0x18(%r14),%rdi
 104f38a:	testb  $0x4,0x10(%rax)
 104f38e:	je     104f3bb <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x97b>
 104f390:	mov    0x18(%rax),%rcx
 104f394:	mov    0x14(%rax),%edx
 104f397:	add    %rcx,%rdx
 104f39a:	add    $0x18,%rdx
 104f39e:	jmp    104f3bf <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x97f>
 104f3a0:	xor    %r15d,%r15d
 104f3a3:	jmp    104f400 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x9c0>
 104f3a5:	mov    0x18(%r14),%rcx
 104f3a9:	mov    0x14(%r14),%edx
 104f3ad:	lea    (%rcx,%rdx,1),%rdi
 104f3b1:	add    $0x18,%rdi
 104f3b5:	testb  $0x4,0x10(%rax)
 104f3b9:	jne    104f390 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x950>
 104f3bb:	lea    0x18(%rax),%rdx
 104f3bf:	mov    0x8(%r14),%rsi
 104f3c3:	mov    0x8(%rax),%rcx
 104f3c7:	call   1091e30 <myl_native_octets_find>
 104f3cc:	cmp    $0xffffffffffffffff,%rax
 104f3d0:	movabs $0x4000000000000002,%rdi
 104f3da:	je     104f400 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x9c0>
 104f3dc:	test   $0x1,%r12b
 104f3e0:	jne    104f3f7 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x9b7>
 104f3e2:	mov    %r14,%rdi
 104f3e5:	mov    %rax,%rsi
 104f3e8:	call   108f7d0 <index_walk>
 104f3ed:	movabs $0x4000000000000002,%rdi
 104f3f7:	mov    %rax,%r15
 104f3fa:	nopw   0x0(%rax,%rax,1)
 104f400:	mov    %r15,%r12
 104f403:	inc    %r12
 104f406:	jo     1051406 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x29c6>
 104f40c:	test   %r14,%r14
 104f40f:	je     104f42b <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x9eb>
 104f411:	test   %rdi,-0x10(%r14)
 104f415:	jne    104f42b <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x9eb>
 104f417:	mov    -0x18(%r14),%rax
 104f41b:	dec    %rax
 104f41e:	jne    104f427 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x9e7>
 104f420:	cmpq   $0x0,-0x20(%r14)
 104f425:	je     104f477 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xa37>
 104f427:	mov    %rax,-0x18(%r14)
 104f42b:	mov    %rbp,%rcx
 104f42e:	add    %r12,%rcx
 104f431:	jo     104f4a1 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xa61>
 104f433:	mov    %rcx,%rax
 104f436:	imul   %r13
 104f439:	add    %rcx,%rdx
 104f43c:	mov    %rdx,%rax
 104f43f:	shr    $0x3f,%rax
 104f443:	sar    $0x1d,%rdx
 104f447:	add    %rax,%rdx
 104f44a:	imul   $0x3b9aca07,%rdx,%rax
 104f451:	sub    %rax,%rcx
 104f454:	mov    %rcx,%rbp
 104f457:	sar    $0x3f,%rbp
 104f45b:	and    $0x3b9aca07,%ebp
 104f461:	add    %rcx,%rbp
 104f464:	inc    %rbx
 104f467:	cmp    %rbx,0x20(%rsp)
 104f46c:	jne    104f300 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x8c0>
 104f472:	jmp    104f251 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x811>
 104f477:	mov    0x10(%rsp),%r15
 104f47c:	mov    %r15,%rdi
 104f47f:	mov    %r14,%rsi
 104f482:	call   1099bc0 <myl_rc_hold_edge_release>
 104f487:	mov    %r15,%rdi
 104f48a:	call   109cbe0 <myl_rc_drain>
 104f48f:	movabs $0x4000000000000002,%rdi
 104f499:	mov    %rbp,%rcx
 104f49c:	add    %r12,%rcx
 104f49f:	jno    104f433 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x9f3>
 104f4a1:	mov    0x8(%rsp),%rdi
 104f4a6:	xor    %esi,%esi
 104f4a8:	mov    %rbp,%rdx
 104f4ab:	mov    %r12,%rcx
 104f4ae:	call   108b100 <myl_qbe_fail_overflow_op>
 104f4b3:	lea    0xc8(%rsp),%rsi
 104f4bb:	mov    0x10(%rsp),%rdi
 104f4c0:	mov    %ebp,%r14d
 104f4c3:	mov    %eax,%ebp
 104f4c5:	call   10861a0 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop>
 104f4ca:	movabs $0x4000000000000002,%rdi
 104f4d4:	mov    %ebp,%eax
 104f4d6:	mov    %r14d,%ebp
 104f4d9:	test   %eax,%eax
 104f4db:	jne    104f2eb <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x8ab>
 104f4e1:	movq   $0x10b8b98,0x40(%rsp)
 104f4ea:	movq   $0x10b8b98,0x70(%rsp)
 104f4f3:	movq   $0x10b8b98,0xc8(%rsp)
 104f4ff:	mov    $0x10b8b98,%esi
 104f504:	mov    %rbx,%rdi
 104f507:	call   1091d30 <myl_native_text_equal>
 104f50c:	movabs $0x4000000000000002,%rcx
 104f516:	test   %rcx,0x6966b(%rip)        # 10b8b88 <myl_lit_4d6ff6f7284ab5ea56c67ebc627dbe0fd0bb153a04fdd105bd867658d486b6d7_instance>
 104f51d:	jne    104f540 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xb00>
 104f51f:	mov    0x69652(%rip),%rcx        # 10b8b78 <myl_lit_4b4df4d43798003d79847faa0fc7a8aff0b04bace93d5fc2cc109ef7308827f6_instance+0x38>
 104f526:	dec    %rcx
 104f529:	jne    104f539 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xaf9>
 104f52b:	cmpq   $0x0,0x6964d(%rip)        # 10b8b80 <myl_lit_4b4df4d43798003d79847faa0fc7a8aff0b04bace93d5fc2cc109ef7308827f6_instance+0x40>
 104f533:	je     10506cc <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1c8c>
 104f539:	mov    %rcx,0x69638(%rip)        # 10b8b78 <myl_lit_4b4df4d43798003d79847faa0fc7a8aff0b04bace93d5fc2cc109ef7308827f6_instance+0x38>
 104f540:	test   %eax,%eax
 104f542:	je     10506f0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1cb0>
 104f548:	mov    %ebp,0x2c(%rsp)
 104f54c:	movabs $0x5000000000000000,%rdi
 104f556:	lea    0x40(%rsp),%rdx
 104f55b:	lea    0x70(%rsp),%rsi
 104f560:	mov    %rsi,%rax
 104f563:	sub    %rdx,%rax
 104f566:	sub    %rsi,%rdx
 104f569:	cmovb  %rax,%rdx
 104f56d:	mov    %rdx,0x120(%rsp)
 104f575:	lea    0x68(%rsp),%rdx
 104f57a:	lea    0x60(%rsp),%rcx
 104f57f:	mov    %rcx,%rax
 104f582:	sub    %rdx,%rax
 104f585:	sub    %rcx,%rdx
 104f588:	cmovb  %rax,%rdx
 104f58c:	mov    %rdx,0x178(%rsp)
 104f594:	xor    %ecx,%ecx
 104f596:	lea    0x1(%rdi),%rax
 104f59a:	mov    %rax,0xf0(%rsp)
 104f5a2:	vpbroadcastd -0x48427(%rip),%xmm9        # 1007184 <__abi_tag+0x6e88>
 104f5ab:	vpbroadcastd -0x48430(%rip),%ymm10        # 1007184 <__abi_tag+0x6e88>
 104f5b4:	vpbroadcastq -0x484a5(%rip),%ymm0        # 1007118 <__abi_tag+0x6e1c>
 104f5bd:	vmovdqu %ymm0,0x1f0(%rsp)
 104f5c6:	xor    %ebp,%ebp
 104f5c8:	vmovdqa %xmm9,0x50(%rsp)
 104f5ce:	vmovdqu %ymm10,0x100(%rsp)
 104f5d7:	nopw   0x0(%rax,%rax,1)
 104f5e0:	mov    0x18(%rsp),%rsi
 104f5e5:	add    %rcx,%rsi
 104f5e8:	jo     105142f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x29ef>
 104f5ee:	mov    %rcx,0x190(%rsp)
 104f5f6:	mov    0x30(%rsp),%rax
 104f5fb:	mov    0x8(%rax),%rax
 104f5ff:	and    $0x1,%esi
 104f602:	mov    (%rax),%rdx
 104f605:	cmp    %rdx,%rsi
 104f608:	jae    1051422 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x29e2>
 104f60e:	mov    0x20(%rax),%rax
 104f612:	mov    (%rax,%rsi,8),%rbx
 104f616:	test   %rsi,%rsi
 104f619:	jne    104f6c0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xc80>
 104f61f:	movq   $0x10b98b0,0x70(%rsp)
 104f628:	movq   $0x10b98b0,0xc8(%rsp)
 104f634:	movq   $0x10b98b0,0x40(%rsp)
 104f63d:	mov    0x6a25c(%rip),%rax        # 10b98a0 <myl_lit_f3eaad558815542caf7da2bdfda9d4cabeaf9c2200b79ab8ff85b21b8470fac6_instance>
 104f644:	test   %rax,0xf0(%rsp)
 104f64c:	je     104f755 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xd15>
 104f652:	cmpq   $0x0,0x120(%rsp)
 104f65b:	setne  %cl
 104f65e:	movabs $0x5000000000000000,%rdx
 104f668:	test   %rdx,%rax
 104f66b:	sete   %dl
 104f66e:	mov    $0x10b98b0,%eax
 104f673:	test   %cl,%dl
 104f675:	jne    104f750 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xd10>
 104f67b:	mov    $0x1030c78,%esi
 104f680:	mov    0x10(%rsp),%rdi
 104f685:	lea    0x70(%rsp),%rdx
 104f68a:	lea    0x40(%rsp),%rcx
 104f68f:	mov    0x2c(%rsp),%r8d
 104f694:	vzeroupper
 104f697:	call   10a6000 <myl_rc_native_take>
 104f69c:	vmovdqu 0x100(%rsp),%ymm10
 104f6a5:	vmovdqa 0x50(%rsp),%xmm9
 104f6ab:	test   %eax,%eax
 104f6ad:	jne    104f75e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xd1e>
 104f6b3:	jmp    1050664 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1c24>
 104f6b8:	nopl   0x0(%rax,%rax,1)
 104f6c0:	movq   $0x10b8c20,0x70(%rsp)
 104f6c9:	movq   $0x10b8c20,0xc8(%rsp)
 104f6d5:	movq   $0x10b8c20,0x40(%rsp)
 104f6de:	mov    0x6952b(%rip),%rax        # 10b8c10 <myl_lit_54807ae7ae90f7f8ab8705f04b17dcd2d77e7355f27b7f7252156b0c234f7d3f_instance>
 104f6e5:	test   %rax,0xf0(%rsp)
 104f6ed:	je     104f755 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xd15>
 104f6ef:	cmpq   $0x0,0x120(%rsp)
 104f6f8:	setne  %cl
 104f6fb:	movabs $0x5000000000000000,%rdx
 104f705:	test   %rdx,%rax
 104f708:	sete   %dl
 104f70b:	mov    $0x10b8c20,%eax
 104f710:	test   %cl,%dl
 104f712:	jne    104f750 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xd10>
 104f714:	mov    $0x1030c78,%esi
 104f719:	mov    0x10(%rsp),%rdi
 104f71e:	lea    0x70(%rsp),%rdx
 104f723:	lea    0x40(%rsp),%rcx
 104f728:	mov    0x2c(%rsp),%r8d
 104f72d:	vzeroupper
 104f730:	call   10a6000 <myl_rc_native_take>
 104f735:	vmovdqu 0x100(%rsp),%ymm10
 104f73e:	vmovdqa 0x50(%rsp),%xmm9
 104f744:	test   %eax,%eax
 104f746:	jne    104f75e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xd1e>
 104f748:	jmp    1050698 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1c58>
 104f74d:	nopl   (%rax)
 104f750:	mov    %rax,0x70(%rsp)
 104f755:	movq   $0x0,0x40(%rsp)
 104f75e:	mov    0x70(%rsp),%rdx
 104f763:	movq   $0x0,0x250(%rsp)
 104f76f:	movq   $0x0,0x230(%rsp)
 104f77b:	mov    0x8(%rsp),%rax
 104f780:	cmp    %rsp,0x40(%rax)
 104f784:	ja     1051443 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2a03>
 104f78a:	cmpq   $0x0,(%rdx)
 104f78e:	je     1051450 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2a10>
 104f794:	mov    0x8(%rsp),%rax
 104f799:	mov    0x2c8(%rax),%eax
 104f79f:	mov    %rbx,0xc0(%rsp)
 104f7a7:	mov    %rdx,0x130(%rsp)
 104f7af:	testb  $0x4,0x10(%rbx)
 104f7b3:	mov    %eax,0xfc(%rsp)
 104f7ba:	jne    104f7e0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xda0>
 104f7bc:	lea    0x18(%rbx),%r14
 104f7c0:	testb  $0x4,0x10(%rdx)
 104f7c4:	je     104f7f5 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xdb5>
 104f7c6:	mov    0x18(%rdx),%rax
 104f7ca:	mov    0x14(%rdx),%ecx
 104f7cd:	lea    (%rax,%rcx,1),%r12
 104f7d1:	add    $0x18,%r12
 104f7d5:	jmp    104f7f9 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xdb9>
 104f7d7:	nopw   0x0(%rax,%rax,1)
 104f7e0:	mov    0x18(%rbx),%rax
 104f7e4:	mov    0x14(%rbx),%ecx
 104f7e7:	lea    (%rax,%rcx,1),%r14
 104f7eb:	add    $0x18,%r14
 104f7ef:	testb  $0x4,0x10(%rdx)
 104f7f3:	jne    104f7c6 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xd86>
 104f7f5:	lea    0x18(%rdx),%r12
 104f7f9:	mov    0x8(%rdx),%rcx
 104f7fd:	mov    0x8(%rbx),%r15
 104f801:	lea    -0x1(%rcx),%rax
 104f805:	cmp    %r15,%rax
 104f808:	mov    %rcx,0x38(%rsp)
 104f80d:	mov    %rdx,0x188(%rsp)
 104f815:	jae    104fa10 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xfd0>
 104f81b:	cmp    $0x1,%rcx
 104f81f:	jne    104fa20 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xfe0>
 104f825:	mov    %rcx,%r13
 104f828:	movzbl (%r12),%eax
 104f82d:	vmovd  %eax,%xmm0
 104f831:	vpbroadcastb %xmm0,%xmm0
 104f836:	lea    0x18(%r14),%rcx
 104f83a:	xor    %ebx,%ebx
 104f83c:	xor    %edx,%edx
 104f83e:	mov    $0x10000,%r11d
 104f844:	jmp    104f862 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xe22>
 104f846:	cs nopw 0x0(%rax,%rax,1)
 104f850:	mov    %r9d,%edi
 104f853:	add    %rdi,%rbx
 104f856:	add    %rsi,%rdx
 104f859:	cmp    %r15,%rdx
 104f85c:	jae    104fa6b <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x102b>
 104f862:	mov    %r15,%rsi
 104f865:	sub    %rdx,%rsi
 104f868:	cmp    $0x10000,%rsi
 104f86f:	cmovae %r11,%rsi
 104f873:	mov    %r15,%r8
 104f876:	sub    %rdx,%r8
 104f879:	jne    104f890 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xe50>
 104f87b:	xor    %edi,%edi
 104f87d:	add    %rdi,%rbx
 104f880:	add    %rsi,%rdx
 104f883:	cmp    %r15,%rdx
 104f886:	jb     104f862 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xe22>
 104f888:	jmp    104fa6b <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x102b>
 104f88d:	nopl   (%rax)
 104f890:	lea    (%r14,%rdx,1),%rdi
 104f894:	cmp    $0x3,%r8
 104f898:	ja     104f8b0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xe70>
 104f89a:	xor    %r8d,%r8d
 104f89d:	xor    %r9d,%r9d
 104f8a0:	jmp    104f9f0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xfb0>
 104f8a5:	data16 cs nopw 0x0(%rax,%rax,1)
 104f8b0:	cmp    $0x20,%r8
 104f8b4:	jae    104f8c1 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xe81>
 104f8b6:	xor    %r8d,%r8d
 104f8b9:	xor    %r9d,%r9d
 104f8bc:	jmp    104f994 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xf54>
 104f8c1:	mov    %esi,%r8d
 104f8c4:	and    $0x1ffe0,%r8d
 104f8cb:	lea    (%rcx,%rdx,1),%r9
 104f8cf:	vpxor  %xmm1,%xmm1,%xmm1
 104f8d3:	xor    %r10d,%r10d
 104f8d6:	vpxor  %xmm2,%xmm2,%xmm2
 104f8da:	vpxor  %xmm3,%xmm3,%xmm3
 104f8de:	vpxor  %xmm4,%xmm4,%xmm4
 104f8e2:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 104f8f0:	vmovq  -0x18(%r9,%r10,1),%xmm5
 104f8f7:	vmovq  -0x10(%r9,%r10,1),%xmm6
 104f8fe:	vmovq  -0x8(%r9,%r10,1),%xmm7
 104f905:	vmovq  (%r9,%r10,1),%xmm8
 104f90b:	vpcmpeqb %xmm0,%xmm5,%xmm5
 104f90f:	vpmovzxbd %xmm5,%ymm5
 104f914:	vpand  %ymm5,%ymm10,%ymm5
 104f918:	vpaddd %ymm5,%ymm1,%ymm1
 104f91c:	vpcmpeqb %xmm0,%xmm6,%xmm5
 104f920:	vpmovzxbd %xmm5,%ymm5
 104f925:	vpand  %ymm5,%ymm10,%ymm5
 104f929:	vpaddd %ymm5,%ymm2,%ymm2
 104f92d:	vpcmpeqb %xmm0,%xmm7,%xmm5
 104f931:	vpmovzxbd %xmm5,%ymm5
 104f936:	vpand  %ymm5,%ymm10,%ymm5
 104f93a:	vpaddd %ymm5,%ymm3,%ymm3
 104f93e:	vpcmpeqb %xmm0,%xmm8,%xmm5
 104f942:	vpmovzxbd %xmm5,%ymm5
 104f947:	vpand  %ymm5,%ymm10,%ymm5
 104f94b:	vpaddd %ymm5,%ymm4,%ymm4
 104f94f:	add    $0x20,%r10
 104f953:	cmp    %r10,%r8
 104f956:	jne    104f8f0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xeb0>
 104f958:	vpaddd %ymm1,%ymm2,%ymm1
 104f95c:	vpaddd %ymm1,%ymm3,%ymm1
 104f960:	vpaddd %ymm1,%ymm4,%ymm1
 104f964:	vextracti128 $0x1,%ymm1,%xmm2
 104f96a:	vpaddd %xmm2,%xmm1,%xmm1
 104f96e:	vpshufd $0xee,%xmm1,%xmm2
 104f973:	vpaddd %xmm2,%xmm1,%xmm1
 104f977:	vpshufd $0x55,%xmm1,%xmm2
 104f97c:	vpaddd %xmm2,%xmm1,%xmm1
 104f980:	vmovd  %xmm1,%r9d
 104f985:	cmp    %r8,%rsi
 104f988:	je     104f850 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xe10>
 104f98e:	test   $0x1c,%sil
 104f992:	je     104f9f0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xfb0>
 104f994:	mov    %r8,%r10
 104f997:	mov    %esi,%r8d
 104f99a:	and    $0x1fffc,%r8d
 104f9a1:	vmovd  %r9d,%xmm1
 104f9a6:	cs nopw 0x0(%rax,%rax,1)
 104f9b0:	vmovd  (%rdi,%r10,1),%xmm2
 104f9b6:	vpcmpeqb %xmm0,%xmm2,%xmm2
 104f9ba:	vpmovzxbd %xmm2,%xmm2
 104f9bf:	vpand  %xmm2,%xmm9,%xmm2
 104f9c3:	vpaddd %xmm2,%xmm1,%xmm1
 104f9c7:	add    $0x4,%r10
 104f9cb:	cmp    %r10,%r8
 104f9ce:	jne    104f9b0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xf70>
 104f9d0:	vpshufd $0xee,%xmm1,%xmm2
 104f9d5:	vpaddd %xmm2,%xmm1,%xmm1
 104f9d9:	vpshufd $0x55,%xmm1,%xmm2
 104f9de:	vpaddd %xmm2,%xmm1,%xmm1
 104f9e2:	vmovd  %xmm1,%r9d
 104f9e7:	jmp    104fa01 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xfc1>
 104f9e9:	nopl   0x0(%rax)
 104f9f0:	xor    %r10d,%r10d
 104f9f3:	cmp    %al,(%rdi,%r8,1)
 104f9f7:	sete   %r10b
 104f9fb:	add    %r10d,%r9d
 104f9fe:	inc    %r8
 104fa01:	cmp    %r8,%rsi
 104fa04:	jne    104f9f0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xfb0>
 104fa06:	jmp    104f850 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xe10>
 104fa0b:	nopl   0x0(%rax,%rax,1)
 104fa10:	mov    %rcx,%r13
 104fa13:	xor    %ebx,%ebx
 104fa15:	jmp    104fa6b <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x102b>
 104fa17:	nopw   0x0(%rax,%rax,1)
 104fa20:	mov    %r14,%rdi
 104fa23:	mov    %r15,%rsi
 104fa26:	mov    %r12,%rdx
 104fa29:	vzeroupper
 104fa2c:	call   1091e30 <myl_native_octets_find>
 104fa31:	xor    %ebx,%ebx
 104fa33:	xor    %r13d,%r13d
 104fa36:	cmp    $0xffffffffffffffff,%rax
 104fa3a:	je     104fa66 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1026>
 104fa3c:	nopl   0x0(%rax)
 104fa40:	mov    0x38(%rsp),%rcx
 104fa45:	add    %rcx,%r13
 104fa48:	add    %rax,%r13
 104fa4b:	inc    %rbx
 104fa4e:	lea    (%r14,%r13,1),%rdi
 104fa52:	mov    %r15,%rsi
 104fa55:	sub    %r13,%rsi
 104fa58:	mov    %r12,%rdx
 104fa5b:	call   1091e30 <myl_native_octets_find>
 104fa60:	cmp    $0xffffffffffffffff,%rax
 104fa64:	jne    104fa40 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1000>
 104fa66:	mov    0x38(%rsp),%r13
 104fa6b:	inc    %rbx
 104fa6e:	mov    0x8(%rsp),%r14
 104fa73:	mov    0x268(%r14),%rax
 104fa7a:	mov    %rax,0x1a8(%rsp)
 104fa82:	lea    0xc0(%rsp),%rax
 104fa8a:	mov    %rax,0x1b0(%rsp)
 104fa92:	movq   $0x1031628,0x1b8(%rsp)
 104fa9e:	lea    0x1a8(%rsp),%rax
 104faa6:	mov    %rax,0x158(%rsp)
 104faae:	lea    0x130(%rsp),%rax
 104fab6:	mov    %rax,0x160(%rsp)
 104fabe:	movq   $0x1031628,0x168(%rsp)
 104faca:	lea    0x158(%rsp),%rax
 104fad2:	mov    %rax,0x268(%r14)
 104fad9:	mov    $0x1031628,%esi
 104fade:	mov    0x10(%rsp),%rdi
 104fae3:	mov    %rbx,%rdx
 104fae6:	vzeroupper
 104fae9:	call   108de70 <myl_native_list_new>
 104faee:	mov    %rax,%rsi
 104faf1:	mov    %rax,0xb8(%rsp)
 104faf9:	mov    0x268(%r14),%rax
 104fb00:	mov    %rax,0x138(%rsp)
 104fb08:	lea    0xb8(%rsp),%rax
 104fb10:	mov    %rax,0x140(%rsp)
 104fb18:	movq   $0x1031628,0x148(%rsp)
 104fb24:	lea    0x138(%rsp),%rax
 104fb2c:	mov    %rax,0x268(%r14)
 104fb33:	test   %rsi,%rsi
 104fb36:	je     1050050 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1610>
 104fb3c:	mov    0xc0(%rsp),%r14
 104fb44:	mov    0x10(%r14),%ecx
 104fb48:	lea    0x18(%r14),%rax
 104fb4c:	mov    %rax,0xb0(%rsp)
 104fb54:	mov    %ecx,0xac(%rsp)
 104fb5b:	test   $0x4,%cl
 104fb5e:	movabs $0x4000000000000002,%rdi
 104fb68:	vmovdqa -0x4e140(%rip),%xmm8        # 1001a30 <__abi_tag+0x1734>
 104fb70:	vmovdqu 0x1f0(%rsp),%ymm9
 104fb79:	vmovdqa -0x4e151(%rip),%xmm10        # 1001a30 <__abi_tag+0x1734>
 104fb81:	je     104fb9a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x115a>
 104fb83:	mov    0x18(%r14),%rcx
 104fb87:	mov    0x14(%r14),%edx
 104fb8b:	add    %rdx,%rcx
 104fb8e:	add    $0x18,%rcx
 104fb92:	mov    %rcx,0xb0(%rsp)
 104fb9a:	mov    0x130(%rsp),%rcx
 104fba2:	testb  $0x4,0x10(%rcx)
 104fba6:	jne    104fbd0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1190>
 104fba8:	add    $0x18,%rcx
 104fbac:	mov    %rcx,0x128(%rsp)
 104fbb4:	mov    %r14,%rcx
 104fbb7:	testb  $0x4,0xac(%rsp)
 104fbbf:	jne    104fbf6 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x11b6>
 104fbc1:	jmp    104fbf9 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x11b9>
 104fbc3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 104fbd0:	mov    %rcx,%rdx
 104fbd3:	mov    0x18(%rcx),%rcx
 104fbd7:	mov    0x14(%rdx),%edx
 104fbda:	add    %rdx,%rcx
 104fbdd:	add    $0x18,%rcx
 104fbe1:	mov    %rcx,0x128(%rsp)
 104fbe9:	mov    %r14,%rcx
 104fbec:	testb  $0x4,0xac(%rsp)
 104fbf4:	je     104fbf9 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x11b9>
 104fbf6:	mov    (%rax),%rcx
 104fbf9:	mov    0x8(%rcx),%rcx
 104fbfd:	shr    $0x2,%rcx
 104fc01:	cmp    $0xa,%rcx
 104fc05:	mov    $0x9,%eax
 104fc0a:	cmovb  %rax,%rcx
 104fc0e:	mov    %rcx,0x1a0(%rsp)
 104fc16:	mov    0xb0(%rsp),%rax
 104fc1e:	add    $0xc,%rax
 104fc22:	mov    %rax,0x180(%rsp)
 104fc2a:	xor    %r8d,%r8d
 104fc2d:	mov    %r13,%rcx
 104fc30:	cmp    $0x1,%rbx
 104fc34:	je     104fcf0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x12b0>
 104fc3a:	nopw   0x0(%rax,%rax,1)
 104fc40:	test   %rbx,%rbx
 104fc43:	mov    0xb0(%rsp),%r13
 104fc4b:	je     1050102 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x16c2>
 104fc51:	lea    (%r8,%r13,1),%rdi
 104fc55:	mov    0x8(%r14),%r15
 104fc59:	mov    %r15,%rsi
 104fc5c:	sub    %r8,%rsi
 104fc5f:	mov    0x128(%rsp),%rdx
 104fc67:	mov    %r8,%r12
 104fc6a:	vzeroupper
 104fc6d:	call   1091e30 <myl_native_octets_find>
 104fc72:	mov    %r12,%r8
 104fc75:	vmovdqa -0x4e24d(%rip),%xmm10        # 1001a30 <__abi_tag+0x1734>
 104fc7d:	vmovdqu 0x1f0(%rsp),%ymm9
 104fc86:	vmovdqa -0x4e25e(%rip),%xmm8        # 1001a30 <__abi_tag+0x1734>
 104fc8e:	add    %rax,%r12
 104fc91:	cmp    $0xffffffffffffffff,%rax
 104fc95:	cmove  %r15,%r12
 104fc99:	mov    %r12,%r15
 104fc9c:	sub    %r8,%r15
 104fc9f:	cmp    0x1a0(%rsp),%r15
 104fca7:	jb     104fd0c <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x12cc>
 104fca9:	mov    0x10(%rsp),%rdi
 104fcae:	mov    %r14,%rsi
 104fcb1:	mov    %r8,%rdx
 104fcb4:	mov    %r15,%rcx
 104fcb7:	mov    $0xffffffffffffffff,%r8
 104fcbe:	vzeroupper
 104fcc1:	call   1090730 <long_piece>
 104fcc6:	mov    %rax,%r13
 104fcc9:	test   %rax,%rax
 104fccc:	movabs $0x4000000000000002,%rdi
 104fcd6:	jne    104ffd0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1590>
 104fcdc:	jmp    1050061 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1621>
 104fce1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 104fcf0:	mov    0x8(%r14),%r12
 104fcf4:	mov    0xb0(%rsp),%r13
 104fcfc:	mov    %r12,%r15
 104fcff:	sub    %r8,%r15
 104fd02:	cmp    0x1a0(%rsp),%r15
 104fd0a:	jae    104fca9 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1269>
 104fd0c:	lea    (%r8,%r13,1),%rsi
 104fd10:	testb  $0x1,0xac(%rsp)
 104fd18:	movabs $0x101010101010101,%rdi
 104fd22:	jne    104feff <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x14bf>
 104fd28:	cmp    $0x8,%r15
 104fd2c:	jae    104fd40 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1300>
 104fd2e:	xor    %ecx,%ecx
 104fd30:	xor    %eax,%eax
 104fd32:	jmp    104fd86 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1346>
 104fd34:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 104fd40:	xor    %edx,%edx
 104fd42:	xor    %ecx,%ecx
 104fd44:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 104fd50:	mov    (%rsi,%rdx,1),%rax
 104fd54:	mov    %rax,%r9
 104fd57:	not    %r9
 104fd5a:	add    %r9,%r9
 104fd5d:	and    %rax,%r9
 104fd60:	shr    $0x7,%r9
 104fd64:	and    %rdi,%r9
 104fd67:	imul   %rdi,%r9
 104fd6b:	shr    $0x38,%r9
 104fd6f:	sub    %r9,%rcx
 104fd72:	add    $0x8,%rcx
 104fd76:	lea    0x8(%rdx),%rax
 104fd7a:	add    $0x10,%rdx
 104fd7e:	cmp    %r15,%rdx
 104fd81:	mov    %rax,%rdx
 104fd84:	jbe    104fd50 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1310>
 104fd86:	cmp    %r15,%rax
 104fd89:	jae    104fef6 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x14b6>
 104fd8f:	lea    (%rax,%r8,1),%rdi
 104fd93:	mov    %r12,%rdx
 104fd96:	sub    %rdi,%rdx
 104fd99:	cmp    $0x3,%rdx
 104fd9d:	jbe    104fed1 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1491>
 104fda3:	cmp    $0x10,%rdx
 104fda7:	jae    104fdb1 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1371>
 104fda9:	xor    %r9d,%r9d
 104fdac:	jmp    104fe7e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x143e>
 104fdb1:	mov    %rdx,%r9
 104fdb4:	and    $0xfffffffffffffff0,%r9
 104fdb8:	vmovq  %rcx,%xmm0
 104fdbd:	add    0x180(%rsp),%rdi
 104fdc5:	vpxor  %xmm1,%xmm1,%xmm1
 104fdc9:	xor    %ecx,%ecx
 104fdcb:	vpxor  %xmm2,%xmm2,%xmm2
 104fdcf:	vpxor  %xmm3,%xmm3,%xmm3
 104fdd3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 104fde0:	vmovd  -0xc(%rdi,%rcx,1),%xmm4
 104fde6:	vmovd  -0x8(%rdi,%rcx,1),%xmm5
 104fdec:	vmovd  -0x4(%rdi,%rcx,1),%xmm6
 104fdf2:	vmovd  (%rdi,%rcx,1),%xmm7
 104fdf7:	vpcmpgtb %xmm10,%xmm4,%xmm4
 104fdfc:	vpmovzxbq %xmm4,%ymm4
 104fe01:	vpand  %ymm4,%ymm9,%ymm4
 104fe05:	vpaddq %ymm4,%ymm0,%ymm0
 104fe09:	vpcmpgtb %xmm10,%xmm5,%xmm4
 104fe0e:	vpmovzxbq %xmm4,%ymm4
 104fe13:	vpand  %ymm4,%ymm9,%ymm4
 104fe17:	vpaddq %ymm4,%ymm1,%ymm1
 104fe1b:	vpcmpgtb %xmm10,%xmm6,%xmm4
 104fe20:	vpmovzxbq %xmm4,%ymm4
 104fe25:	vpand  %ymm4,%ymm9,%ymm4
 104fe29:	vpaddq %ymm4,%ymm2,%ymm2
 104fe2d:	vpcmpgtb %xmm10,%xmm7,%xmm4
 104fe32:	vpmovzxbq %xmm4,%ymm4
 104fe37:	vpand  %ymm4,%ymm9,%ymm4
 104fe3b:	vpaddq %ymm4,%ymm3,%ymm3
 104fe3f:	add    $0x10,%rcx
 104fe43:	cmp    %rcx,%r9
 104fe46:	jne    104fde0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x13a0>
 104fe48:	vpaddq %ymm0,%ymm1,%ymm0
 104fe4c:	vpaddq %ymm0,%ymm2,%ymm0
 104fe50:	vpaddq %ymm0,%ymm3,%ymm0
 104fe54:	vextracti128 $0x1,%ymm0,%xmm1
 104fe5a:	vpaddq %xmm1,%xmm0,%xmm0
 104fe5e:	vpshufd $0xee,%xmm0,%xmm1
 104fe63:	vpaddq %xmm1,%xmm0,%xmm0
 104fe67:	vmovq  %xmm0,%rcx
 104fe6c:	cmp    %r9,%rdx
 104fe6f:	je     104fef6 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x14b6>
 104fe75:	test   $0xc,%dl
 104fe78:	je     105003e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x15fe>
 104fe7e:	mov    %rdx,%rdi
 104fe81:	and    $0xfffffffffffffffc,%rdi
 104fe85:	vmovq  %rcx,%xmm0
 104fe8a:	lea    (%rsi,%rax,1),%rcx
 104fe8e:	xchg   %ax,%ax
 104fe90:	vmovd  (%rcx,%r9,1),%xmm1
 104fe96:	vpcmpgtb %xmm8,%xmm1,%xmm1
 104fe9b:	vpmovzxbq %xmm1,%ymm1
 104fea0:	vpand  %ymm1,%ymm9,%ymm1
 104fea4:	vpaddq %ymm1,%ymm0,%ymm0
 104fea8:	add    $0x4,%r9
 104feac:	cmp    %r9,%rdi
 104feaf:	jne    104fe90 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1450>
 104feb1:	vextracti128 $0x1,%ymm0,%xmm1
 104feb7:	vpaddq %xmm1,%xmm0,%xmm0
 104febb:	vpshufd $0xee,%xmm0,%xmm1
 104fec0:	vpaddq %xmm1,%xmm0,%xmm0
 104fec4:	vmovq  %xmm0,%rcx
 104fec9:	cmp    %rdi,%rdx
 104fecc:	je     104fef6 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x14b6>
 104fece:	add    %rdi,%rax
 104fed1:	add    %r8,%rax
 104fed4:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 104fee0:	xor    %edx,%edx
 104fee2:	cmpb   $0xc0,0x0(%r13,%rax,1)
 104fee8:	setge  %dl
 104feeb:	add    %rdx,%rcx
 104feee:	inc    %rax
 104fef1:	cmp    %rax,%r12
 104fef4:	jne    104fee0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x14a0>
 104fef6:	cmp    %r15,%rcx
 104fef9:	jne    104ffa0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1560>
 104feff:	mov    0x8(%rsp),%rax
 104ff04:	cmpq   $0x0,0x1860(%rax)
 104ff0c:	je     1050050 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1610>
 104ff12:	mov    %rsi,0x198(%rsp)
 104ff1a:	mov    %r8,%r14
 104ff1d:	lea    0x18(%r15),%rsi
 104ff21:	mov    0x2c8(%rax),%edx
 104ff27:	mov    0x10(%rsp),%rdi
 104ff2c:	xor    %ecx,%ecx
 104ff2e:	vzeroupper
 104ff31:	call   10a57a0 <raw_bytes>
 104ff36:	test   %rax,%rax
 104ff39:	movabs $0x4000000000000002,%rdi
 104ff43:	je     1050061 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1621>
 104ff49:	mov    %rax,%r13
 104ff4c:	movq   $0x0,(%rax)
 104ff53:	mov    %r15,0x8(%rax)
 104ff57:	movq   $0x0,0x10(%rax)
 104ff5f:	cmp    %r14,%r12
 104ff62:	je     104ff85 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1545>
 104ff64:	mov    %r13,%rdi
 104ff67:	add    $0x18,%rdi
 104ff6b:	mov    0x198(%rsp),%rsi
 104ff73:	mov    %r15,%rdx
 104ff76:	call   10ab210 <memcpy@plt>
 104ff7b:	movabs $0x4000000000000002,%rdi
 104ff85:	mov    %r15,0x0(%r13)
 104ff89:	movl   $0x1,0x10(%r13)
 104ff91:	jmp    104ffd0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1590>
 104ff93:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 104ffa0:	mov    0x10(%rsp),%rdi
 104ffa5:	mov    %r15,%rdx
 104ffa8:	vzeroupper
 104ffab:	call   108f690 <build_wide>
 104ffb0:	mov    %rax,%r13
 104ffb3:	test   %rax,%rax
 104ffb6:	movabs $0x4000000000000002,%rdi
 104ffc0:	je     1050061 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1621>
 104ffc6:	cs nopw 0x0(%rax,%rax,1)
 104ffd0:	mov    0xb8(%rsp),%rax
 104ffd8:	mov    (%rax),%rcx
 104ffdb:	mov    0x20(%rax),%rdx
 104ffdf:	lea    0x1(%rcx),%rsi
 104ffe3:	mov    %rsi,(%rax)
 104ffe6:	mov    %r13,(%rdx,%rcx,8)
 104ffea:	mov    0xb8(%rsp),%rsi
 104fff2:	incq   0x10(%rsi)
 104fff6:	mov    0xc0(%rsp),%r14
 104fffe:	cmp    0x8(%r14),%r12
 1050002:	je     1050102 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x16c2>
 1050008:	mov    0x38(%rsp),%rcx
 105000d:	add    %rcx,%r12
 1050010:	dec    %rbx
 1050013:	mov    %r12,%r8
 1050016:	vmovdqa -0x4e5ee(%rip),%xmm8        # 1001a30 <__abi_tag+0x1734>
 105001e:	vmovdqu 0x1f0(%rsp),%ymm9
 1050027:	vmovdqa -0x4e5ff(%rip),%xmm10        # 1001a30 <__abi_tag+0x1734>
 105002f:	cmp    $0x1,%rbx
 1050033:	jne    104fc40 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1200>
 1050039:	jmp    104fcf0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x12b0>
 105003e:	add    %r9,%rax
 1050041:	jmp    104fed1 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1491>
 1050046:	cs nopw 0x0(%rax,%rax,1)
 1050050:	xor    %esi,%esi
 1050052:	movabs $0x4000000000000002,%rdi
 105005c:	jmp    1050102 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x16c2>
 1050061:	mov    0x8(%rsp),%rax
 1050066:	cmpq   $0x0,0x1860(%rax)
 105006e:	je     1050100 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x16c0>
 1050074:	mov    0xb8(%rsp),%rbx
 105007c:	mov    0x18(%rbx),%rax
 1050080:	cmpw   $0x1,0x30(%rax)
 1050085:	jne    1051348 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2908>
 105008b:	mov    (%rbx),%rax
 105008e:	test   %rax,%rax
 1050091:	je     10500e9 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x16a9>
 1050093:	mov    0xc0(%rsp),%r14
 105009b:	mov    0x20(%rbx),%r15
 105009f:	xor    %r12d,%r12d
 10500a2:	jmp    10500b8 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1678>
 10500a4:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 10500b0:	inc    %r12
 10500b3:	cmp    %rax,%r12
 10500b6:	jae    10500e9 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x16a9>
 10500b8:	mov    (%r15,%r12,8),%rsi
 10500bc:	test   %rsi,%rsi
 10500bf:	je     10500b0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1670>
 10500c1:	cmp    %r14,%rsi
 10500c4:	je     10500b0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1670>
 10500c6:	lea    -0x2(%rdi),%rcx
 10500ca:	test   %rcx,-0x10(%rsi)
 10500ce:	je     10500b0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1670>
 10500d0:	mov    0x10(%rsp),%rdi
 10500d5:	call   109dc20 <myl_rc_construction_abort>
 10500da:	movabs $0x4000000000000002,%rdi
 10500e4:	mov    (%rbx),%rax
 10500e7:	jmp    10500b0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1670>
 10500e9:	mov    0x10(%rsp),%rdi
 10500ee:	mov    %rbx,%rsi
 10500f1:	call   109dc20 <myl_rc_construction_abort>
 10500f6:	movabs $0x4000000000000002,%rdi
 1050100:	xor    %esi,%esi
 1050102:	mov    0x8(%rsp),%rax
 1050107:	mov    0x268(%rax),%rax
 105010e:	lea    0x138(%rsp),%rcx
 1050116:	cmp    %rcx,%rax
 1050119:	je     1050140 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1700>
 105011b:	lea    0x158(%rsp),%rcx
 1050123:	cmp    %rcx,%rax
 1050126:	je     1050161 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1721>
 1050128:	lea    0x1a8(%rsp),%rcx
 1050130:	cmp    %rcx,%rax
 1050133:	je     1050182 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1742>
 1050135:	test   %rsi,%rsi
 1050138:	jne    105019f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x175f>
 105013a:	jmp    105145d <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2a1d>
 105013f:	nop
 1050140:	mov    0x138(%rsp),%rax
 1050148:	mov    0x8(%rsp),%rcx
 105014d:	mov    %rax,0x268(%rcx)
 1050154:	lea    0x158(%rsp),%rcx
 105015c:	cmp    %rcx,%rax
 105015f:	jne    1050128 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x16e8>
 1050161:	mov    0x158(%rsp),%rax
 1050169:	mov    0x8(%rsp),%rcx
 105016e:	mov    %rax,0x268(%rcx)
 1050175:	lea    0x1a8(%rsp),%rcx
 105017d:	cmp    %rcx,%rax
 1050180:	jne    1050135 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x16f5>
 1050182:	mov    0x1a8(%rsp),%rax
 105018a:	mov    0x8(%rsp),%rcx
 105018f:	mov    %rax,0x268(%rcx)
 1050196:	test   %rsi,%rsi
 1050199:	je     105145d <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2a1d>
 105019f:	mov    %rsi,0x60(%rsp)
 10501a4:	mov    %rsi,0x68(%rsp)
 10501a9:	mov    -0x10(%rsi),%rax
 10501ad:	test   %rax,0xf0(%rsp)
 10501b5:	je     10501d6 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1796>
 10501b7:	movabs $0x5000000000000000,%rcx
 10501c1:	test   %rcx,%rax
 10501c4:	jne    10501f0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x17b0>
 10501c6:	cmpq   $0x0,0x178(%rsp)
 10501cf:	je     10501f0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x17b0>
 10501d1:	mov    %rsi,0x60(%rsp)
 10501d6:	movq   $0x0,0x68(%rsp)
 10501df:	mov    (%rsi),%r14
 10501e2:	test   %r14,%r14
 10501e5:	jns    1050237 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x17f7>
 10501e7:	jmp    105146a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2a2a>
 10501ec:	nopl   0x0(%rax)
 10501f0:	mov    $0x100ba48,%esi
 10501f5:	mov    0x10(%rsp),%rdi
 10501fa:	lea    0x60(%rsp),%rdx
 10501ff:	lea    0x68(%rsp),%rcx
 1050204:	mov    0xfc(%rsp),%r8d
 105020c:	vzeroupper
 105020f:	call   10a6000 <myl_rc_native_take>
 1050214:	test   %eax,%eax
 1050216:	je     1050439 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x19f9>
 105021c:	mov    0x60(%rsp),%rsi
 1050221:	movabs $0x4000000000000002,%rdi
 105022b:	mov    (%rsi),%r14
 105022e:	test   %r14,%r14
 1050231:	js     105146a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2a2a>
 1050237:	imul   $0x7,%r14,%r12
 105023b:	vmovdqa 0x50(%rsp),%xmm9
 1050241:	vmovdqu 0x100(%rsp),%ymm10
 105024a:	jo     105147a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2a3a>
 1050250:	test   %rsi,%rsi
 1050253:	je     105025f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x181f>
 1050255:	test   %rdi,-0x10(%rsi)
 1050259:	je     105036d <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x192d>
 105025f:	mov    %rsi,0x60(%rsp)
 1050264:	test   %r14,%r14
 1050267:	mov    %rsi,0x38(%rsp)
 105026c:	je     1050391 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1951>
 1050272:	xor    %r15d,%r15d
 1050275:	data16 cs nopw 0x0(%rax,%rax,1)
 1050280:	mov    0x20(%rsi),%rax
 1050284:	mov    (%rax,%r15,8),%r13
 1050288:	mov    %r13,0x68(%rsp)
 105028d:	test   %r13,%r13
 1050290:	je     10502a9 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1869>
 1050292:	test   %rdi,-0x10(%r13)
 1050296:	jne    10502a9 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1869>
 1050298:	mov    -0x18(%r13),%rax
 105029c:	inc    %rax
 105029f:	je     1050522 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1ae2>
 10502a5:	mov    %rax,-0x18(%r13)
 10502a9:	mov    %r13,0x60(%rsp)
 10502ae:	movq   $0x0,0x68(%rsp)
 10502b7:	mov    0x8(%rsp),%rdi
 10502bc:	mov    %r13,%rsi
 10502bf:	vzeroupper
 10502c2:	call   10741b0 <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85>
 10502c7:	mov    %r12,%rbx
 10502ca:	add    %rax,%rbx
 10502cd:	jo     1051393 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2953>
 10502d3:	test   %r13,%r13
 10502d6:	movabs $0x4000000000000002,%rdi
 10502e0:	vmovdqa 0x50(%rsp),%xmm9
 10502e6:	vmovdqu 0x100(%rsp),%ymm10
 10502ef:	mov    0x38(%rsp),%rsi
 10502f4:	je     1050310 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x18d0>
 10502f6:	test   %rdi,-0x10(%r13)
 10502fa:	jne    1050310 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x18d0>
 10502fc:	mov    -0x18(%r13),%rax
 1050300:	dec    %rax
 1050303:	jne    105030c <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x18cc>
 1050305:	cmpq   $0x0,-0x20(%r13)
 105030a:	je     105032a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x18ea>
 105030c:	mov    %rax,-0x18(%r13)
 1050310:	cmp    %r14,(%rsi)
 1050313:	jne    10513a5 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2965>
 1050319:	inc    %r15
 105031c:	mov    %rbx,%r12
 105031f:	cmp    %r15,%r14
 1050322:	jne    1050280 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1840>
 1050328:	jmp    1050394 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1954>
 105032a:	mov    0x10(%rsp),%r12
 105032f:	mov    %r12,%rdi
 1050332:	mov    %r13,%rsi
 1050335:	vzeroupper
 1050338:	call   1099bc0 <myl_rc_hold_edge_release>
 105033d:	mov    %r12,%rdi
 1050340:	call   109cbe0 <myl_rc_drain>
 1050345:	mov    0x38(%rsp),%rsi
 105034a:	vmovdqu 0x100(%rsp),%ymm10
 1050353:	vmovdqa 0x50(%rsp),%xmm9
 1050359:	movabs $0x4000000000000002,%rdi
 1050363:	cmp    %r14,(%rsi)
 1050366:	je     1050319 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x18d9>
 1050368:	jmp    10513a5 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2965>
 105036d:	mov    -0x18(%rsi),%rax
 1050371:	inc    %rax
 1050374:	je     1050522 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1ae2>
 105037a:	mov    %rax,-0x18(%rsi)
 105037e:	mov    %rsi,0x60(%rsp)
 1050383:	test   %r14,%r14
 1050386:	mov    %rsi,0x38(%rsp)
 105038b:	jne    1050272 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1832>
 1050391:	mov    %r12,%rbx
 1050394:	mov    0x230(%rsp),%eax
 105039b:	or     0x250(%rsp),%eax
 10503a2:	je     10503eb <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x19ab>
 10503a4:	mov    0x8(%rsp),%rax
 10503a9:	mov    0x1860(%rax),%rax
 10503b0:	test   %rax,%rax
 10503b3:	je     10503be <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x197e>
 10503b5:	mov    0xf8(%rax),%rsi
 10503bc:	jmp    10503c0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1980>
 10503be:	xor    %esi,%esi
 10503c0:	mov    0x10(%rsp),%rdi
 10503c5:	vzeroupper
 10503c8:	call   10a0210 <myl_rc_scope_unwind>
 10503cd:	movabs $0x4000000000000002,%rdi
 10503d7:	vmovdqa 0x50(%rsp),%xmm9
 10503dd:	vmovdqu 0x100(%rsp),%ymm10
 10503e6:	mov    0x38(%rsp),%rsi
 10503eb:	test   %rsi,%rsi
 10503ee:	je     1050590 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1b50>
 10503f4:	test   %rdi,-0x10(%rsi)
 10503f8:	jne    1050412 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x19d2>
 10503fa:	mov    -0x18(%rsi),%rax
 10503fe:	dec    %rax
 1050401:	jne    105040e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x19ce>
 1050403:	cmpq   $0x0,-0x20(%rsi)
 1050408:	je     10504a5 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1a65>
 105040e:	mov    %rax,-0x18(%rsi)
 1050412:	test   %rdi,-0x10(%rsi)
 1050416:	jne    1050590 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1b50>
 105041c:	mov    -0x20(%rsi),%rax
 1050420:	dec    %rax
 1050423:	jne    1050430 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x19f0>
 1050425:	cmpq   $0x0,-0x18(%rsi)
 105042a:	je     10504ef <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1aaf>
 1050430:	mov    %rax,-0x20(%rsi)
 1050434:	jmp    1050590 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1b50>
 1050439:	mov    0x8(%rsp),%rax
 105043e:	mov    0x1860(%rax),%rax
 1050445:	test   %rax,%rax
 1050448:	movabs $0x4000000000000002,%rdi
 1050452:	vmovdqa 0x50(%rsp),%xmm9
 1050458:	vmovdqu 0x100(%rsp),%ymm10
 1050461:	je     1051350 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2910>
 1050467:	mov    0x124(%rax),%ebx
 105046d:	movl   $0x0,0x124(%rax)
 1050477:	test   %rbx,%rbx
 105047a:	je     1050590 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1b50>
 1050480:	cmp    $0x1,%ebx
 1050483:	jne    1050551 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1b11>
 1050489:	mov    $0x1007df2,%esi
 105048e:	mov    0x8(%rsp),%rax
 1050493:	cmpl   $0x0,0x2c4(%rax)
 105049a:	je     105055a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1b1a>
 10504a0:	jmp    1050562 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1b22>
 10504a5:	mov    0x10(%rsp),%r14
 10504aa:	mov    %r14,%rdi
 10504ad:	mov    0x38(%rsp),%rsi
 10504b2:	vzeroupper
 10504b5:	call   1099bc0 <myl_rc_hold_edge_release>
 10504ba:	mov    %r14,%rdi
 10504bd:	call   109cbe0 <myl_rc_drain>
 10504c2:	mov    0x38(%rsp),%rsi
 10504c7:	vmovdqu 0x100(%rsp),%ymm10
 10504d0:	vmovdqa 0x50(%rsp),%xmm9
 10504d6:	movabs $0x4000000000000002,%rdi
 10504e0:	test   %rdi,-0x10(%rsi)
 10504e4:	jne    1050590 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1b50>
 10504ea:	jmp    105041c <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x19dc>
 10504ef:	mov    0x10(%rsp),%r14
 10504f4:	mov    %r14,%rdi
 10504f7:	vzeroupper
 10504fa:	call   1099a60 <myl_rc_edge_release>
 10504ff:	mov    %r14,%rdi
 1050502:	call   109cbe0 <myl_rc_drain>
 1050507:	vmovdqu 0x100(%rsp),%ymm10
 1050510:	vmovdqa 0x50(%rsp),%xmm9
 1050516:	movabs $0x4000000000000002,%rdi
 1050520:	jmp    1050590 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1b50>
 1050522:	mov    $0x1007dbf,%esi
 1050527:	mov    0x8(%rsp),%rdi
 105052c:	vzeroupper
 105052f:	call   108a6ee <fail>
 1050534:	vmovdqu 0x100(%rsp),%ymm10
 105053d:	vmovdqa 0x50(%rsp),%xmm9
 1050543:	movabs $0x4000000000000002,%rdi
 105054d:	xor    %ebx,%ebx
 105054f:	jmp    1050590 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1b50>
 1050551:	cmp    $0x4,%ebx
 1050554:	jae    1051348 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2908>
 105055a:	mov    0x10315e0(,%rbx,8),%rsi
 1050562:	mov    0x8(%rsp),%rdi
 1050567:	vzeroupper
 105056a:	call   108a6ee <fail>
 105056f:	xor    %ebx,%ebx
 1050571:	movabs $0x4000000000000002,%rdi
 105057b:	vmovdqa 0x50(%rsp),%xmm9
 1050581:	vmovdqu 0x100(%rsp),%ymm10
 105058a:	nopw   0x0(%rax,%rax,1)
 1050590:	mov    0x188(%rsp),%rcx
 1050598:	test   %rcx,%rcx
 105059b:	je     10505b7 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1b77>
 105059d:	test   %rdi,-0x10(%rcx)
 10505a1:	jne    10505b7 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1b77>
 10505a3:	mov    -0x20(%rcx),%rax
 10505a7:	dec    %rax
 10505aa:	jne    10505b3 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1b73>
 10505ac:	cmpq   $0x0,-0x18(%rcx)
 10505b1:	je     1050619 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1bd9>
 10505b3:	mov    %rax,-0x20(%rcx)
 10505b7:	mov    %rbp,%rcx
 10505ba:	add    %rbx,%rcx
 10505bd:	jo     105064f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1c0f>
 10505c3:	mov    %rcx,%rax
 10505c6:	movabs $0x89705f3112a28fe5,%rdx
 10505d0:	imul   %rdx
 10505d3:	add    %rcx,%rdx
 10505d6:	mov    %rdx,%rax
 10505d9:	shr    $0x3f,%rax
 10505dd:	sar    $0x1d,%rdx
 10505e1:	add    %rax,%rdx
 10505e4:	imul   $0x3b9aca07,%rdx,%rax
 10505eb:	sub    %rax,%rcx
 10505ee:	mov    %rcx,%rbp
 10505f1:	sar    $0x3f,%rbp
 10505f5:	and    $0x3b9aca07,%ebp
 10505fb:	add    %rcx,%rbp
 10505fe:	mov    0x190(%rsp),%rcx
 1050606:	inc    %rcx
 1050609:	cmp    0x20(%rsp),%rcx
 105060e:	jne    104f5e0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xba0>
 1050614:	jmp    104f251 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x811>
 1050619:	mov    0x10(%rsp),%r14
 105061e:	mov    %rcx,%rsi
 1050621:	mov    %r14,%rdi
 1050624:	vzeroupper
 1050627:	call   1099a60 <myl_rc_edge_release>
 105062c:	mov    %r14,%rdi
 105062f:	call   109cbe0 <myl_rc_drain>
 1050634:	vmovdqu 0x100(%rsp),%ymm10
 105063d:	vmovdqa 0x50(%rsp),%xmm9
 1050643:	mov    %rbp,%rcx
 1050646:	add    %rbx,%rcx
 1050649:	jno    10505c3 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1b83>
 105064f:	mov    0x8(%rsp),%rdi
 1050654:	xor    %esi,%esi
 1050656:	mov    %rbp,%rdx
 1050659:	mov    %rbx,%rcx
 105065c:	vzeroupper
 105065f:	call   108b100 <myl_qbe_fail_overflow_op>
 1050664:	mov    0x8(%rsp),%rdi
 1050669:	mov    0x1860(%rdi),%rax
 1050670:	test   %rax,%rax
 1050673:	je     1051350 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2910>
 1050679:	mov    0x124(%rax),%esi
 105067f:	movl   $0x0,0x124(%rax)
 1050689:	vzeroupper
 105068c:	call   1089e90 <myl_qbe_rc_status>
 1050691:	xor    %ebp,%ebp
 1050693:	jmp    104f251 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x811>
 1050698:	mov    0x8(%rsp),%rdi
 105069d:	mov    0x1860(%rdi),%rax
 10506a4:	test   %rax,%rax
 10506a7:	je     1051350 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2910>
 10506ad:	mov    0x124(%rax),%esi
 10506b3:	movl   $0x0,0x124(%rax)
 10506bd:	vzeroupper
 10506c0:	call   1089e90 <myl_qbe_rc_status>
 10506c5:	xor    %ebp,%ebp
 10506c7:	jmp    104f251 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x811>
 10506cc:	lea    0xc8(%rsp),%rsi
 10506d4:	mov    0x10(%rsp),%rdi
 10506d9:	mov    %ebp,%r14d
 10506dc:	mov    %eax,%ebp
 10506de:	call   10861a0 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop>
 10506e3:	mov    %ebp,%eax
 10506e5:	mov    %r14d,%ebp
 10506e8:	test   %eax,%eax
 10506ea:	jne    104f548 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xb08>
 10506f0:	movq   $0x10b8a60,0x70(%rsp)
 10506f9:	movq   $0x10b8a60,0xc8(%rsp)
 1050705:	mov    $0x10b8a60,%esi
 105070a:	mov    %rbx,%rdi
 105070d:	call   1091d30 <myl_native_text_equal>
 1050712:	movabs $0x4000000000000002,%rsi
 105071c:	test   %rsi,0x6832d(%rip)        # 10b8a50 <myl_lit_4a11bea7b5a6ce8d077c05a11569e05d5d64f10b6601437976e3917dc8273132_instance>
 1050723:	jne    1050746 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1d06>
 1050725:	mov    0x68314(%rip),%rcx        # 10b8a40 <myl_lit_49ddcee716aac9f3632795416226e674fb40f0332dabf1de33fc7f8b34af0696_instance+0x38>
 105072c:	dec    %rcx
 105072f:	jne    105073f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1cff>
 1050731:	cmpq   $0x0,0x6830f(%rip)        # 10b8a48 <myl_lit_49ddcee716aac9f3632795416226e674fb40f0332dabf1de33fc7f8b34af0696_instance+0x40>
 1050739:	je     1050b26 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x20e6>
 105073f:	mov    %rcx,0x682fa(%rip)        # 10b8a40 <myl_lit_49ddcee716aac9f3632795416226e674fb40f0332dabf1de33fc7f8b34af0696_instance+0x38>
 1050746:	test   %eax,%eax
 1050748:	je     1050b54 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2114>
 105074e:	mov    %ebp,0x2c(%rsp)
 1050752:	lea    0x48(%rsp),%r14
 1050757:	lea    0x70(%rsp),%rcx
 105075c:	mov    %rcx,%rax
 105075f:	sub    %r14,%rax
 1050762:	sub    %rcx,%r14
 1050765:	cmovb  %rax,%r14
 1050769:	movabs $0x5000000000000000,%rax
 1050773:	xor    %r15d,%r15d
 1050776:	inc    %rax
 1050779:	mov    %rax,0x50(%rsp)
 105077e:	xor    %ebp,%ebp
 1050780:	mov    0x18(%rsp),%rax
 1050785:	add    %r15,%rax
 1050788:	jo     10514b0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2a70>
 105078e:	test   $0x1,%al
 1050790:	jne    1050807 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1dc7>
 1050792:	movq   $0x10b98b0,0x70(%rsp)
 105079b:	movq   $0x10b98b0,0x1c8(%rsp)
 10507a7:	movq   $0x10b98b0,0x48(%rsp)
 10507b0:	mov    0x690e9(%rip),%rax        # 10b98a0 <myl_lit_f3eaad558815542caf7da2bdfda9d4cabeaf9c2200b79ab8ff85b21b8470fac6_instance>
 10507b7:	test   %rax,0x50(%rsp)
 10507bc:	je     10508b5 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1e75>
 10507c2:	test   %r14,%r14
 10507c5:	sete   %cl
 10507c8:	movabs $0x5000000000000000,%rdx
 10507d2:	test   %rdx,%rax
 10507d5:	setne  %al
 10507d8:	or     %cl,%al
 10507da:	je     10508bd <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1e7d>
 10507e0:	mov    $0x1030c78,%esi
 10507e5:	mov    0x10(%rsp),%rdi
 10507ea:	lea    0x70(%rsp),%rdx
 10507ef:	lea    0x48(%rsp),%rcx
 10507f4:	mov    0x2c(%rsp),%r8d
 10507f9:	call   10a6000 <myl_rc_native_take>
 10507fe:	test   %eax,%eax
 1050800:	jne    1050877 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1e37>
 1050802:	jmp    1050ac4 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2084>
 1050807:	movq   $0x10b8c20,0x70(%rsp)
 1050810:	movq   $0x10b8c20,0x1c8(%rsp)
 105081c:	movq   $0x10b8c20,0x48(%rsp)
 1050825:	mov    0x683e4(%rip),%rax        # 10b8c10 <myl_lit_54807ae7ae90f7f8ab8705f04b17dcd2d77e7355f27b7f7252156b0c234f7d3f_instance>
 105082c:	test   %rax,0x50(%rsp)
 1050831:	je     10508d7 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1e97>
 1050837:	test   %r14,%r14
 105083a:	sete   %cl
 105083d:	movabs $0x5000000000000000,%rdx
 1050847:	test   %rdx,%rax
 105084a:	setne  %al
 105084d:	or     %cl,%al
 105084f:	je     10508ce <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1e8e>
 1050851:	mov    $0x1030c78,%esi
 1050856:	mov    0x10(%rsp),%rdi
 105085b:	lea    0x70(%rsp),%rdx
 1050860:	lea    0x48(%rsp),%rcx
 1050865:	mov    0x2c(%rsp),%r8d
 105086a:	call   10a6000 <myl_rc_native_take>
 105086f:	test   %eax,%eax
 1050871:	je     1050af5 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x20b5>
 1050877:	mov    0x70(%rsp),%r12
 105087c:	mov    %r12,0xa0(%rsp)
 1050884:	mov    %r12,0x48(%rsp)
 1050889:	test   %r12,%r12
 105088c:	movabs $0x4000000000000002,%rsi
 1050896:	jne    10508ea <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1eaa>
 1050898:	movq   $0x0,0x70(%rsp)
 10508a1:	movq   $0x0,0x98(%rsp)
 10508ad:	xor    %r12d,%r12d
 10508b0:	jmp    1050947 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1f07>
 10508b5:	mov    $0x10b98b0,%r12d
 10508bb:	jmp    10508dd <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1e9d>
 10508bd:	movq   $0x10b98b0,0x70(%rsp)
 10508c6:	mov    $0x10b98b0,%r12d
 10508cc:	jmp    10508dd <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1e9d>
 10508ce:	movq   $0x10b8c20,0x70(%rsp)
 10508d7:	mov    $0x10b8c20,%r12d
 10508dd:	mov    %r12,0xa0(%rsp)
 10508e5:	mov    %r12,0x48(%rsp)
 10508ea:	test   %rsi,-0x10(%r12)
 10508ef:	je     1050900 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1ec0>
 10508f1:	mov    %r12,0x70(%rsp)
 10508f6:	mov    %r12,0x98(%rsp)
 10508fe:	jmp    105093b <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1efb>
 1050900:	mov    -0x18(%r12),%rax
 1050905:	inc    %rax
 1050908:	je     1050aae <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x206e>
 105090e:	mov    %rax,-0x18(%r12)
 1050913:	mov    %r12,0x70(%rsp)
 1050918:	mov    %r12,0x98(%rsp)
 1050920:	mov    -0x20(%r12),%rax
 1050925:	dec    %rax
 1050928:	jne    1050936 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1ef6>
 105092a:	cmpq   $0x0,-0x18(%r12)
 1050930:	je     1050a76 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2036>
 1050936:	mov    %rax,-0x20(%r12)
 105093b:	movq   $0x0,0xa0(%rsp)
 1050947:	mov    0x30(%rsp),%rax
 105094c:	mov    0x20(%rax),%rdx
 1050950:	mov    0x10(%rsp),%rdi
 1050955:	mov    %r12,%rsi
 1050958:	call   1092140 <myl_native_text_join>
 105095d:	test   %rax,%rax
 1050960:	je     1051494 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2a54>
 1050966:	mov    %rax,%rbx
 1050969:	mov    %rax,0x48(%rsp)
 105096e:	mov    %rax,0x70(%rsp)
 1050973:	mov    %rax,0x1c8(%rsp)
 105097b:	mov    0x8(%rsp),%rdi
 1050980:	mov    %rax,%rsi
 1050983:	call   10741b0 <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85>
 1050988:	mov    %rax,%r13
 105098b:	movabs $0x4000000000000002,%rsi
 1050995:	test   %rsi,-0x10(%rbx)
 1050999:	jne    10509b3 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1f73>
 105099b:	mov    -0x20(%rbx),%rax
 105099f:	dec    %rax
 10509a2:	jne    10509af <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1f6f>
 10509a4:	cmpq   $0x0,-0x18(%rbx)
 10509a9:	je     1050a4c <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x200c>
 10509af:	mov    %rax,-0x20(%rbx)
 10509b3:	movq   $0x0,0x1c8(%rsp)
 10509bf:	test   %r12,%r12
 10509c2:	je     10509f2 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1fb2>
 10509c4:	test   %rsi,-0x10(%r12)
 10509c9:	jne    10509e6 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1fa6>
 10509cb:	mov    -0x18(%r12),%rax
 10509d0:	dec    %rax
 10509d3:	jne    10509e1 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1fa1>
 10509d5:	cmpq   $0x0,-0x20(%r12)
 10509db:	je     1050a8d <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x204d>
 10509e1:	mov    %rax,-0x18(%r12)
 10509e6:	movq   $0x0,0x98(%rsp)
 10509f2:	mov    %rbp,%rcx
 10509f5:	add    %r13,%rcx
 10509f8:	jo     105149e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2a5e>
 10509fe:	mov    %rcx,%rax
 1050a01:	movabs $0x89705f3112a28fe5,%rdx
 1050a0b:	imul   %rdx
 1050a0e:	add    %rcx,%rdx
 1050a11:	mov    %rdx,%rax
 1050a14:	shr    $0x3f,%rax
 1050a18:	sar    $0x1d,%rdx
 1050a1c:	add    %rax,%rdx
 1050a1f:	imul   $0x3b9aca07,%rdx,%rax
 1050a26:	sub    %rax,%rcx
 1050a29:	mov    %rcx,%rbp
 1050a2c:	sar    $0x3f,%rbp
 1050a30:	and    $0x3b9aca07,%ebp
 1050a36:	add    %rcx,%rbp
 1050a39:	inc    %r15
 1050a3c:	cmp    %r15,0x20(%rsp)
 1050a41:	jne    1050780 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1d40>
 1050a47:	jmp    104f251 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x811>
 1050a4c:	mov    0x10(%rsp),%rdi
 1050a51:	lea    0x1c8(%rsp),%rsi
 1050a59:	call   10861a0 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop>
 1050a5e:	movabs $0x4000000000000002,%rsi
 1050a68:	test   %r12,%r12
 1050a6b:	jne    10509c4 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1f84>
 1050a71:	jmp    10509f2 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1fb2>
 1050a76:	mov    0x10(%rsp),%rdi
 1050a7b:	lea    0xa0(%rsp),%rsi
 1050a83:	call   10861a0 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop>
 1050a88:	jmp    1050947 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1f07>
 1050a8d:	mov    0x10(%rsp),%rdi
 1050a92:	lea    0x98(%rsp),%rsi
 1050a9a:	call   1086130 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan>
 1050a9f:	movabs $0x4000000000000002,%rsi
 1050aa9:	jmp    10509f2 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1fb2>
 1050aae:	mov    $0x1007dbf,%esi
 1050ab3:	mov    0x8(%rsp),%rdi
 1050ab8:	call   108a6ee <fail>
 1050abd:	xor    %ebp,%ebp
 1050abf:	jmp    104f251 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x811>
 1050ac4:	mov    0x8(%rsp),%rdi
 1050ac9:	mov    0x1860(%rdi),%rax
 1050ad0:	test   %rax,%rax
 1050ad3:	je     1051350 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2910>
 1050ad9:	mov    0x124(%rax),%esi
 1050adf:	movl   $0x0,0x124(%rax)
 1050ae9:	call   1089e90 <myl_qbe_rc_status>
 1050aee:	xor    %ebp,%ebp
 1050af0:	jmp    104f251 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x811>
 1050af5:	mov    0x8(%rsp),%rdi
 1050afa:	mov    0x1860(%rdi),%rax
 1050b01:	test   %rax,%rax
 1050b04:	je     1051350 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2910>
 1050b0a:	mov    0x124(%rax),%esi
 1050b10:	movl   $0x0,0x124(%rax)
 1050b1a:	call   1089e90 <myl_qbe_rc_status>
 1050b1f:	xor    %ebp,%ebp
 1050b21:	jmp    104f251 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x811>
 1050b26:	lea    0xc8(%rsp),%rsi
 1050b2e:	mov    0x10(%rsp),%rdi
 1050b33:	mov    %ebp,%r14d
 1050b36:	mov    %eax,%ebp
 1050b38:	call   10861a0 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop>
 1050b3d:	movabs $0x4000000000000002,%rsi
 1050b47:	mov    %ebp,%eax
 1050b49:	mov    %r14d,%ebp
 1050b4c:	test   %eax,%eax
 1050b4e:	jne    105074e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1d0e>
 1050b54:	movq   $0x10b8900,0x40(%rsp)
 1050b5d:	movq   $0x10b8900,0x70(%rsp)
 1050b66:	movq   $0x10b8900,0xc8(%rsp)
 1050b72:	mov    $0x10b8900,%esi
 1050b77:	mov    %rbx,%rdi
 1050b7a:	call   1091d30 <myl_native_text_equal>
 1050b7f:	movabs $0x4000000000000002,%r8
 1050b89:	test   %r8,0x67d60(%rip)        # 10b88f0 <myl_lit_3b82d7fd89ea641dc3c74175c3081dd70840c2be20de843e08a42204e3d9c4cc_instance>
 1050b90:	jne    1050bb3 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2173>
 1050b92:	mov    0x67d47(%rip),%rcx        # 10b88e0 <myl_lit_3b2e9d8953e261b03d089bbc831cd3b7c9a128df1fa9770dfd3ff0548594ae5c_instance+0x20>
 1050b99:	dec    %rcx
 1050b9c:	jne    1050bac <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x216c>
 1050b9e:	cmpq   $0x0,0x67d42(%rip)        # 10b88e8 <myl_lit_3b2e9d8953e261b03d089bbc831cd3b7c9a128df1fa9770dfd3ff0548594ae5c_instance+0x28>
 1050ba6:	je     1050de4 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x23a4>
 1050bac:	mov    %rcx,0x67d2d(%rip)        # 10b88e0 <myl_lit_3b2e9d8953e261b03d089bbc831cd3b7c9a128df1fa9770dfd3ff0548594ae5c_instance+0x20>
 1050bb3:	movq   $0x0,0xc8(%rsp)
 1050bbf:	test   %eax,%eax
 1050bc1:	je     1050e0c <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x23cc>
 1050bc7:	xor    %ebx,%ebx
 1050bc9:	lea    0x1a8(%rsp),%r14
 1050bd1:	lea    0x138(%rsp),%r15
 1050bd9:	movabs $0x89705f3112a28fe5,%r13
 1050be3:	xor    %ebp,%ebp
 1050be5:	mov    0x18(%rsp),%rax
 1050bea:	add    %rbx,%rax
 1050bed:	jo     10514c4 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2a84>
 1050bf3:	mov    0x30(%rsp),%rcx
 1050bf8:	mov    0x8(%rcx),%rdi
 1050bfc:	mov    (%rdi),%rcx
 1050bff:	test   %rcx,%rcx
 1050c02:	js     10514d8 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2a98>
 1050c08:	je     10514e5 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2aa5>
 1050c0e:	mov    %rax,%rdx
 1050c11:	or     %rcx,%rdx
 1050c14:	shr    $0x20,%rdx
 1050c18:	je     1050c21 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x21e1>
 1050c1a:	cqto
 1050c1c:	idiv   %rcx
 1050c1f:	jmp    1050c25 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x21e5>
 1050c21:	xor    %edx,%edx
 1050c23:	div    %ecx
 1050c25:	mov    %rdx,%rax
 1050c28:	sar    $0x3f,%rax
 1050c2c:	and    %rcx,%rax
 1050c2f:	add    %rdx,%rax
 1050c32:	mov    %rax,%rsi
 1050c35:	sar    $0x3f,%rsi
 1050c39:	and    %rcx,%rsi
 1050c3c:	add    %rax,%rsi
 1050c3f:	cmp    %rcx,%rsi
 1050c42:	jae    10514f2 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2ab2>
 1050c48:	mov    0x20(%rdi),%rax
 1050c4c:	mov    (%rax,%rsi,8),%rax
 1050c50:	test   %rax,%rax
 1050c53:	je     1050c86 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2246>
 1050c55:	mov    %rax,%rdi
 1050c58:	test   %r8,-0x10(%rax)
 1050c5c:	jne    1050c72 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2232>
 1050c5e:	mov    -0x18(%rax),%rcx
 1050c62:	inc    %rcx
 1050c65:	je     1050daa <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x236a>
 1050c6b:	mov    %rcx,-0x18(%rax)
 1050c6f:	mov    %rax,%rdi
 1050c72:	mov    %rax,0x138(%rsp)
 1050c7a:	testb  $0x4,0x10(%rdi)
 1050c7e:	jne    1050c96 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2256>
 1050c80:	add    $0x18,%rdi
 1050c84:	jmp    1050ca5 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2265>
 1050c86:	xor    %edi,%edi
 1050c88:	mov    %rax,0x138(%rsp)
 1050c90:	testb  $0x4,0x10(%rdi)
 1050c94:	je     1050c80 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2240>
 1050c96:	mov    0x18(%rdi),%rcx
 1050c9a:	mov    0x14(%rdi),%edx
 1050c9d:	lea    (%rcx,%rdx,1),%rdi
 1050ca1:	add    $0x18,%rdi
 1050ca5:	mov    0x8(%rax),%rsi
 1050ca9:	xor    %edx,%edx
 1050cab:	mov    %r14,%rcx
 1050cae:	call   104a530 <myl_native_bytes_number_parse>
 1050cb3:	test   %eax,%eax
 1050cb5:	je     1050d18 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x22d8>
 1050cb7:	mov    0x1a8(%rsp),%r12
 1050cbf:	movl   $0x1,0x158(%rsp)
 1050cca:	mov    %r12,0x160(%rsp)
 1050cd2:	mov    0x138(%rsp),%rax
 1050cda:	test   %rax,%rax
 1050cdd:	movabs $0x4000000000000002,%r8
 1050ce7:	je     1050d5a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x231a>
 1050ce9:	test   %r8,-0x10(%rax)
 1050ced:	jne    1050d5a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x231a>
 1050cef:	mov    -0x18(%rax),%rcx
 1050cf3:	dec    %rcx
 1050cf6:	jne    1050d56 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2316>
 1050cf8:	cmpq   $0x0,-0x20(%rax)
 1050cfd:	jne    1050d56 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2316>
 1050cff:	mov    0x10(%rsp),%rdi
 1050d04:	mov    %r15,%rsi
 1050d07:	call   1086130 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan>
 1050d0c:	movabs $0x4000000000000002,%r8
 1050d16:	jmp    1050d5a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x231a>
 1050d18:	movl   $0x0,0x158(%rsp)
 1050d23:	mov    0x138(%rsp),%rax
 1050d2b:	mov    $0x61,%r12d
 1050d31:	test   %rax,%rax
 1050d34:	movabs $0x4000000000000002,%r8
 1050d3e:	je     1050d5a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x231a>
 1050d40:	test   %r8,-0x10(%rax)
 1050d44:	jne    1050d5a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x231a>
 1050d46:	mov    -0x18(%rax),%rcx
 1050d4a:	dec    %rcx
 1050d4d:	jne    1050d56 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2316>
 1050d4f:	cmpq   $0x0,-0x20(%rax)
 1050d54:	je     1050dc8 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2388>
 1050d56:	mov    %rcx,-0x18(%rax)
 1050d5a:	mov    %rbp,%rcx
 1050d5d:	add    %r12,%rcx
 1050d60:	jo     10514ff <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2abf>
 1050d66:	mov    %rcx,%rax
 1050d69:	imul   %r13
 1050d6c:	add    %rcx,%rdx
 1050d6f:	mov    %rdx,%rax
 1050d72:	shr    $0x3f,%rax
 1050d76:	sar    $0x1d,%rdx
 1050d7a:	add    %rax,%rdx
 1050d7d:	imul   $0x3b9aca07,%rdx,%rax
 1050d84:	sub    %rax,%rcx
 1050d87:	mov    %rcx,%rbp
 1050d8a:	sar    $0x3f,%rbp
 1050d8e:	and    $0x3b9aca07,%ebp
 1050d94:	add    %rcx,%rbp
 1050d97:	inc    %rbx
 1050d9a:	cmp    %rbx,0x20(%rsp)
 1050d9f:	jne    1050be5 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x21a5>
 1050da5:	jmp    104f251 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x811>
 1050daa:	mov    $0x1007dbf,%esi
 1050daf:	mov    0x8(%rsp),%rdi
 1050db4:	call   108a6ee <fail>
 1050db9:	movabs $0x4000000000000002,%r8
 1050dc3:	xor    %r12d,%r12d
 1050dc6:	jmp    1050d5a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x231a>
 1050dc8:	mov    0x10(%rsp),%rdi
 1050dcd:	mov    %r15,%rsi
 1050dd0:	call   1086130 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan>
 1050dd5:	movabs $0x4000000000000002,%r8
 1050ddf:	jmp    1050d5a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x231a>
 1050de4:	lea    0xc8(%rsp),%rsi
 1050dec:	mov    0x10(%rsp),%rdi
 1050df1:	mov    %eax,%ebp
 1050df3:	call   10861a0 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop>
 1050df8:	movabs $0x4000000000000002,%r8
 1050e02:	mov    %ebp,%eax
 1050e04:	test   %eax,%eax
 1050e06:	jne    1050bc7 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2187>
 1050e0c:	movq   $0x10b8e08,0x70(%rsp)
 1050e15:	movq   $0x10b8e08,0xc8(%rsp)
 1050e21:	mov    $0x10b8e08,%esi
 1050e26:	mov    %rbx,%rdi
 1050e29:	call   1091d30 <myl_native_text_equal>
 1050e2e:	movabs $0x4000000000000002,%rcx
 1050e38:	test   %rcx,0x67fb9(%rip)        # 10b8df8 <myl_lit_626da83bb2caf4205ae415768034d7bb2b32d76c3b0b29af95ab0567cf1d3ca9_instance>
 1050e3f:	jne    1050e62 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2422>
 1050e41:	mov    0x67fa0(%rip),%rcx        # 10b8de8 <myl_lit_5ffcfeefbc77603111eb9faae2375c1bd71d00fc5610c522261905cf007d59b3_instance+0x60>
 1050e48:	dec    %rcx
 1050e4b:	jne    1050e5b <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x241b>
 1050e4d:	cmpq   $0x0,0x67f9b(%rip)        # 10b8df0 <myl_lit_5ffcfeefbc77603111eb9faae2375c1bd71d00fc5610c522261905cf007d59b3_instance+0x68>
 1050e55:	je     1050fc9 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2589>
 1050e5b:	mov    %rcx,0x67f86(%rip)        # 10b8de8 <myl_lit_5ffcfeefbc77603111eb9faae2375c1bd71d00fc5610c522261905cf007d59b3_instance+0x60>
 1050e62:	test   %eax,%eax
 1050e64:	je     1050fe7 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x25a7>
 1050e6a:	xor    %ebx,%ebx
 1050e6c:	lea    0x1c8(%rsp),%r14
 1050e74:	movabs $0x89705f3112a28fe5,%r12
 1050e7e:	xor    %ebp,%ebp
 1050e80:	mov    0x18(%rsp),%rax
 1050e85:	add    %rbx,%rax
 1050e88:	jo     1051511 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2ad1>
 1050e8e:	mov    0x30(%rsp),%rcx
 1050e93:	mov    0x18(%rcx),%rdi
 1050e97:	mov    (%rdi),%rcx
 1050e9a:	test   %rcx,%rcx
 1050e9d:	js     1051525 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2ae5>
 1050ea3:	je     1051532 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2af2>
 1050ea9:	mov    %rax,%rdx
 1050eac:	or     %rcx,%rdx
 1050eaf:	shr    $0x20,%rdx
 1050eb3:	je     1050ebc <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x247c>
 1050eb5:	cqto
 1050eb7:	idiv   %rcx
 1050eba:	jmp    1050ec0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2480>
 1050ebc:	xor    %edx,%edx
 1050ebe:	div    %ecx
 1050ec0:	mov    %rdx,%rsi
 1050ec3:	sar    $0x3f,%rsi
 1050ec7:	and    %rcx,%rsi
 1050eca:	add    %rdx,%rsi
 1050ecd:	cmp    %rcx,%rsi
 1050ed0:	jb     1050ee8 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x24a8>
 1050ed2:	mov    %rsi,%rax
 1050ed5:	sar    $0x3f,%rax
 1050ed9:	and    %rcx,%rax
 1050edc:	add    %rax,%rsi
 1050edf:	cmp    %rcx,%rsi
 1050ee2:	jae    1051549 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2b09>
 1050ee8:	mov    0x20(%rdi),%rax
 1050eec:	mov    (%rax,%rsi,8),%rsi
 1050ef0:	mov    0x10(%rsp),%rdi
 1050ef5:	call   104c060 <myl_native_text_integer>
 1050efa:	test   %rax,%rax
 1050efd:	je     105153f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2aff>
 1050f03:	mov    %rax,%r15
 1050f06:	mov    %rax,0x70(%rsp)
 1050f0b:	mov    %rax,0x1c8(%rsp)
 1050f13:	mov    0x8(%rsp),%rdi
 1050f18:	mov    %rax,%rsi
 1050f1b:	call   10741b0 <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85>
 1050f20:	movabs $0x4000000000000002,%rcx
 1050f2a:	test   %rcx,-0x10(%r15)
 1050f2e:	jne    1050f44 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2504>
 1050f30:	mov    -0x20(%r15),%rcx
 1050f34:	dec    %rcx
 1050f37:	jne    1050f40 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2500>
 1050f39:	cmpq   $0x0,-0x18(%r15)
 1050f3e:	je     1050f9c <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x255c>
 1050f40:	mov    %rcx,-0x20(%r15)
 1050f44:	movq   $0x0,0x1c8(%rsp)
 1050f50:	mov    %rbp,%rcx
 1050f53:	add    %rax,%rcx
 1050f56:	jo     1050fb7 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2577>
 1050f58:	mov    %rcx,%rax
 1050f5b:	imul   %r12
 1050f5e:	add    %rcx,%rdx
 1050f61:	mov    %rdx,%rax
 1050f64:	shr    $0x3f,%rax
 1050f68:	sar    $0x1d,%rdx
 1050f6c:	add    %rax,%rdx
 1050f6f:	imul   $0x3b9aca07,%rdx,%rax
 1050f76:	sub    %rax,%rcx
 1050f79:	mov    %rcx,%rbp
 1050f7c:	sar    $0x3f,%rbp
 1050f80:	and    $0x3b9aca07,%ebp
 1050f86:	add    %rcx,%rbp
 1050f89:	inc    %rbx
 1050f8c:	cmp    %rbx,0x20(%rsp)
 1050f91:	jne    1050e80 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2440>
 1050f97:	jmp    104f251 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x811>
 1050f9c:	mov    0x10(%rsp),%rdi
 1050fa1:	mov    %r14,%rsi
 1050fa4:	mov    %rax,%r15
 1050fa7:	call   10861a0 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop>
 1050fac:	mov    %r15,%rax
 1050faf:	mov    %rbp,%rcx
 1050fb2:	add    %rax,%rcx
 1050fb5:	jno    1050f58 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2518>
 1050fb7:	mov    0x8(%rsp),%rdi
 1050fbc:	xor    %esi,%esi
 1050fbe:	mov    %rbp,%rdx
 1050fc1:	mov    %rax,%rcx
 1050fc4:	call   108b100 <myl_qbe_fail_overflow_op>
 1050fc9:	lea    0xc8(%rsp),%rsi
 1050fd1:	mov    0x10(%rsp),%rdi
 1050fd6:	mov    %eax,%ebp
 1050fd8:	call   10861a0 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop>
 1050fdd:	mov    %ebp,%eax
 1050fdf:	test   %eax,%eax
 1050fe1:	jne    1050e6a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x242a>
 1050fe7:	movq   $0x10b9220,0x70(%rsp)
 1050ff0:	movq   $0x10b9220,0xc8(%rsp)
 1050ffc:	mov    $0x10b9220,%esi
 1051001:	mov    %rbx,%rdi
 1051004:	call   1091d30 <myl_native_text_equal>
 1051009:	movabs $0x4000000000000002,%rcx
 1051013:	test   %rcx,0x681f6(%rip)        # 10b9210 <myl_lit_a35604ac3394cc7d310962e0ecc5dd785c46f6dc02140680027413a7b439bcdd_instance>
 105101a:	jne    105103d <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x25fd>
 105101c:	mov    0x681dd(%rip),%rcx        # 10b9200 <myl_lit_9d259d114fa076e260ed1d46f937777788fb8ac5c28077065c4fa3e2a22cd22a_instance+0x38>
 1051023:	dec    %rcx
 1051026:	jne    1051036 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x25f6>
 1051028:	cmpq   $0x0,0x681d8(%rip)        # 10b9208 <myl_lit_9d259d114fa076e260ed1d46f937777788fb8ac5c28077065c4fa3e2a22cd22a_instance+0x40>
 1051030:	je     10510d7 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2697>
 1051036:	mov    %rcx,0x681c3(%rip)        # 10b9200 <myl_lit_9d259d114fa076e260ed1d46f937777788fb8ac5c28077065c4fa3e2a22cd22a_instance+0x38>
 105103d:	test   %eax,%eax
 105103f:	je     10510f5 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x26b5>
 1051045:	xor    %ebx,%ebx
 1051047:	movabs $0x89705f3112a28fe5,%r14
 1051051:	xor    %ebp,%ebp
 1051053:	mov    0x18(%rsp),%rsi
 1051058:	add    %rbx,%rsi
 105105b:	jo     1051556 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2b16>
 1051061:	mov    0x30(%rsp),%rax
 1051066:	mov    0x8(%rax),%rax
 105106a:	and    $0x1,%esi
 105106d:	mov    (%rax),%rdx
 1051070:	cmp    %rdx,%rsi
 1051073:	jae    105156a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2b2a>
 1051079:	mov    0x20(%rax),%rax
 105107d:	mov    (%rax,%rsi,8),%rsi
 1051081:	mov    0x8(%rsp),%rdi
 1051086:	call   10685e0 <myl_f_ad1ca9f864adc8c89d572ada651cc6dc28bc6d83eeae5c5fc70bc26744bcdb57>
 105108b:	mov    %rbp,%rcx
 105108e:	add    %rax,%rcx
 1051091:	jo     1051574 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2b34>
 1051097:	mov    %rcx,%rax
 105109a:	imul   %r14
 105109d:	add    %rcx,%rdx
 10510a0:	mov    %rdx,%rax
 10510a3:	shr    $0x3f,%rax
 10510a7:	sar    $0x1d,%rdx
 10510ab:	add    %rax,%rdx
 10510ae:	imul   $0x3b9aca07,%rdx,%rax
 10510b5:	sub    %rax,%rcx
 10510b8:	mov    %rcx,%rbp
 10510bb:	sar    $0x3f,%rbp
 10510bf:	and    $0x3b9aca07,%ebp
 10510c5:	add    %rcx,%rbp
 10510c8:	inc    %rbx
 10510cb:	cmp    %rbx,0x20(%rsp)
 10510d0:	jne    1051053 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2613>
 10510d2:	jmp    104f251 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x811>
 10510d7:	lea    0xc8(%rsp),%rsi
 10510df:	mov    0x10(%rsp),%rdi
 10510e4:	mov    %eax,%ebp
 10510e6:	call   10861a0 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop>
 10510eb:	mov    %ebp,%eax
 10510ed:	test   %eax,%eax
 10510ef:	jne    1051045 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2605>
 10510f5:	movq   $0x10b86b8,0x70(%rsp)
 10510fe:	movq   $0x10b86b8,0xc8(%rsp)
 105110a:	mov    $0x10b86b8,%esi
 105110f:	mov    %rbx,%rdi
 1051112:	call   1091d30 <myl_native_text_equal>
 1051117:	movabs $0x4000000000000002,%rdx
 1051121:	test   %rdx,0x67580(%rip)        # 10b86a8 <myl_lit_20a5074191baf0b9771e8515f87070a522415c098c80effc97a3fee2e9d89d03_instance>
 1051128:	jne    105114b <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x270b>
 105112a:	mov    0x67567(%rip),%rcx        # 10b8698 <myl_lit_1ad4f10fd641593331eda3448c74a0b009c6527a19d75e6283c9d7ef74595fd2_instance+0x38>
 1051131:	dec    %rcx
 1051134:	jne    1051144 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2704>
 1051136:	cmpq   $0x0,0x67562(%rip)        # 10b86a0 <myl_lit_1ad4f10fd641593331eda3448c74a0b009c6527a19d75e6283c9d7ef74595fd2_instance+0x40>
 105113e:	je     10511df <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x279f>
 1051144:	mov    %rcx,0x6754d(%rip)        # 10b8698 <myl_lit_1ad4f10fd641593331eda3448c74a0b009c6527a19d75e6283c9d7ef74595fd2_instance+0x38>
 105114b:	test   %eax,%eax
 105114d:	je     1051207 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x27c7>
 1051153:	xor    %ebx,%ebx
 1051155:	movabs $0x89705f3112a28fe5,%r14
 105115f:	xor    %ebp,%ebp
 1051161:	mov    0x18(%rsp),%rax
 1051166:	add    %rbx,%rax
 1051169:	jo     1051586 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2b46>
 105116f:	mov    0x30(%rsp),%rax
 1051174:	mov    0x8(%rax),%rax
 1051178:	cmpq   $0x0,(%rax)
 105117c:	je     105159a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2b5a>
 1051182:	mov    0x20(%rax),%rax
 1051186:	mov    (%rax),%rsi
 1051189:	mov    0x8(%rsp),%rdi
 105118e:	call   106fb60 <myl_f_bc9060da36c8e282f8d98349f6541aa0f2c1802b8a99e1d4c2ef7b134103c5e2>
 1051193:	mov    %rbp,%rcx
 1051196:	add    %rax,%rcx
 1051199:	jo     10515a8 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2b68>
 105119f:	mov    %rcx,%rax
 10511a2:	imul   %r14
 10511a5:	add    %rcx,%rdx
 10511a8:	mov    %rdx,%rax
 10511ab:	shr    $0x3f,%rax
 10511af:	sar    $0x1d,%rdx
 10511b3:	add    %rax,%rdx
 10511b6:	imul   $0x3b9aca07,%rdx,%rax
 10511bd:	sub    %rax,%rcx
 10511c0:	mov    %rcx,%rbp
 10511c3:	sar    $0x3f,%rbp
 10511c7:	and    $0x3b9aca07,%ebp
 10511cd:	add    %rcx,%rbp
 10511d0:	inc    %rbx
 10511d3:	cmp    %rbx,0x20(%rsp)
 10511d8:	jne    1051161 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2721>
 10511da:	jmp    104f251 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x811>
 10511df:	lea    0xc8(%rsp),%rsi
 10511e7:	mov    0x10(%rsp),%rdi
 10511ec:	mov    %eax,%ebp
 10511ee:	call   10861a0 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop>
 10511f3:	movabs $0x4000000000000002,%rdx
 10511fd:	mov    %ebp,%eax
 10511ff:	test   %eax,%eax
 1051201:	jne    1051153 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2713>
 1051207:	movq   $0x10b8788,0x70(%rsp)
 1051210:	movq   $0x10b8788,0xc8(%rsp)
 105121c:	mov    $0x10b8788,%esi
 1051221:	mov    %rbx,%rdi
 1051224:	mov    %rdx,%rbx
 1051227:	call   1091d30 <myl_native_text_equal>
 105122c:	test   %rbx,0x67545(%rip)        # 10b8778 <myl_lit_2cecebef85ac89e87c0bdc9d723015d4a10a29fb007a542e0de04f511346a3b5_instance>
 1051233:	jne    105125a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x281a>
 1051235:	mov    %eax,%ebx
 1051237:	mov    0x6752a(%rip),%rax        # 10b8768 <myl_lit_2ac6840555c10725b6640492294f67393cd0d698e5786fc4e12cdb1cc9a394a2_instance+0x38>
 105123e:	dec    %rax
 1051241:	jne    1051251 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2811>
 1051243:	cmpq   $0x0,0x67525(%rip)        # 10b8770 <myl_lit_2ac6840555c10725b6640492294f67393cd0d698e5786fc4e12cdb1cc9a394a2_instance+0x40>
 105124b:	je     1051331 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x28f1>
 1051251:	mov    %rax,0x67510(%rip)        # 10b8768 <myl_lit_2ac6840555c10725b6640492294f67393cd0d698e5786fc4e12cdb1cc9a394a2_instance+0x38>
 1051258:	mov    %ebx,%eax
 105125a:	test   %eax,%eax
 105125c:	je     105132a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x28ea>
 1051262:	xor    %ebx,%ebx
 1051264:	movabs $0x7878787878787879,%r14
 105126e:	movabs $0x89705f3112a28fe5,%r15
 1051278:	xor    %ebp,%ebp
 105127a:	mov    0x18(%rsp),%rcx
 105127f:	add    %rbx,%rcx
 1051282:	jo     10515ba <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2b7a>
 1051288:	mov    0x30(%rsp),%rax
 105128d:	mov    0x8(%rax),%rax
 1051291:	cmpq   $0x0,(%rax)
 1051295:	je     10515ce <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2b8e>
 105129b:	mov    0x20(%rax),%rax
 105129f:	mov    (%rax),%rsi
 10512a2:	mov    %rcx,%rax
 10512a5:	imul   %r14
 10512a8:	mov    %rdx,%rax
 10512ab:	shr    $0x3f,%rax
 10512af:	sar    $0x3,%rdx
 10512b3:	add    %rax,%rdx
 10512b6:	mov    %rdx,%rax
 10512b9:	shl    $0x4,%rax
 10512bd:	add    %rdx,%rax
 10512c0:	sub    %rax,%rcx
 10512c3:	mov    %rcx,%rdx
 10512c6:	sar    $0x3f,%rdx
 10512ca:	and    $0x11,%edx
 10512cd:	add    %rcx,%rdx
 10512d0:	mov    0x8(%rsp),%rdi
 10512d5:	call   1057da0 <myl_f_47022dd26e980fcb99b6abeb2cfdf289edce3d6955dda89c0a131b73692c5f56>
 10512da:	mov    %rbp,%rcx
 10512dd:	add    %rax,%rcx
 10512e0:	jo     10515dc <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2b9c>
 10512e6:	mov    %rcx,%rax
 10512e9:	imul   %r15
 10512ec:	add    %rcx,%rdx
 10512ef:	mov    %rdx,%rax
 10512f2:	shr    $0x3f,%rax
 10512f6:	sar    $0x1d,%rdx
 10512fa:	add    %rax,%rdx
 10512fd:	imul   $0x3b9aca07,%rdx,%rax
 1051304:	sub    %rax,%rcx
 1051307:	mov    %rcx,%rbp
 105130a:	sar    $0x3f,%rbp
 105130e:	and    $0x3b9aca07,%ebp
 1051314:	add    %rcx,%rbp
 1051317:	inc    %rbx
 105131a:	cmp    %rbx,0x20(%rsp)
 105131f:	jne    105127a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x283a>
 1051325:	jmp    104f251 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x811>
 105132a:	xor    %ebp,%ebp
 105132c:	jmp    104f251 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x811>
 1051331:	lea    0xc8(%rsp),%rsi
 1051339:	mov    0x10(%rsp),%rdi
 105133e:	call   10861a0 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop>
 1051343:	jmp    1051258 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2818>
 1051348:	vzeroupper
 105134b:	call   10ab230 <abort@plt>
 1051350:	vzeroupper
 1051353:	call   10995b7 <myl_rc_invariant_failed>
 1051358:	mov    0x8(%rsp),%rdi
 105135d:	xor    %esi,%esi
 105135f:	vzeroupper
 1051362:	call   108b100 <myl_qbe_fail_overflow_op>
 1051367:	mov    0x8(%rsp),%rdi
 105136c:	xor    %esi,%esi
 105136e:	mov    0x18(%rsp),%rdx
 1051373:	mov    %rbx,%rcx
 1051376:	vzeroupper
 1051379:	call   108b100 <myl_qbe_fail_overflow_op>
 105137e:	mov    0x8(%rsp),%rdi
 1051383:	xor    %esi,%esi
 1051385:	mov    %rbp,%rdx
 1051388:	mov    %r14,%rcx
 105138b:	vzeroupper
 105138e:	call   108b100 <myl_qbe_fail_overflow_op>
 1051393:	mov    0x8(%rsp),%rdi
 1051398:	xor    %esi,%esi
 105139a:	mov    %r12,%rdx
 105139d:	mov    %rax,%rcx
 10513a0:	call   108b100 <myl_qbe_fail_overflow_op>
 10513a5:	mov    0x8(%rsp),%rdi
 10513aa:	vzeroupper
 10513ad:	call   108aeb0 <myl_qbe_fail_iteration>
 10513b2:	mov    0x8(%rsp),%rdi
 10513b7:	call   108aff0 <myl_qbe_fail_normalized_index_bounds>
 10513bc:	mov    0x8(%rsp),%rdi
 10513c1:	call   108aff0 <myl_qbe_fail_normalized_index_bounds>
 10513c6:	mov    0x8(%rsp),%rdi
 10513cb:	xor    %esi,%esi
 10513cd:	mov    0x18(%rsp),%rdx
 10513d2:	mov    %rbx,%rcx
 10513d5:	call   108b100 <myl_qbe_fail_overflow_op>
 10513da:	mov    0x8(%rsp),%rdi
 10513df:	xor    %esi,%esi
 10513e1:	mov    0x18(%rsp),%rdx
 10513e6:	mov    %rbx,%rcx
 10513e9:	call   108b100 <myl_qbe_fail_overflow_op>
 10513ee:	mov    0x8(%rsp),%rdi
 10513f3:	xor    %esi,%esi
 10513f5:	xor    %edx,%edx
 10513f7:	call   108aff0 <myl_qbe_fail_normalized_index_bounds>
 10513fc:	mov    0x8(%rsp),%rdi
 1051401:	call   108aff0 <myl_qbe_fail_normalized_index_bounds>
 1051406:	mov    $0x1,%ecx
 105140b:	mov    0x8(%rsp),%rdi
 1051410:	xor    %esi,%esi
 1051412:	mov    %r15,%rdx
 1051415:	call   108b100 <myl_qbe_fail_overflow_op>
 105141a:	mov    %r14,%rdi
 105141d:	call   108b1c0 <myl_qbe_fail_frame>
 1051422:	mov    0x8(%rsp),%rdi
 1051427:	vzeroupper
 105142a:	call   108aff0 <myl_qbe_fail_normalized_index_bounds>
 105142f:	mov    0x8(%rsp),%rdi
 1051434:	xor    %esi,%esi
 1051436:	mov    0x18(%rsp),%rdx
 105143b:	vzeroupper
 105143e:	call   108b100 <myl_qbe_fail_overflow_op>
 1051443:	mov    0x8(%rsp),%rdi
 1051448:	vzeroupper
 105144b:	call   108b1c0 <myl_qbe_fail_frame>
 1051450:	mov    0x8(%rsp),%rdi
 1051455:	vzeroupper
 1051458:	call   108aea0 <myl_qbe_fail_empty_separator>
 105145d:	mov    0x8(%rsp),%rdi
 1051462:	vzeroupper
 1051465:	call   108adb0 <myl_qbe_fail_allocation>
 105146a:	mov    0x8(%rsp),%rdi
 105146f:	mov    %r14,%rsi
 1051472:	vzeroupper
 1051475:	call   108b160 <myl_qbe_fail_cast>
 105147a:	mov    $0x2,%esi
 105147f:	mov    $0x7,%ecx
 1051484:	mov    0x8(%rsp),%rdi
 1051489:	mov    %r14,%rdx
 105148c:	vzeroupper
 105148f:	call   108b100 <myl_qbe_fail_overflow_op>
 1051494:	mov    0x8(%rsp),%rdi
 1051499:	call   108adb0 <myl_qbe_fail_allocation>
 105149e:	mov    0x8(%rsp),%rdi
 10514a3:	xor    %esi,%esi
 10514a5:	mov    %rbp,%rdx
 10514a8:	mov    %r13,%rcx
 10514ab:	call   108b100 <myl_qbe_fail_overflow_op>
 10514b0:	mov    0x8(%rsp),%rdi
 10514b5:	xor    %esi,%esi
 10514b7:	mov    0x18(%rsp),%rdx
 10514bc:	mov    %r15,%rcx
 10514bf:	call   108b100 <myl_qbe_fail_overflow_op>
 10514c4:	mov    0x8(%rsp),%rdi
 10514c9:	xor    %esi,%esi
 10514cb:	mov    0x18(%rsp),%rdx
 10514d0:	mov    %rbx,%rcx
 10514d3:	call   108b100 <myl_qbe_fail_overflow_op>
 10514d8:	mov    0x8(%rsp),%rdi
 10514dd:	mov    %rcx,%rsi
 10514e0:	call   108b160 <myl_qbe_fail_cast>
 10514e5:	mov    0x8(%rsp),%rdi
 10514ea:	mov    %rax,%rsi
 10514ed:	call   108b0b0 <myl_qbe_fail_division>
 10514f2:	mov    0x8(%rsp),%rdi
 10514f7:	mov    %rcx,%rdx
 10514fa:	call   108aff0 <myl_qbe_fail_normalized_index_bounds>
 10514ff:	mov    0x8(%rsp),%rdi
 1051504:	xor    %esi,%esi
 1051506:	mov    %rbp,%rdx
 1051509:	mov    %r12,%rcx
 105150c:	call   108b100 <myl_qbe_fail_overflow_op>
 1051511:	mov    0x8(%rsp),%rdi
 1051516:	xor    %esi,%esi
 1051518:	mov    0x18(%rsp),%rdx
 105151d:	mov    %rbx,%rcx
 1051520:	call   108b100 <myl_qbe_fail_overflow_op>
 1051525:	mov    0x8(%rsp),%rdi
 105152a:	mov    %rcx,%rsi
 105152d:	call   108b160 <myl_qbe_fail_cast>
 1051532:	mov    0x8(%rsp),%rdi
 1051537:	mov    %rax,%rsi
 105153a:	call   108b0b0 <myl_qbe_fail_division>
 105153f:	mov    0x8(%rsp),%rdi
 1051544:	call   108adb0 <myl_qbe_fail_allocation>
 1051549:	mov    0x8(%rsp),%rdi
 105154e:	mov    %rcx,%rdx
 1051551:	call   108aff0 <myl_qbe_fail_normalized_index_bounds>
 1051556:	mov    0x8(%rsp),%rdi
 105155b:	xor    %esi,%esi
 105155d:	mov    0x18(%rsp),%rdx
 1051562:	mov    %rbx,%rcx
 1051565:	call   108b100 <myl_qbe_fail_overflow_op>
 105156a:	mov    0x8(%rsp),%rdi
 105156f:	call   108aff0 <myl_qbe_fail_normalized_index_bounds>
 1051574:	mov    0x8(%rsp),%rdi
 1051579:	xor    %esi,%esi
 105157b:	mov    %rbp,%rdx
 105157e:	mov    %rax,%rcx
 1051581:	call   108b100 <myl_qbe_fail_overflow_op>
 1051586:	mov    0x8(%rsp),%rdi
 105158b:	xor    %esi,%esi
 105158d:	mov    0x18(%rsp),%rdx
 1051592:	mov    %rbx,%rcx
 1051595:	call   108b100 <myl_qbe_fail_overflow_op>
 105159a:	mov    0x8(%rsp),%rdi
 105159f:	xor    %esi,%esi
 10515a1:	xor    %edx,%edx
 10515a3:	call   108aff0 <myl_qbe_fail_normalized_index_bounds>
 10515a8:	mov    0x8(%rsp),%rdi
 10515ad:	xor    %esi,%esi
 10515af:	mov    %rbp,%rdx
 10515b2:	mov    %rax,%rcx
 10515b5:	call   108b100 <myl_qbe_fail_overflow_op>
 10515ba:	mov    0x8(%rsp),%rdi
 10515bf:	xor    %esi,%esi
 10515c1:	mov    0x18(%rsp),%rdx
 10515c6:	mov    %rbx,%rcx
 10515c9:	call   108b100 <myl_qbe_fail_overflow_op>
 10515ce:	mov    0x8(%rsp),%rdi
 10515d3:	xor    %esi,%esi
 10515d5:	xor    %edx,%edx
 10515d7:	call   108aff0 <myl_qbe_fail_normalized_index_bounds>
 10515dc:	mov    0x8(%rsp),%rdi
 10515e1:	xor    %esi,%esi
 10515e3:	mov    %rbp,%rdx
 10515e6:	mov    %rax,%rcx
 10515e9:	call   108b100 <myl_qbe_fail_overflow_op>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
