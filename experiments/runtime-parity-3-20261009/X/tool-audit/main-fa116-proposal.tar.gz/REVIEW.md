# S2 integration proposal for main fa1160602

Source basis: synthetic merge tree `25d01d16836ffd2d72fde8378b6aad6e81fc67f4`
(root integration `74adf3466317b4883371046ff675ad6a53a45903` plus
main `fa11606022ed217896a27976f8fe6d95db95f465`).

All work here is scratch only. No compiler, test, Guardian gate, guest build, or
measurement has run. `git apply --check` passed for both patches against scratch
copies of the synthetic tree. Tracked S2 and root files have not been edited.

## Proposed files

- `production.patch`: conflict resolution plus bounded demand fallback.
- `tests.patch`: four integration regressions, each exercises verify and trusted.
- `src/core/{passes,fuse_slice_key,optimization_cache_test}.zig`: full proposed files.

The production patch preserves the prepass order: text split fusion, S2 private
split views, then recording slice/byte fusion. The existing public four-argument
`rewriteUses` remains available to split producers; a private recording wrapper
handles slice traversal. Both the ordinary view and `str_from_view` simplification
paths forward their helper requests. U2 `overflow_edges` registration remains in
its existing location after ownership and index checks.

## Why recording the new pass alone is insufficient

- `split_views.zig:60` declares prefix/offset helpers; `:76` interns the offset
  record and list types; `:93` can append span helpers through `rewriteUses`.
- `split_views.zig:102` appends a count helper per count-only split, including
  duplicate same-name declarations. Main `fusion_checkpoint.zig:26` rejects a
  replayed declaration whose name already exists.
- `fuse_text_split.zig:165` and `:242` declare whitespace and explicit cursor
  helpers. Its explicit rewrite at `:278` can append span helpers as well.
- Main `fusion_checkpoint.zig:11` stores declarations and per-producer requests,
  but not generated compound types. `passes.zig`'s `finishFusionInputs` compares
  only requests passed by recording producers. Merely restoring all declarations
  does not prove eager declaration order when a dirty split producer changes
  first-use order while a spectator keeps its old body deferred.
- Main tests raw record presence before fusion when admitting summary reuse.
  Full replay of a new offset-record type would also need that assumption audited.

A complete split replay implementation therefore needs producer recording across
both split passes and their span-helper paths, ordered compound-type replay,
duplicate count-helper policy, and matching catalog/schema validation. This is
larger than a conflict resolution.

## Bounded fallback

For a context with raw demand handles, a raw eligible explicit or whitespace split
runtime declaration selects eager preparation. Every raw body is loaded before
normal fusions. The demand index and the later compact whole-pipeline index are
both skipped for that catalog. The second skip matters while demand handles are
still attached: a normal compact index cannot supply demand checkpoint metadata.

Ordinary per-stage transformation/final caches and emission artifact caches remain
active. String/byte slice-only catalogs retain main demand and fusion checkpoint
reuse. An eligible split declaration conservatively selects the fallback even if
its uses would fail S2's individual escape/update guards. No bodies are decoded
merely to select the fallback; no runtime behavior or optimization is disabled.
This is a declared compile-time compatibility bound, not a timing methodology
change. Final compile-time comparisons must use this actual integrated compiler.

## Pending validation

The four scratch tests compare canonical Core, LLVM, facts, ownership, plans,
ancestry, and cached-unit emission with the eager oracle through existing helpers:

1. Offset lists with generated record/list types, fixed prefixes, duplicate count
   declarations, and lazy explicit iteration: cold/warm equality, all raw bodies
   present, and ordinary warm-stage hits in both modes.
2. Whitespace-only dictionary probe/insertion: same checks without an explicit
   split declaration masking the whitespace fallback predicate.
3. A dirty function swaps prefix helper creation order 1/2 to 2/1 under an equal
   raw catalog, with an unchanged split-using spectator and idle function. Assert
   the actual prefix order and compare dirty/repeated output to a fresh oracle.
4. Byte views without splits: warm raw loading decreases and an idle function
   stays deferred; dirty-caller and repeated output match the eager oracle.

These tests are reviewed source, not executed proof. After the stable-tree gate
finishes and the proposal is applied, run formatting and the four focused tests
through the normal build slot, then the complete required integration gates.
Example focused selector: `zig build test-core -Dtest-filter="optimizer split catalogs"`
(and the other three exact names/prefixes from tests.patch). Do not run builds
under the CPU10 quiet lock.
