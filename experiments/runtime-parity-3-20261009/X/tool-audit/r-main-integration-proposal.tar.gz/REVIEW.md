Proposed R compatibility patch against ffee2b9d703e61386e968e7eff20f4f98623ef05.

Apply only after the real R merge. Neither passes.zig nor optimization_cache_test.zig is changed by accepted R handoff e83dfeb6 relative to M0; the patch therefore targets the exact root versions expected after that merge.

The no-record shortcut must provide module to exploratory Context.fields and the final FieldIntervals. R literal-array hull and fixed-array-bound analysis consult fields.module even when no record field fixed point is necessary. Both prior production edits are preserved unchanged.

The two NEW-CORE-R-ARRAY-2 tests preserve the previous proposed semantics: no record compound, literal [0,4] and updated [-7,4] hulls at length 5, eager/deferred cached equivalence, trusted check removal, verify check retention, and cold/warm demand/compact emission equivalence without rebuilding keys or restoring final bodies. All four existing S2 integration tests and helpers remain byte-for-byte unchanged before this appended section. S2 splitFusionCatalog is restricted to split producers, absent in the array-only fixture; it does not intentionally disable this fixture's demand path.

Allocator hygiene was reviewed against guardian-zig/src/checks/allocator_hygiene.zig. Every added std.testing.allocator expression remains inside a test block. expectArrayOnly accepts backing, owns/deinitializes its local arena, and forwards the injected arena allocator into source building. expectArrayHulls allocates nothing. No allocator waiver is added.

Validation is limited to patch applicability and static inspection. The patch has not been compiled, run, or evaluated by Guardian; root must run the regression tests and ordinary post-merge gates.
