#!/usr/bin/env python3
"""Pure-Python proof: no compiler or guest process is launched."""
import contextlib
import hashlib
import importlib.util
import itertools
import json
import os
from pathlib import Path
import random
import sys
import tempfile
from types import SimpleNamespace
from unittest import mock

AREA = Path(__file__).resolve().parent
TOOLS = Path('/home/epentland/ai/canopy/mylang-worktrees/codex-runtime-parity-3/experiments/runtime-parity-3-20261009/tools')
sys.path.insert(0, str(TOOLS))
spec = importlib.util.spec_from_file_location('checked_pair_proposal', AREA / 'parity_pair.proposed.py')
pair = importlib.util.module_from_spec(spec)
spec.loader.exec_module(pair)
tempfile.tempdir = str(AREA)
BINARY = AREA / 'never-executed'
WANTED = b'expected output\n'
EXPECTED = {str(BINARY): WANTED}
JOB = {'bench': 'fixture', 'arm': 'my', 'bin': BINARY}
OPTS = SimpleNamespace(warmups=2, rounds=3)
results = []

@contextlib.contextmanager
def executions(statuses, outputs=None):
    statuses = iter(statuses)
    outputs = iter(outputs) if outputs is not None else itertools.repeat(WANTED)
    ticks = itertools.count(0, 10_000_000)
    calls = []
    def spawn(binary, argv, environment, file_actions):
        action, descriptor, target = file_actions[0]
        assert action == os.POSIX_SPAWN_DUP2 and target == 1
        calls.append((binary, argv))
        os.write(descriptor, next(outputs))
        return 900001
    def wait(pid, options):
        assert pid == 900001 and options == 0
        return pid, next(statuses) << 8, SimpleNamespace(ru_utime=0.002, ru_stime=0.001)
    with mock.patch.object(pair.os, 'posix_spawn', side_effect=spawn), \
         mock.patch.object(pair.os, 'wait4', side_effect=wait), \
         mock.patch.object(pair.time, 'perf_counter_ns', side_effect=lambda: next(ticks)):
        yield calls

# Native success samples, warmup exclusion, and output shape remain identical.
with mock.patch.object(pair.BP, 'run_timed', return_value=(0.01, 0.003, 0)):
    baseline = pair.BP.measure([JOB], OPTS, random.Random(7))
with executions([0] * 5) as calls, mock.patch.object(pair.BP, 'run_timed', pair.checked_timer(EXPECTED)):
    actual = pair.BP.measure([JOB], OPTS, random.Random(7))
assert actual == baseline == {'my': {'wall': [0.01] * 3, 'cpu': [0.003] * 3}}
assert len(calls) == 5
results.append('successful native sample shape, values, count, and two-warmup exclusion unchanged')

for label, statuses, expected_calls in [('warmup', [7], 1), ('timed', [0, 0, 7], 3)]:
    with executions(statuses) as calls, mock.patch.object(pair.BP, 'run_timed', pair.checked_timer(EXPECTED)):
        try:
            pair.BP.measure([JOB], OPTS, random.Random(7))
        except pair.TimingFailure as failure:
            assert failure.details['status'] == 7
        else:
            raise AssertionError(label + ' failure was admitted')
    assert len(calls) == expected_calls
    results.append(label + ' nonzero exit rejected immediately')

for label, outputs, expected_calls in [('warmup', [b'wrong\n'], 1), ('timed', [WANTED, WANTED, b'wrong\n'], 3)]:
    with executions([0] * expected_calls, outputs) as calls, mock.patch.object(pair.BP, 'run_timed', pair.checked_timer(EXPECTED)):
        try:
            pair.BP.measure([JOB], OPTS, random.Random(7))
        except pair.TimingFailure as failure:
            assert failure.details['status'] == 0
            assert failure.details['stdout_sha256'] != failure.details['expected_stdout_sha256']
        else:
            raise AssertionError(label + ' wrong output was admitted')
    assert len(calls) == expected_calls
    results.append(label + ' zero-exit wrong stdout rejected from that same execution')

# The native timer and time_benchmark confirmation both call the replaced timer.
with executions([7]), mock.patch.object(pair.BP, 'run_timed', pair.checked_timer(EXPECTED)):
    try:
        pair.BP.confirm_benchmark({'arms': {'my': {}}}, [JOB], OPTS, random.Random(7))
    except pair.TimingFailure:
        results.append('native confirmation warmup is covered by the checked timer')
    else:
        raise AssertionError('confirmation failed execution admitted')

# Error receipt creation is additive; no earlier diagnostic is replaced.
failure = pair.TimingFailure({'binary': str(BINARY), 'status': 7})
with tempfile.TemporaryDirectory(dir=AREA) as scratch:
    out = Path(scratch) / 'pair.json'
    pair.timing_failure(out, failure)
    pair.timing_failure(out, failure)
    receipts = list(Path(scratch).glob('pair-timing-failure-*.json'))
    assert len(receipts) == 2
    assert all(json.loads(path.read_text()) == {'complete': False, 'timing_failure': failure.details} for path in receipts)
results.append('two failures produce distinct retained incomplete receipts')

# Integration wrapper reports status 2, which part3.sh refuses to treat as a speed miss.
with tempfile.TemporaryDirectory(dir=AREA) as scratch:
    root = Path(scratch)
    argv = ['parity_pair.py', '--base', str(root / 'base'), 'run', '--mylang', str(root / 'candidate'), '--work', str(root / 'work'), '--json', str(root / 'pair.json')]
    fake_registry = [{'name': 'fixture', 'ports': {}, 'expected': WANTED}]
    timer_before = pair.BP.run_timed
    with mock.patch.object(sys, 'argv', argv), mock.patch.object(pair, 'ROOT', root), \
         mock.patch.object(pair, 'digest', return_value='a' * 64), \
         mock.patch.object(pair, 'paired_arms', return_value=[{'arm': 'my'}]), \
         mock.patch.object(pair.BP, 'OffTimingCpus', contextlib.nullcontext), \
         mock.patch.object(pair.BP, 'discover', return_value=fake_registry), \
         mock.patch.object(pair.BP, 'main', side_effect=failure):
        assert pair.main() == 2
    assert pair.BP.run_timed is timer_before
    receipts = list(root.glob('pair-timing-failure-*.json'))
    assert len(receipts) == 1 and json.loads(receipts[0].read_text())['complete'] is False
results.append('wrapper returns status 2, retains failure, and restores the native timer')

proof = {'passed': len(results), 'tests': results, 'native_or_guest_processes_launched': 0,
         'tracked_files_edited': 0,
         'files': {path.name: hashlib.sha256(path.read_bytes()).hexdigest() for path in
                   [TOOLS / 'parity_pair.py', AREA / 'parity_pair.proposed.py', AREA / 'checked-parity.patch']},
         'method_note': 'Actual stdout is captured in a preopened temporary file; capture verification is outside native spawn/wait timing. Successful return/sample shape is unchanged, but output I/O changes from /dev/null equally for all paired arms.'}
(AREA / 'checked-parity-proof.json').write_text(json.dumps(proof, indent=1) + '\n')
print(json.dumps(proof, indent=1))
