#!/usr/bin/env python3
"""Read actual M0 receipts; corrupt copies in memory only. No native processes."""
from pathlib import Path
import copy
import hashlib
import importlib.util
import json
import statistics

AREA=Path(__file__).resolve().parent
TOOLS=Path('/home/epentland/ai/canopy/mylang-worktrees/codex-runtime-parity-3/experiments/runtime-parity-3-20261009/tools')
spec=importlib.util.spec_from_file_location('row_timing_proposal',AREA/'timing_data.proposed.py')
td=importlib.util.module_from_spec(spec)
spec.loader.exec_module(td)
inputs=[TOOLS.parent/'M0'/f'rows-base-{i}.json.gz' for i in (1,2,3)]
batches=[td.read(path) for path in inputs]
result=td.row_ratios(batches)
assert len(result)==92
runner=td.row_runner()
name=next(name for name,definition in runner.UNITS.items() if definition[1]=='element')

def arm(b, batch=0, size='64'):
    return b[batch]['rows'][name]['sizes'][size]['configurations']['new core release']

def cell(b,batch=0,size='64'):
    return b[batch]['rows'][name]['sizes'][size]

def unsubtracted(b):
    a=arm(b)
    a['cycles_per_unit']=statistics.median(run['cycles'] for run in a['runs'])/(64*cell(b)['iterations'])

def batch_checksum(b):
    c=cell(b,1)
    c['checksum']+=1
    for a in c['configurations'].values():
        for run in a['runs']:
            run['checksum']=c['checksum']
            run['stdout']=f"{run['checksum']} {run['elapsed_ns']}\n"

def bad_work_command(b):
    arm(b)['runs'][0]['command'][-2]=str(cell(b)['iterations']+1)

def bad_start_command(b):
    arm(b)['startup'][0]['command'][-2]='2'

def bad_seed(b):
    arm(b)['runs'][0]['command'][-1]='8'

def wrong_names(b):
    for batch in b:
        batch['rows']['unknown-row']=batch['rows'].pop(name)

mutations={
    'changed normalized cycles':lambda b: arm(b).__setitem__('cycles_per_unit',arm(b)['cycles_per_unit']*2),
    'startup subtraction omitted':unsubtracted,
    'startup checksum mismatch':lambda b: arm(b)['startup'][0].__setitem__('checksum',-123),
    'workload checksum mismatch':lambda b: arm(b)['runs'][0].__setitem__('checksum',-123),
    'whole-batch workload checksum drift':batch_checksum,
    'wrong registered iterations':lambda b: cell(b).__setitem__('iterations',cell(b)['iterations']+1),
    'wrong workload command iterations':bad_work_command,
    'wrong startup command iterations':bad_start_command,
    'wrong seed':bad_seed,
    'wrong unit':lambda b: b[0]['rows'][name].__setitem__('unit','iteration'),
    'raw cycles disagree with parsed counter':lambda b: arm(b)['runs'][0].__setitem__('cycles',arm(b)['runs'][0]['cycles']+1),
    'missing startup run':lambda b: arm(b)['startup'].pop(),
    'missing size64':lambda b: b[0]['rows'][name]['sizes'].pop('64'),
    'unregistered replacement row':wrong_names,
}
passed=[]
for label,mutate in mutations.items():
    changed=copy.deepcopy(batches)
    mutate(changed)
    try:
        td.row_ratios(changed)
    except (AssertionError,runner.InvalidMeasurement):
        passed.append(label)
    else:
        raise AssertionError('corruption admitted: '+label)
# Tight tolerance permits only floating serialization-scale differences.
changed=copy.deepcopy(batches)
arm(changed)['cycles_per_unit']*=1+1e-14
td.row_ratios(changed)
proof={'actual_m0_batches_passed':3,'rows_per_batch':46,'sizes':['4096','64'],'validated_row_size_cells':276,
       'rejected_corruptions':passed,'floating_serialization_tolerance_accepted':True,
       'native_or_guest_processes_launched':0,'tracked_files_edited':0,
       'inputs':[td.identity(path) for path in inputs],
       'files':{path.name:hashlib.sha256(path.read_bytes()).hexdigest() for path in
                [TOOLS/'timing_data.py',AREA/'timing_data.proposed.py',AREA/'validate-row-timing.patch']}}
(AREA/'row-timing-proof.json').write_text(json.dumps(proof,indent=1)+'\n')
print(json.dumps(proof,indent=1))
