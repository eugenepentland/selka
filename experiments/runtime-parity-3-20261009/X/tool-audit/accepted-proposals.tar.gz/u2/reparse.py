#!/usr/bin/env python3
"""Reclassify retained U2 perf samples with recorded, immutable sample identities."""
import ast
import collections
import hashlib
import json
import os
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parents[2]
SCRATCH = Path(__file__).resolve().parent
AREA = ROOT / 'experiments/runtime-parity-3-20261009/U2'
source = (SCRATCH / 'profile_alloc.py').read_text()
nodes = []
for node in ast.parse(source).body:
    if isinstance(node, ast.FunctionDef) and node.name in {'canonical', 'allocation', 'ambiguous', 'generated_release', 'classify_stack'}:
        nodes.append(node)
    if isinstance(node, ast.Assign) and any(isinstance(target, ast.Name) and target.id in {'ALL_FAMILY', 'AMBIGUOUS_FAMILY', 'FAMILY'} for target in node.targets):
        nodes.append(node)
namespace = {}
exec(compile(ast.Module(body=nodes, type_ignores=[]), str(SCRATCH / 'profile_alloc.py'), 'exec'), namespace)
canonical, classify = namespace['canonical'], namespace['classify_stack']
assert os.sched_getaffinity(0) == {8}
result = {'complete': False, 'analysis_cpu': 8, 'fresh_sampling': False,
          'method': 'Existing LBR sample periods reparsed with identical strict/ambiguous definitions in both arms. Strict allocation/free ancestors include their descendants; ambiguous-only stacks are disjoint. Binary identities are copied from the original sample receipts, never inferred from current binaries.',
          'limitation': 'Bounded LBR stacks and missing inline metadata omit allocation/free attribution. Strict share is a lower bound; ambiguous share is unresolved, not an upper bound.',
          'strict_family': sorted(namespace['FAMILY']), 'ambiguous_family': sorted(namespace['AMBIGUOUS_FAMILY']),
          'patch_sha256': hashlib.sha256((SCRATCH / 'profile_alloc.patch').read_bytes()).hexdigest(), 'arms': {}}
for tag in ('base', 'u2'):
    receipt_path = AREA / ('profile-' + tag + '.json')
    receipt_bytes = receipt_path.read_bytes()
    receipt = json.loads(receipt_bytes)
    designs = result['arms'][tag] = {}
    for name, original in receipt['designs'].items():
        perf = ROOT / original['raw_scratch']
        assert hashlib.sha256(perf.read_bytes()).hexdigest() == original['raw_sha256']
        text = subprocess.check_output(['perf', 'script', '-i', str(perf), '-F', 'comm,period,ip,sym', '--inline'], text=True)
        total = strict = ambiguous = prior_family = 0
        uncertain_tops = collections.Counter()
        examples = []
        for event in text.split('\n\n'):
            lines = event.splitlines()
            if not lines or not lines[0].startswith('eda-plain '):
                continue
            period = int(lines[0].split()[1])
            stack = [canonical(line.strip().split(' ', 1)[1].strip()) for line in lines[1:] if ' ' in line.strip()]
            total += period
            matched, uncertain = classify(stack)
            strict += period * matched
            ambiguous += period * uncertain
            legacy = any(symbol in namespace['ALL_FAMILY'] or namespace['generated_release'](symbol) for symbol in stack)
            prior_family += period * legacy
            assert legacy == (matched or uncertain)
            if uncertain:
                uncertain_tops[stack[0]] += period
                if len(examples) < 5:
                    examples.append(stack)
        assert total == original['total_period'], (tag, name, total, original['total_period'])
        assert prior_family == original['allocation_release_period']
        designs[name] = {'total_period': total, 'strict_period': strict, 'strict_share_lower_bound': strict / total,
                         'ambiguous_period': ambiguous, 'ambiguous_share': ambiguous / total,
                         'prior_family_period': prior_family, 'prior_family_share': prior_family / total,
                         'ambiguous_top_exclusive': uncertain_tops.most_common(15), 'ambiguous_examples': examples,
                         'recorded_binary_sha256': original['binary_sha256'], 'recorded_raw_sha256': original['raw_sha256'],
                         'raw_scratch': original['raw_scratch'], 'receipt': str(receipt_path),
                         'receipt_sha256': hashlib.sha256(receipt_bytes).hexdigest()}
        print(tag, name, strict / total, ambiguous / total, flush=True)
        (SCRATCH / 'corrected-profiles.json').write_text(json.dumps(result, indent=1) + '\n')
result['complete'] = True
(SCRATCH / 'corrected-profiles.json').write_text(json.dumps(result, indent=1) + '\n')
