define internal fastcc void @"my.sexpr_parser::parse_list"(ptr noalias sret([144 x i8]) align 8 %ret, ptr noalias align 8 %p0, { i64, i64, i64 } %p1, i64 %p2, { { i64, i64, i64 }, ptr } %p3, ptr noalias %payload) nounwind uwtable !dbg !1007249 {
entry:
  %slot = alloca i64, align 8
  %stack.1 = alloca [40 x i8], align 8
  %stack.2 = alloca [136 x i8], align 8
  %stack.3 = alloca [40 x i8], align 8
  %stack.4 = alloca [144 x i8], align 8
  %v8 = getelementptr inbounds i8, ptr %stack.1, i64 0
  %v20 = getelementptr inbounds i8, ptr %p0, i64 0
  %v22 = getelementptr inbounds i8, ptr %stack.2, i64 0
  %v24 = getelementptr inbounds i8, ptr %p0, i64 0
  %v44 = getelementptr inbounds i8, ptr %stack.3, i64 0
  %v61 = getelementptr inbounds i8, ptr %stack.4, i64 0
  %v63 = getelementptr inbounds i8, ptr %p0, i64 0
  %state0.len = alloca i64, align 8
  %state0.cap = alloca i64, align 8
  %stack.247 = alloca [8 x i8], align 8
  %stack.266 = alloca [8 x i8], align 8
  %stack.285 = alloca [8 x i8], align 8
  %stack.339 = alloca [8 x i8], align 8
  %stack.360 = alloca [8 x i8], align 8
  %stack.381 = alloca [8 x i8], align 8
  %stack.457 = alloca [8 x i8], align 8
  %stack.476 = alloca [8 x i8], align 8
  %stack.495 = alloca [8 x i8], align 8
  %myl.cnt.saved = load ptr, ptr @myl_count_current, align 8
  %myl.cnt.active = call ptr @myl_count_function_local(ptr @myl.cf.131)
  store ptr %myl.cnt.active, ptr @myl_count_current, align 8
  %myl.cnt.calls.at = getelementptr inbounds i8, ptr %myl.cnt.active, i64 8
  %myl.cnt.calls = load i64, ptr %myl.cnt.calls.at, align 8
  %myl.cnt.calls.1 = add i64 %myl.cnt.calls, 1
  store i64 %myl.cnt.calls.1, ptr %myl.cnt.calls.at, align 8
  br label %b0
b0:
  %v5 = icmp sge i64 %p2, 10000
  br i1 %v5, label %b1, label %b2
b1:
  %v7 = insertvalue { i8, [0 x i64] } poison, i8 5, 0
  notail call fastcc void @"my.sexpr_parser::fail"(ptr sret([40 x i8]) align 8 %v8, { { i64, i64, i64 }, ptr } %p3, { i64, i64, i64 } %p1, { i8, [0 x i64] } %v7), !dbg !1007251
  %lt.5 = load i64, ptr %v8, align 8, !tbaa !7
  %lt.6 = trunc i64 %lt.5 to i8
  %v9 = insertvalue { i8, [0 x i64] } poison, i8 %lt.6, 0
  %fp.7 = getelementptr inbounds i8, ptr %v8, i64 8
  %fp.8 = getelementptr inbounds i8, ptr %v8, i64 8
  %lf.10 = load i64, ptr %fp.8, align 8, !tbaa !7
  %lr.11 = insertvalue { i64, i64, i64 } poison, i64 %lf.10, 0
  %fp.13 = getelementptr inbounds i8, ptr %fp.8, i64 8
  %lf.12 = load i64, ptr %fp.13, align 8, !tbaa !7
  %lr.14 = insertvalue { i64, i64, i64 } %lr.11, i64 %lf.12, 1
  %fp.16 = getelementptr inbounds i8, ptr %fp.8, i64 16
  %lf.15 = load i64, ptr %fp.16, align 8, !tbaa !7
  %lf.9 = insertvalue { i64, i64, i64 } %lr.14, i64 %lf.15, 2
  %lr.17 = insertvalue { { i64, i64, i64 }, ptr } poison, { i64, i64, i64 } %lf.9, 0
  %fp.19 = getelementptr inbounds i8, ptr %fp.8, i64 24
  %lf.18 = load ptr, ptr %fp.19, align 8, !tbaa !7
  %v10 = insertvalue { { i64, i64, i64 }, ptr } %lr.17, ptr %lf.18, 1
  call preserve_mostcc void @myl_core_err_trace_origin_preserve_most(ptr @myl.site.2873) #1
  store i64 1, ptr %ret, align 8, !tbaa !7
  %st.20 = extractvalue { i8, [0 x i64] } %v9, 0
  %st.21 = zext i8 %st.20 to i64
  store i64 %st.21, ptr %payload, align 8, !tbaa !7
  %fp.22 = getelementptr inbounds i8, ptr %payload, i64 8
  %fp.23 = getelementptr inbounds i8, ptr %ret, i64 112
  %sf.24 = extractvalue { { i64, i64, i64 }, ptr } %v10, 0
  %sf.25 = extractvalue { i64, i64, i64 } %sf.24, 0
  store i64 %sf.25, ptr %fp.23, align 8, !tbaa !7
  %sf.26 = extractvalue { i64, i64, i64 } %sf.24, 1
  %fp.27 = getelementptr inbounds i8, ptr %fp.23, i64 8
  store i64 %sf.26, ptr %fp.27, align 8, !tbaa !7
  %sf.28 = extractvalue { i64, i64, i64 } %sf.24, 2
  %fp.29 = getelementptr inbounds i8, ptr %fp.23, i64 16
  store i64 %sf.28, ptr %fp.29, align 8, !tbaa !7
  %sf.30 = extractvalue { { i64, i64, i64 }, ptr } %v10, 1
  %fp.31 = getelementptr inbounds i8, ptr %fp.23, i64 24
  store ptr %sf.30, ptr %fp.31, align 8, !tbaa !7
  store ptr %myl.cnt.saved, ptr @myl_count_current, align 8
  ret void
b2:
  %v16 = call ptr @myl_core_list_new(i64 0, i64 48)
  %lay.32 = getelementptr inbounds i8, ptr %v16, i64 24
  store ptr @myl.layout.1, ptr %lay.32, align 8, !tbaa !5
  %stl.33 = getelementptr inbounds i8, ptr %v16, i64 8
  %stl.34 = load i64, ptr %stl.33, align 8, !tbaa !5
  store i64 %stl.34, ptr %state0.len, align 8
  %stc.35 = getelementptr inbounds i8, ptr %v16, i64 16
  %stc.36 = load i64, ptr %stc.35, align 8, !tbaa !5
  store i64 %stc.36, ptr %state0.cap, align 8
  br label %b3
b3:
  %v21 = phi { { i64, i64, i64 }, ptr } [ %p3, %b2 ], [ %v64, %b5 ]
  %v75 = phi ptr [ %v16, %b2 ], [ %v76, %b5 ]
  br label %b4
b4:
  notail call fastcc void @"my.sexpr_parser::next_token"(ptr sret([136 x i8]) align 8 %v22, ptr %v24, { { i64, i64, i64 }, ptr } %v21), !dbg !1007253
  %v23 = getelementptr inbounds i8, ptr %v22, i64 0
  %fp.37 = getelementptr inbounds i8, ptr %v22, i64 104
  %lf.39 = load i64, ptr %fp.37, align 8, !tbaa !7
  %lr.40 = insertvalue { i64, i64, i64 } poison, i64 %lf.39, 0
  %fp.42 = getelementptr inbounds i8, ptr %fp.37, i64 8
  %lf.41 = load i64, ptr %fp.42, align 8, !tbaa !7
  %lr.43 = insertvalue { i64, i64, i64 } %lr.40, i64 %lf.41, 1
  %fp.45 = getelementptr inbounds i8, ptr %fp.37, i64 16
  %lf.44 = load i64, ptr %fp.45, align 8, !tbaa !7
  %lf.38 = insertvalue { i64, i64, i64 } %lr.43, i64 %lf.44, 2
  %lr.46 = insertvalue { { i64, i64, i64 }, ptr } poison, { i64, i64, i64 } %lf.38, 0
  %fp.48 = getelementptr inbounds i8, ptr %fp.37, i64 24
  %lf.47 = load ptr, ptr %fp.48, align 8, !tbaa !7
  %v25 = insertvalue { { i64, i64, i64 }, ptr } %lr.46, ptr %lf.47, 1
  %t.49 = load i64, ptr %v23, align 8, !tbaa !7
  %v26 = trunc i64 %t.49 to i32
  %v28 = icmp eq i32 %v26, 1
  br i1 %v28, label %edge.50, label %b8
edge.50:
  %sts.51 = load i64, ptr %state0.len, align 8
  %sts.52 = getelementptr inbounds i8, ptr %v75, i64 8
  store i64 %sts.51, ptr %sts.52, align 8, !tbaa !5
  br label %b7
b5:
  br label %b3
b6:
  %v85 = getelementptr i8, ptr null, i64 0
  store i64 0, ptr %ret, align 8, !tbaa !7
  store i64 0, ptr %payload, align 8, !tbaa !7
  %fp.53 = getelementptr inbounds i8, ptr %payload, i64 8
  store ptr %v75, ptr %fp.53, align 8, !tbaa !7
  %fp.54 = getelementptr inbounds i8, ptr %payload, i64 16
  %sf.55 = extractvalue { i64, i64, i64 } %p1, 0
  store i64 %sf.55, ptr %fp.54, align 8, !tbaa !7
  %sf.56 = extractvalue { i64, i64, i64 } %p1, 1
  %fp.57 = getelementptr inbounds i8, ptr %fp.54, i64 8
  store i64 %sf.56, ptr %fp.57, align 8, !tbaa !7
  %sf.58 = extractvalue { i64, i64, i64 } %p1, 2
  %fp.59 = getelementptr inbounds i8, ptr %fp.54, i64 16
  store i64 %sf.58, ptr %fp.59, align 8, !tbaa !7
  %fp.60 = getelementptr inbounds i8, ptr %payload, i64 40
  store ptr %v85, ptr %fp.60, align 8, !tbaa !7
  %fp.61 = getelementptr inbounds i8, ptr %ret, i64 112
  %sf.62 = extractvalue { { i64, i64, i64 }, ptr } %v25, 0
  %sf.63 = extractvalue { i64, i64, i64 } %sf.62, 0
  store i64 %sf.63, ptr %fp.61, align 8, !tbaa !7
  %sf.64 = extractvalue { i64, i64, i64 } %sf.62, 1
  %fp.65 = getelementptr inbounds i8, ptr %fp.61, i64 8
  store i64 %sf.64, ptr %fp.65, align 8, !tbaa !7
  %sf.66 = extractvalue { i64, i64, i64 } %sf.62, 2
  %fp.67 = getelementptr inbounds i8, ptr %fp.61, i64 16
  store i64 %sf.66, ptr %fp.67, align 8, !tbaa !7
  %sf.68 = extractvalue { { i64, i64, i64 }, ptr } %v25, 1
  %fp.69 = getelementptr inbounds i8, ptr %fp.61, i64 24
  store ptr %sf.68, ptr %fp.69, align 8, !tbaa !7
  store ptr %myl.cnt.saved, ptr @myl_count_current, align 8
  ret void
b7:
  %cnt.70.record = call ptr @myl_count_site_local(ptr @myl.cs.51242)
  %cnt.70.at = getelementptr inbounds i8, ptr %cnt.70.record, i64 48
  %cnt.70 = load i64, ptr %cnt.70.at, align 8
  %cnt.71 = add i64 %cnt.70, 1
  store i64 %cnt.71, ptr %cnt.70.at, align 8
  call void @myl_core_free(ptr %v75)
  call preserve_mostcc void @myl_core_err_trace_append_preserve_most(ptr @myl.site.2874) #1
  %fp.72 = getelementptr inbounds i8, ptr %v23, i64 8
  %lt.73 = load i64, ptr %fp.72, align 8, !tbaa !7
  %lt.74 = trunc i64 %lt.73 to i8
  %v31 = insertvalue { i8, [0 x i64] } poison, i8 %lt.74, 0
  %fp.75 = getelementptr inbounds i8, ptr %fp.72, i64 8
  %cw.76 = load i64, ptr %v23, align 8, !tbaa !7
  %ct.77 = trunc i64 %cw.76 to i8
  %cc.78 = icmp eq i8 %ct.77, 0
  br i1 %cc.78, label %rc.then.79, label %b7.80
rc.then.79:
  %fp.81 = getelementptr inbounds i8, ptr %v23, i64 8
  %fp.82 = getelementptr inbounds i8, ptr %fp.81, i64 8
  %cm.83 = load ptr, ptr %fp.82, align 8, !tbaa !7
  %cnt.84.record = call ptr @myl_count_site_local(ptr @myl.cs.51243)
  %cnt.84.at = getelementptr inbounds i8, ptr %cnt.84.record, i64 48
  %cnt.84 = load i64, ptr %cnt.84.at, align 8
  %cnt.85 = add i64 %cnt.84, 1
  store i64 %cnt.85, ptr %cnt.84.at, align 8
  %rc.86 = load atomic i32, ptr %cm.83 unordered, align 8, !tbaa !3, !range !8
  %rp.87 = icmp ult i32 %rc.86, 2147483648
  br i1 %rp.87, label %rc.dec.88, label %rc.slow.89, !prof !23
rc.dec.88:
  %rn.91 = sub nuw i32 %rc.86, 1
  %rz.92 = icmp eq i32 %rn.91, 0
  br i1 %rz.92, label %rc.free.94, label %rc.keep.93
rc.keep.93:
  store i32 %rn.91, ptr %cm.83, align 8, !tbaa !3
  br label %rc.then.90
rc.free.94:
  call void @myl_core_free(ptr %cm.83)
  br label %rc.then.90
rc.slow.89:
  call preserve_mostcc void @myl_core_release_slow(ptr %cm.83)
  br label %rc.then.90
rc.then.90:
  br label %b7.80
b7.80:
  store i64 1, ptr %ret, align 8, !tbaa !7
  %st.95 = extractvalue { i8, [0 x i64] } %v31, 0
  %st.96 = zext i8 %st.95 to i64
  store i64 %st.96, ptr %payload, align 8, !tbaa !7
  %fp.97 = getelementptr inbounds i8, ptr %payload, i64 8
  %fp.98 = getelementptr inbounds i8, ptr %ret, i64 112
  %sf.99 = extractvalue { { i64, i64, i64 }, ptr } %v25, 0
  %sf.100 = extractvalue { i64, i64, i64 } %sf.99, 0
  store i64 %sf.100, ptr %fp.98, align 8, !tbaa !7
  %sf.101 = extractvalue { i64, i64, i64 } %sf.99, 1
  %fp.102 = getelementptr inbounds i8, ptr %fp.98, i64 8
  store i64 %sf.101, ptr %fp.102, align 8, !tbaa !7
  %sf.103 = extractvalue { i64, i64, i64 } %sf.99, 2
  %fp.104 = getelementptr inbounds i8, ptr %fp.98, i64 16
  store i64 %sf.103, ptr %fp.104, align 8, !tbaa !7
  %sf.105 = extractvalue { { i64, i64, i64 }, ptr } %v25, 1
  %fp.106 = getelementptr inbounds i8, ptr %fp.98, i64 24
  store ptr %sf.105, ptr %fp.106, align 8, !tbaa !7
  store ptr %myl.cnt.saved, ptr @myl_count_current, align 8
  ret void
b8:
  %v35 = getelementptr inbounds i8, ptr %v23, i64 8
  %lt.107 = load i64, ptr %v35, align 8, !tbaa !7
  %lt.108 = trunc i64 %lt.107 to i8
  %v36 = insertvalue { i8, [0 x i64] } poison, i8 %lt.108, 0
  %fp.109 = getelementptr inbounds i8, ptr %v35, i64 8
  %v37 = insertvalue { i8, [0 x i64] } poison, i8 8, 0
  %t.110 = extractvalue { i8, [0 x i64] } %v36, 0
  %v38 = zext i8 %t.110 to i32
  %t.111 = extractvalue { i8, [0 x i64] } %v37, 0
  %v39 = zext i8 %t.111 to i32
  %v40 = icmp eq i32 %v38, %v39
  br i1 %v40, label %edge.112, label %b10
edge.112:
  %sts.113 = load i64, ptr %state0.len, align 8
  %sts.114 = getelementptr inbounds i8, ptr %v75, i64 8
  store i64 %sts.113, ptr %sts.114, align 8, !tbaa !5
  br label %b9
b9:
  %cw.115 = load i64, ptr %v23, align 8, !tbaa !7
  %ct.116 = trunc i64 %cw.115 to i8
  %cc.117 = icmp eq i8 %ct.116, 0
  br i1 %cc.117, label %rc.then.118, label %b9.119
rc.then.118:
  %fp.120 = getelementptr inbounds i8, ptr %v23, i64 8
  %fp.121 = getelementptr inbounds i8, ptr %fp.120, i64 8
  %cm.122 = load ptr, ptr %fp.121, align 8, !tbaa !7
  %cnt.123.record = call ptr @myl_count_site_local(ptr @myl.cs.51244)
  %cnt.123.at = getelementptr inbounds i8, ptr %cnt.123.record, i64 48
  %cnt.123 = load i64, ptr %cnt.123.at, align 8
  %cnt.124 = add i64 %cnt.123, 1
  store i64 %cnt.124, ptr %cnt.123.at, align 8
  %rc.125 = load atomic i32, ptr %cm.122 unordered, align 8, !tbaa !3, !range !8
  %rp.126 = icmp ult i32 %rc.125, 2147483648
  br i1 %rp.126, label %rc.dec.127, label %rc.slow.128, !prof !23
rc.dec.127:
  %rn.130 = sub nuw i32 %rc.125, 1
  %rz.131 = icmp eq i32 %rn.130, 0
  br i1 %rz.131, label %rc.free.133, label %rc.keep.132
rc.keep.132:
  store i32 %rn.130, ptr %cm.122, align 8, !tbaa !3
  br label %rc.then.129
rc.free.133:
  call void @myl_core_free(ptr %cm.122)
  br label %rc.then.129
rc.slow.128:
  call preserve_mostcc void @myl_core_release_slow(ptr %cm.122)
  br label %rc.then.129
rc.then.129:
  br label %b9.119
b9.119:
  %cnt.134.record = call ptr @myl_count_site_local(ptr @myl.cs.51245)
  %cnt.134.at = getelementptr inbounds i8, ptr %cnt.134.record, i64 48
  %cnt.134 = load i64, ptr %cnt.134.at, align 8
  %cnt.135 = add i64 %cnt.134, 1
  store i64 %cnt.135, ptr %cnt.134.at, align 8
  call void @myl_core_free(ptr %v75)
  %v43 = insertvalue { i8, [0 x i64] } poison, i8 0, 0
  notail call fastcc void @"my.sexpr_parser::fail"(ptr sret([40 x i8]) align 8 %v44, { { i64, i64, i64 }, ptr } %v25, { i64, i64, i64 } %p1, { i8, [0 x i64] } %v43), !dbg !1007255
  %lt.136 = load i64, ptr %v44, align 8, !tbaa !7
  %lt.137 = trunc i64 %lt.136 to i8
  %v45 = insertvalue { i8, [0 x i64] } poison, i8 %lt.137, 0
  %fp.138 = getelementptr inbounds i8, ptr %v44, i64 8
  %fp.139 = getelementptr inbounds i8, ptr %v44, i64 8
  %lf.141 = load i64, ptr %fp.139, align 8, !tbaa !7
  %lr.142 = insertvalue { i64, i64, i64 } poison, i64 %lf.141, 0
  %fp.144 = getelementptr inbounds i8, ptr %fp.139, i64 8
  %lf.143 = load i64, ptr %fp.144, align 8, !tbaa !7
  %lr.145 = insertvalue { i64, i64, i64 } %lr.142, i64 %lf.143, 1
  %fp.147 = getelementptr inbounds i8, ptr %fp.139, i64 16
  %lf.146 = load i64, ptr %fp.147, align 8, !tbaa !7
  %lf.140 = insertvalue { i64, i64, i64 } %lr.145, i64 %lf.146, 2
  %lr.148 = insertvalue { { i64, i64, i64 }, ptr } poison, { i64, i64, i64 } %lf.140, 0
  %fp.150 = getelementptr inbounds i8, ptr %fp.139, i64 24
  %lf.149 = load ptr, ptr %fp.150, align 8, !tbaa !7
  %v46 = insertvalue { { i64, i64, i64 }, ptr } %lr.148, ptr %lf.149, 1
  call preserve_mostcc void @myl_core_err_trace_origin_preserve_most(ptr @myl.site.2875) #1
  store i64 1, ptr %ret, align 8, !tbaa !7
  %st.151 = extractvalue { i8, [0 x i64] } %v45, 0
  %st.152 = zext i8 %st.151 to i64
  store i64 %st.152, ptr %payload, align 8, !tbaa !7
  %fp.153 = getelementptr inbounds i8, ptr %payload, i64 8
  %fp.154 = getelementptr inbounds i8, ptr %ret, i64 112
  %sf.155 = extractvalue { { i64, i64, i64 }, ptr } %v46, 0
  %sf.156 = extractvalue { i64, i64, i64 } %sf.155, 0
  store i64 %sf.156, ptr %fp.154, align 8, !tbaa !7
  %sf.157 = extractvalue { i64, i64, i64 } %sf.155, 1
  %fp.158 = getelementptr inbounds i8, ptr %fp.154, i64 8
  store i64 %sf.157, ptr %fp.158, align 8, !tbaa !7
  %sf.159 = extractvalue { i64, i64, i64 } %sf.155, 2
  %fp.160 = getelementptr inbounds i8, ptr %fp.154, i64 16
  store i64 %sf.159, ptr %fp.160, align 8, !tbaa !7
  %sf.161 = extractvalue { { i64, i64, i64 }, ptr } %v46, 1
  %fp.162 = getelementptr inbounds i8, ptr %fp.154, i64 24
  store ptr %sf.161, ptr %fp.162, align 8, !tbaa !7
  store ptr %myl.cnt.saved, ptr @myl_count_current, align 8
  ret void
b10:
  %lt.163 = load i64, ptr %v35, align 8, !tbaa !7
  %lt.164 = trunc i64 %lt.163 to i8
  %v51 = insertvalue { i8, [0 x i64] } poison, i8 %lt.164, 0
  %fp.165 = getelementptr inbounds i8, ptr %v35, i64 8
  %v52 = insertvalue { i8, [0 x i64] } poison, i8 1, 0
  %t.166 = extractvalue { i8, [0 x i64] } %v51, 0
  %v53 = zext i8 %t.166 to i32
  %t.167 = extractvalue { i8, [0 x i64] } %v52, 0
  %v54 = zext i8 %t.167 to i32
  %v55 = icmp eq i32 %v53, %v54
  br i1 %v55, label %edge.168, label %b12
edge.168:
  %sts.169 = load i64, ptr %state0.len, align 8
  %sts.170 = getelementptr inbounds i8, ptr %v75, i64 8
  store i64 %sts.169, ptr %sts.170, align 8, !tbaa !5
  br label %b11
b11:
  %cw.171 = load i64, ptr %v23, align 8, !tbaa !7
  %ct.172 = trunc i64 %cw.171 to i8
  %cc.173 = icmp eq i8 %ct.172, 0
  br i1 %cc.173, label %rc.then.174, label %b11.175
rc.then.174:
  %fp.176 = getelementptr inbounds i8, ptr %v23, i64 8
  %fp.177 = getelementptr inbounds i8, ptr %fp.176, i64 8
  %cm.178 = load ptr, ptr %fp.177, align 8, !tbaa !7
  %cnt.179.record = call ptr @myl_count_site_local(ptr @myl.cs.51246)
  %cnt.179.at = getelementptr inbounds i8, ptr %cnt.179.record, i64 48
  %cnt.179 = load i64, ptr %cnt.179.at, align 8
  %cnt.180 = add i64 %cnt.179, 1
  store i64 %cnt.180, ptr %cnt.179.at, align 8
  %rc.181 = load atomic i32, ptr %cm.178 unordered, align 8, !tbaa !3, !range !8
  %rp.182 = icmp ult i32 %rc.181, 2147483648
  br i1 %rp.182, label %rc.dec.183, label %rc.slow.184, !prof !23
rc.dec.183:
  %rn.186 = sub nuw i32 %rc.181, 1
  %rz.187 = icmp eq i32 %rn.186, 0
  br i1 %rz.187, label %rc.free.189, label %rc.keep.188
rc.keep.188:
  store i32 %rn.186, ptr %cm.178, align 8, !tbaa !3
  br label %rc.then.185
rc.free.189:
  call void @myl_core_free(ptr %cm.178)
  br label %rc.then.185
rc.slow.184:
  call preserve_mostcc void @myl_core_release_slow(ptr %cm.178)
  br label %rc.then.185
rc.then.185:
  br label %b11.175
b11.175:
  br label %b6
b12:
  %v60 = add nsw i64 %p2, 1
  %fp.190 = getelementptr inbounds i8, ptr %v61, i64 8
  notail call fastcc void @"my.sexpr_parser::parse_node"(ptr sret([144 x i8]) align 8 %v61, ptr %v63, ptr %v35, i64 %v60, { { i64, i64, i64 }, ptr } %v25, ptr %fp.190), !dbg !1007257
  %cw.191 = load i64, ptr %v23, align 8, !tbaa !7
  %ct.192 = trunc i64 %cw.191 to i8
  %cc.193 = icmp eq i8 %ct.192, 0
  br i1 %cc.193, label %rc.then.194, label %b12.195
rc.then.194:
  %fp.196 = getelementptr inbounds i8, ptr %v23, i64 8
  %fp.197 = getelementptr inbounds i8, ptr %fp.196, i64 8
  %cm.198 = load ptr, ptr %fp.197, align 8, !tbaa !7
  %cnt.199.record = call ptr @myl_count_site_local(ptr @myl.cs.51247)
  %cnt.199.at = getelementptr inbounds i8, ptr %cnt.199.record, i64 48
  %cnt.199 = load i64, ptr %cnt.199.at, align 8
  %cnt.200 = add i64 %cnt.199, 1
  store i64 %cnt.200, ptr %cnt.199.at, align 8
  %rc.201 = load atomic i32, ptr %cm.198 unordered, align 8, !tbaa !3, !range !8
  %rp.202 = icmp ult i32 %rc.201, 2147483648
  br i1 %rp.202, label %rc.dec.203, label %rc.slow.204, !prof !23
rc.dec.203:
  %rn.206 = sub nuw i32 %rc.201, 1
  %rz.207 = icmp eq i32 %rn.206, 0
  br i1 %rz.207, label %rc.free.209, label %rc.keep.208
rc.keep.208:
  store i32 %rn.206, ptr %cm.198, align 8, !tbaa !3
  br label %rc.then.205
rc.free.209:
  call void @myl_core_free(ptr %cm.198)
  br label %rc.then.205
rc.slow.204:
  call preserve_mostcc void @myl_core_release_slow(ptr %cm.198)
  br label %rc.then.205
rc.then.205:
  br label %b12.195
b12.195:
  %v62 = getelementptr inbounds i8, ptr %v61, i64 0
  %fp.210 = getelementptr inbounds i8, ptr %v61, i64 112
  %lf.212 = load i64, ptr %fp.210, align 8, !tbaa !7
  %lr.213 = insertvalue { i64, i64, i64 } poison, i64 %lf.212, 0
  %fp.215 = getelementptr inbounds i8, ptr %fp.210, i64 8
  %lf.214 = load i64, ptr %fp.215, align 8, !tbaa !7
  %lr.216 = insertvalue { i64, i64, i64 } %lr.213, i64 %lf.214, 1
  %fp.218 = getelementptr inbounds i8, ptr %fp.210, i64 16
  %lf.217 = load i64, ptr %fp.218, align 8, !tbaa !7
  %lf.211 = insertvalue { i64, i64, i64 } %lr.216, i64 %lf.217, 2
  %lr.219 = insertvalue { { i64, i64, i64 }, ptr } poison, { i64, i64, i64 } %lf.211, 0
  %fp.221 = getelementptr inbounds i8, ptr %fp.210, i64 24
  %lf.220 = load ptr, ptr %fp.221, align 8, !tbaa !7
  %v64 = insertvalue { { i64, i64, i64 }, ptr } %lr.219, ptr %lf.220, 1
  %t.222 = load i64, ptr %v62, align 8, !tbaa !7
  %v65 = trunc i64 %t.222 to i32
  %v67 = icmp eq i32 %v65, 1
  br i1 %v67, label %edge.223, label %b14
edge.223:
  %sts.224 = load i64, ptr %state0.len, align 8
  %sts.225 = getelementptr inbounds i8, ptr %v75, i64 8
  store i64 %sts.224, ptr %sts.225, align 8, !tbaa !5
  br label %b13
b13:
  %cnt.226.record = call ptr @myl_count_site_local(ptr @myl.cs.51248)
  %cnt.226.at = getelementptr inbounds i8, ptr %cnt.226.record, i64 48
  %cnt.226 = load i64, ptr %cnt.226.at, align 8
  %cnt.227 = add i64 %cnt.226, 1
  store i64 %cnt.227, ptr %cnt.226.at, align 8
  call void @myl_core_free(ptr %v75)
  call preserve_mostcc void @myl_core_err_trace_append_preserve_most(ptr @myl.site.2876) #1
  %lt.228 = load i64, ptr %fp.190, align 8, !tbaa !7
  %lt.229 = trunc i64 %lt.228 to i8
  %v70 = insertvalue { i8, [0 x i64] } poison, i8 %lt.229, 0
  %fp.230 = getelementptr inbounds i8, ptr %fp.190, i64 8
  %cw.231 = load i64, ptr %v61, align 8, !tbaa !7
  %ct.232 = trunc i64 %cw.231 to i8
  %cc.233 = icmp eq i8 %ct.232, 0
  br i1 %cc.233, label %rc.then.234, label %b13.235
rc.then.234:
  %lt.237 = load i64, ptr %fp.190, align 8, !tbaa !7
  %lt.238 = trunc i64 %lt.237 to i8
  %lu.239 = insertvalue { i8, [1 x i64] } poison, i8 %lt.238, 0
  %fp.240 = getelementptr inbounds i8, ptr %fp.190, i64 8
  %lw.241 = load i64, ptr %fp.240, align 8, !tbaa !7
  %cm.236 = insertvalue { i8, [1 x i64] } %lu.239, i64 %lw.241, 1, 0
  %ct.242 = extractvalue { i8, [1 x i64] } %cm.236, 0
  %cc.243 = icmp eq i8 %ct.242, 0
  br i1 %cc.243, label %rc.then.244, label %rc.then.245
rc.then.244:
  %pw.248 = extractvalue { i8, [1 x i64] } %cm.236, 1, 0
  store i64 %pw.248, ptr %stack.247, align 8, !tbaa !7
  %lf.249 = load ptr, ptr %stack.247, align 8, !tbaa !7
  %cp.246 = insertvalue { ptr } poison, ptr %lf.249, 0
  %cf.250 = extractvalue { ptr } %cp.246, 0
  %cnt.251.record = call ptr @myl_count_site_local(ptr @myl.cs.51249)
  %cnt.251.at = getelementptr inbounds i8, ptr %cnt.251.record, i64 48
  %cnt.251 = load i64, ptr %cnt.251.at, align 8
  %cnt.252 = add i64 %cnt.251, 1
  store i64 %cnt.252, ptr %cnt.251.at, align 8
  %rc.253 = load atomic i32, ptr %cf.250 unordered, align 8, !tbaa !3, !range !8
  %rp.254 = icmp ult i32 %rc.253, 2147483648
  br i1 %rp.254, label %rc.dec.255, label %rc.slow.256, !prof !23
rc.dec.255:
  %rn.258 = sub nuw i32 %rc.253, 1
  %rz.259 = icmp eq i32 %rn.258, 0
  br i1 %rz.259, label %rc.free.261, label %rc.keep.260
rc.keep.260:
  store i32 %rn.258, ptr %cf.250, align 8, !tbaa !3
  br label %rc.then.257
rc.free.261:
  call void @myl_core_free(ptr %cf.250)
  br label %rc.then.257
rc.slow.256:
  call preserve_mostcc void @myl_core_release_slow(ptr %cf.250)
  br label %rc.then.257
rc.then.257:
  br label %rc.then.245
rc.then.245:
  %cc.262 = icmp eq i8 %ct.242, 1
  br i1 %cc.262, label %rc.then.263, label %rc.then.264
rc.then.263:
  %pw.267 = extractvalue { i8, [1 x i64] } %cm.236, 1, 0
  store i64 %pw.267, ptr %stack.266, align 8, !tbaa !7
  %lf.268 = load ptr, ptr %stack.266, align 8, !tbaa !7
  %cp.265 = insertvalue { ptr } poison, ptr %lf.268, 0
  %cf.269 = extractvalue { ptr } %cp.265, 0
  %cnt.270.record = call ptr @myl_count_site_local(ptr @myl.cs.51250)
  %cnt.270.at = getelementptr inbounds i8, ptr %cnt.270.record, i64 48
  %cnt.270 = load i64, ptr %cnt.270.at, align 8
  %cnt.271 = add i64 %cnt.270, 1
  store i64 %cnt.271, ptr %cnt.270.at, align 8
  %rc.272 = load atomic i32, ptr %cf.269 unordered, align 8, !tbaa !3, !range !8
  %rp.273 = icmp ult i32 %rc.272, 2147483648
  br i1 %rp.273, label %rc.dec.274, label %rc.slow.275, !prof !23
rc.dec.274:
  %rn.277 = sub nuw i32 %rc.272, 1
  %rz.278 = icmp eq i32 %rn.277, 0
  br i1 %rz.278, label %rc.free.280, label %rc.keep.279
rc.keep.279:
  store i32 %rn.277, ptr %cf.269, align 8, !tbaa !3
  br label %rc.then.276
rc.free.280:
  call void @myl_core_free(ptr %cf.269)
  br label %rc.then.276
rc.slow.275:
  call preserve_mostcc void @myl_core_release_slow(ptr %cf.269)
  br label %rc.then.276
rc.then.276:
  br label %rc.then.264
rc.then.264:
  %cc.281 = icmp eq i8 %ct.242, 2
  br i1 %cc.281, label %rc.then.282, label %rc.then.283
rc.then.282:
  %pw.286 = extractvalue { i8, [1 x i64] } %cm.236, 1, 0
  store i64 %pw.286, ptr %stack.285, align 8, !tbaa !7
  %lf.287 = load ptr, ptr %stack.285, align 8, !tbaa !7
  %cp.284 = insertvalue { ptr } poison, ptr %lf.287, 0
  %cf.288 = extractvalue { ptr } %cp.284, 0
  %cnt.289.record = call ptr @myl_count_site_local(ptr @myl.cs.51251)
  %cnt.289.at = getelementptr inbounds i8, ptr %cnt.289.record, i64 48
  %cnt.289 = load i64, ptr %cnt.289.at, align 8
  %cnt.290 = add i64 %cnt.289, 1
  store i64 %cnt.290, ptr %cnt.289.at, align 8
  %rc.291 = load atomic i32, ptr %cf.288 unordered, align 8, !tbaa !3, !range !8
  %rp.292 = icmp ult i32 %rc.291, 2147483648
  br i1 %rp.292, label %rc.dec.293, label %rc.slow.294, !prof !23
rc.dec.293:
  %rn.296 = sub nuw i32 %rc.291, 1
  %rz.297 = icmp eq i32 %rn.296, 0
  br i1 %rz.297, label %rc.free.299, label %rc.keep.298
rc.keep.298:
  store i32 %rn.296, ptr %cf.288, align 8, !tbaa !3
  br label %rc.then.295
rc.free.299:
  call void @myl_core_free(ptr %cf.288)
  br label %rc.then.295
rc.slow.294:
  call preserve_mostcc void @myl_core_release_slow(ptr %cf.288)
  br label %rc.then.295
rc.then.295:
  br label %rc.then.283
rc.then.283:
  %fp.300 = getelementptr inbounds i8, ptr %fp.190, i64 40
  %cm.301 = load ptr, ptr %fp.300, align 8, !tbaa !7
  %cn.302 = icmp ne ptr %cm.301, null
  br i1 %cn.302, label %rc.then.303, label %rc.then.304
rc.then.303:
  %cnt.305.record = call ptr @myl_count_site_local(ptr @myl.cs.51252)
  %cnt.305.at = getelementptr inbounds i8, ptr %cnt.305.record, i64 48
  %cnt.305 = load i64, ptr %cnt.305.at, align 8
  %cnt.306 = add i64 %cnt.305, 1
  store i64 %cnt.306, ptr %cnt.305.at, align 8
  %rc.307 = load atomic i32, ptr %cm.301 unordered, align 8, !tbaa !3, !range !8
  %rp.308 = icmp ult i32 %rc.307, 2147483648
  br i1 %rp.308, label %rc.dec.309, label %rc.slow.310, !prof !23
rc.dec.309:
  %rn.312 = sub nuw i32 %rc.307, 1
  %rz.313 = icmp eq i32 %rn.312, 0
  br i1 %rz.313, label %rc.free.315, label %rc.keep.314
rc.keep.314:
  store i32 %rn.312, ptr %cm.301, align 8, !tbaa !3
  br label %rc.then.311
rc.free.315:
  call void @myl_core_free(ptr %cm.301)
  br label %rc.then.311
rc.slow.310:
  call preserve_mostcc void @myl_core_release_slow(ptr %cm.301)
  br label %rc.then.311
rc.then.311:
  br label %rc.then.304
rc.then.304:
  br label %b13.235
b13.235:
  store i64 1, ptr %ret, align 8, !tbaa !7
  %st.316 = extractvalue { i8, [0 x i64] } %v70, 0
  %st.317 = zext i8 %st.316 to i64
  store i64 %st.317, ptr %payload, align 8, !tbaa !7
  %fp.318 = getelementptr inbounds i8, ptr %payload, i64 8
  %fp.319 = getelementptr inbounds i8, ptr %ret, i64 112
  %sf.320 = extractvalue { { i64, i64, i64 }, ptr } %v64, 0
  %sf.321 = extractvalue { i64, i64, i64 } %sf.320, 0
  store i64 %sf.321, ptr %fp.319, align 8, !tbaa !7
  %sf.322 = extractvalue { i64, i64, i64 } %sf.320, 1
  %fp.323 = getelementptr inbounds i8, ptr %fp.319, i64 8
  store i64 %sf.322, ptr %fp.323, align 8, !tbaa !7
  %sf.324 = extractvalue { i64, i64, i64 } %sf.320, 2
  %fp.325 = getelementptr inbounds i8, ptr %fp.319, i64 16
  store i64 %sf.324, ptr %fp.325, align 8, !tbaa !7
  %sf.326 = extractvalue { { i64, i64, i64 }, ptr } %v64, 1
  %fp.327 = getelementptr inbounds i8, ptr %fp.319, i64 24
  store ptr %sf.326, ptr %fp.327, align 8, !tbaa !7
  store ptr %myl.cnt.saved, ptr @myl_count_current, align 8
  ret void
b14:
  %v74 = getelementptr inbounds i8, ptr %fp.190, i64 0
  %lt.329 = load i64, ptr %fp.190, align 8, !tbaa !7
  %lt.330 = trunc i64 %lt.329 to i8
  %lu.331 = insertvalue { i8, [1 x i64] } poison, i8 %lt.330, 0
  %fp.332 = getelementptr inbounds i8, ptr %fp.190, i64 8
  %lw.333 = load i64, ptr %fp.332, align 8, !tbaa !7
  %cm.328 = insertvalue { i8, [1 x i64] } %lu.331, i64 %lw.333, 1, 0
  %ct.334 = extractvalue { i8, [1 x i64] } %cm.328, 0
  %cc.335 = icmp eq i8 %ct.334, 0
  br i1 %cc.335, label %rc.then.336, label %b14.337
rc.then.336:
  %pw.340 = extractvalue { i8, [1 x i64] } %cm.328, 1, 0
  store i64 %pw.340, ptr %stack.339, align 8, !tbaa !7
  %lf.341 = load ptr, ptr %stack.339, align 8, !tbaa !7
  %cp.338 = insertvalue { ptr } poison, ptr %lf.341, 0
  %cf.342 = extractvalue { ptr } %cp.338, 0
  %cnt.343 = getelementptr inbounds i8, ptr %cf.342, i64 8
  %cnt.344 = load i64, ptr %cnt.343, align 8
  %cnt.345 = mul i64 %cnt.344, 48
  %cnt.346.record = call ptr @myl_count_site_local(ptr @myl.cs.51253)
  %cnt.346.at = getelementptr inbounds i8, ptr %cnt.346.record, i64 48
  %cnt.346 = load i64, ptr %cnt.346.at, align 8
  %cnt.347 = add i64 %cnt.346, 1
  store i64 %cnt.347, ptr %cnt.346.at, align 8
  %cnt.348.record = call ptr @myl_count_site_local(ptr @myl.cs.51253)
  %cnt.348.at = getelementptr inbounds i8, ptr %cnt.348.record, i64 56
  %cnt.348 = load i64, ptr %cnt.348.at, align 8
  %cnt.349 = add i64 %cnt.348, %cnt.345
  store i64 %cnt.349, ptr %cnt.348.at, align 8
  %rc.350 = load atomic i32, ptr %cf.342 unordered, align 8, !tbaa !3, !range !8
  %rp.351 = icmp ult i32 %rc.350, 2147483646
  br i1 %rp.351, label %rc.inc.352, label %rc.slow.353, !prof !23
rc.inc.352:
  %rn.355 = add nuw i32 %rc.350, 1
  store i32 %rn.355, ptr %cf.342, align 8, !tbaa !3
  br label %rc.then.354
rc.slow.353:
  call preserve_mostcc void @myl_core_retain_slow(ptr %cf.342)
  br label %rc.then.354
rc.then.354:
  br label %b14.337
b14.337:
  %cc.356 = icmp eq i8 %ct.334, 1
  br i1 %cc.356, label %rc.then.357, label %b14.358
rc.then.357:
  %pw.361 = extractvalue { i8, [1 x i64] } %cm.328, 1, 0
  store i64 %pw.361, ptr %stack.360, align 8, !tbaa !7
  %lf.362 = load ptr, ptr %stack.360, align 8, !tbaa !7
  %cp.359 = insertvalue { ptr } poison, ptr %lf.362, 0
  %cf.363 = extractvalue { ptr } %cp.359, 0
  %cnt.364 = getelementptr inbounds i8, ptr %cf.363, i64 8
  %cnt.365 = load i64, ptr %cnt.364, align 8
  %cnt.366 = mul i64 %cnt.365, 1
  %cnt.367.record = call ptr @myl_count_site_local(ptr @myl.cs.51254)
  %cnt.367.at = getelementptr inbounds i8, ptr %cnt.367.record, i64 48
  %cnt.367 = load i64, ptr %cnt.367.at, align 8
  %cnt.368 = add i64 %cnt.367, 1
  store i64 %cnt.368, ptr %cnt.367.at, align 8
  %cnt.369.record = call ptr @myl_count_site_local(ptr @myl.cs.51254)
  %cnt.369.at = getelementptr inbounds i8, ptr %cnt.369.record, i64 56
  %cnt.369 = load i64, ptr %cnt.369.at, align 8
  %cnt.370 = add i64 %cnt.369, %cnt.366
  store i64 %cnt.370, ptr %cnt.369.at, align 8
  %rc.371 = load atomic i32, ptr %cf.363 unordered, align 8, !tbaa !3, !range !8
  %rp.372 = icmp ult i32 %rc.371, 2147483646
  br i1 %rp.372, label %rc.inc.373, label %rc.slow.374, !prof !23
rc.inc.373:
  %rn.376 = add nuw i32 %rc.371, 1
  store i32 %rn.376, ptr %cf.363, align 8, !tbaa !3
  br label %rc.then.375
rc.slow.374:
  call preserve_mostcc void @myl_core_retain_slow(ptr %cf.363)
  br label %rc.then.375
rc.then.375:
  br label %b14.358
b14.358:
  %cc.377 = icmp eq i8 %ct.334, 2
  br i1 %cc.377, label %rc.then.378, label %b14.379
rc.then.378:
  %pw.382 = extractvalue { i8, [1 x i64] } %cm.328, 1, 0
  store i64 %pw.382, ptr %stack.381, align 8, !tbaa !7
  %lf.383 = load ptr, ptr %stack.381, align 8, !tbaa !7
  %cp.380 = insertvalue { ptr } poison, ptr %lf.383, 0
  %cf.384 = extractvalue { ptr } %cp.380, 0
  %cnt.385 = getelementptr inbounds i8, ptr %cf.384, i64 8
  %cnt.386 = load i64, ptr %cnt.385, align 8
  %cnt.387 = mul i64 %cnt.386, 1
  %cnt.388.record = call ptr @myl_count_site_local(ptr @myl.cs.51255)
  %cnt.388.at = getelementptr inbounds i8, ptr %cnt.388.record, i64 48
  %cnt.388 = load i64, ptr %cnt.388.at, align 8
  %cnt.389 = add i64 %cnt.388, 1
  store i64 %cnt.389, ptr %cnt.388.at, align 8
  %cnt.390.record = call ptr @myl_count_site_local(ptr @myl.cs.51255)
  %cnt.390.at = getelementptr inbounds i8, ptr %cnt.390.record, i64 56
  %cnt.390 = load i64, ptr %cnt.390.at, align 8
  %cnt.391 = add i64 %cnt.390, %cnt.387
  store i64 %cnt.391, ptr %cnt.390.at, align 8
  %rc.392 = load atomic i32, ptr %cf.384 unordered, align 8, !tbaa !3, !range !8
  %rp.393 = icmp ult i32 %rc.392, 2147483646
  br i1 %rp.393, label %rc.inc.394, label %rc.slow.395, !prof !23
rc.inc.394:
  %rn.397 = add nuw i32 %rc.392, 1
  store i32 %rn.397, ptr %cf.384, align 8, !tbaa !3
  br label %rc.then.396
rc.slow.395:
  call preserve_mostcc void @myl_core_retain_slow(ptr %cf.384)
  br label %rc.then.396
rc.then.396:
  br label %b14.379
b14.379:
  %fp.398 = getelementptr inbounds i8, ptr %fp.190, i64 40
  %cm.399 = load ptr, ptr %fp.398, align 8, !tbaa !7
  %cn.400 = icmp ne ptr %cm.399, null
  br i1 %cn.400, label %rc.then.401, label %b14.402
rc.then.401:
  %cnt.403 = getelementptr inbounds i8, ptr %cm.399, i64 8
  %cnt.404 = load i64, ptr %cnt.403, align 8
  %cnt.405 = mul i64 %cnt.404, 1
  %cnt.406.record = call ptr @myl_count_site_local(ptr @myl.cs.51256)
  %cnt.406.at = getelementptr inbounds i8, ptr %cnt.406.record, i64 48
  %cnt.406 = load i64, ptr %cnt.406.at, align 8
  %cnt.407 = add i64 %cnt.406, 1
  store i64 %cnt.407, ptr %cnt.406.at, align 8
  %cnt.408.record = call ptr @myl_count_site_local(ptr @myl.cs.51256)
  %cnt.408.at = getelementptr inbounds i8, ptr %cnt.408.record, i64 56
  %cnt.408 = load i64, ptr %cnt.408.at, align 8
  %cnt.409 = add i64 %cnt.408, %cnt.405
  store i64 %cnt.409, ptr %cnt.408.at, align 8
  %rc.410 = load atomic i32, ptr %cm.399 unordered, align 8, !tbaa !3, !range !8
  %rp.411 = icmp ult i32 %rc.410, 2147483646
  br i1 %rp.411, label %rc.inc.412, label %rc.slow.413, !prof !23
rc.inc.412:
  %rn.415 = add nuw i32 %rc.410, 1
  store i32 %rn.415, ptr %cm.399, align 8, !tbaa !3
  br label %rc.then.414
rc.slow.413:
  call preserve_mostcc void @myl_core_retain_slow(ptr %cm.399)
  br label %rc.then.414
rc.then.414:
  br label %b14.402
b14.402:
  %cnt.416.record = call ptr @myl_count_site_local(ptr @myl.cs.51257)
  %cnt.416.at = getelementptr inbounds i8, ptr %cnt.416.record, i64 48
  %cnt.416 = load i64, ptr %cnt.416.at, align 8
  %cnt.417 = add i64 %cnt.416, 1
  store i64 %cnt.417, ptr %cnt.416.at, align 8
  %cnt.418.record = call ptr @myl_count_site_local(ptr @myl.cs.51257)
  %cnt.418.at = getelementptr inbounds i8, ptr %cnt.418.record, i64 56
  %cnt.418 = load i64, ptr %cnt.418.at, align 8
  %cnt.419 = add i64 %cnt.418, 48
  store i64 %cnt.419, ptr %cnt.418.at, align 8
  store ptr @myl.cs.51257, ptr @myl_count_push_site, align 8
  %spl.420 = load i64, ptr %state0.len, align 8
  %spc.421 = load i64, ptr %state0.cap, align 8
  %spr.422 = icmp ult i64 %spl.420, %spc.421
  br i1 %spr.422, label %push.fits.423, label %push.grow.424, !prof !10
push.grow.424:
  %sts.427 = load i64, ptr %state0.len, align 8
  %sts.428 = getelementptr inbounds i8, ptr %v75, i64 8
  store i64 %sts.427, ptr %sts.428, align 8, !tbaa !5
  %spg.426 = call ptr @myl_core_list_grow(ptr %v75, i64 48)
  %spc.429 = getelementptr inbounds i8, ptr %spg.426, i64 16
  %spc.430 = load i64, ptr %spc.429, align 8, !tbaa !5
  store i64 %spc.430, ptr %state0.cap, align 8
  br label %b14.425
push.fits.423:
  br label %b14.425
b14.425:
  %v76 = phi ptr [ %v75, %push.fits.423 ], [ %spg.426, %push.grow.424 ]
  store ptr null, ptr @myl_count_push_site, align 8
  %data.431 = getelementptr inbounds i8, ptr %v76, i64 32
  %elt.432 = getelementptr inbounds [48 x i8], ptr %data.431, i64 %spl.420
  %payload.copy.433 = icmp ne ptr %elt.432, %fp.190
  br i1 %payload.copy.433, label %payload.copy.434, label %b14.435
payload.copy.434:
  %cnt.436.record = call ptr @myl_count_site_local(ptr @myl.cs.51258)
  %cnt.436.at = getelementptr inbounds i8, ptr %cnt.436.record, i64 48
  %cnt.436 = load i64, ptr %cnt.436.at, align 8
  %cnt.437 = add i64 %cnt.436, 1
  store i64 %cnt.437, ptr %cnt.436.at, align 8
  %cnt.438.record = call ptr @myl_count_site_local(ptr @myl.cs.51258)
  %cnt.438.at = getelementptr inbounds i8, ptr %cnt.438.record, i64 56
  %cnt.438 = load i64, ptr %cnt.438.at, align 8
  %cnt.439 = add i64 %cnt.438, 48
  store i64 %cnt.439, ptr %cnt.438.at, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr %elt.432, ptr %v74, i64 48, i1 false)
  br label %b14.435
b14.435:
  %spn.440 = add nuw nsw i64 %spl.420, 1
  store i64 %spn.440, ptr %state0.len, align 8
  %cw.441 = load i64, ptr %v61, align 8, !tbaa !7
  %ct.442 = trunc i64 %cw.441 to i8
  %cc.443 = icmp eq i8 %ct.442, 0
  br i1 %cc.443, label %rc.then.444, label %b14.445
rc.then.444:
  %lt.447 = load i64, ptr %fp.190, align 8, !tbaa !7
  %lt.448 = trunc i64 %lt.447 to i8
  %lu.449 = insertvalue { i8, [1 x i64] } poison, i8 %lt.448, 0
  %fp.450 = getelementptr inbounds i8, ptr %fp.190, i64 8
  %lw.451 = load i64, ptr %fp.450, align 8, !tbaa !7
  %cm.446 = insertvalue { i8, [1 x i64] } %lu.449, i64 %lw.451, 1, 0
  %ct.452 = extractvalue { i8, [1 x i64] } %cm.446, 0
  %cc.453 = icmp eq i8 %ct.452, 0
  br i1 %cc.453, label %rc.then.454, label %rc.then.455
rc.then.454:
  %pw.458 = extractvalue { i8, [1 x i64] } %cm.446, 1, 0
  store i64 %pw.458, ptr %stack.457, align 8, !tbaa !7
  %lf.459 = load ptr, ptr %stack.457, align 8, !tbaa !7
  %cp.456 = insertvalue { ptr } poison, ptr %lf.459, 0
  %cf.460 = extractvalue { ptr } %cp.456, 0
  %cnt.461.record = call ptr @myl_count_site_local(ptr @myl.cs.51259)
  %cnt.461.at = getelementptr inbounds i8, ptr %cnt.461.record, i64 48
  %cnt.461 = load i64, ptr %cnt.461.at, align 8
  %cnt.462 = add i64 %cnt.461, 1
  store i64 %cnt.462, ptr %cnt.461.at, align 8
  %rc.463 = load atomic i32, ptr %cf.460 unordered, align 8, !tbaa !3, !range !8
  %rp.464 = icmp ult i32 %rc.463, 2147483648
  br i1 %rp.464, label %rc.dec.465, label %rc.slow.466, !prof !23
rc.dec.465:
  %rn.468 = sub nuw i32 %rc.463, 1
  %rz.469 = icmp eq i32 %rn.468, 0
  br i1 %rz.469, label %rc.free.471, label %rc.keep.470
rc.keep.470:
  store i32 %rn.468, ptr %cf.460, align 8, !tbaa !3
  br label %rc.then.467
rc.free.471:
  call void @myl_core_free(ptr %cf.460)
  br label %rc.then.467
rc.slow.466:
  call preserve_mostcc void @myl_core_release_slow(ptr %cf.460)
  br label %rc.then.467
rc.then.467:
  br label %rc.then.455
rc.then.455:
  %cc.472 = icmp eq i8 %ct.452, 1
  br i1 %cc.472, label %rc.then.473, label %rc.then.474
rc.then.473:
  %pw.477 = extractvalue { i8, [1 x i64] } %cm.446, 1, 0
  store i64 %pw.477, ptr %stack.476, align 8, !tbaa !7
  %lf.478 = load ptr, ptr %stack.476, align 8, !tbaa !7
  %cp.475 = insertvalue { ptr } poison, ptr %lf.478, 0
  %cf.479 = extractvalue { ptr } %cp.475, 0
  %cnt.480.record = call ptr @myl_count_site_local(ptr @myl.cs.51260)
  %cnt.480.at = getelementptr inbounds i8, ptr %cnt.480.record, i64 48
  %cnt.480 = load i64, ptr %cnt.480.at, align 8
  %cnt.481 = add i64 %cnt.480, 1
  store i64 %cnt.481, ptr %cnt.480.at, align 8
  %rc.482 = load atomic i32, ptr %cf.479 unordered, align 8, !tbaa !3, !range !8
  %rp.483 = icmp ult i32 %rc.482, 2147483648
  br i1 %rp.483, label %rc.dec.484, label %rc.slow.485, !prof !23
rc.dec.484:
  %rn.487 = sub nuw i32 %rc.482, 1
  %rz.488 = icmp eq i32 %rn.487, 0
  br i1 %rz.488, label %rc.free.490, label %rc.keep.489
rc.keep.489:
  store i32 %rn.487, ptr %cf.479, align 8, !tbaa !3
  br label %rc.then.486
rc.free.490:
  call void @myl_core_free(ptr %cf.479)
  br label %rc.then.486
rc.slow.485:
  call preserve_mostcc void @myl_core_release_slow(ptr %cf.479)
  br label %rc.then.486
rc.then.486:
  br label %rc.then.474
rc.then.474:
  %cc.491 = icmp eq i8 %ct.452, 2
  br i1 %cc.491, label %rc.then.492, label %rc.then.493
rc.then.492:
  %pw.496 = extractvalue { i8, [1 x i64] } %cm.446, 1, 0
  store i64 %pw.496, ptr %stack.495, align 8, !tbaa !7
  %lf.497 = load ptr, ptr %stack.495, align 8, !tbaa !7
  %cp.494 = insertvalue { ptr } poison, ptr %lf.497, 0
  %cf.498 = extractvalue { ptr } %cp.494, 0
  %cnt.499.record = call ptr @myl_count_site_local(ptr @myl.cs.51261)
  %cnt.499.at = getelementptr inbounds i8, ptr %cnt.499.record, i64 48
  %cnt.499 = load i64, ptr %cnt.499.at, align 8
  %cnt.500 = add i64 %cnt.499, 1
  store i64 %cnt.500, ptr %cnt.499.at, align 8
  %rc.501 = load atomic i32, ptr %cf.498 unordered, align 8, !tbaa !3, !range !8
  %rp.502 = icmp ult i32 %rc.501, 2147483648
  br i1 %rp.502, label %rc.dec.503, label %rc.slow.504, !prof !23
rc.dec.503:
  %rn.506 = sub nuw i32 %rc.501, 1
  %rz.507 = icmp eq i32 %rn.506, 0
  br i1 %rz.507, label %rc.free.509, label %rc.keep.508
rc.keep.508:
  store i32 %rn.506, ptr %cf.498, align 8, !tbaa !3
  br label %rc.then.505
rc.free.509:
  call void @myl_core_free(ptr %cf.498)
  br label %rc.then.505
rc.slow.504:
  call preserve_mostcc void @myl_core_release_slow(ptr %cf.498)
  br label %rc.then.505
rc.then.505:
  br label %rc.then.493
rc.then.493:
  %fp.510 = getelementptr inbounds i8, ptr %fp.190, i64 40
  %cm.511 = load ptr, ptr %fp.510, align 8, !tbaa !7
  %cn.512 = icmp ne ptr %cm.511, null
  br i1 %cn.512, label %rc.then.513, label %rc.then.514
rc.then.513:
  %cnt.515.record = call ptr @myl_count_site_local(ptr @myl.cs.51262)
  %cnt.515.at = getelementptr inbounds i8, ptr %cnt.515.record, i64 48
  %cnt.515 = load i64, ptr %cnt.515.at, align 8
  %cnt.516 = add i64 %cnt.515, 1
  store i64 %cnt.516, ptr %cnt.515.at, align 8
  %rc.517 = load atomic i32, ptr %cm.511 unordered, align 8, !tbaa !3, !range !8
  %rp.518 = icmp ult i32 %rc.517, 2147483648
  br i1 %rp.518, label %rc.dec.519, label %rc.slow.520, !prof !23
rc.dec.519:
  %rn.522 = sub nuw i32 %rc.517, 1
  %rz.523 = icmp eq i32 %rn.522, 0
  br i1 %rz.523, label %rc.free.525, label %rc.keep.524
rc.keep.524:
  store i32 %rn.522, ptr %cm.511, align 8, !tbaa !3
  br label %rc.then.521
rc.free.525:
  call void @myl_core_free(ptr %cm.511)
  br label %rc.then.521
rc.slow.520:
  call preserve_mostcc void @myl_core_release_slow(ptr %cm.511)
  br label %rc.then.521
rc.then.521:
  br label %rc.then.514
rc.then.514:
  br label %b14.445
b14.445:
  br label %b5
}

define internal fastcc void @"my.sexpr_parser::parse_node"(ptr noalias sret([144 x i8]) align 8 %ret, ptr noalias align 8 %p0, ptr noalias readonly align 8 %p1, i64 %p2, { { i64, i64, i64 }, ptr } %p3, ptr noalias %payload) nounwind uwtable !dbg !1006360 {
entry:
  %slot = alloca i64, align 8
  %stack.1 = alloca [144 x i8], align 8
  %stack.2 = alloca [40 x i8], align 8
  %stack.3 = alloca [40 x i8], align 8
  %stack.4 = alloca [88 x i8], align 8
  %stack.5 = alloca [88 x i8], align 8
  %stack.6 = alloca [88 x i8], align 8
  %stack.7 = alloca [88 x i8], align 8
  %v10 = getelementptr inbounds i8, ptr %stack.1, i64 0
  %v12 = getelementptr inbounds i8, ptr %p0, i64 0
  %v29 = getelementptr inbounds i8, ptr %stack.2, i64 0
  %v59 = getelementptr inbounds i8, ptr %stack.3, i64 0
  %v69 = getelementptr inbounds i8, ptr %stack.4, i64 0
  %v85 = getelementptr inbounds i8, ptr %stack.5, i64 0
  %v101 = getelementptr inbounds i8, ptr %stack.6, i64 0
  %v115 = getelementptr inbounds i8, ptr %stack.7, i64 0
  %myl.cnt.saved = load ptr, ptr @myl_count_current, align 8
  %myl.cnt.active = call ptr @myl_count_function_local(ptr @myl.cf.75)
  store ptr %myl.cnt.active, ptr @myl_count_current, align 8
  %myl.cnt.calls.at = getelementptr inbounds i8, ptr %myl.cnt.active, i64 8
  %myl.cnt.calls = load i64, ptr %myl.cnt.calls.at, align 8
  %myl.cnt.calls.1 = add i64 %myl.cnt.calls, 1
  store i64 %myl.cnt.calls.1, ptr %myl.cnt.calls.at, align 8
  br label %b0
b0:
  %lt.8 = load i64, ptr %p1, align 8, !tbaa !7
  %lt.9 = trunc i64 %lt.8 to i8
  %v4 = insertvalue { i8, [0 x i64] } poison, i8 %lt.9, 0
  %fp.10 = getelementptr inbounds i8, ptr %p1, i64 8
  %t.11 = extractvalue { i8, [0 x i64] } %v4, 0
  %v5 = zext i8 %t.11 to i32
  %v7 = icmp eq i32 %v5, 0
  br i1 %v7, label %b2, label %b3
b2:
  %fp.12 = getelementptr inbounds i8, ptr %p1, i64 16
  %lf.13 = load i64, ptr %fp.12, align 8, !tbaa !7
  %lr.14 = insertvalue { i64, i64, i64 } poison, i64 %lf.13, 0
  %fp.16 = getelementptr inbounds i8, ptr %fp.12, i64 8
  %lf.15 = load i64, ptr %fp.16, align 8, !tbaa !7
  %lr.17 = insertvalue { i64, i64, i64 } %lr.14, i64 %lf.15, 1
  %fp.19 = getelementptr inbounds i8, ptr %fp.12, i64 16
  %lf.18 = load i64, ptr %fp.19, align 8, !tbaa !7
  %v9 = insertvalue { i64, i64, i64 } %lr.17, i64 %lf.18, 2
  %fp.20 = getelementptr inbounds i8, ptr %v10, i64 8
  notail call fastcc void @"my.sexpr_parser::parse_list"(ptr sret([144 x i8]) align 8 %v10, ptr %v12, { i64, i64, i64 } %v9, i64 %p2, { { i64, i64, i64 }, ptr } %p3, ptr %fp.20), !dbg !1006362
  %v11 = getelementptr inbounds i8, ptr %v10, i64 0
  %fp.21 = getelementptr inbounds i8, ptr %v10, i64 112
  %lf.23 = load i64, ptr %fp.21, align 8, !tbaa !7
  %lr.24 = insertvalue { i64, i64, i64 } poison, i64 %lf.23, 0
  %fp.26 = getelementptr inbounds i8, ptr %fp.21, i64 8
  %lf.25 = load i64, ptr %fp.26, align 8, !tbaa !7
  %lr.27 = insertvalue { i64, i64, i64 } %lr.24, i64 %lf.25, 1
  %fp.29 = getelementptr inbounds i8, ptr %fp.21, i64 16
  %lf.28 = load i64, ptr %fp.29, align 8, !tbaa !7
  %lf.22 = insertvalue { i64, i64, i64 } %lr.27, i64 %lf.28, 2
  %lr.30 = insertvalue { { i64, i64, i64 }, ptr } poison, { i64, i64, i64 } %lf.22, 0
  %fp.32 = getelementptr inbounds i8, ptr %fp.21, i64 24
  %lf.31 = load ptr, ptr %fp.32, align 8, !tbaa !7
  %v13 = insertvalue { { i64, i64, i64 }, ptr } %lr.30, ptr %lf.31, 1
  %t.33 = load i64, ptr %v11, align 8, !tbaa !7
  %v14 = trunc i64 %t.33 to i32
  %v16 = icmp eq i32 %v14, 1
  br i1 %v16, label %b4, label %b5
b3:
  %v25 = icmp eq i32 %v5, 1
  br i1 %v25, label %b6, label %b7
b4:
  call preserve_mostcc void @myl_core_err_trace_append_preserve_most(ptr @myl.site.2640) #1
  br label %b5
b5:
  %cnt.34.record = call ptr @myl_count_site_local(ptr @myl.cs.49950)
  %cnt.34.at = getelementptr inbounds i8, ptr %cnt.34.record, i64 48
  %cnt.34 = load i64, ptr %cnt.34.at, align 8
  %cnt.35 = add i64 %cnt.34, 1
  store i64 %cnt.35, ptr %cnt.34.at, align 8
  %cnt.36.record = call ptr @myl_count_site_local(ptr @myl.cs.49950)
  %cnt.36.at = getelementptr inbounds i8, ptr %cnt.36.record, i64 56
  %cnt.36 = load i64, ptr %cnt.36.at, align 8
  %cnt.37 = add i64 %cnt.36, 8
  store i64 %cnt.37, ptr %cnt.36.at, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr %ret, ptr %v11, i64 8, i1 false)
  %fp.38 = getelementptr inbounds i8, ptr %v11, i64 8
  %cnt.39.record = call ptr @myl_count_site_local(ptr @myl.cs.49951)
  %cnt.39.at = getelementptr inbounds i8, ptr %cnt.39.record, i64 48
  %cnt.39 = load i64, ptr %cnt.39.at, align 8
  %cnt.40 = add i64 %cnt.39, 1
  store i64 %cnt.40, ptr %cnt.39.at, align 8
  %cnt.41.record = call ptr @myl_count_site_local(ptr @myl.cs.49951)
  %cnt.41.at = getelementptr inbounds i8, ptr %cnt.41.record, i64 56
  %cnt.41 = load i64, ptr %cnt.41.at, align 8
  %cnt.42 = add i64 %cnt.41, 48
  store i64 %cnt.42, ptr %cnt.41.at, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr %payload, ptr %fp.38, i64 48, i1 false)
  %fp.43 = getelementptr inbounds i8, ptr %ret, i64 112
  %sf.44 = extractvalue { { i64, i64, i64 }, ptr } %v13, 0
  %sf.45 = extractvalue { i64, i64, i64 } %sf.44, 0
  store i64 %sf.45, ptr %fp.43, align 8, !tbaa !7
  %sf.46 = extractvalue { i64, i64, i64 } %sf.44, 1
  %fp.47 = getelementptr inbounds i8, ptr %fp.43, i64 8
  store i64 %sf.46, ptr %fp.47, align 8, !tbaa !7
  %sf.48 = extractvalue { i64, i64, i64 } %sf.44, 2
  %fp.49 = getelementptr inbounds i8, ptr %fp.43, i64 16
  store i64 %sf.48, ptr %fp.49, align 8, !tbaa !7
  %sf.50 = extractvalue { { i64, i64, i64 }, ptr } %v13, 1
  %fp.51 = getelementptr inbounds i8, ptr %fp.43, i64 24
  store ptr %sf.50, ptr %fp.51, align 8, !tbaa !7
  store ptr %myl.cnt.saved, ptr @myl_count_current, align 8
  ret void
b6:
  %fp.52 = getelementptr inbounds i8, ptr %p1, i64 16
  %lf.53 = load i64, ptr %fp.52, align 8, !tbaa !7
  %lr.54 = insertvalue { i64, i64, i64 } poison, i64 %lf.53, 0
  %fp.56 = getelementptr inbounds i8, ptr %fp.52, i64 8
  %lf.55 = load i64, ptr %fp.56, align 8, !tbaa !7
  %lr.57 = insertvalue { i64, i64, i64 } %lr.54, i64 %lf.55, 1
  %fp.59 = getelementptr inbounds i8, ptr %fp.52, i64 16
  %lf.58 = load i64, ptr %fp.59, align 8, !tbaa !7
  %v27 = insertvalue { i64, i64, i64 } %lr.57, i64 %lf.58, 2
  %v28 = insertvalue { i8, [0 x i64] } poison, i8 1, 0
  notail call fastcc void @"my.sexpr_parser::fail"(ptr sret([40 x i8]) align 8 %v29, { { i64, i64, i64 }, ptr } %p3, { i64, i64, i64 } %v27, { i8, [0 x i64] } %v28), !dbg !1006364
  %lt.60 = load i64, ptr %v29, align 8, !tbaa !7
  %lt.61 = trunc i64 %lt.60 to i8
  %v30 = insertvalue { i8, [0 x i64] } poison, i8 %lt.61, 0
  %fp.62 = getelementptr inbounds i8, ptr %v29, i64 8
  %fp.63 = getelementptr inbounds i8, ptr %v29, i64 8
  %lf.65 = load i64, ptr %fp.63, align 8, !tbaa !7
  %lr.66 = insertvalue { i64, i64, i64 } poison, i64 %lf.65, 0
  %fp.68 = getelementptr inbounds i8, ptr %fp.63, i64 8
  %lf.67 = load i64, ptr %fp.68, align 8, !tbaa !7
  %lr.69 = insertvalue { i64, i64, i64 } %lr.66, i64 %lf.67, 1
  %fp.71 = getelementptr inbounds i8, ptr %fp.63, i64 16
  %lf.70 = load i64, ptr %fp.71, align 8, !tbaa !7
  %lf.64 = insertvalue { i64, i64, i64 } %lr.69, i64 %lf.70, 2
  %lr.72 = insertvalue { { i64, i64, i64 }, ptr } poison, { i64, i64, i64 } %lf.64, 0
  %fp.74 = getelementptr inbounds i8, ptr %fp.63, i64 24
  %lf.73 = load ptr, ptr %fp.74, align 8, !tbaa !7
  %v31 = insertvalue { { i64, i64, i64 }, ptr } %lr.72, ptr %lf.73, 1
  call preserve_mostcc void @myl_core_err_trace_origin_preserve_most(ptr @myl.site.2641) #1
  store i64 1, ptr %ret, align 8, !tbaa !7
  %st.75 = extractvalue { i8, [0 x i64] } %v30, 0
  %st.76 = zext i8 %st.75 to i64
  store i64 %st.76, ptr %payload, align 8, !tbaa !7
  %fp.77 = getelementptr inbounds i8, ptr %payload, i64 8
  %fp.78 = getelementptr inbounds i8, ptr %ret, i64 112
  %sf.79 = extractvalue { { i64, i64, i64 }, ptr } %v31, 0
  %sf.80 = extractvalue { i64, i64, i64 } %sf.79, 0
  store i64 %sf.80, ptr %fp.78, align 8, !tbaa !7
  %sf.81 = extractvalue { i64, i64, i64 } %sf.79, 1
  %fp.82 = getelementptr inbounds i8, ptr %fp.78, i64 8
  store i64 %sf.81, ptr %fp.82, align 8, !tbaa !7
  %sf.83 = extractvalue { i64, i64, i64 } %sf.79, 2
  %fp.84 = getelementptr inbounds i8, ptr %fp.78, i64 16
  store i64 %sf.83, ptr %fp.84, align 8, !tbaa !7
  %sf.85 = extractvalue { { i64, i64, i64 }, ptr } %v31, 1
  %fp.86 = getelementptr inbounds i8, ptr %fp.78, i64 24
  store ptr %sf.85, ptr %fp.86, align 8, !tbaa !7
  store ptr %myl.cnt.saved, ptr @myl_count_current, align 8
  ret void
b7:
  %v37 = icmp eq i32 %v5, 2
  br i1 %v37, label %b8, label %b9
b8:
  %fp.87 = getelementptr inbounds i8, ptr %p1, i64 16
  %lf.88 = load i64, ptr %fp.87, align 8, !tbaa !7
  %lr.89 = insertvalue { i64, i64, i64 } poison, i64 %lf.88, 0
  %fp.91 = getelementptr inbounds i8, ptr %fp.87, i64 8
  %lf.90 = load i64, ptr %fp.91, align 8, !tbaa !7
  %lr.92 = insertvalue { i64, i64, i64 } %lr.89, i64 %lf.90, 1
  %fp.94 = getelementptr inbounds i8, ptr %fp.87, i64 16
  %lf.93 = load i64, ptr %fp.94, align 8, !tbaa !7
  %v39 = insertvalue { i64, i64, i64 } %lr.92, i64 %lf.93, 2
  %fp.95 = getelementptr inbounds i8, ptr %p1, i64 8
  %v40 = load ptr, ptr %fp.95, align 8, !tbaa !7
  %cnt.96 = getelementptr inbounds i8, ptr %v40, i64 8
  %cnt.97 = load i64, ptr %cnt.96, align 8
  %cnt.98 = mul i64 %cnt.97, 1
  %cnt.99.record = call ptr @myl_count_site_local(ptr @myl.cs.49952)
  %cnt.99.at = getelementptr inbounds i8, ptr %cnt.99.record, i64 48
  %cnt.99 = load i64, ptr %cnt.99.at, align 8
  %cnt.100 = add i64 %cnt.99, 1
  store i64 %cnt.100, ptr %cnt.99.at, align 8
  %cnt.101.record = call ptr @myl_count_site_local(ptr @myl.cs.49952)
  %cnt.101.at = getelementptr inbounds i8, ptr %cnt.101.record, i64 56
  %cnt.101 = load i64, ptr %cnt.101.at, align 8
  %cnt.102 = add i64 %cnt.101, %cnt.98
  store i64 %cnt.102, ptr %cnt.101.at, align 8
  %rc.103 = load atomic i32, ptr %v40 unordered, align 8, !tbaa !3, !range !8
  %rp.104 = icmp ult i32 %rc.103, 2147483646
  br i1 %rp.104, label %rc.inc.105, label %rc.slow.106, !prof !23
rc.inc.105:
  %rn.108 = add nuw i32 %rc.103, 1
  store i32 %rn.108, ptr %v40, align 8, !tbaa !3
  br label %b8.107
rc.slow.106:
  call preserve_mostcc void @myl_core_retain_slow(ptr %v40)
  br label %b8.107
b8.107:
  %v130 = getelementptr i8, ptr null, i64 0
  store i64 0, ptr %ret, align 8, !tbaa !7
  store i64 1, ptr %payload, align 8, !tbaa !7
  %fp.109 = getelementptr inbounds i8, ptr %payload, i64 8
  store ptr %v40, ptr %fp.109, align 8, !tbaa !7
  %fp.110 = getelementptr inbounds i8, ptr %payload, i64 16
  %sf.111 = extractvalue { i64, i64, i64 } %v39, 0
  store i64 %sf.111, ptr %fp.110, align 8, !tbaa !7
  %sf.112 = extractvalue { i64, i64, i64 } %v39, 1
  %fp.113 = getelementptr inbounds i8, ptr %fp.110, i64 8
  store i64 %sf.112, ptr %fp.113, align 8, !tbaa !7
  %sf.114 = extractvalue { i64, i64, i64 } %v39, 2
  %fp.115 = getelementptr inbounds i8, ptr %fp.110, i64 16
  store i64 %sf.114, ptr %fp.115, align 8, !tbaa !7
  %fp.116 = getelementptr inbounds i8, ptr %payload, i64 40
  store ptr %v130, ptr %fp.116, align 8, !tbaa !7
  %fp.117 = getelementptr inbounds i8, ptr %ret, i64 112
  %sf.118 = extractvalue { { i64, i64, i64 }, ptr } %p3, 0
  %sf.119 = extractvalue { i64, i64, i64 } %sf.118, 0
  store i64 %sf.119, ptr %fp.117, align 8, !tbaa !7
  %sf.120 = extractvalue { i64, i64, i64 } %sf.118, 1
  %fp.121 = getelementptr inbounds i8, ptr %fp.117, i64 8
  store i64 %sf.120, ptr %fp.121, align 8, !tbaa !7
  %sf.122 = extractvalue { i64, i64, i64 } %sf.118, 2
  %fp.123 = getelementptr inbounds i8, ptr %fp.117, i64 16
  store i64 %sf.122, ptr %fp.123, align 8, !tbaa !7
  %sf.124 = extractvalue { { i64, i64, i64 }, ptr } %p3, 1
  %fp.125 = getelementptr inbounds i8, ptr %fp.117, i64 24
  store ptr %sf.124, ptr %fp.125, align 8, !tbaa !7
  store ptr %myl.cnt.saved, ptr @myl_count_current, align 8
  ret void
b9:
  %v46 = icmp eq i32 %v5, 3
  br i1 %v46, label %b10, label %b11
b10:
  %fp.126 = getelementptr inbounds i8, ptr %p1, i64 16
  %lf.127 = load i64, ptr %fp.126, align 8, !tbaa !7
  %lr.128 = insertvalue { i64, i64, i64 } poison, i64 %lf.127, 0
  %fp.130 = getelementptr inbounds i8, ptr %fp.126, i64 8
  %lf.129 = load i64, ptr %fp.130, align 8, !tbaa !7
  %lr.131 = insertvalue { i64, i64, i64 } %lr.128, i64 %lf.129, 1
  %fp.133 = getelementptr inbounds i8, ptr %fp.126, i64 16
  %lf.132 = load i64, ptr %fp.133, align 8, !tbaa !7
  %v48 = insertvalue { i64, i64, i64 } %lr.131, i64 %lf.132, 2
  %fp.134 = getelementptr inbounds i8, ptr %p1, i64 8
  %v49 = load ptr, ptr %fp.134, align 8, !tbaa !7
  %cnt.135 = getelementptr inbounds i8, ptr %v49, i64 8
  %cnt.136 = load i64, ptr %cnt.135, align 8
  %cnt.137 = mul i64 %cnt.136, 1
  %cnt.138.record = call ptr @myl_count_site_local(ptr @myl.cs.49953)
  %cnt.138.at = getelementptr inbounds i8, ptr %cnt.138.record, i64 48
  %cnt.138 = load i64, ptr %cnt.138.at, align 8
  %cnt.139 = add i64 %cnt.138, 1
  store i64 %cnt.139, ptr %cnt.138.at, align 8
  %cnt.140.record = call ptr @myl_count_site_local(ptr @myl.cs.49953)
  %cnt.140.at = getelementptr inbounds i8, ptr %cnt.140.record, i64 56
  %cnt.140 = load i64, ptr %cnt.140.at, align 8
  %cnt.141 = add i64 %cnt.140, %cnt.137
  store i64 %cnt.141, ptr %cnt.140.at, align 8
  %rc.142 = load atomic i32, ptr %v49 unordered, align 8, !tbaa !3, !range !8
  %rp.143 = icmp ult i32 %rc.142, 2147483646
  br i1 %rp.143, label %rc.inc.144, label %rc.slow.145, !prof !23
rc.inc.144:
  %rn.147 = add nuw i32 %rc.142, 1
  store i32 %rn.147, ptr %v49, align 8, !tbaa !3
  br label %b10.146
rc.slow.145:
  call preserve_mostcc void @myl_core_retain_slow(ptr %v49)
  br label %b10.146
b10.146:
  %v134 = getelementptr i8, ptr null, i64 0
  store i64 0, ptr %ret, align 8, !tbaa !7
  store i64 2, ptr %payload, align 8, !tbaa !7
  %fp.148 = getelementptr inbounds i8, ptr %payload, i64 8
  store ptr %v49, ptr %fp.148, align 8, !tbaa !7
  %fp.149 = getelementptr inbounds i8, ptr %payload, i64 16
  %sf.150 = extractvalue { i64, i64, i64 } %v48, 0
  store i64 %sf.150, ptr %fp.149, align 8, !tbaa !7
  %sf.151 = extractvalue { i64, i64, i64 } %v48, 1
  %fp.152 = getelementptr inbounds i8, ptr %fp.149, i64 8
  store i64 %sf.151, ptr %fp.152, align 8, !tbaa !7
  %sf.153 = extractvalue { i64, i64, i64 } %v48, 2
  %fp.154 = getelementptr inbounds i8, ptr %fp.149, i64 16
  store i64 %sf.153, ptr %fp.154, align 8, !tbaa !7
  %fp.155 = getelementptr inbounds i8, ptr %payload, i64 40
  store ptr %v134, ptr %fp.155, align 8, !tbaa !7
  %fp.156 = getelementptr inbounds i8, ptr %ret, i64 112
  %sf.157 = extractvalue { { i64, i64, i64 }, ptr } %p3, 0
  %sf.158 = extractvalue { i64, i64, i64 } %sf.157, 0
  store i64 %sf.158, ptr %fp.156, align 8, !tbaa !7
  %sf.159 = extractvalue { i64, i64, i64 } %sf.157, 1
  %fp.160 = getelementptr inbounds i8, ptr %fp.156, i64 8
  store i64 %sf.159, ptr %fp.160, align 8, !tbaa !7
  %sf.161 = extractvalue { i64, i64, i64 } %sf.157, 2
  %fp.162 = getelementptr inbounds i8, ptr %fp.156, i64 16
  store i64 %sf.161, ptr %fp.162, align 8, !tbaa !7
  %sf.163 = extractvalue { { i64, i64, i64 }, ptr } %p3, 1
  %fp.164 = getelementptr inbounds i8, ptr %fp.156, i64 24
  store ptr %sf.163, ptr %fp.164, align 8, !tbaa !7
  store ptr %myl.cnt.saved, ptr @myl_count_current, align 8
  ret void
b11:
  %v55 = icmp eq i32 %v5, 8
  br i1 %v55, label %b12, label %b13
b12:
  %fp.165 = getelementptr inbounds i8, ptr %p1, i64 16
  %lf.166 = load i64, ptr %fp.165, align 8, !tbaa !7
  %lr.167 = insertvalue { i64, i64, i64 } poison, i64 %lf.166, 0
  %fp.169 = getelementptr inbounds i8, ptr %fp.165, i64 8
  %lf.168 = load i64, ptr %fp.169, align 8, !tbaa !7
  %lr.170 = insertvalue { i64, i64, i64 } %lr.167, i64 %lf.168, 1
  %fp.172 = getelementptr inbounds i8, ptr %fp.165, i64 16
  %lf.171 = load i64, ptr %fp.172, align 8, !tbaa !7
  %v57 = insertvalue { i64, i64, i64 } %lr.170, i64 %lf.171, 2
  %v58 = insertvalue { i8, [0 x i64] } poison, i8 0, 0
  notail call fastcc void @"my.sexpr_parser::fail"(ptr sret([40 x i8]) align 8 %v59, { { i64, i64, i64 }, ptr } %p3, { i64, i64, i64 } %v57, { i8, [0 x i64] } %v58), !dbg !1006366
  %lt.173 = load i64, ptr %v59, align 8, !tbaa !7
  %lt.174 = trunc i64 %lt.173 to i8
  %v60 = insertvalue { i8, [0 x i64] } poison, i8 %lt.174, 0
  %fp.175 = getelementptr inbounds i8, ptr %v59, i64 8
  %fp.176 = getelementptr inbounds i8, ptr %v59, i64 8
  %lf.178 = load i64, ptr %fp.176, align 8, !tbaa !7
  %lr.179 = insertvalue { i64, i64, i64 } poison, i64 %lf.178, 0
  %fp.181 = getelementptr inbounds i8, ptr %fp.176, i64 8
  %lf.180 = load i64, ptr %fp.181, align 8, !tbaa !7
  %lr.182 = insertvalue { i64, i64, i64 } %lr.179, i64 %lf.180, 1
  %fp.184 = getelementptr inbounds i8, ptr %fp.176, i64 16
  %lf.183 = load i64, ptr %fp.184, align 8, !tbaa !7
  %lf.177 = insertvalue { i64, i64, i64 } %lr.182, i64 %lf.183, 2
  %lr.185 = insertvalue { { i64, i64, i64 }, ptr } poison, { i64, i64, i64 } %lf.177, 0
  %fp.187 = getelementptr inbounds i8, ptr %fp.176, i64 24
  %lf.186 = load ptr, ptr %fp.187, align 8, !tbaa !7
  %v61 = insertvalue { { i64, i64, i64 }, ptr } %lr.185, ptr %lf.186, 1
  call preserve_mostcc void @myl_core_err_trace_origin_preserve_most(ptr @myl.site.2642) #1
  store i64 1, ptr %ret, align 8, !tbaa !7
  %st.188 = extractvalue { i8, [0 x i64] } %v60, 0
  %st.189 = zext i8 %st.188 to i64
  store i64 %st.189, ptr %payload, align 8, !tbaa !7
  %fp.190 = getelementptr inbounds i8, ptr %payload, i64 8
  %fp.191 = getelementptr inbounds i8, ptr %ret, i64 112
  %sf.192 = extractvalue { { i64, i64, i64 }, ptr } %v61, 0
  %sf.193 = extractvalue { i64, i64, i64 } %sf.192, 0
  store i64 %sf.193, ptr %fp.191, align 8, !tbaa !7
  %sf.194 = extractvalue { i64, i64, i64 } %sf.192, 1
  %fp.195 = getelementptr inbounds i8, ptr %fp.191, i64 8
  store i64 %sf.194, ptr %fp.195, align 8, !tbaa !7
  %sf.196 = extractvalue { i64, i64, i64 } %sf.192, 2
  %fp.197 = getelementptr inbounds i8, ptr %fp.191, i64 16
  store i64 %sf.196, ptr %fp.197, align 8, !tbaa !7
  %sf.198 = extractvalue { { i64, i64, i64 }, ptr } %v61, 1
  %fp.199 = getelementptr inbounds i8, ptr %fp.191, i64 24
  store ptr %sf.198, ptr %fp.199, align 8, !tbaa !7
  store ptr %myl.cnt.saved, ptr @myl_count_current, align 8
  ret void
b13:
  %v67 = icmp eq i32 %v5, 4
  br i1 %v67, label %b14, label %b15
b14:
  %fp.200 = getelementptr inbounds i8, ptr %v69, i64 8
  notail call fastcc void @"my.sexpr_parser::parse_number_node"(ptr sret([88 x i8]) align 8 %v69, ptr %p0, ptr %p1, { { i64, i64, i64 }, ptr } %p3, ptr %fp.200), !dbg !1006368
  %v70 = getelementptr inbounds i8, ptr %v69, i64 0
  %fp.201 = getelementptr inbounds i8, ptr %v69, i64 56
  %lf.203 = load i64, ptr %fp.201, align 8, !tbaa !7
  %lr.204 = insertvalue { i64, i64, i64 } poison, i64 %lf.203, 0
  %fp.206 = getelementptr inbounds i8, ptr %fp.201, i64 8
  %lf.205 = load i64, ptr %fp.206, align 8, !tbaa !7
  %lr.207 = insertvalue { i64, i64, i64 } %lr.204, i64 %lf.205, 1
  %fp.209 = getelementptr inbounds i8, ptr %fp.201, i64 16
  %lf.208 = load i64, ptr %fp.209, align 8, !tbaa !7
  %lf.202 = insertvalue { i64, i64, i64 } %lr.207, i64 %lf.208, 2
  %lr.210 = insertvalue { { i64, i64, i64 }, ptr } poison, { i64, i64, i64 } %lf.202, 0
  %fp.212 = getelementptr inbounds i8, ptr %fp.201, i64 24
  %lf.211 = load ptr, ptr %fp.212, align 8, !tbaa !7
  %v71 = insertvalue { { i64, i64, i64 }, ptr } %lr.210, ptr %lf.211, 1
  %t.213 = load i64, ptr %v70, align 8, !tbaa !7
  %v72 = trunc i64 %t.213 to i32
  %v74 = icmp eq i32 %v72, 1
  br i1 %v74, label %b16, label %b17
b15:
  %v83 = icmp eq i32 %v5, 5
  br i1 %v83, label %b18, label %b19
b16:
  call preserve_mostcc void @myl_core_err_trace_append_preserve_most(ptr @myl.site.2643) #1
  br label %b17
b17:
  %cnt.214.record = call ptr @myl_count_site_local(ptr @myl.cs.49954)
  %cnt.214.at = getelementptr inbounds i8, ptr %cnt.214.record, i64 48
  %cnt.214 = load i64, ptr %cnt.214.at, align 8
  %cnt.215 = add i64 %cnt.214, 1
  store i64 %cnt.215, ptr %cnt.214.at, align 8
  %cnt.216.record = call ptr @myl_count_site_local(ptr @myl.cs.49954)
  %cnt.216.at = getelementptr inbounds i8, ptr %cnt.216.record, i64 56
  %cnt.216 = load i64, ptr %cnt.216.at, align 8
  %cnt.217 = add i64 %cnt.216, 8
  store i64 %cnt.217, ptr %cnt.216.at, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr %ret, ptr %v70, i64 8, i1 false)
  %fp.218 = getelementptr inbounds i8, ptr %v70, i64 8
  %cnt.219.record = call ptr @myl_count_site_local(ptr @myl.cs.49955)
  %cnt.219.at = getelementptr inbounds i8, ptr %cnt.219.record, i64 48
  %cnt.219 = load i64, ptr %cnt.219.at, align 8
  %cnt.220 = add i64 %cnt.219, 1
  store i64 %cnt.220, ptr %cnt.219.at, align 8
  %cnt.221.record = call ptr @myl_count_site_local(ptr @myl.cs.49955)
  %cnt.221.at = getelementptr inbounds i8, ptr %cnt.221.record, i64 56
  %cnt.221 = load i64, ptr %cnt.221.at, align 8
  %cnt.222 = add i64 %cnt.221, 48
  store i64 %cnt.222, ptr %cnt.221.at, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr %payload, ptr %fp.218, i64 48, i1 false)
  %fp.223 = getelementptr inbounds i8, ptr %ret, i64 112
  %sf.224 = extractvalue { { i64, i64, i64 }, ptr } %v71, 0
  %sf.225 = extractvalue { i64, i64, i64 } %sf.224, 0
  store i64 %sf.225, ptr %fp.223, align 8, !tbaa !7
  %sf.226 = extractvalue { i64, i64, i64 } %sf.224, 1
  %fp.227 = getelementptr inbounds i8, ptr %fp.223, i64 8
  store i64 %sf.226, ptr %fp.227, align 8, !tbaa !7
  %sf.228 = extractvalue { i64, i64, i64 } %sf.224, 2
  %fp.229 = getelementptr inbounds i8, ptr %fp.223, i64 16
  store i64 %sf.228, ptr %fp.229, align 8, !tbaa !7
  %sf.230 = extractvalue { { i64, i64, i64 }, ptr } %v71, 1
  %fp.231 = getelementptr inbounds i8, ptr %fp.223, i64 24
  store ptr %sf.230, ptr %fp.231, align 8, !tbaa !7
  store ptr %myl.cnt.saved, ptr @myl_count_current, align 8
  ret void
b18:
  %fp.232 = getelementptr inbounds i8, ptr %v85, i64 8
  notail call fastcc void @"my.sexpr_parser::parse_number_node"(ptr sret([88 x i8]) align 8 %v85, ptr %p0, ptr %p1, { { i64, i64, i64 }, ptr } %p3, ptr %fp.232), !dbg !1006370
  %v86 = getelementptr inbounds i8, ptr %v85, i64 0
  %fp.233 = getelementptr inbounds i8, ptr %v85, i64 56
  %lf.235 = load i64, ptr %fp.233, align 8, !tbaa !7
  %lr.236 = insertvalue { i64, i64, i64 } poison, i64 %lf.235, 0
  %fp.238 = getelementptr inbounds i8, ptr %fp.233, i64 8
  %lf.237 = load i64, ptr %fp.238, align 8, !tbaa !7
  %lr.239 = insertvalue { i64, i64, i64 } %lr.236, i64 %lf.237, 1
  %fp.241 = getelementptr inbounds i8, ptr %fp.233, i64 16
  %lf.240 = load i64, ptr %fp.241, align 8, !tbaa !7
  %lf.234 = insertvalue { i64, i64, i64 } %lr.239, i64 %lf.240, 2
  %lr.242 = insertvalue { { i64, i64, i64 }, ptr } poison, { i64, i64, i64 } %lf.234, 0
  %fp.244 = getelementptr inbounds i8, ptr %fp.233, i64 24
  %lf.243 = load ptr, ptr %fp.244, align 8, !tbaa !7
  %v87 = insertvalue { { i64, i64, i64 }, ptr } %lr.242, ptr %lf.243, 1
  %t.245 = load i64, ptr %v86, align 8, !tbaa !7
  %v88 = trunc i64 %t.245 to i32
  %v90 = icmp eq i32 %v88, 1
  br i1 %v90, label %b20, label %b21
b19:
  %v99 = icmp eq i32 %v5, 6
  br i1 %v99, label %b22, label %b23
b20:
  call preserve_mostcc void @myl_core_err_trace_append_preserve_most(ptr @myl.site.2644) #1
  br label %b21
b21:
  %cnt.246.record = call ptr @myl_count_site_local(ptr @myl.cs.49956)
  %cnt.246.at = getelementptr inbounds i8, ptr %cnt.246.record, i64 48
  %cnt.246 = load i64, ptr %cnt.246.at, align 8
  %cnt.247 = add i64 %cnt.246, 1
  store i64 %cnt.247, ptr %cnt.246.at, align 8
  %cnt.248.record = call ptr @myl_count_site_local(ptr @myl.cs.49956)
  %cnt.248.at = getelementptr inbounds i8, ptr %cnt.248.record, i64 56
  %cnt.248 = load i64, ptr %cnt.248.at, align 8
  %cnt.249 = add i64 %cnt.248, 8
  store i64 %cnt.249, ptr %cnt.248.at, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr %ret, ptr %v86, i64 8, i1 false)
  %fp.250 = getelementptr inbounds i8, ptr %v86, i64 8
  %cnt.251.record = call ptr @myl_count_site_local(ptr @myl.cs.49957)
  %cnt.251.at = getelementptr inbounds i8, ptr %cnt.251.record, i64 48
  %cnt.251 = load i64, ptr %cnt.251.at, align 8
  %cnt.252 = add i64 %cnt.251, 1
  store i64 %cnt.252, ptr %cnt.251.at, align 8
  %cnt.253.record = call ptr @myl_count_site_local(ptr @myl.cs.49957)
  %cnt.253.at = getelementptr inbounds i8, ptr %cnt.253.record, i64 56
  %cnt.253 = load i64, ptr %cnt.253.at, align 8
  %cnt.254 = add i64 %cnt.253, 48
  store i64 %cnt.254, ptr %cnt.253.at, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr %payload, ptr %fp.250, i64 48, i1 false)
  %fp.255 = getelementptr inbounds i8, ptr %ret, i64 112
  %sf.256 = extractvalue { { i64, i64, i64 }, ptr } %v87, 0
  %sf.257 = extractvalue { i64, i64, i64 } %sf.256, 0
  store i64 %sf.257, ptr %fp.255, align 8, !tbaa !7
  %sf.258 = extractvalue { i64, i64, i64 } %sf.256, 1
  %fp.259 = getelementptr inbounds i8, ptr %fp.255, i64 8
  store i64 %sf.258, ptr %fp.259, align 8, !tbaa !7
  %sf.260 = extractvalue { i64, i64, i64 } %sf.256, 2
  %fp.261 = getelementptr inbounds i8, ptr %fp.255, i64 16
  store i64 %sf.260, ptr %fp.261, align 8, !tbaa !7
  %sf.262 = extractvalue { { i64, i64, i64 }, ptr } %v87, 1
  %fp.263 = getelementptr inbounds i8, ptr %fp.255, i64 24
  store ptr %sf.262, ptr %fp.263, align 8, !tbaa !7
  store ptr %myl.cnt.saved, ptr @myl_count_current, align 8
  ret void
b22:
  %fp.264 = getelementptr inbounds i8, ptr %v101, i64 8
  notail call fastcc void @"my.sexpr_parser::parse_number_node"(ptr sret([88 x i8]) align 8 %v101, ptr %p0, ptr %p1, { { i64, i64, i64 }, ptr } %p3, ptr %fp.264), !dbg !1006372
  %v102 = getelementptr inbounds i8, ptr %v101, i64 0
  %fp.265 = getelementptr inbounds i8, ptr %v101, i64 56
  %lf.267 = load i64, ptr %fp.265, align 8, !tbaa !7
  %lr.268 = insertvalue { i64, i64, i64 } poison, i64 %lf.267, 0
  %fp.270 = getelementptr inbounds i8, ptr %fp.265, i64 8
  %lf.269 = load i64, ptr %fp.270, align 8, !tbaa !7
  %lr.271 = insertvalue { i64, i64, i64 } %lr.268, i64 %lf.269, 1
  %fp.273 = getelementptr inbounds i8, ptr %fp.265, i64 16
  %lf.272 = load i64, ptr %fp.273, align 8, !tbaa !7
  %lf.266 = insertvalue { i64, i64, i64 } %lr.271, i64 %lf.272, 2
  %lr.274 = insertvalue { { i64, i64, i64 }, ptr } poison, { i64, i64, i64 } %lf.266, 0
  %fp.276 = getelementptr inbounds i8, ptr %fp.265, i64 24
  %lf.275 = load ptr, ptr %fp.276, align 8, !tbaa !7
  %v103 = insertvalue { { i64, i64, i64 }, ptr } %lr.274, ptr %lf.275, 1
  %t.277 = load i64, ptr %v102, align 8, !tbaa !7
  %v104 = trunc i64 %t.277 to i32
  %v106 = icmp eq i32 %v104, 1
  br i1 %v106, label %b24, label %b25
b23:
  br label %b26
b24:
  call preserve_mostcc void @myl_core_err_trace_append_preserve_most(ptr @myl.site.2645) #1
  br label %b25
b25:
  %cnt.278.record = call ptr @myl_count_site_local(ptr @myl.cs.49958)
  %cnt.278.at = getelementptr inbounds i8, ptr %cnt.278.record, i64 48
  %cnt.278 = load i64, ptr %cnt.278.at, align 8
  %cnt.279 = add i64 %cnt.278, 1
  store i64 %cnt.279, ptr %cnt.278.at, align 8
  %cnt.280.record = call ptr @myl_count_site_local(ptr @myl.cs.49958)
  %cnt.280.at = getelementptr inbounds i8, ptr %cnt.280.record, i64 56
  %cnt.280 = load i64, ptr %cnt.280.at, align 8
  %cnt.281 = add i64 %cnt.280, 8
  store i64 %cnt.281, ptr %cnt.280.at, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr %ret, ptr %v102, i64 8, i1 false)
  %fp.282 = getelementptr inbounds i8, ptr %v102, i64 8
  %cnt.283.record = call ptr @myl_count_site_local(ptr @myl.cs.49959)
  %cnt.283.at = getelementptr inbounds i8, ptr %cnt.283.record, i64 48
  %cnt.283 = load i64, ptr %cnt.283.at, align 8
  %cnt.284 = add i64 %cnt.283, 1
  store i64 %cnt.284, ptr %cnt.283.at, align 8
  %cnt.285.record = call ptr @myl_count_site_local(ptr @myl.cs.49959)
  %cnt.285.at = getelementptr inbounds i8, ptr %cnt.285.record, i64 56
  %cnt.285 = load i64, ptr %cnt.285.at, align 8
  %cnt.286 = add i64 %cnt.285, 48
  store i64 %cnt.286, ptr %cnt.285.at, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr %payload, ptr %fp.282, i64 48, i1 false)
  %fp.287 = getelementptr inbounds i8, ptr %ret, i64 112
  %sf.288 = extractvalue { { i64, i64, i64 }, ptr } %v103, 0
  %sf.289 = extractvalue { i64, i64, i64 } %sf.288, 0
  store i64 %sf.289, ptr %fp.287, align 8, !tbaa !7
  %sf.290 = extractvalue { i64, i64, i64 } %sf.288, 1
  %fp.291 = getelementptr inbounds i8, ptr %fp.287, i64 8
  store i64 %sf.290, ptr %fp.291, align 8, !tbaa !7
  %sf.292 = extractvalue { i64, i64, i64 } %sf.288, 2
  %fp.293 = getelementptr inbounds i8, ptr %fp.287, i64 16
  store i64 %sf.292, ptr %fp.293, align 8, !tbaa !7
  %sf.294 = extractvalue { { i64, i64, i64 }, ptr } %v103, 1
  %fp.295 = getelementptr inbounds i8, ptr %fp.287, i64 24
  store ptr %sf.294, ptr %fp.295, align 8, !tbaa !7
  store ptr %myl.cnt.saved, ptr @myl_count_current, align 8
  ret void
b26:
  %fp.296 = getelementptr inbounds i8, ptr %v115, i64 8
  notail call fastcc void @"my.sexpr_parser::parse_number_node"(ptr sret([88 x i8]) align 8 %v115, ptr %p0, ptr %p1, { { i64, i64, i64 }, ptr } %p3, ptr %fp.296), !dbg !1006374
  %v116 = getelementptr inbounds i8, ptr %v115, i64 0
  %fp.297 = getelementptr inbounds i8, ptr %v115, i64 56
  %lf.299 = load i64, ptr %fp.297, align 8, !tbaa !7
  %lr.300 = insertvalue { i64, i64, i64 } poison, i64 %lf.299, 0
  %fp.302 = getelementptr inbounds i8, ptr %fp.297, i64 8
  %lf.301 = load i64, ptr %fp.302, align 8, !tbaa !7
  %lr.303 = insertvalue { i64, i64, i64 } %lr.300, i64 %lf.301, 1
  %fp.305 = getelementptr inbounds i8, ptr %fp.297, i64 16
  %lf.304 = load i64, ptr %fp.305, align 8, !tbaa !7
  %lf.298 = insertvalue { i64, i64, i64 } %lr.303, i64 %lf.304, 2
  %lr.306 = insertvalue { { i64, i64, i64 }, ptr } poison, { i64, i64, i64 } %lf.298, 0
  %fp.308 = getelementptr inbounds i8, ptr %fp.297, i64 24
  %lf.307 = load ptr, ptr %fp.308, align 8, !tbaa !7
  %v117 = insertvalue { { i64, i64, i64 }, ptr } %lr.306, ptr %lf.307, 1
  %t.309 = load i64, ptr %v116, align 8, !tbaa !7
  %v118 = trunc i64 %t.309 to i32
  %v120 = icmp eq i32 %v118, 1
  br i1 %v120, label %b27, label %b28
b27:
  call preserve_mostcc void @myl_core_err_trace_append_preserve_most(ptr @myl.site.2646) #1
  br label %b28
b28:
  %cnt.310.record = call ptr @myl_count_site_local(ptr @myl.cs.49960)
  %cnt.310.at = getelementptr inbounds i8, ptr %cnt.310.record, i64 48
  %cnt.310 = load i64, ptr %cnt.310.at, align 8
  %cnt.311 = add i64 %cnt.310, 1
  store i64 %cnt.311, ptr %cnt.310.at, align 8
  %cnt.312.record = call ptr @myl_count_site_local(ptr @myl.cs.49960)
  %cnt.312.at = getelementptr inbounds i8, ptr %cnt.312.record, i64 56
  %cnt.312 = load i64, ptr %cnt.312.at, align 8
  %cnt.313 = add i64 %cnt.312, 8
  store i64 %cnt.313, ptr %cnt.312.at, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr %ret, ptr %v116, i64 8, i1 false)
  %fp.314 = getelementptr inbounds i8, ptr %v116, i64 8
  %cnt.315.record = call ptr @myl_count_site_local(ptr @myl.cs.49961)
  %cnt.315.at = getelementptr inbounds i8, ptr %cnt.315.record, i64 48
  %cnt.315 = load i64, ptr %cnt.315.at, align 8
  %cnt.316 = add i64 %cnt.315, 1
  store i64 %cnt.316, ptr %cnt.315.at, align 8
  %cnt.317.record = call ptr @myl_count_site_local(ptr @myl.cs.49961)
  %cnt.317.at = getelementptr inbounds i8, ptr %cnt.317.record, i64 56
  %cnt.317 = load i64, ptr %cnt.317.at, align 8
  %cnt.318 = add i64 %cnt.317, 48
  store i64 %cnt.318, ptr %cnt.317.at, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr %payload, ptr %fp.314, i64 48, i1 false)
  %fp.319 = getelementptr inbounds i8, ptr %ret, i64 112
  %sf.320 = extractvalue { { i64, i64, i64 }, ptr } %v117, 0
  %sf.321 = extractvalue { i64, i64, i64 } %sf.320, 0
  store i64 %sf.321, ptr %fp.319, align 8, !tbaa !7
  %sf.322 = extractvalue { i64, i64, i64 } %sf.320, 1
  %fp.323 = getelementptr inbounds i8, ptr %fp.319, i64 8
  store i64 %sf.322, ptr %fp.323, align 8, !tbaa !7
  %sf.324 = extractvalue { i64, i64, i64 } %sf.320, 2
  %fp.325 = getelementptr inbounds i8, ptr %fp.319, i64 16
  store i64 %sf.324, ptr %fp.325, align 8, !tbaa !7
  %sf.326 = extractvalue { { i64, i64, i64 }, ptr } %v117, 1
  %fp.327 = getelementptr inbounds i8, ptr %fp.319, i64 24
  store ptr %sf.326, ptr %fp.327, align 8, !tbaa !7
  store ptr %myl.cnt.saved, ptr @myl_count_current, align 8
  ret void
}