define internal fastcc void @"my.sexpr_parser::parse_list"(ptr noalias sret([144 x i8]) align 8 %ret, ptr noalias align 8 %p0, { i64, i64, i64 } %p1, i64 %p2, { { i64, i64, i64 }, ptr } %p3, ptr noalias %payload) nounwind uwtable !dbg !1007249 {
entry:
  %slot = alloca i64, align 8
  %stack.1 = alloca [40 x i8], align 8
  %stack.2 = alloca [136 x i8], align 8
  %stack.3 = alloca [40 x i8], align 8
  %stack.4 = alloca [144 x i8], align 8
  %v8 = getelementptr inbounds i8, ptr %stack.1, i64 0
  %v20 = getelementptr inbounds i8, ptr %p0, i64 0
  %v22 = getelementptr inbounds i8, ptr %stack.2, i64 0
  %v24 = getelementptr inbounds i8, ptr %p0, i64 0
  %v44 = getelementptr inbounds i8, ptr %stack.3, i64 0
  %v61 = getelementptr inbounds i8, ptr %stack.4, i64 0
  %v63 = getelementptr inbounds i8, ptr %p0, i64 0
  %state0.len = alloca i64, align 8
  %state0.cap = alloca i64, align 8
  %stack.233 = alloca [8 x i8], align 8
  %stack.250 = alloca [8 x i8], align 8
  %stack.267 = alloca [8 x i8], align 8
  %stack.317 = alloca [8 x i8], align 8
  %stack.331 = alloca [8 x i8], align 8
  %stack.345 = alloca [8 x i8], align 8
  %stack.399 = alloca [8 x i8], align 8
  %stack.416 = alloca [8 x i8], align 8
  %stack.433 = alloca [8 x i8], align 8
  br label %b0
b0:
  %v5 = icmp sge i64 %p2, 10000
  br i1 %v5, label %b1, label %b2
b1:
  %v7 = insertvalue { i8, [0 x i64] } poison, i8 5, 0
  notail call fastcc void @"my.sexpr_parser::fail"(ptr sret([40 x i8]) align 8 %v8, { { i64, i64, i64 }, ptr } %p3, { i64, i64, i64 } %p1, { i8, [0 x i64] } %v7), !dbg !1007251
  %lt.5 = load i64, ptr %v8, align 8, !tbaa !7
  %lt.6 = trunc i64 %lt.5 to i8
  %v9 = insertvalue { i8, [0 x i64] } poison, i8 %lt.6, 0
  %fp.7 = getelementptr inbounds i8, ptr %v8, i64 8
  %fp.8 = getelementptr inbounds i8, ptr %v8, i64 8
  %lf.10 = load i64, ptr %fp.8, align 8, !tbaa !7
  %lr.11 = insertvalue { i64, i64, i64 } poison, i64 %lf.10, 0
  %fp.13 = getelementptr inbounds i8, ptr %fp.8, i64 8
  %lf.12 = load i64, ptr %fp.13, align 8, !tbaa !7
  %lr.14 = insertvalue { i64, i64, i64 } %lr.11, i64 %lf.12, 1
  %fp.16 = getelementptr inbounds i8, ptr %fp.8, i64 16
  %lf.15 = load i64, ptr %fp.16, align 8, !tbaa !7
  %lf.9 = insertvalue { i64, i64, i64 } %lr.14, i64 %lf.15, 2
  %lr.17 = insertvalue { { i64, i64, i64 }, ptr } poison, { i64, i64, i64 } %lf.9, 0
  %fp.19 = getelementptr inbounds i8, ptr %fp.8, i64 24
  %lf.18 = load ptr, ptr %fp.19, align 8, !tbaa !7
  %v10 = insertvalue { { i64, i64, i64 }, ptr } %lr.17, ptr %lf.18, 1
  call preserve_mostcc void @myl_core_err_trace_origin_preserve_most(ptr @myl.site.2873) #1
  store i64 1, ptr %ret, align 8, !tbaa !7
  %st.20 = extractvalue { i8, [0 x i64] } %v9, 0
  %st.21 = zext i8 %st.20 to i64
  store i64 %st.21, ptr %payload, align 8, !tbaa !7
  %fp.22 = getelementptr inbounds i8, ptr %payload, i64 8
  %fp.23 = getelementptr inbounds i8, ptr %ret, i64 112
  %sf.24 = extractvalue { { i64, i64, i64 }, ptr } %v10, 0
  %sf.25 = extractvalue { i64, i64, i64 } %sf.24, 0
  store i64 %sf.25, ptr %fp.23, align 8, !tbaa !7
  %sf.26 = extractvalue { i64, i64, i64 } %sf.24, 1
  %fp.27 = getelementptr inbounds i8, ptr %fp.23, i64 8
  store i64 %sf.26, ptr %fp.27, align 8, !tbaa !7
  %sf.28 = extractvalue { i64, i64, i64 } %sf.24, 2
  %fp.29 = getelementptr inbounds i8, ptr %fp.23, i64 16
  store i64 %sf.28, ptr %fp.29, align 8, !tbaa !7
  %sf.30 = extractvalue { { i64, i64, i64 }, ptr } %v10, 1
  %fp.31 = getelementptr inbounds i8, ptr %fp.23, i64 24
  store ptr %sf.30, ptr %fp.31, align 8, !tbaa !7
  ret void
b2:
  %v16 = call ptr @myl_core_list_new(i64 0, i64 48)
  %lay.32 = getelementptr inbounds i8, ptr %v16, i64 24
  store ptr @myl.layout.1, ptr %lay.32, align 8, !tbaa !5
  %stl.33 = getelementptr inbounds i8, ptr %v16, i64 8
  %stl.34 = load i64, ptr %stl.33, align 8, !tbaa !5
  store i64 %stl.34, ptr %state0.len, align 8
  %stc.35 = getelementptr inbounds i8, ptr %v16, i64 16
  %stc.36 = load i64, ptr %stc.35, align 8, !tbaa !5
  store i64 %stc.36, ptr %state0.cap, align 8
  br label %b3
b3:
  %v21 = phi { { i64, i64, i64 }, ptr } [ %p3, %b2 ], [ %v64, %b5 ]
  %v75 = phi ptr [ %v16, %b2 ], [ %v76, %b5 ]
  br label %b4
b4:
  notail call fastcc void @"my.sexpr_parser::next_token"(ptr sret([136 x i8]) align 8 %v22, ptr %v24, { { i64, i64, i64 }, ptr } %v21), !dbg !1007253
  %v23 = getelementptr inbounds i8, ptr %v22, i64 0
  %fp.37 = getelementptr inbounds i8, ptr %v22, i64 104
  %lf.39 = load i64, ptr %fp.37, align 8, !tbaa !7
  %lr.40 = insertvalue { i64, i64, i64 } poison, i64 %lf.39, 0
  %fp.42 = getelementptr inbounds i8, ptr %fp.37, i64 8
  %lf.41 = load i64, ptr %fp.42, align 8, !tbaa !7
  %lr.43 = insertvalue { i64, i64, i64 } %lr.40, i64 %lf.41, 1
  %fp.45 = getelementptr inbounds i8, ptr %fp.37, i64 16
  %lf.44 = load i64, ptr %fp.45, align 8, !tbaa !7
  %lf.38 = insertvalue { i64, i64, i64 } %lr.43, i64 %lf.44, 2
  %lr.46 = insertvalue { { i64, i64, i64 }, ptr } poison, { i64, i64, i64 } %lf.38, 0
  %fp.48 = getelementptr inbounds i8, ptr %fp.37, i64 24
  %lf.47 = load ptr, ptr %fp.48, align 8, !tbaa !7
  %v25 = insertvalue { { i64, i64, i64 }, ptr } %lr.46, ptr %lf.47, 1
  %t.49 = load i64, ptr %v23, align 8, !tbaa !7
  %v26 = trunc i64 %t.49 to i32
  %v28 = icmp eq i32 %v26, 1
  br i1 %v28, label %edge.50, label %b8
edge.50:
  %sts.51 = load i64, ptr %state0.len, align 8
  %sts.52 = getelementptr inbounds i8, ptr %v75, i64 8
  store i64 %sts.51, ptr %sts.52, align 8, !tbaa !5
  br label %b7
b5:
  br label %b3
b6:
  %v85 = getelementptr i8, ptr null, i64 0
  store i64 0, ptr %ret, align 8, !tbaa !7
  store i64 0, ptr %payload, align 8, !tbaa !7
  %fp.53 = getelementptr inbounds i8, ptr %payload, i64 8
  store ptr %v75, ptr %fp.53, align 8, !tbaa !7
  %fp.54 = getelementptr inbounds i8, ptr %payload, i64 16
  %sf.55 = extractvalue { i64, i64, i64 } %p1, 0
  store i64 %sf.55, ptr %fp.54, align 8, !tbaa !7
  %sf.56 = extractvalue { i64, i64, i64 } %p1, 1
  %fp.57 = getelementptr inbounds i8, ptr %fp.54, i64 8
  store i64 %sf.56, ptr %fp.57, align 8, !tbaa !7
  %sf.58 = extractvalue { i64, i64, i64 } %p1, 2
  %fp.59 = getelementptr inbounds i8, ptr %fp.54, i64 16
  store i64 %sf.58, ptr %fp.59, align 8, !tbaa !7
  %fp.60 = getelementptr inbounds i8, ptr %payload, i64 40
  store ptr %v85, ptr %fp.60, align 8, !tbaa !7
  %fp.61 = getelementptr inbounds i8, ptr %ret, i64 112
  %sf.62 = extractvalue { { i64, i64, i64 }, ptr } %v25, 0
  %sf.63 = extractvalue { i64, i64, i64 } %sf.62, 0
  store i64 %sf.63, ptr %fp.61, align 8, !tbaa !7
  %sf.64 = extractvalue { i64, i64, i64 } %sf.62, 1
  %fp.65 = getelementptr inbounds i8, ptr %fp.61, i64 8
  store i64 %sf.64, ptr %fp.65, align 8, !tbaa !7
  %sf.66 = extractvalue { i64, i64, i64 } %sf.62, 2
  %fp.67 = getelementptr inbounds i8, ptr %fp.61, i64 16
  store i64 %sf.66, ptr %fp.67, align 8, !tbaa !7
  %sf.68 = extractvalue { { i64, i64, i64 }, ptr } %v25, 1
  %fp.69 = getelementptr inbounds i8, ptr %fp.61, i64 24
  store ptr %sf.68, ptr %fp.69, align 8, !tbaa !7
  ret void
b7:
  call void @myl_core_free(ptr %v75)
  call preserve_mostcc void @myl_core_err_trace_append_preserve_most(ptr @myl.site.2874) #1
  %fp.70 = getelementptr inbounds i8, ptr %v23, i64 8
  %lt.71 = load i64, ptr %fp.70, align 8, !tbaa !7
  %lt.72 = trunc i64 %lt.71 to i8
  %v31 = insertvalue { i8, [0 x i64] } poison, i8 %lt.72, 0
  %fp.73 = getelementptr inbounds i8, ptr %fp.70, i64 8
  %cw.74 = load i64, ptr %v23, align 8, !tbaa !7
  %ct.75 = trunc i64 %cw.74 to i8
  %cc.76 = icmp eq i8 %ct.75, 0
  br i1 %cc.76, label %rc.then.77, label %b7.78
rc.then.77:
  %fp.79 = getelementptr inbounds i8, ptr %v23, i64 8
  %fp.80 = getelementptr inbounds i8, ptr %fp.79, i64 8
  %cm.81 = load ptr, ptr %fp.80, align 8, !tbaa !7
  %rc.82 = load atomic i32, ptr %cm.81 unordered, align 8, !tbaa !3, !range !8
  %rp.83 = icmp ult i32 %rc.82, 2147483648
  br i1 %rp.83, label %rc.dec.84, label %rc.slow.85, !prof !23
rc.dec.84:
  %rn.87 = sub nuw i32 %rc.82, 1
  %rz.88 = icmp eq i32 %rn.87, 0
  br i1 %rz.88, label %rc.free.90, label %rc.keep.89
rc.keep.89:
  store i32 %rn.87, ptr %cm.81, align 8, !tbaa !3
  br label %rc.then.86
rc.free.90:
  call void @myl_core_free(ptr %cm.81)
  br label %rc.then.86
rc.slow.85:
  call preserve_mostcc void @myl_core_release_slow(ptr %cm.81)
  br label %rc.then.86
rc.then.86:
  br label %b7.78
b7.78:
  store i64 1, ptr %ret, align 8, !tbaa !7
  %st.91 = extractvalue { i8, [0 x i64] } %v31, 0
  %st.92 = zext i8 %st.91 to i64
  store i64 %st.92, ptr %payload, align 8, !tbaa !7
  %fp.93 = getelementptr inbounds i8, ptr %payload, i64 8
  %fp.94 = getelementptr inbounds i8, ptr %ret, i64 112
  %sf.95 = extractvalue { { i64, i64, i64 }, ptr } %v25, 0
  %sf.96 = extractvalue { i64, i64, i64 } %sf.95, 0
  store i64 %sf.96, ptr %fp.94, align 8, !tbaa !7
  %sf.97 = extractvalue { i64, i64, i64 } %sf.95, 1
  %fp.98 = getelementptr inbounds i8, ptr %fp.94, i64 8
  store i64 %sf.97, ptr %fp.98, align 8, !tbaa !7
  %sf.99 = extractvalue { i64, i64, i64 } %sf.95, 2
  %fp.100 = getelementptr inbounds i8, ptr %fp.94, i64 16
  store i64 %sf.99, ptr %fp.100, align 8, !tbaa !7
  %sf.101 = extractvalue { { i64, i64, i64 }, ptr } %v25, 1
  %fp.102 = getelementptr inbounds i8, ptr %fp.94, i64 24
  store ptr %sf.101, ptr %fp.102, align 8, !tbaa !7
  ret void
b8:
  %v35 = getelementptr inbounds i8, ptr %v23, i64 8
  %lt.103 = load i64, ptr %v35, align 8, !tbaa !7
  %lt.104 = trunc i64 %lt.103 to i8
  %v36 = insertvalue { i8, [0 x i64] } poison, i8 %lt.104, 0
  %fp.105 = getelementptr inbounds i8, ptr %v35, i64 8
  %v37 = insertvalue { i8, [0 x i64] } poison, i8 8, 0
  %t.106 = extractvalue { i8, [0 x i64] } %v36, 0
  %v38 = zext i8 %t.106 to i32
  %t.107 = extractvalue { i8, [0 x i64] } %v37, 0
  %v39 = zext i8 %t.107 to i32
  %v40 = icmp eq i32 %v38, %v39
  br i1 %v40, label %edge.108, label %b10
edge.108:
  %sts.109 = load i64, ptr %state0.len, align 8
  %sts.110 = getelementptr inbounds i8, ptr %v75, i64 8
  store i64 %sts.109, ptr %sts.110, align 8, !tbaa !5
  br label %b9
b9:
  %cw.111 = load i64, ptr %v23, align 8, !tbaa !7
  %ct.112 = trunc i64 %cw.111 to i8
  %cc.113 = icmp eq i8 %ct.112, 0
  br i1 %cc.113, label %rc.then.114, label %b9.115
rc.then.114:
  %fp.116 = getelementptr inbounds i8, ptr %v23, i64 8
  %fp.117 = getelementptr inbounds i8, ptr %fp.116, i64 8
  %cm.118 = load ptr, ptr %fp.117, align 8, !tbaa !7
  %rc.119 = load atomic i32, ptr %cm.118 unordered, align 8, !tbaa !3, !range !8
  %rp.120 = icmp ult i32 %rc.119, 2147483648
  br i1 %rp.120, label %rc.dec.121, label %rc.slow.122, !prof !23
rc.dec.121:
  %rn.124 = sub nuw i32 %rc.119, 1
  %rz.125 = icmp eq i32 %rn.124, 0
  br i1 %rz.125, label %rc.free.127, label %rc.keep.126
rc.keep.126:
  store i32 %rn.124, ptr %cm.118, align 8, !tbaa !3
  br label %rc.then.123
rc.free.127:
  call void @myl_core_free(ptr %cm.118)
  br label %rc.then.123
rc.slow.122:
  call preserve_mostcc void @myl_core_release_slow(ptr %cm.118)
  br label %rc.then.123
rc.then.123:
  br label %b9.115
b9.115:
  call void @myl_core_free(ptr %v75)
  %v43 = insertvalue { i8, [0 x i64] } poison, i8 0, 0
  notail call fastcc void @"my.sexpr_parser::fail"(ptr sret([40 x i8]) align 8 %v44, { { i64, i64, i64 }, ptr } %v25, { i64, i64, i64 } %p1, { i8, [0 x i64] } %v43), !dbg !1007255
  %lt.128 = load i64, ptr %v44, align 8, !tbaa !7
  %lt.129 = trunc i64 %lt.128 to i8
  %v45 = insertvalue { i8, [0 x i64] } poison, i8 %lt.129, 0
  %fp.130 = getelementptr inbounds i8, ptr %v44, i64 8
  %fp.131 = getelementptr inbounds i8, ptr %v44, i64 8
  %lf.133 = load i64, ptr %fp.131, align 8, !tbaa !7
  %lr.134 = insertvalue { i64, i64, i64 } poison, i64 %lf.133, 0
  %fp.136 = getelementptr inbounds i8, ptr %fp.131, i64 8
  %lf.135 = load i64, ptr %fp.136, align 8, !tbaa !7
  %lr.137 = insertvalue { i64, i64, i64 } %lr.134, i64 %lf.135, 1
  %fp.139 = getelementptr inbounds i8, ptr %fp.131, i64 16
  %lf.138 = load i64, ptr %fp.139, align 8, !tbaa !7
  %lf.132 = insertvalue { i64, i64, i64 } %lr.137, i64 %lf.138, 2
  %lr.140 = insertvalue { { i64, i64, i64 }, ptr } poison, { i64, i64, i64 } %lf.132, 0
  %fp.142 = getelementptr inbounds i8, ptr %fp.131, i64 24
  %lf.141 = load ptr, ptr %fp.142, align 8, !tbaa !7
  %v46 = insertvalue { { i64, i64, i64 }, ptr } %lr.140, ptr %lf.141, 1
  call preserve_mostcc void @myl_core_err_trace_origin_preserve_most(ptr @myl.site.2875) #1
  store i64 1, ptr %ret, align 8, !tbaa !7
  %st.143 = extractvalue { i8, [0 x i64] } %v45, 0
  %st.144 = zext i8 %st.143 to i64
  store i64 %st.144, ptr %payload, align 8, !tbaa !7
  %fp.145 = getelementptr inbounds i8, ptr %payload, i64 8
  %fp.146 = getelementptr inbounds i8, ptr %ret, i64 112
  %sf.147 = extractvalue { { i64, i64, i64 }, ptr } %v46, 0
  %sf.148 = extractvalue { i64, i64, i64 } %sf.147, 0
  store i64 %sf.148, ptr %fp.146, align 8, !tbaa !7
  %sf.149 = extractvalue { i64, i64, i64 } %sf.147, 1
  %fp.150 = getelementptr inbounds i8, ptr %fp.146, i64 8
  store i64 %sf.149, ptr %fp.150, align 8, !tbaa !7
  %sf.151 = extractvalue { i64, i64, i64 } %sf.147, 2
  %fp.152 = getelementptr inbounds i8, ptr %fp.146, i64 16
  store i64 %sf.151, ptr %fp.152, align 8, !tbaa !7
  %sf.153 = extractvalue { { i64, i64, i64 }, ptr } %v46, 1
  %fp.154 = getelementptr inbounds i8, ptr %fp.146, i64 24
  store ptr %sf.153, ptr %fp.154, align 8, !tbaa !7
  ret void
b10:
  %lt.155 = load i64, ptr %v35, align 8, !tbaa !7
  %lt.156 = trunc i64 %lt.155 to i8
  %v51 = insertvalue { i8, [0 x i64] } poison, i8 %lt.156, 0
  %fp.157 = getelementptr inbounds i8, ptr %v35, i64 8
  %v52 = insertvalue { i8, [0 x i64] } poison, i8 1, 0
  %t.158 = extractvalue { i8, [0 x i64] } %v51, 0
  %v53 = zext i8 %t.158 to i32
  %t.159 = extractvalue { i8, [0 x i64] } %v52, 0
  %v54 = zext i8 %t.159 to i32
  %v55 = icmp eq i32 %v53, %v54
  br i1 %v55, label %edge.160, label %b12
edge.160:
  %sts.161 = load i64, ptr %state0.len, align 8
  %sts.162 = getelementptr inbounds i8, ptr %v75, i64 8
  store i64 %sts.161, ptr %sts.162, align 8, !tbaa !5
  br label %b11
b11:
  %cw.163 = load i64, ptr %v23, align 8, !tbaa !7
  %ct.164 = trunc i64 %cw.163 to i8
  %cc.165 = icmp eq i8 %ct.164, 0
  br i1 %cc.165, label %rc.then.166, label %b11.167
rc.then.166:
  %fp.168 = getelementptr inbounds i8, ptr %v23, i64 8
  %fp.169 = getelementptr inbounds i8, ptr %fp.168, i64 8
  %cm.170 = load ptr, ptr %fp.169, align 8, !tbaa !7
  %rc.171 = load atomic i32, ptr %cm.170 unordered, align 8, !tbaa !3, !range !8
  %rp.172 = icmp ult i32 %rc.171, 2147483648
  br i1 %rp.172, label %rc.dec.173, label %rc.slow.174, !prof !23
rc.dec.173:
  %rn.176 = sub nuw i32 %rc.171, 1
  %rz.177 = icmp eq i32 %rn.176, 0
  br i1 %rz.177, label %rc.free.179, label %rc.keep.178
rc.keep.178:
  store i32 %rn.176, ptr %cm.170, align 8, !tbaa !3
  br label %rc.then.175
rc.free.179:
  call void @myl_core_free(ptr %cm.170)
  br label %rc.then.175
rc.slow.174:
  call preserve_mostcc void @myl_core_release_slow(ptr %cm.170)
  br label %rc.then.175
rc.then.175:
  br label %b11.167
b11.167:
  br label %b6
b12:
  %v60 = add nsw i64 %p2, 1
  %fp.180 = getelementptr inbounds i8, ptr %v61, i64 8
  notail call fastcc void @"my.sexpr_parser::parse_node"(ptr sret([144 x i8]) align 8 %v61, ptr %v63, ptr %v35, i64 %v60, { { i64, i64, i64 }, ptr } %v25, ptr %fp.180), !dbg !1007257
  %cw.181 = load i64, ptr %v23, align 8, !tbaa !7
  %ct.182 = trunc i64 %cw.181 to i8
  %cc.183 = icmp eq i8 %ct.182, 0
  br i1 %cc.183, label %rc.then.184, label %b12.185
rc.then.184:
  %fp.186 = getelementptr inbounds i8, ptr %v23, i64 8
  %fp.187 = getelementptr inbounds i8, ptr %fp.186, i64 8
  %cm.188 = load ptr, ptr %fp.187, align 8, !tbaa !7
  %rc.189 = load atomic i32, ptr %cm.188 unordered, align 8, !tbaa !3, !range !8
  %rp.190 = icmp ult i32 %rc.189, 2147483648
  br i1 %rp.190, label %rc.dec.191, label %rc.slow.192, !prof !23
rc.dec.191:
  %rn.194 = sub nuw i32 %rc.189, 1
  %rz.195 = icmp eq i32 %rn.194, 0
  br i1 %rz.195, label %rc.free.197, label %rc.keep.196
rc.keep.196:
  store i32 %rn.194, ptr %cm.188, align 8, !tbaa !3
  br label %rc.then.193
rc.free.197:
  call void @myl_core_free(ptr %cm.188)
  br label %rc.then.193
rc.slow.192:
  call preserve_mostcc void @myl_core_release_slow(ptr %cm.188)
  br label %rc.then.193
rc.then.193:
  br label %b12.185
b12.185:
  %v62 = getelementptr inbounds i8, ptr %v61, i64 0
  %fp.198 = getelementptr inbounds i8, ptr %v61, i64 112
  %lf.200 = load i64, ptr %fp.198, align 8, !tbaa !7
  %lr.201 = insertvalue { i64, i64, i64 } poison, i64 %lf.200, 0
  %fp.203 = getelementptr inbounds i8, ptr %fp.198, i64 8
  %lf.202 = load i64, ptr %fp.203, align 8, !tbaa !7
  %lr.204 = insertvalue { i64, i64, i64 } %lr.201, i64 %lf.202, 1
  %fp.206 = getelementptr inbounds i8, ptr %fp.198, i64 16
  %lf.205 = load i64, ptr %fp.206, align 8, !tbaa !7
  %lf.199 = insertvalue { i64, i64, i64 } %lr.204, i64 %lf.205, 2
  %lr.207 = insertvalue { { i64, i64, i64 }, ptr } poison, { i64, i64, i64 } %lf.199, 0
  %fp.209 = getelementptr inbounds i8, ptr %fp.198, i64 24
  %lf.208 = load ptr, ptr %fp.209, align 8, !tbaa !7
  %v64 = insertvalue { { i64, i64, i64 }, ptr } %lr.207, ptr %lf.208, 1
  %t.210 = load i64, ptr %v62, align 8, !tbaa !7
  %v65 = trunc i64 %t.210 to i32
  %v67 = icmp eq i32 %v65, 1
  br i1 %v67, label %edge.211, label %b14
edge.211:
  %sts.212 = load i64, ptr %state0.len, align 8
  %sts.213 = getelementptr inbounds i8, ptr %v75, i64 8
  store i64 %sts.212, ptr %sts.213, align 8, !tbaa !5
  br label %b13
b13:
  call void @myl_core_free(ptr %v75)
  call preserve_mostcc void @myl_core_err_trace_append_preserve_most(ptr @myl.site.2876) #1
  %lt.214 = load i64, ptr %fp.180, align 8, !tbaa !7
  %lt.215 = trunc i64 %lt.214 to i8
  %v70 = insertvalue { i8, [0 x i64] } poison, i8 %lt.215, 0
  %fp.216 = getelementptr inbounds i8, ptr %fp.180, i64 8
  %cw.217 = load i64, ptr %v61, align 8, !tbaa !7
  %ct.218 = trunc i64 %cw.217 to i8
  %cc.219 = icmp eq i8 %ct.218, 0
  br i1 %cc.219, label %rc.then.220, label %b13.221
rc.then.220:
  %lt.223 = load i64, ptr %fp.180, align 8, !tbaa !7
  %lt.224 = trunc i64 %lt.223 to i8
  %lu.225 = insertvalue { i8, [1 x i64] } poison, i8 %lt.224, 0
  %fp.226 = getelementptr inbounds i8, ptr %fp.180, i64 8
  %lw.227 = load i64, ptr %fp.226, align 8, !tbaa !7
  %cm.222 = insertvalue { i8, [1 x i64] } %lu.225, i64 %lw.227, 1, 0
  %ct.228 = extractvalue { i8, [1 x i64] } %cm.222, 0
  %cc.229 = icmp eq i8 %ct.228, 0
  br i1 %cc.229, label %rc.then.230, label %rc.then.231
rc.then.230:
  %pw.234 = extractvalue { i8, [1 x i64] } %cm.222, 1, 0
  store i64 %pw.234, ptr %stack.233, align 8, !tbaa !7
  %lf.235 = load ptr, ptr %stack.233, align 8, !tbaa !7
  %cp.232 = insertvalue { ptr } poison, ptr %lf.235, 0
  %cf.236 = extractvalue { ptr } %cp.232, 0
  %rc.237 = load atomic i32, ptr %cf.236 unordered, align 8, !tbaa !3, !range !8
  %rp.238 = icmp ult i32 %rc.237, 2147483648
  br i1 %rp.238, label %rc.dec.239, label %rc.slow.240, !prof !23
rc.dec.239:
  %rn.242 = sub nuw i32 %rc.237, 1
  %rz.243 = icmp eq i32 %rn.242, 0
  br i1 %rz.243, label %rc.free.245, label %rc.keep.244
rc.keep.244:
  store i32 %rn.242, ptr %cf.236, align 8, !tbaa !3
  br label %rc.then.241
rc.free.245:
  call void @myl_core_free(ptr %cf.236)
  br label %rc.then.241
rc.slow.240:
  call preserve_mostcc void @myl_core_release_slow(ptr %cf.236)
  br label %rc.then.241
rc.then.241:
  br label %rc.then.231
rc.then.231:
  %cc.246 = icmp eq i8 %ct.228, 1
  br i1 %cc.246, label %rc.then.247, label %rc.then.248
rc.then.247:
  %pw.251 = extractvalue { i8, [1 x i64] } %cm.222, 1, 0
  store i64 %pw.251, ptr %stack.250, align 8, !tbaa !7
  %lf.252 = load ptr, ptr %stack.250, align 8, !tbaa !7
  %cp.249 = insertvalue { ptr } poison, ptr %lf.252, 0
  %cf.253 = extractvalue { ptr } %cp.249, 0
  %rc.254 = load atomic i32, ptr %cf.253 unordered, align 8, !tbaa !3, !range !8
  %rp.255 = icmp ult i32 %rc.254, 2147483648
  br i1 %rp.255, label %rc.dec.256, label %rc.slow.257, !prof !23
rc.dec.256:
  %rn.259 = sub nuw i32 %rc.254, 1
  %rz.260 = icmp eq i32 %rn.259, 0
  br i1 %rz.260, label %rc.free.262, label %rc.keep.261
rc.keep.261:
  store i32 %rn.259, ptr %cf.253, align 8, !tbaa !3
  br label %rc.then.258
rc.free.262:
  call void @myl_core_free(ptr %cf.253)
  br label %rc.then.258
rc.slow.257:
  call preserve_mostcc void @myl_core_release_slow(ptr %cf.253)
  br label %rc.then.258
rc.then.258:
  br label %rc.then.248
rc.then.248:
  %cc.263 = icmp eq i8 %ct.228, 2
  br i1 %cc.263, label %rc.then.264, label %rc.then.265
rc.then.264:
  %pw.268 = extractvalue { i8, [1 x i64] } %cm.222, 1, 0
  store i64 %pw.268, ptr %stack.267, align 8, !tbaa !7
  %lf.269 = load ptr, ptr %stack.267, align 8, !tbaa !7
  %cp.266 = insertvalue { ptr } poison, ptr %lf.269, 0
  %cf.270 = extractvalue { ptr } %cp.266, 0
  %rc.271 = load atomic i32, ptr %cf.270 unordered, align 8, !tbaa !3, !range !8
  %rp.272 = icmp ult i32 %rc.271, 2147483648
  br i1 %rp.272, label %rc.dec.273, label %rc.slow.274, !prof !23
rc.dec.273:
  %rn.276 = sub nuw i32 %rc.271, 1
  %rz.277 = icmp eq i32 %rn.276, 0
  br i1 %rz.277, label %rc.free.279, label %rc.keep.278
rc.keep.278:
  store i32 %rn.276, ptr %cf.270, align 8, !tbaa !3
  br label %rc.then.275
rc.free.279:
  call void @myl_core_free(ptr %cf.270)
  br label %rc.then.275
rc.slow.274:
  call preserve_mostcc void @myl_core_release_slow(ptr %cf.270)
  br label %rc.then.275
rc.then.275:
  br label %rc.then.265
rc.then.265:
  %fp.280 = getelementptr inbounds i8, ptr %fp.180, i64 40
  %cm.281 = load ptr, ptr %fp.280, align 8, !tbaa !7
  %cn.282 = icmp ne ptr %cm.281, null
  br i1 %cn.282, label %rc.then.283, label %rc.then.284
rc.then.283:
  %rc.285 = load atomic i32, ptr %cm.281 unordered, align 8, !tbaa !3, !range !8
  %rp.286 = icmp ult i32 %rc.285, 2147483648
  br i1 %rp.286, label %rc.dec.287, label %rc.slow.288, !prof !23
rc.dec.287:
  %rn.290 = sub nuw i32 %rc.285, 1
  %rz.291 = icmp eq i32 %rn.290, 0
  br i1 %rz.291, label %rc.free.293, label %rc.keep.292
rc.keep.292:
  store i32 %rn.290, ptr %cm.281, align 8, !tbaa !3
  br label %rc.then.289
rc.free.293:
  call void @myl_core_free(ptr %cm.281)
  br label %rc.then.289
rc.slow.288:
  call preserve_mostcc void @myl_core_release_slow(ptr %cm.281)
  br label %rc.then.289
rc.then.289:
  br label %rc.then.284
rc.then.284:
  br label %b13.221
b13.221:
  store i64 1, ptr %ret, align 8, !tbaa !7
  %st.294 = extractvalue { i8, [0 x i64] } %v70, 0
  %st.295 = zext i8 %st.294 to i64
  store i64 %st.295, ptr %payload, align 8, !tbaa !7
  %fp.296 = getelementptr inbounds i8, ptr %payload, i64 8
  %fp.297 = getelementptr inbounds i8, ptr %ret, i64 112
  %sf.298 = extractvalue { { i64, i64, i64 }, ptr } %v64, 0
  %sf.299 = extractvalue { i64, i64, i64 } %sf.298, 0
  store i64 %sf.299, ptr %fp.297, align 8, !tbaa !7
  %sf.300 = extractvalue { i64, i64, i64 } %sf.298, 1
  %fp.301 = getelementptr inbounds i8, ptr %fp.297, i64 8
  store i64 %sf.300, ptr %fp.301, align 8, !tbaa !7
  %sf.302 = extractvalue { i64, i64, i64 } %sf.298, 2
  %fp.303 = getelementptr inbounds i8, ptr %fp.297, i64 16
  store i64 %sf.302, ptr %fp.303, align 8, !tbaa !7
  %sf.304 = extractvalue { { i64, i64, i64 }, ptr } %v64, 1
  %fp.305 = getelementptr inbounds i8, ptr %fp.297, i64 24
  store ptr %sf.304, ptr %fp.305, align 8, !tbaa !7
  ret void
b14:
  %v74 = getelementptr inbounds i8, ptr %fp.180, i64 0
  %lt.307 = load i64, ptr %fp.180, align 8, !tbaa !7
  %lt.308 = trunc i64 %lt.307 to i8
  %lu.309 = insertvalue { i8, [1 x i64] } poison, i8 %lt.308, 0
  %fp.310 = getelementptr inbounds i8, ptr %fp.180, i64 8
  %lw.311 = load i64, ptr %fp.310, align 8, !tbaa !7
  %cm.306 = insertvalue { i8, [1 x i64] } %lu.309, i64 %lw.311, 1, 0
  %ct.312 = extractvalue { i8, [1 x i64] } %cm.306, 0
  %cc.313 = icmp eq i8 %ct.312, 0
  br i1 %cc.313, label %rc.then.314, label %b14.315
rc.then.314:
  %pw.318 = extractvalue { i8, [1 x i64] } %cm.306, 1, 0
  store i64 %pw.318, ptr %stack.317, align 8, !tbaa !7
  %lf.319 = load ptr, ptr %stack.317, align 8, !tbaa !7
  %cp.316 = insertvalue { ptr } poison, ptr %lf.319, 0
  %cf.320 = extractvalue { ptr } %cp.316, 0
  %rc.321 = load atomic i32, ptr %cf.320 unordered, align 8, !tbaa !3, !range !8
  %rp.322 = icmp ult i32 %rc.321, 2147483646
  br i1 %rp.322, label %rc.inc.323, label %rc.slow.324, !prof !23
rc.inc.323:
  %rn.326 = add nuw i32 %rc.321, 1
  store i32 %rn.326, ptr %cf.320, align 8, !tbaa !3
  br label %rc.then.325
rc.slow.324:
  call preserve_mostcc void @myl_core_retain_slow(ptr %cf.320)
  br label %rc.then.325
rc.then.325:
  br label %b14.315
b14.315:
  %cc.327 = icmp eq i8 %ct.312, 1
  br i1 %cc.327, label %rc.then.328, label %b14.329
rc.then.328:
  %pw.332 = extractvalue { i8, [1 x i64] } %cm.306, 1, 0
  store i64 %pw.332, ptr %stack.331, align 8, !tbaa !7
  %lf.333 = load ptr, ptr %stack.331, align 8, !tbaa !7
  %cp.330 = insertvalue { ptr } poison, ptr %lf.333, 0
  %cf.334 = extractvalue { ptr } %cp.330, 0
  %rc.335 = load atomic i32, ptr %cf.334 unordered, align 8, !tbaa !3, !range !8
  %rp.336 = icmp ult i32 %rc.335, 2147483646
  br i1 %rp.336, label %rc.inc.337, label %rc.slow.338, !prof !23
rc.inc.337:
  %rn.340 = add nuw i32 %rc.335, 1
  store i32 %rn.340, ptr %cf.334, align 8, !tbaa !3
  br label %rc.then.339
rc.slow.338:
  call preserve_mostcc void @myl_core_retain_slow(ptr %cf.334)
  br label %rc.then.339
rc.then.339:
  br label %b14.329
b14.329:
  %cc.341 = icmp eq i8 %ct.312, 2
  br i1 %cc.341, label %rc.then.342, label %b14.343
rc.then.342:
  %pw.346 = extractvalue { i8, [1 x i64] } %cm.306, 1, 0
  store i64 %pw.346, ptr %stack.345, align 8, !tbaa !7
  %lf.347 = load ptr, ptr %stack.345, align 8, !tbaa !7
  %cp.344 = insertvalue { ptr } poison, ptr %lf.347, 0
  %cf.348 = extractvalue { ptr } %cp.344, 0
  %rc.349 = load atomic i32, ptr %cf.348 unordered, align 8, !tbaa !3, !range !8
  %rp.350 = icmp ult i32 %rc.349, 2147483646
  br i1 %rp.350, label %rc.inc.351, label %rc.slow.352, !prof !23
rc.inc.351:
  %rn.354 = add nuw i32 %rc.349, 1
  store i32 %rn.354, ptr %cf.348, align 8, !tbaa !3
  br label %rc.then.353
rc.slow.352:
  call preserve_mostcc void @myl_core_retain_slow(ptr %cf.348)
  br label %rc.then.353
rc.then.353:
  br label %b14.343
b14.343:
  %fp.355 = getelementptr inbounds i8, ptr %fp.180, i64 40
  %cm.356 = load ptr, ptr %fp.355, align 8, !tbaa !7
  %cn.357 = icmp ne ptr %cm.356, null
  br i1 %cn.357, label %rc.then.358, label %b14.359
rc.then.358:
  %rc.360 = load atomic i32, ptr %cm.356 unordered, align 8, !tbaa !3, !range !8
  %rp.361 = icmp ult i32 %rc.360, 2147483646
  br i1 %rp.361, label %rc.inc.362, label %rc.slow.363, !prof !23
rc.inc.362:
  %rn.365 = add nuw i32 %rc.360, 1
  store i32 %rn.365, ptr %cm.356, align 8, !tbaa !3
  br label %rc.then.364
rc.slow.363:
  call preserve_mostcc void @myl_core_retain_slow(ptr %cm.356)
  br label %rc.then.364
rc.then.364:
  br label %b14.359
b14.359:
  %spl.366 = load i64, ptr %state0.len, align 8
  %spc.367 = load i64, ptr %state0.cap, align 8
  %spr.368 = icmp ult i64 %spl.366, %spc.367
  br i1 %spr.368, label %push.fits.369, label %push.grow.370, !prof !10
push.grow.370:
  %sts.373 = load i64, ptr %state0.len, align 8
  %sts.374 = getelementptr inbounds i8, ptr %v75, i64 8
  store i64 %sts.373, ptr %sts.374, align 8, !tbaa !5
  %spg.372 = call ptr @myl_core_list_grow(ptr %v75, i64 48)
  %spc.375 = getelementptr inbounds i8, ptr %spg.372, i64 16
  %spc.376 = load i64, ptr %spc.375, align 8, !tbaa !5
  store i64 %spc.376, ptr %state0.cap, align 8
  br label %b14.371
push.fits.369:
  br label %b14.371
b14.371:
  %v76 = phi ptr [ %v75, %push.fits.369 ], [ %spg.372, %push.grow.370 ]
  %data.377 = getelementptr inbounds i8, ptr %v76, i64 32
  %elt.378 = getelementptr inbounds [48 x i8], ptr %data.377, i64 %spl.366
  %payload.copy.379 = icmp ne ptr %elt.378, %fp.180
  br i1 %payload.copy.379, label %payload.copy.380, label %b14.381
payload.copy.380:
  call void @llvm.memcpy.p0.p0.i64(ptr %elt.378, ptr %v74, i64 48, i1 false)
  br label %b14.381
b14.381:
  %spn.382 = add nuw nsw i64 %spl.366, 1
  store i64 %spn.382, ptr %state0.len, align 8
  %cw.383 = load i64, ptr %v61, align 8, !tbaa !7
  %ct.384 = trunc i64 %cw.383 to i8
  %cc.385 = icmp eq i8 %ct.384, 0
  br i1 %cc.385, label %rc.then.386, label %b14.387
rc.then.386:
  %lt.389 = load i64, ptr %fp.180, align 8, !tbaa !7
  %lt.390 = trunc i64 %lt.389 to i8
  %lu.391 = insertvalue { i8, [1 x i64] } poison, i8 %lt.390, 0
  %fp.392 = getelementptr inbounds i8, ptr %fp.180, i64 8
  %lw.393 = load i64, ptr %fp.392, align 8, !tbaa !7
  %cm.388 = insertvalue { i8, [1 x i64] } %lu.391, i64 %lw.393, 1, 0
  %ct.394 = extractvalue { i8, [1 x i64] } %cm.388, 0
  %cc.395 = icmp eq i8 %ct.394, 0
  br i1 %cc.395, label %rc.then.396, label %rc.then.397
rc.then.396:
  %pw.400 = extractvalue { i8, [1 x i64] } %cm.388, 1, 0
  store i64 %pw.400, ptr %stack.399, align 8, !tbaa !7
  %lf.401 = load ptr, ptr %stack.399, align 8, !tbaa !7
  %cp.398 = insertvalue { ptr } poison, ptr %lf.401, 0
  %cf.402 = extractvalue { ptr } %cp.398, 0
  %rc.403 = load atomic i32, ptr %cf.402 unordered, align 8, !tbaa !3, !range !8
  %rp.404 = icmp ult i32 %rc.403, 2147483648
  br i1 %rp.404, label %rc.dec.405, label %rc.slow.406, !prof !23
rc.dec.405:
  %rn.408 = sub nuw i32 %rc.403, 1
  %rz.409 = icmp eq i32 %rn.408, 0
  br i1 %rz.409, label %rc.free.411, label %rc.keep.410
rc.keep.410:
  store i32 %rn.408, ptr %cf.402, align 8, !tbaa !3
  br label %rc.then.407
rc.free.411:
  call void @myl_core_free(ptr %cf.402)
  br label %rc.then.407
rc.slow.406:
  call preserve_mostcc void @myl_core_release_slow(ptr %cf.402)
  br label %rc.then.407
rc.then.407:
  br label %rc.then.397
rc.then.397:
  %cc.412 = icmp eq i8 %ct.394, 1
  br i1 %cc.412, label %rc.then.413, label %rc.then.414
rc.then.413:
  %pw.417 = extractvalue { i8, [1 x i64] } %cm.388, 1, 0
  store i64 %pw.417, ptr %stack.416, align 8, !tbaa !7
  %lf.418 = load ptr, ptr %stack.416, align 8, !tbaa !7
  %cp.415 = insertvalue { ptr } poison, ptr %lf.418, 0
  %cf.419 = extractvalue { ptr } %cp.415, 0
  %rc.420 = load atomic i32, ptr %cf.419 unordered, align 8, !tbaa !3, !range !8
  %rp.421 = icmp ult i32 %rc.420, 2147483648
  br i1 %rp.421, label %rc.dec.422, label %rc.slow.423, !prof !23
rc.dec.422:
  %rn.425 = sub nuw i32 %rc.420, 1
  %rz.426 = icmp eq i32 %rn.425, 0
  br i1 %rz.426, label %rc.free.428, label %rc.keep.427
rc.keep.427:
  store i32 %rn.425, ptr %cf.419, align 8, !tbaa !3
  br label %rc.then.424
rc.free.428:
  call void @myl_core_free(ptr %cf.419)
  br label %rc.then.424
rc.slow.423:
  call preserve_mostcc void @myl_core_release_slow(ptr %cf.419)
  br label %rc.then.424
rc.then.424:
  br label %rc.then.414
rc.then.414:
  %cc.429 = icmp eq i8 %ct.394, 2
  br i1 %cc.429, label %rc.then.430, label %rc.then.431
rc.then.430:
  %pw.434 = extractvalue { i8, [1 x i64] } %cm.388, 1, 0
  store i64 %pw.434, ptr %stack.433, align 8, !tbaa !7
  %lf.435 = load ptr, ptr %stack.433, align 8, !tbaa !7
  %cp.432 = insertvalue { ptr } poison, ptr %lf.435, 0
  %cf.436 = extractvalue { ptr } %cp.432, 0
  %rc.437 = load atomic i32, ptr %cf.436 unordered, align 8, !tbaa !3, !range !8
  %rp.438 = icmp ult i32 %rc.437, 2147483648
  br i1 %rp.438, label %rc.dec.439, label %rc.slow.440, !prof !23
rc.dec.439:
  %rn.442 = sub nuw i32 %rc.437, 1
  %rz.443 = icmp eq i32 %rn.442, 0
  br i1 %rz.443, label %rc.free.445, label %rc.keep.444
rc.keep.444:
  store i32 %rn.442, ptr %cf.436, align 8, !tbaa !3
  br label %rc.then.441
rc.free.445:
  call void @myl_core_free(ptr %cf.436)
  br label %rc.then.441
rc.slow.440:
  call preserve_mostcc void @myl_core_release_slow(ptr %cf.436)
  br label %rc.then.441
rc.then.441:
  br label %rc.then.431
rc.then.431:
  %fp.446 = getelementptr inbounds i8, ptr %fp.180, i64 40
  %cm.447 = load ptr, ptr %fp.446, align 8, !tbaa !7
  %cn.448 = icmp ne ptr %cm.447, null
  br i1 %cn.448, label %rc.then.449, label %rc.then.450
rc.then.449:
  %rc.451 = load atomic i32, ptr %cm.447 unordered, align 8, !tbaa !3, !range !8
  %rp.452 = icmp ult i32 %rc.451, 2147483648
  br i1 %rp.452, label %rc.dec.453, label %rc.slow.454, !prof !23
rc.dec.453:
  %rn.456 = sub nuw i32 %rc.451, 1
  %rz.457 = icmp eq i32 %rn.456, 0
  br i1 %rz.457, label %rc.free.459, label %rc.keep.458
rc.keep.458:
  store i32 %rn.456, ptr %cm.447, align 8, !tbaa !3
  br label %rc.then.455
rc.free.459:
  call void @myl_core_free(ptr %cm.447)
  br label %rc.then.455
rc.slow.454:
  call preserve_mostcc void @myl_core_release_slow(ptr %cm.447)
  br label %rc.then.455
rc.then.455:
  br label %rc.then.450
rc.then.450:
  br label %b14.387
b14.387:
  br label %b5
}

define internal fastcc void @"my.sexpr_parser::parse_node"(ptr noalias sret([144 x i8]) align 8 %ret, ptr noalias align 8 %p0, ptr noalias readonly align 8 %p1, i64 %p2, { { i64, i64, i64 }, ptr } %p3, ptr noalias %payload) nounwind uwtable !dbg !1006360 {
entry:
  %slot = alloca i64, align 8
  %stack.1 = alloca [144 x i8], align 8
  %stack.2 = alloca [40 x i8], align 8
  %stack.3 = alloca [40 x i8], align 8
  %stack.4 = alloca [88 x i8], align 8
  %stack.5 = alloca [88 x i8], align 8
  %stack.6 = alloca [88 x i8], align 8
  %stack.7 = alloca [88 x i8], align 8
  %v10 = getelementptr inbounds i8, ptr %stack.1, i64 0
  %v12 = getelementptr inbounds i8, ptr %p0, i64 0
  %v29 = getelementptr inbounds i8, ptr %stack.2, i64 0
  %v59 = getelementptr inbounds i8, ptr %stack.3, i64 0
  %v69 = getelementptr inbounds i8, ptr %stack.4, i64 0
  %v85 = getelementptr inbounds i8, ptr %stack.5, i64 0
  %v101 = getelementptr inbounds i8, ptr %stack.6, i64 0
  %v115 = getelementptr inbounds i8, ptr %stack.7, i64 0
  br label %b0
b0:
  %lt.8 = load i64, ptr %p1, align 8, !tbaa !7
  %lt.9 = trunc i64 %lt.8 to i8
  %v4 = insertvalue { i8, [0 x i64] } poison, i8 %lt.9, 0
  %fp.10 = getelementptr inbounds i8, ptr %p1, i64 8
  %t.11 = extractvalue { i8, [0 x i64] } %v4, 0
  %v5 = zext i8 %t.11 to i32
  %v7 = icmp eq i32 %v5, 0
  br i1 %v7, label %b2, label %b3
b2:
  %fp.12 = getelementptr inbounds i8, ptr %p1, i64 16
  %lf.13 = load i64, ptr %fp.12, align 8, !tbaa !7
  %lr.14 = insertvalue { i64, i64, i64 } poison, i64 %lf.13, 0
  %fp.16 = getelementptr inbounds i8, ptr %fp.12, i64 8
  %lf.15 = load i64, ptr %fp.16, align 8, !tbaa !7
  %lr.17 = insertvalue { i64, i64, i64 } %lr.14, i64 %lf.15, 1
  %fp.19 = getelementptr inbounds i8, ptr %fp.12, i64 16
  %lf.18 = load i64, ptr %fp.19, align 8, !tbaa !7
  %v9 = insertvalue { i64, i64, i64 } %lr.17, i64 %lf.18, 2
  %fp.20 = getelementptr inbounds i8, ptr %v10, i64 8
  notail call fastcc void @"my.sexpr_parser::parse_list"(ptr sret([144 x i8]) align 8 %v10, ptr %v12, { i64, i64, i64 } %v9, i64 %p2, { { i64, i64, i64 }, ptr } %p3, ptr %fp.20), !dbg !1006362
  %v11 = getelementptr inbounds i8, ptr %v10, i64 0
  %fp.21 = getelementptr inbounds i8, ptr %v10, i64 112
  %lf.23 = load i64, ptr %fp.21, align 8, !tbaa !7
  %lr.24 = insertvalue { i64, i64, i64 } poison, i64 %lf.23, 0
  %fp.26 = getelementptr inbounds i8, ptr %fp.21, i64 8
  %lf.25 = load i64, ptr %fp.26, align 8, !tbaa !7
  %lr.27 = insertvalue { i64, i64, i64 } %lr.24, i64 %lf.25, 1
  %fp.29 = getelementptr inbounds i8, ptr %fp.21, i64 16
  %lf.28 = load i64, ptr %fp.29, align 8, !tbaa !7
  %lf.22 = insertvalue { i64, i64, i64 } %lr.27, i64 %lf.28, 2
  %lr.30 = insertvalue { { i64, i64, i64 }, ptr } poison, { i64, i64, i64 } %lf.22, 0
  %fp.32 = getelementptr inbounds i8, ptr %fp.21, i64 24
  %lf.31 = load ptr, ptr %fp.32, align 8, !tbaa !7
  %v13 = insertvalue { { i64, i64, i64 }, ptr } %lr.30, ptr %lf.31, 1
  %t.33 = load i64, ptr %v11, align 8, !tbaa !7
  %v14 = trunc i64 %t.33 to i32
  %v16 = icmp eq i32 %v14, 1
  br i1 %v16, label %b4, label %b5
b3:
  %v25 = icmp eq i32 %v5, 1
  br i1 %v25, label %b6, label %b7
b4:
  call preserve_mostcc void @myl_core_err_trace_append_preserve_most(ptr @myl.site.2640) #1
  br label %b5
b5:
  call void @llvm.memcpy.p0.p0.i64(ptr %ret, ptr %v11, i64 8, i1 false)
  %fp.34 = getelementptr inbounds i8, ptr %v11, i64 8
  call void @llvm.memcpy.p0.p0.i64(ptr %payload, ptr %fp.34, i64 48, i1 false)
  %fp.35 = getelementptr inbounds i8, ptr %ret, i64 112
  %sf.36 = extractvalue { { i64, i64, i64 }, ptr } %v13, 0
  %sf.37 = extractvalue { i64, i64, i64 } %sf.36, 0
  store i64 %sf.37, ptr %fp.35, align 8, !tbaa !7
  %sf.38 = extractvalue { i64, i64, i64 } %sf.36, 1
  %fp.39 = getelementptr inbounds i8, ptr %fp.35, i64 8
  store i64 %sf.38, ptr %fp.39, align 8, !tbaa !7
  %sf.40 = extractvalue { i64, i64, i64 } %sf.36, 2
  %fp.41 = getelementptr inbounds i8, ptr %fp.35, i64 16
  store i64 %sf.40, ptr %fp.41, align 8, !tbaa !7
  %sf.42 = extractvalue { { i64, i64, i64 }, ptr } %v13, 1
  %fp.43 = getelementptr inbounds i8, ptr %fp.35, i64 24
  store ptr %sf.42, ptr %fp.43, align 8, !tbaa !7
  ret void
b6:
  %fp.44 = getelementptr inbounds i8, ptr %p1, i64 16
  %lf.45 = load i64, ptr %fp.44, align 8, !tbaa !7
  %lr.46 = insertvalue { i64, i64, i64 } poison, i64 %lf.45, 0
  %fp.48 = getelementptr inbounds i8, ptr %fp.44, i64 8
  %lf.47 = load i64, ptr %fp.48, align 8, !tbaa !7
  %lr.49 = insertvalue { i64, i64, i64 } %lr.46, i64 %lf.47, 1
  %fp.51 = getelementptr inbounds i8, ptr %fp.44, i64 16
  %lf.50 = load i64, ptr %fp.51, align 8, !tbaa !7
  %v27 = insertvalue { i64, i64, i64 } %lr.49, i64 %lf.50, 2
  %v28 = insertvalue { i8, [0 x i64] } poison, i8 1, 0
  notail call fastcc void @"my.sexpr_parser::fail"(ptr sret([40 x i8]) align 8 %v29, { { i64, i64, i64 }, ptr } %p3, { i64, i64, i64 } %v27, { i8, [0 x i64] } %v28), !dbg !1006364
  %lt.52 = load i64, ptr %v29, align 8, !tbaa !7
  %lt.53 = trunc i64 %lt.52 to i8
  %v30 = insertvalue { i8, [0 x i64] } poison, i8 %lt.53, 0
  %fp.54 = getelementptr inbounds i8, ptr %v29, i64 8
  %fp.55 = getelementptr inbounds i8, ptr %v29, i64 8
  %lf.57 = load i64, ptr %fp.55, align 8, !tbaa !7
  %lr.58 = insertvalue { i64, i64, i64 } poison, i64 %lf.57, 0
  %fp.60 = getelementptr inbounds i8, ptr %fp.55, i64 8
  %lf.59 = load i64, ptr %fp.60, align 8, !tbaa !7
  %lr.61 = insertvalue { i64, i64, i64 } %lr.58, i64 %lf.59, 1
  %fp.63 = getelementptr inbounds i8, ptr %fp.55, i64 16
  %lf.62 = load i64, ptr %fp.63, align 8, !tbaa !7
  %lf.56 = insertvalue { i64, i64, i64 } %lr.61, i64 %lf.62, 2
  %lr.64 = insertvalue { { i64, i64, i64 }, ptr } poison, { i64, i64, i64 } %lf.56, 0
  %fp.66 = getelementptr inbounds i8, ptr %fp.55, i64 24
  %lf.65 = load ptr, ptr %fp.66, align 8, !tbaa !7
  %v31 = insertvalue { { i64, i64, i64 }, ptr } %lr.64, ptr %lf.65, 1
  call preserve_mostcc void @myl_core_err_trace_origin_preserve_most(ptr @myl.site.2641) #1
  store i64 1, ptr %ret, align 8, !tbaa !7
  %st.67 = extractvalue { i8, [0 x i64] } %v30, 0
  %st.68 = zext i8 %st.67 to i64
  store i64 %st.68, ptr %payload, align 8, !tbaa !7
  %fp.69 = getelementptr inbounds i8, ptr %payload, i64 8
  %fp.70 = getelementptr inbounds i8, ptr %ret, i64 112
  %sf.71 = extractvalue { { i64, i64, i64 }, ptr } %v31, 0
  %sf.72 = extractvalue { i64, i64, i64 } %sf.71, 0
  store i64 %sf.72, ptr %fp.70, align 8, !tbaa !7
  %sf.73 = extractvalue { i64, i64, i64 } %sf.71, 1
  %fp.74 = getelementptr inbounds i8, ptr %fp.70, i64 8
  store i64 %sf.73, ptr %fp.74, align 8, !tbaa !7
  %sf.75 = extractvalue { i64, i64, i64 } %sf.71, 2
  %fp.76 = getelementptr inbounds i8, ptr %fp.70, i64 16
  store i64 %sf.75, ptr %fp.76, align 8, !tbaa !7
  %sf.77 = extractvalue { { i64, i64, i64 }, ptr } %v31, 1
  %fp.78 = getelementptr inbounds i8, ptr %fp.70, i64 24
  store ptr %sf.77, ptr %fp.78, align 8, !tbaa !7
  ret void
b7:
  %v37 = icmp eq i32 %v5, 2
  br i1 %v37, label %b8, label %b9
b8:
  %fp.79 = getelementptr inbounds i8, ptr %p1, i64 16
  %lf.80 = load i64, ptr %fp.79, align 8, !tbaa !7
  %lr.81 = insertvalue { i64, i64, i64 } poison, i64 %lf.80, 0
  %fp.83 = getelementptr inbounds i8, ptr %fp.79, i64 8
  %lf.82 = load i64, ptr %fp.83, align 8, !tbaa !7
  %lr.84 = insertvalue { i64, i64, i64 } %lr.81, i64 %lf.82, 1
  %fp.86 = getelementptr inbounds i8, ptr %fp.79, i64 16
  %lf.85 = load i64, ptr %fp.86, align 8, !tbaa !7
  %v39 = insertvalue { i64, i64, i64 } %lr.84, i64 %lf.85, 2
  %fp.87 = getelementptr inbounds i8, ptr %p1, i64 8
  %v40 = load ptr, ptr %fp.87, align 8, !tbaa !7
  %rc.88 = load atomic i32, ptr %v40 unordered, align 8, !tbaa !3, !range !8
  %rp.89 = icmp ult i32 %rc.88, 2147483646
  br i1 %rp.89, label %rc.inc.90, label %rc.slow.91, !prof !23
rc.inc.90:
  %rn.93 = add nuw i32 %rc.88, 1
  store i32 %rn.93, ptr %v40, align 8, !tbaa !3
  br label %b8.92
rc.slow.91:
  call preserve_mostcc void @myl_core_retain_slow(ptr %v40)
  br label %b8.92
b8.92:
  %v130 = getelementptr i8, ptr null, i64 0
  store i64 0, ptr %ret, align 8, !tbaa !7
  store i64 1, ptr %payload, align 8, !tbaa !7
  %fp.94 = getelementptr inbounds i8, ptr %payload, i64 8
  store ptr %v40, ptr %fp.94, align 8, !tbaa !7
  %fp.95 = getelementptr inbounds i8, ptr %payload, i64 16
  %sf.96 = extractvalue { i64, i64, i64 } %v39, 0
  store i64 %sf.96, ptr %fp.95, align 8, !tbaa !7
  %sf.97 = extractvalue { i64, i64, i64 } %v39, 1
  %fp.98 = getelementptr inbounds i8, ptr %fp.95, i64 8
  store i64 %sf.97, ptr %fp.98, align 8, !tbaa !7
  %sf.99 = extractvalue { i64, i64, i64 } %v39, 2
  %fp.100 = getelementptr inbounds i8, ptr %fp.95, i64 16
  store i64 %sf.99, ptr %fp.100, align 8, !tbaa !7
  %fp.101 = getelementptr inbounds i8, ptr %payload, i64 40
  store ptr %v130, ptr %fp.101, align 8, !tbaa !7
  %fp.102 = getelementptr inbounds i8, ptr %ret, i64 112
  %sf.103 = extractvalue { { i64, i64, i64 }, ptr } %p3, 0
  %sf.104 = extractvalue { i64, i64, i64 } %sf.103, 0
  store i64 %sf.104, ptr %fp.102, align 8, !tbaa !7
  %sf.105 = extractvalue { i64, i64, i64 } %sf.103, 1
  %fp.106 = getelementptr inbounds i8, ptr %fp.102, i64 8
  store i64 %sf.105, ptr %fp.106, align 8, !tbaa !7
  %sf.107 = extractvalue { i64, i64, i64 } %sf.103, 2
  %fp.108 = getelementptr inbounds i8, ptr %fp.102, i64 16
  store i64 %sf.107, ptr %fp.108, align 8, !tbaa !7
  %sf.109 = extractvalue { { i64, i64, i64 }, ptr } %p3, 1
  %fp.110 = getelementptr inbounds i8, ptr %fp.102, i64 24
  store ptr %sf.109, ptr %fp.110, align 8, !tbaa !7
  ret void
b9:
  %v46 = icmp eq i32 %v5, 3
  br i1 %v46, label %b10, label %b11
b10:
  %fp.111 = getelementptr inbounds i8, ptr %p1, i64 16
  %lf.112 = load i64, ptr %fp.111, align 8, !tbaa !7
  %lr.113 = insertvalue { i64, i64, i64 } poison, i64 %lf.112, 0
  %fp.115 = getelementptr inbounds i8, ptr %fp.111, i64 8
  %lf.114 = load i64, ptr %fp.115, align 8, !tbaa !7
  %lr.116 = insertvalue { i64, i64, i64 } %lr.113, i64 %lf.114, 1
  %fp.118 = getelementptr inbounds i8, ptr %fp.111, i64 16
  %lf.117 = load i64, ptr %fp.118, align 8, !tbaa !7
  %v48 = insertvalue { i64, i64, i64 } %lr.116, i64 %lf.117, 2
  %fp.119 = getelementptr inbounds i8, ptr %p1, i64 8
  %v49 = load ptr, ptr %fp.119, align 8, !tbaa !7
  %rc.120 = load atomic i32, ptr %v49 unordered, align 8, !tbaa !3, !range !8
  %rp.121 = icmp ult i32 %rc.120, 2147483646
  br i1 %rp.121, label %rc.inc.122, label %rc.slow.123, !prof !23
rc.inc.122:
  %rn.125 = add nuw i32 %rc.120, 1
  store i32 %rn.125, ptr %v49, align 8, !tbaa !3
  br label %b10.124
rc.slow.123:
  call preserve_mostcc void @myl_core_retain_slow(ptr %v49)
  br label %b10.124
b10.124:
  %v134 = getelementptr i8, ptr null, i64 0
  store i64 0, ptr %ret, align 8, !tbaa !7
  store i64 2, ptr %payload, align 8, !tbaa !7
  %fp.126 = getelementptr inbounds i8, ptr %payload, i64 8
  store ptr %v49, ptr %fp.126, align 8, !tbaa !7
  %fp.127 = getelementptr inbounds i8, ptr %payload, i64 16
  %sf.128 = extractvalue { i64, i64, i64 } %v48, 0
  store i64 %sf.128, ptr %fp.127, align 8, !tbaa !7
  %sf.129 = extractvalue { i64, i64, i64 } %v48, 1
  %fp.130 = getelementptr inbounds i8, ptr %fp.127, i64 8
  store i64 %sf.129, ptr %fp.130, align 8, !tbaa !7
  %sf.131 = extractvalue { i64, i64, i64 } %v48, 2
  %fp.132 = getelementptr inbounds i8, ptr %fp.127, i64 16
  store i64 %sf.131, ptr %fp.132, align 8, !tbaa !7
  %fp.133 = getelementptr inbounds i8, ptr %payload, i64 40
  store ptr %v134, ptr %fp.133, align 8, !tbaa !7
  %fp.134 = getelementptr inbounds i8, ptr %ret, i64 112
  %sf.135 = extractvalue { { i64, i64, i64 }, ptr } %p3, 0
  %sf.136 = extractvalue { i64, i64, i64 } %sf.135, 0
  store i64 %sf.136, ptr %fp.134, align 8, !tbaa !7
  %sf.137 = extractvalue { i64, i64, i64 } %sf.135, 1
  %fp.138 = getelementptr inbounds i8, ptr %fp.134, i64 8
  store i64 %sf.137, ptr %fp.138, align 8, !tbaa !7
  %sf.139 = extractvalue { i64, i64, i64 } %sf.135, 2
  %fp.140 = getelementptr inbounds i8, ptr %fp.134, i64 16
  store i64 %sf.139, ptr %fp.140, align 8, !tbaa !7
  %sf.141 = extractvalue { { i64, i64, i64 }, ptr } %p3, 1
  %fp.142 = getelementptr inbounds i8, ptr %fp.134, i64 24
  store ptr %sf.141, ptr %fp.142, align 8, !tbaa !7
  ret void
b11:
  %v55 = icmp eq i32 %v5, 8
  br i1 %v55, label %b12, label %b13
b12:
  %fp.143 = getelementptr inbounds i8, ptr %p1, i64 16
  %lf.144 = load i64, ptr %fp.143, align 8, !tbaa !7
  %lr.145 = insertvalue { i64, i64, i64 } poison, i64 %lf.144, 0
  %fp.147 = getelementptr inbounds i8, ptr %fp.143, i64 8
  %lf.146 = load i64, ptr %fp.147, align 8, !tbaa !7
  %lr.148 = insertvalue { i64, i64, i64 } %lr.145, i64 %lf.146, 1
  %fp.150 = getelementptr inbounds i8, ptr %fp.143, i64 16
  %lf.149 = load i64, ptr %fp.150, align 8, !tbaa !7
  %v57 = insertvalue { i64, i64, i64 } %lr.148, i64 %lf.149, 2
  %v58 = insertvalue { i8, [0 x i64] } poison, i8 0, 0
  notail call fastcc void @"my.sexpr_parser::fail"(ptr sret([40 x i8]) align 8 %v59, { { i64, i64, i64 }, ptr } %p3, { i64, i64, i64 } %v57, { i8, [0 x i64] } %v58), !dbg !1006366
  %lt.151 = load i64, ptr %v59, align 8, !tbaa !7
  %lt.152 = trunc i64 %lt.151 to i8
  %v60 = insertvalue { i8, [0 x i64] } poison, i8 %lt.152, 0
  %fp.153 = getelementptr inbounds i8, ptr %v59, i64 8
  %fp.154 = getelementptr inbounds i8, ptr %v59, i64 8
  %lf.156 = load i64, ptr %fp.154, align 8, !tbaa !7
  %lr.157 = insertvalue { i64, i64, i64 } poison, i64 %lf.156, 0
  %fp.159 = getelementptr inbounds i8, ptr %fp.154, i64 8
  %lf.158 = load i64, ptr %fp.159, align 8, !tbaa !7
  %lr.160 = insertvalue { i64, i64, i64 } %lr.157, i64 %lf.158, 1
  %fp.162 = getelementptr inbounds i8, ptr %fp.154, i64 16
  %lf.161 = load i64, ptr %fp.162, align 8, !tbaa !7
  %lf.155 = insertvalue { i64, i64, i64 } %lr.160, i64 %lf.161, 2
  %lr.163 = insertvalue { { i64, i64, i64 }, ptr } poison, { i64, i64, i64 } %lf.155, 0
  %fp.165 = getelementptr inbounds i8, ptr %fp.154, i64 24
  %lf.164 = load ptr, ptr %fp.165, align 8, !tbaa !7
  %v61 = insertvalue { { i64, i64, i64 }, ptr } %lr.163, ptr %lf.164, 1
  call preserve_mostcc void @myl_core_err_trace_origin_preserve_most(ptr @myl.site.2642) #1
  store i64 1, ptr %ret, align 8, !tbaa !7
  %st.166 = extractvalue { i8, [0 x i64] } %v60, 0
  %st.167 = zext i8 %st.166 to i64
  store i64 %st.167, ptr %payload, align 8, !tbaa !7
  %fp.168 = getelementptr inbounds i8, ptr %payload, i64 8
  %fp.169 = getelementptr inbounds i8, ptr %ret, i64 112
  %sf.170 = extractvalue { { i64, i64, i64 }, ptr } %v61, 0
  %sf.171 = extractvalue { i64, i64, i64 } %sf.170, 0
  store i64 %sf.171, ptr %fp.169, align 8, !tbaa !7
  %sf.172 = extractvalue { i64, i64, i64 } %sf.170, 1
  %fp.173 = getelementptr inbounds i8, ptr %fp.169, i64 8
  store i64 %sf.172, ptr %fp.173, align 8, !tbaa !7
  %sf.174 = extractvalue { i64, i64, i64 } %sf.170, 2
  %fp.175 = getelementptr inbounds i8, ptr %fp.169, i64 16
  store i64 %sf.174, ptr %fp.175, align 8, !tbaa !7
  %sf.176 = extractvalue { { i64, i64, i64 }, ptr } %v61, 1
  %fp.177 = getelementptr inbounds i8, ptr %fp.169, i64 24
  store ptr %sf.176, ptr %fp.177, align 8, !tbaa !7
  ret void
b13:
  %v67 = icmp eq i32 %v5, 4
  br i1 %v67, label %b14, label %b15
b14:
  %fp.178 = getelementptr inbounds i8, ptr %v69, i64 8
  notail call fastcc void @"my.sexpr_parser::parse_number_node"(ptr sret([88 x i8]) align 8 %v69, ptr %p0, ptr %p1, { { i64, i64, i64 }, ptr } %p3, ptr %fp.178), !dbg !1006368
  %v70 = getelementptr inbounds i8, ptr %v69, i64 0
  %fp.179 = getelementptr inbounds i8, ptr %v69, i64 56
  %lf.181 = load i64, ptr %fp.179, align 8, !tbaa !7
  %lr.182 = insertvalue { i64, i64, i64 } poison, i64 %lf.181, 0
  %fp.184 = getelementptr inbounds i8, ptr %fp.179, i64 8
  %lf.183 = load i64, ptr %fp.184, align 8, !tbaa !7
  %lr.185 = insertvalue { i64, i64, i64 } %lr.182, i64 %lf.183, 1
  %fp.187 = getelementptr inbounds i8, ptr %fp.179, i64 16
  %lf.186 = load i64, ptr %fp.187, align 8, !tbaa !7
  %lf.180 = insertvalue { i64, i64, i64 } %lr.185, i64 %lf.186, 2
  %lr.188 = insertvalue { { i64, i64, i64 }, ptr } poison, { i64, i64, i64 } %lf.180, 0
  %fp.190 = getelementptr inbounds i8, ptr %fp.179, i64 24
  %lf.189 = load ptr, ptr %fp.190, align 8, !tbaa !7
  %v71 = insertvalue { { i64, i64, i64 }, ptr } %lr.188, ptr %lf.189, 1
  %t.191 = load i64, ptr %v70, align 8, !tbaa !7
  %v72 = trunc i64 %t.191 to i32
  %v74 = icmp eq i32 %v72, 1
  br i1 %v74, label %b16, label %b17
b15:
  %v83 = icmp eq i32 %v5, 5
  br i1 %v83, label %b18, label %b19
b16:
  call preserve_mostcc void @myl_core_err_trace_append_preserve_most(ptr @myl.site.2643) #1
  br label %b17
b17:
  call void @llvm.memcpy.p0.p0.i64(ptr %ret, ptr %v70, i64 8, i1 false)
  %fp.192 = getelementptr inbounds i8, ptr %v70, i64 8
  call void @llvm.memcpy.p0.p0.i64(ptr %payload, ptr %fp.192, i64 48, i1 false)
  %fp.193 = getelementptr inbounds i8, ptr %ret, i64 112
  %sf.194 = extractvalue { { i64, i64, i64 }, ptr } %v71, 0
  %sf.195 = extractvalue { i64, i64, i64 } %sf.194, 0
  store i64 %sf.195, ptr %fp.193, align 8, !tbaa !7
  %sf.196 = extractvalue { i64, i64, i64 } %sf.194, 1
  %fp.197 = getelementptr inbounds i8, ptr %fp.193, i64 8
  store i64 %sf.196, ptr %fp.197, align 8, !tbaa !7
  %sf.198 = extractvalue { i64, i64, i64 } %sf.194, 2
  %fp.199 = getelementptr inbounds i8, ptr %fp.193, i64 16
  store i64 %sf.198, ptr %fp.199, align 8, !tbaa !7
  %sf.200 = extractvalue { { i64, i64, i64 }, ptr } %v71, 1
  %fp.201 = getelementptr inbounds i8, ptr %fp.193, i64 24
  store ptr %sf.200, ptr %fp.201, align 8, !tbaa !7
  ret void
b18:
  %fp.202 = getelementptr inbounds i8, ptr %v85, i64 8
  notail call fastcc void @"my.sexpr_parser::parse_number_node"(ptr sret([88 x i8]) align 8 %v85, ptr %p0, ptr %p1, { { i64, i64, i64 }, ptr } %p3, ptr %fp.202), !dbg !1006370
  %v86 = getelementptr inbounds i8, ptr %v85, i64 0
  %fp.203 = getelementptr inbounds i8, ptr %v85, i64 56
  %lf.205 = load i64, ptr %fp.203, align 8, !tbaa !7
  %lr.206 = insertvalue { i64, i64, i64 } poison, i64 %lf.205, 0
  %fp.208 = getelementptr inbounds i8, ptr %fp.203, i64 8
  %lf.207 = load i64, ptr %fp.208, align 8, !tbaa !7
  %lr.209 = insertvalue { i64, i64, i64 } %lr.206, i64 %lf.207, 1
  %fp.211 = getelementptr inbounds i8, ptr %fp.203, i64 16
  %lf.210 = load i64, ptr %fp.211, align 8, !tbaa !7
  %lf.204 = insertvalue { i64, i64, i64 } %lr.209, i64 %lf.210, 2
  %lr.212 = insertvalue { { i64, i64, i64 }, ptr } poison, { i64, i64, i64 } %lf.204, 0
  %fp.214 = getelementptr inbounds i8, ptr %fp.203, i64 24
  %lf.213 = load ptr, ptr %fp.214, align 8, !tbaa !7
  %v87 = insertvalue { { i64, i64, i64 }, ptr } %lr.212, ptr %lf.213, 1
  %t.215 = load i64, ptr %v86, align 8, !tbaa !7
  %v88 = trunc i64 %t.215 to i32
  %v90 = icmp eq i32 %v88, 1
  br i1 %v90, label %b20, label %b21
b19:
  %v99 = icmp eq i32 %v5, 6
  br i1 %v99, label %b22, label %b23
b20:
  call preserve_mostcc void @myl_core_err_trace_append_preserve_most(ptr @myl.site.2644) #1
  br label %b21
b21:
  call void @llvm.memcpy.p0.p0.i64(ptr %ret, ptr %v86, i64 8, i1 false)
  %fp.216 = getelementptr inbounds i8, ptr %v86, i64 8
  call void @llvm.memcpy.p0.p0.i64(ptr %payload, ptr %fp.216, i64 48, i1 false)
  %fp.217 = getelementptr inbounds i8, ptr %ret, i64 112
  %sf.218 = extractvalue { { i64, i64, i64 }, ptr } %v87, 0
  %sf.219 = extractvalue { i64, i64, i64 } %sf.218, 0
  store i64 %sf.219, ptr %fp.217, align 8, !tbaa !7
  %sf.220 = extractvalue { i64, i64, i64 } %sf.218, 1
  %fp.221 = getelementptr inbounds i8, ptr %fp.217, i64 8
  store i64 %sf.220, ptr %fp.221, align 8, !tbaa !7
  %sf.222 = extractvalue { i64, i64, i64 } %sf.218, 2
  %fp.223 = getelementptr inbounds i8, ptr %fp.217, i64 16
  store i64 %sf.222, ptr %fp.223, align 8, !tbaa !7
  %sf.224 = extractvalue { { i64, i64, i64 }, ptr } %v87, 1
  %fp.225 = getelementptr inbounds i8, ptr %fp.217, i64 24
  store ptr %sf.224, ptr %fp.225, align 8, !tbaa !7
  ret void
b22:
  %fp.226 = getelementptr inbounds i8, ptr %v101, i64 8
  notail call fastcc void @"my.sexpr_parser::parse_number_node"(ptr sret([88 x i8]) align 8 %v101, ptr %p0, ptr %p1, { { i64, i64, i64 }, ptr } %p3, ptr %fp.226), !dbg !1006372
  %v102 = getelementptr inbounds i8, ptr %v101, i64 0
  %fp.227 = getelementptr inbounds i8, ptr %v101, i64 56
  %lf.229 = load i64, ptr %fp.227, align 8, !tbaa !7
  %lr.230 = insertvalue { i64, i64, i64 } poison, i64 %lf.229, 0
  %fp.232 = getelementptr inbounds i8, ptr %fp.227, i64 8
  %lf.231 = load i64, ptr %fp.232, align 8, !tbaa !7
  %lr.233 = insertvalue { i64, i64, i64 } %lr.230, i64 %lf.231, 1
  %fp.235 = getelementptr inbounds i8, ptr %fp.227, i64 16
  %lf.234 = load i64, ptr %fp.235, align 8, !tbaa !7
  %lf.228 = insertvalue { i64, i64, i64 } %lr.233, i64 %lf.234, 2
  %lr.236 = insertvalue { { i64, i64, i64 }, ptr } poison, { i64, i64, i64 } %lf.228, 0
  %fp.238 = getelementptr inbounds i8, ptr %fp.227, i64 24
  %lf.237 = load ptr, ptr %fp.238, align 8, !tbaa !7
  %v103 = insertvalue { { i64, i64, i64 }, ptr } %lr.236, ptr %lf.237, 1
  %t.239 = load i64, ptr %v102, align 8, !tbaa !7
  %v104 = trunc i64 %t.239 to i32
  %v106 = icmp eq i32 %v104, 1
  br i1 %v106, label %b24, label %b25
b23:
  br label %b26
b24:
  call preserve_mostcc void @myl_core_err_trace_append_preserve_most(ptr @myl.site.2645) #1
  br label %b25
b25:
  call void @llvm.memcpy.p0.p0.i64(ptr %ret, ptr %v102, i64 8, i1 false)
  %fp.240 = getelementptr inbounds i8, ptr %v102, i64 8
  call void @llvm.memcpy.p0.p0.i64(ptr %payload, ptr %fp.240, i64 48, i1 false)
  %fp.241 = getelementptr inbounds i8, ptr %ret, i64 112
  %sf.242 = extractvalue { { i64, i64, i64 }, ptr } %v103, 0
  %sf.243 = extractvalue { i64, i64, i64 } %sf.242, 0
  store i64 %sf.243, ptr %fp.241, align 8, !tbaa !7
  %sf.244 = extractvalue { i64, i64, i64 } %sf.242, 1
  %fp.245 = getelementptr inbounds i8, ptr %fp.241, i64 8
  store i64 %sf.244, ptr %fp.245, align 8, !tbaa !7
  %sf.246 = extractvalue { i64, i64, i64 } %sf.242, 2
  %fp.247 = getelementptr inbounds i8, ptr %fp.241, i64 16
  store i64 %sf.246, ptr %fp.247, align 8, !tbaa !7
  %sf.248 = extractvalue { { i64, i64, i64 }, ptr } %v103, 1
  %fp.249 = getelementptr inbounds i8, ptr %fp.241, i64 24
  store ptr %sf.248, ptr %fp.249, align 8, !tbaa !7
  ret void
b26:
  %fp.250 = getelementptr inbounds i8, ptr %v115, i64 8
  notail call fastcc void @"my.sexpr_parser::parse_number_node"(ptr sret([88 x i8]) align 8 %v115, ptr %p0, ptr %p1, { { i64, i64, i64 }, ptr } %p3, ptr %fp.250), !dbg !1006374
  %v116 = getelementptr inbounds i8, ptr %v115, i64 0
  %fp.251 = getelementptr inbounds i8, ptr %v115, i64 56
  %lf.253 = load i64, ptr %fp.251, align 8, !tbaa !7
  %lr.254 = insertvalue { i64, i64, i64 } poison, i64 %lf.253, 0
  %fp.256 = getelementptr inbounds i8, ptr %fp.251, i64 8
  %lf.255 = load i64, ptr %fp.256, align 8, !tbaa !7
  %lr.257 = insertvalue { i64, i64, i64 } %lr.254, i64 %lf.255, 1
  %fp.259 = getelementptr inbounds i8, ptr %fp.251, i64 16
  %lf.258 = load i64, ptr %fp.259, align 8, !tbaa !7
  %lf.252 = insertvalue { i64, i64, i64 } %lr.257, i64 %lf.258, 2
  %lr.260 = insertvalue { { i64, i64, i64 }, ptr } poison, { i64, i64, i64 } %lf.252, 0
  %fp.262 = getelementptr inbounds i8, ptr %fp.251, i64 24
  %lf.261 = load ptr, ptr %fp.262, align 8, !tbaa !7
  %v117 = insertvalue { { i64, i64, i64 }, ptr } %lr.260, ptr %lf.261, 1
  %t.263 = load i64, ptr %v116, align 8, !tbaa !7
  %v118 = trunc i64 %t.263 to i32
  %v120 = icmp eq i32 %v118, 1
  br i1 %v120, label %b27, label %b28
b27:
  call preserve_mostcc void @myl_core_err_trace_append_preserve_most(ptr @myl.site.2646) #1
  br label %b28
b28:
  call void @llvm.memcpy.p0.p0.i64(ptr %ret, ptr %v116, i64 8, i1 false)
  %fp.264 = getelementptr inbounds i8, ptr %v116, i64 8
  call void @llvm.memcpy.p0.p0.i64(ptr %payload, ptr %fp.264, i64 48, i1 false)
  %fp.265 = getelementptr inbounds i8, ptr %ret, i64 112
  %sf.266 = extractvalue { { i64, i64, i64 }, ptr } %v117, 0
  %sf.267 = extractvalue { i64, i64, i64 } %sf.266, 0
  store i64 %sf.267, ptr %fp.265, align 8, !tbaa !7
  %sf.268 = extractvalue { i64, i64, i64 } %sf.266, 1
  %fp.269 = getelementptr inbounds i8, ptr %fp.265, i64 8
  store i64 %sf.268, ptr %fp.269, align 8, !tbaa !7
  %sf.270 = extractvalue { i64, i64, i64 } %sf.266, 2
  %fp.271 = getelementptr inbounds i8, ptr %fp.265, i64 16
  store i64 %sf.270, ptr %fp.271, align 8, !tbaa !7
  %sf.272 = extractvalue { { i64, i64, i64 }, ptr } %v117, 1
  %fp.273 = getelementptr inbounds i8, ptr %fp.265, i64 24
  store ptr %sf.272, ptr %fp.273, align 8, !tbaa !7
  ret void
}