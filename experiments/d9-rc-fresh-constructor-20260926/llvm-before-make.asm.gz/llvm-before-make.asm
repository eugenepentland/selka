
/home/epentland/ai/canopy/mylang-worktrees/d9-rc-flat-destruction-astra/.tmp-flat/cumulative-19e/llvm-rc-n12:     file format elf64-x86-64


Disassembly of section .text:

000000000101a4a0 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531>:
 101a4a0:	55                   	push   %rbp
 101a4a1:	41 57                	push   %r15
 101a4a3:	41 56                	push   %r14
 101a4a5:	41 55                	push   %r13
 101a4a7:	41 54                	push   %r12
 101a4a9:	53                   	push   %rbx
 101a4aa:	48 81 ec 48 01 00 00 	sub    $0x148,%rsp
 101a4b1:	48 89 fb             	mov    %rdi,%rbx
 101a4b4:	48 39 67 40          	cmp    %rsp,0x40(%rdi)
 101a4b8:	0f 87 41 0b 00 00    	ja     101afff <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xb5f>
 101a4be:	49 89 f7             	mov    %rsi,%r15
 101a4c1:	48 85 f6             	test   %rsi,%rsi
 101a4c4:	0f 84 0e 0a 00 00    	je     101aed8 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xa38>
 101a4ca:	8b 83 c8 02 00 00    	mov    0x2c8(%rbx),%eax
 101a4d0:	89 44 24 0c          	mov    %eax,0xc(%rsp)
 101a4d4:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
 101a4d8:	c5 fc 11 44 24 30    	vmovups %ymm0,0x30(%rsp)
 101a4de:	c5 fc 11 84 24 b8 00 	vmovups %ymm0,0xb8(%rsp)
 101a4e5:	00 00 
 101a4e7:	c5 fc 11 84 24 d8 00 	vmovups %ymm0,0xd8(%rsp)
 101a4ee:	00 00 
 101a4f0:	c5 fc 11 84 24 f8 00 	vmovups %ymm0,0xf8(%rsp)
 101a4f7:	00 00 
 101a4f9:	48 c7 84 24 18 01 00 	movq   $0x0,0x118(%rsp)
 101a500:	00 00 00 00 00 
 101a505:	48 c7 84 24 a0 00 00 	movq   $0x1009be8,0xa0(%rsp)
 101a50c:	00 e8 9b 00 01 
 101a511:	4c 8d 64 24 50       	lea    0x50(%rsp),%r12
 101a516:	4c 89 a4 24 a8 00 00 	mov    %r12,0xa8(%rsp)
 101a51d:	00 
 101a51e:	48 8d 44 24 30       	lea    0x30(%rsp),%rax
 101a523:	48 89 84 24 b0 00 00 	mov    %rax,0xb0(%rsp)
 101a52a:	00 
 101a52b:	48 c7 84 24 c0 00 00 	movq   $0x1009be8,0xc0(%rsp)
 101a532:	00 e8 9b 00 01 
 101a537:	48 8d 44 24 70       	lea    0x70(%rsp),%rax
 101a53c:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
 101a543:	00 
 101a544:	48 8d 44 24 38       	lea    0x38(%rsp),%rax
 101a549:	48 89 84 24 d0 00 00 	mov    %rax,0xd0(%rsp)
 101a550:	00 
 101a551:	48 c7 84 24 e0 00 00 	movq   $0x1009be8,0xe0(%rsp)
 101a558:	00 e8 9b 00 01 
 101a55d:	4c 8d 74 24 10       	lea    0x10(%rsp),%r14
 101a562:	4c 89 b4 24 e8 00 00 	mov    %r14,0xe8(%rsp)
 101a569:	00 
 101a56a:	48 8d 44 24 40       	lea    0x40(%rsp),%rax
 101a56f:	48 89 84 24 f0 00 00 	mov    %rax,0xf0(%rsp)
 101a576:	00 
 101a577:	48 c7 84 24 00 01 00 	movq   $0x1009be8,0x100(%rsp)
 101a57e:	00 e8 9b 00 01 
 101a583:	48 8d ac 24 40 01 00 	lea    0x140(%rsp),%rbp
 101a58a:	00 
 101a58b:	48 89 ac 24 08 01 00 	mov    %rbp,0x108(%rsp)
 101a592:	00 
 101a593:	4c 8d 6c 24 48       	lea    0x48(%rsp),%r13
 101a598:	4c 89 ac 24 10 01 00 	mov    %r13,0x110(%rsp)
 101a59f:	00 
 101a5a0:	48 85 db             	test   %rbx,%rbx
 101a5a3:	0f 84 41 0a 00 00    	je     101afea <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xb4a>
 101a5a9:	48 8b 83 60 18 00 00 	mov    0x1860(%rbx),%rax
 101a5b0:	48 85 c0             	test   %rax,%rax
 101a5b3:	0f 84 31 0a 00 00    	je     101afea <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xb4a>
 101a5b9:	48 8b 8b 80 3d 00 00 	mov    0x3d80(%rbx),%rcx
 101a5c0:	48 8b 40 70          	mov    0x70(%rax),%rax
 101a5c4:	48 89 8c 24 80 00 00 	mov    %rcx,0x80(%rsp)
 101a5cb:	00 
 101a5cc:	48 8d 8c 24 a0 00 00 	lea    0xa0(%rsp),%rcx
 101a5d3:	00 
 101a5d4:	48 89 8c 24 88 00 00 	mov    %rcx,0x88(%rsp)
 101a5db:	00 
 101a5dc:	48 c7 84 24 90 00 00 	movq   $0x4,0x90(%rsp)
 101a5e3:	00 04 00 00 00 
 101a5e8:	48 89 84 24 98 00 00 	mov    %rax,0x98(%rsp)
 101a5ef:	00 
 101a5f0:	48 8d 84 24 80 00 00 	lea    0x80(%rsp),%rax
 101a5f7:	00 
 101a5f8:	48 89 83 80 3d 00 00 	mov    %rax,0x3d80(%rbx)
 101a5ff:	4c 89 7c 24 28       	mov    %r15,0x28(%rsp)
 101a604:	48 c7 44 24 68 01 00 	movq   $0x1,0x68(%rsp)
 101a60b:	00 00 
 101a60d:	4c 89 f8             	mov    %r15,%rax
 101a610:	48 f7 d8             	neg    %rax
 101a613:	0f 80 f6 09 00 00    	jo     101b00f <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xb6f>
 101a619:	49 ff cf             	dec    %r15
 101a61c:	4c 89 7c 24 28       	mov    %r15,0x28(%rsp)
 101a621:	48 89 df             	mov    %rbx,%rdi
 101a624:	4c 89 fe             	mov    %r15,%rsi
 101a627:	c5 f8 77             	vzeroupper
 101a62a:	e8 71 fe ff ff       	call   101a4a0 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531>
 101a62f:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
 101a634:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
 101a639:	48 c7 84 24 e0 00 00 	movq   $0x100a308,0xe0(%rsp)
 101a640:	00 08 a3 00 01 
 101a645:	c7 84 24 f8 00 00 00 	movl   $0x2,0xf8(%rsp)
 101a64c:	02 00 00 00 
 101a650:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
 101a655:	48 89 54 24 58       	mov    %rdx,0x58(%rsp)
 101a65a:	48 c7 84 24 a0 00 00 	movq   $0x100a308,0xa0(%rsp)
 101a661:	00 08 a3 00 01 
 101a666:	c7 84 24 b8 00 00 00 	movl   $0x2,0xb8(%rsp)
 101a66d:	02 00 00 00 
 101a671:	c7 44 24 40 00 00 00 	movl   $0x0,0x40(%rsp)
 101a678:	00 
 101a679:	c7 44 24 30 01 00 00 	movl   $0x1,0x30(%rsp)
 101a680:	00 
 101a681:	4c 89 64 24 28       	mov    %r12,0x28(%rsp)
 101a686:	48 83 bb 60 18 00 00 	cmpq   $0x0,0x1860(%rbx)
 101a68d:	00 
 101a68e:	0f 84 63 09 00 00    	je     101aff7 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xb57>
 101a694:	48 8d bb 58 02 00 00 	lea    0x258(%rbx),%rdi
 101a69b:	8b 8b c8 02 00 00    	mov    0x2c8(%rbx),%ecx
 101a6a1:	be b8 98 00 01       	mov    $0x10098b8,%esi
 101a6a6:	ba 01 00 00 00       	mov    $0x1,%edx
 101a6ab:	e8 00 f9 00 00       	call   1029fb0 <myl_rc_storage_alloc>
 101a6b0:	48 85 c0             	test   %rax,%rax
 101a6b3:	0f 84 3e 09 00 00    	je     101aff7 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xb57>
 101a6b9:	49 89 c4             	mov    %rax,%r12
 101a6bc:	48 89 84 24 40 01 00 	mov    %rax,0x140(%rsp)
 101a6c3:	00 
 101a6c4:	48 c7 84 24 00 01 00 	movq   $0x1009928,0x100(%rsp)
 101a6cb:	00 28 99 00 01 
 101a6d0:	48 89 ac 24 08 01 00 	mov    %rbp,0x108(%rsp)
 101a6d7:	00 
 101a6d8:	4c 89 ac 24 10 01 00 	mov    %r13,0x110(%rsp)
 101a6df:	00 
 101a6e0:	c7 84 24 18 01 00 00 	movl   $0x4,0x118(%rsp)
 101a6e7:	04 00 00 00 
 101a6eb:	c7 44 24 48 01 00 00 	movl   $0x1,0x48(%rsp)
 101a6f2:	00 
 101a6f3:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
 101a6f8:	48 8b 01             	mov    (%rcx),%rax
 101a6fb:	48 85 c0             	test   %rax,%rax
 101a6fe:	74 10                	je     101a710 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x270>
 101a700:	48 ba 01 00 00 00 00 	movabs $0x5000000000000001,%rdx
 101a707:	00 00 50 
 101a70a:	48 85 50 f0          	test   %rdx,-0x10(%rax)
 101a70e:	75 19                	jne    101a729 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x289>
 101a710:	48 8b 41 08          	mov    0x8(%rcx),%rax
 101a714:	48 85 c0             	test   %rax,%rax
 101a717:	74 34                	je     101a74d <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x2ad>
 101a719:	48 ba 01 00 00 00 00 	movabs $0x5000000000000001,%rdx
 101a720:	00 00 50 
 101a723:	48 85 50 f0          	test   %rdx,-0x10(%rax)
 101a727:	74 24                	je     101a74d <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x2ad>
 101a729:	48 8d 54 24 10       	lea    0x10(%rsp),%rdx
 101a72e:	be 08 a3 00 01       	mov    $0x100a308,%esi
 101a733:	48 8d bb 58 02 00 00 	lea    0x258(%rbx),%rdi
 101a73a:	44 8b 44 24 0c       	mov    0xc(%rsp),%r8d
 101a73f:	e8 5c 0a 01 00       	call   102b1a0 <myl_rc_native_take>
 101a744:	85 c0                	test   %eax,%eax
 101a746:	75 17                	jne    101a75f <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x2bf>
 101a748:	e9 62 03 00 00       	jmp    101aaaf <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x60f>
 101a74d:	c5 f8 10 01          	vmovups (%rcx),%xmm0
 101a751:	c5 f8 29 44 24 10    	vmovaps %xmm0,0x10(%rsp)
 101a757:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
 101a75b:	c5 f8 11 01          	vmovups %xmm0,(%rcx)
 101a75f:	48 c7 84 24 e0 00 00 	movq   $0x100a308,0xe0(%rsp)
 101a766:	00 08 a3 00 01 
 101a76b:	c7 84 24 f8 00 00 00 	movl   $0x2,0xf8(%rsp)
 101a772:	02 00 00 00 
 101a776:	c5 f8 28 44 24 10    	vmovaps 0x10(%rsp),%xmm0
 101a77c:	c4 c1 78 11 04 24    	vmovups %xmm0,(%r12)
 101a782:	c7 44 24 40 00 00 00 	movl   $0x0,0x40(%rsp)
 101a789:	00 
 101a78a:	4c 89 64 24 50       	mov    %r12,0x50(%rsp)
 101a78f:	48 c7 84 24 a0 00 00 	movq   $0x1009928,0xa0(%rsp)
 101a796:	00 28 99 00 01 
 101a79b:	c7 84 24 b8 00 00 00 	movl   $0x2,0xb8(%rsp)
 101a7a2:	02 00 00 00 
 101a7a6:	c7 44 24 30 01 00 00 	movl   $0x1,0x30(%rsp)
 101a7ad:	00 
 101a7ae:	4c 89 64 24 28       	mov    %r12,0x28(%rsp)
 101a7b3:	48 c7 84 24 38 01 00 	movq   $0x0,0x138(%rsp)
 101a7ba:	00 00 00 00 00 
 101a7bf:	48 c7 84 24 00 01 00 	movq   $0x1009fd8,0x100(%rsp)
 101a7c6:	00 d8 9f 00 01 
 101a7cb:	c7 84 24 18 01 00 00 	movl   $0x2,0x118(%rsp)
 101a7d2:	02 00 00 00 
 101a7d6:	48 8d 84 24 38 01 00 	lea    0x138(%rsp),%rax
 101a7dd:	00 
 101a7de:	48 89 84 24 08 01 00 	mov    %rax,0x108(%rsp)
 101a7e5:	00 
 101a7e6:	4c 89 ac 24 10 01 00 	mov    %r13,0x110(%rsp)
 101a7ed:	00 
 101a7ee:	c7 44 24 48 01 00 00 	movl   $0x1,0x48(%rsp)
 101a7f5:	00 
 101a7f6:	48 b8 01 00 00 00 00 	movabs $0x5000000000000001,%rax
 101a7fd:	00 00 50 
 101a800:	49 85 44 24 f0       	test   %rax,-0x10(%r12)
 101a805:	74 2f                	je     101a836 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x396>
 101a807:	48 8d 54 24 10       	lea    0x10(%rsp),%rdx
 101a80c:	48 8d 4c 24 28       	lea    0x28(%rsp),%rcx
 101a811:	be 28 99 00 01       	mov    $0x1009928,%esi
 101a816:	48 8d bb 58 02 00 00 	lea    0x258(%rbx),%rdi
 101a81d:	44 8b 44 24 0c       	mov    0xc(%rsp),%r8d
 101a822:	e8 79 09 01 00       	call   102b1a0 <myl_rc_native_take>
 101a827:	85 c0                	test   %eax,%eax
 101a829:	0f 84 80 02 00 00    	je     101aaaf <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x60f>
 101a82f:	4c 8b 64 24 10       	mov    0x10(%rsp),%r12
 101a834:	eb 05                	jmp    101a83b <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x39b>
 101a836:	4c 89 64 24 10       	mov    %r12,0x10(%rsp)
 101a83b:	48 c7 84 24 e0 00 00 	movq   $0x1009928,0xe0(%rsp)
 101a842:	00 28 99 00 01 
 101a847:	c7 84 24 f8 00 00 00 	movl   $0x2,0xf8(%rsp)
 101a84e:	02 00 00 00 
 101a852:	4c 89 a4 24 38 01 00 	mov    %r12,0x138(%rsp)
 101a859:	00 
 101a85a:	c7 44 24 40 00 00 00 	movl   $0x0,0x40(%rsp)
 101a861:	00 
 101a862:	4c 89 64 24 50       	mov    %r12,0x50(%rsp)
 101a867:	48 c7 84 24 a0 00 00 	movq   $0x1009fd8,0xa0(%rsp)
 101a86e:	00 d8 9f 00 01 
 101a873:	c7 84 24 b8 00 00 00 	movl   $0x2,0xb8(%rsp)
 101a87a:	02 00 00 00 
 101a87e:	c7 44 24 30 01 00 00 	movl   $0x1,0x30(%rsp)
 101a885:	00 
 101a886:	48 8d 44 24 50       	lea    0x50(%rsp),%rax
 101a88b:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
 101a890:	c7 44 24 48 00 00 00 	movl   $0x0,0x48(%rsp)
 101a897:	00 
 101a898:	48 89 df             	mov    %rbx,%rdi
 101a89b:	4c 89 fe             	mov    %r15,%rsi
 101a89e:	e8 fd fb ff ff       	call   101a4a0 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531>
 101a8a3:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
 101a8a8:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
 101a8ad:	48 c7 84 24 e0 00 00 	movq   $0x100a308,0xe0(%rsp)
 101a8b4:	00 08 a3 00 01 
 101a8b9:	c7 84 24 f8 00 00 00 	movl   $0x2,0xf8(%rsp)
 101a8c0:	02 00 00 00 
 101a8c4:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
 101a8c9:	48 89 54 24 78       	mov    %rdx,0x78(%rsp)
 101a8ce:	48 c7 84 24 c0 00 00 	movq   $0x100a308,0xc0(%rsp)
 101a8d5:	00 08 a3 00 01 
 101a8da:	c7 84 24 d8 00 00 00 	movl   $0x2,0xd8(%rsp)
 101a8e1:	02 00 00 00 
 101a8e5:	c7 44 24 40 00 00 00 	movl   $0x0,0x40(%rsp)
 101a8ec:	00 
 101a8ed:	c7 44 24 38 01 00 00 	movl   $0x1,0x38(%rsp)
 101a8f4:	00 
 101a8f5:	4c 8d 64 24 70       	lea    0x70(%rsp),%r12
 101a8fa:	4c 89 64 24 68       	mov    %r12,0x68(%rsp)
 101a8ff:	48 83 bb 60 18 00 00 	cmpq   $0x0,0x1860(%rbx)
 101a906:	00 
 101a907:	0f 84 fa 06 00 00    	je     101b007 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xb67>
 101a90d:	8b 8b c8 02 00 00    	mov    0x2c8(%rbx),%ecx
 101a913:	be b8 98 00 01       	mov    $0x10098b8,%esi
 101a918:	ba 01 00 00 00       	mov    $0x1,%edx
 101a91d:	48 8d bb 58 02 00 00 	lea    0x258(%rbx),%rdi
 101a924:	e8 87 f6 00 00       	call   1029fb0 <myl_rc_storage_alloc>
 101a929:	48 85 c0             	test   %rax,%rax
 101a92c:	0f 84 d5 06 00 00    	je     101b007 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xb67>
 101a932:	49 89 c7             	mov    %rax,%r15
 101a935:	48 89 84 24 40 01 00 	mov    %rax,0x140(%rsp)
 101a93c:	00 
 101a93d:	48 c7 84 24 00 01 00 	movq   $0x1009928,0x100(%rsp)
 101a944:	00 28 99 00 01 
 101a949:	48 89 ac 24 08 01 00 	mov    %rbp,0x108(%rsp)
 101a950:	00 
 101a951:	4c 89 ac 24 10 01 00 	mov    %r13,0x110(%rsp)
 101a958:	00 
 101a959:	c7 84 24 18 01 00 00 	movl   $0x4,0x118(%rsp)
 101a960:	04 00 00 00 
 101a964:	c7 44 24 48 01 00 00 	movl   $0x1,0x48(%rsp)
 101a96b:	00 
 101a96c:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
 101a971:	48 85 c0             	test   %rax,%rax
 101a974:	74 10                	je     101a986 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x4e6>
 101a976:	48 b9 01 00 00 00 00 	movabs $0x5000000000000001,%rcx
 101a97d:	00 00 50 
 101a980:	48 85 48 f0          	test   %rcx,-0x10(%rax)
 101a984:	75 1a                	jne    101a9a0 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x500>
 101a986:	48 8b 44 24 78       	mov    0x78(%rsp),%rax
 101a98b:	48 85 c0             	test   %rax,%rax
 101a98e:	74 39                	je     101a9c9 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x529>
 101a990:	48 b9 01 00 00 00 00 	movabs $0x5000000000000001,%rcx
 101a997:	00 00 50 
 101a99a:	48 85 48 f0          	test   %rcx,-0x10(%rax)
 101a99e:	74 29                	je     101a9c9 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x529>
 101a9a0:	48 8d 54 24 10       	lea    0x10(%rsp),%rdx
 101a9a5:	48 8d 4c 24 70       	lea    0x70(%rsp),%rcx
 101a9aa:	be 08 a3 00 01       	mov    $0x100a308,%esi
 101a9af:	48 8d bb 58 02 00 00 	lea    0x258(%rbx),%rdi
 101a9b6:	44 8b 44 24 0c       	mov    0xc(%rsp),%r8d
 101a9bb:	e8 e0 07 01 00       	call   102b1a0 <myl_rc_native_take>
 101a9c0:	85 c0                	test   %eax,%eax
 101a9c2:	75 1a                	jne    101a9de <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x53e>
 101a9c4:	e9 e6 00 00 00       	jmp    101aaaf <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x60f>
 101a9c9:	c5 f8 10 44 24 70    	vmovups 0x70(%rsp),%xmm0
 101a9cf:	c5 f8 29 44 24 10    	vmovaps %xmm0,0x10(%rsp)
 101a9d5:	48 c7 44 24 78 00 00 	movq   $0x0,0x78(%rsp)
 101a9dc:	00 00 
 101a9de:	48 c7 84 24 e0 00 00 	movq   $0x100a308,0xe0(%rsp)
 101a9e5:	00 08 a3 00 01 
 101a9ea:	c7 84 24 f8 00 00 00 	movl   $0x2,0xf8(%rsp)
 101a9f1:	02 00 00 00 
 101a9f5:	c5 f8 28 44 24 10    	vmovaps 0x10(%rsp),%xmm0
 101a9fb:	c4 c1 78 11 07       	vmovups %xmm0,(%r15)
 101aa00:	c7 44 24 40 00 00 00 	movl   $0x0,0x40(%rsp)
 101aa07:	00 
 101aa08:	4c 89 7c 24 70       	mov    %r15,0x70(%rsp)
 101aa0d:	48 c7 84 24 c0 00 00 	movq   $0x1009928,0xc0(%rsp)
 101aa14:	00 28 99 00 01 
 101aa19:	c7 84 24 d8 00 00 00 	movl   $0x2,0xd8(%rsp)
 101aa20:	02 00 00 00 
 101aa24:	c7 44 24 38 01 00 00 	movl   $0x1,0x38(%rsp)
 101aa2b:	00 
 101aa2c:	4c 89 7c 24 68       	mov    %r15,0x68(%rsp)
 101aa31:	48 c7 84 24 30 01 00 	movq   $0x0,0x130(%rsp)
 101aa38:	00 00 00 00 00 
 101aa3d:	48 c7 84 24 00 01 00 	movq   $0x1009fd8,0x100(%rsp)
 101aa44:	00 d8 9f 00 01 
 101aa49:	c7 84 24 18 01 00 00 	movl   $0x2,0x118(%rsp)
 101aa50:	02 00 00 00 
 101aa54:	48 8d 84 24 30 01 00 	lea    0x130(%rsp),%rax
 101aa5b:	00 
 101aa5c:	48 89 84 24 08 01 00 	mov    %rax,0x108(%rsp)
 101aa63:	00 
 101aa64:	4c 89 ac 24 10 01 00 	mov    %r13,0x110(%rsp)
 101aa6b:	00 
 101aa6c:	c7 44 24 48 01 00 00 	movl   $0x1,0x48(%rsp)
 101aa73:	00 
 101aa74:	48 b8 01 00 00 00 00 	movabs $0x5000000000000001,%rax
 101aa7b:	00 00 50 
 101aa7e:	49 85 47 f0          	test   %rax,-0x10(%r15)
 101aa82:	74 5a                	je     101aade <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x63e>
 101aa84:	48 8d 54 24 10       	lea    0x10(%rsp),%rdx
 101aa89:	48 8d 4c 24 68       	lea    0x68(%rsp),%rcx
 101aa8e:	be 28 99 00 01       	mov    $0x1009928,%esi
 101aa93:	48 8d bb 58 02 00 00 	lea    0x258(%rbx),%rdi
 101aa9a:	44 8b 44 24 0c       	mov    0xc(%rsp),%r8d
 101aa9f:	e8 fc 06 01 00       	call   102b1a0 <myl_rc_native_take>
 101aaa4:	85 c0                	test   %eax,%eax
 101aaa6:	74 07                	je     101aaaf <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x60f>
 101aaa8:	4c 8b 7c 24 10       	mov    0x10(%rsp),%r15
 101aaad:	eb 34                	jmp    101aae3 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x643>
 101aaaf:	48 8b 8b 60 18 00 00 	mov    0x1860(%rbx),%rcx
 101aab6:	48 85 c9             	test   %rcx,%rcx
 101aab9:	0f 84 2b 05 00 00    	je     101afea <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xb4a>
 101aabf:	8b 41 78             	mov    0x78(%rcx),%eax
 101aac2:	c7 41 78 00 00 00 00 	movl   $0x0,0x78(%rcx)
 101aac9:	85 c0                	test   %eax,%eax
 101aacb:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
 101aad2:	00 
 101aad3:	0f 85 0e 03 00 00    	jne    101ade7 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x947>
 101aad9:	e9 3e 03 00 00       	jmp    101ae1c <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x97c>
 101aade:	4c 89 7c 24 10       	mov    %r15,0x10(%rsp)
 101aae3:	48 c7 84 24 e0 00 00 	movq   $0x1009928,0xe0(%rsp)
 101aaea:	00 28 99 00 01 
 101aaef:	c7 84 24 f8 00 00 00 	movl   $0x2,0xf8(%rsp)
 101aaf6:	02 00 00 00 
 101aafa:	4c 89 bc 24 30 01 00 	mov    %r15,0x130(%rsp)
 101ab01:	00 
 101ab02:	c7 44 24 40 00 00 00 	movl   $0x0,0x40(%rsp)
 101ab09:	00 
 101ab0a:	4c 89 7c 24 70       	mov    %r15,0x70(%rsp)
 101ab0f:	48 c7 84 24 c0 00 00 	movq   $0x1009fd8,0xc0(%rsp)
 101ab16:	00 d8 9f 00 01 
 101ab1b:	c7 84 24 d8 00 00 00 	movl   $0x2,0xd8(%rsp)
 101ab22:	02 00 00 00 
 101ab26:	c7 44 24 38 01 00 00 	movl   $0x1,0x38(%rsp)
 101ab2d:	00 
 101ab2e:	4c 89 64 24 68       	mov    %r12,0x68(%rsp)
 101ab33:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
 101ab37:	c5 f8 29 84 24 20 01 	vmovaps %xmm0,0x120(%rsp)
 101ab3e:	00 00 
 101ab40:	48 c7 84 24 00 01 00 	movq   $0x100a308,0x100(%rsp)
 101ab47:	00 08 a3 00 01 
 101ab4c:	c7 84 24 18 01 00 00 	movl   $0x2,0x118(%rsp)
 101ab53:	02 00 00 00 
 101ab57:	48 8d 84 24 20 01 00 	lea    0x120(%rsp),%rax
 101ab5e:	00 
 101ab5f:	48 89 84 24 08 01 00 	mov    %rax,0x108(%rsp)
 101ab66:	00 
 101ab67:	4c 89 ac 24 10 01 00 	mov    %r13,0x110(%rsp)
 101ab6e:	00 
 101ab6f:	c7 44 24 48 01 00 00 	movl   $0x1,0x48(%rsp)
 101ab76:	00 
 101ab77:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
 101ab7c:	f6 84 24 b8 00 00 00 	testb  $0x18,0xb8(%rsp)
 101ab83:	18 
 101ab84:	75 70                	jne    101abf6 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x756>
 101ab86:	8b 44 24 30          	mov    0x30(%rsp),%eax
 101ab8a:	83 e0 01             	and    $0x1,%eax
 101ab8d:	74 67                	je     101abf6 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x756>
 101ab8f:	48 89 c8             	mov    %rcx,%rax
 101ab92:	4c 29 f0             	sub    %r14,%rax
 101ab95:	49 29 ce             	sub    %rcx,%r14
 101ab98:	48 83 f8 08          	cmp    $0x8,%rax
 101ab9c:	0f 92 c0             	setb   %al
 101ab9f:	49 83 fe 08          	cmp    $0x8,%r14
 101aba3:	0f 92 c2             	setb   %dl
 101aba6:	08 c2                	or     %al,%dl
 101aba8:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
 101abaf:	00 
 101abb0:	75 20                	jne    101abd2 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x732>
 101abb2:	48 8b 01             	mov    (%rcx),%rax
 101abb5:	48 85 c0             	test   %rax,%rax
 101abb8:	0f 84 9b 00 00 00    	je     101ac59 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x7b9>
 101abbe:	48 ba 01 00 00 00 00 	movabs $0x5000000000000001,%rdx
 101abc5:	00 00 50 
 101abc8:	48 85 50 f0          	test   %rdx,-0x10(%rax)
 101abcc:	0f 84 87 00 00 00    	je     101ac59 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x7b9>
 101abd2:	48 8d 54 24 10       	lea    0x10(%rsp),%rdx
 101abd7:	be d8 9f 00 01       	mov    $0x1009fd8,%esi
 101abdc:	48 8d bb 58 02 00 00 	lea    0x258(%rbx),%rdi
 101abe3:	44 8b 44 24 0c       	mov    0xc(%rsp),%r8d
 101abe8:	e8 b3 05 01 00       	call   102b1a0 <myl_rc_native_take>
 101abed:	85 c0                	test   %eax,%eax
 101abef:	75 74                	jne    101ac65 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x7c5>
 101abf1:	e9 d3 01 00 00       	jmp    101adc9 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x929>
 101abf6:	48 8d 54 24 10       	lea    0x10(%rsp),%rdx
 101abfb:	be d8 9f 00 01       	mov    $0x1009fd8,%esi
 101ac00:	48 8d bb 58 02 00 00 	lea    0x258(%rbx),%rdi
 101ac07:	44 8b 44 24 0c       	mov    0xc(%rsp),%r8d
 101ac0c:	e8 0f 0b 01 00       	call   102b720 <myl_rc_native_retain>
 101ac11:	85 c0                	test   %eax,%eax
 101ac13:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
 101ac1a:	00 
 101ac1b:	0f 84 a8 01 00 00    	je     101adc9 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x929>
 101ac21:	48 c7 84 24 e0 00 00 	movq   $0x1009fd8,0xe0(%rsp)
 101ac28:	00 d8 9f 00 01 
 101ac2d:	c7 84 24 f8 00 00 00 	movl   $0x2,0xf8(%rsp)
 101ac34:	02 00 00 00 
 101ac38:	c7 44 24 40 01 00 00 	movl   $0x1,0x40(%rsp)
 101ac3f:	00 
 101ac40:	83 7c 24 30 00       	cmpl   $0x0,0x30(%rsp)
 101ac45:	74 3d                	je     101ac84 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x7e4>
 101ac47:	48 8d b4 24 a0 00 00 	lea    0xa0(%rsp),%rsi
 101ac4e:	00 
 101ac4f:	48 89 df             	mov    %rbx,%rdi
 101ac52:	e8 29 28 00 00       	call   101d480 <myl_qbe_rc_slot_drop>
 101ac57:	eb 2b                	jmp    101ac84 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x7e4>
 101ac59:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
 101ac5e:	48 c7 01 00 00 00 00 	movq   $0x0,(%rcx)
 101ac65:	c7 44 24 30 00 00 00 	movl   $0x0,0x30(%rsp)
 101ac6c:	00 
 101ac6d:	48 c7 84 24 e0 00 00 	movq   $0x1009fd8,0xe0(%rsp)
 101ac74:	00 d8 9f 00 01 
 101ac79:	c7 84 24 f8 00 00 00 	movl   $0x2,0xf8(%rsp)
 101ac80:	02 00 00 00 
 101ac84:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
 101ac89:	48 89 84 24 20 01 00 	mov    %rax,0x120(%rsp)
 101ac90:	00 
 101ac91:	c7 44 24 40 00 00 00 	movl   $0x0,0x40(%rsp)
 101ac98:	00 
 101ac99:	48 8b 4c 24 68       	mov    0x68(%rsp),%rcx
 101ac9e:	48 8b 01             	mov    (%rcx),%rax
 101aca1:	48 85 c0             	test   %rax,%rax
 101aca4:	74 34                	je     101acda <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x83a>
 101aca6:	48 ba 01 00 00 00 00 	movabs $0x5000000000000001,%rdx
 101acad:	00 00 50 
 101acb0:	48 85 50 f0          	test   %rdx,-0x10(%rax)
 101acb4:	74 24                	je     101acda <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x83a>
 101acb6:	48 8d 54 24 10       	lea    0x10(%rsp),%rdx
 101acbb:	be d8 9f 00 01       	mov    $0x1009fd8,%esi
 101acc0:	48 8d bb 58 02 00 00 	lea    0x258(%rbx),%rdi
 101acc7:	44 8b 44 24 0c       	mov    0xc(%rsp),%r8d
 101accc:	e8 cf 04 01 00       	call   102b1a0 <myl_rc_native_take>
 101acd1:	85 c0                	test   %eax,%eax
 101acd3:	75 11                	jne    101ace6 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x846>
 101acd5:	e9 ef 00 00 00       	jmp    101adc9 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x929>
 101acda:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
 101acdf:	48 c7 01 00 00 00 00 	movq   $0x0,(%rcx)
 101ace6:	c7 44 24 38 00 00 00 	movl   $0x0,0x38(%rsp)
 101aced:	00 
 101acee:	48 c7 84 24 e0 00 00 	movq   $0x1009fd8,0xe0(%rsp)
 101acf5:	00 d8 9f 00 01 
 101acfa:	c7 84 24 f8 00 00 00 	movl   $0x2,0xf8(%rsp)
 101ad01:	02 00 00 00 
 101ad05:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
 101ad0a:	48 89 84 24 28 01 00 	mov    %rax,0x128(%rsp)
 101ad11:	00 
 101ad12:	c7 44 24 40 00 00 00 	movl   $0x0,0x40(%rsp)
 101ad19:	00 
 101ad1a:	48 8b 84 24 20 01 00 	mov    0x120(%rsp),%rax
 101ad21:	00 
 101ad22:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
 101ad27:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
 101ad2e:	00 
 101ad2f:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
 101ad34:	48 c7 84 24 a0 00 00 	movq   $0x100a308,0xa0(%rsp)
 101ad3b:	00 08 a3 00 01 
 101ad40:	c7 84 24 b8 00 00 00 	movl   $0x2,0xb8(%rsp)
 101ad47:	02 00 00 00 
 101ad4b:	c7 44 24 30 01 00 00 	movl   $0x1,0x30(%rsp)
 101ad52:	00 
 101ad53:	48 8d 44 24 50       	lea    0x50(%rsp),%rax
 101ad58:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
 101ad5d:	c7 44 24 48 00 00 00 	movl   $0x0,0x48(%rsp)
 101ad64:	00 
 101ad65:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
 101ad6a:	48 85 c0             	test   %rax,%rax
 101ad6d:	74 10                	je     101ad7f <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x8df>
 101ad6f:	48 b9 01 00 00 00 00 	movabs $0x5000000000000001,%rcx
 101ad76:	00 00 50 
 101ad79:	48 85 48 f0          	test   %rcx,-0x10(%rax)
 101ad7d:	75 22                	jne    101ada1 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x901>
 101ad7f:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
 101ad84:	48 85 c0             	test   %rax,%rax
 101ad87:	0f 84 61 01 00 00    	je     101aeee <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xa4e>
 101ad8d:	48 b9 01 00 00 00 00 	movabs $0x5000000000000001,%rcx
 101ad94:	00 00 50 
 101ad97:	48 85 48 f0          	test   %rcx,-0x10(%rax)
 101ad9b:	0f 84 4d 01 00 00    	je     101aeee <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xa4e>
 101ada1:	48 8d 54 24 10       	lea    0x10(%rsp),%rdx
 101ada6:	48 8d 4c 24 50       	lea    0x50(%rsp),%rcx
 101adab:	be 08 a3 00 01       	mov    $0x100a308,%esi
 101adb0:	48 8d bb 58 02 00 00 	lea    0x258(%rbx),%rdi
 101adb7:	44 8b 44 24 0c       	mov    0xc(%rsp),%r8d
 101adbc:	e8 df 03 01 00       	call   102b1a0 <myl_rc_native_take>
 101adc1:	85 c0                	test   %eax,%eax
 101adc3:	0f 85 3e 01 00 00    	jne    101af07 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xa67>
 101adc9:	48 8b 8b 60 18 00 00 	mov    0x1860(%rbx),%rcx
 101add0:	48 85 c9             	test   %rcx,%rcx
 101add3:	0f 84 11 02 00 00    	je     101afea <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xb4a>
 101add9:	8b 41 78             	mov    0x78(%rcx),%eax
 101addc:	c7 41 78 00 00 00 00 	movl   $0x0,0x78(%rcx)
 101ade3:	85 c0                	test   %eax,%eax
 101ade5:	74 35                	je     101ae1c <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x97c>
 101ade7:	83 f8 01             	cmp    $0x1,%eax
 101adea:	75 15                	jne    101ae01 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x961>
 101adec:	be 60 74 00 01       	mov    $0x1007460,%esi
 101adf1:	83 bb c4 02 00 00 00 	cmpl   $0x0,0x2c4(%rbx)
 101adf8:	75 1a                	jne    101ae14 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x974>
 101adfa:	b8 01 00 00 00       	mov    $0x1,%eax
 101adff:	eb 09                	jmp    101ae0a <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x96a>
 101ae01:	83 f8 04             	cmp    $0x4,%eax
 101ae04:	0f 83 e8 01 00 00    	jae    101aff2 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xb52>
 101ae0a:	89 c0                	mov    %eax,%eax
 101ae0c:	48 8b 34 c5 70 d4 00 	mov    0x100d470(,%rax,8),%rsi
 101ae13:	01 
 101ae14:	48 89 df             	mov    %rbx,%rdi
 101ae17:	e8 f4 31 00 00       	call   101e010 <fail>
 101ae1c:	4c 39 a3 80 3d 00 00 	cmp    %r12,0x3d80(%rbx)
 101ae23:	0f 85 c1 01 00 00    	jne    101afea <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xb4a>
 101ae29:	48 8b b4 24 98 00 00 	mov    0x98(%rsp),%rsi
 101ae30:	00 
 101ae31:	48 8d bb 58 02 00 00 	lea    0x258(%rbx),%rdi
 101ae38:	e8 d3 ce 00 00       	call   1027d10 <myl_rc_scope_unwind>
 101ae3d:	4c 8b b4 24 90 00 00 	mov    0x90(%rsp),%r14
 101ae44:	00 
 101ae45:	4d 85 f6             	test   %r14,%r14
 101ae48:	74 43                	je     101ae8d <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x9ed>
 101ae4a:	4d 89 f7             	mov    %r14,%r15
 101ae4d:	49 c1 e7 05          	shl    $0x5,%r15
 101ae51:	49 83 c7 e0          	add    $0xffffffffffffffe0,%r15
 101ae55:	eb 1d                	jmp    101ae74 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x9d4>
 101ae57:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
 101ae5e:	00 00 
 101ae60:	4c 01 fe             	add    %r15,%rsi
 101ae63:	48 89 df             	mov    %rbx,%rdi
 101ae66:	e8 15 26 00 00       	call   101d480 <myl_qbe_rc_slot_drop>
 101ae6b:	49 83 c7 e0          	add    $0xffffffffffffffe0,%r15
 101ae6f:	49 ff ce             	dec    %r14
 101ae72:	74 19                	je     101ae8d <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x9ed>
 101ae74:	48 8b b4 24 88 00 00 	mov    0x88(%rsp),%rsi
 101ae7b:	00 
 101ae7c:	4a 8b 44 3e 10       	mov    0x10(%rsi,%r15,1),%rax
 101ae81:	48 85 c0             	test   %rax,%rax
 101ae84:	74 da                	je     101ae60 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x9c0>
 101ae86:	83 38 00             	cmpl   $0x0,(%rax)
 101ae89:	75 d5                	jne    101ae60 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x9c0>
 101ae8b:	eb de                	jmp    101ae6b <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x9cb>
 101ae8d:	4c 39 a3 80 3d 00 00 	cmp    %r12,0x3d80(%rbx)
 101ae94:	0f 85 50 01 00 00    	jne    101afea <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xb4a>
 101ae9a:	48 8b 83 60 18 00 00 	mov    0x1860(%rbx),%rax
 101aea1:	48 85 c0             	test   %rax,%rax
 101aea4:	74 13                	je     101aeb9 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xa19>
 101aea6:	48 8b 40 70          	mov    0x70(%rax),%rax
 101aeaa:	48 3b 84 24 98 00 00 	cmp    0x98(%rsp),%rax
 101aeb1:	00 
 101aeb2:	74 15                	je     101aec9 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xa29>
 101aeb4:	e9 31 01 00 00       	jmp    101afea <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xb4a>
 101aeb9:	31 c0                	xor    %eax,%eax
 101aebb:	48 3b 84 24 98 00 00 	cmp    0x98(%rsp),%rax
 101aec2:	00 
 101aec3:	0f 85 21 01 00 00    	jne    101afea <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xb4a>
 101aec9:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
 101aed0:	00 
 101aed1:	48 89 83 80 3d 00 00 	mov    %rax,0x3d80(%rbx)
 101aed8:	31 c0                	xor    %eax,%eax
 101aeda:	31 d2                	xor    %edx,%edx
 101aedc:	48 81 c4 48 01 00 00 	add    $0x148,%rsp
 101aee3:	5b                   	pop    %rbx
 101aee4:	41 5c                	pop    %r12
 101aee6:	41 5d                	pop    %r13
 101aee8:	41 5e                	pop    %r14
 101aeea:	41 5f                	pop    %r15
 101aeec:	5d                   	pop    %rbp
 101aeed:	c3                   	ret
 101aeee:	c5 f8 28 84 24 20 01 	vmovaps 0x120(%rsp),%xmm0
 101aef5:	00 00 
 101aef7:	c5 f8 29 44 24 10    	vmovaps %xmm0,0x10(%rsp)
 101aefd:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
 101af01:	c5 f8 29 44 24 50    	vmovaps %xmm0,0x50(%rsp)
 101af07:	c7 44 24 30 00 00 00 	movl   $0x0,0x30(%rsp)
 101af0e:	00 
 101af0f:	48 c7 84 24 e0 00 00 	movq   $0x100a308,0xe0(%rsp)
 101af16:	00 08 a3 00 01 
 101af1b:	c7 84 24 f8 00 00 00 	movl   $0x2,0xf8(%rsp)
 101af22:	02 00 00 00 
 101af26:	c7 44 24 40 00 00 00 	movl   $0x0,0x40(%rsp)
 101af2d:	00 
 101af2e:	4c 39 a3 80 3d 00 00 	cmp    %r12,0x3d80(%rbx)
 101af35:	0f 85 af 00 00 00    	jne    101afea <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xb4a>
 101af3b:	48 8b b4 24 98 00 00 	mov    0x98(%rsp),%rsi
 101af42:	00 
 101af43:	48 8d bb 58 02 00 00 	lea    0x258(%rbx),%rdi
 101af4a:	e8 c1 cd 00 00       	call   1027d10 <myl_rc_scope_unwind>
 101af4f:	4c 8b b4 24 90 00 00 	mov    0x90(%rsp),%r14
 101af56:	00 
 101af57:	4d 85 f6             	test   %r14,%r14
 101af5a:	74 41                	je     101af9d <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xafd>
 101af5c:	4d 89 f7             	mov    %r14,%r15
 101af5f:	49 c1 e7 05          	shl    $0x5,%r15
 101af63:	49 83 c7 e0          	add    $0xffffffffffffffe0,%r15
 101af67:	eb 1b                	jmp    101af84 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xae4>
 101af69:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
 101af70:	4c 01 fe             	add    %r15,%rsi
 101af73:	48 89 df             	mov    %rbx,%rdi
 101af76:	e8 05 25 00 00       	call   101d480 <myl_qbe_rc_slot_drop>
 101af7b:	49 83 c7 e0          	add    $0xffffffffffffffe0,%r15
 101af7f:	49 ff ce             	dec    %r14
 101af82:	74 19                	je     101af9d <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xafd>
 101af84:	48 8b b4 24 88 00 00 	mov    0x88(%rsp),%rsi
 101af8b:	00 
 101af8c:	4a 8b 44 3e 10       	mov    0x10(%rsi,%r15,1),%rax
 101af91:	48 85 c0             	test   %rax,%rax
 101af94:	74 da                	je     101af70 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xad0>
 101af96:	83 38 00             	cmpl   $0x0,(%rax)
 101af99:	75 d5                	jne    101af70 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xad0>
 101af9b:	eb de                	jmp    101af7b <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xadb>
 101af9d:	4c 39 a3 80 3d 00 00 	cmp    %r12,0x3d80(%rbx)
 101afa4:	75 44                	jne    101afea <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xb4a>
 101afa6:	48 8b 83 60 18 00 00 	mov    0x1860(%rbx),%rax
 101afad:	48 85 c0             	test   %rax,%rax
 101afb0:	74 2c                	je     101afde <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xb3e>
 101afb2:	48 8b 40 70          	mov    0x70(%rax),%rax
 101afb6:	48 3b 84 24 98 00 00 	cmp    0x98(%rsp),%rax
 101afbd:	00 
 101afbe:	75 2a                	jne    101afea <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xb4a>
 101afc0:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
 101afc7:	00 
 101afc8:	48 89 83 80 3d 00 00 	mov    %rax,0x3d80(%rbx)
 101afcf:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
 101afd4:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
 101afd9:	e9 fe fe ff ff       	jmp    101aedc <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xa3c>
 101afde:	31 c0                	xor    %eax,%eax
 101afe0:	48 3b 84 24 98 00 00 	cmp    0x98(%rsp),%rax
 101afe7:	00 
 101afe8:	74 d6                	je     101afc0 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xb20>
 101afea:	c5 f8 77             	vzeroupper
 101afed:	e8 0f 89 00 00       	call   1023901 <myl_rc_invariant_failed>
 101aff2:	e8 89 3f 01 00       	call   102ef80 <abort@plt>
 101aff7:	48 89 df             	mov    %rbx,%rdi
 101affa:	e8 c1 36 00 00       	call   101e6c0 <myl_qbe_fail_allocation>
 101afff:	48 89 df             	mov    %rbx,%rdi
 101b002:	e8 b9 37 00 00       	call   101e7c0 <myl_qbe_fail_frame>
 101b007:	48 89 df             	mov    %rbx,%rdi
 101b00a:	e8 b1 36 00 00       	call   101e6c0 <myl_qbe_fail_allocation>
 101b00f:	48 ba 00 00 00 00 00 	movabs $0x8000000000000000,%rdx
 101b016:	00 00 80 
 101b019:	be 01 00 00 00       	mov    $0x1,%esi
 101b01e:	b9 01 00 00 00       	mov    $0x1,%ecx
 101b023:	48 89 df             	mov    %rbx,%rdi
 101b026:	c5 f8 77             	vzeroupper
 101b029:	e8 22 37 00 00       	call   101e750 <myl_qbe_fail_overflow_op>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
