
/home/epentland/ai/canopy/mylang-worktrees/d9-rc-flat-destruction-astra/.tmp-flat/cumulative-19e/qbe-rc-n12:     file format elf64-x86-64


Disassembly of section .text:

0000000001012aa0 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531>:
 1012aa0:	f3 0f 1e fa          	endbr64
 1012aa4:	55                   	push   %rbp
 1012aa5:	48 89 e5             	mov    %rsp,%rbp
 1012aa8:	48 81 ec 78 01 00 00 	sub    $0x178,%rsp
 1012aaf:	53                   	push   %rbx
 1012ab0:	41 54                	push   %r12
 1012ab2:	41 55                	push   %r13
 1012ab4:	41 56                	push   %r14
 1012ab6:	41 57                	push   %r15
 1012ab8:	49 89 f5             	mov    %rsi,%r13
 1012abb:	48 8b 47 40          	mov    0x40(%rdi),%rax
 1012abf:	48 8d 4d e8          	lea    -0x18(%rbp),%rcx
 1012ac3:	48 39 c1             	cmp    %rax,%rcx
 1012ac6:	0f 82 df 0d 00 00    	jb     10138ab <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xe0b>
 1012acc:	49 83 fd 00          	cmp    $0x0,%r13
 1012ad0:	0f 84 a6 0d 00 00    	je     101387c <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xddc>
 1012ad6:	48 89 fb             	mov    %rdi,%rbx
 1012ad9:	e8 72 70 00 00       	call   1019b50 <myl_qbe_heap>
 1012ade:	48 89 df             	mov    %rbx,%rdi
 1012ae1:	48 89 c3             	mov    %rax,%rbx
 1012ae4:	49 89 fc             	mov    %rdi,%r12
 1012ae7:	e8 a4 93 00 00       	call   101be90 <myl_qbe_region_mark>
 1012aec:	4c 89 ea             	mov    %r13,%rdx
 1012aef:	4c 89 e7             	mov    %r12,%rdi
 1012af2:	49 89 c7             	mov    %rax,%r15
 1012af5:	49 89 d5             	mov    %rdx,%r13
 1012af8:	ba 20 00 00 00       	mov    $0x20,%edx
 1012afd:	be 00 00 00 00       	mov    $0x0,%esi
 1012b02:	49 89 fc             	mov    %rdi,%r12
 1012b05:	48 8d bd 60 ff ff ff 	lea    -0xa0(%rbp),%rdi
 1012b0c:	e8 af 74 01 00       	call   1029fc0 <compiler_rt.fastMemset>
 1012b11:	4c 89 ea             	mov    %r13,%rdx
 1012b14:	4c 89 e7             	mov    %r12,%rdi
 1012b17:	49 89 d5             	mov    %rdx,%r13
 1012b1a:	ba 80 00 00 00       	mov    $0x80,%edx
 1012b1f:	be 00 00 00 00       	mov    $0x0,%esi
 1012b24:	49 89 fc             	mov    %rdi,%r12
 1012b27:	48 8d bd e0 fe ff ff 	lea    -0x120(%rbp),%rdi
 1012b2e:	e8 8d 74 01 00       	call   1029fc0 <compiler_rt.fastMemset>
 1012b33:	4c 89 ea             	mov    %r13,%rdx
 1012b36:	4c 89 e7             	mov    %r12,%rdi
 1012b39:	48 8d 05 98 19 ff ff 	lea    -0xe668(%rip),%rax        # 10044d8 <myl_t_385cfdbc00ec32031699460779c15099b2bba3cad0e440fffb08e10df0acb9e1>
 1012b40:	48 89 85 e0 fe ff ff 	mov    %rax,-0x120(%rbp)
 1012b47:	c7 85 f8 fe ff ff 00 	movl   $0x0,-0x108(%rbp)
 1012b4e:	00 00 00 
 1012b51:	48 8d 45 80          	lea    -0x80(%rbp),%rax
 1012b55:	48 89 85 e8 fe ff ff 	mov    %rax,-0x118(%rbp)
 1012b5c:	48 8d 85 60 ff ff ff 	lea    -0xa0(%rbp),%rax
 1012b63:	48 89 85 f0 fe ff ff 	mov    %rax,-0x110(%rbp)
 1012b6a:	48 8d 05 67 19 ff ff 	lea    -0xe699(%rip),%rax        # 10044d8 <myl_t_385cfdbc00ec32031699460779c15099b2bba3cad0e440fffb08e10df0acb9e1>
 1012b71:	48 89 85 00 ff ff ff 	mov    %rax,-0x100(%rbp)
 1012b78:	c7 85 18 ff ff ff 00 	movl   $0x0,-0xe8(%rbp)
 1012b7f:	00 00 00 
 1012b82:	48 8d 45 90          	lea    -0x70(%rbp),%rax
 1012b86:	48 89 85 08 ff ff ff 	mov    %rax,-0xf8(%rbp)
 1012b8d:	48 8d 85 60 ff ff ff 	lea    -0xa0(%rbp),%rax
 1012b94:	48 83 c0 08          	add    $0x8,%rax
 1012b98:	48 89 85 10 ff ff ff 	mov    %rax,-0xf0(%rbp)
 1012b9f:	48 8d 05 32 19 ff ff 	lea    -0xe6ce(%rip),%rax        # 10044d8 <myl_t_385cfdbc00ec32031699460779c15099b2bba3cad0e440fffb08e10df0acb9e1>
 1012ba6:	48 89 85 20 ff ff ff 	mov    %rax,-0xe0(%rbp)
 1012bad:	c7 85 38 ff ff ff 00 	movl   $0x0,-0xc8(%rbp)
 1012bb4:	00 00 00 
 1012bb7:	48 8d 45 a0          	lea    -0x60(%rbp),%rax
 1012bbb:	48 89 85 28 ff ff ff 	mov    %rax,-0xd8(%rbp)
 1012bc2:	48 8d 85 60 ff ff ff 	lea    -0xa0(%rbp),%rax
 1012bc9:	48 83 c0 10          	add    $0x10,%rax
 1012bcd:	48 89 85 30 ff ff ff 	mov    %rax,-0xd0(%rbp)
 1012bd4:	48 8d 05 fd 18 ff ff 	lea    -0xe703(%rip),%rax        # 10044d8 <myl_t_385cfdbc00ec32031699460779c15099b2bba3cad0e440fffb08e10df0acb9e1>
 1012bdb:	48 89 85 40 ff ff ff 	mov    %rax,-0xc0(%rbp)
 1012be2:	c7 85 58 ff ff ff 00 	movl   $0x0,-0xa8(%rbp)
 1012be9:	00 00 00 
 1012bec:	48 8d 45 b0          	lea    -0x50(%rbp),%rax
 1012bf0:	48 89 85 48 ff ff ff 	mov    %rax,-0xb8(%rbp)
 1012bf7:	48 8d 85 60 ff ff ff 	lea    -0xa0(%rbp),%rax
 1012bfe:	49 89 c4             	mov    %rax,%r12
 1012c01:	49 83 c4 18          	add    $0x18,%r12
 1012c05:	4c 89 a5 50 ff ff ff 	mov    %r12,-0xb0(%rbp)
 1012c0c:	b9 04 00 00 00       	mov    $0x4,%ecx
 1012c11:	49 89 d5             	mov    %rdx,%r13
 1012c14:	48 8d 95 e0 fe ff ff 	lea    -0x120(%rbp),%rdx
 1012c1b:	48 8d b5 c0 fe ff ff 	lea    -0x140(%rbp),%rsi
 1012c22:	49 89 fe             	mov    %rdi,%r14
 1012c25:	e8 36 66 00 00       	call   1019260 <myl_qbe_rc_frame_enter>
 1012c2a:	4c 89 f7             	mov    %r14,%rdi
 1012c2d:	4c 89 6d b8          	mov    %r13,-0x48(%rbp)
 1012c31:	48 c7 45 c0 01 00 00 	movq   $0x1,-0x40(%rbp)
 1012c38:	00 
 1012c39:	48 b8 01 00 00 00 00 	movabs $0x8000000000000001,%rax
 1012c40:	00 00 80 
 1012c43:	49 39 c5             	cmp    %rax,%r13
 1012c46:	0f 8c 16 0c 00 00    	jl     1013862 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xdc2>
 1012c4c:	4c 89 ee             	mov    %r13,%rsi
 1012c4f:	48 83 ee 01          	sub    $0x1,%rsi
 1012c53:	48 89 75 f0          	mov    %rsi,-0x10(%rbp)
 1012c57:	48 89 75 b8          	mov    %rsi,-0x48(%rbp)
 1012c5b:	49 89 fe             	mov    %rdi,%r14
 1012c5e:	e8 3d fe ff ff       	call   1012aa0 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531>
 1012c63:	4c 89 f7             	mov    %r14,%rdi
 1012c66:	48 89 c1             	mov    %rax,%rcx
 1012c69:	48 89 d0             	mov    %rdx,%rax
 1012c6c:	4c 89 ea             	mov    %r13,%rdx
 1012c6f:	48 89 8d 90 fe ff ff 	mov    %rcx,-0x170(%rbp)
 1012c76:	48 89 85 98 fe ff ff 	mov    %rax,-0x168(%rbp)
 1012c7d:	48 8d 85 90 fe ff ff 	lea    -0x170(%rbp),%rax
 1012c84:	48 89 45 b8          	mov    %rax,-0x48(%rbp)
 1012c88:	48 8b 85 90 fe ff ff 	mov    -0x170(%rbp),%rax
 1012c8f:	48 89 45 a0          	mov    %rax,-0x60(%rbp)
 1012c93:	48 8b 85 98 fe ff ff 	mov    -0x168(%rbp),%rax
 1012c9a:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
 1012c9e:	48 8d 05 bb b8 01 00 	lea    0x1b8bb(%rip),%rax        # 102e560 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 1012ca5:	48 89 85 20 ff ff ff 	mov    %rax,-0xe0(%rbp)
 1012cac:	c7 85 38 ff ff ff 02 	movl   $0x2,-0xc8(%rbp)
 1012cb3:	00 00 00 
 1012cb6:	c7 85 70 ff ff ff 01 	movl   $0x1,-0x90(%rbp)
 1012cbd:	00 00 00 
 1012cc0:	48 8b 45 a0          	mov    -0x60(%rbp),%rax
 1012cc4:	48 89 45 80          	mov    %rax,-0x80(%rbp)
 1012cc8:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
 1012ccc:	48 89 45 88          	mov    %rax,-0x78(%rbp)
 1012cd0:	48 8d 05 89 b8 01 00 	lea    0x1b889(%rip),%rax        # 102e560 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 1012cd7:	48 89 85 e0 fe ff ff 	mov    %rax,-0x120(%rbp)
 1012cde:	c7 85 f8 fe ff ff 02 	movl   $0x2,-0x108(%rbp)
 1012ce5:	00 00 00 
 1012ce8:	c7 85 f8 fe ff ff 02 	movl   $0x2,-0x108(%rbp)
 1012cef:	00 00 00 
 1012cf2:	c7 85 70 ff ff ff 00 	movl   $0x0,-0x90(%rbp)
 1012cf9:	00 00 00 
 1012cfc:	c7 85 60 ff ff ff 01 	movl   $0x1,-0xa0(%rbp)
 1012d03:	00 00 00 
 1012d06:	48 8d 45 80          	lea    -0x80(%rbp),%rax
 1012d0a:	48 89 45 b8          	mov    %rax,-0x48(%rbp)
 1012d0e:	49 89 d6             	mov    %rdx,%r14
 1012d11:	ba 01 00 00 00       	mov    $0x1,%edx
 1012d16:	48 8d 35 33 b5 01 00 	lea    0x1b533(%rip),%rsi        # 102e250 <myl_t_1e414bd82e4b50b54939760a2d591f88da97e2f1c8252dbd7dcbc73438e46afb_body>
 1012d1d:	49 89 fd             	mov    %rdi,%r13
 1012d20:	48 89 df             	mov    %rbx,%rdi
 1012d23:	e8 08 b5 00 00       	call   101e230 <myl_native_heap_alloc>
 1012d28:	4c 89 f2             	mov    %r14,%rdx
 1012d2b:	4c 89 ef             	mov    %r13,%rdi
 1012d2e:	48 89 45 f8          	mov    %rax,-0x8(%rbp)
 1012d32:	83 f8 00             	cmp    $0x0,%eax
 1012d35:	75 0a                	jne    1012d41 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x2a1>
 1012d37:	48 89 fb             	mov    %rdi,%rbx
 1012d3a:	e8 91 6b 00 00       	call   10198d0 <myl_qbe_fail_allocation>
 1012d3f:	0f 0b                	ud2
 1012d41:	48 87 fb             	xchg   %rdi,%rbx
 1012d44:	48 89 45 b0          	mov    %rax,-0x50(%rbp)
 1012d48:	48 8d 05 71 b5 01 00 	lea    0x1b571(%rip),%rax        # 102e2c0 <myl_t_1e414bd82e4b50b54939760a2d591f88da97e2f1c8252dbd7dcbc73438e46afb>
 1012d4f:	48 89 85 40 ff ff ff 	mov    %rax,-0xc0(%rbp)
 1012d56:	c7 85 58 ff ff ff 02 	movl   $0x2,-0xa8(%rbp)
 1012d5d:	00 00 00 
 1012d60:	48 8d 45 b0          	lea    -0x50(%rbp),%rax
 1012d64:	48 89 85 48 ff ff ff 	mov    %rax,-0xb8(%rbp)
 1012d6b:	4c 89 a5 50 ff ff ff 	mov    %r12,-0xb0(%rbp)
 1012d72:	c7 85 58 ff ff ff 04 	movl   $0x4,-0xa8(%rbp)
 1012d79:	00 00 00 
 1012d7c:	c7 85 78 ff ff ff 01 	movl   $0x1,-0x88(%rbp)
 1012d83:	00 00 00 
 1012d86:	48 8b 4d b8          	mov    -0x48(%rbp),%rcx
 1012d8a:	48 8b 01             	mov    (%rcx),%rax
 1012d8d:	48 83 f8 00          	cmp    $0x0,%rax
 1012d91:	74 1a                	je     1012dad <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x30d>
 1012d93:	48 83 e8 10          	sub    $0x10,%rax
 1012d97:	48 8b 00             	mov    (%rax),%rax
 1012d9a:	48 be 01 00 00 00 00 	movabs $0x5000000000000001,%rsi
 1012da1:	00 00 50 
 1012da4:	48 21 f0             	and    %rsi,%rax
 1012da7:	48 83 f8 00          	cmp    $0x0,%rax
 1012dab:	75 5d                	jne    1012e0a <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x36a>
 1012dad:	48 8b 41 08          	mov    0x8(%rcx),%rax
 1012db1:	48 83 f8 00          	cmp    $0x0,%rax
 1012db5:	74 1a                	je     1012dd1 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x331>
 1012db7:	48 83 e8 10          	sub    $0x10,%rax
 1012dbb:	48 8b 00             	mov    (%rax),%rax
 1012dbe:	48 be 01 00 00 00 00 	movabs $0x5000000000000001,%rsi
 1012dc5:	00 00 50 
 1012dc8:	48 21 f0             	and    %rsi,%rax
 1012dcb:	48 83 f8 00          	cmp    $0x0,%rax
 1012dcf:	75 39                	jne    1012e0a <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x36a>
 1012dd1:	48 8b 01             	mov    (%rcx),%rax
 1012dd4:	48 89 45 a0          	mov    %rax,-0x60(%rbp)
 1012dd8:	48 8b 41 08          	mov    0x8(%rcx),%rax
 1012ddc:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
 1012de0:	49 89 d6             	mov    %rdx,%r14
 1012de3:	ba 10 00 00 00       	mov    $0x10,%edx
 1012de8:	be 00 00 00 00       	mov    $0x0,%esi
 1012ded:	49 89 fd             	mov    %rdi,%r13
 1012df0:	48 89 cf             	mov    %rcx,%rdi
 1012df3:	e8 c8 71 01 00       	call   1029fc0 <compiler_rt.fastMemset>
 1012df8:	4d 89 f8             	mov    %r15,%r8
 1012dfb:	4c 89 f2             	mov    %r14,%rdx
 1012dfe:	4c 89 ef             	mov    %r13,%rdi
 1012e01:	48 8b 45 f8          	mov    -0x8(%rbp),%rax
 1012e05:	4d 89 c7             	mov    %r8,%r15
 1012e08:	eb 47                	jmp    1012e51 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x3b1>
 1012e0a:	4d 89 f8             	mov    %r15,%r8
 1012e0d:	4d 89 c7             	mov    %r8,%r15
 1012e10:	49 89 d6             	mov    %rdx,%r14
 1012e13:	48 8d 55 a0          	lea    -0x60(%rbp),%rdx
 1012e17:	48 8d 35 42 b7 01 00 	lea    0x1b742(%rip),%rsi        # 102e560 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 1012e1e:	49 89 fd             	mov    %rdi,%r13
 1012e21:	e8 aa 6c 01 00       	call   1029ad0 <myl_rc_native_take>
 1012e26:	4c 89 f2             	mov    %r14,%rdx
 1012e29:	4c 89 ef             	mov    %r13,%rdi
 1012e2c:	89 c1                	mov    %eax,%ecx
 1012e2e:	48 8b 45 f8          	mov    -0x8(%rbp),%rax
 1012e32:	83 f9 00             	cmp    $0x0,%ecx
 1012e35:	75 1a                	jne    1012e51 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x3b1>
 1012e37:	e8 64 ec 00 00       	call   1021aa0 <myl_rc_take_failure>
 1012e3c:	48 89 df             	mov    %rbx,%rdi
 1012e3f:	89 c6                	mov    %eax,%esi
 1012e41:	48 89 fb             	mov    %rdi,%rbx
 1012e44:	e8 27 63 00 00       	call   1019170 <myl_qbe_rc_status>
 1012e49:	48 89 df             	mov    %rbx,%rdi
 1012e4c:	e9 69 09 00 00       	jmp    10137ba <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xd1a>
 1012e51:	c7 85 60 ff ff ff 00 	movl   $0x0,-0xa0(%rbp)
 1012e58:	00 00 00 
 1012e5b:	48 8d 0d fe b6 01 00 	lea    0x1b6fe(%rip),%rcx        # 102e560 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 1012e62:	48 89 8d 20 ff ff ff 	mov    %rcx,-0xe0(%rbp)
 1012e69:	c7 85 38 ff ff ff 02 	movl   $0x2,-0xc8(%rbp)
 1012e70:	00 00 00 
 1012e73:	c7 85 70 ff ff ff 01 	movl   $0x1,-0x90(%rbp)
 1012e7a:	00 00 00 
 1012e7d:	48 8b 4d a0          	mov    -0x60(%rbp),%rcx
 1012e81:	48 89 08             	mov    %rcx,(%rax)
 1012e84:	48 8b 4d a8          	mov    -0x58(%rbp),%rcx
 1012e88:	48 89 48 08          	mov    %rcx,0x8(%rax)
 1012e8c:	c7 85 70 ff ff ff 00 	movl   $0x0,-0x90(%rbp)
 1012e93:	00 00 00 
 1012e96:	48 89 45 b8          	mov    %rax,-0x48(%rbp)
 1012e9a:	48 8b 4d b8          	mov    -0x48(%rbp),%rcx
 1012e9e:	48 89 4d 80          	mov    %rcx,-0x80(%rbp)
 1012ea2:	48 8d 0d 17 b4 01 00 	lea    0x1b417(%rip),%rcx        # 102e2c0 <myl_t_1e414bd82e4b50b54939760a2d591f88da97e2f1c8252dbd7dcbc73438e46afb>
 1012ea9:	48 89 8d e0 fe ff ff 	mov    %rcx,-0x120(%rbp)
 1012eb0:	c7 85 f8 fe ff ff 02 	movl   $0x2,-0x108(%rbp)
 1012eb7:	00 00 00 
 1012eba:	c7 85 60 ff ff ff 01 	movl   $0x1,-0xa0(%rbp)
 1012ec1:	00 00 00 
 1012ec4:	48 89 45 b8          	mov    %rax,-0x48(%rbp)
 1012ec8:	c7 85 78 ff ff ff 00 	movl   $0x0,-0x88(%rbp)
 1012ecf:	00 00 00 
 1012ed2:	49 89 d6             	mov    %rdx,%r14
 1012ed5:	ba 08 00 00 00       	mov    $0x8,%edx
 1012eda:	be 00 00 00 00       	mov    $0x0,%esi
 1012edf:	49 89 fd             	mov    %rdi,%r13
 1012ee2:	48 8d 7d c8          	lea    -0x38(%rbp),%rdi
 1012ee6:	e8 d5 70 01 00       	call   1029fc0 <compiler_rt.fastMemset>
 1012eeb:	4c 89 f2             	mov    %r14,%rdx
 1012eee:	4c 89 ef             	mov    %r13,%rdi
 1012ef1:	48 8d 05 f8 b5 01 00 	lea    0x1b5f8(%rip),%rax        # 102e4f0 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 1012ef8:	48 89 85 40 ff ff ff 	mov    %rax,-0xc0(%rbp)
 1012eff:	c7 85 58 ff ff ff 02 	movl   $0x2,-0xa8(%rbp)
 1012f06:	00 00 00 
 1012f09:	48 8d 45 c8          	lea    -0x38(%rbp),%rax
 1012f0d:	48 89 85 48 ff ff ff 	mov    %rax,-0xb8(%rbp)
 1012f14:	4c 89 a5 50 ff ff ff 	mov    %r12,-0xb0(%rbp)
 1012f1b:	c7 85 78 ff ff ff 01 	movl   $0x1,-0x88(%rbp)
 1012f22:	00 00 00 
 1012f25:	48 8b 45 b8          	mov    -0x48(%rbp),%rax
 1012f29:	48 83 f8 00          	cmp    $0x0,%rax
 1012f2d:	74 1a                	je     1012f49 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x4a9>
 1012f2f:	48 83 e8 10          	sub    $0x10,%rax
 1012f33:	48 8b 00             	mov    (%rax),%rax
 1012f36:	48 b9 01 00 00 00 00 	movabs $0x5000000000000001,%rcx
 1012f3d:	00 00 50 
 1012f40:	48 21 c8             	and    %rcx,%rax
 1012f43:	48 83 f8 00          	cmp    $0x0,%rax
 1012f47:	75 36                	jne    1012f7f <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x4df>
 1012f49:	48 8b 45 b8          	mov    -0x48(%rbp),%rax
 1012f4d:	48 89 45 a0          	mov    %rax,-0x60(%rbp)
 1012f51:	49 89 d6             	mov    %rdx,%r14
 1012f54:	ba 08 00 00 00       	mov    $0x8,%edx
 1012f59:	be 00 00 00 00       	mov    $0x0,%esi
 1012f5e:	49 89 fd             	mov    %rdi,%r13
 1012f61:	48 8d 7d b8          	lea    -0x48(%rbp),%rdi
 1012f65:	e8 56 70 01 00       	call   1029fc0 <compiler_rt.fastMemset>
 1012f6a:	4d 89 f8             	mov    %r15,%r8
 1012f6d:	4c 89 f2             	mov    %r14,%rdx
 1012f70:	4c 89 ef             	mov    %r13,%rdi
 1012f73:	48 8b 75 f0          	mov    -0x10(%rbp),%rsi
 1012f77:	4d 89 c7             	mov    %r8,%r15
 1012f7a:	48 87 df             	xchg   %rbx,%rdi
 1012f7d:	eb 4c                	jmp    1012fcb <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x52b>
 1012f7f:	4d 89 f8             	mov    %r15,%r8
 1012f82:	4d 89 c7             	mov    %r8,%r15
 1012f85:	48 8d 4d b8          	lea    -0x48(%rbp),%rcx
 1012f89:	49 89 d6             	mov    %rdx,%r14
 1012f8c:	48 8d 55 a0          	lea    -0x60(%rbp),%rdx
 1012f90:	48 8d 35 29 b3 01 00 	lea    0x1b329(%rip),%rsi        # 102e2c0 <myl_t_1e414bd82e4b50b54939760a2d591f88da97e2f1c8252dbd7dcbc73438e46afb>
 1012f97:	49 89 fd             	mov    %rdi,%r13
 1012f9a:	e8 31 6b 01 00       	call   1029ad0 <myl_rc_native_take>
 1012f9f:	4c 89 f2             	mov    %r14,%rdx
 1012fa2:	4c 89 ef             	mov    %r13,%rdi
 1012fa5:	48 8b 75 f0          	mov    -0x10(%rbp),%rsi
 1012fa9:	83 f8 00             	cmp    $0x0,%eax
 1012fac:	75 1a                	jne    1012fc8 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x528>
 1012fae:	e8 ed ea 00 00       	call   1021aa0 <myl_rc_take_failure>
 1012fb3:	48 89 df             	mov    %rbx,%rdi
 1012fb6:	89 c6                	mov    %eax,%esi
 1012fb8:	48 89 fb             	mov    %rdi,%rbx
 1012fbb:	e8 b0 61 00 00       	call   1019170 <myl_qbe_rc_status>
 1012fc0:	48 89 df             	mov    %rbx,%rdi
 1012fc3:	e9 f2 07 00 00       	jmp    10137ba <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xd1a>
 1012fc8:	48 87 df             	xchg   %rbx,%rdi
 1012fcb:	c7 85 60 ff ff ff 00 	movl   $0x0,-0xa0(%rbp)
 1012fd2:	00 00 00 
 1012fd5:	48 8d 05 e4 b2 01 00 	lea    0x1b2e4(%rip),%rax        # 102e2c0 <myl_t_1e414bd82e4b50b54939760a2d591f88da97e2f1c8252dbd7dcbc73438e46afb>
 1012fdc:	48 89 85 20 ff ff ff 	mov    %rax,-0xe0(%rbp)
 1012fe3:	c7 85 38 ff ff ff 02 	movl   $0x2,-0xc8(%rbp)
 1012fea:	00 00 00 
 1012fed:	c7 85 70 ff ff ff 01 	movl   $0x1,-0x90(%rbp)
 1012ff4:	00 00 00 
 1012ff7:	48 8b 45 a0          	mov    -0x60(%rbp),%rax
 1012ffb:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
 1012fff:	c7 85 70 ff ff ff 00 	movl   $0x0,-0x90(%rbp)
 1013006:	00 00 00 
 1013009:	48 8d 45 c8          	lea    -0x38(%rbp),%rax
 101300d:	48 89 45 b8          	mov    %rax,-0x48(%rbp)
 1013011:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
 1013015:	48 89 45 80          	mov    %rax,-0x80(%rbp)
 1013019:	48 8d 05 d0 b4 01 00 	lea    0x1b4d0(%rip),%rax        # 102e4f0 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 1013020:	48 89 85 e0 fe ff ff 	mov    %rax,-0x120(%rbp)
 1013027:	c7 85 f8 fe ff ff 02 	movl   $0x2,-0x108(%rbp)
 101302e:	00 00 00 
 1013031:	c7 85 60 ff ff ff 01 	movl   $0x1,-0xa0(%rbp)
 1013038:	00 00 00 
 101303b:	48 8d 45 80          	lea    -0x80(%rbp),%rax
 101303f:	48 89 45 b8          	mov    %rax,-0x48(%rbp)
 1013043:	c7 85 78 ff ff ff 00 	movl   $0x0,-0x88(%rbp)
 101304a:	00 00 00 
 101304d:	48 89 55 c0          	mov    %rdx,-0x40(%rbp)
 1013051:	48 89 75 c0          	mov    %rsi,-0x40(%rbp)
 1013055:	49 89 fd             	mov    %rdi,%r13
 1013058:	e8 43 fa ff ff       	call   1012aa0 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531>
 101305d:	4c 89 ef             	mov    %r13,%rdi
 1013060:	48 89 c1             	mov    %rax,%rcx
 1013063:	48 89 d0             	mov    %rdx,%rax
 1013066:	48 89 8d a0 fe ff ff 	mov    %rcx,-0x160(%rbp)
 101306d:	48 89 85 a8 fe ff ff 	mov    %rax,-0x158(%rbp)
 1013074:	48 8d 85 a0 fe ff ff 	lea    -0x160(%rbp),%rax
 101307b:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
 101307f:	48 8b 85 a0 fe ff ff 	mov    -0x160(%rbp),%rax
 1013086:	48 89 45 a0          	mov    %rax,-0x60(%rbp)
 101308a:	48 8b 85 a8 fe ff ff 	mov    -0x158(%rbp),%rax
 1013091:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
 1013095:	48 8d 05 c4 b4 01 00 	lea    0x1b4c4(%rip),%rax        # 102e560 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 101309c:	48 89 85 20 ff ff ff 	mov    %rax,-0xe0(%rbp)
 10130a3:	c7 85 38 ff ff ff 02 	movl   $0x2,-0xc8(%rbp)
 10130aa:	00 00 00 
 10130ad:	c7 85 70 ff ff ff 01 	movl   $0x1,-0x90(%rbp)
 10130b4:	00 00 00 
 10130b7:	48 8b 45 a0          	mov    -0x60(%rbp),%rax
 10130bb:	48 89 45 90          	mov    %rax,-0x70(%rbp)
 10130bf:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
 10130c3:	48 89 45 98          	mov    %rax,-0x68(%rbp)
 10130c7:	48 8d 05 92 b4 01 00 	lea    0x1b492(%rip),%rax        # 102e560 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 10130ce:	48 89 85 00 ff ff ff 	mov    %rax,-0x100(%rbp)
 10130d5:	c7 85 18 ff ff ff 02 	movl   $0x2,-0xe8(%rbp)
 10130dc:	00 00 00 
 10130df:	c7 85 18 ff ff ff 02 	movl   $0x2,-0xe8(%rbp)
 10130e6:	00 00 00 
 10130e9:	c7 85 70 ff ff ff 00 	movl   $0x0,-0x90(%rbp)
 10130f0:	00 00 00 
 10130f3:	c7 85 68 ff ff ff 01 	movl   $0x1,-0x98(%rbp)
 10130fa:	00 00 00 
 10130fd:	48 8d 45 90          	lea    -0x70(%rbp),%rax
 1013101:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
 1013105:	ba 01 00 00 00       	mov    $0x1,%edx
 101310a:	48 8d 35 3f b1 01 00 	lea    0x1b13f(%rip),%rsi        # 102e250 <myl_t_1e414bd82e4b50b54939760a2d591f88da97e2f1c8252dbd7dcbc73438e46afb_body>
 1013111:	49 89 fd             	mov    %rdi,%r13
 1013114:	48 89 df             	mov    %rbx,%rdi
 1013117:	e8 14 b1 00 00       	call   101e230 <myl_native_heap_alloc>
 101311c:	4c 89 ef             	mov    %r13,%rdi
 101311f:	49 89 c5             	mov    %rax,%r13
 1013122:	41 83 fd 00          	cmp    $0x0,%r13d
 1013126:	75 0a                	jne    1013132 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x692>
 1013128:	48 89 fb             	mov    %rdi,%rbx
 101312b:	e8 a0 67 00 00       	call   10198d0 <myl_qbe_fail_allocation>
 1013130:	0f 0b                	ud2
 1013132:	48 87 fb             	xchg   %rdi,%rbx
 1013135:	4c 89 6d b0          	mov    %r13,-0x50(%rbp)
 1013139:	48 8d 05 80 b1 01 00 	lea    0x1b180(%rip),%rax        # 102e2c0 <myl_t_1e414bd82e4b50b54939760a2d591f88da97e2f1c8252dbd7dcbc73438e46afb>
 1013140:	48 89 85 40 ff ff ff 	mov    %rax,-0xc0(%rbp)
 1013147:	c7 85 58 ff ff ff 02 	movl   $0x2,-0xa8(%rbp)
 101314e:	00 00 00 
 1013151:	48 8d 45 b0          	lea    -0x50(%rbp),%rax
 1013155:	48 89 85 48 ff ff ff 	mov    %rax,-0xb8(%rbp)
 101315c:	4c 89 a5 50 ff ff ff 	mov    %r12,-0xb0(%rbp)
 1013163:	c7 85 58 ff ff ff 04 	movl   $0x4,-0xa8(%rbp)
 101316a:	00 00 00 
 101316d:	c7 85 78 ff ff ff 01 	movl   $0x1,-0x88(%rbp)
 1013174:	00 00 00 
 1013177:	48 8b 4d c0          	mov    -0x40(%rbp),%rcx
 101317b:	48 8b 01             	mov    (%rcx),%rax
 101317e:	48 83 f8 00          	cmp    $0x0,%rax
 1013182:	74 1a                	je     101319e <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x6fe>
 1013184:	48 83 e8 10          	sub    $0x10,%rax
 1013188:	48 8b 00             	mov    (%rax),%rax
 101318b:	48 ba 01 00 00 00 00 	movabs $0x5000000000000001,%rdx
 1013192:	00 00 50 
 1013195:	48 21 d0             	and    %rdx,%rax
 1013198:	48 83 f8 00          	cmp    $0x0,%rax
 101319c:	75 53                	jne    10131f1 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x751>
 101319e:	48 8b 41 08          	mov    0x8(%rcx),%rax
 10131a2:	48 83 f8 00          	cmp    $0x0,%rax
 10131a6:	74 1a                	je     10131c2 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x722>
 10131a8:	48 83 e8 10          	sub    $0x10,%rax
 10131ac:	48 8b 00             	mov    (%rax),%rax
 10131af:	48 ba 01 00 00 00 00 	movabs $0x5000000000000001,%rdx
 10131b6:	00 00 50 
 10131b9:	48 21 d0             	and    %rdx,%rax
 10131bc:	48 83 f8 00          	cmp    $0x0,%rax
 10131c0:	75 2f                	jne    10131f1 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x751>
 10131c2:	48 8b 01             	mov    (%rcx),%rax
 10131c5:	48 89 45 a0          	mov    %rax,-0x60(%rbp)
 10131c9:	48 8b 41 08          	mov    0x8(%rcx),%rax
 10131cd:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
 10131d1:	ba 10 00 00 00       	mov    $0x10,%edx
 10131d6:	be 00 00 00 00       	mov    $0x0,%esi
 10131db:	49 89 fe             	mov    %rdi,%r14
 10131de:	48 89 cf             	mov    %rcx,%rdi
 10131e1:	e8 da 6d 01 00       	call   1029fc0 <compiler_rt.fastMemset>
 10131e6:	4d 89 f8             	mov    %r15,%r8
 10131e9:	4c 89 f7             	mov    %r14,%rdi
 10131ec:	4d 89 c6             	mov    %r8,%r14
 10131ef:	eb 3b                	jmp    101322c <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x78c>
 10131f1:	4d 89 f8             	mov    %r15,%r8
 10131f4:	4d 89 c6             	mov    %r8,%r14
 10131f7:	48 8d 55 a0          	lea    -0x60(%rbp),%rdx
 10131fb:	48 8d 35 5e b3 01 00 	lea    0x1b35e(%rip),%rsi        # 102e560 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 1013202:	49 89 ff             	mov    %rdi,%r15
 1013205:	e8 c6 68 01 00       	call   1029ad0 <myl_rc_native_take>
 101320a:	4c 89 ff             	mov    %r15,%rdi
 101320d:	83 f8 00             	cmp    $0x0,%eax
 1013210:	75 1a                	jne    101322c <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x78c>
 1013212:	e8 89 e8 00 00       	call   1021aa0 <myl_rc_take_failure>
 1013217:	48 89 df             	mov    %rbx,%rdi
 101321a:	89 c6                	mov    %eax,%esi
 101321c:	48 89 fb             	mov    %rdi,%rbx
 101321f:	e8 4c 5f 00 00       	call   1019170 <myl_qbe_rc_status>
 1013224:	48 89 df             	mov    %rbx,%rdi
 1013227:	e9 8e 05 00 00       	jmp    10137ba <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xd1a>
 101322c:	c7 85 68 ff ff ff 00 	movl   $0x0,-0x98(%rbp)
 1013233:	00 00 00 
 1013236:	48 8d 05 23 b3 01 00 	lea    0x1b323(%rip),%rax        # 102e560 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 101323d:	48 89 85 20 ff ff ff 	mov    %rax,-0xe0(%rbp)
 1013244:	c7 85 38 ff ff ff 02 	movl   $0x2,-0xc8(%rbp)
 101324b:	00 00 00 
 101324e:	c7 85 70 ff ff ff 01 	movl   $0x1,-0x90(%rbp)
 1013255:	00 00 00 
 1013258:	48 8b 45 a0          	mov    -0x60(%rbp),%rax
 101325c:	49 89 45 00          	mov    %rax,0x0(%r13)
 1013260:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
 1013264:	49 89 45 08          	mov    %rax,0x8(%r13)
 1013268:	c7 85 70 ff ff ff 00 	movl   $0x0,-0x90(%rbp)
 101326f:	00 00 00 
 1013272:	4c 89 6d c0          	mov    %r13,-0x40(%rbp)
 1013276:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
 101327a:	48 89 45 90          	mov    %rax,-0x70(%rbp)
 101327e:	48 8d 05 3b b0 01 00 	lea    0x1b03b(%rip),%rax        # 102e2c0 <myl_t_1e414bd82e4b50b54939760a2d591f88da97e2f1c8252dbd7dcbc73438e46afb>
 1013285:	48 89 85 00 ff ff ff 	mov    %rax,-0x100(%rbp)
 101328c:	c7 85 18 ff ff ff 02 	movl   $0x2,-0xe8(%rbp)
 1013293:	00 00 00 
 1013296:	c7 85 68 ff ff ff 01 	movl   $0x1,-0x98(%rbp)
 101329d:	00 00 00 
 10132a0:	4c 89 6d c0          	mov    %r13,-0x40(%rbp)
 10132a4:	c7 85 78 ff ff ff 00 	movl   $0x0,-0x88(%rbp)
 10132ab:	00 00 00 
 10132ae:	ba 08 00 00 00       	mov    $0x8,%edx
 10132b3:	be 00 00 00 00       	mov    $0x0,%esi
 10132b8:	49 89 fd             	mov    %rdi,%r13
 10132bb:	48 8d 7d d0          	lea    -0x30(%rbp),%rdi
 10132bf:	e8 fc 6c 01 00       	call   1029fc0 <compiler_rt.fastMemset>
 10132c4:	4c 89 ef             	mov    %r13,%rdi
 10132c7:	48 8d 05 22 b2 01 00 	lea    0x1b222(%rip),%rax        # 102e4f0 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 10132ce:	48 89 85 40 ff ff ff 	mov    %rax,-0xc0(%rbp)
 10132d5:	c7 85 58 ff ff ff 02 	movl   $0x2,-0xa8(%rbp)
 10132dc:	00 00 00 
 10132df:	48 8d 45 d0          	lea    -0x30(%rbp),%rax
 10132e3:	48 89 85 48 ff ff ff 	mov    %rax,-0xb8(%rbp)
 10132ea:	4c 89 a5 50 ff ff ff 	mov    %r12,-0xb0(%rbp)
 10132f1:	c7 85 78 ff ff ff 01 	movl   $0x1,-0x88(%rbp)
 10132f8:	00 00 00 
 10132fb:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
 10132ff:	48 83 f8 00          	cmp    $0x0,%rax
 1013303:	74 1a                	je     101331f <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x87f>
 1013305:	48 83 e8 10          	sub    $0x10,%rax
 1013309:	48 8b 00             	mov    (%rax),%rax
 101330c:	48 b9 01 00 00 00 00 	movabs $0x5000000000000001,%rcx
 1013313:	00 00 50 
 1013316:	48 21 c8             	and    %rcx,%rax
 1013319:	48 83 f8 00          	cmp    $0x0,%rax
 101331d:	75 29                	jne    1013348 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x8a8>
 101331f:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
 1013323:	48 89 45 a0          	mov    %rax,-0x60(%rbp)
 1013327:	ba 08 00 00 00       	mov    $0x8,%edx
 101332c:	be 00 00 00 00       	mov    $0x0,%esi
 1013331:	49 89 fd             	mov    %rdi,%r13
 1013334:	48 8d 7d c0          	lea    -0x40(%rbp),%rdi
 1013338:	e8 83 6c 01 00       	call   1029fc0 <compiler_rt.fastMemset>
 101333d:	4d 89 f0             	mov    %r14,%r8
 1013340:	4c 89 ef             	mov    %r13,%rdi
 1013343:	4d 89 c6             	mov    %r8,%r14
 1013346:	eb 3f                	jmp    1013387 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x8e7>
 1013348:	4d 89 f0             	mov    %r14,%r8
 101334b:	4d 89 c6             	mov    %r8,%r14
 101334e:	48 8d 4d c0          	lea    -0x40(%rbp),%rcx
 1013352:	48 8d 55 a0          	lea    -0x60(%rbp),%rdx
 1013356:	48 8d 35 63 af 01 00 	lea    0x1af63(%rip),%rsi        # 102e2c0 <myl_t_1e414bd82e4b50b54939760a2d591f88da97e2f1c8252dbd7dcbc73438e46afb>
 101335d:	49 89 fd             	mov    %rdi,%r13
 1013360:	e8 6b 67 01 00       	call   1029ad0 <myl_rc_native_take>
 1013365:	4c 89 ef             	mov    %r13,%rdi
 1013368:	83 f8 00             	cmp    $0x0,%eax
 101336b:	75 1a                	jne    1013387 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x8e7>
 101336d:	e8 2e e7 00 00       	call   1021aa0 <myl_rc_take_failure>
 1013372:	48 89 df             	mov    %rbx,%rdi
 1013375:	89 c6                	mov    %eax,%esi
 1013377:	48 89 fb             	mov    %rdi,%rbx
 101337a:	e8 f1 5d 00 00       	call   1019170 <myl_qbe_rc_status>
 101337f:	48 89 df             	mov    %rbx,%rdi
 1013382:	e9 33 04 00 00       	jmp    10137ba <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xd1a>
 1013387:	c7 85 68 ff ff ff 00 	movl   $0x0,-0x98(%rbp)
 101338e:	00 00 00 
 1013391:	48 8d 05 28 af 01 00 	lea    0x1af28(%rip),%rax        # 102e2c0 <myl_t_1e414bd82e4b50b54939760a2d591f88da97e2f1c8252dbd7dcbc73438e46afb>
 1013398:	48 89 85 20 ff ff ff 	mov    %rax,-0xe0(%rbp)
 101339f:	c7 85 38 ff ff ff 02 	movl   $0x2,-0xc8(%rbp)
 10133a6:	00 00 00 
 10133a9:	c7 85 70 ff ff ff 01 	movl   $0x1,-0x90(%rbp)
 10133b0:	00 00 00 
 10133b3:	48 8b 45 a0          	mov    -0x60(%rbp),%rax
 10133b7:	48 89 45 d0          	mov    %rax,-0x30(%rbp)
 10133bb:	c7 85 70 ff ff ff 00 	movl   $0x0,-0x90(%rbp)
 10133c2:	00 00 00 
 10133c5:	48 8d 45 d0          	lea    -0x30(%rbp),%rax
 10133c9:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
 10133cd:	48 8b 45 d0          	mov    -0x30(%rbp),%rax
 10133d1:	48 89 45 90          	mov    %rax,-0x70(%rbp)
 10133d5:	48 8d 05 14 b1 01 00 	lea    0x1b114(%rip),%rax        # 102e4f0 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 10133dc:	48 89 85 00 ff ff ff 	mov    %rax,-0x100(%rbp)
 10133e3:	c7 85 18 ff ff ff 02 	movl   $0x2,-0xe8(%rbp)
 10133ea:	00 00 00 
 10133ed:	c7 85 68 ff ff ff 01 	movl   $0x1,-0x98(%rbp)
 10133f4:	00 00 00 
 10133f7:	48 8d 45 90          	lea    -0x70(%rbp),%rax
 10133fb:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
 10133ff:	c7 85 78 ff ff ff 00 	movl   $0x0,-0x88(%rbp)
 1013406:	00 00 00 
 1013409:	ba 10 00 00 00       	mov    $0x10,%edx
 101340e:	be 00 00 00 00       	mov    $0x0,%esi
 1013413:	49 89 fd             	mov    %rdi,%r13
 1013416:	48 8d 7d d8          	lea    -0x28(%rbp),%rdi
 101341a:	e8 a1 6b 01 00       	call   1029fc0 <compiler_rt.fastMemset>
 101341f:	4d 89 f0             	mov    %r14,%r8
 1013422:	4c 89 ef             	mov    %r13,%rdi
 1013425:	48 8d 05 34 b1 01 00 	lea    0x1b134(%rip),%rax        # 102e560 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 101342c:	48 89 85 40 ff ff ff 	mov    %rax,-0xc0(%rbp)
 1013433:	c7 85 58 ff ff ff 02 	movl   $0x2,-0xa8(%rbp)
 101343a:	00 00 00 
 101343d:	48 8d 45 d8          	lea    -0x28(%rbp),%rax
 1013441:	48 89 85 48 ff ff ff 	mov    %rax,-0xb8(%rbp)
 1013448:	4c 89 a5 50 ff ff ff 	mov    %r12,-0xb0(%rbp)
 101344f:	c7 85 78 ff ff ff 01 	movl   $0x1,-0x88(%rbp)
 1013456:	00 00 00 
 1013459:	48 8b 4d b8          	mov    -0x48(%rbp),%rcx
 101345d:	8b 85 60 ff ff ff    	mov    -0xa0(%rbp),%eax
 1013463:	8b 95 f8 fe ff ff    	mov    -0x108(%rbp),%edx
 1013469:	83 e2 18             	and    $0x18,%edx
 101346c:	83 fa 00             	cmp    $0x0,%edx
 101346f:	0f 94 c2             	sete   %dl
 1013472:	0f b6 d2             	movzbl %dl,%edx
 1013475:	85 c2                	test   %eax,%edx
 1013477:	0f 85 83 00 00 00    	jne    1013500 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xa60>
 101347d:	4d 89 c5             	mov    %r8,%r13
 1013480:	48 8d 55 a0          	lea    -0x60(%rbp),%rdx
 1013484:	48 8d 35 65 b0 01 00 	lea    0x1b065(%rip),%rsi        # 102e4f0 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 101348b:	49 89 fc             	mov    %rdi,%r12
 101348e:	e8 7d 69 01 00       	call   1029e10 <myl_rc_native_retain>
 1013493:	4c 89 e7             	mov    %r12,%rdi
 1013496:	83 f8 00             	cmp    $0x0,%eax
 1013499:	75 1a                	jne    10134b5 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xa15>
 101349b:	e8 00 e6 00 00       	call   1021aa0 <myl_rc_take_failure>
 10134a0:	48 89 df             	mov    %rbx,%rdi
 10134a3:	89 c6                	mov    %eax,%esi
 10134a5:	48 89 fb             	mov    %rdi,%rbx
 10134a8:	e8 c3 5c 00 00       	call   1019170 <myl_qbe_rc_status>
 10134ad:	48 89 df             	mov    %rbx,%rdi
 10134b0:	e9 05 03 00 00       	jmp    10137ba <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xd1a>
 10134b5:	48 8d 05 34 b0 01 00 	lea    0x1b034(%rip),%rax        # 102e4f0 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 10134bc:	48 89 85 20 ff ff ff 	mov    %rax,-0xe0(%rbp)
 10134c3:	c7 85 38 ff ff ff 02 	movl   $0x2,-0xc8(%rbp)
 10134ca:	00 00 00 
 10134cd:	c7 85 70 ff ff ff 01 	movl   $0x1,-0x90(%rbp)
 10134d4:	00 00 00 
 10134d7:	8b 85 60 ff ff ff    	mov    -0xa0(%rbp),%eax
 10134dd:	83 f8 00             	cmp    $0x0,%eax
 10134e0:	0f 84 f7 00 00 00    	je     10135dd <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xb3d>
 10134e6:	48 8d b5 e0 fe ff ff 	lea    -0x120(%rbp),%rsi
 10134ed:	49 89 fc             	mov    %rdi,%r12
 10134f0:	48 89 df             	mov    %rbx,%rdi
 10134f3:	e8 48 5e 00 00       	call   1019340 <myl_qbe_rc_slot_drop>
 10134f8:	4c 89 e7             	mov    %r12,%rdi
 10134fb:	e9 dd 00 00 00       	jmp    10135dd <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xb3d>
 1013500:	4d 89 c5             	mov    %r8,%r13
 1013503:	48 8d 45 a0          	lea    -0x60(%rbp),%rax
 1013507:	48 f7 d8             	neg    %rax
 101350a:	48 01 c8             	add    %rcx,%rax
 101350d:	48 8d 55 a0          	lea    -0x60(%rbp),%rdx
 1013511:	48 29 ca             	sub    %rcx,%rdx
 1013514:	48 83 f8 08          	cmp    $0x8,%rax
 1013518:	0f 92 c0             	setb   %al
 101351b:	0f b6 c0             	movzbl %al,%eax
 101351e:	48 83 fa 08          	cmp    $0x8,%rdx
 1013522:	0f 92 c2             	setb   %dl
 1013525:	0f b6 d2             	movzbl %dl,%edx
 1013528:	09 d0                	or     %edx,%eax
 101352a:	75 4a                	jne    1013576 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xad6>
 101352c:	48 8b 01             	mov    (%rcx),%rax
 101352f:	48 83 f8 00          	cmp    $0x0,%rax
 1013533:	74 1a                	je     101354f <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xaaf>
 1013535:	48 83 e8 10          	sub    $0x10,%rax
 1013539:	48 8b 00             	mov    (%rax),%rax
 101353c:	48 ba 01 00 00 00 00 	movabs $0x5000000000000001,%rdx
 1013543:	00 00 50 
 1013546:	48 21 d0             	and    %rdx,%rax
 1013549:	48 83 f8 00          	cmp    $0x0,%rax
 101354d:	75 27                	jne    1013576 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xad6>
 101354f:	48 8b 01             	mov    (%rcx),%rax
 1013552:	48 89 45 a0          	mov    %rax,-0x60(%rbp)
 1013556:	ba 08 00 00 00       	mov    $0x8,%edx
 101355b:	be 00 00 00 00       	mov    $0x0,%esi
 1013560:	49 89 fc             	mov    %rdi,%r12
 1013563:	48 89 cf             	mov    %rcx,%rdi
 1013566:	e8 55 6a 01 00       	call   1029fc0 <compiler_rt.fastMemset>
 101356b:	4d 89 e8             	mov    %r13,%r8
 101356e:	4c 89 e7             	mov    %r12,%rdi
 1013571:	4d 89 c5             	mov    %r8,%r13
 1013574:	eb 3b                	jmp    10135b1 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xb11>
 1013576:	4d 89 e8             	mov    %r13,%r8
 1013579:	4d 89 c5             	mov    %r8,%r13
 101357c:	48 8d 55 a0          	lea    -0x60(%rbp),%rdx
 1013580:	48 8d 35 69 af 01 00 	lea    0x1af69(%rip),%rsi        # 102e4f0 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 1013587:	49 89 fc             	mov    %rdi,%r12
 101358a:	e8 41 65 01 00       	call   1029ad0 <myl_rc_native_take>
 101358f:	4c 89 e7             	mov    %r12,%rdi
 1013592:	83 f8 00             	cmp    $0x0,%eax
 1013595:	75 1a                	jne    10135b1 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xb11>
 1013597:	e8 04 e5 00 00       	call   1021aa0 <myl_rc_take_failure>
 101359c:	48 89 df             	mov    %rbx,%rdi
 101359f:	89 c6                	mov    %eax,%esi
 10135a1:	48 89 fb             	mov    %rdi,%rbx
 10135a4:	e8 c7 5b 00 00       	call   1019170 <myl_qbe_rc_status>
 10135a9:	48 89 df             	mov    %rbx,%rdi
 10135ac:	e9 09 02 00 00       	jmp    10137ba <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xd1a>
 10135b1:	c7 85 60 ff ff ff 00 	movl   $0x0,-0xa0(%rbp)
 10135b8:	00 00 00 
 10135bb:	48 8d 05 2e af 01 00 	lea    0x1af2e(%rip),%rax        # 102e4f0 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 10135c2:	48 89 85 20 ff ff ff 	mov    %rax,-0xe0(%rbp)
 10135c9:	c7 85 38 ff ff ff 02 	movl   $0x2,-0xc8(%rbp)
 10135d0:	00 00 00 
 10135d3:	c7 85 70 ff ff ff 01 	movl   $0x1,-0x90(%rbp)
 10135da:	00 00 00 
 10135dd:	48 8b 45 a0          	mov    -0x60(%rbp),%rax
 10135e1:	48 89 45 d8          	mov    %rax,-0x28(%rbp)
 10135e5:	c7 85 70 ff ff ff 00 	movl   $0x0,-0x90(%rbp)
 10135ec:	00 00 00 
 10135ef:	48 8b 4d c0          	mov    -0x40(%rbp),%rcx
 10135f3:	48 8b 01             	mov    (%rcx),%rax
 10135f6:	48 83 f8 00          	cmp    $0x0,%rax
 10135fa:	74 1a                	je     1013616 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xb76>
 10135fc:	48 83 e8 10          	sub    $0x10,%rax
 1013600:	48 8b 00             	mov    (%rax),%rax
 1013603:	48 ba 01 00 00 00 00 	movabs $0x5000000000000001,%rdx
 101360a:	00 00 50 
 101360d:	48 21 d0             	and    %rdx,%rax
 1013610:	48 83 f8 00          	cmp    $0x0,%rax
 1013614:	75 27                	jne    101363d <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xb9d>
 1013616:	48 8b 01             	mov    (%rcx),%rax
 1013619:	48 89 45 a0          	mov    %rax,-0x60(%rbp)
 101361d:	ba 08 00 00 00       	mov    $0x8,%edx
 1013622:	be 00 00 00 00       	mov    $0x0,%esi
 1013627:	49 89 fc             	mov    %rdi,%r12
 101362a:	48 89 cf             	mov    %rcx,%rdi
 101362d:	e8 8e 69 01 00       	call   1029fc0 <compiler_rt.fastMemset>
 1013632:	4d 89 e8             	mov    %r13,%r8
 1013635:	4c 89 e7             	mov    %r12,%rdi
 1013638:	48 87 df             	xchg   %rbx,%rdi
 101363b:	eb 41                	jmp    101367e <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xbde>
 101363d:	4d 89 e8             	mov    %r13,%r8
 1013640:	4d 89 c5             	mov    %r8,%r13
 1013643:	48 8d 55 a0          	lea    -0x60(%rbp),%rdx
 1013647:	48 8d 35 a2 ae 01 00 	lea    0x1aea2(%rip),%rsi        # 102e4f0 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 101364e:	49 89 fc             	mov    %rdi,%r12
 1013651:	e8 7a 64 01 00       	call   1029ad0 <myl_rc_native_take>
 1013656:	4d 89 e8             	mov    %r13,%r8
 1013659:	4c 89 e7             	mov    %r12,%rdi
 101365c:	83 f8 00             	cmp    $0x0,%eax
 101365f:	75 1a                	jne    101367b <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xbdb>
 1013661:	e8 3a e4 00 00       	call   1021aa0 <myl_rc_take_failure>
 1013666:	48 89 df             	mov    %rbx,%rdi
 1013669:	89 c6                	mov    %eax,%esi
 101366b:	48 89 fb             	mov    %rdi,%rbx
 101366e:	e8 fd 5a 00 00       	call   1019170 <myl_qbe_rc_status>
 1013673:	48 89 df             	mov    %rbx,%rdi
 1013676:	e9 3f 01 00 00       	jmp    10137ba <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xd1a>
 101367b:	48 87 df             	xchg   %rbx,%rdi
 101367e:	c7 85 68 ff ff ff 00 	movl   $0x0,-0x98(%rbp)
 1013685:	00 00 00 
 1013688:	48 8d 05 61 ae 01 00 	lea    0x1ae61(%rip),%rax        # 102e4f0 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 101368f:	48 89 85 20 ff ff ff 	mov    %rax,-0xe0(%rbp)
 1013696:	c7 85 38 ff ff ff 02 	movl   $0x2,-0xc8(%rbp)
 101369d:	00 00 00 
 10136a0:	c7 85 70 ff ff ff 01 	movl   $0x1,-0x90(%rbp)
 10136a7:	00 00 00 
 10136aa:	48 8b 45 a0          	mov    -0x60(%rbp),%rax
 10136ae:	48 89 45 e0          	mov    %rax,-0x20(%rbp)
 10136b2:	c7 85 70 ff ff ff 00 	movl   $0x0,-0x90(%rbp)
 10136b9:	00 00 00 
 10136bc:	48 8d 45 d8          	lea    -0x28(%rbp),%rax
 10136c0:	48 89 45 b8          	mov    %rax,-0x48(%rbp)
 10136c4:	48 8b 45 d8          	mov    -0x28(%rbp),%rax
 10136c8:	48 89 45 80          	mov    %rax,-0x80(%rbp)
 10136cc:	48 8b 45 e0          	mov    -0x20(%rbp),%rax
 10136d0:	48 89 45 88          	mov    %rax,-0x78(%rbp)
 10136d4:	48 8d 05 85 ae 01 00 	lea    0x1ae85(%rip),%rax        # 102e560 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 10136db:	48 89 85 e0 fe ff ff 	mov    %rax,-0x120(%rbp)
 10136e2:	c7 85 f8 fe ff ff 02 	movl   $0x2,-0x108(%rbp)
 10136e9:	00 00 00 
 10136ec:	c7 85 60 ff ff ff 01 	movl   $0x1,-0xa0(%rbp)
 10136f3:	00 00 00 
 10136f6:	48 8d 45 80          	lea    -0x80(%rbp),%rax
 10136fa:	48 89 45 b8          	mov    %rax,-0x48(%rbp)
 10136fe:	c7 85 78 ff ff ff 00 	movl   $0x0,-0x88(%rbp)
 1013705:	00 00 00 
 1013708:	48 8b 45 80          	mov    -0x80(%rbp),%rax
 101370c:	48 83 f8 00          	cmp    $0x0,%rax
 1013710:	74 1a                	je     101372c <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xc8c>
 1013712:	48 83 e8 10          	sub    $0x10,%rax
 1013716:	48 8b 00             	mov    (%rax),%rax
 1013719:	48 b9 01 00 00 00 00 	movabs $0x5000000000000001,%rcx
 1013720:	00 00 50 
 1013723:	48 21 c8             	and    %rcx,%rax
 1013726:	48 83 f8 00          	cmp    $0x0,%rax
 101372a:	75 57                	jne    1013783 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xce3>
 101372c:	48 8b 45 88          	mov    -0x78(%rbp),%rax
 1013730:	48 83 f8 00          	cmp    $0x0,%rax
 1013734:	74 1a                	je     1013750 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xcb0>
 1013736:	48 83 e8 10          	sub    $0x10,%rax
 101373a:	48 8b 00             	mov    (%rax),%rax
 101373d:	48 b9 01 00 00 00 00 	movabs $0x5000000000000001,%rcx
 1013744:	00 00 50 
 1013747:	48 21 c8             	and    %rcx,%rax
 101374a:	48 83 f8 00          	cmp    $0x0,%rax
 101374e:	75 2e                	jne    101377e <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xcde>
 1013750:	48 8b 45 80          	mov    -0x80(%rbp),%rax
 1013754:	48 89 45 a0          	mov    %rax,-0x60(%rbp)
 1013758:	48 8b 45 88          	mov    -0x78(%rbp),%rax
 101375c:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
 1013760:	ba 10 00 00 00       	mov    $0x10,%edx
 1013765:	be 00 00 00 00       	mov    $0x0,%esi
 101376a:	48 89 fb             	mov    %rdi,%rbx
 101376d:	48 8d 7d 80          	lea    -0x80(%rbp),%rdi
 1013771:	e8 4a 68 01 00       	call   1029fc0 <compiler_rt.fastMemset>
 1013776:	48 89 df             	mov    %rbx,%rdi
 1013779:	e9 86 00 00 00       	jmp    1013804 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xd64>
 101377e:	48 87 fb             	xchg   %rdi,%rbx
 1013781:	eb 03                	jmp    1013786 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xce6>
 1013783:	48 87 fb             	xchg   %rdi,%rbx
 1013786:	48 8d 4d 80          	lea    -0x80(%rbp),%rcx
 101378a:	48 8d 55 a0          	lea    -0x60(%rbp),%rdx
 101378e:	48 8d 35 cb ad 01 00 	lea    0x1adcb(%rip),%rsi        # 102e560 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 1013795:	49 89 fc             	mov    %rdi,%r12
 1013798:	e8 33 63 01 00       	call   1029ad0 <myl_rc_native_take>
 101379d:	4c 89 e7             	mov    %r12,%rdi
 10137a0:	83 f8 00             	cmp    $0x0,%eax
 10137a3:	75 5c                	jne    1013801 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xd61>
 10137a5:	e8 f6 e2 00 00       	call   1021aa0 <myl_rc_take_failure>
 10137aa:	48 89 df             	mov    %rbx,%rdi
 10137ad:	89 c6                	mov    %eax,%esi
 10137af:	48 89 fb             	mov    %rdi,%rbx
 10137b2:	e8 b9 59 00 00       	call   1019170 <myl_qbe_rc_status>
 10137b7:	48 89 df             	mov    %rbx,%rdi
 10137ba:	48 8d b5 c0 fe ff ff 	lea    -0x140(%rbp),%rsi
 10137c1:	48 89 fb             	mov    %rdi,%rbx
 10137c4:	e8 a7 5c 00 00       	call   1019470 <myl_qbe_rc_frame_cleanup>
 10137c9:	48 89 df             	mov    %rbx,%rdi
 10137cc:	48 8d b5 c0 fe ff ff 	lea    -0x140(%rbp),%rsi
 10137d3:	e8 08 5b 00 00       	call   10192e0 <myl_qbe_rc_frame_leave>
 10137d8:	ba 10 00 00 00       	mov    $0x10,%edx
 10137dd:	be 00 00 00 00       	mov    $0x0,%esi
 10137e2:	48 8d bd b0 fe ff ff 	lea    -0x150(%rbp),%rdi
 10137e9:	e8 d2 67 01 00       	call   1029fc0 <compiler_rt.fastMemset>
 10137ee:	48 8b 85 b0 fe ff ff 	mov    -0x150(%rbp),%rax
 10137f5:	48 8b 95 b8 fe ff ff 	mov    -0x148(%rbp),%rdx
 10137fc:	e9 9f 00 00 00       	jmp    10138a0 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xe00>
 1013801:	48 89 df             	mov    %rbx,%rdi
 1013804:	c7 85 60 ff ff ff 00 	movl   $0x0,-0xa0(%rbp)
 101380b:	00 00 00 
 101380e:	48 8d 05 4b ad 01 00 	lea    0x1ad4b(%rip),%rax        # 102e560 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 1013815:	48 89 85 20 ff ff ff 	mov    %rax,-0xe0(%rbp)
 101381c:	c7 85 38 ff ff ff 02 	movl   $0x2,-0xc8(%rbp)
 1013823:	00 00 00 
 1013826:	c7 85 70 ff ff ff 01 	movl   $0x1,-0x90(%rbp)
 101382d:	00 00 00 
 1013830:	c7 85 70 ff ff ff 00 	movl   $0x0,-0x90(%rbp)
 1013837:	00 00 00 
 101383a:	48 8d b5 c0 fe ff ff 	lea    -0x140(%rbp),%rsi
 1013841:	48 89 fb             	mov    %rdi,%rbx
 1013844:	e8 27 5c 00 00       	call   1019470 <myl_qbe_rc_frame_cleanup>
 1013849:	48 89 df             	mov    %rbx,%rdi
 101384c:	48 8d b5 c0 fe ff ff 	lea    -0x140(%rbp),%rsi
 1013853:	e8 88 5a 00 00       	call   10192e0 <myl_qbe_rc_frame_leave>
 1013858:	48 8b 45 a0          	mov    -0x60(%rbp),%rax
 101385c:	48 8b 55 a8          	mov    -0x58(%rbp),%rdx
 1013860:	eb 3e                	jmp    10138a0 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xe00>
 1013862:	4c 89 ea             	mov    %r13,%rdx
 1013865:	41 b8 40 00 00 00    	mov    $0x40,%r8d
 101386b:	b9 01 00 00 00       	mov    $0x1,%ecx
 1013870:	be 01 00 00 00       	mov    $0x1,%esi
 1013875:	e8 96 61 00 00       	call   1019a10 <myl_qbe_fail_overflow_op>
 101387a:	0f 0b                	ud2
 101387c:	48 c7 85 b0 fe ff ff 	movq   $0x0,-0x150(%rbp)
 1013883:	00 00 00 00 
 1013887:	48 c7 85 b8 fe ff ff 	movq   $0x0,-0x148(%rbp)
 101388e:	00 00 00 00 
 1013892:	48 8b 85 b0 fe ff ff 	mov    -0x150(%rbp),%rax
 1013899:	48 8b 95 b8 fe ff ff 	mov    -0x148(%rbp),%rdx
 10138a0:	41 5f                	pop    %r15
 10138a2:	41 5e                	pop    %r14
 10138a4:	41 5d                	pop    %r13
 10138a6:	41 5c                	pop    %r12
 10138a8:	5b                   	pop    %rbx
 10138a9:	c9                   	leave
 10138aa:	c3                   	ret
 10138ab:	e8 b0 62 00 00       	call   1019b60 <myl_qbe_fail_frame>
 10138b0:	0f 0b                	ud2

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
