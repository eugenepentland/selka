import pathlib,subprocess,json,hashlib,statistics
r=pathlib.Path.cwd();w=r/'.tmp-rc/empty-scopes/full';c=r/'.tmp-rc/install-empty-scopes/bin/mylang';base=r/'.tmp-rc/empty-locals/full';data={'compiler_sha256':hashlib.sha256(c.read_bytes()).hexdigest(),'builds':[],'runs':[],'medians':{}}
def save(): (w/'results.json').write_text(json.dumps(data,indent=2)+'\n')
expected=None
for backend in ['qbe','llvm']:
 for stats in [False,True]:
  b=w/(backend+('-stats' if stats else '-rc'))
  cmd=[str(r/'scripts/build-slot.sh'),'build',str(c),'build',str(r/'bench/parity/suite/nbody.my'),'-o',str(b),'--cache-dir='+str(w/'cache'),'--keep-symbols','--rc-runtime'+('=stats' if stats else '')]
  cmd+=['--release'] if backend=='llvm' else ['--mode','ReleaseFast']
  p=subprocess.run(cmd,text=True,capture_output=True);row=dict(command=cmd,status=p.returncode,stdout=p.stdout,stderr=p.stderr);data['builds'].append(row);save();assert p.returncode==0,row
  row['binary_sha256']=hashlib.sha256(b.read_bytes()).hexdigest();save()
  if stats:
   for side,binary in [('before',base/f'{backend}-stats'),('after',b)]:
    p=subprocess.run(['taskset','-c','10',str(binary)],text=True,capture_output=True);row=dict(backend=backend,side=side,stats=True,status=p.returncode,stdout=p.stdout,stderr=p.stderr,binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest());data['runs'].append(row);save();assert p.returncode==0 and p.stdout==expected,row
    row['counts']=json.loads(next(line.removeprefix('MYLANG_RC_COUNTS ') for line in p.stderr.splitlines() if line.startswith('MYLANG_RC_COUNTS ')));save()
   pair=[a['counts'] for a in data['runs'] if a.get('stats') and a['backend']==backend];assert pair[0]==pair[1],pair
  else:
   for side,binary in [('before',base/f'{backend}-rc'),('after',b)]:
    counts=[]
    for repeat in range(3):
     stat=w/f'{side}-{backend}-{repeat}.stat';cmd=['taskset','-c','10','perf','stat','-x,','-e','instructions:u','-o',str(stat),str(binary)]
     p=subprocess.run(cmd,text=True,capture_output=True);raw=stat.read_text();count=next(int(line.split(',')[0]) for line in raw.splitlines() if 'instructions' in line and line.split(',')[0].isdigit())
     row=dict(command=cmd,backend=backend,side=side,repeat=repeat,status=p.returncode,stdout=p.stdout,stderr=p.stderr,perf=raw,instructions=count,binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest());data['runs'].append(row);save();assert p.returncode==0,row
     if expected is None: expected=p.stdout
     assert p.stdout==expected,row
     counts.append(count)
    data['medians'][side+'-'+backend]=statistics.median(counts);save()
   print(backend,data['medians']['after-'+backend]/data['medians']['before-'+backend],flush=True)
