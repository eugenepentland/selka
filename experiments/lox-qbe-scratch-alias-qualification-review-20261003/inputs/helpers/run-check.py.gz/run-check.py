from pathlib import Path
import hashlib, json, os, subprocess, sys, time

work = Path(__file__).resolve().parent
own = work.parent
name, kind = sys.argv[1:3]
argv = [str(own / 'scripts/build-slot.sh'), kind] + sys.argv[3:]
env = {k: v for k, v in os.environ.items() if not k.startswith('MYLANG_') and k != 'LD_PRELOAD'}
env['TMPDIR'] = str(work / 'tmp')
env['ZIG_GLOBAL_CACHE_DIR'] = str(work / 'zig-global')
row = {'argv': argv, 'cwd': str(own), 'environment': {k: env[k] for k in ['TMPDIR', 'ZIG_GLOBAL_CACHE_DIR']}, 'started': time.time(), 'helper_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
log = work / (name + '.log')
with log.open('wb') as out:
    run = subprocess.run(argv, cwd=own, env=env, stdout=out, stderr=subprocess.STDOUT)
row.update(status=run.returncode, finished=time.time(), log_sha256=hashlib.sha256(log.read_bytes()).hexdigest())
(work / (name + '.json')).write_text(json.dumps(row, indent=2) + '\n')
print(json.dumps(row), flush=True)
sys.exit(run.returncode)
