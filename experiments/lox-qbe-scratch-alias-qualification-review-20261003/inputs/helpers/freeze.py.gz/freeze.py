from pathlib import Path
import hashlib, json

OWN = Path(__file__).resolve().parents[1]
WORK = Path(__file__).resolve().parent
AUTHOR = OWN / '.tmp-lox-scratch-alias-20261003'
ROOT = OWN.parent / 'codex-lox-parity-20261003'
LOWER = OWN.parent / 'codex-lox-parity-lowering-20261003'
COMPILER = AUTHOR / 'compiler-final'
CONTROL = LOWER / '.tmp-lox-lowering/cfg-fix-release'
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
files = lambda root: {str(p.relative_to(root)): sha(p) for p in sorted(root.rglob('*')) if p.is_file()}


def registry():
    path = WORK / 'helper-source.json'
    descriptor = json.loads(path.read_text())
    actual = {name: sha(WORK / name) for name in descriptor['files']}
    assert actual == descriptor['files']
    return {'descriptor_sha256': sha(path), 'files_sha256': actual}


def snapshot(guests=(), helpers=()):
    path = AUTHOR / 'frozen-source-final.json'
    assert sha(path) == '69e21a1133e1230285565df05d748242e0d7de5adb34775a51ce463be2363637'
    d = json.loads(path.read_text())
    core = {name: sha(OWN / name) for name in d['core']}
    frozen = {name: sha(WORK / 'frozen-core' / name) for name in d['core']}
    assert core == frozen == d['core']
    candidate37, control37 = files(AUTHOR / 'selected-ast'), files(ROOT / '.tmp-lox-round3/ast')
    assert candidate37 == control37 == d['source37']
    prefixes = {name: {part: files(prefix / part) for part in ['bin', 'lib']} for name, prefix in [('candidate', COMPILER), ('control', CONTROL)]}
    assert prefixes['candidate']['bin']['mylang'] == d['compiler_final']['sha256']
    assert prefixes['candidate']['bin']['qbe'] == '99ad919d70ad582dee6202b045bd53e1ab18fec356de98849610f49983756d63'
    artifacts = {str(p): sha(p) for p in helpers}
    for binary in guests:
        binary = Path(binary)
        manifest = Path(str(binary) + '.qbe-manifest.json')
        for p in [binary, manifest, Path(str(binary) + '.qbe-receipt')]:
            artifacts[str(p)] = sha(p)
        runtime = Path(json.loads(manifest.read_text())['runtime_object'])
        artifacts[str(runtime)] = sha(runtime)
    return {'core_source_sha256': core, 'core_descriptor_sha256': sha(path), 'candidate37': candidate37, 'control37': control37, 'compiler_prefixes_sha256': prefixes, 'helpers': registry(), 'artifacts_sha256': artifacts}
