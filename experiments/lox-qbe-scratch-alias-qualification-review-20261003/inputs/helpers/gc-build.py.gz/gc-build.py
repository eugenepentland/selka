from pathlib import Path
from datetime import datetime, timezone
import json, subprocess, os
from freeze import snapshot, sha, OWN, WORK, AUTHOR, COMPILER

env = {k: v for k, v in os.environ.items() if not k.startswith('MYLANG_') and k != 'LD_PRELOAD'}
env['TMPDIR'] = str(WORK / 'tmp')
env['ZIG_GLOBAL_CACHE_DIR'] = str(WORK / 'zig-global')
source = AUTHOR / 'selected-ast'
rc = [AUTHOR / ('bin/static-v2-' + b) for b in ['llvm', 'qbe']]
before = snapshot(guests=rc)
receipt = {'before': before, 'builds': [], 'verified_after': False}
output = WORK / 'gc-build.json'
assert not output.exists()
for backend in ['qbe', 'llvm']:
    binary = WORK / ('bin/gc-' + backend)
    argv = [str(OWN / 'scripts/build-slot.sh'), 'build', str(COMPILER / 'bin/mylang'), 'build', str(source / 'main.my'), '--project', '--backend', backend, '--gc-runtime', '--keep-symbols', '--cache-dir', str(WORK / ('cache-gc-' + backend)), '-o', str(binary)]
    if backend == 'qbe':
        argv += ['--qbe', str(COMPILER / 'bin/qbe')]
    else:
        argv += ['--llvm-opt', '3', '--lto']
    row = {'argv': argv, 'cwd': str(OWN), 'environment': {k: env[k] for k in ['TMPDIR', 'ZIG_GLOBAL_CACHE_DIR']}, 'started_utc': datetime.now(timezone.utc).isoformat()}
    log = WORK / ('gc-' + backend + '.log')
    with log.open('wb') as out:
        run = subprocess.run(argv, cwd=OWN, env=env, stdout=out, stderr=subprocess.STDOUT)
    row.update(status=run.returncode, finished_utc=datetime.now(timezone.utc).isoformat(), log_sha256=sha(log))
    receipt['builds'].append(row)
    output.write_text(json.dumps(receipt, indent=2) + '\n')
    assert run.returncode == 0, log
    manifest = Path(str(binary) + '.qbe-manifest.json')
    archive = Path(json.loads(manifest.read_text())['runtime_object'])
    row.update(binary=str(binary), binary_sha256=sha(binary), manifest_sha256=sha(manifest), receipt_sha256=sha(str(binary) + '.qbe-receipt'), runtime_object=str(archive), runtime_object_sha256=sha(archive))
    print(json.dumps(row), flush=True)
after = snapshot(guests=rc)
assert before == after
receipt.update(after=after, verified_after=True, produced_artifacts=snapshot(guests=rc + [WORK / ('bin/gc-' + b) for b in ['llvm', 'qbe']]))
output.write_text(json.dumps(receipt, indent=2) + '\n')
