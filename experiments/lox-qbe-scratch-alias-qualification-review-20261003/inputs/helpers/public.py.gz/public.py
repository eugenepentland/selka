from pathlib import Path
import json, os, re, subprocess
from freeze import snapshot, sha, OWN, WORK, AUTHOR, COMPILER

source = AUTHOR / 'selected-ast'
compiler = COMPILER / 'bin/mylang'
guests = [AUTHOR / ('bin/static-v2-' + b) for b in ['llvm', 'qbe']] + [WORK / ('bin/gc-' + b) for b in ['llvm', 'qbe']]
env = {k: v for k, v in os.environ.items() if not k.startswith('MYLANG_') and k != 'LD_PRELOAD'}
env['TMPDIR'] = str(WORK / 'tmp')
env['ZIG_GLOBAL_CACHE_DIR'] = str(WORK / 'zig-global')
assert not set(os.sched_getaffinity(0)) & {2, 3, 10, 11}
before = snapshot(guests=guests)
receipt = {'before': before, 'runs': [], 'verified_after': False}
output = WORK / 'public.json'
assert not output.exists()
names = sorted(f.stem + '::' + n for f in source.glob('*.my') for n in re.findall(r'^public def (test_[A-Za-z0-9_]+)\(', f.read_text(), re.M))
assert len(names) == 84
for backend in ['llvm', 'qbe']:
    for runtime in ['rc', 'gc-stress']:
        key = 'public-' + backend + '-' + runtime
        argv = [str(OWN / 'scripts/build-slot.sh'), 'build', str(compiler), 'test', str(source), '--json', '--jobs', '2', '--max-steps', '1000000000', '--timeout-ms', '120000', '--cache-dir', str(WORK / ('cache-' + key))]
        argv += ['--release'] if backend == 'llvm' else ['--mode', 'ReleaseFast']
        argv += ['--rc-runtime'] if runtime == 'rc' else ['--gc-stress']
        log, err = WORK / (key + '.json'), WORK / (key + '.stderr')
        print('Testing', key, flush=True)
        with log.open('wb') as stdout, err.open('wb') as stderr:
            run = subprocess.run(argv, cwd=OWN, env=env, stdout=stdout, stderr=stderr, timeout=900)
        row = {'argv': argv, 'cwd': str(OWN), 'environment': {k: env[k] for k in ['TMPDIR', 'ZIG_GLOBAL_CACHE_DIR']}, 'status': run.returncode, 'log': str(log), 'log_sha256': sha(log), 'stderr': str(err), 'stderr_sha256': sha(err)}
        receipt['runs'].append(row)
        output.write_text(json.dumps(receipt, indent=2) + '\n')
        assert run.returncode == 0, log
        report = json.loads(log.read_text())
        counts = {k: report[k] for k in ['passed', 'failed', 'skipped', 'cached', 'executed', 'dropped', 'unloaded', 'programs']}
        assert counts == {'passed': 84, 'failed': 0, 'skipped': 0, 'cached': 0, 'executed': 84, 'dropped': 0, 'unloaded': 0, 'programs': 10}
        assert sorted(x['name'] for x in report['tests']) == names
        assert all(x['status'] == 'passed' and x['actual'] is True and x['provider'] == '' for x in report['tests'])
        row.update(counts=counts, provider_identity='')
after = snapshot(guests=guests)
assert before == after
receipt.update(after=after, verified_after=True, fresh_public_passes=336, provider_scope='No --cases; every provider identity empty; clock fixture structural preservation only.')
output.write_text(json.dumps(receipt, indent=2) + '\n')
print('All336 fresh public passes; whole helpers/core/prefix/guest window unchanged', flush=True)
