
/home/epentland/ai/canopy/mylang-worktrees/codex-lox-variant-number-tag-20261003/.tmp-lox-variant-number-tag-20261003/number-tag-stable-rc-qbe:     file format elf64-x86-64


Disassembly of section .text:

0000000001137720 <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c>:
 1137720:	endbr64
 1137724:	push   %rbp
 1137725:	mov    %rsp,%rbp
 1137728:	sub    $0x178,%rsp
 113772f:	push   %rbx
 1137730:	push   %r12
 1137732:	push   %r13
 1137734:	push   %r14
 1137736:	push   %r15
 1137738:	mov    %rcx,%r12
 113773b:	mov    %rdx,%r15
 113773e:	mov    %rsi,%r14
 1137741:	mov    0x40(%rdi),%rax
 1137745:	lea    -0x8(%rbp),%rcx
 1137749:	cmp    %rax,%rcx
 113774c:	jb     1137ff0 <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x8d0>
 1137752:	mov    %rdi,%rbx
 1137755:	call   115abc0 <myl_qbe_heap>
 113775a:	mov    %rbx,%rdi
 113775d:	mov    %rax,%rbx
 1137760:	mov    %rdi,%r13
 1137763:	call   115d720 <myl_qbe_region_mark>
 1137768:	mov    %r15,%rdx
 113776b:	mov    %r14,%rsi
 113776e:	mov    %r13,%rdi
 1137771:	mov    0x80(%rsi),%r13
 1137778:	movabs $0x8000000000000001,%rax
 1137782:	cmp    %rax,%r13
 1137785:	jl     1137fd6 <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x8b6>
 113778b:	mov    %rsi,%r11
 113778e:	add    $0x78,%r11
 1137792:	mov    0x78(%rsi),%r9
 1137796:	mov    (%r9),%r10
 1137799:	mov    %r13,%rax
 113779c:	sub    $0x1,%rax
 11377a0:	cmp    %r10,%rax
 11377a3:	setb   %cl
 11377a6:	movzbq %cl,%rcx
 11377aa:	cmp    $0x0,%ecx
 11377ad:	jne    113783d <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x11d>
 11377b3:	cmp    $0x0,%rax
 11377b7:	jl     11377be <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x9e>
 11377b9:	mov    %rax,%r14
 11377bc:	jmp    11377e8 <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0xc8>
 11377be:	movabs $0x7fffffffffffffff,%rcx
 11377c8:	cmp    %rcx,%r10
 11377cb:	ja     113782e <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x10e>
 11377cd:	mov    %r10,%r14
 11377d0:	add    %rax,%r14
 11377d3:	mov    %r10,%rcx
 11377d6:	xor    %r14,%rcx
 11377d9:	mov    %rax,%r8
 11377dc:	xor    %r14,%r8
 11377df:	and    %r8,%rcx
 11377e2:	cmp    $0x0,%rcx
 11377e6:	jl     1137813 <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0xf3>
 11377e8:	cmp    %r10,%r14
 11377eb:	jb     1137803 <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0xe3>
 11377ed:	mov    %r14,%rdx
 11377f0:	mov    %r10,%rsi
 11377f3:	mov    %rdx,%r10
 11377f6:	mov    %rsi,%rdx
 11377f9:	mov    %r10,%rsi
 11377fc:	call   115a800 <myl_qbe_fail_normalized_index_bounds>
 1137801:	ud2
 1137803:	mov    %r14,%r10
 1137806:	mov    0x20(%r9),%rcx
 113780a:	imul   $0x10,%r10,%r8
 113780e:	add    %r8,%rcx
 1137811:	jmp    1137848 <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x128>
 1137813:	mov    %r10,%rsi
 1137816:	mov    $0x40,%r8d
 113781c:	mov    %rax,%rcx
 113781f:	mov    %rsi,%rdx
 1137822:	mov    $0x0,%esi
 1137827:	call   115aa10 <myl_qbe_fail_overflow_op>
 113782c:	ud2
 113782e:	mov    %r10,%rsi
 1137831:	mov    $0x140,%edx
 1137836:	call   115ab50 <myl_qbe_fail_cast>
 113783b:	ud2
 113783d:	mov    0x20(%r9),%rcx
 1137841:	imul   $0x10,%rax,%r8
 1137845:	add    %r8,%rcx
 1137848:	mov    (%rcx),%r8d
 113784b:	cmp    $0x0,%r8
 113784f:	je     1137f3b <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x81b>
 1137855:	cmp    $0x1,%r8
 1137859:	je     1137e9f <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x77f>
 113785f:	cmp    $0x2,%r8
 1137863:	je     1137912 <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x1f2>
 1137869:	mov    %r8,%rax
 113786c:	cmp    $0x3,%rax
 1137870:	jne    1137cb0 <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x590>
 1137876:	mov    0xfaeeb(%rip),%rcx        # 1232768 <myl_lit_705b80a2adbffde33673cee9517989a5dbc62d5a47d462ddbd71f5170464b997>
 113787d:	mov    %rcx,-0x160(%rbp)
 1137884:	mov    -0x160(%rbp),%rax
 113788b:	mov    %rax,-0x158(%rbp)
 1137892:	mov    -0x158(%rbp),%rax
 1137899:	mov    %rax,-0x168(%rbp)
 11378a0:	call   1128240 <myl_f_8855e2338a0239644fa6d8638afc594de302f594debc25ce542a382b2a6572a1>
 11378a5:	mov    %rbx,%rdi
 11378a8:	mov    -0x168(%rbp),%rdx
 11378af:	cmp    $0x0,%rdx
 11378b3:	je     1137fcb <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x8ab>
 11378b9:	mov    -0x10(%rdx),%rcx
 11378bd:	movabs $0x4000000000000002,%rsi
 11378c7:	and    %rsi,%rcx
 11378ca:	cmp    $0x0,%rcx
 11378ce:	jne    1137902 <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x1e2>
 11378d0:	mov    -0x20(%rdx),%rcx
 11378d4:	sub    $0x1,%rcx
 11378d8:	jne    11378fe <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x1de>
 11378da:	mov    %rax,%rbx
 11378dd:	mov    -0x18(%rdx),%rax
 11378e1:	cmp    $0x0,%rax
 11378e5:	jne    11378fb <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x1db>
 11378e7:	lea    -0x168(%rbp),%rsi
 11378ee:	call   113f3a0 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop>
 11378f3:	mov    %rbx,%rax
 11378f6:	jmp    1137fcb <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x8ab>
 11378fb:	mov    %rbx,%rax
 11378fe:	mov    %rcx,-0x20(%rdx)
 1137902:	movq   $0x0,-0x168(%rbp)
 113790d:	jmp    1137fcb <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x8ab>
 1137912:	mov    0x8(%rcx),%r8
 1137916:	mov    %r8,-0x158(%rbp)
 113791d:	movabs $0x8000000000000001,%rcx
 1137927:	cmp    %rcx,%rax
 113792a:	jl     1137e85 <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x765>
 1137930:	mov    (%r9),%r10
 1137933:	mov    %r13,%rcx
 1137936:	sub    $0x2,%rcx
 113793a:	cmp    %r10,%rcx
 113793d:	setb   %r13b
 1137941:	movzbq %r13b,%r13
 1137945:	cmp    $0x0,%r13d
 1137949:	jne    11379c9 <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x2a9>
 113794b:	cmp    $0x0,%rcx
 113794f:	jl     1137956 <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x236>
 1137951:	mov    %rcx,%r13
 1137954:	jmp    1137980 <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x260>
 1137956:	movabs $0x7fffffffffffffff,%r13
 1137960:	cmp    %r13,%r10
 1137963:	ja     11379ba <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x29a>
 1137965:	mov    %r10,%r13
 1137968:	add    %rcx,%r13
 113796b:	mov    %r10,%r14
 113796e:	xor    %r13,%r14
 1137971:	mov    %rcx,%r15
 1137974:	xor    %r13,%r15
 1137977:	and    %r15,%r14
 113797a:	cmp    $0x0,%r14
 113797e:	jl     11379a2 <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x282>
 1137980:	cmp    %r10,%r13
 1137983:	jb     1137995 <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x275>
 1137985:	mov    %r10,%rsi
 1137988:	mov    %rsi,%rdx
 113798b:	mov    %r13,%rsi
 113798e:	call   115a800 <myl_qbe_fail_normalized_index_bounds>
 1137993:	ud2
 1137995:	mov    0x20(%r9),%r9
 1137999:	imul   $0x10,%r13,%r10
 113799d:	add    %r10,%r9
 11379a0:	jmp    11379d4 <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x2b4>
 11379a2:	mov    %r10,%rsi
 11379a5:	mov    $0x40,%r8d
 11379ab:	mov    %rsi,%rdx
 11379ae:	mov    $0x0,%esi
 11379b3:	call   115aa10 <myl_qbe_fail_overflow_op>
 11379b8:	ud2
 11379ba:	mov    %r10,%rsi
 11379bd:	mov    $0x140,%edx
 11379c2:	call   115ab50 <myl_qbe_fail_cast>
 11379c7:	ud2
 11379c9:	mov    0x20(%r9),%r9
 11379cd:	imul   $0x10,%rcx,%r10
 11379d1:	add    %r10,%r9
 11379d4:	mov    (%r9),%r10d
 11379d7:	cmp    $0x0,%r10
 11379db:	je     1137de9 <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x6c9>
 11379e1:	cmp    $0x1,%r10
 11379e5:	je     1137d4d <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x62d>
 11379eb:	cmp    $0x2,%r10
 11379ef:	je     1137a9e <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x37e>
 11379f5:	mov    %r10,%rax
 11379f8:	cmp    $0x3,%rax
 11379fc:	jne    1137cb0 <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x590>
 1137a02:	mov    0xfad5f(%rip),%rcx        # 1232768 <myl_lit_705b80a2adbffde33673cee9517989a5dbc62d5a47d462ddbd71f5170464b997>
 1137a09:	mov    %rcx,-0x160(%rbp)
 1137a10:	mov    -0x160(%rbp),%rax
 1137a17:	mov    %rax,-0x158(%rbp)
 1137a1e:	mov    -0x158(%rbp),%rax
 1137a25:	mov    %rax,-0x168(%rbp)
 1137a2c:	call   1128240 <myl_f_8855e2338a0239644fa6d8638afc594de302f594debc25ce542a382b2a6572a1>
 1137a31:	mov    %rbx,%rdi
 1137a34:	mov    -0x168(%rbp),%rdx
 1137a3b:	cmp    $0x0,%rdx
 1137a3f:	je     1137fcb <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x8ab>
 1137a45:	mov    -0x10(%rdx),%rcx
 1137a49:	movabs $0x4000000000000002,%rsi
 1137a53:	and    %rsi,%rcx
 1137a56:	cmp    $0x0,%rcx
 1137a5a:	jne    1137a8e <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x36e>
 1137a5c:	mov    -0x20(%rdx),%rcx
 1137a60:	sub    $0x1,%rcx
 1137a64:	jne    1137a8a <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x36a>
 1137a66:	mov    %rax,%rbx
 1137a69:	mov    -0x18(%rdx),%rax
 1137a6d:	cmp    $0x0,%rax
 1137a71:	jne    1137a87 <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x367>
 1137a73:	lea    -0x168(%rbp),%rsi
 1137a7a:	call   113f3a0 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop>
 1137a7f:	mov    %rbx,%rax
 1137a82:	jmp    1137fcb <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x8ab>
 1137a87:	mov    %rbx,%rax
 1137a8a:	mov    %rcx,-0x20(%rdx)
 1137a8e:	movq   $0x0,-0x168(%rbp)
 1137a99:	jmp    1137fcb <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x8ab>
 1137a9e:	mov    %r11,%rdx
 1137aa1:	mov    %r12,%rbx
 1137aa4:	mov    0x8(%r9),%r9
 1137aa8:	mov    %r9,-0x158(%rbp)
 1137aaf:	movq   $0x0,-0x68(%rbp)
 1137ab7:	movq   $0x0,-0x60(%rbp)
 1137abf:	movl   $0x0,-0x68(%rbp)
 1137ac6:	mov    -0x68(%rbp),%r10
 1137aca:	mov    %r10,-0x88(%rbp)
 1137ad1:	mov    -0x60(%rbp),%r10
 1137ad5:	mov    %r10,-0x80(%rbp)
 1137ad9:	movq   %r9,%xmm1
 1137ade:	movq   %r8,%xmm0
 1137ae3:	cmp    $0x10,%rbx
 1137ae7:	je     1137c09 <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x4e9>
 1137aed:	cmp    $0x11,%rbx
 1137af1:	je     1137bcd <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x4ad>
 1137af7:	cmp    $0x13,%rbx
 1137afb:	je     1137b8b <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x46b>
 1137b01:	cmp    $0x14,%rbx
 1137b05:	je     1137b4e <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x42e>
 1137b07:	movsd  %xmm0,%xmm15
 1137b0c:	movsd  %xmm1,%xmm0
 1137b10:	divsd  %xmm15,%xmm0
 1137b15:	movq   %xmm0,%r8
 1137b1a:	movq   $0x0,-0x18(%rbp)
 1137b22:	movq   $0x0,-0x10(%rbp)
 1137b2a:	movq   $0x2,-0x18(%rbp)
 1137b32:	mov    %r8,-0x10(%rbp)
 1137b36:	mov    -0x18(%rbp),%r8
 1137b3a:	mov    %r8,-0x88(%rbp)
 1137b41:	mov    -0x10(%rbp),%r8
 1137b45:	mov    %r8,-0x80(%rbp)
 1137b49:	jmp    1137c43 <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x523>
 1137b4e:	mulsd  %xmm1,%xmm0
 1137b52:	movq   %xmm0,%r8
 1137b57:	movq   $0x0,-0x28(%rbp)
 1137b5f:	movq   $0x0,-0x20(%rbp)
 1137b67:	movq   $0x2,-0x28(%rbp)
 1137b6f:	mov    %r8,-0x20(%rbp)
 1137b73:	mov    -0x28(%rbp),%r8
 1137b77:	mov    %r8,-0x88(%rbp)
 1137b7e:	mov    -0x20(%rbp),%r8
 1137b82:	mov    %r8,-0x80(%rbp)
 1137b86:	jmp    1137c43 <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x523>
 1137b8b:	xorpd  -0x1113b3(%rip),%xmm0        # 10267e0 <__stop_mylang_frame_map+0x20>
 1137b93:	addsd  %xmm1,%xmm0
 1137b97:	movq   %xmm0,%r8
 1137b9c:	movq   $0x0,-0x38(%rbp)
 1137ba4:	movq   $0x0,-0x30(%rbp)
 1137bac:	movq   $0x2,-0x38(%rbp)
 1137bb4:	mov    %r8,-0x30(%rbp)
 1137bb8:	mov    -0x38(%rbp),%r8
 1137bbc:	mov    %r8,-0x88(%rbp)
 1137bc3:	mov    -0x30(%rbp),%r8
 1137bc7:	mov    %r8,-0x80(%rbp)
 1137bcb:	jmp    1137c43 <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x523>
 1137bcd:	ucomisd %xmm1,%xmm0
 1137bd1:	seta   %r8b
 1137bd5:	movzbq %r8b,%r8
 1137bd9:	movq   $0x0,-0x48(%rbp)
 1137be1:	movq   $0x0,-0x40(%rbp)
 1137be9:	movl   $0x1,-0x48(%rbp)
 1137bf0:	mov    %r8b,-0x40(%rbp)
 1137bf4:	mov    -0x48(%rbp),%r8
 1137bf8:	mov    %r8,-0x88(%rbp)
 1137bff:	mov    -0x40(%rbp),%r8
 1137c03:	mov    %r8,-0x80(%rbp)
 1137c07:	jmp    1137c43 <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x523>
 1137c09:	ucomisd %xmm0,%xmm1
 1137c0d:	seta   %r8b
 1137c11:	movzbq %r8b,%r8
 1137c15:	movq   $0x0,-0x58(%rbp)
 1137c1d:	movq   $0x0,-0x50(%rbp)
 1137c25:	movl   $0x1,-0x58(%rbp)
 1137c2c:	mov    %r8b,-0x50(%rbp)
 1137c30:	mov    -0x58(%rbp),%r8
 1137c34:	mov    %r8,-0x88(%rbp)
 1137c3b:	mov    -0x50(%rbp),%r8
 1137c3f:	mov    %r8,-0x80(%rbp)
 1137c43:	mov    %rax,0x80(%rsi)
 1137c4a:	mov    -0x88(%rbp),%rax
 1137c51:	mov    %rax,-0x78(%rbp)
 1137c55:	mov    -0x80(%rbp),%rax
 1137c59:	mov    %rax,-0x70(%rbp)
 1137c5d:	mov    0x78(%rsi),%rax
 1137c61:	cmp    $0x0,%rax
 1137c65:	je     1137cba <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x59a>
 1137c67:	mov    -0x10(%rax),%r8
 1137c6b:	movabs $0x6000000000000002,%r9
 1137c75:	and    %r9,%r8
 1137c78:	cmp    $0x0,%r8
 1137c7c:	jne    1137c88 <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x568>
 1137c7e:	mov    -0x20(%rax),%rax
 1137c82:	cmp    $0x2,%rax
 1137c86:	jb     1137cba <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x59a>
 1137c88:	mov    %rcx,%r13
 1137c8b:	mov    $0x0,%ecx
 1137c90:	mov    %rsi,%r12
 1137c93:	lea    0xf257e(%rip),%rsi        # 122a218 <myl_t_a1fa53db408c85388cfd14badb361c2a89e74ce2a863fa83774cb6942b74317a>
 1137c9a:	mov    %rdi,%rbx
 1137c9d:	call   115a090 <myl_qbe_rc_unique_field>
 1137ca2:	mov    %r13,%rcx
 1137ca5:	mov    %r12,%rsi
 1137ca8:	mov    %rbx,%rdi
 1137cab:	cmp    $0x0,%eax
 1137cae:	jne    1137cba <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x59a>
 1137cb0:	mov    $0x0,%eax
 1137cb5:	jmp    1137fcb <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x8ab>
 1137cba:	mov    0x78(%rsi),%rax
 1137cbe:	cmp    $0x0,%rcx
 1137cc2:	jge    1137cf4 <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x5d4>
 1137cc4:	mov    (%rax),%rsi
 1137cc7:	movabs $0x7fffffffffffffff,%rdx
 1137cd1:	cmp    %rdx,%rsi
 1137cd4:	ja     1137d41 <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x621>
 1137cd6:	mov    %rsi,%rbx
 1137cd9:	add    %rcx,%rbx
 1137cdc:	mov    %rsi,%rdx
 1137cdf:	xor    %rbx,%rdx
 1137ce2:	mov    %rcx,%r8
 1137ce5:	xor    %rbx,%r8
 1137ce8:	and    %r8,%rdx
 1137ceb:	cmp    $0x0,%rdx
 1137cef:	jl     1137d2c <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x60c>
 1137cf1:	mov    %rbx,%rcx
 1137cf4:	mov    (%rax),%rdx
 1137cf7:	cmp    %rdx,%rcx
 1137cfa:	jb     1137d06 <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x5e6>
 1137cfc:	mov    %rcx,%rsi
 1137cff:	call   115a800 <myl_qbe_fail_normalized_index_bounds>
 1137d04:	ud2
 1137d06:	mov    %rcx,%rbx
 1137d09:	mov    0x20(%rax),%rcx
 1137d0d:	imul   $0x10,%rbx,%rdx
 1137d11:	mov    -0x78(%rbp),%rax
 1137d15:	mov    %rax,(%rcx,%rdx,1)
 1137d19:	mov    -0x70(%rbp),%rax
 1137d1d:	mov    %rax,0x8(%rcx,%rdx,1)
 1137d22:	mov    $0x1,%eax
 1137d27:	jmp    1137fcb <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x8ab>
 1137d2c:	mov    $0x40,%r8d
 1137d32:	mov    %rsi,%rdx
 1137d35:	mov    $0x0,%esi
 1137d3a:	call   115aa10 <myl_qbe_fail_overflow_op>
 1137d3f:	ud2
 1137d41:	mov    $0x140,%edx
 1137d46:	call   115ab50 <myl_qbe_fail_cast>
 1137d4b:	ud2
 1137d4d:	mov    0xfaa14(%rip),%rcx        # 1232768 <myl_lit_705b80a2adbffde33673cee9517989a5dbc62d5a47d462ddbd71f5170464b997>
 1137d54:	mov    %rcx,-0x160(%rbp)
 1137d5b:	mov    -0x160(%rbp),%rax
 1137d62:	mov    %rax,-0x158(%rbp)
 1137d69:	mov    -0x158(%rbp),%rax
 1137d70:	mov    %rax,-0x168(%rbp)
 1137d77:	call   1128240 <myl_f_8855e2338a0239644fa6d8638afc594de302f594debc25ce542a382b2a6572a1>
 1137d7c:	mov    %rbx,%rdi
 1137d7f:	mov    -0x168(%rbp),%rdx
 1137d86:	cmp    $0x0,%rdx
 1137d8a:	je     1137fcb <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x8ab>
 1137d90:	mov    -0x10(%rdx),%rcx
 1137d94:	movabs $0x4000000000000002,%rsi
 1137d9e:	and    %rsi,%rcx
 1137da1:	cmp    $0x0,%rcx
 1137da5:	jne    1137dd9 <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x6b9>
 1137da7:	mov    -0x20(%rdx),%rcx
 1137dab:	sub    $0x1,%rcx
 1137daf:	jne    1137dd5 <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x6b5>
 1137db1:	mov    %rax,%rbx
 1137db4:	mov    -0x18(%rdx),%rax
 1137db8:	cmp    $0x0,%rax
 1137dbc:	jne    1137dd2 <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x6b2>
 1137dbe:	lea    -0x168(%rbp),%rsi
 1137dc5:	call   113f3a0 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop>
 1137dca:	mov    %rbx,%rax
 1137dcd:	jmp    1137fcb <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x8ab>
 1137dd2:	mov    %rbx,%rax
 1137dd5:	mov    %rcx,-0x20(%rdx)
 1137dd9:	movq   $0x0,-0x168(%rbp)
 1137de4:	jmp    1137fcb <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x8ab>
 1137de9:	mov    0xfa978(%rip),%rcx        # 1232768 <myl_lit_705b80a2adbffde33673cee9517989a5dbc62d5a47d462ddbd71f5170464b997>
 1137df0:	mov    %rcx,-0x160(%rbp)
 1137df7:	mov    -0x160(%rbp),%rax
 1137dfe:	mov    %rax,-0x158(%rbp)
 1137e05:	mov    -0x158(%rbp),%rax
 1137e0c:	mov    %rax,-0x168(%rbp)
 1137e13:	call   1128240 <myl_f_8855e2338a0239644fa6d8638afc594de302f594debc25ce542a382b2a6572a1>
 1137e18:	mov    %rbx,%rdi
 1137e1b:	mov    -0x168(%rbp),%rdx
 1137e22:	cmp    $0x0,%rdx
 1137e26:	je     1137fcb <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x8ab>
 1137e2c:	mov    -0x10(%rdx),%rcx
 1137e30:	movabs $0x4000000000000002,%rsi
 1137e3a:	and    %rsi,%rcx
 1137e3d:	cmp    $0x0,%rcx
 1137e41:	jne    1137e75 <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x755>
 1137e43:	mov    -0x20(%rdx),%rcx
 1137e47:	sub    $0x1,%rcx
 1137e4b:	jne    1137e71 <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x751>
 1137e4d:	mov    %rax,%rbx
 1137e50:	mov    -0x18(%rdx),%rax
 1137e54:	cmp    $0x0,%rax
 1137e58:	jne    1137e6e <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x74e>
 1137e5a:	lea    -0x168(%rbp),%rsi
 1137e61:	call   113f3a0 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop>
 1137e66:	mov    %rbx,%rax
 1137e69:	jmp    1137fcb <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x8ab>
 1137e6e:	mov    %rbx,%rax
 1137e71:	mov    %rcx,-0x20(%rdx)
 1137e75:	movq   $0x0,-0x168(%rbp)
 1137e80:	jmp    1137fcb <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x8ab>
 1137e85:	mov    %rax,%rdx
 1137e88:	mov    $0x40,%r8d
 1137e8e:	mov    $0x1,%ecx
 1137e93:	mov    $0x1,%esi
 1137e98:	call   115aa10 <myl_qbe_fail_overflow_op>
 1137e9d:	ud2
 1137e9f:	mov    0xfa8c2(%rip),%rcx        # 1232768 <myl_lit_705b80a2adbffde33673cee9517989a5dbc62d5a47d462ddbd71f5170464b997>
 1137ea6:	mov    %rcx,-0x160(%rbp)
 1137ead:	mov    -0x160(%rbp),%rax
 1137eb4:	mov    %rax,-0x158(%rbp)
 1137ebb:	mov    -0x158(%rbp),%rax
 1137ec2:	mov    %rax,-0x168(%rbp)
 1137ec9:	call   1128240 <myl_f_8855e2338a0239644fa6d8638afc594de302f594debc25ce542a382b2a6572a1>
 1137ece:	mov    %rbx,%rdi
 1137ed1:	mov    -0x168(%rbp),%rdx
 1137ed8:	cmp    $0x0,%rdx
 1137edc:	je     1137fcb <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x8ab>
 1137ee2:	mov    -0x10(%rdx),%rcx
 1137ee6:	movabs $0x4000000000000002,%rsi
 1137ef0:	and    %rsi,%rcx
 1137ef3:	cmp    $0x0,%rcx
 1137ef7:	jne    1137f2b <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x80b>
 1137ef9:	mov    -0x20(%rdx),%rcx
 1137efd:	sub    $0x1,%rcx
 1137f01:	jne    1137f27 <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x807>
 1137f03:	mov    %rax,%rbx
 1137f06:	mov    -0x18(%rdx),%rax
 1137f0a:	cmp    $0x0,%rax
 1137f0e:	jne    1137f24 <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x804>
 1137f10:	lea    -0x168(%rbp),%rsi
 1137f17:	call   113f3a0 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop>
 1137f1c:	mov    %rbx,%rax
 1137f1f:	jmp    1137fcb <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x8ab>
 1137f24:	mov    %rbx,%rax
 1137f27:	mov    %rcx,-0x20(%rdx)
 1137f2b:	movq   $0x0,-0x168(%rbp)
 1137f36:	jmp    1137fcb <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x8ab>
 1137f3b:	mov    0xfa826(%rip),%rcx        # 1232768 <myl_lit_705b80a2adbffde33673cee9517989a5dbc62d5a47d462ddbd71f5170464b997>
 1137f42:	mov    %rcx,-0x160(%rbp)
 1137f49:	mov    -0x160(%rbp),%rax
 1137f50:	mov    %rax,-0x158(%rbp)
 1137f57:	mov    -0x158(%rbp),%rax
 1137f5e:	mov    %rax,-0x168(%rbp)
 1137f65:	call   1128240 <myl_f_8855e2338a0239644fa6d8638afc594de302f594debc25ce542a382b2a6572a1>
 1137f6a:	mov    %rbx,%rdi
 1137f6d:	mov    -0x168(%rbp),%rdx
 1137f74:	cmp    $0x0,%rdx
 1137f78:	je     1137fcb <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x8ab>
 1137f7a:	mov    -0x10(%rdx),%rcx
 1137f7e:	movabs $0x4000000000000002,%rsi
 1137f88:	and    %rsi,%rcx
 1137f8b:	cmp    $0x0,%rcx
 1137f8f:	jne    1137fc0 <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x8a0>
 1137f91:	mov    -0x20(%rdx),%rcx
 1137f95:	sub    $0x1,%rcx
 1137f99:	jne    1137fbc <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x89c>
 1137f9b:	mov    %rax,%rbx
 1137f9e:	mov    -0x18(%rdx),%rax
 1137fa2:	cmp    $0x0,%rax
 1137fa6:	jne    1137fb9 <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x899>
 1137fa8:	lea    -0x168(%rbp),%rsi
 1137faf:	call   113f3a0 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop>
 1137fb4:	mov    %rbx,%rax
 1137fb7:	jmp    1137fcb <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x8ab>
 1137fb9:	mov    %rbx,%rax
 1137fbc:	mov    %rcx,-0x20(%rdx)
 1137fc0:	movq   $0x0,-0x168(%rbp)
 1137fcb:	pop    %r15
 1137fcd:	pop    %r14
 1137fcf:	pop    %r13
 1137fd1:	pop    %r12
 1137fd3:	pop    %rbx
 1137fd4:	leave
 1137fd5:	ret
 1137fd6:	mov    %r13,%rdx
 1137fd9:	mov    $0x40,%r8d
 1137fdf:	mov    $0x1,%ecx
 1137fe4:	mov    $0x1,%esi
 1137fe9:	call   115aa10 <myl_qbe_fail_overflow_op>
 1137fee:	ud2
 1137ff0:	call   115abd0 <myl_qbe_fail_frame>
 1137ff5:	ud2

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
