
/home/epentland/ai/canopy/mylang-worktrees/codex-lox-variant-number-tag-20261003/.tmp-lox-variant-number-tag-20261003/number-tag-stable-rc-qbe:     file format elf64-x86-64


Disassembly of section .text:

0000000001124700 <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0>:
 1124700:	endbr64
 1124704:	push   %rbp
 1124705:	mov    %rsp,%rbp
 1124708:	sub    $0x140,%rsp
 112470f:	push   %rbx
 1124710:	push   %r12
 1124712:	push   %r13
 1124714:	push   %r14
 1124716:	mov    %rdx,%r14
 1124719:	mov    %rsi,%r13
 112471c:	mov    0x40(%rdi),%rax
 1124720:	lea    -0x8(%rbp),%rcx
 1124724:	cmp    %rax,%rcx
 1124727:	jb     1124f2b <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x82b>
 112472d:	mov    %rdi,%rbx
 1124730:	call   115abc0 <myl_qbe_heap>
 1124735:	mov    %rbx,%rdi
 1124738:	mov    %rax,%rbx
 112473b:	mov    %rdi,%r12
 112473e:	call   115d720 <myl_qbe_region_mark>
 1124743:	mov    %r14,%rdx
 1124746:	mov    %r13,%rsi
 1124749:	mov    %r12,%rdi
 112474c:	mov    %rdx,%r12
 112474f:	mov    $0x0,%edx
 1124754:	mov    %rsi,%r14
 1124757:	mov    %rdi,%r13
 112475a:	call   1097020 <myl_f_851eb64c403b25f3166dffdb17dfc9e3c924451c20caa5851a74e0f4081ba50f>
 112475f:	mov    %r14,%rsi
 1124762:	mov    %r13,%rdi
 1124765:	mov    %rax,%rcx
 1124768:	mov    %rdx,%rax
 112476b:	mov    %r12,%rdx
 112476e:	mov    %rcx,-0x138(%rbp)
 1124775:	mov    %rax,-0x130(%rbp)
 112477c:	mov    %rdx,%r14
 112477f:	lea    -0x138(%rbp),%rdx
 1124786:	mov    %rsi,%r13
 1124789:	mov    %rdi,%r12
 112478c:	call   1139550 <myl_f_b47aab62b34d4c5fea9afee963024b599e9447bd2b8c27c83d4c94aea0b8b6b3>
 1124791:	mov    %r14,%rdx
 1124794:	mov    %r13,%rsi
 1124797:	mov    %r12,%rdi
 112479a:	cmp    $0x0,%eax
 112479d:	jne    11247a6 <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0xa6>
 112479f:	mov    $0x0,%eax
 11247a4:	jmp    11247f4 <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0xf4>
 11247a6:	mov    %rdx,%r12
 11247a9:	mov    $0x1,%edx
 11247ae:	mov    %rsi,%r14
 11247b1:	mov    %rdi,%r13
 11247b4:	call   1097020 <myl_f_851eb64c403b25f3166dffdb17dfc9e3c924451c20caa5851a74e0f4081ba50f>
 11247b9:	mov    %r14,%rsi
 11247bc:	mov    %r13,%rdi
 11247bf:	mov    %rax,%rcx
 11247c2:	mov    %rdx,%rax
 11247c5:	mov    %r12,%rdx
 11247c8:	mov    %rcx,-0x128(%rbp)
 11247cf:	mov    %rax,-0x120(%rbp)
 11247d6:	mov    %rdx,%r14
 11247d9:	lea    -0x128(%rbp),%rdx
 11247e0:	mov    %rsi,%r13
 11247e3:	mov    %rdi,%r12
 11247e6:	call   1139550 <myl_f_b47aab62b34d4c5fea9afee963024b599e9447bd2b8c27c83d4c94aea0b8b6b3>
 11247eb:	mov    %r14,%rdx
 11247ee:	mov    %r13,%rsi
 11247f1:	mov    %r12,%rdi
 11247f4:	cmp    $0x0,%eax
 11247f7:	jne    1124f18 <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x818>
 11247fd:	mov    0x80(%rsi),%r12
 1124804:	movabs $0x8000000000000001,%rax
 112480e:	cmp    %rax,%r12
 1124811:	jl     1124efe <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x7fe>
 1124817:	mov    %rsi,%r11
 112481a:	add    $0x78,%r11
 112481e:	mov    0x78(%rsi),%r9
 1124822:	mov    (%r9),%r10
 1124825:	mov    %r12,%rax
 1124828:	sub    $0x1,%rax
 112482c:	cmp    %r10,%rax
 112482f:	setb   %cl
 1124832:	movzbq %cl,%rcx
 1124836:	cmp    $0x0,%ecx
 1124839:	jne    11248c9 <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x1c9>
 112483f:	cmp    $0x0,%rax
 1124843:	jl     112484a <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x14a>
 1124845:	mov    %rax,%r13
 1124848:	jmp    1124874 <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x174>
 112484a:	movabs $0x7fffffffffffffff,%rcx
 1124854:	cmp    %rcx,%r10
 1124857:	ja     11248ba <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x1ba>
 1124859:	mov    %r10,%r13
 112485c:	add    %rax,%r13
 112485f:	mov    %r10,%rcx
 1124862:	xor    %r13,%rcx
 1124865:	mov    %rax,%r8
 1124868:	xor    %r13,%r8
 112486b:	and    %r8,%rcx
 112486e:	cmp    $0x0,%rcx
 1124872:	jl     112489f <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x19f>
 1124874:	cmp    %r10,%r13
 1124877:	jb     112488f <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x18f>
 1124879:	mov    %r13,%rdx
 112487c:	mov    %r10,%rsi
 112487f:	mov    %rdx,%r10
 1124882:	mov    %rsi,%rdx
 1124885:	mov    %r10,%rsi
 1124888:	call   115a800 <myl_qbe_fail_normalized_index_bounds>
 112488d:	ud2
 112488f:	mov    %r13,%r10
 1124892:	mov    0x20(%r9),%rcx
 1124896:	imul   $0x10,%r10,%r8
 112489a:	add    %r8,%rcx
 112489d:	jmp    11248d4 <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x1d4>
 112489f:	mov    %r10,%rsi
 11248a2:	mov    $0x40,%r8d
 11248a8:	mov    %rax,%rcx
 11248ab:	mov    %rsi,%rdx
 11248ae:	mov    $0x0,%esi
 11248b3:	call   115aa10 <myl_qbe_fail_overflow_op>
 11248b8:	ud2
 11248ba:	mov    %r10,%rsi
 11248bd:	mov    $0x140,%edx
 11248c2:	call   115ab50 <myl_qbe_fail_cast>
 11248c7:	ud2
 11248c9:	mov    0x20(%r9),%rcx
 11248cd:	imul   $0x10,%rax,%r8
 11248d1:	add    %r8,%rcx
 11248d4:	mov    (%rcx),%r8d
 11248d7:	cmp    $0x0,%r8
 11248db:	je     1124e6c <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x76c>
 11248e1:	cmp    $0x1,%r8
 11248e5:	je     1124dd0 <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x6d0>
 11248eb:	cmp    $0x2,%r8
 11248ef:	je     112499e <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x29e>
 11248f5:	mov    %r8,%rax
 11248f8:	cmp    $0x3,%rax
 11248fc:	jne    1124be1 <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x4e1>
 1124902:	mov    0x10dd77(%rip),%rcx        # 1232680 <myl_lit_4e8cfc313e5d17fa73eb3c68075707ac391b284630fd27670b213105e8e5ed9b>
 1124909:	mov    %rcx,-0x110(%rbp)
 1124910:	mov    -0x110(%rbp),%rax
 1124917:	mov    %rax,-0x108(%rbp)
 112491e:	mov    -0x108(%rbp),%rax
 1124925:	mov    %rax,-0x118(%rbp)
 112492c:	call   1128240 <myl_f_8855e2338a0239644fa6d8638afc594de302f594debc25ce542a382b2a6572a1>
 1124931:	mov    %rbx,%rdi
 1124934:	mov    -0x118(%rbp),%rdx
 112493b:	cmp    $0x0,%rdx
 112493f:	je     1124f22 <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x822>
 1124945:	mov    -0x10(%rdx),%rcx
 1124949:	movabs $0x4000000000000002,%rsi
 1124953:	and    %rsi,%rcx
 1124956:	cmp    $0x0,%rcx
 112495a:	jne    112498e <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x28e>
 112495c:	mov    -0x20(%rdx),%rcx
 1124960:	sub    $0x1,%rcx
 1124964:	jne    112498a <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x28a>
 1124966:	mov    %rax,%rbx
 1124969:	mov    -0x18(%rdx),%rax
 112496d:	cmp    $0x0,%rax
 1124971:	jne    1124987 <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x287>
 1124973:	lea    -0x118(%rbp),%rsi
 112497a:	call   113f3a0 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop>
 112497f:	mov    %rbx,%rax
 1124982:	jmp    1124f22 <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x822>
 1124987:	mov    %rbx,%rax
 112498a:	mov    %rcx,-0x20(%rdx)
 112498e:	movq   $0x0,-0x118(%rbp)
 1124999:	jmp    1124f22 <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x822>
 112499e:	mov    0x8(%rcx),%r8
 11249a2:	mov    %r8,-0x108(%rbp)
 11249a9:	movabs $0x8000000000000001,%rcx
 11249b3:	cmp    %rcx,%rax
 11249b6:	jl     1124db6 <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x6b6>
 11249bc:	mov    (%r9),%r10
 11249bf:	mov    %r12,%rcx
 11249c2:	sub    $0x2,%rcx
 11249c6:	cmp    %r10,%rcx
 11249c9:	setb   %r12b
 11249cd:	movzbq %r12b,%r12
 11249d1:	cmp    $0x0,%r12d
 11249d5:	jne    1124a55 <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x355>
 11249d7:	cmp    $0x0,%rcx
 11249db:	jl     11249e2 <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x2e2>
 11249dd:	mov    %rcx,%r12
 11249e0:	jmp    1124a0c <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x30c>
 11249e2:	movabs $0x7fffffffffffffff,%r12
 11249ec:	cmp    %r12,%r10
 11249ef:	ja     1124a46 <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x346>
 11249f1:	mov    %r10,%r12
 11249f4:	add    %rcx,%r12
 11249f7:	mov    %r10,%r13
 11249fa:	xor    %r12,%r13
 11249fd:	mov    %rcx,%r14
 1124a00:	xor    %r12,%r14
 1124a03:	and    %r14,%r13
 1124a06:	cmp    $0x0,%r13
 1124a0a:	jl     1124a2e <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x32e>
 1124a0c:	cmp    %r10,%r12
 1124a0f:	jb     1124a21 <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x321>
 1124a11:	mov    %r10,%rsi
 1124a14:	mov    %rsi,%rdx
 1124a17:	mov    %r12,%rsi
 1124a1a:	call   115a800 <myl_qbe_fail_normalized_index_bounds>
 1124a1f:	ud2
 1124a21:	mov    0x20(%r9),%r9
 1124a25:	imul   $0x10,%r12,%r10
 1124a29:	add    %r10,%r9
 1124a2c:	jmp    1124a60 <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x360>
 1124a2e:	mov    %r10,%rsi
 1124a31:	mov    $0x40,%r8d
 1124a37:	mov    %rsi,%rdx
 1124a3a:	mov    $0x0,%esi
 1124a3f:	call   115aa10 <myl_qbe_fail_overflow_op>
 1124a44:	ud2
 1124a46:	mov    %r10,%rsi
 1124a49:	mov    $0x140,%edx
 1124a4e:	call   115ab50 <myl_qbe_fail_cast>
 1124a53:	ud2
 1124a55:	mov    0x20(%r9),%r9
 1124a59:	imul   $0x10,%rcx,%r10
 1124a5d:	add    %r10,%r9
 1124a60:	mov    (%r9),%r10d
 1124a63:	cmp    $0x0,%r10
 1124a67:	je     1124d1a <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x61a>
 1124a6d:	cmp    $0x1,%r10
 1124a71:	je     1124c7e <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x57e>
 1124a77:	cmp    $0x2,%r10
 1124a7b:	je     1124b2a <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x42a>
 1124a81:	mov    %r10,%rax
 1124a84:	cmp    $0x3,%rax
 1124a88:	jne    1124be1 <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x4e1>
 1124a8e:	mov    0x10dbeb(%rip),%rcx        # 1232680 <myl_lit_4e8cfc313e5d17fa73eb3c68075707ac391b284630fd27670b213105e8e5ed9b>
 1124a95:	mov    %rcx,-0x110(%rbp)
 1124a9c:	mov    -0x110(%rbp),%rax
 1124aa3:	mov    %rax,-0x108(%rbp)
 1124aaa:	mov    -0x108(%rbp),%rax
 1124ab1:	mov    %rax,-0x118(%rbp)
 1124ab8:	call   1128240 <myl_f_8855e2338a0239644fa6d8638afc594de302f594debc25ce542a382b2a6572a1>
 1124abd:	mov    %rbx,%rdi
 1124ac0:	mov    -0x118(%rbp),%rdx
 1124ac7:	cmp    $0x0,%rdx
 1124acb:	je     1124f22 <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x822>
 1124ad1:	mov    -0x10(%rdx),%rcx
 1124ad5:	movabs $0x4000000000000002,%rsi
 1124adf:	and    %rsi,%rcx
 1124ae2:	cmp    $0x0,%rcx
 1124ae6:	jne    1124b1a <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x41a>
 1124ae8:	mov    -0x20(%rdx),%rcx
 1124aec:	sub    $0x1,%rcx
 1124af0:	jne    1124b16 <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x416>
 1124af2:	mov    %rax,%rbx
 1124af5:	mov    -0x18(%rdx),%rax
 1124af9:	cmp    $0x0,%rax
 1124afd:	jne    1124b13 <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x413>
 1124aff:	lea    -0x118(%rbp),%rsi
 1124b06:	call   113f3a0 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop>
 1124b0b:	mov    %rbx,%rax
 1124b0e:	jmp    1124f22 <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x822>
 1124b13:	mov    %rbx,%rax
 1124b16:	mov    %rcx,-0x20(%rdx)
 1124b1a:	movq   $0x0,-0x118(%rbp)
 1124b25:	jmp    1124f22 <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x822>
 1124b2a:	mov    %r11,%rdx
 1124b2d:	mov    0x8(%r9),%r9
 1124b31:	mov    %r9,-0x108(%rbp)
 1124b38:	movq   %r9,%xmm0
 1124b3d:	movq   %r8,%xmm1
 1124b42:	addsd  %xmm1,%xmm0
 1124b46:	movq   %xmm0,%r8
 1124b4b:	movq   $0x0,-0x18(%rbp)
 1124b53:	movq   $0x0,-0x10(%rbp)
 1124b5b:	movq   $0x2,-0x18(%rbp)
 1124b63:	mov    %r8,-0x10(%rbp)
 1124b67:	mov    -0x18(%rbp),%r8
 1124b6b:	mov    %r8,-0x38(%rbp)
 1124b6f:	mov    -0x10(%rbp),%r8
 1124b73:	mov    %r8,-0x30(%rbp)
 1124b77:	mov    %rax,0x80(%rsi)
 1124b7e:	mov    -0x38(%rbp),%rax
 1124b82:	mov    %rax,-0x28(%rbp)
 1124b86:	mov    -0x30(%rbp),%rax
 1124b8a:	mov    %rax,-0x20(%rbp)
 1124b8e:	mov    0x78(%rsi),%rax
 1124b92:	cmp    $0x0,%rax
 1124b96:	je     1124beb <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x4eb>
 1124b98:	mov    -0x10(%rax),%r8
 1124b9c:	movabs $0x6000000000000002,%r9
 1124ba6:	and    %r9,%r8
 1124ba9:	cmp    $0x0,%r8
 1124bad:	jne    1124bb9 <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x4b9>
 1124baf:	mov    -0x20(%rax),%rax
 1124bb3:	cmp    $0x2,%rax
 1124bb7:	jb     1124beb <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x4eb>
 1124bb9:	mov    %rcx,%r13
 1124bbc:	mov    $0x0,%ecx
 1124bc1:	mov    %rsi,%r12
 1124bc4:	lea    0x10564d(%rip),%rsi        # 122a218 <myl_t_a1fa53db408c85388cfd14badb361c2a89e74ce2a863fa83774cb6942b74317a>
 1124bcb:	mov    %rdi,%rbx
 1124bce:	call   115a090 <myl_qbe_rc_unique_field>
 1124bd3:	mov    %r13,%rcx
 1124bd6:	mov    %r12,%rsi
 1124bd9:	mov    %rbx,%rdi
 1124bdc:	cmp    $0x0,%eax
 1124bdf:	jne    1124beb <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x4eb>
 1124be1:	mov    $0x0,%eax
 1124be6:	jmp    1124f22 <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x822>
 1124beb:	mov    0x78(%rsi),%rax
 1124bef:	cmp    $0x0,%rcx
 1124bf3:	jge    1124c25 <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x525>
 1124bf5:	mov    (%rax),%rsi
 1124bf8:	movabs $0x7fffffffffffffff,%rdx
 1124c02:	cmp    %rdx,%rsi
 1124c05:	ja     1124c72 <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x572>
 1124c07:	mov    %rsi,%rbx
 1124c0a:	add    %rcx,%rbx
 1124c0d:	mov    %rsi,%rdx
 1124c10:	xor    %rbx,%rdx
 1124c13:	mov    %rcx,%r8
 1124c16:	xor    %rbx,%r8
 1124c19:	and    %r8,%rdx
 1124c1c:	cmp    $0x0,%rdx
 1124c20:	jl     1124c5d <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x55d>
 1124c22:	mov    %rbx,%rcx
 1124c25:	mov    (%rax),%rdx
 1124c28:	cmp    %rdx,%rcx
 1124c2b:	jb     1124c37 <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x537>
 1124c2d:	mov    %rcx,%rsi
 1124c30:	call   115a800 <myl_qbe_fail_normalized_index_bounds>
 1124c35:	ud2
 1124c37:	mov    %rcx,%rbx
 1124c3a:	mov    0x20(%rax),%rcx
 1124c3e:	imul   $0x10,%rbx,%rdx
 1124c42:	mov    -0x28(%rbp),%rax
 1124c46:	mov    %rax,(%rcx,%rdx,1)
 1124c4a:	mov    -0x20(%rbp),%rax
 1124c4e:	mov    %rax,0x8(%rcx,%rdx,1)
 1124c53:	mov    $0x1,%eax
 1124c58:	jmp    1124f22 <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x822>
 1124c5d:	mov    $0x40,%r8d
 1124c63:	mov    %rsi,%rdx
 1124c66:	mov    $0x0,%esi
 1124c6b:	call   115aa10 <myl_qbe_fail_overflow_op>
 1124c70:	ud2
 1124c72:	mov    $0x140,%edx
 1124c77:	call   115ab50 <myl_qbe_fail_cast>
 1124c7c:	ud2
 1124c7e:	mov    0x10d9fb(%rip),%rcx        # 1232680 <myl_lit_4e8cfc313e5d17fa73eb3c68075707ac391b284630fd27670b213105e8e5ed9b>
 1124c85:	mov    %rcx,-0x110(%rbp)
 1124c8c:	mov    -0x110(%rbp),%rax
 1124c93:	mov    %rax,-0x108(%rbp)
 1124c9a:	mov    -0x108(%rbp),%rax
 1124ca1:	mov    %rax,-0x118(%rbp)
 1124ca8:	call   1128240 <myl_f_8855e2338a0239644fa6d8638afc594de302f594debc25ce542a382b2a6572a1>
 1124cad:	mov    %rbx,%rdi
 1124cb0:	mov    -0x118(%rbp),%rdx
 1124cb7:	cmp    $0x0,%rdx
 1124cbb:	je     1124f22 <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x822>
 1124cc1:	mov    -0x10(%rdx),%rcx
 1124cc5:	movabs $0x4000000000000002,%rsi
 1124ccf:	and    %rsi,%rcx
 1124cd2:	cmp    $0x0,%rcx
 1124cd6:	jne    1124d0a <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x60a>
 1124cd8:	mov    -0x20(%rdx),%rcx
 1124cdc:	sub    $0x1,%rcx
 1124ce0:	jne    1124d06 <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x606>
 1124ce2:	mov    %rax,%rbx
 1124ce5:	mov    -0x18(%rdx),%rax
 1124ce9:	cmp    $0x0,%rax
 1124ced:	jne    1124d03 <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x603>
 1124cef:	lea    -0x118(%rbp),%rsi
 1124cf6:	call   113f3a0 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop>
 1124cfb:	mov    %rbx,%rax
 1124cfe:	jmp    1124f22 <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x822>
 1124d03:	mov    %rbx,%rax
 1124d06:	mov    %rcx,-0x20(%rdx)
 1124d0a:	movq   $0x0,-0x118(%rbp)
 1124d15:	jmp    1124f22 <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x822>
 1124d1a:	mov    0x10d95f(%rip),%rcx        # 1232680 <myl_lit_4e8cfc313e5d17fa73eb3c68075707ac391b284630fd27670b213105e8e5ed9b>
 1124d21:	mov    %rcx,-0x110(%rbp)
 1124d28:	mov    -0x110(%rbp),%rax
 1124d2f:	mov    %rax,-0x108(%rbp)
 1124d36:	mov    -0x108(%rbp),%rax
 1124d3d:	mov    %rax,-0x118(%rbp)
 1124d44:	call   1128240 <myl_f_8855e2338a0239644fa6d8638afc594de302f594debc25ce542a382b2a6572a1>
 1124d49:	mov    %rbx,%rdi
 1124d4c:	mov    -0x118(%rbp),%rdx
 1124d53:	cmp    $0x0,%rdx
 1124d57:	je     1124f22 <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x822>
 1124d5d:	mov    -0x10(%rdx),%rcx
 1124d61:	movabs $0x4000000000000002,%rsi
 1124d6b:	and    %rsi,%rcx
 1124d6e:	cmp    $0x0,%rcx
 1124d72:	jne    1124da6 <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x6a6>
 1124d74:	mov    -0x20(%rdx),%rcx
 1124d78:	sub    $0x1,%rcx
 1124d7c:	jne    1124da2 <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x6a2>
 1124d7e:	mov    %rax,%rbx
 1124d81:	mov    -0x18(%rdx),%rax
 1124d85:	cmp    $0x0,%rax
 1124d89:	jne    1124d9f <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x69f>
 1124d8b:	lea    -0x118(%rbp),%rsi
 1124d92:	call   113f3a0 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop>
 1124d97:	mov    %rbx,%rax
 1124d9a:	jmp    1124f22 <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x822>
 1124d9f:	mov    %rbx,%rax
 1124da2:	mov    %rcx,-0x20(%rdx)
 1124da6:	movq   $0x0,-0x118(%rbp)
 1124db1:	jmp    1124f22 <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x822>
 1124db6:	mov    %rax,%rdx
 1124db9:	mov    $0x40,%r8d
 1124dbf:	mov    $0x1,%ecx
 1124dc4:	mov    $0x1,%esi
 1124dc9:	call   115aa10 <myl_qbe_fail_overflow_op>
 1124dce:	ud2
 1124dd0:	mov    0x10d8a9(%rip),%rcx        # 1232680 <myl_lit_4e8cfc313e5d17fa73eb3c68075707ac391b284630fd27670b213105e8e5ed9b>
 1124dd7:	mov    %rcx,-0x110(%rbp)
 1124dde:	mov    -0x110(%rbp),%rax
 1124de5:	mov    %rax,-0x108(%rbp)
 1124dec:	mov    -0x108(%rbp),%rax
 1124df3:	mov    %rax,-0x118(%rbp)
 1124dfa:	call   1128240 <myl_f_8855e2338a0239644fa6d8638afc594de302f594debc25ce542a382b2a6572a1>
 1124dff:	mov    %rbx,%rdi
 1124e02:	mov    -0x118(%rbp),%rdx
 1124e09:	cmp    $0x0,%rdx
 1124e0d:	je     1124f22 <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x822>
 1124e13:	mov    -0x10(%rdx),%rcx
 1124e17:	movabs $0x4000000000000002,%rsi
 1124e21:	and    %rsi,%rcx
 1124e24:	cmp    $0x0,%rcx
 1124e28:	jne    1124e5c <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x75c>
 1124e2a:	mov    -0x20(%rdx),%rcx
 1124e2e:	sub    $0x1,%rcx
 1124e32:	jne    1124e58 <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x758>
 1124e34:	mov    %rax,%rbx
 1124e37:	mov    -0x18(%rdx),%rax
 1124e3b:	cmp    $0x0,%rax
 1124e3f:	jne    1124e55 <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x755>
 1124e41:	lea    -0x118(%rbp),%rsi
 1124e48:	call   113f3a0 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop>
 1124e4d:	mov    %rbx,%rax
 1124e50:	jmp    1124f22 <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x822>
 1124e55:	mov    %rbx,%rax
 1124e58:	mov    %rcx,-0x20(%rdx)
 1124e5c:	movq   $0x0,-0x118(%rbp)
 1124e67:	jmp    1124f22 <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x822>
 1124e6c:	mov    0x10d80d(%rip),%rcx        # 1232680 <myl_lit_4e8cfc313e5d17fa73eb3c68075707ac391b284630fd27670b213105e8e5ed9b>
 1124e73:	mov    %rcx,-0x110(%rbp)
 1124e7a:	mov    -0x110(%rbp),%rax
 1124e81:	mov    %rax,-0x108(%rbp)
 1124e88:	mov    -0x108(%rbp),%rax
 1124e8f:	mov    %rax,-0x118(%rbp)
 1124e96:	call   1128240 <myl_f_8855e2338a0239644fa6d8638afc594de302f594debc25ce542a382b2a6572a1>
 1124e9b:	mov    %rbx,%rdi
 1124e9e:	mov    -0x118(%rbp),%rdx
 1124ea5:	cmp    $0x0,%rdx
 1124ea9:	je     1124f22 <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x822>
 1124eab:	mov    -0x10(%rdx),%rcx
 1124eaf:	movabs $0x4000000000000002,%rsi
 1124eb9:	and    %rsi,%rcx
 1124ebc:	cmp    $0x0,%rcx
 1124ec0:	jne    1124ef1 <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x7f1>
 1124ec2:	mov    -0x20(%rdx),%rcx
 1124ec6:	sub    $0x1,%rcx
 1124eca:	jne    1124eed <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x7ed>
 1124ecc:	mov    %rax,%rbx
 1124ecf:	mov    -0x18(%rdx),%rax
 1124ed3:	cmp    $0x0,%rax
 1124ed7:	jne    1124eea <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x7ea>
 1124ed9:	lea    -0x118(%rbp),%rsi
 1124ee0:	call   113f3a0 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop>
 1124ee5:	mov    %rbx,%rax
 1124ee8:	jmp    1124f22 <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x822>
 1124eea:	mov    %rbx,%rax
 1124eed:	mov    %rcx,-0x20(%rdx)
 1124ef1:	movq   $0x0,-0x118(%rbp)
 1124efc:	jmp    1124f22 <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x822>
 1124efe:	mov    %r12,%rdx
 1124f01:	mov    $0x40,%r8d
 1124f07:	mov    $0x1,%ecx
 1124f0c:	mov    $0x1,%esi
 1124f11:	call   115aa10 <myl_qbe_fail_overflow_op>
 1124f16:	ud2
 1124f18:	call   113cb50 <myl_f_f04a28c8dfdceed2bc94d69e9c44787aee268d323f82bfda25644397e8e2282d>
 1124f1d:	mov    $0x1,%eax
 1124f22:	pop    %r14
 1124f24:	pop    %r13
 1124f26:	pop    %r12
 1124f28:	pop    %rbx
 1124f29:	leave
 1124f2a:	ret
 1124f2b:	call   115abd0 <myl_qbe_fail_frame>
 1124f30:	ud2

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
