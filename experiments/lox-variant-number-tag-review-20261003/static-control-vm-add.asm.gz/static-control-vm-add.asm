
/home/epentland/ai/canopy/mylang-worktrees/codex-lox-borrow-assert-20261003/.tmp-lox-borrow-assert-20261003/fixed-qbe-ast:     file format elf64-x86-64


Disassembly of section .text:

00000000011246e0 <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0>:
 11246e0:	endbr64
 11246e4:	push   %rbp
 11246e5:	mov    %rsp,%rbp
 11246e8:	sub    $0x140,%rsp
 11246ef:	push   %rbx
 11246f0:	push   %r12
 11246f2:	push   %r13
 11246f4:	push   %r14
 11246f6:	mov    %rdx,%r14
 11246f9:	mov    %rsi,%r13
 11246fc:	mov    0x40(%rdi),%rax
 1124700:	lea    -0x8(%rbp),%rcx
 1124704:	cmp    %rax,%rcx
 1124707:	jb     1124f0a <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x82a>
 112470d:	mov    %rdi,%rbx
 1124710:	call   115aba0 <myl_qbe_heap>
 1124715:	mov    %rbx,%rdi
 1124718:	mov    %rax,%rbx
 112471b:	mov    %rdi,%r12
 112471e:	call   115d700 <myl_qbe_region_mark>
 1124723:	mov    %r14,%rdx
 1124726:	mov    %r13,%rsi
 1124729:	mov    %r12,%rdi
 112472c:	mov    %rdx,%r12
 112472f:	mov    $0x0,%edx
 1124734:	mov    %rsi,%r14
 1124737:	mov    %rdi,%r13
 112473a:	call   1097020 <myl_f_851eb64c403b25f3166dffdb17dfc9e3c924451c20caa5851a74e0f4081ba50f>
 112473f:	mov    %r14,%rsi
 1124742:	mov    %r13,%rdi
 1124745:	mov    %rax,%rcx
 1124748:	mov    %rdx,%rax
 112474b:	mov    %r12,%rdx
 112474e:	mov    %rcx,-0x138(%rbp)
 1124755:	mov    %rax,-0x130(%rbp)
 112475c:	mov    %rdx,%r14
 112475f:	lea    -0x138(%rbp),%rdx
 1124766:	mov    %rsi,%r13
 1124769:	mov    %rdi,%r12
 112476c:	call   1139530 <myl_f_b47aab62b34d4c5fea9afee963024b599e9447bd2b8c27c83d4c94aea0b8b6b3>
 1124771:	mov    %r14,%rdx
 1124774:	mov    %r13,%rsi
 1124777:	mov    %r12,%rdi
 112477a:	cmp    $0x0,%eax
 112477d:	jne    1124786 <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0xa6>
 112477f:	mov    $0x0,%eax
 1124784:	jmp    11247d4 <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0xf4>
 1124786:	mov    %rdx,%r12
 1124789:	mov    $0x1,%edx
 112478e:	mov    %rsi,%r14
 1124791:	mov    %rdi,%r13
 1124794:	call   1097020 <myl_f_851eb64c403b25f3166dffdb17dfc9e3c924451c20caa5851a74e0f4081ba50f>
 1124799:	mov    %r14,%rsi
 112479c:	mov    %r13,%rdi
 112479f:	mov    %rax,%rcx
 11247a2:	mov    %rdx,%rax
 11247a5:	mov    %r12,%rdx
 11247a8:	mov    %rcx,-0x128(%rbp)
 11247af:	mov    %rax,-0x120(%rbp)
 11247b6:	mov    %rdx,%r14
 11247b9:	lea    -0x128(%rbp),%rdx
 11247c0:	mov    %rsi,%r13
 11247c3:	mov    %rdi,%r12
 11247c6:	call   1139530 <myl_f_b47aab62b34d4c5fea9afee963024b599e9447bd2b8c27c83d4c94aea0b8b6b3>
 11247cb:	mov    %r14,%rdx
 11247ce:	mov    %r13,%rsi
 11247d1:	mov    %r12,%rdi
 11247d4:	cmp    $0x0,%eax
 11247d7:	jne    1124ef7 <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x817>
 11247dd:	mov    0x80(%rsi),%r12
 11247e4:	movabs $0x8000000000000001,%rax
 11247ee:	cmp    %rax,%r12
 11247f1:	jl     1124edd <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x7fd>
 11247f7:	mov    %rsi,%r11
 11247fa:	add    $0x78,%r11
 11247fe:	mov    0x78(%rsi),%r9
 1124802:	mov    (%r9),%r10
 1124805:	mov    %r12,%rax
 1124808:	sub    $0x1,%rax
 112480c:	cmp    %r10,%rax
 112480f:	setb   %cl
 1124812:	movzbq %cl,%rcx
 1124816:	cmp    $0x0,%ecx
 1124819:	jne    11248a9 <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x1c9>
 112481f:	cmp    $0x0,%rax
 1124823:	jl     112482a <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x14a>
 1124825:	mov    %rax,%r13
 1124828:	jmp    1124854 <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x174>
 112482a:	movabs $0x7fffffffffffffff,%rcx
 1124834:	cmp    %rcx,%r10
 1124837:	ja     112489a <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x1ba>
 1124839:	mov    %r10,%r13
 112483c:	add    %rax,%r13
 112483f:	mov    %r10,%rcx
 1124842:	xor    %r13,%rcx
 1124845:	mov    %rax,%r8
 1124848:	xor    %r13,%r8
 112484b:	and    %r8,%rcx
 112484e:	cmp    $0x0,%rcx
 1124852:	jl     112487f <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x19f>
 1124854:	cmp    %r10,%r13
 1124857:	jb     112486f <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x18f>
 1124859:	mov    %r13,%rdx
 112485c:	mov    %r10,%rsi
 112485f:	mov    %rdx,%r10
 1124862:	mov    %rsi,%rdx
 1124865:	mov    %r10,%rsi
 1124868:	call   115a7e0 <myl_qbe_fail_normalized_index_bounds>
 112486d:	ud2
 112486f:	mov    %r13,%r10
 1124872:	mov    0x20(%r9),%rcx
 1124876:	imul   $0x10,%r10,%r8
 112487a:	add    %r8,%rcx
 112487d:	jmp    11248b4 <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x1d4>
 112487f:	mov    %r10,%rsi
 1124882:	mov    $0x40,%r8d
 1124888:	mov    %rax,%rcx
 112488b:	mov    %rsi,%rdx
 112488e:	mov    $0x0,%esi
 1124893:	call   115a9f0 <myl_qbe_fail_overflow_op>
 1124898:	ud2
 112489a:	mov    %r10,%rsi
 112489d:	mov    $0x140,%edx
 11248a2:	call   115ab30 <myl_qbe_fail_cast>
 11248a7:	ud2
 11248a9:	mov    0x20(%r9),%rcx
 11248ad:	imul   $0x10,%rax,%r8
 11248b1:	add    %r8,%rcx
 11248b4:	mov    (%rcx),%r8d
 11248b7:	cmp    $0x0,%r8
 11248bb:	je     1124e4b <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x76b>
 11248c1:	cmp    $0x1,%r8
 11248c5:	je     1124daf <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x6cf>
 11248cb:	cmp    $0x2,%r8
 11248cf:	je     112497e <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x29e>
 11248d5:	mov    %r8,%rax
 11248d8:	cmp    $0x3,%rax
 11248dc:	jne    1124bc0 <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x4e0>
 11248e2:	mov    0x10dd77(%rip),%rcx        # 1232660 <myl_lit_4e8cfc313e5d17fa73eb3c68075707ac391b284630fd27670b213105e8e5ed9b>
 11248e9:	mov    %rcx,-0x110(%rbp)
 11248f0:	mov    -0x110(%rbp),%rax
 11248f7:	mov    %rax,-0x108(%rbp)
 11248fe:	mov    -0x108(%rbp),%rax
 1124905:	mov    %rax,-0x118(%rbp)
 112490c:	call   1128220 <myl_f_8855e2338a0239644fa6d8638afc594de302f594debc25ce542a382b2a6572a1>
 1124911:	mov    %rbx,%rdi
 1124914:	mov    -0x118(%rbp),%rdx
 112491b:	cmp    $0x0,%rdx
 112491f:	je     1124f01 <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x821>
 1124925:	mov    -0x10(%rdx),%rcx
 1124929:	movabs $0x4000000000000002,%rsi
 1124933:	and    %rsi,%rcx
 1124936:	cmp    $0x0,%rcx
 112493a:	jne    112496e <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x28e>
 112493c:	mov    -0x20(%rdx),%rcx
 1124940:	sub    $0x1,%rcx
 1124944:	jne    112496a <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x28a>
 1124946:	mov    %rax,%rbx
 1124949:	mov    -0x18(%rdx),%rax
 112494d:	cmp    $0x0,%rax
 1124951:	jne    1124967 <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x287>
 1124953:	lea    -0x118(%rbp),%rsi
 112495a:	call   113f380 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop>
 112495f:	mov    %rbx,%rax
 1124962:	jmp    1124f01 <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x821>
 1124967:	mov    %rbx,%rax
 112496a:	mov    %rcx,-0x20(%rdx)
 112496e:	movq   $0x0,-0x118(%rbp)
 1124979:	jmp    1124f01 <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x821>
 112497e:	mov    0x8(%rcx),%r8
 1124982:	mov    %r8,-0x108(%rbp)
 1124989:	movabs $0x8000000000000001,%rcx
 1124993:	cmp    %rcx,%rax
 1124996:	jl     1124d95 <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x6b5>
 112499c:	mov    (%r9),%r10
 112499f:	mov    %r12,%rcx
 11249a2:	sub    $0x2,%rcx
 11249a6:	cmp    %r10,%rcx
 11249a9:	setb   %r12b
 11249ad:	movzbq %r12b,%r12
 11249b1:	cmp    $0x0,%r12d
 11249b5:	jne    1124a35 <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x355>
 11249b7:	cmp    $0x0,%rcx
 11249bb:	jl     11249c2 <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x2e2>
 11249bd:	mov    %rcx,%r12
 11249c0:	jmp    11249ec <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x30c>
 11249c2:	movabs $0x7fffffffffffffff,%r12
 11249cc:	cmp    %r12,%r10
 11249cf:	ja     1124a26 <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x346>
 11249d1:	mov    %r10,%r12
 11249d4:	add    %rcx,%r12
 11249d7:	mov    %r10,%r13
 11249da:	xor    %r12,%r13
 11249dd:	mov    %rcx,%r14
 11249e0:	xor    %r12,%r14
 11249e3:	and    %r14,%r13
 11249e6:	cmp    $0x0,%r13
 11249ea:	jl     1124a0e <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x32e>
 11249ec:	cmp    %r10,%r12
 11249ef:	jb     1124a01 <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x321>
 11249f1:	mov    %r10,%rsi
 11249f4:	mov    %rsi,%rdx
 11249f7:	mov    %r12,%rsi
 11249fa:	call   115a7e0 <myl_qbe_fail_normalized_index_bounds>
 11249ff:	ud2
 1124a01:	mov    0x20(%r9),%r9
 1124a05:	imul   $0x10,%r12,%r10
 1124a09:	add    %r10,%r9
 1124a0c:	jmp    1124a40 <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x360>
 1124a0e:	mov    %r10,%rsi
 1124a11:	mov    $0x40,%r8d
 1124a17:	mov    %rsi,%rdx
 1124a1a:	mov    $0x0,%esi
 1124a1f:	call   115a9f0 <myl_qbe_fail_overflow_op>
 1124a24:	ud2
 1124a26:	mov    %r10,%rsi
 1124a29:	mov    $0x140,%edx
 1124a2e:	call   115ab30 <myl_qbe_fail_cast>
 1124a33:	ud2
 1124a35:	mov    0x20(%r9),%r9
 1124a39:	imul   $0x10,%rcx,%r10
 1124a3d:	add    %r10,%r9
 1124a40:	mov    (%r9),%r10d
 1124a43:	cmp    $0x0,%r10
 1124a47:	je     1124cf9 <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x619>
 1124a4d:	cmp    $0x1,%r10
 1124a51:	je     1124c5d <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x57d>
 1124a57:	cmp    $0x2,%r10
 1124a5b:	je     1124b0a <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x42a>
 1124a61:	mov    %r10,%rax
 1124a64:	cmp    $0x3,%rax
 1124a68:	jne    1124bc0 <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x4e0>
 1124a6e:	mov    0x10dbeb(%rip),%rcx        # 1232660 <myl_lit_4e8cfc313e5d17fa73eb3c68075707ac391b284630fd27670b213105e8e5ed9b>
 1124a75:	mov    %rcx,-0x110(%rbp)
 1124a7c:	mov    -0x110(%rbp),%rax
 1124a83:	mov    %rax,-0x108(%rbp)
 1124a8a:	mov    -0x108(%rbp),%rax
 1124a91:	mov    %rax,-0x118(%rbp)
 1124a98:	call   1128220 <myl_f_8855e2338a0239644fa6d8638afc594de302f594debc25ce542a382b2a6572a1>
 1124a9d:	mov    %rbx,%rdi
 1124aa0:	mov    -0x118(%rbp),%rdx
 1124aa7:	cmp    $0x0,%rdx
 1124aab:	je     1124f01 <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x821>
 1124ab1:	mov    -0x10(%rdx),%rcx
 1124ab5:	movabs $0x4000000000000002,%rsi
 1124abf:	and    %rsi,%rcx
 1124ac2:	cmp    $0x0,%rcx
 1124ac6:	jne    1124afa <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x41a>
 1124ac8:	mov    -0x20(%rdx),%rcx
 1124acc:	sub    $0x1,%rcx
 1124ad0:	jne    1124af6 <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x416>
 1124ad2:	mov    %rax,%rbx
 1124ad5:	mov    -0x18(%rdx),%rax
 1124ad9:	cmp    $0x0,%rax
 1124add:	jne    1124af3 <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x413>
 1124adf:	lea    -0x118(%rbp),%rsi
 1124ae6:	call   113f380 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop>
 1124aeb:	mov    %rbx,%rax
 1124aee:	jmp    1124f01 <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x821>
 1124af3:	mov    %rbx,%rax
 1124af6:	mov    %rcx,-0x20(%rdx)
 1124afa:	movq   $0x0,-0x118(%rbp)
 1124b05:	jmp    1124f01 <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x821>
 1124b0a:	mov    %r11,%rdx
 1124b0d:	mov    0x8(%r9),%r9
 1124b11:	mov    %r9,-0x108(%rbp)
 1124b18:	movq   %r9,%xmm0
 1124b1d:	movq   %r8,%xmm1
 1124b22:	addsd  %xmm1,%xmm0
 1124b26:	movq   %xmm0,%r8
 1124b2b:	movq   $0x0,-0x18(%rbp)
 1124b33:	movq   $0x0,-0x10(%rbp)
 1124b3b:	movl   $0x2,-0x18(%rbp)
 1124b42:	mov    %r8,-0x10(%rbp)
 1124b46:	mov    -0x18(%rbp),%r8
 1124b4a:	mov    %r8,-0x38(%rbp)
 1124b4e:	mov    -0x10(%rbp),%r8
 1124b52:	mov    %r8,-0x30(%rbp)
 1124b56:	mov    %rax,0x80(%rsi)
 1124b5d:	mov    -0x38(%rbp),%rax
 1124b61:	mov    %rax,-0x28(%rbp)
 1124b65:	mov    -0x30(%rbp),%rax
 1124b69:	mov    %rax,-0x20(%rbp)
 1124b6d:	mov    0x78(%rsi),%rax
 1124b71:	cmp    $0x0,%rax
 1124b75:	je     1124bca <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x4ea>
 1124b77:	mov    -0x10(%rax),%r8
 1124b7b:	movabs $0x6000000000000002,%r9
 1124b85:	and    %r9,%r8
 1124b88:	cmp    $0x0,%r8
 1124b8c:	jne    1124b98 <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x4b8>
 1124b8e:	mov    -0x20(%rax),%rax
 1124b92:	cmp    $0x2,%rax
 1124b96:	jb     1124bca <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x4ea>
 1124b98:	mov    %rcx,%r13
 1124b9b:	mov    $0x0,%ecx
 1124ba0:	mov    %rsi,%r12
 1124ba3:	lea    0x10564e(%rip),%rsi        # 122a1f8 <myl_t_a1fa53db408c85388cfd14badb361c2a89e74ce2a863fa83774cb6942b74317a>
 1124baa:	mov    %rdi,%rbx
 1124bad:	call   115a070 <myl_qbe_rc_unique_field>
 1124bb2:	mov    %r13,%rcx
 1124bb5:	mov    %r12,%rsi
 1124bb8:	mov    %rbx,%rdi
 1124bbb:	cmp    $0x0,%eax
 1124bbe:	jne    1124bca <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x4ea>
 1124bc0:	mov    $0x0,%eax
 1124bc5:	jmp    1124f01 <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x821>
 1124bca:	mov    0x78(%rsi),%rax
 1124bce:	cmp    $0x0,%rcx
 1124bd2:	jge    1124c04 <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x524>
 1124bd4:	mov    (%rax),%rsi
 1124bd7:	movabs $0x7fffffffffffffff,%rdx
 1124be1:	cmp    %rdx,%rsi
 1124be4:	ja     1124c51 <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x571>
 1124be6:	mov    %rsi,%rbx
 1124be9:	add    %rcx,%rbx
 1124bec:	mov    %rsi,%rdx
 1124bef:	xor    %rbx,%rdx
 1124bf2:	mov    %rcx,%r8
 1124bf5:	xor    %rbx,%r8
 1124bf8:	and    %r8,%rdx
 1124bfb:	cmp    $0x0,%rdx
 1124bff:	jl     1124c3c <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x55c>
 1124c01:	mov    %rbx,%rcx
 1124c04:	mov    (%rax),%rdx
 1124c07:	cmp    %rdx,%rcx
 1124c0a:	jb     1124c16 <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x536>
 1124c0c:	mov    %rcx,%rsi
 1124c0f:	call   115a7e0 <myl_qbe_fail_normalized_index_bounds>
 1124c14:	ud2
 1124c16:	mov    %rcx,%rbx
 1124c19:	mov    0x20(%rax),%rcx
 1124c1d:	imul   $0x10,%rbx,%rdx
 1124c21:	mov    -0x28(%rbp),%rax
 1124c25:	mov    %rax,(%rcx,%rdx,1)
 1124c29:	mov    -0x20(%rbp),%rax
 1124c2d:	mov    %rax,0x8(%rcx,%rdx,1)
 1124c32:	mov    $0x1,%eax
 1124c37:	jmp    1124f01 <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x821>
 1124c3c:	mov    $0x40,%r8d
 1124c42:	mov    %rsi,%rdx
 1124c45:	mov    $0x0,%esi
 1124c4a:	call   115a9f0 <myl_qbe_fail_overflow_op>
 1124c4f:	ud2
 1124c51:	mov    $0x140,%edx
 1124c56:	call   115ab30 <myl_qbe_fail_cast>
 1124c5b:	ud2
 1124c5d:	mov    0x10d9fc(%rip),%rcx        # 1232660 <myl_lit_4e8cfc313e5d17fa73eb3c68075707ac391b284630fd27670b213105e8e5ed9b>
 1124c64:	mov    %rcx,-0x110(%rbp)
 1124c6b:	mov    -0x110(%rbp),%rax
 1124c72:	mov    %rax,-0x108(%rbp)
 1124c79:	mov    -0x108(%rbp),%rax
 1124c80:	mov    %rax,-0x118(%rbp)
 1124c87:	call   1128220 <myl_f_8855e2338a0239644fa6d8638afc594de302f594debc25ce542a382b2a6572a1>
 1124c8c:	mov    %rbx,%rdi
 1124c8f:	mov    -0x118(%rbp),%rdx
 1124c96:	cmp    $0x0,%rdx
 1124c9a:	je     1124f01 <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x821>
 1124ca0:	mov    -0x10(%rdx),%rcx
 1124ca4:	movabs $0x4000000000000002,%rsi
 1124cae:	and    %rsi,%rcx
 1124cb1:	cmp    $0x0,%rcx
 1124cb5:	jne    1124ce9 <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x609>
 1124cb7:	mov    -0x20(%rdx),%rcx
 1124cbb:	sub    $0x1,%rcx
 1124cbf:	jne    1124ce5 <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x605>
 1124cc1:	mov    %rax,%rbx
 1124cc4:	mov    -0x18(%rdx),%rax
 1124cc8:	cmp    $0x0,%rax
 1124ccc:	jne    1124ce2 <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x602>
 1124cce:	lea    -0x118(%rbp),%rsi
 1124cd5:	call   113f380 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop>
 1124cda:	mov    %rbx,%rax
 1124cdd:	jmp    1124f01 <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x821>
 1124ce2:	mov    %rbx,%rax
 1124ce5:	mov    %rcx,-0x20(%rdx)
 1124ce9:	movq   $0x0,-0x118(%rbp)
 1124cf4:	jmp    1124f01 <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x821>
 1124cf9:	mov    0x10d960(%rip),%rcx        # 1232660 <myl_lit_4e8cfc313e5d17fa73eb3c68075707ac391b284630fd27670b213105e8e5ed9b>
 1124d00:	mov    %rcx,-0x110(%rbp)
 1124d07:	mov    -0x110(%rbp),%rax
 1124d0e:	mov    %rax,-0x108(%rbp)
 1124d15:	mov    -0x108(%rbp),%rax
 1124d1c:	mov    %rax,-0x118(%rbp)
 1124d23:	call   1128220 <myl_f_8855e2338a0239644fa6d8638afc594de302f594debc25ce542a382b2a6572a1>
 1124d28:	mov    %rbx,%rdi
 1124d2b:	mov    -0x118(%rbp),%rdx
 1124d32:	cmp    $0x0,%rdx
 1124d36:	je     1124f01 <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x821>
 1124d3c:	mov    -0x10(%rdx),%rcx
 1124d40:	movabs $0x4000000000000002,%rsi
 1124d4a:	and    %rsi,%rcx
 1124d4d:	cmp    $0x0,%rcx
 1124d51:	jne    1124d85 <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x6a5>
 1124d53:	mov    -0x20(%rdx),%rcx
 1124d57:	sub    $0x1,%rcx
 1124d5b:	jne    1124d81 <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x6a1>
 1124d5d:	mov    %rax,%rbx
 1124d60:	mov    -0x18(%rdx),%rax
 1124d64:	cmp    $0x0,%rax
 1124d68:	jne    1124d7e <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x69e>
 1124d6a:	lea    -0x118(%rbp),%rsi
 1124d71:	call   113f380 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop>
 1124d76:	mov    %rbx,%rax
 1124d79:	jmp    1124f01 <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x821>
 1124d7e:	mov    %rbx,%rax
 1124d81:	mov    %rcx,-0x20(%rdx)
 1124d85:	movq   $0x0,-0x118(%rbp)
 1124d90:	jmp    1124f01 <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x821>
 1124d95:	mov    %rax,%rdx
 1124d98:	mov    $0x40,%r8d
 1124d9e:	mov    $0x1,%ecx
 1124da3:	mov    $0x1,%esi
 1124da8:	call   115a9f0 <myl_qbe_fail_overflow_op>
 1124dad:	ud2
 1124daf:	mov    0x10d8aa(%rip),%rcx        # 1232660 <myl_lit_4e8cfc313e5d17fa73eb3c68075707ac391b284630fd27670b213105e8e5ed9b>
 1124db6:	mov    %rcx,-0x110(%rbp)
 1124dbd:	mov    -0x110(%rbp),%rax
 1124dc4:	mov    %rax,-0x108(%rbp)
 1124dcb:	mov    -0x108(%rbp),%rax
 1124dd2:	mov    %rax,-0x118(%rbp)
 1124dd9:	call   1128220 <myl_f_8855e2338a0239644fa6d8638afc594de302f594debc25ce542a382b2a6572a1>
 1124dde:	mov    %rbx,%rdi
 1124de1:	mov    -0x118(%rbp),%rdx
 1124de8:	cmp    $0x0,%rdx
 1124dec:	je     1124f01 <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x821>
 1124df2:	mov    -0x10(%rdx),%rcx
 1124df6:	movabs $0x4000000000000002,%rsi
 1124e00:	and    %rsi,%rcx
 1124e03:	cmp    $0x0,%rcx
 1124e07:	jne    1124e3b <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x75b>
 1124e09:	mov    -0x20(%rdx),%rcx
 1124e0d:	sub    $0x1,%rcx
 1124e11:	jne    1124e37 <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x757>
 1124e13:	mov    %rax,%rbx
 1124e16:	mov    -0x18(%rdx),%rax
 1124e1a:	cmp    $0x0,%rax
 1124e1e:	jne    1124e34 <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x754>
 1124e20:	lea    -0x118(%rbp),%rsi
 1124e27:	call   113f380 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop>
 1124e2c:	mov    %rbx,%rax
 1124e2f:	jmp    1124f01 <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x821>
 1124e34:	mov    %rbx,%rax
 1124e37:	mov    %rcx,-0x20(%rdx)
 1124e3b:	movq   $0x0,-0x118(%rbp)
 1124e46:	jmp    1124f01 <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x821>
 1124e4b:	mov    0x10d80e(%rip),%rcx        # 1232660 <myl_lit_4e8cfc313e5d17fa73eb3c68075707ac391b284630fd27670b213105e8e5ed9b>
 1124e52:	mov    %rcx,-0x110(%rbp)
 1124e59:	mov    -0x110(%rbp),%rax
 1124e60:	mov    %rax,-0x108(%rbp)
 1124e67:	mov    -0x108(%rbp),%rax
 1124e6e:	mov    %rax,-0x118(%rbp)
 1124e75:	call   1128220 <myl_f_8855e2338a0239644fa6d8638afc594de302f594debc25ce542a382b2a6572a1>
 1124e7a:	mov    %rbx,%rdi
 1124e7d:	mov    -0x118(%rbp),%rdx
 1124e84:	cmp    $0x0,%rdx
 1124e88:	je     1124f01 <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x821>
 1124e8a:	mov    -0x10(%rdx),%rcx
 1124e8e:	movabs $0x4000000000000002,%rsi
 1124e98:	and    %rsi,%rcx
 1124e9b:	cmp    $0x0,%rcx
 1124e9f:	jne    1124ed0 <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x7f0>
 1124ea1:	mov    -0x20(%rdx),%rcx
 1124ea5:	sub    $0x1,%rcx
 1124ea9:	jne    1124ecc <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x7ec>
 1124eab:	mov    %rax,%rbx
 1124eae:	mov    -0x18(%rdx),%rax
 1124eb2:	cmp    $0x0,%rax
 1124eb6:	jne    1124ec9 <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x7e9>
 1124eb8:	lea    -0x118(%rbp),%rsi
 1124ebf:	call   113f380 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop>
 1124ec4:	mov    %rbx,%rax
 1124ec7:	jmp    1124f01 <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x821>
 1124ec9:	mov    %rbx,%rax
 1124ecc:	mov    %rcx,-0x20(%rdx)
 1124ed0:	movq   $0x0,-0x118(%rbp)
 1124edb:	jmp    1124f01 <myl_f_2ebfe2cc969f1c1a5ba88011b86a1472451e4fef31738ad491da1fd5ef2c2cc0+0x821>
 1124edd:	mov    %r12,%rdx
 1124ee0:	mov    $0x40,%r8d
 1124ee6:	mov    $0x1,%ecx
 1124eeb:	mov    $0x1,%esi
 1124ef0:	call   115a9f0 <myl_qbe_fail_overflow_op>
 1124ef5:	ud2
 1124ef7:	call   113cb30 <myl_f_f04a28c8dfdceed2bc94d69e9c44787aee268d323f82bfda25644397e8e2282d>
 1124efc:	mov    $0x1,%eax
 1124f01:	pop    %r14
 1124f03:	pop    %r13
 1124f05:	pop    %r12
 1124f07:	pop    %rbx
 1124f08:	leave
 1124f09:	ret
 1124f0a:	call   115abb0 <myl_qbe_fail_frame>
 1124f0f:	ud2

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
