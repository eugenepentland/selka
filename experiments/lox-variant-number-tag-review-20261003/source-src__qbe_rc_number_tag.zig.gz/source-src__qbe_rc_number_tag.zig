//! Fresh-zeroed variant tag padding permits one full-word tag store.
const typed = @import("typed.zig");
const native = @import("native_types.zig");
/// Emitter failures shared with ordinary aggregate initialization.
pub const Error = @import("qbe_rc_values.zig").Error;

/// RC-ZEROED-NUMBER-TAG-1: an exact builtin int/float payload begins at byte
/// eight; tag bytes four through seven have already been cleared. On the
/// exclusively supported little-endian Linux AMD64 ABI, a zero-extended tag
/// word therefore preserves the ordinary four-byte tag store byte for byte.
pub fn admits(records: []const typed.Record, record: typed.Record, tag: usize, physical: native.Layout, payload: @import("rc_shape.zig").Shape) bool {
    if (!payload.copyable or payload.counted or payload.unique_drop) return false;
    if (record.managed or record.fields.len != 0) return false;
    const variants = record.shape.variants orelse return false;
    if (variants.cases.len > 8 or physical.fields.len > 8 or
        tag >= variants.cases.len or tag > @import("std").math.maxInt(u32)) return false;
    const active = variants.cases[tag];
    const ty = active.payload orelse return false;
    if (ty != .i64 and !builtinFloat(ty, records)) return false;
    if (active.boxed or active.fielded) return false;
    if (physical.kind != .variant or physical.payload_offset != 8 or physical.alignment != 8) return false;
    if (physical.size < 16 or physical.size > 32) return false;
    if (physical.copy != .bytes or physical.drop) return false;
    if (physical.count != 1 or physical.stride != 0) return false;
    var active_fields: usize = 0;
    for (physical.fields) |field| {
        const field_tag = field.tag orelse return false;
        if (field_tag >= variants.cases.len or field.offset != 8 or
            field.ty != variants.cases[field_tag].payload) return false;
        if (field_tag == tag) active_fields += 1;
    }
    return active_fields == 1;
}

fn builtinFloat(ty: typed.Type, records: []const typed.Record) bool {
    if (!ty.isAggregate() or ty.recordIndex() >= records.len) return false;
    if (!@import("numeric_surface.zig").isFloat(ty, records)) return false;
    const record = records[ty.recordIndex()];
    if (record.managed or record.fields.len != 0 or record.shape.hasRuntimeIdentity()) return false;
    return !record.contract.move_only and record.contract.callback == null;
}

/// Called only after zeroing the complete admitted fresh variant storage.
/// The payload retains its ordinary scalar read and full-width write.
pub fn writeTag(comptime E: type, self: *E, value: usize, destination: usize) Error!void {
    try self.print(" storel {d}, %v{d}\n", .{ value, destination });
}
