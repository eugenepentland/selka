//! Fresh numeric variant tags preserve all payload bits and ordinary cleanup.
const std = @import("std");
const typed = @import("typed.zig");
const native = @import("native_types.zig");
const tags = @import("qbe_rc_number_tag.zig");
const compiler = @import("compiler.zig");
const runtime = @import("runtime_mode.zig");
const t = std.testing;
const span = @import("source.zig").Span{ .start = 0, .end = 0 };
const float_type: typed.Type = @fromBackingInt(@intCast(typed.Type.record_base + 1));
const cases = [_]typed.Variant{
    .{ .name = "empty", .declaration = span, .payload = null },
    .{ .name = "flag", .declaration = span, .payload = .bool },
    .{ .name = "number", .declaration = span, .payload = float_type },
    .{ .name = "integer", .declaration = span, .payload = .i64 },
};
const record: typed.Record = .{
    .id = @fromBackingInt(@intCast(typed.Type.record_base)),
    .name = "Value",
    .declaration = span,
    .fields = &.{},
    .shape = .{ .variants = .{ .is_union = true, .cases = &cases } },
};
const float_record: typed.Record = .{ .id = float_type, .name = "float", .declaration = span, .fields = &.{}, .shape = .{ .domain = .u64 } };
const records = [_]typed.Record{ record, float_record };

const fields = [_]native.Field{
    .{ .offset = 8, .ty = .bool, .tag = 1 },
    .{ .offset = 8, .ty = float_type, .tag = 2 },
    .{ .offset = 8, .ty = .i64, .tag = 3 },
};
const physical: native.Layout = .{ .kind = .variant, .size = 16, .alignment = 8, .payload_offset = 8, .fields = &fields };

// spec: RC-ZEROED-NUMBER-TAG-1
test "RC-ZEROED-NUMBER-TAG-1 admits only exact numeric builtin payloads" {
    try t.expect(tags.admits(&records, record, 2, physical, .{}));
    try t.expect(tags.admits(&records, record, 3, physical, .{}));
    for ([_]usize{ 0, 1, 4, std.math.maxInt(usize) }) |tag| try t.expect(!tags.admits(&records, record, tag, physical, .{}));
    try wrongBuiltins();
}

fn wrongBuiltins() !void {
    for ([_]typed.Type{ .i8, .i16, .i32, .u64, .unit }) |ty| {
        var changed_cases = cases;
        changed_cases[2].payload = ty;
        var changed_record = record;
        changed_record.shape.variants.?.cases = &changed_cases;
        try t.expect(!tags.admits(&records, changed_record, 2, physical, .{}));
    }
}

// spec-case: RC-ZEROED-NUMBER-TAG-1
test "RC-ZEROED-NUMBER-TAG-1 refuses niche overlap and unsupported physical kinds" {
    for ([_]native.Kind{ .niche, .record, .scalar, .managed }) |kind| {
        var changed = physical;
        changed.kind = kind;
        try t.expect(!tags.admits(&records, record, 2, changed, .{}));
    }
    try wrongPayloadOffsets();
}

fn wrongPayloadOffsets() !void {
    for ([_]u64{ 0, 4, 9, 16 }) |offset| {
        var changed = physical;
        changed.payload_offset = offset;
        try t.expect(!tags.admits(&records, record, 2, changed, .{}));
    }
}

// spec-case: RC-ZEROED-NUMBER-TAG-1
test "RC-ZEROED-NUMBER-TAG-1 size and alignment bounds preserve old stores" {
    for ([_]u64{ 0, 8, 15, 33, 64 }) |size| {
        var changed = physical;
        changed.size = size;
        try t.expect(!tags.admits(&records, record, 2, changed, .{}));
    }
    try wrongAlignments();
}

fn wrongAlignments() !void {
    for ([_]u8{ 1, 4, 16 }) |alignment| {
        var changed = physical;
        changed.alignment = alignment;
        try t.expect(!tags.admits(&records, record, 2, changed, .{}));
    }
}

// spec-case: RC-ZEROED-NUMBER-TAG-1
test "RC-ZEROED-NUMBER-TAG-1 unique repeated and strided layouts retain stores" {
    var changed = physical;
    changed.copy = .prohibited;
    try t.expect(!tags.admits(&records, record, 2, changed, .{}));
    changed = physical;
    changed.drop = true;
    try t.expect(!tags.admits(&records, record, 2, changed, .{}));
    changed = physical;
    changed.count = 2;
    try t.expect(!tags.admits(&records, record, 2, changed, .{}));
    changed = physical;
    changed.stride = 16;
    try t.expect(!tags.admits(&records, record, 2, changed, .{}));
}

// spec-case: RC-ZEROED-NUMBER-TAG-1
test "RC-ZEROED-NUMBER-TAG-1 field mismatch duplicate missing and bounded scan refusals" {
    const wrong: [6][]const native.Field = .{
        &.{.{ .offset = 4, .ty = float_type, .tag = 2 }},
        &.{.{ .offset = 8, .ty = float_type }},
        &.{.{ .offset = 8, .ty = .i64, .tag = 2 }},
        &.{ fields[1], fields[1] },
        &.{fields[0]},
        &.{.{ .offset = 8, .ty = float_type, .tag = 4 }},
    };
    for (wrong) |members| {
        var changed = physical;
        changed.fields = members;
        try t.expect(!tags.admits(&records, record, 2, changed, .{}));
    }
    var many: [9]typed.Variant = @splat(cases[2]);
    var changed_record = record;
    changed_record.shape.variants.?.cases = &many;
    try t.expect(!tags.admits(&records, changed_record, 2, physical, .{}));
    var many_fields: [9]native.Field = @splat(fields[1]);
    var changed = physical;
    changed.fields = &many_fields;
    try t.expect(!tags.admits(&records, record, 2, changed, .{}));
}

// spec-case: RC-ZEROED-NUMBER-TAG-1
test "RC-ZEROED-NUMBER-TAG-1 boxed fielded and managed schemas retain stores" {
    for (0..3) |kind| try t.expect(!changedSchema(kind));
}

// spec-case: RC-ZEROED-NUMBER-TAG-1
test "RC-ZEROED-NUMBER-TAG-1 user domains and owning payload metadata retain stores" {
    var changed_records = records;
    changed_records[1].declaration = .{ .start = 1, .end = 5 };
    try t.expect(!tags.admits(&changed_records, record, 2, physical, .{}));
    changed_records = records;
    changed_records[1].name = "UserBits";
    try t.expect(!tags.admits(&changed_records, record, 2, physical, .{}));
    changed_records = records;
    changed_records[1].managed = true;
    try t.expect(!tags.admits(&changed_records, record, 2, physical, .{}));
    for ([_]@import("rc_shape.zig").Shape{ .{ .copyable = false }, .{ .counted = true }, .{ .unique_drop = true } }) |shape|
        try t.expect(!tags.admits(&records, record, 2, physical, shape));
}

fn changedSchema(kind: usize) bool {
    var changed_record = record;
    var changed_cases = cases;
    if (kind == 0) changed_cases[2].boxed = true;
    if (kind == 1) changed_cases[2].fielded = true;
    if (kind == 2) changed_record.managed = true;
    changed_record.shape.variants.?.cases = &changed_cases;
    return tags.admits(&records, changed_record, 2, physical, .{});
}

const Bytes = struct {
    memory: [36]u8 = @splat(0xa5),
    /// Execute the production tag-store format without touching its payload.
    pub fn print(self: *Bytes, comptime format: []const u8, args: anytype) tags.Error!void {
        std.debug.assert(std.mem.eql(u8, format, " storel {d}, %v{d}\n"));
        std.mem.writeInt(u64, self.memory[2 + args[1] ..][0..8], args[0], .little);
    }
};
const payload_bits = [_]u64{
    0,                  1,                  0x8000000000000000, 0x7fffffffffffffff,
    0xffffffffffffffff, 0x000fffffffffffff, 0x0010000000000000, 0x7fefffffffffffff,
    0x7ff0000000000000, 0xfff0000000000000, 0x7ff8000000000000, 0xfff8000000000000,
    0x7ff0000000000001, 0x7ff8123456789abc, 0xfff8123456789abc, 0x3ff0000000000000,
};

// spec-case: RC-ZEROED-NUMBER-TAG-1
test "RC-ZEROED-NUMBER-TAG-1 tag word preserves IEEE integer and adjacent byte patterns" {
    try exactBytes();
}

fn exactBytes() !void {
    for ([_]usize{ 16, 32 }) |size| for ([_]usize{ 0, 1, 7 }) |tag| for (payload_bits) |bits| {
        var emitter: Bytes = .{};
        @memset(emitter.memory[2 .. 2 + size], 0);
        std.mem.writeInt(u64, emitter.memory[10..18], bits, .little);
        var narrow = emitter.memory;
        std.mem.writeInt(u32, narrow[2..6], @intCast(tag), .little);
        try tags.writeTag(Bytes, &emitter, tag, 0);
        try t.expectEqualSlices(u8, &narrow, &emitter.memory);
    };
}

const Manifest = struct { functions: []const struct { name: []const u8, il: []const u8 } };
const source =
    \\union Value:
    \\    empty,
    \\    flag: bool,
    \\    number: float,
    \\    integer: int,
    \\    items: list[int]
    \\def make(number: float) -> Value:
    \\    return Value.number(number)
    \\def main() -> int:
    \\    result = make(-0.0)
    \\    return 0
;

fn emitted(input: []const u8, mode: runtime.Selection) ![]const u8 {
    const saved = runtime.get();
    defer runtime.set(saved);
    runtime.set(mode);
    var compilation = try compiler.Compilation.init(t.allocator, "number.my", input);
    defer compilation.deinit();
    const output = try compilation.emitQbeWithOptions(t.allocator, .{ .step_checks = false, .frame_checks = true });
    defer t.allocator.free(output);
    var manifest = try std.json.parseFromSlice(Manifest, t.allocator, output, .{ .allocate = .alloc_always, .ignore_unknown_fields = true });
    defer manifest.deinit();
    for (manifest.value.functions) |function| if (std.mem.eql(u8, function.name, "make")) return t.allocator.dupe(u8, function.il);
    return error.TestUnexpectedResult;
}

fn location(output: []const u8, text: []const u8) !usize {
    return std.mem.indexOf(u8, output, text) orelse error.TestUnexpectedResult;
}

// spec-case: RC-ZEROED-NUMBER-TAG-1
test "RC-ZEROED-NUMBER-TAG-1 RC and counting preserve numeric payload read and journal order" {
    for ([_]runtime.Selection{ .rc, .rc_counting }) |mode| {
        const output = try emitted(source, mode);
        defer t.allocator.free(output);
        const clear = try location(output, " storel 0, %v");
        const tag = try location(output, " storel 2, %v");
        const read = tag + try location(output[tag..], " =l loadl ");
        const store = read + try location(output[read..], " storel %v");
        try t.expect(clear < tag and tag < read and read < store);
        try t.expect(std.mem.indexOf(u8, output, " storew 2, %v") == null);
        try t.expect(std.mem.indexOf(u8, output, "# rc-frame") != null);
        try t.expect(std.mem.indexOf(u8, output, "# rc-exit") != null);
    }
}

// spec-case: RC-ZEROED-NUMBER-TAG-1
test "RC-ZEROED-NUMBER-TAG-1 builtin i64 payload retains its full scalar load and store" {
    const integer_source = try std.mem.replaceOwned(u8, t.allocator, source, "number: float", "number: int");
    defer t.allocator.free(integer_source);
    const integer_main = try std.mem.replaceOwned(u8, t.allocator, integer_source, "make(-0.0)", "make(-19)");
    defer t.allocator.free(integer_main);
    const output = try emitted(integer_main, .rc);
    defer t.allocator.free(output);
    const tag = try location(output, " storel 2, %v");
    const read = tag + try location(output[tag..], " =l loadl ");
    const store = read + try location(output[read..], " storel %v");
    try t.expect(tag < read and read < store);
    try t.expect(std.mem.indexOf(u8, output, " storew 2, %v") == null);
}

// spec-case: RC-ZEROED-NUMBER-TAG-1
test "RC-ZEROED-NUMBER-TAG-1 a source created u64 domain keeps its original tag store" {
    const output = try emitted(
        \\domain Bits: u64:
        \\    def create(value: u64) -> Bits:
        \\        return wrap[Bits](value)
        \\union Value:
        \\    empty,
        \\    bits: Bits
        \\def make(value: Bits) -> Value:
        \\    return Value.bits(value)
        \\def main() -> int:
        \\    result = make(Bits.create(19u64))
        \\    return 0
    , .rc);
    defer t.allocator.free(output);
    try t.expect(std.mem.indexOf(u8, output, " storew 1, %v") != null);
    try t.expect(std.mem.indexOf(u8, output, " storel 1, %v") == null);
}

// spec-case: RC-ZEROED-NUMBER-TAG-1
test "RC-ZEROED-NUMBER-TAG-1 GC and bool constructors retain original widths" {
    const gc = try emitted(source, .gc);
    defer t.allocator.free(gc);
    try t.expect(std.mem.indexOf(u8, gc, " storew 2, %v") != null);
    const bool_source = try std.mem.replaceOwned(u8, t.allocator, source, "number: float", "number: bool");
    defer t.allocator.free(bool_source);
    const bool_body = try std.mem.replaceOwned(u8, t.allocator, bool_source, "Value.number(number)", "Value.flag(number)");
    defer t.allocator.free(bool_body);
    const bool_main = try std.mem.replaceOwned(u8, t.allocator, bool_body, "make(-0.0)", "make(False)");
    defer t.allocator.free(bool_main);
    const rc = try emitted(bool_main, .rc);
    defer t.allocator.free(rc);
    try t.expect(std.mem.indexOf(u8, rc, " storew 1, %v") != null);
    try t.expect(std.mem.indexOf(u8, rc, " storeb ") != null);
}

// spec-case: RC-ZEROED-NUMBER-TAG-1
test "RC-ZEROED-NUMBER-TAG-1 legacy sharing retains collector tag protocol" {
    const semantics = @import("wiring/value_semantics.zig");
    const saved = semantics.enabled;
    defer semantics.enabled = saved;
    semantics.enabled = false;
    const output = try emitted(source, .rc);
    defer t.allocator.free(output);
    try t.expect(std.mem.indexOf(u8, output, " storew 2, %v") != null);
    try t.expect(std.mem.indexOf(u8, output, "# rc-frame") == null);
}
