
/home/epentland/ai/canopy/mylang-worktrees/codex-lox-borrow-assert-20261003/.tmp-lox-borrow-assert-20261003/fixed-qbe-ast:     file format elf64-x86-64


Disassembly of section .text:

00000000010a95e0 <myl_f_72cff91e1ca43adf6e3bd650d1fe503b405034486590fc282e877edc70061b44>:
 10a95e0:	endbr64
 10a95e4:	push   %rbp
 10a95e5:	mov    %rsp,%rbp
 10a95e8:	sub    $0x418,%rsp
 10a95ef:	push   %rbx
 10a95f0:	push   %r12
 10a95f2:	push   %r13
 10a95f4:	push   %r14
 10a95f6:	push   %r15
 10a95f8:	mov    0x10(%rbp),%r13
 10a95fc:	mov    %r13,-0x50(%rbp)
 10a9600:	mov    %r9,-0x10(%rbp)
 10a9604:	mov    %r8,-0x18(%rbp)
 10a9608:	mov    %rcx,%r15
 10a960b:	mov    %rdx,-0x20(%rbp)
 10a960f:	mov    %rsi,%r12
 10a9612:	mov    %rdi,%rbx
 10a9615:	mov    0x40(%r12),%rax
 10a961a:	mov    $0x0,%ecx
 10a961f:	mov    %ecx,-0x2c(%rbp)
 10a9622:	mov    $0x0,%r14d
 10a9628:	mov    %r14d,-0x34(%rbp)
 10a962c:	mov    $0x0,%r14d
 10a9632:	mov    %r14d,-0x30(%rbp)
 10a9636:	mov    $0x0,%r14d
 10a963c:	mov    %r14d,-0x8(%rbp)
 10a9640:	lea    -0x78(%rbp),%rcx
 10a9644:	cmp    %rax,%rcx
 10a9647:	jb     10aaa0a <myl_f_72cff91e1ca43adf6e3bd650d1fe503b405034486590fc282e877edc70061b44+0x142a>
 10a964d:	mov    %r12,%rdi
 10a9650:	call   115aba0 <myl_qbe_heap>
 10a9655:	mov    %rax,%rdi
 10a9658:	mov    %rdi,%r14
 10a965b:	mov    %r12,%rdi
 10a965e:	call   115d700 <myl_qbe_region_mark>
 10a9663:	mov    %r15,%rsi
 10a9666:	mov    %r14,%rdi
 10a9669:	mov    %rax,%rcx
 10a966c:	mov    %rbx,%rax
 10a966f:	mov    -0x10(%rbp),%r9
 10a9673:	mov    -0x18(%rbp),%r8
 10a9677:	mov    -0x20(%rbp),%rdx
 10a967b:	mov    %rax,%rbx
 10a967e:	mov    0x0(%r13),%rax
 10a9682:	sub    $0x10,%rsp
 10a9686:	mov    %rsp,%r10
 10a9689:	mov    %rax,(%r10)
 10a968c:	mov    %rcx,%r15
 10a968f:	mov    %rsi,%rcx
 10a9692:	mov    %rsi,%r14
 10a9695:	mov    %r12,%rsi
 10a9698:	mov    %rdi,%r13
 10a969b:	lea    -0x408(%rbp),%rdi
 10a96a2:	call   10b6af0 <myl_f_d32d9d609bd2d498a6b2d4f34d6d36851c296533eaafa0e3b7c4c9b1eec65fca>
 10a96a7:	mov    %r15,%rcx
 10a96aa:	mov    %r14,%rsi
 10a96ad:	mov    %r13,%rdi
 10a96b0:	mov    %rax,%rdx
 10a96b3:	mov    %rbx,%rax
 10a96b6:	sub    $0xfffffffffffffff0,%rsp
 10a96ba:	mov    (%rdx),%r8
 10a96bd:	mov    %r8,-0x268(%rbp)
 10a96c4:	mov    0x8(%rdx),%r8
 10a96c8:	mov    %r8,-0x260(%rbp)
 10a96cf:	mov    0x10(%rdx),%rdx
 10a96d3:	mov    %rdx,-0x258(%rbp)
 10a96da:	mov    -0x268(%rbp),%rdx
 10a96e1:	mov    %rdx,-0x340(%rbp)
 10a96e8:	mov    -0x260(%rbp),%rdx
 10a96ef:	mov    %rdx,-0x338(%rbp)
 10a96f6:	mov    -0x258(%rbp),%rdx
 10a96fd:	mov    %rdx,-0x330(%rbp)
 10a9704:	mov    -0x340(%rbp),%edx
 10a970a:	cmp    $0x0,%rdx
 10a970e:	mov    %rax,%rbx
 10a9711:	sete   %al
 10a9714:	movzbq %al,%rax
 10a9718:	mov    %rcx,%r15
 10a971b:	lea    -0x340(%rbp),%rcx
 10a9722:	mov    %rcx,%r14
 10a9725:	add    $0x8,%r14
 10a9729:	mov    %r14,-0x28(%rbp)
 10a972d:	cmp    $0x0,%eax
 10a9730:	jne    10a98c3 <myl_f_72cff91e1ca43adf6e3bd650d1fe503b405034486590fc282e877edc70061b44+0x2e3>
 10a9736:	movabs $0x300000007,%rsi
 10a9740:	mov    %rdi,%r13
 10a9743:	lea    0x118e4e(%rip),%rdi        # 11c2598 <myl_f_72cff91e1ca43adf6e3bd650d1fe503b405034486590fc282e877edc70061b44_meta>
 10a974a:	call   115c038 <myl_qbe_error_trace_append>
 10a974f:	mov    %r15,%rcx
 10a9752:	mov    %r14,%rdx
 10a9755:	mov    %r13,%rdi
 10a9758:	mov    %rbx,%rax
 10a975b:	mov    -0x8(%rbp),%r13d
 10a975f:	movq   $0x0,-0x140(%rbp)
 10a976a:	mov    %rax,%rbx
 10a976d:	lea    -0x140(%rbp),%rax
 10a9774:	mov    %rax,%rsi
 10a9777:	add    $0x8,%rsi
 10a977b:	movq   $0x0,-0x138(%rbp)
 10a9786:	movq   $0x0,-0x130(%rbp)
 10a9791:	movl   $0x1,-0x140(%rbp)
 10a979b:	mov    %rcx,%r15
 10a979e:	mov    %rdi,%r14
 10a97a1:	call   114d340 <myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_retain>
 10a97a6:	mov    %r15,%rcx
 10a97a9:	mov    %r14,%rdi
 10a97ac:	cmp    $0x0,%eax
 10a97af:	jne    10a97ce <myl_f_72cff91e1ca43adf6e3bd650d1fe503b405034486590fc282e877edc70061b44+0x1ee>
 10a97b1:	call   1169600 <myl_rc_take_failure>
 10a97b6:	mov    %r12,%rdi
 10a97b9:	mov    %eax,%esi
 10a97bb:	mov    %rdi,%r12
 10a97be:	call   1159ab0 <myl_qbe_rc_status>
 10a97c3:	mov    %rbx,%rax
 10a97c6:	mov    %rax,%rbx
 10a97c9:	jmp    10aa9a1 <myl_f_72cff91e1ca43adf6e3bd650d1fe503b405034486590fc282e877edc70061b44+0x13c1>
 10a97ce:	mov    %rbx,%rax
 10a97d1:	mov    -0x140(%rbp),%rdx
 10a97d8:	mov    %rdx,-0x268(%rbp)
 10a97df:	mov    %rcx,%r15
 10a97e2:	mov    -0x138(%rbp),%rcx
 10a97e9:	mov    %rcx,-0x260(%rbp)
 10a97f0:	mov    %rax,%rbx
 10a97f3:	mov    -0x130(%rbp),%rax
 10a97fa:	mov    %rax,-0x258(%rbp)
 10a9801:	lea    -0x340(%rbp),%rsi
 10a9808:	mov    %rdi,%r14
 10a980b:	call   1147800 <myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_drop>
 10a9810:	mov    %r15,%rcx
 10a9813:	mov    %r14,%rdi
 10a9816:	mov    %rbx,%rax
 10a9819:	mov    -0x268(%rbp),%rdx
 10a9820:	mov    %rdx,-0x340(%rbp)
 10a9827:	mov    -0x260(%rbp),%rdx
 10a982e:	mov    %rdx,-0x338(%rbp)
 10a9835:	mov    %rax,%rbx
 10a9838:	mov    -0x258(%rbp),%rax
 10a983f:	mov    %rax,-0x330(%rbp)
 10a9846:	mov    %rcx,%r15
 10a9849:	lea    -0x340(%rbp),%rdx
 10a9850:	lea    -0x268(%rbp),%rsi
 10a9857:	mov    %rdi,%r14
 10a985a:	call   1147890 <myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_take>
 10a985f:	mov    %r14,%rdi
 10a9862:	cmp    $0x0,%eax
 10a9865:	jne    10a987e <myl_f_72cff91e1ca43adf6e3bd650d1fe503b405034486590fc282e877edc70061b44+0x29e>
 10a9867:	call   1169600 <myl_rc_take_failure>
 10a986c:	mov    %r12,%rdi
 10a986f:	mov    %eax,%esi
 10a9871:	mov    %rdi,%r12
 10a9874:	call   1159ab0 <myl_qbe_rc_status>
 10a9879:	jmp    10aa9a1 <myl_f_72cff91e1ca43adf6e3bd650d1fe503b405034486590fc282e877edc70061b44+0x13c1>
 10a987e:	mov    %r13d,%r12d
 10a9881:	cmp    $0x0,%r12d
 10a9885:	jne    10a988c <myl_f_72cff91e1ca43adf6e3bd650d1fe503b405034486590fc282e877edc70061b44+0x2ac>
 10a9887:	mov    %rbx,%rax
 10a988a:	jmp    10a989b <myl_f_72cff91e1ca43adf6e3bd650d1fe503b405034486590fc282e877edc70061b44+0x2bb>
 10a988c:	lea    -0x340(%rbp),%rsi
 10a9893:	call   1147800 <myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_drop>
 10a9898:	mov    %rbx,%rax
 10a989b:	mov    -0x268(%rbp),%rcx
 10a98a2:	mov    %rcx,(%rax)
 10a98a5:	mov    -0x260(%rbp),%rcx
 10a98ac:	mov    %rcx,0x8(%rax)
 10a98b0:	mov    -0x258(%rbp),%rcx
 10a98b7:	mov    %rcx,0x10(%rax)
 10a98bb:	mov    %rax,%rbx
 10a98be:	jmp    10aa9ff <myl_f_72cff91e1ca43adf6e3bd650d1fe503b405034486590fc282e877edc70061b44+0x141f>
 10a98c3:	mov    %rsi,%r14
 10a98c6:	lea    -0x340(%rbp),%rsi
 10a98cd:	mov    %rdi,%r13
 10a98d0:	call   1147800 <myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_drop>
 10a98d5:	mov    %r15,%rcx
 10a98d8:	mov    %r14,%rsi
 10a98db:	mov    %r13,%rdi
 10a98de:	mov    %rbx,%rax
 10a98e1:	mov    -0x50(%rbp),%r13
 10a98e5:	mov    -0x10(%rbp),%r9
 10a98e9:	mov    -0x18(%rbp),%r8
 10a98ed:	mov    -0x20(%rbp),%rdx
 10a98f1:	mov    %rax,%rbx
 10a98f4:	mov    0x30(%r13),%rax
 10a98f8:	sub    $0x10,%rsp
 10a98fc:	mov    %rsp,%r10
 10a98ff:	mov    %rax,(%r10)
 10a9902:	mov    %rcx,%r15
 10a9905:	mov    %rsi,%rcx
 10a9908:	mov    %rsi,%r14
 10a990b:	mov    %r12,%rsi
 10a990e:	mov    %rdi,%r13
 10a9911:	lea    -0x3f0(%rbp),%rdi
 10a9918:	call   10b6af0 <myl_f_d32d9d609bd2d498a6b2d4f34d6d36851c296533eaafa0e3b7c4c9b1eec65fca>
 10a991d:	mov    %r14,%rsi
 10a9920:	mov    %r13,%rdi
 10a9923:	mov    %rax,%rcx
 10a9926:	mov    %rbx,%rax
 10a9929:	mov    %rax,%rbx
 10a992c:	mov    -0x2c(%rbp),%eax
 10a992f:	mov    -0x28(%rbp),%rdx
 10a9933:	sub    $0xfffffffffffffff0,%rsp
 10a9937:	mov    (%rcx),%r8
 10a993a:	mov    %r8,-0x268(%rbp)
 10a9941:	mov    0x8(%rcx),%r8
 10a9945:	mov    %r8,-0x260(%rbp)
 10a994c:	mov    0x10(%rcx),%rcx
 10a9950:	mov    %rcx,-0x258(%rbp)
 10a9957:	cmp    $0x0,%eax
 10a995a:	jne    10a9964 <myl_f_72cff91e1ca43adf6e3bd650d1fe503b405034486590fc282e877edc70061b44+0x384>
 10a995c:	mov    %rbx,%rax
 10a995f:	mov    %r15,%rcx
 10a9962:	jmp    10a9986 <myl_f_72cff91e1ca43adf6e3bd650d1fe503b405034486590fc282e877edc70061b44+0x3a6>
 10a9964:	mov    %rsi,%r14
 10a9967:	lea    -0x340(%rbp),%rsi
 10a996e:	mov    %rdi,%r13
 10a9971:	call   1147f00 <myl_t_87b3a699846cba24453cba0c476cfc282ad163c22e08be1c713a98bd1480fb29_rcg_drop>
 10a9976:	mov    %r15,%rcx
 10a9979:	mov    %r14,%rsi
 10a997c:	mov    %r13,%rdi
 10a997f:	mov    %rbx,%rax
 10a9982:	mov    -0x28(%rbp),%rdx
 10a9986:	mov    -0x268(%rbp),%r8
 10a998d:	mov    %r8,-0x340(%rbp)
 10a9994:	mov    %rdx,%r14
 10a9997:	mov    -0x260(%rbp),%rdx
 10a999e:	mov    %rdx,-0x338(%rbp)
 10a99a5:	mov    %rcx,%r15
 10a99a8:	mov    -0x258(%rbp),%rcx
 10a99af:	mov    %rcx,-0x330(%rbp)
 10a99b6:	mov    %rax,%rbx
 10a99b9:	mov    -0x340(%rbp),%eax
 10a99bf:	cmp    $0x0,%rax
 10a99c3:	je     10a9b53 <myl_f_72cff91e1ca43adf6e3bd650d1fe503b405034486590fc282e877edc70061b44+0x573>
 10a99c9:	movabs $0x300000012,%rsi
 10a99d3:	mov    %rdi,%r13
 10a99d6:	lea    0x118bbb(%rip),%rdi        # 11c2598 <myl_f_72cff91e1ca43adf6e3bd650d1fe503b405034486590fc282e877edc70061b44_meta>
 10a99dd:	call   115c038 <myl_qbe_error_trace_append>
 10a99e2:	mov    %r15,%rcx
 10a99e5:	mov    %r14,%rdx
 10a99e8:	mov    %r13,%rdi
 10a99eb:	mov    %rbx,%rax
 10a99ee:	mov    -0x30(%rbp),%r13d
 10a99f2:	movq   $0x0,-0x128(%rbp)
 10a99fd:	mov    %rax,%rbx
 10a9a00:	lea    -0x128(%rbp),%rax
 10a9a07:	mov    %rax,%rsi
 10a9a0a:	add    $0x8,%rsi
 10a9a0e:	movq   $0x0,-0x120(%rbp)
 10a9a19:	movq   $0x0,-0x118(%rbp)
 10a9a24:	movl   $0x1,-0x128(%rbp)
 10a9a2e:	mov    %rcx,%r15
 10a9a31:	mov    %rdi,%r14
 10a9a34:	call   114d340 <myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_retain>
 10a9a39:	mov    %r15,%rcx
 10a9a3c:	mov    %r14,%rdi
 10a9a3f:	cmp    $0x0,%eax
 10a9a42:	jne    10a9a61 <myl_f_72cff91e1ca43adf6e3bd650d1fe503b405034486590fc282e877edc70061b44+0x481>
 10a9a44:	call   1169600 <myl_rc_take_failure>
 10a9a49:	mov    %r12,%rdi
 10a9a4c:	mov    %eax,%esi
 10a9a4e:	mov    %rdi,%r12
 10a9a51:	call   1159ab0 <myl_qbe_rc_status>
 10a9a56:	mov    %rbx,%rax
 10a9a59:	mov    %rax,%rbx
 10a9a5c:	jmp    10aa9a1 <myl_f_72cff91e1ca43adf6e3bd650d1fe503b405034486590fc282e877edc70061b44+0x13c1>
 10a9a61:	mov    %rbx,%rax
 10a9a64:	mov    -0x128(%rbp),%rdx
 10a9a6b:	mov    %rdx,-0x268(%rbp)
 10a9a72:	mov    %rcx,%r15
 10a9a75:	mov    -0x120(%rbp),%rcx
 10a9a7c:	mov    %rcx,-0x260(%rbp)
 10a9a83:	mov    %rax,%rbx
 10a9a86:	mov    -0x118(%rbp),%rax
 10a9a8d:	mov    %rax,-0x258(%rbp)
 10a9a94:	lea    -0x340(%rbp),%rsi
 10a9a9b:	mov    %rdi,%r14
 10a9a9e:	call   1147800 <myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_drop>
 10a9aa3:	mov    %r15,%rcx
 10a9aa6:	mov    %r14,%rdi
 10a9aa9:	mov    %rbx,%rax
 10a9aac:	mov    -0x268(%rbp),%rdx
 10a9ab3:	mov    %rdx,-0x340(%rbp)
 10a9aba:	mov    -0x260(%rbp),%rdx
 10a9ac1:	mov    %rdx,-0x338(%rbp)
 10a9ac8:	mov    %rax,%rbx
 10a9acb:	mov    -0x258(%rbp),%rax
 10a9ad2:	mov    %rax,-0x330(%rbp)
 10a9ad9:	mov    %rcx,%r15
 10a9adc:	lea    -0x340(%rbp),%rdx
 10a9ae3:	lea    -0x268(%rbp),%rsi
 10a9aea:	mov    %rdi,%r14
 10a9aed:	call   1147890 <myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_take>
 10a9af2:	mov    %r14,%rdi
 10a9af5:	cmp    $0x0,%eax
 10a9af8:	jne    10a9b0e <myl_f_72cff91e1ca43adf6e3bd650d1fe503b405034486590fc282e877edc70061b44+0x52e>
 10a9afa:	call   1169600 <myl_rc_take_failure>
 10a9aff:	mov    %r12,%rdi
 10a9b02:	mov    %eax,%esi
 10a9b04:	call   1159ab0 <myl_qbe_rc_status>
 10a9b09:	jmp    10aa9a1 <myl_f_72cff91e1ca43adf6e3bd650d1fe503b405034486590fc282e877edc70061b44+0x13c1>
 10a9b0e:	mov    %r13d,%r12d
 10a9b11:	cmp    $0x0,%r12d
 10a9b15:	jne    10a9b1c <myl_f_72cff91e1ca43adf6e3bd650d1fe503b405034486590fc282e877edc70061b44+0x53c>
 10a9b17:	mov    %rbx,%rax
 10a9b1a:	jmp    10a9b2b <myl_f_72cff91e1ca43adf6e3bd650d1fe503b405034486590fc282e877edc70061b44+0x54b>
 10a9b1c:	lea    -0x340(%rbp),%rsi
 10a9b23:	call   1147800 <myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_drop>
 10a9b28:	mov    %rbx,%rax
 10a9b2b:	mov    -0x268(%rbp),%rcx
 10a9b32:	mov    %rcx,(%rax)
 10a9b35:	mov    -0x260(%rbp),%rcx
 10a9b3c:	mov    %rcx,0x8(%rax)
 10a9b40:	mov    -0x258(%rbp),%rcx
 10a9b47:	mov    %rcx,0x10(%rax)
 10a9b4b:	mov    %rax,%r12
 10a9b4e:	jmp    10aa9ff <myl_f_72cff91e1ca43adf6e3bd650d1fe503b405034486590fc282e877edc70061b44+0x141f>
 10a9b53:	xchg   %r12,%rbx
 10a9b56:	mov    %rsi,%r14
 10a9b59:	lea    -0x340(%rbp),%rsi
 10a9b60:	mov    %rdi,%r13
 10a9b63:	call   1147800 <myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_drop>
 10a9b68:	mov    %r14,%rsi
 10a9b6b:	mov    %r13,%rdi
 10a9b6e:	mov    $0x1,%edx
 10a9b73:	mov    %rsi,%r14
 10a9b76:	mov    %rdi,%r13
 10a9b79:	mov    %rbx,%rdi
 10a9b7c:	call   1097020 <myl_f_851eb64c403b25f3166dffdb17dfc9e3c924451c20caa5851a74e0f4081ba50f>
 10a9b81:	mov    %r14,%rsi
 10a9b84:	mov    %r13,%rdi
 10a9b87:	mov    %rax,%rcx
 10a9b8a:	mov    %rdx,%rax
 10a9b8d:	mov    -0x34(%rbp),%r13d
 10a9b91:	mov    %rcx,-0x3d8(%rbp)
 10a9b98:	mov    %rax,-0x3d0(%rbp)
 10a9b9f:	cmp    $0x0,%r13d
 10a9ba3:	jne    10a9bb1 <myl_f_72cff91e1ca43adf6e3bd650d1fe503b405034486590fc282e877edc70061b44+0x5d1>
 10a9ba5:	mov    %r12,%rax
 10a9ba8:	mov    %r15,%rcx
 10a9bab:	mov    %r13d,-0x38(%rbp)
 10a9baf:	jmp    10a9bd6 <myl_f_72cff91e1ca43adf6e3bd650d1fe503b405034486590fc282e877edc70061b44+0x5f6>
 10a9bb1:	mov    %rsi,%r14
 10a9bb4:	lea    -0x340(%rbp),%rsi
 10a9bbb:	mov    %rdi,%r13
 10a9bbe:	call   1141730 <myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop>
 10a9bc3:	mov    %r15,%rcx
 10a9bc6:	mov    %r14,%rsi
 10a9bc9:	mov    %r13,%rdi
 10a9bcc:	mov    %r12,%rax
 10a9bcf:	movl   $0x0,-0x38(%rbp)
 10a9bd6:	mov    %rcx,%r15
 10a9bd9:	mov    -0x3d8(%rbp),%rcx
 10a9be0:	mov    %rcx,-0x198(%rbp)
 10a9be7:	mov    %rax,%r12
 10a9bea:	mov    -0x3d0(%rbp),%rax
 10a9bf1:	mov    %rax,-0x190(%rbp)
 10a9bf8:	mov    $0x0,%edx
 10a9bfd:	mov    %rsi,%r14
 10a9c00:	mov    %rdi,%r13
 10a9c03:	mov    %rbx,%rdi
 10a9c06:	call   1097020 <myl_f_851eb64c403b25f3166dffdb17dfc9e3c924451c20caa5851a74e0f4081ba50f>
 10a9c0b:	mov    %r14,%rsi
 10a9c0e:	mov    %r13,%rdi
 10a9c11:	mov    %rax,%rcx
 10a9c14:	mov    %rdx,%rax
 10a9c17:	mov    -0x38(%rbp),%r13d
 10a9c1b:	mov    %r13d,%r14d
 10a9c1e:	mov    -0x50(%rbp),%r13
 10a9c22:	mov    %rcx,-0x3c8(%rbp)
 10a9c29:	mov    %rax,-0x3c0(%rbp)
 10a9c30:	cmp    $0x0,%r14d
 10a9c34:	jne    10a9c3e <myl_f_72cff91e1ca43adf6e3bd650d1fe503b405034486590fc282e877edc70061b44+0x65e>
 10a9c36:	mov    %r12,%rax
 10a9c39:	mov    %r15,%rcx
 10a9c3c:	jmp    10a9c66 <myl_f_72cff91e1ca43adf6e3bd650d1fe503b405034486590fc282e877edc70061b44+0x686>
 10a9c3e:	mov    %rsi,%r14
 10a9c41:	lea    -0x340(%rbp),%rsi
 10a9c48:	mov    %rdi,%r13
 10a9c4b:	call   1141730 <myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop>
 10a9c50:	mov    %r15,%rcx
 10a9c53:	mov    %r14,%rsi
 10a9c56:	mov    %r13,%rdi
 10a9c59:	mov    %r12,%rax
 10a9c5c:	mov    -0x50(%rbp),%r13
 10a9c60:	mov    $0x0,%r14d
 10a9c66:	mov    %rcx,%r15
 10a9c69:	mov    -0x3c8(%rbp),%rcx
 10a9c70:	mov    %rcx,-0x188(%rbp)
 10a9c77:	mov    %rax,%r12
 10a9c7a:	mov    -0x3c0(%rbp),%rax
 10a9c81:	mov    %rax,-0x180(%rbp)
 10a9c88:	cmp    $0x0,%r14d
 10a9c8c:	je     10a9cb0 <myl_f_72cff91e1ca43adf6e3bd650d1fe503b405034486590fc282e877edc70061b44+0x6d0>
 10a9c8e:	mov    %rsi,%r14
 10a9c91:	lea    -0x340(%rbp),%rsi
 10a9c98:	mov    %rdi,%r13
 10a9c9b:	call   114a770 <myl_t_9db29878bb870aedd7beb381f7773c3f7385b7f4bb65a46f8c7260f8d4ec45b9_rcg_drop>
 10a9ca0:	mov    %r14,%rsi
 10a9ca3:	mov    %r13,%rdi
 10a9ca6:	mov    -0x50(%rbp),%r13
 10a9caa:	mov    $0x0,%r14d
 10a9cb0:	cmp    $0x0,%r14d
 10a9cb4:	jne    10a9cc5 <myl_f_72cff91e1ca43adf6e3bd650d1fe503b405034486590fc282e877edc70061b44+0x6e5>
 10a9cb6:	mov    %r12,%rax
 10a9cb9:	mov    %r15,%rcx
 10a9cbc:	mov    %r13,%r12
 10a9cbf:	mov    %r14d,-0x6c(%rbp)
 10a9cc3:	jmp    10a9cee <myl_f_72cff91e1ca43adf6e3bd650d1fe503b405034486590fc282e877edc70061b44+0x70e>
 10a9cc5:	mov    %rsi,%r14
 10a9cc8:	lea    -0x340(%rbp),%rsi
 10a9ccf:	mov    %rdi,%r13
 10a9cd2:	call   113fb10 <myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop>
 10a9cd7:	mov    %r15,%rcx
 10a9cda:	mov    %r14,%rsi
 10a9cdd:	mov    %r13,%rdi
 10a9ce0:	mov    %r12,%rax
 10a9ce3:	mov    -0x50(%rbp),%r12
 10a9ce7:	movl   $0x0,-0x6c(%rbp)
 10a9cee:	mov    0x8(%r12),%edx
 10a9cf3:	mov    %edx,-0x178(%rbp)
 10a9cf9:	movq   $0x0,-0x110(%rbp)
 10a9d04:	movq   $0x0,-0x108(%rbp)
 10a9d0f:	movl   $0x0,-0x110(%rbp)
 10a9d19:	mov    -0x110(%rbp),%rdx
 10a9d20:	mov    %rdx,-0x170(%rbp)
 10a9d27:	mov    %rcx,%r15
 10a9d2a:	mov    -0x108(%rbp),%rcx
 10a9d31:	mov    %rcx,-0x168(%rbp)
 10a9d38:	mov    %rax,%r12
 10a9d3b:	mov    -0x178(%rbp),%eax
 10a9d41:	cmp    $0xe,%rax
 10a9d45:	je     10aa815 <myl_f_72cff91e1ca43adf6e3bd650d1fe503b405034486590fc282e877edc70061b44+0x1235>
 10a9d4b:	cmp    $0xc,%rax
 10a9d4f:	je     10aa787 <myl_f_72cff91e1ca43adf6e3bd650d1fe503b405034486590fc282e877edc70061b44+0x11a7>
 10a9d55:	mov    %rsi,%r14
 10a9d58:	lea    -0x198(%rbp),%rsi
 10a9d5f:	mov    %rdi,%r13
 10a9d62:	mov    %rbx,%rdi
 10a9d65:	call   109cbf0 <myl_f_06f8e1aea800c9b41a5410887391e466d9a10e9d6e39101d9d6988189e351735>
 10a9d6a:	mov    %r15,%rcx
 10a9d6d:	mov    %r14,%rsi
 10a9d70:	mov    %r13,%rdi
 10a9d73:	mov    %rax,%r8
 10a9d76:	mov    %r12,%rax
 10a9d79:	mov    %r8,-0x3a8(%rbp)
 10a9d80:	mov    %rdx,-0x3a0(%rbp)
 10a9d87:	mov    %rcx,%r15
 10a9d8a:	mov    -0x3a8(%rbp),%rcx
 10a9d91:	mov    %rcx,-0x160(%rbp)
 10a9d98:	mov    %rax,%r12
 10a9d9b:	mov    -0x3a0(%rbp),%rax
 10a9da2:	mov    %rax,-0x158(%rbp)
 10a9da9:	mov    %rsi,%r14
 10a9dac:	lea    -0x188(%rbp),%rsi
 10a9db3:	mov    %rdi,%r13
 10a9db6:	mov    %rbx,%rdi
 10a9db9:	call   109cbf0 <myl_f_06f8e1aea800c9b41a5410887391e466d9a10e9d6e39101d9d6988189e351735>
 10a9dbe:	mov    %r15,%rcx
 10a9dc1:	mov    %r14,%rsi
 10a9dc4:	mov    %r13,%rdi
 10a9dc7:	mov    %rax,%r8
 10a9dca:	mov    %r12,%rax
 10a9dcd:	mov    -0x6c(%rbp),%r13d
 10a9dd1:	mov    -0x50(%rbp),%r12
 10a9dd5:	mov    %r8,-0x3b8(%rbp)
 10a9ddc:	mov    %rdx,-0x3b0(%rbp)
 10a9de3:	mov    -0x3b8(%rbp),%rdx
 10a9dea:	mov    %rdx,-0x150(%rbp)
 10a9df1:	mov    -0x3b0(%rbp),%rdx
 10a9df8:	mov    %rdx,-0x148(%rbp)
 10a9dff:	mov    -0x178(%rbp),%edx
 10a9e05:	cmp    $0x7,%rdx
 10a9e09:	sete   %dl
 10a9e0c:	movzbq %dl,%rdx
 10a9e10:	cmp    $0x0,%edx
 10a9e13:	jne    10aa1e2 <myl_f_72cff91e1ca43adf6e3bd650d1fe503b405034486590fc282e877edc70061b44+0xc02>
 10a9e19:	mov    %r12,%r13
 10a9e1c:	mov    -0x160(%rbp),%edx
 10a9e22:	cmp    $0x0,%rdx
 10a9e26:	sete   %r8b
 10a9e2a:	movzbq %r8b,%r8
 10a9e2e:	cmp    $0x0,%r8d
 10a9e32:	jne    10a9e4a <myl_f_72cff91e1ca43adf6e3bd650d1fe503b405034486590fc282e877edc70061b44+0x86a>
 10a9e34:	cmp    $0x1,%rdx
 10a9e38:	je     10a9e42 <myl_f_72cff91e1ca43adf6e3bd650d1fe503b405034486590fc282e877edc70061b44+0x862>
 10a9e3a:	mov    %rax,%rbx
 10a9e3d:	jmp    10aa9a1 <myl_f_72cff91e1ca43adf6e3bd650d1fe503b405034486590fc282e877edc70061b44+0x13c1>
 10a9e42:	mov    $0x0,%r8d
 10a9e48:	jmp    10a9e50 <myl_f_72cff91e1ca43adf6e3bd650d1fe503b405034486590fc282e877edc70061b44+0x870>
 10a9e4a:	mov    $0x1,%r8d
 10a9e50:	cmp    $0x0,%r8d
 10a9e54:	jne    10a9e81 <myl_f_72cff91e1ca43adf6e3bd650d1fe503b405034486590fc282e877edc70061b44+0x8a1>
 10a9e56:	mov    -0x150(%rbp),%r8d
 10a9e5d:	cmp    $0x0,%r8
 10a9e61:	je     10a9e79 <myl_f_72cff91e1ca43adf6e3bd650d1fe503b405034486590fc282e877edc70061b44+0x899>
 10a9e63:	cmp    $0x1,%r8
 10a9e67:	je     10a9e71 <myl_f_72cff91e1ca43adf6e3bd650d1fe503b405034486590fc282e877edc70061b44+0x891>
 10a9e69:	mov    %rax,%rbx
 10a9e6c:	jmp    10aa9a1 <myl_f_72cff91e1ca43adf6e3bd650d1fe503b405034486590fc282e877edc70061b44+0x13c1>
 10a9e71:	mov    $0x0,%r8d
 10a9e77:	jmp    10a9e87 <myl_f_72cff91e1ca43adf6e3bd650d1fe503b405034486590fc282e877edc70061b44+0x8a7>
 10a9e79:	mov    $0x1,%r8d
 10a9e7f:	jmp    10a9e87 <myl_f_72cff91e1ca43adf6e3bd650d1fe503b405034486590fc282e877edc70061b44+0x8a7>
 10a9e81:	mov    $0x1,%r8d
 10a9e87:	cmp    $0x0,%r8d
 10a9e8b:	jne    10a9f67 <myl_f_72cff91e1ca43adf6e3bd650d1fe503b405034486590fc282e877edc70061b44+0x987>
 10a9e91:	cmp    $0x0,%rdx
 10a9e95:	je     10a9f5a <myl_f_72cff91e1ca43adf6e3bd650d1fe503b405034486590fc282e877edc70061b44+0x97a>
 10a9e9b:	cmp    $0x1,%rdx
 10a9e9f:	je     10a9ea9 <myl_f_72cff91e1ca43adf6e3bd650d1fe503b405034486590fc282e877edc70061b44+0x8c9>
 10a9ea1:	mov    %rax,%rbx
 10a9ea4:	jmp    10aa9a1 <myl_f_72cff91e1ca43adf6e3bd650d1fe503b405034486590fc282e877edc70061b44+0x13c1>
 10a9ea9:	mov    %rax,%r12
 10a9eac:	mov    -0x158(%rbp),%rax
 10a9eb3:	mov    %rax,-0x268(%rbp)
 10a9eba:	mov    -0x150(%rbp),%edx
 10a9ec0:	cmp    $0x0,%rdx
 10a9ec4:	je     10a9f50 <myl_f_72cff91e1ca43adf6e3bd650d1fe503b405034486590fc282e877edc70061b44+0x970>
 10a9eca:	cmp    $0x1,%rdx
 10a9ece:	je     10a9ed8 <myl_f_72cff91e1ca43adf6e3bd650d1fe503b405034486590fc282e877edc70061b44+0x8f8>
 10a9ed0:	mov    %r12,%rbx
 10a9ed3:	jmp    10aa9a1 <myl_f_72cff91e1ca43adf6e3bd650d1fe503b405034486590fc282e877edc70061b44+0x13c1>
 10a9ed8:	mov    %rcx,%r15
 10a9edb:	mov    -0x148(%rbp),%rcx
 10a9ee2:	mov    %rcx,-0x268(%rbp)
 10a9ee9:	mov    %rax,%rdx
 10a9eec:	mov    %rsi,%r14
 10a9eef:	lea    -0x178(%rbp),%rsi
 10a9ef6:	mov    %rdi,%r13
 10a9ef9:	mov    %rbx,%rdi
 10a9efc:	call   10a7b30 <myl_f_549c194dd59052d6a584a91a45f8e27a465f53a107227cc684c6aadde33da3a0>
 10a9f01:	mov    %r15,%rcx
 10a9f04:	mov    %r14,%rsi
 10a9f07:	mov    %r13,%rdi
 10a9f0a:	mov    %rax,%r8
 10a9f0d:	mov    %r12,%rax
 10a9f10:	mov    -0x6c(%rbp),%r13d
 10a9f14:	mov    %r8,-0x378(%rbp)
 10a9f1b:	mov    %rdx,-0x370(%rbp)
 10a9f22:	mov    -0x378(%rbp),%rdx
 10a9f29:	mov    %rdx,-0x170(%rbp)
 10a9f30:	mov    -0x370(%rbp),%rdx
 10a9f37:	mov    %rdx,-0x168(%rbp)
 10a9f3e:	mov    %rcx,%r14
 10a9f41:	mov    %rbx,%r12
 10a9f44:	mov    %rax,%rbx
 10a9f47:	mov    %r13d,-0x70(%rbp)
 10a9f4b:	jmp    10aa897 <myl_f_72cff91e1ca43adf6e3bd650d1fe503b405034486590fc282e877edc70061b44+0x12b7>
 10a9f50:	mov    %rbx,%rdi
 10a9f53:	call   115a6c0 <myl_qbe_fail_assert>
 10a9f58:	ud2
 10a9f5a:	mov    %rbx,%rdi
 10a9f5d:	mov    %rdi,%r12
 10a9f60:	call   115a6c0 <myl_qbe_fail_assert>
 10a9f65:	ud2
 10a9f67:	mov    %rbx,%r12
 10a9f6a:	mov    0x1887d7(%rip),%rsi        # 1232748 <myl_lit_705b80a2adbffde33673cee9517989a5dbc62d5a47d462ddbd71f5170464b997>
 10a9f71:	mov    %rsi,-0x270(%rbp)
 10a9f78:	mov    %rcx,%r14
 10a9f7b:	mov    -0x270(%rbp),%rcx
 10a9f82:	mov    %rcx,-0x268(%rbp)
 10a9f89:	mov    %rax,%rbx
 10a9f8c:	mov    -0x268(%rbp),%rax
 10a9f93:	mov    %rax,-0x340(%rbp)
 10a9f9a:	mov    0x20(%r13),%rdx
 10a9f9e:	mov    %rdi,%r13
 10a9fa1:	mov    %r12,%rdi
 10a9fa4:	call   10af7e0 <myl_f_8c062ec4784d4b0491e6d5d24da0bf886cc822f390794d94cd35c159749aceeb_rc_borrow>
 10a9fa9:	mov    %r13,%rdi
 10a9fac:	mov    %rax,%rcx
 10a9faf:	mov    %rdx,%rax
 10a9fb2:	mov    %rcx,-0x388(%rbp)
 10a9fb9:	mov    %rax,-0x380(%rbp)
 10a9fc0:	lea    -0x388(%rbp),%rdx
 10a9fc7:	lea    -0x268(%rbp),%rsi
 10a9fce:	mov    %rdi,%r13
 10a9fd1:	call   114d210 <myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_loan>
 10a9fd6:	mov    %r14,%rcx
 10a9fd9:	mov    %r13,%rdi
 10a9fdc:	cmp    $0x0,%eax
 10a9fdf:	jne    10a9ffe <myl_f_72cff91e1ca43adf6e3bd650d1fe503b405034486590fc282e877edc70061b44+0xa1e>
 10a9fe1:	call   1169600 <myl_rc_take_failure>
 10a9fe6:	mov    %r12,%rdi
 10a9fe9:	mov    %eax,%esi
 10a9feb:	mov    %rdi,%r12
 10a9fee:	call   1159ab0 <myl_qbe_rc_status>
 10a9ff3:	mov    %rbx,%rax
 10a9ff6:	mov    %rax,%rbx
 10a9ff9:	jmp    10aa9a1 <myl_f_72cff91e1ca43adf6e3bd650d1fe503b405034486590fc282e877edc70061b44+0x13c1>
 10a9ffe:	mov    %rbx,%rax
 10aa001:	mov    -0x340(%rbp),%rsi
 10aa008:	cmp    $0x0,%rsi
 10aa00c:	je     10aa071 <myl_f_72cff91e1ca43adf6e3bd650d1fe503b405034486590fc282e877edc70061b44+0xa91>
 10aa00e:	mov    -0x10(%rsi),%rdx
 10aa012:	movabs $0x4000000000000002,%r8
 10aa01c:	and    %r8,%rdx
 10aa01f:	cmp    $0x0,%rdx
 10aa023:	jne    10aa066 <myl_f_72cff91e1ca43adf6e3bd650d1fe503b405034486590fc282e877edc70061b44+0xa86>
 10aa025:	mov    %rcx,%r14
 10aa028:	mov    -0x20(%rsi),%rcx
 10aa02c:	mov    %rcx,%rdx
 10aa02f:	sub    $0x1,%rdx
 10aa033:	jne    10aa05f <myl_f_72cff91e1ca43adf6e3bd650d1fe503b405034486590fc282e877edc70061b44+0xa7f>
 10aa035:	mov    %rax,%rbx
 10aa038:	mov    -0x18(%rsi),%rax
 10aa03c:	cmp    $0x0,%rax
 10aa040:	jne    10aa05c <myl_f_72cff91e1ca43adf6e3bd650d1fe503b405034486590fc282e877edc70061b44+0xa7c>
 10aa042:	lea    -0x340(%rbp),%rsi
 10aa049:	mov    %rdi,%r13
 10aa04c:	call   113f380 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop>
 10aa051:	mov    %r14,%rcx
 10aa054:	mov    %r13,%rdi
 10aa057:	mov    %rbx,%rax
 10aa05a:	jmp    10aa071 <myl_f_72cff91e1ca43adf6e3bd650d1fe503b405034486590fc282e877edc70061b44+0xa91>
 10aa05c:	mov    %rbx,%rax
 10aa05f:	mov    %r14,%rcx
 10aa062:	mov    %rdx,-0x20(%rsi)
 10aa066:	movq   $0x0,-0x340(%rbp)
 10aa071:	mov    -0x268(%rbp),%rdx
 10aa078:	mov    %rdx,-0x340(%rbp)
 10aa07f:	mov    -0x260(%rbp),%rdx
 10aa086:	mov    %rdx,-0x338(%rbp)
 10aa08d:	movq   $0x0,-0xa8(%rbp)
 10aa098:	mov    %rax,%rbx
 10aa09b:	lea    -0xa8(%rbp),%rax
 10aa0a2:	mov    %rax,%r13
 10aa0a5:	add    $0x8,%r13
 10aa0a9:	movq   $0x0,-0xa0(%rbp)
 10aa0b4:	movq   $0x0,-0x98(%rbp)
 10aa0bf:	movl   $0x1,-0xa8(%rbp)
 10aa0c9:	mov    %rcx,%r15
 10aa0cc:	lea    -0x340(%rbp),%rdx
 10aa0d3:	lea    -0x268(%rbp),%rsi
 10aa0da:	mov    %rdi,%r14
 10aa0dd:	call   114d340 <myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_retain>
 10aa0e2:	mov    %r14,%rdi
 10aa0e5:	cmp    $0x0,%eax
 10aa0e8:	jne    10aa101 <myl_f_72cff91e1ca43adf6e3bd650d1fe503b405034486590fc282e877edc70061b44+0xb21>
 10aa0ea:	call   1169600 <myl_rc_take_failure>
 10aa0ef:	mov    %r12,%rdi
 10aa0f2:	mov    %eax,%esi
 10aa0f4:	mov    %rdi,%r12
 10aa0f7:	call   1159ab0 <myl_qbe_rc_status>
 10aa0fc:	jmp    10aa9a1 <myl_f_72cff91e1ca43adf6e3bd650d1fe503b405034486590fc282e877edc70061b44+0x13c1>
 10aa101:	lea    -0x340(%rbp),%rsi
 10aa108:	mov    %rdi,%r14
 10aa10b:	call   114d260 <myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_unloan>
 10aa110:	mov    %r15,%rcx
 10aa113:	mov    %r14,%rdi
 10aa116:	mov    %rbx,%rax
 10aa119:	mov    %rcx,%r14
 10aa11c:	mov    -0x268(%rbp),%rcx
 10aa123:	mov    %rcx,0x0(%r13)
 10aa127:	mov    %rax,%rbx
 10aa12a:	mov    -0x260(%rbp),%rax
 10aa131:	mov    %rax,0x8(%r13)
 10aa135:	mov    $0xaa,%esi
 10aa13a:	mov    %rdi,%r13
 10aa13d:	lea    0x118454(%rip),%rdi        # 11c2598 <myl_f_72cff91e1ca43adf6e3bd650d1fe503b405034486590fc282e877edc70061b44_meta>
 10aa144:	call   115c021 <myl_qbe_error_trace_origin>
 10aa149:	mov    %r14,%rcx
 10aa14c:	mov    %r13,%rdi
 10aa14f:	mov    %rbx,%rax
 10aa152:	mov    -0xa8(%rbp),%rdx
 10aa159:	mov    %rdx,-0x340(%rbp)
 10aa160:	mov    -0xa0(%rbp),%rdx
 10aa167:	mov    %rdx,-0x338(%rbp)
 10aa16e:	mov    %rax,%rbx
 10aa171:	mov    -0x98(%rbp),%rax
 10aa178:	mov    %rax,-0x330(%rbp)
 10aa17f:	lea    -0x340(%rbp),%rdx
 10aa186:	lea    -0x268(%rbp),%rsi
 10aa18d:	mov    %rdi,%r13
 10aa190:	call   1147890 <myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_take>
 10aa195:	mov    %r13,%rdi
 10aa198:	cmp    $0x0,%eax
 10aa19b:	jne    10aa1ba <myl_f_72cff91e1ca43adf6e3bd650d1fe503b405034486590fc282e877edc70061b44+0xbda>
 10aa19d:	call   1169600 <myl_rc_take_failure>
 10aa1a2:	mov    %r12,%rdi
 10aa1a5:	mov    %eax,%esi
 10aa1a7:	mov    %rdi,%r12
 10aa1aa:	call   1159ab0 <myl_qbe_rc_status>
 10aa1af:	mov    %rbx,%rax
 10aa1b2:	mov    %rax,%rbx
 10aa1b5:	jmp    10aa9a1 <myl_f_72cff91e1ca43adf6e3bd650d1fe503b405034486590fc282e877edc70061b44+0x13c1>
 10aa1ba:	mov    %rbx,%rax
 10aa1bd:	mov    -0x268(%rbp),%rcx
 10aa1c4:	mov    %rcx,(%rax)
 10aa1c7:	mov    -0x260(%rbp),%rcx
 10aa1ce:	mov    %rcx,0x8(%rax)
 10aa1d2:	mov    -0x258(%rbp),%rcx
 10aa1d9:	mov    %rcx,0x10(%rax)
 10aa1dd:	jmp    10aa9ff <myl_f_72cff91e1ca43adf6e3bd650d1fe503b405034486590fc282e877edc70061b44+0x141f>
 10aa1e2:	mov    %rbx,%r12
 10aa1e5:	mov    -0x160(%rbp),%edx
 10aa1eb:	cmp    $0x0,%rdx
 10aa1ef:	mov    %rcx,%r15
 10aa1f2:	sete   %cl
 10aa1f5:	movzbq %cl,%rcx
 10aa1f9:	cmp    $0x0,%ecx
 10aa1fc:	jne    10aa213 <myl_f_72cff91e1ca43adf6e3bd650d1fe503b405034486590fc282e877edc70061b44+0xc33>
 10aa1fe:	cmp    $0x1,%rdx
 10aa202:	je     10aa20c <myl_f_72cff91e1ca43adf6e3bd650d1fe503b405034486590fc282e877edc70061b44+0xc2c>
 10aa204:	mov    %rax,%rbx
 10aa207:	jmp    10aa9a1 <myl_f_72cff91e1ca43adf6e3bd650d1fe503b405034486590fc282e877edc70061b44+0x13c1>
 10aa20c:	mov    $0x0,%ecx
 10aa211:	jmp    10aa218 <myl_f_72cff91e1ca43adf6e3bd650d1fe503b405034486590fc282e877edc70061b44+0xc38>
 10aa213:	mov    $0x1,%ecx
 10aa218:	xor    $0x1,%rcx
 10aa21c:	jne    10aa228 <myl_f_72cff91e1ca43adf6e3bd650d1fe503b405034486590fc282e877edc70061b44+0xc48>
 10aa21e:	mov    %rax,%rbx
 10aa221:	mov    $0x0,%eax
 10aa226:	jmp    10aa251 <myl_f_72cff91e1ca43adf6e3bd650d1fe503b405034486590fc282e877edc70061b44+0xc71>
 10aa228:	mov    %rax,%rbx
 10aa22b:	mov    -0x150(%rbp),%eax
 10aa231:	cmp    $0x0,%rax
 10aa235:	je     10aa248 <myl_f_72cff91e1ca43adf6e3bd650d1fe503b405034486590fc282e877edc70061b44+0xc68>
 10aa237:	cmp    $0x1,%rax
 10aa23b:	jne    10aa9a1 <myl_f_72cff91e1ca43adf6e3bd650d1fe503b405034486590fc282e877edc70061b44+0x13c1>
 10aa241:	mov    $0x0,%eax
 10aa246:	jmp    10aa24d <myl_f_72cff91e1ca43adf6e3bd650d1fe503b405034486590fc282e877edc70061b44+0xc6d>
 10aa248:	mov    $0x1,%eax
 10aa24d:	xor    $0x1,%rax
 10aa251:	cmp    $0x0,%eax
 10aa254:	jne    10aa6b0 <myl_f_72cff91e1ca43adf6e3bd650d1fe503b405034486590fc282e877edc70061b44+0x10d0>
 10aa25a:	lea    -0x198(%rbp),%rdx
 10aa261:	mov    %rsi,%r14
 10aa264:	mov    %rdi,%r13
 10aa267:	mov    %r12,%rdi
 10aa26a:	call   109ce60 <myl_f_0c155c0779b8bdd25c5e93399d26b7ce8537f2f7388c677f2661e05c296c2007>
 10aa26f:	mov    %r14,%rsi
 10aa272:	mov    %r13,%rdi
 10aa275:	mov    -0x6c(%rbp),%r13d
 10aa279:	mov    -0x50(%rbp),%r14
 10aa27d:	mov    %rax,-0x40(%rbp)
 10aa281:	cmp    $0x0,%r13d
 10aa285:	jne    10aa28c <myl_f_72cff91e1ca43adf6e3bd650d1fe503b405034486590fc282e877edc70061b44+0xcac>
 10aa287:	xchg   %r13,%r14
 10aa28a:	jmp    10aa2b8 <myl_f_72cff91e1ca43adf6e3bd650d1fe503b405034486590fc282e877edc70061b44+0xcd8>
 10aa28c:	mov    %rsi,%r14
 10aa28f:	lea    -0x340(%rbp),%rsi
 10aa296:	mov    %rdi,%r13
 10aa299:	call   1141730 <myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop>
 10aa29e:	mov    %r14,%rsi
 10aa2a1:	mov    %r13,%rdi
 10aa2a4:	mov    %rbx,%rax
 10aa2a7:	mov    %rax,%rbx
 10aa2aa:	mov    -0x40(%rbp),%rax
 10aa2ae:	mov    -0x50(%rbp),%r13
 10aa2b2:	mov    $0x0,%r14d
 10aa2b8:	mov    %r14d,-0x5c(%rbp)
 10aa2bc:	cmp    $0x0,%eax
 10aa2bf:	jne    10aa2d2 <myl_f_72cff91e1ca43adf6e3bd650d1fe503b405034486590fc282e877edc70061b44+0xcf2>
 10aa2c1:	mov    %rbx,%rax
 10aa2c4:	mov    %r15,%rcx
 10aa2c7:	mov    %r14d,-0x60(%rbp)
 10aa2cb:	mov    $0x0,%edx
 10aa2d0:	jmp    10aa33f <myl_f_72cff91e1ca43adf6e3bd650d1fe503b405034486590fc282e877edc70061b44+0xd5f>
 10aa2d2:	lea    -0x188(%rbp),%rdx
 10aa2d9:	mov    %rsi,%r14
 10aa2dc:	mov    %rdi,%r13
 10aa2df:	mov    %r12,%rdi
 10aa2e2:	call   109ce60 <myl_f_0c155c0779b8bdd25c5e93399d26b7ce8537f2f7388c677f2661e05c296c2007>
 10aa2e7:	mov    %r14,%rsi
 10aa2ea:	mov    %r13,%rdi
 10aa2ed:	mov    %rax,%rdx
 10aa2f0:	mov    -0x5c(%rbp),%r13d
 10aa2f4:	mov    %r13d,%r14d
 10aa2f7:	mov    -0x50(%rbp),%r13
 10aa2fb:	mov    %rdx,-0x48(%rbp)
 10aa2ff:	cmp    $0x0,%r14d
 10aa303:	jne    10aa30d <myl_f_72cff91e1ca43adf6e3bd650d1fe503b405034486590fc282e877edc70061b44+0xd2d>
 10aa305:	mov    %rbx,%rax
 10aa308:	mov    %r15,%rcx
 10aa30b:	jmp    10aa339 <myl_f_72cff91e1ca43adf6e3bd650d1fe503b405034486590fc282e877edc70061b44+0xd59>
 10aa30d:	mov    %rsi,%r14
 10aa310:	lea    -0x340(%rbp),%rsi
 10aa317:	mov    %rdi,%r13
 10aa31a:	call   1141730 <myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop>
 10aa31f:	mov    %r15,%rcx
 10aa322:	mov    %r14,%rsi
 10aa325:	mov    %r13,%rdi
 10aa328:	mov    %rbx,%rax
 10aa32b:	mov    -0x48(%rbp),%rdx
 10aa32f:	mov    -0x50(%rbp),%r13
 10aa333:	mov    $0x0,%r14d
 10aa339:	mov    %r14d,%ebx
 10aa33c:	mov    %ebx,-0x60(%rbp)
 10aa33f:	cmp    $0x0,%edx
 10aa342:	jne    10aa5c6 <myl_f_72cff91e1ca43adf6e3bd650d1fe503b405034486590fc282e877edc70061b44+0xfe6>
 10aa348:	mov    0x188311(%rip),%rsi        # 1232660 <myl_lit_4e8cfc313e5d17fa73eb3c68075707ac391b284630fd27670b213105e8e5ed9b>
 10aa34f:	mov    %rsi,-0x270(%rbp)
 10aa356:	mov    %rcx,%r14
 10aa359:	mov    -0x270(%rbp),%rcx
 10aa360:	mov    %rcx,-0x268(%rbp)
 10aa367:	mov    %rax,%rbx
 10aa36a:	mov    -0x268(%rbp),%rax
 10aa371:	mov    %rax,-0x340(%rbp)
 10aa378:	mov    0x20(%r13),%rdx
 10aa37c:	mov    %rdi,%r13
 10aa37f:	mov    %r12,%rdi
 10aa382:	call   10af7e0 <myl_f_8c062ec4784d4b0491e6d5d24da0bf886cc822f390794d94cd35c159749aceeb_rc_borrow>
 10aa387:	mov    %r13,%rdi
 10aa38a:	mov    %rax,%rcx
 10aa38d:	mov    %rdx,%rax
 10aa390:	mov    %rcx,-0x398(%rbp)
 10aa397:	mov    %rax,-0x390(%rbp)
 10aa39e:	lea    -0x398(%rbp),%rdx
 10aa3a5:	lea    -0x268(%rbp),%rsi
 10aa3ac:	mov    %rdi,%r13
 10aa3af:	call   114d210 <myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_loan>
 10aa3b4:	mov    %r14,%rcx
 10aa3b7:	mov    %r13,%rdi
 10aa3ba:	cmp    $0x0,%eax
 10aa3bd:	jne    10aa3dc <myl_f_72cff91e1ca43adf6e3bd650d1fe503b405034486590fc282e877edc70061b44+0xdfc>
 10aa3bf:	call   1169600 <myl_rc_take_failure>
 10aa3c4:	mov    %r12,%rdi
 10aa3c7:	mov    %eax,%esi
 10aa3c9:	mov    %rdi,%r12
 10aa3cc:	call   1159ab0 <myl_qbe_rc_status>
 10aa3d1:	mov    %rbx,%rax
 10aa3d4:	mov    %rax,%rbx
 10aa3d7:	jmp    10aa9a1 <myl_f_72cff91e1ca43adf6e3bd650d1fe503b405034486590fc282e877edc70061b44+0x13c1>
 10aa3dc:	mov    %rbx,%rax
 10aa3df:	mov    -0x340(%rbp),%rsi
 10aa3e6:	cmp    $0x0,%rsi
 10aa3ea:	je     10aa44f <myl_f_72cff91e1ca43adf6e3bd650d1fe503b405034486590fc282e877edc70061b44+0xe6f>
 10aa3ec:	mov    -0x10(%rsi),%rdx
 10aa3f0:	movabs $0x4000000000000002,%r8
 10aa3fa:	and    %r8,%rdx
 10aa3fd:	cmp    $0x0,%rdx
 10aa401:	jne    10aa444 <myl_f_72cff91e1ca43adf6e3bd650d1fe503b405034486590fc282e877edc70061b44+0xe64>
 10aa403:	mov    %rcx,%r14
 10aa406:	mov    -0x20(%rsi),%rcx
 10aa40a:	mov    %rcx,%rdx
 10aa40d:	sub    $0x1,%rdx
 10aa411:	jne    10aa43d <myl_f_72cff91e1ca43adf6e3bd650d1fe503b405034486590fc282e877edc70061b44+0xe5d>
 10aa413:	mov    %rax,%rbx
 10aa416:	mov    -0x18(%rsi),%rax
 10aa41a:	cmp    $0x0,%rax
 10aa41e:	jne    10aa43a <myl_f_72cff91e1ca43adf6e3bd650d1fe503b405034486590fc282e877edc70061b44+0xe5a>
 10aa420:	lea    -0x340(%rbp),%rsi
 10aa427:	mov    %rdi,%r13
 10aa42a:	call   113f380 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop>
 10aa42f:	mov    %r14,%rcx
 10aa432:	mov    %r13,%rdi
 10aa435:	mov    %rbx,%rax
 10aa438:	jmp    10aa44f <myl_f_72cff91e1ca43adf6e3bd650d1fe503b405034486590fc282e877edc70061b44+0xe6f>
 10aa43a:	mov    %rbx,%rax
 10aa43d:	mov    %r14,%rcx
 10aa440:	mov    %rdx,-0x20(%rsi)
 10aa444:	movq   $0x0,-0x340(%rbp)
 10aa44f:	mov    -0x268(%rbp),%rdx
 10aa456:	mov    %rdx,-0x340(%rbp)
 10aa45d:	mov    -0x260(%rbp),%rdx
 10aa464:	mov    %rdx,-0x338(%rbp)
 10aa46b:	movq   $0x0,-0xc0(%rbp)
 10aa476:	mov    %rax,%rbx
 10aa479:	lea    -0xc0(%rbp),%rax
 10aa480:	mov    %rax,%r13
 10aa483:	add    $0x8,%r13
 10aa487:	movq   $0x0,-0xb8(%rbp)
 10aa492:	movq   $0x0,-0xb0(%rbp)
 10aa49d:	movl   $0x1,-0xc0(%rbp)
 10aa4a7:	mov    %rcx,%r15
 10aa4aa:	lea    -0x340(%rbp),%rdx
 10aa4b1:	lea    -0x268(%rbp),%rsi
 10aa4b8:	mov    %rdi,%r14
 10aa4bb:	call   114d340 <myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_retain>
 10aa4c0:	mov    %r14,%rdi
 10aa4c3:	cmp    $0x0,%eax
 10aa4c6:	jne    10aa4df <myl_f_72cff91e1ca43adf6e3bd650d1fe503b405034486590fc282e877edc70061b44+0xeff>
 10aa4c8:	call   1169600 <myl_rc_take_failure>
 10aa4cd:	mov    %r12,%rdi
 10aa4d0:	mov    %eax,%esi
 10aa4d2:	mov    %rdi,%r12
 10aa4d5:	call   1159ab0 <myl_qbe_rc_status>
 10aa4da:	jmp    10aa9a1 <myl_f_72cff91e1ca43adf6e3bd650d1fe503b405034486590fc282e877edc70061b44+0x13c1>
 10aa4df:	lea    -0x340(%rbp),%rsi
 10aa4e6:	mov    %rdi,%r14
 10aa4e9:	call   114d260 <myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_unloan>
 10aa4ee:	mov    %r15,%rcx
 10aa4f1:	mov    %r14,%rdi
 10aa4f4:	mov    %rbx,%rax
 10aa4f7:	mov    %rcx,%r14
 10aa4fa:	mov    -0x268(%rbp),%rcx
 10aa501:	mov    %rcx,0x0(%r13)
 10aa505:	mov    %rax,%rbx
 10aa508:	mov    -0x260(%rbp),%rax
 10aa50f:	mov    %rax,0x8(%r13)
 10aa513:	mov    $0x8c,%esi
 10aa518:	mov    %rdi,%r13
 10aa51b:	lea    0x118076(%rip),%rdi        # 11c2598 <myl_f_72cff91e1ca43adf6e3bd650d1fe503b405034486590fc282e877edc70061b44_meta>
 10aa522:	call   115c021 <myl_qbe_error_trace_origin>
 10aa527:	mov    %r14,%rcx
 10aa52a:	mov    %r13,%rdi
 10aa52d:	mov    %rbx,%rax
 10aa530:	mov    -0xc0(%rbp),%rdx
 10aa537:	mov    %rdx,-0x340(%rbp)
 10aa53e:	mov    -0xb8(%rbp),%rdx
 10aa545:	mov    %rdx,-0x338(%rbp)
 10aa54c:	mov    %rax,%rbx
 10aa54f:	mov    -0xb0(%rbp),%rax
 10aa556:	mov    %rax,-0x330(%rbp)
 10aa55d:	mov    %rcx,%r15
 10aa560:	lea    -0x340(%rbp),%rdx
 10aa567:	lea    -0x268(%rbp),%rsi
 10aa56e:	mov    %rdi,%r13
 10aa571:	call   1147890 <myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_take>
 10aa576:	mov    %r13,%rdi
 10aa579:	cmp    $0x0,%eax
 10aa57c:	jne    10aa59b <myl_f_72cff91e1ca43adf6e3bd650d1fe503b405034486590fc282e877edc70061b44+0xfbb>
 10aa57e:	call   1169600 <myl_rc_take_failure>
 10aa583:	mov    %r12,%rdi
 10aa586:	mov    %eax,%esi
 10aa588:	mov    %rdi,%r12
 10aa58b:	call   1159ab0 <myl_qbe_rc_status>
 10aa590:	mov    %rbx,%rax
 10aa593:	mov    %rax,%rbx
 10aa596:	jmp    10aa9a1 <myl_f_72cff91e1ca43adf6e3bd650d1fe503b405034486590fc282e877edc70061b44+0x13c1>
 10aa59b:	mov    %rbx,%rax
 10aa59e:	mov    -0x268(%rbp),%rcx
 10aa5a5:	mov    %rcx,(%rax)
 10aa5a8:	mov    -0x260(%rbp),%rcx
 10aa5af:	mov    %rcx,0x8(%rax)
 10aa5b3:	mov    -0x258(%rbp),%rcx
 10aa5ba:	mov    %rcx,0x10(%rax)
 10aa5be:	mov    %rax,%rbx
 10aa5c1:	jmp    10aa9ff <myl_f_72cff91e1ca43adf6e3bd650d1fe503b405034486590fc282e877edc70061b44+0x141f>
 10aa5c6:	mov    %rax,%rbx
 10aa5c9:	mov    %rcx,%r15
 10aa5cc:	mov    %rsi,%r14
 10aa5cf:	lea    -0x198(%rbp),%rsi
 10aa5d6:	mov    %rdi,%r13
 10aa5d9:	mov    %r12,%rdi
 10aa5dc:	call   10b8660 <myl_f_ea97dd36e4e0ea42e46ce6a891c9a00cafb686a8c9a27c77fe327a84d70301d7>
 10aa5e1:	mov    %r14,%rsi
 10aa5e4:	mov    %r13,%rdi
 10aa5e7:	mov    %rax,-0x58(%rbp)
 10aa5eb:	mov    %rsi,%r14
 10aa5ee:	lea    -0x188(%rbp),%rsi
 10aa5f5:	mov    %rdi,%r13
 10aa5f8:	mov    %r12,%rdi
 10aa5fb:	call   10b8660 <myl_f_ea97dd36e4e0ea42e46ce6a891c9a00cafb686a8c9a27c77fe327a84d70301d7>
 10aa600:	mov    %r14,%rsi
 10aa603:	mov    %r13,%rdi
 10aa606:	mov    %rax,%rcx
 10aa609:	mov    -0x58(%rbp),%rdx
 10aa60d:	mov    %rsi,%r14
 10aa610:	mov    %rdi,%r13
 10aa613:	mov    %r12,%rdi
 10aa616:	call   10bae50 <myl_f_47614935f4c1a8cf04cb9956ad991281881c4a7abd3bc9a4a6c225cb77d4b069>
 10aa61b:	mov    %r14,%rsi
 10aa61e:	mov    %r13,%rdi
 10aa621:	mov    %rax,%rdx
 10aa624:	mov    -0x60(%rbp),%r13d
 10aa628:	mov    %rdx,-0x68(%rbp)
 10aa62c:	cmp    $0x0,%r13d
 10aa630:	jne    10aa63a <myl_f_72cff91e1ca43adf6e3bd650d1fe503b405034486590fc282e877edc70061b44+0x105a>
 10aa632:	mov    %rbx,%rax
 10aa635:	mov    %r15,%rcx
 10aa638:	jmp    10aa662 <myl_f_72cff91e1ca43adf6e3bd650d1fe503b405034486590fc282e877edc70061b44+0x1082>
 10aa63a:	mov    %rsi,%r14
 10aa63d:	lea    -0x340(%rbp),%rsi
 10aa644:	mov    %rdi,%r13
 10aa647:	call   1141730 <myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop>
 10aa64c:	mov    %r15,%rcx
 10aa64f:	mov    %r14,%rsi
 10aa652:	mov    %r13,%rdi
 10aa655:	mov    %rbx,%rax
 10aa658:	mov    -0x68(%rbp),%rdx
 10aa65c:	mov    $0x0,%r13d
 10aa662:	movq   $0x0,-0xd0(%rbp)
 10aa66d:	movq   $0x0,-0xc8(%rbp)
 10aa678:	movl   $0x3,-0xd0(%rbp)
 10aa682:	mov    %rdx,-0xc8(%rbp)
 10aa689:	mov    -0xd0(%rbp),%rdx
 10aa690:	mov    %rdx,-0x170(%rbp)
 10aa697:	mov    -0xc8(%rbp),%rdx
 10aa69e:	mov    %rdx,-0x168(%rbp)
 10aa6a5:	mov    %rax,%rbx
 10aa6a8:	mov    %rcx,%r15
 10aa6ab:	jmp    10aa764 <myl_f_72cff91e1ca43adf6e3bd650d1fe503b405034486590fc282e877edc70061b44+0x1184>
 10aa6b0:	mov    %rbx,%rax
 10aa6b3:	mov    %r15,%rcx
 10aa6b6:	cmp    $0x0,%rdx
 10aa6ba:	je     10aa77a <myl_f_72cff91e1ca43adf6e3bd650d1fe503b405034486590fc282e877edc70061b44+0x119a>
 10aa6c0:	cmp    $0x1,%rdx
 10aa6c4:	je     10aa6ce <myl_f_72cff91e1ca43adf6e3bd650d1fe503b405034486590fc282e877edc70061b44+0x10ee>
 10aa6c6:	mov    %rax,%rbx
 10aa6c9:	jmp    10aa9a1 <myl_f_72cff91e1ca43adf6e3bd650d1fe503b405034486590fc282e877edc70061b44+0x13c1>
 10aa6ce:	mov    -0x158(%rbp),%r8
 10aa6d5:	mov    %r8,-0x268(%rbp)
 10aa6dc:	mov    -0x150(%rbp),%edx
 10aa6e2:	cmp    $0x0,%rdx
 10aa6e6:	je     10aa770 <myl_f_72cff91e1ca43adf6e3bd650d1fe503b405034486590fc282e877edc70061b44+0x1190>
 10aa6ec:	cmp    $0x1,%rdx
 10aa6f0:	je     10aa6fa <myl_f_72cff91e1ca43adf6e3bd650d1fe503b405034486590fc282e877edc70061b44+0x111a>
 10aa6f2:	mov    %rax,%rbx
 10aa6f5:	jmp    10aa9a1 <myl_f_72cff91e1ca43adf6e3bd650d1fe503b405034486590fc282e877edc70061b44+0x13c1>
 10aa6fa:	mov    -0x148(%rbp),%rdx
 10aa701:	mov    %rdx,-0x268(%rbp)
 10aa708:	movq   %r8,%xmm0
 10aa70d:	movq   %rdx,%xmm1
 10aa712:	addsd  %xmm1,%xmm0
 10aa716:	movq   %xmm0,%rdx
 10aa71b:	movq   $0x0,-0xe0(%rbp)
 10aa726:	movq   $0x0,-0xd8(%rbp)
 10aa731:	movl   $0x2,-0xe0(%rbp)
 10aa73b:	mov    %rdx,-0xd8(%rbp)
 10aa742:	mov    %rcx,%r15
 10aa745:	mov    -0xe0(%rbp),%rcx
 10aa74c:	mov    %rcx,-0x170(%rbp)
 10aa753:	mov    %rax,%rbx
 10aa756:	mov    -0xd8(%rbp),%rax
 10aa75d:	mov    %rax,-0x168(%rbp)
 10aa764:	mov    %r15,%r14
 10aa767:	mov    %r13d,-0x70(%rbp)
 10aa76b:	jmp    10aa897 <myl_f_72cff91e1ca43adf6e3bd650d1fe503b405034486590fc282e877edc70061b44+0x12b7>
 10aa770:	mov    %r12,%rdi
 10aa773:	call   115a6c0 <myl_qbe_fail_assert>
 10aa778:	ud2
 10aa77a:	mov    %r12,%rdi
 10aa77d:	mov    %rdi,%r12
 10aa780:	call   115a6c0 <myl_qbe_fail_assert>
 10aa785:	ud2
 10aa787:	xchg   %rbx,%r12
 10aa78a:	lea    -0x188(%rbp),%rdx
 10aa791:	mov    %rsi,%r14
 10aa794:	lea    -0x198(%rbp),%rsi
 10aa79b:	mov    %rdi,%r13
 10aa79e:	mov    %r12,%rdi
 10aa7a1:	call   1121c70 <myl_f_393b03e6e8000a2be3bf0bb432f9197ce3fbfd4c525e561e0f9e9b1b3cc38f9b>
 10aa7a6:	mov    %r15,%rcx
 10aa7a9:	mov    %r14,%rsi
 10aa7ac:	mov    %r13,%rdi
 10aa7af:	mov    %rax,%rdx
 10aa7b2:	mov    %rbx,%rax
 10aa7b5:	mov    -0x6c(%rbp),%r13d
 10aa7b9:	xor    $0x1,%rdx
 10aa7bd:	movq   $0x0,-0xf0(%rbp)
 10aa7c8:	movq   $0x0,-0xe8(%rbp)
 10aa7d3:	movl   $0x1,-0xf0(%rbp)
 10aa7dd:	movzbq %dl,%rdx
 10aa7e1:	mov    %dl,-0xe8(%rbp)
 10aa7e7:	mov    %rcx,%r15
 10aa7ea:	mov    -0xf0(%rbp),%rcx
 10aa7f1:	mov    %rcx,-0x170(%rbp)
 10aa7f8:	mov    %rax,%rbx
 10aa7fb:	mov    -0xe8(%rbp),%rax
 10aa802:	mov    %rax,-0x168(%rbp)
 10aa809:	mov    %r15,%r14
 10aa80c:	mov    %r13d,-0x70(%rbp)
 10aa810:	jmp    10aa897 <myl_f_72cff91e1ca43adf6e3bd650d1fe503b405034486590fc282e877edc70061b44+0x12b7>
 10aa815:	xchg   %rbx,%r12
 10aa818:	lea    -0x188(%rbp),%rdx
 10aa81f:	mov    %rsi,%r14
 10aa822:	lea    -0x198(%rbp),%rsi
 10aa829:	mov    %rdi,%r13
 10aa82c:	mov    %r12,%rdi
 10aa82f:	call   1121c70 <myl_f_393b03e6e8000a2be3bf0bb432f9197ce3fbfd4c525e561e0f9e9b1b3cc38f9b>
 10aa834:	mov    %r15,%rcx
 10aa837:	mov    %r14,%rsi
 10aa83a:	mov    %r13,%rdi
 10aa83d:	mov    %rax,%rdx
 10aa840:	mov    %rbx,%rax
 10aa843:	mov    -0x6c(%rbp),%r13d
 10aa847:	movq   $0x0,-0x100(%rbp)
 10aa852:	movq   $0x0,-0xf8(%rbp)
 10aa85d:	movl   $0x1,-0x100(%rbp)
 10aa867:	movzbq %dl,%rdx
 10aa86b:	mov    %dl,-0xf8(%rbp)
 10aa871:	mov    %rcx,%r14
 10aa874:	mov    -0x100(%rbp),%rcx
 10aa87b:	mov    %rcx,-0x170(%rbp)
 10aa882:	mov    %rax,%rbx
 10aa885:	mov    -0xf8(%rbp),%rax
 10aa88c:	mov    %rax,-0x168(%rbp)
 10aa893:	mov    %r13d,-0x70(%rbp)
 10aa897:	mov    %rsi,%r15
 10aa89a:	mov    %rdi,%r13
 10aa89d:	mov    %r12,%rdi
 10aa8a0:	call   108dfe0 <myl_f_339494ddd89a48d13094d9f5c6b4b55320c4f6128bc80d7aba97a84a17838cc1>
 10aa8a5:	mov    %r15,%rsi
 10aa8a8:	mov    %r13,%rdi
 10aa8ab:	mov    %rax,%rcx
 10aa8ae:	mov    %rdx,%rax
 10aa8b1:	mov    -0x70(%rbp),%r13d
 10aa8b5:	mov    %rcx,-0x368(%rbp)
 10aa8bc:	mov    %rax,-0x360(%rbp)
 10aa8c3:	cmp    $0x0,%r13d
 10aa8c7:	je     10aa8e7 <myl_f_72cff91e1ca43adf6e3bd650d1fe503b405034486590fc282e877edc70061b44+0x1307>
 10aa8c9:	mov    %rsi,%r15
 10aa8cc:	lea    -0x340(%rbp),%rsi
 10aa8d3:	mov    %rdi,%r13
 10aa8d6:	call   1141730 <myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop>
 10aa8db:	mov    %r15,%rsi
 10aa8de:	mov    %r13,%rdi
 10aa8e1:	mov    $0x0,%r13d
 10aa8e7:	lea    -0x170(%rbp),%rdx
 10aa8ee:	mov    %rdi,%r15
 10aa8f1:	mov    %r12,%rdi
 10aa8f4:	call   109cfd0 <myl_f_1e67eb8ef4c3a3acc3a97242d455a6d9c8a2bcb48d8912e38331c2e291a74a0e>
 10aa8f9:	mov    %r15,%rdi
 10aa8fc:	cmp    $0x0,%r13d
 10aa900:	jne    10aa90a <myl_f_72cff91e1ca43adf6e3bd650d1fe503b405034486590fc282e877edc70061b44+0x132a>
 10aa902:	mov    %rbx,%rax
 10aa905:	mov    %r14,%rcx
 10aa908:	jmp    10aa922 <myl_f_72cff91e1ca43adf6e3bd650d1fe503b405034486590fc282e877edc70061b44+0x1342>
 10aa90a:	lea    -0x340(%rbp),%rsi
 10aa911:	mov    %rdi,%r13
 10aa914:	call   1141730 <myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop>
 10aa919:	mov    %r14,%rcx
 10aa91c:	mov    %r13,%rdi
 10aa91f:	mov    %rbx,%rax
 10aa922:	movq   $0x0,-0x90(%rbp)
 10aa92d:	movq   $0x0,-0x88(%rbp)
 10aa938:	movq   $0x0,-0x80(%rbp)
 10aa940:	movl   $0x0,-0x90(%rbp)
 10aa94a:	mov    -0x90(%rbp),%rdx
 10aa951:	mov    %rdx,-0x340(%rbp)
 10aa958:	mov    -0x88(%rbp),%rdx
 10aa95f:	mov    %rdx,-0x338(%rbp)
 10aa966:	mov    %rax,%rbx
 10aa969:	mov    -0x80(%rbp),%rax
 10aa96d:	mov    %rax,-0x330(%rbp)
 10aa974:	lea    -0x340(%rbp),%rdx
 10aa97b:	lea    -0x268(%rbp),%rsi
 10aa982:	mov    %rdi,%r13
 10aa985:	call   1147890 <myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_take>
 10aa98a:	mov    %r13,%rdi
 10aa98d:	cmp    $0x0,%eax
 10aa990:	jne    10aa9dc <myl_f_72cff91e1ca43adf6e3bd650d1fe503b405034486590fc282e877edc70061b44+0x13fc>
 10aa992:	call   1169600 <myl_rc_take_failure>
 10aa997:	mov    %r12,%rdi
 10aa99a:	mov    %eax,%esi
 10aa99c:	call   1159ab0 <myl_qbe_rc_status>
 10aa9a1:	mov    $0x18,%edx
 10aa9a6:	mov    $0x0,%esi
 10aa9ab:	lea    -0x358(%rbp),%rdi
 10aa9b2:	call   1176f90 <compiler_rt.fastMemset>
 10aa9b7:	mov    %rbx,%rax
 10aa9ba:	mov    -0x358(%rbp),%rcx
 10aa9c1:	mov    %rcx,(%rax)
 10aa9c4:	mov    -0x350(%rbp),%rcx
 10aa9cb:	mov    %rcx,0x8(%rax)
 10aa9cf:	mov    -0x348(%rbp),%rcx
 10aa9d6:	mov    %rcx,0x10(%rax)
 10aa9da:	jmp    10aa9ff <myl_f_72cff91e1ca43adf6e3bd650d1fe503b405034486590fc282e877edc70061b44+0x141f>
 10aa9dc:	mov    %rbx,%rax
 10aa9df:	mov    -0x268(%rbp),%rcx
 10aa9e6:	mov    %rcx,(%rax)
 10aa9e9:	mov    -0x260(%rbp),%rcx
 10aa9f0:	mov    %rcx,0x8(%rax)
 10aa9f4:	mov    -0x258(%rbp),%rcx
 10aa9fb:	mov    %rcx,0x10(%rax)
 10aa9ff:	pop    %r15
 10aaa01:	pop    %r14
 10aaa03:	pop    %r13
 10aaa05:	pop    %r12
 10aaa07:	pop    %rbx
 10aaa08:	leave
 10aaa09:	ret
 10aaa0a:	mov    %r12,%rdi
 10aaa0d:	call   115abb0 <myl_qbe_fail_frame>
 10aaa12:	ud2

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
