
/home/epentland/ai/canopy/mylang-worktrees/codex-lox-borrow-assert-20261003/.tmp-lox-borrow-assert-20261003/fixed-qbe-ast:     file format elf64-x86-64


Disassembly of section .text:

0000000001137700 <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c>:
 1137700:	endbr64
 1137704:	push   %rbp
 1137705:	mov    %rsp,%rbp
 1137708:	sub    $0x178,%rsp
 113770f:	push   %rbx
 1137710:	push   %r12
 1137712:	push   %r13
 1137714:	push   %r14
 1137716:	push   %r15
 1137718:	mov    %rcx,%r12
 113771b:	mov    %rdx,%r15
 113771e:	mov    %rsi,%r14
 1137721:	mov    0x40(%rdi),%rax
 1137725:	lea    -0x8(%rbp),%rcx
 1137729:	cmp    %rax,%rcx
 113772c:	jb     1137fcd <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x8cd>
 1137732:	mov    %rdi,%rbx
 1137735:	call   115aba0 <myl_qbe_heap>
 113773a:	mov    %rbx,%rdi
 113773d:	mov    %rax,%rbx
 1137740:	mov    %rdi,%r13
 1137743:	call   115d700 <myl_qbe_region_mark>
 1137748:	mov    %r15,%rdx
 113774b:	mov    %r14,%rsi
 113774e:	mov    %r13,%rdi
 1137751:	mov    0x80(%rsi),%r13
 1137758:	movabs $0x8000000000000001,%rax
 1137762:	cmp    %rax,%r13
 1137765:	jl     1137fb3 <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x8b3>
 113776b:	mov    %rsi,%r11
 113776e:	add    $0x78,%r11
 1137772:	mov    0x78(%rsi),%r9
 1137776:	mov    (%r9),%r10
 1137779:	mov    %r13,%rax
 113777c:	sub    $0x1,%rax
 1137780:	cmp    %r10,%rax
 1137783:	setb   %cl
 1137786:	movzbq %cl,%rcx
 113778a:	cmp    $0x0,%ecx
 113778d:	jne    113781d <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x11d>
 1137793:	cmp    $0x0,%rax
 1137797:	jl     113779e <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x9e>
 1137799:	mov    %rax,%r14
 113779c:	jmp    11377c8 <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0xc8>
 113779e:	movabs $0x7fffffffffffffff,%rcx
 11377a8:	cmp    %rcx,%r10
 11377ab:	ja     113780e <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x10e>
 11377ad:	mov    %r10,%r14
 11377b0:	add    %rax,%r14
 11377b3:	mov    %r10,%rcx
 11377b6:	xor    %r14,%rcx
 11377b9:	mov    %rax,%r8
 11377bc:	xor    %r14,%r8
 11377bf:	and    %r8,%rcx
 11377c2:	cmp    $0x0,%rcx
 11377c6:	jl     11377f3 <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0xf3>
 11377c8:	cmp    %r10,%r14
 11377cb:	jb     11377e3 <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0xe3>
 11377cd:	mov    %r14,%rdx
 11377d0:	mov    %r10,%rsi
 11377d3:	mov    %rdx,%r10
 11377d6:	mov    %rsi,%rdx
 11377d9:	mov    %r10,%rsi
 11377dc:	call   115a7e0 <myl_qbe_fail_normalized_index_bounds>
 11377e1:	ud2
 11377e3:	mov    %r14,%r10
 11377e6:	mov    0x20(%r9),%rcx
 11377ea:	imul   $0x10,%r10,%r8
 11377ee:	add    %r8,%rcx
 11377f1:	jmp    1137828 <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x128>
 11377f3:	mov    %r10,%rsi
 11377f6:	mov    $0x40,%r8d
 11377fc:	mov    %rax,%rcx
 11377ff:	mov    %rsi,%rdx
 1137802:	mov    $0x0,%esi
 1137807:	call   115a9f0 <myl_qbe_fail_overflow_op>
 113780c:	ud2
 113780e:	mov    %r10,%rsi
 1137811:	mov    $0x140,%edx
 1137816:	call   115ab30 <myl_qbe_fail_cast>
 113781b:	ud2
 113781d:	mov    0x20(%r9),%rcx
 1137821:	imul   $0x10,%rax,%r8
 1137825:	add    %r8,%rcx
 1137828:	mov    (%rcx),%r8d
 113782b:	cmp    $0x0,%r8
 113782f:	je     1137f18 <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x818>
 1137835:	cmp    $0x1,%r8
 1137839:	je     1137e7c <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x77c>
 113783f:	cmp    $0x2,%r8
 1137843:	je     11378f2 <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x1f2>
 1137849:	mov    %r8,%rax
 113784c:	cmp    $0x3,%rax
 1137850:	jne    1137c8d <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x58d>
 1137856:	mov    0xfaeeb(%rip),%rcx        # 1232748 <myl_lit_705b80a2adbffde33673cee9517989a5dbc62d5a47d462ddbd71f5170464b997>
 113785d:	mov    %rcx,-0x160(%rbp)
 1137864:	mov    -0x160(%rbp),%rax
 113786b:	mov    %rax,-0x158(%rbp)
 1137872:	mov    -0x158(%rbp),%rax
 1137879:	mov    %rax,-0x168(%rbp)
 1137880:	call   1128220 <myl_f_8855e2338a0239644fa6d8638afc594de302f594debc25ce542a382b2a6572a1>
 1137885:	mov    %rbx,%rdi
 1137888:	mov    -0x168(%rbp),%rdx
 113788f:	cmp    $0x0,%rdx
 1137893:	je     1137fa8 <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x8a8>
 1137899:	mov    -0x10(%rdx),%rcx
 113789d:	movabs $0x4000000000000002,%rsi
 11378a7:	and    %rsi,%rcx
 11378aa:	cmp    $0x0,%rcx
 11378ae:	jne    11378e2 <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x1e2>
 11378b0:	mov    -0x20(%rdx),%rcx
 11378b4:	sub    $0x1,%rcx
 11378b8:	jne    11378de <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x1de>
 11378ba:	mov    %rax,%rbx
 11378bd:	mov    -0x18(%rdx),%rax
 11378c1:	cmp    $0x0,%rax
 11378c5:	jne    11378db <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x1db>
 11378c7:	lea    -0x168(%rbp),%rsi
 11378ce:	call   113f380 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop>
 11378d3:	mov    %rbx,%rax
 11378d6:	jmp    1137fa8 <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x8a8>
 11378db:	mov    %rbx,%rax
 11378de:	mov    %rcx,-0x20(%rdx)
 11378e2:	movq   $0x0,-0x168(%rbp)
 11378ed:	jmp    1137fa8 <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x8a8>
 11378f2:	mov    0x8(%rcx),%r8
 11378f6:	mov    %r8,-0x158(%rbp)
 11378fd:	movabs $0x8000000000000001,%rcx
 1137907:	cmp    %rcx,%rax
 113790a:	jl     1137e62 <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x762>
 1137910:	mov    (%r9),%r10
 1137913:	mov    %r13,%rcx
 1137916:	sub    $0x2,%rcx
 113791a:	cmp    %r10,%rcx
 113791d:	setb   %r13b
 1137921:	movzbq %r13b,%r13
 1137925:	cmp    $0x0,%r13d
 1137929:	jne    11379a9 <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x2a9>
 113792b:	cmp    $0x0,%rcx
 113792f:	jl     1137936 <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x236>
 1137931:	mov    %rcx,%r13
 1137934:	jmp    1137960 <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x260>
 1137936:	movabs $0x7fffffffffffffff,%r13
 1137940:	cmp    %r13,%r10
 1137943:	ja     113799a <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x29a>
 1137945:	mov    %r10,%r13
 1137948:	add    %rcx,%r13
 113794b:	mov    %r10,%r14
 113794e:	xor    %r13,%r14
 1137951:	mov    %rcx,%r15
 1137954:	xor    %r13,%r15
 1137957:	and    %r15,%r14
 113795a:	cmp    $0x0,%r14
 113795e:	jl     1137982 <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x282>
 1137960:	cmp    %r10,%r13
 1137963:	jb     1137975 <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x275>
 1137965:	mov    %r10,%rsi
 1137968:	mov    %rsi,%rdx
 113796b:	mov    %r13,%rsi
 113796e:	call   115a7e0 <myl_qbe_fail_normalized_index_bounds>
 1137973:	ud2
 1137975:	mov    0x20(%r9),%r9
 1137979:	imul   $0x10,%r13,%r10
 113797d:	add    %r10,%r9
 1137980:	jmp    11379b4 <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x2b4>
 1137982:	mov    %r10,%rsi
 1137985:	mov    $0x40,%r8d
 113798b:	mov    %rsi,%rdx
 113798e:	mov    $0x0,%esi
 1137993:	call   115a9f0 <myl_qbe_fail_overflow_op>
 1137998:	ud2
 113799a:	mov    %r10,%rsi
 113799d:	mov    $0x140,%edx
 11379a2:	call   115ab30 <myl_qbe_fail_cast>
 11379a7:	ud2
 11379a9:	mov    0x20(%r9),%r9
 11379ad:	imul   $0x10,%rcx,%r10
 11379b1:	add    %r10,%r9
 11379b4:	mov    (%r9),%r10d
 11379b7:	cmp    $0x0,%r10
 11379bb:	je     1137dc6 <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x6c6>
 11379c1:	cmp    $0x1,%r10
 11379c5:	je     1137d2a <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x62a>
 11379cb:	cmp    $0x2,%r10
 11379cf:	je     1137a7e <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x37e>
 11379d5:	mov    %r10,%rax
 11379d8:	cmp    $0x3,%rax
 11379dc:	jne    1137c8d <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x58d>
 11379e2:	mov    0xfad5f(%rip),%rcx        # 1232748 <myl_lit_705b80a2adbffde33673cee9517989a5dbc62d5a47d462ddbd71f5170464b997>
 11379e9:	mov    %rcx,-0x160(%rbp)
 11379f0:	mov    -0x160(%rbp),%rax
 11379f7:	mov    %rax,-0x158(%rbp)
 11379fe:	mov    -0x158(%rbp),%rax
 1137a05:	mov    %rax,-0x168(%rbp)
 1137a0c:	call   1128220 <myl_f_8855e2338a0239644fa6d8638afc594de302f594debc25ce542a382b2a6572a1>
 1137a11:	mov    %rbx,%rdi
 1137a14:	mov    -0x168(%rbp),%rdx
 1137a1b:	cmp    $0x0,%rdx
 1137a1f:	je     1137fa8 <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x8a8>
 1137a25:	mov    -0x10(%rdx),%rcx
 1137a29:	movabs $0x4000000000000002,%rsi
 1137a33:	and    %rsi,%rcx
 1137a36:	cmp    $0x0,%rcx
 1137a3a:	jne    1137a6e <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x36e>
 1137a3c:	mov    -0x20(%rdx),%rcx
 1137a40:	sub    $0x1,%rcx
 1137a44:	jne    1137a6a <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x36a>
 1137a46:	mov    %rax,%rbx
 1137a49:	mov    -0x18(%rdx),%rax
 1137a4d:	cmp    $0x0,%rax
 1137a51:	jne    1137a67 <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x367>
 1137a53:	lea    -0x168(%rbp),%rsi
 1137a5a:	call   113f380 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop>
 1137a5f:	mov    %rbx,%rax
 1137a62:	jmp    1137fa8 <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x8a8>
 1137a67:	mov    %rbx,%rax
 1137a6a:	mov    %rcx,-0x20(%rdx)
 1137a6e:	movq   $0x0,-0x168(%rbp)
 1137a79:	jmp    1137fa8 <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x8a8>
 1137a7e:	mov    %r11,%rdx
 1137a81:	mov    %r12,%rbx
 1137a84:	mov    0x8(%r9),%r9
 1137a88:	mov    %r9,-0x158(%rbp)
 1137a8f:	movq   $0x0,-0x68(%rbp)
 1137a97:	movq   $0x0,-0x60(%rbp)
 1137a9f:	movl   $0x0,-0x68(%rbp)
 1137aa6:	mov    -0x68(%rbp),%r10
 1137aaa:	mov    %r10,-0x88(%rbp)
 1137ab1:	mov    -0x60(%rbp),%r10
 1137ab5:	mov    %r10,-0x80(%rbp)
 1137ab9:	movq   %r9,%xmm1
 1137abe:	movq   %r8,%xmm0
 1137ac3:	cmp    $0x10,%rbx
 1137ac7:	je     1137be6 <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x4e6>
 1137acd:	cmp    $0x11,%rbx
 1137ad1:	je     1137baa <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x4aa>
 1137ad7:	cmp    $0x13,%rbx
 1137adb:	je     1137b69 <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x469>
 1137ae1:	cmp    $0x14,%rbx
 1137ae5:	je     1137b2d <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x42d>
 1137ae7:	movsd  %xmm0,%xmm15
 1137aec:	movsd  %xmm1,%xmm0
 1137af0:	divsd  %xmm15,%xmm0
 1137af5:	movq   %xmm0,%r8
 1137afa:	movq   $0x0,-0x18(%rbp)
 1137b02:	movq   $0x0,-0x10(%rbp)
 1137b0a:	movl   $0x2,-0x18(%rbp)
 1137b11:	mov    %r8,-0x10(%rbp)
 1137b15:	mov    -0x18(%rbp),%r8
 1137b19:	mov    %r8,-0x88(%rbp)
 1137b20:	mov    -0x10(%rbp),%r8
 1137b24:	mov    %r8,-0x80(%rbp)
 1137b28:	jmp    1137c20 <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x520>
 1137b2d:	mulsd  %xmm1,%xmm0
 1137b31:	movq   %xmm0,%r8
 1137b36:	movq   $0x0,-0x28(%rbp)
 1137b3e:	movq   $0x0,-0x20(%rbp)
 1137b46:	movl   $0x2,-0x28(%rbp)
 1137b4d:	mov    %r8,-0x20(%rbp)
 1137b51:	mov    -0x28(%rbp),%r8
 1137b55:	mov    %r8,-0x88(%rbp)
 1137b5c:	mov    -0x20(%rbp),%r8
 1137b60:	mov    %r8,-0x80(%rbp)
 1137b64:	jmp    1137c20 <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x520>
 1137b69:	xorpd  -0x111391(%rip),%xmm0        # 10267e0 <__stop_mylang_frame_map+0x20>
 1137b71:	addsd  %xmm1,%xmm0
 1137b75:	movq   %xmm0,%r8
 1137b7a:	movq   $0x0,-0x38(%rbp)
 1137b82:	movq   $0x0,-0x30(%rbp)
 1137b8a:	movl   $0x2,-0x38(%rbp)
 1137b91:	mov    %r8,-0x30(%rbp)
 1137b95:	mov    -0x38(%rbp),%r8
 1137b99:	mov    %r8,-0x88(%rbp)
 1137ba0:	mov    -0x30(%rbp),%r8
 1137ba4:	mov    %r8,-0x80(%rbp)
 1137ba8:	jmp    1137c20 <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x520>
 1137baa:	ucomisd %xmm1,%xmm0
 1137bae:	seta   %r8b
 1137bb2:	movzbq %r8b,%r8
 1137bb6:	movq   $0x0,-0x48(%rbp)
 1137bbe:	movq   $0x0,-0x40(%rbp)
 1137bc6:	movl   $0x1,-0x48(%rbp)
 1137bcd:	mov    %r8b,-0x40(%rbp)
 1137bd1:	mov    -0x48(%rbp),%r8
 1137bd5:	mov    %r8,-0x88(%rbp)
 1137bdc:	mov    -0x40(%rbp),%r8
 1137be0:	mov    %r8,-0x80(%rbp)
 1137be4:	jmp    1137c20 <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x520>
 1137be6:	ucomisd %xmm0,%xmm1
 1137bea:	seta   %r8b
 1137bee:	movzbq %r8b,%r8
 1137bf2:	movq   $0x0,-0x58(%rbp)
 1137bfa:	movq   $0x0,-0x50(%rbp)
 1137c02:	movl   $0x1,-0x58(%rbp)
 1137c09:	mov    %r8b,-0x50(%rbp)
 1137c0d:	mov    -0x58(%rbp),%r8
 1137c11:	mov    %r8,-0x88(%rbp)
 1137c18:	mov    -0x50(%rbp),%r8
 1137c1c:	mov    %r8,-0x80(%rbp)
 1137c20:	mov    %rax,0x80(%rsi)
 1137c27:	mov    -0x88(%rbp),%rax
 1137c2e:	mov    %rax,-0x78(%rbp)
 1137c32:	mov    -0x80(%rbp),%rax
 1137c36:	mov    %rax,-0x70(%rbp)
 1137c3a:	mov    0x78(%rsi),%rax
 1137c3e:	cmp    $0x0,%rax
 1137c42:	je     1137c97 <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x597>
 1137c44:	mov    -0x10(%rax),%r8
 1137c48:	movabs $0x6000000000000002,%r9
 1137c52:	and    %r9,%r8
 1137c55:	cmp    $0x0,%r8
 1137c59:	jne    1137c65 <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x565>
 1137c5b:	mov    -0x20(%rax),%rax
 1137c5f:	cmp    $0x2,%rax
 1137c63:	jb     1137c97 <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x597>
 1137c65:	mov    %rcx,%r13
 1137c68:	mov    $0x0,%ecx
 1137c6d:	mov    %rsi,%r12
 1137c70:	lea    0xf2581(%rip),%rsi        # 122a1f8 <myl_t_a1fa53db408c85388cfd14badb361c2a89e74ce2a863fa83774cb6942b74317a>
 1137c77:	mov    %rdi,%rbx
 1137c7a:	call   115a070 <myl_qbe_rc_unique_field>
 1137c7f:	mov    %r13,%rcx
 1137c82:	mov    %r12,%rsi
 1137c85:	mov    %rbx,%rdi
 1137c88:	cmp    $0x0,%eax
 1137c8b:	jne    1137c97 <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x597>
 1137c8d:	mov    $0x0,%eax
 1137c92:	jmp    1137fa8 <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x8a8>
 1137c97:	mov    0x78(%rsi),%rax
 1137c9b:	cmp    $0x0,%rcx
 1137c9f:	jge    1137cd1 <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x5d1>
 1137ca1:	mov    (%rax),%rsi
 1137ca4:	movabs $0x7fffffffffffffff,%rdx
 1137cae:	cmp    %rdx,%rsi
 1137cb1:	ja     1137d1e <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x61e>
 1137cb3:	mov    %rsi,%rbx
 1137cb6:	add    %rcx,%rbx
 1137cb9:	mov    %rsi,%rdx
 1137cbc:	xor    %rbx,%rdx
 1137cbf:	mov    %rcx,%r8
 1137cc2:	xor    %rbx,%r8
 1137cc5:	and    %r8,%rdx
 1137cc8:	cmp    $0x0,%rdx
 1137ccc:	jl     1137d09 <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x609>
 1137cce:	mov    %rbx,%rcx
 1137cd1:	mov    (%rax),%rdx
 1137cd4:	cmp    %rdx,%rcx
 1137cd7:	jb     1137ce3 <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x5e3>
 1137cd9:	mov    %rcx,%rsi
 1137cdc:	call   115a7e0 <myl_qbe_fail_normalized_index_bounds>
 1137ce1:	ud2
 1137ce3:	mov    %rcx,%rbx
 1137ce6:	mov    0x20(%rax),%rcx
 1137cea:	imul   $0x10,%rbx,%rdx
 1137cee:	mov    -0x78(%rbp),%rax
 1137cf2:	mov    %rax,(%rcx,%rdx,1)
 1137cf6:	mov    -0x70(%rbp),%rax
 1137cfa:	mov    %rax,0x8(%rcx,%rdx,1)
 1137cff:	mov    $0x1,%eax
 1137d04:	jmp    1137fa8 <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x8a8>
 1137d09:	mov    $0x40,%r8d
 1137d0f:	mov    %rsi,%rdx
 1137d12:	mov    $0x0,%esi
 1137d17:	call   115a9f0 <myl_qbe_fail_overflow_op>
 1137d1c:	ud2
 1137d1e:	mov    $0x140,%edx
 1137d23:	call   115ab30 <myl_qbe_fail_cast>
 1137d28:	ud2
 1137d2a:	mov    0xfaa17(%rip),%rcx        # 1232748 <myl_lit_705b80a2adbffde33673cee9517989a5dbc62d5a47d462ddbd71f5170464b997>
 1137d31:	mov    %rcx,-0x160(%rbp)
 1137d38:	mov    -0x160(%rbp),%rax
 1137d3f:	mov    %rax,-0x158(%rbp)
 1137d46:	mov    -0x158(%rbp),%rax
 1137d4d:	mov    %rax,-0x168(%rbp)
 1137d54:	call   1128220 <myl_f_8855e2338a0239644fa6d8638afc594de302f594debc25ce542a382b2a6572a1>
 1137d59:	mov    %rbx,%rdi
 1137d5c:	mov    -0x168(%rbp),%rdx
 1137d63:	cmp    $0x0,%rdx
 1137d67:	je     1137fa8 <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x8a8>
 1137d6d:	mov    -0x10(%rdx),%rcx
 1137d71:	movabs $0x4000000000000002,%rsi
 1137d7b:	and    %rsi,%rcx
 1137d7e:	cmp    $0x0,%rcx
 1137d82:	jne    1137db6 <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x6b6>
 1137d84:	mov    -0x20(%rdx),%rcx
 1137d88:	sub    $0x1,%rcx
 1137d8c:	jne    1137db2 <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x6b2>
 1137d8e:	mov    %rax,%rbx
 1137d91:	mov    -0x18(%rdx),%rax
 1137d95:	cmp    $0x0,%rax
 1137d99:	jne    1137daf <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x6af>
 1137d9b:	lea    -0x168(%rbp),%rsi
 1137da2:	call   113f380 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop>
 1137da7:	mov    %rbx,%rax
 1137daa:	jmp    1137fa8 <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x8a8>
 1137daf:	mov    %rbx,%rax
 1137db2:	mov    %rcx,-0x20(%rdx)
 1137db6:	movq   $0x0,-0x168(%rbp)
 1137dc1:	jmp    1137fa8 <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x8a8>
 1137dc6:	mov    0xfa97b(%rip),%rcx        # 1232748 <myl_lit_705b80a2adbffde33673cee9517989a5dbc62d5a47d462ddbd71f5170464b997>
 1137dcd:	mov    %rcx,-0x160(%rbp)
 1137dd4:	mov    -0x160(%rbp),%rax
 1137ddb:	mov    %rax,-0x158(%rbp)
 1137de2:	mov    -0x158(%rbp),%rax
 1137de9:	mov    %rax,-0x168(%rbp)
 1137df0:	call   1128220 <myl_f_8855e2338a0239644fa6d8638afc594de302f594debc25ce542a382b2a6572a1>
 1137df5:	mov    %rbx,%rdi
 1137df8:	mov    -0x168(%rbp),%rdx
 1137dff:	cmp    $0x0,%rdx
 1137e03:	je     1137fa8 <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x8a8>
 1137e09:	mov    -0x10(%rdx),%rcx
 1137e0d:	movabs $0x4000000000000002,%rsi
 1137e17:	and    %rsi,%rcx
 1137e1a:	cmp    $0x0,%rcx
 1137e1e:	jne    1137e52 <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x752>
 1137e20:	mov    -0x20(%rdx),%rcx
 1137e24:	sub    $0x1,%rcx
 1137e28:	jne    1137e4e <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x74e>
 1137e2a:	mov    %rax,%rbx
 1137e2d:	mov    -0x18(%rdx),%rax
 1137e31:	cmp    $0x0,%rax
 1137e35:	jne    1137e4b <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x74b>
 1137e37:	lea    -0x168(%rbp),%rsi
 1137e3e:	call   113f380 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop>
 1137e43:	mov    %rbx,%rax
 1137e46:	jmp    1137fa8 <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x8a8>
 1137e4b:	mov    %rbx,%rax
 1137e4e:	mov    %rcx,-0x20(%rdx)
 1137e52:	movq   $0x0,-0x168(%rbp)
 1137e5d:	jmp    1137fa8 <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x8a8>
 1137e62:	mov    %rax,%rdx
 1137e65:	mov    $0x40,%r8d
 1137e6b:	mov    $0x1,%ecx
 1137e70:	mov    $0x1,%esi
 1137e75:	call   115a9f0 <myl_qbe_fail_overflow_op>
 1137e7a:	ud2
 1137e7c:	mov    0xfa8c5(%rip),%rcx        # 1232748 <myl_lit_705b80a2adbffde33673cee9517989a5dbc62d5a47d462ddbd71f5170464b997>
 1137e83:	mov    %rcx,-0x160(%rbp)
 1137e8a:	mov    -0x160(%rbp),%rax
 1137e91:	mov    %rax,-0x158(%rbp)
 1137e98:	mov    -0x158(%rbp),%rax
 1137e9f:	mov    %rax,-0x168(%rbp)
 1137ea6:	call   1128220 <myl_f_8855e2338a0239644fa6d8638afc594de302f594debc25ce542a382b2a6572a1>
 1137eab:	mov    %rbx,%rdi
 1137eae:	mov    -0x168(%rbp),%rdx
 1137eb5:	cmp    $0x0,%rdx
 1137eb9:	je     1137fa8 <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x8a8>
 1137ebf:	mov    -0x10(%rdx),%rcx
 1137ec3:	movabs $0x4000000000000002,%rsi
 1137ecd:	and    %rsi,%rcx
 1137ed0:	cmp    $0x0,%rcx
 1137ed4:	jne    1137f08 <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x808>
 1137ed6:	mov    -0x20(%rdx),%rcx
 1137eda:	sub    $0x1,%rcx
 1137ede:	jne    1137f04 <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x804>
 1137ee0:	mov    %rax,%rbx
 1137ee3:	mov    -0x18(%rdx),%rax
 1137ee7:	cmp    $0x0,%rax
 1137eeb:	jne    1137f01 <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x801>
 1137eed:	lea    -0x168(%rbp),%rsi
 1137ef4:	call   113f380 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop>
 1137ef9:	mov    %rbx,%rax
 1137efc:	jmp    1137fa8 <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x8a8>
 1137f01:	mov    %rbx,%rax
 1137f04:	mov    %rcx,-0x20(%rdx)
 1137f08:	movq   $0x0,-0x168(%rbp)
 1137f13:	jmp    1137fa8 <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x8a8>
 1137f18:	mov    0xfa829(%rip),%rcx        # 1232748 <myl_lit_705b80a2adbffde33673cee9517989a5dbc62d5a47d462ddbd71f5170464b997>
 1137f1f:	mov    %rcx,-0x160(%rbp)
 1137f26:	mov    -0x160(%rbp),%rax
 1137f2d:	mov    %rax,-0x158(%rbp)
 1137f34:	mov    -0x158(%rbp),%rax
 1137f3b:	mov    %rax,-0x168(%rbp)
 1137f42:	call   1128220 <myl_f_8855e2338a0239644fa6d8638afc594de302f594debc25ce542a382b2a6572a1>
 1137f47:	mov    %rbx,%rdi
 1137f4a:	mov    -0x168(%rbp),%rdx
 1137f51:	cmp    $0x0,%rdx
 1137f55:	je     1137fa8 <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x8a8>
 1137f57:	mov    -0x10(%rdx),%rcx
 1137f5b:	movabs $0x4000000000000002,%rsi
 1137f65:	and    %rsi,%rcx
 1137f68:	cmp    $0x0,%rcx
 1137f6c:	jne    1137f9d <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x89d>
 1137f6e:	mov    -0x20(%rdx),%rcx
 1137f72:	sub    $0x1,%rcx
 1137f76:	jne    1137f99 <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x899>
 1137f78:	mov    %rax,%rbx
 1137f7b:	mov    -0x18(%rdx),%rax
 1137f7f:	cmp    $0x0,%rax
 1137f83:	jne    1137f96 <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x896>
 1137f85:	lea    -0x168(%rbp),%rsi
 1137f8c:	call   113f380 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop>
 1137f91:	mov    %rbx,%rax
 1137f94:	jmp    1137fa8 <myl_f_aae7e3f63f242f091f741298468821884e7473697b1d7153432e9386d8e0579c+0x8a8>
 1137f96:	mov    %rbx,%rax
 1137f99:	mov    %rcx,-0x20(%rdx)
 1137f9d:	movq   $0x0,-0x168(%rbp)
 1137fa8:	pop    %r15
 1137faa:	pop    %r14
 1137fac:	pop    %r13
 1137fae:	pop    %r12
 1137fb0:	pop    %rbx
 1137fb1:	leave
 1137fb2:	ret
 1137fb3:	mov    %r13,%rdx
 1137fb6:	mov    $0x40,%r8d
 1137fbc:	mov    $0x1,%ecx
 1137fc1:	mov    $0x1,%esi
 1137fc6:	call   115a9f0 <myl_qbe_fail_overflow_op>
 1137fcb:	ud2
 1137fcd:	call   115abb0 <myl_qbe_fail_frame>
 1137fd2:	ud2

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
