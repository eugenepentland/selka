
/home/epentland/ai/canopy/mylang-worktrees/codex-lox-variant-number-tag-20261003/.tmp-lox-variant-number-tag-20261003/number-tag-stable-rc-qbe:     file format elf64-x86-64


Disassembly of section .text:

000000000109fde0 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e>:
 109fde0:	endbr64
 109fde4:	push   %rbp
 109fde5:	mov    %rsp,%rbp
 109fde8:	sub    $0x4b8,%rsp
 109fdef:	push   %rbx
 109fdf0:	push   %r12
 109fdf2:	push   %r13
 109fdf4:	push   %r14
 109fdf6:	push   %r15
 109fdf8:	mov    0x10(%rbp),%r13
 109fdfc:	mov    %r9,-0x8(%rbp)
 109fe00:	mov    %r8,-0x10(%rbp)
 109fe04:	mov    %rcx,%r15
 109fe07:	mov    %rdx,-0x18(%rbp)
 109fe0b:	mov    %rsi,%r12
 109fe0e:	mov    %rdi,%rax
 109fe11:	mov    %r15,-0x28(%rbp)
 109fe15:	mov    %rax,%rbx
 109fe18:	mov    0x40(%r12),%rax
 109fe1d:	mov    $0x0,%r14d
 109fe23:	mov    %r14d,-0x2c(%rbp)
 109fe27:	mov    $0x0,%r14d
 109fe2d:	mov    %r14d,-0x20(%rbp)
 109fe31:	lea    -0x38(%rbp),%rcx
 109fe35:	cmp    %rax,%rcx
 109fe38:	jb     10a0c2f <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0xe4f>
 109fe3e:	mov    %r12,%rdi
 109fe41:	call   115abc0 <myl_qbe_heap>
 109fe46:	mov    %rax,%rdi
 109fe49:	mov    %rdi,%r14
 109fe4c:	mov    %r12,%rdi
 109fe4f:	call   115d720 <myl_qbe_region_mark>
 109fe54:	mov    %r15,%rsi
 109fe57:	mov    %r14,%rdi
 109fe5a:	mov    %rax,%rcx
 109fe5d:	mov    %rbx,%rax
 109fe60:	mov    -0x8(%rbp),%r9
 109fe64:	mov    -0x10(%rbp),%r8
 109fe68:	mov    -0x18(%rbp),%rdx
 109fe6c:	mov    %rax,%rbx
 109fe6f:	mov    0x28(%r13),%rax
 109fe73:	sub    $0x10,%rsp
 109fe77:	mov    %rsp,%r10
 109fe7a:	mov    %rax,(%r10)
 109fe7d:	mov    %rcx,%r15
 109fe80:	mov    %rsi,%rcx
 109fe83:	mov    %r12,%rsi
 109fe86:	mov    %rdi,%r14
 109fe89:	lea    -0x4a8(%rbp),%rdi
 109fe90:	call   10b6b00 <myl_f_d32d9d609bd2d498a6b2d4f34d6d36851c296533eaafa0e3b7c4c9b1eec65fca>
 109fe95:	mov    %r15,%rcx
 109fe98:	mov    %r14,%rdi
 109fe9b:	mov    %rax,%rdx
 109fe9e:	mov    %rbx,%rax
 109fea1:	mov    -0x20(%rbp),%r14d
 109fea5:	sub    $0xfffffffffffffff0,%rsp
 109fea9:	mov    (%rdx),%rsi
 109feac:	mov    %rsi,-0x360(%rbp)
 109feb3:	mov    0x8(%rdx),%rsi
 109feb7:	mov    %rsi,-0x358(%rbp)
 109febe:	mov    0x10(%rdx),%rdx
 109fec2:	mov    %rdx,-0x350(%rbp)
 109fec9:	mov    -0x360(%rbp),%rdx
 109fed0:	mov    %rdx,-0x438(%rbp)
 109fed7:	mov    -0x358(%rbp),%rdx
 109fede:	mov    %rdx,-0x430(%rbp)
 109fee5:	mov    %rcx,%r15
 109fee8:	mov    -0x350(%rbp),%rcx
 109feef:	mov    %rcx,-0x428(%rbp)
 109fef6:	mov    %rax,%rbx
 109fef9:	mov    -0x438(%rbp),%eax
 109feff:	cmp    $0x0,%rax
 109ff03:	je     10a009d <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0x2bd>
 109ff09:	mov    %r14d,%r13d
 109ff0c:	movabs $0x300000007,%rsi
 109ff16:	mov    %rdi,%r14
 109ff19:	lea    0x1177c8(%rip),%rdi        # 11b76e8 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e_meta>
 109ff20:	call   115c058 <myl_qbe_error_trace_append>
 109ff25:	mov    %r15,%rcx
 109ff28:	mov    %r14,%rdi
 109ff2b:	mov    %rbx,%rax
 109ff2e:	lea    -0x438(%rbp),%rdx
 109ff35:	add    $0x8,%rdx
 109ff39:	movq   $0x0,-0x270(%rbp)
 109ff44:	mov    %rax,%rbx
 109ff47:	lea    -0x270(%rbp),%rax
 109ff4e:	mov    %rax,%rsi
 109ff51:	add    $0x8,%rsi
 109ff55:	movq   $0x0,-0x268(%rbp)
 109ff60:	movq   $0x0,-0x260(%rbp)
 109ff6b:	movl   $0x1,-0x270(%rbp)
 109ff75:	mov    %rcx,%r15
 109ff78:	mov    %rdi,%r14
 109ff7b:	call   114d360 <myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_retain>
 109ff80:	mov    %r15,%rcx
 109ff83:	mov    %r14,%rdi
 109ff86:	cmp    $0x0,%eax
 109ff89:	jne    109ffa8 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0x1c8>
 109ff8b:	call   1169620 <myl_rc_take_failure>
 109ff90:	mov    %r12,%rdi
 109ff93:	mov    %eax,%esi
 109ff95:	mov    %rdi,%r12
 109ff98:	call   1159ad0 <myl_qbe_rc_status>
 109ff9d:	mov    %rbx,%rax
 109ffa0:	mov    %rax,%rbx
 109ffa3:	jmp    10a0bc6 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0xde6>
 109ffa8:	mov    %rbx,%rax
 109ffab:	mov    -0x270(%rbp),%rdx
 109ffb2:	mov    %rdx,-0x360(%rbp)
 109ffb9:	mov    %rcx,%r15
 109ffbc:	mov    -0x268(%rbp),%rcx
 109ffc3:	mov    %rcx,-0x358(%rbp)
 109ffca:	mov    %rax,%rbx
 109ffcd:	mov    -0x260(%rbp),%rax
 109ffd4:	mov    %rax,-0x350(%rbp)
 109ffdb:	lea    -0x438(%rbp),%rsi
 109ffe2:	mov    %rdi,%r14
 109ffe5:	call   1147820 <myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_drop>
 109ffea:	mov    %r15,%rcx
 109ffed:	mov    %r14,%rdi
 109fff0:	mov    %rbx,%rax
 109fff3:	mov    -0x360(%rbp),%rdx
 109fffa:	mov    %rdx,-0x438(%rbp)
 10a0001:	mov    -0x358(%rbp),%rdx
 10a0008:	mov    %rdx,-0x430(%rbp)
 10a000f:	mov    %rax,%rbx
 10a0012:	mov    -0x350(%rbp),%rax
 10a0019:	mov    %rax,-0x428(%rbp)
 10a0020:	mov    %rcx,%r15
 10a0023:	lea    -0x438(%rbp),%rdx
 10a002a:	lea    -0x360(%rbp),%rsi
 10a0031:	mov    %rdi,%r14
 10a0034:	call   11478b0 <myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_take>
 10a0039:	mov    %r14,%rdi
 10a003c:	cmp    $0x0,%eax
 10a003f:	jne    10a0058 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0x278>
 10a0041:	call   1169620 <myl_rc_take_failure>
 10a0046:	mov    %r12,%rdi
 10a0049:	mov    %eax,%esi
 10a004b:	mov    %rdi,%r12
 10a004e:	call   1159ad0 <myl_qbe_rc_status>
 10a0053:	jmp    10a0bc6 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0xde6>
 10a0058:	mov    %r13d,%r12d
 10a005b:	cmp    $0x0,%r12d
 10a005f:	jne    10a0066 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0x286>
 10a0061:	mov    %rbx,%rax
 10a0064:	jmp    10a0075 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0x295>
 10a0066:	lea    -0x438(%rbp),%rsi
 10a006d:	call   1147820 <myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_drop>
 10a0072:	mov    %rbx,%rax
 10a0075:	mov    -0x360(%rbp),%rcx
 10a007c:	mov    %rcx,(%rax)
 10a007f:	mov    -0x358(%rbp),%rcx
 10a0086:	mov    %rcx,0x8(%rax)
 10a008a:	mov    -0x350(%rbp),%rcx
 10a0091:	mov    %rcx,0x10(%rax)
 10a0095:	mov    %rax,%rbx
 10a0098:	jmp    10a0c24 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0xe44>
 10a009d:	lea    -0x438(%rbp),%rsi
 10a00a4:	mov    %rdi,%r14
 10a00a7:	call   1147820 <myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_drop>
 10a00ac:	mov    %r14,%rdi
 10a00af:	mov    -0x28(%rbp),%rsi
 10a00b3:	mov    $0x0,%edx
 10a00b8:	mov    %rdi,%r14
 10a00bb:	mov    %r12,%rdi
 10a00be:	call   1097020 <myl_f_851eb64c403b25f3166dffdb17dfc9e3c924451c20caa5851a74e0f4081ba50f>
 10a00c3:	mov    %r14,%rdi
 10a00c6:	mov    %rax,%rcx
 10a00c9:	mov    %rdx,%rax
 10a00cc:	mov    -0x2c(%rbp),%r14d
 10a00d0:	mov    -0x28(%rbp),%rsi
 10a00d4:	mov    %rcx,-0x490(%rbp)
 10a00db:	mov    %rax,-0x488(%rbp)
 10a00e2:	cmp    $0x0,%r14d
 10a00e6:	jne    10a00f0 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0x310>
 10a00e8:	mov    %rbx,%rax
 10a00eb:	mov    %r15,%rcx
 10a00ee:	jmp    10a0112 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0x332>
 10a00f0:	lea    -0x438(%rbp),%rsi
 10a00f7:	mov    %rdi,%r14
 10a00fa:	call   1141750 <myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop>
 10a00ff:	mov    %r15,%rcx
 10a0102:	mov    %r14,%rdi
 10a0105:	mov    %rbx,%rax
 10a0108:	mov    -0x28(%rbp),%rsi
 10a010c:	mov    $0x0,%r14d
 10a0112:	mov    %rcx,%r15
 10a0115:	mov    -0x490(%rbp),%rcx
 10a011c:	mov    %rcx,-0x290(%rbp)
 10a0123:	mov    %rax,%rbx
 10a0126:	mov    -0x488(%rbp),%rax
 10a012d:	mov    %rax,-0x288(%rbp)
 10a0134:	cmp    $0x0,%r14d
 10a0138:	je     10a0156 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0x376>
 10a013a:	lea    -0x438(%rbp),%rsi
 10a0141:	mov    %rdi,%r14
 10a0144:	call   114e440 <myl_t_f298b6d8457736465302b199391c1c9d6e57cdd1f586a7753cd47f47922b1d32_rcg_drop>
 10a0149:	mov    %r14,%rdi
 10a014c:	mov    -0x28(%rbp),%rsi
 10a0150:	mov    $0x0,%r14d
 10a0156:	cmp    $0x0,%r14d
 10a015a:	jne    10a0164 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0x384>
 10a015c:	mov    %rbx,%rax
 10a015f:	mov    %r15,%rcx
 10a0162:	jmp    10a0186 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0x3a6>
 10a0164:	lea    -0x438(%rbp),%rsi
 10a016b:	mov    %rdi,%r14
 10a016e:	call   113fb30 <myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop>
 10a0173:	mov    %r15,%rcx
 10a0176:	mov    %r14,%rdi
 10a0179:	mov    %rbx,%rax
 10a017c:	mov    -0x28(%rbp),%rsi
 10a0180:	mov    $0x0,%r14d
 10a0186:	mov    %r14d,%ebx
 10a0189:	mov    %ebx,-0x30(%rbp)
 10a018c:	movl   $0x0,-0x258(%rbp)
 10a0196:	movl   $0xb,-0x258(%rbp)
 10a01a0:	mov    0x0(%r13),%edx
 10a01a4:	cmp    $0xb,%rdx
 10a01a8:	je     10a0a61 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0xc81>
 10a01ae:	mov    -0x290(%rbp),%edx
 10a01b4:	cmp    $0x0,%rdx
 10a01b8:	sete   %r8b
 10a01bc:	movzbq %r8b,%r8
 10a01c0:	cmp    $0x0,%r8d
 10a01c4:	jne    10a0801 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0xa21>
 10a01ca:	cmp    $0x1,%rdx
 10a01ce:	je     10a05a1 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0x7c1>
 10a01d4:	cmp    $0x2,%rdx
 10a01d8:	je     10a0452 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0x672>
 10a01de:	cmp    $0x3,%rdx
 10a01e2:	je     10a01ec <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0x40c>
 10a01e4:	mov    %rax,%rbx
 10a01e7:	jmp    10a0bc6 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0xde6>
 10a01ec:	mov    0x1923ed(%rip),%rsi        # 12325e0 <myl_lit_2d6548b0d20925eb41b8b902da17a2651a780e0ecf585d7c93694f27a1a25cd5>
 10a01f3:	mov    %rsi,-0x368(%rbp)
 10a01fa:	mov    %rcx,%r14
 10a01fd:	mov    -0x368(%rbp),%rcx
 10a0204:	mov    %rcx,-0x360(%rbp)
 10a020b:	mov    %rax,%rbx
 10a020e:	mov    -0x360(%rbp),%rax
 10a0215:	mov    %rax,-0x438(%rbp)
 10a021c:	mov    0x18(%r13),%rdx
 10a0220:	mov    %rdi,%r13
 10a0223:	mov    %r12,%rdi
 10a0226:	call   10af7f0 <myl_f_8c062ec4784d4b0491e6d5d24da0bf886cc822f390794d94cd35c159749aceeb_rc_borrow>
 10a022b:	mov    %r13,%rdi
 10a022e:	mov    %rax,%rcx
 10a0231:	mov    %rdx,%rax
 10a0234:	mov    %rcx,-0x460(%rbp)
 10a023b:	mov    %rax,-0x458(%rbp)
 10a0242:	lea    -0x460(%rbp),%rdx
 10a0249:	lea    -0x360(%rbp),%rsi
 10a0250:	mov    %rdi,%r13
 10a0253:	call   114d230 <myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_loan>
 10a0258:	mov    %r14,%rcx
 10a025b:	mov    %r13,%rdi
 10a025e:	cmp    $0x0,%eax
 10a0261:	jne    10a0280 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0x4a0>
 10a0263:	call   1169620 <myl_rc_take_failure>
 10a0268:	mov    %r12,%rdi
 10a026b:	mov    %eax,%esi
 10a026d:	mov    %rdi,%r12
 10a0270:	call   1159ad0 <myl_qbe_rc_status>
 10a0275:	mov    %rbx,%rax
 10a0278:	mov    %rax,%rbx
 10a027b:	jmp    10a0bc6 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0xde6>
 10a0280:	mov    %rbx,%rax
 10a0283:	mov    -0x438(%rbp),%rsi
 10a028a:	cmp    $0x0,%rsi
 10a028e:	je     10a02f3 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0x513>
 10a0290:	mov    -0x10(%rsi),%rdx
 10a0294:	movabs $0x4000000000000002,%r8
 10a029e:	and    %r8,%rdx
 10a02a1:	cmp    $0x0,%rdx
 10a02a5:	jne    10a02e8 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0x508>
 10a02a7:	mov    %rcx,%r14
 10a02aa:	mov    -0x20(%rsi),%rcx
 10a02ae:	mov    %rcx,%rdx
 10a02b1:	sub    $0x1,%rdx
 10a02b5:	jne    10a02e1 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0x501>
 10a02b7:	mov    %rax,%rbx
 10a02ba:	mov    -0x18(%rsi),%rax
 10a02be:	cmp    $0x0,%rax
 10a02c2:	jne    10a02de <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0x4fe>
 10a02c4:	lea    -0x438(%rbp),%rsi
 10a02cb:	mov    %rdi,%r13
 10a02ce:	call   113f3a0 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop>
 10a02d3:	mov    %r14,%rcx
 10a02d6:	mov    %r13,%rdi
 10a02d9:	mov    %rbx,%rax
 10a02dc:	jmp    10a02f3 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0x513>
 10a02de:	mov    %rbx,%rax
 10a02e1:	mov    %r14,%rcx
 10a02e4:	mov    %rdx,-0x20(%rsi)
 10a02e8:	movq   $0x0,-0x438(%rbp)
 10a02f3:	mov    -0x360(%rbp),%rdx
 10a02fa:	mov    %rdx,-0x438(%rbp)
 10a0301:	mov    -0x358(%rbp),%rdx
 10a0308:	mov    %rdx,-0x430(%rbp)
 10a030f:	movq   $0x0,-0x50(%rbp)
 10a0317:	mov    %rax,%rbx
 10a031a:	lea    -0x50(%rbp),%rax
 10a031e:	mov    %rax,%r13
 10a0321:	add    $0x8,%r13
 10a0325:	movq   $0x0,-0x48(%rbp)
 10a032d:	movq   $0x0,-0x40(%rbp)
 10a0335:	movl   $0x1,-0x50(%rbp)
 10a033c:	mov    %rcx,%r15
 10a033f:	lea    -0x438(%rbp),%rdx
 10a0346:	lea    -0x360(%rbp),%rsi
 10a034d:	mov    %rdi,%r14
 10a0350:	call   114d360 <myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_retain>
 10a0355:	mov    %r14,%rdi
 10a0358:	cmp    $0x0,%eax
 10a035b:	jne    10a0374 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0x594>
 10a035d:	call   1169620 <myl_rc_take_failure>
 10a0362:	mov    %r12,%rdi
 10a0365:	mov    %eax,%esi
 10a0367:	mov    %rdi,%r12
 10a036a:	call   1159ad0 <myl_qbe_rc_status>
 10a036f:	jmp    10a0bc6 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0xde6>
 10a0374:	lea    -0x438(%rbp),%rsi
 10a037b:	mov    %rdi,%r14
 10a037e:	call   114d280 <myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_unloan>
 10a0383:	mov    %r15,%rcx
 10a0386:	mov    %r14,%rdi
 10a0389:	mov    %rbx,%rax
 10a038c:	mov    %rcx,%r14
 10a038f:	mov    -0x360(%rbp),%rcx
 10a0396:	mov    %rcx,0x0(%r13)
 10a039a:	mov    %rax,%rbx
 10a039d:	mov    -0x358(%rbp),%rax
 10a03a4:	mov    %rax,0x8(%r13)
 10a03a8:	mov    $0x49,%esi
 10a03ad:	mov    %rdi,%r13
 10a03b0:	lea    0x117331(%rip),%rdi        # 11b76e8 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e_meta>
 10a03b7:	call   115c041 <myl_qbe_error_trace_origin>
 10a03bc:	mov    %r14,%rcx
 10a03bf:	mov    %r13,%rdi
 10a03c2:	mov    %rbx,%rax
 10a03c5:	mov    -0x50(%rbp),%rdx
 10a03c9:	mov    %rdx,-0x438(%rbp)
 10a03d0:	mov    -0x48(%rbp),%rdx
 10a03d4:	mov    %rdx,-0x430(%rbp)
 10a03db:	mov    %rax,%rbx
 10a03de:	mov    -0x40(%rbp),%rax
 10a03e2:	mov    %rax,-0x428(%rbp)
 10a03e9:	mov    %rcx,%r14
 10a03ec:	lea    -0x438(%rbp),%rdx
 10a03f3:	lea    -0x360(%rbp),%rsi
 10a03fa:	mov    %rdi,%r13
 10a03fd:	call   11478b0 <myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_take>
 10a0402:	mov    %r13,%rdi
 10a0405:	cmp    $0x0,%eax
 10a0408:	jne    10a0427 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0x647>
 10a040a:	call   1169620 <myl_rc_take_failure>
 10a040f:	mov    %r12,%rdi
 10a0412:	mov    %eax,%esi
 10a0414:	mov    %rdi,%r12
 10a0417:	call   1159ad0 <myl_qbe_rc_status>
 10a041c:	mov    %rbx,%rax
 10a041f:	mov    %rax,%rbx
 10a0422:	jmp    10a0bc6 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0xde6>
 10a0427:	mov    %rbx,%rax
 10a042a:	mov    -0x360(%rbp),%rcx
 10a0431:	mov    %rcx,(%rax)
 10a0434:	mov    -0x358(%rbp),%rcx
 10a043b:	mov    %rcx,0x8(%rax)
 10a043f:	mov    -0x350(%rbp),%rcx
 10a0446:	mov    %rcx,0x10(%rax)
 10a044a:	mov    %rax,%rbx
 10a044d:	jmp    10a0c24 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0xe44>
 10a0452:	mov    %rax,%rbx
 10a0455:	mov    %rcx,%r14
 10a0458:	mov    -0x288(%rbp),%rdx
 10a045f:	mov    %rdx,-0x360(%rbp)
 10a0466:	mov    %rsi,%r15
 10a0469:	mov    $0x7,%esi
 10a046e:	mov    %rdi,%r13
 10a0471:	mov    %r12,%rdi
 10a0474:	call   115abe0 <myl_qbe_float_unary>
 10a0479:	mov    %r15,%rsi
 10a047c:	mov    %r13,%rdi
 10a047f:	mov    -0x30(%rbp),%r13d
 10a0483:	movq   $0x0,-0x168(%rbp)
 10a048e:	movq   $0x0,-0x160(%rbp)
 10a0499:	movq   $0x2,-0x168(%rbp)
 10a04a4:	mov    %rax,-0x160(%rbp)
 10a04ab:	lea    -0x168(%rbp),%rdx
 10a04b2:	mov    %rdi,%r15
 10a04b5:	mov    %r12,%rdi
 10a04b8:	call   109cfd0 <myl_f_1e67eb8ef4c3a3acc3a97242d455a6d9c8a2bcb48d8912e38331c2e291a74a0e>
 10a04bd:	mov    %r15,%rdi
 10a04c0:	cmp    $0x0,%r13d
 10a04c4:	jne    10a04ce <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0x6ee>
 10a04c6:	mov    %rbx,%rax
 10a04c9:	mov    %r14,%rcx
 10a04cc:	jmp    10a04e6 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0x706>
 10a04ce:	lea    -0x438(%rbp),%rsi
 10a04d5:	mov    %rdi,%r13
 10a04d8:	call   1141750 <myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop>
 10a04dd:	mov    %r14,%rcx
 10a04e0:	mov    %r13,%rdi
 10a04e3:	mov    %rbx,%rax
 10a04e6:	movq   $0x0,-0x98(%rbp)
 10a04f1:	movq   $0x0,-0x90(%rbp)
 10a04fc:	movq   $0x0,-0x88(%rbp)
 10a0507:	movl   $0x0,-0x98(%rbp)
 10a0511:	mov    -0x98(%rbp),%rdx
 10a0518:	mov    %rdx,-0x438(%rbp)
 10a051f:	mov    -0x90(%rbp),%rdx
 10a0526:	mov    %rdx,-0x430(%rbp)
 10a052d:	mov    %rax,%rbx
 10a0530:	mov    -0x88(%rbp),%rax
 10a0537:	mov    %rax,-0x428(%rbp)
 10a053e:	lea    -0x438(%rbp),%rdx
 10a0545:	lea    -0x360(%rbp),%rsi
 10a054c:	mov    %rdi,%r13
 10a054f:	call   11478b0 <myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_take>
 10a0554:	mov    %r13,%rdi
 10a0557:	cmp    $0x0,%eax
 10a055a:	jne    10a0579 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0x799>
 10a055c:	call   1169620 <myl_rc_take_failure>
 10a0561:	mov    %r12,%rdi
 10a0564:	mov    %eax,%esi
 10a0566:	mov    %rdi,%r12
 10a0569:	call   1159ad0 <myl_qbe_rc_status>
 10a056e:	mov    %rbx,%rax
 10a0571:	mov    %rax,%rbx
 10a0574:	jmp    10a0bc6 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0xde6>
 10a0579:	mov    %rbx,%rax
 10a057c:	mov    -0x360(%rbp),%rcx
 10a0583:	mov    %rcx,(%rax)
 10a0586:	mov    -0x358(%rbp),%rcx
 10a058d:	mov    %rcx,0x8(%rax)
 10a0591:	mov    -0x350(%rbp),%rcx
 10a0598:	mov    %rcx,0x10(%rax)
 10a059c:	jmp    10a0c24 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0xe44>
 10a05a1:	mov    0x192038(%rip),%rsi        # 12325e0 <myl_lit_2d6548b0d20925eb41b8b902da17a2651a780e0ecf585d7c93694f27a1a25cd5>
 10a05a8:	mov    %rsi,-0x368(%rbp)
 10a05af:	mov    %rcx,%r14
 10a05b2:	mov    -0x368(%rbp),%rcx
 10a05b9:	mov    %rcx,-0x360(%rbp)
 10a05c0:	mov    %rax,%rbx
 10a05c3:	mov    -0x360(%rbp),%rax
 10a05ca:	mov    %rax,-0x438(%rbp)
 10a05d1:	mov    0x18(%r13),%rdx
 10a05d5:	mov    %rdi,%r13
 10a05d8:	mov    %r12,%rdi
 10a05db:	call   10af7f0 <myl_f_8c062ec4784d4b0491e6d5d24da0bf886cc822f390794d94cd35c159749aceeb_rc_borrow>
 10a05e0:	mov    %r13,%rdi
 10a05e3:	mov    %rax,%rcx
 10a05e6:	mov    %rdx,%rax
 10a05e9:	mov    %rcx,-0x470(%rbp)
 10a05f0:	mov    %rax,-0x468(%rbp)
 10a05f7:	lea    -0x470(%rbp),%rdx
 10a05fe:	lea    -0x360(%rbp),%rsi
 10a0605:	mov    %rdi,%r13
 10a0608:	call   114d230 <myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_loan>
 10a060d:	mov    %r14,%rcx
 10a0610:	mov    %r13,%rdi
 10a0613:	cmp    $0x0,%eax
 10a0616:	jne    10a0635 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0x855>
 10a0618:	call   1169620 <myl_rc_take_failure>
 10a061d:	mov    %r12,%rdi
 10a0620:	mov    %eax,%esi
 10a0622:	mov    %rdi,%r12
 10a0625:	call   1159ad0 <myl_qbe_rc_status>
 10a062a:	mov    %rbx,%rax
 10a062d:	mov    %rax,%rbx
 10a0630:	jmp    10a0bc6 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0xde6>
 10a0635:	mov    %rbx,%rax
 10a0638:	mov    -0x438(%rbp),%rsi
 10a063f:	cmp    $0x0,%rsi
 10a0643:	je     10a06a8 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0x8c8>
 10a0645:	mov    -0x10(%rsi),%rdx
 10a0649:	movabs $0x4000000000000002,%r8
 10a0653:	and    %r8,%rdx
 10a0656:	cmp    $0x0,%rdx
 10a065a:	jne    10a069d <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0x8bd>
 10a065c:	mov    %rcx,%r14
 10a065f:	mov    -0x20(%rsi),%rcx
 10a0663:	mov    %rcx,%rdx
 10a0666:	sub    $0x1,%rdx
 10a066a:	jne    10a0696 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0x8b6>
 10a066c:	mov    %rax,%rbx
 10a066f:	mov    -0x18(%rsi),%rax
 10a0673:	cmp    $0x0,%rax
 10a0677:	jne    10a0693 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0x8b3>
 10a0679:	lea    -0x438(%rbp),%rsi
 10a0680:	mov    %rdi,%r13
 10a0683:	call   113f3a0 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop>
 10a0688:	mov    %r14,%rcx
 10a068b:	mov    %r13,%rdi
 10a068e:	mov    %rbx,%rax
 10a0691:	jmp    10a06a8 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0x8c8>
 10a0693:	mov    %rbx,%rax
 10a0696:	mov    %r14,%rcx
 10a0699:	mov    %rdx,-0x20(%rsi)
 10a069d:	movq   $0x0,-0x438(%rbp)
 10a06a8:	mov    -0x360(%rbp),%rdx
 10a06af:	mov    %rdx,-0x438(%rbp)
 10a06b6:	mov    -0x358(%rbp),%rdx
 10a06bd:	mov    %rdx,-0x430(%rbp)
 10a06c4:	movq   $0x0,-0x68(%rbp)
 10a06cc:	mov    %rax,%rbx
 10a06cf:	lea    -0x68(%rbp),%rax
 10a06d3:	mov    %rax,%r13
 10a06d6:	add    $0x8,%r13
 10a06da:	movq   $0x0,-0x60(%rbp)
 10a06e2:	movq   $0x0,-0x58(%rbp)
 10a06ea:	movl   $0x1,-0x68(%rbp)
 10a06f1:	mov    %rcx,%r15
 10a06f4:	lea    -0x438(%rbp),%rdx
 10a06fb:	lea    -0x360(%rbp),%rsi
 10a0702:	mov    %rdi,%r14
 10a0705:	call   114d360 <myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_retain>
 10a070a:	mov    %r14,%rdi
 10a070d:	cmp    $0x0,%eax
 10a0710:	jne    10a0729 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0x949>
 10a0712:	call   1169620 <myl_rc_take_failure>
 10a0717:	mov    %r12,%rdi
 10a071a:	mov    %eax,%esi
 10a071c:	mov    %rdi,%r12
 10a071f:	call   1159ad0 <myl_qbe_rc_status>
 10a0724:	jmp    10a0bc6 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0xde6>
 10a0729:	lea    -0x438(%rbp),%rsi
 10a0730:	mov    %rdi,%r14
 10a0733:	call   114d280 <myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_unloan>
 10a0738:	mov    %r15,%rcx
 10a073b:	mov    %r14,%rdi
 10a073e:	mov    %rbx,%rax
 10a0741:	mov    %rcx,%r14
 10a0744:	mov    -0x360(%rbp),%rcx
 10a074b:	mov    %rcx,0x0(%r13)
 10a074f:	mov    %rax,%rbx
 10a0752:	mov    -0x358(%rbp),%rax
 10a0759:	mov    %rax,0x8(%r13)
 10a075d:	mov    $0x42,%esi
 10a0762:	mov    %rdi,%r13
 10a0765:	lea    0x116f7c(%rip),%rdi        # 11b76e8 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e_meta>
 10a076c:	call   115c041 <myl_qbe_error_trace_origin>
 10a0771:	mov    %r14,%rcx
 10a0774:	mov    %r13,%rdi
 10a0777:	mov    %rbx,%rax
 10a077a:	mov    -0x68(%rbp),%rdx
 10a077e:	mov    %rdx,-0x438(%rbp)
 10a0785:	mov    -0x60(%rbp),%rdx
 10a0789:	mov    %rdx,-0x430(%rbp)
 10a0790:	mov    %rax,%rbx
 10a0793:	mov    -0x58(%rbp),%rax
 10a0797:	mov    %rax,-0x428(%rbp)
 10a079e:	lea    -0x438(%rbp),%rdx
 10a07a5:	lea    -0x360(%rbp),%rsi
 10a07ac:	mov    %rdi,%r13
 10a07af:	call   11478b0 <myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_take>
 10a07b4:	mov    %r13,%rdi
 10a07b7:	cmp    $0x0,%eax
 10a07ba:	jne    10a07d9 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0x9f9>
 10a07bc:	call   1169620 <myl_rc_take_failure>
 10a07c1:	mov    %r12,%rdi
 10a07c4:	mov    %eax,%esi
 10a07c6:	mov    %rdi,%r12
 10a07c9:	call   1159ad0 <myl_qbe_rc_status>
 10a07ce:	mov    %rbx,%rax
 10a07d1:	mov    %rax,%rbx
 10a07d4:	jmp    10a0bc6 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0xde6>
 10a07d9:	mov    %rbx,%rax
 10a07dc:	mov    -0x360(%rbp),%rcx
 10a07e3:	mov    %rcx,(%rax)
 10a07e6:	mov    -0x358(%rbp),%rcx
 10a07ed:	mov    %rcx,0x8(%rax)
 10a07f1:	mov    -0x350(%rbp),%rcx
 10a07f8:	mov    %rcx,0x10(%rax)
 10a07fc:	jmp    10a0c24 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0xe44>
 10a0801:	mov    0x191dd8(%rip),%rsi        # 12325e0 <myl_lit_2d6548b0d20925eb41b8b902da17a2651a780e0ecf585d7c93694f27a1a25cd5>
 10a0808:	mov    %rsi,-0x368(%rbp)
 10a080f:	mov    %rcx,%r14
 10a0812:	mov    -0x368(%rbp),%rcx
 10a0819:	mov    %rcx,-0x360(%rbp)
 10a0820:	mov    %rax,%rbx
 10a0823:	mov    -0x360(%rbp),%rax
 10a082a:	mov    %rax,-0x438(%rbp)
 10a0831:	mov    0x18(%r13),%rdx
 10a0835:	mov    %rdi,%r13
 10a0838:	mov    %r12,%rdi
 10a083b:	call   10af7f0 <myl_f_8c062ec4784d4b0491e6d5d24da0bf886cc822f390794d94cd35c159749aceeb_rc_borrow>
 10a0840:	mov    %r13,%rdi
 10a0843:	mov    %rax,%rcx
 10a0846:	mov    %rdx,%rax
 10a0849:	mov    %rcx,-0x480(%rbp)
 10a0850:	mov    %rax,-0x478(%rbp)
 10a0857:	lea    -0x480(%rbp),%rdx
 10a085e:	lea    -0x360(%rbp),%rsi
 10a0865:	mov    %rdi,%r13
 10a0868:	call   114d230 <myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_loan>
 10a086d:	mov    %r14,%rcx
 10a0870:	mov    %r13,%rdi
 10a0873:	cmp    $0x0,%eax
 10a0876:	jne    10a0895 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0xab5>
 10a0878:	call   1169620 <myl_rc_take_failure>
 10a087d:	mov    %r12,%rdi
 10a0880:	mov    %eax,%esi
 10a0882:	mov    %rdi,%r12
 10a0885:	call   1159ad0 <myl_qbe_rc_status>
 10a088a:	mov    %rbx,%rax
 10a088d:	mov    %rax,%rbx
 10a0890:	jmp    10a0bc6 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0xde6>
 10a0895:	mov    %rbx,%rax
 10a0898:	mov    -0x438(%rbp),%rsi
 10a089f:	cmp    $0x0,%rsi
 10a08a3:	je     10a0908 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0xb28>
 10a08a5:	mov    -0x10(%rsi),%rdx
 10a08a9:	movabs $0x4000000000000002,%r8
 10a08b3:	and    %r8,%rdx
 10a08b6:	cmp    $0x0,%rdx
 10a08ba:	jne    10a08fd <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0xb1d>
 10a08bc:	mov    %rcx,%r14
 10a08bf:	mov    -0x20(%rsi),%rcx
 10a08c3:	mov    %rcx,%rdx
 10a08c6:	sub    $0x1,%rdx
 10a08ca:	jne    10a08f6 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0xb16>
 10a08cc:	mov    %rax,%rbx
 10a08cf:	mov    -0x18(%rsi),%rax
 10a08d3:	cmp    $0x0,%rax
 10a08d7:	jne    10a08f3 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0xb13>
 10a08d9:	lea    -0x438(%rbp),%rsi
 10a08e0:	mov    %rdi,%r13
 10a08e3:	call   113f3a0 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop>
 10a08e8:	mov    %r14,%rcx
 10a08eb:	mov    %r13,%rdi
 10a08ee:	mov    %rbx,%rax
 10a08f1:	jmp    10a0908 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0xb28>
 10a08f3:	mov    %rbx,%rax
 10a08f6:	mov    %r14,%rcx
 10a08f9:	mov    %rdx,-0x20(%rsi)
 10a08fd:	movq   $0x0,-0x438(%rbp)
 10a0908:	mov    -0x360(%rbp),%rdx
 10a090f:	mov    %rdx,-0x438(%rbp)
 10a0916:	mov    -0x358(%rbp),%rdx
 10a091d:	mov    %rdx,-0x430(%rbp)
 10a0924:	movq   $0x0,-0x80(%rbp)
 10a092c:	mov    %rax,%rbx
 10a092f:	lea    -0x80(%rbp),%rax
 10a0933:	mov    %rax,%r13
 10a0936:	add    $0x8,%r13
 10a093a:	movq   $0x0,-0x78(%rbp)
 10a0942:	movq   $0x0,-0x70(%rbp)
 10a094a:	movl   $0x1,-0x80(%rbp)
 10a0951:	mov    %rcx,%r15
 10a0954:	lea    -0x438(%rbp),%rdx
 10a095b:	lea    -0x360(%rbp),%rsi
 10a0962:	mov    %rdi,%r14
 10a0965:	call   114d360 <myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_retain>
 10a096a:	mov    %r14,%rdi
 10a096d:	cmp    $0x0,%eax
 10a0970:	jne    10a0989 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0xba9>
 10a0972:	call   1169620 <myl_rc_take_failure>
 10a0977:	mov    %r12,%rdi
 10a097a:	mov    %eax,%esi
 10a097c:	mov    %rdi,%r12
 10a097f:	call   1159ad0 <myl_qbe_rc_status>
 10a0984:	jmp    10a0bc6 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0xde6>
 10a0989:	lea    -0x438(%rbp),%rsi
 10a0990:	mov    %rdi,%r14
 10a0993:	call   114d280 <myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_unloan>
 10a0998:	mov    %r15,%rcx
 10a099b:	mov    %r14,%rdi
 10a099e:	mov    %rbx,%rax
 10a09a1:	mov    %rcx,%r14
 10a09a4:	mov    -0x360(%rbp),%rcx
 10a09ab:	mov    %rcx,0x0(%r13)
 10a09af:	mov    %rax,%rbx
 10a09b2:	mov    -0x358(%rbp),%rax
 10a09b9:	mov    %rax,0x8(%r13)
 10a09bd:	mov    $0x3b,%esi
 10a09c2:	mov    %rdi,%r13
 10a09c5:	lea    0x116d1c(%rip),%rdi        # 11b76e8 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e_meta>
 10a09cc:	call   115c041 <myl_qbe_error_trace_origin>
 10a09d1:	mov    %r14,%rcx
 10a09d4:	mov    %r13,%rdi
 10a09d7:	mov    %rbx,%rax
 10a09da:	mov    -0x80(%rbp),%rdx
 10a09de:	mov    %rdx,-0x438(%rbp)
 10a09e5:	mov    -0x78(%rbp),%rdx
 10a09e9:	mov    %rdx,-0x430(%rbp)
 10a09f0:	mov    %rax,%rbx
 10a09f3:	mov    -0x70(%rbp),%rax
 10a09f7:	mov    %rax,-0x428(%rbp)
 10a09fe:	lea    -0x438(%rbp),%rdx
 10a0a05:	lea    -0x360(%rbp),%rsi
 10a0a0c:	mov    %rdi,%r13
 10a0a0f:	call   11478b0 <myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_take>
 10a0a14:	mov    %r13,%rdi
 10a0a17:	cmp    $0x0,%eax
 10a0a1a:	jne    10a0a39 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0xc59>
 10a0a1c:	call   1169620 <myl_rc_take_failure>
 10a0a21:	mov    %r12,%rdi
 10a0a24:	mov    %eax,%esi
 10a0a26:	mov    %rdi,%r12
 10a0a29:	call   1159ad0 <myl_qbe_rc_status>
 10a0a2e:	mov    %rbx,%rax
 10a0a31:	mov    %rax,%rbx
 10a0a34:	jmp    10a0bc6 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0xde6>
 10a0a39:	mov    %rbx,%rax
 10a0a3c:	mov    -0x360(%rbp),%rcx
 10a0a43:	mov    %rcx,(%rax)
 10a0a46:	mov    -0x358(%rbp),%rcx
 10a0a4d:	mov    %rcx,0x8(%rax)
 10a0a51:	mov    -0x350(%rbp),%rcx
 10a0a58:	mov    %rcx,0x10(%rax)
 10a0a5c:	jmp    10a0c24 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0xe44>
 10a0a61:	mov    %ebx,%r13d
 10a0a64:	mov    -0x290(%rbp),%rdx
 10a0a6b:	mov    %rdx,-0x280(%rbp)
 10a0a72:	mov    -0x288(%rbp),%rdx
 10a0a79:	mov    %rdx,-0x278(%rbp)
 10a0a80:	mov    %rcx,%r14
 10a0a83:	mov    -0x280(%rbp),%ecx
 10a0a89:	cmp    $0x0,%rcx
 10a0a8d:	je     10a0ad4 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0xcf4>
 10a0a8f:	cmp    $0x1,%rcx
 10a0a93:	je     10a0abd <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0xcdd>
 10a0a95:	cmp    $0x2,%rcx
 10a0a99:	je     10a0ab3 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0xcd3>
 10a0a9b:	cmp    $0x3,%rcx
 10a0a9f:	je     10a0aa9 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0xcc9>
 10a0aa1:	mov    %rax,%rbx
 10a0aa4:	jmp    10a0bc6 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0xde6>
 10a0aa9:	mov    %rax,%rbx
 10a0aac:	mov    $0x0,%eax
 10a0ab1:	jmp    10a0adc <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0xcfc>
 10a0ab3:	mov    %rax,%rbx
 10a0ab6:	mov    $0x0,%eax
 10a0abb:	jmp    10a0adc <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0xcfc>
 10a0abd:	mov    %rax,%rbx
 10a0ac0:	movzbq -0x278(%rbp),%rax
 10a0ac8:	mov    %al,-0x360(%rbp)
 10a0ace:	xor    $0x1,%rax
 10a0ad2:	jmp    10a0adc <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0xcfc>
 10a0ad4:	mov    %rax,%rbx
 10a0ad7:	mov    $0x1,%eax
 10a0adc:	movq   $0x0,-0x250(%rbp)
 10a0ae7:	movq   $0x0,-0x248(%rbp)
 10a0af2:	movl   $0x1,-0x250(%rbp)
 10a0afc:	movzbq %al,%rax
 10a0b00:	mov    %al,-0x248(%rbp)
 10a0b06:	lea    -0x250(%rbp),%rdx
 10a0b0d:	mov    %rdi,%r15
 10a0b10:	mov    %r12,%rdi
 10a0b13:	call   109cfd0 <myl_f_1e67eb8ef4c3a3acc3a97242d455a6d9c8a2bcb48d8912e38331c2e291a74a0e>
 10a0b18:	mov    %r15,%rdi
 10a0b1b:	cmp    $0x0,%r13d
 10a0b1f:	jne    10a0b29 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0xd49>
 10a0b21:	mov    %rbx,%rax
 10a0b24:	mov    %r14,%rcx
 10a0b27:	jmp    10a0b41 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0xd61>
 10a0b29:	lea    -0x438(%rbp),%rsi
 10a0b30:	mov    %rdi,%r13
 10a0b33:	call   1141750 <myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop>
 10a0b38:	mov    %r14,%rcx
 10a0b3b:	mov    %r13,%rdi
 10a0b3e:	mov    %rbx,%rax
 10a0b41:	movq   $0x0,-0x180(%rbp)
 10a0b4c:	movq   $0x0,-0x178(%rbp)
 10a0b57:	movq   $0x0,-0x170(%rbp)
 10a0b62:	movl   $0x0,-0x180(%rbp)
 10a0b6c:	mov    -0x180(%rbp),%rdx
 10a0b73:	mov    %rdx,-0x438(%rbp)
 10a0b7a:	mov    -0x178(%rbp),%rdx
 10a0b81:	mov    %rdx,-0x430(%rbp)
 10a0b88:	mov    %rax,%rbx
 10a0b8b:	mov    -0x170(%rbp),%rax
 10a0b92:	mov    %rax,-0x428(%rbp)
 10a0b99:	lea    -0x438(%rbp),%rdx
 10a0ba0:	lea    -0x360(%rbp),%rsi
 10a0ba7:	mov    %rdi,%r13
 10a0baa:	call   11478b0 <myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_take>
 10a0baf:	mov    %r13,%rdi
 10a0bb2:	cmp    $0x0,%eax
 10a0bb5:	jne    10a0c01 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0xe21>
 10a0bb7:	call   1169620 <myl_rc_take_failure>
 10a0bbc:	mov    %r12,%rdi
 10a0bbf:	mov    %eax,%esi
 10a0bc1:	call   1159ad0 <myl_qbe_rc_status>
 10a0bc6:	mov    $0x18,%edx
 10a0bcb:	mov    $0x0,%esi
 10a0bd0:	lea    -0x450(%rbp),%rdi
 10a0bd7:	call   1176fb0 <compiler_rt.fastMemset>
 10a0bdc:	mov    %rbx,%rax
 10a0bdf:	mov    -0x450(%rbp),%rcx
 10a0be6:	mov    %rcx,(%rax)
 10a0be9:	mov    -0x448(%rbp),%rcx
 10a0bf0:	mov    %rcx,0x8(%rax)
 10a0bf4:	mov    -0x440(%rbp),%rcx
 10a0bfb:	mov    %rcx,0x10(%rax)
 10a0bff:	jmp    10a0c24 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0xe44>
 10a0c01:	mov    %rbx,%rax
 10a0c04:	mov    -0x360(%rbp),%rcx
 10a0c0b:	mov    %rcx,(%rax)
 10a0c0e:	mov    -0x358(%rbp),%rcx
 10a0c15:	mov    %rcx,0x8(%rax)
 10a0c19:	mov    -0x350(%rbp),%rcx
 10a0c20:	mov    %rcx,0x10(%rax)
 10a0c24:	pop    %r15
 10a0c26:	pop    %r14
 10a0c28:	pop    %r13
 10a0c2a:	pop    %r12
 10a0c2c:	pop    %rbx
 10a0c2d:	leave
 10a0c2e:	ret
 10a0c2f:	mov    %r12,%rdi
 10a0c32:	call   115abd0 <myl_qbe_fail_frame>
 10a0c37:	ud2

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
