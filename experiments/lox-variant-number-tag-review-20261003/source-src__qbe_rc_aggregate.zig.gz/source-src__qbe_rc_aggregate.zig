//! Transactional aggregate ownership while constructors and updates can fail.
const typed = @import("typed.zig");
const bytecode = @import("bytecode.zig");
const frame = @import("qbe_rc_frame.zig");
const values = @import("qbe_rc_values.zig");
const slots = @import("qbe_rc_slots.zig");
const state = @import("qbe_rc_state.zig");
const fresh = @import("qbe_rc_fresh_constructor.zig");
const Op = @FieldType(bytecode.Instruction, "op");
const blit_value = values.blit_value;
/// Native emitter failures shared by aggregate publication helpers.
pub const Error = values.Error;

/// Operations whose complete output ownership is published in this module.
pub fn handles(records: []const typed.Record, op: Op) bool {
    return switch (op) {
        .make_record => |record| !records[record.ty.recordIndex()].isCollection(),
        .make_variant, .update_record, .switch_variant => true,
        .replace_index => |access| !records[access.ty.recordIndex()].managed,
        else => false,
    };
}

/// Handle aggregates only when this function has a live ownership journal.
pub fn emit(comptime E: type, self: *E, op: Op, stack: []const typed.Type) Error!bool {
    if (@import("qbe_rc_borrow.zig").active(E, self)) return false;
    if (frame.get(E, self) == null or !handles(self.program.records, op) or op == .replace_index) return false;
    switch (op) {
        .make_record => |record| try construct(E, self, record, stack.len),
        .make_variant => |variant| try variantValue(E, self, variant, stack.len),
        .update_record => |update| try updateValue(E, self, update, stack.len),
        .switch_variant => |dispatch| try dispatchValue(E, self, dispatch, stack.len),
        else => return error.InternalError,
    }
    return true;
}

fn region(comptime E: type, self: *E) Error!usize {
    return frame.region(E, self);
}

fn internal(comptime E: type, self: *E, ty: typed.Type, address: usize) Error!void {
    const index = frame.pending(E, self) + 1;
    try frame.entry(E, self, index, ty, address);
    try frame.initialized(E, self, index, true);
}

fn pending(comptime E: type, self: *E, ty: typed.Type, address: usize) Error!void {
    const index = frame.pending(E, self);
    try frame.entry(E, self, index, ty, address);
    try frame.initialized(E, self, index, true);
}

fn owns(comptime E: type, self: *E, ty: typed.Type) Error!bool {
    const shape = frame.get(E, self).?.catalog.get(ty) catch return error.InternalError;
    return shape.counted or shape.unique_drop;
}

fn zero(comptime E: type, self: *E, ty: typed.Type, address: usize) Error!void {
    const layout = try self.layout(ty);
    try @import("qbe_zero.zig").clear(*E, self, address, layout.size, layout.alignment);
}

const Field = struct { ty: typed.Type, source: usize, destination: usize, region: usize, operand: ?usize = null, infallible: bool = false };
fn initialize(comptime E: type, self: *E, field: Field) Error!void {
    const shape = frame.get(E, self).?.catalog.get(field.ty) catch return error.InternalError;
    if (!shape.counted and !shape.unique_drop) {
        try self.writeValue(field.destination, try self.readValue(field.source, field.ty), field.ty);
        return;
    }
    if (field.infallible) {
        // Whole-constructor preflight already proved the exact ordinary role.
        // No fallible work follows allocation until complete result publication.
        try self.print(blit_value, .{ field.source, field.destination, (try self.layout(field.ty)).size });
        try frame.initialized(E, self, values.journalIndex(E, self, field.operand.?), false);
        return;
    }
    if (!shape.unique_drop) if (field.operand) |index| {
        // Constructor inputs are consumed. An initialized ordinary owner can
        // move into the already-journaled partial aggregate; borrowed or held
        // inputs still acquire an independent value through prepareOperand.
        // No fallible operation separates this publication and guard handoff.
        const label = try fresh.begin(E, self, field.ty, index, field.source, field.destination);
        try values.prepareOperand(E, self, field.ty, index);
        const work = try values.workAddress(E, self);
        try self.print(blit_value, .{ work, field.destination, (try self.layout(field.ty)).size });
        try frame.initialized(E, self, frame.pending(E, self), false);
        if (label) |id| try self.print("@rcfreshdone{d}\n", .{id});
        return;
    };
    try slots.Lower(E).transfer(self, .{ .ty = field.ty, .source = field.source, .destination = field.destination, .region = field.region, .mode = if (shape.unique_drop) .take_empty else .retain_empty });
    if (shape.unique_drop) if (field.operand) |index|
        try frame.initialized(E, self, values.journalIndex(E, self, index), false);
}

fn construct(comptime E: type, self: *E, record: @FieldType(Op, "make_record"), height: usize) Error!void {
    if (try @import("qbe_rc_views.zig").construct(E, self, record, height)) return;
    const span = try fresh.beginSpan(E, self, record.ty, height - record.fields, record.fields);
    if (span) |label| {
        try recordBody(E, self, record, height, true);
        try self.print(" jmp @rcspandone{d}\n@rcspanslow{d}\n", .{ label, label });
    }
    try recordBody(E, self, record, height, false);
    if (span) |label| try self.print("@rcspandone{d}\n", .{label});
}

fn recordBody(comptime E: type, self: *E, record: @FieldType(Op, "make_record"), height: usize, infallible: bool) Error!void {
    const managed = self.program.records[record.ty.recordIndex()].isManagedRecord();
    const pointer = if (managed)
        try @import("qbe_alloc.zig").cell(*E, self, record.ty, self.states[self.pc].?)
    else
        try self.aggregatePointer();
    if (managed) {
        if (!infallible) try values.holdRuntime(E, self, record.ty, pointer);
    } else if (try owns(E, self, record.ty)) {
        try zero(E, self, record.ty, pointer);
        if (!infallible) try internal(E, self, record.ty, pointer);
    }
    // RC-PLAIN-CONSTRUCT-1: a plain inline record owns nothing; each field is
    // written below without a fallible step, so it needs neither zero bytes
    // nor a cleanup entry for a partial value, exactly as the collector.
    const depth = try region(E, self);
    const base = height - record.fields;
    for (0..record.fields) |i| {
        const index = if (record.order.len == 0) i else record.order[i];
        const member = try self.field(record.ty, index);
        try initialize(E, self, .{ .ty = member.ty, .source = try values.source(E, self, base + i, member.ty), .destination = try self.address(pointer, member.offset), .region = depth, .operand = base + i, .infallible = infallible });
    }
    try self.store(base, pointer);
    try finishConstructor(E, self, record.ty, base, record.fields);
}

fn variantValue(comptime E: type, self: *E, variant: @FieldType(Op, "make_variant"), height: usize) Error!void {
    const payload = self.program.records[variant.ty.recordIndex()].shape.variants.?.cases[variant.tag].payload;
    const count = @intFromBool(payload != null);
    const span = try fresh.beginSpan(E, self, variant.ty, height - count, count);
    if (span) |label| {
        try variantBody(E, self, variant, height, true);
        try self.print(" jmp @rcspandone{d}\n@rcspanslow{d}\n", .{ label, label });
    }
    try variantBody(E, self, variant, height, false);
    if (span) |label| try self.print("@rcspandone{d}\n", .{label});
}

fn variantBody(comptime E: type, self: *E, variant: @FieldType(Op, "make_variant"), height: usize, infallible: bool) Error!void {
    const payload = self.program.records[variant.ty.recordIndex()].shape.variants.?.cases[variant.tag].payload;
    const tag_words = @import("qbe_rc_number_tag.zig");
    const widen_tag = if (payload) |ty| blk: {
        const shape = frame.get(E, self).?.catalog.get(ty) catch return error.InternalError;
        break :blk tag_words.admits(self.program.records, self.program.records[variant.ty.recordIndex()], variant.tag, try self.layout(variant.ty), shape);
    } else false;
    const direct_empty = payload == null and !typed.moveOnly(variant.ty, self.program.records);
    const pointer = try self.aggregatePointer();
    try zero(E, self, variant.ty, pointer);
    if (widen_tag) try tag_words.writeTag(E, self, variant.tag, pointer) else try self.writeTag(variant.ty, variant.tag, pointer);
    if (!direct_empty and !infallible) try internal(E, self, variant.ty, pointer);
    const base = height - @intFromBool(payload != null);
    if (payload) |ty| try initialize(E, self, .{
        .ty = ty,
        .source = try values.source(E, self, base, ty),
        .destination = try self.address(pointer, (try self.layout(variant.ty)).payload_offset),
        .region = try region(E, self),
        .operand = base,
        .infallible = infallible,
    });
    try self.store(base, pointer);
    try @import("qbe_error_trace.zig").Lower(E).construction(self, variant.ty, variant.tag);
    try finishConstructor(E, self, variant.ty, base, @intFromBool(payload != null));
}

fn finishConstructor(comptime E: type, self: *E, ty: typed.Type, base: usize, consumed: usize) Error!void {
    if (typed.moveOnly(ty, self.program.records))
        return finish(E, self, .{ .ty = ty, .base = base, .consumed = consumed, .origin = .owned });
    // initialize consumes every ordinary input guard, including H-to-O copies;
    // a borrowed input starts clear. Plain inputs never carry an obligation.
    // The new body lives in separate aggregate/heap storage, so publishing to
    // the vacated first operand cannot overwrite a still-owned input.
    try values.constructed(E, self, ty, base);
}

fn finish(comptime E: type, self: *E, result: values.Result) Error!void {
    // Ownership moves into pending storage before any input destructor can run.
    // The intervening result load and journal stores cannot fail or call out.
    try values.commitRuntime(E, self);
    try values.finish(E, self, result);
}

/// Own the complete base before a fallible aggregate update or index check.
pub fn prepareBase(comptime E: type, self: *E, ty: typed.Type, base: usize) Error!usize {
    const shape = frame.get(E, self).?.catalog.get(ty) catch return error.InternalError;
    if (!shape.counted and !shape.unique_drop) {
        if (!self.program.records[ty.recordIndex()].isManagedRecord() and (try self.layout(ty)).size != 0) {
            // The same private per-PC scratch used by ordinary GC updates is
            // separate from operand/local/backing storage. Plain bits have no
            // publication, region, pin or cleanup obligation to prepare.
            const source = try self.load("s", base);
            const storage = try self.aggregatePointer();
            try self.print(blit_value, .{ source, storage, (try self.layout(ty)).size });
            return storage;
        }
    }
    try values.prepareOperand(E, self, ty, base);
    const work = try values.workAddress(E, self);
    const managed = self.program.records[ty.recordIndex()].isManagedRecord();
    const storage = if (managed) blk: {
        const address = self.temp();
        try self.print(" %v{d} =l copy %rcinternal\n", .{address});
        break :blk address;
    } else try self.aggregatePointer();
    try self.print(blit_value, .{ work, storage, (try self.layout(ty)).size });
    try frame.initialized(E, self, frame.pending(E, self), false);
    try internal(E, self, ty, storage);
    if (managed) {
        const guard = try frame.guard(E, self, frame.pending(E, self) + 1);
        const unique = self.temp();
        const glue = @import("qbe_rc_glue.zig");
        try glue.uniqueFast(E, self, storage, unique);
        try self.print(" %v{d} =w call $myl_qbe_rc_unique_local(l %ctx, l extern ${s}, l %v{d}, l %v{d})\n", .{ unique, try self.descriptor(ty), storage, guard });
        try @import("qbe_rc_unique.zig").success(E, self, unique);
        try glue.uniqueJoin(E, self, unique);
    }
    return if (managed) self.readValue(storage, ty) else storage;
}

fn replace(comptime E: type, self: *E, field: Field) Error!void {
    const shape = frame.get(E, self).?.catalog.get(field.ty) catch return error.InternalError;
    if (!shape.counted and !shape.unique_drop) if (self.isScalar(field.ty) and (try self.layout(field.ty)).size != 0) {
        // Pending is clear after base preparation and every preceding field.
        // Load the complete scalar before writing, preserving even exact alias
        // and the existing width/domain representation without a dead token.
        try self.writeValue(field.destination, try self.readValue(field.source, field.ty), field.ty);
        return;
    };
    const work = try values.workAddress(E, self);
    try initialize(E, self, .{ .ty = field.ty, .source = field.source, .destination = work, .region = field.region, .operand = field.operand });
    try pending(E, self, field.ty, work);
    if (shape.unique_drop) try self.print(" call $myl_native_owned_drop(l %heap, l extern ${s}, l %v{d})\n", .{ try self.descriptor(field.ty), field.destination });
    if (shape.counted) try @import("qbe_rc_glue.zig").drop(E, self, .{ .ty = field.ty, .address = field.destination });
    try self.print(blit_value, .{ work, field.destination, (try self.layout(field.ty)).size });
    try frame.initialized(E, self, frame.pending(E, self), false);
}

fn updateValue(comptime E: type, self: *E, update: @FieldType(Op, "update_record"), height: usize) Error!void {
    if (try @import("qbe_rc_plain_record_write.zig").update(E, self, height)) return;
    if (try @import("qbe_rc_views.zig").update(E, self, update, height)) return;
    const base = height - update.indices.len - 1;
    const pointer = try prepareBase(E, self, update.ty, base);
    const depth = if (self.program.records[update.ty.recordIndex()].isManagedRecord()) blk: {
        const result = self.temp();
        try self.print(" %v{d} =w call $myl_native_header_region(l %v{d})\n", .{ result, pointer });
        break :blk result;
    } else try region(E, self);
    for (update.indices, 0..) |index, i| {
        const member = try self.field(update.ty, index);
        try replace(E, self, .{ .ty = member.ty, .source = try values.source(E, self, base + 1 + i, member.ty), .destination = try self.address(pointer, member.offset), .region = depth, .operand = base + 1 + i });
    }
    try self.store(base, pointer);
    try finish(E, self, .{ .ty = update.ty, .base = base, .consumed = update.indices.len + 1, .origin = .owned });
}

fn dispatchValue(comptime E: type, self: *E, dispatch: @FieldType(Op, "switch_variant"), height: usize) Error!void {
    const pointer = try self.load("s", height - 1);
    const tag = try self.readTag(dispatch.ty, pointer);
    for (dispatch.arms, 0..) |arm, i| {
        const matches = self.temp();
        try self.print(" %v{d} =l ceql %v{d}, {d}\n jnz %v{d}, @rcarm{d}, @rcarmnext{d}\n@rcarm{d}\n", .{ matches, tag, i, matches, matches, matches, matches });
        if (arm.slot) |slot| if (dispatch.borrowed or @import("qbe_rc_readonly_anchor.zig").payload(E, self, self.pc, @backingInt(slot))) {
            try borrowPayload(E, self, dispatch.ty, pointer, @backingInt(slot));
        } else if (!try @import("qbe_rc_narrowing.zig").bind(E, self, dispatch, @backingInt(slot))) {
            const index = @backingInt(slot);
            const ty = self.function.scope.locals[index].ty;
            const work = try values.workAddress(E, self);
            const payload = try self.address(pointer, (try self.layout(dispatch.ty)).payload_offset);
            if (@import("rc_element_take.zig").find(frame.get(E, self).?.plan.records.takes, self.pc, index)) |take| {
                try @import("qbe_rc_element_take.zig").bind(E, self, take, .{ .scrutinee = pointer, .payload = payload, .work = work, .ty = ty, .region = try region(E, self) });
            } else try initialize(E, self, .{ .ty = ty, .source = payload, .destination = work, .region = try region(E, self) });
            try pending(E, self, ty, work);
            try frame.drop(E, self, index);
            try bindLocal(E, self, work, index, ty);
            try frame.initialized(E, self, frame.pending(E, self), false);
            if (try state.owns(frame.get(E, self).?, ty)) {
                const address = self.temp();
                try self.print(" %v{d} =l copy %l{d}\n", .{ address, index });
                try frame.entry(E, self, index, ty, address);
                try frame.initialized(E, self, index, true);
            }
        };
        try values.drop(E, self, height - 1);
        try self.print(" jmp @{s}{d}\n@rcarmnext{d}\n", .{ self.labelPrefix(arm.target), arm.target, matches });
    }
    try self.print(" jmp @failure\n", .{});
}

fn borrowPayload(comptime E: type, self: *E, parent: typed.Type, pointer: usize, index: usize) Error!void {
    // Contract inspection leaves the complete result, including unique fields,
    // in its hidden owner until the subsequent return or boundary cleanup.
    const ty = self.function.scope.locals[index].ty;
    const selected = try self.address(pointer, (try self.layout(parent)).payload_offset);
    try frame.drop(E, self, index);
    try bindLocal(E, self, selected, index, ty);
    try frame.initialized(E, self, index, false);
}

// RC-MATCH-SCALAR-1: a local's scalar slot is one canonical machine word that
// every read loads whole (`loadl`). A payload's packed layout can be narrower
// (a bool or `u8` is one byte), so a width-sized copy would leave the slot's
// upper bytes stale; load the payload with its own extension and store a word.
fn bindLocal(comptime E: type, self: *E, source: usize, index: usize, ty: typed.Type) Error!void {
    if (self.isScalar(ty)) return self.print(" storel %v{d}, %l{d}\n", .{ try self.readValue(source, ty), index });
    try self.print(" blit %v{d}, %l{d}, {d}\n", .{ source, index, (try self.layout(ty)).size });
}

/// One checked fixed-array update and the instruction's consumed operand range.
pub const ArrayUpdate = struct { array: typed.Type, element: typed.Type, address: usize, source: usize, base: usize, input: usize };
/// Prepare the new element before retiring the old owning field, then publish.
pub fn arrayElement(comptime E: type, self: *E, update: ArrayUpdate) Error!void {
    try replace(E, self, .{ .ty = update.element, .source = try values.source(E, self, update.input, update.element), .destination = update.address, .region = try region(E, self), .operand = update.input });
    try self.store(update.base, update.source);
    try finish(E, self, .{ .ty = update.array, .base = update.base, .consumed = 3, .origin = .owned });
}

const Propagate = @FieldType(Op, "try_result");
const ErrorPayload = struct { input: typed.Type, output: typed.Type };
const TryShape = struct { success: typed.Type, success_tag: usize, error_tag: usize, payload: ?ErrorPayload = null };

/// Own the selected payload before retiring a consumed result or option.
pub fn propagation(comptime E: type, self: *E, operation: Propagate, stack: []const typed.Type) Error!bool {
    if (frame.get(E, self) == null) return false;
    const shape: TryShape = if (typed.resultShape(operation.input, self.program.records)) |input| blk: {
        const output = typed.resultShape(operation.output, self.program.records).?;
        break :blk .{ .success = input.ok_type, .success_tag = input.ok_tag, .error_tag = output.error_tag, .payload = .{ .input = input.error_type, .output = output.error_type } };
    } else if (@import("prelude.zig").optionShape(operation.input, self.program.records)) |input| blk: {
        const output = @import("prelude.zig").optionShape(operation.output, self.program.records).?;
        break :blk .{ .success = input.element, .success_tag = input.some, .error_tag = output.none };
    } else return error.InternalError;
    const source = try self.load("s", stack.len - 1);
    const tag = try self.readTag(operation.input, source);
    const success = self.temp();
    try self.print(" %v{d} =l ceql %v{d}, {d}\n jnz %v{d}, @rctryok{d}, @rctryerror{d}\n@rctryerror{d}\n", .{ success, tag, shape.success_tag, success, tag, tag, tag });
    if (typed.resultShape(operation.input, self.program.records)) |input| {
        try @import("qbe_error_trace.zig").Lower(E).propagation(self, input, typed.resultShape(operation.output, self.program.records).?);
    }
    const payload = try self.address(source, (try self.layout(operation.input)).payload_offset);
    try errorValue(E, self, operation, shape, .{ .address = payload, .height = stack.len });
    try self.print(" jmp @{s}{d}\n@rctryok{d}\n", .{ self.labelPrefix(operation.error_target), operation.error_target, tag });
    const pointer = try self.aggregatePointer();
    try zero(E, self, shape.success, pointer);
    try internal(E, self, shape.success, pointer);
    const selected = try self.address(source, (try self.layout(operation.input)).payload_offset);
    try initialize(E, self, .{ .ty = shape.success, .source = selected, .destination = pointer, .region = try region(E, self) });
    try self.store(stack.len - 1, try self.readValue(pointer, shape.success));
    try finish(E, self, .{ .ty = shape.success, .base = stack.len - 1, .consumed = 1, .origin = .owned });
    return true;
}

const InputPayload = struct { address: usize, height: usize };
fn errorValue(comptime E: type, self: *E, operation: Propagate, shape: TryShape, input: InputPayload) Error!void {
    const pointer = try self.aggregatePointer();
    try zero(E, self, operation.output, pointer);
    try self.writeTag(operation.output, shape.error_tag, pointer);
    if (shape.payload) |failure| {
        var destination = try self.address(pointer, (try self.layout(operation.output)).payload_offset);
        if (failure.input != failure.output) {
            const tag = typed.wrappingCase(self.program.records, failure.output, failure.input) orelse return error.InternalError;
            try self.writeTag(failure.output, tag, destination);
            destination = try self.address(destination, (try self.layout(failure.output)).payload_offset);
        }
        try internal(E, self, operation.output, pointer);
        try initialize(E, self, .{ .ty = failure.input, .source = input.address, .destination = destination, .region = try region(E, self) });
    } else try internal(E, self, operation.output, pointer);
    try self.store(0, pointer);
    try finish(E, self, .{ .ty = operation.output, .base = 0, .consumed = input.height, .origin = .owned });
}
