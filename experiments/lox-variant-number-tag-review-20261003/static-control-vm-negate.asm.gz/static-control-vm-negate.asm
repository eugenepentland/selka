
/home/epentland/ai/canopy/mylang-worktrees/codex-lox-borrow-assert-20261003/.tmp-lox-borrow-assert-20261003/fixed-qbe-ast:     file format elf64-x86-64


Disassembly of section .text:

0000000001127a30 <myl_f_6b8d2a166bbd9c248350f439dfeb2952399d529c32ecd164fee3dd015aa55840>:
 1127a30:	endbr64
 1127a34:	push   %rbp
 1127a35:	mov    %rsp,%rbp
 1127a38:	sub    $0x110,%rsp
 1127a3f:	push   %rbx
 1127a40:	push   %r12
 1127a42:	push   %r13
 1127a44:	push   %r14
 1127a46:	mov    %rdx,%r14
 1127a49:	mov    %rsi,%r13
 1127a4c:	mov    0x40(%rdi),%rax
 1127a50:	lea    -0x8(%rbp),%rcx
 1127a54:	cmp    %rax,%rcx
 1127a57:	jb     1127eb2 <myl_f_6b8d2a166bbd9c248350f439dfeb2952399d529c32ecd164fee3dd015aa55840+0x482>
 1127a5d:	mov    %rdi,%rbx
 1127a60:	call   115aba0 <myl_qbe_heap>
 1127a65:	mov    %rbx,%rdi
 1127a68:	mov    %rax,%rbx
 1127a6b:	mov    %rdi,%r12
 1127a6e:	call   115d700 <myl_qbe_region_mark>
 1127a73:	mov    %r14,%rdx
 1127a76:	mov    %r13,%rsi
 1127a79:	mov    %r12,%rdi
 1127a7c:	mov    0x80(%rsi),%r10
 1127a83:	movabs $0x8000000000000001,%rax
 1127a8d:	cmp    %rax,%r10
 1127a90:	jl     1127e98 <myl_f_6b8d2a166bbd9c248350f439dfeb2952399d529c32ecd164fee3dd015aa55840+0x468>
 1127a96:	mov    %rsi,%r12
 1127a99:	add    $0x78,%r12
 1127a9d:	mov    0x78(%rsi),%rax
 1127aa1:	mov    (%rax),%r9
 1127aa4:	mov    %r10,%rcx
 1127aa7:	sub    $0x1,%rcx
 1127aab:	cmp    %r9,%rcx
 1127aae:	setb   %r8b
 1127ab2:	movzbq %r8b,%r8
 1127ab6:	cmp    $0x0,%r8d
 1127aba:	jne    1127b41 <myl_f_6b8d2a166bbd9c248350f439dfeb2952399d529c32ecd164fee3dd015aa55840+0x111>
 1127ac0:	cmp    $0x0,%rcx
 1127ac4:	jl     1127acb <myl_f_6b8d2a166bbd9c248350f439dfeb2952399d529c32ecd164fee3dd015aa55840+0x9b>
 1127ac6:	mov    %rcx,%r13
 1127ac9:	jmp    1127af5 <myl_f_6b8d2a166bbd9c248350f439dfeb2952399d529c32ecd164fee3dd015aa55840+0xc5>
 1127acb:	movabs $0x7fffffffffffffff,%r8
 1127ad5:	cmp    %r8,%r9
 1127ad8:	ja     1127b32 <myl_f_6b8d2a166bbd9c248350f439dfeb2952399d529c32ecd164fee3dd015aa55840+0x102>
 1127ada:	mov    %r9,%r13
 1127add:	add    %rcx,%r13
 1127ae0:	mov    %r9,%r8
 1127ae3:	xor    %r13,%r8
 1127ae6:	mov    %rcx,%r10
 1127ae9:	xor    %r13,%r10
 1127aec:	and    %r10,%r8
 1127aef:	cmp    $0x0,%r8
 1127af3:	jl     1127b1a <myl_f_6b8d2a166bbd9c248350f439dfeb2952399d529c32ecd164fee3dd015aa55840+0xea>
 1127af5:	cmp    %r9,%r13
 1127af8:	jb     1127b0a <myl_f_6b8d2a166bbd9c248350f439dfeb2952399d529c32ecd164fee3dd015aa55840+0xda>
 1127afa:	mov    %r9,%rsi
 1127afd:	mov    %rsi,%rdx
 1127b00:	mov    %r13,%rsi
 1127b03:	call   115a7e0 <myl_qbe_fail_normalized_index_bounds>
 1127b08:	ud2
 1127b0a:	mov    0x20(%rax),%rax
 1127b0e:	imul   $0x10,%r13,%r8
 1127b12:	add    %r8,%rax
 1127b15:	mov    %rcx,%r14
 1127b18:	jmp    1127b4f <myl_f_6b8d2a166bbd9c248350f439dfeb2952399d529c32ecd164fee3dd015aa55840+0x11f>
 1127b1a:	mov    %r9,%rsi
 1127b1d:	mov    $0x40,%r8d
 1127b23:	mov    %rsi,%rdx
 1127b26:	mov    $0x0,%esi
 1127b2b:	call   115a9f0 <myl_qbe_fail_overflow_op>
 1127b30:	ud2
 1127b32:	mov    %r9,%rsi
 1127b35:	mov    $0x140,%edx
 1127b3a:	call   115ab30 <myl_qbe_fail_cast>
 1127b3f:	ud2
 1127b41:	mov    0x20(%rax),%rax
 1127b45:	mov    %rcx,%r14
 1127b48:	imul   $0x10,%rcx,%rcx
 1127b4c:	add    %rcx,%rax
 1127b4f:	mov    %rax,%rcx
 1127b52:	mov    (%rax),%eax
 1127b54:	cmp    $0x0,%rax
 1127b58:	je     1127dff <myl_f_6b8d2a166bbd9c248350f439dfeb2952399d529c32ecd164fee3dd015aa55840+0x3cf>
 1127b5e:	cmp    $0x1,%rax
 1127b62:	je     1127d63 <myl_f_6b8d2a166bbd9c248350f439dfeb2952399d529c32ecd164fee3dd015aa55840+0x333>
 1127b68:	cmp    $0x2,%rax
 1127b6c:	je     1127c18 <myl_f_6b8d2a166bbd9c248350f439dfeb2952399d529c32ecd164fee3dd015aa55840+0x1e8>
 1127b72:	cmp    $0x3,%rax
 1127b76:	jne    1127cc6 <myl_f_6b8d2a166bbd9c248350f439dfeb2952399d529c32ecd164fee3dd015aa55840+0x296>
 1127b7c:	mov    0x10aa3d(%rip),%rcx        # 12325c0 <myl_lit_2d6548b0d20925eb41b8b902da17a2651a780e0ecf585d7c93694f27a1a25cd5>
 1127b83:	mov    %rcx,-0x100(%rbp)
 1127b8a:	mov    -0x100(%rbp),%rax
 1127b91:	mov    %rax,-0xf8(%rbp)
 1127b98:	mov    -0xf8(%rbp),%rax
 1127b9f:	mov    %rax,-0x108(%rbp)
 1127ba6:	call   1128220 <myl_f_8855e2338a0239644fa6d8638afc594de302f594debc25ce542a382b2a6572a1>
 1127bab:	mov    %rbx,%rdi
 1127bae:	mov    -0x108(%rbp),%rdx
 1127bb5:	cmp    $0x0,%rdx
 1127bb9:	je     1127e8f <myl_f_6b8d2a166bbd9c248350f439dfeb2952399d529c32ecd164fee3dd015aa55840+0x45f>
 1127bbf:	mov    -0x10(%rdx),%rcx
 1127bc3:	movabs $0x4000000000000002,%rsi
 1127bcd:	and    %rsi,%rcx
 1127bd0:	cmp    $0x0,%rcx
 1127bd4:	jne    1127c08 <myl_f_6b8d2a166bbd9c248350f439dfeb2952399d529c32ecd164fee3dd015aa55840+0x1d8>
 1127bd6:	mov    -0x20(%rdx),%rcx
 1127bda:	sub    $0x1,%rcx
 1127bde:	jne    1127c04 <myl_f_6b8d2a166bbd9c248350f439dfeb2952399d529c32ecd164fee3dd015aa55840+0x1d4>
 1127be0:	mov    %rax,%rbx
 1127be3:	mov    -0x18(%rdx),%rax
 1127be7:	cmp    $0x0,%rax
 1127beb:	jne    1127c01 <myl_f_6b8d2a166bbd9c248350f439dfeb2952399d529c32ecd164fee3dd015aa55840+0x1d1>
 1127bed:	lea    -0x108(%rbp),%rsi
 1127bf4:	call   113f380 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop>
 1127bf9:	mov    %rbx,%rax
 1127bfc:	jmp    1127e8f <myl_f_6b8d2a166bbd9c248350f439dfeb2952399d529c32ecd164fee3dd015aa55840+0x45f>
 1127c01:	mov    %rbx,%rax
 1127c04:	mov    %rcx,-0x20(%rdx)
 1127c08:	movq   $0x0,-0x108(%rbp)
 1127c13:	jmp    1127e8f <myl_f_6b8d2a166bbd9c248350f439dfeb2952399d529c32ecd164fee3dd015aa55840+0x45f>
 1127c18:	mov    %rcx,%rax
 1127c1b:	mov    %r12,%rdx
 1127c1e:	mov    %rdx,%r13
 1127c21:	mov    0x8(%rax),%rdx
 1127c25:	mov    %rdx,-0xf8(%rbp)
 1127c2c:	mov    %rsi,%r12
 1127c2f:	mov    $0x7,%esi
 1127c34:	mov    %rdi,%rbx
 1127c37:	call   115abc0 <myl_qbe_float_unary>
 1127c3c:	mov    %r14,%rcx
 1127c3f:	mov    %r13,%rdx
 1127c42:	mov    %r12,%rsi
 1127c45:	mov    %rbx,%rdi
 1127c48:	movq   $0x0,-0x18(%rbp)
 1127c50:	movq   $0x0,-0x10(%rbp)
 1127c58:	movl   $0x2,-0x18(%rbp)
 1127c5f:	mov    %rax,-0x10(%rbp)
 1127c63:	mov    -0x18(%rbp),%rax
 1127c67:	mov    %rax,-0x28(%rbp)
 1127c6b:	mov    -0x10(%rbp),%rax
 1127c6f:	mov    %rax,-0x20(%rbp)
 1127c73:	mov    0x78(%rsi),%rax
 1127c77:	cmp    $0x0,%rax
 1127c7b:	je     1127cd0 <myl_f_6b8d2a166bbd9c248350f439dfeb2952399d529c32ecd164fee3dd015aa55840+0x2a0>
 1127c7d:	mov    -0x10(%rax),%r8
 1127c81:	movabs $0x6000000000000002,%r9
 1127c8b:	and    %r9,%r8
 1127c8e:	cmp    $0x0,%r8
 1127c92:	jne    1127c9e <myl_f_6b8d2a166bbd9c248350f439dfeb2952399d529c32ecd164fee3dd015aa55840+0x26e>
 1127c94:	mov    -0x20(%rax),%rax
 1127c98:	cmp    $0x2,%rax
 1127c9c:	jb     1127cd0 <myl_f_6b8d2a166bbd9c248350f439dfeb2952399d529c32ecd164fee3dd015aa55840+0x2a0>
 1127c9e:	mov    %rcx,%r13
 1127ca1:	mov    $0x0,%ecx
 1127ca6:	mov    %rsi,%r12
 1127ca9:	lea    0x102548(%rip),%rsi        # 122a1f8 <myl_t_a1fa53db408c85388cfd14badb361c2a89e74ce2a863fa83774cb6942b74317a>
 1127cb0:	mov    %rdi,%rbx
 1127cb3:	call   115a070 <myl_qbe_rc_unique_field>
 1127cb8:	mov    %r13,%rcx
 1127cbb:	mov    %r12,%rsi
 1127cbe:	mov    %rbx,%rdi
 1127cc1:	cmp    $0x0,%eax
 1127cc4:	jne    1127cd0 <myl_f_6b8d2a166bbd9c248350f439dfeb2952399d529c32ecd164fee3dd015aa55840+0x2a0>
 1127cc6:	mov    $0x0,%eax
 1127ccb:	jmp    1127e8f <myl_f_6b8d2a166bbd9c248350f439dfeb2952399d529c32ecd164fee3dd015aa55840+0x45f>
 1127cd0:	mov    0x78(%rsi),%rax
 1127cd4:	cmp    $0x0,%rcx
 1127cd8:	jge    1127d0a <myl_f_6b8d2a166bbd9c248350f439dfeb2952399d529c32ecd164fee3dd015aa55840+0x2da>
 1127cda:	mov    (%rax),%rsi
 1127cdd:	movabs $0x7fffffffffffffff,%rdx
 1127ce7:	cmp    %rdx,%rsi
 1127cea:	ja     1127d57 <myl_f_6b8d2a166bbd9c248350f439dfeb2952399d529c32ecd164fee3dd015aa55840+0x327>
 1127cec:	mov    %rsi,%rbx
 1127cef:	add    %rcx,%rbx
 1127cf2:	mov    %rsi,%rdx
 1127cf5:	xor    %rbx,%rdx
 1127cf8:	mov    %rcx,%r8
 1127cfb:	xor    %rbx,%r8
 1127cfe:	and    %r8,%rdx
 1127d01:	cmp    $0x0,%rdx
 1127d05:	jl     1127d42 <myl_f_6b8d2a166bbd9c248350f439dfeb2952399d529c32ecd164fee3dd015aa55840+0x312>
 1127d07:	mov    %rbx,%rcx
 1127d0a:	mov    (%rax),%rdx
 1127d0d:	cmp    %rdx,%rcx
 1127d10:	jb     1127d1c <myl_f_6b8d2a166bbd9c248350f439dfeb2952399d529c32ecd164fee3dd015aa55840+0x2ec>
 1127d12:	mov    %rcx,%rsi
 1127d15:	call   115a7e0 <myl_qbe_fail_normalized_index_bounds>
 1127d1a:	ud2
 1127d1c:	mov    %rcx,%rbx
 1127d1f:	mov    0x20(%rax),%rcx
 1127d23:	imul   $0x10,%rbx,%rdx
 1127d27:	mov    -0x28(%rbp),%rax
 1127d2b:	mov    %rax,(%rcx,%rdx,1)
 1127d2f:	mov    -0x20(%rbp),%rax
 1127d33:	mov    %rax,0x8(%rcx,%rdx,1)
 1127d38:	mov    $0x1,%eax
 1127d3d:	jmp    1127e8f <myl_f_6b8d2a166bbd9c248350f439dfeb2952399d529c32ecd164fee3dd015aa55840+0x45f>
 1127d42:	mov    $0x40,%r8d
 1127d48:	mov    %rsi,%rdx
 1127d4b:	mov    $0x0,%esi
 1127d50:	call   115a9f0 <myl_qbe_fail_overflow_op>
 1127d55:	ud2
 1127d57:	mov    $0x140,%edx
 1127d5c:	call   115ab30 <myl_qbe_fail_cast>
 1127d61:	ud2
 1127d63:	mov    0x10a856(%rip),%rcx        # 12325c0 <myl_lit_2d6548b0d20925eb41b8b902da17a2651a780e0ecf585d7c93694f27a1a25cd5>
 1127d6a:	mov    %rcx,-0x100(%rbp)
 1127d71:	mov    -0x100(%rbp),%rax
 1127d78:	mov    %rax,-0xf8(%rbp)
 1127d7f:	mov    -0xf8(%rbp),%rax
 1127d86:	mov    %rax,-0x108(%rbp)
 1127d8d:	call   1128220 <myl_f_8855e2338a0239644fa6d8638afc594de302f594debc25ce542a382b2a6572a1>
 1127d92:	mov    %rbx,%rdi
 1127d95:	mov    -0x108(%rbp),%rdx
 1127d9c:	cmp    $0x0,%rdx
 1127da0:	je     1127e8f <myl_f_6b8d2a166bbd9c248350f439dfeb2952399d529c32ecd164fee3dd015aa55840+0x45f>
 1127da6:	mov    -0x10(%rdx),%rcx
 1127daa:	movabs $0x4000000000000002,%rsi
 1127db4:	and    %rsi,%rcx
 1127db7:	cmp    $0x0,%rcx
 1127dbb:	jne    1127def <myl_f_6b8d2a166bbd9c248350f439dfeb2952399d529c32ecd164fee3dd015aa55840+0x3bf>
 1127dbd:	mov    -0x20(%rdx),%rcx
 1127dc1:	sub    $0x1,%rcx
 1127dc5:	jne    1127deb <myl_f_6b8d2a166bbd9c248350f439dfeb2952399d529c32ecd164fee3dd015aa55840+0x3bb>
 1127dc7:	mov    %rax,%rbx
 1127dca:	mov    -0x18(%rdx),%rax
 1127dce:	cmp    $0x0,%rax
 1127dd2:	jne    1127de8 <myl_f_6b8d2a166bbd9c248350f439dfeb2952399d529c32ecd164fee3dd015aa55840+0x3b8>
 1127dd4:	lea    -0x108(%rbp),%rsi
 1127ddb:	call   113f380 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop>
 1127de0:	mov    %rbx,%rax
 1127de3:	jmp    1127e8f <myl_f_6b8d2a166bbd9c248350f439dfeb2952399d529c32ecd164fee3dd015aa55840+0x45f>
 1127de8:	mov    %rbx,%rax
 1127deb:	mov    %rcx,-0x20(%rdx)
 1127def:	movq   $0x0,-0x108(%rbp)
 1127dfa:	jmp    1127e8f <myl_f_6b8d2a166bbd9c248350f439dfeb2952399d529c32ecd164fee3dd015aa55840+0x45f>
 1127dff:	mov    0x10a7ba(%rip),%rcx        # 12325c0 <myl_lit_2d6548b0d20925eb41b8b902da17a2651a780e0ecf585d7c93694f27a1a25cd5>
 1127e06:	mov    %rcx,-0x100(%rbp)
 1127e0d:	mov    -0x100(%rbp),%rax
 1127e14:	mov    %rax,-0xf8(%rbp)
 1127e1b:	mov    -0xf8(%rbp),%rax
 1127e22:	mov    %rax,-0x108(%rbp)
 1127e29:	call   1128220 <myl_f_8855e2338a0239644fa6d8638afc594de302f594debc25ce542a382b2a6572a1>
 1127e2e:	mov    %rbx,%rdi
 1127e31:	mov    -0x108(%rbp),%rdx
 1127e38:	cmp    $0x0,%rdx
 1127e3c:	je     1127e8f <myl_f_6b8d2a166bbd9c248350f439dfeb2952399d529c32ecd164fee3dd015aa55840+0x45f>
 1127e3e:	mov    -0x10(%rdx),%rcx
 1127e42:	movabs $0x4000000000000002,%rsi
 1127e4c:	and    %rsi,%rcx
 1127e4f:	cmp    $0x0,%rcx
 1127e53:	jne    1127e84 <myl_f_6b8d2a166bbd9c248350f439dfeb2952399d529c32ecd164fee3dd015aa55840+0x454>
 1127e55:	mov    -0x20(%rdx),%rcx
 1127e59:	sub    $0x1,%rcx
 1127e5d:	jne    1127e80 <myl_f_6b8d2a166bbd9c248350f439dfeb2952399d529c32ecd164fee3dd015aa55840+0x450>
 1127e5f:	mov    %rax,%rbx
 1127e62:	mov    -0x18(%rdx),%rax
 1127e66:	cmp    $0x0,%rax
 1127e6a:	jne    1127e7d <myl_f_6b8d2a166bbd9c248350f439dfeb2952399d529c32ecd164fee3dd015aa55840+0x44d>
 1127e6c:	lea    -0x108(%rbp),%rsi
 1127e73:	call   113f380 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop>
 1127e78:	mov    %rbx,%rax
 1127e7b:	jmp    1127e8f <myl_f_6b8d2a166bbd9c248350f439dfeb2952399d529c32ecd164fee3dd015aa55840+0x45f>
 1127e7d:	mov    %rbx,%rax
 1127e80:	mov    %rcx,-0x20(%rdx)
 1127e84:	movq   $0x0,-0x108(%rbp)
 1127e8f:	pop    %r14
 1127e91:	pop    %r13
 1127e93:	pop    %r12
 1127e95:	pop    %rbx
 1127e96:	leave
 1127e97:	ret
 1127e98:	mov    %r10,%rdx
 1127e9b:	mov    $0x40,%r8d
 1127ea1:	mov    $0x1,%ecx
 1127ea6:	mov    $0x1,%esi
 1127eab:	call   115a9f0 <myl_qbe_fail_overflow_op>
 1127eb0:	ud2
 1127eb2:	call   115abb0 <myl_qbe_fail_frame>
 1127eb7:	ud2

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
