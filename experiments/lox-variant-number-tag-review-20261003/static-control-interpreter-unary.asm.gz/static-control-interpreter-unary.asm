
/home/epentland/ai/canopy/mylang-worktrees/codex-lox-borrow-assert-20261003/.tmp-lox-borrow-assert-20261003/fixed-qbe-ast:     file format elf64-x86-64


Disassembly of section .text:

000000000109fde0 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e>:
 109fde0:	endbr64
 109fde4:	push   %rbp
 109fde5:	mov    %rsp,%rbp
 109fde8:	sub    $0x4b8,%rsp
 109fdef:	push   %rbx
 109fdf0:	push   %r12
 109fdf2:	push   %r13
 109fdf4:	push   %r14
 109fdf6:	push   %r15
 109fdf8:	mov    0x10(%rbp),%r13
 109fdfc:	mov    %r9,-0x8(%rbp)
 109fe00:	mov    %r8,-0x10(%rbp)
 109fe04:	mov    %rcx,%r15
 109fe07:	mov    %rdx,-0x18(%rbp)
 109fe0b:	mov    %rsi,%r12
 109fe0e:	mov    %rdi,%rax
 109fe11:	mov    %r15,-0x28(%rbp)
 109fe15:	mov    %rax,%rbx
 109fe18:	mov    0x40(%r12),%rax
 109fe1d:	mov    $0x0,%r14d
 109fe23:	mov    %r14d,-0x2c(%rbp)
 109fe27:	mov    $0x0,%r14d
 109fe2d:	mov    %r14d,-0x20(%rbp)
 109fe31:	lea    -0x38(%rbp),%rcx
 109fe35:	cmp    %rax,%rcx
 109fe38:	jb     10a0c2e <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0xe4e>
 109fe3e:	mov    %r12,%rdi
 109fe41:	call   115aba0 <myl_qbe_heap>
 109fe46:	mov    %rax,%rdi
 109fe49:	mov    %rdi,%r14
 109fe4c:	mov    %r12,%rdi
 109fe4f:	call   115d700 <myl_qbe_region_mark>
 109fe54:	mov    %r15,%rsi
 109fe57:	mov    %r14,%rdi
 109fe5a:	mov    %rax,%rcx
 109fe5d:	mov    %rbx,%rax
 109fe60:	mov    -0x8(%rbp),%r9
 109fe64:	mov    -0x10(%rbp),%r8
 109fe68:	mov    -0x18(%rbp),%rdx
 109fe6c:	mov    %rax,%rbx
 109fe6f:	mov    0x28(%r13),%rax
 109fe73:	sub    $0x10,%rsp
 109fe77:	mov    %rsp,%r10
 109fe7a:	mov    %rax,(%r10)
 109fe7d:	mov    %rcx,%r15
 109fe80:	mov    %rsi,%rcx
 109fe83:	mov    %r12,%rsi
 109fe86:	mov    %rdi,%r14
 109fe89:	lea    -0x4a8(%rbp),%rdi
 109fe90:	call   10b6af0 <myl_f_d32d9d609bd2d498a6b2d4f34d6d36851c296533eaafa0e3b7c4c9b1eec65fca>
 109fe95:	mov    %r15,%rcx
 109fe98:	mov    %r14,%rdi
 109fe9b:	mov    %rax,%rdx
 109fe9e:	mov    %rbx,%rax
 109fea1:	mov    -0x20(%rbp),%r14d
 109fea5:	sub    $0xfffffffffffffff0,%rsp
 109fea9:	mov    (%rdx),%rsi
 109feac:	mov    %rsi,-0x360(%rbp)
 109feb3:	mov    0x8(%rdx),%rsi
 109feb7:	mov    %rsi,-0x358(%rbp)
 109febe:	mov    0x10(%rdx),%rdx
 109fec2:	mov    %rdx,-0x350(%rbp)
 109fec9:	mov    -0x360(%rbp),%rdx
 109fed0:	mov    %rdx,-0x438(%rbp)
 109fed7:	mov    -0x358(%rbp),%rdx
 109fede:	mov    %rdx,-0x430(%rbp)
 109fee5:	mov    %rcx,%r15
 109fee8:	mov    -0x350(%rbp),%rcx
 109feef:	mov    %rcx,-0x428(%rbp)
 109fef6:	mov    %rax,%rbx
 109fef9:	mov    -0x438(%rbp),%eax
 109feff:	cmp    $0x0,%rax
 109ff03:	je     10a009d <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0x2bd>
 109ff09:	mov    %r14d,%r13d
 109ff0c:	movabs $0x300000007,%rsi
 109ff16:	mov    %rdi,%r14
 109ff19:	lea    0x1177a8(%rip),%rdi        # 11b76c8 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e_meta>
 109ff20:	call   115c038 <myl_qbe_error_trace_append>
 109ff25:	mov    %r15,%rcx
 109ff28:	mov    %r14,%rdi
 109ff2b:	mov    %rbx,%rax
 109ff2e:	lea    -0x438(%rbp),%rdx
 109ff35:	add    $0x8,%rdx
 109ff39:	movq   $0x0,-0x270(%rbp)
 109ff44:	mov    %rax,%rbx
 109ff47:	lea    -0x270(%rbp),%rax
 109ff4e:	mov    %rax,%rsi
 109ff51:	add    $0x8,%rsi
 109ff55:	movq   $0x0,-0x268(%rbp)
 109ff60:	movq   $0x0,-0x260(%rbp)
 109ff6b:	movl   $0x1,-0x270(%rbp)
 109ff75:	mov    %rcx,%r15
 109ff78:	mov    %rdi,%r14
 109ff7b:	call   114d340 <myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_retain>
 109ff80:	mov    %r15,%rcx
 109ff83:	mov    %r14,%rdi
 109ff86:	cmp    $0x0,%eax
 109ff89:	jne    109ffa8 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0x1c8>
 109ff8b:	call   1169600 <myl_rc_take_failure>
 109ff90:	mov    %r12,%rdi
 109ff93:	mov    %eax,%esi
 109ff95:	mov    %rdi,%r12
 109ff98:	call   1159ab0 <myl_qbe_rc_status>
 109ff9d:	mov    %rbx,%rax
 109ffa0:	mov    %rax,%rbx
 109ffa3:	jmp    10a0bc5 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0xde5>
 109ffa8:	mov    %rbx,%rax
 109ffab:	mov    -0x270(%rbp),%rdx
 109ffb2:	mov    %rdx,-0x360(%rbp)
 109ffb9:	mov    %rcx,%r15
 109ffbc:	mov    -0x268(%rbp),%rcx
 109ffc3:	mov    %rcx,-0x358(%rbp)
 109ffca:	mov    %rax,%rbx
 109ffcd:	mov    -0x260(%rbp),%rax
 109ffd4:	mov    %rax,-0x350(%rbp)
 109ffdb:	lea    -0x438(%rbp),%rsi
 109ffe2:	mov    %rdi,%r14
 109ffe5:	call   1147800 <myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_drop>
 109ffea:	mov    %r15,%rcx
 109ffed:	mov    %r14,%rdi
 109fff0:	mov    %rbx,%rax
 109fff3:	mov    -0x360(%rbp),%rdx
 109fffa:	mov    %rdx,-0x438(%rbp)
 10a0001:	mov    -0x358(%rbp),%rdx
 10a0008:	mov    %rdx,-0x430(%rbp)
 10a000f:	mov    %rax,%rbx
 10a0012:	mov    -0x350(%rbp),%rax
 10a0019:	mov    %rax,-0x428(%rbp)
 10a0020:	mov    %rcx,%r15
 10a0023:	lea    -0x438(%rbp),%rdx
 10a002a:	lea    -0x360(%rbp),%rsi
 10a0031:	mov    %rdi,%r14
 10a0034:	call   1147890 <myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_take>
 10a0039:	mov    %r14,%rdi
 10a003c:	cmp    $0x0,%eax
 10a003f:	jne    10a0058 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0x278>
 10a0041:	call   1169600 <myl_rc_take_failure>
 10a0046:	mov    %r12,%rdi
 10a0049:	mov    %eax,%esi
 10a004b:	mov    %rdi,%r12
 10a004e:	call   1159ab0 <myl_qbe_rc_status>
 10a0053:	jmp    10a0bc5 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0xde5>
 10a0058:	mov    %r13d,%r12d
 10a005b:	cmp    $0x0,%r12d
 10a005f:	jne    10a0066 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0x286>
 10a0061:	mov    %rbx,%rax
 10a0064:	jmp    10a0075 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0x295>
 10a0066:	lea    -0x438(%rbp),%rsi
 10a006d:	call   1147800 <myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_drop>
 10a0072:	mov    %rbx,%rax
 10a0075:	mov    -0x360(%rbp),%rcx
 10a007c:	mov    %rcx,(%rax)
 10a007f:	mov    -0x358(%rbp),%rcx
 10a0086:	mov    %rcx,0x8(%rax)
 10a008a:	mov    -0x350(%rbp),%rcx
 10a0091:	mov    %rcx,0x10(%rax)
 10a0095:	mov    %rax,%rbx
 10a0098:	jmp    10a0c23 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0xe43>
 10a009d:	lea    -0x438(%rbp),%rsi
 10a00a4:	mov    %rdi,%r14
 10a00a7:	call   1147800 <myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_drop>
 10a00ac:	mov    %r14,%rdi
 10a00af:	mov    -0x28(%rbp),%rsi
 10a00b3:	mov    $0x0,%edx
 10a00b8:	mov    %rdi,%r14
 10a00bb:	mov    %r12,%rdi
 10a00be:	call   1097020 <myl_f_851eb64c403b25f3166dffdb17dfc9e3c924451c20caa5851a74e0f4081ba50f>
 10a00c3:	mov    %r14,%rdi
 10a00c6:	mov    %rax,%rcx
 10a00c9:	mov    %rdx,%rax
 10a00cc:	mov    -0x2c(%rbp),%r14d
 10a00d0:	mov    -0x28(%rbp),%rsi
 10a00d4:	mov    %rcx,-0x490(%rbp)
 10a00db:	mov    %rax,-0x488(%rbp)
 10a00e2:	cmp    $0x0,%r14d
 10a00e6:	jne    10a00f0 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0x310>
 10a00e8:	mov    %rbx,%rax
 10a00eb:	mov    %r15,%rcx
 10a00ee:	jmp    10a0112 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0x332>
 10a00f0:	lea    -0x438(%rbp),%rsi
 10a00f7:	mov    %rdi,%r14
 10a00fa:	call   1141730 <myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop>
 10a00ff:	mov    %r15,%rcx
 10a0102:	mov    %r14,%rdi
 10a0105:	mov    %rbx,%rax
 10a0108:	mov    -0x28(%rbp),%rsi
 10a010c:	mov    $0x0,%r14d
 10a0112:	mov    %rcx,%r15
 10a0115:	mov    -0x490(%rbp),%rcx
 10a011c:	mov    %rcx,-0x290(%rbp)
 10a0123:	mov    %rax,%rbx
 10a0126:	mov    -0x488(%rbp),%rax
 10a012d:	mov    %rax,-0x288(%rbp)
 10a0134:	cmp    $0x0,%r14d
 10a0138:	je     10a0156 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0x376>
 10a013a:	lea    -0x438(%rbp),%rsi
 10a0141:	mov    %rdi,%r14
 10a0144:	call   114e420 <myl_t_f298b6d8457736465302b199391c1c9d6e57cdd1f586a7753cd47f47922b1d32_rcg_drop>
 10a0149:	mov    %r14,%rdi
 10a014c:	mov    -0x28(%rbp),%rsi
 10a0150:	mov    $0x0,%r14d
 10a0156:	cmp    $0x0,%r14d
 10a015a:	jne    10a0164 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0x384>
 10a015c:	mov    %rbx,%rax
 10a015f:	mov    %r15,%rcx
 10a0162:	jmp    10a0186 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0x3a6>
 10a0164:	lea    -0x438(%rbp),%rsi
 10a016b:	mov    %rdi,%r14
 10a016e:	call   113fb10 <myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop>
 10a0173:	mov    %r15,%rcx
 10a0176:	mov    %r14,%rdi
 10a0179:	mov    %rbx,%rax
 10a017c:	mov    -0x28(%rbp),%rsi
 10a0180:	mov    $0x0,%r14d
 10a0186:	mov    %r14d,%ebx
 10a0189:	mov    %ebx,-0x30(%rbp)
 10a018c:	movl   $0x0,-0x258(%rbp)
 10a0196:	movl   $0xb,-0x258(%rbp)
 10a01a0:	mov    0x0(%r13),%edx
 10a01a4:	cmp    $0xb,%rdx
 10a01a8:	je     10a0a60 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0xc80>
 10a01ae:	mov    -0x290(%rbp),%edx
 10a01b4:	cmp    $0x0,%rdx
 10a01b8:	sete   %r8b
 10a01bc:	movzbq %r8b,%r8
 10a01c0:	cmp    $0x0,%r8d
 10a01c4:	jne    10a0800 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0xa20>
 10a01ca:	cmp    $0x1,%rdx
 10a01ce:	je     10a05a0 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0x7c0>
 10a01d4:	cmp    $0x2,%rdx
 10a01d8:	je     10a0452 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0x672>
 10a01de:	cmp    $0x3,%rdx
 10a01e2:	je     10a01ec <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0x40c>
 10a01e4:	mov    %rax,%rbx
 10a01e7:	jmp    10a0bc5 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0xde5>
 10a01ec:	mov    0x1923cd(%rip),%rsi        # 12325c0 <myl_lit_2d6548b0d20925eb41b8b902da17a2651a780e0ecf585d7c93694f27a1a25cd5>
 10a01f3:	mov    %rsi,-0x368(%rbp)
 10a01fa:	mov    %rcx,%r14
 10a01fd:	mov    -0x368(%rbp),%rcx
 10a0204:	mov    %rcx,-0x360(%rbp)
 10a020b:	mov    %rax,%rbx
 10a020e:	mov    -0x360(%rbp),%rax
 10a0215:	mov    %rax,-0x438(%rbp)
 10a021c:	mov    0x18(%r13),%rdx
 10a0220:	mov    %rdi,%r13
 10a0223:	mov    %r12,%rdi
 10a0226:	call   10af7e0 <myl_f_8c062ec4784d4b0491e6d5d24da0bf886cc822f390794d94cd35c159749aceeb_rc_borrow>
 10a022b:	mov    %r13,%rdi
 10a022e:	mov    %rax,%rcx
 10a0231:	mov    %rdx,%rax
 10a0234:	mov    %rcx,-0x460(%rbp)
 10a023b:	mov    %rax,-0x458(%rbp)
 10a0242:	lea    -0x460(%rbp),%rdx
 10a0249:	lea    -0x360(%rbp),%rsi
 10a0250:	mov    %rdi,%r13
 10a0253:	call   114d210 <myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_loan>
 10a0258:	mov    %r14,%rcx
 10a025b:	mov    %r13,%rdi
 10a025e:	cmp    $0x0,%eax
 10a0261:	jne    10a0280 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0x4a0>
 10a0263:	call   1169600 <myl_rc_take_failure>
 10a0268:	mov    %r12,%rdi
 10a026b:	mov    %eax,%esi
 10a026d:	mov    %rdi,%r12
 10a0270:	call   1159ab0 <myl_qbe_rc_status>
 10a0275:	mov    %rbx,%rax
 10a0278:	mov    %rax,%rbx
 10a027b:	jmp    10a0bc5 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0xde5>
 10a0280:	mov    %rbx,%rax
 10a0283:	mov    -0x438(%rbp),%rsi
 10a028a:	cmp    $0x0,%rsi
 10a028e:	je     10a02f3 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0x513>
 10a0290:	mov    -0x10(%rsi),%rdx
 10a0294:	movabs $0x4000000000000002,%r8
 10a029e:	and    %r8,%rdx
 10a02a1:	cmp    $0x0,%rdx
 10a02a5:	jne    10a02e8 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0x508>
 10a02a7:	mov    %rcx,%r14
 10a02aa:	mov    -0x20(%rsi),%rcx
 10a02ae:	mov    %rcx,%rdx
 10a02b1:	sub    $0x1,%rdx
 10a02b5:	jne    10a02e1 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0x501>
 10a02b7:	mov    %rax,%rbx
 10a02ba:	mov    -0x18(%rsi),%rax
 10a02be:	cmp    $0x0,%rax
 10a02c2:	jne    10a02de <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0x4fe>
 10a02c4:	lea    -0x438(%rbp),%rsi
 10a02cb:	mov    %rdi,%r13
 10a02ce:	call   113f380 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop>
 10a02d3:	mov    %r14,%rcx
 10a02d6:	mov    %r13,%rdi
 10a02d9:	mov    %rbx,%rax
 10a02dc:	jmp    10a02f3 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0x513>
 10a02de:	mov    %rbx,%rax
 10a02e1:	mov    %r14,%rcx
 10a02e4:	mov    %rdx,-0x20(%rsi)
 10a02e8:	movq   $0x0,-0x438(%rbp)
 10a02f3:	mov    -0x360(%rbp),%rdx
 10a02fa:	mov    %rdx,-0x438(%rbp)
 10a0301:	mov    -0x358(%rbp),%rdx
 10a0308:	mov    %rdx,-0x430(%rbp)
 10a030f:	movq   $0x0,-0x50(%rbp)
 10a0317:	mov    %rax,%rbx
 10a031a:	lea    -0x50(%rbp),%rax
 10a031e:	mov    %rax,%r13
 10a0321:	add    $0x8,%r13
 10a0325:	movq   $0x0,-0x48(%rbp)
 10a032d:	movq   $0x0,-0x40(%rbp)
 10a0335:	movl   $0x1,-0x50(%rbp)
 10a033c:	mov    %rcx,%r15
 10a033f:	lea    -0x438(%rbp),%rdx
 10a0346:	lea    -0x360(%rbp),%rsi
 10a034d:	mov    %rdi,%r14
 10a0350:	call   114d340 <myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_retain>
 10a0355:	mov    %r14,%rdi
 10a0358:	cmp    $0x0,%eax
 10a035b:	jne    10a0374 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0x594>
 10a035d:	call   1169600 <myl_rc_take_failure>
 10a0362:	mov    %r12,%rdi
 10a0365:	mov    %eax,%esi
 10a0367:	mov    %rdi,%r12
 10a036a:	call   1159ab0 <myl_qbe_rc_status>
 10a036f:	jmp    10a0bc5 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0xde5>
 10a0374:	lea    -0x438(%rbp),%rsi
 10a037b:	mov    %rdi,%r14
 10a037e:	call   114d260 <myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_unloan>
 10a0383:	mov    %r15,%rcx
 10a0386:	mov    %r14,%rdi
 10a0389:	mov    %rbx,%rax
 10a038c:	mov    %rcx,%r14
 10a038f:	mov    -0x360(%rbp),%rcx
 10a0396:	mov    %rcx,0x0(%r13)
 10a039a:	mov    %rax,%rbx
 10a039d:	mov    -0x358(%rbp),%rax
 10a03a4:	mov    %rax,0x8(%r13)
 10a03a8:	mov    $0x49,%esi
 10a03ad:	mov    %rdi,%r13
 10a03b0:	lea    0x117311(%rip),%rdi        # 11b76c8 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e_meta>
 10a03b7:	call   115c021 <myl_qbe_error_trace_origin>
 10a03bc:	mov    %r14,%rcx
 10a03bf:	mov    %r13,%rdi
 10a03c2:	mov    %rbx,%rax
 10a03c5:	mov    -0x50(%rbp),%rdx
 10a03c9:	mov    %rdx,-0x438(%rbp)
 10a03d0:	mov    -0x48(%rbp),%rdx
 10a03d4:	mov    %rdx,-0x430(%rbp)
 10a03db:	mov    %rax,%rbx
 10a03de:	mov    -0x40(%rbp),%rax
 10a03e2:	mov    %rax,-0x428(%rbp)
 10a03e9:	mov    %rcx,%r14
 10a03ec:	lea    -0x438(%rbp),%rdx
 10a03f3:	lea    -0x360(%rbp),%rsi
 10a03fa:	mov    %rdi,%r13
 10a03fd:	call   1147890 <myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_take>
 10a0402:	mov    %r13,%rdi
 10a0405:	cmp    $0x0,%eax
 10a0408:	jne    10a0427 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0x647>
 10a040a:	call   1169600 <myl_rc_take_failure>
 10a040f:	mov    %r12,%rdi
 10a0412:	mov    %eax,%esi
 10a0414:	mov    %rdi,%r12
 10a0417:	call   1159ab0 <myl_qbe_rc_status>
 10a041c:	mov    %rbx,%rax
 10a041f:	mov    %rax,%rbx
 10a0422:	jmp    10a0bc5 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0xde5>
 10a0427:	mov    %rbx,%rax
 10a042a:	mov    -0x360(%rbp),%rcx
 10a0431:	mov    %rcx,(%rax)
 10a0434:	mov    -0x358(%rbp),%rcx
 10a043b:	mov    %rcx,0x8(%rax)
 10a043f:	mov    -0x350(%rbp),%rcx
 10a0446:	mov    %rcx,0x10(%rax)
 10a044a:	mov    %rax,%rbx
 10a044d:	jmp    10a0c23 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0xe43>
 10a0452:	mov    %rax,%rbx
 10a0455:	mov    %rcx,%r14
 10a0458:	mov    -0x288(%rbp),%rdx
 10a045f:	mov    %rdx,-0x360(%rbp)
 10a0466:	mov    %rsi,%r15
 10a0469:	mov    $0x7,%esi
 10a046e:	mov    %rdi,%r13
 10a0471:	mov    %r12,%rdi
 10a0474:	call   115abc0 <myl_qbe_float_unary>
 10a0479:	mov    %r15,%rsi
 10a047c:	mov    %r13,%rdi
 10a047f:	mov    -0x30(%rbp),%r13d
 10a0483:	movq   $0x0,-0x168(%rbp)
 10a048e:	movq   $0x0,-0x160(%rbp)
 10a0499:	movl   $0x2,-0x168(%rbp)
 10a04a3:	mov    %rax,-0x160(%rbp)
 10a04aa:	lea    -0x168(%rbp),%rdx
 10a04b1:	mov    %rdi,%r15
 10a04b4:	mov    %r12,%rdi
 10a04b7:	call   109cfd0 <myl_f_1e67eb8ef4c3a3acc3a97242d455a6d9c8a2bcb48d8912e38331c2e291a74a0e>
 10a04bc:	mov    %r15,%rdi
 10a04bf:	cmp    $0x0,%r13d
 10a04c3:	jne    10a04cd <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0x6ed>
 10a04c5:	mov    %rbx,%rax
 10a04c8:	mov    %r14,%rcx
 10a04cb:	jmp    10a04e5 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0x705>
 10a04cd:	lea    -0x438(%rbp),%rsi
 10a04d4:	mov    %rdi,%r13
 10a04d7:	call   1141730 <myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop>
 10a04dc:	mov    %r14,%rcx
 10a04df:	mov    %r13,%rdi
 10a04e2:	mov    %rbx,%rax
 10a04e5:	movq   $0x0,-0x98(%rbp)
 10a04f0:	movq   $0x0,-0x90(%rbp)
 10a04fb:	movq   $0x0,-0x88(%rbp)
 10a0506:	movl   $0x0,-0x98(%rbp)
 10a0510:	mov    -0x98(%rbp),%rdx
 10a0517:	mov    %rdx,-0x438(%rbp)
 10a051e:	mov    -0x90(%rbp),%rdx
 10a0525:	mov    %rdx,-0x430(%rbp)
 10a052c:	mov    %rax,%rbx
 10a052f:	mov    -0x88(%rbp),%rax
 10a0536:	mov    %rax,-0x428(%rbp)
 10a053d:	lea    -0x438(%rbp),%rdx
 10a0544:	lea    -0x360(%rbp),%rsi
 10a054b:	mov    %rdi,%r13
 10a054e:	call   1147890 <myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_take>
 10a0553:	mov    %r13,%rdi
 10a0556:	cmp    $0x0,%eax
 10a0559:	jne    10a0578 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0x798>
 10a055b:	call   1169600 <myl_rc_take_failure>
 10a0560:	mov    %r12,%rdi
 10a0563:	mov    %eax,%esi
 10a0565:	mov    %rdi,%r12
 10a0568:	call   1159ab0 <myl_qbe_rc_status>
 10a056d:	mov    %rbx,%rax
 10a0570:	mov    %rax,%rbx
 10a0573:	jmp    10a0bc5 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0xde5>
 10a0578:	mov    %rbx,%rax
 10a057b:	mov    -0x360(%rbp),%rcx
 10a0582:	mov    %rcx,(%rax)
 10a0585:	mov    -0x358(%rbp),%rcx
 10a058c:	mov    %rcx,0x8(%rax)
 10a0590:	mov    -0x350(%rbp),%rcx
 10a0597:	mov    %rcx,0x10(%rax)
 10a059b:	jmp    10a0c23 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0xe43>
 10a05a0:	mov    0x192019(%rip),%rsi        # 12325c0 <myl_lit_2d6548b0d20925eb41b8b902da17a2651a780e0ecf585d7c93694f27a1a25cd5>
 10a05a7:	mov    %rsi,-0x368(%rbp)
 10a05ae:	mov    %rcx,%r14
 10a05b1:	mov    -0x368(%rbp),%rcx
 10a05b8:	mov    %rcx,-0x360(%rbp)
 10a05bf:	mov    %rax,%rbx
 10a05c2:	mov    -0x360(%rbp),%rax
 10a05c9:	mov    %rax,-0x438(%rbp)
 10a05d0:	mov    0x18(%r13),%rdx
 10a05d4:	mov    %rdi,%r13
 10a05d7:	mov    %r12,%rdi
 10a05da:	call   10af7e0 <myl_f_8c062ec4784d4b0491e6d5d24da0bf886cc822f390794d94cd35c159749aceeb_rc_borrow>
 10a05df:	mov    %r13,%rdi
 10a05e2:	mov    %rax,%rcx
 10a05e5:	mov    %rdx,%rax
 10a05e8:	mov    %rcx,-0x470(%rbp)
 10a05ef:	mov    %rax,-0x468(%rbp)
 10a05f6:	lea    -0x470(%rbp),%rdx
 10a05fd:	lea    -0x360(%rbp),%rsi
 10a0604:	mov    %rdi,%r13
 10a0607:	call   114d210 <myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_loan>
 10a060c:	mov    %r14,%rcx
 10a060f:	mov    %r13,%rdi
 10a0612:	cmp    $0x0,%eax
 10a0615:	jne    10a0634 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0x854>
 10a0617:	call   1169600 <myl_rc_take_failure>
 10a061c:	mov    %r12,%rdi
 10a061f:	mov    %eax,%esi
 10a0621:	mov    %rdi,%r12
 10a0624:	call   1159ab0 <myl_qbe_rc_status>
 10a0629:	mov    %rbx,%rax
 10a062c:	mov    %rax,%rbx
 10a062f:	jmp    10a0bc5 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0xde5>
 10a0634:	mov    %rbx,%rax
 10a0637:	mov    -0x438(%rbp),%rsi
 10a063e:	cmp    $0x0,%rsi
 10a0642:	je     10a06a7 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0x8c7>
 10a0644:	mov    -0x10(%rsi),%rdx
 10a0648:	movabs $0x4000000000000002,%r8
 10a0652:	and    %r8,%rdx
 10a0655:	cmp    $0x0,%rdx
 10a0659:	jne    10a069c <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0x8bc>
 10a065b:	mov    %rcx,%r14
 10a065e:	mov    -0x20(%rsi),%rcx
 10a0662:	mov    %rcx,%rdx
 10a0665:	sub    $0x1,%rdx
 10a0669:	jne    10a0695 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0x8b5>
 10a066b:	mov    %rax,%rbx
 10a066e:	mov    -0x18(%rsi),%rax
 10a0672:	cmp    $0x0,%rax
 10a0676:	jne    10a0692 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0x8b2>
 10a0678:	lea    -0x438(%rbp),%rsi
 10a067f:	mov    %rdi,%r13
 10a0682:	call   113f380 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop>
 10a0687:	mov    %r14,%rcx
 10a068a:	mov    %r13,%rdi
 10a068d:	mov    %rbx,%rax
 10a0690:	jmp    10a06a7 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0x8c7>
 10a0692:	mov    %rbx,%rax
 10a0695:	mov    %r14,%rcx
 10a0698:	mov    %rdx,-0x20(%rsi)
 10a069c:	movq   $0x0,-0x438(%rbp)
 10a06a7:	mov    -0x360(%rbp),%rdx
 10a06ae:	mov    %rdx,-0x438(%rbp)
 10a06b5:	mov    -0x358(%rbp),%rdx
 10a06bc:	mov    %rdx,-0x430(%rbp)
 10a06c3:	movq   $0x0,-0x68(%rbp)
 10a06cb:	mov    %rax,%rbx
 10a06ce:	lea    -0x68(%rbp),%rax
 10a06d2:	mov    %rax,%r13
 10a06d5:	add    $0x8,%r13
 10a06d9:	movq   $0x0,-0x60(%rbp)
 10a06e1:	movq   $0x0,-0x58(%rbp)
 10a06e9:	movl   $0x1,-0x68(%rbp)
 10a06f0:	mov    %rcx,%r15
 10a06f3:	lea    -0x438(%rbp),%rdx
 10a06fa:	lea    -0x360(%rbp),%rsi
 10a0701:	mov    %rdi,%r14
 10a0704:	call   114d340 <myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_retain>
 10a0709:	mov    %r14,%rdi
 10a070c:	cmp    $0x0,%eax
 10a070f:	jne    10a0728 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0x948>
 10a0711:	call   1169600 <myl_rc_take_failure>
 10a0716:	mov    %r12,%rdi
 10a0719:	mov    %eax,%esi
 10a071b:	mov    %rdi,%r12
 10a071e:	call   1159ab0 <myl_qbe_rc_status>
 10a0723:	jmp    10a0bc5 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0xde5>
 10a0728:	lea    -0x438(%rbp),%rsi
 10a072f:	mov    %rdi,%r14
 10a0732:	call   114d260 <myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_unloan>
 10a0737:	mov    %r15,%rcx
 10a073a:	mov    %r14,%rdi
 10a073d:	mov    %rbx,%rax
 10a0740:	mov    %rcx,%r14
 10a0743:	mov    -0x360(%rbp),%rcx
 10a074a:	mov    %rcx,0x0(%r13)
 10a074e:	mov    %rax,%rbx
 10a0751:	mov    -0x358(%rbp),%rax
 10a0758:	mov    %rax,0x8(%r13)
 10a075c:	mov    $0x42,%esi
 10a0761:	mov    %rdi,%r13
 10a0764:	lea    0x116f5d(%rip),%rdi        # 11b76c8 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e_meta>
 10a076b:	call   115c021 <myl_qbe_error_trace_origin>
 10a0770:	mov    %r14,%rcx
 10a0773:	mov    %r13,%rdi
 10a0776:	mov    %rbx,%rax
 10a0779:	mov    -0x68(%rbp),%rdx
 10a077d:	mov    %rdx,-0x438(%rbp)
 10a0784:	mov    -0x60(%rbp),%rdx
 10a0788:	mov    %rdx,-0x430(%rbp)
 10a078f:	mov    %rax,%rbx
 10a0792:	mov    -0x58(%rbp),%rax
 10a0796:	mov    %rax,-0x428(%rbp)
 10a079d:	lea    -0x438(%rbp),%rdx
 10a07a4:	lea    -0x360(%rbp),%rsi
 10a07ab:	mov    %rdi,%r13
 10a07ae:	call   1147890 <myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_take>
 10a07b3:	mov    %r13,%rdi
 10a07b6:	cmp    $0x0,%eax
 10a07b9:	jne    10a07d8 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0x9f8>
 10a07bb:	call   1169600 <myl_rc_take_failure>
 10a07c0:	mov    %r12,%rdi
 10a07c3:	mov    %eax,%esi
 10a07c5:	mov    %rdi,%r12
 10a07c8:	call   1159ab0 <myl_qbe_rc_status>
 10a07cd:	mov    %rbx,%rax
 10a07d0:	mov    %rax,%rbx
 10a07d3:	jmp    10a0bc5 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0xde5>
 10a07d8:	mov    %rbx,%rax
 10a07db:	mov    -0x360(%rbp),%rcx
 10a07e2:	mov    %rcx,(%rax)
 10a07e5:	mov    -0x358(%rbp),%rcx
 10a07ec:	mov    %rcx,0x8(%rax)
 10a07f0:	mov    -0x350(%rbp),%rcx
 10a07f7:	mov    %rcx,0x10(%rax)
 10a07fb:	jmp    10a0c23 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0xe43>
 10a0800:	mov    0x191db9(%rip),%rsi        # 12325c0 <myl_lit_2d6548b0d20925eb41b8b902da17a2651a780e0ecf585d7c93694f27a1a25cd5>
 10a0807:	mov    %rsi,-0x368(%rbp)
 10a080e:	mov    %rcx,%r14
 10a0811:	mov    -0x368(%rbp),%rcx
 10a0818:	mov    %rcx,-0x360(%rbp)
 10a081f:	mov    %rax,%rbx
 10a0822:	mov    -0x360(%rbp),%rax
 10a0829:	mov    %rax,-0x438(%rbp)
 10a0830:	mov    0x18(%r13),%rdx
 10a0834:	mov    %rdi,%r13
 10a0837:	mov    %r12,%rdi
 10a083a:	call   10af7e0 <myl_f_8c062ec4784d4b0491e6d5d24da0bf886cc822f390794d94cd35c159749aceeb_rc_borrow>
 10a083f:	mov    %r13,%rdi
 10a0842:	mov    %rax,%rcx
 10a0845:	mov    %rdx,%rax
 10a0848:	mov    %rcx,-0x480(%rbp)
 10a084f:	mov    %rax,-0x478(%rbp)
 10a0856:	lea    -0x480(%rbp),%rdx
 10a085d:	lea    -0x360(%rbp),%rsi
 10a0864:	mov    %rdi,%r13
 10a0867:	call   114d210 <myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_loan>
 10a086c:	mov    %r14,%rcx
 10a086f:	mov    %r13,%rdi
 10a0872:	cmp    $0x0,%eax
 10a0875:	jne    10a0894 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0xab4>
 10a0877:	call   1169600 <myl_rc_take_failure>
 10a087c:	mov    %r12,%rdi
 10a087f:	mov    %eax,%esi
 10a0881:	mov    %rdi,%r12
 10a0884:	call   1159ab0 <myl_qbe_rc_status>
 10a0889:	mov    %rbx,%rax
 10a088c:	mov    %rax,%rbx
 10a088f:	jmp    10a0bc5 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0xde5>
 10a0894:	mov    %rbx,%rax
 10a0897:	mov    -0x438(%rbp),%rsi
 10a089e:	cmp    $0x0,%rsi
 10a08a2:	je     10a0907 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0xb27>
 10a08a4:	mov    -0x10(%rsi),%rdx
 10a08a8:	movabs $0x4000000000000002,%r8
 10a08b2:	and    %r8,%rdx
 10a08b5:	cmp    $0x0,%rdx
 10a08b9:	jne    10a08fc <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0xb1c>
 10a08bb:	mov    %rcx,%r14
 10a08be:	mov    -0x20(%rsi),%rcx
 10a08c2:	mov    %rcx,%rdx
 10a08c5:	sub    $0x1,%rdx
 10a08c9:	jne    10a08f5 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0xb15>
 10a08cb:	mov    %rax,%rbx
 10a08ce:	mov    -0x18(%rsi),%rax
 10a08d2:	cmp    $0x0,%rax
 10a08d6:	jne    10a08f2 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0xb12>
 10a08d8:	lea    -0x438(%rbp),%rsi
 10a08df:	mov    %rdi,%r13
 10a08e2:	call   113f380 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop>
 10a08e7:	mov    %r14,%rcx
 10a08ea:	mov    %r13,%rdi
 10a08ed:	mov    %rbx,%rax
 10a08f0:	jmp    10a0907 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0xb27>
 10a08f2:	mov    %rbx,%rax
 10a08f5:	mov    %r14,%rcx
 10a08f8:	mov    %rdx,-0x20(%rsi)
 10a08fc:	movq   $0x0,-0x438(%rbp)
 10a0907:	mov    -0x360(%rbp),%rdx
 10a090e:	mov    %rdx,-0x438(%rbp)
 10a0915:	mov    -0x358(%rbp),%rdx
 10a091c:	mov    %rdx,-0x430(%rbp)
 10a0923:	movq   $0x0,-0x80(%rbp)
 10a092b:	mov    %rax,%rbx
 10a092e:	lea    -0x80(%rbp),%rax
 10a0932:	mov    %rax,%r13
 10a0935:	add    $0x8,%r13
 10a0939:	movq   $0x0,-0x78(%rbp)
 10a0941:	movq   $0x0,-0x70(%rbp)
 10a0949:	movl   $0x1,-0x80(%rbp)
 10a0950:	mov    %rcx,%r15
 10a0953:	lea    -0x438(%rbp),%rdx
 10a095a:	lea    -0x360(%rbp),%rsi
 10a0961:	mov    %rdi,%r14
 10a0964:	call   114d340 <myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_retain>
 10a0969:	mov    %r14,%rdi
 10a096c:	cmp    $0x0,%eax
 10a096f:	jne    10a0988 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0xba8>
 10a0971:	call   1169600 <myl_rc_take_failure>
 10a0976:	mov    %r12,%rdi
 10a0979:	mov    %eax,%esi
 10a097b:	mov    %rdi,%r12
 10a097e:	call   1159ab0 <myl_qbe_rc_status>
 10a0983:	jmp    10a0bc5 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0xde5>
 10a0988:	lea    -0x438(%rbp),%rsi
 10a098f:	mov    %rdi,%r14
 10a0992:	call   114d260 <myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_unloan>
 10a0997:	mov    %r15,%rcx
 10a099a:	mov    %r14,%rdi
 10a099d:	mov    %rbx,%rax
 10a09a0:	mov    %rcx,%r14
 10a09a3:	mov    -0x360(%rbp),%rcx
 10a09aa:	mov    %rcx,0x0(%r13)
 10a09ae:	mov    %rax,%rbx
 10a09b1:	mov    -0x358(%rbp),%rax
 10a09b8:	mov    %rax,0x8(%r13)
 10a09bc:	mov    $0x3b,%esi
 10a09c1:	mov    %rdi,%r13
 10a09c4:	lea    0x116cfd(%rip),%rdi        # 11b76c8 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e_meta>
 10a09cb:	call   115c021 <myl_qbe_error_trace_origin>
 10a09d0:	mov    %r14,%rcx
 10a09d3:	mov    %r13,%rdi
 10a09d6:	mov    %rbx,%rax
 10a09d9:	mov    -0x80(%rbp),%rdx
 10a09dd:	mov    %rdx,-0x438(%rbp)
 10a09e4:	mov    -0x78(%rbp),%rdx
 10a09e8:	mov    %rdx,-0x430(%rbp)
 10a09ef:	mov    %rax,%rbx
 10a09f2:	mov    -0x70(%rbp),%rax
 10a09f6:	mov    %rax,-0x428(%rbp)
 10a09fd:	lea    -0x438(%rbp),%rdx
 10a0a04:	lea    -0x360(%rbp),%rsi
 10a0a0b:	mov    %rdi,%r13
 10a0a0e:	call   1147890 <myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_take>
 10a0a13:	mov    %r13,%rdi
 10a0a16:	cmp    $0x0,%eax
 10a0a19:	jne    10a0a38 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0xc58>
 10a0a1b:	call   1169600 <myl_rc_take_failure>
 10a0a20:	mov    %r12,%rdi
 10a0a23:	mov    %eax,%esi
 10a0a25:	mov    %rdi,%r12
 10a0a28:	call   1159ab0 <myl_qbe_rc_status>
 10a0a2d:	mov    %rbx,%rax
 10a0a30:	mov    %rax,%rbx
 10a0a33:	jmp    10a0bc5 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0xde5>
 10a0a38:	mov    %rbx,%rax
 10a0a3b:	mov    -0x360(%rbp),%rcx
 10a0a42:	mov    %rcx,(%rax)
 10a0a45:	mov    -0x358(%rbp),%rcx
 10a0a4c:	mov    %rcx,0x8(%rax)
 10a0a50:	mov    -0x350(%rbp),%rcx
 10a0a57:	mov    %rcx,0x10(%rax)
 10a0a5b:	jmp    10a0c23 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0xe43>
 10a0a60:	mov    %ebx,%r13d
 10a0a63:	mov    -0x290(%rbp),%rdx
 10a0a6a:	mov    %rdx,-0x280(%rbp)
 10a0a71:	mov    -0x288(%rbp),%rdx
 10a0a78:	mov    %rdx,-0x278(%rbp)
 10a0a7f:	mov    %rcx,%r14
 10a0a82:	mov    -0x280(%rbp),%ecx
 10a0a88:	cmp    $0x0,%rcx
 10a0a8c:	je     10a0ad3 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0xcf3>
 10a0a8e:	cmp    $0x1,%rcx
 10a0a92:	je     10a0abc <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0xcdc>
 10a0a94:	cmp    $0x2,%rcx
 10a0a98:	je     10a0ab2 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0xcd2>
 10a0a9a:	cmp    $0x3,%rcx
 10a0a9e:	je     10a0aa8 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0xcc8>
 10a0aa0:	mov    %rax,%rbx
 10a0aa3:	jmp    10a0bc5 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0xde5>
 10a0aa8:	mov    %rax,%rbx
 10a0aab:	mov    $0x0,%eax
 10a0ab0:	jmp    10a0adb <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0xcfb>
 10a0ab2:	mov    %rax,%rbx
 10a0ab5:	mov    $0x0,%eax
 10a0aba:	jmp    10a0adb <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0xcfb>
 10a0abc:	mov    %rax,%rbx
 10a0abf:	movzbq -0x278(%rbp),%rax
 10a0ac7:	mov    %al,-0x360(%rbp)
 10a0acd:	xor    $0x1,%rax
 10a0ad1:	jmp    10a0adb <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0xcfb>
 10a0ad3:	mov    %rax,%rbx
 10a0ad6:	mov    $0x1,%eax
 10a0adb:	movq   $0x0,-0x250(%rbp)
 10a0ae6:	movq   $0x0,-0x248(%rbp)
 10a0af1:	movl   $0x1,-0x250(%rbp)
 10a0afb:	movzbq %al,%rax
 10a0aff:	mov    %al,-0x248(%rbp)
 10a0b05:	lea    -0x250(%rbp),%rdx
 10a0b0c:	mov    %rdi,%r15
 10a0b0f:	mov    %r12,%rdi
 10a0b12:	call   109cfd0 <myl_f_1e67eb8ef4c3a3acc3a97242d455a6d9c8a2bcb48d8912e38331c2e291a74a0e>
 10a0b17:	mov    %r15,%rdi
 10a0b1a:	cmp    $0x0,%r13d
 10a0b1e:	jne    10a0b28 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0xd48>
 10a0b20:	mov    %rbx,%rax
 10a0b23:	mov    %r14,%rcx
 10a0b26:	jmp    10a0b40 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0xd60>
 10a0b28:	lea    -0x438(%rbp),%rsi
 10a0b2f:	mov    %rdi,%r13
 10a0b32:	call   1141730 <myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop>
 10a0b37:	mov    %r14,%rcx
 10a0b3a:	mov    %r13,%rdi
 10a0b3d:	mov    %rbx,%rax
 10a0b40:	movq   $0x0,-0x180(%rbp)
 10a0b4b:	movq   $0x0,-0x178(%rbp)
 10a0b56:	movq   $0x0,-0x170(%rbp)
 10a0b61:	movl   $0x0,-0x180(%rbp)
 10a0b6b:	mov    -0x180(%rbp),%rdx
 10a0b72:	mov    %rdx,-0x438(%rbp)
 10a0b79:	mov    -0x178(%rbp),%rdx
 10a0b80:	mov    %rdx,-0x430(%rbp)
 10a0b87:	mov    %rax,%rbx
 10a0b8a:	mov    -0x170(%rbp),%rax
 10a0b91:	mov    %rax,-0x428(%rbp)
 10a0b98:	lea    -0x438(%rbp),%rdx
 10a0b9f:	lea    -0x360(%rbp),%rsi
 10a0ba6:	mov    %rdi,%r13
 10a0ba9:	call   1147890 <myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_take>
 10a0bae:	mov    %r13,%rdi
 10a0bb1:	cmp    $0x0,%eax
 10a0bb4:	jne    10a0c00 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0xe20>
 10a0bb6:	call   1169600 <myl_rc_take_failure>
 10a0bbb:	mov    %r12,%rdi
 10a0bbe:	mov    %eax,%esi
 10a0bc0:	call   1159ab0 <myl_qbe_rc_status>
 10a0bc5:	mov    $0x18,%edx
 10a0bca:	mov    $0x0,%esi
 10a0bcf:	lea    -0x450(%rbp),%rdi
 10a0bd6:	call   1176f90 <compiler_rt.fastMemset>
 10a0bdb:	mov    %rbx,%rax
 10a0bde:	mov    -0x450(%rbp),%rcx
 10a0be5:	mov    %rcx,(%rax)
 10a0be8:	mov    -0x448(%rbp),%rcx
 10a0bef:	mov    %rcx,0x8(%rax)
 10a0bf3:	mov    -0x440(%rbp),%rcx
 10a0bfa:	mov    %rcx,0x10(%rax)
 10a0bfe:	jmp    10a0c23 <myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e+0xe43>
 10a0c00:	mov    %rbx,%rax
 10a0c03:	mov    -0x360(%rbp),%rcx
 10a0c0a:	mov    %rcx,(%rax)
 10a0c0d:	mov    -0x358(%rbp),%rcx
 10a0c14:	mov    %rcx,0x8(%rax)
 10a0c18:	mov    -0x350(%rbp),%rcx
 10a0c1f:	mov    %rcx,0x10(%rax)
 10a0c23:	pop    %r15
 10a0c25:	pop    %r14
 10a0c27:	pop    %r13
 10a0c29:	pop    %r12
 10a0c2b:	pop    %rbx
 10a0c2c:	leave
 10a0c2d:	ret
 10a0c2e:	mov    %r12,%rdi
 10a0c31:	call   115abb0 <myl_qbe_fail_frame>
 10a0c36:	ud2

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
