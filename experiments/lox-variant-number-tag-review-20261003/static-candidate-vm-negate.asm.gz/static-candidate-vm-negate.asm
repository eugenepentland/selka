
/home/epentland/ai/canopy/mylang-worktrees/codex-lox-variant-number-tag-20261003/.tmp-lox-variant-number-tag-20261003/number-tag-stable-rc-qbe:     file format elf64-x86-64


Disassembly of section .text:

0000000001127a50 <myl_f_6b8d2a166bbd9c248350f439dfeb2952399d529c32ecd164fee3dd015aa55840>:
 1127a50:	endbr64
 1127a54:	push   %rbp
 1127a55:	mov    %rsp,%rbp
 1127a58:	sub    $0x110,%rsp
 1127a5f:	push   %rbx
 1127a60:	push   %r12
 1127a62:	push   %r13
 1127a64:	push   %r14
 1127a66:	mov    %rdx,%r14
 1127a69:	mov    %rsi,%r13
 1127a6c:	mov    0x40(%rdi),%rax
 1127a70:	lea    -0x8(%rbp),%rcx
 1127a74:	cmp    %rax,%rcx
 1127a77:	jb     1127ed3 <myl_f_6b8d2a166bbd9c248350f439dfeb2952399d529c32ecd164fee3dd015aa55840+0x483>
 1127a7d:	mov    %rdi,%rbx
 1127a80:	call   115abc0 <myl_qbe_heap>
 1127a85:	mov    %rbx,%rdi
 1127a88:	mov    %rax,%rbx
 1127a8b:	mov    %rdi,%r12
 1127a8e:	call   115d720 <myl_qbe_region_mark>
 1127a93:	mov    %r14,%rdx
 1127a96:	mov    %r13,%rsi
 1127a99:	mov    %r12,%rdi
 1127a9c:	mov    0x80(%rsi),%r10
 1127aa3:	movabs $0x8000000000000001,%rax
 1127aad:	cmp    %rax,%r10
 1127ab0:	jl     1127eb9 <myl_f_6b8d2a166bbd9c248350f439dfeb2952399d529c32ecd164fee3dd015aa55840+0x469>
 1127ab6:	mov    %rsi,%r12
 1127ab9:	add    $0x78,%r12
 1127abd:	mov    0x78(%rsi),%rax
 1127ac1:	mov    (%rax),%r9
 1127ac4:	mov    %r10,%rcx
 1127ac7:	sub    $0x1,%rcx
 1127acb:	cmp    %r9,%rcx
 1127ace:	setb   %r8b
 1127ad2:	movzbq %r8b,%r8
 1127ad6:	cmp    $0x0,%r8d
 1127ada:	jne    1127b61 <myl_f_6b8d2a166bbd9c248350f439dfeb2952399d529c32ecd164fee3dd015aa55840+0x111>
 1127ae0:	cmp    $0x0,%rcx
 1127ae4:	jl     1127aeb <myl_f_6b8d2a166bbd9c248350f439dfeb2952399d529c32ecd164fee3dd015aa55840+0x9b>
 1127ae6:	mov    %rcx,%r13
 1127ae9:	jmp    1127b15 <myl_f_6b8d2a166bbd9c248350f439dfeb2952399d529c32ecd164fee3dd015aa55840+0xc5>
 1127aeb:	movabs $0x7fffffffffffffff,%r8
 1127af5:	cmp    %r8,%r9
 1127af8:	ja     1127b52 <myl_f_6b8d2a166bbd9c248350f439dfeb2952399d529c32ecd164fee3dd015aa55840+0x102>
 1127afa:	mov    %r9,%r13
 1127afd:	add    %rcx,%r13
 1127b00:	mov    %r9,%r8
 1127b03:	xor    %r13,%r8
 1127b06:	mov    %rcx,%r10
 1127b09:	xor    %r13,%r10
 1127b0c:	and    %r10,%r8
 1127b0f:	cmp    $0x0,%r8
 1127b13:	jl     1127b3a <myl_f_6b8d2a166bbd9c248350f439dfeb2952399d529c32ecd164fee3dd015aa55840+0xea>
 1127b15:	cmp    %r9,%r13
 1127b18:	jb     1127b2a <myl_f_6b8d2a166bbd9c248350f439dfeb2952399d529c32ecd164fee3dd015aa55840+0xda>
 1127b1a:	mov    %r9,%rsi
 1127b1d:	mov    %rsi,%rdx
 1127b20:	mov    %r13,%rsi
 1127b23:	call   115a800 <myl_qbe_fail_normalized_index_bounds>
 1127b28:	ud2
 1127b2a:	mov    0x20(%rax),%rax
 1127b2e:	imul   $0x10,%r13,%r8
 1127b32:	add    %r8,%rax
 1127b35:	mov    %rcx,%r14
 1127b38:	jmp    1127b6f <myl_f_6b8d2a166bbd9c248350f439dfeb2952399d529c32ecd164fee3dd015aa55840+0x11f>
 1127b3a:	mov    %r9,%rsi
 1127b3d:	mov    $0x40,%r8d
 1127b43:	mov    %rsi,%rdx
 1127b46:	mov    $0x0,%esi
 1127b4b:	call   115aa10 <myl_qbe_fail_overflow_op>
 1127b50:	ud2
 1127b52:	mov    %r9,%rsi
 1127b55:	mov    $0x140,%edx
 1127b5a:	call   115ab50 <myl_qbe_fail_cast>
 1127b5f:	ud2
 1127b61:	mov    0x20(%rax),%rax
 1127b65:	mov    %rcx,%r14
 1127b68:	imul   $0x10,%rcx,%rcx
 1127b6c:	add    %rcx,%rax
 1127b6f:	mov    %rax,%rcx
 1127b72:	mov    (%rax),%eax
 1127b74:	cmp    $0x0,%rax
 1127b78:	je     1127e20 <myl_f_6b8d2a166bbd9c248350f439dfeb2952399d529c32ecd164fee3dd015aa55840+0x3d0>
 1127b7e:	cmp    $0x1,%rax
 1127b82:	je     1127d84 <myl_f_6b8d2a166bbd9c248350f439dfeb2952399d529c32ecd164fee3dd015aa55840+0x334>
 1127b88:	cmp    $0x2,%rax
 1127b8c:	je     1127c38 <myl_f_6b8d2a166bbd9c248350f439dfeb2952399d529c32ecd164fee3dd015aa55840+0x1e8>
 1127b92:	cmp    $0x3,%rax
 1127b96:	jne    1127ce7 <myl_f_6b8d2a166bbd9c248350f439dfeb2952399d529c32ecd164fee3dd015aa55840+0x297>
 1127b9c:	mov    0x10aa3d(%rip),%rcx        # 12325e0 <myl_lit_2d6548b0d20925eb41b8b902da17a2651a780e0ecf585d7c93694f27a1a25cd5>
 1127ba3:	mov    %rcx,-0x100(%rbp)
 1127baa:	mov    -0x100(%rbp),%rax
 1127bb1:	mov    %rax,-0xf8(%rbp)
 1127bb8:	mov    -0xf8(%rbp),%rax
 1127bbf:	mov    %rax,-0x108(%rbp)
 1127bc6:	call   1128240 <myl_f_8855e2338a0239644fa6d8638afc594de302f594debc25ce542a382b2a6572a1>
 1127bcb:	mov    %rbx,%rdi
 1127bce:	mov    -0x108(%rbp),%rdx
 1127bd5:	cmp    $0x0,%rdx
 1127bd9:	je     1127eb0 <myl_f_6b8d2a166bbd9c248350f439dfeb2952399d529c32ecd164fee3dd015aa55840+0x460>
 1127bdf:	mov    -0x10(%rdx),%rcx
 1127be3:	movabs $0x4000000000000002,%rsi
 1127bed:	and    %rsi,%rcx
 1127bf0:	cmp    $0x0,%rcx
 1127bf4:	jne    1127c28 <myl_f_6b8d2a166bbd9c248350f439dfeb2952399d529c32ecd164fee3dd015aa55840+0x1d8>
 1127bf6:	mov    -0x20(%rdx),%rcx
 1127bfa:	sub    $0x1,%rcx
 1127bfe:	jne    1127c24 <myl_f_6b8d2a166bbd9c248350f439dfeb2952399d529c32ecd164fee3dd015aa55840+0x1d4>
 1127c00:	mov    %rax,%rbx
 1127c03:	mov    -0x18(%rdx),%rax
 1127c07:	cmp    $0x0,%rax
 1127c0b:	jne    1127c21 <myl_f_6b8d2a166bbd9c248350f439dfeb2952399d529c32ecd164fee3dd015aa55840+0x1d1>
 1127c0d:	lea    -0x108(%rbp),%rsi
 1127c14:	call   113f3a0 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop>
 1127c19:	mov    %rbx,%rax
 1127c1c:	jmp    1127eb0 <myl_f_6b8d2a166bbd9c248350f439dfeb2952399d529c32ecd164fee3dd015aa55840+0x460>
 1127c21:	mov    %rbx,%rax
 1127c24:	mov    %rcx,-0x20(%rdx)
 1127c28:	movq   $0x0,-0x108(%rbp)
 1127c33:	jmp    1127eb0 <myl_f_6b8d2a166bbd9c248350f439dfeb2952399d529c32ecd164fee3dd015aa55840+0x460>
 1127c38:	mov    %rcx,%rax
 1127c3b:	mov    %r12,%rdx
 1127c3e:	mov    %rdx,%r13
 1127c41:	mov    0x8(%rax),%rdx
 1127c45:	mov    %rdx,-0xf8(%rbp)
 1127c4c:	mov    %rsi,%r12
 1127c4f:	mov    $0x7,%esi
 1127c54:	mov    %rdi,%rbx
 1127c57:	call   115abe0 <myl_qbe_float_unary>
 1127c5c:	mov    %r14,%rcx
 1127c5f:	mov    %r13,%rdx
 1127c62:	mov    %r12,%rsi
 1127c65:	mov    %rbx,%rdi
 1127c68:	movq   $0x0,-0x18(%rbp)
 1127c70:	movq   $0x0,-0x10(%rbp)
 1127c78:	movq   $0x2,-0x18(%rbp)
 1127c80:	mov    %rax,-0x10(%rbp)
 1127c84:	mov    -0x18(%rbp),%rax
 1127c88:	mov    %rax,-0x28(%rbp)
 1127c8c:	mov    -0x10(%rbp),%rax
 1127c90:	mov    %rax,-0x20(%rbp)
 1127c94:	mov    0x78(%rsi),%rax
 1127c98:	cmp    $0x0,%rax
 1127c9c:	je     1127cf1 <myl_f_6b8d2a166bbd9c248350f439dfeb2952399d529c32ecd164fee3dd015aa55840+0x2a1>
 1127c9e:	mov    -0x10(%rax),%r8
 1127ca2:	movabs $0x6000000000000002,%r9
 1127cac:	and    %r9,%r8
 1127caf:	cmp    $0x0,%r8
 1127cb3:	jne    1127cbf <myl_f_6b8d2a166bbd9c248350f439dfeb2952399d529c32ecd164fee3dd015aa55840+0x26f>
 1127cb5:	mov    -0x20(%rax),%rax
 1127cb9:	cmp    $0x2,%rax
 1127cbd:	jb     1127cf1 <myl_f_6b8d2a166bbd9c248350f439dfeb2952399d529c32ecd164fee3dd015aa55840+0x2a1>
 1127cbf:	mov    %rcx,%r13
 1127cc2:	mov    $0x0,%ecx
 1127cc7:	mov    %rsi,%r12
 1127cca:	lea    0x102547(%rip),%rsi        # 122a218 <myl_t_a1fa53db408c85388cfd14badb361c2a89e74ce2a863fa83774cb6942b74317a>
 1127cd1:	mov    %rdi,%rbx
 1127cd4:	call   115a090 <myl_qbe_rc_unique_field>
 1127cd9:	mov    %r13,%rcx
 1127cdc:	mov    %r12,%rsi
 1127cdf:	mov    %rbx,%rdi
 1127ce2:	cmp    $0x0,%eax
 1127ce5:	jne    1127cf1 <myl_f_6b8d2a166bbd9c248350f439dfeb2952399d529c32ecd164fee3dd015aa55840+0x2a1>
 1127ce7:	mov    $0x0,%eax
 1127cec:	jmp    1127eb0 <myl_f_6b8d2a166bbd9c248350f439dfeb2952399d529c32ecd164fee3dd015aa55840+0x460>
 1127cf1:	mov    0x78(%rsi),%rax
 1127cf5:	cmp    $0x0,%rcx
 1127cf9:	jge    1127d2b <myl_f_6b8d2a166bbd9c248350f439dfeb2952399d529c32ecd164fee3dd015aa55840+0x2db>
 1127cfb:	mov    (%rax),%rsi
 1127cfe:	movabs $0x7fffffffffffffff,%rdx
 1127d08:	cmp    %rdx,%rsi
 1127d0b:	ja     1127d78 <myl_f_6b8d2a166bbd9c248350f439dfeb2952399d529c32ecd164fee3dd015aa55840+0x328>
 1127d0d:	mov    %rsi,%rbx
 1127d10:	add    %rcx,%rbx
 1127d13:	mov    %rsi,%rdx
 1127d16:	xor    %rbx,%rdx
 1127d19:	mov    %rcx,%r8
 1127d1c:	xor    %rbx,%r8
 1127d1f:	and    %r8,%rdx
 1127d22:	cmp    $0x0,%rdx
 1127d26:	jl     1127d63 <myl_f_6b8d2a166bbd9c248350f439dfeb2952399d529c32ecd164fee3dd015aa55840+0x313>
 1127d28:	mov    %rbx,%rcx
 1127d2b:	mov    (%rax),%rdx
 1127d2e:	cmp    %rdx,%rcx
 1127d31:	jb     1127d3d <myl_f_6b8d2a166bbd9c248350f439dfeb2952399d529c32ecd164fee3dd015aa55840+0x2ed>
 1127d33:	mov    %rcx,%rsi
 1127d36:	call   115a800 <myl_qbe_fail_normalized_index_bounds>
 1127d3b:	ud2
 1127d3d:	mov    %rcx,%rbx
 1127d40:	mov    0x20(%rax),%rcx
 1127d44:	imul   $0x10,%rbx,%rdx
 1127d48:	mov    -0x28(%rbp),%rax
 1127d4c:	mov    %rax,(%rcx,%rdx,1)
 1127d50:	mov    -0x20(%rbp),%rax
 1127d54:	mov    %rax,0x8(%rcx,%rdx,1)
 1127d59:	mov    $0x1,%eax
 1127d5e:	jmp    1127eb0 <myl_f_6b8d2a166bbd9c248350f439dfeb2952399d529c32ecd164fee3dd015aa55840+0x460>
 1127d63:	mov    $0x40,%r8d
 1127d69:	mov    %rsi,%rdx
 1127d6c:	mov    $0x0,%esi
 1127d71:	call   115aa10 <myl_qbe_fail_overflow_op>
 1127d76:	ud2
 1127d78:	mov    $0x140,%edx
 1127d7d:	call   115ab50 <myl_qbe_fail_cast>
 1127d82:	ud2
 1127d84:	mov    0x10a855(%rip),%rcx        # 12325e0 <myl_lit_2d6548b0d20925eb41b8b902da17a2651a780e0ecf585d7c93694f27a1a25cd5>
 1127d8b:	mov    %rcx,-0x100(%rbp)
 1127d92:	mov    -0x100(%rbp),%rax
 1127d99:	mov    %rax,-0xf8(%rbp)
 1127da0:	mov    -0xf8(%rbp),%rax
 1127da7:	mov    %rax,-0x108(%rbp)
 1127dae:	call   1128240 <myl_f_8855e2338a0239644fa6d8638afc594de302f594debc25ce542a382b2a6572a1>
 1127db3:	mov    %rbx,%rdi
 1127db6:	mov    -0x108(%rbp),%rdx
 1127dbd:	cmp    $0x0,%rdx
 1127dc1:	je     1127eb0 <myl_f_6b8d2a166bbd9c248350f439dfeb2952399d529c32ecd164fee3dd015aa55840+0x460>
 1127dc7:	mov    -0x10(%rdx),%rcx
 1127dcb:	movabs $0x4000000000000002,%rsi
 1127dd5:	and    %rsi,%rcx
 1127dd8:	cmp    $0x0,%rcx
 1127ddc:	jne    1127e10 <myl_f_6b8d2a166bbd9c248350f439dfeb2952399d529c32ecd164fee3dd015aa55840+0x3c0>
 1127dde:	mov    -0x20(%rdx),%rcx
 1127de2:	sub    $0x1,%rcx
 1127de6:	jne    1127e0c <myl_f_6b8d2a166bbd9c248350f439dfeb2952399d529c32ecd164fee3dd015aa55840+0x3bc>
 1127de8:	mov    %rax,%rbx
 1127deb:	mov    -0x18(%rdx),%rax
 1127def:	cmp    $0x0,%rax
 1127df3:	jne    1127e09 <myl_f_6b8d2a166bbd9c248350f439dfeb2952399d529c32ecd164fee3dd015aa55840+0x3b9>
 1127df5:	lea    -0x108(%rbp),%rsi
 1127dfc:	call   113f3a0 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop>
 1127e01:	mov    %rbx,%rax
 1127e04:	jmp    1127eb0 <myl_f_6b8d2a166bbd9c248350f439dfeb2952399d529c32ecd164fee3dd015aa55840+0x460>
 1127e09:	mov    %rbx,%rax
 1127e0c:	mov    %rcx,-0x20(%rdx)
 1127e10:	movq   $0x0,-0x108(%rbp)
 1127e1b:	jmp    1127eb0 <myl_f_6b8d2a166bbd9c248350f439dfeb2952399d529c32ecd164fee3dd015aa55840+0x460>
 1127e20:	mov    0x10a7b9(%rip),%rcx        # 12325e0 <myl_lit_2d6548b0d20925eb41b8b902da17a2651a780e0ecf585d7c93694f27a1a25cd5>
 1127e27:	mov    %rcx,-0x100(%rbp)
 1127e2e:	mov    -0x100(%rbp),%rax
 1127e35:	mov    %rax,-0xf8(%rbp)
 1127e3c:	mov    -0xf8(%rbp),%rax
 1127e43:	mov    %rax,-0x108(%rbp)
 1127e4a:	call   1128240 <myl_f_8855e2338a0239644fa6d8638afc594de302f594debc25ce542a382b2a6572a1>
 1127e4f:	mov    %rbx,%rdi
 1127e52:	mov    -0x108(%rbp),%rdx
 1127e59:	cmp    $0x0,%rdx
 1127e5d:	je     1127eb0 <myl_f_6b8d2a166bbd9c248350f439dfeb2952399d529c32ecd164fee3dd015aa55840+0x460>
 1127e5f:	mov    -0x10(%rdx),%rcx
 1127e63:	movabs $0x4000000000000002,%rsi
 1127e6d:	and    %rsi,%rcx
 1127e70:	cmp    $0x0,%rcx
 1127e74:	jne    1127ea5 <myl_f_6b8d2a166bbd9c248350f439dfeb2952399d529c32ecd164fee3dd015aa55840+0x455>
 1127e76:	mov    -0x20(%rdx),%rcx
 1127e7a:	sub    $0x1,%rcx
 1127e7e:	jne    1127ea1 <myl_f_6b8d2a166bbd9c248350f439dfeb2952399d529c32ecd164fee3dd015aa55840+0x451>
 1127e80:	mov    %rax,%rbx
 1127e83:	mov    -0x18(%rdx),%rax
 1127e87:	cmp    $0x0,%rax
 1127e8b:	jne    1127e9e <myl_f_6b8d2a166bbd9c248350f439dfeb2952399d529c32ecd164fee3dd015aa55840+0x44e>
 1127e8d:	lea    -0x108(%rbp),%rsi
 1127e94:	call   113f3a0 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop>
 1127e99:	mov    %rbx,%rax
 1127e9c:	jmp    1127eb0 <myl_f_6b8d2a166bbd9c248350f439dfeb2952399d529c32ecd164fee3dd015aa55840+0x460>
 1127e9e:	mov    %rbx,%rax
 1127ea1:	mov    %rcx,-0x20(%rdx)
 1127ea5:	movq   $0x0,-0x108(%rbp)
 1127eb0:	pop    %r14
 1127eb2:	pop    %r13
 1127eb4:	pop    %r12
 1127eb6:	pop    %rbx
 1127eb7:	leave
 1127eb8:	ret
 1127eb9:	mov    %r10,%rdx
 1127ebc:	mov    $0x40,%r8d
 1127ec2:	mov    $0x1,%ecx
 1127ec7:	mov    $0x1,%esi
 1127ecc:	call   115aa10 <myl_qbe_fail_overflow_op>
 1127ed1:	ud2
 1127ed3:	call   115abd0 <myl_qbe_fail_frame>
 1127ed8:	ud2

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
