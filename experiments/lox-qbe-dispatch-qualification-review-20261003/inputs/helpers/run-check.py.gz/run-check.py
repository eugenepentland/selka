import pathlib,json,os,subprocess,time,hashlib,sys
w=pathlib.Path(__file__).resolve().parents[1];s=w/'.tmp-lox-qbe-dispatch-20261003'
name=sys.argv[1];argv=[str(w/'scripts/build-slot.sh'),sys.argv[2]]+sys.argv[3:]
env=os.environ.copy();env['TMPDIR']=str(s/'tmp');env['ZIG_GLOBAL_CACHE_DIR']=str(s/'zig-global')
row={'argv':argv,'cwd':str(w),'env':{k:env[k] for k in ['TMPDIR','ZIG_GLOBAL_CACHE_DIR']},'started':time.time()}
log=s/(name+'.log')
with log.open('wb') as f:r=subprocess.run(argv,cwd=w,env=env,stdout=f,stderr=subprocess.STDOUT)
row.update(status=r.returncode,finished=time.time(),log_sha256=hashlib.sha256(log.read_bytes()).hexdigest())
(s/(name+'.json')).write_text(json.dumps(row,indent=2)+'\n');print(json.dumps(row),flush=True);sys.exit(r.returncode)
