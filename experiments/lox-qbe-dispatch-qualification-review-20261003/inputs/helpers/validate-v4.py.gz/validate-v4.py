#!/usr/bin/env python3
"""Qualify actual dispatch-chain compiler ELFs against frozen selected AST controls."""
from collections import Counter
from datetime import datetime, timezone
import hashlib, json, os, subprocess
from pathlib import Path

OWN = Path(__file__).resolve().parents[1]
WORK = OWN/'.tmp-lox-qbe-dispatch-20261003/native-v3'
OLD = OWN/'.tmp-lox-qbe-dispatch-20261003'
ROOT = Path('/home/epentland/ai/canopy/mylang-worktrees/codex-lox-parity-20261003')
STACK = Path('/home/epentland/ai/canopy/mylang-worktrees/codex-lox-parity-vm-20261003')
SOURCE = OLD/'selected-ast'
BASE = ROOT/'.tmp-lox-round3/ast'
COMPILER = OLD/'compiler-v3/bin/mylang'
HELPER = ROOT/'experiments/lox-parity-tree-20261003/validate.py'
CASES = STACK/'experiments/lox-vm-callee-20261003/regressions.json'
FOCUSED = STACK/'.tmp-lox-ast-carrier-20261003/focused-regressions-final.json'
BENCH = ROOT/'.tmp-lox-parity/reference/benchmarks/lox/bench'
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
files = lambda root: {str(p.relative_to(root)): sha(p) for p in sorted(root.rglob('*')) if p.is_file()}

def write(name, value):
    (WORK/name).write_text(json.dumps(value, indent=2)+'\n')

bins = {'control-'+b: str(ROOT/('.tmp-lox-round3/bin/ast-'+b)) for b in ['llvm', 'qbe']}
for backend in ['llvm', 'qbe']:
    bins['candidate-rc-'+backend] = str(OLD/('static-v3-'+backend+'.elf'))
    for mode in ['ordinary', 'gc']:
        bins['candidate-'+mode+'-'+backend] = str(OLD/('native-v4-gc-'+backend+'.elf'))
assert not (WORK/'binaries.json').exists()
write('binaries.json', {'binaries': bins})


def old_snapshot():
    paths = {COMPILER, COMPILER.with_name('qbe'), HELPER, CASES, FOCUSED, Path(__file__).resolve(), WORK/'binaries.json', OLD/'proof-v3.json', OLD/'compiler-v3.json', OLD/'static-v3-build.json', OLD/'native-v4-gc-build.json', ROOT/'.tmp-lox-round3/ast-build.json', ROOT/'.tmp-lox-parity/inputs/pinned-SPEC.md'}
    paths.add(OLD/'public-qualification-v4.json')
    paths.update([OLD/'freeze.py',OLD/'helper-source-final.json',OLD/'full-source-v3.json'])
    for file in json.loads((OLD/'proof-v3.json').read_text())['files']:
        paths.update([OWN/file, OLD/'proof-v3'/file])
    for name in ['d9-lox-env-reads-runs.json.gz', 'd9-lox-class-method-runs.json.gz']:
        paths.add(ROOT/'docs/audits/evidence'/name)
    paths.update(p for p in BENCH.rglob('*') if p.is_file())
    for binary in set(bins.values()):
        binary = Path(binary)
        manifest = Path(str(binary)+'.qbe-manifest.json')
        paths.update([binary, manifest, Path(str(binary)+'.qbe-receipt')])
        paths.add(Path(json.loads(manifest.read_text())['runtime_object']))
    return {'candidate37': files(SOURCE), 'control37': files(BASE),
            'artifacts_sha256': {str(p): sha(p) for p in sorted(paths)}}

from freeze import snapshot as complete_snapshot
def snapshot():
    old=old_snapshot()
    complete=complete_snapshot(guests=set(bins.values()), helpers=[Path(__file__).resolve()])
    old['complete_freeze']=complete
    return old

assert not (set(os.sched_getaffinity(0)) & {2, 3, 10, 11})
assert not (WORK/'preflight.json').exists()
before = snapshot()
assert len(before['candidate37']) == len(before['control37']) == 37
prior = json.loads((OLD/'static-v3-build.json').read_text())
gc = json.loads((OLD/'native-v4-gc-build.json').read_text())
assert before['candidate37'] == prior['source37_after'] == gc['source37'] == before['control37']
assert prior['verified_after'] and gc['verified_after']
identity = json.loads((OLD/'compiler-v3.json').read_text())
assert sha(COMPILER) == identity['compiler_sha256'] == '1eea98da970ea95911a492b31fe7a0e79aad0c96e920c15aee692377494b51b4'
assert sha(COMPILER.with_name('qbe')) == '99ad919d70ad582dee6202b045bd53e1ab18fec356de98849610f49983756d63'
assert sha(bins['control-llvm']) == '180575c3fc2e46a16ed8dd290e289963a87603b5a7c0cf8bb0e03ba7cf794361'
assert sha(bins['control-qbe']) == '246f21781fd58c7141dbe0992101c842e62d732d9ce47e209d55821d02b11b25'
before.update(started_utc=datetime.now(timezone.utc).isoformat(), runner_affinity=sorted(os.sched_getaffinity(0)))
write('preflight.json', before)
env = {k: v for k, v in os.environ.items() if not k.startswith('MYLANG_') and k != 'LD_PRELOAD'}
env['TMPDIR'] = str(WORK/'tmp')
env['ZIG_GLOBAL_CACHE_DIR'] = str(OLD/'zig-global')
argv = ['python3', str(HELPER), '--work', str(WORK), '--bench', str(BENCH),
        '--manifest', str(WORK/'binaries.json'), '--out', str(WORK/'observations.json'),
        '--jobs', '2', '--cases', str(CASES), '--native-cases', 'closures,instantiation,properties']
write('command.json', {'argv': argv, 'cwd': str(OWN), 'environment': {'TMPDIR': env['TMPDIR']},
                       'affinity': sorted(os.sched_getaffinity(0)),
                       'launcher': [str(OWN/'scripts/build-slot.sh'), 'build', 'python3', str(Path(__file__).resolve())]})
with (WORK/'observations.log').open('w') as out:
    run = subprocess.run(argv, cwd=OWN, env=env, stdout=out, stderr=subprocess.STDOUT)
assert run.returncode == 0, (run.returncode, WORK/'observations.log')
r = json.loads((WORK/'observations.json').read_text())
assert len(r['samples']) == 1168 and len(r['unrun']) == 80 and r['verified_after']
identity = lambda row: (row['name'], row['tier'], row['engine'], row['arm'], row['lox_gc_stress'])
actual = {identity(row) for row in r['samples']}
unrun = {identity(row) for row in r['unrun']}
keys = {(row['name'], row['tier'], row['engine']) for row in r['samples']}
expected = {(n, t, e, arm, stress) for n, t, e in keys for arm in bins if not arm.startswith('control-') for stress in [False, True]}
assert len(keys) == 104 and len(actual) == 1168 and len(unrun) == 80
assert actual.isdisjoint(unrun) and actual|unrun == expected
assert all(row['actual'] == row['expected'] for row in r['samples'])
counts = Counter('native_gc_stress' if row['native_gc_stress'] else 'rc' if '-rc-' in row['arm'] else 'ordinary_gc' for row in r['samples'])
assert counts == {'rc': 416, 'ordinary_gc': 416, 'native_gc_stress': 336}


def observe(binary, script, engine, lox, native):
    argv = [binary, '--engine='+engine, '--stats']
    if lox: argv.append('--gc-stress')
    argv.append(str(script))
    launch = dict(env)
    if native: launch['MYLANG_OPTIONS'] = '--gc-stress'
    run = subprocess.run(argv, env=launch, capture_output=True, timeout=120)
    return {'status': run.returncode, 'stdout': run.stdout.decode(), 'stderr': run.stderr.decode()}, argv

refusals = []
script = WORK/'validation-inputs/closures.vm.smoke.lox'
for backend in ['llvm', 'qbe']:
    for engine in ['tree', 'vm']:
        for lox in [False, True]:
            control, ca = observe(bins['control-'+backend], script, engine, lox, True)
            candidate, cmd = observe(bins['candidate-rc-'+backend], script, engine, lox, True)
            assert candidate == control and candidate['status'] == 2 and candidate['stdout'] == '' and '--gc-runtime' in candidate['stderr']
            refusals.append({'backend': backend, 'engine': engine, 'lox_gc_stress': lox,
                             'environment': {'MYLANG_OPTIONS': '--gc-stress'}, 'argv': cmd,
                             'control_argv': ca, 'expected': control, 'actual': candidate})
assert len(refusals) == 8
write('rc-native-stress-refusals.json', {'pairs': refusals, 'meaning': 'Checked refusals, not program passes'})
focused = []
for case in json.loads(FOCUSED.read_text()):
    script = WORK/('validation-inputs/'+case['name']+'.focused.lox')
    script.write_text(case['source'])
    for engine in ['tree','vm']:
        for backend in ['llvm','qbe']:
            for lox in [False,True]:
                control,ca = observe(bins['control-'+backend],script,engine,lox,False)
                assert control['status']==case['status'] and control['stdout']==case['stdout']
                if 'stderr_prefix_by_engine' in case:
                    assert control['stderr'].startswith(case['stderr_prefix_by_engine'][engine])
                for mode in ['rc','ordinary','gc']:
                    native=mode=='gc'
                    arm='candidate-'+mode+'-'+backend
                    candidate,cmd=observe(bins[arm],script,engine,lox,native)
                    row={'name':case['name'],'engine':engine,'backend':backend,'arm':arm,
                         'lox_gc_stress':lox,'native_gc_stress':native,'source_sha256':sha(script),
                         'argv':cmd,'control_argv':ca,'expected':control,'actual':candidate}
                    assert candidate==control
                    focused.append(row)
                    write('ast-focused-observations.json',{'samples':focused})
    print('PASS dispatch-chain AST focused program',case['name'],flush=True)
assert len(focused)==96

input_paths = sorted((WORK/'validation-inputs').glob('*.lox'))
input_hashes = {str(p): sha(p) for p in input_paths}
after = snapshot()
assert all(sha(p)==h for p,h in input_hashes.items())
assert after['candidate37'] == before['candidate37']
assert after['control37'] == before['control37']
assert after['artifacts_sha256'] == before['artifacts_sha256']
assert after['complete_freeze']==before['complete_freeze']
write('completed.json', {'before': before, 'after': after, 'verified_after': True,
      'finished_utc': datetime.now(timezone.utc).isoformat(), 'helper_status': run.returncode,
      'mode_counts': dict(counts), 'bounded_observations': 1168,
      'rc_native_stress_refusal_pairs': 8,  'ast_focused_pairs':96, 'native_smoke_unrun': r['unrun'],
      'input_sha256': input_hashes, 'receipt_sha256': {name: sha(WORK/name) for name in ['binaries.json', 'command.json',
         'observations.json', 'observations.log', 'rc-native-stress-refusals.json', 'ast-focused-observations.json']}})
print('1168 bounded +96 AST pairs and 8 refusals pass; all37/source/artifact hashes unchanged', flush=True)
