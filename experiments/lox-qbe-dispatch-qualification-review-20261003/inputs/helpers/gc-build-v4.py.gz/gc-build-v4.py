import pathlib, json, hashlib, subprocess, os, datetime, shutil
w = pathlib.Path(__file__).resolve().parents[1]
s = w / '.tmp-lox-qbe-dispatch-20261003'
root = w.parent / 'codex-lox-parity-20261003'
lower = w.parent / 'codex-lox-parity-lowering-20261003'
def sha(p): return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def sources(p): return {str(f.relative_to(p)): sha(f) for f in sorted(p.rglob('*')) if f.is_file()}
proof = json.loads((s / 'proof-v3.json').read_text())
assert all(sha(w / f) == h for f, h in proof['files'].items())
assert json.loads((s / 'release-proof-v3.json').read_text())['status'] == 0
compiler = s / 'compiler-v3/bin/mylang'
ident = json.loads((s / 'compiler-v3.json').read_text())
assert sha(compiler)==ident['compiler_sha256'] and sha(compiler.with_name('qbe'))==ident['qbe_sha256']
qbe=compiler.with_name('qbe')
from freeze import snapshot
full_before=snapshot(guests=[s/('static-v3-'+b+'.elf') for b in ['llvm','qbe']],helpers=[pathlib.Path(__file__).resolve()])
source = s / 'selected-ast'
before = sources(root / '.tmp-lox-round3/ast')
assert len(before) == 37
assert source.is_dir()
assert sources(source) == before
env = os.environ.copy()
env['TMPDIR'] = str(s / 'tmp')
env['ZIG_GLOBAL_CACHE_DIR'] = str(s / 'zig-global')
receipt = {'source37': before, 'source37_before': before, 'compiler': ident, 'builds': []}
print(json.dumps(ident), flush=True)
for backend in ['qbe', 'llvm']:
    name = 'native-v4-gc-' + backend
    elf = s / (name + '.elf')
    argv = [str(w / 'scripts/build-slot.sh'), 'build', str(compiler), 'build', str(source / 'main.my'), '--project', '--backend', backend, '--gc-runtime', '--keep-symbols', '--cache-dir', str(s / name), '-o', str(elf)]
    if backend == 'llvm': argv += ['--llvm-opt', '3', '--lto']
    row = {'argv': argv, 'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat()}
    with (s / (name + '.log')).open('wb') as log:
        p = subprocess.run(argv, cwd=w, env=env, stdout=log, stderr=subprocess.STDOUT)
    row.update(status=p.returncode, finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), log_sha256=sha(s / (name + '.log')))
    receipt['builds'].append(row)
    (s / 'native-v4-gc-build.json').write_text(json.dumps(receipt, indent=2) + '\n')
    assert p.returncode == 0, (s / (name + '.log')).read_text()
    row.update(binary=str(elf), binary_sha256=sha(elf), manifest_sha256=sha(str(elf) + '.qbe-manifest.json'), receipt_sha256=sha(str(elf) + '.qbe-receipt'))
    manifest = json.loads(pathlib.Path(str(elf) + '.qbe-manifest.json').read_text())
    runtime = manifest['runtime_object']
    row.update(runtime_object=runtime, runtime_object_sha256=sha(runtime))
    print(json.dumps(row), flush=True)
receipt['source37_after'] = sources(source)
receipt['root_source37_after'] = sources(root / '.tmp-lox-round3/ast')
assert receipt['source37_after'] == receipt['root_source37_after'] == before
assert sha(compiler) == ident['compiler_sha256'] and sha(qbe) == ident['qbe_sha256']
assert all(sha(w / f) == h for f, h in proof['files'].items())
full_after=snapshot(guests=[s/('static-v3-'+b+'.elf') for b in ['llvm','qbe']],helpers=[pathlib.Path(__file__).resolve()])
assert full_before==full_after
receipt['full_freeze_before']=full_before
receipt['full_freeze_after']=full_after
receipt['verified_after'] = True
(s / 'native-v4-gc-build.json').write_text(json.dumps(receipt, indent=2) + '\n')
