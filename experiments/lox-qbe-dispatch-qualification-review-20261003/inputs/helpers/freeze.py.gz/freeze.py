from pathlib import Path
import hashlib, json

OWN = Path(__file__).resolve().parents[1]
WORK = OWN / '.tmp-lox-qbe-dispatch-20261003'
ROOT = OWN.parent / 'codex-lox-parity-20261003'
LOWER = OWN.parent / 'codex-lox-parity-lowering-20261003'
COMPILER = WORK / 'compiler-v3'
CONTROL = LOWER / '.tmp-lox-lowering/cfg-fix-release'
sha = lambda path: hashlib.sha256(Path(path).read_bytes()).hexdigest()
files = lambda root: {str(p.relative_to(root)): sha(p) for p in sorted(root.rglob('*')) if p.is_file()}

def snapshot(guests=(), helpers=()):
    descriptor = json.loads((WORK / 'full-source-v3.json').read_text())
    core = {name: sha(OWN / name) for name in descriptor['files']}
    frozen = {name: sha(WORK / 'full-source-v3' / name) for name in descriptor['files']}
    assert core == frozen == descriptor['files']
    prefixes = {}
    for name, prefix in [('candidate', COMPILER), ('control', CONTROL)]:
        prefixes[name] = {part: files(prefix / part) for part in ['bin', 'lib']}
    artifacts = {str(p): sha(p) for p in helpers}
    for binary in guests:
        binary = Path(binary)
        manifest = Path(str(binary) + '.qbe-manifest.json')
        for p in [binary, manifest, Path(str(binary) + '.qbe-receipt')]: artifacts[str(p)] = sha(p)
        archive = Path(json.loads(manifest.read_text())['runtime_object'])
        artifacts[str(archive)] = sha(archive)
    return {'core_source_sha256': core, 'core_descriptor_sha256': sha(WORK / 'full-source-v3.json'),
            'candidate37': files(WORK / 'selected-ast'), 'control37': files(ROOT / '.tmp-lox-round3/ast'),
            'compiler_prefixes_sha256': prefixes, 'artifacts_sha256': artifacts}
