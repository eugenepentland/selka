from pathlib import Path
import os,subprocess,json,hashlib
r=Path.cwd();w=r/'.tmp-rc/loop-guard-pc';after=r/'.tmp-rc/install-loop-guard-pc/bin/mylang';e={k:v for k,v in os.environ.items() if not k.startswith('MYLANG_')};e['TMPDIR']=str(r/'.tmp-rc/tmp')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();d={'after_compiler':{'path':str(after),'sha256':sha(after)},'emission':[],'runs':[]}
def save():(w/'results.json').write_text(json.dumps(d,indent=2)+'\n')
for case,before in [('dict_count',r/'.tmp-rc/install-dict-empty-final/bin/mylang'),('bytes_scan',r.parent/'d9-rc-bytes-read/.tmp-bytes/install-final/bin/mylang')]:
 source=r/'bench/parity/micro'/(case+'.my');texts=[]
 for side,c in [('before',before),('after',after)]:
  cmd=[str(r/'scripts/build-slot.sh'),'build',str(c),'emit-qbe',str(source),'--rc-runtime','--drop-step-checks','--drop-frame-checks','--drop-debug'];p=subprocess.run(cmd,env=e,text=True,capture_output=True);row=dict(case=case,side=side,compiler=str(c),compiler_sha256=sha(c),source_sha256=sha(source),command=cmd,status=p.returncode,stderr=p.stderr);d['emission'].append(row);save();assert not p.returncode,row
  (w/(case+'-'+side+'.json')).write_text(p.stdout);m=json.loads(p.stdout);text=next(f['il'] for f in m['functions'] if f['name']=='main');(w/(case+'-'+side+'.ssa')).write_text(text);texts.append(text);row['il_sha256']=hashlib.sha256(text.encode()).hexdigest();save()
 assert texts[0]==texts[1],case
 print('exact independent IL comparison',case,'pass',flush=True)
source=r/'tests/lang/rc_loop_guard_context.my';cmd=[str(r/'scripts/build-slot.sh'),'build',str(after),'emit-qbe',str(source),'--rc-runtime','--drop-step-checks','--drop-frame-checks','--drop-debug'];p=subprocess.run(cmd,env=e,text=True,capture_output=True);assert not p.returncode,p.stderr;(w/'adjacent-emission.json').write_text(p.stdout);m=json.loads(p.stdout);il=next(f['il'] for f in m['functions'] if f['name']=='adjacent');(w/'adjacent.ssa').write_text(il);d['adjacent']={'command':cmd,'source_sha256':sha(source),'dictionary_drops':il.count('RC-DICTIONARY-EMPTY-DROPS-1'),'byte_guards':il.count('RC-READ-BYTES-VERSION-1')};save();assert d['adjacent']['dictionary_drops']==5 and d['adjacent']['byte_guards']==1,d['adjacent']
for backend in ['qbe','llvm']:
 for mode in ['gc','rc']:
  b=w/(backend+'-'+mode);cmd=[str(r/'scripts/build-slot.sh'),'build',str(after),'build',str(source),'--mode=ReleaseFast','--backend='+backend,'-o',str(b),'--cache-dir='+str(w/'guest-cache')]
  if backend=='llvm':cmd+=['--llvm-opt=3','--lto=full']
  if mode=='rc':cmd+=['--rc-runtime=stats']
  p=subprocess.run(cmd,env=e,text=True,capture_output=True);row=dict(backend=backend,mode=mode,build=cmd,build_status=p.returncode,build_stderr=p.stderr);d['runs'].append(row);save();assert not p.returncode,row
  manifest=json.loads(Path(str(b)+'.qbe-manifest.json').read_text());assert manifest['backend']==backend;row['manifest']=manifest;row['binary_sha256']=sha(b)
  p=subprocess.run([str(b)],env=e,text=True,capture_output=True,timeout=60);row.update(status=p.returncode,stdout=p.stdout,stderr=p.stderr);save();assert not p.returncode and p.stdout=='220\n',row
  if mode=='rc':
   c=json.loads(next(x.removeprefix('MYLANG_RC_COUNTS ') for x in p.stderr.splitlines() if x.startswith('MYLANG_RC_COUNTS ')));row['counts']=c;assert c['heap_allocate']==c['retire'] and c['owner_acquire']+c['heap_allocate']==c['owner_release'] and c['hold_acquire']==c['hold_release'],c;save()
  print('adjacent',backend,mode,'pass',flush=True)
