
/home/epentland/ai/canopy/mylang-worktrees/goal110-equality-bounded-20261004/.mylang-cache/goal110-equality-bounded-rf/runner/bin/text-my-llvm:     file format elf64-x86-64


Disassembly of section .text:

0000000001094ca0 <join_short>:
 1094ca0:	test   %rdx,%rdx
 1094ca3:	je     109523a <join_short+0x59a>
 1094ca9:	push   %rbp
 1094caa:	mov    %rsp,%rbp
 1094cad:	push   %rbx
 1094cae:	cmp    $0x8,%r8
 1094cb2:	jb     1094d04 <join_short+0x64>
 1094cb4:	mov    (%rcx),%rax
 1094cb7:	mov    -0x8(%rcx,%r8,1),%rcx
 1094cbc:	mov    (%rsi),%r10
 1094cbf:	mov    0x8(%r10),%r9
 1094cc3:	test   %r9,%r9
 1094cc6:	je     1094ddd <join_short+0x13d>
 1094ccc:	testb  $0x4,0x10(%r10)
 1094cd1:	jne    1094db4 <join_short+0x114>
 1094cd7:	add    $0x18,%r10
 1094cdb:	cmp    $0x7,%r9
 1094cdf:	ja     1094dcd <join_short+0x12d>
 1094ce5:	cmp    $0x3,%r9
 1094ce9:	jbe    1094ed3 <join_short+0x233>
 1094cef:	mov    (%r10),%r11d
 1094cf2:	mov    -0x4(%r10,%r9,1),%r10d
 1094cf7:	mov    %r11d,(%rdi)
 1094cfa:	mov    %r10d,-0x4(%rdi,%r9,1)
 1094cff:	jmp    1094ddd <join_short+0x13d>
 1094d04:	cmp    $0x4,%r8
 1094d08:	jb     1094d59 <join_short+0xb9>
 1094d0a:	mov    (%rcx),%eax
 1094d0c:	mov    -0x4(%rcx,%r8,1),%ecx
 1094d11:	mov    (%rsi),%r10
 1094d14:	mov    0x8(%r10),%r9
 1094d18:	test   %r9,%r9
 1094d1b:	je     1094f12 <join_short+0x272>
 1094d21:	testb  $0x4,0x10(%r10)
 1094d26:	jne    1094ee9 <join_short+0x249>
 1094d2c:	add    $0x18,%r10
 1094d30:	cmp    $0x7,%r9
 1094d34:	ja     1094f02 <join_short+0x262>
 1094d3a:	cmp    $0x3,%r9
 1094d3e:	jbe    1095075 <join_short+0x3d5>
 1094d44:	mov    (%r10),%r11d
 1094d47:	mov    -0x4(%r10,%r9,1),%r10d
 1094d4c:	mov    %r11d,(%rdi)
 1094d4f:	mov    %r10d,-0x4(%rdi,%r9,1)
 1094d54:	jmp    1094f12 <join_short+0x272>
 1094d59:	cmp    $0x2,%r8
 1094d5d:	jb     1094ea3 <join_short+0x203>
 1094d63:	movzwl (%rcx),%eax
 1094d66:	movzwl -0x2(%rcx,%r8,1),%ecx
 1094d6c:	mov    (%rsi),%r10
 1094d6f:	mov    0x8(%r10),%r9
 1094d73:	test   %r9,%r9
 1094d76:	je     10950b4 <join_short+0x414>
 1094d7c:	testb  $0x4,0x10(%r10)
 1094d81:	jne    109508b <join_short+0x3eb>
 1094d87:	add    $0x18,%r10
 1094d8b:	cmp    $0x7,%r9
 1094d8f:	ja     10950a4 <join_short+0x404>
 1094d95:	cmp    $0x3,%r9
 1094d99:	jbe    10951cb <join_short+0x52b>
 1094d9f:	mov    (%r10),%r11d
 1094da2:	mov    -0x4(%r10,%r9,1),%r10d
 1094da7:	mov    %r11d,(%rdi)
 1094daa:	mov    %r10d,-0x4(%rdi,%r9,1)
 1094daf:	jmp    10950b4 <join_short+0x414>
 1094db4:	mov    0x18(%r10),%r11
 1094db8:	mov    0x14(%r10),%r10d
 1094dbc:	add    %r11,%r10
 1094dbf:	add    $0x18,%r10
 1094dc3:	cmp    $0x7,%r9
 1094dc7:	jbe    1094ce5 <join_short+0x45>
 1094dcd:	mov    (%r10),%r11
 1094dd0:	mov    -0x8(%r10,%r9,1),%r10
 1094dd5:	mov    %r11,(%rdi)
 1094dd8:	mov    %r10,-0x8(%rdi,%r9,1)
 1094ddd:	cmp    $0x1,%rdx
 1094de1:	je     1095238 <join_short+0x598>
 1094de7:	add    %r9,%rdi
 1094dea:	mov    $0x1,%r9d
 1094df0:	jmp    1094e1f <join_short+0x17f>
 1094df2:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1094e00:	mov    (%r11),%rbx
 1094e03:	mov    -0x8(%r11,%r10,1),%r11
 1094e08:	mov    %rbx,(%rdi)
 1094e0b:	mov    %r11,-0x8(%rdi,%r10,1)
 1094e10:	add    %r10,%rdi
 1094e13:	inc    %r9
 1094e16:	cmp    %r9,%rdx
 1094e19:	je     1095238 <join_short+0x598>
 1094e1f:	mov    %rax,(%rdi)
 1094e22:	mov    %rcx,-0x8(%rdi,%r8,1)
 1094e27:	add    %r8,%rdi
 1094e2a:	mov    (%rsi,%r9,8),%r11
 1094e2e:	mov    0x8(%r11),%r10
 1094e32:	test   %r10,%r10
 1094e35:	je     1094e10 <join_short+0x170>
 1094e37:	testb  $0x4,0x10(%r11)
 1094e3c:	jne    1094e50 <join_short+0x1b0>
 1094e3e:	add    $0x18,%r11
 1094e42:	cmp    $0x8,%r10
 1094e46:	jae    1094e00 <join_short+0x160>
 1094e48:	jmp    1094e65 <join_short+0x1c5>
 1094e4a:	nopw   0x0(%rax,%rax,1)
 1094e50:	mov    0x18(%r11),%rbx
 1094e54:	mov    0x14(%r11),%r11d
 1094e58:	add    %rbx,%r11
 1094e5b:	add    $0x18,%r11
 1094e5f:	cmp    $0x8,%r10
 1094e63:	jae    1094e00 <join_short+0x160>
 1094e65:	cmp    $0x4,%r10
 1094e69:	jb     1094e7c <join_short+0x1dc>
 1094e6b:	mov    (%r11),%ebx
 1094e6e:	mov    -0x4(%r11,%r10,1),%r11d
 1094e73:	mov    %ebx,(%rdi)
 1094e75:	mov    %r11d,-0x4(%rdi,%r10,1)
 1094e7a:	jmp    1094e10 <join_short+0x170>
 1094e7c:	cmp    $0x1,%r10
 1094e80:	jne    1094e8b <join_short+0x1eb>
 1094e82:	movzbl (%r11),%r11d
 1094e86:	mov    %r11b,(%rdi)
 1094e89:	jmp    1094e10 <join_short+0x170>
 1094e8b:	movzwl (%r11),%ebx
 1094e8f:	movzwl -0x2(%r11,%r10,1),%r11d
 1094e95:	mov    %bx,(%rdi)
 1094e98:	mov    %r11w,-0x2(%rdi,%r10,1)
 1094e9e:	jmp    1094e10 <join_short+0x170>
 1094ea3:	test   %r8,%r8
 1094ea6:	je     1094fd3 <join_short+0x333>
 1094eac:	movzbl (%rcx),%eax
 1094eaf:	mov    (%rsi),%r8
 1094eb2:	mov    0x8(%r8),%rcx
 1094eb6:	test   %rcx,%rcx
 1094eb9:	je     1095232 <join_short+0x592>
 1094ebf:	testb  $0x4,0x10(%r8)
 1094ec4:	jne    109518c <join_short+0x4ec>
 1094eca:	add    $0x18,%r8
 1094ece:	jmp    109519b <join_short+0x4fb>
 1094ed3:	cmp    $0x1,%r9
 1094ed7:	jne    1095173 <join_short+0x4d3>
 1094edd:	movzbl (%r10),%r10d
 1094ee1:	mov    %r10b,(%rdi)
 1094ee4:	jmp    1094ddd <join_short+0x13d>
 1094ee9:	mov    0x18(%r10),%r11
 1094eed:	mov    0x14(%r10),%r10d
 1094ef1:	add    %r11,%r10
 1094ef4:	add    $0x18,%r10
 1094ef8:	cmp    $0x7,%r9
 1094efc:	jbe    1094d3a <join_short+0x9a>
 1094f02:	mov    (%r10),%r11
 1094f05:	mov    -0x8(%r10,%r9,1),%r10
 1094f0a:	mov    %r11,(%rdi)
 1094f0d:	mov    %r10,-0x8(%rdi,%r9,1)
 1094f12:	cmp    $0x1,%rdx
 1094f16:	je     1095238 <join_short+0x598>
 1094f1c:	add    %r9,%rdi
 1094f1f:	mov    $0x1,%r9d
 1094f25:	jmp    1094f4f <join_short+0x2af>
 1094f27:	nopw   0x0(%rax,%rax,1)
 1094f30:	mov    (%r11),%rbx
 1094f33:	mov    -0x8(%r11,%r10,1),%r11
 1094f38:	mov    %rbx,(%rdi)
 1094f3b:	mov    %r11,-0x8(%rdi,%r10,1)
 1094f40:	add    %r10,%rdi
 1094f43:	inc    %r9
 1094f46:	cmp    %r9,%rdx
 1094f49:	je     1095238 <join_short+0x598>
 1094f4f:	mov    %eax,(%rdi)
 1094f51:	mov    %ecx,-0x4(%rdi,%r8,1)
 1094f56:	add    %r8,%rdi
 1094f59:	mov    (%rsi,%r9,8),%r11
 1094f5d:	mov    0x8(%r11),%r10
 1094f61:	test   %r10,%r10
 1094f64:	je     1094f40 <join_short+0x2a0>
 1094f66:	testb  $0x4,0x10(%r11)
 1094f6b:	jne    1094f80 <join_short+0x2e0>
 1094f6d:	add    $0x18,%r11
 1094f71:	cmp    $0x8,%r10
 1094f75:	jae    1094f30 <join_short+0x290>
 1094f77:	jmp    1094f95 <join_short+0x2f5>
 1094f79:	nopl   0x0(%rax)
 1094f80:	mov    0x18(%r11),%rbx
 1094f84:	mov    0x14(%r11),%r11d
 1094f88:	add    %rbx,%r11
 1094f8b:	add    $0x18,%r11
 1094f8f:	cmp    $0x8,%r10
 1094f93:	jae    1094f30 <join_short+0x290>
 1094f95:	cmp    $0x4,%r10
 1094f99:	jb     1094fac <join_short+0x30c>
 1094f9b:	mov    (%r11),%ebx
 1094f9e:	mov    -0x4(%r11,%r10,1),%r11d
 1094fa3:	mov    %ebx,(%rdi)
 1094fa5:	mov    %r11d,-0x4(%rdi,%r10,1)
 1094faa:	jmp    1094f40 <join_short+0x2a0>
 1094fac:	cmp    $0x1,%r10
 1094fb0:	jne    1094fbb <join_short+0x31b>
 1094fb2:	movzbl (%r11),%r11d
 1094fb6:	mov    %r11b,(%rdi)
 1094fb9:	jmp    1094f40 <join_short+0x2a0>
 1094fbb:	movzwl (%r11),%ebx
 1094fbf:	movzwl -0x2(%r11,%r10,1),%r11d
 1094fc5:	mov    %bx,(%rdi)
 1094fc8:	mov    %r11w,-0x2(%rdi,%r10,1)
 1094fce:	jmp    1094f40 <join_short+0x2a0>
 1094fd3:	xor    %eax,%eax
 1094fd5:	jmp    1094fff <join_short+0x35f>
 1094fd7:	nopw   0x0(%rax,%rax,1)
 1094fe0:	mov    (%r8),%r9
 1094fe3:	mov    -0x8(%r8,%rcx,1),%r8
 1094fe8:	mov    %r9,(%rdi)
 1094feb:	mov    %r8,-0x8(%rdi,%rcx,1)
 1094ff0:	add    %rcx,%rdi
 1094ff3:	inc    %rax
 1094ff6:	cmp    %rax,%rdx
 1094ff9:	je     1095238 <join_short+0x598>
 1094fff:	mov    (%rsi,%rax,8),%r8
 1095003:	mov    0x8(%r8),%rcx
 1095007:	test   %rcx,%rcx
 109500a:	je     1094ff0 <join_short+0x350>
 109500c:	testb  $0x4,0x10(%r8)
 1095011:	jne    1095020 <join_short+0x380>
 1095013:	add    $0x18,%r8
 1095017:	cmp    $0x8,%rcx
 109501b:	jae    1094fe0 <join_short+0x340>
 109501d:	jmp    1095035 <join_short+0x395>
 109501f:	nop
 1095020:	mov    0x18(%r8),%r9
 1095024:	mov    0x14(%r8),%r8d
 1095028:	add    %r9,%r8
 109502b:	add    $0x18,%r8
 109502f:	cmp    $0x8,%rcx
 1095033:	jae    1094fe0 <join_short+0x340>
 1095035:	cmp    $0x4,%rcx
 1095039:	jb     109504d <join_short+0x3ad>
 109503b:	mov    (%r8),%r9d
 109503e:	mov    -0x4(%r8,%rcx,1),%r8d
 1095043:	mov    %r9d,(%rdi)
 1095046:	mov    %r8d,-0x4(%rdi,%rcx,1)
 109504b:	jmp    1094ff0 <join_short+0x350>
 109504d:	cmp    $0x1,%rcx
 1095051:	jne    109505c <join_short+0x3bc>
 1095053:	movzbl (%r8),%r8d
 1095057:	mov    %r8b,(%rdi)
 109505a:	jmp    1094ff0 <join_short+0x350>
 109505c:	movzwl (%r8),%r9d
 1095060:	movzwl -0x2(%r8,%rcx,1),%r8d
 1095066:	mov    %r9w,(%rdi)
 109506a:	mov    %r8w,-0x2(%rdi,%rcx,1)
 1095070:	jmp    1094ff0 <join_short+0x350>
 1095075:	cmp    $0x1,%r9
 1095079:	jne    10951dd <join_short+0x53d>
 109507f:	movzbl (%r10),%r10d
 1095083:	mov    %r10b,(%rdi)
 1095086:	jmp    1094f12 <join_short+0x272>
 109508b:	mov    0x18(%r10),%r11
 109508f:	mov    0x14(%r10),%r10d
 1095093:	add    %r11,%r10
 1095096:	add    $0x18,%r10
 109509a:	cmp    $0x7,%r9
 109509e:	jbe    1094d95 <join_short+0xf5>
 10950a4:	mov    (%r10),%r11
 10950a7:	mov    -0x8(%r10,%r9,1),%r10
 10950ac:	mov    %r11,(%rdi)
 10950af:	mov    %r10,-0x8(%rdi,%r9,1)
 10950b4:	cmp    $0x1,%rdx
 10950b8:	je     1095238 <join_short+0x598>
 10950be:	add    %r9,%rdi
 10950c1:	mov    $0x1,%r9d
 10950c7:	jmp    10950ef <join_short+0x44f>
 10950c9:	nopl   0x0(%rax)
 10950d0:	mov    (%r11),%rbx
 10950d3:	mov    -0x8(%r11,%r10,1),%r11
 10950d8:	mov    %rbx,(%rdi)
 10950db:	mov    %r11,-0x8(%rdi,%r10,1)
 10950e0:	add    %r10,%rdi
 10950e3:	inc    %r9
 10950e6:	cmp    %r9,%rdx
 10950e9:	je     1095238 <join_short+0x598>
 10950ef:	mov    %ax,(%rdi)
 10950f2:	mov    %cx,-0x2(%rdi,%r8,1)
 10950f8:	add    %r8,%rdi
 10950fb:	mov    (%rsi,%r9,8),%r11
 10950ff:	mov    0x8(%r11),%r10
 1095103:	test   %r10,%r10
 1095106:	je     10950e0 <join_short+0x440>
 1095108:	testb  $0x4,0x10(%r11)
 109510d:	jne    1095120 <join_short+0x480>
 109510f:	add    $0x18,%r11
 1095113:	cmp    $0x8,%r10
 1095117:	jae    10950d0 <join_short+0x430>
 1095119:	jmp    1095135 <join_short+0x495>
 109511b:	nopl   0x0(%rax,%rax,1)
 1095120:	mov    0x18(%r11),%rbx
 1095124:	mov    0x14(%r11),%r11d
 1095128:	add    %rbx,%r11
 109512b:	add    $0x18,%r11
 109512f:	cmp    $0x8,%r10
 1095133:	jae    10950d0 <join_short+0x430>
 1095135:	cmp    $0x4,%r10
 1095139:	jb     109514c <join_short+0x4ac>
 109513b:	mov    (%r11),%ebx
 109513e:	mov    -0x4(%r11,%r10,1),%r11d
 1095143:	mov    %ebx,(%rdi)
 1095145:	mov    %r11d,-0x4(%rdi,%r10,1)
 109514a:	jmp    10950e0 <join_short+0x440>
 109514c:	cmp    $0x1,%r10
 1095150:	jne    109515b <join_short+0x4bb>
 1095152:	movzbl (%r11),%r11d
 1095156:	mov    %r11b,(%rdi)
 1095159:	jmp    10950e0 <join_short+0x440>
 109515b:	movzwl (%r11),%ebx
 109515f:	movzwl -0x2(%r11,%r10,1),%r11d
 1095165:	mov    %bx,(%rdi)
 1095168:	mov    %r11w,-0x2(%rdi,%r10,1)
 109516e:	jmp    10950e0 <join_short+0x440>
 1095173:	movzwl (%r10),%r11d
 1095177:	movzwl -0x2(%r10,%r9,1),%r10d
 109517d:	mov    %r11w,(%rdi)
 1095181:	mov    %r10w,-0x2(%rdi,%r9,1)
 1095187:	jmp    1094ddd <join_short+0x13d>
 109518c:	mov    0x18(%r8),%r9
 1095190:	mov    0x14(%r8),%r8d
 1095194:	add    %r9,%r8
 1095197:	add    $0x18,%r8
 109519b:	cmp    $0x7,%rcx
 109519f:	jbe    10951b3 <join_short+0x513>
 10951a1:	mov    (%r8),%r9
 10951a4:	mov    -0x8(%r8,%rcx,1),%r8
 10951a9:	mov    %r9,(%rdi)
 10951ac:	mov    %r8,-0x8(%rdi,%rcx,1)
 10951b1:	jmp    1095232 <join_short+0x592>
 10951b3:	cmp    $0x3,%rcx
 10951b7:	jbe    10951f6 <join_short+0x556>
 10951b9:	mov    (%r8),%r9d
 10951bc:	mov    -0x4(%r8,%rcx,1),%r8d
 10951c1:	mov    %r9d,(%rdi)
 10951c4:	mov    %r8d,-0x4(%rdi,%rcx,1)
 10951c9:	jmp    1095232 <join_short+0x592>
 10951cb:	cmp    $0x1,%r9
 10951cf:	jne    1095205 <join_short+0x565>
 10951d1:	movzbl (%r10),%r10d
 10951d5:	mov    %r10b,(%rdi)
 10951d8:	jmp    10950b4 <join_short+0x414>
 10951dd:	movzwl (%r10),%r11d
 10951e1:	movzwl -0x2(%r10,%r9,1),%r10d
 10951e7:	mov    %r11w,(%rdi)
 10951eb:	mov    %r10w,-0x2(%rdi,%r9,1)
 10951f1:	jmp    1094f12 <join_short+0x272>
 10951f6:	cmp    $0x1,%rcx
 10951fa:	jne    109521e <join_short+0x57e>
 10951fc:	movzbl (%r8),%r8d
 1095200:	mov    %r8b,(%rdi)
 1095203:	jmp    1095232 <join_short+0x592>
 1095205:	movzwl (%r10),%r11d
 1095209:	movzwl -0x2(%r10,%r9,1),%r10d
 109520f:	mov    %r11w,(%rdi)
 1095213:	mov    %r10w,-0x2(%rdi,%r9,1)
 1095219:	jmp    10950b4 <join_short+0x414>
 109521e:	movzwl (%r8),%r9d
 1095222:	movzwl -0x2(%r8,%rcx,1),%r8d
 1095228:	mov    %r9w,(%rdi)
 109522c:	mov    %r8w,-0x2(%rdi,%rcx,1)
 1095232:	cmp    $0x1,%rdx
 1095236:	jne    109523b <join_short+0x59b>
 1095238:	pop    %rbx
 1095239:	pop    %rbp
 109523a:	ret
 109523b:	add    %rcx,%rdi
 109523e:	mov    $0x1,%ecx
 1095243:	jmp    109526b <join_short+0x5cb>
 1095245:	data16 cs nopw 0x0(%rax,%rax,1)
 1095250:	mov    (%r9),%r10
 1095253:	mov    -0x8(%r9,%r8,1),%r9
 1095258:	mov    %r10,(%rdi)
 109525b:	mov    %r9,-0x8(%rdi,%r8,1)
 1095260:	add    %r8,%rdi
 1095263:	inc    %rcx
 1095266:	cmp    %rcx,%rdx
 1095269:	je     1095238 <join_short+0x598>
 109526b:	mov    %al,(%rdi)
 109526d:	inc    %rdi
 1095270:	mov    (%rsi,%rcx,8),%r9
 1095274:	mov    0x8(%r9),%r8
 1095278:	test   %r8,%r8
 109527b:	je     1095260 <join_short+0x5c0>
 109527d:	testb  $0x4,0x10(%r9)
 1095282:	jne    1095290 <join_short+0x5f0>
 1095284:	add    $0x18,%r9
 1095288:	cmp    $0x8,%r8
 109528c:	jae    1095250 <join_short+0x5b0>
 109528e:	jmp    10952a5 <join_short+0x605>
 1095290:	mov    0x18(%r9),%r10
 1095294:	mov    0x14(%r9),%r9d
 1095298:	add    %r10,%r9
 109529b:	add    $0x18,%r9
 109529f:	cmp    $0x8,%r8
 10952a3:	jae    1095250 <join_short+0x5b0>
 10952a5:	cmp    $0x4,%r8
 10952a9:	jb     10952bd <join_short+0x61d>
 10952ab:	mov    (%r9),%r10d
 10952ae:	mov    -0x4(%r9,%r8,1),%r9d
 10952b3:	mov    %r10d,(%rdi)
 10952b6:	mov    %r9d,-0x4(%rdi,%r8,1)
 10952bb:	jmp    1095260 <join_short+0x5c0>
 10952bd:	cmp    $0x1,%r8
 10952c1:	jne    10952cc <join_short+0x62c>
 10952c3:	movzbl (%r9),%r9d
 10952c7:	mov    %r9b,(%rdi)
 10952ca:	jmp    1095260 <join_short+0x5c0>
 10952cc:	movzwl (%r9),%r10d
 10952d0:	movzwl -0x2(%r9,%r8,1),%r9d
 10952d6:	mov    %r10w,(%rdi)
 10952da:	mov    %r9w,-0x2(%rdi,%r8,1)
 10952e0:	jmp    1095260 <join_short+0x5c0>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
