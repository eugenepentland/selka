
/home/epentland/ai/canopy/mylang-worktrees/goal110-equality-bounded-20261004/.mylang-cache/goal110-equality-bounded-rf/runner/bin/text-my-llvm:     file format elf64-x86-64


Disassembly of section .text:

000000000104e7d0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76>:
 104e7d0:	push   %rbp
 104e7d1:	push   %r15
 104e7d3:	push   %r14
 104e7d5:	push   %r13
 104e7d7:	push   %r12
 104e7d9:	push   %rbx
 104e7da:	sub    $0x268,%rsp
 104e7e1:	mov    %r8,0x10(%rsp)
 104e7e6:	mov    %rcx,0x28(%rsp)
 104e7eb:	mov    %rdi,0x8(%rsp)
 104e7f0:	cmp    %rsp,0x40(%rdi)
 104e7f4:	ja     1052373 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3ba3>
 104e7fa:	mov    %rdx,%r15
 104e7fd:	movq   $0x0,0xb0(%rsp)
 104e809:	movq   $0x0,0xa8(%rsp)
 104e815:	mov    0x8(%rsp),%rax
 104e81a:	mov    0x2c8(%rax),%eax
 104e820:	mov    %eax,0x44(%rsp)
 104e824:	movq   $0x10bc6b0,0x38(%rsp)
 104e82d:	movq   $0x10bc6b0,0x78(%rsp)
 104e836:	cmp    $0x10bc6b0,%rsi
 104e83d:	jne    104e846 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x76>
 104e83f:	xor    %ebx,%ebx
 104e841:	jmp    104e966 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x196>
 104e846:	mov    $0x1,%bl
 104e848:	test   %rsi,%rsi
 104e84b:	je     104e966 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x196>
 104e851:	mov    0x8(%rsi),%rdx
 104e855:	cmp    0x6de5c(%rip),%rdx        # 10bc6b8 <myl_lit_d666bf92bda1d63f03bf95c09e1bffde05f85315fdade322db024e5b0244b85a_instance+0x18>
 104e85c:	jne    104e966 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x196>
 104e862:	test   %rdx,%rdx
 104e865:	je     104e83f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x6f>
 104e867:	testb  $0x4,0x10(%rsi)
 104e86b:	jne    104e873 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xa3>
 104e86d:	lea    0x18(%rsi),%rdi
 104e871:	jmp    104e882 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xb2>
 104e873:	mov    0x18(%rsi),%rax
 104e877:	mov    0x14(%rsi),%ecx
 104e87a:	lea    (%rax,%rcx,1),%rdi
 104e87e:	add    $0x18,%rdi
 104e882:	testb  $0x4,0x6de37(%rip)        # 10bc6c0 <myl_lit_d666bf92bda1d63f03bf95c09e1bffde05f85315fdade322db024e5b0244b85a_instance+0x20>
 104e889:	mov    0x6de38(%rip),%rax        # 10bc6c8 <myl_lit_d666bf92bda1d63f03bf95c09e1bffde05f85315fdade322db024e5b0244b85a_instance+0x28>
 104e890:	mov    0x6de2e(%rip),%ecx        # 10bc6c4 <myl_lit_d666bf92bda1d63f03bf95c09e1bffde05f85315fdade322db024e5b0244b85a_instance+0x24>
 104e896:	lea    0x18(%rax,%rcx,1),%rcx
 104e89b:	mov    $0x10bc6c8,%eax
 104e8a0:	cmovne %rcx,%rax
 104e8a4:	cmp    $0x10,%rdx
 104e8a8:	ja     104e8c5 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xf5>
 104e8aa:	cmp    $0x8,%rdx
 104e8ae:	jb     104e8ef <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x11f>
 104e8b0:	mov    (%rdi),%rcx
 104e8b3:	mov    -0x8(%rdi,%rdx,1),%rdi
 104e8b8:	xor    (%rax),%rcx
 104e8bb:	xor    -0x8(%rax,%rdx,1),%rdi
 104e8c0:	or     %rcx,%rdi
 104e8c3:	jmp    104e940 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x170>
 104e8c5:	cmp    $0x40,%rdx
 104e8c9:	ja     104e905 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x135>
 104e8cb:	vmovdqu (%rdi),%xmm0
 104e8cf:	cmp    $0x20,%rdx
 104e8d3:	ja     104e920 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x150>
 104e8d5:	vinserti128 $0x1,-0x10(%rdi,%rdx,1),%ymm0,%ymm0
 104e8dd:	vmovdqu (%rax),%xmm1
 104e8e1:	vinserti128 $0x1,-0x10(%rax,%rdx,1),%ymm1,%ymm1
 104e8e9:	vpxor  %ymm1,%ymm0,%ymm0
 104e8ed:	jmp    104e93b <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x16b>
 104e8ef:	cmp    $0x4,%rdx
 104e8f3:	jb     104e948 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x178>
 104e8f5:	mov    (%rdi),%ecx
 104e8f7:	mov    -0x4(%rdi,%rdx,1),%edi
 104e8fb:	xor    (%rax),%ecx
 104e8fd:	xor    -0x4(%rax,%rdx,1),%edi
 104e901:	or     %ecx,%edi
 104e903:	jmp    104e940 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x170>
 104e905:	mov    %rsi,%r14
 104e908:	mov    %rax,%rsi
 104e90b:	cmp    $0x100,%rdx
 104e912:	ja     104e959 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x189>
 104e914:	call   10ae350 <bcmp@plt>
 104e919:	test   %eax,%eax
 104e91b:	setne  %bl
 104e91e:	jmp    104e963 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x193>
 104e920:	vmovdqu -0x20(%rdi,%rdx,1),%ymm1
 104e926:	vinserti128 $0x1,0x10(%rdi),%ymm0,%ymm0
 104e92d:	vpxor  -0x20(%rax,%rdx,1),%ymm1,%ymm1
 104e933:	vpxor  (%rax),%ymm0,%ymm0
 104e937:	vpor   %ymm1,%ymm0,%ymm0
 104e93b:	vptest %ymm0,%ymm0
 104e940:	sete   %bl
 104e943:	xor    $0x1,%bl
 104e946:	jmp    104e966 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x196>
 104e948:	cmp    $0x1,%rdx
 104e94c:	jne    104f0c9 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x8f9>
 104e952:	movzbl (%rdi),%ecx
 104e955:	cmp    (%rax),%cl
 104e957:	jmp    104e940 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x170>
 104e959:	call   10943e0 <equal_large_octets>
 104e95e:	test   %eax,%eax
 104e960:	sete   %bl
 104e963:	mov    %r14,%rsi
 104e966:	mov    0x8(%rsp),%rax
 104e96b:	add    $0x258,%rax
 104e971:	mov    %rax,0x18(%rsp)
 104e976:	movabs $0x4000000000000002,%r13
 104e980:	test   %r13,0x6dd19(%rip)        # 10bc6a0 <myl_lit_d666bf92bda1d63f03bf95c09e1bffde05f85315fdade322db024e5b0244b85a_instance>
 104e987:	je     104e9dd <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x20d>
 104e989:	movq   $0x0,0xd0(%rsp)
 104e995:	test   %bl,%bl
 104e997:	mov    %r15,0x30(%rsp)
 104e99c:	je     104ea13 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x243>
 104e99e:	movq   $0x10bc1c0,0x38(%rsp)
 104e9a7:	movq   $0x10bc1c0,0x78(%rsp)
 104e9b0:	movq   $0x10bc1c0,0xd0(%rsp)
 104e9bc:	cmp    $0x10bc1c0,%rsi
 104e9c3:	jne    104ef92 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x7c2>
 104e9c9:	xor    %ebx,%ebx
 104e9cb:	test   %r13,0x6d7de(%rip)        # 10bc1b0 <myl_lit_8c12e724a44132b907ad7be4d7bffd05d284ce5c644f94f5ab8dbc188941e631_instance>
 104e9d2:	jne    104f131 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x961>
 104e9d8:	jmp    104f110 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x940>
 104e9dd:	mov    0x6dcac(%rip),%rax        # 10bc690 <myl_lit_d3cafad273dd497c488894ca58a5701d146f3969ca50fbb18df3109543cd07e8_instance+0x60>
 104e9e4:	dec    %rax
 104e9e7:	jne    104e9f7 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x227>
 104e9e9:	cmpq   $0x0,0x6dca7(%rip)        # 10bc698 <myl_lit_d3cafad273dd497c488894ca58a5701d146f3969ca50fbb18df3109543cd07e8_instance+0x68>
 104e9f1:	je     104efc3 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x7f3>
 104e9f7:	mov    %rax,0x6dc92(%rip)        # 10bc690 <myl_lit_d3cafad273dd497c488894ca58a5701d146f3969ca50fbb18df3109543cd07e8_instance+0x60>
 104e9fe:	movq   $0x0,0xd0(%rsp)
 104ea0a:	test   %bl,%bl
 104ea0c:	mov    %r15,0x30(%rsp)
 104ea11:	jne    104e99e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1ce>
 104ea13:	xor    %eax,%eax
 104ea15:	movabs $0x89705f3112a28fe5,%r15
 104ea1f:	movabs $0xffffffffffffff0,%rbp
 104ea29:	vpxor  %xmm11,%xmm11,%xmm11
 104ea2e:	vmovd  -0x4d096(%rip),%xmm12        # 10019a0 <__abi_tag+0x16a4>
 104ea36:	vmovd  -0x4d04e(%rip),%xmm13        # 10019f0 <__abi_tag+0x16f4>
 104ea3e:	vmovd  -0x4d0c6(%rip),%xmm14        # 1001980 <__abi_tag+0x1684>
 104ea46:	vmovd  -0x4d12e(%rip),%xmm15        # 1001920 <__abi_tag+0x1624>
 104ea4e:	xor    %r14d,%r14d
 104ea51:	movabs $0x4000000000000002,%r13
 104ea5b:	nopl   0x0(%rax,%rax,1)
 104ea60:	mov    0x10(%rsp),%rdx
 104ea65:	add    %r14,%rdx
 104ea68:	jo     1052243 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3a73>
 104ea6e:	mov    %rax,%r12
 104ea71:	mov    0x30(%rsp),%rax
 104ea76:	mov    (%rax),%rsi
 104ea79:	mov    -0x10(%rsi),%rax
 104ea7d:	test   %r13,%rax
 104ea80:	jne    104ea93 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2c3>
 104ea82:	mov    -0x18(%rsi),%rcx
 104ea86:	inc    %rcx
 104ea89:	je     104ef54 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x784>
 104ea8f:	mov    %rcx,-0x18(%rsi)
 104ea93:	movzbl %dl,%r8d
 104ea97:	mov    (%rsi),%rdi
 104ea9a:	lea    -0x10(%rdi),%r9
 104ea9e:	cmp    %rbp,%r9
 104eaa1:	ja     104eae0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x310>
 104eaa3:	mov    0x20(%rsi),%rcx
 104eaa7:	movabs $0x80808080808080,%r10
 104eab1:	cmp    %r10,%rdi
 104eab4:	ja     104eb10 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x340>
 104eab6:	vmovd  %edx,%xmm0
 104eaba:	vpbroadcastb %xmm0,%xmm0
 104eabf:	mov    %r9d,%r8d
 104eac2:	not    %r8d
 104eac5:	test   $0x30,%r8b
 104eac9:	jne    104ec48 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x478>
 104eacf:	vpxor  %xmm1,%xmm1,%xmm1
 104ead3:	jmp    104ec90 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x4c0>
 104ead8:	nopl   0x0(%rax,%rax,1)
 104eae0:	test   %rdi,%rdi
 104eae3:	jle    104ec41 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x471>
 104eae9:	mov    0x20(%rsi),%rcx
 104eaed:	cmp    $0x8,%rdi
 104eaf1:	jae    104eb10 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x340>
 104eaf3:	mov    $0x1,%r10d
 104eaf9:	xor    %r9d,%r9d
 104eafc:	xor    %edx,%edx
 104eafe:	xor    %ebx,%ebx
 104eb00:	jmp    104ebb7 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3e7>
 104eb05:	data16 cs nopw 0x0(%rax,%rax,1)
 104eb10:	mov    %rdi,%rdx
 104eb13:	and    $0xfffffffffffffff8,%rdx
 104eb17:	vmovq  %r8,%xmm0
 104eb1c:	vpbroadcastq %xmm0,%ymm3
 104eb21:	vpxor  %xmm2,%xmm2,%xmm2
 104eb25:	xor    %r9d,%r9d
 104eb28:	vpxor  %xmm4,%xmm4,%xmm4
 104eb2c:	vpxor  %xmm0,%xmm0,%xmm0
 104eb30:	vpxor  %xmm1,%xmm1,%xmm1
 104eb34:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 104eb40:	vpmovzxbq (%rcx,%r9,1),%ymm5
 104eb46:	vpmovzxbq 0x4(%rcx,%r9,1),%ymm6
 104eb4d:	vpxor  %ymm5,%ymm3,%ymm5
 104eb51:	vpxor  %ymm6,%ymm3,%ymm6
 104eb55:	vpaddq %ymm2,%ymm5,%ymm2
 104eb59:	vpaddq %ymm4,%ymm6,%ymm4
 104eb5d:	vpaddq %ymm0,%ymm5,%ymm0
 104eb61:	vpaddq %ymm1,%ymm6,%ymm1
 104eb65:	add    $0x8,%r9
 104eb69:	cmp    %r9,%rdx
 104eb6c:	jne    104eb40 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x370>
 104eb6e:	vpaddq %ymm2,%ymm4,%ymm2
 104eb72:	vextracti128 $0x1,%ymm2,%xmm3
 104eb78:	vpaddq %xmm3,%xmm2,%xmm2
 104eb7c:	vpshufd $0xee,%xmm2,%xmm3
 104eb81:	vpaddq %xmm3,%xmm2,%xmm2
 104eb85:	vmovq  %xmm2,%r9
 104eb8a:	vpaddq %ymm0,%ymm1,%ymm0
 104eb8e:	vextracti128 $0x1,%ymm0,%xmm1
 104eb94:	vpaddq %xmm1,%xmm0,%xmm0
 104eb98:	vpshufd $0xee,%xmm0,%xmm1
 104eb9d:	vpaddq %xmm1,%xmm0,%xmm0
 104eba1:	vmovq  %xmm0,%rbx
 104eba6:	cmp    %rdx,%rdi
 104eba9:	jne    104ebb0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3e0>
 104ebab:	mov    %rdi,%rcx
 104ebae:	jmp    104ebf6 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x426>
 104ebb0:	mov    %rdx,%r10
 104ebb3:	or     $0x1,%r10
 104ebb7:	add    %rdx,%rcx
 104ebba:	mov    %rdi,%r11
 104ebbd:	sub    %rdx,%r11
 104ebc0:	xor    %edx,%edx
 104ebc2:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 104ebd0:	movzbl (%rcx,%rdx,1),%ebp
 104ebd4:	xor    %r8,%rbp
 104ebd7:	add    %rbp,%r9
 104ebda:	add    %rbp,%rbx
 104ebdd:	inc    %rdx
 104ebe0:	cmp    %rdx,%r11
 104ebe3:	jne    104ebd0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x400>
 104ebe5:	lea    (%r10,%rdx,1),%rcx
 104ebe9:	dec    %rcx
 104ebec:	movabs $0xffffffffffffff0,%rbp
 104ebf6:	mov    $0xffffffff,%edx
 104ebfb:	cmp    %rdx,%rcx
 104ebfe:	setb   %cl
 104ec01:	test   %r9,%r9
 104ec04:	setns  %dl
 104ec07:	test   %dl,%cl
 104ec09:	jne    104eea0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x6d0>
 104ec0f:	mov    0x20(%rsi),%r9
 104ec13:	xor    %r10d,%r10d
 104ec16:	xor    %edx,%edx
 104ec18:	xor    %ebx,%ebx
 104ec1a:	nopw   0x0(%rax,%rax,1)
 104ec20:	movzbl (%r9,%r10,1),%ecx
 104ec25:	xor    %r8,%rcx
 104ec28:	add    %rcx,%rbx
 104ec2b:	jo     1052215 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3a45>
 104ec31:	inc    %r10
 104ec34:	mov    %rbx,%rdx
 104ec37:	cmp    %r10,%rdi
 104ec3a:	jne    104ec20 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x450>
 104ec3c:	jmp    104eea0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x6d0>
 104ec41:	xor    %ebx,%ebx
 104ec43:	jmp    104eea0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x6d0>
 104ec48:	mov    %r9d,%r8d
 104ec4b:	shr    $0x4,%r8d
 104ec4f:	inc    %r8d
 104ec52:	and    $0x3,%r8d
 104ec56:	vpxor  %xmm1,%xmm1,%xmm1
 104ec5a:	mov    %r8,%r10
 104ec5d:	mov    %rcx,%r11
 104ec60:	vpxor  (%r11),%xmm0,%xmm2
 104ec65:	vpsadbw %xmm2,%xmm11,%xmm2
 104ec69:	vpaddq %xmm1,%xmm2,%xmm1
 104ec6d:	add    $0x10,%r11
 104ec71:	dec    %r10
 104ec74:	jne    104ec60 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x490>
 104ec76:	shl    $0x4,%r8d
 104ec7a:	add    %r8,%rcx
 104ec7d:	sub    %r8,%rdi
 104ec80:	cmp    $0x30,%r9
 104ec84:	jb     104ecd1 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x501>
 104ec86:	cs nopw 0x0(%rax,%rax,1)
 104ec90:	vpxor  (%rcx),%xmm0,%xmm2
 104ec94:	vpsadbw %xmm2,%xmm11,%xmm2
 104ec98:	vpaddq %xmm1,%xmm2,%xmm1
 104ec9c:	vpxor  0x10(%rcx),%xmm0,%xmm2
 104eca1:	vpsadbw %xmm2,%xmm11,%xmm2
 104eca5:	vpxor  0x20(%rcx),%xmm0,%xmm3
 104ecaa:	vpsadbw %xmm3,%xmm11,%xmm3
 104ecae:	vpaddq %xmm2,%xmm3,%xmm2
 104ecb2:	vpaddq %xmm1,%xmm2,%xmm1
 104ecb6:	vpxor  0x30(%rcx),%xmm0,%xmm2
 104ecbb:	vpsadbw %xmm2,%xmm11,%xmm2
 104ecbf:	vpaddq %xmm1,%xmm2,%xmm1
 104ecc3:	add    $0x40,%rcx
 104ecc7:	add    $0xffffffffffffffc0,%rdi
 104eccb:	cmp    $0xf,%rdi
 104eccf:	ja     104ec90 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x4c0>
 104ecd1:	vpshufd $0xee,%xmm1,%xmm0
 104ecd6:	vpaddq %xmm0,%xmm1,%xmm0
 104ecda:	vmovq  %xmm0,%rbx
 104ecdf:	test   %rdi,%rdi
 104ece2:	je     104eea0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x6d0>
 104ece8:	mov    %rdi,%r11
 104eceb:	and    $0x3,%r11
 104ecef:	je     104ed2d <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x55d>
 104ecf1:	xor    %r8d,%r8d
 104ecf4:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 104ed00:	movzbl (%rcx,%r8,1),%r9d
 104ed05:	xor    %dl,%r9b
 104ed08:	movzbl %r9b,%r9d
 104ed0c:	add    %r9,%rbx
 104ed0f:	inc    %r8
 104ed12:	cmp    %r8,%r11
 104ed15:	jne    104ed00 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x530>
 104ed17:	mov    %rdi,%r8
 104ed1a:	and    $0xfffffffffffffffc,%r8
 104ed1e:	lea    (%rcx,%r11,1),%r9
 104ed22:	cmp    $0x4,%rdi
 104ed26:	jae    104ed3d <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x56d>
 104ed28:	jmp    104eea0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x6d0>
 104ed2d:	mov    %rcx,%r9
 104ed30:	mov    %rdi,%r8
 104ed33:	cmp    $0x4,%rdi
 104ed37:	jb     104eea0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x6d0>
 104ed3d:	lea    -0x4(%r8),%rdi
 104ed41:	cmp    $0x1c,%rdi
 104ed45:	jb     104ee65 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x695>
 104ed4b:	shr    $0x2,%rdi
 104ed4f:	inc    %rdi
 104ed52:	mov    %rdi,%r10
 104ed55:	and    $0xfffffffffffffff8,%r10
 104ed59:	lea    0x0(,%r10,4),%rbp
 104ed61:	lea    (%r9,%r10,4),%r9
 104ed65:	sub    %rbp,%r8
 104ed68:	vmovq  %rbx,%xmm1
 104ed6d:	vmovd  %edx,%xmm0
 104ed71:	vpbroadcastb %xmm0,%xmm0
 104ed76:	add    %r11,%rcx
 104ed79:	add    $0x10,%rcx
 104ed7d:	vpxor  %xmm2,%xmm2,%xmm2
 104ed81:	xor    %r11d,%r11d
 104ed84:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 104ed90:	vmovdqu -0x10(%rcx,%r11,4),%xmm3
 104ed97:	vmovdqu (%rcx,%r11,4),%xmm4
 104ed9d:	vpshufb %xmm12,%xmm3,%xmm5
 104eda2:	vpshufb %xmm13,%xmm3,%xmm6
 104eda7:	vpshufb %xmm14,%xmm3,%xmm7
 104edac:	vpshufb %xmm15,%xmm3,%xmm3
 104edb1:	vpshufb %xmm12,%xmm4,%xmm8
 104edb6:	vpshufb %xmm13,%xmm4,%xmm9
 104edbb:	vpshufb %xmm14,%xmm4,%xmm10
 104edc0:	vpshufb %xmm15,%xmm4,%xmm4
 104edc5:	vpxor  %xmm0,%xmm5,%xmm5
 104edc9:	vpxor  %xmm0,%xmm8,%xmm8
 104edcd:	vpmovzxbq %xmm5,%ymm5
 104edd2:	vpaddq %ymm5,%ymm1,%ymm1
 104edd6:	vpmovzxbq %xmm8,%ymm5
 104eddb:	vpaddq %ymm5,%ymm2,%ymm2
 104eddf:	vpxor  %xmm0,%xmm6,%xmm5
 104ede3:	vpxor  %xmm0,%xmm9,%xmm6
 104ede7:	vpmovzxbq %xmm5,%ymm5
 104edec:	vpmovzxbq %xmm6,%ymm6
 104edf1:	vpxor  %xmm0,%xmm7,%xmm7
 104edf5:	vpxor  %xmm0,%xmm10,%xmm8
 104edf9:	vpmovzxbq %xmm7,%ymm7
 104edfe:	vpaddq %ymm7,%ymm5,%ymm5
 104ee02:	vpaddq %ymm5,%ymm1,%ymm1
 104ee06:	vpmovzxbq %xmm8,%ymm5
 104ee0b:	vpaddq %ymm5,%ymm6,%ymm5
 104ee0f:	vpaddq %ymm5,%ymm2,%ymm2
 104ee13:	vpxor  %xmm0,%xmm3,%xmm3
 104ee17:	vpxor  %xmm0,%xmm4,%xmm4
 104ee1b:	vpmovzxbq %xmm3,%ymm3
 104ee20:	vpaddq %ymm3,%ymm1,%ymm1
 104ee24:	vpmovzxbq %xmm4,%ymm3
 104ee29:	vpaddq %ymm3,%ymm2,%ymm2
 104ee2d:	add    $0x8,%r11
 104ee31:	cmp    %r11,%r10
 104ee34:	jne    104ed90 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x5c0>
 104ee3a:	vpaddq %ymm1,%ymm2,%ymm0
 104ee3e:	vextracti128 $0x1,%ymm0,%xmm1
 104ee44:	vpaddq %xmm1,%xmm0,%xmm0
 104ee48:	vpshufd $0xee,%xmm0,%xmm1
 104ee4d:	vpaddq %xmm1,%xmm0,%xmm0
 104ee51:	vmovq  %xmm0,%rbx
 104ee56:	cmp    %r10,%rdi
 104ee59:	movabs $0xffffffffffffff0,%rbp
 104ee63:	je     104eea0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x6d0>
 104ee65:	vmovd  %edx,%xmm0
 104ee69:	vpbroadcastb %xmm0,%xmm0
 104ee6e:	xor    %ecx,%ecx
 104ee70:	vmovd  (%r9,%rcx,1),%xmm1
 104ee76:	vpxor  %xmm0,%xmm1,%xmm1
 104ee7a:	vpblendd $0x1,%xmm1,%xmm11,%xmm1
 104ee80:	vpsadbw %xmm1,%xmm11,%xmm1
 104ee84:	vmovq  %xmm1,%rdx
 104ee89:	add    %rdx,%rbx
 104ee8c:	add    $0x4,%rcx
 104ee90:	cmp    %rcx,%r8
 104ee93:	jne    104ee70 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x6a0>
 104ee95:	data16 cs nopw 0x0(%rax,%rax,1)
 104eea0:	test   %r13,%rax
 104eea3:	jne    104eeb9 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x6e9>
 104eea5:	mov    -0x18(%rsi),%rax
 104eea9:	dec    %rax
 104eeac:	jne    104eeb5 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x6e5>
 104eeae:	cmpq   $0x0,-0x20(%rsi)
 104eeb3:	je     104ef08 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x738>
 104eeb5:	mov    %rax,-0x18(%rsi)
 104eeb9:	mov    %r12,%rcx
 104eebc:	add    %rbx,%rcx
 104eebf:	jo     105225a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3a8a>
 104eec5:	mov    %rcx,%rax
 104eec8:	imul   %r15
 104eecb:	add    %rcx,%rdx
 104eece:	mov    %rdx,%rax
 104eed1:	shr    $0x3f,%rax
 104eed5:	sar    $0x1d,%rdx
 104eed9:	add    %rax,%rdx
 104eedc:	imul   $0x3b9aca07,%rdx,%rax
 104eee3:	sub    %rax,%rcx
 104eee6:	mov    %rcx,%rax
 104eee9:	sar    $0x3f,%rax
 104eeed:	and    $0x3b9aca07,%eax
 104eef2:	add    %rcx,%rax
 104eef5:	inc    %r14
 104eef8:	cmp    0x28(%rsp),%r14
 104eefd:	jne    104ea60 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x290>
 104ef03:	jmp    104f1ad <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x9dd>
 104ef08:	mov    0x18(%rsp),%rbp
 104ef0d:	mov    %rbp,%rdi
 104ef10:	vzeroupper
 104ef13:	call   109ccc0 <myl_rc_hold_edge_release>
 104ef18:	mov    %rbp,%rdi
 104ef1b:	movabs $0xffffffffffffff0,%rbp
 104ef25:	call   109fce0 <myl_rc_drain>
 104ef2a:	vmovd  -0x4d612(%rip),%xmm15        # 1001920 <__abi_tag+0x1624>
 104ef32:	vmovd  -0x4d5ba(%rip),%xmm14        # 1001980 <__abi_tag+0x1684>
 104ef3a:	vmovd  -0x4d552(%rip),%xmm13        # 10019f0 <__abi_tag+0x16f4>
 104ef42:	vmovd  -0x4d5aa(%rip),%xmm12        # 10019a0 <__abi_tag+0x16a4>
 104ef4a:	vpxor  %xmm11,%xmm11,%xmm11
 104ef4f:	jmp    104eeb9 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x6e9>
 104ef54:	mov    $0x1007dbf,%esi
 104ef59:	mov    0x8(%rsp),%rdi
 104ef5e:	vzeroupper
 104ef61:	call   108cd9e <fail>
 104ef66:	vmovd  -0x4d64e(%rip),%xmm15        # 1001920 <__abi_tag+0x1624>
 104ef6e:	vmovd  -0x4d5f6(%rip),%xmm14        # 1001980 <__abi_tag+0x1684>
 104ef76:	vmovd  -0x4d58e(%rip),%xmm13        # 10019f0 <__abi_tag+0x16f4>
 104ef7e:	vmovd  -0x4d5e6(%rip),%xmm12        # 10019a0 <__abi_tag+0x16a4>
 104ef86:	vpxor  %xmm11,%xmm11,%xmm11
 104ef8b:	xor    %ebx,%ebx
 104ef8d:	jmp    104eeb9 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x6e9>
 104ef92:	mov    $0x1,%bl
 104ef94:	test   %rsi,%rsi
 104ef97:	je     104f107 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x937>
 104ef9d:	mov    0x8(%rsi),%rdx
 104efa1:	cmp    0x6d220(%rip),%rdx        # 10bc1c8 <myl_lit_8c12e724a44132b907ad7be4d7bffd05d284ce5c644f94f5ab8dbc188941e631_instance+0x18>
 104efa8:	jne    104f107 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x937>
 104efae:	test   %rdx,%rdx
 104efb1:	je     104e9c9 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1f9>
 104efb7:	testb  $0x4,0x10(%rsi)
 104efbb:	jne    104f00b <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x83b>
 104efbd:	lea    0x18(%rsi),%rdi
 104efc1:	jmp    104f01a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x84a>
 104efc3:	mov    %rsi,%r14
 104efc6:	mov    $0x10bc6b0,%esi
 104efcb:	mov    0x8(%rsp),%rax
 104efd0:	lea    0x258(%rax),%r12
 104efd7:	mov    %r12,%rdi
 104efda:	vzeroupper
 104efdd:	call   109cb60 <myl_rc_edge_release>
 104efe2:	movq   $0x0,0xd0(%rsp)
 104efee:	mov    %r12,%rdi
 104eff1:	call   109fce0 <myl_rc_drain>
 104eff6:	mov    %r14,%rsi
 104eff9:	test   %bl,%bl
 104effb:	mov    %r15,0x30(%rsp)
 104f000:	jne    104e99e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1ce>
 104f006:	jmp    104ea13 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x243>
 104f00b:	mov    0x18(%rsi),%rax
 104f00f:	mov    0x14(%rsi),%ecx
 104f012:	lea    (%rax,%rcx,1),%rdi
 104f016:	add    $0x18,%rdi
 104f01a:	testb  $0x4,0x6d1af(%rip)        # 10bc1d0 <myl_lit_8c12e724a44132b907ad7be4d7bffd05d284ce5c644f94f5ab8dbc188941e631_instance+0x20>
 104f021:	mov    0x6d1b0(%rip),%rax        # 10bc1d8 <myl_lit_8c12e724a44132b907ad7be4d7bffd05d284ce5c644f94f5ab8dbc188941e631_instance+0x28>
 104f028:	mov    0x6d1a6(%rip),%ecx        # 10bc1d4 <myl_lit_8c12e724a44132b907ad7be4d7bffd05d284ce5c644f94f5ab8dbc188941e631_instance+0x24>
 104f02e:	lea    0x18(%rax,%rcx,1),%rcx
 104f033:	mov    $0x10bc1d8,%eax
 104f038:	cmovne %rcx,%rax
 104f03c:	cmp    $0x10,%rdx
 104f040:	ja     104f060 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x890>
 104f042:	cmp    $0x8,%rdx
 104f046:	jb     104f08a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x8ba>
 104f048:	mov    (%rdi),%rcx
 104f04b:	mov    -0x8(%rdi,%rdx,1),%rdi
 104f050:	xor    (%rax),%rcx
 104f053:	xor    -0x8(%rax,%rdx,1),%rdi
 104f058:	or     %rcx,%rdi
 104f05b:	jmp    104f101 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x931>
 104f060:	cmp    $0x40,%rdx
 104f064:	ja     104f0a4 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x8d4>
 104f066:	vmovdqu (%rdi),%xmm0
 104f06a:	cmp    $0x20,%rdx
 104f06e:	ja     104f0e1 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x911>
 104f070:	vinserti128 $0x1,-0x10(%rdi,%rdx,1),%ymm0,%ymm0
 104f078:	vmovdqu (%rax),%xmm1
 104f07c:	vinserti128 $0x1,-0x10(%rax,%rdx,1),%ymm1,%ymm1
 104f084:	vpxor  %ymm1,%ymm0,%ymm0
 104f088:	jmp    104f0fc <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x92c>
 104f08a:	cmp    $0x4,%rdx
 104f08e:	jb     104f581 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xdb1>
 104f094:	mov    (%rdi),%ecx
 104f096:	mov    -0x4(%rdi,%rdx,1),%edi
 104f09a:	xor    (%rax),%ecx
 104f09c:	xor    -0x4(%rax,%rdx,1),%edi
 104f0a0:	or     %ecx,%edi
 104f0a2:	jmp    104f101 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x931>
 104f0a4:	mov    %rsi,%r14
 104f0a7:	mov    %rax,%rsi
 104f0aa:	cmp    $0x100,%rdx
 104f0b1:	ja     104f595 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xdc5>
 104f0b7:	vzeroupper
 104f0ba:	call   10ae350 <bcmp@plt>
 104f0bf:	test   %eax,%eax
 104f0c1:	setne  %bl
 104f0c4:	jmp    104f5a2 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xdd2>
 104f0c9:	movzwl (%rdi),%ecx
 104f0cc:	movzwl -0x2(%rdi,%rdx,1),%edi
 104f0d1:	xor    (%rax),%cx
 104f0d4:	xor    -0x2(%rax,%rdx,1),%di
 104f0d9:	or     %cx,%di
 104f0dc:	jmp    104e940 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x170>
 104f0e1:	vmovdqu -0x20(%rdi,%rdx,1),%ymm1
 104f0e7:	vinserti128 $0x1,0x10(%rdi),%ymm0,%ymm0
 104f0ee:	vpxor  -0x20(%rax,%rdx,1),%ymm1,%ymm1
 104f0f4:	vpxor  (%rax),%ymm0,%ymm0
 104f0f8:	vpor   %ymm1,%ymm0,%ymm0
 104f0fc:	vptest %ymm0,%ymm0
 104f101:	sete   %bl
 104f104:	xor    $0x1,%bl
 104f107:	test   %r13,0x6d0a2(%rip)        # 10bc1b0 <myl_lit_8c12e724a44132b907ad7be4d7bffd05d284ce5c644f94f5ab8dbc188941e631_instance>
 104f10e:	jne    104f131 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x961>
 104f110:	mov    0x6d089(%rip),%rax        # 10bc1a0 <myl_lit_842ab9229ccb9156d5ed82c31992b7b48b2d840046545e9d568e989652f87fd6_instance+0x20>
 104f117:	dec    %rax
 104f11a:	jne    104f12a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x95a>
 104f11c:	cmpq   $0x0,0x6d084(%rip)        # 10bc1a8 <myl_lit_842ab9229ccb9156d5ed82c31992b7b48b2d840046545e9d568e989652f87fd6_instance+0x28>
 104f124:	je     104f442 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xc72>
 104f12a:	mov    %rax,0x6d06f(%rip)        # 10bc1a0 <myl_lit_842ab9229ccb9156d5ed82c31992b7b48b2d840046545e9d568e989652f87fd6_instance+0x20>
 104f131:	test   %bl,%bl
 104f133:	je     104f15a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x98a>
 104f135:	movq   $0x10bc010,0x78(%rsp)
 104f13e:	movq   $0x10bc010,0xd0(%rsp)
 104f14a:	cmp    $0x10bc010,%rsi
 104f151:	jne    104f1c2 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x9f2>
 104f153:	xor    %ebx,%ebx
 104f155:	jmp    104f69a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xeca>
 104f15a:	mov    0x8(%r15),%rax
 104f15e:	mov    0x10(%rsp),%rsi
 104f163:	and    $0x3,%esi
 104f166:	mov    (%rax),%rdx
 104f169:	cmp    %rdx,%rsi
 104f16c:	jae    105226f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3a9f>
 104f172:	mov    0x10(%r15),%rcx
 104f176:	mov    (%rcx),%rdx
 104f179:	cmp    %rdx,%rsi
 104f17c:	jae    105227c <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3aac>
 104f182:	mov    0x20(%rax),%rax
 104f186:	shl    $0x3,%esi
 104f189:	mov    (%rax,%rsi,1),%rdi
 104f18d:	mov    0x20(%rcx),%rax
 104f191:	mov    (%rax,%rsi,1),%rsi
 104f195:	mov    $0x1,%eax
 104f19a:	cmp    %rsi,%rdi
 104f19d:	jne    104f1fa <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xa2a>
 104f19f:	mov    %eax,%eax
 104f1a1:	cmpq   $0x1,0x28(%rsp)
 104f1a7:	jne    104f22d <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xa5d>
 104f1ad:	add    $0x268,%rsp
 104f1b4:	pop    %rbx
 104f1b5:	pop    %r12
 104f1b7:	pop    %r13
 104f1b9:	pop    %r14
 104f1bb:	pop    %r15
 104f1bd:	pop    %rbp
 104f1be:	vzeroupper
 104f1c1:	ret
 104f1c2:	mov    $0x1,%bl
 104f1c4:	test   %rsi,%rsi
 104f1c7:	je     104f69a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xeca>
 104f1cd:	mov    0x8(%rsi),%rdx
 104f1d1:	cmp    0x6ce40(%rip),%rdx        # 10bc018 <myl_lit_7afa21b5dfd0bec52f3c46b131c861acf738a60d12be67523b48ae28324a1934_instance+0x18>
 104f1d8:	jne    104f69a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xeca>
 104f1de:	test   %rdx,%rdx
 104f1e1:	je     104f153 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x983>
 104f1e7:	testb  $0x4,0x10(%rsi)
 104f1eb:	jne    104f46c <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xc9c>
 104f1f1:	lea    0x18(%rsi),%rdi
 104f1f5:	jmp    104f47b <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xcab>
 104f1fa:	xor    %eax,%eax
 104f1fc:	test   %rdi,%rdi
 104f1ff:	je     104f19f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x9cf>
 104f201:	test   %rsi,%rsi
 104f204:	je     104f19f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x9cf>
 104f206:	mov    0x8(%rdi),%rdx
 104f20a:	cmp    0x8(%rsi),%rdx
 104f20e:	jne    104f19f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x9cf>
 104f210:	mov    $0x1,%eax
 104f215:	test   %rdx,%rdx
 104f218:	je     104f19f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x9cf>
 104f21a:	testb  $0x4,0x10(%rdi)
 104f21e:	jne    104f4fa <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xd2a>
 104f224:	add    $0x18,%rdi
 104f228:	jmp    104f509 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xd39>
 104f22d:	mov    $0x1,%ebx
 104f232:	movabs $0x89705f3112a28fe5,%r14
 104f23c:	jmp    104f2a9 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xad9>
 104f23e:	mov    (%rdi),%rcx
 104f241:	mov    -0x8(%rdi,%rdx,1),%rdi
 104f246:	xor    (%rsi),%rcx
 104f249:	xor    -0x8(%rsi,%rdx,1),%rdi
 104f24e:	xor    %eax,%eax
 104f250:	or     %rcx,%rdi
 104f253:	sete   %al
 104f256:	cs nopw 0x0(%rax,%rax,1)
 104f260:	mov    %eax,%eax
 104f262:	mov    %r15,%rcx
 104f265:	add    %rax,%rcx
 104f268:	mov    %rcx,%rax
 104f26b:	imul   %r14
 104f26e:	add    %rcx,%rdx
 104f271:	mov    %rdx,%rax
 104f274:	shr    $0x3f,%rax
 104f278:	sar    $0x1d,%rdx
 104f27c:	add    %rax,%rdx
 104f27f:	imul   $0x3b9aca07,%rdx,%rax
 104f286:	sub    %rax,%rcx
 104f289:	mov    %rcx,%rax
 104f28c:	sar    $0x3f,%rax
 104f290:	and    $0x3b9aca07,%eax
 104f295:	add    %rax,%rcx
 104f298:	mov    %rcx,%rax
 104f29b:	inc    %rbx
 104f29e:	cmp    %rbx,0x28(%rsp)
 104f2a3:	je     104f1ad <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x9dd>
 104f2a9:	mov    0x10(%rsp),%rsi
 104f2ae:	add    %rbx,%rsi
 104f2b1:	jo     1052289 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3ab9>
 104f2b7:	mov    %rax,%r15
 104f2ba:	mov    0x30(%rsp),%rcx
 104f2bf:	mov    0x8(%rcx),%rax
 104f2c3:	and    $0x3,%esi
 104f2c6:	mov    (%rax),%rdx
 104f2c9:	cmp    %rdx,%rsi
 104f2cc:	jae    105226f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3a9f>
 104f2d2:	mov    0x10(%rcx),%rcx
 104f2d6:	mov    (%rcx),%rdx
 104f2d9:	cmp    %rdx,%rsi
 104f2dc:	jae    105227c <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3aac>
 104f2e2:	mov    0x20(%rax),%rax
 104f2e6:	shl    $0x3,%esi
 104f2e9:	mov    (%rax,%rsi,1),%rdi
 104f2ed:	mov    0x20(%rcx),%rax
 104f2f1:	mov    (%rax,%rsi,1),%rsi
 104f2f5:	mov    $0x1,%eax
 104f2fa:	cmp    %rsi,%rdi
 104f2fd:	je     104f260 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xa90>
 104f303:	xor    %eax,%eax
 104f305:	test   %rdi,%rdi
 104f308:	je     104f260 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xa90>
 104f30e:	test   %rsi,%rsi
 104f311:	je     104f260 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xa90>
 104f317:	mov    0x8(%rdi),%rdx
 104f31b:	cmp    0x8(%rsi),%rdx
 104f31f:	jne    104f260 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xa90>
 104f325:	mov    $0x1,%eax
 104f32a:	test   %rdx,%rdx
 104f32d:	je     104f260 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xa90>
 104f333:	testb  $0x4,0x10(%rdi)
 104f337:	jne    104f382 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xbb2>
 104f339:	add    $0x18,%rdi
 104f33d:	testb  $0x4,0x10(%rsi)
 104f341:	je     104f397 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xbc7>
 104f343:	mov    0x18(%rsi),%rax
 104f347:	mov    0x14(%rsi),%ecx
 104f34a:	lea    (%rax,%rcx,1),%rsi
 104f34e:	add    $0x18,%rsi
 104f352:	cmp    $0x10,%rdx
 104f356:	jbe    104f3a1 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xbd1>
 104f358:	cmp    $0x40,%rdx
 104f35c:	ja     104f3c6 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xbf6>
 104f35e:	vmovdqu (%rdi),%xmm0
 104f362:	cmp    $0x20,%rdx
 104f366:	ja     104f3e2 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xc12>
 104f368:	vinserti128 $0x1,-0x10(%rdi,%rdx,1),%ymm0,%ymm0
 104f370:	vmovdqu (%rsi),%xmm1
 104f374:	vinserti128 $0x1,-0x10(%rsi,%rdx,1),%ymm1,%ymm1
 104f37c:	vpxor  %ymm1,%ymm0,%ymm0
 104f380:	jmp    104f3fd <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xc2d>
 104f382:	mov    0x18(%rdi),%rax
 104f386:	mov    0x14(%rdi),%ecx
 104f389:	lea    (%rax,%rcx,1),%rdi
 104f38d:	add    $0x18,%rdi
 104f391:	testb  $0x4,0x10(%rsi)
 104f395:	jne    104f343 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xb73>
 104f397:	add    $0x18,%rsi
 104f39b:	cmp    $0x10,%rdx
 104f39f:	ja     104f358 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xb88>
 104f3a1:	cmp    $0x8,%rdx
 104f3a5:	jae    104f23e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xa6e>
 104f3ab:	cmp    $0x4,%rdx
 104f3af:	jb     104f409 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xc39>
 104f3b1:	mov    (%rdi),%ecx
 104f3b3:	mov    -0x4(%rdi,%rdx,1),%edi
 104f3b7:	xor    (%rsi),%ecx
 104f3b9:	xor    -0x4(%rsi,%rdx,1),%edi
 104f3bd:	xor    %eax,%eax
 104f3bf:	or     %ecx,%edi
 104f3c1:	jmp    104f253 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xa83>
 104f3c6:	cmp    $0x100,%rdx
 104f3cd:	ja     104f41b <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xc4b>
 104f3cf:	vzeroupper
 104f3d2:	call   10ae350 <bcmp@plt>
 104f3d7:	mov    %eax,%ecx
 104f3d9:	xor    %eax,%eax
 104f3db:	test   %ecx,%ecx
 104f3dd:	jmp    104f253 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xa83>
 104f3e2:	vmovdqu -0x20(%rdi,%rdx,1),%ymm1
 104f3e8:	vinserti128 $0x1,0x10(%rdi),%ymm0,%ymm0
 104f3ef:	vpxor  -0x20(%rsi,%rdx,1),%ymm1,%ymm1
 104f3f5:	vpxor  (%rsi),%ymm0,%ymm0
 104f3f9:	vpor   %ymm1,%ymm0,%ymm0
 104f3fd:	xor    %eax,%eax
 104f3ff:	vptest %ymm0,%ymm0
 104f404:	jmp    104f253 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xa83>
 104f409:	cmp    $0x1,%rdx
 104f40d:	jne    104f428 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xc58>
 104f40f:	movzbl (%rdi),%ecx
 104f412:	xor    %eax,%eax
 104f414:	cmp    (%rsi),%cl
 104f416:	jmp    104f253 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xa83>
 104f41b:	vzeroupper
 104f41e:	call   10943e0 <equal_large_octets>
 104f423:	jmp    104f260 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xa90>
 104f428:	movzwl (%rdi),%ecx
 104f42b:	movzwl -0x2(%rdi,%rdx,1),%edi
 104f430:	xor    (%rsi),%cx
 104f433:	xor    -0x2(%rsi,%rdx,1),%di
 104f438:	xor    %eax,%eax
 104f43a:	or     %cx,%di
 104f43d:	jmp    104f253 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xa83>
 104f442:	lea    0xd0(%rsp),%rax
 104f44a:	mov    0x8(%rsp),%rcx
 104f44f:	lea    0x258(%rcx),%rdi
 104f456:	mov    %rsi,%r14
 104f459:	mov    %rax,%rsi
 104f45c:	vzeroupper
 104f45f:	call   1088850 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop>
 104f464:	mov    %r14,%rsi
 104f467:	jmp    104f131 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x961>
 104f46c:	mov    0x18(%rsi),%rax
 104f470:	mov    0x14(%rsi),%ecx
 104f473:	lea    (%rax,%rcx,1),%rdi
 104f477:	add    $0x18,%rdi
 104f47b:	testb  $0x4,0x6cb9e(%rip)        # 10bc020 <myl_lit_7afa21b5dfd0bec52f3c46b131c861acf738a60d12be67523b48ae28324a1934_instance+0x20>
 104f482:	mov    0x6cb9f(%rip),%rax        # 10bc028 <myl_lit_7afa21b5dfd0bec52f3c46b131c861acf738a60d12be67523b48ae28324a1934_instance+0x28>
 104f489:	mov    0x6cb95(%rip),%ecx        # 10bc024 <myl_lit_7afa21b5dfd0bec52f3c46b131c861acf738a60d12be67523b48ae28324a1934_instance+0x24>
 104f48f:	lea    0x18(%rax,%rcx,1),%rcx
 104f494:	mov    $0x10bc028,%eax
 104f499:	cmovne %rcx,%rax
 104f49d:	cmp    $0x10,%rdx
 104f4a1:	ja     104f4c5 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xcf5>
 104f4a3:	cmp    $0x8,%rdx
 104f4a7:	jb     104f5b7 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xde7>
 104f4ad:	mov    (%rdi),%rcx
 104f4b0:	mov    -0x8(%rdi,%rdx,1),%rdi
 104f4b5:	xor    (%rax),%rcx
 104f4b8:	xor    -0x8(%rax,%rdx,1),%rdi
 104f4bd:	or     %rcx,%rdi
 104f4c0:	jmp    104f659 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xe89>
 104f4c5:	cmp    $0x40,%rdx
 104f4c9:	ja     104f5d4 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xe04>
 104f4cf:	vmovdqu (%rdi),%xmm0
 104f4d3:	cmp    $0x20,%rdx
 104f4d7:	ja     104f639 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xe69>
 104f4dd:	vinserti128 $0x1,-0x10(%rdi,%rdx,1),%ymm0,%ymm0
 104f4e5:	vmovdqu (%rax),%xmm1
 104f4e9:	vinserti128 $0x1,-0x10(%rax,%rdx,1),%ymm1,%ymm1
 104f4f1:	vpxor  %ymm1,%ymm0,%ymm0
 104f4f5:	jmp    104f654 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xe84>
 104f4fa:	mov    0x18(%rdi),%rax
 104f4fe:	mov    0x14(%rdi),%ecx
 104f501:	lea    (%rax,%rcx,1),%rdi
 104f505:	add    $0x18,%rdi
 104f509:	testb  $0x4,0x10(%rsi)
 104f50d:	jne    104f515 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xd45>
 104f50f:	add    $0x18,%rsi
 104f513:	jmp    104f524 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xd54>
 104f515:	mov    0x18(%rsi),%rax
 104f519:	mov    0x14(%rsi),%ecx
 104f51c:	lea    (%rax,%rcx,1),%rsi
 104f520:	add    $0x18,%rsi
 104f524:	cmp    $0x11,%rdx
 104f528:	jae    104f54c <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xd7c>
 104f52a:	cmp    $0x7,%rdx
 104f52e:	jbe    104f5f9 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xe29>
 104f534:	mov    (%rdi),%rax
 104f537:	mov    -0x8(%rdi,%rdx,1),%rcx
 104f53c:	xor    (%rsi),%rax
 104f53f:	xor    -0x8(%rsi,%rdx,1),%rcx
 104f544:	or     %rax,%rcx
 104f547:	jmp    1050dd1 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2601>
 104f54c:	cmp    $0x41,%rdx
 104f550:	jae    104f616 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xe46>
 104f556:	vmovdqu (%rdi),%xmm0
 104f55a:	cmp    $0x21,%rdx
 104f55e:	jae    104fa0d <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x123d>
 104f564:	vinserti128 $0x1,-0x10(%rdi,%rdx,1),%ymm0,%ymm0
 104f56c:	vmovdqu (%rsi),%xmm1
 104f570:	vinserti128 $0x1,-0x10(%rsi,%rdx,1),%ymm1,%ymm1
 104f578:	vpxor  %ymm1,%ymm0,%ymm0
 104f57c:	jmp    104fa28 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1258>
 104f581:	cmp    $0x1,%rdx
 104f585:	jne    104f661 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xe91>
 104f58b:	movzbl (%rdi),%ecx
 104f58e:	cmp    (%rax),%cl
 104f590:	jmp    104f101 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x931>
 104f595:	vzeroupper
 104f598:	call   10943e0 <equal_large_octets>
 104f59d:	test   %eax,%eax
 104f59f:	sete   %bl
 104f5a2:	mov    %r14,%rsi
 104f5a5:	test   %r13,0x6cc04(%rip)        # 10bc1b0 <myl_lit_8c12e724a44132b907ad7be4d7bffd05d284ce5c644f94f5ab8dbc188941e631_instance>
 104f5ac:	jne    104f131 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x961>
 104f5b2:	jmp    104f110 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x940>
 104f5b7:	cmp    $0x4,%rdx
 104f5bb:	jb     104f679 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xea9>
 104f5c1:	mov    (%rdi),%ecx
 104f5c3:	mov    -0x4(%rdi,%rdx,1),%edi
 104f5c7:	xor    (%rax),%ecx
 104f5c9:	xor    -0x4(%rax,%rdx,1),%edi
 104f5cd:	or     %ecx,%edi
 104f5cf:	jmp    104f659 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xe89>
 104f5d4:	mov    %rsi,%r14
 104f5d7:	mov    %rax,%rsi
 104f5da:	cmp    $0x100,%rdx
 104f5e1:	ja     104f68a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xeba>
 104f5e7:	vzeroupper
 104f5ea:	call   10ae350 <bcmp@plt>
 104f5ef:	test   %eax,%eax
 104f5f1:	setne  %bl
 104f5f4:	jmp    104f697 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xec7>
 104f5f9:	cmp    $0x3,%rdx
 104f5fd:	jbe    104fa37 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1267>
 104f603:	mov    (%rdi),%eax
 104f605:	mov    -0x4(%rdi,%rdx,1),%ecx
 104f609:	xor    (%rsi),%eax
 104f60b:	xor    -0x4(%rsi,%rdx,1),%ecx
 104f60f:	or     %eax,%ecx
 104f611:	jmp    1050dd1 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2601>
 104f616:	cmp    $0x101,%rdx
 104f61d:	jae    104fa4b <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x127b>
 104f623:	vzeroupper
 104f626:	call   10ae350 <bcmp@plt>
 104f62b:	mov    %eax,%ecx
 104f62d:	xor    %eax,%eax
 104f62f:	test   %ecx,%ecx
 104f631:	sete   %al
 104f634:	jmp    104f19f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x9cf>
 104f639:	vmovdqu -0x20(%rdi,%rdx,1),%ymm1
 104f63f:	vinserti128 $0x1,0x10(%rdi),%ymm0,%ymm0
 104f646:	vpxor  -0x20(%rax,%rdx,1),%ymm1,%ymm1
 104f64c:	vpxor  (%rax),%ymm0,%ymm0
 104f650:	vpor   %ymm1,%ymm0,%ymm0
 104f654:	vptest %ymm0,%ymm0
 104f659:	sete   %bl
 104f65c:	xor    $0x1,%bl
 104f65f:	jmp    104f69a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xeca>
 104f661:	movzwl (%rdi),%ecx
 104f664:	movzwl -0x2(%rdi,%rdx,1),%edi
 104f669:	xor    (%rax),%cx
 104f66c:	xor    -0x2(%rax,%rdx,1),%di
 104f671:	or     %cx,%di
 104f674:	jmp    104f101 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x931>
 104f679:	cmp    $0x1,%rdx
 104f67d:	jne    104fa58 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1288>
 104f683:	movzbl (%rdi),%ecx
 104f686:	cmp    (%rax),%cl
 104f688:	jmp    104f659 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xe89>
 104f68a:	vzeroupper
 104f68d:	call   10943e0 <equal_large_octets>
 104f692:	test   %eax,%eax
 104f694:	sete   %bl
 104f697:	mov    %r14,%rsi
 104f69a:	test   %r13,0x6c95f(%rip)        # 10bc000 <myl_lit_7afa21b5dfd0bec52f3c46b131c861acf738a60d12be67523b48ae28324a1934_instance>
 104f6a1:	je     104f6d9 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xf09>
 104f6a3:	test   %bl,%bl
 104f6a5:	je     104f6fe <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xf2e>
 104f6a7:	movq   $0x10bbc98,0x38(%rsp)
 104f6b0:	movq   $0x10bbc98,0x78(%rsp)
 104f6b9:	movq   $0x10bbc98,0xd0(%rsp)
 104f6c5:	cmp    $0x10bbc98,%rsi
 104f6cc:	jne    104f8e2 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1112>
 104f6d2:	xor    %ebx,%ebx
 104f6d4:	jmp    104fab9 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x12e9>
 104f6d9:	mov    0x6c910(%rip),%rax        # 10bbff0 <myl_lit_7a43bb86b2bccf6ad7e922d1f9ee2e9c1abbad0e5e2f1aa80d1ed73fc964ae92_instance+0x20>
 104f6e0:	dec    %rax
 104f6e3:	jne    104f6f3 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xf23>
 104f6e5:	cmpq   $0x0,0x6c90b(%rip)        # 10bbff8 <myl_lit_7a43bb86b2bccf6ad7e922d1f9ee2e9c1abbad0e5e2f1aa80d1ed73fc964ae92_instance+0x28>
 104f6ed:	je     104f913 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1143>
 104f6f3:	mov    %rax,0x6c8f6(%rip)        # 10bbff0 <myl_lit_7a43bb86b2bccf6ad7e922d1f9ee2e9c1abbad0e5e2f1aa80d1ed73fc964ae92_instance+0x20>
 104f6fa:	test   %bl,%bl
 104f6fc:	jne    104f6a7 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xed7>
 104f6fe:	xor    %eax,%eax
 104f700:	movabs $0x89705f3112a28fe5,%rdi
 104f70a:	xor    %ebx,%ebx
 104f70c:	nopl   0x0(%rax)
 104f710:	mov    0x10(%rsp),%rsi
 104f715:	add    %rbx,%rsi
 104f718:	jo     10522a0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3ad0>
 104f71e:	mov    %rax,%r13
 104f721:	mov    0x30(%rsp),%rcx
 104f726:	mov    0x8(%rcx),%rax
 104f72a:	cmpq   $0x0,(%rax)
 104f72e:	je     10522b7 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3ae7>
 104f734:	mov    0x20(%rax),%rax
 104f738:	mov    (%rax),%r14
 104f73b:	test   %r14,%r14
 104f73e:	je     104f761 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xf91>
 104f740:	movabs $0x4000000000000002,%rax
 104f74a:	test   %rax,-0x10(%r14)
 104f74e:	jne    104f761 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xf91>
 104f750:	mov    -0x18(%r14),%rax
 104f754:	inc    %rax
 104f757:	je     1051369 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2b99>
 104f75d:	mov    %rax,-0x18(%r14)
 104f761:	mov    %r14,0x78(%rsp)
 104f766:	mov    0x10(%rcx),%rax
 104f76a:	and    $0x3,%esi
 104f76d:	mov    (%rax),%rdx
 104f770:	cmp    %rdx,%rsi
 104f773:	jae    10522c8 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3af8>
 104f779:	mov    0x20(%rax),%rax
 104f77d:	mov    (%rax,%rsi,8),%rax
 104f781:	mov    (%rax),%rcx
 104f784:	test   %rcx,%rcx
 104f787:	je     104f7c0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xff0>
 104f789:	mov    $0xffffffffffffffff,%r15
 104f790:	cmp    (%r14),%rcx
 104f793:	ja     104f820 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1050>
 104f799:	mov    0x10(%r14),%ebp
 104f79d:	test   $0x4,%bpl
 104f7a1:	jne    104f7c5 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xff5>
 104f7a3:	lea    0x18(%r14),%rdi
 104f7a7:	testb  $0x4,0x10(%rax)
 104f7ab:	je     104f7db <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x100b>
 104f7ad:	mov    0x18(%rax),%rcx
 104f7b1:	mov    0x14(%rax),%edx
 104f7b4:	add    %rcx,%rdx
 104f7b7:	add    $0x18,%rdx
 104f7bb:	jmp    104f7df <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x100f>
 104f7bd:	nopl   (%rax)
 104f7c0:	xor    %r15d,%r15d
 104f7c3:	jmp    104f820 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1050>
 104f7c5:	mov    0x18(%r14),%rcx
 104f7c9:	mov    0x14(%r14),%edx
 104f7cd:	lea    (%rcx,%rdx,1),%rdi
 104f7d1:	add    $0x18,%rdi
 104f7d5:	testb  $0x4,0x10(%rax)
 104f7d9:	jne    104f7ad <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xfdd>
 104f7db:	lea    0x18(%rax),%rdx
 104f7df:	mov    0x8(%r14),%rsi
 104f7e3:	mov    0x8(%rax),%rcx
 104f7e7:	vzeroupper
 104f7ea:	call   1094440 <myl_native_octets_find>
 104f7ef:	cmp    $0xffffffffffffffff,%rax
 104f7f3:	movabs $0x89705f3112a28fe5,%rdi
 104f7fd:	je     104f820 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1050>
 104f7ff:	test   $0x1,%bpl
 104f803:	jne    104f81a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x104a>
 104f805:	mov    %r14,%rdi
 104f808:	mov    %rax,%rsi
 104f80b:	call   1091e80 <index_walk>
 104f810:	movabs $0x89705f3112a28fe5,%rdi
 104f81a:	mov    %rax,%r15
 104f81d:	nopl   (%rax)
 104f820:	mov    %r15,%r12
 104f823:	inc    %r12
 104f826:	jo     10522d5 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3b05>
 104f82c:	test   %r14,%r14
 104f82f:	je     104f855 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1085>
 104f831:	movabs $0x4000000000000002,%rax
 104f83b:	test   %rax,-0x10(%r14)
 104f83f:	jne    104f855 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1085>
 104f841:	mov    -0x18(%r14),%rax
 104f845:	dec    %rax
 104f848:	jne    104f851 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1081>
 104f84a:	cmpq   $0x0,-0x20(%r14)
 104f84f:	je     104f8a0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x10d0>
 104f851:	mov    %rax,-0x18(%r14)
 104f855:	mov    %r13,%rcx
 104f858:	add    %r12,%rcx
 104f85b:	jo     104f8cd <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x10fd>
 104f85d:	mov    %rcx,%rax
 104f860:	imul   %rdi
 104f863:	add    %rcx,%rdx
 104f866:	mov    %rdx,%rax
 104f869:	shr    $0x3f,%rax
 104f86d:	sar    $0x1d,%rdx
 104f871:	add    %rax,%rdx
 104f874:	imul   $0x3b9aca07,%rdx,%rax
 104f87b:	sub    %rax,%rcx
 104f87e:	mov    %rcx,%rax
 104f881:	sar    $0x3f,%rax
 104f885:	and    $0x3b9aca07,%eax
 104f88a:	add    %rcx,%rax
 104f88d:	inc    %rbx
 104f890:	cmp    %rbx,0x28(%rsp)
 104f895:	jne    104f710 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xf40>
 104f89b:	jmp    104f1ad <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x9dd>
 104f8a0:	mov    0x18(%rsp),%r15
 104f8a5:	mov    %r15,%rdi
 104f8a8:	mov    %r14,%rsi
 104f8ab:	vzeroupper
 104f8ae:	call   109ccc0 <myl_rc_hold_edge_release>
 104f8b3:	mov    %r15,%rdi
 104f8b6:	call   109fce0 <myl_rc_drain>
 104f8bb:	movabs $0x89705f3112a28fe5,%rdi
 104f8c5:	mov    %r13,%rcx
 104f8c8:	add    %r12,%rcx
 104f8cb:	jno    104f85d <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x108d>
 104f8cd:	mov    0x8(%rsp),%rdi
 104f8d2:	xor    %esi,%esi
 104f8d4:	mov    %r13,%rdx
 104f8d7:	mov    %r12,%rcx
 104f8da:	vzeroupper
 104f8dd:	call   108d7b0 <myl_qbe_fail_overflow_op>
 104f8e2:	mov    $0x1,%bl
 104f8e4:	test   %rsi,%rsi
 104f8e7:	je     104fab9 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x12e9>
 104f8ed:	mov    0x8(%rsi),%rdx
 104f8f1:	cmp    0x6c3a8(%rip),%rdx        # 10bbca0 <myl_lit_4d6ff6f7284ab5ea56c67ebc627dbe0fd0bb153a04fdd105bd867658d486b6d7_instance+0x18>
 104f8f8:	jne    104fab9 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x12e9>
 104f8fe:	test   %rdx,%rdx
 104f901:	je     104f6d2 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xf02>
 104f907:	testb  $0x4,0x10(%rsi)
 104f90b:	jne    104f945 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1175>
 104f90d:	lea    0x18(%rsi),%rdi
 104f911:	jmp    104f954 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1184>
 104f913:	lea    0xd0(%rsp),%rax
 104f91b:	mov    0x8(%rsp),%rcx
 104f920:	lea    0x258(%rcx),%rdi
 104f927:	mov    %rsi,%r14
 104f92a:	mov    %rax,%rsi
 104f92d:	vzeroupper
 104f930:	call   1088850 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop>
 104f935:	mov    %r14,%rsi
 104f938:	test   %bl,%bl
 104f93a:	jne    104f6a7 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xed7>
 104f940:	jmp    104f6fe <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xf2e>
 104f945:	mov    0x18(%rsi),%rax
 104f949:	mov    0x14(%rsi),%ecx
 104f94c:	lea    (%rax,%rcx,1),%rdi
 104f950:	add    $0x18,%rdi
 104f954:	testb  $0x4,0x6c34d(%rip)        # 10bbca8 <myl_lit_4d6ff6f7284ab5ea56c67ebc627dbe0fd0bb153a04fdd105bd867658d486b6d7_instance+0x20>
 104f95b:	mov    0x6c34e(%rip),%rax        # 10bbcb0 <myl_lit_4d6ff6f7284ab5ea56c67ebc627dbe0fd0bb153a04fdd105bd867658d486b6d7_instance+0x28>
 104f962:	mov    0x6c344(%rip),%ecx        # 10bbcac <myl_lit_4d6ff6f7284ab5ea56c67ebc627dbe0fd0bb153a04fdd105bd867658d486b6d7_instance+0x24>
 104f968:	lea    0x18(%rax,%rcx,1),%rcx
 104f96d:	mov    $0x10bbcb0,%eax
 104f972:	cmovne %rcx,%rax
 104f976:	cmp    $0x10,%rdx
 104f97a:	ja     104f99a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x11ca>
 104f97c:	cmp    $0x8,%rdx
 104f980:	jb     104f9cb <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x11fb>
 104f982:	mov    (%rdi),%rcx
 104f985:	mov    -0x8(%rdi,%rdx,1),%rdi
 104f98a:	xor    (%rax),%rcx
 104f98d:	xor    -0x8(%rax,%rdx,1),%rdi
 104f992:	or     %rcx,%rdi
 104f995:	jmp    104fa90 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x12c0>
 104f99a:	cmp    $0x40,%rdx
 104f99e:	ja     104f9e8 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1218>
 104f9a0:	vmovdqu (%rdi),%xmm0
 104f9a4:	cmp    $0x20,%rdx
 104f9a8:	ja     104fa70 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x12a0>
 104f9ae:	vinserti128 $0x1,-0x10(%rdi,%rdx,1),%ymm0,%ymm0
 104f9b6:	vmovdqu (%rax),%xmm1
 104f9ba:	vinserti128 $0x1,-0x10(%rax,%rdx,1),%ymm1,%ymm1
 104f9c2:	vpxor  %ymm1,%ymm0,%ymm0
 104f9c6:	jmp    104fa8b <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x12bb>
 104f9cb:	cmp    $0x4,%rdx
 104f9cf:	jb     104fa98 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x12c8>
 104f9d5:	mov    (%rdi),%ecx
 104f9d7:	mov    -0x4(%rdi,%rdx,1),%edi
 104f9db:	xor    (%rax),%ecx
 104f9dd:	xor    -0x4(%rax,%rdx,1),%edi
 104f9e1:	or     %ecx,%edi
 104f9e3:	jmp    104fa90 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x12c0>
 104f9e8:	mov    %rsi,%r14
 104f9eb:	mov    %rax,%rsi
 104f9ee:	cmp    $0x100,%rdx
 104f9f5:	ja     104faa9 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x12d9>
 104f9fb:	vzeroupper
 104f9fe:	call   10ae350 <bcmp@plt>
 104fa03:	test   %eax,%eax
 104fa05:	setne  %bl
 104fa08:	jmp    104fab6 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x12e6>
 104fa0d:	vmovdqu -0x20(%rdi,%rdx,1),%ymm1
 104fa13:	vinserti128 $0x1,0x10(%rdi),%ymm0,%ymm0
 104fa1a:	vpxor  -0x20(%rsi,%rdx,1),%ymm1,%ymm1
 104fa20:	vpxor  (%rsi),%ymm0,%ymm0
 104fa24:	vpor   %ymm1,%ymm0,%ymm0
 104fa28:	xor    %eax,%eax
 104fa2a:	vptest %ymm0,%ymm0
 104fa2f:	sete   %al
 104fa32:	jmp    104f19f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x9cf>
 104fa37:	cmp    $0x1,%rdx
 104fa3b:	jne    1050dbe <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x25ee>
 104fa41:	movzbl (%rdi),%eax
 104fa44:	cmp    (%rsi),%al
 104fa46:	jmp    1050dd1 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2601>
 104fa4b:	vzeroupper
 104fa4e:	call   10943e0 <equal_large_octets>
 104fa53:	jmp    104f19f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x9cf>
 104fa58:	movzwl (%rdi),%ecx
 104fa5b:	movzwl -0x2(%rdi,%rdx,1),%edi
 104fa60:	xor    (%rax),%cx
 104fa63:	xor    -0x2(%rax,%rdx,1),%di
 104fa68:	or     %cx,%di
 104fa6b:	jmp    104f659 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xe89>
 104fa70:	vmovdqu -0x20(%rdi,%rdx,1),%ymm1
 104fa76:	vinserti128 $0x1,0x10(%rdi),%ymm0,%ymm0
 104fa7d:	vpxor  -0x20(%rax,%rdx,1),%ymm1,%ymm1
 104fa83:	vpxor  (%rax),%ymm0,%ymm0
 104fa87:	vpor   %ymm1,%ymm0,%ymm0
 104fa8b:	vptest %ymm0,%ymm0
 104fa90:	sete   %bl
 104fa93:	xor    $0x1,%bl
 104fa96:	jmp    104fab9 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x12e9>
 104fa98:	cmp    $0x1,%rdx
 104fa9c:	jne    1050ddc <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x260c>
 104faa2:	movzbl (%rdi),%ecx
 104faa5:	cmp    (%rax),%cl
 104faa7:	jmp    104fa90 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x12c0>
 104faa9:	vzeroupper
 104faac:	call   10943e0 <equal_large_octets>
 104fab1:	test   %eax,%eax
 104fab3:	sete   %bl
 104fab6:	mov    %r14,%rsi
 104fab9:	test   %r13,0x6c1c8(%rip)        # 10bbc88 <myl_lit_4d6ff6f7284ab5ea56c67ebc627dbe0fd0bb153a04fdd105bd867658d486b6d7_instance>
 104fac0:	je     104faef <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x131f>
 104fac2:	test   %bl,%bl
 104fac4:	je     104fb14 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1344>
 104fac6:	movq   $0x10bbb60,0x78(%rsp)
 104facf:	movq   $0x10bbb60,0xd0(%rsp)
 104fadb:	cmp    $0x10bbb60,%rsi
 104fae2:	jne    1050c24 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2454>
 104fae8:	xor    %ebx,%ebx
 104faea:	jmp    1050e3d <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x266d>
 104faef:	mov    0x6c182(%rip),%rax        # 10bbc78 <myl_lit_4b4df4d43798003d79847faa0fc7a8aff0b04bace93d5fc2cc109ef7308827f6_instance+0x38>
 104faf6:	dec    %rax
 104faf9:	jne    104fb09 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1339>
 104fafb:	cmpq   $0x0,0x6c17d(%rip)        # 10bbc80 <myl_lit_4b4df4d43798003d79847faa0fc7a8aff0b04bace93d5fc2cc109ef7308827f6_instance+0x40>
 104fb03:	je     1050cce <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x24fe>
 104fb09:	mov    %rax,0x6c168(%rip)        # 10bbc78 <myl_lit_4b4df4d43798003d79847faa0fc7a8aff0b04bace93d5fc2cc109ef7308827f6_instance+0x38>
 104fb10:	test   %bl,%bl
 104fb12:	jne    104fac6 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x12f6>
 104fb14:	movabs $0x5000000000000000,%rcx
 104fb1e:	movabs $0x101010101010101,%r15
 104fb28:	lea    0x38(%rsp),%rdx
 104fb2d:	lea    0x78(%rsp),%rsi
 104fb32:	mov    %rsi,%rax
 104fb35:	sub    %rdx,%rax
 104fb38:	sub    %rsi,%rdx
 104fb3b:	cmovb  %rax,%rdx
 104fb3f:	mov    %rdx,0x138(%rsp)
 104fb47:	lea    0x70(%rsp),%rdx
 104fb4c:	lea    0x68(%rsp),%rsi
 104fb51:	mov    %rsi,%rax
 104fb54:	sub    %rdx,%rax
 104fb57:	sub    %rsi,%rdx
 104fb5a:	cmovb  %rax,%rdx
 104fb5e:	mov    %rdx,0x190(%rsp)
 104fb66:	xor    %r12d,%r12d
 104fb69:	lea    0x1(%rcx),%rax
 104fb6d:	mov    %rax,0xf8(%rsp)
 104fb75:	vpbroadcastd -0x489fa(%rip),%xmm9        # 1007184 <__abi_tag+0x6e88>
 104fb7e:	vpbroadcastd -0x48a03(%rip),%ymm10        # 1007184 <__abi_tag+0x6e88>
 104fb87:	vpbroadcastq -0x48a78(%rip),%ymm0        # 1007118 <__abi_tag+0x6e1c>
 104fb90:	vmovdqu %ymm0,0x200(%rsp)
 104fb99:	xor    %eax,%eax
 104fb9b:	vmovdqa %xmm9,0x50(%rsp)
 104fba1:	vmovdqu %ymm10,0x110(%rsp)
 104fbaa:	nopw   0x0(%rax,%rax,1)
 104fbb0:	mov    %rax,0x20(%rsp)
 104fbb5:	mov    0x10(%rsp),%rsi
 104fbba:	add    %r12,%rsi
 104fbbd:	jo     10522f9 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3b29>
 104fbc3:	mov    0x30(%rsp),%rax
 104fbc8:	mov    0x8(%rax),%rax
 104fbcc:	and    $0x1,%esi
 104fbcf:	mov    (%rax),%rdx
 104fbd2:	cmp    %rdx,%rsi
 104fbd5:	jae    10522ec <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3b1c>
 104fbdb:	mov    0x20(%rax),%rax
 104fbdf:	mov    (%rax,%rsi,8),%r14
 104fbe3:	test   %rsi,%rsi
 104fbe6:	jne    104fc90 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x14c0>
 104fbec:	movq   $0x10bc9b0,0x78(%rsp)
 104fbf5:	movq   $0x10bc9b0,0xd0(%rsp)
 104fc01:	movq   $0x10bc9b0,0x38(%rsp)
 104fc0a:	mov    0x6cd8f(%rip),%rax        # 10bc9a0 <myl_lit_f3eaad558815542caf7da2bdfda9d4cabeaf9c2200b79ab8ff85b21b8470fac6_instance>
 104fc11:	test   %rax,0xf8(%rsp)
 104fc19:	je     104fd25 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1555>
 104fc1f:	cmpq   $0x0,0x138(%rsp)
 104fc28:	setne  %cl
 104fc2b:	movabs $0x5000000000000000,%rdx
 104fc35:	test   %rdx,%rax
 104fc38:	sete   %dl
 104fc3b:	mov    $0x10bc9b0,%eax
 104fc40:	test   %cl,%dl
 104fc42:	jne    104fd20 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1550>
 104fc48:	mov    $0x1030c78,%esi
 104fc4d:	mov    0x18(%rsp),%rdi
 104fc52:	lea    0x78(%rsp),%rdx
 104fc57:	lea    0x38(%rsp),%rcx
 104fc5c:	mov    0x44(%rsp),%r8d
 104fc61:	vzeroupper
 104fc64:	call   10a9100 <myl_rc_native_take>
 104fc69:	vmovdqu 0x110(%rsp),%ymm10
 104fc72:	vmovdqa 0x50(%rsp),%xmm9
 104fc78:	test   %eax,%eax
 104fc7a:	jne    104fd2e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x155e>
 104fc80:	jmp    1050c5c <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x248c>
 104fc85:	data16 cs nopw 0x0(%rax,%rax,1)
 104fc90:	movq   $0x10bbd20,0x78(%rsp)
 104fc99:	movq   $0x10bbd20,0xd0(%rsp)
 104fca5:	movq   $0x10bbd20,0x38(%rsp)
 104fcae:	mov    0x6c05b(%rip),%rax        # 10bbd10 <myl_lit_54807ae7ae90f7f8ab8705f04b17dcd2d77e7355f27b7f7252156b0c234f7d3f_instance>
 104fcb5:	test   %rax,0xf8(%rsp)
 104fcbd:	je     104fd25 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1555>
 104fcbf:	cmpq   $0x0,0x138(%rsp)
 104fcc8:	setne  %cl
 104fccb:	movabs $0x5000000000000000,%rdx
 104fcd5:	test   %rdx,%rax
 104fcd8:	sete   %dl
 104fcdb:	mov    $0x10bbd20,%eax
 104fce0:	test   %cl,%dl
 104fce2:	jne    104fd20 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1550>
 104fce4:	mov    $0x1030c78,%esi
 104fce9:	mov    0x18(%rsp),%rdi
 104fcee:	lea    0x78(%rsp),%rdx
 104fcf3:	lea    0x38(%rsp),%rcx
 104fcf8:	mov    0x44(%rsp),%r8d
 104fcfd:	vzeroupper
 104fd00:	call   10a9100 <myl_rc_native_take>
 104fd05:	vmovdqu 0x110(%rsp),%ymm10
 104fd0e:	vmovdqa 0x50(%rsp),%xmm9
 104fd14:	test   %eax,%eax
 104fd16:	jne    104fd2e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x155e>
 104fd18:	jmp    1050c95 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x24c5>
 104fd1d:	nopl   (%rax)
 104fd20:	mov    %rax,0x78(%rsp)
 104fd25:	movq   $0x0,0x38(%rsp)
 104fd2e:	mov    0x78(%rsp),%rdx
 104fd33:	movq   $0x0,0x260(%rsp)
 104fd3f:	movq   $0x0,0x240(%rsp)
 104fd4b:	mov    0x8(%rsp),%rax
 104fd50:	cmp    %rsp,0x40(%rax)
 104fd54:	ja     1052310 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3b40>
 104fd5a:	cmpq   $0x0,(%rdx)
 104fd5e:	je     105231d <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3b4d>
 104fd64:	mov    0x8(%rsp),%rax
 104fd69:	mov    0x2c8(%rax),%esi
 104fd6f:	mov    %r14,0xc8(%rsp)
 104fd77:	mov    %rdx,0x148(%rsp)
 104fd7f:	testb  $0x4,0x10(%r14)
 104fd84:	jne    104fdb0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x15e0>
 104fd86:	lea    0x18(%r14),%rbx
 104fd8a:	mov    %r12,0x1a8(%rsp)
 104fd92:	testb  $0x4,0x10(%rdx)
 104fd96:	je     104fdce <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x15fe>
 104fd98:	mov    0x18(%rdx),%rax
 104fd9c:	mov    0x14(%rdx),%ecx
 104fd9f:	lea    (%rax,%rcx,1),%r13
 104fda3:	add    $0x18,%r13
 104fda7:	jmp    104fdd2 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1602>
 104fda9:	nopl   0x0(%rax)
 104fdb0:	mov    0x18(%r14),%rax
 104fdb4:	mov    0x14(%r14),%ecx
 104fdb8:	lea    (%rax,%rcx,1),%rbx
 104fdbc:	add    $0x18,%rbx
 104fdc0:	mov    %r12,0x1a8(%rsp)
 104fdc8:	testb  $0x4,0x10(%rdx)
 104fdcc:	jne    104fd98 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x15c8>
 104fdce:	lea    0x18(%rdx),%r13
 104fdd2:	mov    0x8(%rdx),%rcx
 104fdd6:	mov    0x8(%r14),%r14
 104fdda:	lea    -0x1(%rcx),%rax
 104fdde:	cmp    %r14,%rax
 104fde1:	mov    %rcx,0x100(%rsp)
 104fde9:	mov    %rdx,0x1a0(%rsp)
 104fdf1:	mov    %esi,0x10c(%rsp)
 104fdf8:	jae    104fff0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1820>
 104fdfe:	cmp    $0x1,%rcx
 104fe02:	jne    1050000 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1830>
 104fe08:	movzbl 0x0(%r13),%eax
 104fe0d:	vmovd  %eax,%xmm0
 104fe11:	vpbroadcastb %xmm0,%xmm0
 104fe16:	lea    0x18(%rbx),%rcx
 104fe1a:	xor    %r12d,%r12d
 104fe1d:	xor    %edx,%edx
 104fe1f:	mov    $0x10000,%r11d
 104fe25:	jmp    104fe42 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1672>
 104fe27:	nopw   0x0(%rax,%rax,1)
 104fe30:	mov    %r9d,%edi
 104fe33:	add    %rdi,%r12
 104fe36:	add    %rsi,%rdx
 104fe39:	cmp    %r14,%rdx
 104fe3c:	jae    1050053 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1883>
 104fe42:	mov    %r14,%rsi
 104fe45:	sub    %rdx,%rsi
 104fe48:	cmp    $0x10000,%rsi
 104fe4f:	cmovae %r11,%rsi
 104fe53:	mov    %r14,%r8
 104fe56:	sub    %rdx,%r8
 104fe59:	jne    104fe70 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x16a0>
 104fe5b:	xor    %edi,%edi
 104fe5d:	add    %rdi,%r12
 104fe60:	add    %rsi,%rdx
 104fe63:	cmp    %r14,%rdx
 104fe66:	jb     104fe42 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1672>
 104fe68:	jmp    1050053 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1883>
 104fe6d:	nopl   (%rax)
 104fe70:	lea    (%rbx,%rdx,1),%rdi
 104fe74:	cmp    $0x3,%r8
 104fe78:	ja     104fe90 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x16c0>
 104fe7a:	xor    %r8d,%r8d
 104fe7d:	xor    %r9d,%r9d
 104fe80:	jmp    104ffd0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1800>
 104fe85:	data16 cs nopw 0x0(%rax,%rax,1)
 104fe90:	cmp    $0x20,%r8
 104fe94:	jae    104fea1 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x16d1>
 104fe96:	xor    %r8d,%r8d
 104fe99:	xor    %r9d,%r9d
 104fe9c:	jmp    104ff74 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x17a4>
 104fea1:	mov    %esi,%r8d
 104fea4:	and    $0x1ffe0,%r8d
 104feab:	lea    (%rcx,%rdx,1),%r9
 104feaf:	vpxor  %xmm1,%xmm1,%xmm1
 104feb3:	xor    %r10d,%r10d
 104feb6:	vpxor  %xmm2,%xmm2,%xmm2
 104feba:	vpxor  %xmm3,%xmm3,%xmm3
 104febe:	vpxor  %xmm4,%xmm4,%xmm4
 104fec2:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 104fed0:	vmovq  -0x18(%r9,%r10,1),%xmm5
 104fed7:	vmovq  -0x10(%r9,%r10,1),%xmm6
 104fede:	vmovq  -0x8(%r9,%r10,1),%xmm7
 104fee5:	vmovq  (%r9,%r10,1),%xmm8
 104feeb:	vpcmpeqb %xmm0,%xmm5,%xmm5
 104feef:	vpmovzxbd %xmm5,%ymm5
 104fef4:	vpand  %ymm5,%ymm10,%ymm5
 104fef8:	vpaddd %ymm5,%ymm1,%ymm1
 104fefc:	vpcmpeqb %xmm0,%xmm6,%xmm5
 104ff00:	vpmovzxbd %xmm5,%ymm5
 104ff05:	vpand  %ymm5,%ymm10,%ymm5
 104ff09:	vpaddd %ymm5,%ymm2,%ymm2
 104ff0d:	vpcmpeqb %xmm0,%xmm7,%xmm5
 104ff11:	vpmovzxbd %xmm5,%ymm5
 104ff16:	vpand  %ymm5,%ymm10,%ymm5
 104ff1a:	vpaddd %ymm5,%ymm3,%ymm3
 104ff1e:	vpcmpeqb %xmm0,%xmm8,%xmm5
 104ff22:	vpmovzxbd %xmm5,%ymm5
 104ff27:	vpand  %ymm5,%ymm10,%ymm5
 104ff2b:	vpaddd %ymm5,%ymm4,%ymm4
 104ff2f:	add    $0x20,%r10
 104ff33:	cmp    %r10,%r8
 104ff36:	jne    104fed0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1700>
 104ff38:	vpaddd %ymm1,%ymm2,%ymm1
 104ff3c:	vpaddd %ymm1,%ymm3,%ymm1
 104ff40:	vpaddd %ymm1,%ymm4,%ymm1
 104ff44:	vextracti128 $0x1,%ymm1,%xmm2
 104ff4a:	vpaddd %xmm2,%xmm1,%xmm1
 104ff4e:	vpshufd $0xee,%xmm1,%xmm2
 104ff53:	vpaddd %xmm2,%xmm1,%xmm1
 104ff57:	vpshufd $0x55,%xmm1,%xmm2
 104ff5c:	vpaddd %xmm2,%xmm1,%xmm1
 104ff60:	vmovd  %xmm1,%r9d
 104ff65:	cmp    %r8,%rsi
 104ff68:	je     104fe30 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1660>
 104ff6e:	test   $0x1c,%sil
 104ff72:	je     104ffd0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1800>
 104ff74:	mov    %r8,%r10
 104ff77:	mov    %esi,%r8d
 104ff7a:	and    $0x1fffc,%r8d
 104ff81:	vmovd  %r9d,%xmm1
 104ff86:	cs nopw 0x0(%rax,%rax,1)
 104ff90:	vmovd  (%rdi,%r10,1),%xmm2
 104ff96:	vpcmpeqb %xmm0,%xmm2,%xmm2
 104ff9a:	vpmovzxbd %xmm2,%xmm2
 104ff9f:	vpand  %xmm2,%xmm9,%xmm2
 104ffa3:	vpaddd %xmm2,%xmm1,%xmm1
 104ffa7:	add    $0x4,%r10
 104ffab:	cmp    %r10,%r8
 104ffae:	jne    104ff90 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x17c0>
 104ffb0:	vpshufd $0xee,%xmm1,%xmm2
 104ffb5:	vpaddd %xmm2,%xmm1,%xmm1
 104ffb9:	vpshufd $0x55,%xmm1,%xmm2
 104ffbe:	vpaddd %xmm2,%xmm1,%xmm1
 104ffc2:	vmovd  %xmm1,%r9d
 104ffc7:	jmp    104ffe1 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1811>
 104ffc9:	nopl   0x0(%rax)
 104ffd0:	xor    %r10d,%r10d
 104ffd3:	cmp    %al,(%rdi,%r8,1)
 104ffd7:	sete   %r10b
 104ffdb:	add    %r10d,%r9d
 104ffde:	inc    %r8
 104ffe1:	cmp    %r8,%rsi
 104ffe4:	jne    104ffd0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1800>
 104ffe6:	jmp    104fe30 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1660>
 104ffeb:	nopl   0x0(%rax,%rax,1)
 104fff0:	xor    %r12d,%r12d
 104fff3:	jmp    1050053 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1883>
 104fff5:	data16 cs nopw 0x0(%rax,%rax,1)
 1050000:	mov    %rbx,%rdi
 1050003:	mov    %r14,%rsi
 1050006:	mov    %r13,%rdx
 1050009:	vzeroupper
 105000c:	call   1094440 <myl_native_octets_find>
 1050011:	xor    %r12d,%r12d
 1050014:	xor    %r15d,%r15d
 1050017:	cmp    $0xffffffffffffffff,%rax
 105001b:	je     1050049 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1879>
 105001d:	nopl   (%rax)
 1050020:	mov    0x100(%rsp),%rcx
 1050028:	add    %rcx,%r15
 105002b:	add    %rax,%r15
 105002e:	inc    %r12
 1050031:	lea    (%rbx,%r15,1),%rdi
 1050035:	mov    %r14,%rsi
 1050038:	sub    %r15,%rsi
 105003b:	mov    %r13,%rdx
 105003e:	call   1094440 <myl_native_octets_find>
 1050043:	cmp    $0xffffffffffffffff,%rax
 1050047:	jne    1050020 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1850>
 1050049:	movabs $0x101010101010101,%r15
 1050053:	inc    %r12
 1050056:	mov    0x8(%rsp),%r14
 105005b:	mov    0x268(%r14),%rax
 1050062:	mov    %rax,0x1b8(%rsp)
 105006a:	lea    0xc8(%rsp),%rax
 1050072:	mov    %rax,0x1c0(%rsp)
 105007a:	movq   $0x1031628,0x1c8(%rsp)
 1050086:	lea    0x1b8(%rsp),%rax
 105008e:	mov    %rax,0x170(%rsp)
 1050096:	lea    0x148(%rsp),%rax
 105009e:	mov    %rax,0x178(%rsp)
 10500a6:	movq   $0x1031628,0x180(%rsp)
 10500b2:	lea    0x170(%rsp),%rax
 10500ba:	mov    %rax,0x268(%r14)
 10500c1:	mov    $0x1031628,%esi
 10500c6:	mov    0x18(%rsp),%rdi
 10500cb:	mov    %r12,%rdx
 10500ce:	vzeroupper
 10500d1:	call   1090520 <myl_native_list_new>
 10500d6:	mov    %rax,%rbx
 10500d9:	mov    %rax,0xc0(%rsp)
 10500e1:	mov    0x268(%r14),%rax
 10500e8:	mov    %rax,0x150(%rsp)
 10500f0:	lea    0xc0(%rsp),%rax
 10500f8:	mov    %rax,0x158(%rsp)
 1050100:	movq   $0x1031628,0x160(%rsp)
 105010c:	lea    0x150(%rsp),%rax
 1050114:	mov    %rax,0x268(%r14)
 105011b:	test   %rbx,%rbx
 105011e:	je     105066c <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1e9c>
 1050124:	mov    0xc8(%rsp),%r13
 105012c:	mov    0x10(%r13),%ecx
 1050130:	lea    0x18(%r13),%rax
 1050134:	mov    %rax,0xa0(%rsp)
 105013c:	mov    %ecx,0xbc(%rsp)
 1050143:	test   $0x4,%cl
 1050146:	vmovdqa -0x4e71e(%rip),%xmm8        # 1001a30 <__abi_tag+0x1734>
 105014e:	vmovdqu 0x200(%rsp),%ymm9
 1050157:	vmovdqa -0x4e72f(%rip),%xmm10        # 1001a30 <__abi_tag+0x1734>
 105015f:	je     1050178 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x19a8>
 1050161:	mov    0x18(%r13),%rcx
 1050165:	mov    0x14(%r13),%edx
 1050169:	add    %rdx,%rcx
 105016c:	add    $0x18,%rcx
 1050170:	mov    %rcx,0xa0(%rsp)
 1050178:	mov    0x148(%rsp),%rcx
 1050180:	testb  $0x4,0x10(%rcx)
 1050184:	jne    10501b0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x19e0>
 1050186:	add    $0x18,%rcx
 105018a:	mov    %rcx,0x140(%rsp)
 1050192:	mov    %r13,%rcx
 1050195:	testb  $0x4,0xbc(%rsp)
 105019d:	jne    10501d6 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1a06>
 105019f:	jmp    10501d9 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1a09>
 10501a1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 10501b0:	mov    %rcx,%rdx
 10501b3:	mov    0x18(%rcx),%rcx
 10501b7:	mov    0x14(%rdx),%edx
 10501ba:	add    %rdx,%rcx
 10501bd:	add    $0x18,%rcx
 10501c1:	mov    %rcx,0x140(%rsp)
 10501c9:	mov    %r13,%rcx
 10501cc:	testb  $0x4,0xbc(%rsp)
 10501d4:	je     10501d9 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1a09>
 10501d6:	mov    (%rax),%rcx
 10501d9:	mov    0x8(%rcx),%rcx
 10501dd:	shr    $0x2,%rcx
 10501e1:	cmp    $0xa,%rcx
 10501e5:	mov    $0x9,%eax
 10501ea:	cmovb  %rax,%rcx
 10501ee:	mov    %rcx,0x1b0(%rsp)
 10501f6:	mov    0xa0(%rsp),%rax
 10501fe:	add    $0xc,%rax
 1050202:	mov    %rax,0x198(%rsp)
 105020a:	xor    %ebp,%ebp
 105020c:	mov    0x100(%rsp),%rcx
 1050214:	cmp    $0x1,%r12
 1050218:	je     10502c0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1af0>
 105021e:	xchg   %ax,%ax
 1050220:	test   %r12,%r12
 1050223:	je     105066e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1e9e>
 1050229:	mov    0xa0(%rsp),%rax
 1050231:	lea    (%rax,%rbp,1),%rdi
 1050235:	mov    0x8(%r13),%rbx
 1050239:	mov    %rbx,%rsi
 105023c:	sub    %rbp,%rsi
 105023f:	mov    0x140(%rsp),%rdx
 1050247:	vzeroupper
 105024a:	call   1094440 <myl_native_octets_find>
 105024f:	vmovdqa -0x4e827(%rip),%xmm10        # 1001a30 <__abi_tag+0x1734>
 1050257:	vmovdqu 0x200(%rsp),%ymm9
 1050260:	vmovdqa -0x4e838(%rip),%xmm8        # 1001a30 <__abi_tag+0x1734>
 1050268:	lea    (%rax,%rbp,1),%r14
 105026c:	cmp    $0xffffffffffffffff,%rax
 1050270:	cmove  %rbx,%r14
 1050274:	mov    %r14,%rbx
 1050277:	sub    %rbp,%rbx
 105027a:	cmp    0x1b0(%rsp),%rbx
 1050282:	jb     10502d4 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1b04>
 1050284:	mov    0x18(%rsp),%rdi
 1050289:	mov    %r13,%rsi
 105028c:	mov    %rbp,%rdx
 105028f:	mov    %rbx,%rcx
 1050292:	mov    $0xffffffffffffffff,%r8
 1050299:	vzeroupper
 105029c:	call   1092de0 <long_piece>
 10502a1:	mov    %rax,%r15
 10502a4:	test   %rax,%rax
 10502a7:	jne    1050550 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1d80>
 10502ad:	jmp    10505e0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1e10>
 10502b2:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 10502c0:	mov    0x8(%r13),%r14
 10502c4:	mov    %r14,%rbx
 10502c7:	sub    %rbp,%rbx
 10502ca:	cmp    0x1b0(%rsp),%rbx
 10502d2:	jae    1050284 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1ab4>
 10502d4:	mov    0xa0(%rsp),%rax
 10502dc:	lea    (%rax,%rbp,1),%r13
 10502e0:	testb  $0x1,0xbc(%rsp)
 10502e8:	jne    10504ba <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1cea>
 10502ee:	cmp    $0x8,%rbx
 10502f2:	jae    1050300 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1b30>
 10502f4:	xor    %ecx,%ecx
 10502f6:	xor    %eax,%eax
 10502f8:	jmp    1050347 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1b77>
 10502fa:	nopw   0x0(%rax,%rax,1)
 1050300:	xor    %edx,%edx
 1050302:	xor    %ecx,%ecx
 1050304:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 1050310:	mov    0x0(%r13,%rdx,1),%rax
 1050315:	mov    %rax,%rsi
 1050318:	not    %rsi
 105031b:	add    %rsi,%rsi
 105031e:	and    %rax,%rsi
 1050321:	shr    $0x7,%rsi
 1050325:	and    %r15,%rsi
 1050328:	imul   %r15,%rsi
 105032c:	shr    $0x38,%rsi
 1050330:	sub    %rsi,%rcx
 1050333:	add    $0x8,%rcx
 1050337:	lea    0x8(%rdx),%rax
 105033b:	add    $0x10,%rdx
 105033f:	cmp    %rbx,%rdx
 1050342:	mov    %rax,%rdx
 1050345:	jbe    1050310 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1b40>
 1050347:	cmp    %rbx,%rax
 105034a:	jae    10504b5 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1ce5>
 1050350:	lea    (%rax,%rbp,1),%rdi
 1050354:	mov    %r14,%rdx
 1050357:	sub    %rdi,%rdx
 105035a:	cmp    $0x3,%rdx
 105035e:	mov    0xa0(%rsp),%r8
 1050366:	jbe    1050490 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1cc0>
 105036c:	cmp    $0x10,%rdx
 1050370:	jae    1050379 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1ba9>
 1050372:	xor    %esi,%esi
 1050374:	jmp    105043e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1c6e>
 1050379:	mov    %rdx,%rsi
 105037c:	and    $0xfffffffffffffff0,%rsi
 1050380:	vmovq  %rcx,%xmm0
 1050385:	add    0x198(%rsp),%rdi
 105038d:	vpxor  %xmm1,%xmm1,%xmm1
 1050391:	xor    %ecx,%ecx
 1050393:	vpxor  %xmm2,%xmm2,%xmm2
 1050397:	vpxor  %xmm3,%xmm3,%xmm3
 105039b:	nopl   0x0(%rax,%rax,1)
 10503a0:	vmovd  -0xc(%rdi,%rcx,1),%xmm4
 10503a6:	vmovd  -0x8(%rdi,%rcx,1),%xmm5
 10503ac:	vmovd  -0x4(%rdi,%rcx,1),%xmm6
 10503b2:	vmovd  (%rdi,%rcx,1),%xmm7
 10503b7:	vpcmpgtb %xmm10,%xmm4,%xmm4
 10503bc:	vpmovzxbq %xmm4,%ymm4
 10503c1:	vpand  %ymm4,%ymm9,%ymm4
 10503c5:	vpaddq %ymm4,%ymm0,%ymm0
 10503c9:	vpcmpgtb %xmm10,%xmm5,%xmm4
 10503ce:	vpmovzxbq %xmm4,%ymm4
 10503d3:	vpand  %ymm4,%ymm9,%ymm4
 10503d7:	vpaddq %ymm4,%ymm1,%ymm1
 10503db:	vpcmpgtb %xmm10,%xmm6,%xmm4
 10503e0:	vpmovzxbq %xmm4,%ymm4
 10503e5:	vpand  %ymm4,%ymm9,%ymm4
 10503e9:	vpaddq %ymm4,%ymm2,%ymm2
 10503ed:	vpcmpgtb %xmm10,%xmm7,%xmm4
 10503f2:	vpmovzxbq %xmm4,%ymm4
 10503f7:	vpand  %ymm4,%ymm9,%ymm4
 10503fb:	vpaddq %ymm4,%ymm3,%ymm3
 10503ff:	add    $0x10,%rcx
 1050403:	cmp    %rcx,%rsi
 1050406:	jne    10503a0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1bd0>
 1050408:	vpaddq %ymm0,%ymm1,%ymm0
 105040c:	vpaddq %ymm0,%ymm2,%ymm0
 1050410:	vpaddq %ymm0,%ymm3,%ymm0
 1050414:	vextracti128 $0x1,%ymm0,%xmm1
 105041a:	vpaddq %xmm1,%xmm0,%xmm0
 105041e:	vpshufd $0xee,%xmm0,%xmm1
 1050423:	vpaddq %xmm1,%xmm0,%xmm0
 1050427:	vmovq  %xmm0,%rcx
 105042c:	cmp    %rsi,%rdx
 105042f:	je     10504b5 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1ce5>
 1050435:	test   $0xc,%dl
 1050438:	je     10505cb <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1dfb>
 105043e:	mov    %rdx,%rdi
 1050441:	and    $0xfffffffffffffffc,%rdi
 1050445:	vmovq  %rcx,%xmm0
 105044a:	lea    (%rax,%r13,1),%rcx
 105044e:	xchg   %ax,%ax
 1050450:	vmovd  (%rcx,%rsi,1),%xmm1
 1050455:	vpcmpgtb %xmm8,%xmm1,%xmm1
 105045a:	vpmovzxbq %xmm1,%ymm1
 105045f:	vpand  %ymm1,%ymm9,%ymm1
 1050463:	vpaddq %ymm1,%ymm0,%ymm0
 1050467:	add    $0x4,%rsi
 105046b:	cmp    %rsi,%rdi
 105046e:	jne    1050450 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1c80>
 1050470:	vextracti128 $0x1,%ymm0,%xmm1
 1050476:	vpaddq %xmm1,%xmm0,%xmm0
 105047a:	vpshufd $0xee,%xmm0,%xmm1
 105047f:	vpaddq %xmm1,%xmm0,%xmm0
 1050483:	vmovq  %xmm0,%rcx
 1050488:	cmp    %rdi,%rdx
 105048b:	je     10504b5 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1ce5>
 105048d:	add    %rdi,%rax
 1050490:	add    %rbp,%rax
 1050493:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 10504a0:	xor    %edx,%edx
 10504a2:	cmpb   $0xc0,(%r8,%rax,1)
 10504a7:	setge  %dl
 10504aa:	add    %rdx,%rcx
 10504ad:	inc    %rax
 10504b0:	cmp    %rax,%r14
 10504b3:	jne    10504a0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1cd0>
 10504b5:	cmp    %rbx,%rcx
 10504b8:	jne    1050530 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1d60>
 10504ba:	mov    0x8(%rsp),%rax
 10504bf:	cmpq   $0x0,0x1860(%rax)
 10504c7:	je     105066c <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1e9c>
 10504cd:	lea    0x18(%rbx),%rsi
 10504d1:	mov    0x8(%rsp),%rax
 10504d6:	mov    0x2c8(%rax),%edx
 10504dc:	mov    0x18(%rsp),%rdi
 10504e1:	xor    %ecx,%ecx
 10504e3:	vzeroupper
 10504e6:	call   10a88a0 <raw_bytes>
 10504eb:	test   %rax,%rax
 10504ee:	je     10505e0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1e10>
 10504f4:	mov    %rax,%r15
 10504f7:	movq   $0x0,(%rax)
 10504fe:	mov    %rbx,0x8(%rax)
 1050502:	movq   $0x0,0x10(%rax)
 105050a:	cmp    %rbp,%r14
 105050d:	je     1050521 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1d51>
 105050f:	mov    %r15,%rdi
 1050512:	add    $0x18,%rdi
 1050516:	mov    %r13,%rsi
 1050519:	mov    %rbx,%rdx
 105051c:	call   10ae310 <memcpy@plt>
 1050521:	mov    %rbx,(%r15)
 1050524:	movl   $0x1,0x10(%r15)
 105052c:	jmp    1050550 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1d80>
 105052e:	xchg   %ax,%ax
 1050530:	mov    0x18(%rsp),%rdi
 1050535:	mov    %r13,%rsi
 1050538:	mov    %rbx,%rdx
 105053b:	vzeroupper
 105053e:	call   1091d40 <build_wide>
 1050543:	mov    %rax,%r15
 1050546:	test   %rax,%rax
 1050549:	je     10505e0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1e10>
 105054f:	nop
 1050550:	mov    0xc0(%rsp),%rax
 1050558:	mov    (%rax),%rcx
 105055b:	mov    0x20(%rax),%rdx
 105055f:	lea    0x1(%rcx),%rsi
 1050563:	mov    %rsi,(%rax)
 1050566:	mov    %r15,(%rdx,%rcx,8)
 105056a:	mov    0xc0(%rsp),%rbx
 1050572:	incq   0x10(%rbx)
 1050576:	mov    0xc8(%rsp),%r13
 105057e:	cmp    0x8(%r13),%r14
 1050582:	je     105066e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1e9e>
 1050588:	mov    0x100(%rsp),%rcx
 1050590:	add    %rcx,%r14
 1050593:	dec    %r12
 1050596:	mov    %r14,%rbp
 1050599:	movabs $0x101010101010101,%r15
 10505a3:	vmovdqa -0x4eb7b(%rip),%xmm8        # 1001a30 <__abi_tag+0x1734>
 10505ab:	vmovdqu 0x200(%rsp),%ymm9
 10505b4:	vmovdqa -0x4eb8c(%rip),%xmm10        # 1001a30 <__abi_tag+0x1734>
 10505bc:	cmp    $0x1,%r12
 10505c0:	jne    1050220 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1a50>
 10505c6:	jmp    10502c0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1af0>
 10505cb:	add    %rsi,%rax
 10505ce:	jmp    1050490 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1cc0>
 10505d3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 10505e0:	mov    0x8(%rsp),%rax
 10505e5:	cmpq   $0x0,0x1860(%rax)
 10505ed:	movabs $0x4000000000000002,%r13
 10505f7:	je     105066c <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1e9c>
 10505f9:	mov    0xc0(%rsp),%rbx
 1050601:	mov    0x18(%rbx),%rax
 1050605:	cmpw   $0x1,0x30(%rax)
 105060a:	jne    1052205 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3a35>
 1050610:	mov    (%rbx),%rax
 1050613:	test   %rax,%rax
 1050616:	je     105065f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1e8f>
 1050618:	mov    0xc8(%rsp),%r14
 1050620:	mov    0x20(%rbx),%r15
 1050624:	xor    %r12d,%r12d
 1050627:	jmp    1050638 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1e68>
 1050629:	nopl   0x0(%rax)
 1050630:	inc    %r12
 1050633:	cmp    %rax,%r12
 1050636:	jae    105065f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1e8f>
 1050638:	mov    (%r15,%r12,8),%rsi
 105063c:	test   %rsi,%rsi
 105063f:	je     1050630 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1e60>
 1050641:	cmp    %r14,%rsi
 1050644:	je     1050630 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1e60>
 1050646:	lea    -0x2(%r13),%rcx
 105064a:	test   %rcx,-0x10(%rsi)
 105064e:	je     1050630 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1e60>
 1050650:	mov    0x18(%rsp),%rdi
 1050655:	call   10a0d20 <myl_rc_construction_abort>
 105065a:	mov    (%rbx),%rax
 105065d:	jmp    1050630 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1e60>
 105065f:	mov    0x18(%rsp),%rdi
 1050664:	mov    %rbx,%rsi
 1050667:	call   10a0d20 <myl_rc_construction_abort>
 105066c:	xor    %ebx,%ebx
 105066e:	mov    0x8(%rsp),%rax
 1050673:	mov    0x268(%rax),%rax
 105067a:	lea    0x150(%rsp),%rcx
 1050682:	cmp    %rcx,%rax
 1050685:	je     10506c0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1ef0>
 1050687:	lea    0x170(%rsp),%rcx
 105068f:	cmp    %rcx,%rax
 1050692:	je     10506e1 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1f11>
 1050694:	lea    0x1b8(%rsp),%rcx
 105069c:	cmp    %rcx,%rax
 105069f:	je     1050702 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1f32>
 10506a1:	test   %rbx,%rbx
 10506a4:	movabs $0x4000000000000002,%r13
 10506ae:	jne    1050729 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1f59>
 10506b0:	jmp    105232a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3b5a>
 10506b5:	data16 cs nopw 0x0(%rax,%rax,1)
 10506c0:	mov    0x150(%rsp),%rax
 10506c8:	mov    0x8(%rsp),%rcx
 10506cd:	mov    %rax,0x268(%rcx)
 10506d4:	lea    0x170(%rsp),%rcx
 10506dc:	cmp    %rcx,%rax
 10506df:	jne    1050694 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1ec4>
 10506e1:	mov    0x170(%rsp),%rax
 10506e9:	mov    0x8(%rsp),%rcx
 10506ee:	mov    %rax,0x268(%rcx)
 10506f5:	lea    0x1b8(%rsp),%rcx
 10506fd:	cmp    %rcx,%rax
 1050700:	jne    10506a1 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1ed1>
 1050702:	mov    0x1b8(%rsp),%rax
 105070a:	mov    0x8(%rsp),%rcx
 105070f:	mov    %rax,0x268(%rcx)
 1050716:	test   %rbx,%rbx
 1050719:	movabs $0x4000000000000002,%r13
 1050723:	je     105232a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3b5a>
 1050729:	mov    %rbx,0x68(%rsp)
 105072e:	mov    %rbx,0x70(%rsp)
 1050733:	mov    -0x10(%rbx),%rax
 1050737:	test   %rax,0xf8(%rsp)
 105073f:	je     1050760 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1f90>
 1050741:	movabs $0x5000000000000000,%rcx
 105074b:	test   %rcx,%rax
 105074e:	jne    1050780 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1fb0>
 1050750:	cmpq   $0x0,0x190(%rsp)
 1050759:	je     1050780 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1fb0>
 105075b:	mov    %rbx,0x68(%rsp)
 1050760:	movq   $0x0,0x70(%rsp)
 1050769:	mov    (%rbx),%r15
 105076c:	test   %r15,%r15
 105076f:	jns    10507bd <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1fed>
 1050771:	jmp    1052349 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3b79>
 1050776:	cs nopw 0x0(%rax,%rax,1)
 1050780:	mov    $0x100ba48,%esi
 1050785:	mov    0x18(%rsp),%rdi
 105078a:	lea    0x68(%rsp),%rdx
 105078f:	lea    0x70(%rsp),%rcx
 1050794:	mov    0x10c(%rsp),%r8d
 105079c:	vzeroupper
 105079f:	call   10a9100 <myl_rc_native_take>
 10507a4:	test   %eax,%eax
 10507a6:	je     1050a61 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2291>
 10507ac:	mov    0x68(%rsp),%rbx
 10507b1:	mov    (%rbx),%r15
 10507b4:	test   %r15,%r15
 10507b7:	js     1052349 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3b79>
 10507bd:	imul   $0x7,%r15,%r12
 10507c1:	vmovdqa 0x50(%rsp),%xmm9
 10507c7:	vmovdqu 0x110(%rsp),%ymm10
 10507d0:	jo     1052359 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3b89>
 10507d6:	test   %rbx,%rbx
 10507d9:	je     10507e5 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2015>
 10507db:	test   %r13,-0x10(%rbx)
 10507df:	je     10508f0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2120>
 10507e5:	mov    %rbx,0x68(%rsp)
 10507ea:	test   %r15,%r15
 10507ed:	je     105090f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x213f>
 10507f3:	xor    %ebp,%ebp
 10507f5:	data16 cs nopw 0x0(%rax,%rax,1)
 1050800:	mov    0x20(%rbx),%rax
 1050804:	mov    (%rax,%rbp,8),%r13
 1050808:	mov    %r13,0x70(%rsp)
 105080d:	test   %r13,%r13
 1050810:	je     1050833 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2063>
 1050812:	movabs $0x4000000000000002,%rax
 105081c:	test   %rax,-0x10(%r13)
 1050820:	jne    1050833 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2063>
 1050822:	mov    -0x18(%r13),%rax
 1050826:	inc    %rax
 1050829:	je     1050ba7 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x23d7>
 105082f:	mov    %rax,-0x18(%r13)
 1050833:	mov    %r13,0x68(%rsp)
 1050838:	movq   $0x0,0x70(%rsp)
 1050841:	mov    0x8(%rsp),%rdi
 1050846:	mov    %r13,%rsi
 1050849:	vzeroupper
 105084c:	call   10758b0 <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85>
 1050851:	mov    %r12,%r14
 1050854:	add    %rax,%r14
 1050857:	jo     1052224 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3a54>
 105085d:	test   %r13,%r13
 1050860:	vmovdqa 0x50(%rsp),%xmm9
 1050866:	vmovdqu 0x110(%rsp),%ymm10
 105086f:	je     1050895 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x20c5>
 1050871:	movabs $0x4000000000000002,%rax
 105087b:	test   %rax,-0x10(%r13)
 105087f:	jne    1050895 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x20c5>
 1050881:	mov    -0x18(%r13),%rax
 1050885:	dec    %rax
 1050888:	jne    1050891 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x20c1>
 105088a:	cmpq   $0x0,-0x20(%r13)
 105088f:	je     10508af <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x20df>
 1050891:	mov    %rax,-0x18(%r13)
 1050895:	cmp    %r15,(%rbx)
 1050898:	jne    1052236 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3a66>
 105089e:	inc    %rbp
 10508a1:	mov    %r14,%r12
 10508a4:	cmp    %rbp,%r15
 10508a7:	jne    1050800 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2030>
 10508ad:	jmp    1050912 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2142>
 10508af:	mov    0x18(%rsp),%r12
 10508b4:	mov    %r12,%rdi
 10508b7:	mov    %r13,%rsi
 10508ba:	vzeroupper
 10508bd:	call   109ccc0 <myl_rc_hold_edge_release>
 10508c2:	mov    %r12,%rdi
 10508c5:	call   109fce0 <myl_rc_drain>
 10508ca:	vmovdqu 0x110(%rsp),%ymm10
 10508d3:	vmovdqa 0x50(%rsp),%xmm9
 10508d9:	cmp    %r15,(%rbx)
 10508dc:	je     105089e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x20ce>
 10508de:	jmp    1052236 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3a66>
 10508e3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 10508f0:	mov    -0x18(%rbx),%rax
 10508f4:	inc    %rax
 10508f7:	je     1050b81 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x23b1>
 10508fd:	mov    %rax,-0x18(%rbx)
 1050901:	mov    %rbx,0x68(%rsp)
 1050906:	test   %r15,%r15
 1050909:	jne    10507f3 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2023>
 105090f:	mov    %r12,%r14
 1050912:	mov    0x240(%rsp),%eax
 1050919:	or     0x260(%rsp),%eax
 1050920:	movabs $0x4000000000000002,%r13
 105092a:	movabs $0x101010101010101,%r15
 1050934:	je     105096e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x219e>
 1050936:	mov    0x8(%rsp),%rax
 105093b:	mov    0x1860(%rax),%rax
 1050942:	test   %rax,%rax
 1050945:	je     1050950 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2180>
 1050947:	mov    0xf8(%rax),%rsi
 105094e:	jmp    1050952 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2182>
 1050950:	xor    %esi,%esi
 1050952:	mov    0x18(%rsp),%rdi
 1050957:	vzeroupper
 105095a:	call   10a3310 <myl_rc_scope_unwind>
 105095f:	vmovdqa 0x50(%rsp),%xmm9
 1050965:	vmovdqu 0x110(%rsp),%ymm10
 105096e:	test   %rbx,%rbx
 1050971:	je     10509cb <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x21fb>
 1050973:	test   %r13,-0x10(%rbx)
 1050977:	mov    0x20(%rsp),%rdx
 105097c:	je     1050990 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x21c0>
 105097e:	test   %r13,-0x10(%rbx)
 1050982:	jne    10509d0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2200>
 1050984:	jmp    10509b3 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x21e3>
 1050986:	cs nopw 0x0(%rax,%rax,1)
 1050990:	mov    -0x18(%rbx),%rax
 1050994:	dec    %rax
 1050997:	jne    10509a4 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x21d4>
 1050999:	cmpq   $0x0,-0x20(%rbx)
 105099e:	je     1050b00 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2330>
 10509a4:	mov    %rax,-0x18(%rbx)
 10509a8:	mov    0x20(%rsp),%rdx
 10509ad:	test   %r13,-0x10(%rbx)
 10509b1:	jne    10509d0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2200>
 10509b3:	mov    -0x20(%rbx),%rax
 10509b7:	dec    %rax
 10509ba:	jne    10509c7 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x21f7>
 10509bc:	cmpq   $0x0,-0x18(%rbx)
 10509c1:	je     1050b48 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2378>
 10509c7:	mov    %rax,-0x20(%rbx)
 10509cb:	mov    0x20(%rsp),%rdx
 10509d0:	mov    0x1a0(%rsp),%rsi
 10509d8:	test   %rsi,%rsi
 10509db:	je     1050a00 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2230>
 10509dd:	test   %r13,-0x10(%rsi)
 10509e1:	jne    1050a00 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2230>
 10509e3:	mov    -0x20(%rsi),%rax
 10509e7:	dec    %rax
 10509ea:	jne    10509f7 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2227>
 10509ec:	cmpq   $0x0,-0x18(%rsi)
 10509f1:	je     1050ad4 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2304>
 10509f7:	mov    %rax,-0x20(%rsi)
 10509fb:	mov    0x20(%rsp),%rdx
 1050a00:	mov    %rdx,%rcx
 1050a03:	add    %r14,%rcx
 1050a06:	jo     1052337 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3b67>
 1050a0c:	mov    %rcx,%rax
 1050a0f:	movabs $0x89705f3112a28fe5,%rdx
 1050a19:	imul   %rdx
 1050a1c:	add    %rcx,%rdx
 1050a1f:	mov    %rdx,%rax
 1050a22:	shr    $0x3f,%rax
 1050a26:	sar    $0x1d,%rdx
 1050a2a:	add    %rax,%rdx
 1050a2d:	imul   $0x3b9aca07,%rdx,%rax
 1050a34:	sub    %rax,%rcx
 1050a37:	mov    %rcx,%rax
 1050a3a:	sar    $0x3f,%rax
 1050a3e:	and    $0x3b9aca07,%eax
 1050a43:	add    %rcx,%rax
 1050a46:	mov    0x1a8(%rsp),%r12
 1050a4e:	inc    %r12
 1050a51:	cmp    0x28(%rsp),%r12
 1050a56:	jne    104fbb0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x13e0>
 1050a5c:	jmp    104f1ad <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x9dd>
 1050a61:	mov    0x8(%rsp),%rax
 1050a66:	mov    0x1860(%rax),%rax
 1050a6d:	test   %rax,%rax
 1050a70:	vmovdqa 0x50(%rsp),%xmm9
 1050a76:	vmovdqu 0x110(%rsp),%ymm10
 1050a7f:	je     105220d <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3a3d>
 1050a85:	mov    0x124(%rax),%r14d
 1050a8c:	movl   $0x0,0x124(%rax)
 1050a96:	test   %r14,%r14
 1050a99:	mov    0x20(%rsp),%rdx
 1050a9e:	movabs $0x101010101010101,%r15
 1050aa8:	je     10509d0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2200>
 1050aae:	cmp    $0x1,%r14d
 1050ab2:	jne    1050be9 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2419>
 1050ab8:	mov    $0x1007df2,%esi
 1050abd:	mov    0x8(%rsp),%rax
 1050ac2:	cmpl   $0x0,0x2c4(%rax)
 1050ac9:	je     1050bf3 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2423>
 1050acf:	jmp    1050bfb <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x242b>
 1050ad4:	mov    0x18(%rsp),%rbx
 1050ad9:	mov    %rbx,%rdi
 1050adc:	vzeroupper
 1050adf:	call   109cb60 <myl_rc_edge_release>
 1050ae4:	mov    %rbx,%rdi
 1050ae7:	call   109fce0 <myl_rc_drain>
 1050aec:	vmovdqu 0x110(%rsp),%ymm10
 1050af5:	vmovdqa 0x50(%rsp),%xmm9
 1050afb:	jmp    10509fb <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x222b>
 1050b00:	mov    0x18(%rsp),%r15
 1050b05:	mov    %r15,%rdi
 1050b08:	mov    %rbx,%rsi
 1050b0b:	vzeroupper
 1050b0e:	call   109ccc0 <myl_rc_hold_edge_release>
 1050b13:	mov    %r15,%rdi
 1050b16:	movabs $0x101010101010101,%r15
 1050b20:	call   109fce0 <myl_rc_drain>
 1050b25:	vmovdqu 0x110(%rsp),%ymm10
 1050b2e:	vmovdqa 0x50(%rsp),%xmm9
 1050b34:	mov    0x20(%rsp),%rdx
 1050b39:	test   %r13,-0x10(%rbx)
 1050b3d:	jne    10509d0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2200>
 1050b43:	jmp    10509b3 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x21e3>
 1050b48:	mov    0x18(%rsp),%r15
 1050b4d:	mov    %r15,%rdi
 1050b50:	mov    %rbx,%rsi
 1050b53:	vzeroupper
 1050b56:	call   109cb60 <myl_rc_edge_release>
 1050b5b:	mov    %r15,%rdi
 1050b5e:	movabs $0x101010101010101,%r15
 1050b68:	call   109fce0 <myl_rc_drain>
 1050b6d:	vmovdqu 0x110(%rsp),%ymm10
 1050b76:	vmovdqa 0x50(%rsp),%xmm9
 1050b7c:	jmp    10509cb <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x21fb>
 1050b81:	mov    $0x1007dbf,%esi
 1050b86:	mov    0x8(%rsp),%rdi
 1050b8b:	vzeroupper
 1050b8e:	call   108cd9e <fail>
 1050b93:	vmovdqu 0x110(%rsp),%ymm10
 1050b9c:	vmovdqa 0x50(%rsp),%xmm9
 1050ba2:	xor    %r14d,%r14d
 1050ba5:	jmp    1050bd5 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2405>
 1050ba7:	mov    $0x1007dbf,%esi
 1050bac:	mov    0x8(%rsp),%rdi
 1050bb1:	vzeroupper
 1050bb4:	call   108cd9e <fail>
 1050bb9:	vmovdqu 0x110(%rsp),%ymm10
 1050bc2:	vmovdqa 0x50(%rsp),%xmm9
 1050bc8:	xor    %r14d,%r14d
 1050bcb:	movabs $0x4000000000000002,%r13
 1050bd5:	mov    0x20(%rsp),%rdx
 1050bda:	movabs $0x101010101010101,%r15
 1050be4:	jmp    10509d0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2200>
 1050be9:	cmp    $0x4,%r14d
 1050bed:	jae    1052205 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3a35>
 1050bf3:	mov    0x10315e0(,%r14,8),%rsi
 1050bfb:	mov    0x8(%rsp),%rdi
 1050c00:	vzeroupper
 1050c03:	call   108cd9e <fail>
 1050c08:	xor    %r14d,%r14d
 1050c0b:	mov    0x20(%rsp),%rdx
 1050c10:	vmovdqa 0x50(%rsp),%xmm9
 1050c16:	vmovdqu 0x110(%rsp),%ymm10
 1050c1f:	jmp    10509d0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2200>
 1050c24:	mov    $0x1,%bl
 1050c26:	test   %rsi,%rsi
 1050c29:	je     1050e3d <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x266d>
 1050c2f:	mov    0x8(%rsi),%rdx
 1050c33:	cmp    0x6af2e(%rip),%rdx        # 10bbb68 <myl_lit_4a11bea7b5a6ce8d077c05a11569e05d5d64f10b6601437976e3917dc8273132_instance+0x18>
 1050c3a:	jne    1050e3d <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x266d>
 1050c40:	test   %rdx,%rdx
 1050c43:	je     104fae8 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1318>
 1050c49:	testb  $0x4,0x10(%rsi)
 1050c4d:	jne    1050d00 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2530>
 1050c53:	lea    0x18(%rsi),%rdi
 1050c57:	jmp    1050d0f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x253f>
 1050c5c:	mov    0x8(%rsp),%rax
 1050c61:	mov    0x1860(%rax),%rax
 1050c68:	test   %rax,%rax
 1050c6b:	je     105220d <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3a3d>
 1050c71:	mov    0x124(%rax),%esi
 1050c77:	movl   $0x0,0x124(%rax)
 1050c81:	mov    0x8(%rsp),%rdi
 1050c86:	vzeroupper
 1050c89:	call   108c540 <myl_qbe_rc_status>
 1050c8e:	xor    %eax,%eax
 1050c90:	jmp    104f1ad <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x9dd>
 1050c95:	mov    0x8(%rsp),%rax
 1050c9a:	mov    0x1860(%rax),%rax
 1050ca1:	test   %rax,%rax
 1050ca4:	je     105220d <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3a3d>
 1050caa:	mov    0x124(%rax),%esi
 1050cb0:	movl   $0x0,0x124(%rax)
 1050cba:	mov    0x8(%rsp),%rdi
 1050cbf:	vzeroupper
 1050cc2:	call   108c540 <myl_qbe_rc_status>
 1050cc7:	xor    %eax,%eax
 1050cc9:	jmp    104f1ad <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x9dd>
 1050cce:	lea    0xd0(%rsp),%rax
 1050cd6:	mov    0x8(%rsp),%rcx
 1050cdb:	lea    0x258(%rcx),%rdi
 1050ce2:	mov    %rsi,%r14
 1050ce5:	mov    %rax,%rsi
 1050ce8:	vzeroupper
 1050ceb:	call   1088850 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop>
 1050cf0:	mov    %r14,%rsi
 1050cf3:	test   %bl,%bl
 1050cf5:	jne    104fac6 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x12f6>
 1050cfb:	jmp    104fb14 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1344>
 1050d00:	mov    0x18(%rsi),%rax
 1050d04:	mov    0x14(%rsi),%ecx
 1050d07:	lea    (%rax,%rcx,1),%rdi
 1050d0b:	add    $0x18,%rdi
 1050d0f:	testb  $0x4,0x6ae5a(%rip)        # 10bbb70 <myl_lit_4a11bea7b5a6ce8d077c05a11569e05d5d64f10b6601437976e3917dc8273132_instance+0x20>
 1050d16:	mov    0x6ae5b(%rip),%rax        # 10bbb78 <myl_lit_4a11bea7b5a6ce8d077c05a11569e05d5d64f10b6601437976e3917dc8273132_instance+0x28>
 1050d1d:	mov    0x6ae51(%rip),%ecx        # 10bbb74 <myl_lit_4a11bea7b5a6ce8d077c05a11569e05d5d64f10b6601437976e3917dc8273132_instance+0x24>
 1050d23:	lea    0x18(%rax,%rcx,1),%rcx
 1050d28:	mov    $0x10bbb78,%eax
 1050d2d:	cmovne %rcx,%rax
 1050d31:	cmp    $0x10,%rdx
 1050d35:	ja     1050d55 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2585>
 1050d37:	cmp    $0x8,%rdx
 1050d3b:	jb     1050d86 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x25b6>
 1050d3d:	mov    (%rdi),%rcx
 1050d40:	mov    -0x8(%rdi,%rdx,1),%rdi
 1050d45:	xor    (%rax),%rcx
 1050d48:	xor    -0x8(%rax,%rdx,1),%rdi
 1050d4d:	or     %rcx,%rdi
 1050d50:	jmp    1050e14 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2644>
 1050d55:	cmp    $0x40,%rdx
 1050d59:	ja     1050da0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x25d0>
 1050d5b:	vmovdqu (%rdi),%xmm0
 1050d5f:	cmp    $0x20,%rdx
 1050d63:	ja     1050df4 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2624>
 1050d69:	vinserti128 $0x1,-0x10(%rdi,%rdx,1),%ymm0,%ymm0
 1050d71:	vmovdqu (%rax),%xmm1
 1050d75:	vinserti128 $0x1,-0x10(%rax,%rdx,1),%ymm1,%ymm1
 1050d7d:	vpxor  %ymm1,%ymm0,%ymm0
 1050d81:	jmp    1050e0f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x263f>
 1050d86:	cmp    $0x4,%rdx
 1050d8a:	jb     1050e1c <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x264c>
 1050d90:	mov    (%rdi),%ecx
 1050d92:	mov    -0x4(%rdi,%rdx,1),%edi
 1050d96:	xor    (%rax),%ecx
 1050d98:	xor    -0x4(%rax,%rdx,1),%edi
 1050d9c:	or     %ecx,%edi
 1050d9e:	jmp    1050e14 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2644>
 1050da0:	mov    %rsi,%r14
 1050da3:	mov    %rax,%rsi
 1050da6:	cmp    $0x100,%rdx
 1050dad:	ja     1050e2d <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x265d>
 1050daf:	vzeroupper
 1050db2:	call   10ae350 <bcmp@plt>
 1050db7:	test   %eax,%eax
 1050db9:	setne  %bl
 1050dbc:	jmp    1050e3a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x266a>
 1050dbe:	movzwl (%rdi),%eax
 1050dc1:	movzwl -0x2(%rdi,%rdx,1),%ecx
 1050dc6:	xor    (%rsi),%ax
 1050dc9:	xor    -0x2(%rsi,%rdx,1),%cx
 1050dce:	or     %ax,%cx
 1050dd1:	sete   %al
 1050dd4:	movzbl %al,%eax
 1050dd7:	jmp    104f19f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x9cf>
 1050ddc:	movzwl (%rdi),%ecx
 1050ddf:	movzwl -0x2(%rdi,%rdx,1),%edi
 1050de4:	xor    (%rax),%cx
 1050de7:	xor    -0x2(%rax,%rdx,1),%di
 1050dec:	or     %cx,%di
 1050def:	jmp    104fa90 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x12c0>
 1050df4:	vmovdqu -0x20(%rdi,%rdx,1),%ymm1
 1050dfa:	vinserti128 $0x1,0x10(%rdi),%ymm0,%ymm0
 1050e01:	vpxor  -0x20(%rax,%rdx,1),%ymm1,%ymm1
 1050e07:	vpxor  (%rax),%ymm0,%ymm0
 1050e0b:	vpor   %ymm1,%ymm0,%ymm0
 1050e0f:	vptest %ymm0,%ymm0
 1050e14:	sete   %bl
 1050e17:	xor    $0x1,%bl
 1050e1a:	jmp    1050e3d <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x266d>
 1050e1c:	cmp    $0x1,%rdx
 1050e20:	jne    1051435 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2c65>
 1050e26:	movzbl (%rdi),%ecx
 1050e29:	cmp    (%rax),%cl
 1050e2b:	jmp    1050e14 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2644>
 1050e2d:	vzeroupper
 1050e30:	call   10943e0 <equal_large_octets>
 1050e35:	test   %eax,%eax
 1050e37:	sete   %bl
 1050e3a:	mov    %r14,%rsi
 1050e3d:	test   %r13,0x6ad0c(%rip)        # 10bbb50 <myl_lit_4a11bea7b5a6ce8d077c05a11569e05d5d64f10b6601437976e3917dc8273132_instance>
 1050e44:	jne    1050e63 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2693>
 1050e46:	mov    0x6acf3(%rip),%rax        # 10bbb40 <myl_lit_49ddcee716aac9f3632795416226e674fb40f0332dabf1de33fc7f8b34af0696_instance+0x38>
 1050e4d:	dec    %rax
 1050e50:	jne    1050e5c <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x268c>
 1050e52:	cmpq   $0x0,0x6acee(%rip)        # 10bbb48 <myl_lit_49ddcee716aac9f3632795416226e674fb40f0332dabf1de33fc7f8b34af0696_instance+0x40>
 1050e5a:	je     1050ecd <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x26fd>
 1050e5c:	mov    %rax,0x6acdd(%rip)        # 10bbb40 <myl_lit_49ddcee716aac9f3632795416226e674fb40f0332dabf1de33fc7f8b34af0696_instance+0x38>
 1050e63:	test   %bl,%bl
 1050e65:	je     1050efa <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x272a>
 1050e6b:	movq   $0x10bba00,0x38(%rsp)
 1050e74:	movq   $0x10bba00,0x78(%rsp)
 1050e7d:	movq   $0x10bba00,0xd0(%rsp)
 1050e89:	cmp    $0x10bba00,%rsi
 1050e90:	jne    1050e99 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x26c9>
 1050e92:	xor    %ebx,%ebx
 1050e94:	jmp    1051496 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2cc6>
 1050e99:	mov    $0x1,%bl
 1050e9b:	test   %rsi,%rsi
 1050e9e:	je     1051496 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2cc6>
 1050ea4:	mov    0x8(%rsi),%rdx
 1050ea8:	cmp    0x6ab59(%rip),%rdx        # 10bba08 <myl_lit_3b82d7fd89ea641dc3c74175c3081dd70840c2be20de843e08a42204e3d9c4cc_instance+0x18>
 1050eaf:	jne    1051496 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2cc6>
 1050eb5:	test   %rdx,%rdx
 1050eb8:	je     1050e92 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x26c2>
 1050eba:	testb  $0x4,0x10(%rsi)
 1050ebe:	jne    1051382 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2bb2>
 1050ec4:	lea    0x18(%rsi),%rdi
 1050ec8:	jmp    1051391 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2bc1>
 1050ecd:	lea    0xd0(%rsp),%rax
 1050ed5:	mov    0x8(%rsp),%rcx
 1050eda:	lea    0x258(%rcx),%rdi
 1050ee1:	mov    %rsi,%r14
 1050ee4:	mov    %rax,%rsi
 1050ee7:	vzeroupper
 1050eea:	call   1088850 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop>
 1050eef:	mov    %r14,%rsi
 1050ef2:	test   %bl,%bl
 1050ef4:	jne    1050e6b <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x269b>
 1050efa:	lea    0x48(%rsp),%rbp
 1050eff:	lea    0x78(%rsp),%rcx
 1050f04:	mov    %rcx,%rax
 1050f07:	sub    %rbp,%rax
 1050f0a:	sub    %rcx,%rbp
 1050f0d:	cmovb  %rax,%rbp
 1050f11:	movabs $0x5000000000000000,%rax
 1050f1b:	xor    %r15d,%r15d
 1050f1e:	inc    %rax
 1050f21:	mov    %rax,0x50(%rsp)
 1050f26:	xor    %eax,%eax
 1050f28:	nopl   0x0(%rax,%rax,1)
 1050f30:	mov    %rax,%r14
 1050f33:	mov    0x10(%rsp),%rax
 1050f38:	add    %r15,%rax
 1050f3b:	jo     1052399 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3bc9>
 1050f41:	test   $0x1,%al
 1050f43:	jne    1050fe0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2810>
 1050f49:	movq   $0x10bc9b0,0x78(%rsp)
 1050f52:	movq   $0x10bc9b0,0x1d8(%rsp)
 1050f5e:	movq   $0x10bc9b0,0x48(%rsp)
 1050f67:	mov    0x6ba32(%rip),%rax        # 10bc9a0 <myl_lit_f3eaad558815542caf7da2bdfda9d4cabeaf9c2200b79ab8ff85b21b8470fac6_instance>
 1050f6e:	test   %rax,0x50(%rsp)
 1050f73:	movabs $0x4000000000000002,%rbx
 1050f7d:	je     105109c <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x28cc>
 1050f83:	test   %rbp,%rbp
 1050f86:	sete   %cl
 1050f89:	movabs $0x5000000000000000,%rdx
 1050f93:	test   %rdx,%rax
 1050f96:	setne  %al
 1050f99:	or     %cl,%al
 1050f9b:	je     10510b8 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x28e8>
 1050fa1:	mov    $0x1030c78,%esi
 1050fa6:	mov    0x8(%rsp),%rax
 1050fab:	lea    0x258(%rax),%rdi
 1050fb2:	lea    0x78(%rsp),%rdx
 1050fb7:	lea    0x48(%rsp),%rcx
 1050fbc:	mov    0x44(%rsp),%r8d
 1050fc1:	vzeroupper
 1050fc4:	call   10a9100 <myl_rc_native_take>
 1050fc9:	test   %eax,%eax
 1050fcb:	jne    1051068 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2898>
 1050fd1:	jmp    10512fd <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2b2d>
 1050fd6:	cs nopw 0x0(%rax,%rax,1)
 1050fe0:	movq   $0x10bbd20,0x78(%rsp)
 1050fe9:	movq   $0x10bbd20,0x1d8(%rsp)
 1050ff5:	movq   $0x10bbd20,0x48(%rsp)
 1050ffe:	mov    0x6ad0b(%rip),%rax        # 10bbd10 <myl_lit_54807ae7ae90f7f8ab8705f04b17dcd2d77e7355f27b7f7252156b0c234f7d3f_instance>
 1051005:	test   %rax,0x50(%rsp)
 105100a:	movabs $0x4000000000000002,%rbx
 1051014:	je     10510e6 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2916>
 105101a:	test   %rbp,%rbp
 105101d:	sete   %cl
 1051020:	movabs $0x5000000000000000,%rdx
 105102a:	test   %rdx,%rax
 105102d:	setne  %al
 1051030:	or     %cl,%al
 1051032:	je     10510dd <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x290d>
 1051038:	mov    $0x1030c78,%esi
 105103d:	mov    0x8(%rsp),%rax
 1051042:	lea    0x258(%rax),%rdi
 1051049:	lea    0x78(%rsp),%rdx
 105104e:	lea    0x48(%rsp),%rcx
 1051053:	mov    0x44(%rsp),%r8d
 1051058:	vzeroupper
 105105b:	call   10a9100 <myl_rc_native_take>
 1051060:	test   %eax,%eax
 1051062:	je     1051333 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2b63>
 1051068:	mov    0x78(%rsp),%r12
 105106d:	mov    %r12,0xb0(%rsp)
 1051075:	mov    %r12,0x48(%rsp)
 105107a:	test   %r12,%r12
 105107d:	je     105127a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2aaa>
 1051083:	test   %rbx,-0x10(%r12)
 1051088:	je     1051100 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2930>
 105108a:	mov    %r12,0x78(%rsp)
 105108f:	mov    %r12,0xa8(%rsp)
 1051097:	jmp    105113b <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x296b>
 105109c:	mov    $0x10bc9b0,%r12d
 10510a2:	mov    %r12,0xb0(%rsp)
 10510aa:	mov    %r12,0x48(%rsp)
 10510af:	test   %rbx,-0x10(%r12)
 10510b4:	jne    105108a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x28ba>
 10510b6:	jmp    1051100 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2930>
 10510b8:	movq   $0x10bc9b0,0x78(%rsp)
 10510c1:	mov    $0x10bc9b0,%r12d
 10510c7:	mov    %r12,0xb0(%rsp)
 10510cf:	mov    %r12,0x48(%rsp)
 10510d4:	test   %rbx,-0x10(%r12)
 10510d9:	jne    105108a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x28ba>
 10510db:	jmp    1051100 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2930>
 10510dd:	movq   $0x10bbd20,0x78(%rsp)
 10510e6:	mov    $0x10bbd20,%r12d
 10510ec:	mov    %r12,0xb0(%rsp)
 10510f4:	mov    %r12,0x48(%rsp)
 10510f9:	test   %rbx,-0x10(%r12)
 10510fe:	jne    105108a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x28ba>
 1051100:	mov    -0x18(%r12),%rax
 1051105:	inc    %rax
 1051108:	je     1051369 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2b99>
 105110e:	mov    %rax,-0x18(%r12)
 1051113:	mov    %r12,0x78(%rsp)
 1051118:	mov    %r12,0xa8(%rsp)
 1051120:	mov    -0x20(%r12),%rax
 1051125:	dec    %rax
 1051128:	jne    1051136 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2966>
 105112a:	cmpq   $0x0,-0x18(%r12)
 1051130:	je     10512be <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2aee>
 1051136:	mov    %rax,-0x20(%r12)
 105113b:	movq   $0x0,0xb0(%rsp)
 1051147:	mov    0x30(%rsp),%rax
 105114c:	mov    0x20(%rax),%rdx
 1051150:	mov    0x8(%rsp),%rax
 1051155:	lea    0x258(%rax),%rdi
 105115c:	mov    %r12,%rsi
 105115f:	vzeroupper
 1051162:	call   1094750 <myl_native_text_join>
 1051167:	test   %rax,%rax
 105116a:	je     105237d <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3bad>
 1051170:	mov    %rax,%rbx
 1051173:	mov    %rax,0x48(%rsp)
 1051178:	mov    %rax,0x78(%rsp)
 105117d:	mov    %rax,0x1d8(%rsp)
 1051185:	mov    0x8(%rsp),%rdi
 105118a:	mov    %rax,%rsi
 105118d:	call   10758b0 <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85>
 1051192:	mov    %rax,%r13
 1051195:	movabs $0x4000000000000002,%rax
 105119f:	test   %rax,-0x10(%rbx)
 10511a3:	je     10511c0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x29f0>
 10511a5:	movq   $0x0,0x1d8(%rsp)
 10511b1:	test   %r12,%r12
 10511b4:	jne    10511e9 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2a19>
 10511b6:	jmp    1051221 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2a51>
 10511b8:	nopl   0x0(%rax,%rax,1)
 10511c0:	mov    -0x20(%rbx),%rax
 10511c4:	dec    %rax
 10511c7:	jne    10511d4 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2a04>
 10511c9:	cmpq   $0x0,-0x18(%rbx)
 10511ce:	je     1051297 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2ac7>
 10511d4:	mov    %rax,-0x20(%rbx)
 10511d8:	movq   $0x0,0x1d8(%rsp)
 10511e4:	test   %r12,%r12
 10511e7:	je     1051221 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2a51>
 10511e9:	movabs $0x4000000000000002,%rax
 10511f3:	test   %rax,-0x10(%r12)
 10511f8:	jne    1051215 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2a45>
 10511fa:	mov    -0x18(%r12),%rax
 10511ff:	dec    %rax
 1051202:	jne    1051210 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2a40>
 1051204:	cmpq   $0x0,-0x20(%r12)
 105120a:	je     10512df <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2b0f>
 1051210:	mov    %rax,-0x18(%r12)
 1051215:	movq   $0x0,0xa8(%rsp)
 1051221:	mov    %r14,%rcx
 1051224:	add    %r13,%rcx
 1051227:	jo     1052387 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3bb7>
 105122d:	mov    %rcx,%rax
 1051230:	movabs $0x89705f3112a28fe5,%rdx
 105123a:	imul   %rdx
 105123d:	add    %rcx,%rdx
 1051240:	mov    %rdx,%rax
 1051243:	shr    $0x3f,%rax
 1051247:	sar    $0x1d,%rdx
 105124b:	add    %rax,%rdx
 105124e:	imul   $0x3b9aca07,%rdx,%rax
 1051255:	sub    %rax,%rcx
 1051258:	mov    %rcx,%rax
 105125b:	sar    $0x3f,%rax
 105125f:	and    $0x3b9aca07,%eax
 1051264:	add    %rcx,%rax
 1051267:	inc    %r15
 105126a:	cmp    %r15,0x28(%rsp)
 105126f:	jne    1050f30 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2760>
 1051275:	jmp    104f1ad <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x9dd>
 105127a:	movq   $0x0,0x78(%rsp)
 1051283:	movq   $0x0,0xa8(%rsp)
 105128f:	xor    %r12d,%r12d
 1051292:	jmp    1051147 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2977>
 1051297:	mov    0x8(%rsp),%rax
 105129c:	lea    0x258(%rax),%rdi
 10512a3:	lea    0x1d8(%rsp),%rsi
 10512ab:	call   1088850 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop>
 10512b0:	test   %r12,%r12
 10512b3:	jne    10511e9 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2a19>
 10512b9:	jmp    1051221 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2a51>
 10512be:	mov    0x8(%rsp),%rax
 10512c3:	lea    0x258(%rax),%rdi
 10512ca:	lea    0xb0(%rsp),%rsi
 10512d2:	vzeroupper
 10512d5:	call   1088850 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop>
 10512da:	jmp    1051147 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2977>
 10512df:	mov    0x8(%rsp),%rax
 10512e4:	lea    0x258(%rax),%rdi
 10512eb:	lea    0xa8(%rsp),%rsi
 10512f3:	call   10887e0 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan>
 10512f8:	jmp    1051221 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2a51>
 10512fd:	mov    0x8(%rsp),%rax
 1051302:	mov    0x1860(%rax),%rax
 1051309:	test   %rax,%rax
 105130c:	je     105220d <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3a3d>
 1051312:	mov    0x124(%rax),%esi
 1051318:	movl   $0x0,0x124(%rax)
 1051322:	mov    0x8(%rsp),%rdi
 1051327:	call   108c540 <myl_qbe_rc_status>
 105132c:	xor    %eax,%eax
 105132e:	jmp    104f1ad <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x9dd>
 1051333:	mov    0x8(%rsp),%rax
 1051338:	mov    0x1860(%rax),%rax
 105133f:	test   %rax,%rax
 1051342:	je     105220d <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3a3d>
 1051348:	mov    0x124(%rax),%esi
 105134e:	movl   $0x0,0x124(%rax)
 1051358:	mov    0x8(%rsp),%rdi
 105135d:	call   108c540 <myl_qbe_rc_status>
 1051362:	xor    %eax,%eax
 1051364:	jmp    104f1ad <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x9dd>
 1051369:	mov    $0x1007dbf,%esi
 105136e:	mov    0x8(%rsp),%rdi
 1051373:	vzeroupper
 1051376:	call   108cd9e <fail>
 105137b:	xor    %eax,%eax
 105137d:	jmp    104f1ad <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x9dd>
 1051382:	mov    0x18(%rsi),%rax
 1051386:	mov    0x14(%rsi),%ecx
 1051389:	lea    (%rax,%rcx,1),%rdi
 105138d:	add    $0x18,%rdi
 1051391:	testb  $0x4,0x6a678(%rip)        # 10bba10 <myl_lit_3b82d7fd89ea641dc3c74175c3081dd70840c2be20de843e08a42204e3d9c4cc_instance+0x20>
 1051398:	mov    0x6a679(%rip),%rax        # 10bba18 <myl_lit_3b82d7fd89ea641dc3c74175c3081dd70840c2be20de843e08a42204e3d9c4cc_instance+0x28>
 105139f:	mov    0x6a66f(%rip),%ecx        # 10bba14 <myl_lit_3b82d7fd89ea641dc3c74175c3081dd70840c2be20de843e08a42204e3d9c4cc_instance+0x24>
 10513a5:	lea    0x18(%rax,%rcx,1),%rcx
 10513aa:	mov    $0x10bba18,%eax
 10513af:	cmovne %rcx,%rax
 10513b3:	cmp    $0x10,%rdx
 10513b7:	ja     10513d7 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2c07>
 10513b9:	cmp    $0x8,%rdx
 10513bd:	jb     1051401 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2c31>
 10513bf:	mov    (%rdi),%rcx
 10513c2:	mov    -0x8(%rdi,%rdx,1),%rdi
 10513c7:	xor    (%rax),%rcx
 10513ca:	xor    -0x8(%rax,%rdx,1),%rdi
 10513cf:	or     %rcx,%rdi
 10513d2:	jmp    105146d <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2c9d>
 10513d7:	cmp    $0x40,%rdx
 10513db:	ja     1051417 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2c47>
 10513dd:	vmovdqu (%rdi),%xmm0
 10513e1:	cmp    $0x20,%rdx
 10513e5:	ja     105144d <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2c7d>
 10513e7:	vinserti128 $0x1,-0x10(%rdi,%rdx,1),%ymm0,%ymm0
 10513ef:	vmovdqu (%rax),%xmm1
 10513f3:	vinserti128 $0x1,-0x10(%rax,%rdx,1),%ymm1,%ymm1
 10513fb:	vpxor  %ymm1,%ymm0,%ymm0
 10513ff:	jmp    1051468 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2c98>
 1051401:	cmp    $0x4,%rdx
 1051405:	jb     1051475 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2ca5>
 1051407:	mov    (%rdi),%ecx
 1051409:	mov    -0x4(%rdi,%rdx,1),%edi
 105140d:	xor    (%rax),%ecx
 105140f:	xor    -0x4(%rax,%rdx,1),%edi
 1051413:	or     %ecx,%edi
 1051415:	jmp    105146d <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2c9d>
 1051417:	mov    %rsi,%r14
 105141a:	mov    %rax,%rsi
 105141d:	cmp    $0x100,%rdx
 1051424:	ja     1051486 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2cb6>
 1051426:	vzeroupper
 1051429:	call   10ae350 <bcmp@plt>
 105142e:	test   %eax,%eax
 1051430:	setne  %bl
 1051433:	jmp    1051493 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2cc3>
 1051435:	movzwl (%rdi),%ecx
 1051438:	movzwl -0x2(%rdi,%rdx,1),%edi
 105143d:	xor    (%rax),%cx
 1051440:	xor    -0x2(%rax,%rdx,1),%di
 1051445:	or     %cx,%di
 1051448:	jmp    1050e14 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2644>
 105144d:	vmovdqu -0x20(%rdi,%rdx,1),%ymm1
 1051453:	vinserti128 $0x1,0x10(%rdi),%ymm0,%ymm0
 105145a:	vpxor  -0x20(%rax,%rdx,1),%ymm1,%ymm1
 1051460:	vpxor  (%rax),%ymm0,%ymm0
 1051464:	vpor   %ymm1,%ymm0,%ymm0
 1051468:	vptest %ymm0,%ymm0
 105146d:	sete   %bl
 1051470:	xor    $0x1,%bl
 1051473:	jmp    1051496 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2cc6>
 1051475:	cmp    $0x1,%rdx
 1051479:	jne    105185c <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x308c>
 105147f:	movzbl (%rdi),%ecx
 1051482:	cmp    (%rax),%cl
 1051484:	jmp    105146d <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2c9d>
 1051486:	vzeroupper
 1051489:	call   10943e0 <equal_large_octets>
 105148e:	test   %eax,%eax
 1051490:	sete   %bl
 1051493:	mov    %r14,%rsi
 1051496:	test   %r13,0x6a553(%rip)        # 10bb9f0 <myl_lit_3b82d7fd89ea641dc3c74175c3081dd70840c2be20de843e08a42204e3d9c4cc_instance>
 105149d:	jne    10514bc <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2cec>
 105149f:	mov    0x6a53a(%rip),%rax        # 10bb9e0 <myl_lit_3b2e9d8953e261b03d089bbc831cd3b7c9a128df1fa9770dfd3ff0548594ae5c_instance+0x20>
 10514a6:	dec    %rax
 10514a9:	jne    10514b5 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2ce5>
 10514ab:	cmpq   $0x0,0x6a535(%rip)        # 10bb9e8 <myl_lit_3b2e9d8953e261b03d089bbc831cd3b7c9a128df1fa9770dfd3ff0548594ae5c_instance+0x28>
 10514b3:	je     1051529 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2d59>
 10514b5:	mov    %rax,0x6a524(%rip)        # 10bb9e0 <myl_lit_3b2e9d8953e261b03d089bbc831cd3b7c9a128df1fa9770dfd3ff0548594ae5c_instance+0x20>
 10514bc:	movq   $0x0,0xd0(%rsp)
 10514c8:	test   %bl,%bl
 10514ca:	je     1051556 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2d86>
 10514d0:	movq   $0x10bbf08,0x78(%rsp)
 10514d9:	movq   $0x10bbf08,0xd0(%rsp)
 10514e5:	cmp    $0x10bbf08,%rsi
 10514ec:	jne    10514f5 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2d25>
 10514ee:	xor    %ebx,%ebx
 10514f0:	jmp    10518bd <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x30ed>
 10514f5:	mov    $0x1,%bl
 10514f7:	test   %rsi,%rsi
 10514fa:	je     10518bd <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x30ed>
 1051500:	mov    0x8(%rsi),%rdx
 1051504:	cmp    0x6aa05(%rip),%rdx        # 10bbf10 <myl_lit_626da83bb2caf4205ae415768034d7bb2b32d76c3b0b29af95ab0567cf1d3ca9_instance+0x18>
 105150b:	jne    10518bd <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x30ed>
 1051511:	test   %rdx,%rdx
 1051514:	je     10514ee <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2d1e>
 1051516:	testb  $0x4,0x10(%rsi)
 105151a:	jne    10517a9 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2fd9>
 1051520:	lea    0x18(%rsi),%rdi
 1051524:	jmp    10517b8 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2fe8>
 1051529:	lea    0xd0(%rsp),%rax
 1051531:	mov    0x8(%rsp),%rcx
 1051536:	lea    0x258(%rcx),%rdi
 105153d:	mov    %rsi,%r14
 1051540:	mov    %rax,%rsi
 1051543:	vzeroupper
 1051546:	call   1088850 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop>
 105154b:	mov    %r14,%rsi
 105154e:	test   %bl,%bl
 1051550:	jne    10514d0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2d00>
 1051556:	xor    %ebx,%ebx
 1051558:	lea    0x1b8(%rsp),%r14
 1051560:	lea    0x150(%rsp),%rbp
 1051568:	movabs $0x89705f3112a28fe5,%r13
 1051572:	xor    %eax,%eax
 1051574:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 1051580:	mov    %rax,%r15
 1051583:	mov    0x10(%rsp),%rax
 1051588:	add    %rbx,%rax
 105158b:	jo     10523b0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3be0>
 1051591:	mov    0x30(%rsp),%rcx
 1051596:	mov    0x8(%rcx),%rdi
 105159a:	mov    (%rdi),%rcx
 105159d:	test   %rcx,%rcx
 10515a0:	js     10523c7 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3bf7>
 10515a6:	je     10523d7 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3c07>
 10515ac:	mov    %rax,%rdx
 10515af:	or     %rcx,%rdx
 10515b2:	shr    $0x20,%rdx
 10515b6:	je     10515bf <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2def>
 10515b8:	cqto
 10515ba:	idiv   %rcx
 10515bd:	jmp    10515c3 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2df3>
 10515bf:	xor    %edx,%edx
 10515c1:	div    %ecx
 10515c3:	mov    %rdx,%rax
 10515c6:	sar    $0x3f,%rax
 10515ca:	and    %rcx,%rax
 10515cd:	add    %rdx,%rax
 10515d0:	mov    %rax,%rsi
 10515d3:	sar    $0x3f,%rsi
 10515d7:	and    %rcx,%rsi
 10515da:	add    %rax,%rsi
 10515dd:	cmp    %rcx,%rsi
 10515e0:	jae    10523e7 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3c17>
 10515e6:	mov    0x20(%rdi),%rax
 10515ea:	mov    (%rax,%rsi,8),%rax
 10515ee:	test   %rax,%rax
 10515f1:	je     105161e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2e4e>
 10515f3:	mov    %rax,%rdi
 10515f6:	movabs $0x4000000000000002,%rcx
 1051600:	test   %rcx,-0x10(%rax)
 1051604:	je     105174f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2f7f>
 105160a:	mov    %rax,0x150(%rsp)
 1051612:	testb  $0x4,0x10(%rdi)
 1051616:	jne    105162e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2e5e>
 1051618:	add    $0x18,%rdi
 105161c:	jmp    105163d <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2e6d>
 105161e:	xor    %edi,%edi
 1051620:	mov    %rax,0x150(%rsp)
 1051628:	testb  $0x4,0x10(%rdi)
 105162c:	je     1051618 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2e48>
 105162e:	mov    0x18(%rdi),%rcx
 1051632:	mov    0x14(%rdi),%edx
 1051635:	lea    (%rcx,%rdx,1),%rdi
 1051639:	add    $0x18,%rdi
 105163d:	mov    0x8(%rax),%rsi
 1051641:	xor    %edx,%edx
 1051643:	mov    %r14,%rcx
 1051646:	vzeroupper
 1051649:	call   104a290 <myl_native_bytes_number_parse>
 105164e:	test   %eax,%eax
 1051650:	je     10516b4 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2ee4>
 1051652:	mov    0x1b8(%rsp),%r12
 105165a:	movl   $0x1,0x170(%rsp)
 1051665:	mov    %r12,0x178(%rsp)
 105166d:	mov    0x150(%rsp),%rax
 1051675:	test   %rax,%rax
 1051678:	je     1051700 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2f30>
 105167e:	movabs $0x4000000000000002,%rcx
 1051688:	test   %rcx,-0x10(%rax)
 105168c:	jne    1051700 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2f30>
 105168e:	mov    -0x18(%rax),%rcx
 1051692:	dec    %rcx
 1051695:	jne    10516f6 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2f26>
 1051697:	cmpq   $0x0,-0x20(%rax)
 105169c:	jne    10516f6 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2f26>
 105169e:	mov    0x8(%rsp),%rax
 10516a3:	lea    0x258(%rax),%rdi
 10516aa:	mov    %rbp,%rsi
 10516ad:	call   10887e0 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan>
 10516b2:	jmp    1051700 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2f30>
 10516b4:	movl   $0x0,0x170(%rsp)
 10516bf:	mov    0x150(%rsp),%rax
 10516c7:	mov    $0x61,%r12d
 10516cd:	test   %rax,%rax
 10516d0:	je     1051700 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2f30>
 10516d2:	movabs $0x4000000000000002,%rcx
 10516dc:	test   %rcx,-0x10(%rax)
 10516e0:	jne    1051700 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2f30>
 10516e2:	mov    -0x18(%rax),%rcx
 10516e6:	dec    %rcx
 10516e9:	jne    10516f6 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2f26>
 10516eb:	cmpq   $0x0,-0x20(%rax)
 10516f0:	je     1051790 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2fc0>
 10516f6:	mov    %rcx,-0x18(%rax)
 10516fa:	nopw   0x0(%rax,%rax,1)
 1051700:	mov    %r15,%rcx
 1051703:	add    %r12,%rcx
 1051706:	jo     10523f7 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3c27>
 105170c:	mov    %rcx,%rax
 105170f:	imul   %r13
 1051712:	add    %rcx,%rdx
 1051715:	mov    %rdx,%rax
 1051718:	shr    $0x3f,%rax
 105171c:	sar    $0x1d,%rdx
 1051720:	add    %rax,%rdx
 1051723:	imul   $0x3b9aca07,%rdx,%rax
 105172a:	sub    %rax,%rcx
 105172d:	mov    %rcx,%rax
 1051730:	sar    $0x3f,%rax
 1051734:	and    $0x3b9aca07,%eax
 1051739:	add    %rcx,%rax
 105173c:	inc    %rbx
 105173f:	cmp    %rbx,0x28(%rsp)
 1051744:	jne    1051580 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2db0>
 105174a:	jmp    104f1ad <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x9dd>
 105174f:	mov    -0x18(%rax),%rcx
 1051753:	inc    %rcx
 1051756:	je     1051776 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2fa6>
 1051758:	mov    %rcx,-0x18(%rax)
 105175c:	mov    %rax,%rdi
 105175f:	mov    %rax,0x150(%rsp)
 1051767:	testb  $0x4,0x10(%rdi)
 105176b:	jne    105162e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2e5e>
 1051771:	jmp    1051618 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2e48>
 1051776:	mov    $0x1007dbf,%esi
 105177b:	mov    0x8(%rsp),%rdi
 1051780:	vzeroupper
 1051783:	call   108cd9e <fail>
 1051788:	xor    %r12d,%r12d
 105178b:	jmp    1051700 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2f30>
 1051790:	mov    0x8(%rsp),%rax
 1051795:	lea    0x258(%rax),%rdi
 105179c:	mov    %rbp,%rsi
 105179f:	call   10887e0 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan>
 10517a4:	jmp    1051700 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2f30>
 10517a9:	mov    0x18(%rsi),%rax
 10517ad:	mov    0x14(%rsi),%ecx
 10517b0:	lea    (%rax,%rcx,1),%rdi
 10517b4:	add    $0x18,%rdi
 10517b8:	testb  $0x4,0x6a759(%rip)        # 10bbf18 <myl_lit_626da83bb2caf4205ae415768034d7bb2b32d76c3b0b29af95ab0567cf1d3ca9_instance+0x20>
 10517bf:	mov    0x6a75a(%rip),%rax        # 10bbf20 <myl_lit_626da83bb2caf4205ae415768034d7bb2b32d76c3b0b29af95ab0567cf1d3ca9_instance+0x28>
 10517c6:	mov    0x6a750(%rip),%ecx        # 10bbf1c <myl_lit_626da83bb2caf4205ae415768034d7bb2b32d76c3b0b29af95ab0567cf1d3ca9_instance+0x24>
 10517cc:	lea    0x18(%rax,%rcx,1),%rcx
 10517d1:	mov    $0x10bbf20,%eax
 10517d6:	cmovne %rcx,%rax
 10517da:	cmp    $0x10,%rdx
 10517de:	ja     10517fe <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x302e>
 10517e0:	cmp    $0x8,%rdx
 10517e4:	jb     1051828 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3058>
 10517e6:	mov    (%rdi),%rcx
 10517e9:	mov    -0x8(%rdi,%rdx,1),%rdi
 10517ee:	xor    (%rax),%rcx
 10517f1:	xor    -0x8(%rax,%rdx,1),%rdi
 10517f6:	or     %rcx,%rdi
 10517f9:	jmp    1051894 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x30c4>
 10517fe:	cmp    $0x40,%rdx
 1051802:	ja     105183e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x306e>
 1051804:	vmovdqu (%rdi),%xmm0
 1051808:	cmp    $0x20,%rdx
 105180c:	ja     1051874 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x30a4>
 105180e:	vinserti128 $0x1,-0x10(%rdi,%rdx,1),%ymm0,%ymm0
 1051816:	vmovdqu (%rax),%xmm1
 105181a:	vinserti128 $0x1,-0x10(%rax,%rdx,1),%ymm1,%ymm1
 1051822:	vpxor  %ymm1,%ymm0,%ymm0
 1051826:	jmp    105188f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x30bf>
 1051828:	cmp    $0x4,%rdx
 105182c:	jb     105189c <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x30cc>
 105182e:	mov    (%rdi),%ecx
 1051830:	mov    -0x4(%rdi,%rdx,1),%edi
 1051834:	xor    (%rax),%ecx
 1051836:	xor    -0x4(%rax,%rdx,1),%edi
 105183a:	or     %ecx,%edi
 105183c:	jmp    1051894 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x30c4>
 105183e:	mov    %rsi,%r14
 1051841:	mov    %rax,%rsi
 1051844:	cmp    $0x100,%rdx
 105184b:	ja     10518ad <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x30dd>
 105184d:	vzeroupper
 1051850:	call   10ae350 <bcmp@plt>
 1051855:	test   %eax,%eax
 1051857:	setne  %bl
 105185a:	jmp    10518ba <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x30ea>
 105185c:	movzwl (%rdi),%ecx
 105185f:	movzwl -0x2(%rdi,%rdx,1),%edi
 1051864:	xor    (%rax),%cx
 1051867:	xor    -0x2(%rax,%rdx,1),%di
 105186c:	or     %cx,%di
 105186f:	jmp    105146d <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2c9d>
 1051874:	vmovdqu -0x20(%rdi,%rdx,1),%ymm1
 105187a:	vinserti128 $0x1,0x10(%rdi),%ymm0,%ymm0
 1051881:	vpxor  -0x20(%rax,%rdx,1),%ymm1,%ymm1
 1051887:	vpxor  (%rax),%ymm0,%ymm0
 105188b:	vpor   %ymm1,%ymm0,%ymm0
 105188f:	vptest %ymm0,%ymm0
 1051894:	sete   %bl
 1051897:	xor    $0x1,%bl
 105189a:	jmp    10518bd <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x30ed>
 105189c:	cmp    $0x1,%rdx
 10518a0:	jne    1051ba5 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x33d5>
 10518a6:	movzbl (%rdi),%ecx
 10518a9:	cmp    (%rax),%cl
 10518ab:	jmp    1051894 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x30c4>
 10518ad:	vzeroupper
 10518b0:	call   10943e0 <equal_large_octets>
 10518b5:	test   %eax,%eax
 10518b7:	sete   %bl
 10518ba:	mov    %r14,%rsi
 10518bd:	test   %r13,0x6a634(%rip)        # 10bbef8 <myl_lit_626da83bb2caf4205ae415768034d7bb2b32d76c3b0b29af95ab0567cf1d3ca9_instance>
 10518c4:	jne    10518e3 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3113>
 10518c6:	mov    0x6a61b(%rip),%rax        # 10bbee8 <myl_lit_5ffcfeefbc77603111eb9faae2375c1bd71d00fc5610c522261905cf007d59b3_instance+0x60>
 10518cd:	dec    %rax
 10518d0:	jne    10518dc <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x310c>
 10518d2:	cmpq   $0x0,0x6a616(%rip)        # 10bbef0 <myl_lit_5ffcfeefbc77603111eb9faae2375c1bd71d00fc5610c522261905cf007d59b3_instance+0x68>
 10518da:	je     105194d <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x317d>
 10518dc:	mov    %rax,0x6a605(%rip)        # 10bbee8 <myl_lit_5ffcfeefbc77603111eb9faae2375c1bd71d00fc5610c522261905cf007d59b3_instance+0x60>
 10518e3:	test   %bl,%bl
 10518e5:	je     105197a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x31aa>
 10518eb:	movq   $0x10bc320,0x38(%rsp)
 10518f4:	movq   $0x10bc320,0x78(%rsp)
 10518fd:	movq   $0x10bc320,0xd0(%rsp)
 1051909:	cmp    $0x10bc320,%rsi
 1051910:	jne    1051919 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3149>
 1051912:	xor    %ebx,%ebx
 1051914:	jmp    1051c06 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3436>
 1051919:	mov    $0x1,%bl
 105191b:	test   %rsi,%rsi
 105191e:	je     1051c06 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3436>
 1051924:	mov    0x8(%rsi),%rdx
 1051928:	cmp    0x6a9f9(%rip),%rdx        # 10bc328 <myl_lit_a35604ac3394cc7d310962e0ecc5dd785c46f6dc02140680027413a7b439bcdd_instance+0x18>
 105192f:	jne    1051c06 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3436>
 1051935:	test   %rdx,%rdx
 1051938:	je     1051912 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3142>
 105193a:	testb  $0x4,0x10(%rsi)
 105193e:	jne    1051af2 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3322>
 1051944:	lea    0x18(%rsi),%rdi
 1051948:	jmp    1051b01 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3331>
 105194d:	lea    0xd0(%rsp),%rax
 1051955:	mov    0x8(%rsp),%rcx
 105195a:	lea    0x258(%rcx),%rdi
 1051961:	mov    %rsi,%r14
 1051964:	mov    %rax,%rsi
 1051967:	vzeroupper
 105196a:	call   1088850 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop>
 105196f:	mov    %r14,%rsi
 1051972:	test   %bl,%bl
 1051974:	jne    10518eb <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x311b>
 105197a:	xor    %ebx,%ebx
 105197c:	lea    0x1d8(%rsp),%rbp
 1051984:	movabs $0x89705f3112a28fe5,%r12
 105198e:	xor    %eax,%eax
 1051990:	movabs $0x4000000000000002,%r13
 105199a:	nopw   0x0(%rax,%rax,1)
 10519a0:	mov    %rax,%r14
 10519a3:	mov    0x10(%rsp),%rax
 10519a8:	add    %rbx,%rax
 10519ab:	jo     1052409 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3c39>
 10519b1:	mov    0x30(%rsp),%rcx
 10519b6:	mov    0x18(%rcx),%rdi
 10519ba:	mov    (%rdi),%rcx
 10519bd:	test   %rcx,%rcx
 10519c0:	js     1052420 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3c50>
 10519c6:	je     1052430 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3c60>
 10519cc:	mov    %rax,%rdx
 10519cf:	or     %rcx,%rdx
 10519d2:	shr    $0x20,%rdx
 10519d6:	je     10519df <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x320f>
 10519d8:	cqto
 10519da:	idiv   %rcx
 10519dd:	jmp    10519e3 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3213>
 10519df:	xor    %edx,%edx
 10519e1:	div    %ecx
 10519e3:	mov    %rdx,%rsi
 10519e6:	sar    $0x3f,%rsi
 10519ea:	and    %rcx,%rsi
 10519ed:	add    %rdx,%rsi
 10519f0:	cmp    %rcx,%rsi
 10519f3:	jb     1051a0b <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x323b>
 10519f5:	mov    %rsi,%rax
 10519f8:	sar    $0x3f,%rax
 10519fc:	and    %rcx,%rax
 10519ff:	add    %rax,%rsi
 1051a02:	cmp    %rcx,%rsi
 1051a05:	jae    105244a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3c7a>
 1051a0b:	mov    0x20(%rdi),%rax
 1051a0f:	mov    (%rax,%rsi,8),%rsi
 1051a13:	mov    0x8(%rsp),%rax
 1051a18:	lea    0x258(%rax),%rdi
 1051a1f:	vzeroupper
 1051a22:	call   104bdf0 <myl_native_text_integer>
 1051a27:	test   %rax,%rax
 1051a2a:	je     1052440 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3c70>
 1051a30:	mov    %rax,%r15
 1051a33:	mov    %rax,0x78(%rsp)
 1051a38:	mov    %rax,0x1d8(%rsp)
 1051a40:	mov    0x8(%rsp),%rdi
 1051a45:	mov    %rax,%rsi
 1051a48:	call   10758b0 <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85>
 1051a4d:	test   %r13,-0x10(%r15)
 1051a51:	jne    1051a67 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3297>
 1051a53:	mov    -0x20(%r15),%rcx
 1051a57:	dec    %rcx
 1051a5a:	jne    1051a63 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3293>
 1051a5c:	cmpq   $0x0,-0x18(%r15)
 1051a61:	je     1051abe <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x32ee>
 1051a63:	mov    %rcx,-0x20(%r15)
 1051a67:	movq   $0x0,0x1d8(%rsp)
 1051a73:	mov    %r14,%rcx
 1051a76:	add    %rax,%rcx
 1051a79:	jo     1051ae0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3310>
 1051a7b:	mov    %rcx,%rax
 1051a7e:	imul   %r12
 1051a81:	add    %rcx,%rdx
 1051a84:	mov    %rdx,%rax
 1051a87:	shr    $0x3f,%rax
 1051a8b:	sar    $0x1d,%rdx
 1051a8f:	add    %rax,%rdx
 1051a92:	imul   $0x3b9aca07,%rdx,%rax
 1051a99:	sub    %rax,%rcx
 1051a9c:	mov    %rcx,%rax
 1051a9f:	sar    $0x3f,%rax
 1051aa3:	and    $0x3b9aca07,%eax
 1051aa8:	add    %rcx,%rax
 1051aab:	inc    %rbx
 1051aae:	cmp    %rbx,0x28(%rsp)
 1051ab3:	jne    10519a0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x31d0>
 1051ab9:	jmp    104f1ad <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x9dd>
 1051abe:	mov    0x8(%rsp),%rcx
 1051ac3:	lea    0x258(%rcx),%rdi
 1051aca:	mov    %rbp,%rsi
 1051acd:	mov    %rax,%r15
 1051ad0:	call   1088850 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop>
 1051ad5:	mov    %r15,%rax
 1051ad8:	mov    %r14,%rcx
 1051adb:	add    %rax,%rcx
 1051ade:	jno    1051a7b <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x32ab>
 1051ae0:	mov    0x8(%rsp),%rdi
 1051ae5:	xor    %esi,%esi
 1051ae7:	mov    %r14,%rdx
 1051aea:	mov    %rax,%rcx
 1051aed:	call   108d7b0 <myl_qbe_fail_overflow_op>
 1051af2:	mov    0x18(%rsi),%rax
 1051af6:	mov    0x14(%rsi),%ecx
 1051af9:	lea    (%rax,%rcx,1),%rdi
 1051afd:	add    $0x18,%rdi
 1051b01:	testb  $0x4,0x6a828(%rip)        # 10bc330 <myl_lit_a35604ac3394cc7d310962e0ecc5dd785c46f6dc02140680027413a7b439bcdd_instance+0x20>
 1051b08:	mov    0x6a829(%rip),%rax        # 10bc338 <myl_lit_a35604ac3394cc7d310962e0ecc5dd785c46f6dc02140680027413a7b439bcdd_instance+0x28>
 1051b0f:	mov    0x6a81f(%rip),%ecx        # 10bc334 <myl_lit_a35604ac3394cc7d310962e0ecc5dd785c46f6dc02140680027413a7b439bcdd_instance+0x24>
 1051b15:	lea    0x18(%rax,%rcx,1),%rcx
 1051b1a:	mov    $0x10bc338,%eax
 1051b1f:	cmovne %rcx,%rax
 1051b23:	cmp    $0x10,%rdx
 1051b27:	ja     1051b47 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3377>
 1051b29:	cmp    $0x8,%rdx
 1051b2d:	jb     1051b71 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x33a1>
 1051b2f:	mov    (%rdi),%rcx
 1051b32:	mov    -0x8(%rdi,%rdx,1),%rdi
 1051b37:	xor    (%rax),%rcx
 1051b3a:	xor    -0x8(%rax,%rdx,1),%rdi
 1051b3f:	or     %rcx,%rdi
 1051b42:	jmp    1051bdd <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x340d>
 1051b47:	cmp    $0x40,%rdx
 1051b4b:	ja     1051b87 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x33b7>
 1051b4d:	vmovdqu (%rdi),%xmm0
 1051b51:	cmp    $0x20,%rdx
 1051b55:	ja     1051bbd <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x33ed>
 1051b57:	vinserti128 $0x1,-0x10(%rdi,%rdx,1),%ymm0,%ymm0
 1051b5f:	vmovdqu (%rax),%xmm1
 1051b63:	vinserti128 $0x1,-0x10(%rax,%rdx,1),%ymm1,%ymm1
 1051b6b:	vpxor  %ymm1,%ymm0,%ymm0
 1051b6f:	jmp    1051bd8 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3408>
 1051b71:	cmp    $0x4,%rdx
 1051b75:	jb     1051be5 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3415>
 1051b77:	mov    (%rdi),%ecx
 1051b79:	mov    -0x4(%rdi,%rdx,1),%edi
 1051b7d:	xor    (%rax),%ecx
 1051b7f:	xor    -0x4(%rax,%rdx,1),%edi
 1051b83:	or     %ecx,%edi
 1051b85:	jmp    1051bdd <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x340d>
 1051b87:	mov    %rsi,%r14
 1051b8a:	mov    %rax,%rsi
 1051b8d:	cmp    $0x100,%rdx
 1051b94:	ja     1051bf6 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3426>
 1051b96:	vzeroupper
 1051b99:	call   10ae350 <bcmp@plt>
 1051b9e:	test   %eax,%eax
 1051ba0:	setne  %bl
 1051ba3:	jmp    1051c03 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3433>
 1051ba5:	movzwl (%rdi),%ecx
 1051ba8:	movzwl -0x2(%rdi,%rdx,1),%edi
 1051bad:	xor    (%rax),%cx
 1051bb0:	xor    -0x2(%rax,%rdx,1),%di
 1051bb5:	or     %cx,%di
 1051bb8:	jmp    1051894 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x30c4>
 1051bbd:	vmovdqu -0x20(%rdi,%rdx,1),%ymm1
 1051bc3:	vinserti128 $0x1,0x10(%rdi),%ymm0,%ymm0
 1051bca:	vpxor  -0x20(%rax,%rdx,1),%ymm1,%ymm1
 1051bd0:	vpxor  (%rax),%ymm0,%ymm0
 1051bd4:	vpor   %ymm1,%ymm0,%ymm0
 1051bd8:	vptest %ymm0,%ymm0
 1051bdd:	sete   %bl
 1051be0:	xor    $0x1,%bl
 1051be3:	jmp    1051c06 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3436>
 1051be5:	cmp    $0x1,%rdx
 1051be9:	jne    1051e08 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3638>
 1051bef:	movzbl (%rdi),%ecx
 1051bf2:	cmp    (%rax),%cl
 1051bf4:	jmp    1051bdd <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x340d>
 1051bf6:	vzeroupper
 1051bf9:	call   10943e0 <equal_large_octets>
 1051bfe:	test   %eax,%eax
 1051c00:	sete   %bl
 1051c03:	mov    %r14,%rsi
 1051c06:	test   %r13,0x6a703(%rip)        # 10bc310 <myl_lit_a35604ac3394cc7d310962e0ecc5dd785c46f6dc02140680027413a7b439bcdd_instance>
 1051c0d:	jne    1051c2c <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x345c>
 1051c0f:	mov    0x6a6ea(%rip),%rax        # 10bc300 <myl_lit_9d259d114fa076e260ed1d46f937777788fb8ac5c28077065c4fa3e2a22cd22a_instance+0x38>
 1051c16:	dec    %rax
 1051c19:	jne    1051c25 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3455>
 1051c1b:	cmpq   $0x0,0x6a6e5(%rip)        # 10bc308 <myl_lit_9d259d114fa076e260ed1d46f937777788fb8ac5c28077065c4fa3e2a22cd22a_instance+0x40>
 1051c23:	je     1051c8d <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x34bd>
 1051c25:	mov    %rax,0x6a6d4(%rip)        # 10bc300 <myl_lit_9d259d114fa076e260ed1d46f937777788fb8ac5c28077065c4fa3e2a22cd22a_instance+0x38>
 1051c2c:	test   %bl,%bl
 1051c2e:	je     1051cba <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x34ea>
 1051c34:	movq   $0x10bb7b8,0x78(%rsp)
 1051c3d:	movq   $0x10bb7b8,0xd0(%rsp)
 1051c49:	cmp    $0x10bb7b8,%rsi
 1051c50:	jne    1051c59 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3489>
 1051c52:	xor    %ebx,%ebx
 1051c54:	jmp    1051e8a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x36ba>
 1051c59:	mov    $0x1,%bl
 1051c5b:	test   %rsi,%rsi
 1051c5e:	je     1051e8a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x36ba>
 1051c64:	mov    0x8(%rsi),%rdx
 1051c68:	cmp    0x69b51(%rip),%rdx        # 10bb7c0 <myl_lit_20a5074191baf0b9771e8515f87070a522415c098c80effc97a3fee2e9d89d03_instance+0x18>
 1051c6f:	jne    1051e8a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x36ba>
 1051c75:	test   %rdx,%rdx
 1051c78:	je     1051c52 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3482>
 1051c7a:	testb  $0x4,0x10(%rsi)
 1051c7e:	jne    1051d55 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3585>
 1051c84:	lea    0x18(%rsi),%rdi
 1051c88:	jmp    1051d64 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3594>
 1051c8d:	lea    0xd0(%rsp),%rax
 1051c95:	mov    0x8(%rsp),%rcx
 1051c9a:	lea    0x258(%rcx),%rdi
 1051ca1:	mov    %rsi,%r14
 1051ca4:	mov    %rax,%rsi
 1051ca7:	vzeroupper
 1051caa:	call   1088850 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop>
 1051caf:	mov    %r14,%rsi
 1051cb2:	test   %bl,%bl
 1051cb4:	jne    1051c34 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3464>
 1051cba:	xor    %ebx,%ebx
 1051cbc:	movabs $0x89705f3112a28fe5,%r14
 1051cc6:	xor    %eax,%eax
 1051cc8:	mov    0x10(%rsp),%rsi
 1051ccd:	add    %rbx,%rsi
 1051cd0:	jo     105245a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3c8a>
 1051cd6:	mov    %rax,%r15
 1051cd9:	mov    0x30(%rsp),%rax
 1051cde:	mov    0x8(%rax),%rax
 1051ce2:	and    $0x1,%esi
 1051ce5:	mov    (%rax),%rdx
 1051ce8:	cmp    %rdx,%rsi
 1051ceb:	jae    1052471 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3ca1>
 1051cf1:	mov    0x20(%rax),%rax
 1051cf5:	mov    (%rax,%rsi,8),%rsi
 1051cf9:	mov    0x8(%rsp),%rdi
 1051cfe:	vzeroupper
 1051d01:	call   106bf60 <myl_f_ad1ca9f864adc8c89d572ada651cc6dc28bc6d83eeae5c5fc70bc26744bcdb57>
 1051d06:	mov    %r15,%rcx
 1051d09:	add    %rax,%rcx
 1051d0c:	jo     105247e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3cae>
 1051d12:	mov    %rcx,%rax
 1051d15:	imul   %r14
 1051d18:	add    %rcx,%rdx
 1051d1b:	mov    %rdx,%rax
 1051d1e:	shr    $0x3f,%rax
 1051d22:	sar    $0x1d,%rdx
 1051d26:	add    %rax,%rdx
 1051d29:	imul   $0x3b9aca07,%rdx,%rax
 1051d30:	sub    %rax,%rcx
 1051d33:	mov    %rcx,%rax
 1051d36:	sar    $0x3f,%rax
 1051d3a:	and    $0x3b9aca07,%eax
 1051d3f:	add    %rcx,%rax
 1051d42:	inc    %rbx
 1051d45:	cmp    %rbx,0x28(%rsp)
 1051d4a:	jne    1051cc8 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x34f8>
 1051d50:	jmp    104f1ad <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x9dd>
 1051d55:	mov    0x18(%rsi),%rax
 1051d59:	mov    0x14(%rsi),%ecx
 1051d5c:	lea    (%rax,%rcx,1),%rdi
 1051d60:	add    $0x18,%rdi
 1051d64:	testb  $0x4,0x69a5d(%rip)        # 10bb7c8 <myl_lit_20a5074191baf0b9771e8515f87070a522415c098c80effc97a3fee2e9d89d03_instance+0x20>
 1051d6b:	mov    0x69a5e(%rip),%rax        # 10bb7d0 <myl_lit_20a5074191baf0b9771e8515f87070a522415c098c80effc97a3fee2e9d89d03_instance+0x28>
 1051d72:	mov    0x69a54(%rip),%ecx        # 10bb7cc <myl_lit_20a5074191baf0b9771e8515f87070a522415c098c80effc97a3fee2e9d89d03_instance+0x24>
 1051d78:	lea    0x18(%rax,%rcx,1),%rcx
 1051d7d:	mov    $0x10bb7d0,%eax
 1051d82:	cmovne %rcx,%rax
 1051d86:	cmp    $0x10,%rdx
 1051d8a:	ja     1051daa <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x35da>
 1051d8c:	cmp    $0x8,%rdx
 1051d90:	jb     1051dd4 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3604>
 1051d92:	mov    (%rdi),%rcx
 1051d95:	mov    -0x8(%rdi,%rdx,1),%rdi
 1051d9a:	xor    (%rax),%rcx
 1051d9d:	xor    -0x8(%rax,%rdx,1),%rdi
 1051da2:	or     %rcx,%rdi
 1051da5:	jmp    1051e40 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3670>
 1051daa:	cmp    $0x40,%rdx
 1051dae:	ja     1051dea <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x361a>
 1051db0:	vmovdqu (%rdi),%xmm0
 1051db4:	cmp    $0x20,%rdx
 1051db8:	ja     1051e20 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3650>
 1051dba:	vinserti128 $0x1,-0x10(%rdi,%rdx,1),%ymm0,%ymm0
 1051dc2:	vmovdqu (%rax),%xmm1
 1051dc6:	vinserti128 $0x1,-0x10(%rax,%rdx,1),%ymm1,%ymm1
 1051dce:	vpxor  %ymm1,%ymm0,%ymm0
 1051dd2:	jmp    1051e3b <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x366b>
 1051dd4:	cmp    $0x4,%rdx
 1051dd8:	jb     1051e48 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3678>
 1051dda:	mov    (%rdi),%ecx
 1051ddc:	mov    -0x4(%rdi,%rdx,1),%edi
 1051de0:	xor    (%rax),%ecx
 1051de2:	xor    -0x4(%rax,%rdx,1),%edi
 1051de6:	or     %ecx,%edi
 1051de8:	jmp    1051e40 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3670>
 1051dea:	mov    %rsi,%r14
 1051ded:	mov    %rax,%rsi
 1051df0:	cmp    $0x100,%rdx
 1051df7:	ja     1051e55 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3685>
 1051df9:	vzeroupper
 1051dfc:	call   10ae350 <bcmp@plt>
 1051e01:	test   %eax,%eax
 1051e03:	setne  %bl
 1051e06:	jmp    1051e62 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3692>
 1051e08:	movzwl (%rdi),%ecx
 1051e0b:	movzwl -0x2(%rdi,%rdx,1),%edi
 1051e10:	xor    (%rax),%cx
 1051e13:	xor    -0x2(%rax,%rdx,1),%di
 1051e18:	or     %cx,%di
 1051e1b:	jmp    1051bdd <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x340d>
 1051e20:	vmovdqu -0x20(%rdi,%rdx,1),%ymm1
 1051e26:	vinserti128 $0x1,0x10(%rdi),%ymm0,%ymm0
 1051e2d:	vpxor  -0x20(%rax,%rdx,1),%ymm1,%ymm1
 1051e33:	vpxor  (%rax),%ymm0,%ymm0
 1051e37:	vpor   %ymm1,%ymm0,%ymm0
 1051e3b:	vptest %ymm0,%ymm0
 1051e40:	sete   %bl
 1051e43:	xor    $0x1,%bl
 1051e46:	jmp    1051e8a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x36ba>
 1051e48:	cmp    $0x1,%rdx
 1051e4c:	jne    1051e67 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3697>
 1051e4e:	movzbl (%rdi),%ecx
 1051e51:	cmp    (%rax),%cl
 1051e53:	jmp    1051e7a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x36aa>
 1051e55:	vzeroupper
 1051e58:	call   10943e0 <equal_large_octets>
 1051e5d:	test   %eax,%eax
 1051e5f:	sete   %bl
 1051e62:	mov    %r14,%rsi
 1051e65:	jmp    1051e8a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x36ba>
 1051e67:	movzwl (%rdi),%ecx
 1051e6a:	movzwl -0x2(%rdi,%rdx,1),%edi
 1051e6f:	xor    (%rax),%cx
 1051e72:	xor    -0x2(%rax,%rdx,1),%di
 1051e77:	or     %cx,%di
 1051e7a:	sete   %bl
 1051e7d:	xor    $0x1,%bl
 1051e80:	movabs $0x4000000000000002,%r13
 1051e8a:	test   %r13,0x69917(%rip)        # 10bb7a8 <myl_lit_20a5074191baf0b9771e8515f87070a522415c098c80effc97a3fee2e9d89d03_instance>
 1051e91:	jne    1051eb0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x36e0>
 1051e93:	mov    0x698fe(%rip),%rax        # 10bb798 <myl_lit_1ad4f10fd641593331eda3448c74a0b009c6527a19d75e6283c9d7ef74595fd2_instance+0x38>
 1051e9a:	dec    %rax
 1051e9d:	jne    1051ea9 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x36d9>
 1051e9f:	cmpq   $0x0,0x698f9(%rip)        # 10bb7a0 <myl_lit_1ad4f10fd641593331eda3448c74a0b009c6527a19d75e6283c9d7ef74595fd2_instance+0x40>
 1051ea7:	je     1051f0d <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x373d>
 1051ea9:	mov    %rax,0x698e8(%rip)        # 10bb798 <myl_lit_1ad4f10fd641593331eda3448c74a0b009c6527a19d75e6283c9d7ef74595fd2_instance+0x38>
 1051eb0:	test   %bl,%bl
 1051eb2:	je     1051f2f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x375f>
 1051eb4:	movq   $0x10bb888,0x78(%rsp)
 1051ebd:	movq   $0x10bb888,0xd0(%rsp)
 1051ec9:	cmp    $0x10bb888,%rsi
 1051ed0:	jne    1051ed9 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3709>
 1051ed2:	xor    %ebx,%ebx
 1051ed4:	jmp    10520b4 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x38e4>
 1051ed9:	mov    $0x1,%bl
 1051edb:	test   %rsi,%rsi
 1051ede:	je     10520b4 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x38e4>
 1051ee4:	mov    0x8(%rsi),%rdx
 1051ee8:	cmp    0x699a1(%rip),%rdx        # 10bb890 <myl_lit_2cecebef85ac89e87c0bdc9d723015d4a10a29fb007a542e0de04f511346a3b5_instance+0x18>
 1051eef:	jne    10520b4 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x38e4>
 1051ef5:	test   %rdx,%rdx
 1051ef8:	je     1051ed2 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3702>
 1051efa:	testb  $0x4,0x10(%rsi)
 1051efe:	jne    1051fc0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x37f0>
 1051f04:	add    $0x18,%rsi
 1051f08:	jmp    1051fcf <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x37ff>
 1051f0d:	lea    0xd0(%rsp),%rax
 1051f15:	mov    0x18(%rsp),%rdi
 1051f1a:	mov    %rsi,%r14
 1051f1d:	mov    %rax,%rsi
 1051f20:	vzeroupper
 1051f23:	call   1088850 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop>
 1051f28:	mov    %r14,%rsi
 1051f2b:	test   %bl,%bl
 1051f2d:	jne    1051eb4 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x36e4>
 1051f2f:	xor    %ebx,%ebx
 1051f31:	movabs $0x89705f3112a28fe5,%r14
 1051f3b:	xor    %eax,%eax
 1051f3d:	mov    %rax,%r15
 1051f40:	mov    0x10(%rsp),%rax
 1051f45:	add    %rbx,%rax
 1051f48:	jo     1052490 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3cc0>
 1051f4e:	mov    0x30(%rsp),%rax
 1051f53:	mov    0x8(%rax),%rax
 1051f57:	cmpq   $0x0,(%rax)
 1051f5b:	je     10524a7 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3cd7>
 1051f61:	mov    0x20(%rax),%rax
 1051f65:	mov    (%rax),%rsi
 1051f68:	mov    0x8(%rsp),%rdi
 1051f6d:	vzeroupper
 1051f70:	call   10734e0 <myl_f_bc9060da36c8e282f8d98349f6541aa0f2c1802b8a99e1d4c2ef7b134103c5e2>
 1051f75:	mov    %r15,%rcx
 1051f78:	add    %rax,%rcx
 1051f7b:	jo     10524b8 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3ce8>
 1051f81:	mov    %rcx,%rax
 1051f84:	imul   %r14
 1051f87:	add    %rcx,%rdx
 1051f8a:	mov    %rdx,%rax
 1051f8d:	shr    $0x3f,%rax
 1051f91:	sar    $0x1d,%rdx
 1051f95:	add    %rax,%rdx
 1051f98:	imul   $0x3b9aca07,%rdx,%rax
 1051f9f:	sub    %rax,%rcx
 1051fa2:	mov    %rcx,%rax
 1051fa5:	sar    $0x3f,%rax
 1051fa9:	and    $0x3b9aca07,%eax
 1051fae:	add    %rcx,%rax
 1051fb1:	inc    %rbx
 1051fb4:	cmp    %rbx,0x28(%rsp)
 1051fb9:	jne    1051f3d <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x376d>
 1051fbb:	jmp    104f1ad <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x9dd>
 1051fc0:	mov    0x18(%rsi),%rax
 1051fc4:	mov    0x14(%rsi),%ecx
 1051fc7:	lea    (%rax,%rcx,1),%rsi
 1051fcb:	add    $0x18,%rsi
 1051fcf:	testb  $0x4,0x698c2(%rip)        # 10bb898 <myl_lit_2cecebef85ac89e87c0bdc9d723015d4a10a29fb007a542e0de04f511346a3b5_instance+0x20>
 1051fd6:	mov    0x698c3(%rip),%rax        # 10bb8a0 <myl_lit_2cecebef85ac89e87c0bdc9d723015d4a10a29fb007a542e0de04f511346a3b5_instance+0x28>
 1051fdd:	mov    0x698b9(%rip),%ecx        # 10bb89c <myl_lit_2cecebef85ac89e87c0bdc9d723015d4a10a29fb007a542e0de04f511346a3b5_instance+0x24>
 1051fe3:	lea    0x18(%rax,%rcx,1),%rcx
 1051fe8:	mov    $0x10bb8a0,%eax
 1051fed:	cmovne %rcx,%rax
 1051ff1:	cmp    $0x10,%rdx
 1051ff5:	ja     105201b <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x384b>
 1051ff7:	cmp    $0x8,%rdx
 1051ffb:	jb     1052048 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3878>
 1051ffd:	mov    (%rsi),%rcx
 1052000:	mov    -0x8(%rsi,%rdx,1),%rsi
 1052005:	xor    (%rax),%rcx
 1052008:	xor    -0x8(%rax,%rdx,1),%rsi
 105200d:	or     %rcx,%rsi
 1052010:	sete   %bl
 1052013:	xor    $0x1,%bl
 1052016:	jmp    10520b4 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x38e4>
 105201b:	cmp    $0x40,%rdx
 105201f:	ja     1052062 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3892>
 1052021:	mov    %rsi,%rcx
 1052024:	vmovdqu (%rsi),%xmm0
 1052028:	cmp    $0x20,%rdx
 105202c:	ja     1052084 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x38b4>
 105202e:	vinserti128 $0x1,-0x10(%rcx,%rdx,1),%ymm0,%ymm0
 1052036:	vmovdqu (%rax),%xmm1
 105203a:	vinserti128 $0x1,-0x10(%rax,%rdx,1),%ymm1,%ymm1
 1052042:	vpxor  %ymm1,%ymm0,%ymm0
 1052046:	jmp    105209f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x38cf>
 1052048:	cmp    $0x4,%rdx
 105204c:	jb     10521cb <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x39fb>
 1052052:	mov    (%rsi),%ecx
 1052054:	mov    -0x4(%rsi,%rdx,1),%esi
 1052058:	xor    (%rax),%ecx
 105205a:	xor    -0x4(%rax,%rdx,1),%esi
 105205e:	or     %ecx,%esi
 1052060:	jmp    10520a4 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x38d4>
 1052062:	mov    %rsi,%rdi
 1052065:	mov    %rax,%rsi
 1052068:	cmp    $0x100,%rdx
 105206f:	ja     10521db <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3a0b>
 1052075:	vzeroupper
 1052078:	call   10ae350 <bcmp@plt>
 105207d:	test   %eax,%eax
 105207f:	setne  %bl
 1052082:	jmp    10520aa <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x38da>
 1052084:	vmovdqu -0x20(%rcx,%rdx,1),%ymm1
 105208a:	vinserti128 $0x1,0x10(%rcx),%ymm0,%ymm0
 1052091:	vpxor  -0x20(%rax,%rdx,1),%ymm1,%ymm1
 1052097:	vpxor  (%rax),%ymm0,%ymm0
 105209b:	vpor   %ymm1,%ymm0,%ymm0
 105209f:	vptest %ymm0,%ymm0
 10520a4:	sete   %bl
 10520a7:	xor    $0x1,%bl
 10520aa:	movabs $0x4000000000000002,%r13
 10520b4:	test   %r13,0x697bd(%rip)        # 10bb878 <myl_lit_2cecebef85ac89e87c0bdc9d723015d4a10a29fb007a542e0de04f511346a3b5_instance>
 10520bb:	jne    10520da <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x390a>
 10520bd:	mov    0x697a4(%rip),%rax        # 10bb868 <myl_lit_2ac6840555c10725b6640492294f67393cd0d698e5786fc4e12cdb1cc9a394a2_instance+0x38>
 10520c4:	dec    %rax
 10520c7:	jne    10520d3 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3903>
 10520c9:	cmpq   $0x0,0x6979f(%rip)        # 10bb870 <myl_lit_2ac6840555c10725b6640492294f67393cd0d698e5786fc4e12cdb1cc9a394a2_instance+0x40>
 10520d1:	je     10520e5 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3915>
 10520d3:	mov    %rax,0x6978e(%rip)        # 10bb868 <myl_lit_2ac6840555c10725b6640492294f67393cd0d698e5786fc4e12cdb1cc9a394a2_instance+0x38>
 10520da:	test   %bl,%bl
 10520dc:	je     10520fe <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x392e>
 10520de:	xor    %eax,%eax
 10520e0:	jmp    104f1ad <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x9dd>
 10520e5:	lea    0xd0(%rsp),%rsi
 10520ed:	mov    0x18(%rsp),%rdi
 10520f2:	vzeroupper
 10520f5:	call   1088850 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop>
 10520fa:	test   %bl,%bl
 10520fc:	jne    10520de <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x390e>
 10520fe:	xor    %ebx,%ebx
 1052100:	movabs $0x7878787878787879,%r14
 105210a:	movabs $0x89705f3112a28fe5,%r15
 1052114:	xor    %eax,%eax
 1052116:	mov    0x10(%rsp),%rcx
 105211b:	add    %rbx,%rcx
 105211e:	jo     10524ca <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3cfa>
 1052124:	mov    %rax,%r12
 1052127:	mov    0x30(%rsp),%rax
 105212c:	mov    0x8(%rax),%rax
 1052130:	cmpq   $0x0,(%rax)
 1052134:	je     10524e1 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3d11>
 105213a:	mov    0x20(%rax),%rax
 105213e:	mov    (%rax),%rsi
 1052141:	mov    %rcx,%rax
 1052144:	imul   %r14
 1052147:	mov    %rdx,%rax
 105214a:	shr    $0x3f,%rax
 105214e:	sar    $0x3,%rdx
 1052152:	add    %rax,%rdx
 1052155:	mov    %rdx,%rax
 1052158:	shl    $0x4,%rax
 105215c:	add    %rdx,%rax
 105215f:	sub    %rax,%rcx
 1052162:	mov    %rcx,%rdx
 1052165:	sar    $0x3f,%rdx
 1052169:	and    $0x11,%edx
 105216c:	add    %rcx,%rdx
 105216f:	mov    0x8(%rsp),%rdi
 1052174:	vzeroupper
 1052177:	call   1058cc0 <myl_f_47022dd26e980fcb99b6abeb2cfdf289edce3d6955dda89c0a131b73692c5f56>
 105217c:	mov    %r12,%rcx
 105217f:	add    %rax,%rcx
 1052182:	jo     10524f2 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3d22>
 1052188:	mov    %rcx,%rax
 105218b:	imul   %r15
 105218e:	add    %rcx,%rdx
 1052191:	mov    %rdx,%rax
 1052194:	shr    $0x3f,%rax
 1052198:	sar    $0x1d,%rdx
 105219c:	add    %rax,%rdx
 105219f:	imul   $0x3b9aca07,%rdx,%rax
 10521a6:	sub    %rax,%rcx
 10521a9:	mov    %rcx,%rax
 10521ac:	sar    $0x3f,%rax
 10521b0:	and    $0x3b9aca07,%eax
 10521b5:	add    %rcx,%rax
 10521b8:	inc    %rbx
 10521bb:	cmp    %rbx,0x28(%rsp)
 10521c0:	jne    1052116 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3946>
 10521c6:	jmp    104f1ad <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x9dd>
 10521cb:	cmp    $0x1,%rdx
 10521cf:	jne    10521ed <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3a1d>
 10521d1:	movzbl (%rsi),%ecx
 10521d4:	cmp    (%rax),%cl
 10521d6:	jmp    10520a4 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x38d4>
 10521db:	vzeroupper
 10521de:	call   10943e0 <equal_large_octets>
 10521e3:	test   %eax,%eax
 10521e5:	sete   %bl
 10521e8:	jmp    10520aa <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x38da>
 10521ed:	movzwl (%rsi),%ecx
 10521f0:	movzwl -0x2(%rsi,%rdx,1),%esi
 10521f5:	xor    (%rax),%cx
 10521f8:	xor    -0x2(%rax,%rdx,1),%si
 10521fd:	or     %cx,%si
 1052200:	jmp    10520a4 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x38d4>
 1052205:	vzeroupper
 1052208:	call   10ae330 <abort@plt>
 105220d:	vzeroupper
 1052210:	call   109c6b7 <myl_rc_invariant_failed>
 1052215:	mov    0x8(%rsp),%rdi
 105221a:	xor    %esi,%esi
 105221c:	vzeroupper
 105221f:	call   108d7b0 <myl_qbe_fail_overflow_op>
 1052224:	mov    0x8(%rsp),%rdi
 1052229:	xor    %esi,%esi
 105222b:	mov    %r12,%rdx
 105222e:	mov    %rax,%rcx
 1052231:	call   108d7b0 <myl_qbe_fail_overflow_op>
 1052236:	mov    0x8(%rsp),%rdi
 105223b:	vzeroupper
 105223e:	call   108d560 <myl_qbe_fail_iteration>
 1052243:	mov    0x8(%rsp),%rdi
 1052248:	xor    %esi,%esi
 105224a:	mov    0x10(%rsp),%rdx
 105224f:	mov    %r14,%rcx
 1052252:	vzeroupper
 1052255:	call   108d7b0 <myl_qbe_fail_overflow_op>
 105225a:	mov    0x8(%rsp),%rdi
 105225f:	xor    %esi,%esi
 1052261:	mov    %r12,%rdx
 1052264:	mov    %rbx,%rcx
 1052267:	vzeroupper
 105226a:	call   108d7b0 <myl_qbe_fail_overflow_op>
 105226f:	mov    0x8(%rsp),%rdi
 1052274:	vzeroupper
 1052277:	call   108d6a0 <myl_qbe_fail_normalized_index_bounds>
 105227c:	mov    0x8(%rsp),%rdi
 1052281:	vzeroupper
 1052284:	call   108d6a0 <myl_qbe_fail_normalized_index_bounds>
 1052289:	mov    0x8(%rsp),%rdi
 105228e:	xor    %esi,%esi
 1052290:	mov    0x10(%rsp),%rdx
 1052295:	mov    %rbx,%rcx
 1052298:	vzeroupper
 105229b:	call   108d7b0 <myl_qbe_fail_overflow_op>
 10522a0:	mov    0x8(%rsp),%rdi
 10522a5:	xor    %esi,%esi
 10522a7:	mov    0x10(%rsp),%rdx
 10522ac:	mov    %rbx,%rcx
 10522af:	vzeroupper
 10522b2:	call   108d7b0 <myl_qbe_fail_overflow_op>
 10522b7:	mov    0x8(%rsp),%rdi
 10522bc:	xor    %esi,%esi
 10522be:	xor    %edx,%edx
 10522c0:	vzeroupper
 10522c3:	call   108d6a0 <myl_qbe_fail_normalized_index_bounds>
 10522c8:	mov    0x8(%rsp),%rdi
 10522cd:	vzeroupper
 10522d0:	call   108d6a0 <myl_qbe_fail_normalized_index_bounds>
 10522d5:	mov    $0x1,%ecx
 10522da:	mov    0x8(%rsp),%rdi
 10522df:	xor    %esi,%esi
 10522e1:	mov    %r15,%rdx
 10522e4:	vzeroupper
 10522e7:	call   108d7b0 <myl_qbe_fail_overflow_op>
 10522ec:	mov    0x8(%rsp),%rdi
 10522f1:	vzeroupper
 10522f4:	call   108d6a0 <myl_qbe_fail_normalized_index_bounds>
 10522f9:	mov    0x8(%rsp),%rdi
 10522fe:	xor    %esi,%esi
 1052300:	mov    0x10(%rsp),%rdx
 1052305:	mov    %r12,%rcx
 1052308:	vzeroupper
 105230b:	call   108d7b0 <myl_qbe_fail_overflow_op>
 1052310:	mov    0x8(%rsp),%rdi
 1052315:	vzeroupper
 1052318:	call   108d870 <myl_qbe_fail_frame>
 105231d:	mov    0x8(%rsp),%rdi
 1052322:	vzeroupper
 1052325:	call   108d550 <myl_qbe_fail_empty_separator>
 105232a:	mov    0x8(%rsp),%rdi
 105232f:	vzeroupper
 1052332:	call   108d460 <myl_qbe_fail_allocation>
 1052337:	mov    0x8(%rsp),%rdi
 105233c:	xor    %esi,%esi
 105233e:	mov    %r14,%rcx
 1052341:	vzeroupper
 1052344:	call   108d7b0 <myl_qbe_fail_overflow_op>
 1052349:	mov    0x8(%rsp),%rdi
 105234e:	mov    %r15,%rsi
 1052351:	vzeroupper
 1052354:	call   108d810 <myl_qbe_fail_cast>
 1052359:	mov    $0x2,%esi
 105235e:	mov    $0x7,%ecx
 1052363:	mov    0x8(%rsp),%rdi
 1052368:	mov    %r15,%rdx
 105236b:	vzeroupper
 105236e:	call   108d7b0 <myl_qbe_fail_overflow_op>
 1052373:	mov    0x8(%rsp),%rdi
 1052378:	call   108d870 <myl_qbe_fail_frame>
 105237d:	mov    0x8(%rsp),%rdi
 1052382:	call   108d460 <myl_qbe_fail_allocation>
 1052387:	mov    0x8(%rsp),%rdi
 105238c:	xor    %esi,%esi
 105238e:	mov    %r14,%rdx
 1052391:	mov    %r13,%rcx
 1052394:	call   108d7b0 <myl_qbe_fail_overflow_op>
 1052399:	mov    0x8(%rsp),%rdi
 105239e:	xor    %esi,%esi
 10523a0:	mov    0x10(%rsp),%rdx
 10523a5:	mov    %r15,%rcx
 10523a8:	vzeroupper
 10523ab:	call   108d7b0 <myl_qbe_fail_overflow_op>
 10523b0:	mov    0x8(%rsp),%rdi
 10523b5:	xor    %esi,%esi
 10523b7:	mov    0x10(%rsp),%rdx
 10523bc:	mov    %rbx,%rcx
 10523bf:	vzeroupper
 10523c2:	call   108d7b0 <myl_qbe_fail_overflow_op>
 10523c7:	mov    0x8(%rsp),%rdi
 10523cc:	mov    %rcx,%rsi
 10523cf:	vzeroupper
 10523d2:	call   108d810 <myl_qbe_fail_cast>
 10523d7:	mov    0x8(%rsp),%rdi
 10523dc:	mov    %rax,%rsi
 10523df:	vzeroupper
 10523e2:	call   108d760 <myl_qbe_fail_division>
 10523e7:	mov    0x8(%rsp),%rdi
 10523ec:	mov    %rcx,%rdx
 10523ef:	vzeroupper
 10523f2:	call   108d6a0 <myl_qbe_fail_normalized_index_bounds>
 10523f7:	mov    0x8(%rsp),%rdi
 10523fc:	xor    %esi,%esi
 10523fe:	mov    %r15,%rdx
 1052401:	mov    %r12,%rcx
 1052404:	call   108d7b0 <myl_qbe_fail_overflow_op>
 1052409:	mov    0x8(%rsp),%rdi
 105240e:	xor    %esi,%esi
 1052410:	mov    0x10(%rsp),%rdx
 1052415:	mov    %rbx,%rcx
 1052418:	vzeroupper
 105241b:	call   108d7b0 <myl_qbe_fail_overflow_op>
 1052420:	mov    0x8(%rsp),%rdi
 1052425:	mov    %rcx,%rsi
 1052428:	vzeroupper
 105242b:	call   108d810 <myl_qbe_fail_cast>
 1052430:	mov    0x8(%rsp),%rdi
 1052435:	mov    %rax,%rsi
 1052438:	vzeroupper
 105243b:	call   108d760 <myl_qbe_fail_division>
 1052440:	mov    0x8(%rsp),%rdi
 1052445:	call   108d460 <myl_qbe_fail_allocation>
 105244a:	mov    0x8(%rsp),%rdi
 105244f:	mov    %rcx,%rdx
 1052452:	vzeroupper
 1052455:	call   108d6a0 <myl_qbe_fail_normalized_index_bounds>
 105245a:	mov    0x8(%rsp),%rdi
 105245f:	xor    %esi,%esi
 1052461:	mov    0x10(%rsp),%rdx
 1052466:	mov    %rbx,%rcx
 1052469:	vzeroupper
 105246c:	call   108d7b0 <myl_qbe_fail_overflow_op>
 1052471:	mov    0x8(%rsp),%rdi
 1052476:	vzeroupper
 1052479:	call   108d6a0 <myl_qbe_fail_normalized_index_bounds>
 105247e:	mov    %r15,%rdx
 1052481:	mov    0x8(%rsp),%rdi
 1052486:	xor    %esi,%esi
 1052488:	mov    %rax,%rcx
 105248b:	call   108d7b0 <myl_qbe_fail_overflow_op>
 1052490:	mov    0x8(%rsp),%rdi
 1052495:	xor    %esi,%esi
 1052497:	mov    0x10(%rsp),%rdx
 105249c:	mov    %rbx,%rcx
 105249f:	vzeroupper
 10524a2:	call   108d7b0 <myl_qbe_fail_overflow_op>
 10524a7:	mov    0x8(%rsp),%rdi
 10524ac:	xor    %esi,%esi
 10524ae:	xor    %edx,%edx
 10524b0:	vzeroupper
 10524b3:	call   108d6a0 <myl_qbe_fail_normalized_index_bounds>
 10524b8:	mov    %r15,%rdx
 10524bb:	mov    0x8(%rsp),%rdi
 10524c0:	xor    %esi,%esi
 10524c2:	mov    %rax,%rcx
 10524c5:	call   108d7b0 <myl_qbe_fail_overflow_op>
 10524ca:	mov    0x8(%rsp),%rdi
 10524cf:	xor    %esi,%esi
 10524d1:	mov    0x10(%rsp),%rdx
 10524d6:	mov    %rbx,%rcx
 10524d9:	vzeroupper
 10524dc:	call   108d7b0 <myl_qbe_fail_overflow_op>
 10524e1:	mov    0x8(%rsp),%rdi
 10524e6:	xor    %esi,%esi
 10524e8:	xor    %edx,%edx
 10524ea:	vzeroupper
 10524ed:	call   108d6a0 <myl_qbe_fail_normalized_index_bounds>
 10524f2:	mov    %r12,%rdx
 10524f5:	mov    0x8(%rsp),%rdi
 10524fa:	xor    %esi,%esi
 10524fc:	mov    %rax,%rcx
 10524ff:	call   108d7b0 <myl_qbe_fail_overflow_op>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
