   27149:	add    %r12,%rcx
   2714c:	mov    %rcx,%rax
   2714f:	imul   %rbp
   27152:	add    %rcx,%rdx
   27155:	mov    %rdx,%rax
   27158:	shr    $0x3f,%rax
   2715c:	sar    $0x1d,%rdx
   27160:	add    %rax,%rdx
   27163:	imul   $0x3b9aca07,%rdx,%rax
   2716a:	sub    %rax,%rcx
   2716d:	incq   0x10(%rsp)
   27172:	mov    %rcx,(%rsp)
   27176:	mov    %rcx,%r12
   27179:	decq   0x18(%rsp)
   2717e:	je     259bd <_RNvCseJ3uQ9fe193_12runtime_text4main+0x2aad>
