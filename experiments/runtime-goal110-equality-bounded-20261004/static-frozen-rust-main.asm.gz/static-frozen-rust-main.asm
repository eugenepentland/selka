
/home/epentland/ai/canopy/mylang-worktrees/goal110-equality-bounded-20261004/.mylang-cache/goal110-equality-bounded-rf/runner/bin/text-rust:     file format elf64-x86-64


Disassembly of section .text:

0000000000022f10 <_RNvCseJ3uQ9fe193_12runtime_text4main>:
   22f10:	push   %rbp
   22f11:	push   %r15
   22f13:	push   %r14
   22f15:	push   %r13
   22f17:	push   %r12
   22f19:	push   %rbx
   22f1a:	sub    $0x2d8,%rsp
   22f21:	lea    0x80(%rsp),%rbp
   22f29:	mov    %rbp,%rdi
   22f2c:	call   *0x5f236(%rip)        # 82168 <_DYNAMIC+0x240>
   22f32:	movq   $0x1,0xa0(%rsp)
   22f3e:	lea    0x240(%rsp),%rdi
   22f46:	mov    %rbp,%rsi
   22f49:	call   32bf0 <_RNvXNtNtCs6i54tJFfzR_5alloc3vec21spec_from_iter_nestedINtB4_3VecNtNtB6_6string6StringEINtB2_18SpecFromIterNestedB10_INtNtNtNtCsgxBkk5gSRhY_4core4iter8adapters4skip4SkipNtNtCs9k3SxhrAWiO_3std3env4ArgsEE9from_iterCseJ3uQ9fe193_12runtime_text>
   22f4e:	cmpq   $0x4,0x250(%rsp)
   22f57:	jne    276b3 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x47a3>
   22f5d:	mov    0x248(%rsp),%rdi
   22f65:	mov    0x10(%rdi),%rax
   22f69:	lea    -0x9(%rax),%rsi
   22f6d:	cmp    $0x5,%rsi
   22f71:	ja     276b3 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x47a3>
   22f77:	mov    0x8(%rdi),%rcx
   22f7b:	lea    -0x17942(%rip),%rdx        # b640 <anon.db448e2af9fdd3f56f054211eea53148.7.llvm.3520701504562932850+0x300>
   22f82:	movslq (%rdx,%rsi,4),%r8
   22f86:	add    %rdx,%r8
   22f89:	jmp    *%r8
   22f8c:	movabs $0x737261705f746e69,%rax
   22f96:	xor    (%rcx),%rax
   22f99:	movzbl 0x8(%rcx),%edx
   22f9d:	xor    $0x65,%rdx
   22fa1:	jmp    230d5 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x1c5>
   22fa6:	movabs $0x655f676e69727473,%rdx
   22fb0:	xor    (%rcx),%rdx
   22fb3:	mov    0x8(%rcx),%r8d
   22fb7:	xor    $0x6c617571,%r8
   22fbe:	or     %rdx,%r8
   22fc1:	je     230de <_RNvCseJ3uQ9fe193_12runtime_text4main+0x1ce>
   22fc7:	movabs $0x735f676e69727473,%rdx
   22fd1:	xor    (%rcx),%rdx
   22fd4:	mov    0x8(%rcx),%r8d
   22fd8:	xor    $0x74696c70,%r8
   22fdf:	or     %rdx,%r8
   22fe2:	jne    230a9 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x199>
   22fe8:	jmp    230de <_RNvCseJ3uQ9fe193_12runtime_text4main+0x1ce>
   22fed:	movabs $0x6a5f676e69727473,%rax
   22ff7:	xor    (%rcx),%rax
   22ffa:	movabs $0x6e696f6a5f676e69,%rdx
   23004:	xor    0x3(%rcx),%rdx
   23008:	jmp    230d5 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x1c5>
   2300d:	movabs $0x63735f7365747962,%rax
   23017:	xor    (%rcx),%rax
   2301a:	movzwl 0x8(%rcx),%edx
   2301e:	xor    $0x6e61,%rdx
   23025:	or     %rax,%rdx
   23028:	je     230de <_RNvCseJ3uQ9fe193_12runtime_text4main+0x1ce>
   2302e:	movabs $0x6d726f665f746e69,%rax
   23038:	xor    (%rcx),%rax
   2303b:	movzwl 0x8(%rcx),%edx
   2303f:	xor    $0x7461,%rdx
   23046:	or     %rax,%rdx
   23049:	je     230de <_RNvCseJ3uQ9fe193_12runtime_text4main+0x1ce>
   2304f:	movabs $0x756f635f64726f77,%rax
   23059:	xor    (%rcx),%rax
   2305c:	movzwl 0x8(%rcx),%edx
   23060:	xor    $0x746e,%rdx
   23067:	jmp    230d5 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x1c5>
   23069:	movabs $0x735f676e69727473,%rdx
   23073:	xor    (%rcx),%rdx
   23076:	movabs $0x6863726165735f67,%r8
   23080:	xor    0x5(%rcx),%r8
   23084:	or     %rdx,%r8
   23087:	je     230de <_RNvCseJ3uQ9fe193_12runtime_text4main+0x1ce>
   23089:	movabs $0x726767615f767363,%rdx
   23093:	xor    (%rcx),%rdx
   23096:	movabs $0x6574616765726767,%r8
   230a0:	xor    0x5(%rcx),%r8
   230a4:	or     %rdx,%r8
   230a7:	je     230de <_RNvCseJ3uQ9fe193_12runtime_text4main+0x1ce>
   230a9:	cmp    $0xe,%rax
   230ad:	jne    276b3 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x47a3>
   230b3:	movabs $0x6172745f6e6f736a,%rax
   230bd:	xor    (%rcx),%rax
   230c0:	movabs $0x6d726f665f746e69,%rdx
   230ca:	add    $0x13f9f309,%rdx
   230d1:	xor    0x6(%rcx),%rdx
   230d5:	or     %rax,%rdx
   230d8:	jne    276b3 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x47a3>
   230de:	mov    0x28(%rdi),%r8
   230e2:	test   %r8,%r8
   230e5:	je     2310c <_RNvCseJ3uQ9fe193_12runtime_text4main+0x1fc>
   230e7:	mov    0x20(%rdi),%r9
   230eb:	cmp    $0x1,%r8
   230ef:	jne    23126 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x216>
   230f1:	movzbl (%r9),%eax
   230f5:	xor    %r15d,%r15d
   230f8:	cmp    $0x2b,%eax
   230fb:	je     231c7 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x2b7>
   23101:	cmp    $0x2d,%eax
   23104:	je     231c7 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x2b7>
   2310a:	jmp    2312a <_RNvCseJ3uQ9fe193_12runtime_text4main+0x21a>
   2310c:	mov    %r8,%r15
   2310f:	mov    0x40(%rdi),%r8
   23113:	test   %r8,%r8
   23116:	jne    231d4 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x2c4>
   2311c:	mov    %r8,0x18(%rsp)
   23121:	jmp    232b7 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x3a7>
   23126:	movzbl (%r9),%eax
   2312a:	xor    %r10d,%r10d
   2312d:	cmp    $0x2b,%al
   2312f:	sete   %r10b
   23133:	mov    %r8,%rdx
   23136:	sub    %r10,%rdx
   23139:	add    %r10,%r9
   2313c:	mov    %r10,%rax
   2313f:	neg    %rax
   23142:	cmp    $0x11,%rdx
   23146:	jae    23188 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x278>
   23148:	test   %rdx,%rdx
   2314b:	je     23f64 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x1054>
   23151:	add    %rax,%r8
   23154:	neg    %r8
   23157:	xor    %eax,%eax
   23159:	xor    %r15d,%r15d
   2315c:	nopl   0x0(%rax)
   23160:	movzbl (%r9,%rax,1),%edx
   23165:	add    $0xffffffd0,%edx
   23168:	cmp    $0x9,%edx
   2316b:	ja     23f79 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x1069>
   23171:	lea    (%r15,%r15,4),%r10
   23175:	mov    %edx,%edx
   23177:	lea    (%rdx,%r10,2),%r15
   2317b:	inc    %rax
   2317e:	mov    %r8,%rdx
   23181:	add    %rax,%rdx
   23184:	jne    23160 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x250>
   23186:	jmp    231c7 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x2b7>
   23188:	add    %rax,%r8
   2318b:	neg    %r8
   2318e:	xor    %r15d,%r15d
   23191:	mov    $0xa,%r10d
   23197:	xor    %r11d,%r11d
   2319a:	xor    %eax,%eax
   2319c:	mov    %r8,%rdx
   2319f:	add    %r11,%rdx
   231a2:	je     27798 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4888>
   231a8:	mul    %r10
   231ab:	jo     231c7 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x2b7>
   231ad:	movzbl (%r9,%r11,1),%ebx
   231b2:	add    $0xffffffd0,%ebx
   231b5:	add    %rbx,%rax
   231b8:	setb   %dl
   231bb:	cmp    $0x9,%ebx
   231be:	ja     231c7 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x2b7>
   231c0:	inc    %r11
   231c3:	test   %dl,%dl
   231c5:	je     2319c <_RNvCseJ3uQ9fe193_12runtime_text4main+0x28c>
   231c7:	mov    0x40(%rdi),%r8
   231cb:	test   %r8,%r8
   231ce:	je     2311c <_RNvCseJ3uQ9fe193_12runtime_text4main+0x20c>
   231d4:	mov    0x38(%rdi),%r9
   231d8:	cmp    $0x1,%r8
   231dc:	jne    231ff <_RNvCseJ3uQ9fe193_12runtime_text4main+0x2ef>
   231de:	movzbl (%r9),%eax
   231e2:	movq   $0x0,0x18(%rsp)
   231eb:	cmp    $0x2b,%eax
   231ee:	je     232b7 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x3a7>
   231f4:	cmp    $0x2d,%eax
   231f7:	je     232b7 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x3a7>
   231fd:	jmp    23203 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x2f3>
   231ff:	movzbl (%r9),%eax
   23203:	xor    %r10d,%r10d
   23206:	cmp    $0x2b,%al
   23208:	sete   %r10b
   2320c:	mov    %r8,%rdx
   2320f:	sub    %r10,%rdx
   23212:	add    %r10,%r9
   23215:	mov    %r10,%rax
   23218:	neg    %rax
   2321b:	cmp    $0x11,%rdx
   2321f:	jae    23272 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x362>
   23221:	test   %rdx,%rdx
   23224:	je     232d3 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x3c3>
   2322a:	add    %rax,%r8
   2322d:	neg    %r8
   23230:	xor    %eax,%eax
   23232:	movq   $0x0,0x18(%rsp)
   2323b:	nopl   0x0(%rax,%rax,1)
   23240:	movzbl (%r9,%rax,1),%edx
   23245:	add    $0xffffffd0,%edx
   23248:	cmp    $0x9,%edx
   2324b:	ja     232d3 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x3c3>
   23251:	mov    0x18(%rsp),%r10
   23256:	lea    (%r10,%r10,4),%r10
   2325a:	mov    %edx,%edx
   2325c:	lea    (%rdx,%r10,2),%rdx
   23260:	mov    %rdx,0x18(%rsp)
   23265:	inc    %rax
   23268:	mov    %r8,%rdx
   2326b:	add    %rax,%rdx
   2326e:	jne    23240 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x330>
   23270:	jmp    232b7 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x3a7>
   23272:	add    %rax,%r8
   23275:	neg    %r8
   23278:	movq   $0x0,0x18(%rsp)
   23281:	mov    $0xa,%r10d
   23287:	xor    %r11d,%r11d
   2328a:	xor    %eax,%eax
   2328c:	mov    %r8,%rdx
   2328f:	add    %r11,%rdx
   23292:	je     277ad <_RNvCseJ3uQ9fe193_12runtime_text4main+0x489d>
   23298:	mul    %r10
   2329b:	jo     232b7 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x3a7>
   2329d:	movzbl (%r9,%r11,1),%ebx
   232a2:	add    $0xffffffd0,%ebx
   232a5:	add    %rbx,%rax
   232a8:	setb   %dl
   232ab:	cmp    $0x9,%ebx
   232ae:	ja     232b7 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x3a7>
   232b0:	inc    %r11
   232b3:	test   %dl,%dl
   232b5:	je     2328c <_RNvCseJ3uQ9fe193_12runtime_text4main+0x37c>
   232b7:	mov    0x50(%rdi),%rax
   232bb:	mov    0x58(%rdi),%rdx
   232bf:	cmp    $0x1,%rdx
   232c3:	je     232ea <_RNvCseJ3uQ9fe193_12runtime_text4main+0x3da>
   232c5:	test   %rdx,%rdx
   232c8:	je     276b3 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x47a3>
   232ce:	movzbl (%rax),%edi
   232d1:	jmp    232ff <_RNvCseJ3uQ9fe193_12runtime_text4main+0x3ef>
   232d3:	movq   $0x0,0x18(%rsp)
   232dc:	mov    0x50(%rdi),%rax
   232e0:	mov    0x58(%rdi),%rdx
   232e4:	cmp    $0x1,%rdx
   232e8:	jne    232c5 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x3b5>
   232ea:	movzbl (%rax),%edi
   232ed:	cmp    $0x2b,%edi
   232f0:	je     276b3 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x47a3>
   232f6:	cmp    $0x2d,%edi
   232f9:	je     276b3 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x47a3>
   232ff:	cmp    $0x2d,%dil
   23303:	je     2335b <_RNvCseJ3uQ9fe193_12runtime_text4main+0x44b>
   23305:	movzbl %dil,%edi
   23309:	cmp    $0x2b,%edi
   2330c:	jne    23314 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x404>
   2330e:	inc    %rax
   23311:	dec    %rdx
   23314:	cmp    $0x10,%rdx
   23318:	jae    233aa <_RNvCseJ3uQ9fe193_12runtime_text4main+0x49a>
   2331e:	test   %rdx,%rdx
   23321:	je     276b3 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x47a3>
   23327:	xor    %r9d,%r9d
   2332a:	xor    %edi,%edi
   2332c:	nopl   0x0(%rax)
   23330:	movzbl (%rax,%rdi,1),%r8d
   23335:	add    $0xffffffd0,%r8d
   23339:	cmp    $0x9,%r8d
   2333d:	ja     276b3 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x47a3>
   23343:	lea    (%r9,%r9,4),%r9
   23347:	mov    %r8d,%r8d
   2334a:	lea    (%r8,%r9,2),%r9
   2334e:	inc    %rdi
   23351:	cmp    %rdi,%rdx
   23354:	jne    23330 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x420>
   23356:	jmp    23421 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x511>
   2335b:	cmp    $0x11,%rdx
   2335f:	jae    233e3 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4d3>
   23365:	mov    %rdx,%rdi
   23368:	dec    %rdi
   2336b:	je     276b3 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x47a3>
   23371:	mov    $0x1,%edi
   23376:	xor    %r9d,%r9d
   23379:	nopl   0x0(%rax)
   23380:	movzbl (%rax,%rdi,1),%r8d
   23385:	add    $0xffffffd0,%r8d
   23389:	cmp    $0x9,%r8d
   2338d:	ja     276b3 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x47a3>
   23393:	add    %r9,%r9
   23396:	lea    (%r9,%r9,4),%r9
   2339a:	mov    %r8d,%r8d
   2339d:	sub    %r8,%r9
   233a0:	inc    %rdi
   233a3:	cmp    %rdi,%rdx
   233a6:	jne    23380 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x470>
   233a8:	jmp    23421 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x511>
   233aa:	xor    %r9d,%r9d
   233ad:	xor    %edi,%edi
   233af:	nop
   233b0:	imul   $0xa,%r9,%r9
   233b4:	jo     276b3 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x47a3>
   233ba:	movzbl (%rax,%rdi,1),%r8d
   233bf:	add    $0xffffffd0,%r8d
   233c3:	cmp    $0x9,%r8d
   233c7:	ja     276b3 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x47a3>
   233cd:	mov    %r8d,%r8d
   233d0:	add    %r8,%r9
   233d3:	jo     276b3 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x47a3>
   233d9:	inc    %rdi
   233dc:	cmp    %rdi,%rdx
   233df:	jne    233b0 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4a0>
   233e1:	jmp    23421 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x511>
   233e3:	mov    $0x1,%edi
   233e8:	xor    %r9d,%r9d
   233eb:	nopl   0x0(%rax,%rax,1)
   233f0:	imul   $0xa,%r9,%r9
   233f4:	jo     276b3 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x47a3>
   233fa:	movzbl (%rax,%rdi,1),%r8d
   233ff:	add    $0xffffffd0,%r8d
   23403:	cmp    $0x9,%r8d
   23407:	ja     276b3 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x47a3>
   2340d:	mov    %r8d,%r8d
   23410:	sub    %r8,%r9
   23413:	jo     276b3 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x47a3>
   23419:	inc    %rdi
   2341c:	cmp    %rdi,%rdx
   2341f:	jne    233f0 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4e0>
   23421:	cmp    $0x2,%r15
   23425:	jb     276b3 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x47a3>
   2342b:	cmpq   $0x0,0x18(%rsp)
   23431:	je     276b3 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x47a3>
   23437:	lea    -0x1(%r9),%rax
   2343b:	cmp    $0xf423f,%rax
   23441:	ja     276b3 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x47a3>
   23447:	mov    %r9,0x1a0(%rsp)
   2344f:	movq   $0x0,0x120(%rsp)
   2345b:	movq   $0x1,0x128(%rsp)
   23467:	pxor   %xmm0,%xmm0
   2346b:	movdqu %xmm0,0x130(%rsp)
   23474:	movq   $0x8,0x140(%rsp)
   23480:	movdqu %xmm0,0x148(%rsp)
   23489:	movq   $0x8,0x158(%rsp)
   23495:	movdqu %xmm0,0x160(%rsp)
   2349e:	movq   $0x8,0x170(%rsp)
   234aa:	movdqu %xmm0,0x178(%rsp)
   234b3:	movq   $0x8,0x188(%rsp)
   234bf:	movq   $0x0,0x190(%rsp)
   234cb:	cmp    $0x5,%rsi
   234cf:	ja     278fe <_RNvCseJ3uQ9fe193_12runtime_text4main+0x49ee>
   234d5:	lea    -0x17e84(%rip),%rax        # b658 <anon.db448e2af9fdd3f56f054211eea53148.7.llvm.3520701504562932850+0x318>
   234dc:	movslq (%rax,%rsi,4),%rdx
   234e0:	add    %rax,%rdx
   234e3:	mov    %r9,0x10(%rsp)
   234e8:	jmp    *%rdx
   234ea:	movabs $0x737261705f746e69,%rax
   234f4:	xor    (%rcx),%rax
   234f7:	movzbl 0x8(%rcx),%ecx
   234fb:	xor    $0x65,%rcx
   234ff:	or     %rax,%rcx
   23502:	jne    278fe <_RNvCseJ3uQ9fe193_12runtime_text4main+0x49ee>
   23508:	movq   $0x0,0x88(%rsp)
   23514:	mov    %r15,0x90(%rsp)
   2351c:	lea    0x1a0(%rsp),%rax
   23524:	mov    %rax,0x80(%rsp)
   2352c:	lea    0x1c0(%rsp),%rdi
   23534:	lea    0x80(%rsp),%rsi
   2353c:	call   336c0 <_RNvXs_NtNtCs6i54tJFfzR_5alloc3vec21spec_from_iter_nestedINtB6_3VecNtNtB8_6string6StringEINtB4_18SpecFromIterNestedB12_INtNtNtNtCsgxBkk5gSRhY_4core4iter8adapters3map3MapINtNtNtB21_3ops5range5RangejENCNvCseJ3uQ9fe193_12runtime_text6inputss1_0EE9from_iterB3d_>
   23541:	mov    0x148(%rsp),%rbx
   23549:	test   %rbx,%rbx
   2354c:	je     23ce3 <_RNvCseJ3uQ9fe193_12runtime_text4main+0xdd3>
   23552:	mov    0x140(%rsp),%r14
   2355a:	add    $0x8,%r14
   2355e:	mov    0x5ebf3(%rip),%r15        # 82158 <_DYNAMIC+0x230>
   23565:	jmp    2357d <_RNvCseJ3uQ9fe193_12runtime_text4main+0x66d>
   23567:	nopw   0x0(%rax,%rax,1)
   23570:	add    $0x18,%r14
   23574:	dec    %rbx
   23577:	je     23ce3 <_RNvCseJ3uQ9fe193_12runtime_text4main+0xdd3>
   2357d:	mov    -0x8(%r14),%rsi
   23581:	test   %rsi,%rsi
   23584:	je     23570 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x660>
   23586:	mov    (%r14),%rdi
   23589:	mov    $0x1,%edx
   2358e:	call   *%r15
   23591:	jmp    23570 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x660>
   23593:	movabs $0x735f676e69727473,%rax
   2359d:	xor    (%rcx),%rax
   235a0:	movabs $0x6863726165735f67,%rdx
   235aa:	xor    0x5(%rcx),%rdx
   235ae:	or     %rax,%rdx
   235b1:	je     23fdb <_RNvCseJ3uQ9fe193_12runtime_text4main+0x10cb>
   235b7:	movabs $0x726767615f767363,%rax
   235c1:	xor    (%rcx),%rax
   235c4:	movabs $0x6574616765726767,%rdx
   235ce:	xor    0x5(%rcx),%rdx
   235d2:	or     %rax,%rdx
   235d5:	jne    278fe <_RNvCseJ3uQ9fe193_12runtime_text4main+0x49ee>
   235db:	lea    -0x16216(%rip),%rax        # d3cc <anon.c41b9569d3e50f51ac9d11be340d2ec5.16.llvm.16118886657712379284+0x4>
   235e2:	mov    %rax,0x80(%rsp)
   235ea:	movq   $0x4,0x88(%rsp)
   235f6:	lea    -0x16279(%rip),%rax        # d384 <anon.ed156775cc2f3392bb82488487d1de8d.21.llvm.4912082265219229507+0x18>
   235fd:	mov    %rax,0x90(%rsp)
   23605:	movq   $0x4,0x98(%rsp)
   23611:	lea    -0x16228(%rip),%rax        # d3f0 <anon.c41b9569d3e50f51ac9d11be340d2ec5.16.llvm.16118886657712379284+0x28>
   23618:	mov    %rax,0xa0(%rsp)
   23620:	movq   $0x5,0xa8(%rsp)
   2362c:	movq   $0x0,0x1d0(%rsp)
   23638:	mov    %r15,0x1d8(%rsp)
   23640:	lea    0x1a0(%rsp),%rax
   23648:	mov    %rax,0x1c0(%rsp)
   23650:	mov    %rbp,0x1c8(%rsp)
   23658:	lea    0x30(%rsp),%rdi
   2365d:	lea    0x1c0(%rsp),%rsi
   23665:	call   2e010 <_RINvXs8_NtCs6i54tJFfzR_5alloc6stringNtB6_6StringINtNtNtNtCsgxBkk5gSRhY_4core4iter6traits7collect12FromIteratorBy_E9from_iterINtNtNtBR_8adapters3map3MapINtNtNtBT_3ops5range5RangejENCNvCseJ3uQ9fe193_12runtime_text6inputss4_0EEB2V_>
   2366a:	call   *0x5eb00(%rip)        # 82170 <_DYNAMIC+0x248>
   23670:	mov    $0x18,%edi
   23675:	mov    $0x8,%esi
   2367a:	call   *0x5eaf8(%rip)        # 82178 <_DYNAMIC+0x250>
   23680:	test   %rax,%rax
   23683:	je     2794f <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4a3f>
   23689:	mov    %rax,%r14
   2368c:	mov    0x40(%rsp),%rax
   23691:	mov    %rax,0x10(%r14)
   23695:	movdqu 0x30(%rsp),%xmm0
   2369b:	movdqu %xmm0,(%r14)
   236a0:	mov    0x148(%rsp),%rbx
   236a8:	test   %rbx,%rbx
   236ab:	je     23f17 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x1007>
   236b1:	mov    0x140(%rsp),%r15
   236b9:	add    $0x8,%r15
   236bd:	mov    0x5ea94(%rip),%r12        # 82158 <_DYNAMIC+0x230>
   236c4:	jmp    236dd <_RNvCseJ3uQ9fe193_12runtime_text4main+0x7cd>
   236c6:	cs nopw 0x0(%rax,%rax,1)
   236d0:	add    $0x18,%r15
   236d4:	dec    %rbx
   236d7:	je     23f17 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x1007>
   236dd:	mov    -0x8(%r15),%rsi
   236e1:	test   %rsi,%rsi
   236e4:	je     236d0 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x7c0>
   236e6:	mov    (%r15),%rdi
   236e9:	mov    $0x1,%edx
   236ee:	call   *%r12
   236f1:	jmp    236d0 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x7c0>
   236f3:	movabs $0x6a5f676e69727473,%rax
   236fd:	xor    (%rcx),%rax
   23700:	movabs $0x6e696f6a5f676e69,%rdx
   2370a:	xor    0x3(%rcx),%rdx
   2370e:	or     %rax,%rdx
   23711:	je     23758 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x848>
   23713:	jmp    278fe <_RNvCseJ3uQ9fe193_12runtime_text4main+0x49ee>
   23718:	movabs $0x655f676e69727473,%rax
   23722:	xor    (%rcx),%rax
   23725:	mov    0x8(%rcx),%edx
   23728:	xor    $0x6c617571,%rdx
   2372f:	or     %rax,%rdx
   23732:	je     24123 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x1213>
   23738:	movabs $0x735f676e69727473,%rax
   23742:	xor    (%rcx),%rax
   23745:	mov    0x8(%rcx),%ecx
   23748:	xor    $0x74696c70,%rcx
   2374f:	or     %rax,%rcx
   23752:	jne    278fe <_RNvCseJ3uQ9fe193_12runtime_text4main+0x49ee>
   23758:	movq   $0x1,0x80(%rsp)
   23764:	movq   $0x0,0x88(%rsp)
   23770:	lea    -0x1636a(%rip),%rax        # d40d <anon.c41b9569d3e50f51ac9d11be340d2ec5.16.llvm.16118886657712379284+0x45>
   23777:	mov    %rax,0x90(%rsp)
   2377f:	movq   $0x5,0x98(%rsp)
   2378b:	lea    -0x1639a(%rip),%rax        # d3f8 <anon.c41b9569d3e50f51ac9d11be340d2ec5.16.llvm.16118886657712379284+0x30>
   23792:	mov    %rax,0xa0(%rsp)
   2379a:	movq   $0x5,0xa8(%rsp)
   237a6:	lea    -0x1639b(%rip),%rax        # d412 <anon.c41b9569d3e50f51ac9d11be340d2ec5.16.llvm.16118886657712379284+0x4a>
   237ad:	mov    %rax,0xb0(%rsp)
   237b5:	movq   $0x1,0xb8(%rsp)
   237c1:	lea    -0x163c6(%rip),%rax        # d402 <anon.c41b9569d3e50f51ac9d11be340d2ec5.16.llvm.16118886657712379284+0x3a>
   237c8:	mov    %rax,0xc0(%rsp)
   237d0:	movq   $0x6,0xc8(%rsp)
   237dc:	movq   $0x0,0x1d0(%rsp)
   237e8:	mov    %r15,0x1d8(%rsp)
   237f0:	mov    %rbp,0x1c0(%rsp)
   237f8:	lea    0x1a0(%rsp),%rax
   23800:	mov    %rax,0x1c8(%rsp)
   23808:	lea    0x30(%rsp),%rdi
   2380d:	lea    0x1c0(%rsp),%rsi
   23815:	call   335d0 <_RNvXs_NtNtCs6i54tJFfzR_5alloc3vec21spec_from_iter_nestedINtB6_3VecNtNtB8_6string6StringEINtB4_18SpecFromIterNestedB12_INtNtNtNtCsgxBkk5gSRhY_4core4iter8adapters3map3MapINtNtNtB21_3ops5range5RangejENCNvCseJ3uQ9fe193_12runtime_text6inputss0_0EE9from_iterB3d_>
   2381a:	mov    0x190(%rsp),%rbx
   23822:	test   %rbx,%rbx
   23825:	je     2385f <_RNvCseJ3uQ9fe193_12runtime_text4main+0x94f>
   23827:	mov    0x188(%rsp),%r14
   2382f:	add    $0x8,%r14
   23833:	mov    0x5e91e(%rip),%r15        # 82158 <_DYNAMIC+0x230>
   2383a:	jmp    23849 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x939>
   2383c:	nopl   0x0(%rax)
   23840:	add    $0x18,%r14
   23844:	dec    %rbx
   23847:	je     2385f <_RNvCseJ3uQ9fe193_12runtime_text4main+0x94f>
   23849:	mov    -0x8(%r14),%rsi
   2384d:	test   %rsi,%rsi
   23850:	je     23840 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x930>
   23852:	mov    (%r14),%rdi
   23855:	mov    $0x1,%edx
   2385a:	call   *%r15
   2385d:	jmp    23840 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x930>
   2385f:	lea    0x180(%rsp),%rbx
   23867:	mov    0x180(%rsp),%rax
   2386f:	test   %rax,%rax
   23872:	je     2388f <_RNvCseJ3uQ9fe193_12runtime_text4main+0x97f>
   23874:	mov    0x188(%rsp),%rdi
   2387c:	shl    $0x3,%rax
   23880:	lea    (%rax,%rax,2),%rsi
   23884:	mov    $0x8,%edx
   23889:	call   *0x5e8c9(%rip)        # 82158 <_DYNAMIC+0x230>
   2388f:	mov    0x40(%rsp),%rax
   23894:	mov    %rax,0x10(%rbx)
   23898:	movdqu 0x30(%rsp),%xmm0
   2389e:	movdqu %xmm0,(%rbx)
   238a2:	call   *0x5e8c8(%rip)        # 82170 <_DYNAMIC+0x248>
   238a8:	mov    $0x30,%r14d
   238ae:	mov    $0x30,%edi
   238b3:	mov    $0x8,%esi
   238b8:	call   *0x5e8ba(%rip)        # 82178 <_DYNAMIC+0x250>
   238be:	test   %rax,%rax
   238c1:	je     278cd <_RNvCseJ3uQ9fe193_12runtime_text4main+0x49bd>
   238c7:	mov    %rax,%r12
   238ca:	mov    0x188(%rsp),%rsi
   238d2:	mov    0x190(%rsp),%rdx
   238da:	lea    -0x164ce(%rip),%rcx        # d413 <anon.c41b9569d3e50f51ac9d11be340d2ec5.16.llvm.16118886657712379284+0x4b>
   238e1:	lea    0x1c0(%rsp),%rdi
   238e9:	mov    $0x1,%r8d
   238ef:	call   29fa0 <_RINvNtCs6i54tJFfzR_5alloc3str17join_generic_copyehNtNtB4_6string6StringECseJ3uQ9fe193_12runtime_text>
   238f4:	mov    0x1c0(%rsp),%r14
   238fc:	mov    0x1c8(%rsp),%r15
   23904:	mov    0x1d0(%rsp),%rbx
   2390c:	mov    0x188(%rsp),%rsi
   23914:	mov    0x190(%rsp),%rdx
   2391c:	lea    -0x1650f(%rip),%rcx        # d414 <anon.c41b9569d3e50f51ac9d11be340d2ec5.16.llvm.16118886657712379284+0x4c>
   23923:	lea    0x1c0(%rsp),%rdi
   2392b:	mov    $0x2,%r8d
   23931:	call   29fa0 <_RINvNtCs6i54tJFfzR_5alloc3str17join_generic_copyehNtNtB4_6string6StringECseJ3uQ9fe193_12runtime_text>
   23936:	mov    0x1d0(%rsp),%rax
   2393e:	mov    %rax,0x28(%r12)
   23943:	movdqu 0x1c0(%rsp),%xmm0
   2394c:	movdqu %xmm0,0x18(%r12)
   23953:	mov    %r14,(%r12)
   23957:	mov    %r15,0x8(%r12)
   2395c:	mov    %rbx,0x10(%r12)
   23961:	mov    0x148(%rsp),%rbx
   23969:	test   %rbx,%rbx
   2396c:	je     239af <_RNvCseJ3uQ9fe193_12runtime_text4main+0xa9f>
   2396e:	mov    0x140(%rsp),%r14
   23976:	add    $0x8,%r14
   2397a:	mov    0x5e7d7(%rip),%r15        # 82158 <_DYNAMIC+0x230>
   23981:	jmp    23999 <_RNvCseJ3uQ9fe193_12runtime_text4main+0xa89>
   23983:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   23990:	add    $0x18,%r14
   23994:	dec    %rbx
   23997:	je     239af <_RNvCseJ3uQ9fe193_12runtime_text4main+0xa9f>
   23999:	mov    -0x8(%r14),%rsi
   2399d:	test   %rsi,%rsi
   239a0:	je     23990 <_RNvCseJ3uQ9fe193_12runtime_text4main+0xa80>
   239a2:	mov    (%r14),%rdi
   239a5:	mov    $0x1,%edx
   239aa:	call   *%r15
   239ad:	jmp    23990 <_RNvCseJ3uQ9fe193_12runtime_text4main+0xa80>
   239af:	mov    0x138(%rsp),%rax
   239b7:	test   %rax,%rax
   239ba:	je     239d7 <_RNvCseJ3uQ9fe193_12runtime_text4main+0xac7>
   239bc:	mov    0x140(%rsp),%rdi
   239c4:	shl    $0x3,%rax
   239c8:	lea    (%rax,%rax,2),%rsi
   239cc:	mov    $0x8,%edx
   239d1:	call   *0x5e781(%rip)        # 82158 <_DYNAMIC+0x230>
   239d7:	movq   $0x2,0x138(%rsp)
   239e3:	mov    %r12,0x140(%rsp)
   239eb:	movq   $0x2,0x148(%rsp)
   239f7:	jmp    243d8 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x14c8>
   239fc:	movabs $0x63735f7365747962,%rax
   23a06:	xor    (%rcx),%rax
   23a09:	movzwl 0x8(%rcx),%edx
   23a0d:	xor    $0x6e61,%rdx
   23a14:	or     %rax,%rdx
   23a17:	je     242d3 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x13c3>
   23a1d:	movabs $0x6d726f665f746e69,%rax
   23a27:	xor    (%rcx),%rax
   23a2a:	movzwl 0x8(%rcx),%edx
   23a2e:	xor    $0x7461,%rdx
   23a35:	or     %rax,%rdx
   23a38:	je     272fc <_RNvCseJ3uQ9fe193_12runtime_text4main+0x43ec>
   23a3e:	movabs $0x756f635f64726f77,%rax
   23a48:	xor    (%rcx),%rax
   23a4b:	movzwl 0x8(%rcx),%ecx
   23a4f:	xor    $0x746e,%rcx
   23a56:	or     %rax,%rcx
   23a59:	jne    278fe <_RNvCseJ3uQ9fe193_12runtime_text4main+0x49ee>
   23a5f:	lea    -0x16671(%rip),%rax        # d3f5 <anon.c41b9569d3e50f51ac9d11be340d2ec5.16.llvm.16118886657712379284+0x2d>
   23a66:	mov    %rax,0x80(%rsp)
   23a6e:	movq   $0x3,0x88(%rsp)
   23a7a:	lea    -0x166a9(%rip),%rcx        # d3d8 <anon.c41b9569d3e50f51ac9d11be340d2ec5.16.llvm.16118886657712379284+0x10>
   23a81:	mov    %rcx,0x90(%rsp)
   23a89:	movq   $0x4,0x98(%rsp)
   23a95:	lea    -0x166a4(%rip),%rdx        # d3f8 <anon.c41b9569d3e50f51ac9d11be340d2ec5.16.llvm.16118886657712379284+0x30>
   23a9c:	mov    %rdx,0xa0(%rsp)
   23aa4:	movq   $0x5,0xa8(%rsp)
   23ab0:	mov    %rax,0xb0(%rsp)
   23ab8:	movq   $0x3,0xb8(%rsp)
   23ac4:	lea    -0x166ce(%rip),%rdx        # d3fd <anon.c41b9569d3e50f51ac9d11be340d2ec5.16.llvm.16118886657712379284+0x35>
   23acb:	mov    %rdx,0xc0(%rsp)
   23ad3:	movq   $0x5,0xc8(%rsp)
   23adf:	mov    %rcx,0xd0(%rsp)
   23ae7:	movq   $0x4,0xd8(%rsp)
   23af3:	lea    -0x166f8(%rip),%rcx        # d402 <anon.c41b9569d3e50f51ac9d11be340d2ec5.16.llvm.16118886657712379284+0x3a>
   23afa:	mov    %rcx,0xe0(%rsp)
   23b02:	movq   $0x6,0xe8(%rsp)
   23b0e:	mov    %rax,0xf0(%rsp)
   23b16:	movq   $0x3,0xf8(%rsp)
   23b22:	lea    -0x16721(%rip),%rax        # d408 <anon.c41b9569d3e50f51ac9d11be340d2ec5.16.llvm.16118886657712379284+0x40>
   23b29:	mov    %rax,0x1c0(%rsp)
   23b31:	movq   $0x1,0x1c8(%rsp)
   23b3d:	lea    -0x1673b(%rip),%rax        # d409 <anon.c41b9569d3e50f51ac9d11be340d2ec5.16.llvm.16118886657712379284+0x41>
   23b44:	mov    %rax,0x1d0(%rsp)
   23b4c:	movq   $0x1,0x1d8(%rsp)
   23b58:	lea    -0x16755(%rip),%rax        # d40a <anon.c41b9569d3e50f51ac9d11be340d2ec5.16.llvm.16118886657712379284+0x42>
   23b5f:	mov    %rax,0x1e0(%rsp)
   23b67:	movq   $0x1,0x1e8(%rsp)
   23b73:	lea    -0x1676f(%rip),%rax        # d40b <anon.c41b9569d3e50f51ac9d11be340d2ec5.16.llvm.16118886657712379284+0x43>
   23b7a:	mov    %rax,0x1f0(%rsp)
   23b82:	movq   $0x2,0x1f8(%rsp)
   23b8e:	movq   $0x0,0x48(%rsp)
   23b97:	mov    %r15,0x50(%rsp)
   23b9c:	mov    %rbp,0x30(%rsp)
   23ba1:	lea    0x1a0(%rsp),%rax
   23ba9:	mov    %rax,0x38(%rsp)
   23bae:	lea    0x1c0(%rsp),%rax
   23bb6:	mov    %rax,0x40(%rsp)
   23bbb:	lea    0x108(%rsp),%rdi
   23bc3:	lea    0x30(%rsp),%rsi
   23bc8:	call   2def0 <_RINvXs8_NtCs6i54tJFfzR_5alloc6stringNtB6_6StringINtNtNtNtCsgxBkk5gSRhY_4core4iter6traits7collect12FromIteratorBy_E9from_iterINtNtNtBR_8adapters3map3MapINtNtNtBT_3ops5range5RangejENCNvCseJ3uQ9fe193_12runtime_text6inputss3_0EEB2V_>
   23bcd:	call   *0x5e59d(%rip)        # 82170 <_DYNAMIC+0x248>
   23bd3:	mov    $0x30,%edi
   23bd8:	mov    $0x8,%esi
   23bdd:	call   *0x5e595(%rip)        # 82178 <_DYNAMIC+0x250>
   23be3:	test   %rax,%rax
   23be6:	je     27964 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4a54>
   23bec:	mov    %rax,%r15
   23bef:	lea    0x30(%rsp),%rdi
   23bf4:	lea    0x108(%rsp),%rsi
   23bfc:	call   *0x5e57e(%rip)        # 82180 <_DYNAMIC+0x258>
   23c02:	mov    0x30(%rsp),%r13
   23c07:	mov    0x40(%rsp),%r14
   23c0c:	mov    %r13,%rax
   23c0f:	sub    %r14,%rax
   23c12:	cmp    $0x2,%rax
   23c16:	jbe    27979 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4a69>
   23c1c:	mov    0x38(%rsp),%r12
   23c21:	movb   $0x64,0x2(%r12,%r14,1)
   23c27:	movw   $0x6572,(%r12,%r14,1)
   23c2e:	movdqu 0x108(%rsp),%xmm0
   23c37:	movdqa %xmm0,0x30(%rsp)
   23c3d:	mov    0x118(%rsp),%rsi
   23c45:	mov    %rsi,0x40(%rsp)
   23c4a:	mov    0x30(%rsp),%rax
   23c4f:	sub    %rsi,%rax
   23c52:	cmp    $0x3,%rax
   23c56:	jbe    279a5 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4a95>
   23c5c:	add    $0x3,%r14
   23c60:	mov    0x38(%rsp),%rax
   23c65:	movl   $0x65756c62,(%rax,%rsi,1)
   23c6c:	add    $0x4,%rsi
   23c70:	mov    %rsi,0x40(%rsp)
   23c75:	mov    %rsi,0x28(%r15)
   23c79:	movdqa 0x30(%rsp),%xmm0
   23c7f:	movdqu %xmm0,0x18(%r15)
   23c85:	mov    %r13,(%r15)
   23c88:	mov    %r12,0x8(%r15)
   23c8c:	mov    %r14,0x10(%r15)
   23c90:	mov    0x148(%rsp),%rbx
   23c98:	test   %rbx,%rbx
   23c9b:	je     23f8e <_RNvCseJ3uQ9fe193_12runtime_text4main+0x107e>
   23ca1:	mov    0x140(%rsp),%r14
   23ca9:	add    $0x8,%r14
   23cad:	mov    0x5e4a4(%rip),%r12        # 82158 <_DYNAMIC+0x230>
   23cb4:	jmp    23ccd <_RNvCseJ3uQ9fe193_12runtime_text4main+0xdbd>
   23cb6:	cs nopw 0x0(%rax,%rax,1)
   23cc0:	add    $0x18,%r14
   23cc4:	dec    %rbx
   23cc7:	je     23f8e <_RNvCseJ3uQ9fe193_12runtime_text4main+0x107e>
   23ccd:	mov    -0x8(%r14),%rsi
   23cd1:	test   %rsi,%rsi
   23cd4:	je     23cc0 <_RNvCseJ3uQ9fe193_12runtime_text4main+0xdb0>
   23cd6:	mov    (%r14),%rdi
   23cd9:	mov    $0x1,%edx
   23cde:	call   *%r12
   23ce1:	jmp    23cc0 <_RNvCseJ3uQ9fe193_12runtime_text4main+0xdb0>
   23ce3:	lea    0x138(%rsp),%rbx
   23ceb:	mov    0x138(%rsp),%rax
   23cf3:	test   %rax,%rax
   23cf6:	je     23d13 <_RNvCseJ3uQ9fe193_12runtime_text4main+0xe03>
   23cf8:	mov    0x140(%rsp),%rdi
   23d00:	shl    $0x3,%rax
   23d04:	lea    (%rax,%rax,2),%rsi
   23d08:	mov    $0x8,%edx
   23d0d:	call   *0x5e445(%rip)        # 82158 <_DYNAMIC+0x230>
   23d13:	mov    0x1d0(%rsp),%rax
   23d1b:	mov    %rax,0x10(%rbx)
   23d1f:	movdqu 0x1c0(%rsp),%xmm0
   23d28:	jmp    243d4 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x14c4>
   23d2d:	movabs $0x6172745f6e6f736a,%rax
   23d37:	xor    (%rcx),%rax
   23d3a:	movabs $0x6d726f665f746e69,%rdx
   23d44:	add    $0x13f9f309,%rdx
   23d4b:	xor    0x6(%rcx),%rdx
   23d4f:	or     %rax,%rdx
   23d52:	jne    278fe <_RNvCseJ3uQ9fe193_12runtime_text4main+0x49ee>
   23d58:	movq   $0x0,0x88(%rsp)
   23d64:	mov    %r15,0x90(%rsp)
   23d6c:	lea    0x1a0(%rsp),%rax
   23d74:	mov    %rax,0x80(%rsp)
   23d7c:	lea    0x1c0(%rsp),%rdi
   23d84:	lea    0x80(%rsp),%r14
   23d8c:	mov    %r14,%rsi
   23d8f:	call   33950 <_RNvXs_NtNtCs6i54tJFfzR_5alloc3vec21spec_from_iter_nestedINtB6_3VecNtNtCs1ZxogWZ17zb_10serde_json5value5ValueEINtB4_18SpecFromIterNestedB12_INtNtNtNtCsgxBkk5gSRhY_4core4iter8adapters3map3MapINtNtNtB2m_3ops5range5RangejENCNvCseJ3uQ9fe193_12runtime_text6inputss5_0EE9from_iterB3y_>
   23d94:	call   *0x5e3d6(%rip)        # 82170 <_DYNAMIC+0x248>
   23d9a:	mov    $0x18,%edi
   23d9f:	mov    $0x8,%esi
   23da4:	call   *0x5e3ce(%rip)        # 82178 <_DYNAMIC+0x250>
   23daa:	test   %rax,%rax
   23dad:	je     2793a <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4a2a>
   23db3:	mov    %rax,%r15
   23db6:	call   *0x5e3b4(%rip)        # 82170 <_DYNAMIC+0x248>
   23dbc:	mov    $0x80,%edi
   23dc1:	mov    $0x1,%esi
   23dc6:	call   *0x5e3ac(%rip)        # 82178 <_DYNAMIC+0x250>
   23dcc:	test   %rax,%rax
   23dcf:	je     27b8a <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4c7a>
   23dd5:	movq   $0x80,0x80(%rsp)
   23de1:	mov    %rax,0x88(%rsp)
   23de9:	movq   $0x0,0x90(%rsp)
   23df5:	mov    %r14,0x30(%rsp)
   23dfa:	lea    0x30(%rsp),%rdi
   23dff:	lea    0x1c0(%rsp),%rsi
   23e07:	call   29550 <_RINvYQINtNtCs1ZxogWZ17zb_10serde_json3ser10SerializerQINtNtCs6i54tJFfzR_5alloc3vec3VechEENtNtCsd8e2XcjHJpb_10serde_core3ser10Serializer11collect_seqRIBR_NtNtB9_5value5ValueEECseJ3uQ9fe193_12runtime_text>
   23e0c:	test   %rax,%rax
   23e0f:	jne    27b9f <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4c8f>
   23e15:	mov    0x80(%rsp),%rax
   23e1d:	mov    0x88(%rsp),%rbx
   23e25:	cmp    $0xffffffffffffffff,%rax
   23e29:	je     27bc2 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4cb2>
   23e2f:	mov    0x90(%rsp),%rcx
   23e37:	mov    %rax,(%r15)
   23e3a:	mov    %rbx,0x8(%r15)
   23e3e:	mov    %rcx,0x10(%r15)
   23e42:	mov    0x148(%rsp),%rbx
   23e4a:	test   %rbx,%rbx
   23e4d:	je     23e8f <_RNvCseJ3uQ9fe193_12runtime_text4main+0xf7f>
   23e4f:	mov    0x140(%rsp),%r14
   23e57:	add    $0x8,%r14
   23e5b:	mov    0x5e2f6(%rip),%r12        # 82158 <_DYNAMIC+0x230>
   23e62:	jmp    23e79 <_RNvCseJ3uQ9fe193_12runtime_text4main+0xf69>
   23e64:	data16 data16 cs nopw 0x0(%rax,%rax,1)
   23e70:	add    $0x18,%r14
   23e74:	dec    %rbx
   23e77:	je     23e8f <_RNvCseJ3uQ9fe193_12runtime_text4main+0xf7f>
   23e79:	mov    -0x8(%r14),%rsi
   23e7d:	test   %rsi,%rsi
   23e80:	je     23e70 <_RNvCseJ3uQ9fe193_12runtime_text4main+0xf60>
   23e82:	mov    (%r14),%rdi
   23e85:	mov    $0x1,%edx
   23e8a:	call   *%r12
   23e8d:	jmp    23e70 <_RNvCseJ3uQ9fe193_12runtime_text4main+0xf60>
   23e8f:	mov    0x138(%rsp),%rax
   23e97:	test   %rax,%rax
   23e9a:	je     23eb7 <_RNvCseJ3uQ9fe193_12runtime_text4main+0xfa7>
   23e9c:	mov    0x140(%rsp),%rdi
   23ea4:	shl    $0x3,%rax
   23ea8:	lea    (%rax,%rax,2),%rsi
   23eac:	mov    $0x8,%edx
   23eb1:	call   *0x5e2a1(%rip)        # 82158 <_DYNAMIC+0x230>
   23eb7:	movq   $0x1,0x138(%rsp)
   23ec3:	mov    %r15,0x140(%rsp)
   23ecb:	movq   $0x1,0x148(%rsp)
   23ed7:	mov    0x1c8(%rsp),%r14
   23edf:	mov    0x1d0(%rsp),%rsi
   23ee7:	mov    %r14,%rdi
   23eea:	call   32ad0 <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueSNtNtCs1ZxogWZ17zb_10serde_json5value5ValueECseJ3uQ9fe193_12runtime_text.llvm.889774890497533298>
   23eef:	mov    0x1c0(%rsp),%rsi
   23ef7:	test   %rsi,%rsi
   23efa:	je     243d8 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x14c8>
   23f00:	shl    $0x5,%rsi
   23f04:	mov    $0x8,%edx
   23f09:	mov    %r14,%rdi
   23f0c:	call   *0x5e246(%rip)        # 82158 <_DYNAMIC+0x230>
   23f12:	jmp    243d8 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x14c8>
   23f17:	mov    0x138(%rsp),%rax
   23f1f:	test   %rax,%rax
   23f22:	je     23f3f <_RNvCseJ3uQ9fe193_12runtime_text4main+0x102f>
   23f24:	mov    0x140(%rsp),%rdi
   23f2c:	shl    $0x3,%rax
   23f30:	lea    (%rax,%rax,2),%rsi
   23f34:	mov    $0x8,%edx
   23f39:	call   *0x5e219(%rip)        # 82158 <_DYNAMIC+0x230>
   23f3f:	movq   $0x1,0x138(%rsp)
   23f4b:	mov    %r14,0x140(%rsp)
   23f53:	movq   $0x1,0x148(%rsp)
   23f5f:	jmp    243d8 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x14c8>
   23f64:	xor    %r15d,%r15d
   23f67:	mov    0x40(%rdi),%r8
   23f6b:	test   %r8,%r8
   23f6e:	jne    231d4 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x2c4>
   23f74:	jmp    2311c <_RNvCseJ3uQ9fe193_12runtime_text4main+0x20c>
   23f79:	xor    %r15d,%r15d
   23f7c:	mov    0x40(%rdi),%r8
   23f80:	test   %r8,%r8
   23f83:	jne    231d4 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x2c4>
   23f89:	jmp    2311c <_RNvCseJ3uQ9fe193_12runtime_text4main+0x20c>
   23f8e:	mov    0x138(%rsp),%rax
   23f96:	test   %rax,%rax
   23f99:	je     23fb6 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x10a6>
   23f9b:	mov    0x140(%rsp),%rdi
   23fa3:	shl    $0x3,%rax
   23fa7:	lea    (%rax,%rax,2),%rsi
   23fab:	mov    $0x8,%edx
   23fb0:	call   *0x5e1a2(%rip)        # 82158 <_DYNAMIC+0x230>
   23fb6:	movq   $0x2,0x138(%rsp)
   23fc2:	mov    %r15,0x140(%rsp)
   23fca:	movq   $0x2,0x148(%rsp)
   23fd6:	jmp    243d8 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x14c8>
   23fdb:	call   *0x5e18f(%rip)        # 82170 <_DYNAMIC+0x248>
   23fe1:	mov    $0x18,%r14d
   23fe7:	mov    $0x18,%edi
   23fec:	mov    $0x8,%esi
   23ff1:	call   *0x5e181(%rip)        # 82178 <_DYNAMIC+0x250>
   23ff7:	test   %rax,%rax
   23ffa:	je     278cd <_RNvCseJ3uQ9fe193_12runtime_text4main+0x49bd>
   24000:	mov    %rax,%r12
   24003:	lea    -0x16bf4(%rip),%rsi        # d416 <anon.c41b9569d3e50f51ac9d11be340d2ec5.16.llvm.16118886657712379284+0x4e>
   2400a:	lea    0x80(%rsp),%rdi
   24012:	mov    $0x1,%edx
   24017:	mov    %r15,%rcx
   2401a:	call   29660 <_RNvMNtCs6i54tJFfzR_5alloc5sliceSh6repeatCseJ3uQ9fe193_12runtime_text>
   2401f:	mov    0x90(%rsp),%rax
   24027:	mov    %rax,0x1d0(%rsp)
   2402f:	movdqu 0x80(%rsp),%xmm0
   24038:	movdqa %xmm0,0x1c0(%rsp)
   24041:	lea    0x1c0(%rsp),%rax
   24049:	mov    %rax,0x80(%rsp)
   24051:	lea    0x4328(%rip),%rax        # 28380 <_RNvXsq_NtCs6i54tJFfzR_5alloc6stringNtB5_6StringNtNtCsgxBkk5gSRhY_4core3fmt7Display3fmt>
   24058:	mov    %rax,0x88(%rsp)
   24060:	lea    0x1a0(%rsp),%rax
   24068:	mov    %rax,0x90(%rsp)
   24070:	mov    0x5e111(%rip),%rax        # 82188 <_DYNAMIC+0x260>
   24077:	mov    %rax,0x98(%rsp)
   2407f:	lea    -0x17175(%rip),%rsi        # cf11 <anon.ce8fe1c85ef8c3c1f3e808abdc2069a9.13.llvm.734355871812708367+0x463>
   24086:	lea    0x30(%rsp),%rdi
   2408b:	lea    0x80(%rsp),%rdx
   24093:	call   *0x5e0f7(%rip)        # 82190 <_DYNAMIC+0x268>
   24099:	mov    0x1c0(%rsp),%rsi
   240a1:	test   %rsi,%rsi
   240a4:	je     240b9 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x11a9>
   240a6:	mov    0x1c8(%rsp),%rdi
   240ae:	mov    $0x1,%edx
   240b3:	call   *0x5e09f(%rip)        # 82158 <_DYNAMIC+0x230>
   240b9:	mov    0x40(%rsp),%rax
   240be:	mov    %rax,0x10(%r12)
   240c3:	movdqu 0x30(%rsp),%xmm0
   240c9:	movdqu %xmm0,(%r12)
   240cf:	mov    0x148(%rsp),%rbx
   240d7:	test   %rbx,%rbx
   240da:	je     242e7 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x13d7>
   240e0:	mov    0x140(%rsp),%r14
   240e8:	add    $0x8,%r14
   240ec:	mov    0x5e065(%rip),%r15        # 82158 <_DYNAMIC+0x230>
   240f3:	jmp    2410d <_RNvCseJ3uQ9fe193_12runtime_text4main+0x11fd>
   240f5:	data16 cs nopw 0x0(%rax,%rax,1)
   24100:	add    $0x18,%r14
   24104:	dec    %rbx
   24107:	je     242e7 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x13d7>
   2410d:	mov    -0x8(%r14),%rsi
   24111:	test   %rsi,%rsi
   24114:	je     24100 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x11f0>
   24116:	mov    (%r14),%rdi
   24119:	mov    $0x1,%edx
   2411e:	call   *%r15
   24121:	jmp    24100 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x11f0>
   24123:	call   *0x5e047(%rip)        # 82170 <_DYNAMIC+0x248>
   24129:	mov    $0x60,%r14d
   2412f:	mov    $0x60,%edi
   24134:	mov    $0x8,%esi
   24139:	call   *0x5e039(%rip)        # 82178 <_DYNAMIC+0x250>
   2413f:	test   %rax,%rax
   24142:	je     278cd <_RNvCseJ3uQ9fe193_12runtime_text4main+0x49bd>
   24148:	mov    %rax,%rbp
   2414b:	lea    -0x16d3c(%rip),%rsi        # d416 <anon.c41b9569d3e50f51ac9d11be340d2ec5.16.llvm.16118886657712379284+0x4e>
   24152:	lea    0x80(%rsp),%rdi
   2415a:	mov    $0x1,%edx
   2415f:	mov    %r15,%rcx
   24162:	call   29660 <_RNvMNtCs6i54tJFfzR_5alloc5sliceSh6repeatCseJ3uQ9fe193_12runtime_text>
   24167:	mov    0x80(%rsp),%rax
   2416f:	mov    %rax,(%rsp)
   24173:	mov    0x88(%rsp),%rbx
   2417b:	mov    0x90(%rsp),%r14
   24183:	lea    -0x16d0a(%rip),%rsi        # d480 <anon.c41b9569d3e50f51ac9d11be340d2ec5.16.llvm.16118886657712379284+0xb8>
   2418a:	lea    0x80(%rsp),%rdi
   24192:	mov    $0x2,%edx
   24197:	mov    %r15,%rcx
   2419a:	mov    %rbx,0x20(%rsp)
   2419f:	call   29660 <_RNvMNtCs6i54tJFfzR_5alloc5sliceSh6repeatCseJ3uQ9fe193_12runtime_text>
   241a4:	mov    0x80(%rsp),%rax
   241ac:	mov    %rax,0x8(%rsp)
   241b1:	mov    0x88(%rsp),%rax
   241b9:	mov    %rax,0x78(%rsp)
   241be:	mov    0x90(%rsp),%rax
   241c6:	mov    %rax,0x60(%rsp)
   241cb:	lea    -0x16dbc(%rip),%rsi        # d416 <anon.c41b9569d3e50f51ac9d11be340d2ec5.16.llvm.16118886657712379284+0x4e>
   241d2:	lea    0x80(%rsp),%rdi
   241da:	mov    $0x1,%edx
   241df:	mov    %r15,%rcx
   241e2:	call   29660 <_RNvMNtCs6i54tJFfzR_5alloc5sliceSh6repeatCseJ3uQ9fe193_12runtime_text>
   241e7:	mov    0x80(%rsp),%r12
   241ef:	mov    0x88(%rsp),%r13
   241f7:	mov    0x90(%rsp),%rbx
   241ff:	lea    0x1a0(%rsp),%rax
   24207:	mov    %rax,0x80(%rsp)
   2420f:	mov    0x5df72(%rip),%rax        # 82188 <_DYNAMIC+0x260>
   24216:	mov    %rax,0x88(%rsp)
   2421e:	lea    -0x186a1(%rip),%rsi        # bb84 <anon.2c3024bf600baf6499788d207c16e381.4.llvm.166979056262668204+0x1bd>
   24225:	lea    0x30(%rsp),%rdi
   2422a:	lea    0x80(%rsp),%rdx
   24232:	call   *0x5df58(%rip)        # 82190 <_DYNAMIC+0x268>
   24238:	mov    (%rsp),%rax
   2423c:	mov    %rax,0x0(%rbp)
   24240:	mov    0x20(%rsp),%rax
   24245:	mov    %rax,0x8(%rbp)
   24249:	mov    %r14,0x10(%rbp)
   2424d:	mov    0x8(%rsp),%rax
   24252:	mov    %rax,0x18(%rbp)
   24256:	mov    0x78(%rsp),%rax
   2425b:	mov    %rax,0x20(%rbp)
   2425f:	mov    0x60(%rsp),%rax
   24264:	mov    %rax,0x28(%rbp)
   24268:	mov    %r12,0x30(%rbp)
   2426c:	mov    %r13,0x38(%rbp)
   24270:	mov    %rbx,0x40(%rbp)
   24274:	mov    0x40(%rsp),%rax
   24279:	mov    %rax,0x58(%rbp)
   2427d:	movdqu 0x30(%rsp),%xmm0
   24283:	movdqu %xmm0,0x48(%rbp)
   24288:	mov    0x148(%rsp),%rbx
   24290:	test   %rbx,%rbx
   24293:	je     26885 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x3975>
   24299:	mov    0x140(%rsp),%r14
   242a1:	add    $0x8,%r14
   242a5:	mov    0x5deac(%rip),%r12        # 82158 <_DYNAMIC+0x230>
   242ac:	jmp    242bd <_RNvCseJ3uQ9fe193_12runtime_text4main+0x13ad>
   242ae:	xchg   %ax,%ax
   242b0:	add    $0x18,%r14
   242b4:	dec    %rbx
   242b7:	je     26885 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x3975>
   242bd:	mov    -0x8(%r14),%rsi
   242c1:	test   %rsi,%rsi
   242c4:	je     242b0 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x13a0>
   242c6:	mov    (%r14),%rdi
   242c9:	mov    $0x1,%edx
   242ce:	call   *%r12
   242d1:	jmp    242b0 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x13a0>
   242d3:	test   %r15,%r15
   242d6:	jns    27611 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4701>
   242dc:	xor    %r12d,%r12d
   242df:	mov    %r15,%r13
   242e2:	jmp    2732d <_RNvCseJ3uQ9fe193_12runtime_text4main+0x441d>
   242e7:	mov    0x138(%rsp),%rax
   242ef:	test   %rax,%rax
   242f2:	je     2430f <_RNvCseJ3uQ9fe193_12runtime_text4main+0x13ff>
   242f4:	mov    0x140(%rsp),%rdi
   242fc:	shl    $0x3,%rax
   24300:	lea    (%rax,%rax,2),%rsi
   24304:	mov    $0x8,%edx
   24309:	call   *0x5de49(%rip)        # 82158 <_DYNAMIC+0x230>
   2430f:	movq   $0x1,0x138(%rsp)
   2431b:	mov    %r12,0x140(%rsp)
   24323:	movq   $0x1,0x148(%rsp)
   2432f:	lea    0x5af2a(%rip),%rsi        # 7f260 <__frame_dummy_init_array_entry+0x80>
   24336:	lea    0x5af63(%rip),%rdx        # 7f2a0 <__frame_dummy_init_array_entry+0xc0>
   2433d:	lea    0x80(%rsp),%rdi
   24345:	call   337b0 <_RNvXs_NtNtCs6i54tJFfzR_5alloc3vec21spec_from_iter_nestedINtB6_3VecNtNtB8_6string6StringEINtB4_18SpecFromIterNestedB12_INtNtNtNtCsgxBkk5gSRhY_4core4iter8adapters3map3MapINtNtNtB21_5slice4iter4IterReENCNvCseJ3uQ9fe193_12runtime_text6inputss_0EE9from_iterB3e_>
   2434a:	mov    0x160(%rsp),%rbx
   24352:	test   %rbx,%rbx
   24355:	je     2438f <_RNvCseJ3uQ9fe193_12runtime_text4main+0x147f>
   24357:	mov    0x158(%rsp),%r14
   2435f:	add    $0x8,%r14
   24363:	mov    0x5ddee(%rip),%r15        # 82158 <_DYNAMIC+0x230>
   2436a:	jmp    24379 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x1469>
   2436c:	nopl   0x0(%rax)
   24370:	add    $0x18,%r14
   24374:	dec    %rbx
   24377:	je     2438f <_RNvCseJ3uQ9fe193_12runtime_text4main+0x147f>
   24379:	mov    -0x8(%r14),%rsi
   2437d:	test   %rsi,%rsi
   24380:	je     24370 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x1460>
   24382:	mov    (%r14),%rdi
   24385:	mov    $0x1,%edx
   2438a:	call   *%r15
   2438d:	jmp    24370 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x1460>
   2438f:	lea    0x150(%rsp),%rbx
   24397:	mov    0x150(%rsp),%rax
   2439f:	test   %rax,%rax
   243a2:	je     243bf <_RNvCseJ3uQ9fe193_12runtime_text4main+0x14af>
   243a4:	mov    0x158(%rsp),%rdi
   243ac:	shl    $0x3,%rax
   243b0:	lea    (%rax,%rax,2),%rsi
   243b4:	mov    $0x8,%edx
   243b9:	call   *0x5dd99(%rip)        # 82158 <_DYNAMIC+0x230>
   243bf:	mov    0x90(%rsp),%rax
   243c7:	mov    %rax,0x10(%rbx)
   243cb:	movdqu 0x80(%rsp),%xmm0
   243d4:	movdqu %xmm0,(%rbx)
   243d8:	mov    0x190(%rsp),%rax
   243e0:	mov    %rax,0x230(%rsp)
   243e8:	movups 0x180(%rsp),%xmm0
   243f0:	movaps %xmm0,0x220(%rsp)
   243f8:	mov    0x170(%rsp),%rax
   24400:	mov    %rax,0x210(%rsp)
   24408:	mov    0x178(%rsp),%rax
   24410:	mov    %rax,0x218(%rsp)
   24418:	mov    0x160(%rsp),%rax
   24420:	mov    %rax,0x200(%rsp)
   24428:	mov    0x168(%rsp),%rax
   24430:	mov    %rax,0x208(%rsp)
   24438:	mov    0x120(%rsp),%rax
   24440:	mov    0x128(%rsp),%rcx
   24448:	movdqu 0x130(%rsp),%xmm0
   24451:	movdqu 0x140(%rsp),%xmm1
   2445a:	movdqu 0x150(%rsp),%xmm2
   24463:	movdqa %xmm2,0x1f0(%rsp)
   2446c:	movdqa %xmm1,0x1e0(%rsp)
   24475:	movdqa %xmm0,0x1d0(%rsp)
   2447e:	mov    %rax,0x1c0(%rsp)
   24486:	mov    %rcx,0x1c8(%rsp)
   2448e:	call   *0x5dd04(%rip)        # 82198 <_DYNAMIC+0x270>
   24494:	mov    %rax,0x2a0(%rsp)
   2449c:	mov    %edx,0x2a8(%rsp)
   244a3:	cmpq   $0x0,0x250(%rsp)
   244ac:	je     27b06 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4bf6>
   244b2:	mov    0x248(%rsp),%rax
   244ba:	mov    0x10(%rax),%rcx
   244be:	add    $0xfffffffffffffff7,%rcx
   244c2:	cmp    $0x5,%rcx
   244c6:	ja     2791c <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4a0c>
   244cc:	mov    0x8(%rax),%rax
   244d0:	lea    -0x18e67(%rip),%rdx        # b670 <anon.db448e2af9fdd3f56f054211eea53148.7.llvm.3520701504562932850+0x330>
   244d7:	movslq (%rdx,%rcx,4),%rcx
   244db:	add    %rdx,%rcx
   244de:	jmp    *%rcx
   244e0:	movabs $0x737261705f746e69,%rcx
   244ea:	xor    (%rax),%rcx
   244ed:	movzbl 0x8(%rax),%eax
   244f1:	xor    $0x65,%rax
   244f5:	or     %rcx,%rax
   244f8:	jne    2791c <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4a0c>
   244fe:	mov    0x1e8(%rsp),%rsi
   24506:	test   %rsi,%rsi
   24509:	je     27bf4 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4ce4>
   2450f:	mov    0x1e0(%rsp),%rdi
   24517:	movq   $0x0,(%rsp)
   2451f:	movabs $0x89705f3112a28fe5,%r8
   24529:	xor    %r9d,%r9d
   2452c:	jmp    24579 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x1669>
   2452e:	xchg   %ax,%ax
   24530:	mov    $0x61,%ecx
   24535:	add    %rbx,%rcx
   24538:	inc    %r9
   2453b:	mov    %rcx,%rax
   2453e:	imul   %r8
   24541:	add    %rcx,%rdx
   24544:	mov    %rdx,%rax
   24547:	shr    $0x3f,%rax
   2454b:	sar    $0x1d,%rdx
   2454f:	add    %rax,%rdx
   24552:	imul   $0x3b9aca07,%rdx,%rax
   24559:	sub    %rax,%rcx
   2455c:	lea    0x3b9aca07(%rcx),%rax
   24563:	test   %rcx,%rcx
   24566:	cmovns %rcx,%rax
   2456a:	mov    %rax,(%rsp)
   2456e:	cmp    0x18(%rsp),%r9
   24573:	je     259bd <_RNvCseJ3uQ9fe193_12runtime_text4main+0x2aad>
   24579:	mov    0x10(%rsp),%rax
   2457e:	add    %r9,%rax
   24581:	mov    %rax,%rcx
   24584:	or     %rsi,%rcx
   24587:	shr    $0x20,%rcx
   2458b:	je     245a0 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x1690>
   2458d:	xor    %edx,%edx
   2458f:	div    %rsi
   24592:	jmp    245a4 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x1694>
   24594:	data16 data16 cs nopw 0x0(%rax,%rax,1)
   245a0:	xor    %edx,%edx
   245a2:	div    %esi
   245a4:	mov    (%rsp),%rbx
   245a8:	lea    (%rdx,%rdx,2),%rcx
   245ac:	mov    0x10(%rdi,%rcx,8),%rax
   245b1:	test   %rax,%rax
   245b4:	je     24530 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x1620>
   245ba:	mov    0x8(%rdi,%rcx,8),%rdx
   245bf:	cmp    $0x1,%rax
   245c3:	jne    24640 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x1730>
   245c5:	movzbl (%rdx),%ecx
   245c8:	cmp    $0x2b,%ecx
   245cb:	je     24530 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x1620>
   245d1:	cmp    $0x2d,%ecx
   245d4:	je     24530 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x1620>
   245da:	cmp    $0x2d,%cl
   245dd:	je     24648 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x1738>
   245df:	movzbl %cl,%ecx
   245e2:	cmp    $0x2b,%ecx
   245e5:	jne    245ed <_RNvCseJ3uQ9fe193_12runtime_text4main+0x16dd>
   245e7:	inc    %rdx
   245ea:	dec    %rax
   245ed:	cmp    $0x10,%rax
   245f1:	jae    2469d <_RNvCseJ3uQ9fe193_12runtime_text4main+0x178d>
   245f7:	test   %rax,%rax
   245fa:	je     246e6 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x17d6>
   24600:	xor    %r10d,%r10d
   24603:	xor    %ecx,%ecx
   24605:	data16 cs nopw 0x0(%rax,%rax,1)
   24610:	movzbl (%rdx,%r10,1),%r11d
   24615:	add    $0xffffffd0,%r11d
   24619:	cmp    $0x9,%r11d
   2461d:	ja     24530 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x1620>
   24623:	lea    (%rcx,%rcx,4),%rcx
   24627:	mov    %r11d,%r11d
   2462a:	lea    (%r11,%rcx,2),%rcx
   2462e:	inc    %r10
   24631:	cmp    %r10,%rax
   24634:	jne    24610 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x1700>
   24636:	jmp    24535 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x1625>
   2463b:	nopl   0x0(%rax,%rax,1)
   24640:	movzbl (%rdx),%ecx
   24643:	cmp    $0x2d,%cl
   24646:	jne    245df <_RNvCseJ3uQ9fe193_12runtime_text4main+0x16cf>
   24648:	cmp    $0x11,%rax
   2464c:	jae    246ed <_RNvCseJ3uQ9fe193_12runtime_text4main+0x17dd>
   24652:	mov    %rax,%rcx
   24655:	dec    %rcx
   24658:	je     246e6 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x17d6>
   2465e:	mov    $0x1,%r10d
   24664:	xor    %ecx,%ecx
   24666:	cs nopw 0x0(%rax,%rax,1)
   24670:	movzbl (%rdx,%r10,1),%r11d
   24675:	add    $0xffffffd0,%r11d
   24679:	cmp    $0x9,%r11d
   2467d:	ja     24530 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x1620>
   24683:	add    %rcx,%rcx
   24686:	lea    (%rcx,%rcx,4),%rcx
   2468a:	mov    %r11d,%r11d
   2468d:	sub    %r11,%rcx
   24690:	inc    %r10
   24693:	cmp    %r10,%rax
   24696:	jne    24670 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x1760>
   24698:	jmp    24535 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x1625>
   2469d:	xor    %r10d,%r10d
   246a0:	xor    %ecx,%ecx
   246a2:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   246b0:	imul   $0xa,%rcx,%rcx
   246b4:	jo     24530 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x1620>
   246ba:	movzbl (%rdx,%r10,1),%r11d
   246bf:	add    $0xffffffd0,%r11d
   246c3:	cmp    $0x9,%r11d
   246c7:	ja     24530 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x1620>
   246cd:	mov    %r11d,%r11d
   246d0:	add    %r11,%rcx
   246d3:	jo     24530 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x1620>
   246d9:	inc    %r10
   246dc:	cmp    %r10,%rax
   246df:	jne    246b0 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x17a0>
   246e1:	jmp    24535 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x1625>
   246e6:	xor    %ecx,%ecx
   246e8:	jmp    24535 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x1625>
   246ed:	mov    $0x1,%r10d
   246f3:	xor    %ecx,%ecx
   246f5:	data16 cs nopw 0x0(%rax,%rax,1)
   24700:	imul   $0xa,%rcx,%rcx
   24704:	jo     24530 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x1620>
   2470a:	movzbl (%rdx,%r10,1),%r11d
   2470f:	add    $0xffffffd0,%r11d
   24713:	cmp    $0x9,%r11d
   24717:	ja     24530 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x1620>
   2471d:	mov    %r11d,%r11d
   24720:	sub    %r11,%rcx
   24723:	jo     24530 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x1620>
   24729:	inc    %r10
   2472c:	cmp    %r10,%rax
   2472f:	jne    24700 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x17f0>
   24731:	jmp    24535 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x1625>
   24736:	movabs $0x735f676e69727473,%rcx
   24740:	xor    (%rax),%rcx
   24743:	movabs $0x6863726165735f67,%rdx
   2474d:	xor    0x5(%rax),%rdx
   24751:	or     %rcx,%rdx
   24754:	je     26b9a <_RNvCseJ3uQ9fe193_12runtime_text4main+0x3c8a>
   2475a:	movabs $0x726767615f767363,%rcx
   24764:	xor    (%rax),%rcx
   24767:	movabs $0x6574616765726767,%rdx
   24771:	xor    0x5(%rax),%rdx
   24775:	or     %rcx,%rdx
   24778:	jne    2791c <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4a0c>
   2477e:	cmpq   $0x0,0x1e8(%rsp)
   24787:	je     27c32 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4d22>
   2478d:	mov    0x1e0(%rsp),%rax
   24795:	movq   $0x0,(%rsp)
   2479d:	mov    0x5d9cc(%rip),%rbp        # 82170 <_DYNAMIC+0x248>
   247a4:	mov    0x5d9cd(%rip),%rbx        # 82178 <_DYNAMIC+0x250>
   247ab:	mov    $0x4,%r12d
   247b1:	mov    0x5d9a0(%rip),%r14        # 82158 <_DYNAMIC+0x230>
   247b8:	lea    0x5ac31(%rip),%rcx        # 7f3f0 <__frame_dummy_init_array_entry+0x210>
   247bf:	mov    %rcx,0x258(%rsp)
   247c7:	movq   $0x0,0x78(%rsp)
   247d0:	mov    %rax,0x290(%rsp)
   247d8:	mov    0x8(%rax),%r13
   247dc:	mov    0x10(%rax),%rax
   247e0:	mov    %rax,0x10(%rsp)
   247e5:	call   *%rbp
   247e7:	mov    $0x4,%edi
   247ec:	mov    $0x1,%esi
   247f1:	call   *%rbx
   247f3:	test   %rax,%rax
   247f6:	je     27af3 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4be3>
   247fc:	mov    %rax,%r15
   247ff:	movl   $0x74736165,(%rax)
   24805:	call   *%rbp
   24807:	mov    $0x4,%edi
   2480c:	mov    $0x1,%esi
   24811:	call   *%rbx
   24813:	test   %rax,%rax
   24816:	je     27c0e <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4cfe>
   2481c:	mov    %rax,%r12
   2481f:	movl   $0x74736577,(%rax)
   24825:	call   *%rbp
   24827:	mov    $0x5,%edi
   2482c:	mov    $0x1,%esi
   24831:	call   *%rbx
   24833:	test   %rax,%rax
   24836:	je     27c20 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4d10>
   2483c:	movb   $0x68,0x4(%rax)
   24840:	movl   $0x74726f6e,(%rax)
   24846:	movq   $0x4,0x90(%rsp)
   24852:	mov    %r15,0x98(%rsp)
   2485a:	movq   $0x4,0xa0(%rsp)
   24866:	movq   $0x0,0xa8(%rsp)
   24872:	movq   $0x4,0xb0(%rsp)
   2487e:	mov    %r12,0xb8(%rsp)
   24886:	movq   $0x4,0xc0(%rsp)
   24892:	movq   $0x0,0xc8(%rsp)
   2489e:	movq   $0x0,0x80(%rsp)
   248aa:	movq   $0x3,0x88(%rsp)
   248b6:	movq   $0x5,0xd0(%rsp)
   248c2:	mov    %rax,0xd8(%rsp)
   248ca:	movq   $0x5,0xe0(%rsp)
   248d6:	movq   $0x0,0xe8(%rsp)
   248e2:	lea    0x120(%rsp),%rdi
   248ea:	lea    0x80(%rsp),%rsi
   248f2:	call   2b8e0 <_RINvXs1c_NtNtNtCs9k3SxhrAWiO_3std11collections4hash3mapINtB7_7HashMapNtNtCs6i54tJFfzR_5alloc6string6StringxEINtNtNtNtCsgxBkk5gSRhY_4core4iter6traits7collect12FromIteratorTB15_xEE9from_iterINtNtNtB1R_5array4iter8IntoIterB2I_Kj3_EECseJ3uQ9fe193_12runtime_text>
   248f7:	incq   0x78(%rsp)
   248fc:	movq   $0x0,0x1a0(%rsp)
   24908:	movq   $0x8,0x1a8(%rsp)
   24914:	movq   $0x0,0x1b0(%rsp)
   24920:	movq   $0x0,0x108(%rsp)
   2492c:	movq   $0x8,0x110(%rsp)
   24938:	movq   $0x0,0x118(%rsp)
   24944:	movq   $0x0,0x30(%rsp)
   2494d:	movq   $0x1,0x38(%rsp)
   24956:	movq   $0x0,0x40(%rsp)
   2495f:	add    %r13,0x10(%rsp)
   24964:	mov    $0xfffffffe,%edx
   24969:	mov    $0x1,%eax
   2496e:	xor    %ebp,%ebp
   24970:	mov    $0x1,%r15d
   24976:	jmp    249c1 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x1ab1>
   24978:	nopl   0x0(%rax,%rax,1)
   24980:	mov    0x110(%rsp),%rax
   24988:	lea    0x0(,%r13,2),%rcx
   24990:	add    %r13,%rcx
   24993:	mov    %r12,(%rax,%rcx,8)
   24997:	mov    %r15,0x8(%rax,%rcx,8)
   2499c:	mov    %rbp,0x10(%rax,%rcx,8)
   249a1:	inc    %r13
   249a4:	mov    %r13,0x118(%rsp)
   249ac:	xor    %ebp,%ebp
   249ae:	mov    $0x1,%eax
   249b3:	mov    $0x1,%r15d
   249b9:	mov    $0xfffffffe,%edx
   249be:	mov    %rbx,%r13
   249c1:	xor    %ecx,%ecx
   249c3:	cmp    $0xfffffffe,%edx
   249c6:	je     24a20 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x1b10>
   249c8:	mov    %r13,%rbx
   249cb:	mov    %edx,%r12d
   249ce:	cmp    $0xffffffff,%edx
   249d1:	je     24f9e <_RNvCseJ3uQ9fe193_12runtime_text4main+0x208e>
   249d7:	test   $0x1,%cl
   249da:	je     24ba0 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x1c90>
   249e0:	cmp    $0x22,%r12d
   249e4:	je     24b03 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x1bf3>
   249ea:	cmp    $0x80,%r12d
   249f1:	jae    24aa1 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x1b91>
   249f7:	cmp    %rbp,0x30(%rsp)
   249fc:	je     24d9d <_RNvCseJ3uQ9fe193_12runtime_text4main+0x1e8d>
   24a02:	mov    0x38(%rsp),%rax
   24a07:	mov    %r12b,(%rax,%rbp,1)
   24a0b:	mov    $0x1,%ecx
   24a10:	jmp    24c80 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x1d70>
   24a15:	data16 cs nopw 0x0(%rax,%rax,1)
   24a20:	cmp    0x10(%rsp),%r13
   24a25:	je     24f9e <_RNvCseJ3uQ9fe193_12runtime_text4main+0x208e>
   24a2b:	movzbl 0x0(%r13),%r12d
   24a30:	test   %r12b,%r12b
   24a33:	js     24a45 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x1b35>
   24a35:	inc    %r13
   24a38:	mov    %r13,%rbx
   24a3b:	test   $0x1,%cl
   24a3e:	jne    249e0 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x1ad0>
   24a40:	jmp    24ba0 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x1c90>
   24a45:	mov    %r12d,%edx
   24a48:	and    $0x1f,%edx
   24a4b:	movzbl 0x1(%r13),%edi
   24a50:	and    $0x3f,%edi
   24a53:	cmp    $0xdf,%r12b
   24a57:	jbe    24b3c <_RNvCseJ3uQ9fe193_12runtime_text4main+0x1c2c>
   24a5d:	movzbl 0x2(%r13),%esi
   24a62:	shl    $0x6,%edi
   24a65:	and    $0x3f,%esi
   24a68:	or     %edi,%esi
   24a6a:	cmp    $0xf0,%r12b
   24a6e:	jb     24b88 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x1c78>
   24a74:	movzbl 0x3(%r13),%r12d
   24a79:	add    $0x4,%r13
   24a7d:	and    $0x7,%edx
   24a80:	shl    $0x12,%edx
   24a83:	shl    $0x6,%esi
   24a86:	and    $0x3f,%r12d
   24a8a:	or     %esi,%r12d
   24a8d:	or     %edx,%r12d
   24a90:	mov    %r13,%rbx
   24a93:	test   $0x1,%cl
   24a96:	jne    249e0 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x1ad0>
   24a9c:	jmp    24ba0 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x1c90>
   24aa1:	cmp    $0x10000,%r12d
   24aa8:	mov    $0x4,%edx
   24aad:	sbb    $0x0,%rdx
   24ab1:	cmp    $0x800,%r12d
   24ab8:	mov    $0x2,%eax
   24abd:	cmovb  %rax,%rdx
   24ac1:	mov    0x30(%rsp),%rax
   24ac6:	sub    %rbp,%rax
   24ac9:	cmp    %rax,%rdx
   24acc:	ja     24dbf <_RNvCseJ3uQ9fe193_12runtime_text4main+0x1eaf>
   24ad2:	mov    %r12d,%ecx
   24ad5:	and    $0x3f,%cl
   24ad8:	or     $0x80,%cl
   24adb:	mov    %r12d,%edx
   24ade:	shr    $0x6,%edx
   24ae1:	mov    0x38(%rsp),%rax
   24ae6:	cmp    $0x800,%r12d
   24aed:	jae    24b55 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x1c45>
   24aef:	or     $0xc0,%dl
   24af2:	mov    %dl,(%rax,%rbp,1)
   24af5:	mov    %cl,0x1(%rax,%rbp,1)
   24af9:	mov    $0x2,%ecx
   24afe:	jmp    24c80 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x1d70>
   24b03:	mov    $0xffffffff,%edx
   24b08:	xor    %ecx,%ecx
   24b0a:	mov    0x10(%rsp),%rsi
   24b0f:	mov    %rsi,%r13
   24b12:	cmp    %rsi,%rbx
   24b15:	je     249c3 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x1ab3>
   24b1b:	movzbl (%rbx),%edx
   24b1e:	test   %dl,%dl
   24b20:	js     24c8f <_RNvCseJ3uQ9fe193_12runtime_text4main+0x1d7f>
   24b26:	inc    %rbx
   24b29:	mov    %rbx,%r13
   24b2c:	xor    %ecx,%ecx
   24b2e:	cmp    $0x22,%edx
   24b31:	jne    249c3 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x1ab3>
   24b37:	jmp    24d72 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x1e62>
   24b3c:	add    $0x2,%r13
   24b40:	shl    $0x6,%edx
   24b43:	or     %edi,%edx
   24b45:	mov    %r13,%rbx
   24b48:	mov    %edx,%r12d
   24b4b:	test   $0x1,%cl
   24b4e:	je     24ba0 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x1c90>
   24b50:	jmp    249e0 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x1ad0>
   24b55:	and    $0x3f,%dl
   24b58:	or     $0x80,%dl
   24b5b:	mov    %r12d,%esi
   24b5e:	shr    $0xc,%esi
   24b61:	cmp    $0xffff,%r12d
   24b68:	ja     24c50 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x1d40>
   24b6e:	or     $0xe0,%sil
   24b72:	mov    %sil,(%rax,%rbp,1)
   24b76:	mov    %dl,0x1(%rax,%rbp,1)
   24b7a:	mov    %cl,0x2(%rax,%rbp,1)
   24b7e:	mov    $0x3,%ecx
   24b83:	jmp    24c80 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x1d70>
   24b88:	add    $0x3,%r13
   24b8c:	shl    $0xc,%edx
   24b8f:	or     %edx,%esi
   24b91:	mov    %r13,%rbx
   24b94:	mov    %esi,%r12d
   24b97:	test   $0x1,%cl
   24b9a:	jne    249e0 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x1ad0>
   24ba0:	cmp    $0xa,%r12d
   24ba4:	je     24ea0 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x1f90>
   24baa:	mov    $0x1,%cl
   24bac:	mov    $0xfffffffe,%edx
   24bb1:	mov    %rbx,%r13
   24bb4:	cmp    $0x22,%r12d
   24bb8:	je     249c3 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x1ab3>
   24bbe:	cmp    $0x2c,%r12d
   24bc2:	je     24e50 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x1f40>
   24bc8:	cmp    $0x80,%r12d
   24bcf:	jae    24bef <_RNvCseJ3uQ9fe193_12runtime_text4main+0x1cdf>
   24bd1:	cmp    %rbp,0x30(%rsp)
   24bd6:	je     24ddc <_RNvCseJ3uQ9fe193_12runtime_text4main+0x1ecc>
   24bdc:	mov    0x38(%rsp),%rax
   24be1:	mov    %r12b,(%rax,%rbp,1)
   24be5:	mov    $0x1,%ecx
   24bea:	jmp    24d3f <_RNvCseJ3uQ9fe193_12runtime_text4main+0x1e2f>
   24bef:	cmp    $0x10000,%r12d
   24bf6:	mov    $0x4,%edx
   24bfb:	sbb    $0x0,%rdx
   24bff:	cmp    $0x800,%r12d
   24c06:	mov    $0x2,%ecx
   24c0b:	cmovb  %rcx,%rdx
   24c0f:	mov    0x30(%rsp),%rcx
   24c14:	sub    %rbp,%rcx
   24c17:	cmp    %rcx,%rdx
   24c1a:	ja     24dfe <_RNvCseJ3uQ9fe193_12runtime_text4main+0x1eee>
   24c20:	mov    %r12d,%ecx
   24c23:	and    $0x3f,%cl
   24c26:	or     $0x80,%cl
   24c29:	mov    %r12d,%edx
   24c2c:	shr    $0x6,%edx
   24c2f:	cmp    $0x800,%r12d
   24c36:	jae    24cd2 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x1dc2>
   24c3c:	or     $0xc0,%dl
   24c3f:	mov    %dl,(%rax,%rbp,1)
   24c42:	mov    %cl,0x1(%rax,%rbp,1)
   24c46:	mov    $0x2,%ecx
   24c4b:	jmp    24d3f <_RNvCseJ3uQ9fe193_12runtime_text4main+0x1e2f>
   24c50:	and    $0x3f,%sil
   24c54:	or     $0x80,%sil
   24c58:	shr    $0x12,%r12d
   24c5c:	or     $0xf0,%r12b
   24c60:	mov    %r12b,(%rax,%rbp,1)
   24c64:	mov    %sil,0x1(%rax,%rbp,1)
   24c69:	mov    %dl,0x2(%rax,%rbp,1)
   24c6d:	mov    %cl,0x3(%rax,%rbp,1)
   24c71:	mov    $0x4,%ecx
   24c76:	cs nopw 0x0(%rax,%rax,1)
   24c80:	add    %rcx,%rbp
   24c83:	mov    %rbp,0x40(%rsp)
   24c88:	mov    $0x1,%cl
   24c8a:	jmp    24d49 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x1e39>
   24c8f:	mov    %edx,%ecx
   24c91:	and    $0x1f,%ecx
   24c94:	movzbl 0x1(%rbx),%edi
   24c98:	and    $0x3f,%edi
   24c9b:	cmp    $0xdf,%dl
   24c9e:	jbe    24cfe <_RNvCseJ3uQ9fe193_12runtime_text4main+0x1dee>
   24ca0:	movzbl 0x2(%rbx),%esi
   24ca4:	shl    $0x6,%edi
   24ca7:	and    $0x3f,%esi
   24caa:	or     %edi,%esi
   24cac:	cmp    $0xf0,%dl
   24caf:	jb     24d59 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x1e49>
   24cb5:	movzbl 0x3(%rbx),%edx
   24cb9:	add    $0x4,%rbx
   24cbd:	and    $0x7,%ecx
   24cc0:	shl    $0x12,%ecx
   24cc3:	shl    $0x6,%esi
   24cc6:	and    $0x3f,%edx
   24cc9:	or     %esi,%edx
   24ccb:	or     %ecx,%edx
   24ccd:	jmp    24b29 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x1c19>
   24cd2:	and    $0x3f,%dl
   24cd5:	or     $0x80,%dl
   24cd8:	mov    %r12d,%esi
   24cdb:	shr    $0xc,%esi
   24cde:	cmp    $0xffff,%r12d
   24ce5:	ja     24d19 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x1e09>
   24ce7:	or     $0xe0,%sil
   24ceb:	mov    %sil,(%rax,%rbp,1)
   24cef:	mov    %dl,0x1(%rax,%rbp,1)
   24cf3:	mov    %cl,0x2(%rax,%rbp,1)
   24cf7:	mov    $0x3,%ecx
   24cfc:	jmp    24d3f <_RNvCseJ3uQ9fe193_12runtime_text4main+0x1e2f>
   24cfe:	add    $0x2,%rbx
   24d02:	shl    $0x6,%ecx
   24d05:	or     %edi,%ecx
   24d07:	mov    %rbx,%r13
   24d0a:	mov    %ecx,%edx
   24d0c:	xor    %ecx,%ecx
   24d0e:	cmp    $0x22,%edx
   24d11:	jne    249c3 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x1ab3>
   24d17:	jmp    24d72 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x1e62>
   24d19:	and    $0x3f,%sil
   24d1d:	or     $0x80,%sil
   24d21:	shr    $0x12,%r12d
   24d25:	or     $0xf0,%r12b
   24d29:	mov    %r12b,(%rax,%rbp,1)
   24d2d:	mov    %sil,0x1(%rax,%rbp,1)
   24d32:	mov    %dl,0x2(%rax,%rbp,1)
   24d36:	mov    %cl,0x3(%rax,%rbp,1)
   24d3a:	mov    $0x4,%ecx
   24d3f:	add    %rcx,%rbp
   24d42:	mov    %rbp,0x40(%rsp)
   24d47:	xor    %ecx,%ecx
   24d49:	mov    %rax,%r15
   24d4c:	mov    $0xfffffffe,%edx
   24d51:	mov    %rbx,%r13
   24d54:	jmp    249c3 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x1ab3>
   24d59:	add    $0x3,%rbx
   24d5d:	shl    $0xc,%ecx
   24d60:	or     %ecx,%esi
   24d62:	mov    %rbx,%r13
   24d65:	mov    %esi,%edx
   24d67:	xor    %ecx,%ecx
   24d69:	cmp    $0x22,%edx
   24d6c:	jne    249c3 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x1ab3>
   24d72:	cmp    %rbp,0x30(%rsp)
   24d77:	je     24e20 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x1f10>
   24d7d:	mov    0x38(%rsp),%rax
   24d82:	movb   $0x22,(%rax,%rbp,1)
   24d86:	inc    %rbp
   24d89:	mov    %rbp,0x40(%rsp)
   24d8e:	mov    $0x1,%cl
   24d90:	mov    %rax,%r15
   24d93:	mov    $0xfffffffe,%edx
   24d98:	jmp    249c3 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x1ab3>
   24d9d:	mov    $0x1,%edx
   24da2:	mov    $0x1,%ecx
   24da7:	mov    $0x1,%r8d
   24dad:	lea    0x30(%rsp),%rdi
   24db2:	mov    %rbp,%rsi
   24db5:	call   28440 <_RINvNvMs2_NtCs6i54tJFfzR_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECseJ3uQ9fe193_12runtime_text>
   24dba:	jmp    24a02 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x1af2>
   24dbf:	mov    $0x1,%ecx
   24dc4:	mov    $0x1,%r8d
   24dca:	lea    0x30(%rsp),%rdi
   24dcf:	mov    %rbp,%rsi
   24dd2:	call   28440 <_RINvNvMs2_NtCs6i54tJFfzR_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECseJ3uQ9fe193_12runtime_text>
   24dd7:	jmp    24ad2 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x1bc2>
   24ddc:	mov    $0x1,%edx
   24de1:	mov    $0x1,%ecx
   24de6:	mov    $0x1,%r8d
   24dec:	lea    0x30(%rsp),%rdi
   24df1:	mov    %rbp,%rsi
   24df4:	call   28440 <_RINvNvMs2_NtCs6i54tJFfzR_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECseJ3uQ9fe193_12runtime_text>
   24df9:	jmp    24bdc <_RNvCseJ3uQ9fe193_12runtime_text4main+0x1ccc>
   24dfe:	mov    $0x1,%ecx
   24e03:	mov    $0x1,%r8d
   24e09:	lea    0x30(%rsp),%rdi
   24e0e:	mov    %rbp,%rsi
   24e11:	call   28440 <_RINvNvMs2_NtCs6i54tJFfzR_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECseJ3uQ9fe193_12runtime_text>
   24e16:	mov    0x38(%rsp),%rax
   24e1b:	jmp    24c20 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x1d10>
   24e20:	mov    $0x1,%edx
   24e25:	mov    $0x1,%ecx
   24e2a:	mov    $0x1,%r8d
   24e30:	lea    0x30(%rsp),%rdi
   24e35:	mov    %rbp,%rsi
   24e38:	call   28440 <_RINvNvMs2_NtCs6i54tJFfzR_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECseJ3uQ9fe193_12runtime_text>
   24e3d:	jmp    24d7d <_RNvCseJ3uQ9fe193_12runtime_text4main+0x1e6d>
   24e42:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   24e50:	mov    0x30(%rsp),%r12
   24e55:	movq   $0x0,0x30(%rsp)
   24e5e:	movq   $0x1,0x38(%rsp)
   24e67:	movq   $0x0,0x40(%rsp)
   24e70:	mov    0x118(%rsp),%r13
   24e78:	cmp    0x108(%rsp),%r13
   24e80:	jne    24980 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x1a70>
   24e86:	lea    0x108(%rsp),%rdi
   24e8e:	call   *0x5d30c(%rip)        # 821a0 <_DYNAMIC+0x278>
   24e94:	jmp    24980 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x1a70>
   24e99:	nopl   0x0(%rax)
   24ea0:	mov    0x30(%rsp),%r12
   24ea5:	movq   $0x0,0x30(%rsp)
   24eae:	movq   $0x1,0x38(%rsp)
   24eb7:	movq   $0x0,0x40(%rsp)
   24ec0:	mov    0x118(%rsp),%r13
   24ec8:	cmp    0x108(%rsp),%r13
   24ed0:	jne    24ee0 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x1fd0>
   24ed2:	lea    0x108(%rsp),%rdi
   24eda:	call   *0x5d2c0(%rip)        # 821a0 <_DYNAMIC+0x278>
   24ee0:	mov    0x110(%rsp),%rax
   24ee8:	lea    0x0(,%r13,2),%rcx
   24ef0:	add    %r13,%rcx
   24ef3:	mov    %r12,(%rax,%rcx,8)
   24ef7:	mov    %r15,0x8(%rax,%rcx,8)
   24efc:	mov    %rbp,0x10(%rax,%rcx,8)
   24f01:	inc    %r13
   24f04:	mov    %r13,0x118(%rsp)
   24f0c:	mov    %r13,0x90(%rsp)
   24f14:	movups 0x108(%rsp),%xmm0
   24f1c:	movaps %xmm0,0x80(%rsp)
   24f24:	movq   $0x0,0x108(%rsp)
   24f30:	movq   $0x8,0x110(%rsp)
   24f3c:	movq   $0x0,0x118(%rsp)
   24f48:	mov    0x1b0(%rsp),%r15
   24f50:	cmp    0x1a0(%rsp),%r15
   24f58:	jne    24f67 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x2057>
   24f5a:	lea    0x1a0(%rsp),%rdi
   24f62:	call   299b0 <_RNvMs4_NtCs6i54tJFfzR_5alloc7raw_vecINtB5_6RawVecINtNtB7_3vec3VecNtNtB7_6string6StringEE8grow_oneCseJ3uQ9fe193_12runtime_text>
   24f67:	mov    0x1a8(%rsp),%rax
   24f6f:	lea    (%r15,%r15,2),%rcx
   24f73:	mov    0x90(%rsp),%rdx
   24f7b:	mov    %rdx,0x10(%rax,%rcx,8)
   24f80:	movdqa 0x80(%rsp),%xmm0
   24f89:	movdqu %xmm0,(%rax,%rcx,8)
   24f8e:	inc    %r15
   24f91:	mov    %r15,0x1b0(%rsp)
   24f99:	jmp    249ac <_RNvCseJ3uQ9fe193_12runtime_text4main+0x1a9c>
   24f9e:	test   $0x1,%cl
   24fa1:	jne    278e0 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x49d0>
   24fa7:	test   %rbp,%rbp
   24faa:	jne    278e0 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x49d0>
   24fb0:	cmpq   $0x0,0x118(%rsp)
   24fb9:	jne    278e0 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x49d0>
   24fbf:	mov    0x1a0(%rsp),%rax
   24fc7:	mov    %rax,0x20(%rsp)
   24fcc:	mov    0x1a8(%rsp),%r13
   24fd4:	mov    0x1b0(%rsp),%rbx
   24fdc:	mov    0x30(%rsp),%rsi
   24fe1:	test   %rsi,%rsi
   24fe4:	je     25031 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x2121>
   24fe6:	mov    $0x1,%edx
   24feb:	mov    %r15,%rdi
   24fee:	call   *%r14
   24ff1:	mov    0x118(%rsp),%r15
   24ff9:	test   %r15,%r15
   24ffc:	je     25031 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x2121>
   24ffe:	mov    0x110(%rsp),%r12
   25006:	add    $0x8,%r12
   2500a:	jmp    25019 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x2109>
   2500c:	nopl   0x0(%rax)
   25010:	add    $0x18,%r12
   25014:	dec    %r15
   25017:	je     25031 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x2121>
   25019:	mov    -0x8(%r12),%rsi
   2501e:	test   %rsi,%rsi
   25021:	je     25010 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x2100>
   25023:	mov    (%r12),%rdi
   25027:	mov    $0x1,%edx
   2502c:	call   *%r14
   2502f:	jmp    25010 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x2100>
   25031:	mov    0x108(%rsp),%rax
   25039:	test   %rax,%rax
   2503c:	je     25056 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x2146>
   2503e:	mov    0x110(%rsp),%rdi
   25046:	shl    $0x3,%rax
   2504a:	lea    (%rax,%rax,2),%rsi
   2504e:	mov    $0x8,%edx
   25053:	call   *%r14
   25056:	lea    (%rbx,%rbx,2),%rax
   2505a:	lea    0x0(,%rax,8),%rcx
   25062:	add    %r13,%rcx
   25065:	mov    %r13,0x80(%rsp)
   2506d:	mov    %r13,0x88(%rsp)
   25075:	mov    0x20(%rsp),%rax
   2507a:	mov    %rax,0x90(%rsp)
   25082:	mov    %rcx,0x10(%rsp)
   25087:	mov    %rcx,0x98(%rsp)
   2508f:	test   %rbx,%rbx
   25092:	mov    %r13,0x68(%rsp)
   25097:	je     25517 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x2607>
   2509d:	mov    0x138(%rsp),%rax
   250a5:	mov    %rax,0x298(%rsp)
   250ad:	mov    0x120(%rsp),%rax
   250b5:	mov    %rax,0x28(%rsp)
   250ba:	mov    0x128(%rsp),%rax
   250c2:	mov    %rax,0x1b8(%rsp)
   250ca:	mov    %r13,%rax
   250cd:	movq   $0x0,0x70(%rsp)
   250d6:	movq   $0x0,0x8(%rsp)
   250df:	movq   $0x0,0x60(%rsp)
   250e8:	jmp    250fe <_RNvCseJ3uQ9fe193_12runtime_text4main+0x21ee>
   250ea:	nopw   0x0(%rax,%rax,1)
   250f0:	mov    %rbx,%rax
   250f3:	cmp    0x10(%rsp),%rbx
   250f8:	je     25537 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x2627>
   250fe:	lea    0x18(%rax),%rbp
   25102:	mov    (%rax),%r13
   25105:	cmp    $0xffffffffffffffff,%r13
   25109:	je     2553c <_RNvCseJ3uQ9fe193_12runtime_text4main+0x262c>
   2510f:	mov    %rbp,%rbx
   25112:	mov    %r13,0x30(%rsp)
   25117:	movdqu 0x8(%rax),%xmm0
   2511c:	lea    0x38(%rsp),%rax
   25121:	movdqu %xmm0,(%rax)
   25125:	mov    0x40(%rsp),%r12
   2512a:	cmp    $0x3,%r12
   2512e:	jbe    27b1c <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4c0c>
   25134:	mov    0x38(%rsp),%r15
   25139:	mov    0x58(%r15),%rax
   2513d:	test   %rax,%rax
   25140:	je     25160 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x2250>
   25142:	mov    0x50(%r15),%rcx
   25146:	cmp    $0x1,%rax
   2514a:	jne    251c0 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x22b0>
   2514c:	movzbl (%rcx),%edx
   2514f:	cmp    $0x2b,%edx
   25152:	je     25160 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x2250>
   25154:	cmp    $0x2d,%edx
   25157:	jne    251c3 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x22b3>
   25159:	nopl   0x0(%rax)
   25160:	incq   0x8(%rsp)
   25165:	lea    0x8(%r15),%rbp
   25169:	jmp    25179 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x2269>
   2516b:	nopl   0x0(%rax,%rax,1)
   25170:	add    $0x18,%rbp
   25174:	dec    %r12
   25177:	je     25190 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x2280>
   25179:	mov    -0x8(%rbp),%rsi
   2517d:	test   %rsi,%rsi
   25180:	je     25170 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x2260>
   25182:	mov    0x0(%rbp),%rdi
   25186:	mov    $0x1,%edx
   2518b:	call   *%r14
   2518e:	jmp    25170 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x2260>
   25190:	test   %r13,%r13
   25193:	je     250f0 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x21e0>
   25199:	shl    $0x3,%r13
   2519d:	lea    0x0(,%r13,2),%rsi
   251a5:	add    %r13,%rsi
   251a8:	mov    $0x8,%edx
   251ad:	mov    %r15,%rdi
   251b0:	call   *%r14
   251b3:	jmp    250f0 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x21e0>
   251b8:	nopl   0x0(%rax,%rax,1)
   251c0:	movzbl (%rcx),%edx
   251c3:	cmp    $0x2d,%dl
   251c6:	je     2521e <_RNvCseJ3uQ9fe193_12runtime_text4main+0x230e>
   251c8:	movzbl %dl,%edx
   251cb:	cmp    $0x2b,%edx
   251ce:	jne    251d6 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x22c6>
   251d0:	inc    %rcx
   251d3:	dec    %rax
   251d6:	cmp    $0x10,%rax
   251da:	jae    25267 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x2357>
   251e0:	test   %rax,%rax
   251e3:	je     252df <_RNvCseJ3uQ9fe193_12runtime_text4main+0x23cf>
   251e9:	xor    %edx,%edx
   251eb:	xor    %ebp,%ebp
   251ed:	nopl   (%rax)
   251f0:	movzbl (%rcx,%rdx,1),%esi
   251f4:	add    $0xffffffd0,%esi
   251f7:	cmp    $0x9,%esi
   251fa:	ja     25160 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x2250>
   25200:	lea    0x0(,%rbp,4),%rdi
   25208:	add    %rbp,%rdi
   2520b:	mov    %esi,%esi
   2520d:	lea    (%rsi,%rdi,2),%rbp
   25211:	inc    %rdx
   25214:	cmp    %rdx,%rax
   25217:	jne    251f0 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x22e0>
   25219:	jmp    252e1 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x23d1>
   2521e:	cmp    $0x11,%rax
   25222:	jae    2529f <_RNvCseJ3uQ9fe193_12runtime_text4main+0x238f>
   25224:	mov    %rax,%rdx
   25227:	dec    %rdx
   2522a:	je     2547b <_RNvCseJ3uQ9fe193_12runtime_text4main+0x256b>
   25230:	mov    $0x1,%edx
   25235:	xor    %ebp,%ebp
   25237:	nopw   0x0(%rax,%rax,1)
   25240:	movzbl (%rcx,%rdx,1),%esi
   25244:	add    $0xffffffd0,%esi
   25247:	cmp    $0x9,%esi
   2524a:	ja     25160 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x2250>
   25250:	add    %rbp,%rbp
   25253:	lea    0x0(%rbp,%rbp,4),%rbp
   25258:	mov    %esi,%esi
   2525a:	sub    %rsi,%rbp
   2525d:	inc    %rdx
   25260:	cmp    %rdx,%rax
   25263:	jne    25240 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x2330>
   25265:	jmp    252e1 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x23d1>
   25267:	xor    %edx,%edx
   25269:	xor    %ebp,%ebp
   2526b:	nopl   0x0(%rax,%rax,1)
   25270:	imul   $0xa,%rbp,%rbp
   25274:	jo     25160 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x2250>
   2527a:	movzbl (%rcx,%rdx,1),%esi
   2527e:	add    $0xffffffd0,%esi
   25281:	cmp    $0x9,%esi
   25284:	ja     25160 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x2250>
   2528a:	mov    %esi,%esi
   2528c:	add    %rsi,%rbp
   2528f:	jo     25160 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x2250>
   25295:	inc    %rdx
   25298:	cmp    %rdx,%rax
   2529b:	jne    25270 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x2360>
   2529d:	jmp    252e1 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x23d1>
   2529f:	mov    $0x1,%edx
   252a4:	xor    %ebp,%ebp
   252a6:	cs nopw 0x0(%rax,%rax,1)
   252b0:	imul   $0xa,%rbp,%rbp
   252b4:	jo     25160 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x2250>
   252ba:	movzbl (%rcx,%rdx,1),%esi
   252be:	add    $0xffffffd0,%esi
   252c1:	cmp    $0x9,%esi
   252c4:	ja     25160 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x2250>
   252ca:	mov    %esi,%esi
   252cc:	sub    %rsi,%rbp
   252cf:	jo     25160 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x2250>
   252d5:	inc    %rdx
   252d8:	cmp    %rdx,%rax
   252db:	jne    252b0 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x23a0>
   252dd:	jmp    252e1 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x23d1>
   252df:	xor    %ebp,%ebp
   252e1:	cmp    $0x4,%r12
   252e5:	je     27b58 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4c48>
   252eb:	cmpq   $0x1,0x70(%r15)
   252f0:	jne    25165 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x2255>
   252f6:	mov    0x68(%r15),%rax
   252fa:	cmpb   $0x31,(%rax)
   252fd:	jne    25165 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x2255>
   25303:	cmpq   $0x0,0x298(%rsp)
   2530c:	je     27662 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4752>
   25312:	lea    0x30(%r15),%rsi
   25316:	lea    0x140(%rsp),%rdi
   2531e:	call   29110 <_RINvYNtNtNtCs9k3SxhrAWiO_3std4hash6random11RandomStateNtNtCsgxBkk5gSRhY_4core4hash11BuildHasher8hash_oneRNtNtCs6i54tJFfzR_5alloc6string6StringECseJ3uQ9fe193_12runtime_text>
   25323:	mov    %rax,%rcx
   25326:	shr    $0x39,%rax
   2532a:	movd   %eax,%xmm0
   2532e:	punpcklbw %xmm0,%xmm0
   25332:	pshuflw $0x0,%xmm0,%xmm0
   25337:	pshufd $0x44,%xmm0,%xmm1
   2533c:	mov    0x38(%r15),%rdi
   25340:	mov    0x40(%r15),%rdx
   25344:	xor    %esi,%esi
   25346:	and    0x1b8(%rsp),%rcx
   2534e:	mov    0x28(%rsp),%rax
   25353:	movdqu (%rax,%rcx,1),%xmm2
   25358:	movdqa %xmm2,%xmm0
   2535c:	pcmpeqb %xmm1,%xmm0
   25360:	pmovmskb %xmm0,%eax
   25364:	test   %eax,%eax
   25366:	pcmpeqd %xmm0,%xmm0
   2536a:	je     2543b <_RNvCseJ3uQ9fe193_12runtime_text4main+0x252b>
   25370:	mov    %rcx,0x270(%rsp)
   25378:	movdqa %xmm1,0x2c0(%rsp)
   25381:	mov    %rsi,0x268(%rsp)
   25389:	movdqa %xmm2,0x2b0(%rsp)
   25392:	mov    %rax,0x278(%rsp)
   2539a:	tzcnt  %eax,%eax
   2539e:	add    %rcx,%rax
   253a1:	and    0x1b8(%rsp),%rax
   253a9:	shl    $0x5,%rax
   253ad:	mov    0x28(%rsp),%rcx
   253b2:	sub    %rax,%rcx
   253b5:	cmp    -0x10(%rcx),%rdx
   253b9:	jne    25401 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x24f1>
   253bb:	mov    -0x18(%rcx),%rsi
   253bf:	mov    %rdi,0x260(%rsp)
   253c7:	mov    0x260(%rsp),%rdi
   253cf:	mov    %rdx,0x288(%rsp)
   253d7:	mov    %rcx,0x280(%rsp)
   253df:	call   *0x5cdc3(%rip)        # 821a8 <bcmp@GLIBC_2.2.5>
   253e5:	mov    0x280(%rsp),%rcx
   253ed:	mov    0x288(%rsp),%rdx
   253f5:	mov    0x260(%rsp),%rdi
   253fd:	test   %eax,%eax
   253ff:	je     2545b <_RNvCseJ3uQ9fe193_12runtime_text4main+0x254b>
   25401:	mov    0x278(%rsp),%rcx
   25409:	lea    -0x1(%rcx),%eax
   2540c:	and    %cx,%ax
   2540f:	pcmpeqd %xmm0,%xmm0
   25413:	mov    0x270(%rsp),%rcx
   2541b:	movdqa 0x2c0(%rsp),%xmm1
   25424:	mov    0x268(%rsp),%rsi
   2542c:	movdqa 0x2b0(%rsp),%xmm2
   25435:	jne    25392 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x2482>
   2543b:	pcmpeqb %xmm0,%xmm2
   2543f:	pmovmskb %xmm2,%eax
   25443:	test   %eax,%eax
   25445:	jne    27662 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4752>
   2544b:	add    %rsi,%rcx
   2544e:	add    $0x10,%rcx
   25452:	add    $0x10,%rsi
   25456:	jmp    25346 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x2436>
   2545b:	add    %rbp,-0x8(%rcx)
   2545f:	mov    0x28(%r15),%rax
   25463:	test   %rax,%rax
   25466:	je     2548c <_RNvCseJ3uQ9fe193_12runtime_text4main+0x257c>
   25468:	mov    0x20(%r15),%rcx
   2546c:	mov    %eax,%edx
   2546e:	and    $0x7,%edx
   25471:	cmp    $0x8,%rax
   25475:	jae    25490 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x2580>
   25477:	xor    %esi,%esi
   25479:	jmp    254eb <_RNvCseJ3uQ9fe193_12runtime_text4main+0x25db>
   2547b:	xor    %ebp,%ebp
   2547d:	cmp    $0x4,%r12
   25481:	jne    252eb <_RNvCseJ3uQ9fe193_12runtime_text4main+0x23db>
   25487:	jmp    27b58 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4c48>
   2548c:	xor    %esi,%esi
   2548e:	jmp    25500 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x25f0>
   25490:	mov    %rax,%rdi
   25493:	and    $0xfffffffffffffff8,%rdi
   25497:	xor    %esi,%esi
   25499:	nopl   0x0(%rax)
   254a0:	movzbl (%rcx),%r8d
   254a4:	add    %rsi,%r8
   254a7:	movzbl 0x1(%rcx),%esi
   254ab:	movzbl 0x2(%rcx),%r9d
   254b0:	add    %rsi,%r9
   254b3:	add    %r8,%r9
   254b6:	movzbl 0x3(%rcx),%esi
   254ba:	movzbl 0x4(%rcx),%r8d
   254bf:	add    %rsi,%r8
   254c2:	movzbl 0x5(%rcx),%r10d
   254c7:	add    %r8,%r10
   254ca:	add    %r9,%r10
   254cd:	movzbl 0x6(%rcx),%r8d
   254d2:	movzbl 0x7(%rcx),%esi
   254d6:	add    $0x8,%rcx
   254da:	add    %r8,%rsi
   254dd:	add    %r10,%rsi
   254e0:	add    $0xfffffffffffffff8,%rdi
   254e4:	jne    254a0 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x2590>
   254e6:	test   %rdx,%rdx
   254e9:	je     25500 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x25f0>
   254eb:	xor    %edi,%edi
   254ed:	nopl   (%rax)
   254f0:	movzbl (%rcx,%rdi,1),%r8d
   254f5:	add    %r8,%rsi
   254f8:	inc    %rdi
   254fb:	cmp    %rdi,%rdx
   254fe:	jne    254f0 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x25e0>
   25500:	incq   0x70(%rsp)
   25505:	add    0x60(%rsp),%rax
   2550a:	add    %rsi,%rax
   2550d:	mov    %rax,0x60(%rsp)
   25512:	jmp    25165 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x2255>
   25517:	mov    %r13,%rbp
   2551a:	movq   $0x0,0x60(%rsp)
   25523:	movq   $0x0,0x8(%rsp)
   2552c:	movq   $0x0,0x28(%rsp)
   25535:	jmp    25563 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x2653>
   25537:	mov    0x10(%rsp),%rbp
   2553c:	mov    %rbp,0x88(%rsp)
   25544:	mov    0x70(%rsp),%rax
   25549:	mov    %rax,%rcx
   2554c:	shl    $0x4,%rcx
   25550:	add    %rax,%rcx
   25553:	mov    %rcx,0x28(%rsp)
   25558:	imul   $0x65,0x8(%rsp),%rax
   2555e:	mov    %rax,0x8(%rsp)
   25563:	sub    %rbp,0x10(%rsp)
   25568:	je     25605 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x26f5>
   2556e:	mov    0x10(%rsp),%rcx
   25573:	shr    $0x3,%rcx
   25577:	movabs $0xaaaaaaaaaaaaaaab,%rax
   25581:	imul   %rax,%rcx
   25585:	mov    %rcx,0x10(%rsp)
   2558a:	xor    %r15d,%r15d
   2558d:	jmp    2559a <_RNvCseJ3uQ9fe193_12runtime_text4main+0x268a>
   2558f:	nop
   25590:	inc    %r15
   25593:	cmp    0x10(%rsp),%r15
   25598:	je     25605 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x26f5>
   2559a:	lea    (%r15,%r15,2),%rbx
   2559e:	mov    %rbp,%r12
   255a1:	mov    0x10(%rbp,%rbx,8),%r13
   255a6:	test   %r13,%r13
   255a9:	je     255e0 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x26d0>
   255ab:	mov    0x8(%r12,%rbx,8),%rbp
   255b0:	add    $0x8,%rbp
   255b4:	jmp    255c9 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x26b9>
   255b6:	cs nopw 0x0(%rax,%rax,1)
   255c0:	add    $0x18,%rbp
   255c4:	dec    %r13
   255c7:	je     255e0 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x26d0>
   255c9:	mov    -0x8(%rbp),%rsi
   255cd:	test   %rsi,%rsi
   255d0:	je     255c0 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x26b0>
   255d2:	mov    0x0(%rbp),%rdi
   255d6:	mov    $0x1,%edx
   255db:	call   *%r14
   255de:	jmp    255c0 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x26b0>
   255e0:	mov    %r12,%rbp
   255e3:	lea    (%r12,%rbx,8),%rcx
   255e7:	mov    (%rcx),%rax
   255ea:	test   %rax,%rax
   255ed:	je     25590 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x2680>
   255ef:	mov    0x8(%rcx),%rdi
   255f3:	shl    $0x3,%rax
   255f7:	lea    (%rax,%rax,2),%rsi
   255fb:	mov    $0x8,%edx
   25600:	call   *%r14
   25603:	jmp    25590 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x2680>
   25605:	mov    0x20(%rsp),%rax
   2560a:	test   %rax,%rax
   2560d:	je     25624 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x2714>
   2560f:	shl    $0x3,%rax
   25613:	lea    (%rax,%rax,2),%rsi
   25617:	mov    $0x8,%edx
   2561c:	mov    0x68(%rsp),%rdi
   25621:	call   *%r14
   25624:	mov    0x138(%rsp),%rbx
   2562c:	test   %rbx,%rbx
   2562f:	mov    $0x4,%r12d
   25635:	lea    0x140(%rsp),%r13
   2563d:	mov    0x5cb2c(%rip),%rbp        # 82170 <_DYNAMIC+0x248>
   25644:	je     2733e <_RNvCseJ3uQ9fe193_12runtime_text4main+0x442e>
   2564a:	mov    $0x4,%edx
   2564f:	mov    %r13,%rdi
   25652:	lea    -0x1828d(%rip),%rsi        # d3cc <anon.c41b9569d3e50f51ac9d11be340d2ec5.16.llvm.16118886657712379284+0x4>
   25659:	call   293f0 <_RINvYNtNtNtCs9k3SxhrAWiO_3std4hash6random11RandomStateNtNtCsgxBkk5gSRhY_4core4hash11BuildHasher8hash_oneReECseJ3uQ9fe193_12runtime_text>
   2565e:	mov    %rax,%rcx
   25661:	shr    $0x39,%rcx
   25665:	mov    0x120(%rsp),%rdx
   2566d:	mov    0x128(%rsp),%r15
   25675:	movd   %ecx,%xmm0
   25679:	punpcklbw %xmm0,%xmm0
   2567d:	pshuflw $0x0,%xmm0,%xmm0
   25682:	pshufd $0x44,%xmm0,%xmm0
   25687:	xor    %ecx,%ecx
   25689:	mov    %rdx,0x10(%rsp)
   2568e:	and    %r15,%rax
   25691:	movdqu (%rdx,%rax,1),%xmm1
   25696:	movdqa %xmm1,%xmm2
   2569a:	pcmpeqb %xmm0,%xmm2
   2569e:	pmovmskb %xmm2,%edx
   256a2:	test   %edx,%edx
   256a4:	je     256d9 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x27c9>
   256a6:	tzcnt  %edx,%edi
   256aa:	add    %rax,%rdi
   256ad:	and    %r15,%rdi
   256b0:	shl    $0x5,%rdi
   256b4:	mov    0x10(%rsp),%rsi
   256b9:	sub    %rdi,%rsi
   256bc:	cmpq   $0x4,-0x10(%rsi)
   256c1:	jne    256cf <_RNvCseJ3uQ9fe193_12runtime_text4main+0x27bf>
   256c3:	mov    -0x18(%rsi),%rdi
   256c7:	cmpl   $0x74736165,(%rdi)
   256cd:	je     256ff <_RNvCseJ3uQ9fe193_12runtime_text4main+0x27ef>
   256cf:	lea    -0x1(%rdx),%esi
   256d2:	and    %dx,%si
   256d5:	mov    %esi,%edx
   256d7:	jne    256a6 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x2796>
   256d9:	pcmpeqd %xmm2,%xmm2
   256dd:	pcmpeqb %xmm2,%xmm1
   256e1:	pmovmskb %xmm1,%edx
   256e5:	test   %edx,%edx
   256e7:	jne    2733e <_RNvCseJ3uQ9fe193_12runtime_text4main+0x442e>
   256ed:	add    %rcx,%rax
   256f0:	add    $0x10,%rax
   256f4:	add    $0x10,%rcx
   256f8:	mov    0x10(%rsp),%rdx
   256fd:	jmp    2568e <_RNvCseJ3uQ9fe193_12runtime_text4main+0x277e>
   256ff:	mov    -0x8(%rsi),%rax
   25703:	mov    %rax,0x20(%rsp)
   25708:	mov    $0x4,%edx
   2570d:	mov    %r13,%rdi
   25710:	lea    -0x18393(%rip),%rsi        # d384 <anon.ed156775cc2f3392bb82488487d1de8d.21.llvm.4912082265219229507+0x18>
   25717:	call   293f0 <_RINvYNtNtNtCs9k3SxhrAWiO_3std4hash6random11RandomStateNtNtCsgxBkk5gSRhY_4core4hash11BuildHasher8hash_oneReECseJ3uQ9fe193_12runtime_text>
   2571c:	mov    %rax,%rcx
   2571f:	shr    $0x39,%rcx
   25723:	movd   %ecx,%xmm0
   25727:	punpcklbw %xmm0,%xmm0
   2572b:	pshuflw $0x0,%xmm0,%xmm0
   25730:	pshufd $0x44,%xmm0,%xmm0
   25735:	xor    %ecx,%ecx
   25737:	and    %r15,%rax
   2573a:	mov    0x10(%rsp),%rdx
   2573f:	movdqu (%rdx,%rax,1),%xmm1
   25744:	movdqa %xmm1,%xmm2
   25748:	pcmpeqb %xmm0,%xmm2
   2574c:	pmovmskb %xmm2,%edx
   25750:	test   %edx,%edx
   25752:	je     25787 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x2877>
   25754:	tzcnt  %edx,%edi
   25758:	add    %rax,%rdi
   2575b:	and    %r15,%rdi
   2575e:	shl    $0x5,%rdi
   25762:	mov    0x10(%rsp),%rsi
   25767:	sub    %rdi,%rsi
   2576a:	cmpq   $0x4,-0x10(%rsi)
   2576f:	jne    2577d <_RNvCseJ3uQ9fe193_12runtime_text4main+0x286d>
   25771:	mov    -0x18(%rsi),%rdi
   25775:	cmpl   $0x74736577,(%rdi)
   2577b:	je     257a8 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x2898>
   2577d:	lea    -0x1(%rdx),%esi
   25780:	and    %dx,%si
   25783:	mov    %esi,%edx
   25785:	jne    25754 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x2844>
   25787:	pcmpeqd %xmm2,%xmm2
   2578b:	pcmpeqb %xmm2,%xmm1
   2578f:	pmovmskb %xmm1,%edx
   25793:	test   %edx,%edx
   25795:	jne    27656 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4746>
   2579b:	add    %rcx,%rax
   2579e:	add    $0x10,%rax
   257a2:	add    $0x10,%rcx
   257a6:	jmp    25737 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x2827>
   257a8:	mov    -0x8(%rsi),%rax
   257ac:	mov    %rax,0x68(%rsp)
   257b1:	mov    $0x5,%edx
   257b6:	mov    %r13,%rdi
   257b9:	lea    -0x183d0(%rip),%rsi        # d3f0 <anon.c41b9569d3e50f51ac9d11be340d2ec5.16.llvm.16118886657712379284+0x28>
   257c0:	call   293f0 <_RINvYNtNtNtCs9k3SxhrAWiO_3std4hash6random11RandomStateNtNtCsgxBkk5gSRhY_4core4hash11BuildHasher8hash_oneReECseJ3uQ9fe193_12runtime_text>
   257c5:	mov    %rax,%rcx
   257c8:	shr    $0x39,%rcx
   257cc:	movd   %ecx,%xmm0
   257d0:	punpcklbw %xmm0,%xmm0
   257d4:	pshuflw $0x0,%xmm0,%xmm0
   257d9:	pshufd $0x44,%xmm0,%xmm0
   257de:	xor    %ecx,%ecx
   257e0:	and    %r15,%rax
   257e3:	mov    0x10(%rsp),%r10
   257e8:	movdqu (%r10,%rax,1),%xmm1
   257ee:	movdqa %xmm1,%xmm2
   257f2:	pcmpeqb %xmm0,%xmm2
   257f6:	pmovmskb %xmm2,%edx
   257fa:	test   %edx,%edx
   257fc:	je     2583f <_RNvCseJ3uQ9fe193_12runtime_text4main+0x292f>
   257fe:	tzcnt  %edx,%edi
   25802:	add    %rax,%rdi
   25805:	and    %r15,%rdi
   25808:	shl    $0x5,%rdi
   2580c:	mov    %r10,%rsi
   2580f:	sub    %rdi,%rsi
   25812:	cmpq   $0x5,-0x10(%rsi)
   25817:	jne    25835 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x2925>
   25819:	mov    -0x18(%rsi),%rdi
   2581d:	mov    (%rdi),%r8d
   25820:	mov    $0x74726f6e,%r9d
   25826:	xor    %r9d,%r8d
   25829:	movzbl 0x4(%rdi),%edi
   2582d:	xor    $0x68,%edi
   25830:	or     %r8d,%edi
   25833:	je     25860 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x2950>
   25835:	lea    -0x1(%rdx),%esi
   25838:	and    %dx,%si
   2583b:	mov    %esi,%edx
   2583d:	jne    257fe <_RNvCseJ3uQ9fe193_12runtime_text4main+0x28ee>
   2583f:	pcmpeqd %xmm2,%xmm2
   25843:	pcmpeqb %xmm2,%xmm1
   25847:	pmovmskb %xmm1,%edx
   2584b:	test   %edx,%edx
   2584d:	jne    2777a <_RNvCseJ3uQ9fe193_12runtime_text4main+0x486a>
   25853:	add    %rcx,%rax
   25856:	add    $0x10,%rax
   2585a:	add    $0x10,%rcx
   2585e:	jmp    257e0 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x28d0>
   25860:	mov    -0x8(%rsi),%r13
   25864:	test   %r15,%r15
   25867:	je     2592f <_RNvCseJ3uQ9fe193_12runtime_text4main+0x2a1f>
   2586d:	mov    %r13,0x1b8(%rsp)
   25875:	movdqa (%r10),%xmm0
   2587a:	lea    0x10(%r10),%rbp
   2587e:	mov    %r10,%r12
   25881:	pmovmskb %xmm0,%r13d
   25886:	not    %r13d
   25889:	jmp    258a2 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x2992>
   2588b:	nopl   0x0(%rax,%rax,1)
   25890:	dec    %rbx
   25893:	lea    -0x1(%r13),%eax
   25897:	and    %r13d,%eax
   2589a:	mov    %eax,%r13d
   2589d:	test   %rbx,%rbx
   258a0:	je     258f3 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x29e3>
   258a2:	test   %r13w,%r13w
   258a6:	jne    258ce <_RNvCseJ3uQ9fe193_12runtime_text4main+0x29be>
   258a8:	nopl   0x0(%rax,%rax,1)
   258b0:	movdqa 0x0(%rbp),%xmm0
   258b5:	add    $0xfffffffffffffe00,%r12
   258bc:	add    $0x10,%rbp
   258c0:	pmovmskb %xmm0,%r13d
   258c5:	xor    $0xffff,%r13d
   258cc:	je     258b0 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x29a0>
   258ce:	tzcnt  %r13d,%ecx
   258d3:	shl    $0x5,%ecx
   258d6:	mov    %r12,%rax
   258d9:	sub    %rcx,%rax
   258dc:	mov    -0x20(%rax),%rsi
   258e0:	test   %rsi,%rsi
   258e3:	je     25890 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x2980>
   258e5:	mov    -0x18(%rax),%rdi
   258e9:	mov    $0x1,%edx
   258ee:	call   *%r14
   258f1:	jmp    25890 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x2980>
   258f3:	mov    %r15,%rax
   258f6:	shl    $0x5,%rax
   258fa:	add    %rax,%r15
   258fd:	add    $0x31,%r15
   25901:	mov    $0x4,%r12d
   25907:	mov    0x5c862(%rip),%rbp        # 82170 <_DYNAMIC+0x248>
   2590e:	mov    0x10(%rsp),%rdi
   25913:	mov    0x1b8(%rsp),%r13
   2591b:	je     2592f <_RNvCseJ3uQ9fe193_12runtime_text4main+0x2a1f>
   2591d:	sub    %rax,%rdi
   25920:	add    $0xffffffffffffffe0,%rdi
   25924:	mov    $0x10,%edx
   25929:	mov    %r15,%rsi
   2592c:	call   *%r14
   2592f:	lea    0x0(,%r13,2),%rax
   25937:	add    %r13,%rax
   2593a:	mov    0x60(%rsp),%rcx
   2593f:	add    (%rsp),%rcx
   25943:	mov    0x8(%rsp),%rdx
   25948:	add    0x28(%rsp),%rdx
   2594d:	add    %rcx,%rdx
   25950:	add    0x20(%rsp),%rdx
   25955:	mov    0x68(%rsp),%rcx
   2595a:	lea    (%rdx,%rcx,2),%rcx
   2595e:	add    %rax,%rcx
   25961:	mov    %rcx,%rax
   25964:	movabs $0x89705f3112a28fe5,%rdx
   2596e:	imul   %rdx
   25971:	add    %rcx,%rdx
   25974:	mov    %rdx,%rax
   25977:	shr    $0x3f,%rax
   2597b:	sar    $0x1d,%rdx
   2597f:	add    %rax,%rdx
   25982:	imul   $0x3b9aca07,%rdx,%rax
   25989:	sub    %rax,%rcx
   2598c:	lea    0x3b9aca07(%rcx),%rax
   25993:	test   %rcx,%rcx
   25996:	cmovns %rcx,%rax
   2599a:	mov    %rax,(%rsp)
   2599e:	mov    0x78(%rsp),%rax
   259a3:	cmp    0x18(%rsp),%rax
   259a8:	mov    0x290(%rsp),%rax
   259b0:	mov    0x5c7c1(%rip),%rbx        # 82178 <_DYNAMIC+0x250>
   259b7:	jne    247d8 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x18c8>
   259bd:	mov    (%rsp),%rax
   259c1:	mov    %rax,0x30(%rsp)
   259c6:	lea    0x2a0(%rsp),%rdi
   259ce:	call   *0x5c7dc(%rip)        # 821b0 <_DYNAMIC+0x288>
   259d4:	mov    %edx,%ecx
   259d6:	mov    $0x3b9aca00,%edx
   259db:	mul    %rdx
   259de:	mov    %ecx,%ecx
   259e0:	add    %rax,%rcx
   259e3:	adc    $0x0,%rdx
   259e7:	mov    %rcx,0x120(%rsp)
   259ef:	mov    %rdx,0x128(%rsp)
   259f7:	lea    0x30(%rsp),%rax
   259fc:	mov    %rax,0x80(%rsp)
   25a04:	mov    0x5c77d(%rip),%rax        # 82188 <_DYNAMIC+0x260>
   25a0b:	mov    %rax,0x88(%rsp)
   25a13:	lea    0x120(%rsp),%rax
   25a1b:	mov    %rax,0x90(%rsp)
   25a23:	mov    0x5c78e(%rip),%rax        # 821b8 <_DYNAMIC+0x290>
   25a2a:	mov    %rax,0x98(%rsp)
   25a32:	lea    -0x1a3b1(%rip),%rdi        # b688 <anon.db448e2af9fdd3f56f054211eea53148.7.llvm.3520701504562932850+0x348>
   25a39:	lea    0x80(%rsp),%rsi
   25a41:	call   *0x5c779(%rip)        # 821c0 <_DYNAMIC+0x298>
   25a47:	lea    0x1c0(%rsp),%rdi
   25a4f:	call   22cf0 <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtCseJ3uQ9fe193_12runtime_text6InputsEBD_>
   25a54:	mov    0x248(%rsp),%rbx
   25a5c:	mov    0x250(%rsp),%r14
   25a64:	test   %r14,%r14
   25a67:	je     25a9f <_RNvCseJ3uQ9fe193_12runtime_text4main+0x2b8f>
   25a69:	lea    0x8(%rbx),%r15
   25a6d:	mov    0x5c6e4(%rip),%r12        # 82158 <_DYNAMIC+0x230>
   25a74:	jmp    25a89 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x2b79>
   25a76:	cs nopw 0x0(%rax,%rax,1)
   25a80:	add    $0x18,%r15
   25a84:	dec    %r14
   25a87:	je     25a9f <_RNvCseJ3uQ9fe193_12runtime_text4main+0x2b8f>
   25a89:	mov    -0x8(%r15),%rsi
   25a8d:	test   %rsi,%rsi
   25a90:	je     25a80 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x2b70>
   25a92:	mov    (%r15),%rdi
   25a95:	mov    $0x1,%edx
   25a9a:	call   *%r12
   25a9d:	jmp    25a80 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x2b70>
   25a9f:	mov    0x240(%rsp),%rax
   25aa7:	test   %rax,%rax
   25aaa:	je     25ac2 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x2bb2>
   25aac:	shl    $0x3,%rax
   25ab0:	lea    (%rax,%rax,2),%rsi
   25ab4:	mov    $0x8,%edx
   25ab9:	mov    %rbx,%rdi
   25abc:	call   *0x5c696(%rip)        # 82158 <_DYNAMIC+0x230>
   25ac2:	add    $0x2d8,%rsp
   25ac9:	pop    %rbx
   25aca:	pop    %r12
   25acc:	pop    %r13
   25ace:	pop    %r14
   25ad0:	pop    %r15
   25ad2:	pop    %rbp
   25ad3:	ret
   25ad4:	movabs $0x6a5f676e69727473,%rcx
   25ade:	xor    (%rax),%rcx
   25ae1:	movabs $0x6e696f6a5f676e69,%rdx
   25aeb:	xor    0x3(%rax),%rdx
   25aef:	or     %rcx,%rdx
   25af2:	jne    2791c <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4a0c>
   25af8:	mov    0x228(%rsp),%r14
   25b00:	mov    0x230(%rsp),%r15
   25b08:	movq   $0x0,(%rsp)
   25b10:	lea    0x80(%rsp),%r12
   25b18:	xor    %ebp,%ebp
   25b1a:	jmp    25b72 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x2c62>
   25b1c:	nopl   0x0(%rax)
   25b20:	inc    %rbp
   25b23:	add    (%rsp),%r13
   25b27:	add    %rbx,%r13
   25b2a:	mov    %r13,%rax
   25b2d:	movabs $0x89705f3112a28fe5,%rcx
   25b37:	imul   %rcx
   25b3a:	add    %r13,%rdx
   25b3d:	mov    %rdx,%rax
   25b40:	shr    $0x3f,%rax
   25b44:	sar    $0x1d,%rdx
   25b48:	add    %rax,%rdx
   25b4b:	imul   $0x3b9aca07,%rdx,%rax
   25b52:	sub    %rax,%r13
   25b55:	lea    0x3b9aca07(%r13),%rax
   25b5c:	test   %r13,%r13
   25b5f:	cmovns %r13,%rax
   25b63:	mov    %rax,(%rsp)
   25b67:	cmp    0x18(%rsp),%rbp
   25b6c:	je     259bd <_RNvCseJ3uQ9fe193_12runtime_text4main+0x2aad>
   25b72:	mov    0x10(%rsp),%rax
   25b77:	add    %ebp,%eax
   25b79:	and    $0x1,%eax
   25b7c:	lea    0x1(%rax),%r8
   25b80:	test   %eax,%eax
   25b82:	lea    -0x18775(%rip),%rcx        # d414 <anon.c41b9569d3e50f51ac9d11be340d2ec5.16.llvm.16118886657712379284+0x4c>
   25b89:	lea    -0x1877d(%rip),%rax        # d413 <anon.c41b9569d3e50f51ac9d11be340d2ec5.16.llvm.16118886657712379284+0x4b>
   25b90:	cmove  %rax,%rcx
   25b94:	mov    %r12,%rdi
   25b97:	mov    %r14,%rsi
   25b9a:	mov    %r15,%rdx
   25b9d:	call   29fa0 <_RINvNtCs6i54tJFfzR_5alloc3str17join_generic_copyehNtNtB4_6string6StringECseJ3uQ9fe193_12runtime_text>
   25ba2:	mov    0x88(%rsp),%rdi
   25baa:	mov    0x90(%rsp),%r13
   25bb2:	test   %r13,%r13
   25bb5:	je     25bd0 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x2cc0>
   25bb7:	mov    %r13d,%eax
   25bba:	and    $0x7,%eax
   25bbd:	cmp    $0x8,%r13
   25bc1:	jae    25be0 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x2cd0>
   25bc3:	xor    %ebx,%ebx
   25bc5:	mov    %rdi,%rcx
   25bc8:	jmp    25c3a <_RNvCseJ3uQ9fe193_12runtime_text4main+0x2d2a>
   25bca:	nopw   0x0(%rax,%rax,1)
   25bd0:	xor    %ebx,%ebx
   25bd2:	jmp    25c4f <_RNvCseJ3uQ9fe193_12runtime_text4main+0x2d3f>
   25bd4:	data16 data16 cs nopw 0x0(%rax,%rax,1)
   25be0:	mov    %r13,%rdx
   25be3:	and    $0xfffffffffffffff8,%rdx
   25be7:	xor    %ebx,%ebx
   25be9:	mov    %rdi,%rcx
   25bec:	nopl   0x0(%rax)
   25bf0:	movzbl (%rcx),%esi
   25bf3:	add    %rbx,%rsi
   25bf6:	movzbl 0x1(%rcx),%r8d
   25bfb:	movzbl 0x2(%rcx),%r9d
   25c00:	add    %r8,%r9
   25c03:	add    %rsi,%r9
   25c06:	movzbl 0x3(%rcx),%esi
   25c0a:	movzbl 0x4(%rcx),%r8d
   25c0f:	add    %rsi,%r8
   25c12:	movzbl 0x5(%rcx),%esi
   25c16:	add    %r8,%rsi
   25c19:	add    %r9,%rsi
   25c1c:	movzbl 0x6(%rcx),%r8d
   25c21:	movzbl 0x7(%rcx),%ebx
   25c25:	add    $0x8,%rcx
   25c29:	add    %r8,%rbx
   25c2c:	add    %rsi,%rbx
   25c2f:	add    $0xfffffffffffffff8,%rdx
   25c33:	jne    25bf0 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x2ce0>
   25c35:	test   %rax,%rax
   25c38:	je     25c4f <_RNvCseJ3uQ9fe193_12runtime_text4main+0x2d3f>
   25c3a:	xor    %edx,%edx
   25c3c:	nopl   0x0(%rax)
   25c40:	movzbl (%rcx,%rdx,1),%esi
   25c44:	add    %rsi,%rbx
   25c47:	inc    %rdx
   25c4a:	cmp    %rdx,%rax
   25c4d:	jne    25c40 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x2d30>
   25c4f:	mov    0x80(%rsp),%rsi
   25c57:	test   %rsi,%rsi
   25c5a:	je     25b20 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x2c10>
   25c60:	mov    $0x1,%edx
   25c65:	call   *0x5c4ed(%rip)        # 82158 <_DYNAMIC+0x230>
   25c6b:	jmp    25b20 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x2c10>
   25c70:	movabs $0x655f676e69727473,%rcx
   25c7a:	xor    (%rax),%rcx
   25c7d:	mov    0x8(%rax),%edx
   25c80:	xor    $0x6c617571,%rdx
   25c87:	or     %rcx,%rdx
   25c8a:	je     270e1 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x41d1>
   25c90:	movabs $0x735f676e69727473,%rcx
   25c9a:	xor    (%rax),%rcx
   25c9d:	mov    0x8(%rax),%eax
   25ca0:	xor    $0x74696c70,%rax
   25ca6:	or     %rcx,%rax
   25ca9:	jne    2791c <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4a0c>
   25caf:	mov    0x1e0(%rsp),%r14
   25cb7:	mov    0x1e8(%rsp),%rax
   25cbf:	mov    %rax,0x8(%rsp)
   25cc4:	movq   $0x0,(%rsp)
   25ccc:	lea    0x5965d(%rip),%rax        # 7f330 <__frame_dummy_init_array_entry+0x150>
   25cd3:	mov    %rax,0x70(%rsp)
   25cd8:	lea    0x80(%rsp),%rbx
   25ce0:	xor    %r15d,%r15d
   25ce3:	jmp    25d71 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x2e61>
   25ce8:	xor    %ebp,%ebp
   25cea:	nopw   0x0(%rax,%rax,1)
   25cf0:	mov    0x120(%rsp),%rsi
   25cf8:	test   %rsi,%rsi
   25cfb:	je     25d0c <_RNvCseJ3uQ9fe193_12runtime_text4main+0x2dfc>
   25cfd:	shl    $0x4,%rsi
   25d01:	mov    $0x8,%edx
   25d06:	call   *0x5c44c(%rip)        # 82158 <_DYNAMIC+0x230>
   25d0c:	lea    0x0(,%r12,8),%rcx
   25d14:	add    %rbp,%rcx
   25d17:	sub    %r12,%rcx
   25d1a:	add    (%rsp),%rcx
   25d1e:	inc    %r15
   25d21:	mov    %rcx,%rax
   25d24:	movabs $0x89705f3112a28fe5,%rdx
   25d2e:	imul   %rdx
   25d31:	add    %rcx,%rdx
   25d34:	mov    %rdx,%rax
   25d37:	shr    $0x3f,%rax
   25d3b:	sar    $0x1d,%rdx
   25d3f:	add    %rax,%rdx
   25d42:	imul   $0x3b9aca07,%rdx,%rax
   25d49:	sub    %rax,%rcx
   25d4c:	lea    0x3b9aca07(%rcx),%rax
   25d53:	test   %rcx,%rcx
   25d56:	cmovns %rcx,%rax
   25d5a:	mov    %rax,(%rsp)
   25d5e:	cmp    0x18(%rsp),%r15
   25d63:	lea    0x80(%rsp),%rbx
   25d6b:	je     259bd <_RNvCseJ3uQ9fe193_12runtime_text4main+0x2aad>
   25d71:	mov    0x10(%rsp),%rax
   25d76:	lea    (%r15,%rax,1),%edi
   25d7a:	and    $0x1,%edi
   25d7d:	cmp    0x8(%rsp),%rdi
   25d82:	jae    27a63 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4b53>
   25d88:	lea    (%rdi,%rdi,2),%rax
   25d8c:	mov    0x8(%r14,%rax,8),%rsi
   25d91:	mov    0x10(%r14,%rax,8),%r12
   25d96:	test   %rdi,%rdi
   25d99:	jne    25ee0 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x2fd0>
   25d9f:	mov    $0x1,%r8d
   25da5:	mov    %rbx,%rdi
   25da8:	mov    %r12,%rdx
   25dab:	lea    -0x1899f(%rip),%rcx        # d413 <anon.c41b9569d3e50f51ac9d11be340d2ec5.16.llvm.16118886657712379284+0x4b>
   25db2:	call   *0x5c410(%rip)        # 821c8 <_DYNAMIC+0x2a0>
   25db8:	movq   $0x0,0xe8(%rsp)
   25dc4:	mov    %r12,0xf0(%rsp)
   25dcc:	movw   $0x1,0xf8(%rsp)
   25dd6:	lea    0x120(%rsp),%rdi
   25dde:	mov    %rbx,%rsi
   25de1:	call   32fc0 <_RNvXNtNtCs6i54tJFfzR_5alloc3vec21spec_from_iter_nestedINtB4_3VecReEINtB2_18SpecFromIterNestedB10_INtNtNtCsgxBkk5gSRhY_4core3str4iter5SplitB10_EE9from_iterCseJ3uQ9fe193_12runtime_text>
   25de6:	mov    0x130(%rsp),%r12
   25dee:	mov    0x128(%rsp),%rdi
   25df6:	test   %r12,%r12
   25df9:	je     25ce8 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x2dd8>
   25dff:	mov    %r12,%rax
   25e02:	shl    $0x4,%rax
   25e06:	add    %rdi,%rax
   25e09:	xor    %ebp,%ebp
   25e0b:	mov    %rdi,%rcx
   25e0e:	jmp    25e26 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x2f16>
   25e10:	xor    %r9d,%r9d
   25e13:	add    $0x10,%rcx
   25e17:	add    %rdx,%rbp
   25e1a:	add    %r9,%rbp
   25e1d:	cmp    %rax,%rcx
   25e20:	je     25cf0 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x2de0>
   25e26:	mov    0x8(%rcx),%rdx
   25e2a:	test   %rdx,%rdx
   25e2d:	je     25e10 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x2f00>
   25e2f:	mov    (%rcx),%rsi
   25e32:	mov    %edx,%r8d
   25e35:	and    $0x7,%r8d
   25e39:	cmp    $0x8,%rdx
   25e3d:	jae    25e50 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x2f40>
   25e3f:	xor    %r9d,%r9d
   25e42:	jmp    25eb1 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x2fa1>
   25e44:	data16 data16 cs nopw 0x0(%rax,%rax,1)
   25e50:	mov    %rdx,%r10
   25e53:	and    $0xfffffffffffffff8,%r10
   25e57:	xor    %r9d,%r9d
   25e5a:	nopw   0x0(%rax,%rax,1)
   25e60:	movzbl (%rsi),%r11d
   25e64:	add    %r9,%r11
   25e67:	movzbl 0x1(%rsi),%r9d
   25e6c:	movzbl 0x2(%rsi),%ebx
   25e70:	add    %r9,%rbx
   25e73:	add    %r11,%rbx
   25e76:	movzbl 0x3(%rsi),%r9d
   25e7b:	movzbl 0x4(%rsi),%r11d
   25e80:	add    %r9,%r11
   25e83:	movzbl 0x5(%rsi),%r13d
   25e88:	add    %r11,%r13
   25e8b:	add    %rbx,%r13
   25e8e:	movzbl 0x6(%rsi),%r11d
   25e93:	movzbl 0x7(%rsi),%r9d
   25e98:	add    $0x8,%rsi
   25e9c:	add    %r11,%r9
   25e9f:	add    %r13,%r9
   25ea2:	add    $0xfffffffffffffff8,%r10
   25ea6:	jne    25e60 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x2f50>
   25ea8:	test   %r8,%r8
   25eab:	je     25e13 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x2f03>
   25eb1:	xor    %r10d,%r10d
   25eb4:	data16 data16 cs nopw 0x0(%rax,%rax,1)
   25ec0:	movzbl (%rsi,%r10,1),%r11d
   25ec5:	add    %r11,%r9
   25ec8:	inc    %r10
   25ecb:	cmp    %r10,%r8
   25ece:	jne    25ec0 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x2fb0>
   25ed0:	jmp    25e13 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x2f03>
   25ed5:	data16 cs nopw 0x0(%rax,%rax,1)
   25ee0:	mov    $0x2,%r8d
   25ee6:	mov    %rbx,%rdi
   25ee9:	mov    %r12,%rdx
   25eec:	lea    -0x18adf(%rip),%rcx        # d414 <anon.c41b9569d3e50f51ac9d11be340d2ec5.16.llvm.16118886657712379284+0x4c>
   25ef3:	call   *0x5c2cf(%rip)        # 821c8 <_DYNAMIC+0x2a0>
   25ef9:	movq   $0x0,0xe8(%rsp)
   25f05:	mov    %r12,0xf0(%rsp)
   25f0d:	movw   $0x1,0xf8(%rsp)
   25f17:	lea    0x120(%rsp),%rdi
   25f1f:	mov    %rbx,%rsi
   25f22:	call   32fc0 <_RNvXNtNtCs6i54tJFfzR_5alloc3vec21spec_from_iter_nestedINtB4_3VecReEINtB2_18SpecFromIterNestedB10_INtNtNtCsgxBkk5gSRhY_4core3str4iter5SplitB10_EE9from_iterCseJ3uQ9fe193_12runtime_text>
   25f27:	mov    0x130(%rsp),%r12
   25f2f:	mov    0x128(%rsp),%rdi
   25f37:	test   %r12,%r12
   25f3a:	je     26025 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x3115>
   25f40:	mov    %r12,%rax
   25f43:	shl    $0x4,%rax
   25f47:	add    %rdi,%rax
   25f4a:	xor    %ebp,%ebp
   25f4c:	mov    %rdi,%rcx
   25f4f:	jmp    25f76 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x3066>
   25f51:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   25f60:	xor    %r9d,%r9d
   25f63:	add    $0x10,%rcx
   25f67:	add    %rdx,%rbp
   25f6a:	add    %r9,%rbp
   25f6d:	cmp    %rax,%rcx
   25f70:	je     25cf0 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x2de0>
   25f76:	mov    0x8(%rcx),%rdx
   25f7a:	test   %rdx,%rdx
   25f7d:	je     25f60 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x3050>
   25f7f:	mov    (%rcx),%rsi
   25f82:	mov    %edx,%r8d
   25f85:	and    $0x7,%r8d
   25f89:	cmp    $0x8,%rdx
   25f8d:	jae    25fa0 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x3090>
   25f8f:	xor    %r9d,%r9d
   25f92:	jmp    26001 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x30f1>
   25f94:	data16 data16 cs nopw 0x0(%rax,%rax,1)
   25fa0:	mov    %rdx,%r10
   25fa3:	and    $0xfffffffffffffff8,%r10
   25fa7:	xor    %r9d,%r9d
   25faa:	nopw   0x0(%rax,%rax,1)
   25fb0:	movzbl (%rsi),%r11d
   25fb4:	add    %r9,%r11
   25fb7:	movzbl 0x1(%rsi),%r9d
   25fbc:	movzbl 0x2(%rsi),%ebx
   25fc0:	add    %r9,%rbx
   25fc3:	add    %r11,%rbx
   25fc6:	movzbl 0x3(%rsi),%r9d
   25fcb:	movzbl 0x4(%rsi),%r11d
   25fd0:	add    %r9,%r11
   25fd3:	movzbl 0x5(%rsi),%r13d
   25fd8:	add    %r11,%r13
   25fdb:	add    %rbx,%r13
   25fde:	movzbl 0x6(%rsi),%r11d
   25fe3:	movzbl 0x7(%rsi),%r9d
   25fe8:	add    $0x8,%rsi
   25fec:	add    %r11,%r9
   25fef:	add    %r13,%r9
   25ff2:	add    $0xfffffffffffffff8,%r10
   25ff6:	jne    25fb0 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x30a0>
   25ff8:	test   %r8,%r8
   25ffb:	je     25f63 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x3053>
   26001:	xor    %r10d,%r10d
   26004:	data16 data16 cs nopw 0x0(%rax,%rax,1)
   26010:	movzbl (%rsi,%r10,1),%r11d
   26015:	add    %r11,%r9
   26018:	inc    %r10
   2601b:	cmp    %r10,%r8
   2601e:	jne    26010 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x3100>
   26020:	jmp    25f63 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x3053>
   26025:	xor    %ebp,%ebp
   26027:	mov    0x120(%rsp),%rsi
   2602f:	test   %rsi,%rsi
   26032:	jne    25cfd <_RNvCseJ3uQ9fe193_12runtime_text4main+0x2ded>
   26038:	jmp    25d0c <_RNvCseJ3uQ9fe193_12runtime_text4main+0x2dfc>
   2603d:	movabs $0x63735f7365747962,%rcx
   26047:	xor    (%rax),%rcx
   2604a:	movzwl 0x8(%rax),%edx
   2604e:	xor    $0x6e61,%rdx
   26055:	or     %rcx,%rdx
   26058:	je     271bb <_RNvCseJ3uQ9fe193_12runtime_text4main+0x42ab>
   2605e:	movabs $0x6d726f665f746e69,%rcx
   26068:	xor    (%rax),%rcx
   2606b:	movzwl 0x8(%rax),%edx
   2606f:	xor    $0x7461,%rdx
   26076:	or     %rcx,%rdx
   26079:	je     2734a <_RNvCseJ3uQ9fe193_12runtime_text4main+0x443a>
   2607f:	movabs $0x756f635f64726f77,%rcx
   26089:	xor    (%rax),%rcx
   2608c:	movzwl 0x8(%rax),%eax
   26090:	xor    $0x746e,%rax
   26096:	or     %rcx,%rax
   26099:	jne    2791c <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4a0c>
   2609f:	mov    0x1e0(%rsp),%rax
   260a7:	mov    %rax,0x1b8(%rsp)
   260af:	mov    0x1e8(%rsp),%rax
   260b7:	mov    %rax,0x8(%rsp)
   260bc:	movq   $0x0,(%rsp)
   260c4:	lea    0x5921d(%rip),%rax        # 7f2e8 <__frame_dummy_init_array_entry+0x108>
   260cb:	mov    %rax,0x70(%rsp)
   260d0:	mov    $0xffffffffffffffd8,%rbx
   260d7:	lea    0x80(%rsp),%r13
   260df:	movabs $0x100003600,%rbp
   260e9:	xor    %ecx,%ecx
   260eb:	jmp    26148 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x3238>
   260ed:	nopl   (%rax)
   260f0:	add    (%rsp),%r15
   260f4:	mov    %r15,%rax
   260f7:	movabs $0x89705f3112a28fe5,%rcx
   26101:	imul   %rcx
   26104:	add    %r15,%rdx
   26107:	mov    %rdx,%rax
   2610a:	shr    $0x3f,%rax
   2610e:	sar    $0x1d,%rdx
   26112:	add    %rax,%rdx
   26115:	imul   $0x3b9aca07,%rdx,%rax
   2611c:	sub    %rax,%r15
   2611f:	lea    0x3b9aca07(%r15),%rax
   26126:	test   %r15,%r15
   26129:	cmovns %r15,%rax
   2612d:	mov    %rax,(%rsp)
   26131:	mov    0x20(%rsp),%rcx
   26136:	cmp    0x18(%rsp),%rcx
   2613b:	mov    $0xffffffffffffffd8,%rbx
   26142:	je     259bd <_RNvCseJ3uQ9fe193_12runtime_text4main+0x2aad>
   26148:	mov    0x10(%rsp),%rax
   2614d:	mov    %rcx,0x20(%rsp)
   26152:	lea    (%rcx,%rax,1),%edi
   26155:	and    $0x1,%edi
   26158:	cmp    0x8(%rsp),%rdi
   2615d:	jae    27a63 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4b53>
   26163:	lea    (%rdi,%rdi,2),%rax
   26167:	mov    0x1b8(%rsp),%rcx
   2616f:	mov    0x8(%rcx,%rax,8),%r14
   26174:	mov    0x10(%rcx,%rax,8),%r15
   26179:	cmpb   $0x1,%fs:0x10(%rbx)
   2617e:	jne    2656c <_RNvCseJ3uQ9fe193_12runtime_text4main+0x365c>
   26184:	mov    %fs:(%rbx),%rax
   26188:	mov    %fs:0x8(%rbx),%rdx
   2618d:	incq   0x20(%rsp)
   26192:	lea    0x1(%rax),%rcx
   26196:	mov    %rcx,%fs:(%rbx)
   2619a:	movups 0x592df(%rip),%xmm0        # 7f480 <__frame_dummy_init_array_entry+0x2a0>
   261a1:	movaps %xmm0,0x80(%rsp)
   261a9:	movdqu 0x592df(%rip),%xmm0        # 7f490 <__frame_dummy_init_array_entry+0x2b0>
   261b1:	movdqa %xmm0,0x90(%rsp)
   261ba:	mov    %rax,0xa0(%rsp)
   261c2:	mov    %rdx,0xa8(%rsp)
   261ca:	xor    %r12d,%r12d
   261cd:	mov    %r15,%rax
   261d0:	mov    %r14,%rdi
   261d3:	xor    %esi,%esi
   261d5:	lea    0x120(%rsp),%rbx
   261dd:	jmp    261f5 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x32e5>
   261df:	nop
   261e0:	mov    0x128(%rsp),%rax
   261e8:	incq   -0x8(%rax)
   261ec:	mov    %r15,%rax
   261ef:	mov    %r14,%rdi
   261f2:	mov    %r12d,%esi
   261f5:	test   $0x1,%sil
   261f9:	jne    26380 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x3470>
   261ff:	mov    %rdi,%rdx
   26202:	mov    $0x1,%sil
   26205:	test   %rax,%rax
   26208:	je     26250 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x3340>
   2620a:	xor    %ecx,%ecx
   2620c:	jmp    26218 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x3308>
   2620e:	xchg   %ax,%ax
   26210:	inc    %rcx
   26213:	cmp    %rcx,%rax
   26216:	je     26261 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x3351>
   26218:	movzbl (%rdx,%rcx,1),%edi
   2621c:	cmp    $0x20,%rdi
   26220:	ja     26210 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x3300>
   26222:	bt     %rdi,%rbp
   26226:	jae    26210 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x3300>
   26228:	mov    %rcx,%r15
   2622b:	not    %r15
   2622e:	add    %rax,%r15
   26231:	lea    (%rdx,%rcx,1),%r14
   26235:	inc    %r14
   26238:	xor    %esi,%esi
   2623a:	mov    %r15,%rax
   2623d:	mov    %r14,%rdi
   26240:	test   %rcx,%rcx
   26243:	jne    26270 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x3360>
   26245:	jmp    261f5 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x32e5>
   26247:	nopw   0x0(%rax,%rax,1)
   26250:	mov    $0x1,%r12b
   26253:	xor    %eax,%eax
   26255:	mov    %rdx,%rdi
   26258:	xor    %ecx,%ecx
   2625a:	test   %rcx,%rcx
   2625d:	jne    26270 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x3360>
   2625f:	jmp    261f5 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x32e5>
   26261:	mov    $0x1,%r12b
   26264:	mov    %rdx,%rdi
   26267:	mov    %rax,%rcx
   2626a:	test   %rcx,%rcx
   2626d:	je     261f5 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x32e5>
   2626f:	nop
   26270:	mov    %rbx,%rdi
   26273:	mov    %r13,%rsi
   26276:	call   29810 <_RNvMNtCsfBDUjroi3FF_9hashbrown11rustc_entryINtNtB4_3map7HashMapRexNtNtNtCs9k3SxhrAWiO_3std4hash6random11RandomStateE11rustc_entryCseJ3uQ9fe193_12runtime_text>
   2627b:	mov    0x120(%rsp),%rcx
   26283:	test   %rcx,%rcx
   26286:	je     261e0 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x32d0>
   2628c:	mov    0x130(%rsp),%rax
   26294:	mov    0x138(%rsp),%rsi
   2629c:	mov    (%rax),%rdx
   2629f:	mov    0x8(%rax),%rdi
   262a3:	mov    %rdi,%r8
   262a6:	and    %rsi,%r8
   262a9:	movdqu (%rdx,%r8,1),%xmm0
   262af:	pmovmskb %xmm0,%r9d
   262b4:	test   %r9d,%r9d
   262b7:	je     26338 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x3428>
   262b9:	tzcnt  %r9d,%r9d
   262be:	add    %r8,%r9
   262c1:	and    %rdi,%r9
   262c4:	movzbl (%rdx,%r9,1),%r8d
   262c9:	test   %r8b,%r8b
   262cc:	jns    2635e <_RNvCseJ3uQ9fe193_12runtime_text4main+0x344e>
   262d2:	mov    0x128(%rsp),%r10
   262da:	shr    $0x39,%rsi
   262de:	lea    -0x10(%r9),%r11
   262e2:	and    %rdi,%r11
   262e5:	mov    %sil,(%rdx,%r9,1)
   262e9:	mov    %sil,0x10(%rdx,%r11,1)
   262ee:	neg    %r9
   262f1:	lea    (%r9,%r9,2),%rsi
   262f5:	lea    (%rdx,%rsi,8),%rdi
   262f9:	and    $0x1,%r8b
   262fd:	mov    %rcx,-0x18(%rdx,%rsi,8)
   26302:	mov    %r10,-0x10(%rdx,%rsi,8)
   26307:	movq   $0x0,-0x8(%rdx,%rsi,8)
   26310:	movdqu 0x10(%rax),%xmm0
   26315:	movzbl %r8b,%ecx
   26319:	movd   %ecx,%xmm1
   2631d:	shufpd $0x2,-0x1af96(%rip),%xmm1        # b390 <anon.db448e2af9fdd3f56f054211eea53148.7.llvm.3520701504562932850+0x50>
   26326:	psubq  %xmm1,%xmm0
   2632a:	movdqu %xmm0,0x10(%rax)
   2632f:	incq   -0x8(%rdi)
   26333:	jmp    261ec <_RNvCseJ3uQ9fe193_12runtime_text4main+0x32dc>
   26338:	mov    $0x10,%r10d
   2633e:	add    %r10,%r8
   26341:	and    %rdi,%r8
   26344:	movdqu (%rdx,%r8,1),%xmm0
   2634a:	pmovmskb %xmm0,%r9d
   2634f:	add    $0x10,%r10
   26353:	test   %r9d,%r9d
   26356:	jne    262b9 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x33a9>
   2635c:	jmp    2633e <_RNvCseJ3uQ9fe193_12runtime_text4main+0x342e>
   2635e:	movdqa (%rdx),%xmm0
   26362:	pmovmskb %xmm0,%r8d
   26367:	tzcnt  %r8d,%r9d
   2636c:	movzbl (%rdx,%r9,1),%r8d
   26371:	jmp    262d2 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x33c2>
   26376:	cs nopw 0x0(%rax,%rax,1)
   26380:	mov    0x80(%rsp),%rcx
   26388:	mov    0x88(%rsp),%rdx
   26390:	test   %rdx,%rdx
   26393:	mov    %rdx,0x78(%rsp)
   26398:	je     26520 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x3610>
   2639e:	lea    (%rdx,%rdx,2),%rax
   263a2:	lea    0x27(,%rax,8),%rax
   263aa:	and    $0xfffffffffffffff0,%rax
   263ae:	add    %rax,%rdx
   263b1:	add    $0x11,%rdx
   263b5:	mov    %rdx,0x60(%rsp)
   263ba:	mov    %rcx,%rdx
   263bd:	sub    %rax,%rdx
   263c0:	mov    %rdx,0x28(%rsp)
   263c5:	mov    $0x10,%eax
   263ca:	mov    %rax,0x68(%rsp)
   263cf:	mov    0x98(%rsp),%r8
   263d7:	test   %r8,%r8
   263da:	je     2653a <_RNvCseJ3uQ9fe193_12runtime_text4main+0x362a>
   263e0:	movdqa (%rcx),%xmm0
   263e4:	pmovmskb %xmm0,%ebx
   263e8:	not    %ebx
   263ea:	lea    0x10(%rcx),%r9
   263ee:	xor    %r15d,%r15d
   263f1:	jmp    26428 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x3518>
   263f3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   26400:	xor    %eax,%eax
   26402:	lea    -0x1(%r10),%ebx
   26406:	and    %r10d,%ebx
   26409:	dec    %r8
   2640c:	mov    -0x8(%rcx,%r11,8),%rsi
   26411:	add    %rdx,%rax
   26414:	imul   %rsi,%rsi
   26418:	imul   %rax,%rsi
   2641c:	add    %rsi,%r15
   2641f:	test   %r8,%r8
   26422:	je     2653d <_RNvCseJ3uQ9fe193_12runtime_text4main+0x362d>
   26428:	test   %bx,%bx
   2642b:	jne    2644c <_RNvCseJ3uQ9fe193_12runtime_text4main+0x353c>
   2642d:	nopl   (%rax)
   26430:	movdqa (%r9),%xmm0
   26435:	add    $0xfffffffffffffe80,%rcx
   2643c:	add    $0x10,%r9
   26440:	pmovmskb %xmm0,%ebx
   26444:	xor    $0xffff,%ebx
   2644a:	je     26430 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x3520>
   2644c:	mov    %ebx,%r10d
   2644f:	tzcnt  %r10d,%eax
   26454:	neg    %rax
   26457:	lea    (%rax,%rax,2),%r11
   2645b:	mov    -0x18(%rcx,%r11,8),%rbx
   26460:	test   %rbx,%rbx
   26463:	je     2653d <_RNvCseJ3uQ9fe193_12runtime_text4main+0x362d>
   26469:	mov    -0x10(%rcx,%r11,8),%rdx
   2646e:	test   %rdx,%rdx
   26471:	je     26400 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x34f0>
   26473:	mov    %edx,%r12d
   26476:	and    $0x7,%r12d
   2647a:	cmp    $0x8,%rdx
   2647e:	jae    26490 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x3580>
   26480:	xor    %eax,%eax
   26482:	jmp    264f8 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x35e8>
   26484:	data16 data16 cs nopw 0x0(%rax,%rax,1)
   26490:	mov    %r13,%rbp
   26493:	mov    %rdx,%r14
   26496:	and    $0xfffffffffffffff8,%r14
   2649a:	xor    %eax,%eax
   2649c:	nopl   0x0(%rax)
   264a0:	movzbl (%rbx),%esi
   264a3:	add    %rax,%rsi
   264a6:	movzbl 0x1(%rbx),%eax
   264aa:	movzbl 0x2(%rbx),%edi
   264ae:	add    %rax,%rdi
   264b1:	add    %rsi,%rdi
   264b4:	movzbl 0x3(%rbx),%eax
   264b8:	movzbl 0x4(%rbx),%esi
   264bc:	add    %rax,%rsi
   264bf:	movzbl 0x5(%rbx),%r13d
   264c4:	add    %rsi,%r13
   264c7:	add    %rdi,%r13
   264ca:	movzbl 0x6(%rbx),%esi
   264ce:	movzbl 0x7(%rbx),%eax
   264d2:	add    $0x8,%rbx
   264d6:	add    %rsi,%rax
   264d9:	add    %r13,%rax
   264dc:	add    $0xfffffffffffffff8,%r14
   264e0:	jne    264a0 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x3590>
   264e2:	test   %r12,%r12
   264e5:	mov    %rbp,%r13
   264e8:	movabs $0x100003600,%rbp
   264f2:	je     26402 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x34f2>
   264f8:	xor    %r14d,%r14d
   264fb:	nopl   0x0(%rax,%rax,1)
   26500:	movzbl (%rbx,%r14,1),%esi
   26505:	add    %rsi,%rax
   26508:	inc    %r14
   2650b:	cmp    %r14,%r12
   2650e:	jne    26500 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x35f0>
   26510:	jmp    26402 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x34f2>
   26515:	data16 cs nopw 0x0(%rax,%rax,1)
   26520:	movq   $0x0,0x68(%rsp)
   26529:	mov    0x98(%rsp),%r8
   26531:	test   %r8,%r8
   26534:	jne    263e0 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x34d0>
   2653a:	xor    %r15d,%r15d
   2653d:	cmpq   $0x0,0x78(%rsp)
   26543:	mov    0x60(%rsp),%rsi
   26548:	je     260f0 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x31e0>
   2654e:	test   %rsi,%rsi
   26551:	je     260f0 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x31e0>
   26557:	mov    0x28(%rsp),%rdi
   2655c:	mov    0x68(%rsp),%rdx
   26561:	call   *0x5bbf1(%rip)        # 82158 <_DYNAMIC+0x230>
   26567:	jmp    260f0 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x31e0>
   2656c:	call   *0x5bc5e(%rip)        # 821d0 <_DYNAMIC+0x2a8>
   26572:	mov    %rax,%fs:(%rbx)
   26576:	mov    %rdx,%fs:0x8(%rbx)
   2657b:	movb   $0x1,%fs:0x10(%rbx)
   26580:	jmp    2618d <_RNvCseJ3uQ9fe193_12runtime_text4main+0x327d>
   26585:	movabs $0x6172745f6e6f736a,%rcx
   2658f:	xor    (%rax),%rcx
   26592:	movabs $0x6d726f665f746e69,%rdx
   2659c:	add    $0x13f9f309,%rdx
   265a3:	xor    0x6(%rax),%rdx
   265a7:	or     %rcx,%rdx
   265aa:	jne    2791c <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4a0c>
   265b0:	cmpq   $0x0,0x1e8(%rsp)
   265b9:	je     27c03 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4cf3>
   265bf:	mov    0x1e0(%rsp),%rax
   265c7:	mov    %rax,0x8(%rsp)
   265cc:	movq   $0x0,(%rsp)
   265d4:	lea    0x120(%rsp),%rbx
   265dc:	xor    %r15d,%r15d
   265df:	jmp    26652 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x3742>
   265e1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   265f0:	inc    %r15
   265f3:	add    (%rsp),%r14
   265f7:	add    %rbx,%r14
   265fa:	mov    %r14,%rax
   265fd:	movabs $0x89705f3112a28fe5,%rcx
   26607:	imul   %rcx
   2660a:	add    %r14,%rdx
   2660d:	mov    %rdx,%rax
   26610:	shr    $0x3f,%rax
   26614:	sar    $0x1d,%rdx
   26618:	add    %rax,%rdx
   2661b:	imul   $0x3b9aca07,%rdx,%rax
   26622:	sub    %rax,%r14
   26625:	lea    0x3b9aca07(%r14),%rax
   2662c:	test   %r14,%r14
   2662f:	cmovns %r14,%rax
   26633:	mov    %rax,(%rsp)
   26637:	cmp    0x18(%rsp),%r15
   2663c:	lea    0x80(%rsp),%rbp
   26644:	lea    0x120(%rsp),%rbx
   2664c:	je     259bd <_RNvCseJ3uQ9fe193_12runtime_text4main+0x2aad>
   26652:	mov    0x10(%rsp),%rax
   26657:	lea    (%r15,%rax,1),%rcx
   2665b:	mov    0x8(%rsp),%rax
   26660:	movdqu 0x8(%rax),%xmm0
   26665:	mov    %rcx,%rax
   26668:	movabs $0xf0f0f0f0f0f0f0f1,%rdx
   26672:	mul    %rdx
   26675:	mov    %rdx,%rax
   26678:	and    $0xfffffffffffffff0,%rax
   2667c:	shr    $0x4,%rdx
   26680:	add    %rax,%rdx
   26683:	sub    %rdx,%rcx
   26686:	mov    %rcx,0x108(%rsp)
   2668e:	movdqu %xmm0,0x80(%rsp)
   26697:	movq   $0x0,0x90(%rsp)
   266a3:	mov    %rbx,%rdi
   266a6:	mov    %rbp,%rsi
   266a9:	call   2ea40 <_RINvNtCs1ZxogWZ17zb_10serde_json2de10from_traitNtNtB4_4read7StrReadINtNtCs6i54tJFfzR_5alloc3vec3VecNtNtB4_5value5ValueEECseJ3uQ9fe193_12runtime_text>
   266ae:	mov    0x120(%rsp),%rax
   266b6:	cmp    $0xffffffffffffffff,%rax
   266ba:	je     27890 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4980>
   266c0:	mov    0x128(%rsp),%rcx
   266c8:	mov    0x130(%rsp),%rdx
   266d0:	shl    $0x5,%rdx
   266d4:	add    %rcx,%rdx
   266d7:	mov    %rcx,0x80(%rsp)
   266df:	mov    %rcx,0x88(%rsp)
   266e7:	mov    %rax,0x90(%rsp)
   266ef:	mov    %rdx,0x98(%rsp)
   266f7:	lea    0x108(%rsp),%rax
   266ff:	mov    %rax,0xa0(%rsp)
   26707:	mov    %rbx,%rdi
   2670a:	mov    %rbp,%rsi
   2670d:	call   2aa20 <_RINvNtNtCs6i54tJFfzR_5alloc3vec16in_place_collect18from_iter_in_placeINtNtNtNtCsgxBkk5gSRhY_4core4iter8adapters3map3MapINtNtB1a_6filter6FilterINtNtB4_9into_iter8IntoIterNtNtCs1ZxogWZ17zb_10serde_json5value5ValueENCNvCseJ3uQ9fe193_12runtime_text8json_job0ENCB3q_s_0EB2H_EB3s_>
   26712:	call   *0x5ba58(%rip)        # 82170 <_DYNAMIC+0x248>
   26718:	mov    $0x80,%edi
   2671d:	mov    $0x1,%esi
   26722:	call   *0x5ba50(%rip)        # 82178 <_DYNAMIC+0x250>
   26728:	test   %rax,%rax
   2672b:	je     27a78 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4b68>
   26731:	movq   $0x80,0x80(%rsp)
   2673d:	mov    %rax,0x88(%rsp)
   26745:	movq   $0x0,0x90(%rsp)
   26751:	mov    %rbp,0x30(%rsp)
   26756:	lea    0x30(%rsp),%rdi
   2675b:	mov    %rbx,%rsi
   2675e:	call   29550 <_RINvYQINtNtCs1ZxogWZ17zb_10serde_json3ser10SerializerQINtNtCs6i54tJFfzR_5alloc3vec3VechEENtNtCsd8e2XcjHJpb_10serde_core3ser10Serializer11collect_seqRIBR_NtNtB9_5value5ValueEECseJ3uQ9fe193_12runtime_text>
   26763:	mov    %rax,%r13
   26766:	test   %rax,%rax
   26769:	jne    27a8d <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4b7d>
   2676f:	mov    0x80(%rsp),%rbp
   26777:	mov    0x88(%rsp),%r13
   2677f:	cmp    $0xffffffffffffffff,%rbp
   26783:	je     27aad <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4b9d>
   26789:	mov    0x90(%rsp),%r14
   26791:	test   %r14,%r14
   26794:	je     267b0 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x38a0>
   26796:	mov    %r14d,%eax
   26799:	and    $0x7,%eax
   2679c:	cmp    $0x8,%r14
   267a0:	jae    267c0 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x38b0>
   267a2:	xor    %ebx,%ebx
   267a4:	mov    %r13,%rcx
   267a7:	jmp    26817 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x3907>
   267a9:	nopl   0x0(%rax)
   267b0:	xor    %ebx,%ebx
   267b2:	jmp    2682f <_RNvCseJ3uQ9fe193_12runtime_text4main+0x391f>
   267b4:	data16 data16 cs nopw 0x0(%rax,%rax,1)
   267c0:	mov    %r14,%rdx
   267c3:	and    $0xfffffffffffffff8,%rdx
   267c7:	xor    %ebx,%ebx
   267c9:	mov    %r13,%rcx
   267cc:	nopl   0x0(%rax)
   267d0:	movzbl (%rcx),%esi
   267d3:	add    %rbx,%rsi
   267d6:	movzbl 0x1(%rcx),%edi
   267da:	movzbl 0x2(%rcx),%r8d
   267df:	add    %rdi,%r8
   267e2:	add    %rsi,%r8
   267e5:	movzbl 0x3(%rcx),%esi
   267e9:	movzbl 0x4(%rcx),%edi
   267ed:	add    %rsi,%rdi
   267f0:	movzbl 0x5(%rcx),%esi
   267f4:	add    %rdi,%rsi
   267f7:	add    %r8,%rsi
   267fa:	movzbl 0x6(%rcx),%edi
   267fe:	movzbl 0x7(%rcx),%ebx
   26802:	add    $0x8,%rcx
   26806:	add    %rdi,%rbx
   26809:	add    %rsi,%rbx
   2680c:	add    $0xfffffffffffffff8,%rdx
   26810:	jne    267d0 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x38c0>
   26812:	test   %rax,%rax
   26815:	je     2682f <_RNvCseJ3uQ9fe193_12runtime_text4main+0x391f>
   26817:	xor    %edx,%edx
   26819:	nopl   0x0(%rax)
   26820:	movzbl (%rcx,%rdx,1),%esi
   26824:	add    %rsi,%rbx
   26827:	inc    %rdx
   2682a:	cmp    %rdx,%rax
   2682d:	jne    26820 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x3910>
   2682f:	mov    0x128(%rsp),%r12
   26837:	mov    0x130(%rsp),%rsi
   2683f:	mov    %r12,%rdi
   26842:	call   32ad0 <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueSNtNtCs1ZxogWZ17zb_10serde_json5value5ValueECseJ3uQ9fe193_12runtime_text.llvm.889774890497533298>
   26847:	mov    0x120(%rsp),%rsi
   2684f:	test   %rsi,%rsi
   26852:	je     26866 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x3956>
   26854:	shl    $0x5,%rsi
   26858:	mov    $0x8,%edx
   2685d:	mov    %r12,%rdi
   26860:	call   *0x5b8f2(%rip)        # 82158 <_DYNAMIC+0x230>
   26866:	test   %rbp,%rbp
   26869:	je     265f0 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x36e0>
   2686f:	mov    $0x1,%edx
   26874:	mov    %r13,%rdi
   26877:	mov    %rbp,%rsi
   2687a:	call   *0x5b8d8(%rip)        # 82158 <_DYNAMIC+0x230>
   26880:	jmp    265f0 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x36e0>
   26885:	mov    0x138(%rsp),%rax
   2688d:	test   %rax,%rax
   26890:	je     268ad <_RNvCseJ3uQ9fe193_12runtime_text4main+0x399d>
   26892:	mov    0x140(%rsp),%rdi
   2689a:	shl    $0x3,%rax
   2689e:	lea    (%rax,%rax,2),%rsi
   268a2:	mov    $0x8,%edx
   268a7:	call   *0x5b8ab(%rip)        # 82158 <_DYNAMIC+0x230>
   268ad:	movq   $0x4,0x138(%rsp)
   268b9:	mov    %rbp,0x140(%rsp)
   268c1:	movq   $0x4,0x148(%rsp)
   268cd:	call   *0x5b89d(%rip)        # 82170 <_DYNAMIC+0x248>
   268d3:	mov    $0x60,%r14d
   268d9:	mov    $0x60,%edi
   268de:	mov    $0x8,%esi
   268e3:	call   *0x5b88f(%rip)        # 82178 <_DYNAMIC+0x250>
   268e9:	test   %rax,%rax
   268ec:	je     278cd <_RNvCseJ3uQ9fe193_12runtime_text4main+0x49bd>
   268f2:	mov    %rax,%r13
   268f5:	lea    -0x194e6(%rip),%rsi        # d416 <anon.c41b9569d3e50f51ac9d11be340d2ec5.16.llvm.16118886657712379284+0x4e>
   268fc:	lea    0x80(%rsp),%rdi
   26904:	mov    $0x1,%edx
   26909:	mov    %r15,%rcx
   2690c:	call   29660 <_RNvMNtCs6i54tJFfzR_5alloc5sliceSh6repeatCseJ3uQ9fe193_12runtime_text>
   26911:	mov    0x80(%rsp),%rax
   26919:	mov    %rax,(%rsp)
   2691d:	mov    0x88(%rsp),%rax
   26925:	mov    %rax,0x20(%rsp)
   2692a:	mov    0x90(%rsp),%rbx
   26932:	dec    %r15
   26935:	lea    -0x194bc(%rip),%rsi        # d480 <anon.c41b9569d3e50f51ac9d11be340d2ec5.16.llvm.16118886657712379284+0xb8>
   2693c:	lea    0x80(%rsp),%rdi
   26944:	mov    $0x2,%edx
   26949:	mov    %r15,%rcx
   2694c:	call   29660 <_RNvMNtCs6i54tJFfzR_5alloc5sliceSh6repeatCseJ3uQ9fe193_12runtime_text>
   26951:	mov    0x90(%rsp),%r14
   26959:	mov    %r14,0x1d0(%rsp)
   26961:	movdqu 0x80(%rsp),%xmm0
   2696a:	movdqa %xmm0,0x1c0(%rsp)
   26973:	mov    0x1c0(%rsp),%rcx
   2697b:	mov    %rcx,%rax
   2697e:	sub    %r14,%rax
   26981:	cmp    $0x1,%rax
   26985:	mov    %rbx,0x60(%rsp)
   2698a:	jbe    279c9 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4ab9>
   26990:	mov    %rcx,0x8(%rsp)
   26995:	mov    0x1c8(%rsp),%rax
   2699d:	mov    %rax,0x78(%rsp)
   269a2:	movw   $0xaac3,(%rax,%r14,1)
   269a9:	call   *0x5b7c1(%rip)        # 82170 <_DYNAMIC+0x248>
   269af:	mov    $0x1,%edi
   269b4:	mov    $0x1,%esi
   269b9:	call   *0x5b7b9(%rip)        # 82178 <_DYNAMIC+0x250>
   269bf:	test   %rax,%rax
   269c2:	je     27c48 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4d38>
   269c8:	mov    %rax,%rbp
   269cb:	movb   $0x62,(%rax)
   269ce:	movq   $0x1,0x1c0(%rsp)
   269da:	mov    %rax,0x1c8(%rsp)
   269e2:	movq   $0x1,0x1d0(%rsp)
   269ee:	lea    -0x195df(%rip),%rsi        # d416 <anon.c41b9569d3e50f51ac9d11be340d2ec5.16.llvm.16118886657712379284+0x4e>
   269f5:	lea    0x80(%rsp),%rdi
   269fd:	mov    $0x1,%r12d
   26a03:	mov    $0x1,%edx
   26a08:	mov    %r15,%rcx
   26a0b:	call   29660 <_RNvMNtCs6i54tJFfzR_5alloc5sliceSh6repeatCseJ3uQ9fe193_12runtime_text>
   26a10:	mov    0x80(%rsp),%rax
   26a18:	mov    %rax,0x68(%rsp)
   26a1d:	mov    0x88(%rsp),%rax
   26a25:	mov    %rax,0x28(%rsp)
   26a2a:	mov    0x90(%rsp),%r15
   26a32:	mov    $0x1,%ebx
   26a37:	test   %r15,%r15
   26a3a:	jne    27a03 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4af3>
   26a40:	lea    0x1a0(%rsp),%rax
   26a48:	mov    %rax,0x1c0(%rsp)
   26a50:	mov    0x5b731(%rip),%rax        # 82188 <_DYNAMIC+0x260>
   26a57:	mov    %rax,0x1c8(%rsp)
   26a5f:	lea    -0x1aee2(%rip),%rsi        # bb84 <anon.2c3024bf600baf6499788d207c16e381.4.llvm.166979056262668204+0x1bd>
   26a66:	lea    0x80(%rsp),%rdi
   26a6e:	lea    0x1c0(%rsp),%rdx
   26a76:	call   *0x5b714(%rip)        # 82190 <_DYNAMIC+0x268>
   26a7c:	add    $0x2,%r14
   26a80:	add    %r15,%rbx
   26a83:	mov    (%rsp),%rax
   26a87:	mov    %rax,0x0(%r13)
   26a8b:	mov    0x20(%rsp),%rax
   26a90:	mov    %rax,0x8(%r13)
   26a94:	mov    0x60(%rsp),%rax
   26a99:	mov    %rax,0x10(%r13)
   26a9d:	mov    0x8(%rsp),%rax
   26aa2:	mov    %rax,0x18(%r13)
   26aa6:	mov    0x78(%rsp),%rax
   26aab:	mov    %rax,0x20(%r13)
   26aaf:	mov    %r14,0x28(%r13)
   26ab3:	mov    %r12,0x30(%r13)
   26ab7:	mov    %rbp,0x38(%r13)
   26abb:	mov    %rbx,0x40(%r13)
   26abf:	mov    0x90(%rsp),%rax
   26ac7:	mov    %rax,0x58(%r13)
   26acb:	movdqu 0x80(%rsp),%xmm0
   26ad4:	movdqu %xmm0,0x48(%r13)
   26ada:	mov    0x160(%rsp),%rbx
   26ae2:	test   %rbx,%rbx
   26ae5:	lea    0x80(%rsp),%rbp
   26aed:	je     26b2f <_RNvCseJ3uQ9fe193_12runtime_text4main+0x3c1f>
   26aef:	mov    0x158(%rsp),%r14
   26af7:	add    $0x8,%r14
   26afb:	mov    0x5b656(%rip),%r15        # 82158 <_DYNAMIC+0x230>
   26b02:	jmp    26b19 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x3c09>
   26b04:	data16 data16 cs nopw 0x0(%rax,%rax,1)
   26b10:	add    $0x18,%r14
   26b14:	dec    %rbx
   26b17:	je     26b2f <_RNvCseJ3uQ9fe193_12runtime_text4main+0x3c1f>
   26b19:	mov    -0x8(%r14),%rsi
   26b1d:	test   %rsi,%rsi
   26b20:	je     26b10 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x3c00>
   26b22:	mov    (%r14),%rdi
   26b25:	mov    $0x1,%edx
   26b2a:	call   *%r15
   26b2d:	jmp    26b10 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x3c00>
   26b2f:	mov    0x150(%rsp),%rax
   26b37:	test   %rax,%rax
   26b3a:	je     26b57 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x3c47>
   26b3c:	mov    0x158(%rsp),%rdi
   26b44:	shl    $0x3,%rax
   26b48:	lea    (%rax,%rax,2),%rsi
   26b4c:	mov    $0x8,%edx
   26b51:	call   *0x5b601(%rip)        # 82158 <_DYNAMIC+0x230>
   26b57:	movq   $0x4,0x150(%rsp)
   26b63:	mov    %r13,0x158(%rsp)
   26b6b:	movq   $0x4,0x160(%rsp)
   26b77:	mov    0x68(%rsp),%rsi
   26b7c:	test   %rsi,%rsi
   26b7f:	je     243d8 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x14c8>
   26b85:	mov    $0x1,%edx
   26b8a:	mov    0x28(%rsp),%rdi
   26b8f:	call   *0x5b5c3(%rip)        # 82158 <_DYNAMIC+0x230>
   26b95:	jmp    243d8 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x14c8>
   26b9a:	cmpq   $0x0,0x1e8(%rsp)
   26ba3:	je     27c5a <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4d4a>
   26ba9:	mov    0x200(%rsp),%rax
   26bb1:	mov    %rax,0x8(%rsp)
   26bb6:	mov    0x1e0(%rsp),%rax
   26bbe:	mov    %rax,0x20(%rsp)
   26bc3:	mov    0x1f8(%rsp),%rax
   26bcb:	mov    %rax,0x78(%rsp)
   26bd0:	lea    0x58789(%rip),%rax        # 7f360 <__frame_dummy_init_array_entry+0x180>
   26bd7:	mov    %rax,0x70(%rsp)
   26bdc:	lea    0x5861d(%rip),%rax        # 7f200 <__frame_dummy_init_array_entry+0x20>
   26be3:	mov    %rax,0x28(%rsp)
   26be8:	movq   $0x0,(%rsp)
   26bf0:	xor    %r13d,%r13d
   26bf3:	jmp    26c50 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x3d40>
   26bf5:	data16 cs nopw 0x0(%rax,%rax,1)
   26c00:	xor    %ecx,%ecx
   26c02:	add    %r15,%rcx
   26c05:	inc    %r13
   26c08:	mov    %rcx,%rax
   26c0b:	movabs $0x89705f3112a28fe5,%rdx
   26c15:	imul   %rdx
   26c18:	add    %rcx,%rdx
   26c1b:	mov    %rdx,%rax
   26c1e:	shr    $0x3f,%rax
   26c22:	sar    $0x1d,%rdx
   26c26:	add    %rax,%rdx
   26c29:	imul   $0x3b9aca07,%rdx,%rax
   26c30:	sub    %rax,%rcx
   26c33:	lea    0x3b9aca07(%rcx),%rax
   26c3a:	test   %rcx,%rcx
   26c3d:	cmovns %rcx,%rax
   26c41:	mov    %rax,(%rsp)
   26c45:	cmp    0x18(%rsp),%r13
   26c4a:	je     259bd <_RNvCseJ3uQ9fe193_12runtime_text4main+0x2aad>
   26c50:	mov    0x10(%rsp),%rax
   26c55:	lea    (%rax,%r13,1),%edi
   26c59:	and    $0x3,%edi
   26c5c:	cmp    0x8(%rsp),%rdi
   26c61:	jae    27a63 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4b53>
   26c67:	mov    0x20(%rsp),%rax
   26c6c:	mov    0x8(%rax),%rbp
   26c70:	mov    0x10(%rax),%r12
   26c74:	lea    (%rdi,%rdi,2),%rax
   26c78:	mov    0x78(%rsp),%rdx
   26c7d:	mov    0x8(%rdx,%rax,8),%rcx
   26c82:	mov    0x10(%rdx,%rax,8),%r8
   26c87:	lea    0x80(%rsp),%rdi
   26c8f:	mov    %rbp,%rsi
   26c92:	mov    %r12,%rdx
   26c95:	call   *0x5b52d(%rip)        # 821c8 <_DYNAMIC+0x2a0>
   26c9b:	mov    (%rsp),%r15
   26c9f:	cmpb   $0x0,0x80(%rsp)
   26ca7:	je     26d30 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x3e20>
   26cad:	mov    0xb8(%rsp),%r10
   26cb5:	mov    0xc8(%rsp),%r8
   26cbd:	mov    0xe0(%rsp),%rcx
   26cc5:	lea    -0x1(%rcx),%rax
   26cc9:	mov    0xd0(%rsp),%rdi
   26cd1:	mov    0xd8(%rsp),%r9
   26cd9:	cmp    $0xffffffffffffffff,%r10
   26cdd:	je     26e23 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x3f13>
   26ce3:	mov    0xa8(%rsp),%rdx
   26ceb:	lea    (%rdx,%rax,1),%rsi
   26cef:	cmp    %rdi,%rsi
   26cf2:	jae    26c00 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x3cf0>
   26cf8:	mov    %rdi,%r14
   26cfb:	mov    0xa0(%rsp),%r11
   26d03:	mov    0x88(%rsp),%rbx
   26d0b:	mov    0x98(%rsp),%rax
   26d13:	mov    %rcx,%rdi
   26d16:	mov    %rax,0x60(%rsp)
   26d1b:	sub    %rax,%rdi
   26d1e:	mov    %rdi,0x68(%rsp)
   26d23:	jmp    26d97 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x3e87>
   26d25:	data16 cs nopw 0x0(%rax,%rax,1)
   26d30:	cmpb   $0x0,0x9a(%rsp)
   26d38:	jne    26c00 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x3cf0>
   26d3e:	mov    0x88(%rsp),%rcx
   26d46:	mov    0xc8(%rsp),%rsi
   26d4e:	mov    0xd0(%rsp),%rdx
   26d56:	movzbl 0x98(%rsp),%eax
   26d5e:	test   %rcx,%rcx
   26d61:	je     26eff <_RNvCseJ3uQ9fe193_12runtime_text4main+0x3fef>
   26d67:	cmp    %rdx,%rcx
   26d6a:	jae    26ef9 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x3fe9>
   26d70:	cmpb   $0xc0,(%rsi,%rcx,1)
   26d74:	jge    26eff <_RNvCseJ3uQ9fe193_12runtime_text4main+0x3fef>
   26d7a:	jmp    27b27 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4c17>
   26d7f:	nop
   26d80:	add    %rcx,%rdx
   26d83:	xor    %r10d,%r10d
   26d86:	lea    -0x1(%rcx),%rax
   26d8a:	lea    (%rdx,%rax,1),%rsi
   26d8e:	cmp    %r14,%rsi
   26d91:	jae    26c00 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x3cf0>
   26d97:	movzbl (%r8,%rsi,1),%eax
   26d9c:	bt     %rax,%r11
   26da0:	jae    26d80 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x3e70>
   26da2:	cmp    %rbx,%r10
   26da5:	mov    %rbx,%rax
   26da8:	cmova  %r10,%rax
   26dac:	lea    (%r8,%rdx,1),%rsi
   26db0:	cmp    %rcx,%rax
   26db3:	jae    26de0 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x3ed0>
   26db5:	lea    0x1(%rax),%rdi
   26db9:	movzbl (%r9,%rax,1),%r15d
   26dbe:	cmp    (%rsi,%rax,1),%r15b
   26dc2:	mov    %rdi,%rax
   26dc5:	je     26db0 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x3ea0>
   26dc7:	sub    %rbx,%rdx
   26dca:	add    %rdi,%rdx
   26dcd:	xor    %r10d,%r10d
   26dd0:	mov    (%rsp),%r15
   26dd4:	jmp    26d86 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x3e76>
   26dd6:	cs nopw 0x0(%rax,%rax,1)
   26de0:	lea    -0x1(%rbx),%rdi
   26de4:	mov    (%rsp),%r15
   26de8:	nopl   0x0(%rax,%rax,1)
   26df0:	lea    0x1(%rdi),%rax
   26df4:	cmp    %rax,%r10
   26df7:	jae    27080 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4170>
   26dfd:	cmp    %rcx,%rdi
   26e00:	jae    27a52 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4b42>
   26e06:	movzbl (%r9,%rdi,1),%eax
   26e0b:	cmp    (%rsi,%rdi,1),%al
   26e0e:	lea    -0x1(%rdi),%rdi
   26e12:	je     26df0 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x3ee0>
   26e14:	add    0x60(%rsp),%rdx
   26e19:	mov    0x68(%rsp),%r10
   26e1e:	jmp    26d86 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x3e76>
   26e23:	mov    0xa8(%rsp),%rdx
   26e2b:	lea    (%rdx,%rax,1),%r14
   26e2f:	mov    %rdi,0x60(%rsp)
   26e34:	cmp    %rdi,%r14
   26e37:	jae    26c00 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x3cf0>
   26e3d:	mov    0xa0(%rsp),%r11
   26e45:	mov    0x88(%rsp),%r10
   26e4d:	lea    -0x1(%r10),%rdi
   26e51:	cmp    %rcx,%rdi
   26e54:	jae    26f3b <_RNvCseJ3uQ9fe193_12runtime_text4main+0x402b>
   26e5a:	mov    0x98(%rsp),%rdi
   26e62:	mov    %r10,%rbx
   26e65:	dec    %rbx
   26e68:	jmp    26e80 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x3f70>
   26e6a:	add    %rcx,%rdx
   26e6d:	lea    -0x1(%rcx),%rax
   26e71:	lea    (%rdx,%rax,1),%r14
   26e75:	cmp    0x60(%rsp),%r14
   26e7a:	jae    26c00 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x3cf0>
   26e80:	movzbl (%r8,%r14,1),%eax
   26e85:	bt     %rax,%r11
   26e89:	jae    26e6a <_RNvCseJ3uQ9fe193_12runtime_text4main+0x3f5a>
   26e8b:	mov    %rdx,%rsi
   26e8e:	neg    %rsi
   26e91:	lea    (%r8,%rdx,1),%r14
   26e95:	mov    %r10,%rax
   26e98:	nopl   0x0(%rax,%rax,1)
   26ea0:	cmp    %rax,%rcx
   26ea3:	je     26ec3 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x3fb3>
   26ea5:	movzbl (%r9,%rax,1),%r15d
   26eaa:	dec    %rsi
   26ead:	cmp    (%r14,%rax,1),%r15b
   26eb1:	lea    0x1(%rax),%rax
   26eb5:	je     26ea0 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x3f90>
   26eb7:	neg    %rsi
   26eba:	mov    %rsi,%rdx
   26ebd:	mov    (%rsp),%r15
   26ec1:	jmp    26e6d <_RNvCseJ3uQ9fe193_12runtime_text4main+0x3f5d>
   26ec3:	lea    (%rbx,%rdx,1),%rsi
   26ec7:	mov    %r10,%rax
   26eca:	mov    %r10,%r14
   26ecd:	nopl   (%rax)
   26ed0:	sub    $0x1,%r14
   26ed4:	jb     27010 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4100>
   26eda:	movzbl -0x1(%r9,%rax,1),%r15d
   26ee0:	mov    %r14,%rax
   26ee3:	cmp    (%r8,%rsi,1),%r15b
   26ee7:	lea    -0x1(%rsi),%rsi
   26eeb:	je     26ed0 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x3fc0>
   26eed:	add    %rdi,%rdx
   26ef0:	mov    (%rsp),%r15
   26ef4:	jmp    26e6d <_RNvCseJ3uQ9fe193_12runtime_text4main+0x3f5d>
   26ef9:	jne    27b27 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4c17>
   26eff:	cmp    %rdx,%rcx
   26f02:	jne    26f1e <_RNvCseJ3uQ9fe193_12runtime_text4main+0x400e>
   26f04:	test   $0x1,%al
   26f06:	je     26c00 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x3cf0>
   26f0c:	nopl   0x0(%rax)
   26f10:	test   %rcx,%rcx
   26f13:	jne    27088 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4178>
   26f19:	jmp    270a5 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4195>
   26f1e:	movzbl (%rsi,%rcx,1),%edi
   26f22:	test   %dil,%dil
   26f25:	js     26fac <_RNvCseJ3uQ9fe193_12runtime_text4main+0x409c>
   26f2b:	test   $0x1,%al
   26f2d:	je     27028 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4118>
   26f33:	mov    %rcx,%rdx
   26f36:	jmp    27080 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4170>
   26f3b:	add    %r10,%r9
   26f3e:	lea    (%r8,%r10,1),%rbx
   26f42:	mov    %r11,0x68(%rsp)
   26f47:	movzbl (%r8,%r14,1),%eax
   26f4c:	bt     %rax,%r11
   26f50:	jae    26f86 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4076>
   26f52:	xor    %esi,%esi
   26f54:	mov    %r9,%r14
   26f57:	mov    %rdx,%r15
   26f5a:	nopw   0x0(%rax,%rax,1)
   26f60:	lea    (%r10,%rsi,1),%rax
   26f64:	cmp    %rcx,%rax
   26f67:	jae    27002 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x40f2>
   26f6d:	movzbl (%r14),%r11d
   26f71:	lea    0x1(%r15),%rax
   26f75:	inc    %r14
   26f78:	inc    %rsi
   26f7b:	cmp    (%rbx,%r15,1),%r11b
   26f7f:	mov    %rax,%r15
   26f82:	je     26f60 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4050>
   26f84:	jmp    26f8c <_RNvCseJ3uQ9fe193_12runtime_text4main+0x407c>
   26f86:	add    %rcx,%rdx
   26f89:	mov    %rdx,%rax
   26f8c:	lea    -0x1(%rcx),%rdx
   26f90:	lea    (%rax,%rdx,1),%r14
   26f94:	mov    %rax,%rdx
   26f97:	cmp    0x60(%rsp),%r14
   26f9c:	mov    (%rsp),%r15
   26fa0:	mov    0x68(%rsp),%r11
   26fa5:	jb     26f47 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4037>
   26fa7:	jmp    26c00 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x3cf0>
   26fac:	mov    %edi,%r8d
   26faf:	and    $0x1f,%r8d
   26fb3:	movzbl 0x1(%rsi,%rcx,1),%r10d
   26fb9:	and    $0x3f,%r10d
   26fbd:	cmp    $0xe0,%dil
   26fc1:	jb     27016 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4106>
   26fc3:	movzbl 0x2(%rsi,%rcx,1),%r9d
   26fc9:	shl    $0x6,%r10d
   26fcd:	and    $0x3f,%r9d
   26fd1:	or     %r10d,%r9d
   26fd4:	cmp    $0xf0,%dil
   26fd8:	jb     270ca <_RNvCseJ3uQ9fe193_12runtime_text4main+0x41ba>
   26fde:	movzbl 0x3(%rsi,%rcx,1),%edi
   26fe3:	and    $0x7,%r8d
   26fe7:	shl    $0x12,%r8d
   26feb:	shl    $0x6,%r9d
   26fef:	and    $0x3f,%edi
   26ff2:	or     %r9d,%edi
   26ff5:	or     %r8d,%edi
   26ff8:	test   $0x1,%al
   26ffa:	jne    26f33 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4023>
   27000:	jmp    27028 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4118>
   27002:	test   %r10,%r10
   27005:	mov    (%rsp),%r15
   27009:	je     27080 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4170>
   2700b:	jmp    27a52 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4b42>
   27010:	mov    (%rsp),%r15
   27014:	jmp    27080 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4170>
   27016:	shl    $0x6,%r8d
   2701a:	or     %r10d,%r8d
   2701d:	mov    %r8d,%edi
   27020:	test   $0x1,%al
   27022:	jne    26f33 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4023>
   27028:	mov    $0x1,%eax
   2702d:	cmp    $0x80,%edi
   27033:	jb     27051 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4141>
   27035:	mov    $0x2,%eax
   2703a:	cmp    $0x800,%edi
   27040:	jb     27051 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4141>
   27042:	cmp    $0x10000,%edi
   27048:	mov    $0x4,%eax
   2704d:	sbb    $0x0,%rax
   27051:	add    %rcx,%rax
   27054:	je     2706c <_RNvCseJ3uQ9fe193_12runtime_text4main+0x415c>
   27056:	cmp    %rdx,%rax
   27059:	jae    27066 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4156>
   2705b:	cmpb   $0xc0,(%rsi,%rax,1)
   2705f:	jge    2706c <_RNvCseJ3uQ9fe193_12runtime_text4main+0x415c>
   27061:	jmp    27c3d <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4d2d>
   27066:	jne    27c3d <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4d2d>
   2706c:	cmp    %rdx,%rax
   2706f:	je     27080 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4170>
   27071:	movzbl (%rsi,%rax,1),%ecx
   27075:	test   %cl,%cl
   27077:	jns    2707c <_RNvCseJ3uQ9fe193_12runtime_text4main+0x416c>
   27079:	cmp    $0xe0,%cl
   2707c:	mov    %rax,%rdx
   2707f:	nop
   27080:	mov    %rdx,%rcx
   27083:	test   %rcx,%rcx
   27086:	je     270a5 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4195>
   27088:	cmp    %r12,%rcx
   2708b:	jae    27099 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4189>
   2708d:	cmpb   $0xc0,0x0(%rbp,%rcx,1)
   27092:	jge    2709f <_RNvCseJ3uQ9fe193_12runtime_text4main+0x418f>
   27094:	jmp    27b23 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4c13>
   27099:	jne    27b23 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4c13>
   2709f:	cmp    $0x20,%rcx
   270a3:	jae    270b3 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x41a3>
   270a5:	mov    %rbp,%rdi
   270a8:	mov    %rcx,%rsi
   270ab:	call   *0x5b127(%rip)        # 821d8 <_DYNAMIC+0x2b0>
   270b1:	jmp    270bf <_RNvCseJ3uQ9fe193_12runtime_text4main+0x41af>
   270b3:	mov    %rbp,%rdi
   270b6:	mov    %rcx,%rsi
   270b9:	call   *0x5b121(%rip)        # 821e0 <_DYNAMIC+0x2b8>
   270bf:	mov    %rax,%rcx
   270c2:	inc    %rcx
   270c5:	jmp    26c02 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x3cf2>
   270ca:	shl    $0xc,%r8d
   270ce:	or     %r8d,%r9d
   270d1:	mov    %r9d,%edi
   270d4:	test   $0x1,%al
   270d6:	jne    26f33 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4023>
   270dc:	jmp    27028 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4118>
   270e1:	mov    0x1e0(%rsp),%r14
   270e9:	mov    0x1e8(%rsp),%rax
   270f1:	mov    %rax,0x8(%rsp)
   270f6:	mov    0x200(%rsp),%rbx
   270fe:	mov    0x1f8(%rsp),%r15
   27106:	xor    %r12d,%r12d
   27109:	lea    0x58268(%rip),%rax        # 7f378 <__frame_dummy_init_array_entry+0x198>
   27110:	mov    %rax,0x70(%rsp)
   27115:	mov    0x5b08c(%rip),%r13        # 821a8 <bcmp@GLIBC_2.2.5>
   2711c:	movabs $0x89705f3112a28fe5,%rbp
   27126:	jmp    27184 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4274>
   27128:	nopl   0x0(%rax,%rax,1)
   27130:	lea    (%r14,%rax,1),%rcx
   27134:	add    %r15,%rax
   27137:	mov    0x8(%rax),%rsi
   2713b:	mov    0x8(%rcx),%rdi
   2713f:	call   *%r13
   27142:	xor    %ecx,%ecx
   27144:	test   %eax,%eax
   27146:	sete   %cl
   27149:	add    %r12,%rcx
   2714c:	mov    %rcx,%rax
   2714f:	imul   %rbp
   27152:	add    %rcx,%rdx
   27155:	mov    %rdx,%rax
   27158:	shr    $0x3f,%rax
   2715c:	sar    $0x1d,%rdx
   27160:	add    %rax,%rdx
   27163:	imul   $0x3b9aca07,%rdx,%rax
   2716a:	sub    %rax,%rcx
   2716d:	incq   0x10(%rsp)
   27172:	mov    %rcx,(%rsp)
   27176:	mov    %rcx,%r12
   27179:	decq   0x18(%rsp)
   2717e:	je     259bd <_RNvCseJ3uQ9fe193_12runtime_text4main+0x2aad>
   27184:	mov    0x10(%rsp),%rdi
   27189:	and    $0x3,%edi
   2718c:	cmp    0x8(%rsp),%rdi
   27191:	jae    27a63 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4b53>
   27197:	cmp    %rbx,%rdi
   2719a:	jae    27ae2 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4bd2>
   271a0:	shl    $0x3,%edi
   271a3:	lea    (%rdi,%rdi,2),%rax
   271a7:	mov    0x10(%r14,%rax,1),%rdx
   271ac:	cmp    0x10(%r15,%rax,1),%rdx
   271b1:	je     27130 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4220>
   271b7:	xor    %ecx,%ecx
   271b9:	jmp    27149 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4239>
   271bb:	mov    0x1c8(%rsp),%rsi
   271c3:	mov    0x1d0(%rsp),%rdi
   271cb:	mov    %rdi,%r8
   271ce:	and    $0xfffffffffffffffc,%r8
   271d2:	movq   $0x0,(%rsp)
   271da:	movabs $0x89705f3112a28fe5,%r9
   271e4:	pxor   %xmm0,%xmm0
   271e8:	xor    %r10d,%r10d
   271eb:	jmp    2723a <_RNvCseJ3uQ9fe193_12runtime_text4main+0x432a>
   271ed:	nopl   (%rax)
   271f0:	xor    %ecx,%ecx
   271f2:	mov    (%rsp),%rbx
   271f6:	add    %rbx,%rcx
   271f9:	inc    %r10
   271fc:	mov    %rcx,%rax
   271ff:	imul   %r9
   27202:	add    %rcx,%rdx
   27205:	mov    %rdx,%rax
   27208:	shr    $0x3f,%rax
   2720c:	sar    $0x1d,%rdx
   27210:	add    %rax,%rdx
   27213:	imul   $0x3b9aca07,%rdx,%rax
   2721a:	sub    %rax,%rcx
   2721d:	lea    0x3b9aca07(%rcx),%rax
   27224:	test   %rcx,%rcx
   27227:	cmovns %rcx,%rax
   2722b:	mov    %rax,(%rsp)
   2722f:	cmp    0x18(%rsp),%r10
   27234:	je     259bd <_RNvCseJ3uQ9fe193_12runtime_text4main+0x2aad>
   2723a:	test   %rdi,%rdi
   2723d:	je     271f0 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x42e0>
   2723f:	mov    0x10(%rsp),%rax
   27244:	add    %r10d,%eax
   27247:	cmp    $0x4,%rdi
   2724b:	mov    (%rsp),%rbx
   2724f:	jae    27260 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4350>
   27251:	xor    %edx,%edx
   27253:	xor    %ecx,%ecx
   27255:	jmp    272e0 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x43d0>
   2725a:	nopw   0x0(%rax,%rax,1)
   27260:	movzbl %al,%ecx
   27263:	movd   %ecx,%xmm2
   27267:	punpcklbw %xmm2,%xmm2
   2726b:	pxor   %xmm1,%xmm1
   2726f:	xor    %ecx,%ecx
   27271:	pxor   %xmm3,%xmm3
   27275:	data16 cs nopw 0x0(%rax,%rax,1)
   27280:	movzwl (%rsi,%rcx,1),%edx
   27284:	movd   %edx,%xmm4
   27288:	movzwl 0x2(%rsi,%rcx,1),%edx
   2728d:	movd   %edx,%xmm5
   27291:	pxor   %xmm2,%xmm4
   27295:	pxor   %xmm2,%xmm5
   27299:	punpcklbw %xmm0,%xmm4
   2729d:	punpcklwd %xmm0,%xmm4
   272a1:	punpckldq %xmm0,%xmm4
   272a5:	paddq  %xmm4,%xmm3
   272a9:	punpcklbw %xmm0,%xmm5
   272ad:	punpcklwd %xmm0,%xmm5
   272b1:	punpckldq %xmm0,%xmm5
   272b5:	paddq  %xmm5,%xmm1
   272b9:	add    $0x4,%rcx
   272bd:	cmp    %rcx,%r8
   272c0:	jne    27280 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4370>
   272c2:	paddq  %xmm3,%xmm1
   272c6:	pshufd $0xee,%xmm1,%xmm2
   272cb:	paddq  %xmm1,%xmm2
   272cf:	movq   %xmm2,%rcx
   272d4:	mov    %r8,%rdx
   272d7:	cmp    %r8,%rdi
   272da:	je     271f6 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x42e6>
   272e0:	movzbl (%rsi,%rdx,1),%r11d
   272e5:	xor    %al,%r11b
   272e8:	movzbl %r11b,%r11d
   272ec:	add    %r11,%rcx
   272ef:	inc    %rdx
   272f2:	cmp    %rdx,%rdi
   272f5:	jne    272e0 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x43d0>
   272f7:	jmp    271f6 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x42e6>
   272fc:	lea    0x0(,%r15,8),%r13
   27304:	mov    %r15,%rax
   27307:	shr    $0x3d,%rax
   2730b:	setne  %al
   2730e:	movabs $0x7ffffffffffffff1,%rcx
   27318:	add    $0x7,%rcx
   2731c:	cmp    %rcx,%r13
   2731f:	seta   %cl
   27322:	or     %al,%cl
   27324:	je     2767c <_RNvCseJ3uQ9fe193_12runtime_text4main+0x476c>
   2732a:	xor    %r12d,%r12d
   2732d:	mov    %r12,%rdi
   27330:	mov    %r13,%rsi
   27333:	call   *0x5aeaf(%rip)        # 821e8 <_DYNAMIC+0x2c0>
   27339:	jmp    27c58 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4d48>
   2733e:	lea    0x58063(%rip),%rdx        # 7f3a8 <__frame_dummy_init_array_entry+0x1c8>
   27345:	jmp    27781 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4871>
   2734a:	mov    0x218(%rsp),%rsi
   27352:	test   %rsi,%rsi
   27355:	je     27c76 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4d66>
   2735b:	mov    0x210(%rsp),%rax
   27363:	mov    %rax,0x8(%rsp)
   27368:	movq   $0x0,(%rsp)
   27370:	xor    %r14d,%r14d
   27373:	mov    %rsi,0x20(%rsp)
   27378:	jmp    273d6 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x44c6>
   2737a:	nopw   0x0(%rax,%rax,1)
   27380:	inc    %r14
   27383:	add    %r15,%rbp
   27386:	add    %rbx,%rbp
   27389:	mov    %rbp,%rax
   2738c:	movabs $0x89705f3112a28fe5,%rcx
   27396:	imul   %rcx
   27399:	add    %rbp,%rdx
   2739c:	mov    %rdx,%rax
   2739f:	shr    $0x3f,%rax
   273a3:	sar    $0x1d,%rdx
   273a7:	add    %rax,%rdx
   273aa:	imul   $0x3b9aca07,%rdx,%rax
   273b1:	sub    %rax,%rbp
   273b4:	lea    0x3b9aca07(%rbp),%rax
   273bb:	test   %rbp,%rbp
   273be:	cmovns %rbp,%rax
   273c2:	mov    %rax,(%rsp)
   273c6:	cmp    0x18(%rsp),%r14
   273cb:	mov    0x20(%rsp),%rsi
   273d0:	je     259bd <_RNvCseJ3uQ9fe193_12runtime_text4main+0x2aad>
   273d6:	mov    0x10(%rsp),%rax
   273db:	add    %r14,%rax
   273de:	mov    %rax,%rcx
   273e1:	or     %rsi,%rcx
   273e4:	shr    $0x20,%rcx
   273e8:	je     27400 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x44f0>
   273ea:	xor    %edx,%edx
   273ec:	div    %rsi
   273ef:	jmp    27404 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x44f4>
   273f1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   27400:	xor    %edx,%edx
   27402:	div    %esi
   27404:	mov    0x8(%rsp),%rax
   27409:	mov    (%rax,%rdx,8),%r15
   2740d:	call   *0x5ad5d(%rip)        # 82170 <_DYNAMIC+0x248>
   27413:	test   %r15,%r15
   27416:	js     27470 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4560>
   27418:	mov    $0x13,%r12d
   2741e:	mov    $0x13,%edi
   27423:	mov    $0x1,%esi
   27428:	call   *0x5ad4a(%rip)        # 82178 <_DYNAMIC+0x250>
   2742e:	test   %rax,%rax
   27431:	je     27af3 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4be3>
   27437:	mov    %rax,%r13
   2743a:	movq   $0x13,0x80(%rsp)
   27446:	mov    %rax,0x88(%rsp)
   2744e:	movq   $0x0,0x90(%rsp)
   2745a:	mov    $0x13,%ebx
   2745f:	xor    %r12d,%r12d
   27462:	jmp    274c3 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x45b3>
   27464:	data16 data16 cs nopw 0x0(%rax,%rax,1)
   27470:	mov    $0x14,%r12d
   27476:	mov    $0x14,%edi
   2747b:	mov    $0x1,%esi
   27480:	call   *0x5acf2(%rip)        # 82178 <_DYNAMIC+0x250>
   27486:	test   %rax,%rax
   27489:	je     27af3 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4be3>
   2748f:	mov    %rax,%r13
   27492:	movq   $0x14,0x80(%rsp)
   2749e:	mov    %rax,0x88(%rsp)
   274a6:	movb   $0x2d,(%rax)
   274a9:	movq   $0x1,0x90(%rsp)
   274b5:	neg    %r15
   274b8:	mov    $0x1,%r12d
   274be:	mov    $0x14,%ebx
   274c3:	mov    $0x13,%edx
   274c8:	mov    %r15,%rdi
   274cb:	lea    0x120(%rsp),%rsi
   274d3:	call   *0x5ad17(%rip)        # 821f0 <_DYNAMIC+0x2c8>
   274d9:	mov    %rax,%rbp
   274dc:	mov    %rdx,%r15
   274df:	mov    %rbx,%rax
   274e2:	sub    %r12,%rax
   274e5:	cmp    %rax,%rdx
   274e8:	ja     275de <_RNvCseJ3uQ9fe193_12runtime_text4main+0x46ce>
   274ee:	test   %r15,%r15
   274f1:	je     27515 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4605>
   274f3:	add    %r12,%r13
   274f6:	mov    %r13,%rdi
   274f9:	mov    %rbp,%rsi
   274fc:	mov    %r15,%rdx
   274ff:	call   *0x5acf3(%rip)        # 821f8 <memcpy@GLIBC_2.14>
   27505:	mov    0x80(%rsp),%rbx
   2750d:	mov    0x88(%rsp),%r13
   27515:	mov    %r12,%rbp
   27518:	mov    %rbx,%r9
   2751b:	add    %r15,%rbp
   2751e:	je     27540 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4630>
   27520:	lea    (%r15,%r12,1),%rcx
   27524:	dec    %rcx
   27527:	mov    %ebp,%eax
   27529:	and    $0x7,%eax
   2752c:	cmp    $0x7,%rcx
   27530:	jae    27550 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4640>
   27532:	xor    %ebx,%ebx
   27534:	mov    %r13,%rcx
   27537:	mov    (%rsp),%r15
   2753b:	jmp    275a7 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4697>
   2753d:	nopl   (%rax)
   27540:	xor    %ebx,%ebx
   27542:	mov    (%rsp),%r15
   27546:	jmp    275bf <_RNvCseJ3uQ9fe193_12runtime_text4main+0x46af>
   27548:	nopl   0x0(%rax,%rax,1)
   27550:	mov    %rbp,%rdx
   27553:	and    $0xfffffffffffffff8,%rdx
   27557:	xor    %ebx,%ebx
   27559:	mov    %r13,%rcx
   2755c:	mov    (%rsp),%r15
   27560:	movzbl (%rcx),%esi
   27563:	add    %rbx,%rsi
   27566:	movzbl 0x1(%rcx),%edi
   2756a:	movzbl 0x2(%rcx),%r8d
   2756f:	add    %rdi,%r8
   27572:	add    %rsi,%r8
   27575:	movzbl 0x3(%rcx),%esi
   27579:	movzbl 0x4(%rcx),%edi
   2757d:	add    %rsi,%rdi
   27580:	movzbl 0x5(%rcx),%esi
   27584:	add    %rdi,%rsi
   27587:	add    %r8,%rsi
   2758a:	movzbl 0x6(%rcx),%edi
   2758e:	movzbl 0x7(%rcx),%ebx
   27592:	add    $0x8,%rcx
   27596:	add    %rdi,%rbx
   27599:	add    %rsi,%rbx
   2759c:	add    $0xfffffffffffffff8,%rdx
   275a0:	jne    27560 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4650>
   275a2:	test   %rax,%rax
   275a5:	je     275bf <_RNvCseJ3uQ9fe193_12runtime_text4main+0x46af>
   275a7:	xor    %edx,%edx
   275a9:	nopl   0x0(%rax)
   275b0:	movzbl (%rcx,%rdx,1),%esi
   275b4:	add    %rsi,%rbx
   275b7:	inc    %rdx
   275ba:	cmp    %rdx,%rax
   275bd:	jne    275b0 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x46a0>
   275bf:	test   %r9,%r9
   275c2:	je     27380 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4470>
   275c8:	mov    %r9,%rsi
   275cb:	mov    $0x1,%edx
   275d0:	mov    %r13,%rdi
   275d3:	call   *0x5ab7f(%rip)        # 82158 <_DYNAMIC+0x230>
   275d9:	jmp    27380 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4470>
   275de:	mov    $0x1,%ecx
   275e3:	mov    $0x1,%r8d
   275e9:	lea    0x80(%rsp),%rdi
   275f1:	mov    %r12,%rsi
   275f4:	mov    %r15,%rdx
   275f7:	call   28440 <_RINvNvMs2_NtCs6i54tJFfzR_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECseJ3uQ9fe193_12runtime_text>
   275fc:	mov    0x88(%rsp),%r13
   27604:	mov    0x90(%rsp),%r12
   2760c:	jmp    274f3 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x45e3>
   27611:	call   *0x5ab59(%rip)        # 82170 <_DYNAMIC+0x248>
   27617:	mov    $0x1,%r12d
   2761d:	mov    $0x1,%esi
   27622:	mov    %r15,%rdi
   27625:	call   *0x5ab4d(%rip)        # 82178 <_DYNAMIC+0x250>
   2762b:	test   %rax,%rax
   2762e:	je     242df <_RNvCseJ3uQ9fe193_12runtime_text4main+0x13cf>
   27634:	mov    %rax,%r14
   27637:	mov    0x1a0(%rsp),%rax
   2763f:	lea    -0x1(%r15),%rdx
   27643:	mov    %r15d,%ecx
   27646:	and    $0x3,%ecx
   27649:	cmp    $0x3,%rdx
   2764d:	jae    276c3 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x47b3>
   2764f:	xor    %edx,%edx
   27651:	jmp    27711 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4801>
   27656:	lea    0x57d63(%rip),%rdx        # 7f3c0 <__frame_dummy_init_array_entry+0x1e0>
   2765d:	jmp    27781 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4871>
   27662:	mov    %rbx,0x88(%rsp)
   2766a:	lea    0x57daf(%rip),%rdi        # 7f420 <__frame_dummy_init_array_entry+0x240>
   27671:	call   *0x5ab89(%rip)        # 82200 <_DYNAMIC+0x2d8>
   27677:	jmp    27c58 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4d48>
   2767c:	test   %r13,%r13
   2767f:	je     277c9 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x48b9>
   27685:	call   *0x5aae5(%rip)        # 82170 <_DYNAMIC+0x248>
   2768b:	mov    $0x8,%r12d
   27691:	mov    $0x8,%esi
   27696:	mov    %r13,%rdi
   27699:	call   *0x5aad9(%rip)        # 82178 <_DYNAMIC+0x250>
   2769f:	test   %rax,%rax
   276a2:	je     2732d <_RNvCseJ3uQ9fe193_12runtime_text4main+0x441d>
   276a8:	mov    %rax,%r14
   276ab:	mov    %r15,%rbx
   276ae:	jmp    277d1 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x48c1>
   276b3:	mov    $0x2,%edi
   276b8:	call   *0x5ab4a(%rip)        # 82208 <_DYNAMIC+0x2e0>
   276be:	jmp    27c58 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4d48>
   276c3:	movabs $0x7ffffffffffffff1,%rsi
   276cd:	add    $0xb,%rsi
   276d1:	and    %r15,%rsi
   276d4:	xor    %edx,%edx
   276d6:	mov    %eax,%edi
   276d8:	nopl   0x0(%rax,%rax,1)
   276e0:	mov    %dil,(%r14,%rdx,1)
   276e4:	lea    0x25(%rdi),%r8d
   276e8:	mov    %r8b,0x1(%r14,%rdx,1)
   276ed:	lea    0x4a(%rdi),%r8d
   276f1:	mov    %r8b,0x2(%r14,%rdx,1)
   276f6:	lea    0x6f(%rdi),%r8d
   276fa:	mov    %r8b,0x3(%r14,%rdx,1)
   276ff:	add    $0x4,%rdx
   27703:	add    $0x94,%dil
   27707:	cmp    %rdx,%rsi
   2770a:	jne    276e0 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x47d0>
   2770c:	test   %rcx,%rcx
   2770f:	je     2773d <_RNvCseJ3uQ9fe193_12runtime_text4main+0x482d>
   27711:	mov    %r14,%rsi
   27714:	add    %rdx,%rsi
   27717:	lea    (%rdx,%rdx,8),%edi
   2771a:	lea    (%rdx,%rdi,4),%edx
   2771d:	add    %dl,%al
   2771f:	xor    %edx,%edx
   27721:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   27730:	mov    %al,(%rsi,%rdx,1)
   27733:	inc    %rdx
   27736:	add    $0x25,%al
   27738:	cmp    %rdx,%rcx
   2773b:	jne    27730 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4820>
   2773d:	mov    0x120(%rsp),%rsi
   27745:	test   %rsi,%rsi
   27748:	je     2775d <_RNvCseJ3uQ9fe193_12runtime_text4main+0x484d>
   2774a:	mov    0x128(%rsp),%rdi
   27752:	mov    $0x1,%edx
   27757:	call   *0x5a9fb(%rip)        # 82158 <_DYNAMIC+0x230>
   2775d:	mov    %r15,0x120(%rsp)
   27765:	mov    %r14,0x128(%rsp)
   2776d:	mov    %r15,0x130(%rsp)
   27775:	jmp    243d8 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x14c8>
   2777a:	lea    0x57c57(%rip),%rdx        # 7f3d8 <__frame_dummy_init_array_entry+0x1f8>
   27781:	lea    -0x1a306(%rip),%rdi        # d482 <anon.c41b9569d3e50f51ac9d11be340d2ec5.16.llvm.16118886657712379284+0xba>
   27788:	mov    $0x16,%esi
   2778d:	call   *0x5aa7d(%rip)        # 82210 <_DYNAMIC+0x2e8>
   27793:	jmp    27c58 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4d48>
   27798:	mov    %rax,%r15
   2779b:	mov    0x40(%rdi),%r8
   2779f:	test   %r8,%r8
   277a2:	jne    231d4 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x2c4>
   277a8:	jmp    2311c <_RNvCseJ3uQ9fe193_12runtime_text4main+0x20c>
   277ad:	mov    %rax,0x18(%rsp)
   277b2:	mov    0x50(%rdi),%rax
   277b6:	mov    0x58(%rdi),%rdx
   277ba:	cmp    $0x1,%rdx
   277be:	jne    232c5 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x3b5>
   277c4:	jmp    232ea <_RNvCseJ3uQ9fe193_12runtime_text4main+0x3da>
   277c9:	mov    $0x8,%r14d
   277cf:	xor    %ebx,%ebx
   277d1:	xor    %ecx,%ecx
   277d3:	movabs $0xaaaaaaaaaaaaaaab,%r8
   277dd:	movabs $0x8637a2a24e5ace35,%r9
   277e7:	xor    %r10d,%r10d
   277ea:	xor    %r11d,%r11d
   277ed:	nopl   (%rax)
   277f0:	mov    %rcx,%rax
   277f3:	mul    %r8
   277f6:	mov    %rdx,%rsi
   277f9:	shr    $1,%rsi
   277fc:	mov    0x1a0(%rsp),%rdi
   27804:	add    %r11,%rdi
   27807:	mov    %rdi,%rax
   2780a:	imul   %r9
   2780d:	lea    (%rsi,%rsi,2),%rax
   27811:	add    %rdi,%rdx
   27814:	mov    %rdx,%rsi
   27817:	shr    $0x3f,%rsi
   2781b:	sar    $0x13,%rdx
   2781f:	add    %rsi,%rdx
   27822:	imul   $0xf4243,%rdx,%rdx
   27829:	sub    %rdx,%rdi
   2782c:	mov    %rdi,%rdx
   2782f:	neg    %rdx
   27832:	add    %r10,%rax
   27835:	cmovne %rdi,%rdx
   27839:	mov    %rdx,(%r14,%rcx,8)
   2783d:	inc    %rcx
   27840:	add    $0x89,%r11
   27847:	dec    %r10
   2784a:	cmp    %rcx,%r15
   2784d:	jne    277f0 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x48e0>
   2784f:	mov    0x168(%rsp),%rsi
   27857:	test   %rsi,%rsi
   2785a:	je     27873 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4963>
   2785c:	mov    0x170(%rsp),%rdi
   27864:	shl    $0x3,%rsi
   27868:	mov    $0x8,%edx
   2786d:	call   *0x5a8e5(%rip)        # 82158 <_DYNAMIC+0x230>
   27873:	mov    %rbx,0x168(%rsp)
   2787b:	mov    %r14,0x170(%rsp)
   27883:	mov    %r15,0x178(%rsp)
   2788b:	jmp    243d8 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x14c8>
   27890:	mov    0x128(%rsp),%rax
   27898:	mov    %rax,0x80(%rsp)
   278a0:	lea    -0x1a3cd(%rip),%rdi        # d4da <anon.c41b9569d3e50f51ac9d11be340d2ec5.16.llvm.16118886657712379284+0x112>
   278a7:	lea    0x57bf2(%rip),%rcx        # 7f4a0 <__frame_dummy_init_array_entry+0x2c0>
   278ae:	lea    0x57b9b(%rip),%r8        # 7f450 <__frame_dummy_init_array_entry+0x270>
   278b5:	lea    0x80(%rsp),%rdx
   278bd:	mov    $0x2b,%esi
   278c2:	call   *0x5a950(%rip)        # 82218 <_DYNAMIC+0x2f0>
   278c8:	jmp    27c58 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4d48>
   278cd:	mov    $0x8,%edi
   278d2:	mov    %r14,%rsi
   278d5:	call   *0x5a945(%rip)        # 82220 <_DYNAMIC+0x2f8>
   278db:	jmp    27c58 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4d48>
   278e0:	lea    -0x1a44f(%rip),%rdi        # d498 <anon.c41b9569d3e50f51ac9d11be340d2ec5.16.llvm.16118886657712379284+0xd0>
   278e7:	lea    0x57b4a(%rip),%rdx        # 7f438 <__frame_dummy_init_array_entry+0x258>
   278ee:	mov    $0x42,%esi
   278f3:	call   *0x5a92f(%rip)        # 82228 <_DYNAMIC+0x300>
   278f9:	jmp    27c58 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4d48>
   278fe:	lea    -0x1a58e(%rip),%rdi        # d377 <anon.ed156775cc2f3392bb82488487d1de8d.21.llvm.4912082265219229507+0xb>
   27905:	lea    0x57924(%rip),%rdx        # 7f230 <__frame_dummy_init_array_entry+0x50>
   2790c:	mov    $0x19,%esi
   27911:	call   *0x5a919(%rip)        # 82230 <_DYNAMIC+0x308>
   27917:	jmp    27c58 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4d48>
   2791c:	lea    -0x1a5eb(%rip),%rdi        # d338 <anon.94ae5f503651b4b31a30de9efa2babba.39.llvm.15791727422996027285+0x76>
   27923:	lea    0x57976(%rip),%rdx        # 7f2a0 <__frame_dummy_init_array_entry+0xc0>
   2792a:	mov    $0x28,%esi
   2792f:	call   *0x5a8f3(%rip)        # 82228 <_DYNAMIC+0x300>
   27935:	jmp    27c58 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4d48>
   2793a:	mov    $0x8,%edi
   2793f:	mov    $0x18,%esi
   27944:	call   *0x5a8d6(%rip)        # 82220 <_DYNAMIC+0x2f8>
   2794a:	jmp    27c58 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4d48>
   2794f:	mov    $0x8,%edi
   27954:	mov    $0x18,%esi
   27959:	call   *0x5a8c1(%rip)        # 82220 <_DYNAMIC+0x2f8>
   2795f:	jmp    27c58 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4d48>
   27964:	mov    $0x8,%edi
   27969:	mov    $0x30,%esi
   2796e:	call   *0x5a8ac(%rip)        # 82220 <_DYNAMIC+0x2f8>
   27974:	jmp    27c58 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4d48>
   27979:	lea    0x30(%rsp),%rdi
   2797e:	mov    $0x3,%edx
   27983:	mov    $0x1,%ecx
   27988:	mov    $0x1,%r8d
   2798e:	mov    %r14,%rsi
   27991:	call   28440 <_RINvNvMs2_NtCs6i54tJFfzR_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECseJ3uQ9fe193_12runtime_text>
   27996:	mov    0x30(%rsp),%r13
   2799b:	mov    0x40(%rsp),%r14
   279a0:	jmp    23c1c <_RNvCseJ3uQ9fe193_12runtime_text4main+0xd0c>
   279a5:	lea    0x30(%rsp),%rdi
   279aa:	mov    $0x4,%edx
   279af:	mov    $0x1,%ecx
   279b4:	mov    $0x1,%r8d
   279ba:	call   28440 <_RINvNvMs2_NtCs6i54tJFfzR_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECseJ3uQ9fe193_12runtime_text>
   279bf:	mov    0x40(%rsp),%rsi
   279c4:	jmp    23c5c <_RNvCseJ3uQ9fe193_12runtime_text4main+0xd4c>
   279c9:	lea    0x1c0(%rsp),%rdi
   279d1:	mov    $0x2,%edx
   279d6:	mov    $0x1,%ecx
   279db:	mov    $0x1,%r8d
   279e1:	mov    %r14,%rsi
   279e4:	call   28440 <_RINvNvMs2_NtCs6i54tJFfzR_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECseJ3uQ9fe193_12runtime_text>
   279e9:	mov    0x1c0(%rsp),%rax
   279f1:	mov    %rax,0x8(%rsp)
   279f6:	mov    0x1d0(%rsp),%r14
   279fe:	jmp    26995 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x3a85>
   27a03:	lea    0x1c0(%rsp),%rdi
   27a0b:	mov    $0x1,%esi
   27a10:	mov    $0x1,%ecx
   27a15:	mov    $0x1,%r8d
   27a1b:	mov    %r15,%rdx
   27a1e:	call   28440 <_RINvNvMs2_NtCs6i54tJFfzR_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECseJ3uQ9fe193_12runtime_text>
   27a23:	mov    0x1c8(%rsp),%rbp
   27a2b:	mov    0x1d0(%rsp),%rbx
   27a33:	lea    (%rbx,%rbp,1),%rdi
   27a37:	mov    0x28(%rsp),%rsi
   27a3c:	mov    %r15,%rdx
   27a3f:	call   *0x5a7b3(%rip)        # 821f8 <memcpy@GLIBC_2.14>
   27a45:	mov    0x1c0(%rsp),%r12
   27a4d:	jmp    26a40 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x3b30>
   27a52:	mov    %rcx,0x8(%rsp)
   27a57:	lea    0x5778a(%rip),%rax        # 7f1e8 <__frame_dummy_init_array_entry+0x8>
   27a5e:	mov    %rax,0x70(%rsp)
   27a63:	mov    0x8(%rsp),%rsi
   27a68:	mov    0x70(%rsp),%rdx
   27a6d:	call   *0x5a7c5(%rip)        # 82238 <_DYNAMIC+0x310>
   27a73:	jmp    27c58 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4d48>
   27a78:	mov    $0x1,%edi
   27a7d:	mov    $0x80,%esi
   27a82:	call   *0x5a760(%rip)        # 821e8 <_DYNAMIC+0x2c0>
   27a88:	jmp    27c58 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4d48>
   27a8d:	mov    0x80(%rsp),%rsi
   27a95:	test   %rsi,%rsi
   27a98:	je     27aad <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4b9d>
   27a9a:	mov    0x88(%rsp),%rdi
   27aa2:	mov    $0x1,%edx
   27aa7:	call   *0x5a6ab(%rip)        # 82158 <_DYNAMIC+0x230>
   27aad:	mov    %r13,0x80(%rsp)
   27ab5:	lea    -0x1a5e2(%rip),%rdi        # d4da <anon.c41b9569d3e50f51ac9d11be340d2ec5.16.llvm.16118886657712379284+0x112>
   27abc:	lea    0x579dd(%rip),%rcx        # 7f4a0 <__frame_dummy_init_array_entry+0x2c0>
   27ac3:	lea    0x5799e(%rip),%r8        # 7f468 <__frame_dummy_init_array_entry+0x288>
   27aca:	lea    0x80(%rsp),%rdx
   27ad2:	mov    $0x2b,%esi
   27ad7:	call   *0x5a73b(%rip)        # 82218 <_DYNAMIC+0x2f0>
   27add:	jmp    27c58 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4d48>
   27ae2:	mov    %rbx,0x8(%rsp)
   27ae7:	lea    0x578a2(%rip),%rax        # 7f390 <__frame_dummy_init_array_entry+0x1b0>
   27aee:	jmp    27a5e <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4b4e>
   27af3:	mov    $0x1,%edi
   27af8:	mov    %r12,%rsi
   27afb:	call   *0x5a6e7(%rip)        # 821e8 <_DYNAMIC+0x2c0>
   27b01:	jmp    27c58 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4d48>
   27b06:	lea    0x5770b(%rip),%rdx        # 7f218 <__frame_dummy_init_array_entry+0x38>
   27b0d:	xor    %edi,%edi
   27b0f:	xor    %esi,%esi
   27b11:	call   *0x5a721(%rip)        # 82238 <_DYNAMIC+0x310>
   27b17:	jmp    27c58 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4d48>
   27b1c:	mov    $0x3,%edi
   27b21:	jmp    27b6c <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4c5c>
   27b23:	xor    %eax,%eax
   27b25:	jmp    27b3f <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4c2f>
   27b27:	mov    %rsi,%rbp
   27b2a:	mov    %rdx,%r12
   27b2d:	mov    %rcx,%rax
   27b30:	mov    %rdx,%rcx
   27b33:	lea    0x57986(%rip),%rdx        # 7f4c0 <__frame_dummy_init_array_entry+0x2e0>
   27b3a:	mov    %rdx,0x28(%rsp)
   27b3f:	mov    %rbp,%rdi
   27b42:	mov    %r12,%rsi
   27b45:	mov    %rax,%rdx
   27b48:	mov    0x28(%rsp),%r8
   27b4d:	call   *0x5a6ed(%rip)        # 82240 <_DYNAMIC+0x318>
   27b53:	jmp    27c58 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4d48>
   27b58:	mov    $0x4,%edi
   27b5d:	lea    0x578a4(%rip),%rax        # 7f408 <__frame_dummy_init_array_entry+0x228>
   27b64:	mov    %rax,0x258(%rsp)
   27b6c:	mov    %rbx,0x88(%rsp)
   27b74:	mov    %r12,%rsi
   27b77:	mov    0x258(%rsp),%rdx
   27b7f:	call   *0x5a6b3(%rip)        # 82238 <_DYNAMIC+0x310>
   27b85:	jmp    27c58 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4d48>
   27b8a:	mov    $0x1,%edi
   27b8f:	mov    $0x80,%esi
   27b94:	call   *0x5a64e(%rip)        # 821e8 <_DYNAMIC+0x2c0>
   27b9a:	jmp    27c58 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4d48>
   27b9f:	mov    %rax,%rbx
   27ba2:	mov    0x80(%rsp),%rsi
   27baa:	test   %rsi,%rsi
   27bad:	je     27bc2 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4cb2>
   27baf:	mov    0x88(%rsp),%rdi
   27bb7:	mov    $0x1,%edx
   27bbc:	call   *0x5a596(%rip)        # 82158 <_DYNAMIC+0x230>
   27bc2:	mov    %rbx,0x80(%rsp)
   27bca:	lea    -0x1a6f7(%rip),%rdi        # d4da <anon.c41b9569d3e50f51ac9d11be340d2ec5.16.llvm.16118886657712379284+0x112>
   27bd1:	lea    0x578c8(%rip),%rcx        # 7f4a0 <__frame_dummy_init_array_entry+0x2c0>
   27bd8:	lea    0x57669(%rip),%r8        # 7f248 <__frame_dummy_init_array_entry+0x68>
   27bdf:	lea    0x80(%rsp),%rdx
   27be7:	mov    $0x2b,%esi
   27bec:	call   *0x5a626(%rip)        # 82218 <_DYNAMIC+0x2f0>
   27bf2:	jmp    27c58 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4d48>
   27bf4:	lea    0x5771d(%rip),%rdi        # 7f318 <__frame_dummy_init_array_entry+0x138>
   27bfb:	call   *0x5a647(%rip)        # 82248 <_DYNAMIC+0x320>
   27c01:	jmp    27c58 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4d48>
   27c03:	xor    %edi,%edi
   27c05:	lea    0x576ac(%rip),%rax        # 7f2b8 <__frame_dummy_init_array_entry+0xd8>
   27c0c:	jmp    27c63 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4d53>
   27c0e:	mov    $0x1,%edi
   27c13:	mov    $0x4,%esi
   27c18:	call   *0x5a5ca(%rip)        # 821e8 <_DYNAMIC+0x2c0>
   27c1e:	jmp    27c58 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4d48>
   27c20:	mov    $0x1,%edi
   27c25:	mov    $0x5,%esi
   27c2a:	call   *0x5a5b8(%rip)        # 821e8 <_DYNAMIC+0x2c0>
   27c30:	jmp    27c58 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4d48>
   27c32:	xor    %edi,%edi
   27c34:	lea    0x57695(%rip),%rax        # 7f2d0 <__frame_dummy_init_array_entry+0xf0>
   27c3b:	jmp    27c63 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4d53>
   27c3d:	mov    %rsi,%rbp
   27c40:	mov    %rdx,%r12
   27c43:	jmp    27b30 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4c20>
   27c48:	mov    $0x1,%edi
   27c4d:	mov    $0x1,%esi
   27c52:	call   *0x5a590(%rip)        # 821e8 <_DYNAMIC+0x2c0>
   27c58:	ud2
   27c5a:	xor    %edi,%edi
   27c5c:	lea    0x576e5(%rip),%rax        # 7f348 <__frame_dummy_init_array_entry+0x168>
   27c63:	mov    %rax,0x70(%rsp)
   27c68:	movq   $0x0,0x8(%rsp)
   27c71:	jmp    27a63 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4b53>
   27c76:	lea    0x57683(%rip),%rdi        # 7f300 <__frame_dummy_init_array_entry+0x120>
   27c7d:	jmp    27bfb <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4ceb>
   27c82:	mov    %rax,%rbx
   27c85:	mov    0x1c0(%rsp),%rsi
   27c8d:	test   %rsi,%rsi
   27c90:	je     27d6a <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4e5a>
   27c96:	mov    0x1c8(%rsp),%rdi
   27c9e:	mov    $0x1,%edx
   27ca3:	jmp    27d64 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4e54>
   27ca8:	mov    %rax,%rbx
   27cab:	mov    0x1c0(%rsp),%rsi
   27cb3:	test   %rsi,%rsi
   27cb6:	je     27e11 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4f01>
   27cbc:	mov    0x1c8(%rsp),%rdi
   27cc4:	mov    $0x1,%edx
   27cc9:	call   *0x5a489(%rip)        # 82158 <_DYNAMIC+0x230>
   27ccf:	jmp    27e11 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4f01>
   27cd4:	mov    %rax,%rbx
   27cd7:	mov    0x30(%rsp),%rsi
   27cdc:	test   %rsi,%rsi
   27cdf:	je     27cf1 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4de1>
   27ce1:	mov    0x38(%rsp),%rdi
   27ce6:	mov    $0x1,%edx
   27ceb:	call   *0x5a467(%rip)        # 82158 <_DYNAMIC+0x230>
   27cf1:	test   %r13,%r13
   27cf4:	je     27d07 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4df7>
   27cf6:	mov    $0x1,%edx
   27cfb:	mov    %r12,%rdi
   27cfe:	mov    %r13,%rsi
   27d01:	call   *0x5a451(%rip)        # 82158 <_DYNAMIC+0x230>
   27d07:	mov    $0x30,%esi
   27d0c:	mov    $0x8,%edx
   27d11:	mov    %r15,%rdi
   27d14:	jmp    27ead <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4f9d>
   27d19:	mov    %rax,%r13
   27d1c:	mov    0x30(%rsp),%rsi
   27d21:	test   %rsi,%rsi
   27d24:	je     27ef8 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4fe8>
   27d2a:	mov    0x38(%rsp),%rdi
   27d2f:	mov    $0x1,%edx
   27d34:	call   *0x5a41e(%rip)        # 82158 <_DYNAMIC+0x230>
   27d3a:	jmp    27ef8 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4fe8>
   27d3f:	jmp    2817e <_RNvCseJ3uQ9fe193_12runtime_text4main+0x526e>
   27d44:	jmp    28186 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x5276>
   27d49:	mov    %rax,%rbx
   27d4c:	jmp    27def <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4edf>
   27d51:	mov    %rax,%rbx
   27d54:	test   %r12,%r12
   27d57:	je     27d6a <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4e5a>
   27d59:	mov    $0x1,%edx
   27d5e:	mov    %rbp,%rdi
   27d61:	mov    %r12,%rsi
   27d64:	call   *0x5a3ee(%rip)        # 82158 <_DYNAMIC+0x230>
   27d6a:	cmpq   $0x0,0x8(%rsp)
   27d70:	je     27d87 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4e77>
   27d72:	mov    $0x1,%edx
   27d77:	mov    0x78(%rsp),%rdi
   27d7c:	mov    0x8(%rsp),%rsi
   27d81:	call   *0x5a3d1(%rip)        # 82158 <_DYNAMIC+0x230>
   27d87:	cmpq   $0x0,(%rsp)
   27d8c:	je     27da2 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4e92>
   27d8e:	mov    $0x1,%edx
   27d93:	mov    0x20(%rsp),%rdi
   27d98:	mov    (%rsp),%rsi
   27d9c:	call   *0x5a3b6(%rip)        # 82158 <_DYNAMIC+0x230>
   27da2:	mov    $0x60,%esi
   27da7:	mov    $0x8,%edx
   27dac:	mov    %r13,%rdi
   27daf:	call   *0x5a3a3(%rip)        # 82158 <_DYNAMIC+0x230>
   27db5:	cmpq   $0x0,0x68(%rsp)
   27dbb:	jne    27dc5 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4eb5>
   27dbd:	mov    %rbx,%r13
   27dc0:	jmp    28207 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x52f7>
   27dc5:	mov    $0x1,%edx
   27dca:	mov    0x28(%rsp),%rdi
   27dcf:	mov    0x68(%rsp),%rsi
   27dd4:	jmp    27ead <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4f9d>
   27dd9:	mov    %rax,%rbx
   27ddc:	mov    $0x1,%esi
   27de1:	mov    $0x1,%edx
   27de6:	mov    %rbp,%rdi
   27de9:	call   *0x5a369(%rip)        # 82158 <_DYNAMIC+0x230>
   27def:	cmpq   $0x0,0x8(%rsp)
   27df5:	je     27e11 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4f01>
   27df7:	mov    $0x1,%edx
   27dfc:	mov    0x78(%rsp),%rdi
   27e01:	mov    0x8(%rsp),%rsi
   27e06:	call   *0x5a34c(%rip)        # 82158 <_DYNAMIC+0x230>
   27e0c:	jmp    27e11 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4f01>
   27e0e:	mov    %rax,%rbx
   27e11:	cmpq   $0x0,(%rsp)
   27e16:	je     27e31 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4f21>
   27e18:	mov    $0x1,%edx
   27e1d:	mov    0x20(%rsp),%rdi
   27e22:	mov    (%rsp),%rsi
   27e26:	call   *0x5a32c(%rip)        # 82158 <_DYNAMIC+0x230>
   27e2c:	jmp    27e31 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4f21>
   27e2e:	mov    %rax,%rbx
   27e31:	mov    $0x60,%esi
   27e36:	mov    $0x8,%edx
   27e3b:	mov    %r13,%rdi
   27e3e:	jmp    27ead <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4f9d>
   27e40:	mov    %rax,%rbx
   27e43:	test   %r12,%r12
   27e46:	je     27e5e <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4f4e>
   27e48:	mov    $0x1,%edx
   27e4d:	mov    %r13,%rdi
   27e50:	mov    %r12,%rsi
   27e53:	call   *0x5a2ff(%rip)        # 82158 <_DYNAMIC+0x230>
   27e59:	jmp    27e5e <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4f4e>
   27e5b:	mov    %rax,%rbx
   27e5e:	cmpq   $0x0,0x8(%rsp)
   27e64:	je     27e80 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4f70>
   27e66:	mov    $0x1,%edx
   27e6b:	mov    0x78(%rsp),%rdi
   27e70:	mov    0x8(%rsp),%rsi
   27e75:	call   *0x5a2dd(%rip)        # 82158 <_DYNAMIC+0x230>
   27e7b:	jmp    27e80 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4f70>
   27e7d:	mov    %rax,%rbx
   27e80:	cmpq   $0x0,(%rsp)
   27e85:	je     27ea0 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4f90>
   27e87:	mov    $0x1,%edx
   27e8c:	mov    0x20(%rsp),%rdi
   27e91:	mov    (%rsp),%rsi
   27e95:	call   *0x5a2bd(%rip)        # 82158 <_DYNAMIC+0x230>
   27e9b:	jmp    27ea0 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4f90>
   27e9d:	mov    %rax,%rbx
   27ea0:	mov    $0x60,%esi
   27ea5:	mov    $0x8,%edx
   27eaa:	mov    %rbp,%rdi
   27ead:	call   *0x5a2a5(%rip)        # 82158 <_DYNAMIC+0x230>
   27eb3:	mov    %rbx,%r13
   27eb6:	jmp    28207 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x52f7>
   27ebb:	mov    %rax,%r13
   27ebe:	mov    0x1c0(%rsp),%rsi
   27ec6:	test   %rsi,%rsi
   27ec9:	je     27eeb <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4fdb>
   27ecb:	mov    0x1c8(%rsp),%rdi
   27ed3:	mov    $0x1,%edx
   27ed8:	call   *0x5a27a(%rip)        # 82158 <_DYNAMIC+0x230>
   27ede:	mov    $0x18,%esi
   27ee3:	jmp    27ffa <_RNvCseJ3uQ9fe193_12runtime_text4main+0x50ea>
   27ee8:	mov    %rax,%r13
   27eeb:	mov    $0x18,%esi
   27ef0:	jmp    27ffa <_RNvCseJ3uQ9fe193_12runtime_text4main+0x50ea>
   27ef5:	mov    %rax,%r13
   27ef8:	mov    $0x30,%esi
   27efd:	mov    $0x8,%edx
   27f02:	mov    %r15,%rdi
   27f05:	call   *0x5a24d(%rip)        # 82158 <_DYNAMIC+0x230>
   27f0b:	jmp    2810d <_RNvCseJ3uQ9fe193_12runtime_text4main+0x51fd>
   27f10:	jmp    2817e <_RNvCseJ3uQ9fe193_12runtime_text4main+0x526e>
   27f15:	mov    %rax,%r13
   27f18:	mov    $0x4,%esi
   27f1d:	mov    $0x1,%edx
   27f22:	mov    %r12,%rdi
   27f25:	call   *0x5a22d(%rip)        # 82158 <_DYNAMIC+0x230>
   27f2b:	jmp    27f30 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x5020>
   27f2d:	mov    %rax,%r13
   27f30:	mov    $0x4,%esi
   27f35:	mov    $0x1,%edx
   27f3a:	mov    %r15,%rdi
   27f3d:	call   *0x5a215(%rip)        # 82158 <_DYNAMIC+0x230>
   27f43:	jmp    28267 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x5357>
   27f48:	mov    %rax,%r13
   27f4b:	jmp    28017 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x5107>
   27f50:	mov    %rax,%r13
   27f53:	mov    0x1c0(%rsp),%rsi
   27f5b:	test   %rsi,%rsi
   27f5e:	je     28207 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x52f7>
   27f64:	shl    $0x5,%rsi
   27f68:	mov    $0x8,%edx
   27f6d:	mov    %r14,%rdi
   27f70:	jmp    28158 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x5248>
   27f75:	mov    %rax,%r13
   27f78:	mov    0x80(%rsp),%rsi
   27f80:	test   %rsi,%rsi
   27f83:	je     28017 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x5107>
   27f89:	mov    0x88(%rsp),%rdi
   27f91:	mov    $0x1,%edx
   27f96:	call   *0x5a1bc(%rip)        # 82158 <_DYNAMIC+0x230>
   27f9c:	jmp    28017 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x5107>
   27f9e:	mov    %rax,%r13
   27fa1:	lea    0x80(%rsp),%rdi
   27fa9:	call   22bf0 <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueINtNtCs6i54tJFfzR_5alloc3vec3VecNtNtBG_6string6StringEECseJ3uQ9fe193_12runtime_text>
   27fae:	jmp    28189 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x5279>
   27fb3:	jmp    27fb5 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x50a5>
   27fb5:	mov    %rax,%r13
   27fb8:	test   %r12,%r12
   27fbb:	je     28189 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x5279>
   27fc1:	mov    $0x1,%edx
   27fc6:	mov    %r15,%rdi
   27fc9:	mov    %r12,%rsi
   27fcc:	call   *0x5a186(%rip)        # 82158 <_DYNAMIC+0x230>
   27fd2:	jmp    28189 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x5279>
   27fd7:	mov    %rax,%r13
   27fda:	test   %r14,%r14
   27fdd:	je     27ff5 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x50e5>
   27fdf:	mov    $0x1,%edx
   27fe4:	mov    %r15,%rdi
   27fe7:	mov    %r14,%rsi
   27fea:	call   *0x5a168(%rip)        # 82158 <_DYNAMIC+0x230>
   27ff0:	jmp    27ff5 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x50e5>
   27ff2:	mov    %rax,%r13
   27ff5:	mov    $0x30,%esi
   27ffa:	mov    $0x8,%edx
   27fff:	mov    %r12,%rdi
   28002:	jmp    28158 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x5248>
   28007:	mov    %rax,%r13
   2800a:	lea    0x80(%rsp),%rdi
   28012:	call   22e70 <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtCs1ZxogWZ17zb_10serde_json5error5ErrorECseJ3uQ9fe193_12runtime_text>
   28017:	mov    $0x18,%esi
   2801c:	mov    $0x8,%edx
   28021:	mov    %r15,%rdi
   28024:	call   *0x5a12e(%rip)        # 82158 <_DYNAMIC+0x230>
   2802a:	jmp    28166 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x5256>
   2802f:	call   *0x5a21b(%rip)        # 82250 <_DYNAMIC+0x328>
   28035:	mov    %rax,%r13
   28038:	mov    0x80(%rsp),%rsi
   28040:	test   %rsi,%rsi
   28043:	je     28267 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x5357>
   28049:	mov    0x88(%rsp),%rdi
   28051:	mov    $0x1,%edx
   28056:	call   *0x5a0fc(%rip)        # 82158 <_DYNAMIC+0x230>
   2805c:	jmp    28267 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x5357>
   28061:	jmp    2817e <_RNvCseJ3uQ9fe193_12runtime_text4main+0x526e>
   28066:	mov    %rax,%rbx
   28069:	mov    0x120(%rsp),%rsi
   28071:	test   %rsi,%rsi
   28074:	je     28088 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x5178>
   28076:	shl    $0x5,%rsi
   2807a:	mov    $0x8,%edx
   2807f:	mov    %r12,%rdi
   28082:	call   *0x5a0d0(%rip)        # 82158 <_DYNAMIC+0x230>
   28088:	test   %rbp,%rbp
   2808b:	je     2809e <_RNvCseJ3uQ9fe193_12runtime_text4main+0x518e>
   2808d:	mov    $0x1,%edx
   28092:	mov    %r13,%rdi
   28095:	mov    %rbp,%rsi
   28098:	call   *0x5a0ba(%rip)        # 82158 <_DYNAMIC+0x230>
   2809e:	mov    %rbx,%r13
   280a1:	jmp    28267 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x5357>
   280a6:	mov    %rax,%r13
   280a9:	mov    0x80(%rsp),%rsi
   280b1:	test   %rsi,%rsi
   280b4:	je     280ea <_RNvCseJ3uQ9fe193_12runtime_text4main+0x51da>
   280b6:	mov    0x88(%rsp),%rdi
   280be:	mov    $0x1,%edx
   280c3:	call   *0x5a08f(%rip)        # 82158 <_DYNAMIC+0x230>
   280c9:	jmp    280ea <_RNvCseJ3uQ9fe193_12runtime_text4main+0x51da>
   280cb:	mov    %rax,%r13
   280ce:	jmp    280ea <_RNvCseJ3uQ9fe193_12runtime_text4main+0x51da>
   280d0:	jmp    2817e <_RNvCseJ3uQ9fe193_12runtime_text4main+0x526e>
   280d5:	jmp    2817e <_RNvCseJ3uQ9fe193_12runtime_text4main+0x526e>
   280da:	mov    %rax,%r13
   280dd:	lea    0x80(%rsp),%rdi
   280e5:	call   22e70 <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtCs1ZxogWZ17zb_10serde_json5error5ErrorECseJ3uQ9fe193_12runtime_text>
   280ea:	lea    0x120(%rsp),%rdi
   280f2:	call   22c80 <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueINtNtCs6i54tJFfzR_5alloc3vec3VecNtNtCs1ZxogWZ17zb_10serde_json5value5ValueEECseJ3uQ9fe193_12runtime_text>
   280f7:	jmp    28267 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x5357>
   280fc:	call   *0x5a14e(%rip)        # 82250 <_DYNAMIC+0x328>
   28102:	call   *0x5a148(%rip)        # 82250 <_DYNAMIC+0x328>
   28108:	jmp    2817e <_RNvCseJ3uQ9fe193_12runtime_text4main+0x526e>
   2810a:	mov    %rax,%r13
   2810d:	mov    0x108(%rsp),%rsi
   28115:	test   %rsi,%rsi
   28118:	je     28207 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x52f7>
   2811e:	mov    0x110(%rsp),%rdi
   28126:	jmp    28153 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x5243>
   28128:	mov    %rax,%r13
   2812b:	lea    0x80(%rsp),%rdi
   28133:	call   32790 <_RNvXsg_NtCsfBDUjroi3FF_9hashbrown3rawINtB5_8RawTableTRexEENtNtNtCsgxBkk5gSRhY_4core3ops4drop4Drop4dropCseJ3uQ9fe193_12runtime_text>
   28138:	jmp    28267 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x5357>
   2813d:	mov    %rax,%r13
   28140:	mov    0x30(%rsp),%rsi
   28145:	test   %rsi,%rsi
   28148:	je     28207 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x52f7>
   2814e:	mov    0x38(%rsp),%rdi
   28153:	mov    $0x1,%edx
   28158:	call   *0x59ffa(%rip)        # 82158 <_DYNAMIC+0x230>
   2815e:	jmp    28207 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x52f7>
   28163:	mov    %rax,%r13
   28166:	lea    0x1c0(%rsp),%rdi
   2816e:	call   22c80 <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueINtNtCs6i54tJFfzR_5alloc3vec3VecNtNtCs1ZxogWZ17zb_10serde_json5value5ValueEECseJ3uQ9fe193_12runtime_text>
   28173:	jmp    28207 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x52f7>
   28178:	call   *0x5a0d2(%rip)        # 82250 <_DYNAMIC+0x328>
   2817e:	mov    %rax,%r13
   28181:	jmp    28267 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x5357>
   28186:	mov    %rax,%r13
   28189:	mov    0x30(%rsp),%rsi
   2818e:	test   %rsi,%rsi
   28191:	je     281a3 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x5293>
   28193:	mov    0x38(%rsp),%rdi
   28198:	mov    $0x1,%edx
   2819d:	call   *0x59fb5(%rip)        # 82158 <_DYNAMIC+0x230>
   281a3:	lea    0x108(%rsp),%rdi
   281ab:	call   22bf0 <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueINtNtCs6i54tJFfzR_5alloc3vec3VecNtNtBG_6string6StringEECseJ3uQ9fe193_12runtime_text>
   281b0:	lea    0x1a0(%rsp),%rdi
   281b8:	call   22af0 <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueINtNtCs6i54tJFfzR_5alloc3vec3VecIBC_NtNtBG_6string6StringEEECseJ3uQ9fe193_12runtime_text>
   281bd:	jmp    28214 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x5304>
   281bf:	mov    %rax,%r13
   281c2:	lea    0x80(%rsp),%rdi
   281ca:	call   22e70 <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtCs1ZxogWZ17zb_10serde_json5error5ErrorECseJ3uQ9fe193_12runtime_text>
   281cf:	jmp    28267 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x5357>
   281d4:	call   *0x5a076(%rip)        # 82250 <_DYNAMIC+0x328>
   281da:	mov    %rax,%r13
   281dd:	jmp    28274 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x5364>
   281e2:	mov    %rax,%r13
   281e5:	lea    0x30(%rsp),%rdi
   281ea:	call   22bf0 <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueINtNtCs6i54tJFfzR_5alloc3vec3VecNtNtBG_6string6StringEECseJ3uQ9fe193_12runtime_text>
   281ef:	lea    0x80(%rsp),%rdi
   281f7:	call   2e7c0 <_RNvXse_NtNtCs6i54tJFfzR_5alloc3vec9into_iterINtB5_8IntoIterINtB7_3VecNtNtB9_6string6StringEENtNtNtCsgxBkk5gSRhY_4core3ops4drop4Drop4dropCseJ3uQ9fe193_12runtime_text>
   281fc:	jmp    28214 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x5304>
   281fe:	call   *0x5a04c(%rip)        # 82250 <_DYNAMIC+0x328>
   28204:	mov    %rax,%r13
   28207:	lea    0x120(%rsp),%rdi
   2820f:	jmp    2826f <_RNvCseJ3uQ9fe193_12runtime_text4main+0x535f>
   28211:	mov    %rax,%r13
   28214:	mov    0x128(%rsp),%rbx
   2821c:	test   %rbx,%rbx
   2821f:	je     28267 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x5357>
   28221:	mov    %r13,(%rsp)
   28225:	mov    0x138(%rsp),%r15
   2822d:	test   %r15,%r15
   28230:	jne    282ef <_RNvCseJ3uQ9fe193_12runtime_text4main+0x53df>
   28236:	mov    %rbx,%rax
   28239:	shl    $0x5,%rax
   2823d:	add    %rax,%rbx
   28240:	add    $0x31,%rbx
   28244:	je     28263 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x5353>
   28246:	mov    0x120(%rsp),%rdi
   2824e:	sub    %rax,%rdi
   28251:	add    $0xffffffffffffffe0,%rdi
   28255:	mov    $0x10,%edx
   2825a:	mov    %rbx,%rsi
   2825d:	call   *0x59ef5(%rip)        # 82158 <_DYNAMIC+0x230>
   28263:	mov    (%rsp),%r13
   28267:	lea    0x1c0(%rsp),%rdi
   2826f:	call   22cf0 <_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtCseJ3uQ9fe193_12runtime_text6InputsEBD_>
   28274:	mov    0x248(%rsp),%rbx
   2827c:	mov    0x250(%rsp),%r14
   28284:	test   %r14,%r14
   28287:	jne    282b4 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x53a4>
   28289:	mov    0x240(%rsp),%rax
   28291:	test   %rax,%rax
   28294:	je     282ac <_RNvCseJ3uQ9fe193_12runtime_text4main+0x539c>
   28296:	shl    $0x3,%rax
   2829a:	lea    (%rax,%rax,2),%rsi
   2829e:	mov    $0x8,%edx
   282a3:	mov    %rbx,%rdi
   282a6:	call   *0x59eac(%rip)        # 82158 <_DYNAMIC+0x230>
   282ac:	mov    %r13,%rdi
   282af:	call   7e190 <_Unwind_Resume@plt>
   282b4:	lea    0x8(%rbx),%r15
   282b8:	mov    0x59e99(%rip),%r12        # 82158 <_DYNAMIC+0x230>
   282bf:	jmp    282d9 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x53c9>
   282c1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   282d0:	add    $0x18,%r15
   282d4:	dec    %r14
   282d7:	je     28289 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x5379>
   282d9:	mov    -0x8(%r15),%rsi
   282dd:	test   %rsi,%rsi
   282e0:	je     282d0 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x53c0>
   282e2:	mov    (%r15),%rdi
   282e5:	mov    $0x1,%edx
   282ea:	call   *%r12
   282ed:	jmp    282d0 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x53c0>
   282ef:	mov    0x120(%rsp),%r12
   282f7:	movdqa (%r12),%xmm0
   282fd:	lea    0x10(%r12),%r13
   28302:	pmovmskb %xmm0,%ebp
   28306:	not    %ebp
   28308:	jmp    28323 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x5413>
   2830a:	nopw   0x0(%rax,%rax,1)
   28310:	dec    %r15
   28313:	lea    -0x1(%rbp),%eax
   28316:	and    %ebp,%eax
   28318:	mov    %eax,%ebp
   2831a:	test   %r15,%r15
   2831d:	je     28236 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x5326>
   28323:	test   %bp,%bp
   28326:	jne    2834d <_RNvCseJ3uQ9fe193_12runtime_text4main+0x543d>
   28328:	nopl   0x0(%rax,%rax,1)
   28330:	movdqa 0x0(%r13),%xmm0
   28336:	add    $0xfffffffffffffe00,%r12
   2833d:	add    $0x10,%r13
   28341:	pmovmskb %xmm0,%ebp
   28345:	xor    $0xffff,%ebp
   2834b:	je     28330 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x5420>
   2834d:	tzcnt  %ebp,%ecx
   28351:	shl    $0x5,%ecx
   28354:	mov    %r12,%rax
   28357:	sub    %rcx,%rax
   2835a:	mov    -0x20(%rax),%rsi
   2835e:	test   %rsi,%rsi
   28361:	je     28310 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x5400>
   28363:	mov    -0x18(%rax),%rdi
   28367:	mov    $0x1,%edx
   2836c:	call   *%r14
   2836f:	jmp    28310 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x5400>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
