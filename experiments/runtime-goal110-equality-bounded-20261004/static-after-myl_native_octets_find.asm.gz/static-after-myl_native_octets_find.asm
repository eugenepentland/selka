
/home/epentland/ai/canopy/mylang-worktrees/goal110-equality-bounded-20261004/.mylang-cache/goal110-equality-bounded-rf/runner/bin/text-my-llvm:     file format elf64-x86-64


Disassembly of section .text:

0000000001094440 <myl_native_octets_find>:
 1094440:	test   %rcx,%rcx
 1094443:	je     109449a <myl_native_octets_find+0x5a>
 1094445:	push   %rbp
 1094446:	mov    %rsp,%rbp
 1094449:	push   %r15
 109444b:	push   %r14
 109444d:	push   %r13
 109444f:	push   %r12
 1094451:	push   %rbx
 1094452:	sub    $0x18,%rsp
 1094456:	mov    $0xffffffffffffffff,%rax
 109445d:	mov    %rsi,%r14
 1094460:	sub    %rcx,%r14
 1094463:	jb     1094705 <myl_native_octets_find+0x2c5>
 1094469:	mov    %rsi,%rbx
 109446c:	cmp    $0x1,%rcx
 1094470:	jne    109449d <myl_native_octets_find+0x5d>
 1094472:	movzbl (%rdx),%esi
 1094475:	mov    %rdi,%r14
 1094478:	mov    %rbx,%rdx
 109447b:	call   10ae530 <memchr@plt>
 1094480:	mov    %rax,%rcx
 1094483:	mov    %rax,%rdx
 1094486:	sub    %r14,%rdx
 1094489:	xor    %eax,%eax
 109448b:	cmp    $0x1,%rcx
 109448f:	sbb    %rax,%rax
 1094492:	or     %rdx,%rax
 1094495:	jmp    1094705 <myl_native_octets_find+0x2c5>
 109449a:	xor    %eax,%eax
 109449c:	ret
 109449d:	mov    %rcx,-0x30(%rbp)
 10944a1:	mov    %rdx,%r15
 10944a4:	movzbl (%rdx),%r12d
 10944a8:	lea    0x1(%r14),%rdx
 10944ac:	mov    %rdi,%r13
 10944af:	mov    %r12d,%esi
 10944b2:	call   10ae530 <memchr@plt>
 10944b7:	test   %rax,%rax
 10944ba:	je     10946fe <myl_native_octets_find+0x2be>
 10944c0:	mov    %r13,%rcx
 10944c3:	lea    (%r14,%r13,1),%r10
 10944c7:	lea    (%r14,%r13,1),%r11
 10944cb:	inc    %r11
 10944ce:	lea    0x1(%rax),%rdi
 10944d2:	mov    $0x1,%edx
 10944d7:	mov    -0x30(%rbp),%rsi
 10944db:	mov    %r15,%r8
 10944de:	xchg   %ax,%ax
 10944e0:	movzbl (%rax,%rdx,1),%r9d
 10944e5:	cmp    (%r8,%rdx,1),%r9b
 10944e9:	jne    10944fb <myl_native_octets_find+0xbb>
 10944eb:	inc    %rdx
 10944ee:	cmp    %rdx,%rsi
 10944f1:	jne    10944e0 <myl_native_octets_find+0xa0>
 10944f3:	sub    %rcx,%rax
 10944f6:	jmp    1094705 <myl_native_octets_find+0x2c5>
 10944fb:	cmp    %r10,%rax
 10944fe:	je     10946fe <myl_native_octets_find+0x2be>
 1094504:	mov    %r10,-0x38(%rbp)
 1094508:	mov    %r11,%r14
 109450b:	mov    %r11,%rdx
 109450e:	sub    %rdi,%rdx
 1094511:	mov    %r12d,%esi
 1094514:	call   10ae530 <memchr@plt>
 1094519:	test   %rax,%rax
 109451c:	je     10946fe <myl_native_octets_find+0x2be>
 1094522:	lea    0x1(%rax),%rdi
 1094526:	mov    $0x1,%edx
 109452b:	mov    %r13,%rcx
 109452e:	mov    -0x30(%rbp),%rsi
 1094532:	mov    %r15,%r8
 1094535:	mov    -0x38(%rbp),%r10
 1094539:	mov    %r14,%r11
 109453c:	nopl   0x0(%rax)
 1094540:	movzbl (%rax,%rdx,1),%r9d
 1094545:	cmp    (%r8,%rdx,1),%r9b
 1094549:	jne    1094555 <myl_native_octets_find+0x115>
 109454b:	inc    %rdx
 109454e:	cmp    %rdx,%rsi
 1094551:	jne    1094540 <myl_native_octets_find+0x100>
 1094553:	jmp    10944f3 <myl_native_octets_find+0xb3>
 1094555:	cmp    %r10,%rax
 1094558:	je     10946fe <myl_native_octets_find+0x2be>
 109455e:	mov    %r11,%rdx
 1094561:	sub    %rdi,%rdx
 1094564:	mov    %r12d,%esi
 1094567:	call   10ae530 <memchr@plt>
 109456c:	test   %rax,%rax
 109456f:	je     10946fe <myl_native_octets_find+0x2be>
 1094575:	lea    0x1(%rax),%rdi
 1094579:	mov    $0x1,%edx
 109457e:	mov    %r13,%rcx
 1094581:	mov    -0x30(%rbp),%rsi
 1094585:	mov    %r15,%r8
 1094588:	mov    -0x38(%rbp),%r10
 109458c:	mov    %r14,%r11
 109458f:	movzbl (%rax,%rdx,1),%r9d
 1094594:	cmp    (%r8,%rdx,1),%r9b
 1094598:	jne    10945a7 <myl_native_octets_find+0x167>
 109459a:	inc    %rdx
 109459d:	cmp    %rdx,%rsi
 10945a0:	jne    109458f <myl_native_octets_find+0x14f>
 10945a2:	jmp    10944f3 <myl_native_octets_find+0xb3>
 10945a7:	cmp    %r10,%rax
 10945aa:	je     10946fe <myl_native_octets_find+0x2be>
 10945b0:	mov    %r11,%rdx
 10945b3:	sub    %rdi,%rdx
 10945b6:	mov    %r12d,%esi
 10945b9:	call   10ae530 <memchr@plt>
 10945be:	test   %rax,%rax
 10945c1:	je     10946fe <myl_native_octets_find+0x2be>
 10945c7:	lea    0x1(%rax),%rdi
 10945cb:	mov    $0x1,%edx
 10945d0:	mov    %r13,%rcx
 10945d3:	mov    -0x30(%rbp),%rsi
 10945d7:	mov    %r15,%r8
 10945da:	mov    -0x38(%rbp),%r10
 10945de:	mov    %r14,%r11
 10945e1:	movzbl (%rax,%rdx,1),%r9d
 10945e6:	cmp    (%r8,%rdx,1),%r9b
 10945ea:	jne    10945f9 <myl_native_octets_find+0x1b9>
 10945ec:	inc    %rdx
 10945ef:	cmp    %rdx,%rsi
 10945f2:	jne    10945e1 <myl_native_octets_find+0x1a1>
 10945f4:	jmp    10944f3 <myl_native_octets_find+0xb3>
 10945f9:	cmp    %r10,%rax
 10945fc:	je     10946fe <myl_native_octets_find+0x2be>
 1094602:	mov    %r11,%rdx
 1094605:	sub    %rdi,%rdx
 1094608:	mov    %r12d,%esi
 109460b:	call   10ae530 <memchr@plt>
 1094610:	test   %rax,%rax
 1094613:	je     10946fe <myl_native_octets_find+0x2be>
 1094619:	lea    0x1(%rax),%rdi
 109461d:	mov    $0x1,%ecx
 1094622:	mov    -0x30(%rbp),%rdx
 1094626:	mov    %r15,%rsi
 1094629:	movzbl (%rax,%rcx,1),%r8d
 109462e:	cmp    (%rsi,%rcx,1),%r8b
 1094632:	jne    1094644 <myl_native_octets_find+0x204>
 1094634:	inc    %rcx
 1094637:	cmp    %rcx,%rdx
 109463a:	jne    1094629 <myl_native_octets_find+0x1e9>
 109463c:	mov    %r13,%rcx
 109463f:	jmp    10944f3 <myl_native_octets_find+0xb3>
 1094644:	cmp    -0x38(%rbp),%rax
 1094648:	je     10946fe <myl_native_octets_find+0x2be>
 109464e:	mov    %r14,%rdx
 1094651:	sub    %rdi,%rdx
 1094654:	mov    %r12d,%esi
 1094657:	call   10ae530 <memchr@plt>
 109465c:	test   %rax,%rax
 109465f:	je     10946fe <myl_native_octets_find+0x2be>
 1094665:	lea    0x1(%rax),%rdi
 1094669:	mov    $0x1,%ecx
 109466e:	mov    -0x30(%rbp),%rdx
 1094672:	mov    %r15,%rsi
 1094675:	movzbl (%rax,%rcx,1),%r8d
 109467a:	cmp    (%rsi,%rcx,1),%r8b
 109467e:	jne    109468a <myl_native_octets_find+0x24a>
 1094680:	inc    %rcx
 1094683:	cmp    %rcx,%rdx
 1094686:	jne    1094675 <myl_native_octets_find+0x235>
 1094688:	jmp    109463c <myl_native_octets_find+0x1fc>
 109468a:	cmp    -0x38(%rbp),%rax
 109468e:	je     10946fe <myl_native_octets_find+0x2be>
 1094690:	mov    %r14,%rdx
 1094693:	sub    %rdi,%rdx
 1094696:	mov    %r12d,%esi
 1094699:	call   10ae530 <memchr@plt>
 109469e:	test   %rax,%rax
 10946a1:	je     10946fe <myl_native_octets_find+0x2be>
 10946a3:	lea    0x1(%rax),%rdi
 10946a7:	mov    $0x1,%ecx
 10946ac:	movzbl (%rax,%rcx,1),%edx
 10946b0:	cmp    (%r15,%rcx,1),%dl
 10946b4:	jne    10946c4 <myl_native_octets_find+0x284>
 10946b6:	inc    %rcx
 10946b9:	cmp    %rcx,-0x30(%rbp)
 10946bd:	jne    10946ac <myl_native_octets_find+0x26c>
 10946bf:	jmp    109463c <myl_native_octets_find+0x1fc>
 10946c4:	cmp    -0x38(%rbp),%rax
 10946c8:	je     10946fe <myl_native_octets_find+0x2be>
 10946ca:	sub    %rdi,%r14
 10946cd:	mov    %r12d,%esi
 10946d0:	mov    %r14,%rdx
 10946d3:	call   10ae530 <memchr@plt>
 10946d8:	test   %rax,%rax
 10946db:	je     10946fe <myl_native_octets_find+0x2be>
 10946dd:	lea    0x1(%rax),%rdi
 10946e1:	mov    $0x1,%ecx
 10946e6:	movzbl (%rax,%rcx,1),%edx
 10946ea:	cmp    (%r15,%rcx,1),%dl
 10946ee:	jne    1094714 <myl_native_octets_find+0x2d4>
 10946f0:	inc    %rcx
 10946f3:	cmp    %rcx,-0x30(%rbp)
 10946f7:	jne    10946e6 <myl_native_octets_find+0x2a6>
 10946f9:	jmp    109463c <myl_native_octets_find+0x1fc>
 10946fe:	mov    $0xffffffffffffffff,%rax
 1094705:	add    $0x18,%rsp
 1094709:	pop    %rbx
 109470a:	pop    %r12
 109470c:	pop    %r13
 109470e:	pop    %r14
 1094710:	pop    %r15
 1094712:	pop    %rbp
 1094713:	ret
 1094714:	cmp    -0x38(%rbp),%rax
 1094718:	mov    $0xffffffffffffffff,%rax
 109471f:	je     1094705 <myl_native_octets_find+0x2c5>
 1094721:	add    %r13,%rbx
 1094724:	sub    %rdi,%rbx
 1094727:	mov    %rbx,%rsi
 109472a:	mov    %r15,%rdx
 109472d:	mov    -0x30(%rbp),%rcx
 1094731:	call   10ae540 <memmem@plt>
 1094736:	mov    %rax,%rcx
 1094739:	mov    %rax,%rdx
 109473c:	sub    %r13,%rdx
 109473f:	jmp    1094489 <myl_native_octets_find+0x49>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
