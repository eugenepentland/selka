
/home/epentland/ai/canopy/mylang-worktrees/goal110-equality-bounded-20261004/.mylang-cache/goal110-equality-bounded-rf/runner/bin/text-my-qbe:     file format elf64-x86-64


Disassembly of section .text:

00000000010c79b0 <myl_native_text_equal>:
 10c79b0:	mov    $0x1,%eax
 10c79b5:	cmp    %rsi,%rdi
 10c79b8:	je     10c7add <myl_native_text_equal+0x12d>
 10c79be:	test   %rdi,%rdi
 10c79c1:	sete   %cl
 10c79c4:	test   %rsi,%rsi
 10c79c7:	sete   %dl
 10c79ca:	xor    %eax,%eax
 10c79cc:	or     %cl,%dl
 10c79ce:	jne    10c7add <myl_native_text_equal+0x12d>
 10c79d4:	mov    0x8(%rdi),%rdx
 10c79d8:	cmp    0x8(%rsi),%rdx
 10c79dc:	jne    10c7add <myl_native_text_equal+0x12d>
 10c79e2:	mov    $0x1,%eax
 10c79e7:	test   %rdx,%rdx
 10c79ea:	je     10c7add <myl_native_text_equal+0x12d>
 10c79f0:	testb  $0x4,0x10(%rdi)
 10c79f4:	jne    10c7a46 <myl_native_text_equal+0x96>
 10c79f6:	add    $0x18,%rdi
 10c79fa:	testb  $0x4,0x10(%rsi)
 10c79fe:	je     10c7a5b <myl_native_text_equal+0xab>
 10c7a00:	mov    0x18(%rsi),%rax
 10c7a04:	mov    0x14(%rsi),%ecx
 10c7a07:	lea    (%rax,%rcx,1),%rsi
 10c7a0b:	add    $0x18,%rsi
 10c7a0f:	cmp    $0x10,%rdx
 10c7a13:	jbe    10c7a65 <myl_native_text_equal+0xb5>
 10c7a15:	cmp    $0x40,%rdx
 10c7a19:	ja     10c7a82 <myl_native_text_equal+0xd2>
 10c7a1b:	cmp    $0x20,%rdx
 10c7a1f:	ja     10c7abb <myl_native_text_equal+0x10b>
 10c7a25:	vmovdqu (%rdi),%xmm0
 10c7a29:	vinserti128 $0x1,-0x10(%rdi,%rdx,1),%ymm0,%ymm0
 10c7a31:	vmovdqu (%rsi),%xmm1
 10c7a35:	vinserti128 $0x1,-0x10(%rsi,%rdx,1),%ymm1,%ymm1
 10c7a3d:	vpxor  %ymm1,%ymm0,%ymm0
 10c7a41:	jmp    10c7ad3 <myl_native_text_equal+0x123>
 10c7a46:	mov    0x18(%rdi),%rax
 10c7a4a:	mov    0x14(%rdi),%ecx
 10c7a4d:	lea    (%rax,%rcx,1),%rdi
 10c7a51:	add    $0x18,%rdi
 10c7a55:	testb  $0x4,0x10(%rsi)
 10c7a59:	jne    10c7a00 <myl_native_text_equal+0x50>
 10c7a5b:	add    $0x18,%rsi
 10c7a5f:	cmp    $0x10,%rdx
 10c7a63:	ja     10c7a15 <myl_native_text_equal+0x65>
 10c7a65:	cmp    $0x8,%rdx
 10c7a69:	jb     10c7aa3 <myl_native_text_equal+0xf3>
 10c7a6b:	mov    (%rdi),%rcx
 10c7a6e:	mov    -0x8(%rdi,%rdx,1),%rdi
 10c7a73:	xor    (%rsi),%rcx
 10c7a76:	xor    -0x8(%rsi,%rdx,1),%rdi
 10c7a7b:	xor    %eax,%eax
 10c7a7d:	or     %rcx,%rdi
 10c7a80:	jmp    10c7ada <myl_native_text_equal+0x12a>
 10c7a82:	cmp    $0x100,%rdx
 10c7a89:	ja     10c7b10 <equal_large_octets>
 10c7a8f:	push   %rbp
 10c7a90:	mov    %rsp,%rbp
 10c7a93:	call   10df580 <bcmp>
 10c7a98:	mov    %eax,%ecx
 10c7a9a:	xor    %eax,%eax
 10c7a9c:	test   %ecx,%ecx
 10c7a9e:	sete   %al
 10c7aa1:	pop    %rbp
 10c7aa2:	ret
 10c7aa3:	cmp    $0x4,%rdx
 10c7aa7:	jb     10c7ae1 <myl_native_text_equal+0x131>
 10c7aa9:	mov    (%rdi),%ecx
 10c7aab:	mov    -0x4(%rdi,%rdx,1),%edi
 10c7aaf:	xor    (%rsi),%ecx
 10c7ab1:	xor    -0x4(%rsi,%rdx,1),%edi
 10c7ab5:	xor    %eax,%eax
 10c7ab7:	or     %ecx,%edi
 10c7ab9:	jmp    10c7ada <myl_native_text_equal+0x12a>
 10c7abb:	vmovdqu -0x20(%rdi,%rdx,1),%ymm0
 10c7ac1:	vpxor  -0x20(%rsi,%rdx,1),%ymm0,%ymm0
 10c7ac7:	vmovdqu (%rdi),%ymm1
 10c7acb:	vpxor  (%rsi),%ymm1,%ymm1
 10c7acf:	vpor   %ymm0,%ymm1,%ymm0
 10c7ad3:	xor    %eax,%eax
 10c7ad5:	vptest %ymm0,%ymm0
 10c7ada:	sete   %al
 10c7add:	vzeroupper
 10c7ae0:	ret
 10c7ae1:	cmp    $0x1,%rdx
 10c7ae5:	jne    10c7af0 <myl_native_text_equal+0x140>
 10c7ae7:	movzbl (%rdi),%ecx
 10c7aea:	xor    %eax,%eax
 10c7aec:	cmp    (%rsi),%cl
 10c7aee:	jmp    10c7ada <myl_native_text_equal+0x12a>
 10c7af0:	movzwl (%rdi),%ecx
 10c7af3:	movzwl -0x2(%rdi,%rdx,1),%edi
 10c7af8:	xor    (%rsi),%cx
 10c7afb:	xor    -0x2(%rsi,%rdx,1),%di
 10c7b00:	xor    %eax,%eax
 10c7b02:	or     %cx,%di
 10c7b05:	jmp    10c7ada <myl_native_text_equal+0x12a>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
