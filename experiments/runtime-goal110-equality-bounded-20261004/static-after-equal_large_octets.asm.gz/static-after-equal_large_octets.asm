
/home/epentland/ai/canopy/mylang-worktrees/goal110-equality-bounded-20261004/.mylang-cache/goal110-equality-bounded-rf/runner/bin/text-my-llvm:     file format elf64-x86-64


Disassembly of section .text:

00000000010943e0 <equal_large_octets>:
 10943e0:	mov    (%rdi),%rcx
 10943e3:	xor    %eax,%eax
 10943e5:	cmp    (%rsi),%rcx
 10943e8:	jne    1094415 <equal_large_octets+0x35>
 10943ea:	mov    -0x8(%rsi,%rdx,1),%rcx
 10943ef:	cmp    %rcx,-0x8(%rdi,%rdx,1)
 10943f4:	jne    1094415 <equal_large_octets+0x35>
 10943f6:	push   %rbp
 10943f7:	mov    %rsp,%rbp
 10943fa:	add    $0x8,%rdi
 10943fe:	add    $0x8,%rsi
 1094402:	add    $0xfffffffffffffff0,%rdx
 1094406:	call   10ae350 <bcmp@plt>
 109440b:	mov    %eax,%ecx
 109440d:	xor    %eax,%eax
 109440f:	test   %ecx,%ecx
 1094411:	sete   %al
 1094414:	pop    %rbp
 1094415:	ret

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
