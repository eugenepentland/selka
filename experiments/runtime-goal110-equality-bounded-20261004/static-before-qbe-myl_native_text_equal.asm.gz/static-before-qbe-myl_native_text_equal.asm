
/home/epentland/ai/canopy/mylang-worktrees/goal110-g4-rf-20261004/.mylang-cache/goal110-g4-rf/runner/bin/text-my-qbe:     file format elf64-x86-64


Disassembly of section .text:

00000000010c79b0 <myl_native_text_equal>:
 10c79b0:	mov    $0x1,%eax
 10c79b5:	cmp    %rsi,%rdi
 10c79b8:	je     10c7ab1 <myl_native_text_equal+0x101>
 10c79be:	test   %rdi,%rdi
 10c79c1:	sete   %cl
 10c79c4:	test   %rsi,%rsi
 10c79c7:	sete   %dl
 10c79ca:	xor    %eax,%eax
 10c79cc:	or     %cl,%dl
 10c79ce:	jne    10c7ab1 <myl_native_text_equal+0x101>
 10c79d4:	mov    0x8(%rdi),%rdx
 10c79d8:	cmp    0x8(%rsi),%rdx
 10c79dc:	jne    10c7ab1 <myl_native_text_equal+0x101>
 10c79e2:	mov    $0x1,%eax
 10c79e7:	test   %rdx,%rdx
 10c79ea:	je     10c7ab1 <myl_native_text_equal+0x101>
 10c79f0:	testb  $0x4,0x10(%rdi)
 10c79f4:	jne    10c7a36 <myl_native_text_equal+0x86>
 10c79f6:	add    $0x18,%rdi
 10c79fa:	testb  $0x4,0x10(%rsi)
 10c79fe:	je     10c7a4b <myl_native_text_equal+0x9b>
 10c7a00:	mov    0x18(%rsi),%rax
 10c7a04:	mov    0x14(%rsi),%ecx
 10c7a07:	lea    (%rax,%rcx,1),%rsi
 10c7a0b:	add    $0x18,%rsi
 10c7a0f:	cmp    $0x10,%rdx
 10c7a13:	jbe    10c7a55 <myl_native_text_equal+0xa5>
 10c7a15:	cmp    $0x100,%rdx
 10c7a1c:	ja     10c7ac0 <equal_large_octets>
 10c7a22:	push   %rbp
 10c7a23:	mov    %rsp,%rbp
 10c7a26:	call   10df500 <bcmp>
 10c7a2b:	mov    %eax,%ecx
 10c7a2d:	xor    %eax,%eax
 10c7a2f:	test   %ecx,%ecx
 10c7a31:	sete   %al
 10c7a34:	pop    %rbp
 10c7a35:	ret
 10c7a36:	mov    0x18(%rdi),%rax
 10c7a3a:	mov    0x14(%rdi),%ecx
 10c7a3d:	lea    (%rax,%rcx,1),%rdi
 10c7a41:	add    $0x18,%rdi
 10c7a45:	testb  $0x4,0x10(%rsi)
 10c7a49:	jne    10c7a00 <myl_native_text_equal+0x50>
 10c7a4b:	add    $0x18,%rsi
 10c7a4f:	cmp    $0x10,%rdx
 10c7a53:	ja     10c7a15 <myl_native_text_equal+0x65>
 10c7a55:	cmp    $0x8,%rdx
 10c7a59:	jb     10c7a72 <myl_native_text_equal+0xc2>
 10c7a5b:	mov    (%rdi),%rcx
 10c7a5e:	mov    -0x8(%rdi,%rdx,1),%rdi
 10c7a63:	xor    (%rsi),%rcx
 10c7a66:	xor    -0x8(%rsi,%rdx,1),%rdi
 10c7a6b:	xor    %eax,%eax
 10c7a6d:	or     %rcx,%rdi
 10c7a70:	jmp    10c7aae <myl_native_text_equal+0xfe>
 10c7a72:	cmp    $0x4,%rdx
 10c7a76:	jb     10c7a8a <myl_native_text_equal+0xda>
 10c7a78:	mov    (%rdi),%ecx
 10c7a7a:	mov    -0x4(%rdi,%rdx,1),%edi
 10c7a7e:	xor    (%rsi),%ecx
 10c7a80:	xor    -0x4(%rsi,%rdx,1),%edi
 10c7a84:	xor    %eax,%eax
 10c7a86:	or     %ecx,%edi
 10c7a88:	jmp    10c7aae <myl_native_text_equal+0xfe>
 10c7a8a:	cmp    $0x1,%rdx
 10c7a8e:	jne    10c7a99 <myl_native_text_equal+0xe9>
 10c7a90:	movzbl (%rdi),%ecx
 10c7a93:	xor    %eax,%eax
 10c7a95:	cmp    (%rsi),%cl
 10c7a97:	jmp    10c7aae <myl_native_text_equal+0xfe>
 10c7a99:	movzwl (%rdi),%ecx
 10c7a9c:	movzwl -0x2(%rdi,%rdx,1),%edi
 10c7aa1:	xor    (%rsi),%cx
 10c7aa4:	xor    -0x2(%rsi,%rdx,1),%di
 10c7aa9:	xor    %eax,%eax
 10c7aab:	or     %cx,%di
 10c7aae:	sete   %al
 10c7ab1:	ret

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
