
/home/epentland/ai/canopy/mylang-worktrees/goal110-g4-rf-20261004/.mylang-cache/goal110-g4-rf/runner/bin/text-my-llvm:     file format elf64-x86-64


Disassembly of section .text:

0000000001093490 <equal_large_octets>:
 1093490:	mov    (%rdi),%rcx
 1093493:	xor    %eax,%eax
 1093495:	cmp    (%rsi),%rcx
 1093498:	jne    10934c5 <equal_large_octets+0x35>
 109349a:	mov    -0x8(%rsi,%rdx,1),%rcx
 109349f:	cmp    %rcx,-0x8(%rdi,%rdx,1)
 10934a4:	jne    10934c5 <equal_large_octets+0x35>
 10934a6:	push   %rbp
 10934a7:	mov    %rsp,%rbp
 10934aa:	add    $0x8,%rdi
 10934ae:	add    $0x8,%rsi
 10934b2:	add    $0xfffffffffffffff0,%rdx
 10934b6:	call   10ad360 <bcmp@plt>
 10934bb:	mov    %eax,%ecx
 10934bd:	xor    %eax,%eax
 10934bf:	test   %ecx,%ecx
 10934c1:	sete   %al
 10934c4:	pop    %rbp
 10934c5:	ret

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
