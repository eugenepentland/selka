   270e1:	mov    0x1e0(%rsp),%r14
   270e9:	mov    0x1e8(%rsp),%rax
   270f1:	mov    %rax,0x8(%rsp)
   270f6:	mov    0x200(%rsp),%rbx
   270fe:	mov    0x1f8(%rsp),%r15
   27106:	xor    %r12d,%r12d
   27109:	lea    0x58268(%rip),%rax        # 7f378 <__frame_dummy_init_array_entry+0x198>
   27110:	mov    %rax,0x70(%rsp)
   27115:	mov    0x5b08c(%rip),%r13        # 821a8 <bcmp@GLIBC_2.2.5>
   2711c:	movabs $0x89705f3112a28fe5,%rbp
   27126:	jmp    27184 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4274>
   27128:	nopl   0x0(%rax,%rax,1)
   27130:	lea    (%r14,%rax,1),%rcx
   27134:	add    %r15,%rax
   27137:	mov    0x8(%rax),%rsi
   2713b:	mov    0x8(%rcx),%rdi
   2713f:	call   *%r13
   27142:	xor    %ecx,%ecx
   27144:	test   %eax,%eax
   27146:	sete   %cl
   27149:	add    %r12,%rcx
   2714c:	mov    %rcx,%rax
   2714f:	imul   %rbp
   27152:	add    %rcx,%rdx
   27155:	mov    %rdx,%rax
   27158:	shr    $0x3f,%rax
   2715c:	sar    $0x1d,%rdx
   27160:	add    %rax,%rdx
   27163:	imul   $0x3b9aca07,%rdx,%rax
   2716a:	sub    %rax,%rcx
   2716d:	incq   0x10(%rsp)
   27172:	mov    %rcx,(%rsp)
   27176:	mov    %rcx,%r12
   27179:	decq   0x18(%rsp)
   2717e:	je     259bd <_RNvCseJ3uQ9fe193_12runtime_text4main+0x2aad>
   27184:	mov    0x10(%rsp),%rdi
   27189:	and    $0x3,%edi
   2718c:	cmp    0x8(%rsp),%rdi
   27191:	jae    27a63 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4b53>
   27197:	cmp    %rbx,%rdi
   2719a:	jae    27ae2 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4bd2>
   271a0:	shl    $0x3,%edi
   271a3:	lea    (%rdi,%rdi,2),%rax
   271a7:	mov    0x10(%r14,%rax,1),%rdx
   271ac:	cmp    0x10(%r15,%rax,1),%rdx
   271b1:	je     27130 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4220>
   271b7:	xor    %ecx,%ecx
   271b9:	jmp    27149 <_RNvCseJ3uQ9fe193_12runtime_text4main+0x4239>
