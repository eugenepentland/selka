
/home/epentland/ai/canopy/mylang-worktrees/d9-rc-mut-argument-astra/.tmp-mut-argument/retain-run/alloc-churn-qbe-before-rc:     file format elf64-x86-64


Disassembly of section .text:

00000000010173e0 <myl_rc_native_retain>:
 10173e0:	55                   	push   %rbp
 10173e1:	48 89 e5             	mov    %rsp,%rbp
 10173e4:	41 57                	push   %r15
 10173e6:	41 56                	push   %r14
 10173e8:	41 55                	push   %r13
 10173ea:	41 54                	push   %r12
 10173ec:	53                   	push   %rbx
 10173ed:	48 83 ec 48          	sub    $0x48,%rsp
 10173f1:	45 89 c5             	mov    %r8d,%r13d
 10173f4:	48 89 4d d0          	mov    %rcx,-0x30(%rbp)
 10173f8:	49 89 d4             	mov    %rdx,%r12
 10173fb:	49 89 f6             	mov    %rsi,%r14
 10173fe:	48 89 fb             	mov    %rdi,%rbx
 1017401:	e8 8a f8 ff ff       	call   1016c90 <myl_rc_native_shape>
 1017406:	48 85 c0             	test   %rax,%rax
 1017409:	74 7b                	je     1017486 <myl_rc_native_retain+0xa6>
 101740b:	49 89 c7             	mov    %rax,%r15
 101740e:	48 89 df             	mov    %rbx,%rdi
 1017411:	4c 89 f6             	mov    %r14,%rsi
 1017414:	e8 b7 a9 ff ff       	call   1011dd0 <myl_rc_native_has_unique>
 1017419:	85 c0                	test   %eax,%eax
 101741b:	0f 85 8f 00 00 00    	jne    10174b0 <myl_rc_native_retain+0xd0>
 1017421:	49 8b 16             	mov    (%r14),%rdx
 1017424:	45 31 f6             	xor    %r14d,%r14d
 1017427:	4c 89 e7             	mov    %r12,%rdi
 101742a:	31 f6                	xor    %esi,%esi
 101742c:	e8 5f 01 00 00       	call   1017590 <compiler_rt.fastMemset>
 1017431:	4c 89 7d b0          	mov    %r15,-0x50(%rbp)
 1017435:	4c 89 65 b8          	mov    %r12,-0x48(%rbp)
 1017439:	48 c7 45 c0 00 00 00 	movq   $0x0,-0x40(%rbp)
 1017440:	00 
 1017441:	44 89 6d c8          	mov    %r13d,-0x38(%rbp)
 1017445:	c7 45 cc 00 00 00 00 	movl   $0x0,-0x34(%rbp)
 101744c:	4c 89 7d 90          	mov    %r15,-0x70(%rbp)
 1017450:	48 8b 45 d0          	mov    -0x30(%rbp),%rax
 1017454:	48 89 45 98          	mov    %rax,-0x68(%rbp)
 1017458:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
 101745c:	c5 f8 11 45 a0       	vmovups %xmm0,-0x60(%rbp)
 1017461:	48 8d 75 b0          	lea    -0x50(%rbp),%rsi
 1017465:	48 8d 55 90          	lea    -0x70(%rbp),%rdx
 1017469:	b9 01 00 00 00       	mov    $0x1,%ecx
 101746e:	48 89 df             	mov    %rbx,%rdi
 1017471:	e8 da d9 ff ff       	call   1014e50 <myl_rc_value_retain_many>
 1017476:	85 c0                	test   %eax,%eax
 1017478:	74 1e                	je     1017498 <myl_rc_native_retain+0xb8>
 101747a:	48 89 df             	mov    %rbx,%rdi
 101747d:	89 c6                	mov    %eax,%esi
 101747f:	e8 dc 7e ff ff       	call   100f360 <myl_rc_record_failure>
 1017484:	eb 18                	jmp    101749e <myl_rc_native_retain+0xbe>
 1017486:	49 8b 16             	mov    (%r14),%rdx
 1017489:	45 31 f6             	xor    %r14d,%r14d
 101748c:	4c 89 e7             	mov    %r12,%rdi
 101748f:	31 f6                	xor    %esi,%esi
 1017491:	e8 fa 00 00 00       	call   1017590 <compiler_rt.fastMemset>
 1017496:	eb 06                	jmp    101749e <myl_rc_native_retain+0xbe>
 1017498:	41 be 01 00 00 00    	mov    $0x1,%r14d
 101749e:	44 89 f0             	mov    %r14d,%eax
 10174a1:	48 83 c4 48          	add    $0x48,%rsp
 10174a5:	5b                   	pop    %rbx
 10174a6:	41 5c                	pop    %r12
 10174a8:	41 5d                	pop    %r13
 10174aa:	41 5e                	pop    %r14
 10174ac:	41 5f                	pop    %r15
 10174ae:	5d                   	pop    %rbp
 10174af:	c3                   	ret
 10174b0:	e8 50 7d ff ff       	call   100f205 <myl_rc_invariant_failed>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
