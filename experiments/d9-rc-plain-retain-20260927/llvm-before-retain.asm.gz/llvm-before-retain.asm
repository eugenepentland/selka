
/home/epentland/ai/canopy/mylang-worktrees/d9-rc-mut-argument-astra/.tmp-mut-argument/retain-run/alloc-churn-llvm-before-rc:     file format elf64-x86-64


Disassembly of section .text:

0000000001018050 <myl_rc_native_retain>:
 1018050:	55                   	push   %rbp
 1018051:	48 89 e5             	mov    %rsp,%rbp
 1018054:	41 57                	push   %r15
 1018056:	41 56                	push   %r14
 1018058:	41 55                	push   %r13
 101805a:	41 54                	push   %r12
 101805c:	53                   	push   %rbx
 101805d:	48 81 ec 08 02 00 00 	sub    $0x208,%rsp
 1018064:	44 89 45 d4          	mov    %r8d,-0x2c(%rbp)
 1018068:	48 89 4d c8          	mov    %rcx,-0x38(%rbp)
 101806c:	49 89 d6             	mov    %rdx,%r14
 101806f:	49 89 f5             	mov    %rsi,%r13
 1018072:	48 89 fb             	mov    %rdi,%rbx
 1018075:	e8 36 f8 ff ff       	call   10178b0 <myl_rc_native_shape>
 101807a:	48 85 c0             	test   %rax,%rax
 101807d:	0f 84 da 02 00 00    	je     101835d <myl_rc_native_retain+0x30d>
 1018083:	48 85 db             	test   %rbx,%rbx
 1018086:	0f 84 63 04 00 00    	je     10184ef <myl_rc_native_retain+0x49f>
 101808c:	49 89 c7             	mov    %rax,%r15
 101808f:	48 8b 83 08 16 00 00 	mov    0x1608(%rbx),%rax
 1018096:	48 85 c0             	test   %rax,%rax
 1018099:	0f 84 50 04 00 00    	je     10184ef <myl_rc_native_retain+0x49f>
 101809f:	48 83 78 58 00       	cmpq   $0x0,0x58(%rax)
 10180a4:	0f 85 45 04 00 00    	jne    10184ef <myl_rc_native_retain+0x49f>
 10180aa:	49 bc b9 e5 e4 1c 6d 	movabs $0xbf58476d1ce4e5b9,%r12
 10180b1:	47 58 bf 
 10180b4:	31 f6                	xor    %esi,%esi
 10180b6:	b9 1c 00 00 00       	mov    $0x1c,%ecx
 10180bb:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
 10180bf:	ba 60 01 00 00       	mov    $0x160,%edx
 10180c4:	4c 89 ef             	mov    %r13,%rdi
 10180c7:	44 8b 47 30          	mov    0x30(%rdi),%r8d
 10180cb:	41 83 f8 08          	cmp    $0x8,%r8d
 10180cf:	77 36                	ja     1018107 <myl_rc_native_retain+0xb7>
 10180d1:	44 0f a3 c1          	bt     %r8d,%ecx
 10180d5:	0f 83 c5 00 00 00    	jae    10181a0 <myl_rc_native_retain+0x150>
 10180db:	48 3b 70 50          	cmp    0x50(%rax),%rsi
 10180df:	0f 83 0a 04 00 00    	jae    10184ef <myl_rc_native_retain+0x49f>
 10180e5:	4c 8b 40 48          	mov    0x48(%rax),%r8
 10180e9:	4c 8d 4e 01          	lea    0x1(%rsi),%r9
 10180ed:	4c 89 48 58          	mov    %r9,0x58(%rax)
 10180f1:	48 8d 04 76          	lea    (%rsi,%rsi,2),%rax
 10180f5:	49 89 3c c0          	mov    %rdi,(%r8,%rax,8)
 10180f9:	c4 c1 78 11 44 c0 08 	vmovups %xmm0,0x8(%r8,%rax,8)
 1018100:	48 8b 83 08 16 00 00 	mov    0x1608(%rbx),%rax
 1018107:	48 8b 70 58          	mov    0x58(%rax),%rsi
 101810b:	48 85 f6             	test   %rsi,%rsi
 101810e:	0f 84 49 01 00 00    	je     101825d <myl_rc_native_retain+0x20d>
 1018114:	48 8d 3c 76          	lea    (%rsi,%rsi,2),%rdi
 1018118:	48 c1 e7 03          	shl    $0x3,%rdi
 101811c:	48 03 78 48          	add    0x48(%rax),%rdi
 1018120:	4c 8b 47 e8          	mov    -0x18(%rdi),%r8
 1018124:	41 83 78 30 03       	cmpl   $0x3,0x30(%r8)
 1018129:	75 25                	jne    1018150 <myl_rc_native_retain+0x100>
 101812b:	45 31 c9             	xor    %r9d,%r9d
 101812e:	49 83 78 20 00       	cmpq   $0x0,0x20(%r8)
 1018133:	41 0f 95 c1          	setne  %r9b
 1018137:	4c 8b 57 f8          	mov    -0x8(%rdi),%r10
 101813b:	4d 39 ca             	cmp    %r9,%r10
 101813e:	73 1d                	jae    101815d <myl_rc_native_retain+0x10d>
 1018140:	eb 2e                	jmp    1018170 <myl_rc_native_retain+0x120>
 1018142:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1018149:	1f 84 00 00 00 00 00 
 1018150:	4d 8b 48 18          	mov    0x18(%r8),%r9
 1018154:	4c 8b 57 f8          	mov    -0x8(%rdi),%r10
 1018158:	4d 39 ca             	cmp    %r9,%r10
 101815b:	72 13                	jb     1018170 <myl_rc_native_retain+0x120>
 101815d:	48 83 c7 e8          	add    $0xffffffffffffffe8,%rdi
 1018161:	48 ff ce             	dec    %rsi
 1018164:	48 89 70 58          	mov    %rsi,0x58(%rax)
 1018168:	75 b6                	jne    1018120 <myl_rc_native_retain+0xd0>
 101816a:	e9 ee 00 00 00       	jmp    101825d <myl_rc_native_retain+0x20d>
 101816f:	90                   	nop
 1018170:	4d 8b 40 10          	mov    0x10(%r8),%r8
 1018174:	4d 8d 4a 01          	lea    0x1(%r10),%r9
 1018178:	4c 89 4f f8          	mov    %r9,-0x8(%rdi)
 101817c:	4b 8d 3c 52          	lea    (%r10,%r10,2),%rdi
 1018180:	49 8b 7c f8 08       	mov    0x8(%r8,%rdi,8),%rdi
 1018185:	44 8b 47 30          	mov    0x30(%rdi),%r8d
 1018189:	41 83 f8 08          	cmp    $0x8,%r8d
 101818d:	0f 86 3e ff ff ff    	jbe    10180d1 <myl_rc_native_retain+0x81>
 1018193:	e9 6f ff ff ff       	jmp    1018107 <myl_rc_native_retain+0xb7>
 1018198:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
 101819f:	00 
 10181a0:	41 83 f8 01          	cmp    $0x1,%r8d
 10181a4:	0f 85 9c 00 00 00    	jne    1018246 <myl_rc_native_retain+0x1f6>
 10181aa:	83 7f 34 05          	cmpl   $0x5,0x34(%rdi)
 10181ae:	0f 85 53 ff ff ff    	jne    1018107 <myl_rc_native_retain+0xb7>
 10181b4:	48 8b 77 38          	mov    0x38(%rdi),%rsi
 10181b8:	48 85 f6             	test   %rsi,%rsi
 10181bb:	0f 84 46 ff ff ff    	je     1018107 <myl_rc_native_retain+0xb7>
 10181c1:	48 8b 78 40          	mov    0x40(%rax),%rdi
 10181c5:	48 85 ff             	test   %rdi,%rdi
 10181c8:	0f 84 21 03 00 00    	je     10184ef <myl_rc_native_retain+0x49f>
 10181ce:	4c 8b 40 30          	mov    0x30(%rax),%r8
 10181d2:	49 89 f1             	mov    %rsi,%r9
 10181d5:	49 c1 e9 03          	shr    $0x3,%r9
 10181d9:	49 89 f2             	mov    %rsi,%r10
 10181dc:	49 c1 ea 21          	shr    $0x21,%r10
 10181e0:	4d 31 ca             	xor    %r9,%r10
 10181e3:	4d 0f af d4          	imul   %r12,%r10
 10181e7:	4d 89 d1             	mov    %r10,%r9
 10181ea:	49 c1 e9 1b          	shr    $0x1b,%r9
 10181ee:	4d 31 d1             	xor    %r10,%r9
 10181f1:	49 83 f1 02          	xor    $0x2,%r9
 10181f5:	48 ff cf             	dec    %rdi
 10181f8:	eb 09                	jmp    1018203 <myl_rc_native_retain+0x1b3>
 10181fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
 1018200:	49 ff c1             	inc    %r9
 1018203:	49 21 f9             	and    %rdi,%r9
 1018206:	4f 8d 14 89          	lea    (%r9,%r9,4),%r10
 101820a:	4f 8b 14 d0          	mov    (%r8,%r10,8),%r10
 101820e:	4d 85 d2             	test   %r10,%r10
 1018211:	0f 84 d8 02 00 00    	je     10184ef <myl_rc_native_retain+0x49f>
 1018217:	49 39 f2             	cmp    %rsi,%r10
 101821a:	75 e4                	jne    1018200 <myl_rc_native_retain+0x1b0>
 101821c:	4f 8d 14 89          	lea    (%r9,%r9,4),%r10
 1018220:	43 83 7c d0 20 02    	cmpl   $0x2,0x20(%r8,%r10,8)
 1018226:	75 d8                	jne    1018200 <myl_rc_native_retain+0x1b0>
 1018228:	4b 8d 34 d0          	lea    (%r8,%r10,8),%rsi
 101822c:	48 8b 76 08          	mov    0x8(%rsi),%rsi
 1018230:	48 85 f6             	test   %rsi,%rsi
 1018233:	0f 84 b6 02 00 00    	je     10184ef <myl_rc_native_retain+0x49f>
 1018239:	48 83 7e 18 00       	cmpq   $0x0,0x18(%rsi)
 101823e:	0f 84 c3 fe ff ff    	je     1018107 <myl_rc_native_retain+0xb7>
 1018244:	eb 0a                	jmp    1018250 <myl_rc_native_retain+0x200>
 1018246:	44 0f a3 c2          	bt     %r8d,%edx
 101824a:	0f 83 b7 fe ff ff    	jae    1018107 <myl_rc_native_retain+0xb7>
 1018250:	48 c7 40 58 00 00 00 	movq   $0x0,0x58(%rax)
 1018257:	00 
 1018258:	e8 37 86 ff ff       	call   1010894 <myl_rc_invariant_failed>
 101825d:	49 8b 55 00          	mov    0x0(%r13),%rdx
 1018261:	4c 89 f7             	mov    %r14,%rdi
 1018264:	31 f6                	xor    %esi,%esi
 1018266:	e8 05 36 00 00       	call   101b870 <memset@plt>
 101826b:	48 8b 83 08 16 00 00 	mov    0x1608(%rbx),%rax
 1018272:	48 85 c0             	test   %rax,%rax
 1018275:	0f 84 74 02 00 00    	je     10184ef <myl_rc_native_retain+0x49f>
 101827b:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
 101827f:	c5 fc 11 85 70 ff ff 	vmovups %ymm0,-0x90(%rbp)
 1018286:	ff 
 1018287:	c5 fc 11 85 50 ff ff 	vmovups %ymm0,-0xb0(%rbp)
 101828e:	ff 
 101828f:	c5 fc 11 85 30 ff ff 	vmovups %ymm0,-0xd0(%rbp)
 1018296:	ff 
 1018297:	c5 fc 11 85 10 ff ff 	vmovups %ymm0,-0xf0(%rbp)
 101829e:	ff 
 101829f:	c5 fc 11 85 f0 fe ff 	vmovups %ymm0,-0x110(%rbp)
 10182a6:	ff 
 10182a7:	c5 fc 11 85 d0 fe ff 	vmovups %ymm0,-0x130(%rbp)
 10182ae:	ff 
 10182af:	48 c7 45 90 00 00 00 	movq   $0x0,-0x70(%rbp)
 10182b6:	00 
 10182b7:	48 89 5d 98          	mov    %rbx,-0x68(%rbp)
 10182bb:	48 8d 8d d0 fd ff ff 	lea    -0x230(%rbp),%rcx
 10182c2:	48 89 4d a0          	mov    %rcx,-0x60(%rbp)
 10182c6:	48 c7 45 a8 08 00 00 	movq   $0x8,-0x58(%rbp)
 10182cd:	00 
 10182ce:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
 10182d2:	c5 f8 11 45 b0       	vmovups %xmm0,-0x50(%rbp)
 10182d7:	48 8d 8d d0 fe ff ff 	lea    -0x130(%rbp),%rcx
 10182de:	48 89 4d c0          	mov    %rcx,-0x40(%rbp)
 10182e2:	48 8b 48 40          	mov    0x40(%rax),%rcx
 10182e6:	48 85 c9             	test   %rcx,%rcx
 10182e9:	0f 84 83 00 00 00    	je     1018372 <myl_rc_native_retain+0x322>
 10182ef:	48 8b 50 30          	mov    0x30(%rax),%rdx
 10182f3:	4c 89 fe             	mov    %r15,%rsi
 10182f6:	48 c1 ee 03          	shr    $0x3,%rsi
 10182fa:	4c 89 ff             	mov    %r15,%rdi
 10182fd:	48 c1 ef 21          	shr    $0x21,%rdi
 1018301:	48 31 f7             	xor    %rsi,%rdi
 1018304:	49 0f af fc          	imul   %r12,%rdi
 1018308:	48 89 fe             	mov    %rdi,%rsi
 101830b:	48 c1 ee 1b          	shr    $0x1b,%rsi
 101830f:	48 31 fe             	xor    %rdi,%rsi
 1018312:	48 83 f6 01          	xor    $0x1,%rsi
 1018316:	48 ff c9             	dec    %rcx
 1018319:	48 21 ce             	and    %rcx,%rsi
 101831c:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
 1018320:	48 8b 3c fa          	mov    (%rdx,%rdi,8),%rdi
 1018324:	45 31 ed             	xor    %r13d,%r13d
 1018327:	eb 15                	jmp    101833e <myl_rc_native_retain+0x2ee>
 1018329:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
 1018330:	48 ff c6             	inc    %rsi
 1018333:	48 21 ce             	and    %rcx,%rsi
 1018336:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
 101833a:	48 8b 3c fa          	mov    (%rdx,%rdi,8),%rdi
 101833e:	48 85 ff             	test   %rdi,%rdi
 1018341:	74 32                	je     1018375 <myl_rc_native_retain+0x325>
 1018343:	4c 39 ff             	cmp    %r15,%rdi
 1018346:	75 e8                	jne    1018330 <myl_rc_native_retain+0x2e0>
 1018348:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
 101834c:	83 7c fa 20 01       	cmpl   $0x1,0x20(%rdx,%rdi,8)
 1018351:	75 dd                	jne    1018330 <myl_rc_native_retain+0x2e0>
 1018353:	48 8d 0c fa          	lea    (%rdx,%rdi,8),%rcx
 1018357:	4c 8b 69 08          	mov    0x8(%rcx),%r13
 101835b:	eb 18                	jmp    1018375 <myl_rc_native_retain+0x325>
 101835d:	49 8b 55 00          	mov    0x0(%r13),%rdx
 1018361:	31 db                	xor    %ebx,%ebx
 1018363:	4c 89 f7             	mov    %r14,%rdi
 1018366:	31 f6                	xor    %esi,%esi
 1018368:	e8 03 35 00 00       	call   101b870 <memset@plt>
 101836d:	e9 57 01 00 00       	jmp    10184c9 <myl_rc_native_retain+0x479>
 1018372:	45 31 ed             	xor    %r13d,%r13d
 1018375:	48 8b 48 40          	mov    0x40(%rax),%rcx
 1018379:	48 85 c9             	test   %rcx,%rcx
 101837c:	0f 84 6d 01 00 00    	je     10184ef <myl_rc_native_retain+0x49f>
 1018382:	48 8b 40 30          	mov    0x30(%rax),%rax
 1018386:	4c 89 fa             	mov    %r15,%rdx
 1018389:	48 c1 ea 03          	shr    $0x3,%rdx
 101838d:	4c 89 fe             	mov    %r15,%rsi
 1018390:	48 c1 ee 21          	shr    $0x21,%rsi
 1018394:	48 31 d6             	xor    %rdx,%rsi
 1018397:	49 0f af f4          	imul   %r12,%rsi
 101839b:	48 89 f2             	mov    %rsi,%rdx
 101839e:	48 c1 ea 1b          	shr    $0x1b,%rdx
 10183a2:	48 31 f2             	xor    %rsi,%rdx
 10183a5:	48 83 f2 01          	xor    $0x1,%rdx
 10183a9:	48 ff c9             	dec    %rcx
 10183ac:	eb 05                	jmp    10183b3 <myl_rc_native_retain+0x363>
 10183ae:	66 90                	xchg   %ax,%ax
 10183b0:	48 ff c2             	inc    %rdx
 10183b3:	48 21 ca             	and    %rcx,%rdx
 10183b6:	48 8d 34 92          	lea    (%rdx,%rdx,4),%rsi
 10183ba:	48 8b 34 f0          	mov    (%rax,%rsi,8),%rsi
 10183be:	48 85 f6             	test   %rsi,%rsi
 10183c1:	0f 84 28 01 00 00    	je     10184ef <myl_rc_native_retain+0x49f>
 10183c7:	4c 39 fe             	cmp    %r15,%rsi
 10183ca:	75 e4                	jne    10183b0 <myl_rc_native_retain+0x360>
 10183cc:	48 8d 34 92          	lea    (%rdx,%rdx,4),%rsi
 10183d0:	83 7c f0 20 01       	cmpl   $0x1,0x20(%rax,%rsi,8)
 10183d5:	75 d9                	jne    10183b0 <myl_rc_native_retain+0x360>
 10183d7:	4d 85 ed             	test   %r13,%r13
 10183da:	0f 84 0f 01 00 00    	je     10184ef <myl_rc_native_retain+0x49f>
 10183e0:	48 8d 04 f0          	lea    (%rax,%rsi,8),%rax
 10183e4:	48 8b 40 08          	mov    0x8(%rax),%rax
 10183e8:	48 85 c0             	test   %rax,%rax
 10183eb:	0f 84 fe 00 00 00    	je     10184ef <myl_rc_native_retain+0x49f>
 10183f1:	49 8b 4d 00          	mov    0x0(%r13),%rcx
 10183f5:	48 3b 08             	cmp    (%rax),%rcx
 10183f8:	0f 85 f1 00 00 00    	jne    10184ef <myl_rc_native_retain+0x49f>
 10183fe:	4c 39 75 c8          	cmp    %r14,-0x38(%rbp)
 1018402:	0f 84 e7 00 00 00    	je     10184ef <myl_rc_native_retain+0x49f>
 1018408:	41 bc 03 00 00 00    	mov    $0x3,%r12d
 101840e:	8b 45 d4             	mov    -0x2c(%rbp),%eax
 1018411:	3b 43 70             	cmp    0x70(%rbx),%eax
 1018414:	0f 87 86 00 00 00    	ja     10184a0 <myl_rc_native_retain+0x450>
 101841a:	48 8d 7d 98          	lea    -0x68(%rbp),%rdi
 101841e:	4c 89 ee             	mov    %r13,%rsi
 1018421:	c5 f8 77             	vzeroupper
 1018424:	e8 67 cd ff ff       	call   1015190 <prepare_frames>
 1018429:	41 bc 01 00 00 00    	mov    $0x1,%r12d
 101842f:	85 c0                	test   %eax,%eax
 1018431:	75 6d                	jne    10184a0 <myl_rc_native_retain+0x450>
 1018433:	41 b8 01 00 00 00    	mov    $0x1,%r8d
 1018439:	48 89 df             	mov    %rbx,%rdi
 101843c:	4c 89 ee             	mov    %r13,%rsi
 101843f:	4c 89 f2             	mov    %r14,%rdx
 1018442:	4c 8b 65 c8          	mov    -0x38(%rbp),%r12
 1018446:	4c 89 e1             	mov    %r12,%rcx
 1018449:	e8 42 ac ff ff       	call   1013090 <myl_rc_value_seed>
 101844e:	8b 45 d4             	mov    -0x2c(%rbp),%eax
 1018451:	89 45 b8             	mov    %eax,-0x48(%rbp)
 1018454:	48 8d 7d 98          	lea    -0x68(%rbp),%rdi
 1018458:	41 b8 20 6a 01 01    	mov    $0x1016a20,%r8d
 101845e:	4c 89 ee             	mov    %r13,%rsi
 1018461:	4c 89 f2             	mov    %r14,%rdx
 1018464:	4c 89 e1             	mov    %r12,%rcx
 1018467:	e8 a4 ce ff ff       	call   1015310 <visit>
 101846c:	85 c0                	test   %eax,%eax
 101846e:	75 0d                	jne    101847d <myl_rc_native_retain+0x42d>
 1018470:	48 8d 7d 98          	lea    -0x68(%rbp),%rdi
 1018474:	e8 77 de ff ff       	call   10162f0 <finish_clones>
 1018479:	85 c0                	test   %eax,%eax
 101847b:	74 60                	je     10184dd <myl_rc_native_retain+0x48d>
 101847d:	41 89 c4             	mov    %eax,%r12d
 1018480:	b9 01 00 00 00       	mov    $0x1,%ecx
 1018485:	48 89 df             	mov    %rbx,%rdi
 1018488:	4c 89 fe             	mov    %r15,%rsi
 101848b:	4c 89 f2             	mov    %r14,%rdx
 101848e:	e8 6d a3 ff ff       	call   1012800 <myl_rc_edges_release>
 1018493:	49 8b 17             	mov    (%r15),%rdx
 1018496:	4c 89 f7             	mov    %r14,%rdi
 1018499:	31 f6                	xor    %esi,%esi
 101849b:	e8 d0 33 00 00       	call   101b870 <memset@plt>
 10184a0:	48 8d 7d 98          	lea    -0x68(%rbp),%rdi
 10184a4:	be 01 00 00 00       	mov    $0x1,%esi
 10184a9:	c5 f8 77             	vzeroupper
 10184ac:	e8 df e1 ff ff       	call   1016690 <dispose_walk>
 10184b1:	48 8b 83 08 16 00 00 	mov    0x1608(%rbx),%rax
 10184b8:	48 85 c0             	test   %rax,%rax
 10184bb:	74 32                	je     10184ef <myl_rc_native_retain+0x49f>
 10184bd:	31 db                	xor    %ebx,%ebx
 10184bf:	83 78 78 00          	cmpl   $0x0,0x78(%rax)
 10184c3:	75 04                	jne    10184c9 <myl_rc_native_retain+0x479>
 10184c5:	44 89 60 78          	mov    %r12d,0x78(%rax)
 10184c9:	89 d8                	mov    %ebx,%eax
 10184cb:	48 81 c4 08 02 00 00 	add    $0x208,%rsp
 10184d2:	5b                   	pop    %rbx
 10184d3:	41 5c                	pop    %r12
 10184d5:	41 5d                	pop    %r13
 10184d7:	41 5e                	pop    %r14
 10184d9:	41 5f                	pop    %r15
 10184db:	5d                   	pop    %rbp
 10184dc:	c3                   	ret
 10184dd:	48 8d 7d 98          	lea    -0x68(%rbp),%rdi
 10184e1:	31 f6                	xor    %esi,%esi
 10184e3:	e8 a8 e1 ff ff       	call   1016690 <dispose_walk>
 10184e8:	bb 01 00 00 00       	mov    $0x1,%ebx
 10184ed:	eb da                	jmp    10184c9 <myl_rc_native_retain+0x479>
 10184ef:	c5 f8 77             	vzeroupper
 10184f2:	e8 9d 83 ff ff       	call   1010894 <myl_rc_invariant_failed>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
