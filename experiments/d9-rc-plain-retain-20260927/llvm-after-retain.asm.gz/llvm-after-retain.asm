
/home/epentland/ai/canopy/mylang-worktrees/d9-rc-mut-argument-astra/.tmp-mut-argument/retain-run/alloc-churn-llvm-after-rc:     file format elf64-x86-64


Disassembly of section .text:

0000000001018050 <myl_rc_native_retain>:
 1018050:	55                   	push   %rbp
 1018051:	48 89 e5             	mov    %rsp,%rbp
 1018054:	41 57                	push   %r15
 1018056:	41 56                	push   %r14
 1018058:	41 55                	push   %r13
 101805a:	41 54                	push   %r12
 101805c:	53                   	push   %rbx
 101805d:	48 81 ec 08 02 00 00 	sub    $0x208,%rsp
 1018064:	44 89 45 d4          	mov    %r8d,-0x2c(%rbp)
 1018068:	49 89 cf             	mov    %rcx,%r15
 101806b:	49 89 d6             	mov    %rdx,%r14
 101806e:	49 89 f4             	mov    %rsi,%r12
 1018071:	48 89 fb             	mov    %rdi,%rbx
 1018074:	48 85 ff             	test   %rdi,%rdi
 1018077:	0f 84 aa 00 00 00    	je     1018127 <myl_rc_native_retain+0xd7>
 101807d:	48 8b 83 08 16 00 00 	mov    0x1608(%rbx),%rax
 1018084:	48 85 c0             	test   %rax,%rax
 1018087:	0f 94 c1             	sete   %cl
 101808a:	4d 85 e4             	test   %r12,%r12
 101808d:	0f 94 c2             	sete   %dl
 1018090:	08 ca                	or     %cl,%dl
 1018092:	0f 85 8f 00 00 00    	jne    1018127 <myl_rc_native_retain+0xd7>
 1018098:	48 8b 48 40          	mov    0x40(%rax),%rcx
 101809c:	48 85 c9             	test   %rcx,%rcx
 101809f:	0f 84 82 00 00 00    	je     1018127 <myl_rc_native_retain+0xd7>
 10180a5:	48 8b 50 30          	mov    0x30(%rax),%rdx
 10180a9:	4c 89 e6             	mov    %r12,%rsi
 10180ac:	48 c1 ee 03          	shr    $0x3,%rsi
 10180b0:	4c 89 e7             	mov    %r12,%rdi
 10180b3:	48 c1 ef 21          	shr    $0x21,%rdi
 10180b7:	48 31 f7             	xor    %rsi,%rdi
 10180ba:	49 b8 b9 e5 e4 1c 6d 	movabs $0xbf58476d1ce4e5b9,%r8
 10180c1:	47 58 bf 
 10180c4:	4c 0f af c7          	imul   %rdi,%r8
 10180c8:	4c 89 c6             	mov    %r8,%rsi
 10180cb:	48 c1 ee 1b          	shr    $0x1b,%rsi
 10180cf:	4c 31 c6             	xor    %r8,%rsi
 10180d2:	48 83 f6 02          	xor    $0x2,%rsi
 10180d6:	48 ff c9             	dec    %rcx
 10180d9:	eb 08                	jmp    10180e3 <myl_rc_native_retain+0x93>
 10180db:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
 10180e0:	48 ff c6             	inc    %rsi
 10180e3:	48 21 ce             	and    %rcx,%rsi
 10180e6:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
 10180ea:	48 8b 3c fa          	mov    (%rdx,%rdi,8),%rdi
 10180ee:	48 85 ff             	test   %rdi,%rdi
 10180f1:	74 34                	je     1018127 <myl_rc_native_retain+0xd7>
 10180f3:	4c 39 e7             	cmp    %r12,%rdi
 10180f6:	75 e8                	jne    10180e0 <myl_rc_native_retain+0x90>
 10180f8:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
 10180fc:	83 7c fa 20 02       	cmpl   $0x2,0x20(%rdx,%rdi,8)
 1018101:	75 dd                	jne    10180e0 <myl_rc_native_retain+0x90>
 1018103:	48 8d 0c fa          	lea    (%rdx,%rdi,8),%rcx
 1018107:	48 8b 49 08          	mov    0x8(%rcx),%rcx
 101810b:	48 85 c9             	test   %rcx,%rcx
 101810e:	74 17                	je     1018127 <myl_rc_native_retain+0xd7>
 1018110:	83 79 78 00          	cmpl   $0x0,0x78(%rcx)
 1018114:	75 0b                	jne    1018121 <myl_rc_native_retain+0xd1>
 1018116:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
 101811b:	0f 84 96 04 00 00    	je     10185b7 <myl_rc_native_retain+0x567>
 1018121:	4c 8b 69 08          	mov    0x8(%rcx),%r13
 1018125:	eb 0e                	jmp    1018135 <myl_rc_native_retain+0xe5>
 1018127:	48 89 df             	mov    %rbx,%rdi
 101812a:	4c 89 e6             	mov    %r12,%rsi
 101812d:	e8 7e f7 ff ff       	call   10178b0 <myl_rc_native_shape>
 1018132:	49 89 c5             	mov    %rax,%r13
 1018135:	4d 85 ed             	test   %r13,%r13
 1018138:	0f 84 df 02 00 00    	je     101841d <myl_rc_native_retain+0x3cd>
 101813e:	4c 89 7d c8          	mov    %r15,-0x38(%rbp)
 1018142:	48 85 db             	test   %rbx,%rbx
 1018145:	0f 84 d6 04 00 00    	je     1018621 <myl_rc_native_retain+0x5d1>
 101814b:	48 8b 83 08 16 00 00 	mov    0x1608(%rbx),%rax
 1018152:	48 85 c0             	test   %rax,%rax
 1018155:	0f 84 c6 04 00 00    	je     1018621 <myl_rc_native_retain+0x5d1>
 101815b:	48 83 78 58 00       	cmpq   $0x0,0x58(%rax)
 1018160:	0f 85 bb 04 00 00    	jne    1018621 <myl_rc_native_retain+0x5d1>
 1018166:	49 bf b9 e5 e4 1c 6d 	movabs $0xbf58476d1ce4e5b9,%r15
 101816d:	47 58 bf 
 1018170:	31 f6                	xor    %esi,%esi
 1018172:	b9 1c 00 00 00       	mov    $0x1c,%ecx
 1018177:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
 101817b:	ba 60 01 00 00       	mov    $0x160,%edx
 1018180:	4c 89 e7             	mov    %r12,%rdi
 1018183:	44 8b 47 30          	mov    0x30(%rdi),%r8d
 1018187:	41 83 f8 08          	cmp    $0x8,%r8d
 101818b:	77 36                	ja     10181c3 <myl_rc_native_retain+0x173>
 101818d:	44 0f a3 c1          	bt     %r8d,%ecx
 1018191:	0f 83 c9 00 00 00    	jae    1018260 <myl_rc_native_retain+0x210>
 1018197:	48 3b 70 50          	cmp    0x50(%rax),%rsi
 101819b:	0f 83 80 04 00 00    	jae    1018621 <myl_rc_native_retain+0x5d1>
 10181a1:	4c 8b 40 48          	mov    0x48(%rax),%r8
 10181a5:	4c 8d 4e 01          	lea    0x1(%rsi),%r9
 10181a9:	4c 89 48 58          	mov    %r9,0x58(%rax)
 10181ad:	48 8d 04 76          	lea    (%rsi,%rsi,2),%rax
 10181b1:	49 89 3c c0          	mov    %rdi,(%r8,%rax,8)
 10181b5:	c4 c1 78 11 44 c0 08 	vmovups %xmm0,0x8(%r8,%rax,8)
 10181bc:	48 8b 83 08 16 00 00 	mov    0x1608(%rbx),%rax
 10181c3:	48 8b 70 58          	mov    0x58(%rax),%rsi
 10181c7:	48 85 f6             	test   %rsi,%rsi
 10181ca:	0f 84 4d 01 00 00    	je     101831d <myl_rc_native_retain+0x2cd>
 10181d0:	48 8d 3c 76          	lea    (%rsi,%rsi,2),%rdi
 10181d4:	48 c1 e7 03          	shl    $0x3,%rdi
 10181d8:	48 03 78 48          	add    0x48(%rax),%rdi
 10181dc:	0f 1f 40 00          	nopl   0x0(%rax)
 10181e0:	4c 8b 47 e8          	mov    -0x18(%rdi),%r8
 10181e4:	41 83 78 30 03       	cmpl   $0x3,0x30(%r8)
 10181e9:	75 25                	jne    1018210 <myl_rc_native_retain+0x1c0>
 10181eb:	45 31 c9             	xor    %r9d,%r9d
 10181ee:	49 83 78 20 00       	cmpq   $0x0,0x20(%r8)
 10181f3:	41 0f 95 c1          	setne  %r9b
 10181f7:	4c 8b 57 f8          	mov    -0x8(%rdi),%r10
 10181fb:	4d 39 ca             	cmp    %r9,%r10
 10181fe:	73 1d                	jae    101821d <myl_rc_native_retain+0x1cd>
 1018200:	eb 2e                	jmp    1018230 <myl_rc_native_retain+0x1e0>
 1018202:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1018209:	1f 84 00 00 00 00 00 
 1018210:	4d 8b 48 18          	mov    0x18(%r8),%r9
 1018214:	4c 8b 57 f8          	mov    -0x8(%rdi),%r10
 1018218:	4d 39 ca             	cmp    %r9,%r10
 101821b:	72 13                	jb     1018230 <myl_rc_native_retain+0x1e0>
 101821d:	48 83 c7 e8          	add    $0xffffffffffffffe8,%rdi
 1018221:	48 ff ce             	dec    %rsi
 1018224:	48 89 70 58          	mov    %rsi,0x58(%rax)
 1018228:	75 b6                	jne    10181e0 <myl_rc_native_retain+0x190>
 101822a:	e9 ee 00 00 00       	jmp    101831d <myl_rc_native_retain+0x2cd>
 101822f:	90                   	nop
 1018230:	4d 8b 40 10          	mov    0x10(%r8),%r8
 1018234:	4d 8d 4a 01          	lea    0x1(%r10),%r9
 1018238:	4c 89 4f f8          	mov    %r9,-0x8(%rdi)
 101823c:	4b 8d 3c 52          	lea    (%r10,%r10,2),%rdi
 1018240:	49 8b 7c f8 08       	mov    0x8(%r8,%rdi,8),%rdi
 1018245:	44 8b 47 30          	mov    0x30(%rdi),%r8d
 1018249:	41 83 f8 08          	cmp    $0x8,%r8d
 101824d:	0f 86 3a ff ff ff    	jbe    101818d <myl_rc_native_retain+0x13d>
 1018253:	e9 6b ff ff ff       	jmp    10181c3 <myl_rc_native_retain+0x173>
 1018258:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
 101825f:	00 
 1018260:	41 83 f8 01          	cmp    $0x1,%r8d
 1018264:	0f 85 9c 00 00 00    	jne    1018306 <myl_rc_native_retain+0x2b6>
 101826a:	83 7f 34 05          	cmpl   $0x5,0x34(%rdi)
 101826e:	0f 85 4f ff ff ff    	jne    10181c3 <myl_rc_native_retain+0x173>
 1018274:	48 8b 77 38          	mov    0x38(%rdi),%rsi
 1018278:	48 85 f6             	test   %rsi,%rsi
 101827b:	0f 84 42 ff ff ff    	je     10181c3 <myl_rc_native_retain+0x173>
 1018281:	48 8b 78 40          	mov    0x40(%rax),%rdi
 1018285:	48 85 ff             	test   %rdi,%rdi
 1018288:	0f 84 93 03 00 00    	je     1018621 <myl_rc_native_retain+0x5d1>
 101828e:	4c 8b 40 30          	mov    0x30(%rax),%r8
 1018292:	49 89 f1             	mov    %rsi,%r9
 1018295:	49 c1 e9 03          	shr    $0x3,%r9
 1018299:	49 89 f2             	mov    %rsi,%r10
 101829c:	49 c1 ea 21          	shr    $0x21,%r10
 10182a0:	4d 31 ca             	xor    %r9,%r10
 10182a3:	4d 0f af d7          	imul   %r15,%r10
 10182a7:	4d 89 d1             	mov    %r10,%r9
 10182aa:	49 c1 e9 1b          	shr    $0x1b,%r9
 10182ae:	4d 31 d1             	xor    %r10,%r9
 10182b1:	49 83 f1 02          	xor    $0x2,%r9
 10182b5:	48 ff cf             	dec    %rdi
 10182b8:	eb 09                	jmp    10182c3 <myl_rc_native_retain+0x273>
 10182ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
 10182c0:	49 ff c1             	inc    %r9
 10182c3:	49 21 f9             	and    %rdi,%r9
 10182c6:	4f 8d 14 89          	lea    (%r9,%r9,4),%r10
 10182ca:	4f 8b 14 d0          	mov    (%r8,%r10,8),%r10
 10182ce:	4d 85 d2             	test   %r10,%r10
 10182d1:	0f 84 4a 03 00 00    	je     1018621 <myl_rc_native_retain+0x5d1>
 10182d7:	49 39 f2             	cmp    %rsi,%r10
 10182da:	75 e4                	jne    10182c0 <myl_rc_native_retain+0x270>
 10182dc:	4f 8d 14 89          	lea    (%r9,%r9,4),%r10
 10182e0:	43 83 7c d0 20 02    	cmpl   $0x2,0x20(%r8,%r10,8)
 10182e6:	75 d8                	jne    10182c0 <myl_rc_native_retain+0x270>
 10182e8:	4b 8d 34 d0          	lea    (%r8,%r10,8),%rsi
 10182ec:	48 8b 76 08          	mov    0x8(%rsi),%rsi
 10182f0:	48 85 f6             	test   %rsi,%rsi
 10182f3:	0f 84 28 03 00 00    	je     1018621 <myl_rc_native_retain+0x5d1>
 10182f9:	48 83 7e 18 00       	cmpq   $0x0,0x18(%rsi)
 10182fe:	0f 84 bf fe ff ff    	je     10181c3 <myl_rc_native_retain+0x173>
 1018304:	eb 0a                	jmp    1018310 <myl_rc_native_retain+0x2c0>
 1018306:	44 0f a3 c2          	bt     %r8d,%edx
 101830a:	0f 83 b3 fe ff ff    	jae    10181c3 <myl_rc_native_retain+0x173>
 1018310:	48 c7 40 58 00 00 00 	movq   $0x0,0x58(%rax)
 1018317:	00 
 1018318:	e8 77 85 ff ff       	call   1010894 <myl_rc_invariant_failed>
 101831d:	49 8b 14 24          	mov    (%r12),%rdx
 1018321:	4c 89 f7             	mov    %r14,%rdi
 1018324:	31 f6                	xor    %esi,%esi
 1018326:	e8 75 36 00 00       	call   101b9a0 <memset@plt>
 101832b:	48 8b 83 08 16 00 00 	mov    0x1608(%rbx),%rax
 1018332:	48 85 c0             	test   %rax,%rax
 1018335:	0f 84 e6 02 00 00    	je     1018621 <myl_rc_native_retain+0x5d1>
 101833b:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
 101833f:	c5 fc 11 85 70 ff ff 	vmovups %ymm0,-0x90(%rbp)
 1018346:	ff 
 1018347:	c5 fc 11 85 50 ff ff 	vmovups %ymm0,-0xb0(%rbp)
 101834e:	ff 
 101834f:	c5 fc 11 85 30 ff ff 	vmovups %ymm0,-0xd0(%rbp)
 1018356:	ff 
 1018357:	c5 fc 11 85 10 ff ff 	vmovups %ymm0,-0xf0(%rbp)
 101835e:	ff 
 101835f:	c5 fc 11 85 f0 fe ff 	vmovups %ymm0,-0x110(%rbp)
 1018366:	ff 
 1018367:	c5 fc 11 85 d0 fe ff 	vmovups %ymm0,-0x130(%rbp)
 101836e:	ff 
 101836f:	48 c7 45 90 00 00 00 	movq   $0x0,-0x70(%rbp)
 1018376:	00 
 1018377:	48 89 5d 98          	mov    %rbx,-0x68(%rbp)
 101837b:	48 8d 8d d0 fd ff ff 	lea    -0x230(%rbp),%rcx
 1018382:	48 89 4d a0          	mov    %rcx,-0x60(%rbp)
 1018386:	48 c7 45 a8 08 00 00 	movq   $0x8,-0x58(%rbp)
 101838d:	00 
 101838e:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
 1018392:	c5 f8 11 45 b0       	vmovups %xmm0,-0x50(%rbp)
 1018397:	48 8d 8d d0 fe ff ff 	lea    -0x130(%rbp),%rcx
 101839e:	48 89 4d c0          	mov    %rcx,-0x40(%rbp)
 10183a2:	48 8b 48 40          	mov    0x40(%rax),%rcx
 10183a6:	48 85 c9             	test   %rcx,%rcx
 10183a9:	0f 84 84 00 00 00    	je     1018433 <myl_rc_native_retain+0x3e3>
 10183af:	48 8b 50 30          	mov    0x30(%rax),%rdx
 10183b3:	4c 89 ee             	mov    %r13,%rsi
 10183b6:	48 c1 ee 03          	shr    $0x3,%rsi
 10183ba:	4c 89 ef             	mov    %r13,%rdi
 10183bd:	48 c1 ef 21          	shr    $0x21,%rdi
 10183c1:	48 31 f7             	xor    %rsi,%rdi
 10183c4:	49 0f af ff          	imul   %r15,%rdi
 10183c8:	48 89 fe             	mov    %rdi,%rsi
 10183cb:	48 c1 ee 1b          	shr    $0x1b,%rsi
 10183cf:	48 31 fe             	xor    %rdi,%rsi
 10183d2:	48 83 f6 01          	xor    $0x1,%rsi
 10183d6:	48 ff c9             	dec    %rcx
 10183d9:	48 21 ce             	and    %rcx,%rsi
 10183dc:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
 10183e0:	48 8b 3c fa          	mov    (%rdx,%rdi,8),%rdi
 10183e4:	45 31 e4             	xor    %r12d,%r12d
 10183e7:	eb 15                	jmp    10183fe <myl_rc_native_retain+0x3ae>
 10183e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
 10183f0:	48 ff c6             	inc    %rsi
 10183f3:	48 21 ce             	and    %rcx,%rsi
 10183f6:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
 10183fa:	48 8b 3c fa          	mov    (%rdx,%rdi,8),%rdi
 10183fe:	48 85 ff             	test   %rdi,%rdi
 1018401:	74 33                	je     1018436 <myl_rc_native_retain+0x3e6>
 1018403:	4c 39 ef             	cmp    %r13,%rdi
 1018406:	75 e8                	jne    10183f0 <myl_rc_native_retain+0x3a0>
 1018408:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
 101840c:	83 7c fa 20 01       	cmpl   $0x1,0x20(%rdx,%rdi,8)
 1018411:	75 dd                	jne    10183f0 <myl_rc_native_retain+0x3a0>
 1018413:	48 8d 0c fa          	lea    (%rdx,%rdi,8),%rcx
 1018417:	4c 8b 61 08          	mov    0x8(%rcx),%r12
 101841b:	eb 19                	jmp    1018436 <myl_rc_native_retain+0x3e6>
 101841d:	49 8b 14 24          	mov    (%r12),%rdx
 1018421:	45 31 e4             	xor    %r12d,%r12d
 1018424:	4c 89 f7             	mov    %r14,%rdi
 1018427:	31 f6                	xor    %esi,%esi
 1018429:	e8 72 35 00 00       	call   101b9a0 <memset@plt>
 101842e:	e9 5c 01 00 00       	jmp    101858f <myl_rc_native_retain+0x53f>
 1018433:	45 31 e4             	xor    %r12d,%r12d
 1018436:	48 8b 48 40          	mov    0x40(%rax),%rcx
 101843a:	48 85 c9             	test   %rcx,%rcx
 101843d:	0f 84 de 01 00 00    	je     1018621 <myl_rc_native_retain+0x5d1>
 1018443:	48 8b 40 30          	mov    0x30(%rax),%rax
 1018447:	4c 89 ea             	mov    %r13,%rdx
 101844a:	48 c1 ea 03          	shr    $0x3,%rdx
 101844e:	4c 89 ee             	mov    %r13,%rsi
 1018451:	48 c1 ee 21          	shr    $0x21,%rsi
 1018455:	48 31 d6             	xor    %rdx,%rsi
 1018458:	49 0f af f7          	imul   %r15,%rsi
 101845c:	48 89 f2             	mov    %rsi,%rdx
 101845f:	48 c1 ea 1b          	shr    $0x1b,%rdx
 1018463:	48 31 f2             	xor    %rsi,%rdx
 1018466:	48 83 f2 01          	xor    $0x1,%rdx
 101846a:	48 ff c9             	dec    %rcx
 101846d:	eb 04                	jmp    1018473 <myl_rc_native_retain+0x423>
 101846f:	90                   	nop
 1018470:	48 ff c2             	inc    %rdx
 1018473:	48 21 ca             	and    %rcx,%rdx
 1018476:	48 8d 34 92          	lea    (%rdx,%rdx,4),%rsi
 101847a:	48 8b 34 f0          	mov    (%rax,%rsi,8),%rsi
 101847e:	48 85 f6             	test   %rsi,%rsi
 1018481:	0f 84 9a 01 00 00    	je     1018621 <myl_rc_native_retain+0x5d1>
 1018487:	4c 39 ee             	cmp    %r13,%rsi
 101848a:	75 e4                	jne    1018470 <myl_rc_native_retain+0x420>
 101848c:	48 8d 34 92          	lea    (%rdx,%rdx,4),%rsi
 1018490:	83 7c f0 20 01       	cmpl   $0x1,0x20(%rax,%rsi,8)
 1018495:	75 d9                	jne    1018470 <myl_rc_native_retain+0x420>
 1018497:	4d 85 e4             	test   %r12,%r12
 101849a:	0f 84 81 01 00 00    	je     1018621 <myl_rc_native_retain+0x5d1>
 10184a0:	48 8d 04 f0          	lea    (%rax,%rsi,8),%rax
 10184a4:	48 8b 40 08          	mov    0x8(%rax),%rax
 10184a8:	48 85 c0             	test   %rax,%rax
 10184ab:	0f 84 70 01 00 00    	je     1018621 <myl_rc_native_retain+0x5d1>
 10184b1:	49 8b 0c 24          	mov    (%r12),%rcx
 10184b5:	48 3b 08             	cmp    (%rax),%rcx
 10184b8:	0f 85 63 01 00 00    	jne    1018621 <myl_rc_native_retain+0x5d1>
 10184be:	4c 39 75 c8          	cmp    %r14,-0x38(%rbp)
 10184c2:	0f 84 59 01 00 00    	je     1018621 <myl_rc_native_retain+0x5d1>
 10184c8:	41 bf 03 00 00 00    	mov    $0x3,%r15d
 10184ce:	8b 45 d4             	mov    -0x2c(%rbp),%eax
 10184d1:	3b 43 70             	cmp    0x70(%rbx),%eax
 10184d4:	0f 87 87 00 00 00    	ja     1018561 <myl_rc_native_retain+0x511>
 10184da:	48 8d 7d 98          	lea    -0x68(%rbp),%rdi
 10184de:	4c 89 e6             	mov    %r12,%rsi
 10184e1:	c5 f8 77             	vzeroupper
 10184e4:	e8 a7 cc ff ff       	call   1015190 <prepare_frames>
 10184e9:	41 bf 01 00 00 00    	mov    $0x1,%r15d
 10184ef:	85 c0                	test   %eax,%eax
 10184f1:	75 6e                	jne    1018561 <myl_rc_native_retain+0x511>
 10184f3:	41 b8 01 00 00 00    	mov    $0x1,%r8d
 10184f9:	48 89 df             	mov    %rbx,%rdi
 10184fc:	4c 89 e6             	mov    %r12,%rsi
 10184ff:	4c 89 f2             	mov    %r14,%rdx
 1018502:	4c 8b 7d c8          	mov    -0x38(%rbp),%r15
 1018506:	4c 89 f9             	mov    %r15,%rcx
 1018509:	e8 82 ab ff ff       	call   1013090 <myl_rc_value_seed>
 101850e:	8b 45 d4             	mov    -0x2c(%rbp),%eax
 1018511:	89 45 b8             	mov    %eax,-0x48(%rbp)
 1018514:	48 8d 7d 98          	lea    -0x68(%rbp),%rdi
 1018518:	41 b8 20 6a 01 01    	mov    $0x1016a20,%r8d
 101851e:	4c 89 e6             	mov    %r12,%rsi
 1018521:	4c 89 f2             	mov    %r14,%rdx
 1018524:	4c 89 f9             	mov    %r15,%rcx
 1018527:	e8 e4 cd ff ff       	call   1015310 <visit>
 101852c:	85 c0                	test   %eax,%eax
 101852e:	75 0d                	jne    101853d <myl_rc_native_retain+0x4ed>
 1018530:	48 8d 7d 98          	lea    -0x68(%rbp),%rdi
 1018534:	e8 b7 dd ff ff       	call   10162f0 <finish_clones>
 1018539:	85 c0                	test   %eax,%eax
 101853b:	74 67                	je     10185a4 <myl_rc_native_retain+0x554>
 101853d:	41 89 c7             	mov    %eax,%r15d
 1018540:	b9 01 00 00 00       	mov    $0x1,%ecx
 1018545:	48 89 df             	mov    %rbx,%rdi
 1018548:	4c 89 ee             	mov    %r13,%rsi
 101854b:	4c 89 f2             	mov    %r14,%rdx
 101854e:	e8 ad a2 ff ff       	call   1012800 <myl_rc_edges_release>
 1018553:	49 8b 55 00          	mov    0x0(%r13),%rdx
 1018557:	4c 89 f7             	mov    %r14,%rdi
 101855a:	31 f6                	xor    %esi,%esi
 101855c:	e8 3f 34 00 00       	call   101b9a0 <memset@plt>
 1018561:	48 8d 7d 98          	lea    -0x68(%rbp),%rdi
 1018565:	be 01 00 00 00       	mov    $0x1,%esi
 101856a:	c5 f8 77             	vzeroupper
 101856d:	e8 1e e1 ff ff       	call   1016690 <dispose_walk>
 1018572:	48 8b 83 08 16 00 00 	mov    0x1608(%rbx),%rax
 1018579:	48 85 c0             	test   %rax,%rax
 101857c:	0f 84 9f 00 00 00    	je     1018621 <myl_rc_native_retain+0x5d1>
 1018582:	45 31 e4             	xor    %r12d,%r12d
 1018585:	83 78 78 00          	cmpl   $0x0,0x78(%rax)
 1018589:	75 04                	jne    101858f <myl_rc_native_retain+0x53f>
 101858b:	44 89 78 78          	mov    %r15d,0x78(%rax)
 101858f:	44 89 e0             	mov    %r12d,%eax
 1018592:	48 81 c4 08 02 00 00 	add    $0x208,%rsp
 1018599:	5b                   	pop    %rbx
 101859a:	41 5c                	pop    %r12
 101859c:	41 5d                	pop    %r13
 101859e:	41 5e                	pop    %r14
 10185a0:	41 5f                	pop    %r15
 10185a2:	5d                   	pop    %rbp
 10185a3:	c3                   	ret
 10185a4:	48 8d 7d 98          	lea    -0x68(%rbp),%rdi
 10185a8:	31 f6                	xor    %esi,%esi
 10185aa:	e8 e1 e0 ff ff       	call   1016690 <dispose_walk>
 10185af:	41 bc 01 00 00 00    	mov    $0x1,%r12d
 10185b5:	eb d8                	jmp    101858f <myl_rc_native_retain+0x53f>
 10185b7:	49 8b 14 24          	mov    (%r12),%rdx
 10185bb:	48 85 d2             	test   %rdx,%rdx
 10185be:	0f 84 5d fb ff ff    	je     1018121 <myl_rc_native_retain+0xd1>
 10185c4:	4c 89 f0             	mov    %r14,%rax
 10185c7:	4c 29 f8             	sub    %r15,%rax
 10185ca:	77 06                	ja     10185d2 <myl_rc_native_retain+0x582>
 10185cc:	4c 89 f8             	mov    %r15,%rax
 10185cf:	4c 29 f0             	sub    %r14,%rax
 10185d2:	48 39 d0             	cmp    %rdx,%rax
 10185d5:	0f 82 46 fb ff ff    	jb     1018121 <myl_rc_native_retain+0xd1>
 10185db:	8b 45 d4             	mov    -0x2c(%rbp),%eax
 10185de:	3b 43 70             	cmp    0x70(%rbx),%eax
 10185e1:	76 28                	jbe    101860b <myl_rc_native_retain+0x5bb>
 10185e3:	45 31 e4             	xor    %r12d,%r12d
 10185e6:	4c 89 f7             	mov    %r14,%rdi
 10185e9:	31 f6                	xor    %esi,%esi
 10185eb:	e8 b0 33 00 00       	call   101b9a0 <memset@plt>
 10185f0:	48 8b 83 08 16 00 00 	mov    0x1608(%rbx),%rax
 10185f7:	48 85 c0             	test   %rax,%rax
 10185fa:	74 25                	je     1018621 <myl_rc_native_retain+0x5d1>
 10185fc:	83 78 78 00          	cmpl   $0x0,0x78(%rax)
 1018600:	75 8d                	jne    101858f <myl_rc_native_retain+0x53f>
 1018602:	c7 40 78 03 00 00 00 	movl   $0x3,0x78(%rax)
 1018609:	eb 84                	jmp    101858f <myl_rc_native_retain+0x53f>
 101860b:	4c 89 f7             	mov    %r14,%rdi
 101860e:	4c 89 fe             	mov    %r15,%rsi
 1018611:	e8 da 33 00 00       	call   101b9f0 <memcpy@plt>
 1018616:	41 bc 01 00 00 00    	mov    $0x1,%r12d
 101861c:	e9 6e ff ff ff       	jmp    101858f <myl_rc_native_retain+0x53f>
 1018621:	c5 f8 77             	vzeroupper
 1018624:	e8 6b 82 ff ff       	call   1010894 <myl_rc_invariant_failed>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
