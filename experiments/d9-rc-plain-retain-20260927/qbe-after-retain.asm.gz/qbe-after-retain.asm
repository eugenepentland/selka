
/home/epentland/ai/canopy/mylang-worktrees/d9-rc-mut-argument-astra/.tmp-mut-argument/retain-run/alloc-churn-qbe-after-rc:     file format elf64-x86-64


Disassembly of section .text:

00000000010173e0 <myl_rc_native_retain>:
 10173e0:	55                   	push   %rbp
 10173e1:	48 89 e5             	mov    %rsp,%rbp
 10173e4:	41 57                	push   %r15
 10173e6:	41 56                	push   %r14
 10173e8:	41 55                	push   %r13
 10173ea:	41 54                	push   %r12
 10173ec:	53                   	push   %rbx
 10173ed:	48 83 ec 48          	sub    $0x48,%rsp
 10173f1:	45 89 c4             	mov    %r8d,%r12d
 10173f4:	49 89 cf             	mov    %rcx,%r15
 10173f7:	49 89 d6             	mov    %rdx,%r14
 10173fa:	49 89 f5             	mov    %rsi,%r13
 10173fd:	48 89 fb             	mov    %rdi,%rbx
 1017400:	e8 5b 8b ff ff       	call   100ff60 <myl_rc_descriptor_find>
 1017405:	48 85 c0             	test   %rax,%rax
 1017408:	4c 89 7d d0          	mov    %r15,-0x30(%rbp)
 101740c:	0f 84 a2 00 00 00    	je     10174b4 <myl_rc_native_retain+0xd4>
 1017412:	83 78 78 00          	cmpl   $0x0,0x78(%rax)
 1017416:	75 12                	jne    101742a <myl_rc_native_retain+0x4a>
 1017418:	48 8b 8b 08 16 00 00 	mov    0x1608(%rbx),%rcx
 101741f:	48 83 79 60 00       	cmpq   $0x0,0x60(%rcx)
 1017424:	0f 84 b4 00 00 00    	je     10174de <myl_rc_native_retain+0xfe>
 101742a:	4c 8b 78 08          	mov    0x8(%rax),%r15
 101742e:	4d 85 ff             	test   %r15,%r15
 1017431:	0f 84 94 00 00 00    	je     10174cb <myl_rc_native_retain+0xeb>
 1017437:	48 89 df             	mov    %rbx,%rdi
 101743a:	4c 89 ee             	mov    %r13,%rsi
 101743d:	e8 8e a9 ff ff       	call   1011dd0 <myl_rc_native_has_unique>
 1017442:	85 c0                	test   %eax,%eax
 1017444:	0f 85 f8 00 00 00    	jne    1017542 <myl_rc_native_retain+0x162>
 101744a:	49 8b 55 00          	mov    0x0(%r13),%rdx
 101744e:	45 31 ed             	xor    %r13d,%r13d
 1017451:	4c 89 f7             	mov    %r14,%rdi
 1017454:	31 f6                	xor    %esi,%esi
 1017456:	e8 c5 01 00 00       	call   1017620 <compiler_rt.fastMemset>
 101745b:	4c 89 7d b0          	mov    %r15,-0x50(%rbp)
 101745f:	4c 89 75 b8          	mov    %r14,-0x48(%rbp)
 1017463:	48 c7 45 c0 00 00 00 	movq   $0x0,-0x40(%rbp)
 101746a:	00 
 101746b:	44 89 65 c8          	mov    %r12d,-0x38(%rbp)
 101746f:	c7 45 cc 00 00 00 00 	movl   $0x0,-0x34(%rbp)
 1017476:	4c 89 7d 90          	mov    %r15,-0x70(%rbp)
 101747a:	48 8b 45 d0          	mov    -0x30(%rbp),%rax
 101747e:	48 89 45 98          	mov    %rax,-0x68(%rbp)
 1017482:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
 1017486:	c5 f8 11 45 a0       	vmovups %xmm0,-0x60(%rbp)
 101748b:	48 8d 75 b0          	lea    -0x50(%rbp),%rsi
 101748f:	48 8d 55 90          	lea    -0x70(%rbp),%rdx
 1017493:	b9 01 00 00 00       	mov    $0x1,%ecx
 1017498:	48 89 df             	mov    %rbx,%rdi
 101749b:	e8 b0 d9 ff ff       	call   1014e50 <myl_rc_value_retain_many>
 10174a0:	85 c0                	test   %eax,%eax
 10174a2:	0f 84 82 00 00 00    	je     101752a <myl_rc_native_retain+0x14a>
 10174a8:	48 89 df             	mov    %rbx,%rdi
 10174ab:	89 c6                	mov    %eax,%esi
 10174ad:	e8 ae 7e ff ff       	call   100f360 <myl_rc_record_failure>
 10174b2:	eb 7c                	jmp    1017530 <myl_rc_native_retain+0x150>
 10174b4:	48 89 df             	mov    %rbx,%rdi
 10174b7:	4c 89 ee             	mov    %r13,%rsi
 10174ba:	e8 d1 f7 ff ff       	call   1016c90 <myl_rc_native_shape>
 10174bf:	49 89 c7             	mov    %rax,%r15
 10174c2:	4d 85 ff             	test   %r15,%r15
 10174c5:	0f 85 6c ff ff ff    	jne    1017437 <myl_rc_native_retain+0x57>
 10174cb:	49 8b 55 00          	mov    0x0(%r13),%rdx
 10174cf:	45 31 ed             	xor    %r13d,%r13d
 10174d2:	4c 89 f7             	mov    %r14,%rdi
 10174d5:	31 f6                	xor    %esi,%esi
 10174d7:	e8 44 01 00 00       	call   1017620 <compiler_rt.fastMemset>
 10174dc:	eb 52                	jmp    1017530 <myl_rc_native_retain+0x150>
 10174de:	49 8b 55 00          	mov    0x0(%r13),%rdx
 10174e2:	48 85 d2             	test   %rdx,%rdx
 10174e5:	0f 84 3f ff ff ff    	je     101742a <myl_rc_native_retain+0x4a>
 10174eb:	4c 89 f1             	mov    %r14,%rcx
 10174ee:	4c 29 f9             	sub    %r15,%rcx
 10174f1:	77 06                	ja     10174f9 <myl_rc_native_retain+0x119>
 10174f3:	4c 89 f9             	mov    %r15,%rcx
 10174f6:	4c 29 f1             	sub    %r14,%rcx
 10174f9:	48 39 d1             	cmp    %rdx,%rcx
 10174fc:	0f 82 28 ff ff ff    	jb     101742a <myl_rc_native_retain+0x4a>
 1017502:	44 3b 63 70          	cmp    0x70(%rbx),%r12d
 1017506:	76 17                	jbe    101751f <myl_rc_native_retain+0x13f>
 1017508:	45 31 ed             	xor    %r13d,%r13d
 101750b:	4c 89 f7             	mov    %r14,%rdi
 101750e:	31 f6                	xor    %esi,%esi
 1017510:	e8 0b 01 00 00       	call   1017620 <compiler_rt.fastMemset>
 1017515:	48 89 df             	mov    %rbx,%rdi
 1017518:	be 03 00 00 00       	mov    $0x3,%esi
 101751d:	eb 8e                	jmp    10174ad <myl_rc_native_retain+0xcd>
 101751f:	4c 89 f7             	mov    %r14,%rdi
 1017522:	4c 89 fe             	mov    %r15,%rsi
 1017525:	e8 f6 05 00 00       	call   1017b20 <compiler_rt.memcpy.memcpyFast>
 101752a:	41 bd 01 00 00 00    	mov    $0x1,%r13d
 1017530:	44 89 e8             	mov    %r13d,%eax
 1017533:	48 83 c4 48          	add    $0x48,%rsp
 1017537:	5b                   	pop    %rbx
 1017538:	41 5c                	pop    %r12
 101753a:	41 5d                	pop    %r13
 101753c:	41 5e                	pop    %r14
 101753e:	41 5f                	pop    %r15
 1017540:	5d                   	pop    %rbp
 1017541:	c3                   	ret
 1017542:	e8 be 7c ff ff       	call   100f205 <myl_rc_invariant_failed>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
