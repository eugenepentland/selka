pub const Predicate = enum { eq, ne, lt, le, gt, ge };
