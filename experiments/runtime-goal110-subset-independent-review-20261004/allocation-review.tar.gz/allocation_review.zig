const std = @import("std");
const model = @import("qbe_loop_unswitch_model.zig");
const rewrite = @import("qbe_loop_unswitch_text.zig");
const il_source =
    \\export function l $sample(l %l0) {
    \\@entry
    \\ jmp @i0
    \\@i0
    \\ jnz %counter, @i4, @i9
    \\@i4
    \\ jnz %condition, @yes, @i7
    \\@yes
    \\ storel 5, %position
    \\ call $myl_qbe_rc_scope_begin(l %ctx, l 0)
    \\ jmp @i8
    \\@i7
    \\ storel 7, %position
    \\ call $myl_qbe_rc_scope_end(l %ctx, l 0)
    \\ jmp @i8
    \\@i8
    \\ jmp @i0
    \\@i9
    \\ ret 0
    \\}
    \\
;
fn certificate() model.Certificate {
    var result: model.Certificate = .{ .head = 0, .back = 8, .slot = 0, .conditions = .{}, .values = .{} };
    result.conditions.items[0] = .{ .pc = 4, .value = 0, .predicate = .eq, .target = 7 };
    result.conditions.len = 1;
    result.values.items[0] = 0;
    result.values.len = 1;
    return result;
}

fn allocations(a: std.mem.Allocator) !void {
    var proof = certificate();
    proof.values.items[0] = 1;
    proof.values.items[1] = 0;
    proof.values.items[2] = 2;
    proof.values.len = 3;
    const result = try rewrite.rewrite(a, il_source, proof);
    defer a.free(result);
    try std.testing.expect(std.mem.indexOf(u8, result, "source-literals=3") != null);
    try std.testing.expect(std.mem.indexOf(u8, result, "_original_") != null);
}
fn refusalAllocations(a: std.mem.Allocator) !void {
    const padding = try a.alloc(u8, 65537);
    defer a.free(padding);
    @memset(padding, 'x');
    const split = std.mem.indexOf(u8, il_source, "\n@i4\n").? + 1;
    const large = try std.fmt.allocPrint(a, "{s}\n # {s}\n{s}", .{il_source[0..split], padding, il_source[split..]});
    defer a.free(large);
    const result = try rewrite.rewrite(a, large, certificate());
    defer a.free(result);
    try std.testing.expectEqualStrings(large, result);
}
test "exact stable native text rewrite cleans every failed allocation" {
    try std.testing.checkAllAllocationFailures(std.testing.allocator, allocations, .{});
}
test "zero fitting copy refusal cleans every failed allocation" {
    try std.testing.checkAllAllocationFailures(std.testing.allocator, refusalAllocations, .{});
}
