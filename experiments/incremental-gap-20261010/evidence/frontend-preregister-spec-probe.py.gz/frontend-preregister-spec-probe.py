import json, pathlib, shutil, subprocess, os
root=pathlib.Path(__file__).parent
work=root/'frontend-preregister-spec-probe-source'
shutil.copytree(root/'merged-baseline/1/source',work,dirs_exist_ok=True)
compiler=pathlib.Path('/home/epentland/ai/canopy/mylang-worktrees/codex-incremental-recursion-gap-20261010/.zig-cache/o/72ee2798888f1d8f4cf6909cb66037f0/mylang')
with (root/'frontend-preregister-spec-probe.stderr').open('w') as err:
 proc=subprocess.Popen([str(compiler),'check-session',str(work/'main.my')],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=err,text=True,env={**os.environ,"MYLANG_SEMANTIC_BUDGET":"134217728"})
 records=[]
 for phase in ['cold','entry-body-edit','prefix-only-edit']:
  if phase=='entry-body-edit':
   p=work/'main.my';s=p.read_text();assert '    return status' in s;p.write_text(s.replace('    return status','    return status + 0'))
  if phase=='prefix-only-edit':
   p=work/'main.my';p.write_text('\n'+p.read_text())
  proc.stdin.write('check\n');proc.stdin.flush()
  line=proc.stdout.readline();r=json.loads(line);r['probe_phase']=phase;records.append(r)
 proc.stdin.write('quit\n');proc.stdin.flush();proc.communicate(timeout=30)
 assert proc.returncode==0
(root/'frontend-preregister-spec-probe.json').write_text(json.dumps(records,indent=2)+'\n')
for i,r in enumerate(records):
 print(r['probe_phase'],r['status'],r['functions']['checked'],r['specialization_bodies'],r['semantic_miss_reasons'])
