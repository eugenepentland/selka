import hashlib, importlib.util, json, os, pathlib, subprocess, sys, time
art=pathlib.Path(__file__).parent
report=json.loads((art/'paired-final-clean-uncompressed/results.json').read_text())
original=next(r for r in report['records'] if r['phase']=='eager_verification')
worktree=pathlib.Path('/home/epentland/ai/canopy/mylang-worktrees/codex-incremental-recursion-gap-20261010')
spec=importlib.util.spec_from_file_location('comparison',worktree/'experiments/incremental-gap-20261010/compare.py')
comparison=importlib.util.module_from_spec(spec);spec.loader.exec_module(comparison)
bench=comparison.benchmark
root=art/'paired-final-clean-uncompressed'
variant=root/'12/candidate'
out=variant/'eager-fresh-link-verification'
out.mkdir(exist_ok=True)
assert bench.sha(pathlib.Path(report['compilers']['candidate']['path']))==report['compilers']['candidate']['sha256']
command=original['command']
binary=pathlib.Path(command[4])
expected_binary=bench.sha(binary)
assert expected_binary==original['binary_sha256']
(variant/'cache/programs-v1').rename(out/'programs-before-verification')
env={k:v for k,v in os.environ.items() if not k.startswith(('MYLANG_','MYL_CORE_','ZIG_'))}
env.update(MYLANG_JOBS='4',TMPDIR=str(root/'tmp'),MYLANG_CORE_RUNTIME_CACHE=str(variant/'native'),MYLANG_STAGE_CACHE_COMPRESSION='none')
metrics=out/'metrics.json'
start=time.perf_counter()
code,stdout,stderr=bench.run(['/usr/bin/time','-f','{"peak_rss_kb":%M,"user_s":%U,"system_s":%S}','-o',metrics,*command],original['cwd'],env)
seconds=time.perf_counter()-start
(out/'build.stdout').write_bytes(stdout);(out/'build.stderr').write_bytes(stderr)
assert code==0,(code,stderr[-6000:])
cache=next(json.loads(l) for l in stderr.decode().splitlines() if l.startswith('{"version":"cache-report-v1"'))
assert cache['program']=='linked' and cache['verified']==cache['units']==760 and cache['compiled']==0,cache
assert bench.sha(binary)==expected_binary,'Freshly linked executable differs'
env['MYL_CORE_LEAKCHECK']='1'
code,stdout,stderr=bench.run([binary],out,env)
(out/'usage.stdout').write_bytes(stdout);(out/'usage.stderr').write_bytes(stderr)
assert code==2 and not stdout and stderr.count(b'usage: eda-sch')==12 and stderr.count(b'usage: eda-sch-t002xx ')==1
manifest=json.loads((bench.GOLDENS/'manifest.json').read_text())
golden=next(c for c in manifest['cases'] if c['id']=='blinky-breakout')
exports=out/'golden-output';exports.mkdir()
code,stdout,stderr=bench.run([binary,'--model',bench.GOLDENS/'cases/blinky-breakout/model.sexp','--project-dir',bench.GOLDENS/'projects'/golden['project'],'--out-dir',exports,*golden['flags']],out,env)
(out/'golden.stdout').write_bytes(stdout);(out/'golden.stderr').write_bytes(stderr)
assert code==0 and not stderr and stdout.count(b'eda-sch: ')==12,(code,stderr)
actual={str(p.relative_to(exports)):bench.sha(p) for p in exports.rglob('*') if p.is_file()}
assert actual=={name:value['sha256'] for name,value in golden['outputs'].items()}
result={'method':'Independent follow-up: moved linked-program cache aside, eagerly regenerated and verified every native unit, forced fresh linking, compared whole executable bytes and executed usage/export/leak checks. Excluded from all edit timing medians.', 'command':command,'cwd':original['cwd'],'compiler':report['compilers']['candidate'],'affinity':sorted(os.sched_getaffinity(0)),'seconds':seconds,**json.loads(metrics.read_text()),'cache':cache,'expected_binary_sha256':expected_binary,'actual_binary_sha256':bench.sha(binary),'execution_check':'passed: every replica executed; usage, export hashes and leak check passed'}
(art/'eager-fresh-link-verification.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ('seconds','expected_binary_sha256','actual_binary_sha256','execution_check')},indent=2),flush=True)
