000000000104e6f0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76>:
 104e6f0:	push   %rbp
 104e6f1:	push   %r15
 104e6f3:	push   %r14
 104e6f5:	push   %r13
 104e6f7:	push   %r12
 104e6f9:	push   %rbx
 104e6fa:	sub    $0x258,%rsp
 104e701:	mov    %r8,0x8(%rsp)
 104e706:	mov    %rcx,0x28(%rsp)
 104e70b:	mov    %rdi,%rbp
 104e70e:	cmp    %rsp,0x40(%rdi)
 104e712:	ja     1051cf1 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3601>
 104e718:	mov    %rdx,%r15
 104e71b:	movq   $0x0,0xa8(%rsp)
 104e727:	movq   $0x0,0xa0(%rsp)
 104e733:	mov    0x2c8(%rbp),%eax
 104e739:	mov    %eax,0x44(%rsp)
 104e73d:	movq   $0x10bb020,0x38(%rsp)
 104e746:	movq   $0x10bb020,0x70(%rsp)
 104e74f:	cmp    $0x10bb020,%rsi
 104e756:	jne    104e75f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x6f>
 104e758:	xor    %ebx,%ebx
 104e75a:	jmp    104e844 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x154>
 104e75f:	mov    $0x1,%bl
 104e761:	test   %rsi,%rsi
 104e764:	je     104e844 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x154>
 104e76a:	mov    0x8(%rsi),%rdx
 104e76e:	cmp    0x6c8b3(%rip),%rdx        # 10bb028 <myl_lit_d666bf92bda1d63f03bf95c09e1bffde05f85315fdade322db024e5b0244b85a_instance+0x18>
 104e775:	jne    104e844 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x154>
 104e77b:	test   %rdx,%rdx
 104e77e:	je     104e758 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x68>
 104e780:	testb  $0x4,0x10(%rsi)
 104e784:	jne    104e78c <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x9c>
 104e786:	lea    0x18(%rsi),%rdi
 104e78a:	jmp    104e79b <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xab>
 104e78c:	mov    0x18(%rsi),%rax
 104e790:	mov    0x14(%rsi),%ecx
 104e793:	lea    (%rax,%rcx,1),%rdi
 104e797:	add    $0x18,%rdi
 104e79b:	testb  $0x4,0x6c88e(%rip)        # 10bb030 <myl_lit_d666bf92bda1d63f03bf95c09e1bffde05f85315fdade322db024e5b0244b85a_instance+0x20>
 104e7a2:	mov    0x6c88f(%rip),%rax        # 10bb038 <myl_lit_d666bf92bda1d63f03bf95c09e1bffde05f85315fdade322db024e5b0244b85a_instance+0x28>
 104e7a9:	mov    0x6c885(%rip),%ecx        # 10bb034 <myl_lit_d666bf92bda1d63f03bf95c09e1bffde05f85315fdade322db024e5b0244b85a_instance+0x24>
 104e7af:	lea    0x18(%rax,%rcx,1),%rcx
 104e7b4:	mov    $0x10bb038,%eax
 104e7b9:	cmovne %rcx,%rax
 104e7bd:	cmp    $0x10,%rdx
 104e7c1:	ja     104e7de <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xee>
 104e7c3:	cmp    $0x8,%rdx
 104e7c7:	jb     104e7f9 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x109>
 104e7c9:	mov    (%rdi),%rcx
 104e7cc:	mov    -0x8(%rdi,%rdx,1),%rdi
 104e7d1:	xor    (%rax),%rcx
 104e7d4:	xor    -0x8(%rax,%rdx,1),%rdi
 104e7d9:	or     %rcx,%rdi
 104e7dc:	jmp    104e83e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x14e>
 104e7de:	mov    %rsi,%r14
 104e7e1:	mov    %rax,%rsi
 104e7e4:	cmp    $0x100,%rdx
 104e7eb:	ja     104e80f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x11f>
 104e7ed:	call   10accc0 <bcmp@plt>
 104e7f2:	test   %eax,%eax
 104e7f4:	setne  %bl
 104e7f7:	jmp    104e819 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x129>
 104e7f9:	cmp    $0x4,%rdx
 104e7fd:	jb     104e81e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x12e>
 104e7ff:	mov    (%rdi),%ecx
 104e801:	mov    -0x4(%rdi,%rdx,1),%edi
 104e805:	xor    (%rax),%ecx
 104e807:	xor    -0x4(%rax,%rdx,1),%edi
 104e80b:	or     %ecx,%edi
 104e80d:	jmp    104e83e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x14e>
 104e80f:	call   10934f0 <equal_large_octets>
 104e814:	test   %eax,%eax
 104e816:	sete   %bl
 104e819:	mov    %r14,%rsi
 104e81c:	jmp    104e844 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x154>
 104e81e:	cmp    $0x1,%rdx
 104e822:	jne    104e82b <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x13b>
 104e824:	movzbl (%rdi),%ecx
 104e827:	cmp    (%rax),%cl
 104e829:	jmp    104e83e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x14e>
 104e82b:	movzwl (%rdi),%ecx
 104e82e:	movzwl -0x2(%rdi,%rdx,1),%edi
 104e833:	xor    (%rax),%cx
 104e836:	xor    -0x2(%rax,%rdx,1),%di
 104e83b:	or     %cx,%di
 104e83e:	sete   %bl
 104e841:	xor    $0x1,%bl
 104e844:	lea    0x258(%rbp),%rax
 104e84b:	mov    %rax,0x18(%rsp)
 104e850:	movabs $0x4000000000000002,%r13
 104e85a:	test   %r13,0x6c7af(%rip)        # 10bb010 <myl_lit_d666bf92bda1d63f03bf95c09e1bffde05f85315fdade322db024e5b0244b85a_instance>
 104e861:	jne    104e884 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x194>
 104e863:	mov    0x6c796(%rip),%rax        # 10bb000 <myl_lit_d3cafad273dd497c488894ca58a5701d146f3969ca50fbb18df3109543cd07e8_instance+0x60>
 104e86a:	dec    %rax
 104e86d:	jne    104e87d <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x18d>
 104e86f:	cmpq   $0x0,0x6c791(%rip)        # 10bb008 <myl_lit_d3cafad273dd497c488894ca58a5701d146f3969ca50fbb18df3109543cd07e8_instance+0x68>
 104e877:	je     104e904 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x214>
 104e87d:	mov    %rax,0x6c77c(%rip)        # 10bb000 <myl_lit_d3cafad273dd497c488894ca58a5701d146f3969ca50fbb18df3109543cd07e8_instance+0x60>
 104e884:	movq   $0x0,0xc8(%rsp)
 104e890:	test   %bl,%bl
 104e892:	mov    %rbp,0x10(%rsp)
 104e897:	mov    %r15,0x30(%rsp)
 104e89c:	je     104e944 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x254>
 104e8a2:	movq   $0x10bab30,0x38(%rsp)
 104e8ab:	movq   $0x10bab30,0x70(%rsp)
 104e8b4:	movq   $0x10bab30,0xc8(%rsp)
 104e8c0:	cmp    $0x10bab30,%rsi
 104e8c7:	jne    104e8d0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1e0>
 104e8c9:	xor    %ebx,%ebx
 104e8cb:	jmp    104ef6e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x87e>
 104e8d0:	mov    $0x1,%bl
 104e8d2:	test   %rsi,%rsi
 104e8d5:	je     104ef6e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x87e>
 104e8db:	mov    0x8(%rsi),%rdx
 104e8df:	cmp    0x6c252(%rip),%rdx        # 10bab38 <myl_lit_8c12e724a44132b907ad7be4d7bffd05d284ce5c644f94f5ab8dbc188941e631_instance+0x18>
 104e8e6:	jne    104ef6e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x87e>
 104e8ec:	test   %rdx,%rdx
 104e8ef:	je     104e8c9 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1d9>
 104e8f1:	testb  $0x4,0x10(%rsi)
 104e8f5:	jne    104eeb6 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x7c6>
 104e8fb:	lea    0x18(%rsi),%rdi
 104e8ff:	jmp    104eec5 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x7d5>
 104e904:	mov    %rsi,%r14
 104e907:	mov    $0x10bb020,%esi
 104e90c:	lea    0x258(%rbp),%r12
 104e913:	mov    %r12,%rdi
 104e916:	call   109b4d0 <myl_rc_edge_release>
 104e91b:	movq   $0x0,0xc8(%rsp)
 104e927:	mov    %r12,%rdi
 104e92a:	call   109e650 <myl_rc_drain>
 104e92f:	mov    %r14,%rsi
 104e932:	test   %bl,%bl
 104e934:	mov    %rbp,0x10(%rsp)
 104e939:	mov    %r15,0x30(%rsp)
 104e93e:	jne    104e8a2 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1b2>
 104e944:	xor    %eax,%eax
 104e946:	movabs $0x89705f3112a28fe5,%r15
 104e950:	vpxor  %xmm11,%xmm11,%xmm11
 104e955:	vmovd  -0x4cfbd(%rip),%xmm12        # 10019a0 <__abi_tag+0x16a4>
 104e95d:	vmovd  -0x4cf75(%rip),%xmm13        # 10019f0 <__abi_tag+0x16f4>
 104e965:	vmovd  -0x4cfed(%rip),%xmm14        # 1001980 <__abi_tag+0x1684>
 104e96d:	vmovd  -0x4d055(%rip),%xmm15        # 1001920 <__abi_tag+0x1624>
 104e975:	xor    %r14d,%r14d
 104e978:	nopl   0x0(%rax,%rax,1)
 104e980:	mov    0x8(%rsp),%rdx
 104e985:	add    %r14,%rdx
 104e988:	jo     1051bf2 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3502>
 104e98e:	mov    %rax,%r12
 104e991:	mov    0x30(%rsp),%rax
 104e996:	mov    (%rax),%rsi
 104e999:	mov    -0x10(%rsi),%rax
 104e99d:	movabs $0x4000000000000002,%r13
 104e9a7:	test   %r13,%rax
 104e9aa:	jne    104e9bd <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2cd>
 104e9ac:	mov    -0x18(%rsi),%rcx
 104e9b0:	inc    %rcx
 104e9b3:	je     104ee7a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x78a>
 104e9b9:	mov    %rcx,-0x18(%rsi)
 104e9bd:	movzbl %dl,%r8d
 104e9c1:	mov    (%rsi),%rdi
 104e9c4:	lea    -0x10(%rdi),%r9
 104e9c8:	movabs $0xffffffffffffff0,%rcx
 104e9d2:	cmp    %rcx,%r9
 104e9d5:	ja     104ea10 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x320>
 104e9d7:	mov    0x20(%rsi),%rcx
 104e9db:	movabs $0x80808080808080,%r10
 104e9e5:	cmp    %r10,%rdi
 104e9e8:	ja     104ea40 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x350>
 104e9ea:	vmovd  %edx,%xmm0
 104e9ee:	vpbroadcastb %xmm0,%xmm0
 104e9f3:	mov    %r9d,%r8d
 104e9f6:	not    %r8d
 104e9f9:	test   $0x30,%r8b
 104e9fd:	jne    104eb78 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x488>
 104ea03:	vpxor  %xmm1,%xmm1,%xmm1
 104ea07:	jmp    104ebc0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x4d0>
 104ea0c:	nopl   0x0(%rax)
 104ea10:	test   %rdi,%rdi
 104ea13:	jle    104eb71 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x481>
 104ea19:	mov    0x20(%rsi),%rcx
 104ea1d:	cmp    $0x8,%rdi
 104ea21:	jae    104ea40 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x350>
 104ea23:	mov    $0x1,%r10d
 104ea29:	xor    %r9d,%r9d
 104ea2c:	xor    %edx,%edx
 104ea2e:	xor    %ebx,%ebx
 104ea30:	jmp    104eae7 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3f7>
 104ea35:	data16 cs nopw 0x0(%rax,%rax,1)
 104ea40:	mov    %rdi,%rdx
 104ea43:	and    $0xfffffffffffffff8,%rdx
 104ea47:	vmovq  %r8,%xmm0
 104ea4c:	vpbroadcastq %xmm0,%ymm3
 104ea51:	vpxor  %xmm2,%xmm2,%xmm2
 104ea55:	xor    %r9d,%r9d
 104ea58:	vpxor  %xmm4,%xmm4,%xmm4
 104ea5c:	vpxor  %xmm0,%xmm0,%xmm0
 104ea60:	vpxor  %xmm1,%xmm1,%xmm1
 104ea64:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 104ea70:	vpmovzxbq (%rcx,%r9,1),%ymm5
 104ea76:	vpmovzxbq 0x4(%rcx,%r9,1),%ymm6
 104ea7d:	vpxor  %ymm5,%ymm3,%ymm5
 104ea81:	vpxor  %ymm6,%ymm3,%ymm6
 104ea85:	vpaddq %ymm2,%ymm5,%ymm2
 104ea89:	vpaddq %ymm4,%ymm6,%ymm4
 104ea8d:	vpaddq %ymm0,%ymm5,%ymm0
 104ea91:	vpaddq %ymm1,%ymm6,%ymm1
 104ea95:	add    $0x8,%r9
 104ea99:	cmp    %r9,%rdx
 104ea9c:	jne    104ea70 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x380>
 104ea9e:	vpaddq %ymm2,%ymm4,%ymm2
 104eaa2:	vextracti128 $0x1,%ymm2,%xmm3
 104eaa8:	vpaddq %xmm3,%xmm2,%xmm2
 104eaac:	vpshufd $0xee,%xmm2,%xmm3
 104eab1:	vpaddq %xmm3,%xmm2,%xmm2
 104eab5:	vmovq  %xmm2,%r9
 104eaba:	vpaddq %ymm0,%ymm1,%ymm0
 104eabe:	vextracti128 $0x1,%ymm0,%xmm1
 104eac4:	vpaddq %xmm1,%xmm0,%xmm0
 104eac8:	vpshufd $0xee,%xmm0,%xmm1
 104eacd:	vpaddq %xmm1,%xmm0,%xmm0
 104ead1:	vmovq  %xmm0,%rbx
 104ead6:	cmp    %rdx,%rdi
 104ead9:	jne    104eae0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3f0>
 104eadb:	mov    %rdi,%rcx
 104eade:	jmp    104eb21 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x431>
 104eae0:	mov    %rdx,%r10
 104eae3:	or     $0x1,%r10
 104eae7:	add    %rdx,%rcx
 104eaea:	mov    %rdi,%r11
 104eaed:	sub    %rdx,%r11
 104eaf0:	xor    %edx,%edx
 104eaf2:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 104eb00:	movzbl (%rcx,%rdx,1),%ebp
 104eb04:	xor    %r8,%rbp
 104eb07:	add    %rbp,%r9
 104eb0a:	add    %rbp,%rbx
 104eb0d:	inc    %rdx
 104eb10:	cmp    %rdx,%r11
 104eb13:	jne    104eb00 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x410>
 104eb15:	lea    (%r10,%rdx,1),%rcx
 104eb19:	dec    %rcx
 104eb1c:	mov    0x10(%rsp),%rbp
 104eb21:	mov    $0xffffffff,%edx
 104eb26:	cmp    %rdx,%rcx
 104eb29:	setb   %cl
 104eb2c:	test   %r9,%r9
 104eb2f:	setns  %dl
 104eb32:	test   %dl,%cl
 104eb34:	jne    104edd0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x6e0>
 104eb3a:	mov    0x20(%rsi),%r9
 104eb3e:	xor    %r10d,%r10d
 104eb41:	xor    %edx,%edx
 104eb43:	xor    %ebx,%ebx
 104eb45:	data16 cs nopw 0x0(%rax,%rax,1)
 104eb50:	movzbl (%r9,%r10,1),%ecx
 104eb55:	xor    %r8,%rcx
 104eb58:	add    %rcx,%rbx
 104eb5b:	jo     1051bc6 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x34d6>
 104eb61:	inc    %r10
 104eb64:	mov    %rbx,%rdx
 104eb67:	cmp    %r10,%rdi
 104eb6a:	jne    104eb50 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x460>
 104eb6c:	jmp    104edd0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x6e0>
 104eb71:	xor    %ebx,%ebx
 104eb73:	jmp    104edd0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x6e0>
 104eb78:	mov    %r9d,%r8d
 104eb7b:	shr    $0x4,%r8d
 104eb7f:	inc    %r8d
 104eb82:	and    $0x3,%r8d
 104eb86:	vpxor  %xmm1,%xmm1,%xmm1
 104eb8a:	mov    %r8,%r10
 104eb8d:	mov    %rcx,%r11
 104eb90:	vpxor  (%r11),%xmm0,%xmm2
 104eb95:	vpsadbw %xmm2,%xmm11,%xmm2
 104eb99:	vpaddq %xmm1,%xmm2,%xmm1
 104eb9d:	add    $0x10,%r11
 104eba1:	dec    %r10
 104eba4:	jne    104eb90 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x4a0>
 104eba6:	shl    $0x4,%r8d
 104ebaa:	add    %r8,%rcx
 104ebad:	sub    %r8,%rdi
 104ebb0:	cmp    $0x30,%r9
 104ebb4:	jb     104ec01 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x511>
 104ebb6:	cs nopw 0x0(%rax,%rax,1)
 104ebc0:	vpxor  (%rcx),%xmm0,%xmm2
 104ebc4:	vpsadbw %xmm2,%xmm11,%xmm2
 104ebc8:	vpaddq %xmm1,%xmm2,%xmm1
 104ebcc:	vpxor  0x10(%rcx),%xmm0,%xmm2
 104ebd1:	vpsadbw %xmm2,%xmm11,%xmm2
 104ebd5:	vpxor  0x20(%rcx),%xmm0,%xmm3
 104ebda:	vpsadbw %xmm3,%xmm11,%xmm3
 104ebde:	vpaddq %xmm2,%xmm3,%xmm2
 104ebe2:	vpaddq %xmm1,%xmm2,%xmm1
 104ebe6:	vpxor  0x30(%rcx),%xmm0,%xmm2
 104ebeb:	vpsadbw %xmm2,%xmm11,%xmm2
 104ebef:	vpaddq %xmm1,%xmm2,%xmm1
 104ebf3:	add    $0x40,%rcx
 104ebf7:	add    $0xffffffffffffffc0,%rdi
 104ebfb:	cmp    $0xf,%rdi
 104ebff:	ja     104ebc0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x4d0>
 104ec01:	vpshufd $0xee,%xmm1,%xmm0
 104ec06:	vpaddq %xmm0,%xmm1,%xmm0
 104ec0a:	vmovq  %xmm0,%rbx
 104ec0f:	test   %rdi,%rdi
 104ec12:	je     104edd0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x6e0>
 104ec18:	mov    %rdi,%r11
 104ec1b:	and    $0x3,%r11
 104ec1f:	je     104ec5d <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x56d>
 104ec21:	xor    %r8d,%r8d
 104ec24:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 104ec30:	movzbl (%rcx,%r8,1),%r9d
 104ec35:	xor    %dl,%r9b
 104ec38:	movzbl %r9b,%r9d
 104ec3c:	add    %r9,%rbx
 104ec3f:	inc    %r8
 104ec42:	cmp    %r8,%r11
 104ec45:	jne    104ec30 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x540>
 104ec47:	mov    %rdi,%r8
 104ec4a:	and    $0xfffffffffffffffc,%r8
 104ec4e:	lea    (%rcx,%r11,1),%r9
 104ec52:	cmp    $0x4,%rdi
 104ec56:	jae    104ec6d <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x57d>
 104ec58:	jmp    104edd0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x6e0>
 104ec5d:	mov    %rcx,%r9
 104ec60:	mov    %rdi,%r8
 104ec63:	cmp    $0x4,%rdi
 104ec67:	jb     104edd0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x6e0>
 104ec6d:	lea    -0x4(%r8),%rdi
 104ec71:	cmp    $0x1c,%rdi
 104ec75:	jb     104ed90 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x6a0>
 104ec7b:	shr    $0x2,%rdi
 104ec7f:	inc    %rdi
 104ec82:	mov    %rdi,%r10
 104ec85:	and    $0xfffffffffffffff8,%r10
 104ec89:	lea    0x0(,%r10,4),%rbp
 104ec91:	lea    (%r9,%r10,4),%r9
 104ec95:	sub    %rbp,%r8
 104ec98:	vmovq  %rbx,%xmm1
 104ec9d:	vmovd  %edx,%xmm0
 104eca1:	vpbroadcastb %xmm0,%xmm0
 104eca6:	add    %r11,%rcx
 104eca9:	add    $0x10,%rcx
 104ecad:	vpxor  %xmm2,%xmm2,%xmm2
 104ecb1:	xor    %r11d,%r11d
 104ecb4:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 104ecc0:	vmovdqu -0x10(%rcx,%r11,4),%xmm3
 104ecc7:	vmovdqu (%rcx,%r11,4),%xmm4
 104eccd:	vpshufb %xmm12,%xmm3,%xmm5
 104ecd2:	vpshufb %xmm13,%xmm3,%xmm6
 104ecd7:	vpshufb %xmm14,%xmm3,%xmm7
 104ecdc:	vpshufb %xmm15,%xmm3,%xmm3
 104ece1:	vpshufb %xmm12,%xmm4,%xmm8
 104ece6:	vpshufb %xmm13,%xmm4,%xmm9
 104eceb:	vpshufb %xmm14,%xmm4,%xmm10
 104ecf0:	vpshufb %xmm15,%xmm4,%xmm4
 104ecf5:	vpxor  %xmm0,%xmm5,%xmm5
 104ecf9:	vpxor  %xmm0,%xmm8,%xmm8
 104ecfd:	vpmovzxbq %xmm5,%ymm5
 104ed02:	vpaddq %ymm5,%ymm1,%ymm1
 104ed06:	vpmovzxbq %xmm8,%ymm5
 104ed0b:	vpaddq %ymm5,%ymm2,%ymm2
 104ed0f:	vpxor  %xmm0,%xmm6,%xmm5
 104ed13:	vpxor  %xmm0,%xmm9,%xmm6
 104ed17:	vpmovzxbq %xmm5,%ymm5
 104ed1c:	vpmovzxbq %xmm6,%ymm6
 104ed21:	vpxor  %xmm0,%xmm7,%xmm7
 104ed25:	vpxor  %xmm0,%xmm10,%xmm8
 104ed29:	vpmovzxbq %xmm7,%ymm7
 104ed2e:	vpaddq %ymm7,%ymm5,%ymm5
 104ed32:	vpaddq %ymm5,%ymm1,%ymm1
 104ed36:	vpmovzxbq %xmm8,%ymm5
 104ed3b:	vpaddq %ymm5,%ymm6,%ymm5
 104ed3f:	vpaddq %ymm5,%ymm2,%ymm2
 104ed43:	vpxor  %xmm0,%xmm3,%xmm3
 104ed47:	vpxor  %xmm0,%xmm4,%xmm4
 104ed4b:	vpmovzxbq %xmm3,%ymm3
 104ed50:	vpaddq %ymm3,%ymm1,%ymm1
 104ed54:	vpmovzxbq %xmm4,%ymm3
 104ed59:	vpaddq %ymm3,%ymm2,%ymm2
 104ed5d:	add    $0x8,%r11
 104ed61:	cmp    %r11,%r10
 104ed64:	jne    104ecc0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x5d0>
 104ed6a:	vpaddq %ymm1,%ymm2,%ymm0
 104ed6e:	vextracti128 $0x1,%ymm0,%xmm1
 104ed74:	vpaddq %xmm1,%xmm0,%xmm0
 104ed78:	vpshufd $0xee,%xmm0,%xmm1
 104ed7d:	vpaddq %xmm1,%xmm0,%xmm0
 104ed81:	vmovq  %xmm0,%rbx
 104ed86:	cmp    %r10,%rdi
 104ed89:	mov    0x10(%rsp),%rbp
 104ed8e:	je     104edd0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x6e0>
 104ed90:	vmovd  %edx,%xmm0
 104ed94:	vpbroadcastb %xmm0,%xmm0
 104ed99:	xor    %ecx,%ecx
 104ed9b:	nopl   0x0(%rax,%rax,1)
 104eda0:	vmovd  (%r9,%rcx,1),%xmm1
 104eda6:	vpxor  %xmm0,%xmm1,%xmm1
 104edaa:	vpblendd $0x1,%xmm1,%xmm11,%xmm1
 104edb0:	vpsadbw %xmm1,%xmm11,%xmm1
 104edb4:	vmovq  %xmm1,%rdx
 104edb9:	add    %rdx,%rbx
 104edbc:	add    $0x4,%rcx
 104edc0:	cmp    %rcx,%r8
 104edc3:	jne    104eda0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x6b0>
 104edc5:	data16 cs nopw 0x0(%rax,%rax,1)
 104edd0:	test   %r13,%rax
 104edd3:	jne    104ede9 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x6f9>
 104edd5:	mov    -0x18(%rsi),%rax
 104edd9:	dec    %rax
 104eddc:	jne    104ede5 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x6f5>
 104edde:	cmpq   $0x0,-0x20(%rsi)
 104ede3:	je     104ee38 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x748>
 104ede5:	mov    %rax,-0x18(%rsi)
 104ede9:	mov    %r12,%rcx
 104edec:	add    %rbx,%rcx
 104edef:	jo     1051c07 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3517>
 104edf5:	mov    %rcx,%rax
 104edf8:	imul   %r15
 104edfb:	add    %rcx,%rdx
 104edfe:	mov    %rdx,%rax
 104ee01:	shr    $0x3f,%rax
 104ee05:	sar    $0x1d,%rdx
 104ee09:	add    %rax,%rdx
 104ee0c:	imul   $0x3b9aca07,%rdx,%rax
 104ee13:	sub    %rax,%rcx
 104ee16:	mov    %rcx,%rax
 104ee19:	sar    $0x3f,%rax
 104ee1d:	and    $0x3b9aca07,%eax
 104ee22:	add    %rcx,%rax
 104ee25:	inc    %r14
 104ee28:	cmp    0x28(%rsp),%r14
 104ee2d:	jne    104e980 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x290>
 104ee33:	jmp    104f01c <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x92c>
 104ee38:	mov    0x18(%rsp),%r13
 104ee3d:	mov    %r13,%rdi
 104ee40:	vzeroupper
 104ee43:	call   109b630 <myl_rc_hold_edge_release>
 104ee48:	mov    %r13,%rdi
 104ee4b:	call   109e650 <myl_rc_drain>
 104ee50:	vmovd  -0x4d538(%rip),%xmm15        # 1001920 <__abi_tag+0x1624>
 104ee58:	vmovd  -0x4d4e0(%rip),%xmm14        # 1001980 <__abi_tag+0x1684>
 104ee60:	vmovd  -0x4d478(%rip),%xmm13        # 10019f0 <__abi_tag+0x16f4>
 104ee68:	vmovd  -0x4d4d0(%rip),%xmm12        # 10019a0 <__abi_tag+0x16a4>
 104ee70:	vpxor  %xmm11,%xmm11,%xmm11
 104ee75:	jmp    104ede9 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x6f9>
 104ee7a:	mov    $0x1007dbf,%esi
 104ee7f:	mov    %rbp,%rdi
 104ee82:	vzeroupper
 104ee85:	call   108beae <fail>
 104ee8a:	vmovd  -0x4d572(%rip),%xmm15        # 1001920 <__abi_tag+0x1624>
 104ee92:	vmovd  -0x4d51a(%rip),%xmm14        # 1001980 <__abi_tag+0x1684>
 104ee9a:	vmovd  -0x4d4b2(%rip),%xmm13        # 10019f0 <__abi_tag+0x16f4>
 104eea2:	vmovd  -0x4d50a(%rip),%xmm12        # 10019a0 <__abi_tag+0x16a4>
 104eeaa:	vpxor  %xmm11,%xmm11,%xmm11
 104eeaf:	xor    %ebx,%ebx
 104eeb1:	jmp    104ede9 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x6f9>
 104eeb6:	mov    0x18(%rsi),%rax
 104eeba:	mov    0x14(%rsi),%ecx
 104eebd:	lea    (%rax,%rcx,1),%rdi
 104eec1:	add    $0x18,%rdi
 104eec5:	testb  $0x4,0x6bc74(%rip)        # 10bab40 <myl_lit_8c12e724a44132b907ad7be4d7bffd05d284ce5c644f94f5ab8dbc188941e631_instance+0x20>
 104eecc:	mov    0x6bc75(%rip),%rax        # 10bab48 <myl_lit_8c12e724a44132b907ad7be4d7bffd05d284ce5c644f94f5ab8dbc188941e631_instance+0x28>
 104eed3:	mov    0x6bc6b(%rip),%ecx        # 10bab44 <myl_lit_8c12e724a44132b907ad7be4d7bffd05d284ce5c644f94f5ab8dbc188941e631_instance+0x24>
 104eed9:	lea    0x18(%rax,%rcx,1),%rcx
 104eede:	mov    $0x10bab48,%eax
 104eee3:	cmovne %rcx,%rax
 104eee7:	cmp    $0x10,%rdx
 104eeeb:	ja     104ef08 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x818>
 104eeed:	cmp    $0x8,%rdx
 104eef1:	jb     104ef23 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x833>
 104eef3:	mov    (%rdi),%rcx
 104eef6:	mov    -0x8(%rdi,%rdx,1),%rdi
 104eefb:	xor    (%rax),%rcx
 104eefe:	xor    -0x8(%rax,%rdx,1),%rdi
 104ef03:	or     %rcx,%rdi
 104ef06:	jmp    104ef68 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x878>
 104ef08:	mov    %rsi,%r14
 104ef0b:	mov    %rax,%rsi
 104ef0e:	cmp    $0x100,%rdx
 104ef15:	ja     104ef39 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x849>
 104ef17:	call   10accc0 <bcmp@plt>
 104ef1c:	test   %eax,%eax
 104ef1e:	setne  %bl
 104ef21:	jmp    104ef43 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x853>
 104ef23:	cmp    $0x4,%rdx
 104ef27:	jb     104ef48 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x858>
 104ef29:	mov    (%rdi),%ecx
 104ef2b:	mov    -0x4(%rdi,%rdx,1),%edi
 104ef2f:	xor    (%rax),%ecx
 104ef31:	xor    -0x4(%rax,%rdx,1),%edi
 104ef35:	or     %ecx,%edi
 104ef37:	jmp    104ef68 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x878>
 104ef39:	call   10934f0 <equal_large_octets>
 104ef3e:	test   %eax,%eax
 104ef40:	sete   %bl
 104ef43:	mov    %r14,%rsi
 104ef46:	jmp    104ef6e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x87e>
 104ef48:	cmp    $0x1,%rdx
 104ef4c:	jne    104ef55 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x865>
 104ef4e:	movzbl (%rdi),%ecx
 104ef51:	cmp    (%rax),%cl
 104ef53:	jmp    104ef68 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x878>
 104ef55:	movzwl (%rdi),%ecx
 104ef58:	movzwl -0x2(%rdi,%rdx,1),%edi
 104ef5d:	xor    (%rax),%cx
 104ef60:	xor    -0x2(%rax,%rdx,1),%di
 104ef65:	or     %cx,%di
 104ef68:	sete   %bl
 104ef6b:	xor    $0x1,%bl
 104ef6e:	test   %r13,0x6bbab(%rip)        # 10bab20 <myl_lit_8c12e724a44132b907ad7be4d7bffd05d284ce5c644f94f5ab8dbc188941e631_instance>
 104ef75:	je     104efa4 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x8b4>
 104ef77:	test   %bl,%bl
 104ef79:	je     104efc9 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x8d9>
 104ef7b:	movq   $0x10ba980,0x70(%rsp)
 104ef84:	movq   $0x10ba980,0xc8(%rsp)
 104ef90:	cmp    $0x10ba980,%rsi
 104ef97:	jne    104f031 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x941>
 104ef9d:	xor    %ebx,%ebx
 104ef9f:	jmp    104f3fb <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xd0b>
 104efa4:	mov    0x6bb65(%rip),%rax        # 10bab10 <myl_lit_842ab9229ccb9156d5ed82c31992b7b48b2d840046545e9d568e989652f87fd6_instance+0x20>
 104efab:	dec    %rax
 104efae:	jne    104efbe <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x8ce>
 104efb0:	cmpq   $0x0,0x6bb60(%rip)        # 10bab18 <myl_lit_842ab9229ccb9156d5ed82c31992b7b48b2d840046545e9d568e989652f87fd6_instance+0x28>
 104efb8:	je     104f26a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xb7a>
 104efbe:	mov    %rax,0x6bb4b(%rip)        # 10bab10 <myl_lit_842ab9229ccb9156d5ed82c31992b7b48b2d840046545e9d568e989652f87fd6_instance+0x20>
 104efc5:	test   %bl,%bl
 104efc7:	jne    104ef7b <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x88b>
 104efc9:	mov    0x8(%r15),%rax
 104efcd:	mov    0x8(%rsp),%rsi
 104efd2:	and    $0x3,%esi
 104efd5:	mov    (%rax),%rdx
 104efd8:	cmp    %rdx,%rsi
 104efdb:	jae    1051c1a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x352a>
 104efe1:	mov    0x10(%r15),%rcx
 104efe5:	mov    (%rcx),%rdx
 104efe8:	cmp    %rdx,%rsi
 104efeb:	jae    1051c24 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3534>
 104eff1:	mov    0x20(%rax),%rax
 104eff5:	shl    $0x3,%esi
 104eff8:	mov    (%rax,%rsi,1),%rdi
 104effc:	mov    0x20(%rcx),%rax
 104f000:	mov    (%rax,%rsi,1),%rsi
 104f004:	mov    $0x1,%eax
 104f009:	cmp    %rsi,%rdi
 104f00c:	jne    104f069 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x979>
 104f00e:	mov    %eax,%eax
 104f010:	cmpq   $0x1,0x28(%rsp)
 104f016:	jne    104f09c <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x9ac>
 104f01c:	add    $0x258,%rsp
 104f023:	pop    %rbx
 104f024:	pop    %r12
 104f026:	pop    %r13
 104f028:	pop    %r14
 104f02a:	pop    %r15
 104f02c:	pop    %rbp
 104f02d:	vzeroupper
 104f030:	ret
 104f031:	mov    $0x1,%bl
 104f033:	test   %rsi,%rsi
 104f036:	je     104f3fb <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xd0b>
 104f03c:	mov    0x8(%rsi),%rdx
 104f040:	cmp    0x6b941(%rip),%rdx        # 10ba988 <myl_lit_7afa21b5dfd0bec52f3c46b131c861acf738a60d12be67523b48ae28324a1934_instance+0x18>
 104f047:	jne    104f3fb <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xd0b>
 104f04d:	test   %rdx,%rdx
 104f050:	je     104ef9d <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x8ad>
 104f056:	testb  $0x4,0x10(%rsi)
 104f05a:	jne    104f294 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xba4>
 104f060:	lea    0x18(%rsi),%rdi
 104f064:	jmp    104f2a3 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xbb3>
 104f069:	xor    %eax,%eax
 104f06b:	test   %rdi,%rdi
 104f06e:	je     104f00e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x91e>
 104f070:	test   %rsi,%rsi
 104f073:	je     104f00e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x91e>
 104f075:	mov    0x8(%rdi),%rdx
 104f079:	cmp    0x8(%rsi),%rdx
 104f07d:	jne    104f00e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x91e>
 104f07f:	mov    $0x1,%eax
 104f084:	test   %rdx,%rdx
 104f087:	je     104f00e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x91e>
 104f089:	testb  $0x4,0x10(%rdi)
 104f08d:	jne    104f30f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xc1f>
 104f093:	add    $0x18,%rdi
 104f097:	jmp    104f31e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xc2e>
 104f09c:	mov    $0x1,%ebx
 104f0a1:	movabs $0x89705f3112a28fe5,%r14
 104f0ab:	jmp    104f109 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xa19>
 104f0ad:	call   10934f0 <equal_large_octets>
 104f0b2:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 104f0c0:	mov    %eax,%eax
 104f0c2:	mov    %r15,%rcx
 104f0c5:	add    %rax,%rcx
 104f0c8:	mov    %rcx,%rax
 104f0cb:	imul   %r14
 104f0ce:	add    %rcx,%rdx
 104f0d1:	mov    %rdx,%rax
 104f0d4:	shr    $0x3f,%rax
 104f0d8:	sar    $0x1d,%rdx
 104f0dc:	add    %rax,%rdx
 104f0df:	imul   $0x3b9aca07,%rdx,%rax
 104f0e6:	sub    %rax,%rcx
 104f0e9:	mov    %rcx,%rax
 104f0ec:	sar    $0x3f,%rax
 104f0f0:	and    $0x3b9aca07,%eax
 104f0f5:	add    %rax,%rcx
 104f0f8:	mov    %rcx,%rax
 104f0fb:	inc    %rbx
 104f0fe:	cmp    %rbx,0x28(%rsp)
 104f103:	je     104f01c <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x92c>
 104f109:	mov    0x8(%rsp),%rsi
 104f10e:	add    %rbx,%rsi
 104f111:	jo     1051c2e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x353e>
 104f117:	mov    %rax,%r15
 104f11a:	mov    0x30(%rsp),%rcx
 104f11f:	mov    0x8(%rcx),%rax
 104f123:	and    $0x3,%esi
 104f126:	mov    (%rax),%rdx
 104f129:	cmp    %rdx,%rsi
 104f12c:	jae    1051c1a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x352a>
 104f132:	mov    0x10(%rcx),%rcx
 104f136:	mov    (%rcx),%rdx
 104f139:	cmp    %rdx,%rsi
 104f13c:	jae    1051c24 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3534>
 104f142:	mov    0x20(%rax),%rax
 104f146:	shl    $0x3,%esi
 104f149:	mov    (%rax,%rsi,1),%rdi
 104f14d:	mov    0x20(%rcx),%rax
 104f151:	mov    (%rax,%rsi,1),%rsi
 104f155:	mov    $0x1,%eax
 104f15a:	cmp    %rsi,%rdi
 104f15d:	je     104f0c0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x9d0>
 104f163:	xor    %eax,%eax
 104f165:	test   %rdi,%rdi
 104f168:	je     104f0c0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x9d0>
 104f16e:	test   %rsi,%rsi
 104f171:	je     104f0c0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x9d0>
 104f177:	mov    0x8(%rdi),%rdx
 104f17b:	cmp    0x8(%rsi),%rdx
 104f17f:	jne    104f0c0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x9d0>
 104f185:	mov    $0x1,%eax
 104f18a:	test   %rdx,%rdx
 104f18d:	je     104f0c0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x9d0>
 104f193:	testb  $0x4,0x10(%rdi)
 104f197:	jne    104f1d8 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xae8>
 104f199:	add    $0x18,%rdi
 104f19d:	testb  $0x4,0x10(%rsi)
 104f1a1:	je     104f1ed <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xafd>
 104f1a3:	mov    0x18(%rsi),%rax
 104f1a7:	mov    0x14(%rsi),%ecx
 104f1aa:	lea    (%rax,%rcx,1),%rsi
 104f1ae:	add    $0x18,%rsi
 104f1b2:	cmp    $0x10,%rdx
 104f1b6:	jbe    104f1f7 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xb07>
 104f1b8:	cmp    $0x100,%rdx
 104f1bf:	ja     104f0ad <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x9bd>
 104f1c5:	call   10accc0 <bcmp@plt>
 104f1ca:	mov    %eax,%ecx
 104f1cc:	xor    %eax,%eax
 104f1ce:	test   %ecx,%ecx
 104f1d0:	sete   %al
 104f1d3:	jmp    104f0c0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x9d0>
 104f1d8:	mov    0x18(%rdi),%rax
 104f1dc:	mov    0x14(%rdi),%ecx
 104f1df:	lea    (%rax,%rcx,1),%rdi
 104f1e3:	add    $0x18,%rdi
 104f1e7:	testb  $0x4,0x10(%rsi)
 104f1eb:	jne    104f1a3 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xab3>
 104f1ed:	add    $0x18,%rsi
 104f1f1:	cmp    $0x10,%rdx
 104f1f5:	ja     104f1b8 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xac8>
 104f1f7:	cmp    $0x8,%rdx
 104f1fb:	jb     104f21a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xb2a>
 104f1fd:	mov    (%rdi),%rcx
 104f200:	mov    -0x8(%rdi,%rdx,1),%rdi
 104f205:	xor    (%rsi),%rcx
 104f208:	xor    -0x8(%rsi,%rdx,1),%rdi
 104f20d:	xor    %eax,%eax
 104f20f:	or     %rcx,%rdi
 104f212:	sete   %al
 104f215:	jmp    104f0c0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x9d0>
 104f21a:	cmp    $0x4,%rdx
 104f21e:	jb     104f238 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xb48>
 104f220:	mov    (%rdi),%ecx
 104f222:	mov    -0x4(%rdi,%rdx,1),%edi
 104f226:	xor    (%rsi),%ecx
 104f228:	xor    -0x4(%rsi,%rdx,1),%edi
 104f22c:	xor    %eax,%eax
 104f22e:	or     %ecx,%edi
 104f230:	sete   %al
 104f233:	jmp    104f0c0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x9d0>
 104f238:	cmp    $0x1,%rdx
 104f23c:	jne    104f24d <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xb5d>
 104f23e:	movzbl (%rdi),%ecx
 104f241:	xor    %eax,%eax
 104f243:	cmp    (%rsi),%cl
 104f245:	sete   %al
 104f248:	jmp    104f0c0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x9d0>
 104f24d:	movzwl (%rdi),%ecx
 104f250:	movzwl -0x2(%rdi,%rdx,1),%edi
 104f255:	xor    (%rsi),%cx
 104f258:	xor    -0x2(%rsi,%rdx,1),%di
 104f25d:	xor    %eax,%eax
 104f25f:	or     %cx,%di
 104f262:	sete   %al
 104f265:	jmp    104f0c0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x9d0>
 104f26a:	lea    0xc8(%rsp),%rax
 104f272:	lea    0x258(%rbp),%rdi
 104f279:	mov    %rsi,%r14
 104f27c:	mov    %rax,%rsi
 104f27f:	call   1087960 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop>
 104f284:	mov    %r14,%rsi
 104f287:	test   %bl,%bl
 104f289:	jne    104ef7b <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x88b>
 104f28f:	jmp    104efc9 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x8d9>
 104f294:	mov    0x18(%rsi),%rax
 104f298:	mov    0x14(%rsi),%ecx
 104f29b:	lea    (%rax,%rcx,1),%rdi
 104f29f:	add    $0x18,%rdi
 104f2a3:	testb  $0x4,0x6b6e6(%rip)        # 10ba990 <myl_lit_7afa21b5dfd0bec52f3c46b131c861acf738a60d12be67523b48ae28324a1934_instance+0x20>
 104f2aa:	mov    0x6b6e7(%rip),%rax        # 10ba998 <myl_lit_7afa21b5dfd0bec52f3c46b131c861acf738a60d12be67523b48ae28324a1934_instance+0x28>
 104f2b1:	mov    0x6b6dd(%rip),%ecx        # 10ba994 <myl_lit_7afa21b5dfd0bec52f3c46b131c861acf738a60d12be67523b48ae28324a1934_instance+0x24>
 104f2b7:	lea    0x18(%rax,%rcx,1),%rcx
 104f2bc:	mov    $0x10ba998,%eax
 104f2c1:	cmovne %rcx,%rax
 104f2c5:	cmp    $0x10,%rdx
 104f2c9:	ja     104f2ed <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xbfd>
 104f2cb:	cmp    $0x8,%rdx
 104f2cf:	jb     104f379 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xc89>
 104f2d5:	mov    (%rdi),%rcx
 104f2d8:	mov    -0x8(%rdi,%rdx,1),%rdi
 104f2dd:	xor    (%rax),%rcx
 104f2e0:	xor    -0x8(%rax,%rdx,1),%rdi
 104f2e5:	or     %rcx,%rdi
 104f2e8:	jmp    104f3f5 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xd05>
 104f2ed:	mov    %rsi,%r14
 104f2f0:	mov    %rax,%rsi
 104f2f3:	cmp    $0x100,%rdx
 104f2fa:	ja     104f38f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xc9f>
 104f300:	call   10accc0 <bcmp@plt>
 104f305:	test   %eax,%eax
 104f307:	setne  %bl
 104f30a:	jmp    104f399 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xca9>
 104f30f:	mov    0x18(%rdi),%rax
 104f313:	mov    0x14(%rdi),%ecx
 104f316:	lea    (%rax,%rcx,1),%rdi
 104f31a:	add    $0x18,%rdi
 104f31e:	testb  $0x4,0x10(%rsi)
 104f322:	jne    104f32a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xc3a>
 104f324:	add    $0x18,%rsi
 104f328:	jmp    104f339 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xc49>
 104f32a:	mov    0x18(%rsi),%rax
 104f32e:	mov    0x14(%rsi),%ecx
 104f331:	lea    (%rax,%rcx,1),%rsi
 104f335:	add    $0x18,%rsi
 104f339:	cmp    $0x11,%rdx
 104f33d:	jae    104f35d <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xc6d>
 104f33f:	cmp    $0x7,%rdx
 104f343:	jbe    104f39e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xcae>
 104f345:	mov    (%rdi),%rax
 104f348:	mov    -0x8(%rdi,%rdx,1),%rcx
 104f34d:	xor    (%rsi),%rax
 104f350:	xor    -0x8(%rsi,%rdx,1),%rcx
 104f355:	or     %rax,%rcx
 104f358:	jmp    104f74c <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x105c>
 104f35d:	cmp    $0x101,%rdx
 104f364:	jae    104f3b7 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xcc7>
 104f366:	call   10accc0 <bcmp@plt>
 104f36b:	mov    %eax,%ecx
 104f36d:	xor    %eax,%eax
 104f36f:	test   %ecx,%ecx
 104f371:	sete   %al
 104f374:	jmp    104f00e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x91e>
 104f379:	cmp    $0x4,%rdx
 104f37d:	jb     104f3c1 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xcd1>
 104f37f:	mov    (%rdi),%ecx
 104f381:	mov    -0x4(%rdi,%rdx,1),%edi
 104f385:	xor    (%rax),%ecx
 104f387:	xor    -0x4(%rax,%rdx,1),%edi
 104f38b:	or     %ecx,%edi
 104f38d:	jmp    104f3f5 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xd05>
 104f38f:	call   10934f0 <equal_large_octets>
 104f394:	test   %eax,%eax
 104f396:	sete   %bl
 104f399:	mov    %r14,%rsi
 104f39c:	jmp    104f3fb <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xd0b>
 104f39e:	cmp    $0x3,%rdx
 104f3a2:	jbe    104f3ce <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xcde>
 104f3a4:	mov    (%rdi),%eax
 104f3a6:	mov    -0x4(%rdi,%rdx,1),%ecx
 104f3aa:	xor    (%rsi),%eax
 104f3ac:	xor    -0x4(%rsi,%rdx,1),%ecx
 104f3b0:	or     %eax,%ecx
 104f3b2:	jmp    104f74c <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x105c>
 104f3b7:	call   10934f0 <equal_large_octets>
 104f3bc:	jmp    104f00e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x91e>
 104f3c1:	cmp    $0x1,%rdx
 104f3c5:	jne    104f3e2 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xcf2>
 104f3c7:	movzbl (%rdi),%ecx
 104f3ca:	cmp    (%rax),%cl
 104f3cc:	jmp    104f3f5 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xd05>
 104f3ce:	cmp    $0x1,%rdx
 104f3d2:	jne    104f739 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1049>
 104f3d8:	movzbl (%rdi),%eax
 104f3db:	cmp    (%rsi),%al
 104f3dd:	jmp    104f74c <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x105c>
 104f3e2:	movzwl (%rdi),%ecx
 104f3e5:	movzwl -0x2(%rdi,%rdx,1),%edi
 104f3ea:	xor    (%rax),%cx
 104f3ed:	xor    -0x2(%rax,%rdx,1),%di
 104f3f2:	or     %cx,%di
 104f3f5:	sete   %bl
 104f3f8:	xor    $0x1,%bl
 104f3fb:	test   %r13,0x6b56e(%rip)        # 10ba970 <myl_lit_7afa21b5dfd0bec52f3c46b131c861acf738a60d12be67523b48ae28324a1934_instance>
 104f402:	je     104f43a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xd4a>
 104f404:	test   %bl,%bl
 104f406:	je     104f45f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xd6f>
 104f408:	movq   $0x10ba608,0x38(%rsp)
 104f411:	movq   $0x10ba608,0x70(%rsp)
 104f41a:	movq   $0x10ba608,0xc8(%rsp)
 104f426:	cmp    $0x10ba608,%rsi
 104f42d:	jne    104f63f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xf4f>
 104f433:	xor    %ebx,%ebx
 104f435:	jmp    104f770 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1080>
 104f43a:	mov    0x6b51f(%rip),%rax        # 10ba960 <myl_lit_7a43bb86b2bccf6ad7e922d1f9ee2e9c1abbad0e5e2f1aa80d1ed73fc964ae92_instance+0x20>
 104f441:	dec    %rax
 104f444:	jne    104f454 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xd64>
 104f446:	cmpq   $0x0,0x6b51a(%rip)        # 10ba968 <myl_lit_7a43bb86b2bccf6ad7e922d1f9ee2e9c1abbad0e5e2f1aa80d1ed73fc964ae92_instance+0x28>
 104f44e:	je     104f670 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xf80>
 104f454:	mov    %rax,0x6b505(%rip)        # 10ba960 <myl_lit_7a43bb86b2bccf6ad7e922d1f9ee2e9c1abbad0e5e2f1aa80d1ed73fc964ae92_instance+0x20>
 104f45b:	test   %bl,%bl
 104f45d:	jne    104f408 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xd18>
 104f45f:	xor    %eax,%eax
 104f461:	movabs $0x89705f3112a28fe5,%rdi
 104f46b:	xor    %ebx,%ebx
 104f46d:	nopl   (%rax)
 104f470:	mov    0x8(%rsp),%rsi
 104f475:	add    %rbx,%rsi
 104f478:	jo     1051c40 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3550>
 104f47e:	mov    %rax,%r13
 104f481:	mov    0x30(%rsp),%rcx
 104f486:	mov    0x8(%rcx),%rax
 104f48a:	cmpq   $0x0,(%rax)
 104f48e:	je     1051c52 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3562>
 104f494:	mov    0x20(%rax),%rax
 104f498:	mov    (%rax),%r14
 104f49b:	test   %r14,%r14
 104f49e:	je     104f4c1 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xdd1>
 104f4a0:	movabs $0x4000000000000002,%rax
 104f4aa:	test   %rax,-0x10(%r14)
 104f4ae:	jne    104f4c1 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xdd1>
 104f4b0:	mov    -0x18(%r14),%rax
 104f4b4:	inc    %rax
 104f4b7:	je     1050f39 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2849>
 104f4bd:	mov    %rax,-0x18(%r14)
 104f4c1:	mov    %r14,0x70(%rsp)
 104f4c6:	mov    0x10(%rcx),%rax
 104f4ca:	and    $0x3,%esi
 104f4cd:	mov    (%rax),%rdx
 104f4d0:	cmp    %rdx,%rsi
 104f4d3:	jae    1051c5e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x356e>
 104f4d9:	mov    0x20(%rax),%rax
 104f4dd:	mov    (%rax,%rsi,8),%rax
 104f4e1:	mov    (%rax),%rcx
 104f4e4:	test   %rcx,%rcx
 104f4e7:	je     104f520 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xe30>
 104f4e9:	mov    $0xffffffffffffffff,%r15
 104f4f0:	cmp    (%r14),%rcx
 104f4f3:	ja     104f580 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xe90>
 104f4f9:	mov    0x10(%r14),%ebp
 104f4fd:	test   $0x4,%bpl
 104f501:	jne    104f525 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xe35>
 104f503:	lea    0x18(%r14),%rdi
 104f507:	testb  $0x4,0x10(%rax)
 104f50b:	je     104f53b <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xe4b>
 104f50d:	mov    0x18(%rax),%rcx
 104f511:	mov    0x14(%rax),%edx
 104f514:	add    %rcx,%rdx
 104f517:	add    $0x18,%rdx
 104f51b:	jmp    104f53f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xe4f>
 104f51d:	nopl   (%rax)
 104f520:	xor    %r15d,%r15d
 104f523:	jmp    104f580 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xe90>
 104f525:	mov    0x18(%r14),%rcx
 104f529:	mov    0x14(%r14),%edx
 104f52d:	lea    (%rcx,%rdx,1),%rdi
 104f531:	add    $0x18,%rdi
 104f535:	testb  $0x4,0x10(%rax)
 104f539:	jne    104f50d <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xe1d>
 104f53b:	lea    0x18(%rax),%rdx
 104f53f:	mov    0x8(%r14),%rsi
 104f543:	mov    0x8(%rax),%rcx
 104f547:	call   1093530 <myl_native_octets_find>
 104f54c:	cmp    $0xffffffffffffffff,%rax
 104f550:	movabs $0x89705f3112a28fe5,%rdi
 104f55a:	je     104f580 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xe90>
 104f55c:	test   $0x1,%bpl
 104f560:	jne    104f577 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xe87>
 104f562:	mov    %r14,%rdi
 104f565:	mov    %rax,%rsi
 104f568:	call   1090f90 <index_walk>
 104f56d:	movabs $0x89705f3112a28fe5,%rdi
 104f577:	mov    %rax,%r15
 104f57a:	nopw   0x0(%rax,%rax,1)
 104f580:	mov    %r15,%r12
 104f583:	inc    %r12
 104f586:	jo     1051c66 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3576>
 104f58c:	test   %r14,%r14
 104f58f:	mov    0x10(%rsp),%rbp
 104f594:	je     104f5ba <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xeca>
 104f596:	movabs $0x4000000000000002,%rax
 104f5a0:	test   %rax,-0x10(%r14)
 104f5a4:	jne    104f5ba <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xeca>
 104f5a6:	mov    -0x18(%r14),%rax
 104f5aa:	dec    %rax
 104f5ad:	jne    104f5b6 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xec6>
 104f5af:	cmpq   $0x0,-0x20(%r14)
 104f5b4:	je     104f605 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xf15>
 104f5b6:	mov    %rax,-0x18(%r14)
 104f5ba:	mov    %r13,%rcx
 104f5bd:	add    %r12,%rcx
 104f5c0:	jo     104f62f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xf3f>
 104f5c2:	mov    %rcx,%rax
 104f5c5:	imul   %rdi
 104f5c8:	add    %rcx,%rdx
 104f5cb:	mov    %rdx,%rax
 104f5ce:	shr    $0x3f,%rax
 104f5d2:	sar    $0x1d,%rdx
 104f5d6:	add    %rax,%rdx
 104f5d9:	imul   $0x3b9aca07,%rdx,%rax
 104f5e0:	sub    %rax,%rcx
 104f5e3:	mov    %rcx,%rax
 104f5e6:	sar    $0x3f,%rax
 104f5ea:	and    $0x3b9aca07,%eax
 104f5ef:	add    %rcx,%rax
 104f5f2:	inc    %rbx
 104f5f5:	cmp    %rbx,0x28(%rsp)
 104f5fa:	jne    104f470 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xd80>
 104f600:	jmp    104f01c <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x92c>
 104f605:	mov    0x18(%rsp),%r15
 104f60a:	mov    %r15,%rdi
 104f60d:	mov    %r14,%rsi
 104f610:	call   109b630 <myl_rc_hold_edge_release>
 104f615:	mov    %r15,%rdi
 104f618:	call   109e650 <myl_rc_drain>
 104f61d:	movabs $0x89705f3112a28fe5,%rdi
 104f627:	mov    %r13,%rcx
 104f62a:	add    %r12,%rcx
 104f62d:	jno    104f5c2 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xed2>
 104f62f:	mov    %rbp,%rdi
 104f632:	xor    %esi,%esi
 104f634:	mov    %r13,%rdx
 104f637:	mov    %r12,%rcx
 104f63a:	call   108c8c0 <myl_qbe_fail_overflow_op>
 104f63f:	mov    $0x1,%bl
 104f641:	test   %rsi,%rsi
 104f644:	je     104f770 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1080>
 104f64a:	mov    0x8(%rsi),%rdx
 104f64e:	cmp    0x6afbb(%rip),%rdx        # 10ba610 <myl_lit_4d6ff6f7284ab5ea56c67ebc627dbe0fd0bb153a04fdd105bd867658d486b6d7_instance+0x18>
 104f655:	jne    104f770 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1080>
 104f65b:	test   %rdx,%rdx
 104f65e:	je     104f433 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xd43>
 104f664:	testb  $0x4,0x10(%rsi)
 104f668:	jne    104f69a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xfaa>
 104f66a:	lea    0x18(%rsi),%rdi
 104f66e:	jmp    104f6a9 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xfb9>
 104f670:	lea    0xc8(%rsp),%rax
 104f678:	lea    0x258(%rbp),%rdi
 104f67f:	mov    %rsi,%r14
 104f682:	mov    %rax,%rsi
 104f685:	call   1087960 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop>
 104f68a:	mov    %r14,%rsi
 104f68d:	test   %bl,%bl
 104f68f:	jne    104f408 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xd18>
 104f695:	jmp    104f45f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xd6f>
 104f69a:	mov    0x18(%rsi),%rax
 104f69e:	mov    0x14(%rsi),%ecx
 104f6a1:	lea    (%rax,%rcx,1),%rdi
 104f6a5:	add    $0x18,%rdi
 104f6a9:	testb  $0x4,0x6af68(%rip)        # 10ba618 <myl_lit_4d6ff6f7284ab5ea56c67ebc627dbe0fd0bb153a04fdd105bd867658d486b6d7_instance+0x20>
 104f6b0:	mov    0x6af69(%rip),%rax        # 10ba620 <myl_lit_4d6ff6f7284ab5ea56c67ebc627dbe0fd0bb153a04fdd105bd867658d486b6d7_instance+0x28>
 104f6b7:	mov    0x6af5f(%rip),%ecx        # 10ba61c <myl_lit_4d6ff6f7284ab5ea56c67ebc627dbe0fd0bb153a04fdd105bd867658d486b6d7_instance+0x24>
 104f6bd:	lea    0x18(%rax,%rcx,1),%rcx
 104f6c2:	mov    $0x10ba620,%eax
 104f6c7:	cmovne %rcx,%rax
 104f6cb:	cmp    $0x10,%rdx
 104f6cf:	ja     104f6ec <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0xffc>
 104f6d1:	cmp    $0x8,%rdx
 104f6d5:	jb     104f707 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1017>
 104f6d7:	mov    (%rdi),%rcx
 104f6da:	mov    -0x8(%rdi,%rdx,1),%rdi
 104f6df:	xor    (%rax),%rcx
 104f6e2:	xor    -0x8(%rax,%rdx,1),%rdi
 104f6e7:	or     %rcx,%rdi
 104f6ea:	jmp    104f76a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x107a>
 104f6ec:	mov    %rsi,%r14
 104f6ef:	mov    %rax,%rsi
 104f6f2:	cmp    $0x100,%rdx
 104f6f9:	ja     104f71d <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x102d>
 104f6fb:	call   10accc0 <bcmp@plt>
 104f700:	test   %eax,%eax
 104f702:	setne  %bl
 104f705:	jmp    104f727 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1037>
 104f707:	cmp    $0x4,%rdx
 104f70b:	jb     104f72c <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x103c>
 104f70d:	mov    (%rdi),%ecx
 104f70f:	mov    -0x4(%rdi,%rdx,1),%edi
 104f713:	xor    (%rax),%ecx
 104f715:	xor    -0x4(%rax,%rdx,1),%edi
 104f719:	or     %ecx,%edi
 104f71b:	jmp    104f76a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x107a>
 104f71d:	call   10934f0 <equal_large_octets>
 104f722:	test   %eax,%eax
 104f724:	sete   %bl
 104f727:	mov    %r14,%rsi
 104f72a:	jmp    104f770 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1080>
 104f72c:	cmp    $0x1,%rdx
 104f730:	jne    104f757 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1067>
 104f732:	movzbl (%rdi),%ecx
 104f735:	cmp    (%rax),%cl
 104f737:	jmp    104f76a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x107a>
 104f739:	movzwl (%rdi),%eax
 104f73c:	movzwl -0x2(%rdi,%rdx,1),%ecx
 104f741:	xor    (%rsi),%ax
 104f744:	xor    -0x2(%rsi,%rdx,1),%cx
 104f749:	or     %ax,%cx
 104f74c:	sete   %al
 104f74f:	movzbl %al,%eax
 104f752:	jmp    104f00e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x91e>
 104f757:	movzwl (%rdi),%ecx
 104f75a:	movzwl -0x2(%rdi,%rdx,1),%edi
 104f75f:	xor    (%rax),%cx
 104f762:	xor    -0x2(%rax,%rdx,1),%di
 104f767:	or     %cx,%di
 104f76a:	sete   %bl
 104f76d:	xor    $0x1,%bl
 104f770:	test   %r13,0x6ae81(%rip)        # 10ba5f8 <myl_lit_4d6ff6f7284ab5ea56c67ebc627dbe0fd0bb153a04fdd105bd867658d486b6d7_instance>
 104f777:	je     104f7a6 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x10b6>
 104f779:	test   %bl,%bl
 104f77b:	je     104f7cb <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x10db>
 104f77d:	movq   $0x10ba4d0,0x70(%rsp)
 104f786:	movq   $0x10ba4d0,0xc8(%rsp)
 104f792:	cmp    $0x10ba4d0,%rsi
 104f799:	jne    10508b9 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x21c9>
 104f79f:	xor    %ebx,%ebx
 104f7a1:	jmp    1050a37 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2347>
 104f7a6:	mov    0x6ae3b(%rip),%rax        # 10ba5e8 <myl_lit_4b4df4d43798003d79847faa0fc7a8aff0b04bace93d5fc2cc109ef7308827f6_instance+0x38>
 104f7ad:	dec    %rax
 104f7b0:	jne    104f7c0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x10d0>
 104f7b2:	cmpq   $0x0,0x6ae36(%rip)        # 10ba5f0 <myl_lit_4b4df4d43798003d79847faa0fc7a8aff0b04bace93d5fc2cc109ef7308827f6_instance+0x40>
 104f7ba:	je     1050955 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2265>
 104f7c0:	mov    %rax,0x6ae21(%rip)        # 10ba5e8 <myl_lit_4b4df4d43798003d79847faa0fc7a8aff0b04bace93d5fc2cc109ef7308827f6_instance+0x38>
 104f7c7:	test   %bl,%bl
 104f7c9:	jne    104f77d <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x108d>
 104f7cb:	movabs $0x5000000000000000,%rcx
 104f7d5:	movabs $0x101010101010101,%r15
 104f7df:	lea    0x38(%rsp),%rdx
 104f7e4:	lea    0x70(%rsp),%rsi
 104f7e9:	mov    %rsi,%rax
 104f7ec:	sub    %rdx,%rax
 104f7ef:	sub    %rsi,%rdx
 104f7f2:	cmovb  %rax,%rdx
 104f7f6:	mov    %rdx,0x128(%rsp)
 104f7fe:	lea    0x68(%rsp),%rdx
 104f803:	lea    0x60(%rsp),%rsi
 104f808:	mov    %rsi,%rax
 104f80b:	sub    %rdx,%rax
 104f80e:	sub    %rsi,%rdx
 104f811:	cmovb  %rax,%rdx
 104f815:	mov    %rdx,0x180(%rsp)
 104f81d:	xor    %r12d,%r12d
 104f820:	lea    0x1(%rcx),%rax
 104f824:	mov    %rax,0x110(%rsp)
 104f82c:	vpbroadcastd -0x486b1(%rip),%xmm9        # 1007184 <__abi_tag+0x6e88>
 104f835:	vpbroadcastd -0x486ba(%rip),%ymm10        # 1007184 <__abi_tag+0x6e88>
 104f83e:	vpbroadcastq -0x4872f(%rip),%ymm0        # 1007118 <__abi_tag+0x6e1c>
 104f847:	vmovdqu %ymm0,0x1f0(%rsp)
 104f850:	xor    %eax,%eax
 104f852:	vmovdqa %xmm9,0x50(%rsp)
 104f858:	vmovdqu %ymm10,0xf0(%rsp)
 104f861:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 104f870:	mov    %rax,0x20(%rsp)
 104f875:	mov    0x8(%rsp),%rsi
 104f87a:	add    %r12,%rsi
 104f87d:	jo     1051c85 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3595>
 104f883:	mov    0x30(%rsp),%rax
 104f888:	mov    0x8(%rax),%rax
 104f88c:	and    $0x1,%esi
 104f88f:	mov    (%rax),%rdx
 104f892:	cmp    %rdx,%rsi
 104f895:	jae    1051c7a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x358a>
 104f89b:	mov    0x20(%rax),%rax
 104f89f:	mov    (%rax,%rsi,8),%r14
 104f8a3:	test   %rsi,%rsi
 104f8a6:	jne    104f950 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1260>
 104f8ac:	movq   $0x10bb320,0x70(%rsp)
 104f8b5:	movq   $0x10bb320,0xc8(%rsp)
 104f8c1:	movq   $0x10bb320,0x38(%rsp)
 104f8ca:	mov    0x6ba3f(%rip),%rax        # 10bb310 <myl_lit_f3eaad558815542caf7da2bdfda9d4cabeaf9c2200b79ab8ff85b21b8470fac6_instance>
 104f8d1:	test   %rax,0x110(%rsp)
 104f8d9:	je     104f9e5 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x12f5>
 104f8df:	cmpq   $0x0,0x128(%rsp)
 104f8e8:	setne  %cl
 104f8eb:	movabs $0x5000000000000000,%rdx
 104f8f5:	test   %rdx,%rax
 104f8f8:	sete   %dl
 104f8fb:	mov    $0x10bb320,%eax
 104f900:	test   %cl,%dl
 104f902:	jne    104f9e0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x12f0>
 104f908:	mov    $0x1030c78,%esi
 104f90d:	mov    0x18(%rsp),%rdi
 104f912:	lea    0x70(%rsp),%rdx
 104f917:	lea    0x38(%rsp),%rcx
 104f91c:	mov    0x44(%rsp),%r8d
 104f921:	vzeroupper
 104f924:	call   10a7a70 <myl_rc_native_take>
 104f929:	vmovdqu 0xf0(%rsp),%ymm10
 104f932:	vmovdqa 0x50(%rsp),%xmm9
 104f938:	test   %eax,%eax
 104f93a:	jne    104f9ee <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x12fe>
 104f940:	jmp    10508f1 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2201>
 104f945:	data16 cs nopw 0x0(%rax,%rax,1)
 104f950:	movq   $0x10ba690,0x70(%rsp)
 104f959:	movq   $0x10ba690,0xc8(%rsp)
 104f965:	movq   $0x10ba690,0x38(%rsp)
 104f96e:	mov    0x6ad0b(%rip),%rax        # 10ba680 <myl_lit_54807ae7ae90f7f8ab8705f04b17dcd2d77e7355f27b7f7252156b0c234f7d3f_instance>
 104f975:	test   %rax,0x110(%rsp)
 104f97d:	je     104f9e5 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x12f5>
 104f97f:	cmpq   $0x0,0x128(%rsp)
 104f988:	setne  %cl
 104f98b:	movabs $0x5000000000000000,%rdx
 104f995:	test   %rdx,%rax
 104f998:	sete   %dl
 104f99b:	mov    $0x10ba690,%eax
 104f9a0:	test   %cl,%dl
 104f9a2:	jne    104f9e0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x12f0>
 104f9a4:	mov    $0x1030c78,%esi
 104f9a9:	mov    0x18(%rsp),%rdi
 104f9ae:	lea    0x70(%rsp),%rdx
 104f9b3:	lea    0x38(%rsp),%rcx
 104f9b8:	mov    0x44(%rsp),%r8d
 104f9bd:	vzeroupper
 104f9c0:	call   10a7a70 <myl_rc_native_take>
 104f9c5:	vmovdqu 0xf0(%rsp),%ymm10
 104f9ce:	vmovdqa 0x50(%rsp),%xmm9
 104f9d4:	test   %eax,%eax
 104f9d6:	jne    104f9ee <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x12fe>
 104f9d8:	jmp    1050923 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2233>
 104f9dd:	nopl   (%rax)
 104f9e0:	mov    %rax,0x70(%rsp)
 104f9e5:	movq   $0x0,0x38(%rsp)
 104f9ee:	mov    0x70(%rsp),%rdx
 104f9f3:	movq   $0x0,0x250(%rsp)
 104f9ff:	movq   $0x0,0x230(%rsp)
 104fa0b:	cmp    %rsp,0x40(%rbp)
 104fa0f:	ja     1051c9a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x35aa>
 104fa15:	cmpq   $0x0,(%rdx)
 104fa19:	je     1051ca5 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x35b5>
 104fa1f:	mov    0x2c8(%rbp),%esi
 104fa25:	mov    %r14,0xc0(%rsp)
 104fa2d:	mov    %rdx,0x138(%rsp)
 104fa35:	testb  $0x4,0x10(%r14)
 104fa3a:	jne    104fa60 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1370>
 104fa3c:	lea    0x18(%r14),%rbx
 104fa40:	mov    %r12,0x198(%rsp)
 104fa48:	testb  $0x4,0x10(%rdx)
 104fa4c:	je     104fa7e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x138e>
 104fa4e:	mov    0x18(%rdx),%rax
 104fa52:	mov    0x14(%rdx),%ecx
 104fa55:	lea    (%rax,%rcx,1),%r13
 104fa59:	add    $0x18,%r13
 104fa5d:	jmp    104fa82 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1392>
 104fa5f:	nop
 104fa60:	mov    0x18(%r14),%rax
 104fa64:	mov    0x14(%r14),%ecx
 104fa68:	lea    (%rax,%rcx,1),%rbx
 104fa6c:	add    $0x18,%rbx
 104fa70:	mov    %r12,0x198(%rsp)
 104fa78:	testb  $0x4,0x10(%rdx)
 104fa7c:	jne    104fa4e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x135e>
 104fa7e:	lea    0x18(%rdx),%r13
 104fa82:	mov    0x8(%rdx),%rcx
 104fa86:	mov    0x8(%r14),%r14
 104fa8a:	lea    -0x1(%rcx),%rax
 104fa8e:	cmp    %r14,%rax
 104fa91:	mov    %rcx,0x118(%rsp)
 104fa99:	mov    %rdx,0x190(%rsp)
 104faa1:	mov    %esi,0x124(%rsp)
 104faa8:	jae    104fca0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x15b0>
 104faae:	cmp    $0x1,%rcx
 104fab2:	jne    104fcb0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x15c0>
 104fab8:	movzbl 0x0(%r13),%eax
 104fabd:	vmovd  %eax,%xmm0
 104fac1:	vpbroadcastb %xmm0,%xmm0
 104fac6:	lea    0x18(%rbx),%rcx
 104faca:	xor    %r12d,%r12d
 104facd:	xor    %edx,%edx
 104facf:	mov    $0x10000,%r11d
 104fad5:	jmp    104faf2 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1402>
 104fad7:	nopw   0x0(%rax,%rax,1)
 104fae0:	mov    %r9d,%edi
 104fae3:	add    %rdi,%r12
 104fae6:	add    %rsi,%rdx
 104fae9:	cmp    %r14,%rdx
 104faec:	jae    104fd03 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1613>
 104faf2:	mov    %r14,%rsi
 104faf5:	sub    %rdx,%rsi
 104faf8:	cmp    $0x10000,%rsi
 104faff:	cmovae %r11,%rsi
 104fb03:	mov    %r14,%r8
 104fb06:	sub    %rdx,%r8
 104fb09:	jne    104fb20 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1430>
 104fb0b:	xor    %edi,%edi
 104fb0d:	add    %rdi,%r12
 104fb10:	add    %rsi,%rdx
 104fb13:	cmp    %r14,%rdx
 104fb16:	jb     104faf2 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1402>
 104fb18:	jmp    104fd03 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1613>
 104fb1d:	nopl   (%rax)
 104fb20:	lea    (%rbx,%rdx,1),%rdi
 104fb24:	cmp    $0x3,%r8
 104fb28:	ja     104fb40 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1450>
 104fb2a:	xor    %r8d,%r8d
 104fb2d:	xor    %r9d,%r9d
 104fb30:	jmp    104fc80 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1590>
 104fb35:	data16 cs nopw 0x0(%rax,%rax,1)
 104fb40:	cmp    $0x20,%r8
 104fb44:	jae    104fb51 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1461>
 104fb46:	xor    %r8d,%r8d
 104fb49:	xor    %r9d,%r9d
 104fb4c:	jmp    104fc24 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1534>
 104fb51:	mov    %esi,%r8d
 104fb54:	and    $0x1ffe0,%r8d
 104fb5b:	lea    (%rcx,%rdx,1),%r9
 104fb5f:	vpxor  %xmm1,%xmm1,%xmm1
 104fb63:	xor    %r10d,%r10d
 104fb66:	vpxor  %xmm2,%xmm2,%xmm2
 104fb6a:	vpxor  %xmm3,%xmm3,%xmm3
 104fb6e:	vpxor  %xmm4,%xmm4,%xmm4
 104fb72:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 104fb80:	vmovq  -0x18(%r9,%r10,1),%xmm5
 104fb87:	vmovq  -0x10(%r9,%r10,1),%xmm6
 104fb8e:	vmovq  -0x8(%r9,%r10,1),%xmm7
 104fb95:	vmovq  (%r9,%r10,1),%xmm8
 104fb9b:	vpcmpeqb %xmm0,%xmm5,%xmm5
 104fb9f:	vpmovzxbd %xmm5,%ymm5
 104fba4:	vpand  %ymm5,%ymm10,%ymm5
 104fba8:	vpaddd %ymm5,%ymm1,%ymm1
 104fbac:	vpcmpeqb %xmm0,%xmm6,%xmm5
 104fbb0:	vpmovzxbd %xmm5,%ymm5
 104fbb5:	vpand  %ymm5,%ymm10,%ymm5
 104fbb9:	vpaddd %ymm5,%ymm2,%ymm2
 104fbbd:	vpcmpeqb %xmm0,%xmm7,%xmm5
 104fbc1:	vpmovzxbd %xmm5,%ymm5
 104fbc6:	vpand  %ymm5,%ymm10,%ymm5
 104fbca:	vpaddd %ymm5,%ymm3,%ymm3
 104fbce:	vpcmpeqb %xmm0,%xmm8,%xmm5
 104fbd2:	vpmovzxbd %xmm5,%ymm5
 104fbd7:	vpand  %ymm5,%ymm10,%ymm5
 104fbdb:	vpaddd %ymm5,%ymm4,%ymm4
 104fbdf:	add    $0x20,%r10
 104fbe3:	cmp    %r10,%r8
 104fbe6:	jne    104fb80 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1490>
 104fbe8:	vpaddd %ymm1,%ymm2,%ymm1
 104fbec:	vpaddd %ymm1,%ymm3,%ymm1
 104fbf0:	vpaddd %ymm1,%ymm4,%ymm1
 104fbf4:	vextracti128 $0x1,%ymm1,%xmm2
 104fbfa:	vpaddd %xmm2,%xmm1,%xmm1
 104fbfe:	vpshufd $0xee,%xmm1,%xmm2
 104fc03:	vpaddd %xmm2,%xmm1,%xmm1
 104fc07:	vpshufd $0x55,%xmm1,%xmm2
 104fc0c:	vpaddd %xmm2,%xmm1,%xmm1
 104fc10:	vmovd  %xmm1,%r9d
 104fc15:	cmp    %r8,%rsi
 104fc18:	je     104fae0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x13f0>
 104fc1e:	test   $0x1c,%sil
 104fc22:	je     104fc80 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1590>
 104fc24:	mov    %r8,%r10
 104fc27:	mov    %esi,%r8d
 104fc2a:	and    $0x1fffc,%r8d
 104fc31:	vmovd  %r9d,%xmm1
 104fc36:	cs nopw 0x0(%rax,%rax,1)
 104fc40:	vmovd  (%rdi,%r10,1),%xmm2
 104fc46:	vpcmpeqb %xmm0,%xmm2,%xmm2
 104fc4a:	vpmovzxbd %xmm2,%xmm2
 104fc4f:	vpand  %xmm2,%xmm9,%xmm2
 104fc53:	vpaddd %xmm2,%xmm1,%xmm1
 104fc57:	add    $0x4,%r10
 104fc5b:	cmp    %r10,%r8
 104fc5e:	jne    104fc40 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1550>
 104fc60:	vpshufd $0xee,%xmm1,%xmm2
 104fc65:	vpaddd %xmm2,%xmm1,%xmm1
 104fc69:	vpshufd $0x55,%xmm1,%xmm2
 104fc6e:	vpaddd %xmm2,%xmm1,%xmm1
 104fc72:	vmovd  %xmm1,%r9d
 104fc77:	jmp    104fc91 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x15a1>
 104fc79:	nopl   0x0(%rax)
 104fc80:	xor    %r10d,%r10d
 104fc83:	cmp    %al,(%rdi,%r8,1)
 104fc87:	sete   %r10b
 104fc8b:	add    %r10d,%r9d
 104fc8e:	inc    %r8
 104fc91:	cmp    %r8,%rsi
 104fc94:	jne    104fc80 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1590>
 104fc96:	jmp    104fae0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x13f0>
 104fc9b:	nopl   0x0(%rax,%rax,1)
 104fca0:	xor    %r12d,%r12d
 104fca3:	jmp    104fd03 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1613>
 104fca5:	data16 cs nopw 0x0(%rax,%rax,1)
 104fcb0:	mov    %rbx,%rdi
 104fcb3:	mov    %r14,%rsi
 104fcb6:	mov    %r13,%rdx
 104fcb9:	vzeroupper
 104fcbc:	call   1093530 <myl_native_octets_find>
 104fcc1:	xor    %r12d,%r12d
 104fcc4:	xor    %r15d,%r15d
 104fcc7:	cmp    $0xffffffffffffffff,%rax
 104fccb:	je     104fcf9 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1609>
 104fccd:	nopl   (%rax)
 104fcd0:	mov    0x118(%rsp),%rcx
 104fcd8:	add    %rcx,%r15
 104fcdb:	add    %rax,%r15
 104fcde:	inc    %r12
 104fce1:	lea    (%rbx,%r15,1),%rdi
 104fce5:	mov    %r14,%rsi
 104fce8:	sub    %r15,%rsi
 104fceb:	mov    %r13,%rdx
 104fcee:	call   1093530 <myl_native_octets_find>
 104fcf3:	cmp    $0xffffffffffffffff,%rax
 104fcf7:	jne    104fcd0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x15e0>
 104fcf9:	movabs $0x101010101010101,%r15
 104fd03:	inc    %r12
 104fd06:	mov    0x10(%rsp),%r14
 104fd0b:	mov    0x268(%r14),%rax
 104fd12:	mov    %rax,0x1a8(%rsp)
 104fd1a:	lea    0xc0(%rsp),%rax
 104fd22:	mov    %rax,0x1b0(%rsp)
 104fd2a:	movq   $0x1031628,0x1b8(%rsp)
 104fd36:	lea    0x1a8(%rsp),%rax
 104fd3e:	mov    %rax,0x160(%rsp)
 104fd46:	lea    0x138(%rsp),%rax
 104fd4e:	mov    %rax,0x168(%rsp)
 104fd56:	movq   $0x1031628,0x170(%rsp)
 104fd62:	lea    0x160(%rsp),%rax
 104fd6a:	mov    %rax,0x268(%r14)
 104fd71:	mov    $0x1031628,%esi
 104fd76:	mov    0x18(%rsp),%rdi
 104fd7b:	mov    %r12,%rdx
 104fd7e:	vzeroupper
 104fd81:	call   108f630 <myl_native_list_new>
 104fd86:	mov    %rax,%rbx
 104fd89:	mov    %rax,0xb8(%rsp)
 104fd91:	mov    0x268(%r14),%rax
 104fd98:	mov    %rax,0x140(%rsp)
 104fda0:	lea    0xb8(%rsp),%rax
 104fda8:	mov    %rax,0x148(%rsp)
 104fdb0:	movq   $0x1031628,0x150(%rsp)
 104fdbc:	lea    0x140(%rsp),%rax
 104fdc4:	mov    %rax,0x268(%r14)
 104fdcb:	test   %rbx,%rbx
 104fdce:	je     105031c <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1c2c>
 104fdd4:	mov    0xc0(%rsp),%r13
 104fddc:	mov    0x10(%r13),%ecx
 104fde0:	lea    0x18(%r13),%rax
 104fde4:	mov    %rax,0x98(%rsp)
 104fdec:	mov    %ecx,0xb4(%rsp)
 104fdf3:	test   $0x4,%cl
 104fdf6:	vmovdqa -0x4e3ce(%rip),%xmm8        # 1001a30 <__abi_tag+0x1734>
 104fdfe:	vmovdqu 0x1f0(%rsp),%ymm9
 104fe07:	vmovdqa -0x4e3df(%rip),%xmm10        # 1001a30 <__abi_tag+0x1734>
 104fe0f:	je     104fe28 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1738>
 104fe11:	mov    0x18(%r13),%rcx
 104fe15:	mov    0x14(%r13),%edx
 104fe19:	add    %rdx,%rcx
 104fe1c:	add    $0x18,%rcx
 104fe20:	mov    %rcx,0x98(%rsp)
 104fe28:	mov    0x138(%rsp),%rcx
 104fe30:	testb  $0x4,0x10(%rcx)
 104fe34:	jne    104fe60 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1770>
 104fe36:	add    $0x18,%rcx
 104fe3a:	mov    %rcx,0x130(%rsp)
 104fe42:	mov    %r13,%rcx
 104fe45:	testb  $0x4,0xb4(%rsp)
 104fe4d:	jne    104fe86 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1796>
 104fe4f:	jmp    104fe89 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1799>
 104fe51:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 104fe60:	mov    %rcx,%rdx
 104fe63:	mov    0x18(%rcx),%rcx
 104fe67:	mov    0x14(%rdx),%edx
 104fe6a:	add    %rdx,%rcx
 104fe6d:	add    $0x18,%rcx
 104fe71:	mov    %rcx,0x130(%rsp)
 104fe79:	mov    %r13,%rcx
 104fe7c:	testb  $0x4,0xb4(%rsp)
 104fe84:	je     104fe89 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1799>
 104fe86:	mov    (%rax),%rcx
 104fe89:	mov    0x8(%rcx),%rcx
 104fe8d:	shr    $0x2,%rcx
 104fe91:	cmp    $0xa,%rcx
 104fe95:	mov    $0x9,%eax
 104fe9a:	cmovb  %rax,%rcx
 104fe9e:	mov    %rcx,0x1a0(%rsp)
 104fea6:	mov    0x98(%rsp),%rax
 104feae:	add    $0xc,%rax
 104feb2:	mov    %rax,0x188(%rsp)
 104feba:	xor    %ebp,%ebp
 104febc:	mov    0x118(%rsp),%rcx
 104fec4:	cmp    $0x1,%r12
 104fec8:	je     104ff70 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1880>
 104fece:	xchg   %ax,%ax
 104fed0:	test   %r12,%r12
 104fed3:	je     105031e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1c2e>
 104fed9:	mov    0x98(%rsp),%rax
 104fee1:	lea    (%rax,%rbp,1),%rdi
 104fee5:	mov    0x8(%r13),%rbx
 104fee9:	mov    %rbx,%rsi
 104feec:	sub    %rbp,%rsi
 104feef:	mov    0x130(%rsp),%rdx
 104fef7:	vzeroupper
 104fefa:	call   1093530 <myl_native_octets_find>
 104feff:	vmovdqa -0x4e4d7(%rip),%xmm10        # 1001a30 <__abi_tag+0x1734>
 104ff07:	vmovdqu 0x1f0(%rsp),%ymm9
 104ff10:	vmovdqa -0x4e4e8(%rip),%xmm8        # 1001a30 <__abi_tag+0x1734>
 104ff18:	lea    (%rax,%rbp,1),%r14
 104ff1c:	cmp    $0xffffffffffffffff,%rax
 104ff20:	cmove  %rbx,%r14
 104ff24:	mov    %r14,%rbx
 104ff27:	sub    %rbp,%rbx
 104ff2a:	cmp    0x1a0(%rsp),%rbx
 104ff32:	jb     104ff84 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1894>
 104ff34:	mov    0x18(%rsp),%rdi
 104ff39:	mov    %r13,%rsi
 104ff3c:	mov    %rbp,%rdx
 104ff3f:	mov    %rbx,%rcx
 104ff42:	mov    $0xffffffffffffffff,%r8
 104ff49:	vzeroupper
 104ff4c:	call   1091ef0 <long_piece>
 104ff51:	mov    %rax,%r15
 104ff54:	test   %rax,%rax
 104ff57:	jne    1050200 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1b10>
 104ff5d:	jmp    1050290 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1ba0>
 104ff62:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 104ff70:	mov    0x8(%r13),%r14
 104ff74:	mov    %r14,%rbx
 104ff77:	sub    %rbp,%rbx
 104ff7a:	cmp    0x1a0(%rsp),%rbx
 104ff82:	jae    104ff34 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1844>
 104ff84:	mov    0x98(%rsp),%rax
 104ff8c:	lea    (%rax,%rbp,1),%r13
 104ff90:	testb  $0x1,0xb4(%rsp)
 104ff98:	jne    105016a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1a7a>
 104ff9e:	cmp    $0x8,%rbx
 104ffa2:	jae    104ffb0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x18c0>
 104ffa4:	xor    %ecx,%ecx
 104ffa6:	xor    %eax,%eax
 104ffa8:	jmp    104fff7 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1907>
 104ffaa:	nopw   0x0(%rax,%rax,1)
 104ffb0:	xor    %edx,%edx
 104ffb2:	xor    %ecx,%ecx
 104ffb4:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 104ffc0:	mov    0x0(%r13,%rdx,1),%rax
 104ffc5:	mov    %rax,%rsi
 104ffc8:	not    %rsi
 104ffcb:	add    %rsi,%rsi
 104ffce:	and    %rax,%rsi
 104ffd1:	shr    $0x7,%rsi
 104ffd5:	and    %r15,%rsi
 104ffd8:	imul   %r15,%rsi
 104ffdc:	shr    $0x38,%rsi
 104ffe0:	sub    %rsi,%rcx
 104ffe3:	add    $0x8,%rcx
 104ffe7:	lea    0x8(%rdx),%rax
 104ffeb:	add    $0x10,%rdx
 104ffef:	cmp    %rbx,%rdx
 104fff2:	mov    %rax,%rdx
 104fff5:	jbe    104ffc0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x18d0>
 104fff7:	cmp    %rbx,%rax
 104fffa:	jae    1050165 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1a75>
 1050000:	lea    (%rax,%rbp,1),%rdi
 1050004:	mov    %r14,%rdx
 1050007:	sub    %rdi,%rdx
 105000a:	cmp    $0x3,%rdx
 105000e:	mov    0x98(%rsp),%r8
 1050016:	jbe    1050140 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1a50>
 105001c:	cmp    $0x10,%rdx
 1050020:	jae    1050029 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1939>
 1050022:	xor    %esi,%esi
 1050024:	jmp    10500ee <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x19fe>
 1050029:	mov    %rdx,%rsi
 105002c:	and    $0xfffffffffffffff0,%rsi
 1050030:	vmovq  %rcx,%xmm0
 1050035:	add    0x188(%rsp),%rdi
 105003d:	vpxor  %xmm1,%xmm1,%xmm1
 1050041:	xor    %ecx,%ecx
 1050043:	vpxor  %xmm2,%xmm2,%xmm2
 1050047:	vpxor  %xmm3,%xmm3,%xmm3
 105004b:	nopl   0x0(%rax,%rax,1)
 1050050:	vmovd  -0xc(%rdi,%rcx,1),%xmm4
 1050056:	vmovd  -0x8(%rdi,%rcx,1),%xmm5
 105005c:	vmovd  -0x4(%rdi,%rcx,1),%xmm6
 1050062:	vmovd  (%rdi,%rcx,1),%xmm7
 1050067:	vpcmpgtb %xmm10,%xmm4,%xmm4
 105006c:	vpmovzxbq %xmm4,%ymm4
 1050071:	vpand  %ymm4,%ymm9,%ymm4
 1050075:	vpaddq %ymm4,%ymm0,%ymm0
 1050079:	vpcmpgtb %xmm10,%xmm5,%xmm4
 105007e:	vpmovzxbq %xmm4,%ymm4
 1050083:	vpand  %ymm4,%ymm9,%ymm4
 1050087:	vpaddq %ymm4,%ymm1,%ymm1
 105008b:	vpcmpgtb %xmm10,%xmm6,%xmm4
 1050090:	vpmovzxbq %xmm4,%ymm4
 1050095:	vpand  %ymm4,%ymm9,%ymm4
 1050099:	vpaddq %ymm4,%ymm2,%ymm2
 105009d:	vpcmpgtb %xmm10,%xmm7,%xmm4
 10500a2:	vpmovzxbq %xmm4,%ymm4
 10500a7:	vpand  %ymm4,%ymm9,%ymm4
 10500ab:	vpaddq %ymm4,%ymm3,%ymm3
 10500af:	add    $0x10,%rcx
 10500b3:	cmp    %rcx,%rsi
 10500b6:	jne    1050050 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1960>
 10500b8:	vpaddq %ymm0,%ymm1,%ymm0
 10500bc:	vpaddq %ymm0,%ymm2,%ymm0
 10500c0:	vpaddq %ymm0,%ymm3,%ymm0
 10500c4:	vextracti128 $0x1,%ymm0,%xmm1
 10500ca:	vpaddq %xmm1,%xmm0,%xmm0
 10500ce:	vpshufd $0xee,%xmm0,%xmm1
 10500d3:	vpaddq %xmm1,%xmm0,%xmm0
 10500d7:	vmovq  %xmm0,%rcx
 10500dc:	cmp    %rsi,%rdx
 10500df:	je     1050165 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1a75>
 10500e5:	test   $0xc,%dl
 10500e8:	je     105027b <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1b8b>
 10500ee:	mov    %rdx,%rdi
 10500f1:	and    $0xfffffffffffffffc,%rdi
 10500f5:	vmovq  %rcx,%xmm0
 10500fa:	lea    (%rax,%r13,1),%rcx
 10500fe:	xchg   %ax,%ax
 1050100:	vmovd  (%rcx,%rsi,1),%xmm1
 1050105:	vpcmpgtb %xmm8,%xmm1,%xmm1
 105010a:	vpmovzxbq %xmm1,%ymm1
 105010f:	vpand  %ymm1,%ymm9,%ymm1
 1050113:	vpaddq %ymm1,%ymm0,%ymm0
 1050117:	add    $0x4,%rsi
 105011b:	cmp    %rsi,%rdi
 105011e:	jne    1050100 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1a10>
 1050120:	vextracti128 $0x1,%ymm0,%xmm1
 1050126:	vpaddq %xmm1,%xmm0,%xmm0
 105012a:	vpshufd $0xee,%xmm0,%xmm1
 105012f:	vpaddq %xmm1,%xmm0,%xmm0
 1050133:	vmovq  %xmm0,%rcx
 1050138:	cmp    %rdi,%rdx
 105013b:	je     1050165 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1a75>
 105013d:	add    %rdi,%rax
 1050140:	add    %rbp,%rax
 1050143:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1050150:	xor    %edx,%edx
 1050152:	cmpb   $0xc0,(%r8,%rax,1)
 1050157:	setge  %dl
 105015a:	add    %rdx,%rcx
 105015d:	inc    %rax
 1050160:	cmp    %rax,%r14
 1050163:	jne    1050150 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1a60>
 1050165:	cmp    %rbx,%rcx
 1050168:	jne    10501e0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1af0>
 105016a:	mov    0x10(%rsp),%rax
 105016f:	cmpq   $0x0,0x1860(%rax)
 1050177:	je     105031c <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1c2c>
 105017d:	lea    0x18(%rbx),%rsi
 1050181:	mov    0x2c8(%rax),%edx
 1050187:	mov    0x18(%rsp),%rdi
 105018c:	xor    %ecx,%ecx
 105018e:	vzeroupper
 1050191:	call   10a7210 <raw_bytes>
 1050196:	test   %rax,%rax
 1050199:	je     1050290 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1ba0>
 105019f:	mov    %rax,%r15
 10501a2:	movq   $0x0,(%rax)
 10501a9:	mov    %rbx,0x8(%rax)
 10501ad:	movq   $0x0,0x10(%rax)
 10501b5:	cmp    %rbp,%r14
 10501b8:	je     10501cc <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1adc>
 10501ba:	mov    %r15,%rdi
 10501bd:	add    $0x18,%rdi
 10501c1:	mov    %r13,%rsi
 10501c4:	mov    %rbx,%rdx
 10501c7:	call   10acc80 <memcpy@plt>
 10501cc:	mov    %rbx,(%r15)
 10501cf:	movl   $0x1,0x10(%r15)
 10501d7:	jmp    1050200 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1b10>
 10501d9:	nopl   0x0(%rax)
 10501e0:	mov    0x18(%rsp),%rdi
 10501e5:	mov    %r13,%rsi
 10501e8:	mov    %rbx,%rdx
 10501eb:	vzeroupper
 10501ee:	call   1090e50 <build_wide>
 10501f3:	mov    %rax,%r15
 10501f6:	test   %rax,%rax
 10501f9:	je     1050290 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1ba0>
 10501ff:	nop
 1050200:	mov    0xb8(%rsp),%rax
 1050208:	mov    (%rax),%rcx
 105020b:	mov    0x20(%rax),%rdx
 105020f:	lea    0x1(%rcx),%rsi
 1050213:	mov    %rsi,(%rax)
 1050216:	mov    %r15,(%rdx,%rcx,8)
 105021a:	mov    0xb8(%rsp),%rbx
 1050222:	incq   0x10(%rbx)
 1050226:	mov    0xc0(%rsp),%r13
 105022e:	cmp    0x8(%r13),%r14
 1050232:	je     105031e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1c2e>
 1050238:	mov    0x118(%rsp),%rcx
 1050240:	add    %rcx,%r14
 1050243:	dec    %r12
 1050246:	mov    %r14,%rbp
 1050249:	movabs $0x101010101010101,%r15
 1050253:	vmovdqa -0x4e82b(%rip),%xmm8        # 1001a30 <__abi_tag+0x1734>
 105025b:	vmovdqu 0x1f0(%rsp),%ymm9
 1050264:	vmovdqa -0x4e83c(%rip),%xmm10        # 1001a30 <__abi_tag+0x1734>
 105026c:	cmp    $0x1,%r12
 1050270:	jne    104fed0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x17e0>
 1050276:	jmp    104ff70 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1880>
 105027b:	add    %rsi,%rax
 105027e:	jmp    1050140 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1a50>
 1050283:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1050290:	mov    0x10(%rsp),%rax
 1050295:	cmpq   $0x0,0x1860(%rax)
 105029d:	movabs $0x4000000000000002,%r13
 10502a7:	je     105031c <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1c2c>
 10502a9:	mov    0xb8(%rsp),%rbx
 10502b1:	mov    0x18(%rbx),%rax
 10502b5:	cmpw   $0x1,0x30(%rax)
 10502ba:	jne    1051bb6 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x34c6>
 10502c0:	mov    (%rbx),%rax
 10502c3:	test   %rax,%rax
 10502c6:	je     105030f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1c1f>
 10502c8:	mov    0xc0(%rsp),%r14
 10502d0:	mov    0x20(%rbx),%r15
 10502d4:	xor    %r12d,%r12d
 10502d7:	jmp    10502e8 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1bf8>
 10502d9:	nopl   0x0(%rax)
 10502e0:	inc    %r12
 10502e3:	cmp    %rax,%r12
 10502e6:	jae    105030f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1c1f>
 10502e8:	mov    (%r15,%r12,8),%rsi
 10502ec:	test   %rsi,%rsi
 10502ef:	je     10502e0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1bf0>
 10502f1:	cmp    %r14,%rsi
 10502f4:	je     10502e0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1bf0>
 10502f6:	lea    -0x2(%r13),%rcx
 10502fa:	test   %rcx,-0x10(%rsi)
 10502fe:	je     10502e0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1bf0>
 1050300:	mov    0x18(%rsp),%rdi
 1050305:	call   109f690 <myl_rc_construction_abort>
 105030a:	mov    (%rbx),%rax
 105030d:	jmp    10502e0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1bf0>
 105030f:	mov    0x18(%rsp),%rdi
 1050314:	mov    %rbx,%rsi
 1050317:	call   109f690 <myl_rc_construction_abort>
 105031c:	xor    %ebx,%ebx
 105031e:	mov    0x10(%rsp),%rbp
 1050323:	mov    0x268(%rbp),%rax
 105032a:	lea    0x140(%rsp),%rcx
 1050332:	cmp    %rcx,%rax
 1050335:	je     1050370 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1c80>
 1050337:	lea    0x160(%rsp),%rcx
 105033f:	cmp    %rcx,%rax
 1050342:	je     105038c <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1c9c>
 1050344:	lea    0x1a8(%rsp),%rcx
 105034c:	cmp    %rcx,%rax
 105034f:	je     10503a8 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1cb8>
 1050351:	test   %rbx,%rbx
 1050354:	movabs $0x4000000000000002,%r13
 105035e:	jne    10503ca <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1cda>
 1050360:	jmp    1051cb0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x35c0>
 1050365:	data16 cs nopw 0x0(%rax,%rax,1)
 1050370:	mov    0x140(%rsp),%rax
 1050378:	mov    %rax,0x268(%rbp)
 105037f:	lea    0x160(%rsp),%rcx
 1050387:	cmp    %rcx,%rax
 105038a:	jne    1050344 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1c54>
 105038c:	mov    0x160(%rsp),%rax
 1050394:	mov    %rax,0x268(%rbp)
 105039b:	lea    0x1a8(%rsp),%rcx
 10503a3:	cmp    %rcx,%rax
 10503a6:	jne    1050351 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1c61>
 10503a8:	mov    0x1a8(%rsp),%rax
 10503b0:	mov    %rax,0x268(%rbp)
 10503b7:	test   %rbx,%rbx
 10503ba:	movabs $0x4000000000000002,%r13
 10503c4:	je     1051cb0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x35c0>
 10503ca:	mov    %rbx,0x60(%rsp)
 10503cf:	mov    %rbx,0x68(%rsp)
 10503d4:	mov    -0x10(%rbx),%rax
 10503d8:	test   %rax,0x110(%rsp)
 10503e0:	je     1050401 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1d11>
 10503e2:	movabs $0x5000000000000000,%rcx
 10503ec:	test   %rcx,%rax
 10503ef:	jne    1050420 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1d30>
 10503f1:	cmpq   $0x0,0x180(%rsp)
 10503fa:	je     1050420 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1d30>
 10503fc:	mov    %rbx,0x60(%rsp)
 1050401:	movq   $0x0,0x68(%rsp)
 105040a:	mov    (%rbx),%r15
 105040d:	test   %r15,%r15
 1050410:	jns    105045d <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1d6d>
 1050412:	jmp    1051ccb <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x35db>
 1050417:	nopw   0x0(%rax,%rax,1)
 1050420:	mov    $0x100ba48,%esi
 1050425:	mov    0x18(%rsp),%rdi
 105042a:	lea    0x60(%rsp),%rdx
 105042f:	lea    0x68(%rsp),%rcx
 1050434:	mov    0x124(%rsp),%r8d
 105043c:	vzeroupper
 105043f:	call   10a7a70 <myl_rc_native_take>
 1050444:	test   %eax,%eax
 1050446:	je     1050701 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2011>
 105044c:	mov    0x60(%rsp),%rbx
 1050451:	mov    (%rbx),%r15
 1050454:	test   %r15,%r15
 1050457:	js     1051ccb <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x35db>
 105045d:	imul   $0x7,%r15,%r12
 1050461:	vmovdqa 0x50(%rsp),%xmm9
 1050467:	vmovdqu 0xf0(%rsp),%ymm10
 1050470:	jo     1051cd9 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x35e9>
 1050476:	test   %rbx,%rbx
 1050479:	je     1050485 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1d95>
 105047b:	test   %r13,-0x10(%rbx)
 105047f:	je     1050590 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1ea0>
 1050485:	mov    %rbx,0x60(%rsp)
 105048a:	test   %r15,%r15
 105048d:	je     10505af <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1ebf>
 1050493:	xor    %ebp,%ebp
 1050495:	data16 cs nopw 0x0(%rax,%rax,1)
 10504a0:	mov    0x20(%rbx),%rax
 10504a4:	mov    (%rax,%rbp,8),%r13
 10504a8:	mov    %r13,0x68(%rsp)
 10504ad:	test   %r13,%r13
 10504b0:	je     10504d3 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1de3>
 10504b2:	movabs $0x4000000000000002,%rax
 10504bc:	test   %rax,-0x10(%r13)
 10504c0:	jne    10504d3 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1de3>
 10504c2:	mov    -0x18(%r13),%rax
 10504c6:	inc    %rax
 10504c9:	je     105083b <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x214b>
 10504cf:	mov    %rax,-0x18(%r13)
 10504d3:	mov    %r13,0x60(%rsp)
 10504d8:	movq   $0x0,0x68(%rsp)
 10504e1:	mov    0x10(%rsp),%rdi
 10504e6:	mov    %r13,%rsi
 10504e9:	vzeroupper
 10504ec:	call   1074d50 <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85>
 10504f1:	mov    %r12,%r14
 10504f4:	add    %rax,%r14
 10504f7:	jo     1051bd3 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x34e3>
 10504fd:	test   %r13,%r13
 1050500:	vmovdqa 0x50(%rsp),%xmm9
 1050506:	vmovdqu 0xf0(%rsp),%ymm10
 105050f:	je     1050535 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1e45>
 1050511:	movabs $0x4000000000000002,%rax
 105051b:	test   %rax,-0x10(%r13)
 105051f:	jne    1050535 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1e45>
 1050521:	mov    -0x18(%r13),%rax
 1050525:	dec    %rax
 1050528:	jne    1050531 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1e41>
 105052a:	cmpq   $0x0,-0x20(%r13)
 105052f:	je     105054f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1e5f>
 1050531:	mov    %rax,-0x18(%r13)
 1050535:	cmp    %r15,(%rbx)
 1050538:	jne    1051be5 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x34f5>
 105053e:	inc    %rbp
 1050541:	mov    %r14,%r12
 1050544:	cmp    %rbp,%r15
 1050547:	jne    10504a0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1db0>
 105054d:	jmp    10505b2 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1ec2>
 105054f:	mov    0x18(%rsp),%r12
 1050554:	mov    %r12,%rdi
 1050557:	mov    %r13,%rsi
 105055a:	vzeroupper
 105055d:	call   109b630 <myl_rc_hold_edge_release>
 1050562:	mov    %r12,%rdi
 1050565:	call   109e650 <myl_rc_drain>
 105056a:	vmovdqu 0xf0(%rsp),%ymm10
 1050573:	vmovdqa 0x50(%rsp),%xmm9
 1050579:	cmp    %r15,(%rbx)
 105057c:	je     105053e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1e4e>
 105057e:	jmp    1051be5 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x34f5>
 1050583:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1050590:	mov    -0x18(%rbx),%rax
 1050594:	inc    %rax
 1050597:	je     1050817 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2127>
 105059d:	mov    %rax,-0x18(%rbx)
 10505a1:	mov    %rbx,0x60(%rsp)
 10505a6:	test   %r15,%r15
 10505a9:	jne    1050493 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1da3>
 10505af:	mov    %r12,%r14
 10505b2:	mov    0x230(%rsp),%eax
 10505b9:	or     0x250(%rsp),%eax
 10505c0:	mov    0x10(%rsp),%rbp
 10505c5:	movabs $0x4000000000000002,%r13
 10505cf:	movabs $0x101010101010101,%r15
 10505d9:	je     105060e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1f1e>
 10505db:	mov    0x1860(%rbp),%rax
 10505e2:	test   %rax,%rax
 10505e5:	je     10505f0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1f00>
 10505e7:	mov    0xf8(%rax),%rsi
 10505ee:	jmp    10505f2 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1f02>
 10505f0:	xor    %esi,%esi
 10505f2:	mov    0x18(%rsp),%rdi
 10505f7:	vzeroupper
 10505fa:	call   10a1c80 <myl_rc_scope_unwind>
 10505ff:	vmovdqa 0x50(%rsp),%xmm9
 1050605:	vmovdqu 0xf0(%rsp),%ymm10
 105060e:	test   %rbx,%rbx
 1050611:	je     105066b <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1f7b>
 1050613:	test   %r13,-0x10(%rbx)
 1050617:	mov    0x20(%rsp),%rdx
 105061c:	je     1050630 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1f40>
 105061e:	test   %r13,-0x10(%rbx)
 1050622:	jne    1050670 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1f80>
 1050624:	jmp    1050653 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1f63>
 1050626:	cs nopw 0x0(%rax,%rax,1)
 1050630:	mov    -0x18(%rbx),%rax
 1050634:	dec    %rax
 1050637:	jne    1050644 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1f54>
 1050639:	cmpq   $0x0,-0x20(%rbx)
 105063e:	je     1050796 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x20a6>
 1050644:	mov    %rax,-0x18(%rbx)
 1050648:	mov    0x20(%rsp),%rdx
 105064d:	test   %r13,-0x10(%rbx)
 1050651:	jne    1050670 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1f80>
 1050653:	mov    -0x20(%rbx),%rax
 1050657:	dec    %rax
 105065a:	jne    1050667 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1f77>
 105065c:	cmpq   $0x0,-0x18(%rbx)
 1050661:	je     10507de <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x20ee>
 1050667:	mov    %rax,-0x20(%rbx)
 105066b:	mov    0x20(%rsp),%rdx
 1050670:	mov    0x190(%rsp),%rsi
 1050678:	test   %rsi,%rsi
 105067b:	je     10506a0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1fb0>
 105067d:	test   %r13,-0x10(%rsi)
 1050681:	jne    10506a0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1fb0>
 1050683:	mov    -0x20(%rsi),%rax
 1050687:	dec    %rax
 105068a:	jne    1050697 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1fa7>
 105068c:	cmpq   $0x0,-0x18(%rsi)
 1050691:	je     105076a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x207a>
 1050697:	mov    %rax,-0x20(%rsi)
 105069b:	mov    0x20(%rsp),%rdx
 10506a0:	mov    %rdx,%rcx
 10506a3:	add    %r14,%rcx
 10506a6:	jo     1051cbb <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x35cb>
 10506ac:	mov    %rcx,%rax
 10506af:	movabs $0x89705f3112a28fe5,%rdx
 10506b9:	imul   %rdx
 10506bc:	add    %rcx,%rdx
 10506bf:	mov    %rdx,%rax
 10506c2:	shr    $0x3f,%rax
 10506c6:	sar    $0x1d,%rdx
 10506ca:	add    %rax,%rdx
 10506cd:	imul   $0x3b9aca07,%rdx,%rax
 10506d4:	sub    %rax,%rcx
 10506d7:	mov    %rcx,%rax
 10506da:	sar    $0x3f,%rax
 10506de:	and    $0x3b9aca07,%eax
 10506e3:	add    %rcx,%rax
 10506e6:	mov    0x198(%rsp),%r12
 10506ee:	inc    %r12
 10506f1:	cmp    0x28(%rsp),%r12
 10506f6:	jne    104f870 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1180>
 10506fc:	jmp    104f01c <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x92c>
 1050701:	mov    0x1860(%rbp),%rax
 1050708:	test   %rax,%rax
 105070b:	vmovdqa 0x50(%rsp),%xmm9
 1050711:	vmovdqu 0xf0(%rsp),%ymm10
 105071a:	je     1051bbe <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x34ce>
 1050720:	mov    0x124(%rax),%r14d
 1050727:	movl   $0x0,0x124(%rax)
 1050731:	test   %r14,%r14
 1050734:	mov    0x20(%rsp),%rdx
 1050739:	movabs $0x101010101010101,%r15
 1050743:	je     1050670 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1f80>
 1050749:	cmp    $0x1,%r14d
 105074d:	jne    1050880 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2190>
 1050753:	mov    $0x1007df2,%esi
 1050758:	cmpl   $0x0,0x2c4(%rbp)
 105075f:	je     105088a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x219a>
 1050765:	jmp    1050892 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x21a2>
 105076a:	mov    0x18(%rsp),%rbx
 105076f:	mov    %rbx,%rdi
 1050772:	vzeroupper
 1050775:	call   109b4d0 <myl_rc_edge_release>
 105077a:	mov    %rbx,%rdi
 105077d:	call   109e650 <myl_rc_drain>
 1050782:	vmovdqu 0xf0(%rsp),%ymm10
 105078b:	vmovdqa 0x50(%rsp),%xmm9
 1050791:	jmp    105069b <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1fab>
 1050796:	mov    0x18(%rsp),%r15
 105079b:	mov    %r15,%rdi
 105079e:	mov    %rbx,%rsi
 10507a1:	vzeroupper
 10507a4:	call   109b630 <myl_rc_hold_edge_release>
 10507a9:	mov    %r15,%rdi
 10507ac:	movabs $0x101010101010101,%r15
 10507b6:	call   109e650 <myl_rc_drain>
 10507bb:	vmovdqu 0xf0(%rsp),%ymm10
 10507c4:	vmovdqa 0x50(%rsp),%xmm9
 10507ca:	mov    0x20(%rsp),%rdx
 10507cf:	test   %r13,-0x10(%rbx)
 10507d3:	jne    1050670 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1f80>
 10507d9:	jmp    1050653 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1f63>
 10507de:	mov    0x18(%rsp),%r15
 10507e3:	mov    %r15,%rdi
 10507e6:	mov    %rbx,%rsi
 10507e9:	vzeroupper
 10507ec:	call   109b4d0 <myl_rc_edge_release>
 10507f1:	mov    %r15,%rdi
 10507f4:	movabs $0x101010101010101,%r15
 10507fe:	call   109e650 <myl_rc_drain>
 1050803:	vmovdqu 0xf0(%rsp),%ymm10
 105080c:	vmovdqa 0x50(%rsp),%xmm9
 1050812:	jmp    105066b <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1f7b>
 1050817:	mov    $0x1007dbf,%esi
 105081c:	mov    %rbp,%rdi
 105081f:	vzeroupper
 1050822:	call   108beae <fail>
 1050827:	vmovdqu 0xf0(%rsp),%ymm10
 1050830:	vmovdqa 0x50(%rsp),%xmm9
 1050836:	xor    %r14d,%r14d
 1050839:	jmp    105086c <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x217c>
 105083b:	mov    $0x1007dbf,%esi
 1050840:	mov    0x10(%rsp),%rbp
 1050845:	mov    %rbp,%rdi
 1050848:	vzeroupper
 105084b:	call   108beae <fail>
 1050850:	vmovdqu 0xf0(%rsp),%ymm10
 1050859:	vmovdqa 0x50(%rsp),%xmm9
 105085f:	xor    %r14d,%r14d
 1050862:	movabs $0x4000000000000002,%r13
 105086c:	mov    0x20(%rsp),%rdx
 1050871:	movabs $0x101010101010101,%r15
 105087b:	jmp    1050670 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1f80>
 1050880:	cmp    $0x4,%r14d
 1050884:	jae    1051bb6 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x34c6>
 105088a:	mov    0x10315e0(,%r14,8),%rsi
 1050892:	mov    %rbp,%rdi
 1050895:	vzeroupper
 1050898:	call   108beae <fail>
 105089d:	xor    %r14d,%r14d
 10508a0:	mov    0x20(%rsp),%rdx
 10508a5:	vmovdqa 0x50(%rsp),%xmm9
 10508ab:	vmovdqu 0xf0(%rsp),%ymm10
 10508b4:	jmp    1050670 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x1f80>
 10508b9:	mov    $0x1,%bl
 10508bb:	test   %rsi,%rsi
 10508be:	je     1050a37 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2347>
 10508c4:	mov    0x8(%rsi),%rdx
 10508c8:	cmp    0x69c09(%rip),%rdx        # 10ba4d8 <myl_lit_4a11bea7b5a6ce8d077c05a11569e05d5d64f10b6601437976e3917dc8273132_instance+0x18>
 10508cf:	jne    1050a37 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2347>
 10508d5:	test   %rdx,%rdx
 10508d8:	je     104f79f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x10af>
 10508de:	testb  $0x4,0x10(%rsi)
 10508e2:	jne    105097f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x228f>
 10508e8:	lea    0x18(%rsi),%rdi
 10508ec:	jmp    105098e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x229e>
 10508f1:	mov    0x1860(%rbp),%rax
 10508f8:	test   %rax,%rax
 10508fb:	je     1051bbe <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x34ce>
 1050901:	mov    0x124(%rax),%esi
 1050907:	movl   $0x0,0x124(%rax)
 1050911:	mov    %rbp,%rdi
 1050914:	vzeroupper
 1050917:	call   108b650 <myl_qbe_rc_status>
 105091c:	xor    %eax,%eax
 105091e:	jmp    104f01c <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x92c>
 1050923:	mov    0x1860(%rbp),%rax
 105092a:	test   %rax,%rax
 105092d:	je     1051bbe <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x34ce>
 1050933:	mov    0x124(%rax),%esi
 1050939:	movl   $0x0,0x124(%rax)
 1050943:	mov    %rbp,%rdi
 1050946:	vzeroupper
 1050949:	call   108b650 <myl_qbe_rc_status>
 105094e:	xor    %eax,%eax
 1050950:	jmp    104f01c <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x92c>
 1050955:	lea    0xc8(%rsp),%rax
 105095d:	lea    0x258(%rbp),%rdi
 1050964:	mov    %rsi,%r14
 1050967:	mov    %rax,%rsi
 105096a:	call   1087960 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop>
 105096f:	mov    %r14,%rsi
 1050972:	test   %bl,%bl
 1050974:	jne    104f77d <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x108d>
 105097a:	jmp    104f7cb <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x10db>
 105097f:	mov    0x18(%rsi),%rax
 1050983:	mov    0x14(%rsi),%ecx
 1050986:	lea    (%rax,%rcx,1),%rdi
 105098a:	add    $0x18,%rdi
 105098e:	testb  $0x4,0x69b4b(%rip)        # 10ba4e0 <myl_lit_4a11bea7b5a6ce8d077c05a11569e05d5d64f10b6601437976e3917dc8273132_instance+0x20>
 1050995:	mov    0x69b4c(%rip),%rax        # 10ba4e8 <myl_lit_4a11bea7b5a6ce8d077c05a11569e05d5d64f10b6601437976e3917dc8273132_instance+0x28>
 105099c:	mov    0x69b42(%rip),%ecx        # 10ba4e4 <myl_lit_4a11bea7b5a6ce8d077c05a11569e05d5d64f10b6601437976e3917dc8273132_instance+0x24>
 10509a2:	lea    0x18(%rax,%rcx,1),%rcx
 10509a7:	mov    $0x10ba4e8,%eax
 10509ac:	cmovne %rcx,%rax
 10509b0:	cmp    $0x10,%rdx
 10509b4:	ja     10509d1 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x22e1>
 10509b6:	cmp    $0x8,%rdx
 10509ba:	jb     10509ec <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x22fc>
 10509bc:	mov    (%rdi),%rcx
 10509bf:	mov    -0x8(%rdi,%rdx,1),%rdi
 10509c4:	xor    (%rax),%rcx
 10509c7:	xor    -0x8(%rax,%rdx,1),%rdi
 10509cc:	or     %rcx,%rdi
 10509cf:	jmp    1050a31 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2341>
 10509d1:	mov    %rsi,%r14
 10509d4:	mov    %rax,%rsi
 10509d7:	cmp    $0x100,%rdx
 10509de:	ja     1050a02 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2312>
 10509e0:	call   10accc0 <bcmp@plt>
 10509e5:	test   %eax,%eax
 10509e7:	setne  %bl
 10509ea:	jmp    1050a0c <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x231c>
 10509ec:	cmp    $0x4,%rdx
 10509f0:	jb     1050a11 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2321>
 10509f2:	mov    (%rdi),%ecx
 10509f4:	mov    -0x4(%rdi,%rdx,1),%edi
 10509f8:	xor    (%rax),%ecx
 10509fa:	xor    -0x4(%rax,%rdx,1),%edi
 10509fe:	or     %ecx,%edi
 1050a00:	jmp    1050a31 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2341>
 1050a02:	call   10934f0 <equal_large_octets>
 1050a07:	test   %eax,%eax
 1050a09:	sete   %bl
 1050a0c:	mov    %r14,%rsi
 1050a0f:	jmp    1050a37 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2347>
 1050a11:	cmp    $0x1,%rdx
 1050a15:	jne    1050a1e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x232e>
 1050a17:	movzbl (%rdi),%ecx
 1050a1a:	cmp    (%rax),%cl
 1050a1c:	jmp    1050a31 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2341>
 1050a1e:	movzwl (%rdi),%ecx
 1050a21:	movzwl -0x2(%rdi,%rdx,1),%edi
 1050a26:	xor    (%rax),%cx
 1050a29:	xor    -0x2(%rax,%rdx,1),%di
 1050a2e:	or     %cx,%di
 1050a31:	sete   %bl
 1050a34:	xor    $0x1,%bl
 1050a37:	test   %r13,0x69a82(%rip)        # 10ba4c0 <myl_lit_4a11bea7b5a6ce8d077c05a11569e05d5d64f10b6601437976e3917dc8273132_instance>
 1050a3e:	jne    1050a5d <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x236d>
 1050a40:	mov    0x69a69(%rip),%rax        # 10ba4b0 <myl_lit_49ddcee716aac9f3632795416226e674fb40f0332dabf1de33fc7f8b34af0696_instance+0x38>
 1050a47:	dec    %rax
 1050a4a:	jne    1050a56 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2366>
 1050a4c:	cmpq   $0x0,0x69a64(%rip)        # 10ba4b8 <myl_lit_49ddcee716aac9f3632795416226e674fb40f0332dabf1de33fc7f8b34af0696_instance+0x40>
 1050a54:	je     1050ac7 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x23d7>
 1050a56:	mov    %rax,0x69a53(%rip)        # 10ba4b0 <myl_lit_49ddcee716aac9f3632795416226e674fb40f0332dabf1de33fc7f8b34af0696_instance+0x38>
 1050a5d:	test   %bl,%bl
 1050a5f:	je     1050aec <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x23fc>
 1050a65:	movq   $0x10ba370,0x38(%rsp)
 1050a6e:	movq   $0x10ba370,0x70(%rsp)
 1050a77:	movq   $0x10ba370,0xc8(%rsp)
 1050a83:	cmp    $0x10ba370,%rsi
 1050a8a:	jne    1050a93 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x23a3>
 1050a8c:	xor    %ebx,%ebx
 1050a8e:	jmp    1051005 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2915>
 1050a93:	mov    $0x1,%bl
 1050a95:	test   %rsi,%rsi
 1050a98:	je     1051005 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2915>
 1050a9e:	mov    0x8(%rsi),%rdx
 1050aa2:	cmp    0x698cf(%rip),%rdx        # 10ba378 <myl_lit_3b82d7fd89ea641dc3c74175c3081dd70840c2be20de843e08a42204e3d9c4cc_instance+0x18>
 1050aa9:	jne    1051005 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2915>
 1050aaf:	test   %rdx,%rdx
 1050ab2:	je     1050a8c <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x239c>
 1050ab4:	testb  $0x4,0x10(%rsi)
 1050ab8:	jne    1050f4d <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x285d>
 1050abe:	lea    0x18(%rsi),%rdi
 1050ac2:	jmp    1050f5c <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x286c>
 1050ac7:	lea    0xc8(%rsp),%rax
 1050acf:	lea    0x258(%rbp),%rdi
 1050ad6:	mov    %rsi,%r14
 1050ad9:	mov    %rax,%rsi
 1050adc:	call   1087960 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop>
 1050ae1:	mov    %r14,%rsi
 1050ae4:	test   %bl,%bl
 1050ae6:	jne    1050a65 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2375>
 1050aec:	lea    0x48(%rsp),%rcx
 1050af1:	lea    0x70(%rsp),%rdx
 1050af6:	mov    %rdx,%rax
 1050af9:	sub    %rcx,%rax
 1050afc:	sub    %rdx,%rcx
 1050aff:	cmovb  %rax,%rcx
 1050b03:	mov    %rcx,0xf0(%rsp)
 1050b0b:	movabs $0x5000000000000000,%rax
 1050b15:	xor    %r15d,%r15d
 1050b18:	inc    %rax
 1050b1b:	mov    %rax,0x50(%rsp)
 1050b20:	xor    %eax,%eax
 1050b22:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1050b30:	mov    %rax,%r14
 1050b33:	mov    0x8(%rsp),%rax
 1050b38:	add    %r15,%rax
 1050b3b:	jo     1051d11 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3621>
 1050b41:	test   $0x1,%al
 1050b43:	jne    1050be0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x24f0>
 1050b49:	movq   $0x10bb320,0x70(%rsp)
 1050b52:	movq   $0x10bb320,0x1c8(%rsp)
 1050b5e:	movq   $0x10bb320,0x48(%rsp)
 1050b67:	mov    0x6a7a2(%rip),%rax        # 10bb310 <myl_lit_f3eaad558815542caf7da2bdfda9d4cabeaf9c2200b79ab8ff85b21b8470fac6_instance>
 1050b6e:	test   %rax,0x50(%rsp)
 1050b73:	movabs $0x4000000000000002,%rbx
 1050b7d:	je     1050c9a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x25aa>
 1050b83:	cmpq   $0x0,0xf0(%rsp)
 1050b8c:	sete   %cl
 1050b8f:	movabs $0x5000000000000000,%rdx
 1050b99:	test   %rdx,%rax
 1050b9c:	setne  %al
 1050b9f:	or     %cl,%al
 1050ba1:	je     1050cb6 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x25c6>
 1050ba7:	mov    $0x1030c78,%esi
 1050bac:	lea    0x258(%rbp),%rdi
 1050bb3:	lea    0x70(%rsp),%rdx
 1050bb8:	lea    0x48(%rsp),%rcx
 1050bbd:	mov    0x44(%rsp),%r8d
 1050bc2:	call   10a7a70 <myl_rc_native_take>
 1050bc7:	test   %eax,%eax
 1050bc9:	jne    1050c66 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2576>
 1050bcf:	jmp    1050edb <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x27eb>
 1050bd4:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 1050be0:	movq   $0x10ba690,0x70(%rsp)
 1050be9:	movq   $0x10ba690,0x1c8(%rsp)
 1050bf5:	movq   $0x10ba690,0x48(%rsp)
 1050bfe:	mov    0x69a7b(%rip),%rax        # 10ba680 <myl_lit_54807ae7ae90f7f8ab8705f04b17dcd2d77e7355f27b7f7252156b0c234f7d3f_instance>
 1050c05:	test   %rax,0x50(%rsp)
 1050c0a:	movabs $0x4000000000000002,%rbx
 1050c14:	je     1050ce4 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x25f4>
 1050c1a:	cmpq   $0x0,0xf0(%rsp)
 1050c23:	sete   %cl
 1050c26:	movabs $0x5000000000000000,%rdx
 1050c30:	test   %rdx,%rax
 1050c33:	setne  %al
 1050c36:	or     %cl,%al
 1050c38:	je     1050cdb <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x25eb>
 1050c3e:	mov    $0x1030c78,%esi
 1050c43:	lea    0x258(%rbp),%rdi
 1050c4a:	lea    0x70(%rsp),%rdx
 1050c4f:	lea    0x48(%rsp),%rcx
 1050c54:	mov    0x44(%rsp),%r8d
 1050c59:	call   10a7a70 <myl_rc_native_take>
 1050c5e:	test   %eax,%eax
 1050c60:	je     1050f0a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x281a>
 1050c66:	mov    0x70(%rsp),%r12
 1050c6b:	mov    %r12,0xa8(%rsp)
 1050c73:	mov    %r12,0x48(%rsp)
 1050c78:	test   %r12,%r12
 1050c7b:	je     1050e6a <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x277a>
 1050c81:	test   %rbx,-0x10(%r12)
 1050c86:	je     1050cfe <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x260e>
 1050c88:	mov    %r12,0x70(%rsp)
 1050c8d:	mov    %r12,0xa0(%rsp)
 1050c95:	jmp    1050d39 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2649>
 1050c9a:	mov    $0x10bb320,%r12d
 1050ca0:	mov    %r12,0xa8(%rsp)
 1050ca8:	mov    %r12,0x48(%rsp)
 1050cad:	test   %rbx,-0x10(%r12)
 1050cb2:	jne    1050c88 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2598>
 1050cb4:	jmp    1050cfe <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x260e>
 1050cb6:	movq   $0x10bb320,0x70(%rsp)
 1050cbf:	mov    $0x10bb320,%r12d
 1050cc5:	mov    %r12,0xa8(%rsp)
 1050ccd:	mov    %r12,0x48(%rsp)
 1050cd2:	test   %rbx,-0x10(%r12)
 1050cd7:	jne    1050c88 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2598>
 1050cd9:	jmp    1050cfe <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x260e>
 1050cdb:	movq   $0x10ba690,0x70(%rsp)
 1050ce4:	mov    $0x10ba690,%r12d
 1050cea:	mov    %r12,0xa8(%rsp)
 1050cf2:	mov    %r12,0x48(%rsp)
 1050cf7:	test   %rbx,-0x10(%r12)
 1050cfc:	jne    1050c88 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2598>
 1050cfe:	mov    -0x18(%r12),%rax
 1050d03:	inc    %rax
 1050d06:	je     1050f39 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2849>
 1050d0c:	mov    %rax,-0x18(%r12)
 1050d11:	mov    %r12,0x70(%rsp)
 1050d16:	mov    %r12,0xa0(%rsp)
 1050d1e:	mov    -0x20(%r12),%rax
 1050d23:	dec    %rax
 1050d26:	jne    1050d34 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2644>
 1050d28:	cmpq   $0x0,-0x18(%r12)
 1050d2e:	je     1050ea9 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x27b9>
 1050d34:	mov    %rax,-0x20(%r12)
 1050d39:	movq   $0x0,0xa8(%rsp)
 1050d45:	mov    0x30(%rsp),%rax
 1050d4a:	mov    0x20(%rax),%rdx
 1050d4e:	lea    0x258(%rbp),%rdi
 1050d55:	mov    %r12,%rsi
 1050d58:	call   1093840 <myl_native_text_join>
 1050d5d:	test   %rax,%rax
 1050d60:	je     1051cf9 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3609>
 1050d66:	mov    %rax,%rbx
 1050d69:	mov    %rax,0x48(%rsp)
 1050d6e:	mov    %rax,0x70(%rsp)
 1050d73:	mov    %rax,0x1c8(%rsp)
 1050d7b:	mov    %rbp,%rdi
 1050d7e:	mov    %rax,%rsi
 1050d81:	call   1074d50 <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85>
 1050d86:	mov    %rax,%r13
 1050d89:	movabs $0x4000000000000002,%rax
 1050d93:	test   %rax,-0x10(%rbx)
 1050d97:	je     1050db0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x26c0>
 1050d99:	movq   $0x0,0x1c8(%rsp)
 1050da5:	test   %r12,%r12
 1050da8:	jne    1050dd9 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x26e9>
 1050daa:	jmp    1050e11 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2721>
 1050dac:	nopl   0x0(%rax)
 1050db0:	mov    -0x20(%rbx),%rax
 1050db4:	dec    %rax
 1050db7:	jne    1050dc4 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x26d4>
 1050db9:	cmpq   $0x0,-0x18(%rbx)
 1050dbe:	je     1050e87 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2797>
 1050dc4:	mov    %rax,-0x20(%rbx)
 1050dc8:	movq   $0x0,0x1c8(%rsp)
 1050dd4:	test   %r12,%r12
 1050dd7:	je     1050e11 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2721>
 1050dd9:	movabs $0x4000000000000002,%rax
 1050de3:	test   %rax,-0x10(%r12)
 1050de8:	jne    1050e05 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2715>
 1050dea:	mov    -0x18(%r12),%rax
 1050def:	dec    %rax
 1050df2:	jne    1050e00 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2710>
 1050df4:	cmpq   $0x0,-0x20(%r12)
 1050dfa:	je     1050ec2 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x27d2>
 1050e00:	mov    %rax,-0x18(%r12)
 1050e05:	movq   $0x0,0xa0(%rsp)
 1050e11:	mov    %r14,%rcx
 1050e14:	add    %r13,%rcx
 1050e17:	jo     1051d01 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3611>
 1050e1d:	mov    %rcx,%rax
 1050e20:	movabs $0x89705f3112a28fe5,%rdx
 1050e2a:	imul   %rdx
 1050e2d:	add    %rcx,%rdx
 1050e30:	mov    %rdx,%rax
 1050e33:	shr    $0x3f,%rax
 1050e37:	sar    $0x1d,%rdx
 1050e3b:	add    %rax,%rdx
 1050e3e:	imul   $0x3b9aca07,%rdx,%rax
 1050e45:	sub    %rax,%rcx
 1050e48:	mov    %rcx,%rax
 1050e4b:	sar    $0x3f,%rax
 1050e4f:	and    $0x3b9aca07,%eax
 1050e54:	add    %rcx,%rax
 1050e57:	inc    %r15
 1050e5a:	cmp    %r15,0x28(%rsp)
 1050e5f:	jne    1050b30 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2440>
 1050e65:	jmp    104f01c <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x92c>
 1050e6a:	movq   $0x0,0x70(%rsp)
 1050e73:	movq   $0x0,0xa0(%rsp)
 1050e7f:	xor    %r12d,%r12d
 1050e82:	jmp    1050d45 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2655>
 1050e87:	lea    0x258(%rbp),%rdi
 1050e8e:	lea    0x1c8(%rsp),%rsi
 1050e96:	call   1087960 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop>
 1050e9b:	test   %r12,%r12
 1050e9e:	jne    1050dd9 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x26e9>
 1050ea4:	jmp    1050e11 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2721>
 1050ea9:	lea    0x258(%rbp),%rdi
 1050eb0:	lea    0xa8(%rsp),%rsi
 1050eb8:	call   1087960 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop>
 1050ebd:	jmp    1050d45 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2655>
 1050ec2:	lea    0x258(%rbp),%rdi
 1050ec9:	lea    0xa0(%rsp),%rsi
 1050ed1:	call   10878f0 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan>
 1050ed6:	jmp    1050e11 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2721>
 1050edb:	mov    0x1860(%rbp),%rax
 1050ee2:	test   %rax,%rax
 1050ee5:	je     1051bbe <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x34ce>
 1050eeb:	mov    0x124(%rax),%esi
 1050ef1:	movl   $0x0,0x124(%rax)
 1050efb:	mov    %rbp,%rdi
 1050efe:	call   108b650 <myl_qbe_rc_status>
 1050f03:	xor    %eax,%eax
 1050f05:	jmp    104f01c <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x92c>
 1050f0a:	mov    0x1860(%rbp),%rax
 1050f11:	test   %rax,%rax
 1050f14:	je     1051bbe <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x34ce>
 1050f1a:	mov    0x124(%rax),%esi
 1050f20:	movl   $0x0,0x124(%rax)
 1050f2a:	mov    %rbp,%rdi
 1050f2d:	call   108b650 <myl_qbe_rc_status>
 1050f32:	xor    %eax,%eax
 1050f34:	jmp    104f01c <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x92c>
 1050f39:	mov    $0x1007dbf,%esi
 1050f3e:	mov    %rbp,%rdi
 1050f41:	call   108beae <fail>
 1050f46:	xor    %eax,%eax
 1050f48:	jmp    104f01c <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x92c>
 1050f4d:	mov    0x18(%rsi),%rax
 1050f51:	mov    0x14(%rsi),%ecx
 1050f54:	lea    (%rax,%rcx,1),%rdi
 1050f58:	add    $0x18,%rdi
 1050f5c:	testb  $0x4,0x6941d(%rip)        # 10ba380 <myl_lit_3b82d7fd89ea641dc3c74175c3081dd70840c2be20de843e08a42204e3d9c4cc_instance+0x20>
 1050f63:	mov    0x6941e(%rip),%rax        # 10ba388 <myl_lit_3b82d7fd89ea641dc3c74175c3081dd70840c2be20de843e08a42204e3d9c4cc_instance+0x28>
 1050f6a:	mov    0x69414(%rip),%ecx        # 10ba384 <myl_lit_3b82d7fd89ea641dc3c74175c3081dd70840c2be20de843e08a42204e3d9c4cc_instance+0x24>
 1050f70:	lea    0x18(%rax,%rcx,1),%rcx
 1050f75:	mov    $0x10ba388,%eax
 1050f7a:	cmovne %rcx,%rax
 1050f7e:	cmp    $0x10,%rdx
 1050f82:	ja     1050f9f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x28af>
 1050f84:	cmp    $0x8,%rdx
 1050f88:	jb     1050fba <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x28ca>
 1050f8a:	mov    (%rdi),%rcx
 1050f8d:	mov    -0x8(%rdi,%rdx,1),%rdi
 1050f92:	xor    (%rax),%rcx
 1050f95:	xor    -0x8(%rax,%rdx,1),%rdi
 1050f9a:	or     %rcx,%rdi
 1050f9d:	jmp    1050fff <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x290f>
 1050f9f:	mov    %rsi,%r14
 1050fa2:	mov    %rax,%rsi
 1050fa5:	cmp    $0x100,%rdx
 1050fac:	ja     1050fd0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x28e0>
 1050fae:	call   10accc0 <bcmp@plt>
 1050fb3:	test   %eax,%eax
 1050fb5:	setne  %bl
 1050fb8:	jmp    1050fda <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x28ea>
 1050fba:	cmp    $0x4,%rdx
 1050fbe:	jb     1050fdf <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x28ef>
 1050fc0:	mov    (%rdi),%ecx
 1050fc2:	mov    -0x4(%rdi,%rdx,1),%edi
 1050fc6:	xor    (%rax),%ecx
 1050fc8:	xor    -0x4(%rax,%rdx,1),%edi
 1050fcc:	or     %ecx,%edi
 1050fce:	jmp    1050fff <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x290f>
 1050fd0:	call   10934f0 <equal_large_octets>
 1050fd5:	test   %eax,%eax
 1050fd7:	sete   %bl
 1050fda:	mov    %r14,%rsi
 1050fdd:	jmp    1051005 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2915>
 1050fdf:	cmp    $0x1,%rdx
 1050fe3:	jne    1050fec <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x28fc>
 1050fe5:	movzbl (%rdi),%ecx
 1050fe8:	cmp    (%rax),%cl
 1050fea:	jmp    1050fff <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x290f>
 1050fec:	movzwl (%rdi),%ecx
 1050fef:	movzwl -0x2(%rdi,%rdx,1),%edi
 1050ff4:	xor    (%rax),%cx
 1050ff7:	xor    -0x2(%rax,%rdx,1),%di
 1050ffc:	or     %cx,%di
 1050fff:	sete   %bl
 1051002:	xor    $0x1,%bl
 1051005:	test   %r13,0x69354(%rip)        # 10ba360 <myl_lit_3b82d7fd89ea641dc3c74175c3081dd70840c2be20de843e08a42204e3d9c4cc_instance>
 105100c:	jne    105102b <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x293b>
 105100e:	mov    0x6933b(%rip),%rax        # 10ba350 <myl_lit_3b2e9d8953e261b03d089bbc831cd3b7c9a128df1fa9770dfd3ff0548594ae5c_instance+0x20>
 1051015:	dec    %rax
 1051018:	jne    1051024 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2934>
 105101a:	cmpq   $0x0,0x69336(%rip)        # 10ba358 <myl_lit_3b2e9d8953e261b03d089bbc831cd3b7c9a128df1fa9770dfd3ff0548594ae5c_instance+0x28>
 1051022:	je     1051094 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x29a4>
 1051024:	mov    %rax,0x69325(%rip)        # 10ba350 <myl_lit_3b2e9d8953e261b03d089bbc831cd3b7c9a128df1fa9770dfd3ff0548594ae5c_instance+0x20>
 105102b:	movq   $0x0,0xc8(%rsp)
 1051037:	test   %bl,%bl
 1051039:	je     10510b5 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x29c5>
 105103b:	movq   $0x10ba878,0x70(%rsp)
 1051044:	movq   $0x10ba878,0xc8(%rsp)
 1051050:	cmp    $0x10ba878,%rsi
 1051057:	jne    1051060 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2970>
 1051059:	xor    %ebx,%ebx
 105105b:	jmp    10513ac <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2cbc>
 1051060:	mov    $0x1,%bl
 1051062:	test   %rsi,%rsi
 1051065:	je     10513ac <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2cbc>
 105106b:	mov    0x8(%rsi),%rdx
 105106f:	cmp    0x6980a(%rip),%rdx        # 10ba880 <myl_lit_626da83bb2caf4205ae415768034d7bb2b32d76c3b0b29af95ab0567cf1d3ca9_instance+0x18>
 1051076:	jne    10513ac <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2cbc>
 105107c:	test   %rdx,%rdx
 105107f:	je     1051059 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2969>
 1051081:	testb  $0x4,0x10(%rsi)
 1051085:	jne    10512f4 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2c04>
 105108b:	lea    0x18(%rsi),%rdi
 105108f:	jmp    1051303 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2c13>
 1051094:	lea    0xc8(%rsp),%rax
 105109c:	lea    0x258(%rbp),%rdi
 10510a3:	mov    %rsi,%r14
 10510a6:	mov    %rax,%rsi
 10510a9:	call   1087960 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop>
 10510ae:	mov    %r14,%rsi
 10510b1:	test   %bl,%bl
 10510b3:	jne    105103b <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x294b>
 10510b5:	xor    %ebx,%ebx
 10510b7:	lea    0x1a8(%rsp),%r14
 10510bf:	movabs $0x89705f3112a28fe5,%r13
 10510c9:	xor    %eax,%eax
 10510cb:	nopl   0x0(%rax,%rax,1)
 10510d0:	mov    %rax,%r15
 10510d3:	mov    0x8(%rsp),%rax
 10510d8:	add    %rbx,%rax
 10510db:	jo     1051d23 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3633>
 10510e1:	mov    0x30(%rsp),%rcx
 10510e6:	mov    0x8(%rcx),%rdi
 10510ea:	mov    (%rdi),%rcx
 10510ed:	test   %rcx,%rcx
 10510f0:	js     1051d35 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3645>
 10510f6:	je     1051d40 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3650>
 10510fc:	mov    %rax,%rdx
 10510ff:	or     %rcx,%rdx
 1051102:	shr    $0x20,%rdx
 1051106:	je     105110f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2a1f>
 1051108:	cqto
 105110a:	idiv   %rcx
 105110d:	jmp    1051113 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2a23>
 105110f:	xor    %edx,%edx
 1051111:	div    %ecx
 1051113:	mov    %rdx,%rax
 1051116:	sar    $0x3f,%rax
 105111a:	and    %rcx,%rax
 105111d:	add    %rdx,%rax
 1051120:	mov    %rax,%rsi
 1051123:	sar    $0x3f,%rsi
 1051127:	and    %rcx,%rsi
 105112a:	add    %rax,%rsi
 105112d:	cmp    %rcx,%rsi
 1051130:	jae    1051d4b <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x365b>
 1051136:	mov    0x20(%rdi),%rax
 105113a:	mov    (%rax,%rsi,8),%rax
 105113e:	test   %rax,%rax
 1051141:	je     105116e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2a7e>
 1051143:	mov    %rax,%rdi
 1051146:	movabs $0x4000000000000002,%rcx
 1051150:	test   %rcx,-0x10(%rax)
 1051154:	je     105129f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2baf>
 105115a:	mov    %rax,0x140(%rsp)
 1051162:	testb  $0x4,0x10(%rdi)
 1051166:	jne    105117e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2a8e>
 1051168:	add    $0x18,%rdi
 105116c:	jmp    105118d <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2a9d>
 105116e:	xor    %edi,%edi
 1051170:	mov    %rax,0x140(%rsp)
 1051178:	testb  $0x4,0x10(%rdi)
 105117c:	je     1051168 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2a78>
 105117e:	mov    0x18(%rdi),%rcx
 1051182:	mov    0x14(%rdi),%edx
 1051185:	lea    (%rcx,%rdx,1),%rdi
 1051189:	add    $0x18,%rdi
 105118d:	mov    0x8(%rax),%rsi
 1051191:	xor    %edx,%edx
 1051193:	mov    %r14,%rcx
 1051196:	call   104a1e0 <myl_native_bytes_number_parse>
 105119b:	test   %eax,%eax
 105119d:	je     1051201 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2b11>
 105119f:	mov    0x1a8(%rsp),%r12
 10511a7:	movl   $0x1,0x160(%rsp)
 10511b2:	mov    %r12,0x168(%rsp)
 10511ba:	mov    0x140(%rsp),%rax
 10511c2:	test   %rax,%rax
 10511c5:	je     1051250 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2b60>
 10511cb:	movabs $0x4000000000000002,%rcx
 10511d5:	test   %rcx,-0x10(%rax)
 10511d9:	jne    1051250 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2b60>
 10511db:	mov    -0x18(%rax),%rcx
 10511df:	dec    %rcx
 10511e2:	jne    1051243 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2b53>
 10511e4:	cmpq   $0x0,-0x20(%rax)
 10511e9:	jne    1051243 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2b53>
 10511eb:	lea    0x258(%rbp),%rdi
 10511f2:	lea    0x140(%rsp),%rsi
 10511fa:	call   10878f0 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan>
 10511ff:	jmp    1051250 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2b60>
 1051201:	movl   $0x0,0x160(%rsp)
 105120c:	mov    0x140(%rsp),%rax
 1051214:	mov    $0x61,%r12d
 105121a:	test   %rax,%rax
 105121d:	je     1051250 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2b60>
 105121f:	movabs $0x4000000000000002,%rcx
 1051229:	test   %rcx,-0x10(%rax)
 105122d:	jne    1051250 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2b60>
 105122f:	mov    -0x18(%rax),%rcx
 1051233:	dec    %rcx
 1051236:	jne    1051243 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2b53>
 1051238:	cmpq   $0x0,-0x20(%rax)
 105123d:	je     10512db <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2beb>
 1051243:	mov    %rcx,-0x18(%rax)
 1051247:	nopw   0x0(%rax,%rax,1)
 1051250:	mov    %r15,%rcx
 1051253:	add    %r12,%rcx
 1051256:	jo     1051d56 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3666>
 105125c:	mov    %rcx,%rax
 105125f:	imul   %r13
 1051262:	add    %rcx,%rdx
 1051265:	mov    %rdx,%rax
 1051268:	shr    $0x3f,%rax
 105126c:	sar    $0x1d,%rdx
 1051270:	add    %rax,%rdx
 1051273:	imul   $0x3b9aca07,%rdx,%rax
 105127a:	sub    %rax,%rcx
 105127d:	mov    %rcx,%rax
 1051280:	sar    $0x3f,%rax
 1051284:	and    $0x3b9aca07,%eax
 1051289:	add    %rcx,%rax
 105128c:	inc    %rbx
 105128f:	cmp    %rbx,0x28(%rsp)
 1051294:	jne    10510d0 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x29e0>
 105129a:	jmp    104f01c <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x92c>
 105129f:	mov    -0x18(%rax),%rcx
 10512a3:	inc    %rcx
 10512a6:	je     10512c6 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2bd6>
 10512a8:	mov    %rcx,-0x18(%rax)
 10512ac:	mov    %rax,%rdi
 10512af:	mov    %rax,0x140(%rsp)
 10512b7:	testb  $0x4,0x10(%rdi)
 10512bb:	jne    105117e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2a8e>
 10512c1:	jmp    1051168 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2a78>
 10512c6:	mov    $0x1007dbf,%esi
 10512cb:	mov    %rbp,%rdi
 10512ce:	call   108beae <fail>
 10512d3:	xor    %r12d,%r12d
 10512d6:	jmp    1051250 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2b60>
 10512db:	lea    0x258(%rbp),%rdi
 10512e2:	lea    0x140(%rsp),%rsi
 10512ea:	call   10878f0 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan>
 10512ef:	jmp    1051250 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2b60>
 10512f4:	mov    0x18(%rsi),%rax
 10512f8:	mov    0x14(%rsi),%ecx
 10512fb:	lea    (%rax,%rcx,1),%rdi
 10512ff:	add    $0x18,%rdi
 1051303:	testb  $0x4,0x6957e(%rip)        # 10ba888 <myl_lit_626da83bb2caf4205ae415768034d7bb2b32d76c3b0b29af95ab0567cf1d3ca9_instance+0x20>
 105130a:	mov    0x6957f(%rip),%rax        # 10ba890 <myl_lit_626da83bb2caf4205ae415768034d7bb2b32d76c3b0b29af95ab0567cf1d3ca9_instance+0x28>
 1051311:	mov    0x69575(%rip),%ecx        # 10ba88c <myl_lit_626da83bb2caf4205ae415768034d7bb2b32d76c3b0b29af95ab0567cf1d3ca9_instance+0x24>
 1051317:	lea    0x18(%rax,%rcx,1),%rcx
 105131c:	mov    $0x10ba890,%eax
 1051321:	cmovne %rcx,%rax
 1051325:	cmp    $0x10,%rdx
 1051329:	ja     1051346 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2c56>
 105132b:	cmp    $0x8,%rdx
 105132f:	jb     1051361 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2c71>
 1051331:	mov    (%rdi),%rcx
 1051334:	mov    -0x8(%rdi,%rdx,1),%rdi
 1051339:	xor    (%rax),%rcx
 105133c:	xor    -0x8(%rax,%rdx,1),%rdi
 1051341:	or     %rcx,%rdi
 1051344:	jmp    10513a6 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2cb6>
 1051346:	mov    %rsi,%r14
 1051349:	mov    %rax,%rsi
 105134c:	cmp    $0x100,%rdx
 1051353:	ja     1051377 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2c87>
 1051355:	call   10accc0 <bcmp@plt>
 105135a:	test   %eax,%eax
 105135c:	setne  %bl
 105135f:	jmp    1051381 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2c91>
 1051361:	cmp    $0x4,%rdx
 1051365:	jb     1051386 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2c96>
 1051367:	mov    (%rdi),%ecx
 1051369:	mov    -0x4(%rdi,%rdx,1),%edi
 105136d:	xor    (%rax),%ecx
 105136f:	xor    -0x4(%rax,%rdx,1),%edi
 1051373:	or     %ecx,%edi
 1051375:	jmp    10513a6 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2cb6>
 1051377:	call   10934f0 <equal_large_octets>
 105137c:	test   %eax,%eax
 105137e:	sete   %bl
 1051381:	mov    %r14,%rsi
 1051384:	jmp    10513ac <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2cbc>
 1051386:	cmp    $0x1,%rdx
 105138a:	jne    1051393 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2ca3>
 105138c:	movzbl (%rdi),%ecx
 105138f:	cmp    (%rax),%cl
 1051391:	jmp    10513a6 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2cb6>
 1051393:	movzwl (%rdi),%ecx
 1051396:	movzwl -0x2(%rdi,%rdx,1),%edi
 105139b:	xor    (%rax),%cx
 105139e:	xor    -0x2(%rax,%rdx,1),%di
 10513a3:	or     %cx,%di
 10513a6:	sete   %bl
 10513a9:	xor    $0x1,%bl
 10513ac:	test   %r13,0x694b5(%rip)        # 10ba868 <myl_lit_626da83bb2caf4205ae415768034d7bb2b32d76c3b0b29af95ab0567cf1d3ca9_instance>
 10513b3:	jne    10513d2 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2ce2>
 10513b5:	mov    0x6949c(%rip),%rax        # 10ba858 <myl_lit_5ffcfeefbc77603111eb9faae2375c1bd71d00fc5610c522261905cf007d59b3_instance+0x60>
 10513bc:	dec    %rax
 10513bf:	jne    10513cb <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2cdb>
 10513c1:	cmpq   $0x0,0x69497(%rip)        # 10ba860 <myl_lit_5ffcfeefbc77603111eb9faae2375c1bd71d00fc5610c522261905cf007d59b3_instance+0x68>
 10513c9:	je     105142f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2d3f>
 10513cb:	mov    %rax,0x69486(%rip)        # 10ba858 <myl_lit_5ffcfeefbc77603111eb9faae2375c1bd71d00fc5610c522261905cf007d59b3_instance+0x60>
 10513d2:	test   %bl,%bl
 10513d4:	je     1051450 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2d60>
 10513d6:	movq   $0x10bac90,0x70(%rsp)
 10513df:	movq   $0x10bac90,0xc8(%rsp)
 10513eb:	cmp    $0x10bac90,%rsi
 10513f2:	jne    10513fb <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2d0b>
 10513f4:	xor    %ebx,%ebx
 10513f6:	jmp    105166e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2f7e>
 10513fb:	mov    $0x1,%bl
 10513fd:	test   %rsi,%rsi
 1051400:	je     105166e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2f7e>
 1051406:	mov    0x8(%rsi),%rdx
 105140a:	cmp    0x69887(%rip),%rdx        # 10bac98 <myl_lit_a35604ac3394cc7d310962e0ecc5dd785c46f6dc02140680027413a7b439bcdd_instance+0x18>
 1051411:	jne    105166e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2f7e>
 1051417:	test   %rdx,%rdx
 105141a:	je     10513f4 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2d04>
 105141c:	testb  $0x4,0x10(%rsi)
 1051420:	jne    10515b6 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2ec6>
 1051426:	lea    0x18(%rsi),%rdi
 105142a:	jmp    10515c5 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2ed5>
 105142f:	lea    0xc8(%rsp),%rax
 1051437:	lea    0x258(%rbp),%rdi
 105143e:	mov    %rsi,%r14
 1051441:	mov    %rax,%rsi
 1051444:	call   1087960 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop>
 1051449:	mov    %r14,%rsi
 105144c:	test   %bl,%bl
 105144e:	jne    10513d6 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2ce6>
 1051450:	xor    %ebx,%ebx
 1051452:	movabs $0x89705f3112a28fe5,%r12
 105145c:	xor    %eax,%eax
 105145e:	movabs $0x4000000000000002,%r13
 1051468:	nopl   0x0(%rax,%rax,1)
 1051470:	mov    %rax,%r14
 1051473:	mov    0x8(%rsp),%rax
 1051478:	add    %rbx,%rax
 105147b:	jo     1051d66 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3676>
 1051481:	mov    0x30(%rsp),%rcx
 1051486:	mov    0x18(%rcx),%rdi
 105148a:	mov    (%rdi),%rcx
 105148d:	test   %rcx,%rcx
 1051490:	js     1051d78 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3688>
 1051496:	je     1051d83 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3693>
 105149c:	mov    %rax,%rdx
 105149f:	or     %rcx,%rdx
 10514a2:	shr    $0x20,%rdx
 10514a6:	je     10514af <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2dbf>
 10514a8:	cqto
 10514aa:	idiv   %rcx
 10514ad:	jmp    10514b3 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2dc3>
 10514af:	xor    %edx,%edx
 10514b1:	div    %ecx
 10514b3:	mov    %rdx,%rsi
 10514b6:	sar    $0x3f,%rsi
 10514ba:	and    %rcx,%rsi
 10514bd:	add    %rdx,%rsi
 10514c0:	cmp    %rcx,%rsi
 10514c3:	jb     10514db <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2deb>
 10514c5:	mov    %rsi,%rax
 10514c8:	sar    $0x3f,%rax
 10514cc:	and    %rcx,%rax
 10514cf:	add    %rax,%rsi
 10514d2:	cmp    %rcx,%rsi
 10514d5:	jae    1051d96 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x36a6>
 10514db:	mov    0x20(%rdi),%rax
 10514df:	mov    (%rax,%rsi,8),%rsi
 10514e3:	lea    0x258(%rbp),%rdi
 10514ea:	call   104bd10 <myl_native_text_integer>
 10514ef:	test   %rax,%rax
 10514f2:	je     1051d8e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x369e>
 10514f8:	mov    %rax,%r15
 10514fb:	mov    %rax,0x70(%rsp)
 1051500:	mov    %rax,0x1c8(%rsp)
 1051508:	mov    %rbp,%rdi
 105150b:	mov    %rax,%rsi
 105150e:	call   1074d50 <myl_f_c022a6ad651d6537a30c1e2f178a185a896cdb5bde02baa31c70d91d735e3e85>
 1051513:	test   %r13,-0x10(%r15)
 1051517:	jne    105152d <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2e3d>
 1051519:	mov    -0x20(%r15),%rcx
 105151d:	dec    %rcx
 1051520:	jne    1051529 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2e39>
 1051522:	cmpq   $0x0,-0x18(%r15)
 1051527:	je     1051584 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2e94>
 1051529:	mov    %rcx,-0x20(%r15)
 105152d:	movq   $0x0,0x1c8(%rsp)
 1051539:	mov    %r14,%rcx
 105153c:	add    %rax,%rcx
 105153f:	jo     10515a6 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2eb6>
 1051541:	mov    %rcx,%rax
 1051544:	imul   %r12
 1051547:	add    %rcx,%rdx
 105154a:	mov    %rdx,%rax
 105154d:	shr    $0x3f,%rax
 1051551:	sar    $0x1d,%rdx
 1051555:	add    %rax,%rdx
 1051558:	imul   $0x3b9aca07,%rdx,%rax
 105155f:	sub    %rax,%rcx
 1051562:	mov    %rcx,%rax
 1051565:	sar    $0x3f,%rax
 1051569:	and    $0x3b9aca07,%eax
 105156e:	add    %rcx,%rax
 1051571:	inc    %rbx
 1051574:	cmp    %rbx,0x28(%rsp)
 1051579:	jne    1051470 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2d80>
 105157f:	jmp    104f01c <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x92c>
 1051584:	lea    0x258(%rbp),%rdi
 105158b:	lea    0x1c8(%rsp),%rsi
 1051593:	mov    %rax,%r15
 1051596:	call   1087960 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop>
 105159b:	mov    %r15,%rax
 105159e:	mov    %r14,%rcx
 10515a1:	add    %rax,%rcx
 10515a4:	jno    1051541 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2e51>
 10515a6:	mov    %rbp,%rdi
 10515a9:	xor    %esi,%esi
 10515ab:	mov    %r14,%rdx
 10515ae:	mov    %rax,%rcx
 10515b1:	call   108c8c0 <myl_qbe_fail_overflow_op>
 10515b6:	mov    0x18(%rsi),%rax
 10515ba:	mov    0x14(%rsi),%ecx
 10515bd:	lea    (%rax,%rcx,1),%rdi
 10515c1:	add    $0x18,%rdi
 10515c5:	testb  $0x4,0x696d4(%rip)        # 10baca0 <myl_lit_a35604ac3394cc7d310962e0ecc5dd785c46f6dc02140680027413a7b439bcdd_instance+0x20>
 10515cc:	mov    0x696d5(%rip),%rax        # 10baca8 <myl_lit_a35604ac3394cc7d310962e0ecc5dd785c46f6dc02140680027413a7b439bcdd_instance+0x28>
 10515d3:	mov    0x696cb(%rip),%ecx        # 10baca4 <myl_lit_a35604ac3394cc7d310962e0ecc5dd785c46f6dc02140680027413a7b439bcdd_instance+0x24>
 10515d9:	lea    0x18(%rax,%rcx,1),%rcx
 10515de:	mov    $0x10baca8,%eax
 10515e3:	cmovne %rcx,%rax
 10515e7:	cmp    $0x10,%rdx
 10515eb:	ja     1051608 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2f18>
 10515ed:	cmp    $0x8,%rdx
 10515f1:	jb     1051623 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2f33>
 10515f3:	mov    (%rdi),%rcx
 10515f6:	mov    -0x8(%rdi,%rdx,1),%rdi
 10515fb:	xor    (%rax),%rcx
 10515fe:	xor    -0x8(%rax,%rdx,1),%rdi
 1051603:	or     %rcx,%rdi
 1051606:	jmp    1051668 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2f78>
 1051608:	mov    %rsi,%r14
 105160b:	mov    %rax,%rsi
 105160e:	cmp    $0x100,%rdx
 1051615:	ja     1051639 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2f49>
 1051617:	call   10accc0 <bcmp@plt>
 105161c:	test   %eax,%eax
 105161e:	setne  %bl
 1051621:	jmp    1051643 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2f53>
 1051623:	cmp    $0x4,%rdx
 1051627:	jb     1051648 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2f58>
 1051629:	mov    (%rdi),%ecx
 105162b:	mov    -0x4(%rdi,%rdx,1),%edi
 105162f:	xor    (%rax),%ecx
 1051631:	xor    -0x4(%rax,%rdx,1),%edi
 1051635:	or     %ecx,%edi
 1051637:	jmp    1051668 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2f78>
 1051639:	call   10934f0 <equal_large_octets>
 105163e:	test   %eax,%eax
 1051640:	sete   %bl
 1051643:	mov    %r14,%rsi
 1051646:	jmp    105166e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2f7e>
 1051648:	cmp    $0x1,%rdx
 105164c:	jne    1051655 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2f65>
 105164e:	movzbl (%rdi),%ecx
 1051651:	cmp    (%rax),%cl
 1051653:	jmp    1051668 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2f78>
 1051655:	movzwl (%rdi),%ecx
 1051658:	movzwl -0x2(%rdi,%rdx,1),%edi
 105165d:	xor    (%rax),%cx
 1051660:	xor    -0x2(%rax,%rdx,1),%di
 1051665:	or     %cx,%di
 1051668:	sete   %bl
 105166b:	xor    $0x1,%bl
 105166e:	test   %r13,0x6960b(%rip)        # 10bac80 <myl_lit_a35604ac3394cc7d310962e0ecc5dd785c46f6dc02140680027413a7b439bcdd_instance>
 1051675:	jne    1051694 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2fa4>
 1051677:	mov    0x695f2(%rip),%rax        # 10bac70 <myl_lit_9d259d114fa076e260ed1d46f937777788fb8ac5c28077065c4fa3e2a22cd22a_instance+0x38>
 105167e:	dec    %rax
 1051681:	jne    105168d <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2f9d>
 1051683:	cmpq   $0x0,0x695ed(%rip)        # 10bac78 <myl_lit_9d259d114fa076e260ed1d46f937777788fb8ac5c28077065c4fa3e2a22cd22a_instance+0x40>
 105168b:	je     1051702 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3012>
 105168d:	mov    %rax,0x695dc(%rip)        # 10bac70 <myl_lit_9d259d114fa076e260ed1d46f937777788fb8ac5c28077065c4fa3e2a22cd22a_instance+0x38>
 1051694:	test   %bl,%bl
 1051696:	je     1051727 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3037>
 105169c:	movq   $0x10ba128,0x70(%rsp)
 10516a5:	movq   $0x10ba128,0xc8(%rsp)
 10516b1:	cmp    $0x10ba128,%rsi
 10516b8:	jne    10516ce <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2fde>
 10516ba:	xor    %ebx,%ebx
 10516bc:	test   %r13,0x68a55(%rip)        # 10ba118 <myl_lit_20a5074191baf0b9771e8515f87070a522415c098c80effc97a3fee2e9d89d03_instance>
 10516c3:	jne    1051886 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3196>
 10516c9:	jmp    1051865 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3175>
 10516ce:	mov    $0x1,%bl
 10516d0:	test   %rsi,%rsi
 10516d3:	je     105185c <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x316c>
 10516d9:	mov    0x8(%rsi),%rdx
 10516dd:	cmp    0x68a4c(%rip),%rdx        # 10ba130 <myl_lit_20a5074191baf0b9771e8515f87070a522415c098c80effc97a3fee2e9d89d03_instance+0x18>
 10516e4:	jne    105185c <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x316c>
 10516ea:	test   %rdx,%rdx
 10516ed:	je     10516ba <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2fca>
 10516ef:	testb  $0x4,0x10(%rsi)
 10516f3:	jne    10517b9 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x30c9>
 10516f9:	lea    0x18(%rsi),%rdi
 10516fd:	jmp    10517c8 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x30d8>
 1051702:	lea    0xc8(%rsp),%rax
 105170a:	lea    0x258(%rbp),%rdi
 1051711:	mov    %rsi,%r14
 1051714:	mov    %rax,%rsi
 1051717:	call   1087960 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop>
 105171c:	mov    %r14,%rsi
 105171f:	test   %bl,%bl
 1051721:	jne    105169c <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x2fac>
 1051727:	xor    %ebx,%ebx
 1051729:	movabs $0x89705f3112a28fe5,%r14
 1051733:	xor    %eax,%eax
 1051735:	mov    0x8(%rsp),%rsi
 105173a:	add    %rbx,%rsi
 105173d:	jo     1051da1 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x36b1>
 1051743:	mov    %rax,%r15
 1051746:	mov    0x30(%rsp),%rax
 105174b:	mov    0x8(%rax),%rax
 105174f:	and    $0x1,%esi
 1051752:	mov    (%rax),%rdx
 1051755:	cmp    %rdx,%rsi
 1051758:	jae    1051db3 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x36c3>
 105175e:	mov    0x20(%rax),%rax
 1051762:	mov    (%rax,%rsi,8),%rsi
 1051766:	mov    %rbp,%rdi
 1051769:	call   106b4b0 <myl_f_ad1ca9f864adc8c89d572ada651cc6dc28bc6d83eeae5c5fc70bc26744bcdb57>
 105176e:	mov    %r15,%rcx
 1051771:	add    %rax,%rcx
 1051774:	jo     1051dbb <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x36cb>
 105177a:	mov    %rcx,%rax
 105177d:	imul   %r14
 1051780:	add    %rcx,%rdx
 1051783:	mov    %rdx,%rax
 1051786:	shr    $0x3f,%rax
 105178a:	sar    $0x1d,%rdx
 105178e:	add    %rax,%rdx
 1051791:	imul   $0x3b9aca07,%rdx,%rax
 1051798:	sub    %rax,%rcx
 105179b:	mov    %rcx,%rax
 105179e:	sar    $0x3f,%rax
 10517a2:	and    $0x3b9aca07,%eax
 10517a7:	add    %rcx,%rax
 10517aa:	inc    %rbx
 10517ad:	cmp    %rbx,0x28(%rsp)
 10517b2:	jne    1051735 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3045>
 10517b4:	jmp    104f01c <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x92c>
 10517b9:	mov    0x18(%rsi),%rax
 10517bd:	mov    0x14(%rsi),%ecx
 10517c0:	lea    (%rax,%rcx,1),%rdi
 10517c4:	add    $0x18,%rdi
 10517c8:	testb  $0x4,0x68969(%rip)        # 10ba138 <myl_lit_20a5074191baf0b9771e8515f87070a522415c098c80effc97a3fee2e9d89d03_instance+0x20>
 10517cf:	mov    0x6896a(%rip),%rax        # 10ba140 <myl_lit_20a5074191baf0b9771e8515f87070a522415c098c80effc97a3fee2e9d89d03_instance+0x28>
 10517d6:	mov    0x68960(%rip),%ecx        # 10ba13c <myl_lit_20a5074191baf0b9771e8515f87070a522415c098c80effc97a3fee2e9d89d03_instance+0x24>
 10517dc:	lea    0x18(%rax,%rcx,1),%rcx
 10517e1:	mov    $0x10ba140,%eax
 10517e6:	cmovne %rcx,%rax
 10517ea:	cmp    $0x10,%rdx
 10517ee:	ja     105180b <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x311b>
 10517f0:	cmp    $0x8,%rdx
 10517f4:	jb     1051826 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3136>
 10517f6:	mov    (%rdi),%rcx
 10517f9:	mov    -0x8(%rdi,%rdx,1),%rdi
 10517fe:	xor    (%rax),%rcx
 1051801:	xor    -0x8(%rax,%rdx,1),%rdi
 1051806:	or     %rcx,%rdi
 1051809:	jmp    105183e <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x314e>
 105180b:	mov    %rsi,%r14
 105180e:	mov    %rax,%rsi
 1051811:	cmp    $0x100,%rdx
 1051818:	ja     105184f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x315f>
 105181a:	call   10accc0 <bcmp@plt>
 105181f:	test   %eax,%eax
 1051821:	setne  %bl
 1051824:	jmp    1051859 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3169>
 1051826:	cmp    $0x4,%rdx
 105182a:	jb     1051a09 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3319>
 1051830:	mov    (%rdi),%ecx
 1051832:	mov    -0x4(%rdi,%rdx,1),%edi
 1051836:	xor    (%rax),%ecx
 1051838:	xor    -0x4(%rax,%rdx,1),%edi
 105183c:	or     %ecx,%edi
 105183e:	sete   %bl
 1051841:	xor    $0x1,%bl
 1051844:	test   %r13,0x688cd(%rip)        # 10ba118 <myl_lit_20a5074191baf0b9771e8515f87070a522415c098c80effc97a3fee2e9d89d03_instance>
 105184b:	jne    1051886 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3196>
 105184d:	jmp    1051865 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3175>
 105184f:	call   10934f0 <equal_large_octets>
 1051854:	test   %eax,%eax
 1051856:	sete   %bl
 1051859:	mov    %r14,%rsi
 105185c:	test   %r13,0x688b5(%rip)        # 10ba118 <myl_lit_20a5074191baf0b9771e8515f87070a522415c098c80effc97a3fee2e9d89d03_instance>
 1051863:	jne    1051886 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3196>
 1051865:	mov    0x6889c(%rip),%rax        # 10ba108 <myl_lit_1ad4f10fd641593331eda3448c74a0b009c6527a19d75e6283c9d7ef74595fd2_instance+0x38>
 105186c:	dec    %rax
 105186f:	jne    105187f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x318f>
 1051871:	cmpq   $0x0,0x68897(%rip)        # 10ba110 <myl_lit_1ad4f10fd641593331eda3448c74a0b009c6527a19d75e6283c9d7ef74595fd2_instance+0x40>
 1051879:	je     1051970 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3280>
 105187f:	mov    %rax,0x68882(%rip)        # 10ba108 <myl_lit_1ad4f10fd641593331eda3448c74a0b009c6527a19d75e6283c9d7ef74595fd2_instance+0x38>
 1051886:	test   %bl,%bl
 1051888:	je     10518b3 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x31c3>
 105188a:	movq   $0x10ba1f8,0x70(%rsp)
 1051893:	movq   $0x10ba1f8,0xc8(%rsp)
 105189f:	cmp    $0x10ba1f8,%rsi
 10518a6:	jne    105193f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x324f>
 10518ac:	xor    %ebx,%ebx
 10518ae:	jmp    1051aa7 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x33b7>
 10518b3:	xor    %ebx,%ebx
 10518b5:	movabs $0x89705f3112a28fe5,%r14
 10518bf:	xor    %eax,%eax
 10518c1:	mov    %rax,%r15
 10518c4:	mov    0x8(%rsp),%rax
 10518c9:	add    %rbx,%rax
 10518cc:	jo     1051dcb <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x36db>
 10518d2:	mov    0x30(%rsp),%rax
 10518d7:	mov    0x8(%rax),%rax
 10518db:	cmpq   $0x0,(%rax)
 10518df:	je     1051ddd <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x36ed>
 10518e5:	mov    0x20(%rax),%rax
 10518e9:	mov    (%rax),%rsi
 10518ec:	mov    %rbp,%rdi
 10518ef:	call   1072a30 <myl_f_bc9060da36c8e282f8d98349f6541aa0f2c1802b8a99e1d4c2ef7b134103c5e2>
 10518f4:	mov    %r15,%rcx
 10518f7:	add    %rax,%rcx
 10518fa:	jo     1051de9 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x36f9>
 1051900:	mov    %rcx,%rax
 1051903:	imul   %r14
 1051906:	add    %rcx,%rdx
 1051909:	mov    %rdx,%rax
 105190c:	shr    $0x3f,%rax
 1051910:	sar    $0x1d,%rdx
 1051914:	add    %rax,%rdx
 1051917:	imul   $0x3b9aca07,%rdx,%rax
 105191e:	sub    %rax,%rcx
 1051921:	mov    %rcx,%rax
 1051924:	sar    $0x3f,%rax
 1051928:	and    $0x3b9aca07,%eax
 105192d:	add    %rcx,%rax
 1051930:	inc    %rbx
 1051933:	cmp    %rbx,0x28(%rsp)
 1051938:	jne    10518c1 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x31d1>
 105193a:	jmp    104f01c <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x92c>
 105193f:	mov    $0x1,%bl
 1051941:	test   %rsi,%rsi
 1051944:	je     1051aa7 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x33b7>
 105194a:	mov    0x8(%rsi),%rdx
 105194e:	cmp    0x688ab(%rip),%rdx        # 10ba200 <myl_lit_2cecebef85ac89e87c0bdc9d723015d4a10a29fb007a542e0de04f511346a3b5_instance+0x18>
 1051955:	jne    1051aa7 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x33b7>
 105195b:	test   %rdx,%rdx
 105195e:	je     10518ac <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x31bc>
 1051964:	testb  $0x4,0x10(%rsi)
 1051968:	jne    1051990 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x32a0>
 105196a:	add    $0x18,%rsi
 105196e:	jmp    105199f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x32af>
 1051970:	lea    0xc8(%rsp),%rax
 1051978:	mov    0x18(%rsp),%rdi
 105197d:	mov    %rsi,%r14
 1051980:	mov    %rax,%rsi
 1051983:	call   1087960 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop>
 1051988:	mov    %r14,%rsi
 105198b:	jmp    1051886 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3196>
 1051990:	mov    0x18(%rsi),%rax
 1051994:	mov    0x14(%rsi),%ecx
 1051997:	lea    (%rax,%rcx,1),%rsi
 105199b:	add    $0x18,%rsi
 105199f:	testb  $0x4,0x68862(%rip)        # 10ba208 <myl_lit_2cecebef85ac89e87c0bdc9d723015d4a10a29fb007a542e0de04f511346a3b5_instance+0x20>
 10519a6:	mov    0x68863(%rip),%rax        # 10ba210 <myl_lit_2cecebef85ac89e87c0bdc9d723015d4a10a29fb007a542e0de04f511346a3b5_instance+0x28>
 10519ad:	mov    0x68859(%rip),%ecx        # 10ba20c <myl_lit_2cecebef85ac89e87c0bdc9d723015d4a10a29fb007a542e0de04f511346a3b5_instance+0x24>
 10519b3:	lea    0x18(%rax,%rcx,1),%rcx
 10519b8:	mov    $0x10ba210,%eax
 10519bd:	cmovne %rcx,%rax
 10519c1:	cmp    $0x10,%rdx
 10519c5:	ja     10519eb <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x32fb>
 10519c7:	cmp    $0x8,%rdx
 10519cb:	jb     1051a16 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3326>
 10519cd:	mov    (%rsi),%rcx
 10519d0:	mov    -0x8(%rsi,%rdx,1),%rsi
 10519d5:	xor    (%rax),%rcx
 10519d8:	xor    -0x8(%rax,%rdx,1),%rsi
 10519dd:	or     %rcx,%rsi
 10519e0:	sete   %bl
 10519e3:	xor    $0x1,%bl
 10519e6:	jmp    1051aa7 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x33b7>
 10519eb:	mov    %rsi,%rdi
 10519ee:	mov    %rax,%rsi
 10519f1:	cmp    $0x100,%rdx
 10519f8:	ja     1051a2c <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x333c>
 10519fa:	call   10accc0 <bcmp@plt>
 10519ff:	test   %eax,%eax
 1051a01:	setne  %bl
 1051a04:	jmp    1051aa7 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x33b7>
 1051a09:	cmp    $0x1,%rdx
 1051a0d:	jne    1051a38 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3348>
 1051a0f:	movzbl (%rdi),%ecx
 1051a12:	cmp    (%rax),%cl
 1051a14:	jmp    1051a4b <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x335b>
 1051a16:	cmp    $0x4,%rdx
 1051a1a:	jb     1051a72 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3382>
 1051a1c:	mov    (%rsi),%ecx
 1051a1e:	mov    -0x4(%rsi,%rdx,1),%esi
 1051a22:	xor    (%rax),%ecx
 1051a24:	xor    -0x4(%rax,%rdx,1),%esi
 1051a28:	or     %ecx,%esi
 1051a2a:	jmp    1051a92 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x33a2>
 1051a2c:	call   10934f0 <equal_large_octets>
 1051a31:	test   %eax,%eax
 1051a33:	sete   %bl
 1051a36:	jmp    1051aa7 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x33b7>
 1051a38:	movzwl (%rdi),%ecx
 1051a3b:	movzwl -0x2(%rdi,%rdx,1),%edi
 1051a40:	xor    (%rax),%cx
 1051a43:	xor    -0x2(%rax,%rdx,1),%di
 1051a48:	or     %cx,%di
 1051a4b:	sete   %bl
 1051a4e:	xor    $0x1,%bl
 1051a51:	mov    0x10(%rsp),%rbp
 1051a56:	movabs $0x4000000000000002,%r13
 1051a60:	test   %r13,0x686b1(%rip)        # 10ba118 <myl_lit_20a5074191baf0b9771e8515f87070a522415c098c80effc97a3fee2e9d89d03_instance>
 1051a67:	jne    1051886 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3196>
 1051a6d:	jmp    1051865 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3175>
 1051a72:	cmp    $0x1,%rdx
 1051a76:	jne    1051a7f <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x338f>
 1051a78:	movzbl (%rsi),%ecx
 1051a7b:	cmp    (%rax),%cl
 1051a7d:	jmp    1051a92 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x33a2>
 1051a7f:	movzwl (%rsi),%ecx
 1051a82:	movzwl -0x2(%rsi,%rdx,1),%esi
 1051a87:	xor    (%rax),%cx
 1051a8a:	xor    -0x2(%rax,%rdx,1),%si
 1051a8f:	or     %cx,%si
 1051a92:	sete   %bl
 1051a95:	xor    $0x1,%bl
 1051a98:	mov    0x10(%rsp),%rbp
 1051a9d:	movabs $0x4000000000000002,%r13
 1051aa7:	test   %r13,0x6873a(%rip)        # 10ba1e8 <myl_lit_2cecebef85ac89e87c0bdc9d723015d4a10a29fb007a542e0de04f511346a3b5_instance>
 1051aae:	jne    1051acd <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x33dd>
 1051ab0:	mov    0x68721(%rip),%rax        # 10ba1d8 <myl_lit_2ac6840555c10725b6640492294f67393cd0d698e5786fc4e12cdb1cc9a394a2_instance+0x38>
 1051ab7:	dec    %rax
 1051aba:	jne    1051ac6 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x33d6>
 1051abc:	cmpq   $0x0,0x6871c(%rip)        # 10ba1e0 <myl_lit_2ac6840555c10725b6640492294f67393cd0d698e5786fc4e12cdb1cc9a394a2_instance+0x40>
 1051ac4:	je     1051ad8 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x33e8>
 1051ac6:	mov    %rax,0x6870b(%rip)        # 10ba1d8 <myl_lit_2ac6840555c10725b6640492294f67393cd0d698e5786fc4e12cdb1cc9a394a2_instance+0x38>
 1051acd:	test   %bl,%bl
 1051acf:	je     1051aee <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x33fe>
 1051ad1:	xor    %eax,%eax
 1051ad3:	jmp    104f01c <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x92c>
 1051ad8:	lea    0xc8(%rsp),%rsi
 1051ae0:	mov    0x18(%rsp),%rdi
 1051ae5:	call   1087960 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop>
 1051aea:	test   %bl,%bl
 1051aec:	jne    1051ad1 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x33e1>
 1051aee:	xor    %ebx,%ebx
 1051af0:	movabs $0x7878787878787879,%r14
 1051afa:	movabs $0x89705f3112a28fe5,%r15
 1051b04:	xor    %eax,%eax
 1051b06:	mov    0x8(%rsp),%rcx
 1051b0b:	add    %rbx,%rcx
 1051b0e:	jo     1051df9 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3709>
 1051b14:	mov    %rax,%r12
 1051b17:	mov    0x30(%rsp),%rax
 1051b1c:	mov    0x8(%rax),%rax
 1051b20:	cmpq   $0x0,(%rax)
 1051b24:	je     1051e0b <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x371b>
 1051b2a:	mov    0x20(%rax),%rax
 1051b2e:	mov    (%rax),%rsi
 1051b31:	mov    %rcx,%rax
 1051b34:	imul   %r14
 1051b37:	mov    %rdx,%rax
 1051b3a:	shr    $0x3f,%rax
 1051b3e:	sar    $0x3,%rdx
 1051b42:	add    %rax,%rdx
 1051b45:	mov    %rdx,%rax
 1051b48:	shl    $0x4,%rax
 1051b4c:	add    %rdx,%rax
 1051b4f:	sub    %rax,%rcx
 1051b52:	mov    %rcx,%rdx
 1051b55:	sar    $0x3f,%rdx
 1051b59:	and    $0x11,%edx
 1051b5c:	add    %rcx,%rdx
 1051b5f:	mov    %rbp,%rdi
 1051b62:	call   10585e0 <myl_f_47022dd26e980fcb99b6abeb2cfdf289edce3d6955dda89c0a131b73692c5f56>
 1051b67:	mov    %r12,%rcx
 1051b6a:	add    %rax,%rcx
 1051b6d:	jo     1051e17 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3727>
 1051b73:	mov    %rcx,%rax
 1051b76:	imul   %r15
 1051b79:	add    %rcx,%rdx
 1051b7c:	mov    %rdx,%rax
 1051b7f:	shr    $0x3f,%rax
 1051b83:	sar    $0x1d,%rdx
 1051b87:	add    %rax,%rdx
 1051b8a:	imul   $0x3b9aca07,%rdx,%rax
 1051b91:	sub    %rax,%rcx
 1051b94:	mov    %rcx,%rax
 1051b97:	sar    $0x3f,%rax
 1051b9b:	and    $0x3b9aca07,%eax
 1051ba0:	add    %rcx,%rax
 1051ba3:	inc    %rbx
 1051ba6:	cmp    %rbx,0x28(%rsp)
 1051bab:	jne    1051b06 <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x3416>
 1051bb1:	jmp    104f01c <myl_f_1af80ea2572d9d5f91426ffa7805826aa9a97e2ce757b902d5901fdbfc722f76+0x92c>
 1051bb6:	vzeroupper
 1051bb9:	call   10acca0 <abort@plt>
 1051bbe:	vzeroupper
 1051bc1:	call   109b027 <myl_rc_invariant_failed>
 1051bc6:	mov    %rbp,%rdi
 1051bc9:	xor    %esi,%esi
 1051bcb:	vzeroupper
 1051bce:	call   108c8c0 <myl_qbe_fail_overflow_op>
 1051bd3:	mov    0x10(%rsp),%rdi
 1051bd8:	xor    %esi,%esi
 1051bda:	mov    %r12,%rdx
 1051bdd:	mov    %rax,%rcx
 1051be0:	call   108c8c0 <myl_qbe_fail_overflow_op>
 1051be5:	mov    0x10(%rsp),%rdi
 1051bea:	vzeroupper
 1051bed:	call   108c670 <myl_qbe_fail_iteration>
 1051bf2:	mov    %rbp,%rdi
 1051bf5:	xor    %esi,%esi
 1051bf7:	mov    0x8(%rsp),%rdx
 1051bfc:	mov    %r14,%rcx
 1051bff:	vzeroupper
 1051c02:	call   108c8c0 <myl_qbe_fail_overflow_op>
 1051c07:	mov    %rbp,%rdi
 1051c0a:	xor    %esi,%esi
 1051c0c:	mov    %r12,%rdx
 1051c0f:	mov    %rbx,%rcx
 1051c12:	vzeroupper
 1051c15:	call   108c8c0 <myl_qbe_fail_overflow_op>
 1051c1a:	mov    0x10(%rsp),%rdi
 1051c1f:	call   108c7b0 <myl_qbe_fail_normalized_index_bounds>
 1051c24:	mov    0x10(%rsp),%rdi
 1051c29:	call   108c7b0 <myl_qbe_fail_normalized_index_bounds>
 1051c2e:	mov    %rbp,%rdi
 1051c31:	xor    %esi,%esi
 1051c33:	mov    0x8(%rsp),%rdx
 1051c38:	mov    %rbx,%rcx
 1051c3b:	call   108c8c0 <myl_qbe_fail_overflow_op>
 1051c40:	mov    %rbp,%rdi
 1051c43:	xor    %esi,%esi
 1051c45:	mov    0x8(%rsp),%rdx
 1051c4a:	mov    %rbx,%rcx
 1051c4d:	call   108c8c0 <myl_qbe_fail_overflow_op>
 1051c52:	mov    %rbp,%rdi
 1051c55:	xor    %esi,%esi
 1051c57:	xor    %edx,%edx
 1051c59:	call   108c7b0 <myl_qbe_fail_normalized_index_bounds>
 1051c5e:	mov    %rbp,%rdi
 1051c61:	call   108c7b0 <myl_qbe_fail_normalized_index_bounds>
 1051c66:	mov    $0x1,%ecx
 1051c6b:	mov    0x10(%rsp),%rdi
 1051c70:	xor    %esi,%esi
 1051c72:	mov    %r15,%rdx
 1051c75:	call   108c8c0 <myl_qbe_fail_overflow_op>
 1051c7a:	mov    %rbp,%rdi
 1051c7d:	vzeroupper
 1051c80:	call   108c7b0 <myl_qbe_fail_normalized_index_bounds>
 1051c85:	mov    %rbp,%rdi
 1051c88:	xor    %esi,%esi
 1051c8a:	mov    0x8(%rsp),%rdx
 1051c8f:	mov    %r12,%rcx
 1051c92:	vzeroupper
 1051c95:	call   108c8c0 <myl_qbe_fail_overflow_op>
 1051c9a:	mov    %rbp,%rdi
 1051c9d:	vzeroupper
 1051ca0:	call   108c980 <myl_qbe_fail_frame>
 1051ca5:	mov    %rbp,%rdi
 1051ca8:	vzeroupper
 1051cab:	call   108c660 <myl_qbe_fail_empty_separator>
 1051cb0:	mov    %rbp,%rdi
 1051cb3:	vzeroupper
 1051cb6:	call   108c570 <myl_qbe_fail_allocation>
 1051cbb:	mov    %rbp,%rdi
 1051cbe:	xor    %esi,%esi
 1051cc0:	mov    %r14,%rcx
 1051cc3:	vzeroupper
 1051cc6:	call   108c8c0 <myl_qbe_fail_overflow_op>
 1051ccb:	mov    %rbp,%rdi
 1051cce:	mov    %r15,%rsi
 1051cd1:	vzeroupper
 1051cd4:	call   108c920 <myl_qbe_fail_cast>
 1051cd9:	mov    $0x2,%esi
 1051cde:	mov    $0x7,%ecx
 1051ce3:	mov    %rbp,%rdi
 1051ce6:	mov    %r15,%rdx
 1051ce9:	vzeroupper
 1051cec:	call   108c8c0 <myl_qbe_fail_overflow_op>
 1051cf1:	mov    %rbp,%rdi
 1051cf4:	call   108c980 <myl_qbe_fail_frame>
 1051cf9:	mov    %rbp,%rdi
 1051cfc:	call   108c570 <myl_qbe_fail_allocation>
 1051d01:	mov    %rbp,%rdi
 1051d04:	xor    %esi,%esi
 1051d06:	mov    %r14,%rdx
 1051d09:	mov    %r13,%rcx
 1051d0c:	call   108c8c0 <myl_qbe_fail_overflow_op>
 1051d11:	mov    %rbp,%rdi
 1051d14:	xor    %esi,%esi
 1051d16:	mov    0x8(%rsp),%rdx
 1051d1b:	mov    %r15,%rcx
 1051d1e:	call   108c8c0 <myl_qbe_fail_overflow_op>
 1051d23:	mov    %rbp,%rdi
 1051d26:	xor    %esi,%esi
 1051d28:	mov    0x8(%rsp),%rdx
 1051d2d:	mov    %rbx,%rcx
 1051d30:	call   108c8c0 <myl_qbe_fail_overflow_op>
 1051d35:	mov    %rbp,%rdi
 1051d38:	mov    %rcx,%rsi
 1051d3b:	call   108c920 <myl_qbe_fail_cast>
 1051d40:	mov    %rbp,%rdi
 1051d43:	mov    %rax,%rsi
 1051d46:	call   108c870 <myl_qbe_fail_division>
 1051d4b:	mov    %rbp,%rdi
 1051d4e:	mov    %rcx,%rdx
 1051d51:	call   108c7b0 <myl_qbe_fail_normalized_index_bounds>
 1051d56:	mov    %rbp,%rdi
 1051d59:	xor    %esi,%esi
 1051d5b:	mov    %r15,%rdx
 1051d5e:	mov    %r12,%rcx
 1051d61:	call   108c8c0 <myl_qbe_fail_overflow_op>
 1051d66:	mov    %rbp,%rdi
 1051d69:	xor    %esi,%esi
 1051d6b:	mov    0x8(%rsp),%rdx
 1051d70:	mov    %rbx,%rcx
 1051d73:	call   108c8c0 <myl_qbe_fail_overflow_op>
 1051d78:	mov    %rbp,%rdi
 1051d7b:	mov    %rcx,%rsi
 1051d7e:	call   108c920 <myl_qbe_fail_cast>
 1051d83:	mov    %rbp,%rdi
 1051d86:	mov    %rax,%rsi
 1051d89:	call   108c870 <myl_qbe_fail_division>
 1051d8e:	mov    %rbp,%rdi
 1051d91:	call   108c570 <myl_qbe_fail_allocation>
 1051d96:	mov    %rbp,%rdi
 1051d99:	mov    %rcx,%rdx
 1051d9c:	call   108c7b0 <myl_qbe_fail_normalized_index_bounds>
 1051da1:	mov    %rbp,%rdi
 1051da4:	xor    %esi,%esi
 1051da6:	mov    0x8(%rsp),%rdx
 1051dab:	mov    %rbx,%rcx
 1051dae:	call   108c8c0 <myl_qbe_fail_overflow_op>
 1051db3:	mov    %rbp,%rdi
 1051db6:	call   108c7b0 <myl_qbe_fail_normalized_index_bounds>
 1051dbb:	mov    %r15,%rdx
 1051dbe:	mov    %rbp,%rdi
 1051dc1:	xor    %esi,%esi
 1051dc3:	mov    %rax,%rcx
 1051dc6:	call   108c8c0 <myl_qbe_fail_overflow_op>
 1051dcb:	mov    %rbp,%rdi
 1051dce:	xor    %esi,%esi
 1051dd0:	mov    0x8(%rsp),%rdx
 1051dd5:	mov    %rbx,%rcx
 1051dd8:	call   108c8c0 <myl_qbe_fail_overflow_op>
 1051ddd:	mov    %rbp,%rdi
 1051de0:	xor    %esi,%esi
 1051de2:	xor    %edx,%edx
 1051de4:	call   108c7b0 <myl_qbe_fail_normalized_index_bounds>
 1051de9:	mov    %r15,%rdx
 1051dec:	mov    %rbp,%rdi
 1051def:	xor    %esi,%esi
 1051df1:	mov    %rax,%rcx
 1051df4:	call   108c8c0 <myl_qbe_fail_overflow_op>
 1051df9:	mov    %rbp,%rdi
 1051dfc:	xor    %esi,%esi
 1051dfe:	mov    0x8(%rsp),%rdx
 1051e03:	mov    %rbx,%rcx
 1051e06:	call   108c8c0 <myl_qbe_fail_overflow_op>
 1051e0b:	mov    %rbp,%rdi
 1051e0e:	xor    %esi,%esi
 1051e10:	xor    %edx,%edx
 1051e12:	call   108c7b0 <myl_qbe_fail_normalized_index_bounds>
 1051e17:	mov    %r12,%rdx
 1051e1a:	mov    %rbp,%rdi
 1051e1d:	xor    %esi,%esi
 1051e1f:	mov    %rax,%rcx
 1051e22:	call   108c8c0 <myl_qbe_fail_overflow_op>
 1051e27:	int3
 1051e28:	int3
 1051e29:	int3
 1051e2a:	int3
 1051e2b:	int3
 1051e2c:	int3
 1051e2d:	int3
 1051e2e:	int3
 1051e2f:	int3

