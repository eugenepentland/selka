
.tmp-rc/profile/cumulative-qbe-rc-n12:     file format elf64-x86-64


Disassembly of section .text:

00000000010137c0 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531>:
 10137c0:	f3 0f 1e fa          	endbr64
 10137c4:	55                   	push   %rbp
 10137c5:	48 89 e5             	mov    %rsp,%rbp
 10137c8:	48 81 ec 68 02 00 00 	sub    $0x268,%rsp
 10137cf:	53                   	push   %rbx
 10137d0:	41 54                	push   %r12
 10137d2:	41 55                	push   %r13
 10137d4:	41 56                	push   %r14
 10137d6:	41 57                	push   %r15
 10137d8:	48 8b 47 40          	mov    0x40(%rdi),%rax
 10137dc:	48 8d 4d b8          	lea    -0x48(%rbp),%rcx
 10137e0:	48 39 c1             	cmp    %rax,%rcx
 10137e3:	0f 82 bd 24 00 00    	jb     1015ca6 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x24e6>
 10137e9:	48 89 b5 20 ff ff ff 	mov    %rsi,-0xe0(%rbp)
 10137f0:	48 89 fb             	mov    %rdi,%rbx
 10137f3:	e8 68 87 00 00       	call   101bf60 <myl_qbe_heap>
 10137f8:	48 89 df             	mov    %rbx,%rdi
 10137fb:	49 89 c4             	mov    %rax,%r12
 10137fe:	ba 30 00 00 00       	mov    $0x30,%edx
 1013803:	be 00 00 00 00       	mov    $0x0,%esi
 1013808:	48 89 fb             	mov    %rdi,%rbx
 101380b:	48 8d bd b0 fe ff ff 	lea    -0x150(%rbp),%rdi
 1013812:	e8 69 82 01 00       	call   102ba80 <compiler_rt.fastMemset>
 1013817:	48 89 df             	mov    %rbx,%rdi
 101381a:	ba c0 00 00 00       	mov    $0xc0,%edx
 101381f:	be 00 00 00 00       	mov    $0x0,%esi
 1013824:	48 89 fb             	mov    %rdi,%rbx
 1013827:	48 8d bd f0 fd ff ff 	lea    -0x210(%rbp),%rdi
 101382e:	e8 4d 82 01 00       	call   102ba80 <compiler_rt.fastMemset>
 1013833:	48 89 df             	mov    %rbx,%rdi
 1013836:	48 8d 05 eb 0c ff ff 	lea    -0xf315(%rip),%rax        # 1004528 <myl_t_1a91deb3742283487d66c3b500f6effd7ef1170e6d4b4368fe9ec3c3f0354fda>
 101383d:	48 89 85 f0 fd ff ff 	mov    %rax,-0x210(%rbp)
 1013844:	48 8d 85 20 ff ff ff 	lea    -0xe0(%rbp),%rax
 101384b:	48 89 85 f8 fd ff ff 	mov    %rax,-0x208(%rbp)
 1013852:	48 8d 85 b0 fe ff ff 	lea    -0x150(%rbp),%rax
 1013859:	48 89 85 00 fe ff ff 	mov    %rax,-0x200(%rbp)
 1013860:	c7 85 08 fe ff ff 00 	movl   $0x0,-0x1f8(%rbp)
 1013867:	00 00 00 
 101386a:	48 8d 85 f0 fd ff ff 	lea    -0x210(%rbp),%rax
 1013871:	48 89 c6             	mov    %rax,%rsi
 1013874:	48 83 c6 20          	add    $0x20,%rsi
 1013878:	48 89 75 c8          	mov    %rsi,-0x38(%rbp)
 101387c:	48 8d 05 15 0e ff ff 	lea    -0xf1eb(%rip),%rax        # 1004698 <myl_t_385cfdbc00ec32031699460779c15099b2bba3cad0e440fffb08e10df0acb9e1>
 1013883:	48 89 85 10 fe ff ff 	mov    %rax,-0x1f0(%rbp)
 101388a:	48 8d 85 e0 fe ff ff 	lea    -0x120(%rbp),%rax
 1013891:	48 89 85 18 fe ff ff 	mov    %rax,-0x1e8(%rbp)
 1013898:	48 8d 85 b0 fe ff ff 	lea    -0x150(%rbp),%rax
 101389f:	49 89 c6             	mov    %rax,%r14
 10138a2:	49 83 c6 08          	add    $0x8,%r14
 10138a6:	4c 89 75 e8          	mov    %r14,-0x18(%rbp)
 10138aa:	4c 89 b5 20 fe ff ff 	mov    %r14,-0x1e0(%rbp)
 10138b1:	c7 85 28 fe ff ff 00 	movl   $0x0,-0x1d8(%rbp)
 10138b8:	00 00 00 
 10138bb:	48 8d 85 f0 fd ff ff 	lea    -0x210(%rbp),%rax
 10138c2:	48 89 c6             	mov    %rax,%rsi
 10138c5:	48 83 c6 40          	add    $0x40,%rsi
 10138c9:	48 89 75 c0          	mov    %rsi,-0x40(%rbp)
 10138cd:	48 8d 05 c4 0d ff ff 	lea    -0xf23c(%rip),%rax        # 1004698 <myl_t_385cfdbc00ec32031699460779c15099b2bba3cad0e440fffb08e10df0acb9e1>
 10138d4:	48 89 85 30 fe ff ff 	mov    %rax,-0x1d0(%rbp)
 10138db:	48 8d 85 f0 fe ff ff 	lea    -0x110(%rbp),%rax
 10138e2:	48 89 85 38 fe ff ff 	mov    %rax,-0x1c8(%rbp)
 10138e9:	48 8d 85 b0 fe ff ff 	lea    -0x150(%rbp),%rax
 10138f0:	48 83 c0 10          	add    $0x10,%rax
 10138f4:	48 89 45 d8          	mov    %rax,-0x28(%rbp)
 10138f8:	48 89 85 40 fe ff ff 	mov    %rax,-0x1c0(%rbp)
 10138ff:	c7 85 48 fe ff ff 00 	movl   $0x0,-0x1b8(%rbp)
 1013906:	00 00 00 
 1013909:	48 8d 05 88 0d ff ff 	lea    -0xf278(%rip),%rax        # 1004698 <myl_t_385cfdbc00ec32031699460779c15099b2bba3cad0e440fffb08e10df0acb9e1>
 1013910:	48 89 85 50 fe ff ff 	mov    %rax,-0x1b0(%rbp)
 1013917:	48 8d 85 00 ff ff ff 	lea    -0x100(%rbp),%rax
 101391e:	48 89 85 58 fe ff ff 	mov    %rax,-0x1a8(%rbp)
 1013925:	48 8d 85 b0 fe ff ff 	lea    -0x150(%rbp),%rax
 101392c:	48 83 c0 18          	add    $0x18,%rax
 1013930:	48 89 85 60 fe ff ff 	mov    %rax,-0x1a0(%rbp)
 1013937:	c7 85 68 fe ff ff 00 	movl   $0x0,-0x198(%rbp)
 101393e:	00 00 00 
 1013941:	48 8d 05 50 0d ff ff 	lea    -0xf2b0(%rip),%rax        # 1004698 <myl_t_385cfdbc00ec32031699460779c15099b2bba3cad0e440fffb08e10df0acb9e1>
 1013948:	48 89 85 70 fe ff ff 	mov    %rax,-0x190(%rbp)
 101394f:	48 8d 85 08 ff ff ff 	lea    -0xf8(%rbp),%rax
 1013956:	48 89 85 78 fe ff ff 	mov    %rax,-0x188(%rbp)
 101395d:	48 8d 85 b0 fe ff ff 	lea    -0x150(%rbp),%rax
 1013964:	48 89 c3             	mov    %rax,%rbx
 1013967:	48 83 c3 20          	add    $0x20,%rbx
 101396b:	48 89 9d 80 fe ff ff 	mov    %rbx,-0x180(%rbp)
 1013972:	c7 85 88 fe ff ff 00 	movl   $0x0,-0x178(%rbp)
 1013979:	00 00 00 
 101397c:	48 8d 05 15 0d ff ff 	lea    -0xf2eb(%rip),%rax        # 1004698 <myl_t_385cfdbc00ec32031699460779c15099b2bba3cad0e440fffb08e10df0acb9e1>
 1013983:	48 89 85 90 fe ff ff 	mov    %rax,-0x170(%rbp)
 101398a:	48 8d 85 18 ff ff ff 	lea    -0xe8(%rbp),%rax
 1013991:	48 89 85 98 fe ff ff 	mov    %rax,-0x168(%rbp)
 1013998:	48 8d 85 b0 fe ff ff 	lea    -0x150(%rbp),%rax
 101399f:	49 89 c5             	mov    %rax,%r13
 10139a2:	49 83 c5 28          	add    $0x28,%r13
 10139a6:	4c 89 ad a0 fe ff ff 	mov    %r13,-0x160(%rbp)
 10139ad:	c7 85 a8 fe ff ff 00 	movl   $0x0,-0x158(%rbp)
 10139b4:	00 00 00 
 10139b7:	b9 06 00 00 00       	mov    $0x6,%ecx
 10139bc:	48 8d 95 f0 fd ff ff 	lea    -0x210(%rbp),%rdx
 10139c3:	48 8d b5 d0 fd ff ff 	lea    -0x230(%rbp),%rsi
 10139ca:	49 89 ff             	mov    %rdi,%r15
 10139cd:	e8 7e 7c 00 00       	call   101b650 <myl_qbe_rc_frame_enter>
 10139d2:	4c 89 ff             	mov    %r15,%rdi
 10139d5:	49 89 ff             	mov    %rdi,%r15
 10139d8:	e8 53 83 00 00       	call   101bd30 <myl_qbe_root_mark>
 10139dd:	4c 89 ff             	mov    %r15,%rdi
 10139e0:	48 89 45 d0          	mov    %rax,-0x30(%rbp)
 10139e4:	48 8b 95 20 ff ff ff 	mov    -0xe0(%rbp),%rdx
 10139eb:	48 89 95 28 ff ff ff 	mov    %rdx,-0xd8(%rbp)
 10139f2:	48 c7 85 30 ff ff ff 	movq   $0x0,-0xd0(%rbp)
 10139f9:	00 00 00 00 
 10139fd:	48 83 fa 00          	cmp    $0x0,%rdx
 1013a01:	0f 94 c0             	sete   %al
 1013a04:	48 0f b6 c0          	movzbq %al,%rax
 1013a08:	48 89 85 28 ff ff ff 	mov    %rax,-0xd8(%rbp)
 1013a0f:	83 f8 00             	cmp    $0x0,%eax
 1013a12:	0f 85 68 18 00 00    	jne    1015280 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1ac0>
 1013a18:	48 89 95 28 ff ff ff 	mov    %rdx,-0xd8(%rbp)
 1013a1f:	48 c7 85 30 ff ff ff 	movq   $0x1,-0xd0(%rbp)
 1013a26:	01 00 00 00 
 1013a2a:	48 b8 01 00 00 00 00 	movabs $0x8000000000000001,%rax
 1013a31:	00 00 80 
 1013a34:	48 39 c2             	cmp    %rax,%rdx
 1013a37:	0f 8c 2c 18 00 00    	jl     1015269 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1aa9>
 1013a3d:	48 89 d6             	mov    %rdx,%rsi
 1013a40:	48 83 ee 01          	sub    $0x1,%rsi
 1013a44:	48 89 b5 28 ff ff ff 	mov    %rsi,-0xd8(%rbp)
 1013a4b:	49 89 ff             	mov    %rdi,%r15
 1013a4e:	e8 6d fd ff ff       	call   10137c0 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531>
 1013a53:	4c 89 ff             	mov    %r15,%rdi
 1013a56:	48 89 c1             	mov    %rax,%rcx
 1013a59:	48 89 d0             	mov    %rdx,%rax
 1013a5c:	48 89 8d a0 fd ff ff 	mov    %rcx,-0x260(%rbp)
 1013a63:	48 89 85 a8 fd ff ff 	mov    %rax,-0x258(%rbp)
 1013a6a:	48 8d 85 a0 fd ff ff 	lea    -0x260(%rbp),%rax
 1013a71:	48 89 85 28 ff ff ff 	mov    %rax,-0xd8(%rbp)
 1013a78:	48 8b 85 a0 fd ff ff 	mov    -0x260(%rbp),%rax
 1013a7f:	48 89 85 08 ff ff ff 	mov    %rax,-0xf8(%rbp)
 1013a86:	48 8b 85 a8 fd ff ff 	mov    -0x258(%rbp),%rax
 1013a8d:	48 89 85 10 ff ff ff 	mov    %rax,-0xf0(%rbp)
 1013a94:	48 8d 05 85 c5 01 00 	lea    0x1c585(%rip),%rax        # 1030020 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 1013a9b:	48 89 85 70 fe ff ff 	mov    %rax,-0x190(%rbp)
 1013aa2:	48 8d 85 08 ff ff ff 	lea    -0xf8(%rbp),%rax
 1013aa9:	48 89 85 78 fe ff ff 	mov    %rax,-0x188(%rbp)
 1013ab0:	48 89 9d 80 fe ff ff 	mov    %rbx,-0x180(%rbp)
 1013ab7:	c7 85 88 fe ff ff 02 	movl   $0x2,-0x178(%rbp)
 1013abe:	00 00 00 
 1013ac1:	c7 85 d0 fe ff ff 01 	movl   $0x1,-0x130(%rbp)
 1013ac8:	00 00 00 
 1013acb:	48 8b 85 08 ff ff ff 	mov    -0xf8(%rbp),%rax
 1013ad2:	48 89 85 e0 fe ff ff 	mov    %rax,-0x120(%rbp)
 1013ad9:	48 8b 85 10 ff ff ff 	mov    -0xf0(%rbp),%rax
 1013ae0:	48 89 85 e8 fe ff ff 	mov    %rax,-0x118(%rbp)
 1013ae7:	48 8d 05 32 c5 01 00 	lea    0x1c532(%rip),%rax        # 1030020 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 1013aee:	48 89 85 10 fe ff ff 	mov    %rax,-0x1f0(%rbp)
 1013af5:	48 8d 85 e0 fe ff ff 	lea    -0x120(%rbp),%rax
 1013afc:	48 89 85 18 fe ff ff 	mov    %rax,-0x1e8(%rbp)
 1013b03:	4c 89 b5 20 fe ff ff 	mov    %r14,-0x1e0(%rbp)
 1013b0a:	c7 85 28 fe ff ff 02 	movl   $0x2,-0x1d8(%rbp)
 1013b11:	00 00 00 
 1013b14:	c7 85 d0 fe ff ff 00 	movl   $0x0,-0x130(%rbp)
 1013b1b:	00 00 00 
 1013b1e:	c7 85 b8 fe ff ff 01 	movl   $0x1,-0x148(%rbp)
 1013b25:	00 00 00 
 1013b28:	48 8d 85 e0 fe ff ff 	lea    -0x120(%rbp),%rax
 1013b2f:	48 89 85 28 ff ff ff 	mov    %rax,-0xd8(%rbp)
 1013b36:	49 8b 44 24 10       	mov    0x10(%r12),%rax
 1013b3b:	48 89 85 38 ff ff ff 	mov    %rax,-0xc8(%rbp)
 1013b42:	48 8d 85 e0 fe ff ff 	lea    -0x120(%rbp),%rax
 1013b49:	48 89 85 40 ff ff ff 	mov    %rax,-0xc0(%rbp)
 1013b50:	48 8d 05 c9 c4 01 00 	lea    0x1c4c9(%rip),%rax        # 1030020 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 1013b57:	48 89 85 48 ff ff ff 	mov    %rax,-0xb8(%rbp)
 1013b5e:	48 8d 85 38 ff ff ff 	lea    -0xc8(%rbp),%rax
 1013b65:	49 89 44 24 10       	mov    %rax,0x10(%r12)
 1013b6a:	ba 01 00 00 00       	mov    $0x1,%edx
 1013b6f:	48 8d 35 9a c1 01 00 	lea    0x1c19a(%rip),%rsi        # 102fd10 <myl_t_1e414bd82e4b50b54939760a2d591f88da97e2f1c8252dbd7dcbc73438e46afb_body>
 1013b76:	49 89 fe             	mov    %rdi,%r14
 1013b79:	4c 89 e7             	mov    %r12,%rdi
 1013b7c:	e8 bf ca 00 00       	call   1020640 <myl_native_heap_alloc>
 1013b81:	4c 89 f7             	mov    %r14,%rdi
 1013b84:	48 89 45 f0          	mov    %rax,-0x10(%rbp)
 1013b88:	83 f8 00             	cmp    $0x0,%eax
 1013b8b:	75 07                	jne    1013b94 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x3d4>
 1013b8d:	e8 2e 81 00 00       	call   101bcc0 <myl_qbe_fail_allocation>
 1013b92:	0f 0b                	ud2
 1013b94:	48 89 85 18 ff ff ff 	mov    %rax,-0xe8(%rbp)
 1013b9b:	48 8d 05 de c1 01 00 	lea    0x1c1de(%rip),%rax        # 102fd80 <myl_t_1e414bd82e4b50b54939760a2d591f88da97e2f1c8252dbd7dcbc73438e46afb>
 1013ba2:	48 89 85 90 fe ff ff 	mov    %rax,-0x170(%rbp)
 1013ba9:	48 8d 85 18 ff ff ff 	lea    -0xe8(%rbp),%rax
 1013bb0:	48 89 85 98 fe ff ff 	mov    %rax,-0x168(%rbp)
 1013bb7:	4c 89 ad a0 fe ff ff 	mov    %r13,-0x160(%rbp)
 1013bbe:	c7 85 a8 fe ff ff 02 	movl   $0x2,-0x158(%rbp)
 1013bc5:	00 00 00 
 1013bc8:	c7 85 a8 fe ff ff 04 	movl   $0x4,-0x158(%rbp)
 1013bcf:	00 00 00 
 1013bd2:	c7 85 d8 fe ff ff 01 	movl   $0x1,-0x128(%rbp)
 1013bd9:	00 00 00 
 1013bdc:	49 89 fe             	mov    %rdi,%r14
 1013bdf:	e8 bc a6 00 00       	call   101e2a0 <myl_qbe_region_mark>
 1013be4:	4c 89 f7             	mov    %r14,%rdi
 1013be7:	4c 8b bd 28 ff ff ff 	mov    -0xd8(%rbp),%r15
 1013bee:	8b 85 b8 fe ff ff    	mov    -0x148(%rbp),%eax
 1013bf4:	83 f8 00             	cmp    $0x0,%eax
 1013bf7:	0f 85 a6 00 00 00    	jne    1013ca3 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x4e3>
 1013bfd:	49 89 fe             	mov    %rdi,%r14
 1013c00:	e8 9b a6 00 00       	call   101e2a0 <myl_qbe_region_mark>
 1013c05:	4c 89 f9             	mov    %r15,%rcx
 1013c08:	4c 89 f7             	mov    %r14,%rdi
 1013c0b:	49 89 c0             	mov    %rax,%r8
 1013c0e:	4c 8b 75 e8          	mov    -0x18(%rbp),%r14
 1013c12:	49 89 cf             	mov    %rcx,%r15
 1013c15:	48 8d 95 08 ff ff ff 	lea    -0xf8(%rbp),%rdx
 1013c1c:	48 8d 35 fd c3 01 00 	lea    0x1c3fd(%rip),%rsi        # 1030020 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 1013c23:	49 89 ff             	mov    %rdi,%r15
 1013c26:	4c 89 e7             	mov    %r12,%rdi
 1013c29:	e8 f2 75 01 00       	call   102b220 <myl_rc_native_copy>
 1013c2e:	4c 89 ff             	mov    %r15,%rdi
 1013c31:	89 c1                	mov    %eax,%ecx
 1013c33:	48 8b 45 f0          	mov    -0x10(%rbp),%rax
 1013c37:	4c 8b 7d d0          	mov    -0x30(%rbp),%r15
 1013c3b:	48 8b 75 c8          	mov    -0x38(%rbp),%rsi
 1013c3f:	83 f9 00             	cmp    $0x0,%ecx
 1013c42:	75 23                	jne    1013c67 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x4a7>
 1013c44:	48 89 fb             	mov    %rdi,%rbx
 1013c47:	4c 89 e7             	mov    %r12,%rdi
 1013c4a:	e8 71 02 01 00       	call   1023ec0 <myl_rc_take_failure>
 1013c4f:	48 89 df             	mov    %rbx,%rdi
 1013c52:	89 c6                	mov    %eax,%esi
 1013c54:	48 89 fb             	mov    %rdi,%rbx
 1013c57:	e8 04 79 00 00       	call   101b560 <myl_qbe_rc_status>
 1013c5c:	48 89 df             	mov    %rbx,%rdi
 1013c5f:	4c 89 fb             	mov    %r15,%rbx
 1013c62:	e9 74 1f 00 00       	jmp    1015bdb <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x241b>
 1013c67:	48 8d 0d b2 c3 01 00 	lea    0x1c3b2(%rip),%rcx        # 1030020 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 1013c6e:	48 89 8d 70 fe ff ff 	mov    %rcx,-0x190(%rbp)
 1013c75:	48 8d 8d 08 ff ff ff 	lea    -0xf8(%rbp),%rcx
 1013c7c:	48 89 8d 78 fe ff ff 	mov    %rcx,-0x188(%rbp)
 1013c83:	48 89 9d 80 fe ff ff 	mov    %rbx,-0x180(%rbp)
 1013c8a:	c7 85 88 fe ff ff 02 	movl   $0x2,-0x178(%rbp)
 1013c91:	00 00 00 
 1013c94:	c7 85 d0 fe ff ff 01 	movl   $0x1,-0x130(%rbp)
 1013c9b:	00 00 00 
 1013c9e:	e9 5d 01 00 00       	jmp    1013e00 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x640>
 1013ca3:	49 89 fe             	mov    %rdi,%r14
 1013ca6:	e8 f5 a5 00 00       	call   101e2a0 <myl_qbe_region_mark>
 1013cab:	4c 89 f9             	mov    %r15,%rcx
 1013cae:	4c 89 f7             	mov    %r14,%rdi
 1013cb1:	49 89 c0             	mov    %rax,%r8
 1013cb4:	4c 8b 75 e8          	mov    -0x18(%rbp),%r14
 1013cb8:	48 8d 85 08 ff ff ff 	lea    -0xf8(%rbp),%rax
 1013cbf:	48 f7 d8             	neg    %rax
 1013cc2:	48 01 c8             	add    %rcx,%rax
 1013cc5:	48 8d 95 08 ff ff ff 	lea    -0xf8(%rbp),%rdx
 1013ccc:	48 29 ca             	sub    %rcx,%rdx
 1013ccf:	48 83 f8 10          	cmp    $0x10,%rax
 1013cd3:	0f 92 c0             	setb   %al
 1013cd6:	0f b6 c0             	movzbl %al,%eax
 1013cd9:	48 83 fa 10          	cmp    $0x10,%rdx
 1013cdd:	0f 92 c2             	setb   %dl
 1013ce0:	0f b6 d2             	movzbl %dl,%edx
 1013ce3:	09 d0                	or     %edx,%eax
 1013ce5:	0f 85 82 00 00 00    	jne    1013d6d <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x5ad>
 1013ceb:	48 8b 01             	mov    (%rcx),%rax
 1013cee:	48 83 f8 00          	cmp    $0x0,%rax
 1013cf2:	74 1a                	je     1013d0e <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x54e>
 1013cf4:	48 83 e8 10          	sub    $0x10,%rax
 1013cf8:	48 8b 00             	mov    (%rax),%rax
 1013cfb:	48 ba 01 00 00 00 00 	movabs $0x5000000000000001,%rdx
 1013d02:	00 00 50 
 1013d05:	48 21 d0             	and    %rdx,%rax
 1013d08:	48 83 f8 00          	cmp    $0x0,%rax
 1013d0c:	75 5f                	jne    1013d6d <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x5ad>
 1013d0e:	48 8b 41 08          	mov    0x8(%rcx),%rax
 1013d12:	48 83 f8 00          	cmp    $0x0,%rax
 1013d16:	74 1a                	je     1013d32 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x572>
 1013d18:	48 83 e8 10          	sub    $0x10,%rax
 1013d1c:	48 8b 00             	mov    (%rax),%rax
 1013d1f:	48 ba 01 00 00 00 00 	movabs $0x5000000000000001,%rdx
 1013d26:	00 00 50 
 1013d29:	48 21 d0             	and    %rdx,%rax
 1013d2c:	48 83 f8 00          	cmp    $0x0,%rax
 1013d30:	75 3b                	jne    1013d6d <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x5ad>
 1013d32:	48 8b 01             	mov    (%rcx),%rax
 1013d35:	48 89 85 08 ff ff ff 	mov    %rax,-0xf8(%rbp)
 1013d3c:	48 8b 41 08          	mov    0x8(%rcx),%rax
 1013d40:	48 89 85 10 ff ff ff 	mov    %rax,-0xf0(%rbp)
 1013d47:	ba 10 00 00 00       	mov    $0x10,%edx
 1013d4c:	be 00 00 00 00       	mov    $0x0,%esi
 1013d51:	49 89 ff             	mov    %rdi,%r15
 1013d54:	48 89 cf             	mov    %rcx,%rdi
 1013d57:	e8 24 7d 01 00       	call   102ba80 <compiler_rt.fastMemset>
 1013d5c:	4c 89 ff             	mov    %r15,%rdi
 1013d5f:	48 8b 45 f0          	mov    -0x10(%rbp),%rax
 1013d63:	4c 8b 7d d0          	mov    -0x30(%rbp),%r15
 1013d67:	48 8b 75 c8          	mov    -0x38(%rbp),%rsi
 1013d6b:	eb 52                	jmp    1013dbf <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x5ff>
 1013d6d:	48 8d 95 08 ff ff ff 	lea    -0xf8(%rbp),%rdx
 1013d74:	48 8d 35 a5 c2 01 00 	lea    0x1c2a5(%rip),%rsi        # 1030020 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 1013d7b:	49 89 ff             	mov    %rdi,%r15
 1013d7e:	4c 89 e7             	mov    %r12,%rdi
 1013d81:	e8 5a 79 01 00       	call   102b6e0 <myl_rc_native_take>
 1013d86:	4c 89 ff             	mov    %r15,%rdi
 1013d89:	89 c1                	mov    %eax,%ecx
 1013d8b:	48 8b 45 f0          	mov    -0x10(%rbp),%rax
 1013d8f:	4c 8b 7d d0          	mov    -0x30(%rbp),%r15
 1013d93:	48 8b 75 c8          	mov    -0x38(%rbp),%rsi
 1013d97:	83 f9 00             	cmp    $0x0,%ecx
 1013d9a:	75 23                	jne    1013dbf <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x5ff>
 1013d9c:	48 89 fb             	mov    %rdi,%rbx
 1013d9f:	4c 89 e7             	mov    %r12,%rdi
 1013da2:	e8 19 01 01 00       	call   1023ec0 <myl_rc_take_failure>
 1013da7:	48 89 df             	mov    %rbx,%rdi
 1013daa:	89 c6                	mov    %eax,%esi
 1013dac:	48 89 fb             	mov    %rdi,%rbx
 1013daf:	e8 ac 77 00 00       	call   101b560 <myl_qbe_rc_status>
 1013db4:	48 89 df             	mov    %rbx,%rdi
 1013db7:	4c 89 fb             	mov    %r15,%rbx
 1013dba:	e9 1c 1e 00 00       	jmp    1015bdb <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x241b>
 1013dbf:	c7 85 b8 fe ff ff 00 	movl   $0x0,-0x148(%rbp)
 1013dc6:	00 00 00 
 1013dc9:	48 8d 0d 50 c2 01 00 	lea    0x1c250(%rip),%rcx        # 1030020 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 1013dd0:	48 89 8d 70 fe ff ff 	mov    %rcx,-0x190(%rbp)
 1013dd7:	48 8d 8d 08 ff ff ff 	lea    -0xf8(%rbp),%rcx
 1013dde:	48 89 8d 78 fe ff ff 	mov    %rcx,-0x188(%rbp)
 1013de5:	48 89 9d 80 fe ff ff 	mov    %rbx,-0x180(%rbp)
 1013dec:	c7 85 88 fe ff ff 02 	movl   $0x2,-0x178(%rbp)
 1013df3:	00 00 00 
 1013df6:	c7 85 d0 fe ff ff 01 	movl   $0x1,-0x130(%rbp)
 1013dfd:	00 00 00 
 1013e00:	48 8b 8d 08 ff ff ff 	mov    -0xf8(%rbp),%rcx
 1013e07:	48 89 08             	mov    %rcx,(%rax)
 1013e0a:	48 8b 8d 10 ff ff ff 	mov    -0xf0(%rbp),%rcx
 1013e11:	48 89 48 08          	mov    %rcx,0x8(%rax)
 1013e15:	c7 85 d0 fe ff ff 00 	movl   $0x0,-0x130(%rbp)
 1013e1c:	00 00 00 
 1013e1f:	48 89 85 28 ff ff ff 	mov    %rax,-0xd8(%rbp)
 1013e26:	c7 85 d8 fe ff ff 00 	movl   $0x0,-0x128(%rbp)
 1013e2d:	00 00 00 
 1013e30:	48 8b 85 28 ff ff ff 	mov    -0xd8(%rbp),%rax
 1013e37:	48 89 85 08 ff ff ff 	mov    %rax,-0xf8(%rbp)
 1013e3e:	48 8d 05 3b bf 01 00 	lea    0x1bf3b(%rip),%rax        # 102fd80 <myl_t_1e414bd82e4b50b54939760a2d591f88da97e2f1c8252dbd7dcbc73438e46afb>
 1013e45:	48 89 85 70 fe ff ff 	mov    %rax,-0x190(%rbp)
 1013e4c:	48 8d 85 08 ff ff ff 	lea    -0xf8(%rbp),%rax
 1013e53:	48 89 85 78 fe ff ff 	mov    %rax,-0x188(%rbp)
 1013e5a:	48 89 9d 80 fe ff ff 	mov    %rbx,-0x180(%rbp)
 1013e61:	c7 85 88 fe ff ff 02 	movl   $0x2,-0x178(%rbp)
 1013e68:	00 00 00 
 1013e6b:	c7 85 d0 fe ff ff 01 	movl   $0x1,-0x130(%rbp)
 1013e72:	00 00 00 
 1013e75:	8b 85 b8 fe ff ff    	mov    -0x148(%rbp),%eax
 1013e7b:	83 f8 00             	cmp    $0x0,%eax
 1013e7e:	74 0f                	je     1013e8f <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x6cf>
 1013e80:	49 89 ff             	mov    %rdi,%r15
 1013e83:	e8 b8 78 00 00       	call   101b740 <myl_qbe_rc_slot_drop>
 1013e88:	4c 89 ff             	mov    %r15,%rdi
 1013e8b:	4c 8b 7d d0          	mov    -0x30(%rbp),%r15
 1013e8f:	48 8b 85 08 ff ff ff 	mov    -0xf8(%rbp),%rax
 1013e96:	48 89 85 e0 fe ff ff 	mov    %rax,-0x120(%rbp)
 1013e9d:	48 8d 05 dc be 01 00 	lea    0x1bedc(%rip),%rax        # 102fd80 <myl_t_1e414bd82e4b50b54939760a2d591f88da97e2f1c8252dbd7dcbc73438e46afb>
 1013ea4:	48 89 85 10 fe ff ff 	mov    %rax,-0x1f0(%rbp)
 1013eab:	48 8d 85 e0 fe ff ff 	lea    -0x120(%rbp),%rax
 1013eb2:	48 89 85 18 fe ff ff 	mov    %rax,-0x1e8(%rbp)
 1013eb9:	4c 89 b5 20 fe ff ff 	mov    %r14,-0x1e0(%rbp)
 1013ec0:	c7 85 28 fe ff ff 02 	movl   $0x2,-0x1d8(%rbp)
 1013ec7:	00 00 00 
 1013eca:	c7 85 d0 fe ff ff 00 	movl   $0x0,-0x130(%rbp)
 1013ed1:	00 00 00 
 1013ed4:	c7 85 b8 fe ff ff 01 	movl   $0x1,-0x148(%rbp)
 1013edb:	00 00 00 
 1013ede:	48 8b 85 e0 fe ff ff 	mov    -0x120(%rbp),%rax
 1013ee5:	48 89 85 28 ff ff ff 	mov    %rax,-0xd8(%rbp)
 1013eec:	4d 89 7c 24 10       	mov    %r15,0x10(%r12)
 1013ef1:	ba 08 00 00 00       	mov    $0x8,%edx
 1013ef6:	be 00 00 00 00       	mov    $0x0,%esi
 1013efb:	49 89 ff             	mov    %rdi,%r15
 1013efe:	48 8d 7d 98          	lea    -0x68(%rbp),%rdi
 1013f02:	e8 79 7b 01 00       	call   102ba80 <compiler_rt.fastMemset>
 1013f07:	4c 89 ff             	mov    %r15,%rdi
 1013f0a:	48 8d 05 9f c0 01 00 	lea    0x1c09f(%rip),%rax        # 102ffb0 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 1013f11:	48 89 85 90 fe ff ff 	mov    %rax,-0x170(%rbp)
 1013f18:	48 8d 45 98          	lea    -0x68(%rbp),%rax
 1013f1c:	48 89 85 98 fe ff ff 	mov    %rax,-0x168(%rbp)
 1013f23:	4c 89 ad a0 fe ff ff 	mov    %r13,-0x160(%rbp)
 1013f2a:	c7 85 a8 fe ff ff 02 	movl   $0x2,-0x158(%rbp)
 1013f31:	00 00 00 
 1013f34:	c7 85 d8 fe ff ff 01 	movl   $0x1,-0x128(%rbp)
 1013f3b:	00 00 00 
 1013f3e:	49 89 ff             	mov    %rdi,%r15
 1013f41:	e8 5a a3 00 00       	call   101e2a0 <myl_qbe_region_mark>
 1013f46:	4c 89 ff             	mov    %r15,%rdi
 1013f49:	8b 85 b8 fe ff ff    	mov    -0x148(%rbp),%eax
 1013f4f:	83 f8 00             	cmp    $0x0,%eax
 1013f52:	0f 85 9d 00 00 00    	jne    1013ff5 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x835>
 1013f58:	49 89 ff             	mov    %rdi,%r15
 1013f5b:	e8 40 a3 00 00       	call   101e2a0 <myl_qbe_region_mark>
 1013f60:	4c 89 ff             	mov    %r15,%rdi
 1013f63:	49 89 c0             	mov    %rax,%r8
 1013f66:	48 8d 8d 28 ff ff ff 	lea    -0xd8(%rbp),%rcx
 1013f6d:	48 8d 95 08 ff ff ff 	lea    -0xf8(%rbp),%rdx
 1013f74:	48 8d 35 05 be 01 00 	lea    0x1be05(%rip),%rsi        # 102fd80 <myl_t_1e414bd82e4b50b54939760a2d591f88da97e2f1c8252dbd7dcbc73438e46afb>
 1013f7b:	49 89 ff             	mov    %rdi,%r15
 1013f7e:	4c 89 e7             	mov    %r12,%rdi
 1013f81:	e8 9a 72 01 00       	call   102b220 <myl_rc_native_copy>
 1013f86:	4c 89 ff             	mov    %r15,%rdi
 1013f89:	4c 8b 7d d0          	mov    -0x30(%rbp),%r15
 1013f8d:	48 8b 75 c8          	mov    -0x38(%rbp),%rsi
 1013f91:	83 f8 00             	cmp    $0x0,%eax
 1013f94:	75 23                	jne    1013fb9 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x7f9>
 1013f96:	48 89 fb             	mov    %rdi,%rbx
 1013f99:	4c 89 e7             	mov    %r12,%rdi
 1013f9c:	e8 1f ff 00 00       	call   1023ec0 <myl_rc_take_failure>
 1013fa1:	48 89 df             	mov    %rbx,%rdi
 1013fa4:	89 c6                	mov    %eax,%esi
 1013fa6:	48 89 fb             	mov    %rdi,%rbx
 1013fa9:	e8 b2 75 00 00       	call   101b560 <myl_qbe_rc_status>
 1013fae:	48 89 df             	mov    %rbx,%rdi
 1013fb1:	4c 89 fb             	mov    %r15,%rbx
 1013fb4:	e9 22 1c 00 00       	jmp    1015bdb <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x241b>
 1013fb9:	48 8d 05 c0 bd 01 00 	lea    0x1bdc0(%rip),%rax        # 102fd80 <myl_t_1e414bd82e4b50b54939760a2d591f88da97e2f1c8252dbd7dcbc73438e46afb>
 1013fc0:	48 89 85 70 fe ff ff 	mov    %rax,-0x190(%rbp)
 1013fc7:	48 8d 85 08 ff ff ff 	lea    -0xf8(%rbp),%rax
 1013fce:	48 89 85 78 fe ff ff 	mov    %rax,-0x188(%rbp)
 1013fd5:	48 89 9d 80 fe ff ff 	mov    %rbx,-0x180(%rbp)
 1013fdc:	c7 85 88 fe ff ff 02 	movl   $0x2,-0x178(%rbp)
 1013fe3:	00 00 00 
 1013fe6:	c7 85 d0 fe ff ff 01 	movl   $0x1,-0x130(%rbp)
 1013fed:	00 00 00 
 1013ff0:	e9 37 01 00 00       	jmp    101412c <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x96c>
 1013ff5:	49 89 ff             	mov    %rdi,%r15
 1013ff8:	e8 a3 a2 00 00       	call   101e2a0 <myl_qbe_region_mark>
 1013ffd:	4c 89 ff             	mov    %r15,%rdi
 1014000:	49 89 c0             	mov    %rax,%r8
 1014003:	48 8d 8d 08 ff ff ff 	lea    -0xf8(%rbp),%rcx
 101400a:	48 8d 85 28 ff ff ff 	lea    -0xd8(%rbp),%rax
 1014011:	48 29 c8             	sub    %rcx,%rax
 1014014:	48 8d 95 28 ff ff ff 	lea    -0xd8(%rbp),%rdx
 101401b:	48 8d 8d 08 ff ff ff 	lea    -0xf8(%rbp),%rcx
 1014022:	48 29 d1             	sub    %rdx,%rcx
 1014025:	48 83 f8 08          	cmp    $0x8,%rax
 1014029:	0f 92 c0             	setb   %al
 101402c:	0f b6 c0             	movzbl %al,%eax
 101402f:	48 83 f9 08          	cmp    $0x8,%rcx
 1014033:	0f 92 c1             	setb   %cl
 1014036:	0f b6 c9             	movzbl %cl,%ecx
 1014039:	09 c8                	or     %ecx,%eax
 101403b:	75 5b                	jne    1014098 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x8d8>
 101403d:	48 8b 85 28 ff ff ff 	mov    -0xd8(%rbp),%rax
 1014044:	48 83 f8 00          	cmp    $0x0,%rax
 1014048:	74 1a                	je     1014064 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x8a4>
 101404a:	48 83 e8 10          	sub    $0x10,%rax
 101404e:	48 8b 00             	mov    (%rax),%rax
 1014051:	48 b9 01 00 00 00 00 	movabs $0x5000000000000001,%rcx
 1014058:	00 00 50 
 101405b:	48 21 c8             	and    %rcx,%rax
 101405e:	48 83 f8 00          	cmp    $0x0,%rax
 1014062:	75 34                	jne    1014098 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x8d8>
 1014064:	48 8b 85 28 ff ff ff 	mov    -0xd8(%rbp),%rax
 101406b:	48 89 85 08 ff ff ff 	mov    %rax,-0xf8(%rbp)
 1014072:	ba 08 00 00 00       	mov    $0x8,%edx
 1014077:	be 00 00 00 00       	mov    $0x0,%esi
 101407c:	49 89 ff             	mov    %rdi,%r15
 101407f:	48 8d bd 28 ff ff ff 	lea    -0xd8(%rbp),%rdi
 1014086:	e8 f5 79 01 00       	call   102ba80 <compiler_rt.fastMemset>
 101408b:	4c 89 ff             	mov    %r15,%rdi
 101408e:	4c 8b 7d d0          	mov    -0x30(%rbp),%r15
 1014092:	48 8b 75 c8          	mov    -0x38(%rbp),%rsi
 1014096:	eb 53                	jmp    10140eb <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x92b>
 1014098:	48 8d 8d 28 ff ff ff 	lea    -0xd8(%rbp),%rcx
 101409f:	48 8d 95 08 ff ff ff 	lea    -0xf8(%rbp),%rdx
 10140a6:	48 8d 35 d3 bc 01 00 	lea    0x1bcd3(%rip),%rsi        # 102fd80 <myl_t_1e414bd82e4b50b54939760a2d591f88da97e2f1c8252dbd7dcbc73438e46afb>
 10140ad:	49 89 ff             	mov    %rdi,%r15
 10140b0:	4c 89 e7             	mov    %r12,%rdi
 10140b3:	e8 28 76 01 00       	call   102b6e0 <myl_rc_native_take>
 10140b8:	4c 89 ff             	mov    %r15,%rdi
 10140bb:	4c 8b 7d d0          	mov    -0x30(%rbp),%r15
 10140bf:	48 8b 75 c8          	mov    -0x38(%rbp),%rsi
 10140c3:	83 f8 00             	cmp    $0x0,%eax
 10140c6:	75 23                	jne    10140eb <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x92b>
 10140c8:	48 89 fb             	mov    %rdi,%rbx
 10140cb:	4c 89 e7             	mov    %r12,%rdi
 10140ce:	e8 ed fd 00 00       	call   1023ec0 <myl_rc_take_failure>
 10140d3:	48 89 df             	mov    %rbx,%rdi
 10140d6:	89 c6                	mov    %eax,%esi
 10140d8:	48 89 fb             	mov    %rdi,%rbx
 10140db:	e8 80 74 00 00       	call   101b560 <myl_qbe_rc_status>
 10140e0:	48 89 df             	mov    %rbx,%rdi
 10140e3:	4c 89 fb             	mov    %r15,%rbx
 10140e6:	e9 f0 1a 00 00       	jmp    1015bdb <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x241b>
 10140eb:	c7 85 b8 fe ff ff 00 	movl   $0x0,-0x148(%rbp)
 10140f2:	00 00 00 
 10140f5:	48 8d 05 84 bc 01 00 	lea    0x1bc84(%rip),%rax        # 102fd80 <myl_t_1e414bd82e4b50b54939760a2d591f88da97e2f1c8252dbd7dcbc73438e46afb>
 10140fc:	48 89 85 70 fe ff ff 	mov    %rax,-0x190(%rbp)
 1014103:	48 8d 85 08 ff ff ff 	lea    -0xf8(%rbp),%rax
 101410a:	48 89 85 78 fe ff ff 	mov    %rax,-0x188(%rbp)
 1014111:	48 89 9d 80 fe ff ff 	mov    %rbx,-0x180(%rbp)
 1014118:	c7 85 88 fe ff ff 02 	movl   $0x2,-0x178(%rbp)
 101411f:	00 00 00 
 1014122:	c7 85 d0 fe ff ff 01 	movl   $0x1,-0x130(%rbp)
 1014129:	00 00 00 
 101412c:	48 8b 85 08 ff ff ff 	mov    -0xf8(%rbp),%rax
 1014133:	48 89 45 98          	mov    %rax,-0x68(%rbp)
 1014137:	c7 85 d0 fe ff ff 00 	movl   $0x0,-0x130(%rbp)
 101413e:	00 00 00 
 1014141:	48 8d 45 98          	lea    -0x68(%rbp),%rax
 1014145:	48 89 85 28 ff ff ff 	mov    %rax,-0xd8(%rbp)
 101414c:	c7 85 d8 fe ff ff 00 	movl   $0x0,-0x128(%rbp)
 1014153:	00 00 00 
 1014156:	48 8b 45 98          	mov    -0x68(%rbp),%rax
 101415a:	48 89 85 08 ff ff ff 	mov    %rax,-0xf8(%rbp)
 1014161:	48 8d 05 48 be 01 00 	lea    0x1be48(%rip),%rax        # 102ffb0 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 1014168:	48 89 85 70 fe ff ff 	mov    %rax,-0x190(%rbp)
 101416f:	48 8d 85 08 ff ff ff 	lea    -0xf8(%rbp),%rax
 1014176:	48 89 85 78 fe ff ff 	mov    %rax,-0x188(%rbp)
 101417d:	48 89 9d 80 fe ff ff 	mov    %rbx,-0x180(%rbp)
 1014184:	c7 85 88 fe ff ff 02 	movl   $0x2,-0x178(%rbp)
 101418b:	00 00 00 
 101418e:	c7 85 d0 fe ff ff 01 	movl   $0x1,-0x130(%rbp)
 1014195:	00 00 00 
 1014198:	8b 85 b8 fe ff ff    	mov    -0x148(%rbp),%eax
 101419e:	83 f8 00             	cmp    $0x0,%eax
 10141a1:	74 0f                	je     10141b2 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x9f2>
 10141a3:	49 89 ff             	mov    %rdi,%r15
 10141a6:	e8 95 75 00 00       	call   101b740 <myl_qbe_rc_slot_drop>
 10141ab:	4c 89 ff             	mov    %r15,%rdi
 10141ae:	4c 8b 7d d0          	mov    -0x30(%rbp),%r15
 10141b2:	48 8b 85 08 ff ff ff 	mov    -0xf8(%rbp),%rax
 10141b9:	48 89 85 e0 fe ff ff 	mov    %rax,-0x120(%rbp)
 10141c0:	48 8d 05 e9 bd 01 00 	lea    0x1bde9(%rip),%rax        # 102ffb0 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 10141c7:	48 89 85 10 fe ff ff 	mov    %rax,-0x1f0(%rbp)
 10141ce:	48 8d 85 e0 fe ff ff 	lea    -0x120(%rbp),%rax
 10141d5:	48 89 85 18 fe ff ff 	mov    %rax,-0x1e8(%rbp)
 10141dc:	4c 89 b5 20 fe ff ff 	mov    %r14,-0x1e0(%rbp)
 10141e3:	c7 85 28 fe ff ff 02 	movl   $0x2,-0x1d8(%rbp)
 10141ea:	00 00 00 
 10141ed:	c7 85 d0 fe ff ff 00 	movl   $0x0,-0x130(%rbp)
 10141f4:	00 00 00 
 10141f7:	c7 85 b8 fe ff ff 01 	movl   $0x1,-0x148(%rbp)
 10141fe:	00 00 00 
 1014201:	48 8d 85 e0 fe ff ff 	lea    -0x120(%rbp),%rax
 1014208:	48 89 85 28 ff ff ff 	mov    %rax,-0xd8(%rbp)
 101420f:	48 8b 95 20 ff ff ff 	mov    -0xe0(%rbp),%rdx
 1014216:	48 89 95 30 ff ff ff 	mov    %rdx,-0xd0(%rbp)
 101421d:	48 b8 01 00 00 00 00 	movabs $0x8000000000000001,%rax
 1014224:	00 00 80 
 1014227:	48 39 c2             	cmp    %rax,%rdx
 101422a:	0f 8c 22 10 00 00    	jl     1015252 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1a92>
 1014230:	48 89 d0             	mov    %rdx,%rax
 1014233:	48 83 e8 01          	sub    $0x1,%rax
 1014237:	48 89 85 30 ff ff ff 	mov    %rax,-0xd0(%rbp)
 101423e:	49 8b 44 24 10       	mov    0x10(%r12),%rax
 1014243:	48 89 85 38 ff ff ff 	mov    %rax,-0xc8(%rbp)
 101424a:	48 8d 85 e0 fe ff ff 	lea    -0x120(%rbp),%rax
 1014251:	48 89 85 40 ff ff ff 	mov    %rax,-0xc0(%rbp)
 1014258:	48 8d 05 51 bd 01 00 	lea    0x1bd51(%rip),%rax        # 102ffb0 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 101425f:	48 89 85 48 ff ff ff 	mov    %rax,-0xb8(%rbp)
 1014266:	48 8d 85 38 ff ff ff 	lea    -0xc8(%rbp),%rax
 101426d:	49 89 44 24 10       	mov    %rax,0x10(%r12)
 1014272:	48 8b b5 30 ff ff ff 	mov    -0xd0(%rbp),%rsi
 1014279:	49 89 fe             	mov    %rdi,%r14
 101427c:	e8 3f f5 ff ff       	call   10137c0 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531>
 1014281:	4c 89 f7             	mov    %r14,%rdi
 1014284:	48 89 d1             	mov    %rdx,%rcx
 1014287:	48 89 c2             	mov    %rax,%rdx
 101428a:	48 8b 45 d8          	mov    -0x28(%rbp),%rax
 101428e:	48 89 95 b0 fd ff ff 	mov    %rdx,-0x250(%rbp)
 1014295:	48 89 8d b8 fd ff ff 	mov    %rcx,-0x248(%rbp)
 101429c:	48 8d 8d b0 fd ff ff 	lea    -0x250(%rbp),%rcx
 10142a3:	48 89 8d 30 ff ff ff 	mov    %rcx,-0xd0(%rbp)
 10142aa:	4d 89 7c 24 10       	mov    %r15,0x10(%r12)
 10142af:	48 8b 8d 30 ff ff ff 	mov    -0xd0(%rbp),%rcx
 10142b6:	48 8b 11             	mov    (%rcx),%rdx
 10142b9:	48 89 95 08 ff ff ff 	mov    %rdx,-0xf8(%rbp)
 10142c0:	48 8b 49 08          	mov    0x8(%rcx),%rcx
 10142c4:	48 89 8d 10 ff ff ff 	mov    %rcx,-0xf0(%rbp)
 10142cb:	48 8d 0d 4e bd 01 00 	lea    0x1bd4e(%rip),%rcx        # 1030020 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 10142d2:	48 89 8d 70 fe ff ff 	mov    %rcx,-0x190(%rbp)
 10142d9:	48 8d 8d 08 ff ff ff 	lea    -0xf8(%rbp),%rcx
 10142e0:	48 89 8d 78 fe ff ff 	mov    %rcx,-0x188(%rbp)
 10142e7:	48 89 9d 80 fe ff ff 	mov    %rbx,-0x180(%rbp)
 10142ee:	c7 85 88 fe ff ff 02 	movl   $0x2,-0x178(%rbp)
 10142f5:	00 00 00 
 10142f8:	c7 85 d0 fe ff ff 01 	movl   $0x1,-0x130(%rbp)
 10142ff:	00 00 00 
 1014302:	48 8b 8d 08 ff ff ff 	mov    -0xf8(%rbp),%rcx
 1014309:	48 89 8d f0 fe ff ff 	mov    %rcx,-0x110(%rbp)
 1014310:	48 8b 8d 10 ff ff ff 	mov    -0xf0(%rbp),%rcx
 1014317:	48 89 8d f8 fe ff ff 	mov    %rcx,-0x108(%rbp)
 101431e:	48 8d 0d fb bc 01 00 	lea    0x1bcfb(%rip),%rcx        # 1030020 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 1014325:	48 89 8d 30 fe ff ff 	mov    %rcx,-0x1d0(%rbp)
 101432c:	48 8d 8d f0 fe ff ff 	lea    -0x110(%rbp),%rcx
 1014333:	48 89 8d 38 fe ff ff 	mov    %rcx,-0x1c8(%rbp)
 101433a:	48 89 85 40 fe ff ff 	mov    %rax,-0x1c0(%rbp)
 1014341:	c7 85 48 fe ff ff 02 	movl   $0x2,-0x1b8(%rbp)
 1014348:	00 00 00 
 101434b:	c7 85 d0 fe ff ff 00 	movl   $0x0,-0x130(%rbp)
 1014352:	00 00 00 
 1014355:	c7 85 c0 fe ff ff 01 	movl   $0x1,-0x140(%rbp)
 101435c:	00 00 00 
 101435f:	48 8d 85 f0 fe ff ff 	lea    -0x110(%rbp),%rax
 1014366:	48 89 85 30 ff ff ff 	mov    %rax,-0xd0(%rbp)
 101436d:	49 8b 4c 24 10       	mov    0x10(%r12),%rcx
 1014372:	48 8b 85 28 ff ff ff 	mov    -0xd8(%rbp),%rax
 1014379:	48 89 8d 38 ff ff ff 	mov    %rcx,-0xc8(%rbp)
 1014380:	48 89 85 40 ff ff ff 	mov    %rax,-0xc0(%rbp)
 1014387:	48 8d 05 22 bc 01 00 	lea    0x1bc22(%rip),%rax        # 102ffb0 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 101438e:	48 89 85 48 ff ff ff 	mov    %rax,-0xb8(%rbp)
 1014395:	48 8d 85 38 ff ff ff 	lea    -0xc8(%rbp),%rax
 101439c:	49 89 44 24 10       	mov    %rax,0x10(%r12)
 10143a1:	48 8b 85 30 ff ff ff 	mov    -0xd0(%rbp),%rax
 10143a8:	48 8d 8d 38 ff ff ff 	lea    -0xc8(%rbp),%rcx
 10143af:	48 89 8d 58 ff ff ff 	mov    %rcx,-0xa8(%rbp)
 10143b6:	48 89 85 60 ff ff ff 	mov    %rax,-0xa0(%rbp)
 10143bd:	48 8d 05 5c bc 01 00 	lea    0x1bc5c(%rip),%rax        # 1030020 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 10143c4:	48 89 85 68 ff ff ff 	mov    %rax,-0x98(%rbp)
 10143cb:	48 8d 85 58 ff ff ff 	lea    -0xa8(%rbp),%rax
 10143d2:	49 89 44 24 10       	mov    %rax,0x10(%r12)
 10143d7:	ba 01 00 00 00       	mov    $0x1,%edx
 10143dc:	48 8d 35 2d b9 01 00 	lea    0x1b92d(%rip),%rsi        # 102fd10 <myl_t_1e414bd82e4b50b54939760a2d591f88da97e2f1c8252dbd7dcbc73438e46afb_body>
 10143e3:	49 89 fe             	mov    %rdi,%r14
 10143e6:	4c 89 e7             	mov    %r12,%rdi
 10143e9:	e8 52 c2 00 00       	call   1020640 <myl_native_heap_alloc>
 10143ee:	4c 89 f7             	mov    %r14,%rdi
 10143f1:	48 89 c1             	mov    %rax,%rcx
 10143f4:	48 89 4d e0          	mov    %rcx,-0x20(%rbp)
 10143f8:	83 f9 00             	cmp    $0x0,%ecx
 10143fb:	75 07                	jne    1014404 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xc44>
 10143fd:	e8 be 78 00 00       	call   101bcc0 <myl_qbe_fail_allocation>
 1014402:	0f 0b                	ud2
 1014404:	48 89 8d 18 ff ff ff 	mov    %rcx,-0xe8(%rbp)
 101440b:	48 8d 05 6e b9 01 00 	lea    0x1b96e(%rip),%rax        # 102fd80 <myl_t_1e414bd82e4b50b54939760a2d591f88da97e2f1c8252dbd7dcbc73438e46afb>
 1014412:	48 89 85 90 fe ff ff 	mov    %rax,-0x170(%rbp)
 1014419:	48 8d 85 18 ff ff ff 	lea    -0xe8(%rbp),%rax
 1014420:	48 89 85 98 fe ff ff 	mov    %rax,-0x168(%rbp)
 1014427:	4c 89 ad a0 fe ff ff 	mov    %r13,-0x160(%rbp)
 101442e:	c7 85 a8 fe ff ff 02 	movl   $0x2,-0x158(%rbp)
 1014435:	00 00 00 
 1014438:	c7 85 a8 fe ff ff 04 	movl   $0x4,-0x158(%rbp)
 101443f:	00 00 00 
 1014442:	c7 85 d8 fe ff ff 01 	movl   $0x1,-0x128(%rbp)
 1014449:	00 00 00 
 101444c:	49 89 fe             	mov    %rdi,%r14
 101444f:	e8 4c 9e 00 00       	call   101e2a0 <myl_qbe_region_mark>
 1014454:	4c 89 f7             	mov    %r14,%rdi
 1014457:	4c 8b bd 30 ff ff ff 	mov    -0xd0(%rbp),%r15
 101445e:	8b 85 c0 fe ff ff    	mov    -0x140(%rbp),%eax
 1014464:	83 f8 00             	cmp    $0x0,%eax
 1014467:	0f 85 aa 00 00 00    	jne    1014517 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xd57>
 101446d:	49 89 fe             	mov    %rdi,%r14
 1014470:	e8 2b 9e 00 00       	call   101e2a0 <myl_qbe_region_mark>
 1014475:	4c 89 f9             	mov    %r15,%rcx
 1014478:	4c 89 f7             	mov    %r14,%rdi
 101447b:	49 89 c0             	mov    %rax,%r8
 101447e:	4c 8b 75 e8          	mov    -0x18(%rbp),%r14
 1014482:	49 89 cf             	mov    %rcx,%r15
 1014485:	48 8d 95 08 ff ff ff 	lea    -0xf8(%rbp),%rdx
 101448c:	48 8d 35 8d bb 01 00 	lea    0x1bb8d(%rip),%rsi        # 1030020 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 1014493:	49 89 ff             	mov    %rdi,%r15
 1014496:	4c 89 e7             	mov    %r12,%rdi
 1014499:	e8 82 6d 01 00       	call   102b220 <myl_rc_native_copy>
 101449e:	4c 89 ff             	mov    %r15,%rdi
 10144a1:	89 c2                	mov    %eax,%edx
 10144a3:	48 8b 4d e0          	mov    -0x20(%rbp),%rcx
 10144a7:	4c 8b 7d d0          	mov    -0x30(%rbp),%r15
 10144ab:	48 8b 45 d8          	mov    -0x28(%rbp),%rax
 10144af:	48 8b 75 c0          	mov    -0x40(%rbp),%rsi
 10144b3:	83 fa 00             	cmp    $0x0,%edx
 10144b6:	75 23                	jne    10144db <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xd1b>
 10144b8:	48 89 fb             	mov    %rdi,%rbx
 10144bb:	4c 89 e7             	mov    %r12,%rdi
 10144be:	e8 fd f9 00 00       	call   1023ec0 <myl_rc_take_failure>
 10144c3:	48 89 df             	mov    %rbx,%rdi
 10144c6:	89 c6                	mov    %eax,%esi
 10144c8:	48 89 fb             	mov    %rdi,%rbx
 10144cb:	e8 90 70 00 00       	call   101b560 <myl_qbe_rc_status>
 10144d0:	48 89 df             	mov    %rbx,%rdi
 10144d3:	4c 89 fb             	mov    %r15,%rbx
 10144d6:	e9 00 17 00 00       	jmp    1015bdb <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x241b>
 10144db:	48 8d 15 3e bb 01 00 	lea    0x1bb3e(%rip),%rdx        # 1030020 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 10144e2:	48 89 95 70 fe ff ff 	mov    %rdx,-0x190(%rbp)
 10144e9:	48 8d 95 08 ff ff ff 	lea    -0xf8(%rbp),%rdx
 10144f0:	48 89 95 78 fe ff ff 	mov    %rdx,-0x188(%rbp)
 10144f7:	48 89 9d 80 fe ff ff 	mov    %rbx,-0x180(%rbp)
 10144fe:	c7 85 88 fe ff ff 02 	movl   $0x2,-0x178(%rbp)
 1014505:	00 00 00 
 1014508:	c7 85 d0 fe ff ff 01 	movl   $0x1,-0x130(%rbp)
 101450f:	00 00 00 
 1014512:	e9 65 01 00 00       	jmp    101467c <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xebc>
 1014517:	49 89 fe             	mov    %rdi,%r14
 101451a:	e8 81 9d 00 00       	call   101e2a0 <myl_qbe_region_mark>
 101451f:	4c 89 f9             	mov    %r15,%rcx
 1014522:	4c 89 f7             	mov    %r14,%rdi
 1014525:	49 89 c0             	mov    %rax,%r8
 1014528:	4c 8b 75 e8          	mov    -0x18(%rbp),%r14
 101452c:	48 8d 85 08 ff ff ff 	lea    -0xf8(%rbp),%rax
 1014533:	48 f7 d8             	neg    %rax
 1014536:	48 01 c8             	add    %rcx,%rax
 1014539:	48 8d 95 08 ff ff ff 	lea    -0xf8(%rbp),%rdx
 1014540:	48 29 ca             	sub    %rcx,%rdx
 1014543:	48 83 f8 10          	cmp    $0x10,%rax
 1014547:	0f 92 c0             	setb   %al
 101454a:	0f b6 c0             	movzbl %al,%eax
 101454d:	48 83 fa 10          	cmp    $0x10,%rdx
 1014551:	0f 92 c2             	setb   %dl
 1014554:	0f b6 d2             	movzbl %dl,%edx
 1014557:	09 d0                	or     %edx,%eax
 1014559:	0f 85 86 00 00 00    	jne    10145e5 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xe25>
 101455f:	48 8b 01             	mov    (%rcx),%rax
 1014562:	48 83 f8 00          	cmp    $0x0,%rax
 1014566:	74 1a                	je     1014582 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xdc2>
 1014568:	48 83 e8 10          	sub    $0x10,%rax
 101456c:	48 8b 00             	mov    (%rax),%rax
 101456f:	48 ba 01 00 00 00 00 	movabs $0x5000000000000001,%rdx
 1014576:	00 00 50 
 1014579:	48 21 d0             	and    %rdx,%rax
 101457c:	48 83 f8 00          	cmp    $0x0,%rax
 1014580:	75 63                	jne    10145e5 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xe25>
 1014582:	48 8b 41 08          	mov    0x8(%rcx),%rax
 1014586:	48 83 f8 00          	cmp    $0x0,%rax
 101458a:	74 1a                	je     10145a6 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xde6>
 101458c:	48 83 e8 10          	sub    $0x10,%rax
 1014590:	48 8b 00             	mov    (%rax),%rax
 1014593:	48 ba 01 00 00 00 00 	movabs $0x5000000000000001,%rdx
 101459a:	00 00 50 
 101459d:	48 21 d0             	and    %rdx,%rax
 10145a0:	48 83 f8 00          	cmp    $0x0,%rax
 10145a4:	75 3f                	jne    10145e5 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xe25>
 10145a6:	48 8b 01             	mov    (%rcx),%rax
 10145a9:	48 89 85 08 ff ff ff 	mov    %rax,-0xf8(%rbp)
 10145b0:	48 8b 41 08          	mov    0x8(%rcx),%rax
 10145b4:	48 89 85 10 ff ff ff 	mov    %rax,-0xf0(%rbp)
 10145bb:	ba 10 00 00 00       	mov    $0x10,%edx
 10145c0:	be 00 00 00 00       	mov    $0x0,%esi
 10145c5:	49 89 ff             	mov    %rdi,%r15
 10145c8:	48 89 cf             	mov    %rcx,%rdi
 10145cb:	e8 b0 74 01 00       	call   102ba80 <compiler_rt.fastMemset>
 10145d0:	4c 89 ff             	mov    %r15,%rdi
 10145d3:	48 8b 4d e0          	mov    -0x20(%rbp),%rcx
 10145d7:	4c 8b 7d d0          	mov    -0x30(%rbp),%r15
 10145db:	48 8b 45 d8          	mov    -0x28(%rbp),%rax
 10145df:	48 8b 75 c0          	mov    -0x40(%rbp),%rsi
 10145e3:	eb 56                	jmp    101463b <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xe7b>
 10145e5:	48 8d 95 08 ff ff ff 	lea    -0xf8(%rbp),%rdx
 10145ec:	48 8d 35 2d ba 01 00 	lea    0x1ba2d(%rip),%rsi        # 1030020 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 10145f3:	49 89 ff             	mov    %rdi,%r15
 10145f6:	4c 89 e7             	mov    %r12,%rdi
 10145f9:	e8 e2 70 01 00       	call   102b6e0 <myl_rc_native_take>
 10145fe:	4c 89 ff             	mov    %r15,%rdi
 1014601:	89 c2                	mov    %eax,%edx
 1014603:	48 8b 4d e0          	mov    -0x20(%rbp),%rcx
 1014607:	4c 8b 7d d0          	mov    -0x30(%rbp),%r15
 101460b:	48 8b 45 d8          	mov    -0x28(%rbp),%rax
 101460f:	48 8b 75 c0          	mov    -0x40(%rbp),%rsi
 1014613:	83 fa 00             	cmp    $0x0,%edx
 1014616:	75 23                	jne    101463b <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xe7b>
 1014618:	48 89 fb             	mov    %rdi,%rbx
 101461b:	4c 89 e7             	mov    %r12,%rdi
 101461e:	e8 9d f8 00 00       	call   1023ec0 <myl_rc_take_failure>
 1014623:	48 89 df             	mov    %rbx,%rdi
 1014626:	89 c6                	mov    %eax,%esi
 1014628:	48 89 fb             	mov    %rdi,%rbx
 101462b:	e8 30 6f 00 00       	call   101b560 <myl_qbe_rc_status>
 1014630:	48 89 df             	mov    %rbx,%rdi
 1014633:	4c 89 fb             	mov    %r15,%rbx
 1014636:	e9 a0 15 00 00       	jmp    1015bdb <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x241b>
 101463b:	c7 85 c0 fe ff ff 00 	movl   $0x0,-0x140(%rbp)
 1014642:	00 00 00 
 1014645:	48 8d 15 d4 b9 01 00 	lea    0x1b9d4(%rip),%rdx        # 1030020 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 101464c:	48 89 95 70 fe ff ff 	mov    %rdx,-0x190(%rbp)
 1014653:	48 8d 95 08 ff ff ff 	lea    -0xf8(%rbp),%rdx
 101465a:	48 89 95 78 fe ff ff 	mov    %rdx,-0x188(%rbp)
 1014661:	48 89 9d 80 fe ff ff 	mov    %rbx,-0x180(%rbp)
 1014668:	c7 85 88 fe ff ff 02 	movl   $0x2,-0x178(%rbp)
 101466f:	00 00 00 
 1014672:	c7 85 d0 fe ff ff 01 	movl   $0x1,-0x130(%rbp)
 1014679:	00 00 00 
 101467c:	48 8b 95 08 ff ff ff 	mov    -0xf8(%rbp),%rdx
 1014683:	48 89 11             	mov    %rdx,(%rcx)
 1014686:	48 8b 95 10 ff ff ff 	mov    -0xf0(%rbp),%rdx
 101468d:	48 89 51 08          	mov    %rdx,0x8(%rcx)
 1014691:	c7 85 d0 fe ff ff 00 	movl   $0x0,-0x130(%rbp)
 1014698:	00 00 00 
 101469b:	48 89 8d 30 ff ff ff 	mov    %rcx,-0xd0(%rbp)
 10146a2:	c7 85 d8 fe ff ff 00 	movl   $0x0,-0x128(%rbp)
 10146a9:	00 00 00 
 10146ac:	48 8b 8d 30 ff ff ff 	mov    -0xd0(%rbp),%rcx
 10146b3:	48 89 8d 08 ff ff ff 	mov    %rcx,-0xf8(%rbp)
 10146ba:	48 8d 0d bf b6 01 00 	lea    0x1b6bf(%rip),%rcx        # 102fd80 <myl_t_1e414bd82e4b50b54939760a2d591f88da97e2f1c8252dbd7dcbc73438e46afb>
 10146c1:	48 89 8d 70 fe ff ff 	mov    %rcx,-0x190(%rbp)
 10146c8:	48 8d 8d 08 ff ff ff 	lea    -0xf8(%rbp),%rcx
 10146cf:	48 89 8d 78 fe ff ff 	mov    %rcx,-0x188(%rbp)
 10146d6:	48 89 9d 80 fe ff ff 	mov    %rbx,-0x180(%rbp)
 10146dd:	c7 85 88 fe ff ff 02 	movl   $0x2,-0x178(%rbp)
 10146e4:	00 00 00 
 10146e7:	c7 85 d0 fe ff ff 01 	movl   $0x1,-0x130(%rbp)
 10146ee:	00 00 00 
 10146f1:	8b 8d c0 fe ff ff    	mov    -0x140(%rbp),%ecx
 10146f7:	83 f9 00             	cmp    $0x0,%ecx
 10146fa:	74 13                	je     101470f <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xf4f>
 10146fc:	49 89 ff             	mov    %rdi,%r15
 10146ff:	e8 3c 70 00 00       	call   101b740 <myl_qbe_rc_slot_drop>
 1014704:	4c 89 ff             	mov    %r15,%rdi
 1014707:	4c 8b 7d d0          	mov    -0x30(%rbp),%r15
 101470b:	48 8b 45 d8          	mov    -0x28(%rbp),%rax
 101470f:	48 8b 8d 08 ff ff ff 	mov    -0xf8(%rbp),%rcx
 1014716:	48 89 8d f0 fe ff ff 	mov    %rcx,-0x110(%rbp)
 101471d:	48 8d 0d 5c b6 01 00 	lea    0x1b65c(%rip),%rcx        # 102fd80 <myl_t_1e414bd82e4b50b54939760a2d591f88da97e2f1c8252dbd7dcbc73438e46afb>
 1014724:	48 89 8d 30 fe ff ff 	mov    %rcx,-0x1d0(%rbp)
 101472b:	48 8d 8d f0 fe ff ff 	lea    -0x110(%rbp),%rcx
 1014732:	48 89 8d 38 fe ff ff 	mov    %rcx,-0x1c8(%rbp)
 1014739:	48 89 85 40 fe ff ff 	mov    %rax,-0x1c0(%rbp)
 1014740:	c7 85 48 fe ff ff 02 	movl   $0x2,-0x1b8(%rbp)
 1014747:	00 00 00 
 101474a:	c7 85 d0 fe ff ff 00 	movl   $0x0,-0x130(%rbp)
 1014751:	00 00 00 
 1014754:	c7 85 c0 fe ff ff 01 	movl   $0x1,-0x140(%rbp)
 101475b:	00 00 00 
 101475e:	48 8b 85 f0 fe ff ff 	mov    -0x110(%rbp),%rax
 1014765:	48 89 85 30 ff ff ff 	mov    %rax,-0xd0(%rbp)
 101476c:	4d 89 7c 24 10       	mov    %r15,0x10(%r12)
 1014771:	ba 08 00 00 00       	mov    $0x8,%edx
 1014776:	be 00 00 00 00       	mov    $0x0,%esi
 101477b:	49 89 ff             	mov    %rdi,%r15
 101477e:	48 8d 7d a0          	lea    -0x60(%rbp),%rdi
 1014782:	e8 f9 72 01 00       	call   102ba80 <compiler_rt.fastMemset>
 1014787:	4c 89 ff             	mov    %r15,%rdi
 101478a:	48 8d 05 1f b8 01 00 	lea    0x1b81f(%rip),%rax        # 102ffb0 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 1014791:	48 89 85 90 fe ff ff 	mov    %rax,-0x170(%rbp)
 1014798:	48 8d 45 a0          	lea    -0x60(%rbp),%rax
 101479c:	48 89 85 98 fe ff ff 	mov    %rax,-0x168(%rbp)
 10147a3:	4c 89 ad a0 fe ff ff 	mov    %r13,-0x160(%rbp)
 10147aa:	c7 85 a8 fe ff ff 02 	movl   $0x2,-0x158(%rbp)
 10147b1:	00 00 00 
 10147b4:	c7 85 d8 fe ff ff 01 	movl   $0x1,-0x128(%rbp)
 10147bb:	00 00 00 
 10147be:	49 89 ff             	mov    %rdi,%r15
 10147c1:	e8 da 9a 00 00       	call   101e2a0 <myl_qbe_region_mark>
 10147c6:	4c 89 ff             	mov    %r15,%rdi
 10147c9:	8b 85 c0 fe ff ff    	mov    -0x140(%rbp),%eax
 10147cf:	83 f8 00             	cmp    $0x0,%eax
 10147d2:	0f 85 a3 00 00 00    	jne    101487b <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x10bb>
 10147d8:	49 89 ff             	mov    %rdi,%r15
 10147db:	e8 c0 9a 00 00       	call   101e2a0 <myl_qbe_region_mark>
 10147e0:	4c 89 ff             	mov    %r15,%rdi
 10147e3:	49 89 c0             	mov    %rax,%r8
 10147e6:	48 8d 8d 30 ff ff ff 	lea    -0xd0(%rbp),%rcx
 10147ed:	48 8d 95 08 ff ff ff 	lea    -0xf8(%rbp),%rdx
 10147f4:	48 8d 35 85 b5 01 00 	lea    0x1b585(%rip),%rsi        # 102fd80 <myl_t_1e414bd82e4b50b54939760a2d591f88da97e2f1c8252dbd7dcbc73438e46afb>
 10147fb:	49 89 ff             	mov    %rdi,%r15
 10147fe:	4c 89 e7             	mov    %r12,%rdi
 1014801:	e8 1a 6a 01 00       	call   102b220 <myl_rc_native_copy>
 1014806:	4c 89 ff             	mov    %r15,%rdi
 1014809:	89 c1                	mov    %eax,%ecx
 101480b:	4c 8b 7d d0          	mov    -0x30(%rbp),%r15
 101480f:	48 8b 45 d8          	mov    -0x28(%rbp),%rax
 1014813:	48 8b 75 c0          	mov    -0x40(%rbp),%rsi
 1014817:	83 f9 00             	cmp    $0x0,%ecx
 101481a:	75 23                	jne    101483f <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x107f>
 101481c:	48 89 fb             	mov    %rdi,%rbx
 101481f:	4c 89 e7             	mov    %r12,%rdi
 1014822:	e8 99 f6 00 00       	call   1023ec0 <myl_rc_take_failure>
 1014827:	48 89 df             	mov    %rbx,%rdi
 101482a:	89 c6                	mov    %eax,%esi
 101482c:	48 89 fb             	mov    %rdi,%rbx
 101482f:	e8 2c 6d 00 00       	call   101b560 <myl_qbe_rc_status>
 1014834:	48 89 df             	mov    %rbx,%rdi
 1014837:	4c 89 fb             	mov    %r15,%rbx
 101483a:	e9 9c 13 00 00       	jmp    1015bdb <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x241b>
 101483f:	48 8d 0d 3a b5 01 00 	lea    0x1b53a(%rip),%rcx        # 102fd80 <myl_t_1e414bd82e4b50b54939760a2d591f88da97e2f1c8252dbd7dcbc73438e46afb>
 1014846:	48 89 8d 70 fe ff ff 	mov    %rcx,-0x190(%rbp)
 101484d:	48 8d 8d 08 ff ff ff 	lea    -0xf8(%rbp),%rcx
 1014854:	48 89 8d 78 fe ff ff 	mov    %rcx,-0x188(%rbp)
 101485b:	48 89 9d 80 fe ff ff 	mov    %rbx,-0x180(%rbp)
 1014862:	c7 85 88 fe ff ff 02 	movl   $0x2,-0x178(%rbp)
 1014869:	00 00 00 
 101486c:	c7 85 d0 fe ff ff 01 	movl   $0x1,-0x130(%rbp)
 1014873:	00 00 00 
 1014876:	e9 40 01 00 00       	jmp    10149bb <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x11fb>
 101487b:	49 89 ff             	mov    %rdi,%r15
 101487e:	e8 1d 9a 00 00       	call   101e2a0 <myl_qbe_region_mark>
 1014883:	4c 89 ff             	mov    %r15,%rdi
 1014886:	49 89 c0             	mov    %rax,%r8
 1014889:	48 8d 8d 08 ff ff ff 	lea    -0xf8(%rbp),%rcx
 1014890:	48 8d 85 30 ff ff ff 	lea    -0xd0(%rbp),%rax
 1014897:	48 29 c8             	sub    %rcx,%rax
 101489a:	48 8d 95 30 ff ff ff 	lea    -0xd0(%rbp),%rdx
 10148a1:	48 8d 8d 08 ff ff ff 	lea    -0xf8(%rbp),%rcx
 10148a8:	48 29 d1             	sub    %rdx,%rcx
 10148ab:	48 83 f8 08          	cmp    $0x8,%rax
 10148af:	0f 92 c0             	setb   %al
 10148b2:	0f b6 c0             	movzbl %al,%eax
 10148b5:	48 83 f9 08          	cmp    $0x8,%rcx
 10148b9:	0f 92 c1             	setb   %cl
 10148bc:	0f b6 c9             	movzbl %cl,%ecx
 10148bf:	09 c8                	or     %ecx,%eax
 10148c1:	75 5b                	jne    101491e <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x115e>
 10148c3:	48 8b 85 30 ff ff ff 	mov    -0xd0(%rbp),%rax
 10148ca:	48 83 f8 00          	cmp    $0x0,%rax
 10148ce:	74 1a                	je     10148ea <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x112a>
 10148d0:	48 83 e8 10          	sub    $0x10,%rax
 10148d4:	48 8b 00             	mov    (%rax),%rax
 10148d7:	48 b9 01 00 00 00 00 	movabs $0x5000000000000001,%rcx
 10148de:	00 00 50 
 10148e1:	48 21 c8             	and    %rcx,%rax
 10148e4:	48 83 f8 00          	cmp    $0x0,%rax
 10148e8:	75 34                	jne    101491e <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x115e>
 10148ea:	48 8b 85 30 ff ff ff 	mov    -0xd0(%rbp),%rax
 10148f1:	48 89 85 08 ff ff ff 	mov    %rax,-0xf8(%rbp)
 10148f8:	ba 08 00 00 00       	mov    $0x8,%edx
 10148fd:	be 00 00 00 00       	mov    $0x0,%esi
 1014902:	49 89 ff             	mov    %rdi,%r15
 1014905:	48 8d bd 30 ff ff ff 	lea    -0xd0(%rbp),%rdi
 101490c:	e8 6f 71 01 00       	call   102ba80 <compiler_rt.fastMemset>
 1014911:	4c 89 ff             	mov    %r15,%rdi
 1014914:	48 8b 45 d8          	mov    -0x28(%rbp),%rax
 1014918:	48 8b 75 c0          	mov    -0x40(%rbp),%rsi
 101491c:	eb 5c                	jmp    101497a <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x11ba>
 101491e:	48 8d 8d 30 ff ff ff 	lea    -0xd0(%rbp),%rcx
 1014925:	48 8d 95 08 ff ff ff 	lea    -0xf8(%rbp),%rdx
 101492c:	48 8d 35 4d b4 01 00 	lea    0x1b44d(%rip),%rsi        # 102fd80 <myl_t_1e414bd82e4b50b54939760a2d591f88da97e2f1c8252dbd7dcbc73438e46afb>
 1014933:	49 89 ff             	mov    %rdi,%r15
 1014936:	4c 89 e7             	mov    %r12,%rdi
 1014939:	e8 a2 6d 01 00       	call   102b6e0 <myl_rc_native_take>
 101493e:	4c 89 ff             	mov    %r15,%rdi
 1014941:	89 c1                	mov    %eax,%ecx
 1014943:	4c 8b 7d d0          	mov    -0x30(%rbp),%r15
 1014947:	48 8b 45 d8          	mov    -0x28(%rbp),%rax
 101494b:	48 8b 75 c0          	mov    -0x40(%rbp),%rsi
 101494f:	83 f9 00             	cmp    $0x0,%ecx
 1014952:	75 26                	jne    101497a <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x11ba>
 1014954:	4d 89 fd             	mov    %r15,%r13
 1014957:	48 89 fb             	mov    %rdi,%rbx
 101495a:	4c 89 e7             	mov    %r12,%rdi
 101495d:	e8 5e f5 00 00       	call   1023ec0 <myl_rc_take_failure>
 1014962:	48 89 df             	mov    %rbx,%rdi
 1014965:	89 c6                	mov    %eax,%esi
 1014967:	48 89 fb             	mov    %rdi,%rbx
 101496a:	e8 f1 6b 00 00       	call   101b560 <myl_qbe_rc_status>
 101496f:	48 89 df             	mov    %rbx,%rdi
 1014972:	4c 89 eb             	mov    %r13,%rbx
 1014975:	e9 61 12 00 00       	jmp    1015bdb <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x241b>
 101497a:	c7 85 c0 fe ff ff 00 	movl   $0x0,-0x140(%rbp)
 1014981:	00 00 00 
 1014984:	48 8d 0d f5 b3 01 00 	lea    0x1b3f5(%rip),%rcx        # 102fd80 <myl_t_1e414bd82e4b50b54939760a2d591f88da97e2f1c8252dbd7dcbc73438e46afb>
 101498b:	48 89 8d 70 fe ff ff 	mov    %rcx,-0x190(%rbp)
 1014992:	48 8d 8d 08 ff ff ff 	lea    -0xf8(%rbp),%rcx
 1014999:	48 89 8d 78 fe ff ff 	mov    %rcx,-0x188(%rbp)
 10149a0:	48 89 9d 80 fe ff ff 	mov    %rbx,-0x180(%rbp)
 10149a7:	c7 85 88 fe ff ff 02 	movl   $0x2,-0x178(%rbp)
 10149ae:	00 00 00 
 10149b1:	c7 85 d0 fe ff ff 01 	movl   $0x1,-0x130(%rbp)
 10149b8:	00 00 00 
 10149bb:	48 8b 8d 08 ff ff ff 	mov    -0xf8(%rbp),%rcx
 10149c2:	48 89 4d a0          	mov    %rcx,-0x60(%rbp)
 10149c6:	c7 85 d0 fe ff ff 00 	movl   $0x0,-0x130(%rbp)
 10149cd:	00 00 00 
 10149d0:	48 8d 4d a0          	lea    -0x60(%rbp),%rcx
 10149d4:	48 89 8d 30 ff ff ff 	mov    %rcx,-0xd0(%rbp)
 10149db:	c7 85 d8 fe ff ff 00 	movl   $0x0,-0x128(%rbp)
 10149e2:	00 00 00 
 10149e5:	48 8b 4d a0          	mov    -0x60(%rbp),%rcx
 10149e9:	48 89 8d 08 ff ff ff 	mov    %rcx,-0xf8(%rbp)
 10149f0:	48 8d 0d b9 b5 01 00 	lea    0x1b5b9(%rip),%rcx        # 102ffb0 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 10149f7:	48 89 8d 70 fe ff ff 	mov    %rcx,-0x190(%rbp)
 10149fe:	48 8d 8d 08 ff ff ff 	lea    -0xf8(%rbp),%rcx
 1014a05:	48 89 8d 78 fe ff ff 	mov    %rcx,-0x188(%rbp)
 1014a0c:	48 89 9d 80 fe ff ff 	mov    %rbx,-0x180(%rbp)
 1014a13:	c7 85 88 fe ff ff 02 	movl   $0x2,-0x178(%rbp)
 1014a1a:	00 00 00 
 1014a1d:	c7 85 d0 fe ff ff 01 	movl   $0x1,-0x130(%rbp)
 1014a24:	00 00 00 
 1014a27:	8b 8d c0 fe ff ff    	mov    -0x140(%rbp),%ecx
 1014a2d:	83 f9 00             	cmp    $0x0,%ecx
 1014a30:	74 0f                	je     1014a41 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1281>
 1014a32:	49 89 ff             	mov    %rdi,%r15
 1014a35:	e8 06 6d 00 00       	call   101b740 <myl_qbe_rc_slot_drop>
 1014a3a:	4c 89 ff             	mov    %r15,%rdi
 1014a3d:	48 8b 45 d8          	mov    -0x28(%rbp),%rax
 1014a41:	48 8b 8d 08 ff ff ff 	mov    -0xf8(%rbp),%rcx
 1014a48:	48 89 8d f0 fe ff ff 	mov    %rcx,-0x110(%rbp)
 1014a4f:	48 8d 0d 5a b5 01 00 	lea    0x1b55a(%rip),%rcx        # 102ffb0 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 1014a56:	48 89 8d 30 fe ff ff 	mov    %rcx,-0x1d0(%rbp)
 1014a5d:	48 8d 8d f0 fe ff ff 	lea    -0x110(%rbp),%rcx
 1014a64:	48 89 8d 38 fe ff ff 	mov    %rcx,-0x1c8(%rbp)
 1014a6b:	48 89 85 40 fe ff ff 	mov    %rax,-0x1c0(%rbp)
 1014a72:	c7 85 48 fe ff ff 02 	movl   $0x2,-0x1b8(%rbp)
 1014a79:	00 00 00 
 1014a7c:	c7 85 d0 fe ff ff 00 	movl   $0x0,-0x130(%rbp)
 1014a83:	00 00 00 
 1014a86:	c7 85 c0 fe ff ff 01 	movl   $0x1,-0x140(%rbp)
 1014a8d:	00 00 00 
 1014a90:	48 8d 85 f0 fe ff ff 	lea    -0x110(%rbp),%rax
 1014a97:	48 89 85 30 ff ff ff 	mov    %rax,-0xd0(%rbp)
 1014a9e:	49 8b 4c 24 10       	mov    0x10(%r12),%rcx
 1014aa3:	48 8b 85 28 ff ff ff 	mov    -0xd8(%rbp),%rax
 1014aaa:	48 89 8d 38 ff ff ff 	mov    %rcx,-0xc8(%rbp)
 1014ab1:	48 89 85 40 ff ff ff 	mov    %rax,-0xc0(%rbp)
 1014ab8:	48 8d 05 f1 b4 01 00 	lea    0x1b4f1(%rip),%rax        # 102ffb0 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 1014abf:	48 89 85 48 ff ff ff 	mov    %rax,-0xb8(%rbp)
 1014ac6:	48 8d 85 38 ff ff ff 	lea    -0xc8(%rbp),%rax
 1014acd:	49 89 44 24 10       	mov    %rax,0x10(%r12)
 1014ad2:	48 8b 85 30 ff ff ff 	mov    -0xd0(%rbp),%rax
 1014ad9:	48 8d 8d 38 ff ff ff 	lea    -0xc8(%rbp),%rcx
 1014ae0:	48 89 8d 58 ff ff ff 	mov    %rcx,-0xa8(%rbp)
 1014ae7:	48 89 85 60 ff ff ff 	mov    %rax,-0xa0(%rbp)
 1014aee:	48 8d 05 bb b4 01 00 	lea    0x1b4bb(%rip),%rax        # 102ffb0 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 1014af5:	48 89 85 68 ff ff ff 	mov    %rax,-0x98(%rbp)
 1014afc:	48 8d 85 58 ff ff ff 	lea    -0xa8(%rbp),%rax
 1014b03:	49 89 44 24 10       	mov    %rax,0x10(%r12)
 1014b08:	ba 10 00 00 00       	mov    $0x10,%edx
 1014b0d:	be 00 00 00 00       	mov    $0x0,%esi
 1014b12:	49 89 ff             	mov    %rdi,%r15
 1014b15:	48 8d 7d a8          	lea    -0x58(%rbp),%rdi
 1014b19:	e8 62 6f 01 00       	call   102ba80 <compiler_rt.fastMemset>
 1014b1e:	4c 89 ff             	mov    %r15,%rdi
 1014b21:	48 8d 05 f8 b4 01 00 	lea    0x1b4f8(%rip),%rax        # 1030020 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 1014b28:	48 89 85 90 fe ff ff 	mov    %rax,-0x170(%rbp)
 1014b2f:	48 8d 45 a8          	lea    -0x58(%rbp),%rax
 1014b33:	48 89 85 98 fe ff ff 	mov    %rax,-0x168(%rbp)
 1014b3a:	4c 89 ad a0 fe ff ff 	mov    %r13,-0x160(%rbp)
 1014b41:	c7 85 a8 fe ff ff 02 	movl   $0x2,-0x158(%rbp)
 1014b48:	00 00 00 
 1014b4b:	c7 85 d8 fe ff ff 01 	movl   $0x1,-0x128(%rbp)
 1014b52:	00 00 00 
 1014b55:	49 89 fd             	mov    %rdi,%r13
 1014b58:	e8 43 97 00 00       	call   101e2a0 <myl_qbe_region_mark>
 1014b5d:	4c 89 ef             	mov    %r13,%rdi
 1014b60:	4c 8b bd 28 ff ff ff 	mov    -0xd8(%rbp),%r15
 1014b67:	8b 85 b8 fe ff ff    	mov    -0x148(%rbp),%eax
 1014b6d:	83 f8 00             	cmp    $0x0,%eax
 1014b70:	0f 85 98 00 00 00    	jne    1014c0e <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x144e>
 1014b76:	49 89 fd             	mov    %rdi,%r13
 1014b79:	e8 22 97 00 00       	call   101e2a0 <myl_qbe_region_mark>
 1014b7e:	4c 89 f9             	mov    %r15,%rcx
 1014b81:	4c 89 ef             	mov    %r13,%rdi
 1014b84:	49 89 c0             	mov    %rax,%r8
 1014b87:	4c 8b 6d d0          	mov    -0x30(%rbp),%r13
 1014b8b:	49 89 cf             	mov    %rcx,%r15
 1014b8e:	48 8d 95 08 ff ff ff 	lea    -0xf8(%rbp),%rdx
 1014b95:	48 8d 35 14 b4 01 00 	lea    0x1b414(%rip),%rsi        # 102ffb0 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 1014b9c:	49 89 ff             	mov    %rdi,%r15
 1014b9f:	4c 89 e7             	mov    %r12,%rdi
 1014ba2:	e8 79 66 01 00       	call   102b220 <myl_rc_native_copy>
 1014ba7:	4c 89 ff             	mov    %r15,%rdi
 1014baa:	83 f8 00             	cmp    $0x0,%eax
 1014bad:	75 23                	jne    1014bd2 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1412>
 1014baf:	48 89 fb             	mov    %rdi,%rbx
 1014bb2:	4c 89 e7             	mov    %r12,%rdi
 1014bb5:	e8 06 f3 00 00       	call   1023ec0 <myl_rc_take_failure>
 1014bba:	48 89 df             	mov    %rbx,%rdi
 1014bbd:	89 c6                	mov    %eax,%esi
 1014bbf:	48 89 fb             	mov    %rdi,%rbx
 1014bc2:	e8 99 69 00 00       	call   101b560 <myl_qbe_rc_status>
 1014bc7:	48 89 df             	mov    %rbx,%rdi
 1014bca:	4c 89 eb             	mov    %r13,%rbx
 1014bcd:	e9 09 10 00 00       	jmp    1015bdb <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x241b>
 1014bd2:	48 8d 05 d7 b3 01 00 	lea    0x1b3d7(%rip),%rax        # 102ffb0 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 1014bd9:	48 89 85 70 fe ff ff 	mov    %rax,-0x190(%rbp)
 1014be0:	48 8d 85 08 ff ff ff 	lea    -0xf8(%rbp),%rax
 1014be7:	48 89 85 78 fe ff ff 	mov    %rax,-0x188(%rbp)
 1014bee:	48 89 9d 80 fe ff ff 	mov    %rbx,-0x180(%rbp)
 1014bf5:	c7 85 88 fe ff ff 02 	movl   $0x2,-0x178(%rbp)
 1014bfc:	00 00 00 
 1014bff:	c7 85 d0 fe ff ff 01 	movl   $0x1,-0x130(%rbp)
 1014c06:	00 00 00 
 1014c09:	e9 10 01 00 00       	jmp    1014d1e <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x155e>
 1014c0e:	49 89 fd             	mov    %rdi,%r13
 1014c11:	e8 8a 96 00 00       	call   101e2a0 <myl_qbe_region_mark>
 1014c16:	4c 89 f9             	mov    %r15,%rcx
 1014c19:	4c 89 ef             	mov    %r13,%rdi
 1014c1c:	49 89 c0             	mov    %rax,%r8
 1014c1f:	4c 8b 6d d0          	mov    -0x30(%rbp),%r13
 1014c23:	48 8d 85 08 ff ff ff 	lea    -0xf8(%rbp),%rax
 1014c2a:	48 f7 d8             	neg    %rax
 1014c2d:	48 01 c8             	add    %rcx,%rax
 1014c30:	48 8d 95 08 ff ff ff 	lea    -0xf8(%rbp),%rdx
 1014c37:	48 29 ca             	sub    %rcx,%rdx
 1014c3a:	48 83 f8 08          	cmp    $0x8,%rax
 1014c3e:	0f 92 c0             	setb   %al
 1014c41:	0f b6 c0             	movzbl %al,%eax
 1014c44:	48 83 fa 08          	cmp    $0x8,%rdx
 1014c48:	0f 92 c2             	setb   %dl
 1014c4b:	0f b6 d2             	movzbl %dl,%edx
 1014c4e:	09 d0                	or     %edx,%eax
 1014c50:	75 47                	jne    1014c99 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x14d9>
 1014c52:	48 8b 01             	mov    (%rcx),%rax
 1014c55:	48 83 f8 00          	cmp    $0x0,%rax
 1014c59:	74 1a                	je     1014c75 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x14b5>
 1014c5b:	48 83 e8 10          	sub    $0x10,%rax
 1014c5f:	48 8b 00             	mov    (%rax),%rax
 1014c62:	48 ba 01 00 00 00 00 	movabs $0x5000000000000001,%rdx
 1014c69:	00 00 50 
 1014c6c:	48 21 d0             	and    %rdx,%rax
 1014c6f:	48 83 f8 00          	cmp    $0x0,%rax
 1014c73:	75 24                	jne    1014c99 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x14d9>
 1014c75:	48 8b 01             	mov    (%rcx),%rax
 1014c78:	48 89 85 08 ff ff ff 	mov    %rax,-0xf8(%rbp)
 1014c7f:	ba 08 00 00 00       	mov    $0x8,%edx
 1014c84:	be 00 00 00 00       	mov    $0x0,%esi
 1014c89:	49 89 fd             	mov    %rdi,%r13
 1014c8c:	48 89 cf             	mov    %rcx,%rdi
 1014c8f:	e8 ec 6d 01 00       	call   102ba80 <compiler_rt.fastMemset>
 1014c94:	4c 89 ef             	mov    %r13,%rdi
 1014c97:	eb 44                	jmp    1014cdd <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x151d>
 1014c99:	48 8d 95 08 ff ff ff 	lea    -0xf8(%rbp),%rdx
 1014ca0:	48 8d 35 09 b3 01 00 	lea    0x1b309(%rip),%rsi        # 102ffb0 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 1014ca7:	49 89 ff             	mov    %rdi,%r15
 1014caa:	4c 89 e7             	mov    %r12,%rdi
 1014cad:	e8 2e 6a 01 00       	call   102b6e0 <myl_rc_native_take>
 1014cb2:	4c 89 ff             	mov    %r15,%rdi
 1014cb5:	83 f8 00             	cmp    $0x0,%eax
 1014cb8:	75 23                	jne    1014cdd <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x151d>
 1014cba:	48 89 fb             	mov    %rdi,%rbx
 1014cbd:	4c 89 e7             	mov    %r12,%rdi
 1014cc0:	e8 fb f1 00 00       	call   1023ec0 <myl_rc_take_failure>
 1014cc5:	48 89 df             	mov    %rbx,%rdi
 1014cc8:	89 c6                	mov    %eax,%esi
 1014cca:	48 89 fb             	mov    %rdi,%rbx
 1014ccd:	e8 8e 68 00 00       	call   101b560 <myl_qbe_rc_status>
 1014cd2:	48 89 df             	mov    %rbx,%rdi
 1014cd5:	4c 89 eb             	mov    %r13,%rbx
 1014cd8:	e9 fe 0e 00 00       	jmp    1015bdb <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x241b>
 1014cdd:	c7 85 b8 fe ff ff 00 	movl   $0x0,-0x148(%rbp)
 1014ce4:	00 00 00 
 1014ce7:	48 8d 05 c2 b2 01 00 	lea    0x1b2c2(%rip),%rax        # 102ffb0 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 1014cee:	48 89 85 70 fe ff ff 	mov    %rax,-0x190(%rbp)
 1014cf5:	48 8d 85 08 ff ff ff 	lea    -0xf8(%rbp),%rax
 1014cfc:	48 89 85 78 fe ff ff 	mov    %rax,-0x188(%rbp)
 1014d03:	48 89 9d 80 fe ff ff 	mov    %rbx,-0x180(%rbp)
 1014d0a:	c7 85 88 fe ff ff 02 	movl   $0x2,-0x178(%rbp)
 1014d11:	00 00 00 
 1014d14:	c7 85 d0 fe ff ff 01 	movl   $0x1,-0x130(%rbp)
 1014d1b:	00 00 00 
 1014d1e:	48 8b 85 08 ff ff ff 	mov    -0xf8(%rbp),%rax
 1014d25:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
 1014d29:	c7 85 d0 fe ff ff 00 	movl   $0x0,-0x130(%rbp)
 1014d30:	00 00 00 
 1014d33:	4c 8b bd 30 ff ff ff 	mov    -0xd0(%rbp),%r15
 1014d3a:	8b 85 c0 fe ff ff    	mov    -0x140(%rbp),%eax
 1014d40:	83 f8 00             	cmp    $0x0,%eax
 1014d43:	0f 85 a5 00 00 00    	jne    1014dee <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x162e>
 1014d49:	49 89 fd             	mov    %rdi,%r13
 1014d4c:	e8 4f 95 00 00       	call   101e2a0 <myl_qbe_region_mark>
 1014d51:	4c 89 f9             	mov    %r15,%rcx
 1014d54:	4c 89 ef             	mov    %r13,%rdi
 1014d57:	49 89 c0             	mov    %rax,%r8
 1014d5a:	4c 8b 6d d0          	mov    -0x30(%rbp),%r13
 1014d5e:	49 89 cf             	mov    %rcx,%r15
 1014d61:	48 8d 95 08 ff ff ff 	lea    -0xf8(%rbp),%rdx
 1014d68:	48 8d 35 41 b2 01 00 	lea    0x1b241(%rip),%rsi        # 102ffb0 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 1014d6f:	49 89 ff             	mov    %rdi,%r15
 1014d72:	4c 89 e7             	mov    %r12,%rdi
 1014d75:	e8 a6 64 01 00       	call   102b220 <myl_rc_native_copy>
 1014d7a:	4c 89 ff             	mov    %r15,%rdi
 1014d7d:	89 c1                	mov    %eax,%ecx
 1014d7f:	48 8b 75 c0          	mov    -0x40(%rbp),%rsi
 1014d83:	48 89 f0             	mov    %rsi,%rax
 1014d86:	48 8b 75 c8          	mov    -0x38(%rbp),%rsi
 1014d8a:	83 f9 00             	cmp    $0x0,%ecx
 1014d8d:	75 23                	jne    1014db2 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x15f2>
 1014d8f:	48 89 fb             	mov    %rdi,%rbx
 1014d92:	4c 89 e7             	mov    %r12,%rdi
 1014d95:	e8 26 f1 00 00       	call   1023ec0 <myl_rc_take_failure>
 1014d9a:	48 89 df             	mov    %rbx,%rdi
 1014d9d:	89 c6                	mov    %eax,%esi
 1014d9f:	48 89 fb             	mov    %rdi,%rbx
 1014da2:	e8 b9 67 00 00       	call   101b560 <myl_qbe_rc_status>
 1014da7:	48 89 df             	mov    %rbx,%rdi
 1014daa:	4c 89 eb             	mov    %r13,%rbx
 1014dad:	e9 29 0e 00 00       	jmp    1015bdb <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x241b>
 1014db2:	48 8d 0d f7 b1 01 00 	lea    0x1b1f7(%rip),%rcx        # 102ffb0 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 1014db9:	48 89 8d 70 fe ff ff 	mov    %rcx,-0x190(%rbp)
 1014dc0:	48 8d 8d 08 ff ff ff 	lea    -0xf8(%rbp),%rcx
 1014dc7:	48 89 8d 78 fe ff ff 	mov    %rcx,-0x188(%rbp)
 1014dce:	48 89 9d 80 fe ff ff 	mov    %rbx,-0x180(%rbp)
 1014dd5:	c7 85 88 fe ff ff 02 	movl   $0x2,-0x178(%rbp)
 1014ddc:	00 00 00 
 1014ddf:	c7 85 d0 fe ff ff 01 	movl   $0x1,-0x130(%rbp)
 1014de6:	00 00 00 
 1014de9:	e9 28 01 00 00       	jmp    1014f16 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1756>
 1014dee:	49 89 fd             	mov    %rdi,%r13
 1014df1:	e8 aa 94 00 00       	call   101e2a0 <myl_qbe_region_mark>
 1014df6:	4c 89 f9             	mov    %r15,%rcx
 1014df9:	4c 89 ef             	mov    %r13,%rdi
 1014dfc:	49 89 c0             	mov    %rax,%r8
 1014dff:	4c 8b 6d d0          	mov    -0x30(%rbp),%r13
 1014e03:	48 8d 85 08 ff ff ff 	lea    -0xf8(%rbp),%rax
 1014e0a:	48 f7 d8             	neg    %rax
 1014e0d:	48 01 c8             	add    %rcx,%rax
 1014e10:	48 8d 95 08 ff ff ff 	lea    -0xf8(%rbp),%rdx
 1014e17:	48 29 ca             	sub    %rcx,%rdx
 1014e1a:	48 83 f8 08          	cmp    $0x8,%rax
 1014e1e:	0f 92 c0             	setb   %al
 1014e21:	0f b6 c0             	movzbl %al,%eax
 1014e24:	48 83 fa 08          	cmp    $0x8,%rdx
 1014e28:	0f 92 c2             	setb   %dl
 1014e2b:	0f b6 d2             	movzbl %dl,%edx
 1014e2e:	09 d0                	or     %edx,%eax
 1014e30:	75 52                	jne    1014e84 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x16c4>
 1014e32:	48 8b 01             	mov    (%rcx),%rax
 1014e35:	48 83 f8 00          	cmp    $0x0,%rax
 1014e39:	74 1a                	je     1014e55 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1695>
 1014e3b:	48 83 e8 10          	sub    $0x10,%rax
 1014e3f:	48 8b 00             	mov    (%rax),%rax
 1014e42:	48 ba 01 00 00 00 00 	movabs $0x5000000000000001,%rdx
 1014e49:	00 00 50 
 1014e4c:	48 21 d0             	and    %rdx,%rax
 1014e4f:	48 83 f8 00          	cmp    $0x0,%rax
 1014e53:	75 2f                	jne    1014e84 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x16c4>
 1014e55:	48 8b 01             	mov    (%rcx),%rax
 1014e58:	48 89 85 08 ff ff ff 	mov    %rax,-0xf8(%rbp)
 1014e5f:	ba 08 00 00 00       	mov    $0x8,%edx
 1014e64:	be 00 00 00 00       	mov    $0x0,%esi
 1014e69:	49 89 ff             	mov    %rdi,%r15
 1014e6c:	48 89 cf             	mov    %rcx,%rdi
 1014e6f:	e8 0c 6c 01 00       	call   102ba80 <compiler_rt.fastMemset>
 1014e74:	4c 89 ff             	mov    %r15,%rdi
 1014e77:	48 8b 75 c0          	mov    -0x40(%rbp),%rsi
 1014e7b:	48 89 f0             	mov    %rsi,%rax
 1014e7e:	48 8b 75 c8          	mov    -0x38(%rbp),%rsi
 1014e82:	eb 51                	jmp    1014ed5 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1715>
 1014e84:	48 8d 95 08 ff ff ff 	lea    -0xf8(%rbp),%rdx
 1014e8b:	48 8d 35 1e b1 01 00 	lea    0x1b11e(%rip),%rsi        # 102ffb0 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 1014e92:	49 89 ff             	mov    %rdi,%r15
 1014e95:	4c 89 e7             	mov    %r12,%rdi
 1014e98:	e8 43 68 01 00       	call   102b6e0 <myl_rc_native_take>
 1014e9d:	4c 89 ff             	mov    %r15,%rdi
 1014ea0:	89 c1                	mov    %eax,%ecx
 1014ea2:	48 8b 75 c0          	mov    -0x40(%rbp),%rsi
 1014ea6:	48 89 f0             	mov    %rsi,%rax
 1014ea9:	48 8b 75 c8          	mov    -0x38(%rbp),%rsi
 1014ead:	83 f9 00             	cmp    $0x0,%ecx
 1014eb0:	75 23                	jne    1014ed5 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1715>
 1014eb2:	48 89 fb             	mov    %rdi,%rbx
 1014eb5:	4c 89 e7             	mov    %r12,%rdi
 1014eb8:	e8 03 f0 00 00       	call   1023ec0 <myl_rc_take_failure>
 1014ebd:	48 89 df             	mov    %rbx,%rdi
 1014ec0:	89 c6                	mov    %eax,%esi
 1014ec2:	48 89 fb             	mov    %rdi,%rbx
 1014ec5:	e8 96 66 00 00       	call   101b560 <myl_qbe_rc_status>
 1014eca:	48 89 df             	mov    %rbx,%rdi
 1014ecd:	4c 89 eb             	mov    %r13,%rbx
 1014ed0:	e9 06 0d 00 00       	jmp    1015bdb <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x241b>
 1014ed5:	c7 85 c0 fe ff ff 00 	movl   $0x0,-0x140(%rbp)
 1014edc:	00 00 00 
 1014edf:	48 8d 0d ca b0 01 00 	lea    0x1b0ca(%rip),%rcx        # 102ffb0 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 1014ee6:	48 89 8d 70 fe ff ff 	mov    %rcx,-0x190(%rbp)
 1014eed:	48 8d 8d 08 ff ff ff 	lea    -0xf8(%rbp),%rcx
 1014ef4:	48 89 8d 78 fe ff ff 	mov    %rcx,-0x188(%rbp)
 1014efb:	48 89 9d 80 fe ff ff 	mov    %rbx,-0x180(%rbp)
 1014f02:	c7 85 88 fe ff ff 02 	movl   $0x2,-0x178(%rbp)
 1014f09:	00 00 00 
 1014f0c:	c7 85 d0 fe ff ff 01 	movl   $0x1,-0x130(%rbp)
 1014f13:	00 00 00 
 1014f16:	48 8b 8d 08 ff ff ff 	mov    -0xf8(%rbp),%rcx
 1014f1d:	48 89 4d b0          	mov    %rcx,-0x50(%rbp)
 1014f21:	c7 85 d0 fe ff ff 00 	movl   $0x0,-0x130(%rbp)
 1014f28:	00 00 00 
 1014f2b:	48 8d 4d a8          	lea    -0x58(%rbp),%rcx
 1014f2f:	48 89 8d 28 ff ff ff 	mov    %rcx,-0xd8(%rbp)
 1014f36:	c7 85 d8 fe ff ff 00 	movl   $0x0,-0x128(%rbp)
 1014f3d:	00 00 00 
 1014f40:	48 8b 4d a8          	mov    -0x58(%rbp),%rcx
 1014f44:	48 89 8d 08 ff ff ff 	mov    %rcx,-0xf8(%rbp)
 1014f4b:	48 8b 4d b0          	mov    -0x50(%rbp),%rcx
 1014f4f:	48 89 8d 10 ff ff ff 	mov    %rcx,-0xf0(%rbp)
 1014f56:	48 8d 0d c3 b0 01 00 	lea    0x1b0c3(%rip),%rcx        # 1030020 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 1014f5d:	48 89 8d 70 fe ff ff 	mov    %rcx,-0x190(%rbp)
 1014f64:	48 8d 8d 08 ff ff ff 	lea    -0xf8(%rbp),%rcx
 1014f6b:	48 89 8d 78 fe ff ff 	mov    %rcx,-0x188(%rbp)
 1014f72:	48 89 9d 80 fe ff ff 	mov    %rbx,-0x180(%rbp)
 1014f79:	c7 85 88 fe ff ff 02 	movl   $0x2,-0x178(%rbp)
 1014f80:	00 00 00 
 1014f83:	c7 85 d0 fe ff ff 01 	movl   $0x1,-0x130(%rbp)
 1014f8a:	00 00 00 
 1014f8d:	8b 8d b8 fe ff ff    	mov    -0x148(%rbp),%ecx
 1014f93:	83 f9 00             	cmp    $0x0,%ecx
 1014f96:	75 05                	jne    1014f9d <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x17dd>
 1014f98:	48 89 c6             	mov    %rax,%rsi
 1014f9b:	eb 0f                	jmp    1014fac <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x17ec>
 1014f9d:	49 89 ff             	mov    %rdi,%r15
 1014fa0:	e8 9b 67 00 00       	call   101b740 <myl_qbe_rc_slot_drop>
 1014fa5:	4c 89 ff             	mov    %r15,%rdi
 1014fa8:	48 8b 75 c0          	mov    -0x40(%rbp),%rsi
 1014fac:	8b 85 c0 fe ff ff    	mov    -0x140(%rbp),%eax
 1014fb2:	83 f8 00             	cmp    $0x0,%eax
 1014fb5:	74 0b                	je     1014fc2 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1802>
 1014fb7:	49 89 ff             	mov    %rdi,%r15
 1014fba:	e8 81 67 00 00       	call   101b740 <myl_qbe_rc_slot_drop>
 1014fbf:	4c 89 ff             	mov    %r15,%rdi
 1014fc2:	48 8b 85 08 ff ff ff 	mov    -0xf8(%rbp),%rax
 1014fc9:	48 89 85 e0 fe ff ff 	mov    %rax,-0x120(%rbp)
 1014fd0:	48 8b 85 10 ff ff ff 	mov    -0xf0(%rbp),%rax
 1014fd7:	48 89 85 e8 fe ff ff 	mov    %rax,-0x118(%rbp)
 1014fde:	48 8d 05 3b b0 01 00 	lea    0x1b03b(%rip),%rax        # 1030020 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 1014fe5:	48 89 85 10 fe ff ff 	mov    %rax,-0x1f0(%rbp)
 1014fec:	48 8d 85 e0 fe ff ff 	lea    -0x120(%rbp),%rax
 1014ff3:	48 89 85 18 fe ff ff 	mov    %rax,-0x1e8(%rbp)
 1014ffa:	4c 89 b5 20 fe ff ff 	mov    %r14,-0x1e0(%rbp)
 1015001:	c7 85 28 fe ff ff 02 	movl   $0x2,-0x1d8(%rbp)
 1015008:	00 00 00 
 101500b:	c7 85 d0 fe ff ff 00 	movl   $0x0,-0x130(%rbp)
 1015012:	00 00 00 
 1015015:	c7 85 b8 fe ff ff 01 	movl   $0x1,-0x148(%rbp)
 101501c:	00 00 00 
 101501f:	48 8d 85 e0 fe ff ff 	lea    -0x120(%rbp),%rax
 1015026:	48 89 85 28 ff ff ff 	mov    %rax,-0xd8(%rbp)
 101502d:	4d 89 6c 24 10       	mov    %r13,0x10(%r12)
 1015032:	4c 8b bd 28 ff ff ff 	mov    -0xd8(%rbp),%r15
 1015039:	8b 85 b8 fe ff ff    	mov    -0x148(%rbp),%eax
 101503f:	83 f8 00             	cmp    $0x0,%eax
 1015042:	0f 85 94 00 00 00    	jne    10150dc <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x191c>
 1015048:	49 89 fe             	mov    %rdi,%r14
 101504b:	e8 50 92 00 00       	call   101e2a0 <myl_qbe_region_mark>
 1015050:	4c 89 f9             	mov    %r15,%rcx
 1015053:	4c 89 f7             	mov    %r14,%rdi
 1015056:	49 89 c0             	mov    %rax,%r8
 1015059:	49 89 cf             	mov    %rcx,%r15
 101505c:	48 8d 95 08 ff ff ff 	lea    -0xf8(%rbp),%rdx
 1015063:	48 8d 35 b6 af 01 00 	lea    0x1afb6(%rip),%rsi        # 1030020 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 101506a:	49 89 fe             	mov    %rdi,%r14
 101506d:	4c 89 e7             	mov    %r12,%rdi
 1015070:	e8 ab 61 01 00       	call   102b220 <myl_rc_native_copy>
 1015075:	4c 89 f7             	mov    %r14,%rdi
 1015078:	83 f8 00             	cmp    $0x0,%eax
 101507b:	75 23                	jne    10150a0 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x18e0>
 101507d:	48 89 fb             	mov    %rdi,%rbx
 1015080:	4c 89 e7             	mov    %r12,%rdi
 1015083:	e8 38 ee 00 00       	call   1023ec0 <myl_rc_take_failure>
 1015088:	48 89 df             	mov    %rbx,%rdi
 101508b:	89 c6                	mov    %eax,%esi
 101508d:	48 89 fb             	mov    %rdi,%rbx
 1015090:	e8 cb 64 00 00       	call   101b560 <myl_qbe_rc_status>
 1015095:	48 89 df             	mov    %rbx,%rdi
 1015098:	4c 89 eb             	mov    %r13,%rbx
 101509b:	e9 3b 0b 00 00       	jmp    1015bdb <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x241b>
 10150a0:	48 8d 05 79 af 01 00 	lea    0x1af79(%rip),%rax        # 1030020 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 10150a7:	48 89 85 70 fe ff ff 	mov    %rax,-0x190(%rbp)
 10150ae:	48 8d 85 08 ff ff ff 	lea    -0xf8(%rbp),%rax
 10150b5:	48 89 85 78 fe ff ff 	mov    %rax,-0x188(%rbp)
 10150bc:	48 89 9d 80 fe ff ff 	mov    %rbx,-0x180(%rbp)
 10150c3:	c7 85 88 fe ff ff 02 	movl   $0x2,-0x178(%rbp)
 10150ca:	00 00 00 
 10150cd:	c7 85 d0 fe ff ff 01 	movl   $0x1,-0x130(%rbp)
 10150d4:	00 00 00 
 10150d7:	e9 3b 01 00 00       	jmp    1015217 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1a57>
 10150dc:	49 89 fe             	mov    %rdi,%r14
 10150df:	e8 bc 91 00 00       	call   101e2a0 <myl_qbe_region_mark>
 10150e4:	4c 89 f9             	mov    %r15,%rcx
 10150e7:	4c 89 f7             	mov    %r14,%rdi
 10150ea:	49 89 c0             	mov    %rax,%r8
 10150ed:	48 8d 85 08 ff ff ff 	lea    -0xf8(%rbp),%rax
 10150f4:	48 f7 d8             	neg    %rax
 10150f7:	48 01 c8             	add    %rcx,%rax
 10150fa:	48 8d 95 08 ff ff ff 	lea    -0xf8(%rbp),%rdx
 1015101:	48 29 ca             	sub    %rcx,%rdx
 1015104:	48 83 f8 10          	cmp    $0x10,%rax
 1015108:	0f 92 c0             	setb   %al
 101510b:	0f b6 c0             	movzbl %al,%eax
 101510e:	48 83 fa 10          	cmp    $0x10,%rdx
 1015112:	0f 92 c2             	setb   %dl
 1015115:	0f b6 d2             	movzbl %dl,%edx
 1015118:	09 d0                	or     %edx,%eax
 101511a:	75 76                	jne    1015192 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x19d2>
 101511c:	48 8b 01             	mov    (%rcx),%rax
 101511f:	48 83 f8 00          	cmp    $0x0,%rax
 1015123:	74 1a                	je     101513f <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x197f>
 1015125:	48 83 e8 10          	sub    $0x10,%rax
 1015129:	48 8b 00             	mov    (%rax),%rax
 101512c:	48 ba 01 00 00 00 00 	movabs $0x5000000000000001,%rdx
 1015133:	00 00 50 
 1015136:	48 21 d0             	and    %rdx,%rax
 1015139:	48 83 f8 00          	cmp    $0x0,%rax
 101513d:	75 53                	jne    1015192 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x19d2>
 101513f:	48 8b 41 08          	mov    0x8(%rcx),%rax
 1015143:	48 83 f8 00          	cmp    $0x0,%rax
 1015147:	74 1a                	je     1015163 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x19a3>
 1015149:	48 83 e8 10          	sub    $0x10,%rax
 101514d:	48 8b 00             	mov    (%rax),%rax
 1015150:	48 ba 01 00 00 00 00 	movabs $0x5000000000000001,%rdx
 1015157:	00 00 50 
 101515a:	48 21 d0             	and    %rdx,%rax
 101515d:	48 83 f8 00          	cmp    $0x0,%rax
 1015161:	75 2f                	jne    1015192 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x19d2>
 1015163:	48 8b 01             	mov    (%rcx),%rax
 1015166:	48 89 85 08 ff ff ff 	mov    %rax,-0xf8(%rbp)
 101516d:	48 8b 41 08          	mov    0x8(%rcx),%rax
 1015171:	48 89 85 10 ff ff ff 	mov    %rax,-0xf0(%rbp)
 1015178:	ba 10 00 00 00       	mov    $0x10,%edx
 101517d:	be 00 00 00 00       	mov    $0x0,%esi
 1015182:	49 89 fc             	mov    %rdi,%r12
 1015185:	48 89 cf             	mov    %rcx,%rdi
 1015188:	e8 f3 68 01 00       	call   102ba80 <compiler_rt.fastMemset>
 101518d:	4c 89 e7             	mov    %r12,%rdi
 1015190:	eb 44                	jmp    10151d6 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1a16>
 1015192:	48 8d 95 08 ff ff ff 	lea    -0xf8(%rbp),%rdx
 1015199:	48 8d 35 80 ae 01 00 	lea    0x1ae80(%rip),%rsi        # 1030020 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 10151a0:	49 89 fe             	mov    %rdi,%r14
 10151a3:	4c 89 e7             	mov    %r12,%rdi
 10151a6:	e8 35 65 01 00       	call   102b6e0 <myl_rc_native_take>
 10151ab:	4c 89 f7             	mov    %r14,%rdi
 10151ae:	83 f8 00             	cmp    $0x0,%eax
 10151b1:	75 23                	jne    10151d6 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1a16>
 10151b3:	48 89 fb             	mov    %rdi,%rbx
 10151b6:	4c 89 e7             	mov    %r12,%rdi
 10151b9:	e8 02 ed 00 00       	call   1023ec0 <myl_rc_take_failure>
 10151be:	48 89 df             	mov    %rbx,%rdi
 10151c1:	89 c6                	mov    %eax,%esi
 10151c3:	48 89 fb             	mov    %rdi,%rbx
 10151c6:	e8 95 63 00 00       	call   101b560 <myl_qbe_rc_status>
 10151cb:	48 89 df             	mov    %rbx,%rdi
 10151ce:	4c 89 eb             	mov    %r13,%rbx
 10151d1:	e9 05 0a 00 00       	jmp    1015bdb <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x241b>
 10151d6:	c7 85 b8 fe ff ff 00 	movl   $0x0,-0x148(%rbp)
 10151dd:	00 00 00 
 10151e0:	48 8d 05 39 ae 01 00 	lea    0x1ae39(%rip),%rax        # 1030020 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 10151e7:	48 89 85 70 fe ff ff 	mov    %rax,-0x190(%rbp)
 10151ee:	48 8d 85 08 ff ff ff 	lea    -0xf8(%rbp),%rax
 10151f5:	48 89 85 78 fe ff ff 	mov    %rax,-0x188(%rbp)
 10151fc:	48 89 9d 80 fe ff ff 	mov    %rbx,-0x180(%rbp)
 1015203:	c7 85 88 fe ff ff 02 	movl   $0x2,-0x178(%rbp)
 101520a:	00 00 00 
 101520d:	c7 85 d0 fe ff ff 01 	movl   $0x1,-0x130(%rbp)
 1015214:	00 00 00 
 1015217:	c7 85 d0 fe ff ff 00 	movl   $0x0,-0x130(%rbp)
 101521e:	00 00 00 
 1015221:	48 8d b5 d0 fd ff ff 	lea    -0x230(%rbp),%rsi
 1015228:	48 89 fb             	mov    %rdi,%rbx
 101522b:	e8 40 66 00 00       	call   101b870 <myl_qbe_rc_frame_cleanup>
 1015230:	48 89 df             	mov    %rbx,%rdi
 1015233:	48 8d b5 d0 fd ff ff 	lea    -0x230(%rbp),%rsi
 101523a:	e8 91 64 00 00       	call   101b6d0 <myl_qbe_rc_frame_leave>
 101523f:	48 8b 85 08 ff ff ff 	mov    -0xf8(%rbp),%rax
 1015246:	48 8b 95 10 ff ff ff 	mov    -0xf0(%rbp),%rdx
 101524d:	e9 49 0a 00 00       	jmp    1015c9b <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x24db>
 1015252:	41 b8 40 00 00 00    	mov    $0x40,%r8d
 1015258:	b9 01 00 00 00       	mov    $0x1,%ecx
 101525d:	be 01 00 00 00       	mov    $0x1,%esi
 1015262:	e8 b9 6b 00 00       	call   101be20 <myl_qbe_fail_overflow_op>
 1015267:	0f 0b                	ud2
 1015269:	41 b8 40 00 00 00    	mov    $0x40,%r8d
 101526f:	b9 01 00 00 00       	mov    $0x1,%ecx
 1015274:	be 01 00 00 00       	mov    $0x1,%esi
 1015279:	e8 a2 6b 00 00       	call   101be20 <myl_qbe_fail_overflow_op>
 101527e:	0f 0b                	ud2
 1015280:	ba 08 00 00 00       	mov    $0x8,%edx
 1015285:	be 00 00 00 00       	mov    $0x0,%esi
 101528a:	49 89 ff             	mov    %rdi,%r15
 101528d:	48 8d bd 78 ff ff ff 	lea    -0x88(%rbp),%rdi
 1015294:	e8 e7 67 01 00       	call   102ba80 <compiler_rt.fastMemset>
 1015299:	4c 89 ff             	mov    %r15,%rdi
 101529c:	48 c7 85 78 ff ff ff 	movq   $0x0,-0x88(%rbp)
 10152a3:	00 00 00 00 
 10152a7:	48 8d 05 02 ad 01 00 	lea    0x1ad02(%rip),%rax        # 102ffb0 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 10152ae:	48 89 85 90 fe ff ff 	mov    %rax,-0x170(%rbp)
 10152b5:	48 8d 85 78 ff ff ff 	lea    -0x88(%rbp),%rax
 10152bc:	48 89 85 98 fe ff ff 	mov    %rax,-0x168(%rbp)
 10152c3:	4c 89 ad a0 fe ff ff 	mov    %r13,-0x160(%rbp)
 10152ca:	c7 85 a8 fe ff ff 02 	movl   $0x2,-0x158(%rbp)
 10152d1:	00 00 00 
 10152d4:	c7 85 d8 fe ff ff 01 	movl   $0x1,-0x128(%rbp)
 10152db:	00 00 00 
 10152de:	48 8d 85 78 ff ff ff 	lea    -0x88(%rbp),%rax
 10152e5:	48 89 85 28 ff ff ff 	mov    %rax,-0xd8(%rbp)
 10152ec:	c7 85 d8 fe ff ff 00 	movl   $0x0,-0x128(%rbp)
 10152f3:	00 00 00 
 10152f6:	48 8b 85 78 ff ff ff 	mov    -0x88(%rbp),%rax
 10152fd:	48 89 85 08 ff ff ff 	mov    %rax,-0xf8(%rbp)
 1015304:	48 8d 05 a5 ac 01 00 	lea    0x1aca5(%rip),%rax        # 102ffb0 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 101530b:	48 89 85 70 fe ff ff 	mov    %rax,-0x190(%rbp)
 1015312:	48 8d 85 08 ff ff ff 	lea    -0xf8(%rbp),%rax
 1015319:	48 89 85 78 fe ff ff 	mov    %rax,-0x188(%rbp)
 1015320:	48 89 9d 80 fe ff ff 	mov    %rbx,-0x180(%rbp)
 1015327:	c7 85 88 fe ff ff 02 	movl   $0x2,-0x178(%rbp)
 101532e:	00 00 00 
 1015331:	c7 85 d0 fe ff ff 01 	movl   $0x1,-0x130(%rbp)
 1015338:	00 00 00 
 101533b:	48 8b 85 08 ff ff ff 	mov    -0xf8(%rbp),%rax
 1015342:	48 89 85 e0 fe ff ff 	mov    %rax,-0x120(%rbp)
 1015349:	48 8d 05 60 ac 01 00 	lea    0x1ac60(%rip),%rax        # 102ffb0 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 1015350:	48 89 85 10 fe ff ff 	mov    %rax,-0x1f0(%rbp)
 1015357:	48 8d 85 e0 fe ff ff 	lea    -0x120(%rbp),%rax
 101535e:	48 89 85 18 fe ff ff 	mov    %rax,-0x1e8(%rbp)
 1015365:	4c 89 b5 20 fe ff ff 	mov    %r14,-0x1e0(%rbp)
 101536c:	c7 85 28 fe ff ff 02 	movl   $0x2,-0x1d8(%rbp)
 1015373:	00 00 00 
 1015376:	c7 85 d0 fe ff ff 00 	movl   $0x0,-0x130(%rbp)
 101537d:	00 00 00 
 1015380:	c7 85 b8 fe ff ff 01 	movl   $0x1,-0x148(%rbp)
 1015387:	00 00 00 
 101538a:	48 8d 85 e0 fe ff ff 	lea    -0x120(%rbp),%rax
 1015391:	48 89 85 28 ff ff ff 	mov    %rax,-0xd8(%rbp)
 1015398:	ba 08 00 00 00       	mov    $0x8,%edx
 101539d:	be 00 00 00 00       	mov    $0x0,%esi
 10153a2:	49 89 ff             	mov    %rdi,%r15
 10153a5:	48 8d 7d 80          	lea    -0x80(%rbp),%rdi
 10153a9:	e8 d2 66 01 00       	call   102ba80 <compiler_rt.fastMemset>
 10153ae:	4c 89 ff             	mov    %r15,%rdi
 10153b1:	48 8b 45 d8          	mov    -0x28(%rbp),%rax
 10153b5:	48 c7 45 80 00 00 00 	movq   $0x0,-0x80(%rbp)
 10153bc:	00 
 10153bd:	48 8d 0d ec ab 01 00 	lea    0x1abec(%rip),%rcx        # 102ffb0 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 10153c4:	48 89 8d 90 fe ff ff 	mov    %rcx,-0x170(%rbp)
 10153cb:	48 8d 4d 80          	lea    -0x80(%rbp),%rcx
 10153cf:	48 89 8d 98 fe ff ff 	mov    %rcx,-0x168(%rbp)
 10153d6:	4c 89 ad a0 fe ff ff 	mov    %r13,-0x160(%rbp)
 10153dd:	c7 85 a8 fe ff ff 02 	movl   $0x2,-0x158(%rbp)
 10153e4:	00 00 00 
 10153e7:	c7 85 d8 fe ff ff 01 	movl   $0x1,-0x128(%rbp)
 10153ee:	00 00 00 
 10153f1:	48 8d 4d 80          	lea    -0x80(%rbp),%rcx
 10153f5:	48 89 8d 30 ff ff ff 	mov    %rcx,-0xd0(%rbp)
 10153fc:	c7 85 d8 fe ff ff 00 	movl   $0x0,-0x128(%rbp)
 1015403:	00 00 00 
 1015406:	48 8b 4d 80          	mov    -0x80(%rbp),%rcx
 101540a:	48 89 8d 08 ff ff ff 	mov    %rcx,-0xf8(%rbp)
 1015411:	48 8d 0d 98 ab 01 00 	lea    0x1ab98(%rip),%rcx        # 102ffb0 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 1015418:	48 89 8d 70 fe ff ff 	mov    %rcx,-0x190(%rbp)
 101541f:	48 8d 8d 08 ff ff ff 	lea    -0xf8(%rbp),%rcx
 1015426:	48 89 8d 78 fe ff ff 	mov    %rcx,-0x188(%rbp)
 101542d:	48 89 9d 80 fe ff ff 	mov    %rbx,-0x180(%rbp)
 1015434:	c7 85 88 fe ff ff 02 	movl   $0x2,-0x178(%rbp)
 101543b:	00 00 00 
 101543e:	c7 85 d0 fe ff ff 01 	movl   $0x1,-0x130(%rbp)
 1015445:	00 00 00 
 1015448:	48 8b 8d 08 ff ff ff 	mov    -0xf8(%rbp),%rcx
 101544f:	48 89 8d f0 fe ff ff 	mov    %rcx,-0x110(%rbp)
 1015456:	48 8d 0d 53 ab 01 00 	lea    0x1ab53(%rip),%rcx        # 102ffb0 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 101545d:	48 89 8d 30 fe ff ff 	mov    %rcx,-0x1d0(%rbp)
 1015464:	48 8d 8d f0 fe ff ff 	lea    -0x110(%rbp),%rcx
 101546b:	48 89 8d 38 fe ff ff 	mov    %rcx,-0x1c8(%rbp)
 1015472:	48 89 85 40 fe ff ff 	mov    %rax,-0x1c0(%rbp)
 1015479:	c7 85 48 fe ff ff 02 	movl   $0x2,-0x1b8(%rbp)
 1015480:	00 00 00 
 1015483:	c7 85 d0 fe ff ff 00 	movl   $0x0,-0x130(%rbp)
 101548a:	00 00 00 
 101548d:	c7 85 c0 fe ff ff 01 	movl   $0x1,-0x140(%rbp)
 1015494:	00 00 00 
 1015497:	48 8d 85 f0 fe ff ff 	lea    -0x110(%rbp),%rax
 101549e:	48 89 85 30 ff ff ff 	mov    %rax,-0xd0(%rbp)
 10154a5:	49 8b 4c 24 10       	mov    0x10(%r12),%rcx
 10154aa:	48 8b 85 28 ff ff ff 	mov    -0xd8(%rbp),%rax
 10154b1:	48 89 8d 38 ff ff ff 	mov    %rcx,-0xc8(%rbp)
 10154b8:	48 89 85 40 ff ff ff 	mov    %rax,-0xc0(%rbp)
 10154bf:	48 8d 05 ea aa 01 00 	lea    0x1aaea(%rip),%rax        # 102ffb0 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 10154c6:	48 89 85 48 ff ff ff 	mov    %rax,-0xb8(%rbp)
 10154cd:	48 8d 85 38 ff ff ff 	lea    -0xc8(%rbp),%rax
 10154d4:	49 89 44 24 10       	mov    %rax,0x10(%r12)
 10154d9:	48 8b 85 30 ff ff ff 	mov    -0xd0(%rbp),%rax
 10154e0:	48 8d 8d 38 ff ff ff 	lea    -0xc8(%rbp),%rcx
 10154e7:	48 89 8d 58 ff ff ff 	mov    %rcx,-0xa8(%rbp)
 10154ee:	48 89 85 60 ff ff ff 	mov    %rax,-0xa0(%rbp)
 10154f5:	48 8d 05 b4 aa 01 00 	lea    0x1aab4(%rip),%rax        # 102ffb0 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 10154fc:	48 89 85 68 ff ff ff 	mov    %rax,-0x98(%rbp)
 1015503:	48 8d 85 58 ff ff ff 	lea    -0xa8(%rbp),%rax
 101550a:	49 89 44 24 10       	mov    %rax,0x10(%r12)
 101550f:	ba 10 00 00 00       	mov    $0x10,%edx
 1015514:	be 00 00 00 00       	mov    $0x0,%esi
 1015519:	49 89 ff             	mov    %rdi,%r15
 101551c:	48 8d 7d 88          	lea    -0x78(%rbp),%rdi
 1015520:	e8 5b 65 01 00       	call   102ba80 <compiler_rt.fastMemset>
 1015525:	4c 89 ff             	mov    %r15,%rdi
 1015528:	48 8d 05 f1 aa 01 00 	lea    0x1aaf1(%rip),%rax        # 1030020 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 101552f:	48 89 85 90 fe ff ff 	mov    %rax,-0x170(%rbp)
 1015536:	48 8d 45 88          	lea    -0x78(%rbp),%rax
 101553a:	48 89 85 98 fe ff ff 	mov    %rax,-0x168(%rbp)
 1015541:	4c 89 ad a0 fe ff ff 	mov    %r13,-0x160(%rbp)
 1015548:	c7 85 a8 fe ff ff 02 	movl   $0x2,-0x158(%rbp)
 101554f:	00 00 00 
 1015552:	c7 85 d8 fe ff ff 01 	movl   $0x1,-0x128(%rbp)
 1015559:	00 00 00 
 101555c:	49 89 fd             	mov    %rdi,%r13
 101555f:	e8 3c 8d 00 00       	call   101e2a0 <myl_qbe_region_mark>
 1015564:	4c 89 ef             	mov    %r13,%rdi
 1015567:	4c 8b bd 28 ff ff ff 	mov    -0xd8(%rbp),%r15
 101556e:	8b 85 b8 fe ff ff    	mov    -0x148(%rbp),%eax
 1015574:	83 f8 00             	cmp    $0x0,%eax
 1015577:	0f 85 98 00 00 00    	jne    1015615 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1e55>
 101557d:	49 89 fd             	mov    %rdi,%r13
 1015580:	e8 1b 8d 00 00       	call   101e2a0 <myl_qbe_region_mark>
 1015585:	4c 89 f9             	mov    %r15,%rcx
 1015588:	4c 89 ef             	mov    %r13,%rdi
 101558b:	49 89 c0             	mov    %rax,%r8
 101558e:	4c 8b 6d d0          	mov    -0x30(%rbp),%r13
 1015592:	49 89 cf             	mov    %rcx,%r15
 1015595:	48 8d 95 08 ff ff ff 	lea    -0xf8(%rbp),%rdx
 101559c:	48 8d 35 0d aa 01 00 	lea    0x1aa0d(%rip),%rsi        # 102ffb0 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 10155a3:	49 89 ff             	mov    %rdi,%r15
 10155a6:	4c 89 e7             	mov    %r12,%rdi
 10155a9:	e8 72 5c 01 00       	call   102b220 <myl_rc_native_copy>
 10155ae:	4c 89 ff             	mov    %r15,%rdi
 10155b1:	83 f8 00             	cmp    $0x0,%eax
 10155b4:	75 23                	jne    10155d9 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1e19>
 10155b6:	48 89 fb             	mov    %rdi,%rbx
 10155b9:	4c 89 e7             	mov    %r12,%rdi
 10155bc:	e8 ff e8 00 00       	call   1023ec0 <myl_rc_take_failure>
 10155c1:	48 89 df             	mov    %rbx,%rdi
 10155c4:	89 c6                	mov    %eax,%esi
 10155c6:	48 89 fb             	mov    %rdi,%rbx
 10155c9:	e8 92 5f 00 00       	call   101b560 <myl_qbe_rc_status>
 10155ce:	48 89 df             	mov    %rbx,%rdi
 10155d1:	4c 89 eb             	mov    %r13,%rbx
 10155d4:	e9 02 06 00 00       	jmp    1015bdb <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x241b>
 10155d9:	48 8d 05 d0 a9 01 00 	lea    0x1a9d0(%rip),%rax        # 102ffb0 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 10155e0:	48 89 85 70 fe ff ff 	mov    %rax,-0x190(%rbp)
 10155e7:	48 8d 85 08 ff ff ff 	lea    -0xf8(%rbp),%rax
 10155ee:	48 89 85 78 fe ff ff 	mov    %rax,-0x188(%rbp)
 10155f5:	48 89 9d 80 fe ff ff 	mov    %rbx,-0x180(%rbp)
 10155fc:	c7 85 88 fe ff ff 02 	movl   $0x2,-0x178(%rbp)
 1015603:	00 00 00 
 1015606:	c7 85 d0 fe ff ff 01 	movl   $0x1,-0x130(%rbp)
 101560d:	00 00 00 
 1015610:	e9 10 01 00 00       	jmp    1015725 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1f65>
 1015615:	49 89 fd             	mov    %rdi,%r13
 1015618:	e8 83 8c 00 00       	call   101e2a0 <myl_qbe_region_mark>
 101561d:	4c 89 f9             	mov    %r15,%rcx
 1015620:	4c 89 ef             	mov    %r13,%rdi
 1015623:	49 89 c0             	mov    %rax,%r8
 1015626:	4c 8b 6d d0          	mov    -0x30(%rbp),%r13
 101562a:	48 8d 85 08 ff ff ff 	lea    -0xf8(%rbp),%rax
 1015631:	48 f7 d8             	neg    %rax
 1015634:	48 01 c8             	add    %rcx,%rax
 1015637:	48 8d 95 08 ff ff ff 	lea    -0xf8(%rbp),%rdx
 101563e:	48 29 ca             	sub    %rcx,%rdx
 1015641:	48 83 f8 08          	cmp    $0x8,%rax
 1015645:	0f 92 c0             	setb   %al
 1015648:	0f b6 c0             	movzbl %al,%eax
 101564b:	48 83 fa 08          	cmp    $0x8,%rdx
 101564f:	0f 92 c2             	setb   %dl
 1015652:	0f b6 d2             	movzbl %dl,%edx
 1015655:	09 d0                	or     %edx,%eax
 1015657:	75 47                	jne    10156a0 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1ee0>
 1015659:	48 8b 01             	mov    (%rcx),%rax
 101565c:	48 83 f8 00          	cmp    $0x0,%rax
 1015660:	74 1a                	je     101567c <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1ebc>
 1015662:	48 83 e8 10          	sub    $0x10,%rax
 1015666:	48 8b 00             	mov    (%rax),%rax
 1015669:	48 ba 01 00 00 00 00 	movabs $0x5000000000000001,%rdx
 1015670:	00 00 50 
 1015673:	48 21 d0             	and    %rdx,%rax
 1015676:	48 83 f8 00          	cmp    $0x0,%rax
 101567a:	75 24                	jne    10156a0 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1ee0>
 101567c:	48 8b 01             	mov    (%rcx),%rax
 101567f:	48 89 85 08 ff ff ff 	mov    %rax,-0xf8(%rbp)
 1015686:	ba 08 00 00 00       	mov    $0x8,%edx
 101568b:	be 00 00 00 00       	mov    $0x0,%esi
 1015690:	49 89 fd             	mov    %rdi,%r13
 1015693:	48 89 cf             	mov    %rcx,%rdi
 1015696:	e8 e5 63 01 00       	call   102ba80 <compiler_rt.fastMemset>
 101569b:	4c 89 ef             	mov    %r13,%rdi
 101569e:	eb 44                	jmp    10156e4 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1f24>
 10156a0:	48 8d 95 08 ff ff ff 	lea    -0xf8(%rbp),%rdx
 10156a7:	48 8d 35 02 a9 01 00 	lea    0x1a902(%rip),%rsi        # 102ffb0 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 10156ae:	49 89 ff             	mov    %rdi,%r15
 10156b1:	4c 89 e7             	mov    %r12,%rdi
 10156b4:	e8 27 60 01 00       	call   102b6e0 <myl_rc_native_take>
 10156b9:	4c 89 ff             	mov    %r15,%rdi
 10156bc:	83 f8 00             	cmp    $0x0,%eax
 10156bf:	75 23                	jne    10156e4 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1f24>
 10156c1:	48 89 fb             	mov    %rdi,%rbx
 10156c4:	4c 89 e7             	mov    %r12,%rdi
 10156c7:	e8 f4 e7 00 00       	call   1023ec0 <myl_rc_take_failure>
 10156cc:	48 89 df             	mov    %rbx,%rdi
 10156cf:	89 c6                	mov    %eax,%esi
 10156d1:	48 89 fb             	mov    %rdi,%rbx
 10156d4:	e8 87 5e 00 00       	call   101b560 <myl_qbe_rc_status>
 10156d9:	48 89 df             	mov    %rbx,%rdi
 10156dc:	4c 89 eb             	mov    %r13,%rbx
 10156df:	e9 f7 04 00 00       	jmp    1015bdb <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x241b>
 10156e4:	c7 85 b8 fe ff ff 00 	movl   $0x0,-0x148(%rbp)
 10156eb:	00 00 00 
 10156ee:	48 8d 05 bb a8 01 00 	lea    0x1a8bb(%rip),%rax        # 102ffb0 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 10156f5:	48 89 85 70 fe ff ff 	mov    %rax,-0x190(%rbp)
 10156fc:	48 8d 85 08 ff ff ff 	lea    -0xf8(%rbp),%rax
 1015703:	48 89 85 78 fe ff ff 	mov    %rax,-0x188(%rbp)
 101570a:	48 89 9d 80 fe ff ff 	mov    %rbx,-0x180(%rbp)
 1015711:	c7 85 88 fe ff ff 02 	movl   $0x2,-0x178(%rbp)
 1015718:	00 00 00 
 101571b:	c7 85 d0 fe ff ff 01 	movl   $0x1,-0x130(%rbp)
 1015722:	00 00 00 
 1015725:	48 8b 85 08 ff ff ff 	mov    -0xf8(%rbp),%rax
 101572c:	48 89 45 88          	mov    %rax,-0x78(%rbp)
 1015730:	c7 85 d0 fe ff ff 00 	movl   $0x0,-0x130(%rbp)
 1015737:	00 00 00 
 101573a:	4c 8b bd 30 ff ff ff 	mov    -0xd0(%rbp),%r15
 1015741:	8b 85 c0 fe ff ff    	mov    -0x140(%rbp),%eax
 1015747:	83 f8 00             	cmp    $0x0,%eax
 101574a:	0f 85 a5 00 00 00    	jne    10157f5 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x2035>
 1015750:	49 89 fd             	mov    %rdi,%r13
 1015753:	e8 48 8b 00 00       	call   101e2a0 <myl_qbe_region_mark>
 1015758:	4c 89 f9             	mov    %r15,%rcx
 101575b:	4c 89 ef             	mov    %r13,%rdi
 101575e:	49 89 c0             	mov    %rax,%r8
 1015761:	4c 8b 6d d0          	mov    -0x30(%rbp),%r13
 1015765:	49 89 cf             	mov    %rcx,%r15
 1015768:	48 8d 95 08 ff ff ff 	lea    -0xf8(%rbp),%rdx
 101576f:	48 8d 35 3a a8 01 00 	lea    0x1a83a(%rip),%rsi        # 102ffb0 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 1015776:	49 89 ff             	mov    %rdi,%r15
 1015779:	4c 89 e7             	mov    %r12,%rdi
 101577c:	e8 9f 5a 01 00       	call   102b220 <myl_rc_native_copy>
 1015781:	4c 89 ff             	mov    %r15,%rdi
 1015784:	89 c1                	mov    %eax,%ecx
 1015786:	48 8b 75 c0          	mov    -0x40(%rbp),%rsi
 101578a:	48 89 f0             	mov    %rsi,%rax
 101578d:	48 8b 75 c8          	mov    -0x38(%rbp),%rsi
 1015791:	83 f9 00             	cmp    $0x0,%ecx
 1015794:	75 23                	jne    10157b9 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1ff9>
 1015796:	48 89 fb             	mov    %rdi,%rbx
 1015799:	4c 89 e7             	mov    %r12,%rdi
 101579c:	e8 1f e7 00 00       	call   1023ec0 <myl_rc_take_failure>
 10157a1:	48 89 df             	mov    %rbx,%rdi
 10157a4:	89 c6                	mov    %eax,%esi
 10157a6:	48 89 fb             	mov    %rdi,%rbx
 10157a9:	e8 b2 5d 00 00       	call   101b560 <myl_qbe_rc_status>
 10157ae:	48 89 df             	mov    %rbx,%rdi
 10157b1:	4c 89 eb             	mov    %r13,%rbx
 10157b4:	e9 22 04 00 00       	jmp    1015bdb <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x241b>
 10157b9:	48 8d 0d f0 a7 01 00 	lea    0x1a7f0(%rip),%rcx        # 102ffb0 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 10157c0:	48 89 8d 70 fe ff ff 	mov    %rcx,-0x190(%rbp)
 10157c7:	48 8d 8d 08 ff ff ff 	lea    -0xf8(%rbp),%rcx
 10157ce:	48 89 8d 78 fe ff ff 	mov    %rcx,-0x188(%rbp)
 10157d5:	48 89 9d 80 fe ff ff 	mov    %rbx,-0x180(%rbp)
 10157dc:	c7 85 88 fe ff ff 02 	movl   $0x2,-0x178(%rbp)
 10157e3:	00 00 00 
 10157e6:	c7 85 d0 fe ff ff 01 	movl   $0x1,-0x130(%rbp)
 10157ed:	00 00 00 
 10157f0:	e9 28 01 00 00       	jmp    101591d <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x215d>
 10157f5:	49 89 fd             	mov    %rdi,%r13
 10157f8:	e8 a3 8a 00 00       	call   101e2a0 <myl_qbe_region_mark>
 10157fd:	4c 89 f9             	mov    %r15,%rcx
 1015800:	4c 89 ef             	mov    %r13,%rdi
 1015803:	49 89 c0             	mov    %rax,%r8
 1015806:	4c 8b 6d d0          	mov    -0x30(%rbp),%r13
 101580a:	48 8d 85 08 ff ff ff 	lea    -0xf8(%rbp),%rax
 1015811:	48 f7 d8             	neg    %rax
 1015814:	48 01 c8             	add    %rcx,%rax
 1015817:	48 8d 95 08 ff ff ff 	lea    -0xf8(%rbp),%rdx
 101581e:	48 29 ca             	sub    %rcx,%rdx
 1015821:	48 83 f8 08          	cmp    $0x8,%rax
 1015825:	0f 92 c0             	setb   %al
 1015828:	0f b6 c0             	movzbl %al,%eax
 101582b:	48 83 fa 08          	cmp    $0x8,%rdx
 101582f:	0f 92 c2             	setb   %dl
 1015832:	0f b6 d2             	movzbl %dl,%edx
 1015835:	09 d0                	or     %edx,%eax
 1015837:	75 52                	jne    101588b <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x20cb>
 1015839:	48 8b 01             	mov    (%rcx),%rax
 101583c:	48 83 f8 00          	cmp    $0x0,%rax
 1015840:	74 1a                	je     101585c <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x209c>
 1015842:	48 83 e8 10          	sub    $0x10,%rax
 1015846:	48 8b 00             	mov    (%rax),%rax
 1015849:	48 ba 01 00 00 00 00 	movabs $0x5000000000000001,%rdx
 1015850:	00 00 50 
 1015853:	48 21 d0             	and    %rdx,%rax
 1015856:	48 83 f8 00          	cmp    $0x0,%rax
 101585a:	75 2f                	jne    101588b <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x20cb>
 101585c:	48 8b 01             	mov    (%rcx),%rax
 101585f:	48 89 85 08 ff ff ff 	mov    %rax,-0xf8(%rbp)
 1015866:	ba 08 00 00 00       	mov    $0x8,%edx
 101586b:	be 00 00 00 00       	mov    $0x0,%esi
 1015870:	49 89 ff             	mov    %rdi,%r15
 1015873:	48 89 cf             	mov    %rcx,%rdi
 1015876:	e8 05 62 01 00       	call   102ba80 <compiler_rt.fastMemset>
 101587b:	4c 89 ff             	mov    %r15,%rdi
 101587e:	48 8b 75 c0          	mov    -0x40(%rbp),%rsi
 1015882:	48 89 f0             	mov    %rsi,%rax
 1015885:	48 8b 75 c8          	mov    -0x38(%rbp),%rsi
 1015889:	eb 51                	jmp    10158dc <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x211c>
 101588b:	48 8d 95 08 ff ff ff 	lea    -0xf8(%rbp),%rdx
 1015892:	48 8d 35 17 a7 01 00 	lea    0x1a717(%rip),%rsi        # 102ffb0 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 1015899:	49 89 ff             	mov    %rdi,%r15
 101589c:	4c 89 e7             	mov    %r12,%rdi
 101589f:	e8 3c 5e 01 00       	call   102b6e0 <myl_rc_native_take>
 10158a4:	4c 89 ff             	mov    %r15,%rdi
 10158a7:	89 c1                	mov    %eax,%ecx
 10158a9:	48 8b 75 c0          	mov    -0x40(%rbp),%rsi
 10158ad:	48 89 f0             	mov    %rsi,%rax
 10158b0:	48 8b 75 c8          	mov    -0x38(%rbp),%rsi
 10158b4:	83 f9 00             	cmp    $0x0,%ecx
 10158b7:	75 23                	jne    10158dc <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x211c>
 10158b9:	48 89 fb             	mov    %rdi,%rbx
 10158bc:	4c 89 e7             	mov    %r12,%rdi
 10158bf:	e8 fc e5 00 00       	call   1023ec0 <myl_rc_take_failure>
 10158c4:	48 89 df             	mov    %rbx,%rdi
 10158c7:	89 c6                	mov    %eax,%esi
 10158c9:	48 89 fb             	mov    %rdi,%rbx
 10158cc:	e8 8f 5c 00 00       	call   101b560 <myl_qbe_rc_status>
 10158d1:	48 89 df             	mov    %rbx,%rdi
 10158d4:	4c 89 eb             	mov    %r13,%rbx
 10158d7:	e9 ff 02 00 00       	jmp    1015bdb <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x241b>
 10158dc:	c7 85 c0 fe ff ff 00 	movl   $0x0,-0x140(%rbp)
 10158e3:	00 00 00 
 10158e6:	48 8d 0d c3 a6 01 00 	lea    0x1a6c3(%rip),%rcx        # 102ffb0 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 10158ed:	48 89 8d 70 fe ff ff 	mov    %rcx,-0x190(%rbp)
 10158f4:	48 8d 8d 08 ff ff ff 	lea    -0xf8(%rbp),%rcx
 10158fb:	48 89 8d 78 fe ff ff 	mov    %rcx,-0x188(%rbp)
 1015902:	48 89 9d 80 fe ff ff 	mov    %rbx,-0x180(%rbp)
 1015909:	c7 85 88 fe ff ff 02 	movl   $0x2,-0x178(%rbp)
 1015910:	00 00 00 
 1015913:	c7 85 d0 fe ff ff 01 	movl   $0x1,-0x130(%rbp)
 101591a:	00 00 00 
 101591d:	48 8b 8d 08 ff ff ff 	mov    -0xf8(%rbp),%rcx
 1015924:	48 89 4d 90          	mov    %rcx,-0x70(%rbp)
 1015928:	c7 85 d0 fe ff ff 00 	movl   $0x0,-0x130(%rbp)
 101592f:	00 00 00 
 1015932:	48 8d 4d 88          	lea    -0x78(%rbp),%rcx
 1015936:	48 89 8d 28 ff ff ff 	mov    %rcx,-0xd8(%rbp)
 101593d:	c7 85 d8 fe ff ff 00 	movl   $0x0,-0x128(%rbp)
 1015944:	00 00 00 
 1015947:	48 8b 4d 88          	mov    -0x78(%rbp),%rcx
 101594b:	48 89 8d 08 ff ff ff 	mov    %rcx,-0xf8(%rbp)
 1015952:	48 8b 4d 90          	mov    -0x70(%rbp),%rcx
 1015956:	48 89 8d 10 ff ff ff 	mov    %rcx,-0xf0(%rbp)
 101595d:	48 8d 0d bc a6 01 00 	lea    0x1a6bc(%rip),%rcx        # 1030020 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 1015964:	48 89 8d 70 fe ff ff 	mov    %rcx,-0x190(%rbp)
 101596b:	48 8d 8d 08 ff ff ff 	lea    -0xf8(%rbp),%rcx
 1015972:	48 89 8d 78 fe ff ff 	mov    %rcx,-0x188(%rbp)
 1015979:	48 89 9d 80 fe ff ff 	mov    %rbx,-0x180(%rbp)
 1015980:	c7 85 88 fe ff ff 02 	movl   $0x2,-0x178(%rbp)
 1015987:	00 00 00 
 101598a:	c7 85 d0 fe ff ff 01 	movl   $0x1,-0x130(%rbp)
 1015991:	00 00 00 
 1015994:	8b 8d b8 fe ff ff    	mov    -0x148(%rbp),%ecx
 101599a:	83 f9 00             	cmp    $0x0,%ecx
 101599d:	75 05                	jne    10159a4 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x21e4>
 101599f:	48 89 c6             	mov    %rax,%rsi
 10159a2:	eb 0f                	jmp    10159b3 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x21f3>
 10159a4:	49 89 ff             	mov    %rdi,%r15
 10159a7:	e8 94 5d 00 00       	call   101b740 <myl_qbe_rc_slot_drop>
 10159ac:	4c 89 ff             	mov    %r15,%rdi
 10159af:	48 8b 75 c0          	mov    -0x40(%rbp),%rsi
 10159b3:	8b 85 c0 fe ff ff    	mov    -0x140(%rbp),%eax
 10159b9:	83 f8 00             	cmp    $0x0,%eax
 10159bc:	74 0b                	je     10159c9 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x2209>
 10159be:	49 89 ff             	mov    %rdi,%r15
 10159c1:	e8 7a 5d 00 00       	call   101b740 <myl_qbe_rc_slot_drop>
 10159c6:	4c 89 ff             	mov    %r15,%rdi
 10159c9:	48 8b 85 08 ff ff ff 	mov    -0xf8(%rbp),%rax
 10159d0:	48 89 85 e0 fe ff ff 	mov    %rax,-0x120(%rbp)
 10159d7:	48 8b 85 10 ff ff ff 	mov    -0xf0(%rbp),%rax
 10159de:	48 89 85 e8 fe ff ff 	mov    %rax,-0x118(%rbp)
 10159e5:	48 8d 05 34 a6 01 00 	lea    0x1a634(%rip),%rax        # 1030020 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 10159ec:	48 89 85 10 fe ff ff 	mov    %rax,-0x1f0(%rbp)
 10159f3:	48 8d 85 e0 fe ff ff 	lea    -0x120(%rbp),%rax
 10159fa:	48 89 85 18 fe ff ff 	mov    %rax,-0x1e8(%rbp)
 1015a01:	4c 89 b5 20 fe ff ff 	mov    %r14,-0x1e0(%rbp)
 1015a08:	c7 85 28 fe ff ff 02 	movl   $0x2,-0x1d8(%rbp)
 1015a0f:	00 00 00 
 1015a12:	c7 85 d0 fe ff ff 00 	movl   $0x0,-0x130(%rbp)
 1015a19:	00 00 00 
 1015a1c:	c7 85 b8 fe ff ff 01 	movl   $0x1,-0x148(%rbp)
 1015a23:	00 00 00 
 1015a26:	48 8d 85 e0 fe ff ff 	lea    -0x120(%rbp),%rax
 1015a2d:	48 89 85 28 ff ff ff 	mov    %rax,-0xd8(%rbp)
 1015a34:	4d 89 6c 24 10       	mov    %r13,0x10(%r12)
 1015a39:	4c 8b bd 28 ff ff ff 	mov    -0xd8(%rbp),%r15
 1015a40:	8b 85 b8 fe ff ff    	mov    -0x148(%rbp),%eax
 1015a46:	83 f8 00             	cmp    $0x0,%eax
 1015a49:	0f 85 94 00 00 00    	jne    1015ae3 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x2323>
 1015a4f:	49 89 fe             	mov    %rdi,%r14
 1015a52:	e8 49 88 00 00       	call   101e2a0 <myl_qbe_region_mark>
 1015a57:	4c 89 f9             	mov    %r15,%rcx
 1015a5a:	4c 89 f7             	mov    %r14,%rdi
 1015a5d:	49 89 c0             	mov    %rax,%r8
 1015a60:	49 89 cf             	mov    %rcx,%r15
 1015a63:	48 8d 95 08 ff ff ff 	lea    -0xf8(%rbp),%rdx
 1015a6a:	48 8d 35 af a5 01 00 	lea    0x1a5af(%rip),%rsi        # 1030020 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 1015a71:	49 89 fe             	mov    %rdi,%r14
 1015a74:	4c 89 e7             	mov    %r12,%rdi
 1015a77:	e8 a4 57 01 00       	call   102b220 <myl_rc_native_copy>
 1015a7c:	4c 89 f7             	mov    %r14,%rdi
 1015a7f:	83 f8 00             	cmp    $0x0,%eax
 1015a82:	75 23                	jne    1015aa7 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x22e7>
 1015a84:	48 89 fb             	mov    %rdi,%rbx
 1015a87:	4c 89 e7             	mov    %r12,%rdi
 1015a8a:	e8 31 e4 00 00       	call   1023ec0 <myl_rc_take_failure>
 1015a8f:	48 89 df             	mov    %rbx,%rdi
 1015a92:	89 c6                	mov    %eax,%esi
 1015a94:	48 89 fb             	mov    %rdi,%rbx
 1015a97:	e8 c4 5a 00 00       	call   101b560 <myl_qbe_rc_status>
 1015a9c:	48 89 df             	mov    %rbx,%rdi
 1015a9f:	4c 89 eb             	mov    %r13,%rbx
 1015aa2:	e9 34 01 00 00       	jmp    1015bdb <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x241b>
 1015aa7:	48 8d 05 72 a5 01 00 	lea    0x1a572(%rip),%rax        # 1030020 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 1015aae:	48 89 85 70 fe ff ff 	mov    %rax,-0x190(%rbp)
 1015ab5:	48 8d 85 08 ff ff ff 	lea    -0xf8(%rbp),%rax
 1015abc:	48 89 85 78 fe ff ff 	mov    %rax,-0x188(%rbp)
 1015ac3:	48 89 9d 80 fe ff ff 	mov    %rbx,-0x180(%rbp)
 1015aca:	c7 85 88 fe ff ff 02 	movl   $0x2,-0x178(%rbp)
 1015ad1:	00 00 00 
 1015ad4:	c7 85 d0 fe ff ff 01 	movl   $0x1,-0x130(%rbp)
 1015adb:	00 00 00 
 1015ade:	e9 82 01 00 00       	jmp    1015c65 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x24a5>
 1015ae3:	49 89 fe             	mov    %rdi,%r14
 1015ae6:	e8 b5 87 00 00       	call   101e2a0 <myl_qbe_region_mark>
 1015aeb:	4c 89 f9             	mov    %r15,%rcx
 1015aee:	4c 89 f7             	mov    %r14,%rdi
 1015af1:	49 89 c0             	mov    %rax,%r8
 1015af4:	48 8d 85 08 ff ff ff 	lea    -0xf8(%rbp),%rax
 1015afb:	48 f7 d8             	neg    %rax
 1015afe:	48 01 c8             	add    %rcx,%rax
 1015b01:	48 8d 95 08 ff ff ff 	lea    -0xf8(%rbp),%rdx
 1015b08:	48 29 ca             	sub    %rcx,%rdx
 1015b0b:	48 83 f8 10          	cmp    $0x10,%rax
 1015b0f:	0f 92 c0             	setb   %al
 1015b12:	0f b6 c0             	movzbl %al,%eax
 1015b15:	48 83 fa 10          	cmp    $0x10,%rdx
 1015b19:	0f 92 c2             	setb   %dl
 1015b1c:	0f b6 d2             	movzbl %dl,%edx
 1015b1f:	09 d0                	or     %edx,%eax
 1015b21:	75 79                	jne    1015b9c <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x23dc>
 1015b23:	48 8b 01             	mov    (%rcx),%rax
 1015b26:	48 83 f8 00          	cmp    $0x0,%rax
 1015b2a:	74 1a                	je     1015b46 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x2386>
 1015b2c:	48 83 e8 10          	sub    $0x10,%rax
 1015b30:	48 8b 00             	mov    (%rax),%rax
 1015b33:	48 ba 01 00 00 00 00 	movabs $0x5000000000000001,%rdx
 1015b3a:	00 00 50 
 1015b3d:	48 21 d0             	and    %rdx,%rax
 1015b40:	48 83 f8 00          	cmp    $0x0,%rax
 1015b44:	75 56                	jne    1015b9c <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x23dc>
 1015b46:	48 8b 41 08          	mov    0x8(%rcx),%rax
 1015b4a:	48 83 f8 00          	cmp    $0x0,%rax
 1015b4e:	74 1a                	je     1015b6a <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x23aa>
 1015b50:	48 83 e8 10          	sub    $0x10,%rax
 1015b54:	48 8b 00             	mov    (%rax),%rax
 1015b57:	48 ba 01 00 00 00 00 	movabs $0x5000000000000001,%rdx
 1015b5e:	00 00 50 
 1015b61:	48 21 d0             	and    %rdx,%rax
 1015b64:	48 83 f8 00          	cmp    $0x0,%rax
 1015b68:	75 32                	jne    1015b9c <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x23dc>
 1015b6a:	48 8b 01             	mov    (%rcx),%rax
 1015b6d:	48 89 85 08 ff ff ff 	mov    %rax,-0xf8(%rbp)
 1015b74:	48 8b 41 08          	mov    0x8(%rcx),%rax
 1015b78:	48 89 85 10 ff ff ff 	mov    %rax,-0xf0(%rbp)
 1015b7f:	ba 10 00 00 00       	mov    $0x10,%edx
 1015b84:	be 00 00 00 00       	mov    $0x0,%esi
 1015b89:	49 89 fc             	mov    %rdi,%r12
 1015b8c:	48 89 cf             	mov    %rcx,%rdi
 1015b8f:	e8 ec 5e 01 00       	call   102ba80 <compiler_rt.fastMemset>
 1015b94:	4c 89 e7             	mov    %r12,%rdi
 1015b97:	e9 88 00 00 00       	jmp    1015c24 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x2464>
 1015b9c:	48 8d 95 08 ff ff ff 	lea    -0xf8(%rbp),%rdx
 1015ba3:	48 8d 35 76 a4 01 00 	lea    0x1a476(%rip),%rsi        # 1030020 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 1015baa:	49 89 fe             	mov    %rdi,%r14
 1015bad:	4c 89 e7             	mov    %r12,%rdi
 1015bb0:	e8 2b 5b 01 00       	call   102b6e0 <myl_rc_native_take>
 1015bb5:	4c 89 f7             	mov    %r14,%rdi
 1015bb8:	83 f8 00             	cmp    $0x0,%eax
 1015bbb:	75 67                	jne    1015c24 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x2464>
 1015bbd:	4c 89 eb             	mov    %r13,%rbx
 1015bc0:	49 89 fd             	mov    %rdi,%r13
 1015bc3:	4c 89 e7             	mov    %r12,%rdi
 1015bc6:	e8 f5 e2 00 00       	call   1023ec0 <myl_rc_take_failure>
 1015bcb:	4c 89 ef             	mov    %r13,%rdi
 1015bce:	89 c6                	mov    %eax,%esi
 1015bd0:	49 89 fd             	mov    %rdi,%r13
 1015bd3:	e8 88 59 00 00       	call   101b560 <myl_qbe_rc_status>
 1015bd8:	4c 89 ef             	mov    %r13,%rdi
 1015bdb:	48 8d b5 d0 fd ff ff 	lea    -0x230(%rbp),%rsi
 1015be2:	49 89 fd             	mov    %rdi,%r13
 1015be5:	e8 86 5c 00 00       	call   101b870 <myl_qbe_rc_frame_cleanup>
 1015bea:	4c 89 ef             	mov    %r13,%rdi
 1015bed:	48 8d b5 d0 fd ff ff 	lea    -0x230(%rbp),%rsi
 1015bf4:	e8 d7 5a 00 00       	call   101b6d0 <myl_qbe_rc_frame_leave>
 1015bf9:	49 89 5c 24 10       	mov    %rbx,0x10(%r12)
 1015bfe:	ba 10 00 00 00       	mov    $0x10,%edx
 1015c03:	be 00 00 00 00       	mov    $0x0,%esi
 1015c08:	48 8d bd c0 fd ff ff 	lea    -0x240(%rbp),%rdi
 1015c0f:	e8 6c 5e 01 00       	call   102ba80 <compiler_rt.fastMemset>
 1015c14:	48 8b 85 c0 fd ff ff 	mov    -0x240(%rbp),%rax
 1015c1b:	48 8b 95 c8 fd ff ff 	mov    -0x238(%rbp),%rdx
 1015c22:	eb 77                	jmp    1015c9b <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x24db>
 1015c24:	c7 85 b8 fe ff ff 00 	movl   $0x0,-0x148(%rbp)
 1015c2b:	00 00 00 
 1015c2e:	48 8d 05 eb a3 01 00 	lea    0x1a3eb(%rip),%rax        # 1030020 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 1015c35:	48 89 85 70 fe ff ff 	mov    %rax,-0x190(%rbp)
 1015c3c:	48 8d 85 08 ff ff ff 	lea    -0xf8(%rbp),%rax
 1015c43:	48 89 85 78 fe ff ff 	mov    %rax,-0x188(%rbp)
 1015c4a:	48 89 9d 80 fe ff ff 	mov    %rbx,-0x180(%rbp)
 1015c51:	c7 85 88 fe ff ff 02 	movl   $0x2,-0x178(%rbp)
 1015c58:	00 00 00 
 1015c5b:	c7 85 d0 fe ff ff 01 	movl   $0x1,-0x130(%rbp)
 1015c62:	00 00 00 
 1015c65:	c7 85 d0 fe ff ff 00 	movl   $0x0,-0x130(%rbp)
 1015c6c:	00 00 00 
 1015c6f:	48 8d b5 d0 fd ff ff 	lea    -0x230(%rbp),%rsi
 1015c76:	48 89 fb             	mov    %rdi,%rbx
 1015c79:	e8 f2 5b 00 00       	call   101b870 <myl_qbe_rc_frame_cleanup>
 1015c7e:	48 89 df             	mov    %rbx,%rdi
 1015c81:	48 8d b5 d0 fd ff ff 	lea    -0x230(%rbp),%rsi
 1015c88:	e8 43 5a 00 00       	call   101b6d0 <myl_qbe_rc_frame_leave>
 1015c8d:	48 8b 85 08 ff ff ff 	mov    -0xf8(%rbp),%rax
 1015c94:	48 8b 95 10 ff ff ff 	mov    -0xf0(%rbp),%rdx
 1015c9b:	41 5f                	pop    %r15
 1015c9d:	41 5e                	pop    %r14
 1015c9f:	41 5d                	pop    %r13
 1015ca1:	41 5c                	pop    %r12
 1015ca3:	5b                   	pop    %rbx
 1015ca4:	c9                   	leave
 1015ca5:	c3                   	ret
 1015ca6:	e8 c5 62 00 00       	call   101bf70 <myl_qbe_fail_frame>
 1015cab:	0f 0b                	ud2

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
