
.tmp-rc/profile/gap-allocator-qbe-rc-repeat:     file format elf64-x86-64


Disassembly of section .text:

0000000001027850 <slab_take>:
 1027850:	push   %rbp
 1027851:	mov    %rsp,%rbp
 1027854:	push   %r15
 1027856:	push   %r14
 1027858:	push   %r13
 102785a:	push   %r12
 102785c:	push   %rbx
 102785d:	push   %rax
 102785e:	test   %rdi,%rdi
 1027861:	je     1027a66 <slab_take+0x216>
 1027867:	mov    %rdi,%rbx
 102786a:	mov    0x1608(%rdi),%rax
 1027871:	test   %rax,%rax
 1027874:	je     1027a66 <slab_take+0x216>
 102787a:	mov    0x18(%rax),%r14
 102787e:	mov    %rsi,%r15
 1027881:	shl    $0x4,%r15
 1027885:	mov    0x8(%r14,%r15,1),%rax
 102788a:	test   %rax,%rax
 102788d:	jne    10279d3 <slab_take+0x183>
 1027893:	mov    %rsi,%r12
 1027896:	mov    $0x10000,%esi
 102789b:	mov    %rbx,%rdi
 102789e:	call   1027d40 <reserve>
 10278a3:	test   %eax,%eax
 10278a5:	je     1027961 <slab_take+0x111>
 10278ab:	mov    $0x10000,%edi
 10278b0:	mov    $0x10000,%esi
 10278b5:	call   1029630 <aligned_alloc@plt>
 10278ba:	test   %rax,%rax
 10278bd:	jne    1027920 <slab_take+0xd0>
 10278bf:	xor    %r13d,%r13d
 10278c2:	jmp    10278dd <slab_take+0x8d>
 10278c4:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 10278d0:	add    $0x10,%r13
 10278d4:	cmp    $0x200,%r13
 10278db:	je     102790c <slab_take+0xbc>
 10278dd:	mov    0x1608(%rbx),%rax
 10278e4:	test   %rax,%rax
 10278e7:	je     1027a66 <slab_take+0x216>
 10278ed:	mov    0x18(%rax),%rax
 10278f1:	mov    0x8(%rax,%r13,1),%rsi
 10278f6:	test   %rsi,%rsi
 10278f9:	je     10278d0 <slab_take+0x80>
 10278fb:	cmpq   $0x0,0x30(%rsi)
 1027900:	jne    10278d0 <slab_take+0x80>
 1027902:	mov    %rbx,%rdi
 1027905:	call   1027e10 <slab_free>
 102790a:	jmp    10278d0 <slab_take+0x80>
 102790c:	mov    $0x10000,%edi
 1027911:	mov    $0x10000,%esi
 1027916:	call   1029630 <aligned_alloc@plt>
 102791b:	test   %rax,%rax
 102791e:	je     1027961 <slab_take+0x111>
 1027920:	vpxor  %xmm0,%xmm0,%xmm0
 1027924:	vmovdqa %ymm0,0x20(%rax)
 1027929:	vmovdqu %ymm0,0x30(%rax)
 102792e:	vmovdqa %ymm0,(%rax)
 1027932:	lea    -0x1ce29(%rip),%rcx        # 100ab10 <strides>
 1027939:	mov    (%rcx,%r12,8),%rcx
 102793d:	mov    %rcx,0x20(%rax)
 1027941:	mov    %r12,0x40(%rax)
 1027945:	cmp    $0xffb0,%rcx
 102794c:	ja     1027972 <slab_take+0x122>
 102794e:	mov    %rax,%rsi
 1027951:	mov    $0xffb0,%eax
 1027956:	xor    %edx,%edx
 1027958:	div    %ecx
 102795a:	mov    %eax,%ecx
 102795c:	mov    %rsi,%rax
 102795f:	jmp    1027974 <slab_take+0x124>
 1027961:	xor    %eax,%eax
 1027963:	add    $0x8,%rsp
 1027967:	pop    %rbx
 1027968:	pop    %r12
 102796a:	pop    %r13
 102796c:	pop    %r14
 102796e:	pop    %r15
 1027970:	pop    %rbp
 1027971:	ret
 1027972:	xor    %ecx,%ecx
 1027974:	mov    %rcx,0x48(%rax)
 1027978:	mov    0x1608(%rbx),%rcx
 102797f:	test   %rcx,%rcx
 1027982:	je     1027a66 <slab_take+0x216>
 1027988:	mov    0x18(%rcx),%rcx
 102798c:	lea    (%rcx,%r15,1),%rdx
 1027990:	mov    (%rcx,%r15,1),%rsi
 1027994:	mov    %rsi,0x8(%rax)
 1027998:	test   %rsi,%rsi
 102799b:	je     10279a0 <slab_take+0x150>
 102799d:	mov    %rax,(%rsi)
 10279a0:	mov    %rax,(%rdx)
 10279a3:	mov    0x8(%rdx),%rsi
 10279a7:	movq   $0x0,0x10(%rax)
 10279af:	mov    %rsi,0x18(%rax)
 10279b3:	test   %rsi,%rsi
 10279b6:	je     10279bc <slab_take+0x16c>
 10279b8:	mov    %rax,0x10(%rsi)
 10279bc:	mov    %rax,0x8(%rdx)
 10279c0:	addq   $0x10000,0x18(%rbx)
 10279c8:	addq   $0x10000,0x208(%rcx)
 10279d3:	mov    0x38(%rax),%rdi
 10279d7:	test   %rdi,%rdi
 10279da:	je     10279ee <slab_take+0x19e>
 10279dc:	mov    (%rdi),%rcx
 10279df:	mov    %rcx,0x38(%rax)
 10279e3:	incq   0x30(%rax)
 10279e7:	test   %rcx,%rcx
 10279ea:	jne    1027a4a <slab_take+0x1fa>
 10279ec:	jmp    1027a11 <slab_take+0x1c1>
 10279ee:	vmovdqu 0x28(%rax),%xmm0
 10279f3:	mov    0x28(%rax),%rcx
 10279f7:	imul   0x20(%rax),%rcx
 10279fc:	lea    (%rax,%rcx,1),%rdi
 1027a00:	add    $0x50,%rdi
 1027a04:	vpcmpeqd %xmm1,%xmm1,%xmm1
 1027a08:	vpsubq %xmm1,%xmm0,%xmm0
 1027a0c:	vmovdqu %xmm0,0x28(%rax)
 1027a11:	mov    0x28(%rax),%rcx
 1027a15:	cmp    0x48(%rax),%rcx
 1027a19:	jne    1027a4a <slab_take+0x1fa>
 1027a1b:	mov    0x10(%rax),%rcx
 1027a1f:	mov    0x18(%rax),%rdx
 1027a23:	test   %rcx,%rcx
 1027a26:	je     1027a2e <slab_take+0x1de>
 1027a28:	mov    %rdx,0x18(%rcx)
 1027a2c:	jmp    1027a35 <slab_take+0x1e5>
 1027a2e:	add    %r15,%r14
 1027a31:	mov    %rdx,0x8(%r14)
 1027a35:	lea    0x10(%rax),%rsi
 1027a39:	test   %rdx,%rdx
 1027a3c:	je     1027a42 <slab_take+0x1f2>
 1027a3e:	mov    %rcx,0x10(%rdx)
 1027a42:	vpxor  %xmm0,%xmm0,%xmm0
 1027a46:	vmovdqu %xmm0,(%rsi)
 1027a4a:	mov    0x20(%rax),%rdx
 1027a4e:	xor    %esi,%esi
 1027a50:	add    $0x8,%rsp
 1027a54:	pop    %rbx
 1027a55:	pop    %r12
 1027a57:	pop    %r13
 1027a59:	pop    %r14
 1027a5b:	pop    %r15
 1027a5d:	pop    %rbp
 1027a5e:	vzeroupper
 1027a61:	jmp    10289e0 <compiler_rt.fastMemset>
 1027a66:	vzeroupper
 1027a69:	call   1020fce <myl_rc_invariant_failed>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
