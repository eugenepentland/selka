
.tmp-rc/profile/gap-allocator-qbe-rc-n12:     file format elf64-x86-64


Disassembly of section .text:

0000000001011840 <myl_f_20f65c28671b40937c5bf23acc7c6f37e5a5ec0622e347b57685725df5ba9e50>:
 1011840:	endbr64
 1011844:	push   %rbp
 1011845:	mov    %rsp,%rbp
 1011848:	sub    $0x40,%rsp
 101184c:	push   %rbx
 101184d:	push   %r12
 101184f:	mov    0x40(%rdi),%rax
 1011853:	lea    -0x8(%rbp),%rcx
 1011857:	cmp    %rax,%rcx
 101185a:	jb     1011a00 <myl_f_20f65c28671b40937c5bf23acc7c6f37e5a5ec0622e347b57685725df5ba9e50+0x1c0>
 1011860:	mov    (%rsi),%rax
 1011863:	mov    %rax,-0x40(%rbp)
 1011867:	mov    0x8(%rsi),%rax
 101186b:	mov    %rax,-0x30(%rbp)
 101186f:	mov    -0x40(%rbp),%rax
 1011873:	cmp    $0x0,%rax
 1011877:	setne  %cl
 101187a:	movzbq %cl,%rcx
 101187e:	cmp    $0x0,%rcx
 1011882:	sete   %dl
 1011885:	movzbq %dl,%rdx
 1011889:	cmp    $0x0,%edx
 101188c:	jne    101189f <myl_f_20f65c28671b40937c5bf23acc7c6f37e5a5ec0622e347b57685725df5ba9e50+0x5f>
 101188e:	cmp    $0x1,%rcx
 1011892:	jne    1011961 <myl_f_20f65c28671b40937c5bf23acc7c6f37e5a5ec0622e347b57685725df5ba9e50+0x121>
 1011898:	mov    $0x0,%edx
 101189d:	jmp    10118a4 <myl_f_20f65c28671b40937c5bf23acc7c6f37e5a5ec0622e347b57685725df5ba9e50+0x64>
 101189f:	mov    $0x1,%edx
 10118a4:	cmp    $0x0,%edx
 10118a7:	jne    10118d6 <myl_f_20f65c28671b40937c5bf23acc7c6f37e5a5ec0622e347b57685725df5ba9e50+0x96>
 10118a9:	mov    -0x30(%rbp),%rdx
 10118ad:	cmp    $0x0,%rdx
 10118b1:	setne  %dl
 10118b4:	movzbq %dl,%rdx
 10118b8:	cmp    $0x0,%rdx
 10118bc:	je     10118cf <myl_f_20f65c28671b40937c5bf23acc7c6f37e5a5ec0622e347b57685725df5ba9e50+0x8f>
 10118be:	cmp    $0x1,%rdx
 10118c2:	jne    1011961 <myl_f_20f65c28671b40937c5bf23acc7c6f37e5a5ec0622e347b57685725df5ba9e50+0x121>
 10118c8:	mov    $0x0,%edx
 10118cd:	jmp    10118db <myl_f_20f65c28671b40937c5bf23acc7c6f37e5a5ec0622e347b57685725df5ba9e50+0x9b>
 10118cf:	mov    $0x1,%edx
 10118d4:	jmp    10118db <myl_f_20f65c28671b40937c5bf23acc7c6f37e5a5ec0622e347b57685725df5ba9e50+0x9b>
 10118d6:	mov    $0x1,%edx
 10118db:	cmp    $0x0,%edx
 10118de:	jne    10119f6 <myl_f_20f65c28671b40937c5bf23acc7c6f37e5a5ec0622e347b57685725df5ba9e50+0x1b6>
 10118e4:	cmp    $0x0,%rcx
 10118e8:	je     10119ef <myl_f_20f65c28671b40937c5bf23acc7c6f37e5a5ec0622e347b57685725df5ba9e50+0x1af>
 10118ee:	cmp    $0x1,%rcx
 10118f2:	jne    1011961 <myl_f_20f65c28671b40937c5bf23acc7c6f37e5a5ec0622e347b57685725df5ba9e50+0x121>
 10118f4:	mov    (%rax),%rcx
 10118f7:	mov    %rcx,-0x40(%rbp)
 10118fb:	mov    0x8(%rax),%rax
 10118ff:	mov    %rax,-0x38(%rbp)
 1011903:	mov    -0x40(%rbp),%rax
 1011907:	mov    %rax,-0x28(%rbp)
 101190b:	mov    -0x38(%rbp),%rax
 101190f:	mov    %rax,-0x20(%rbp)
 1011913:	lea    -0x28(%rbp),%rsi
 1011917:	mov    %rdi,%rbx
 101191a:	call   1011840 <myl_f_20f65c28671b40937c5bf23acc7c6f37e5a5ec0622e347b57685725df5ba9e50>
 101191f:	mov    %rbx,%rdi
 1011922:	mov    %rax,%rcx
 1011925:	mov    %rcx,%rdx
 1011928:	add    $0x1,%rdx
 101192c:	mov    %rdx,%rax
 101192f:	xor    $0x1,%rax
 1011933:	mov    %rdx,%r12
 1011936:	xor    %rcx,%rdx
 1011939:	and    %rdx,%rax
 101193c:	cmp    $0x0,%rax
 1011940:	jl     10119d8 <myl_f_20f65c28671b40937c5bf23acc7c6f37e5a5ec0622e347b57685725df5ba9e50+0x198>
 1011946:	mov    -0x30(%rbp),%rax
 101194a:	cmp    $0x0,%rax
 101194e:	setne  %cl
 1011951:	movzbq %cl,%rcx
 1011955:	cmp    $0x0,%rcx
 1011959:	je     10119d1 <myl_f_20f65c28671b40937c5bf23acc7c6f37e5a5ec0622e347b57685725df5ba9e50+0x191>
 101195b:	cmp    $0x1,%rcx
 101195f:	je     101196b <myl_f_20f65c28671b40937c5bf23acc7c6f37e5a5ec0622e347b57685725df5ba9e50+0x12b>
 1011961:	mov    $0x0,%eax
 1011966:	jmp    10119fb <myl_f_20f65c28671b40937c5bf23acc7c6f37e5a5ec0622e347b57685725df5ba9e50+0x1bb>
 101196b:	mov    (%rax),%rcx
 101196e:	mov    %rcx,-0x40(%rbp)
 1011972:	mov    0x8(%rax),%rax
 1011976:	mov    %rax,-0x38(%rbp)
 101197a:	mov    -0x40(%rbp),%rax
 101197e:	mov    %rax,-0x18(%rbp)
 1011982:	mov    -0x38(%rbp),%rax
 1011986:	mov    %rax,-0x10(%rbp)
 101198a:	lea    -0x18(%rbp),%rsi
 101198e:	mov    %rdi,%rbx
 1011991:	call   1011840 <myl_f_20f65c28671b40937c5bf23acc7c6f37e5a5ec0622e347b57685725df5ba9e50>
 1011996:	mov    %r12,%rdx
 1011999:	mov    %rbx,%rdi
 101199c:	mov    %rax,%rcx
 101199f:	mov    %rcx,%rsi
 10119a2:	add    %rdx,%rsi
 10119a5:	mov    %rdx,%rax
 10119a8:	xor    %rsi,%rax
 10119ab:	xor    %rcx,%rsi
 10119ae:	and    %rsi,%rax
 10119b1:	cmp    $0x0,%rax
 10119b5:	jl     10119bf <myl_f_20f65c28671b40937c5bf23acc7c6f37e5a5ec0622e347b57685725df5ba9e50+0x17f>
 10119b7:	mov    %rcx,%rax
 10119ba:	add    %rdx,%rax
 10119bd:	jmp    10119fb <myl_f_20f65c28671b40937c5bf23acc7c6f37e5a5ec0622e347b57685725df5ba9e50+0x1bb>
 10119bf:	mov    $0x40,%r8d
 10119c5:	mov    $0x0,%esi
 10119ca:	call   1019090 <myl_qbe_fail_overflow_op>
 10119cf:	ud2
 10119d1:	call   1018fc0 <myl_qbe_fail_assert>
 10119d6:	ud2
 10119d8:	mov    $0x40,%r8d
 10119de:	mov    $0x1,%edx
 10119e3:	mov    $0x0,%esi
 10119e8:	call   1019090 <myl_qbe_fail_overflow_op>
 10119ed:	ud2
 10119ef:	call   1018fc0 <myl_qbe_fail_assert>
 10119f4:	ud2
 10119f6:	mov    $0x1,%eax
 10119fb:	pop    %r12
 10119fd:	pop    %rbx
 10119fe:	leave
 10119ff:	ret
 1011a00:	call   10191e0 <myl_qbe_fail_frame>
 1011a05:	ud2

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
