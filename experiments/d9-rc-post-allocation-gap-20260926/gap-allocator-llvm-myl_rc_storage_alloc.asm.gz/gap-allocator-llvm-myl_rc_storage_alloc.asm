
.tmp-rc/profile/gap-allocator-llvm-rc-repeat:     file format elf64-x86-64


Disassembly of section .text:

0000000001029cd0 <myl_rc_storage_alloc>:
 1029cd0:	push   %rbp
 1029cd1:	mov    %rsp,%rbp
 1029cd4:	push   %r15
 1029cd6:	push   %r14
 1029cd8:	push   %r13
 1029cda:	push   %r12
 1029cdc:	push   %rbx
 1029cdd:	sub    $0x28,%rsp
 1029ce1:	test   %rdi,%rdi
 1029ce4:	je     1029e8b <myl_rc_storage_alloc+0x1bb>
 1029cea:	mov    %rsi,%r14
 1029ced:	test   %rsi,%rsi
 1029cf0:	je     1029e8b <myl_rc_storage_alloc+0x1bb>
 1029cf6:	mov    %rdi,%rbx
 1029cf9:	mov    0x1608(%rdi),%rax
 1029d00:	test   %rax,%rax
 1029d03:	je     1029e8b <myl_rc_storage_alloc+0x1bb>
 1029d09:	mov    %ecx,%r15d
 1029d0c:	mov    %rdx,%r12
 1029d0f:	test   %ecx,%ecx
 1029d11:	setne  %cl
 1029d14:	cmp    $0x1,%rdx
 1029d18:	setne  %dl
 1029d1b:	or     %cl,%dl
 1029d1d:	jne    1029d28 <myl_rc_storage_alloc+0x58>
 1029d1f:	cmpq   $0x1029e90,(%rax)
 1029d26:	je     1029d8d <myl_rc_storage_alloc+0xbd>
 1029d28:	mov    %rbx,%rdi
 1029d2b:	mov    %r14,%rsi
 1029d2e:	call   102ab40 <myl_rc_native_shape>
 1029d33:	test   %rax,%rax
 1029d36:	je     1029e7a <myl_rc_storage_alloc+0x1aa>
 1029d3c:	mov    %r14,-0x48(%rbp)
 1029d40:	mov    %r12,-0x40(%rbp)
 1029d44:	mov    %r15d,-0x38(%rbp)
 1029d48:	movl   $0x0,-0x34(%rbp)
 1029d4f:	movq   $0x0,-0x30(%rbp)
 1029d57:	lea    -0x48(%rbp),%rsi
 1029d5b:	lea    -0x30(%rbp),%rdx
 1029d5f:	mov    %rbx,%rdi
 1029d62:	call   1023e00 <myl_rc_new>
 1029d67:	test   %eax,%eax
 1029d69:	je     1029d84 <myl_rc_storage_alloc+0xb4>
 1029d6b:	mov    0x1608(%rbx),%rcx
 1029d72:	test   %rcx,%rcx
 1029d75:	je     1029e8b <myl_rc_storage_alloc+0x1bb>
 1029d7b:	cmpl   $0x0,0x78(%rcx)
 1029d7f:	jne    1029d84 <myl_rc_storage_alloc+0xb4>
 1029d81:	mov    %eax,0x78(%rcx)
 1029d84:	mov    -0x30(%rbp),%rax
 1029d88:	jmp    1029e7c <myl_rc_storage_alloc+0x1ac>
 1029d8d:	mov    0x18(%rax),%r13
 1029d91:	cmp    %r14,0x210(%r13)
 1029d98:	je     1029e1a <myl_rc_storage_alloc+0x14a>
 1029d9e:	mov    %rbx,%rdi
 1029da1:	mov    %r14,%rsi
 1029da4:	call   102ab40 <myl_rc_native_shape>
 1029da9:	test   %rax,%rax
 1029dac:	je     1029e7a <myl_rc_storage_alloc+0x1aa>
 1029db2:	cmpq   $0x10,0x8(%r14)
 1029db7:	ja     1029d3c <myl_rc_storage_alloc+0x6c>
 1029db9:	mov    (%r14),%rax
 1029dbc:	cmp    $0x1fe0,%rax
 1029dc2:	ja     1029d3c <myl_rc_storage_alloc+0x6c>
 1029dc8:	add    $0x20,%rax
 1029dcc:	mov    $0x20,%ecx
 1029dd1:	xor    %esi,%esi
 1029dd3:	jmp    1029de8 <myl_rc_storage_alloc+0x118>
 1029dd5:	data16 cs nopw 0x0(%rax,%rax,1)
 1029de0:	mov    %rdi,%rcx
 1029de3:	cmp    %rcx,%rsi
 1029de6:	jae    1029e0a <myl_rc_storage_alloc+0x13a>
 1029de8:	mov    %rcx,%rdx
 1029deb:	sub    %rsi,%rdx
 1029dee:	shr    $1,%rdx
 1029df1:	lea    (%rdx,%rsi,1),%rdi
 1029df5:	cmp    %rax,0x100d4f0(,%rdi,8)
 1029dfd:	jae    1029de0 <myl_rc_storage_alloc+0x110>
 1029dff:	add    %rdx,%rsi
 1029e02:	inc    %rsi
 1029e05:	cmp    %rcx,%rsi
 1029e08:	jb     1029de8 <myl_rc_storage_alloc+0x118>
 1029e0a:	mov    %r14,0x210(%r13)
 1029e11:	mov    %rsi,0x218(%r13)
 1029e18:	jmp    1029e21 <myl_rc_storage_alloc+0x151>
 1029e1a:	mov    0x218(%r13),%rsi
 1029e21:	mov    %rbx,%rdi
 1029e24:	call   102a110 <slab_take>
 1029e29:	test   %rax,%rax
 1029e2c:	je     1029e61 <myl_rc_storage_alloc+0x191>
 1029e2e:	movq   $0x1,(%rax)
 1029e35:	movq   $0x0,0x8(%rax)
 1029e3d:	movq   $0x4,0x10(%rax)
 1029e45:	mov    %r14,0x18(%rax)
 1029e49:	vmovdqu 0x40(%rbx),%xmm0
 1029e4e:	vpcmpeqd %xmm1,%xmm1,%xmm1
 1029e52:	vpsubq %xmm1,%xmm0,%xmm0
 1029e56:	vmovdqu %xmm0,0x40(%rbx)
 1029e5b:	add    $0x20,%rax
 1029e5f:	jmp    1029e7c <myl_rc_storage_alloc+0x1ac>
 1029e61:	mov    0x1608(%rbx),%rax
 1029e68:	test   %rax,%rax
 1029e6b:	je     1029e8b <myl_rc_storage_alloc+0x1bb>
 1029e6d:	cmpl   $0x0,0x78(%rax)
 1029e71:	jne    1029e7a <myl_rc_storage_alloc+0x1aa>
 1029e73:	movl   $0x1,0x78(%rax)
 1029e7a:	xor    %eax,%eax
 1029e7c:	add    $0x28,%rsp
 1029e80:	pop    %rbx
 1029e81:	pop    %r12
 1029e83:	pop    %r13
 1029e85:	pop    %r14
 1029e87:	pop    %r15
 1029e89:	pop    %rbp
 1029e8a:	ret
 1029e8b:	call   1023be1 <myl_rc_invariant_failed>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
