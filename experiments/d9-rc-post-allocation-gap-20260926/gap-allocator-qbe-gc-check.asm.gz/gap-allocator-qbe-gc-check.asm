
.tmp-rc/profile/gap-allocator-qbe-gc-n12:     file format elf64-x86-64


Disassembly of section .text:

000000000100f790 <myl_f_20f65c28671b40937c5bf23acc7c6f37e5a5ec0622e347b57685725df5ba9e50>:
 100f790:	endbr64
 100f794:	push   %rbp
 100f795:	mov    %rsp,%rbp
 100f798:	sub    $0x40,%rsp
 100f79c:	push   %rbx
 100f79d:	push   %r12
 100f79f:	mov    0x40(%rdi),%rax
 100f7a3:	lea    -0x8(%rbp),%rcx
 100f7a7:	cmp    %rax,%rcx
 100f7aa:	jb     100f950 <myl_f_20f65c28671b40937c5bf23acc7c6f37e5a5ec0622e347b57685725df5ba9e50+0x1c0>
 100f7b0:	mov    (%rsi),%rax
 100f7b3:	mov    %rax,-0x40(%rbp)
 100f7b7:	mov    0x8(%rsi),%rax
 100f7bb:	mov    %rax,-0x30(%rbp)
 100f7bf:	mov    -0x40(%rbp),%rax
 100f7c3:	cmp    $0x0,%rax
 100f7c7:	setne  %cl
 100f7ca:	movzbq %cl,%rcx
 100f7ce:	cmp    $0x0,%rcx
 100f7d2:	sete   %dl
 100f7d5:	movzbq %dl,%rdx
 100f7d9:	cmp    $0x0,%edx
 100f7dc:	jne    100f7ef <myl_f_20f65c28671b40937c5bf23acc7c6f37e5a5ec0622e347b57685725df5ba9e50+0x5f>
 100f7de:	cmp    $0x1,%rcx
 100f7e2:	jne    100f8b1 <myl_f_20f65c28671b40937c5bf23acc7c6f37e5a5ec0622e347b57685725df5ba9e50+0x121>
 100f7e8:	mov    $0x0,%edx
 100f7ed:	jmp    100f7f4 <myl_f_20f65c28671b40937c5bf23acc7c6f37e5a5ec0622e347b57685725df5ba9e50+0x64>
 100f7ef:	mov    $0x1,%edx
 100f7f4:	cmp    $0x0,%edx
 100f7f7:	jne    100f826 <myl_f_20f65c28671b40937c5bf23acc7c6f37e5a5ec0622e347b57685725df5ba9e50+0x96>
 100f7f9:	mov    -0x30(%rbp),%rdx
 100f7fd:	cmp    $0x0,%rdx
 100f801:	setne  %dl
 100f804:	movzbq %dl,%rdx
 100f808:	cmp    $0x0,%rdx
 100f80c:	je     100f81f <myl_f_20f65c28671b40937c5bf23acc7c6f37e5a5ec0622e347b57685725df5ba9e50+0x8f>
 100f80e:	cmp    $0x1,%rdx
 100f812:	jne    100f8b1 <myl_f_20f65c28671b40937c5bf23acc7c6f37e5a5ec0622e347b57685725df5ba9e50+0x121>
 100f818:	mov    $0x0,%edx
 100f81d:	jmp    100f82b <myl_f_20f65c28671b40937c5bf23acc7c6f37e5a5ec0622e347b57685725df5ba9e50+0x9b>
 100f81f:	mov    $0x1,%edx
 100f824:	jmp    100f82b <myl_f_20f65c28671b40937c5bf23acc7c6f37e5a5ec0622e347b57685725df5ba9e50+0x9b>
 100f826:	mov    $0x1,%edx
 100f82b:	cmp    $0x0,%edx
 100f82e:	jne    100f946 <myl_f_20f65c28671b40937c5bf23acc7c6f37e5a5ec0622e347b57685725df5ba9e50+0x1b6>
 100f834:	cmp    $0x0,%rcx
 100f838:	je     100f93f <myl_f_20f65c28671b40937c5bf23acc7c6f37e5a5ec0622e347b57685725df5ba9e50+0x1af>
 100f83e:	cmp    $0x1,%rcx
 100f842:	jne    100f8b1 <myl_f_20f65c28671b40937c5bf23acc7c6f37e5a5ec0622e347b57685725df5ba9e50+0x121>
 100f844:	mov    (%rax),%rcx
 100f847:	mov    %rcx,-0x40(%rbp)
 100f84b:	mov    0x8(%rax),%rax
 100f84f:	mov    %rax,-0x38(%rbp)
 100f853:	mov    -0x40(%rbp),%rax
 100f857:	mov    %rax,-0x28(%rbp)
 100f85b:	mov    -0x38(%rbp),%rax
 100f85f:	mov    %rax,-0x20(%rbp)
 100f863:	lea    -0x28(%rbp),%rsi
 100f867:	mov    %rdi,%rbx
 100f86a:	call   100f790 <myl_f_20f65c28671b40937c5bf23acc7c6f37e5a5ec0622e347b57685725df5ba9e50>
 100f86f:	mov    %rbx,%rdi
 100f872:	mov    %rax,%rcx
 100f875:	mov    %rcx,%rdx
 100f878:	add    $0x1,%rdx
 100f87c:	mov    %rdx,%rax
 100f87f:	xor    $0x1,%rax
 100f883:	mov    %rdx,%r12
 100f886:	xor    %rcx,%rdx
 100f889:	and    %rdx,%rax
 100f88c:	cmp    $0x0,%rax
 100f890:	jl     100f928 <myl_f_20f65c28671b40937c5bf23acc7c6f37e5a5ec0622e347b57685725df5ba9e50+0x198>
 100f896:	mov    -0x30(%rbp),%rax
 100f89a:	cmp    $0x0,%rax
 100f89e:	setne  %cl
 100f8a1:	movzbq %cl,%rcx
 100f8a5:	cmp    $0x0,%rcx
 100f8a9:	je     100f921 <myl_f_20f65c28671b40937c5bf23acc7c6f37e5a5ec0622e347b57685725df5ba9e50+0x191>
 100f8ab:	cmp    $0x1,%rcx
 100f8af:	je     100f8bb <myl_f_20f65c28671b40937c5bf23acc7c6f37e5a5ec0622e347b57685725df5ba9e50+0x12b>
 100f8b1:	mov    $0x0,%eax
 100f8b6:	jmp    100f94b <myl_f_20f65c28671b40937c5bf23acc7c6f37e5a5ec0622e347b57685725df5ba9e50+0x1bb>
 100f8bb:	mov    (%rax),%rcx
 100f8be:	mov    %rcx,-0x40(%rbp)
 100f8c2:	mov    0x8(%rax),%rax
 100f8c6:	mov    %rax,-0x38(%rbp)
 100f8ca:	mov    -0x40(%rbp),%rax
 100f8ce:	mov    %rax,-0x18(%rbp)
 100f8d2:	mov    -0x38(%rbp),%rax
 100f8d6:	mov    %rax,-0x10(%rbp)
 100f8da:	lea    -0x18(%rbp),%rsi
 100f8de:	mov    %rdi,%rbx
 100f8e1:	call   100f790 <myl_f_20f65c28671b40937c5bf23acc7c6f37e5a5ec0622e347b57685725df5ba9e50>
 100f8e6:	mov    %r12,%rdx
 100f8e9:	mov    %rbx,%rdi
 100f8ec:	mov    %rax,%rcx
 100f8ef:	mov    %rcx,%rsi
 100f8f2:	add    %rdx,%rsi
 100f8f5:	mov    %rdx,%rax
 100f8f8:	xor    %rsi,%rax
 100f8fb:	xor    %rcx,%rsi
 100f8fe:	and    %rsi,%rax
 100f901:	cmp    $0x0,%rax
 100f905:	jl     100f90f <myl_f_20f65c28671b40937c5bf23acc7c6f37e5a5ec0622e347b57685725df5ba9e50+0x17f>
 100f907:	mov    %rcx,%rax
 100f90a:	add    %rdx,%rax
 100f90d:	jmp    100f94b <myl_f_20f65c28671b40937c5bf23acc7c6f37e5a5ec0622e347b57685725df5ba9e50+0x1bb>
 100f90f:	mov    $0x40,%r8d
 100f915:	mov    $0x0,%esi
 100f91a:	call   1015710 <myl_qbe_fail_overflow_op>
 100f91f:	ud2
 100f921:	call   1015640 <myl_qbe_fail_assert>
 100f926:	ud2
 100f928:	mov    $0x40,%r8d
 100f92e:	mov    $0x1,%edx
 100f933:	mov    $0x0,%esi
 100f938:	call   1015710 <myl_qbe_fail_overflow_op>
 100f93d:	ud2
 100f93f:	call   1015640 <myl_qbe_fail_assert>
 100f944:	ud2
 100f946:	mov    $0x1,%eax
 100f94b:	pop    %r12
 100f94d:	pop    %rbx
 100f94e:	leave
 100f94f:	ret
 100f950:	call   1015860 <myl_qbe_fail_frame>
 100f955:	ud2

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
