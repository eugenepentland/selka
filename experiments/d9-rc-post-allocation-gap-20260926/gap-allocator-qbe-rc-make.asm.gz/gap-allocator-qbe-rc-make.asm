
.tmp-rc/profile/gap-allocator-qbe-rc-n12:     file format elf64-x86-64


Disassembly of section .text:

0000000001011a10 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531>:
 1011a10:	endbr64
 1011a14:	push   %rbp
 1011a15:	mov    %rsp,%rbp
 1011a18:	sub    $0x1f8,%rsp
 1011a1f:	push   %rbx
 1011a20:	push   %r12
 1011a22:	push   %r13
 1011a24:	push   %r14
 1011a26:	push   %r15
 1011a28:	mov    0x40(%rdi),%rax
 1011a2c:	lea    -0x18(%rbp),%rcx
 1011a30:	cmp    %rax,%rcx
 1011a33:	jb     1012f4f <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x153f>
 1011a39:	mov    %rsi,-0x70(%rbp)
 1011a3d:	mov    %rdi,%rbx
 1011a40:	call   10191d0 <myl_qbe_heap>
 1011a45:	mov    %rbx,%rdi
 1011a48:	mov    %rax,%rbx
 1011a4b:	mov    %rdi,%r12
 1011a4e:	call   101b510 <myl_qbe_region_mark>
 1011a53:	mov    %r12,%rdi
 1011a56:	mov    %rax,%r13
 1011a59:	mov    $0x30,%edx
 1011a5e:	mov    $0x0,%esi
 1011a63:	mov    %rdi,%r12
 1011a66:	lea    -0xe0(%rbp),%rdi
 1011a6d:	call   1028940 <compiler_rt.fastMemset>
 1011a72:	mov    %r12,%rdi
 1011a75:	mov    $0xc0,%edx
 1011a7a:	mov    $0x0,%esi
 1011a7f:	mov    %rdi,%r12
 1011a82:	lea    -0x1a0(%rbp),%rdi
 1011a89:	call   1028940 <compiler_rt.fastMemset>
 1011a8e:	mov    %r12,%rdi
 1011a91:	lea    -0xd8c0(%rip),%rax        # 10041d8 <myl_t_1a91deb3742283487d66c3b500f6effd7ef1170e6d4b4368fe9ec3c3f0354fda>
 1011a98:	mov    %rax,-0x1a0(%rbp)
 1011a9f:	movl   $0x0,-0x188(%rbp)
 1011aa9:	lea    -0x70(%rbp),%rax
 1011aad:	mov    %rax,-0x198(%rbp)
 1011ab4:	lea    -0xe0(%rbp),%rax
 1011abb:	mov    %rax,-0x190(%rbp)
 1011ac2:	lea    -0xd781(%rip),%rax        # 1004348 <myl_t_385cfdbc00ec32031699460779c15099b2bba3cad0e440fffb08e10df0acb9e1>
 1011ac9:	mov    %rax,-0x180(%rbp)
 1011ad0:	movl   $0x0,-0x168(%rbp)
 1011ada:	lea    -0xb0(%rbp),%rax
 1011ae1:	mov    %rax,-0x178(%rbp)
 1011ae8:	lea    -0xe0(%rbp),%rax
 1011aef:	add    $0x8,%rax
 1011af3:	mov    %rax,-0x170(%rbp)
 1011afa:	lea    -0xd7b9(%rip),%rax        # 1004348 <myl_t_385cfdbc00ec32031699460779c15099b2bba3cad0e440fffb08e10df0acb9e1>
 1011b01:	mov    %rax,-0x160(%rbp)
 1011b08:	movl   $0x0,-0x148(%rbp)
 1011b12:	lea    -0xa0(%rbp),%rax
 1011b19:	mov    %rax,-0x158(%rbp)
 1011b20:	lea    -0xe0(%rbp),%rax
 1011b27:	add    $0x10,%rax
 1011b2b:	mov    %rax,-0x150(%rbp)
 1011b32:	lea    -0xd7f1(%rip),%rax        # 1004348 <myl_t_385cfdbc00ec32031699460779c15099b2bba3cad0e440fffb08e10df0acb9e1>
 1011b39:	mov    %rax,-0x140(%rbp)
 1011b40:	movl   $0x0,-0x128(%rbp)
 1011b4a:	lea    -0x90(%rbp),%rax
 1011b51:	mov    %rax,-0x138(%rbp)
 1011b58:	lea    -0xe0(%rbp),%rax
 1011b5f:	add    $0x18,%rax
 1011b63:	mov    %rax,-0x130(%rbp)
 1011b6a:	lea    -0xd829(%rip),%rax        # 1004348 <myl_t_385cfdbc00ec32031699460779c15099b2bba3cad0e440fffb08e10df0acb9e1>
 1011b71:	mov    %rax,-0x120(%rbp)
 1011b78:	movl   $0x0,-0x108(%rbp)
 1011b82:	lea    -0x88(%rbp),%rax
 1011b89:	mov    %rax,-0x118(%rbp)
 1011b90:	lea    -0xe0(%rbp),%rax
 1011b97:	add    $0x20,%rax
 1011b9b:	mov    %rax,-0x110(%rbp)
 1011ba2:	lea    -0xd861(%rip),%rax        # 1004348 <myl_t_385cfdbc00ec32031699460779c15099b2bba3cad0e440fffb08e10df0acb9e1>
 1011ba9:	mov    %rax,-0x100(%rbp)
 1011bb0:	movl   $0x0,-0xe8(%rbp)
 1011bba:	lea    -0x78(%rbp),%rax
 1011bbe:	mov    %rax,-0xf8(%rbp)
 1011bc5:	lea    -0xe0(%rbp),%rax
 1011bcc:	mov    %rax,%r14
 1011bcf:	add    $0x28,%r14
 1011bd3:	mov    %r14,-0xf0(%rbp)
 1011bda:	mov    $0x6,%ecx
 1011bdf:	lea    -0x1a0(%rbp),%rdx
 1011be6:	lea    -0x1c0(%rbp),%rsi
 1011bed:	mov    %rdi,%r12
 1011bf0:	call   1018900 <myl_qbe_rc_frame_enter>
 1011bf5:	mov    %r13,%r8
 1011bf8:	mov    %r12,%rdi
 1011bfb:	mov    -0x70(%rbp),%rdx
 1011bff:	mov    %rdx,-0x68(%rbp)
 1011c03:	movq   $0x0,-0x60(%rbp)
 1011c0b:	cmp    $0x0,%rdx
 1011c0f:	sete   %al
 1011c12:	movzbq %al,%rax
 1011c16:	mov    %rax,-0x68(%rbp)
 1011c1a:	lea    -0x88(%rbp),%rsi
 1011c21:	lea    -0xb0(%rbp),%rcx
 1011c28:	neg    %rsi
 1011c2b:	add    %rcx,%rsi
 1011c2e:	mov    %r8,%r15
 1011c31:	lea    -0xb0(%rbp),%r8
 1011c38:	lea    -0x88(%rbp),%rcx
 1011c3f:	sub    %r8,%rcx
 1011c42:	cmp    $0x10,%rsi
 1011c46:	setb   %r12b
 1011c4a:	movzbl %r12b,%r12d
 1011c4e:	mov    %r12d,-0xc(%rbp)
 1011c52:	cmp    $0x10,%rcx
 1011c56:	setb   %r13b
 1011c5a:	movzbl %r13b,%r13d
 1011c5e:	mov    %r13d,-0x10(%rbp)
 1011c62:	cmp    $0x0,%eax
 1011c65:	jne    10129cd <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xfbd>
 1011c6b:	mov    %rdx,-0x68(%rbp)
 1011c6f:	movq   $0x1,-0x60(%rbp)
 1011c77:	movabs $0x8000000000000001,%rax
 1011c81:	cmp    %rax,%rdx
 1011c84:	jl     10129b3 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xfa3>
 1011c8a:	mov    %rdx,%rsi
 1011c8d:	sub    $0x1,%rsi
 1011c91:	mov    %rsi,-0x68(%rbp)
 1011c95:	mov    %rdi,%r12
 1011c98:	call   1011a10 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531>
 1011c9d:	mov    %r12,%rdi
 1011ca0:	mov    %rax,%rcx
 1011ca3:	mov    %rdx,%rax
 1011ca6:	mov    %rcx,-0x1f0(%rbp)
 1011cad:	mov    %rax,-0x1e8(%rbp)
 1011cb4:	lea    -0x1f0(%rbp),%rax
 1011cbb:	mov    %rax,-0x68(%rbp)
 1011cbf:	mov    -0x1f0(%rbp),%rax
 1011cc6:	mov    %rax,-0x88(%rbp)
 1011ccd:	mov    -0x1e8(%rbp),%rax
 1011cd4:	mov    %rax,-0x80(%rbp)
 1011cd8:	lea    0x1b201(%rip),%rax        # 102cee0 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 1011cdf:	mov    %rax,-0x120(%rbp)
 1011ce6:	movl   $0x2,-0x108(%rbp)
 1011cf0:	movl   $0x1,-0xc0(%rbp)
 1011cfa:	mov    -0x88(%rbp),%rax
 1011d01:	mov    %rax,-0xb0(%rbp)
 1011d08:	mov    -0x80(%rbp),%rax
 1011d0c:	mov    %rax,-0xa8(%rbp)
 1011d13:	lea    0x1b1c6(%rip),%rax        # 102cee0 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 1011d1a:	mov    %rax,-0x180(%rbp)
 1011d21:	movl   $0x2,-0x168(%rbp)
 1011d2b:	movl   $0x0,-0xc0(%rbp)
 1011d35:	movl   $0x1,-0xd8(%rbp)
 1011d3f:	lea    -0xb0(%rbp),%rax
 1011d46:	mov    %rax,-0x68(%rbp)
 1011d4a:	mov    $0x1,%edx
 1011d4f:	lea    0x1ae7a(%rip),%rsi        # 102cbd0 <myl_t_1e414bd82e4b50b54939760a2d591f88da97e2f1c8252dbd7dcbc73438e46afb_body>
 1011d56:	mov    %rdi,%r12
 1011d59:	mov    %rbx,%rdi
 1011d5c:	call   101d8b0 <myl_native_heap_alloc>
 1011d61:	mov    %r12,%rdi
 1011d64:	mov    %rax,%r12
 1011d67:	cmp    $0x0,%r12d
 1011d6b:	jne    1011d77 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x367>
 1011d6d:	mov    %rdi,%rbx
 1011d70:	call   1018f50 <myl_qbe_fail_allocation>
 1011d75:	ud2
 1011d77:	xchg   %rdi,%rbx
 1011d7a:	mov    %r12,-0x78(%rbp)
 1011d7e:	lea    0x1aebb(%rip),%rax        # 102cc40 <myl_t_1e414bd82e4b50b54939760a2d591f88da97e2f1c8252dbd7dcbc73438e46afb>
 1011d85:	mov    %rax,-0x100(%rbp)
 1011d8c:	movl   $0x2,-0xe8(%rbp)
 1011d96:	lea    -0x78(%rbp),%rax
 1011d9a:	mov    %rax,-0xf8(%rbp)
 1011da1:	mov    %r14,-0xf0(%rbp)
 1011da8:	movl   $0x4,-0xe8(%rbp)
 1011db2:	movl   $0x1,-0xb8(%rbp)
 1011dbc:	mov    -0x68(%rbp),%rcx
 1011dc0:	lea    -0x88(%rbp),%rax
 1011dc7:	neg    %rax
 1011dca:	add    %rcx,%rax
 1011dcd:	lea    -0x88(%rbp),%rdx
 1011dd4:	sub    %rcx,%rdx
 1011dd7:	cmp    $0x10,%rax
 1011ddb:	setb   %al
 1011dde:	movzbl %al,%eax
 1011de1:	cmp    $0x10,%rdx
 1011de5:	setb   %dl
 1011de8:	movzbl %dl,%edx
 1011deb:	or     %edx,%eax
 1011ded:	jne    1011e68 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x458>
 1011def:	mov    (%rcx),%rax
 1011df2:	cmp    $0x0,%rax
 1011df6:	je     1011e12 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x402>
 1011df8:	sub    $0x10,%rax
 1011dfc:	mov    (%rax),%rax
 1011dff:	movabs $0x5000000000000001,%rdx
 1011e09:	and    %rdx,%rax
 1011e0c:	cmp    $0x0,%rax
 1011e10:	jne    1011e68 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x458>
 1011e12:	mov    0x8(%rcx),%rax
 1011e16:	cmp    $0x0,%rax
 1011e1a:	je     1011e36 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x426>
 1011e1c:	sub    $0x10,%rax
 1011e20:	mov    (%rax),%rax
 1011e23:	movabs $0x5000000000000001,%rdx
 1011e2d:	and    %rdx,%rax
 1011e30:	cmp    $0x0,%rax
 1011e34:	jne    1011e68 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x458>
 1011e36:	mov    (%rcx),%rax
 1011e39:	mov    %rax,-0x88(%rbp)
 1011e40:	mov    0x8(%rcx),%rax
 1011e44:	mov    %rax,-0x80(%rbp)
 1011e48:	mov    $0x10,%edx
 1011e4d:	mov    $0x0,%esi
 1011e52:	mov    %rdi,%r13
 1011e55:	mov    %rcx,%rdi
 1011e58:	call   1028940 <compiler_rt.fastMemset>
 1011e5d:	mov    %r15,%r8
 1011e60:	mov    %r13,%rdi
 1011e63:	mov    %r8,%r13
 1011e66:	jmp    1011ea6 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x496>
 1011e68:	mov    %r15,%r8
 1011e6b:	mov    %r8,%r13
 1011e6e:	lea    -0x88(%rbp),%rdx
 1011e75:	lea    0x1b064(%rip),%rsi        # 102cee0 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 1011e7c:	mov    %rdi,%r15
 1011e7f:	call   10285a0 <myl_rc_native_take>
 1011e84:	mov    %r15,%rdi
 1011e87:	cmp    $0x0,%eax
 1011e8a:	jne    1011ea6 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x496>
 1011e8c:	call   10210c0 <myl_rc_take_failure>
 1011e91:	mov    %rbx,%rdi
 1011e94:	mov    %eax,%esi
 1011e96:	mov    %rdi,%rbx
 1011e99:	call   1018810 <myl_qbe_rc_status>
 1011e9e:	mov    %rbx,%rdi
 1011ea1:	jmp    1012e9e <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x148e>
 1011ea6:	movl   $0x0,-0xd8(%rbp)
 1011eb0:	lea    0x1b029(%rip),%rax        # 102cee0 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 1011eb7:	mov    %rax,-0x120(%rbp)
 1011ebe:	movl   $0x2,-0x108(%rbp)
 1011ec8:	movl   $0x1,-0xc0(%rbp)
 1011ed2:	mov    -0x88(%rbp),%rax
 1011ed9:	mov    %rax,(%r12)
 1011edd:	mov    -0x80(%rbp),%rax
 1011ee1:	mov    %rax,0x8(%r12)
 1011ee6:	movl   $0x0,-0xc0(%rbp)
 1011ef0:	mov    %r12,-0x68(%rbp)
 1011ef4:	mov    -0x68(%rbp),%rax
 1011ef8:	mov    %rax,-0xb0(%rbp)
 1011eff:	lea    0x1ad3a(%rip),%rax        # 102cc40 <myl_t_1e414bd82e4b50b54939760a2d591f88da97e2f1c8252dbd7dcbc73438e46afb>
 1011f06:	mov    %rax,-0x180(%rbp)
 1011f0d:	movl   $0x2,-0x168(%rbp)
 1011f17:	movl   $0x1,-0xd8(%rbp)
 1011f21:	mov    %r12,-0x68(%rbp)
 1011f25:	movl   $0x0,-0xb8(%rbp)
 1011f2f:	mov    $0x8,%edx
 1011f34:	mov    $0x0,%esi
 1011f39:	mov    %rdi,%r12
 1011f3c:	lea    -0x38(%rbp),%rdi
 1011f40:	call   1028940 <compiler_rt.fastMemset>
 1011f45:	mov    %r12,%rdi
 1011f48:	lea    0x1af21(%rip),%rax        # 102ce70 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 1011f4f:	mov    %rax,-0x100(%rbp)
 1011f56:	movl   $0x2,-0xe8(%rbp)
 1011f60:	lea    -0x38(%rbp),%rax
 1011f64:	mov    %rax,-0xf8(%rbp)
 1011f6b:	mov    %r14,-0xf0(%rbp)
 1011f72:	movl   $0x1,-0xb8(%rbp)
 1011f7c:	lea    -0x88(%rbp),%rcx
 1011f83:	lea    -0x68(%rbp),%rax
 1011f87:	sub    %rcx,%rax
 1011f8a:	lea    -0x68(%rbp),%rdx
 1011f8e:	lea    -0x88(%rbp),%rcx
 1011f95:	sub    %rdx,%rcx
 1011f98:	cmp    $0x8,%rax
 1011f9c:	setb   %al
 1011f9f:	movzbl %al,%eax
 1011fa2:	cmp    $0x8,%rcx
 1011fa6:	setb   %cl
 1011fa9:	movzbl %cl,%ecx
 1011fac:	or     %ecx,%eax
 1011fae:	jne    1012003 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x5f3>
 1011fb0:	mov    -0x68(%rbp),%rax
 1011fb4:	cmp    $0x0,%rax
 1011fb8:	je     1011fd4 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x5c4>
 1011fba:	sub    $0x10,%rax
 1011fbe:	mov    (%rax),%rax
 1011fc1:	movabs $0x5000000000000001,%rcx
 1011fcb:	and    %rcx,%rax
 1011fce:	cmp    $0x0,%rax
 1011fd2:	jne    1012003 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x5f3>
 1011fd4:	mov    -0x68(%rbp),%rax
 1011fd8:	mov    %rax,-0x88(%rbp)
 1011fdf:	mov    $0x8,%edx
 1011fe4:	mov    $0x0,%esi
 1011fe9:	mov    %rdi,%r12
 1011fec:	lea    -0x68(%rbp),%rdi
 1011ff0:	call   1028940 <compiler_rt.fastMemset>
 1011ff5:	mov    %r13,%r8
 1011ff8:	mov    %r12,%rdi
 1011ffb:	mov    %r8,%r15
 1011ffe:	xchg   %rbx,%rdi
 1012001:	jmp    1012048 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x638>
 1012003:	mov    %r13,%r8
 1012006:	mov    %r8,%r15
 1012009:	lea    -0x68(%rbp),%rcx
 101200d:	lea    -0x88(%rbp),%rdx
 1012014:	lea    0x1ac25(%rip),%rsi        # 102cc40 <myl_t_1e414bd82e4b50b54939760a2d591f88da97e2f1c8252dbd7dcbc73438e46afb>
 101201b:	mov    %rdi,%r12
 101201e:	call   10285a0 <myl_rc_native_take>
 1012023:	mov    %r12,%rdi
 1012026:	cmp    $0x0,%eax
 1012029:	jne    1012045 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x635>
 101202b:	call   10210c0 <myl_rc_take_failure>
 1012030:	mov    %rbx,%rdi
 1012033:	mov    %eax,%esi
 1012035:	mov    %rdi,%rbx
 1012038:	call   1018810 <myl_qbe_rc_status>
 101203d:	mov    %rbx,%rdi
 1012040:	jmp    1012e9e <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x148e>
 1012045:	xchg   %rbx,%rdi
 1012048:	movl   $0x0,-0xd8(%rbp)
 1012052:	lea    0x1abe7(%rip),%rax        # 102cc40 <myl_t_1e414bd82e4b50b54939760a2d591f88da97e2f1c8252dbd7dcbc73438e46afb>
 1012059:	mov    %rax,-0x120(%rbp)
 1012060:	movl   $0x2,-0x108(%rbp)
 101206a:	movl   $0x1,-0xc0(%rbp)
 1012074:	mov    -0x88(%rbp),%rax
 101207b:	mov    %rax,-0x38(%rbp)
 101207f:	movl   $0x0,-0xc0(%rbp)
 1012089:	lea    -0x38(%rbp),%rax
 101208d:	mov    %rax,-0x68(%rbp)
 1012091:	mov    -0x38(%rbp),%rax
 1012095:	mov    %rax,-0xb0(%rbp)
 101209c:	lea    0x1adcd(%rip),%rax        # 102ce70 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 10120a3:	mov    %rax,-0x180(%rbp)
 10120aa:	movl   $0x2,-0x168(%rbp)
 10120b4:	movl   $0x1,-0xd8(%rbp)
 10120be:	lea    -0xb0(%rbp),%rax
 10120c5:	mov    %rax,-0x68(%rbp)
 10120c9:	movl   $0x0,-0xb8(%rbp)
 10120d3:	mov    -0x70(%rbp),%rdx
 10120d7:	mov    %rdx,-0x60(%rbp)
 10120db:	movabs $0x8000000000000001,%rax
 10120e5:	cmp    %rax,%rdx
 10120e8:	jl     101299c <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xf8c>
 10120ee:	mov    %rdx,%rsi
 10120f1:	sub    $0x1,%rsi
 10120f5:	mov    %rsi,-0x60(%rbp)
 10120f9:	mov    %rdi,%r12
 10120fc:	call   1011a10 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531>
 1012101:	mov    %r12,%rdi
 1012104:	mov    %rax,%rcx
 1012107:	mov    %rdx,%rax
 101210a:	mov    %rcx,-0x1e0(%rbp)
 1012111:	mov    %rax,-0x1d8(%rbp)
 1012118:	lea    -0x1e0(%rbp),%rax
 101211f:	mov    %rax,-0x60(%rbp)
 1012123:	mov    -0x1e0(%rbp),%rax
 101212a:	mov    %rax,-0x88(%rbp)
 1012131:	mov    -0x1d8(%rbp),%rax
 1012138:	mov    %rax,-0x80(%rbp)
 101213c:	lea    0x1ad9d(%rip),%rax        # 102cee0 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 1012143:	mov    %rax,-0x120(%rbp)
 101214a:	movl   $0x2,-0x108(%rbp)
 1012154:	movl   $0x1,-0xc0(%rbp)
 101215e:	mov    -0x88(%rbp),%rax
 1012165:	mov    %rax,-0xa0(%rbp)
 101216c:	mov    -0x80(%rbp),%rax
 1012170:	mov    %rax,-0x98(%rbp)
 1012177:	lea    0x1ad62(%rip),%rax        # 102cee0 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 101217e:	mov    %rax,-0x160(%rbp)
 1012185:	movl   $0x2,-0x148(%rbp)
 101218f:	movl   $0x0,-0xc0(%rbp)
 1012199:	movl   $0x1,-0xd0(%rbp)
 10121a3:	lea    -0xa0(%rbp),%rax
 10121aa:	mov    %rax,-0x60(%rbp)
 10121ae:	mov    $0x1,%edx
 10121b3:	lea    0x1aa16(%rip),%rsi        # 102cbd0 <myl_t_1e414bd82e4b50b54939760a2d591f88da97e2f1c8252dbd7dcbc73438e46afb_body>
 10121ba:	mov    %rdi,%r12
 10121bd:	mov    %rbx,%rdi
 10121c0:	call   101d8b0 <myl_native_heap_alloc>
 10121c5:	mov    %r12,%rdi
 10121c8:	mov    %rax,%r13
 10121cb:	cmp    $0x0,%r13d
 10121cf:	jne    10121db <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x7cb>
 10121d1:	mov    %rdi,%rbx
 10121d4:	call   1018f50 <myl_qbe_fail_allocation>
 10121d9:	ud2
 10121db:	xchg   %rdi,%rbx
 10121de:	mov    %r13,-0x78(%rbp)
 10121e2:	lea    0x1aa57(%rip),%rax        # 102cc40 <myl_t_1e414bd82e4b50b54939760a2d591f88da97e2f1c8252dbd7dcbc73438e46afb>
 10121e9:	mov    %rax,-0x100(%rbp)
 10121f0:	movl   $0x2,-0xe8(%rbp)
 10121fa:	lea    -0x78(%rbp),%rax
 10121fe:	mov    %rax,-0xf8(%rbp)
 1012205:	mov    %r14,-0xf0(%rbp)
 101220c:	movl   $0x4,-0xe8(%rbp)
 1012216:	movl   $0x1,-0xb8(%rbp)
 1012220:	mov    -0x60(%rbp),%rcx
 1012224:	lea    -0x88(%rbp),%rax
 101222b:	neg    %rax
 101222e:	add    %rcx,%rax
 1012231:	lea    -0x88(%rbp),%rdx
 1012238:	sub    %rcx,%rdx
 101223b:	cmp    $0x10,%rax
 101223f:	setb   %al
 1012242:	movzbl %al,%eax
 1012245:	cmp    $0x10,%rdx
 1012249:	setb   %dl
 101224c:	movzbl %dl,%edx
 101224f:	or     %edx,%eax
 1012251:	jne    10122d0 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x8c0>
 1012253:	mov    (%rcx),%rax
 1012256:	cmp    $0x0,%rax
 101225a:	je     1012276 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x866>
 101225c:	sub    $0x10,%rax
 1012260:	mov    (%rax),%rax
 1012263:	movabs $0x5000000000000001,%rdx
 101226d:	and    %rdx,%rax
 1012270:	cmp    $0x0,%rax
 1012274:	jne    10122d0 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x8c0>
 1012276:	mov    0x8(%rcx),%rax
 101227a:	cmp    $0x0,%rax
 101227e:	je     101229a <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x88a>
 1012280:	sub    $0x10,%rax
 1012284:	mov    (%rax),%rax
 1012287:	movabs $0x5000000000000001,%rdx
 1012291:	and    %rdx,%rax
 1012294:	cmp    $0x0,%rax
 1012298:	jne    10122d0 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x8c0>
 101229a:	mov    (%rcx),%rax
 101229d:	mov    %rax,-0x88(%rbp)
 10122a4:	mov    0x8(%rcx),%rax
 10122a8:	mov    %rax,-0x80(%rbp)
 10122ac:	mov    $0x10,%edx
 10122b1:	mov    $0x0,%esi
 10122b6:	mov    %rdi,%r12
 10122b9:	mov    %rcx,%rdi
 10122bc:	call   1028940 <compiler_rt.fastMemset>
 10122c1:	mov    %r15,%r8
 10122c4:	mov    %r12,%rdi
 10122c7:	mov    -0xc(%rbp),%r12d
 10122cb:	mov    %r8,%r15
 10122ce:	jmp    1012312 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x902>
 10122d0:	mov    %r15,%r8
 10122d3:	mov    %r8,%r15
 10122d6:	lea    -0x88(%rbp),%rdx
 10122dd:	lea    0x1abfc(%rip),%rsi        # 102cee0 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 10122e4:	mov    %rdi,%r12
 10122e7:	call   10285a0 <myl_rc_native_take>
 10122ec:	mov    %r12,%rdi
 10122ef:	mov    -0xc(%rbp),%r12d
 10122f3:	cmp    $0x0,%eax
 10122f6:	jne    1012312 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x902>
 10122f8:	call   10210c0 <myl_rc_take_failure>
 10122fd:	mov    %rbx,%rdi
 1012300:	mov    %eax,%esi
 1012302:	mov    %rdi,%rbx
 1012305:	call   1018810 <myl_qbe_rc_status>
 101230a:	mov    %rbx,%rdi
 101230d:	jmp    1012e9e <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x148e>
 1012312:	movl   $0x0,-0xd0(%rbp)
 101231c:	lea    0x1abbd(%rip),%rax        # 102cee0 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 1012323:	mov    %rax,-0x120(%rbp)
 101232a:	movl   $0x2,-0x108(%rbp)
 1012334:	movl   $0x1,-0xc0(%rbp)
 101233e:	mov    -0x88(%rbp),%rax
 1012345:	mov    %rax,0x0(%r13)
 1012349:	mov    -0x80(%rbp),%rax
 101234d:	mov    %rax,0x8(%r13)
 1012351:	movl   $0x0,-0xc0(%rbp)
 101235b:	mov    %r13,-0x60(%rbp)
 101235f:	mov    -0x60(%rbp),%rax
 1012363:	mov    %rax,-0xa0(%rbp)
 101236a:	lea    0x1a8cf(%rip),%rax        # 102cc40 <myl_t_1e414bd82e4b50b54939760a2d591f88da97e2f1c8252dbd7dcbc73438e46afb>
 1012371:	mov    %rax,-0x160(%rbp)
 1012378:	movl   $0x2,-0x148(%rbp)
 1012382:	movl   $0x1,-0xd0(%rbp)
 101238c:	mov    %r13,-0x60(%rbp)
 1012390:	movl   $0x0,-0xb8(%rbp)
 101239a:	mov    $0x8,%edx
 101239f:	mov    $0x0,%esi
 10123a4:	mov    %rdi,%r13
 10123a7:	lea    -0x30(%rbp),%rdi
 10123ab:	call   1028940 <compiler_rt.fastMemset>
 10123b0:	mov    %r13,%rdi
 10123b3:	lea    0x1aab6(%rip),%rax        # 102ce70 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 10123ba:	mov    %rax,-0x100(%rbp)
 10123c1:	movl   $0x2,-0xe8(%rbp)
 10123cb:	lea    -0x30(%rbp),%rax
 10123cf:	mov    %rax,-0xf8(%rbp)
 10123d6:	mov    %r14,-0xf0(%rbp)
 10123dd:	movl   $0x1,-0xb8(%rbp)
 10123e7:	lea    -0x88(%rbp),%rcx
 10123ee:	lea    -0x60(%rbp),%rax
 10123f2:	sub    %rcx,%rax
 10123f5:	lea    -0x60(%rbp),%rdx
 10123f9:	lea    -0x88(%rbp),%rcx
 1012400:	sub    %rdx,%rcx
 1012403:	cmp    $0x8,%rax
 1012407:	setb   %al
 101240a:	movzbl %al,%eax
 101240d:	cmp    $0x8,%rcx
 1012411:	setb   %cl
 1012414:	movzbl %cl,%ecx
 1012417:	or     %ecx,%eax
 1012419:	jne    101246b <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xa5b>
 101241b:	mov    -0x60(%rbp),%rax
 101241f:	cmp    $0x0,%rax
 1012423:	je     101243f <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xa2f>
 1012425:	sub    $0x10,%rax
 1012429:	mov    (%rax),%rax
 101242c:	movabs $0x5000000000000001,%rcx
 1012436:	and    %rcx,%rax
 1012439:	cmp    $0x0,%rax
 101243d:	jne    101246b <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xa5b>
 101243f:	mov    -0x60(%rbp),%rax
 1012443:	mov    %rax,-0x88(%rbp)
 101244a:	mov    $0x8,%edx
 101244f:	mov    $0x0,%esi
 1012454:	mov    %rdi,%r13
 1012457:	lea    -0x60(%rbp),%rdi
 101245b:	call   1028940 <compiler_rt.fastMemset>
 1012460:	mov    %r15,%r8
 1012463:	mov    %r13,%rdi
 1012466:	mov    %r8,%r15
 1012469:	jmp    10124ad <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xa9d>
 101246b:	mov    %r15,%r8
 101246e:	mov    %r8,%r15
 1012471:	lea    -0x60(%rbp),%rcx
 1012475:	lea    -0x88(%rbp),%rdx
 101247c:	lea    0x1a7bd(%rip),%rsi        # 102cc40 <myl_t_1e414bd82e4b50b54939760a2d591f88da97e2f1c8252dbd7dcbc73438e46afb>
 1012483:	mov    %rdi,%r13
 1012486:	call   10285a0 <myl_rc_native_take>
 101248b:	mov    %r13,%rdi
 101248e:	cmp    $0x0,%eax
 1012491:	jne    10124ad <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xa9d>
 1012493:	call   10210c0 <myl_rc_take_failure>
 1012498:	mov    %rbx,%rdi
 101249b:	mov    %eax,%esi
 101249d:	mov    %rdi,%rbx
 10124a0:	call   1018810 <myl_qbe_rc_status>
 10124a5:	mov    %rbx,%rdi
 10124a8:	jmp    1012e9e <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x148e>
 10124ad:	movl   $0x0,-0xd0(%rbp)
 10124b7:	lea    0x1a782(%rip),%rax        # 102cc40 <myl_t_1e414bd82e4b50b54939760a2d591f88da97e2f1c8252dbd7dcbc73438e46afb>
 10124be:	mov    %rax,-0x120(%rbp)
 10124c5:	movl   $0x2,-0x108(%rbp)
 10124cf:	movl   $0x1,-0xc0(%rbp)
 10124d9:	mov    -0x88(%rbp),%rax
 10124e0:	mov    %rax,-0x30(%rbp)
 10124e4:	movl   $0x0,-0xc0(%rbp)
 10124ee:	lea    -0x30(%rbp),%rax
 10124f2:	mov    %rax,-0x60(%rbp)
 10124f6:	mov    -0x30(%rbp),%rax
 10124fa:	mov    %rax,-0xa0(%rbp)
 1012501:	lea    0x1a968(%rip),%rax        # 102ce70 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 1012508:	mov    %rax,-0x160(%rbp)
 101250f:	movl   $0x2,-0x148(%rbp)
 1012519:	movl   $0x1,-0xd0(%rbp)
 1012523:	lea    -0xa0(%rbp),%rax
 101252a:	mov    %rax,-0x60(%rbp)
 101252e:	movl   $0x0,-0xb8(%rbp)
 1012538:	mov    $0x10,%edx
 101253d:	mov    $0x0,%esi
 1012542:	mov    %rdi,%r13
 1012545:	lea    -0x28(%rbp),%rdi
 1012549:	call   1028940 <compiler_rt.fastMemset>
 101254e:	mov    %r15,%r8
 1012551:	mov    %r13,%rdi
 1012554:	mov    -0x10(%rbp),%r13d
 1012558:	lea    0x1a981(%rip),%rax        # 102cee0 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 101255f:	mov    %rax,-0x100(%rbp)
 1012566:	movl   $0x2,-0xe8(%rbp)
 1012570:	lea    -0x28(%rbp),%rax
 1012574:	mov    %rax,-0xf8(%rbp)
 101257b:	mov    %r14,-0xf0(%rbp)
 1012582:	movl   $0x1,-0xb8(%rbp)
 101258c:	mov    -0x68(%rbp),%rcx
 1012590:	mov    -0xd8(%rbp),%eax
 1012596:	cmp    $0x0,%eax
 1012599:	jne    10125fd <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xbed>
 101259b:	mov    %r8,%r15
 101259e:	lea    -0x88(%rbp),%rdx
 10125a5:	lea    0x1a8c4(%rip),%rsi        # 102ce70 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 10125ac:	mov    %rdi,%r14
 10125af:	call   1028100 <myl_rc_native_copy>
 10125b4:	mov    %r14,%rdi
 10125b7:	cmp    $0x0,%eax
 10125ba:	jne    10125d6 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xbc6>
 10125bc:	call   10210c0 <myl_rc_take_failure>
 10125c1:	mov    %rbx,%rdi
 10125c4:	mov    %eax,%esi
 10125c6:	mov    %rdi,%rbx
 10125c9:	call   1018810 <myl_qbe_rc_status>
 10125ce:	mov    %rbx,%rdi
 10125d1:	jmp    1012e9e <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x148e>
 10125d6:	lea    0x1a893(%rip),%rax        # 102ce70 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 10125dd:	mov    %rax,-0x120(%rbp)
 10125e4:	movl   $0x2,-0x108(%rbp)
 10125ee:	movl   $0x1,-0xc0(%rbp)
 10125f8:	jmp    10126e6 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xcd6>
 10125fd:	mov    %r8,%r15
 1012600:	lea    -0x88(%rbp),%rax
 1012607:	neg    %rax
 101260a:	add    %rcx,%rax
 101260d:	lea    -0x88(%rbp),%rdx
 1012614:	sub    %rcx,%rdx
 1012617:	cmp    $0x8,%rax
 101261b:	setb   %al
 101261e:	movzbl %al,%eax
 1012621:	cmp    $0x8,%rdx
 1012625:	setb   %dl
 1012628:	movzbl %dl,%edx
 101262b:	or     %edx,%eax
 101262d:	jne    101267c <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xc6c>
 101262f:	mov    (%rcx),%rax
 1012632:	cmp    $0x0,%rax
 1012636:	je     1012652 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xc42>
 1012638:	sub    $0x10,%rax
 101263c:	mov    (%rax),%rax
 101263f:	movabs $0x5000000000000001,%rdx
 1012649:	and    %rdx,%rax
 101264c:	cmp    $0x0,%rax
 1012650:	jne    101267c <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xc6c>
 1012652:	mov    (%rcx),%rax
 1012655:	mov    %rax,-0x88(%rbp)
 101265c:	mov    $0x8,%edx
 1012661:	mov    $0x0,%esi
 1012666:	mov    %rdi,%r14
 1012669:	mov    %rcx,%rdi
 101266c:	call   1028940 <compiler_rt.fastMemset>
 1012671:	mov    %r15,%r8
 1012674:	mov    %r14,%rdi
 1012677:	mov    %r8,%r15
 101267a:	jmp    10126ba <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xcaa>
 101267c:	mov    %r15,%r8
 101267f:	mov    %r8,%r15
 1012682:	lea    -0x88(%rbp),%rdx
 1012689:	lea    0x1a7e0(%rip),%rsi        # 102ce70 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 1012690:	mov    %rdi,%r14
 1012693:	call   10285a0 <myl_rc_native_take>
 1012698:	mov    %r14,%rdi
 101269b:	cmp    $0x0,%eax
 101269e:	jne    10126ba <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xcaa>
 10126a0:	call   10210c0 <myl_rc_take_failure>
 10126a5:	mov    %rbx,%rdi
 10126a8:	mov    %eax,%esi
 10126aa:	mov    %rdi,%rbx
 10126ad:	call   1018810 <myl_qbe_rc_status>
 10126b2:	mov    %rbx,%rdi
 10126b5:	jmp    1012e9e <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x148e>
 10126ba:	movl   $0x0,-0xd8(%rbp)
 10126c4:	lea    0x1a7a5(%rip),%rax        # 102ce70 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 10126cb:	mov    %rax,-0x120(%rbp)
 10126d2:	movl   $0x2,-0x108(%rbp)
 10126dc:	movl   $0x1,-0xc0(%rbp)
 10126e6:	mov    -0x88(%rbp),%rax
 10126ed:	mov    %rax,-0x28(%rbp)
 10126f1:	movl   $0x0,-0xc0(%rbp)
 10126fb:	mov    -0x60(%rbp),%rcx
 10126ff:	lea    -0x88(%rbp),%rax
 1012706:	neg    %rax
 1012709:	add    %rcx,%rax
 101270c:	lea    -0x88(%rbp),%rdx
 1012713:	sub    %rcx,%rdx
 1012716:	cmp    $0x8,%rax
 101271a:	setb   %al
 101271d:	movzbl %al,%eax
 1012720:	cmp    $0x8,%rdx
 1012724:	setb   %dl
 1012727:	movzbl %dl,%edx
 101272a:	or     %edx,%eax
 101272c:	jne    101277b <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xd6b>
 101272e:	mov    (%rcx),%rax
 1012731:	cmp    $0x0,%rax
 1012735:	je     1012751 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xd41>
 1012737:	sub    $0x10,%rax
 101273b:	mov    (%rax),%rax
 101273e:	movabs $0x5000000000000001,%rdx
 1012748:	and    %rdx,%rax
 101274b:	cmp    $0x0,%rax
 101274f:	jne    101277b <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xd6b>
 1012751:	mov    (%rcx),%rax
 1012754:	mov    %rax,-0x88(%rbp)
 101275b:	mov    $0x8,%edx
 1012760:	mov    $0x0,%esi
 1012765:	mov    %rdi,%r14
 1012768:	mov    %rcx,%rdi
 101276b:	call   1028940 <compiler_rt.fastMemset>
 1012770:	mov    %r15,%r8
 1012773:	mov    %r14,%rdi
 1012776:	xchg   %rbx,%rdi
 1012779:	jmp    10127bf <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xdaf>
 101277b:	mov    %r15,%r8
 101277e:	mov    %r8,%r15
 1012781:	lea    -0x88(%rbp),%rdx
 1012788:	lea    0x1a6e1(%rip),%rsi        # 102ce70 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 101278f:	mov    %rdi,%r14
 1012792:	call   10285a0 <myl_rc_native_take>
 1012797:	mov    %r15,%r8
 101279a:	mov    %r14,%rdi
 101279d:	cmp    $0x0,%eax
 10127a0:	jne    10127bc <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xdac>
 10127a2:	call   10210c0 <myl_rc_take_failure>
 10127a7:	mov    %rbx,%rdi
 10127aa:	mov    %eax,%esi
 10127ac:	mov    %rdi,%rbx
 10127af:	call   1018810 <myl_qbe_rc_status>
 10127b4:	mov    %rbx,%rdi
 10127b7:	jmp    1012e9e <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x148e>
 10127bc:	xchg   %rbx,%rdi
 10127bf:	movl   $0x0,-0xd0(%rbp)
 10127c9:	lea    0x1a6a0(%rip),%rax        # 102ce70 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 10127d0:	mov    %rax,-0x120(%rbp)
 10127d7:	movl   $0x2,-0x108(%rbp)
 10127e1:	movl   $0x1,-0xc0(%rbp)
 10127eb:	mov    -0x88(%rbp),%rax
 10127f2:	mov    %rax,-0x20(%rbp)
 10127f6:	movl   $0x0,-0xc0(%rbp)
 1012800:	lea    -0x28(%rbp),%rax
 1012804:	mov    %rax,-0x68(%rbp)
 1012808:	mov    -0x28(%rbp),%rax
 101280c:	mov    %rax,-0xb0(%rbp)
 1012813:	mov    -0x20(%rbp),%rax
 1012817:	mov    %rax,-0xa8(%rbp)
 101281e:	lea    0x1a6bb(%rip),%rax        # 102cee0 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 1012825:	mov    %rax,-0x180(%rbp)
 101282c:	movl   $0x2,-0x168(%rbp)
 1012836:	movl   $0x1,-0xd8(%rbp)
 1012840:	lea    -0xb0(%rbp),%rax
 1012847:	mov    %rax,-0x68(%rbp)
 101284b:	movl   $0x0,-0xb8(%rbp)
 1012855:	mov    %r12d,%eax
 1012858:	or     %r13d,%eax
 101285b:	jne    10128f0 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xee0>
 1012861:	mov    -0xb0(%rbp),%rax
 1012868:	cmp    $0x0,%rax
 101286c:	je     1012888 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xe78>
 101286e:	sub    $0x10,%rax
 1012872:	mov    (%rax),%rax
 1012875:	movabs $0x5000000000000001,%rcx
 101287f:	and    %rcx,%rax
 1012882:	cmp    $0x0,%rax
 1012886:	jne    10128eb <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xedb>
 1012888:	mov    -0xa8(%rbp),%rax
 101288f:	cmp    $0x0,%rax
 1012893:	je     10128af <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xe9f>
 1012895:	sub    $0x10,%rax
 1012899:	mov    (%rax),%rax
 101289c:	movabs $0x5000000000000001,%rcx
 10128a6:	and    %rcx,%rax
 10128a9:	cmp    $0x0,%rax
 10128ad:	jne    10128e6 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xed6>
 10128af:	mov    -0xb0(%rbp),%rax
 10128b6:	mov    %rax,-0x88(%rbp)
 10128bd:	mov    -0xa8(%rbp),%rax
 10128c4:	mov    %rax,-0x80(%rbp)
 10128c8:	mov    $0x10,%edx
 10128cd:	mov    $0x0,%esi
 10128d2:	mov    %rdi,%rbx
 10128d5:	lea    -0xb0(%rbp),%rdi
 10128dc:	call   1028940 <compiler_rt.fastMemset>
 10128e1:	mov    %rbx,%rdi
 10128e4:	jmp    1012938 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xf28>
 10128e6:	xchg   %rdi,%rbx
 10128e9:	jmp    10128f3 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xee3>
 10128eb:	xchg   %rdi,%rbx
 10128ee:	jmp    10128f3 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xee3>
 10128f0:	xchg   %rdi,%rbx
 10128f3:	mov    %r8,%r15
 10128f6:	lea    -0xb0(%rbp),%rcx
 10128fd:	lea    -0x88(%rbp),%rdx
 1012904:	lea    0x1a5d5(%rip),%rsi        # 102cee0 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 101290b:	mov    %rdi,%r12
 101290e:	call   10285a0 <myl_rc_native_take>
 1012913:	mov    %r12,%rdi
 1012916:	cmp    $0x0,%eax
 1012919:	jne    1012935 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xf25>
 101291b:	call   10210c0 <myl_rc_take_failure>
 1012920:	mov    %rbx,%rdi
 1012923:	mov    %eax,%esi
 1012925:	mov    %rdi,%rbx
 1012928:	call   1018810 <myl_qbe_rc_status>
 101292d:	mov    %rbx,%rdi
 1012930:	jmp    1012e9e <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x148e>
 1012935:	mov    %rbx,%rdi
 1012938:	movl   $0x0,-0xd8(%rbp)
 1012942:	lea    0x1a597(%rip),%rax        # 102cee0 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 1012949:	mov    %rax,-0x120(%rbp)
 1012950:	movl   $0x2,-0x108(%rbp)
 101295a:	movl   $0x1,-0xc0(%rbp)
 1012964:	movl   $0x0,-0xc0(%rbp)
 101296e:	lea    -0x1c0(%rbp),%rsi
 1012975:	mov    %rdi,%rbx
 1012978:	call   1018af0 <myl_qbe_rc_frame_cleanup>
 101297d:	mov    %rbx,%rdi
 1012980:	lea    -0x1c0(%rbp),%rsi
 1012987:	call   1018980 <myl_qbe_rc_frame_leave>
 101298c:	mov    -0x88(%rbp),%rax
 1012993:	mov    -0x80(%rbp),%rdx
 1012997:	jmp    1012f44 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1534>
 101299c:	mov    $0x40,%r8d
 10129a2:	mov    $0x1,%ecx
 10129a7:	mov    $0x1,%esi
 10129ac:	call   1019090 <myl_qbe_fail_overflow_op>
 10129b1:	ud2
 10129b3:	mov    $0x40,%r8d
 10129b9:	mov    $0x1,%ecx
 10129be:	mov    $0x1,%esi
 10129c3:	mov    %rdi,%rbx
 10129c6:	call   1019090 <myl_qbe_fail_overflow_op>
 10129cb:	ud2
 10129cd:	xchg   %rdi,%rbx
 10129d0:	mov    $0x8,%edx
 10129d5:	mov    $0x0,%esi
 10129da:	mov    %rdi,%r13
 10129dd:	lea    -0x58(%rbp),%rdi
 10129e1:	call   1028940 <compiler_rt.fastMemset>
 10129e6:	mov    %r13,%rdi
 10129e9:	movq   $0x0,-0x58(%rbp)
 10129f1:	lea    -0x58(%rbp),%rax
 10129f5:	mov    %rax,-0x68(%rbp)
 10129f9:	mov    -0x58(%rbp),%rax
 10129fd:	mov    %rax,-0xb0(%rbp)
 1012a04:	lea    0x1a465(%rip),%rax        # 102ce70 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 1012a0b:	mov    %rax,-0x180(%rbp)
 1012a12:	movl   $0x2,-0x168(%rbp)
 1012a1c:	movl   $0x1,-0xd8(%rbp)
 1012a26:	lea    -0xb0(%rbp),%rax
 1012a2d:	mov    %rax,-0x68(%rbp)
 1012a31:	movl   $0x0,-0xb8(%rbp)
 1012a3b:	mov    $0x8,%edx
 1012a40:	mov    $0x0,%esi
 1012a45:	mov    %rdi,%r13
 1012a48:	lea    -0x50(%rbp),%rdi
 1012a4c:	call   1028940 <compiler_rt.fastMemset>
 1012a51:	mov    %r13,%rdi
 1012a54:	movq   $0x0,-0x50(%rbp)
 1012a5c:	lea    -0x50(%rbp),%rax
 1012a60:	mov    %rax,-0x60(%rbp)
 1012a64:	mov    -0x50(%rbp),%rax
 1012a68:	mov    %rax,-0xa0(%rbp)
 1012a6f:	lea    0x1a3fa(%rip),%rax        # 102ce70 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 1012a76:	mov    %rax,-0x160(%rbp)
 1012a7d:	movl   $0x2,-0x148(%rbp)
 1012a87:	movl   $0x1,-0xd0(%rbp)
 1012a91:	lea    -0xa0(%rbp),%rax
 1012a98:	mov    %rax,-0x60(%rbp)
 1012a9c:	movl   $0x0,-0xb8(%rbp)
 1012aa6:	mov    $0x10,%edx
 1012aab:	mov    $0x0,%esi
 1012ab0:	mov    %rdi,%r13
 1012ab3:	lea    -0x48(%rbp),%rdi
 1012ab7:	call   1028940 <compiler_rt.fastMemset>
 1012abc:	mov    %r15,%r8
 1012abf:	mov    %r13,%rdi
 1012ac2:	mov    -0x10(%rbp),%r13d
 1012ac6:	lea    0x1a413(%rip),%rax        # 102cee0 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 1012acd:	mov    %rax,-0x100(%rbp)
 1012ad4:	movl   $0x2,-0xe8(%rbp)
 1012ade:	lea    -0x48(%rbp),%rax
 1012ae2:	mov    %rax,-0xf8(%rbp)
 1012ae9:	mov    %r14,-0xf0(%rbp)
 1012af0:	movl   $0x1,-0xb8(%rbp)
 1012afa:	mov    -0x68(%rbp),%rcx
 1012afe:	mov    -0xd8(%rbp),%eax
 1012b04:	cmp    $0x0,%eax
 1012b07:	jne    1012b6b <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x115b>
 1012b09:	mov    %r8,%r15
 1012b0c:	lea    -0x88(%rbp),%rdx
 1012b13:	lea    0x1a356(%rip),%rsi        # 102ce70 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 1012b1a:	mov    %rdi,%r14
 1012b1d:	call   1028100 <myl_rc_native_copy>
 1012b22:	mov    %r14,%rdi
 1012b25:	cmp    $0x0,%eax
 1012b28:	jne    1012b44 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1134>
 1012b2a:	call   10210c0 <myl_rc_take_failure>
 1012b2f:	mov    %rbx,%rdi
 1012b32:	mov    %eax,%esi
 1012b34:	mov    %rdi,%rbx
 1012b37:	call   1018810 <myl_qbe_rc_status>
 1012b3c:	mov    %rbx,%rdi
 1012b3f:	jmp    1012e9e <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x148e>
 1012b44:	lea    0x1a325(%rip),%rax        # 102ce70 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 1012b4b:	mov    %rax,-0x120(%rbp)
 1012b52:	movl   $0x2,-0x108(%rbp)
 1012b5c:	movl   $0x1,-0xc0(%rbp)
 1012b66:	jmp    1012c54 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1244>
 1012b6b:	mov    %r8,%r15
 1012b6e:	lea    -0x88(%rbp),%rax
 1012b75:	neg    %rax
 1012b78:	add    %rcx,%rax
 1012b7b:	lea    -0x88(%rbp),%rdx
 1012b82:	sub    %rcx,%rdx
 1012b85:	cmp    $0x8,%rax
 1012b89:	setb   %al
 1012b8c:	movzbl %al,%eax
 1012b8f:	cmp    $0x8,%rdx
 1012b93:	setb   %dl
 1012b96:	movzbl %dl,%edx
 1012b99:	or     %edx,%eax
 1012b9b:	jne    1012bea <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x11da>
 1012b9d:	mov    (%rcx),%rax
 1012ba0:	cmp    $0x0,%rax
 1012ba4:	je     1012bc0 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x11b0>
 1012ba6:	sub    $0x10,%rax
 1012baa:	mov    (%rax),%rax
 1012bad:	movabs $0x5000000000000001,%rdx
 1012bb7:	and    %rdx,%rax
 1012bba:	cmp    $0x0,%rax
 1012bbe:	jne    1012bea <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x11da>
 1012bc0:	mov    (%rcx),%rax
 1012bc3:	mov    %rax,-0x88(%rbp)
 1012bca:	mov    $0x8,%edx
 1012bcf:	mov    $0x0,%esi
 1012bd4:	mov    %rdi,%r14
 1012bd7:	mov    %rcx,%rdi
 1012bda:	call   1028940 <compiler_rt.fastMemset>
 1012bdf:	mov    %r15,%r8
 1012be2:	mov    %r14,%rdi
 1012be5:	mov    %r8,%r15
 1012be8:	jmp    1012c28 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1218>
 1012bea:	mov    %r15,%r8
 1012bed:	mov    %r8,%r15
 1012bf0:	lea    -0x88(%rbp),%rdx
 1012bf7:	lea    0x1a272(%rip),%rsi        # 102ce70 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 1012bfe:	mov    %rdi,%r14
 1012c01:	call   10285a0 <myl_rc_native_take>
 1012c06:	mov    %r14,%rdi
 1012c09:	cmp    $0x0,%eax
 1012c0c:	jne    1012c28 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1218>
 1012c0e:	call   10210c0 <myl_rc_take_failure>
 1012c13:	mov    %rbx,%rdi
 1012c16:	mov    %eax,%esi
 1012c18:	mov    %rdi,%rbx
 1012c1b:	call   1018810 <myl_qbe_rc_status>
 1012c20:	mov    %rbx,%rdi
 1012c23:	jmp    1012e9e <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x148e>
 1012c28:	movl   $0x0,-0xd8(%rbp)
 1012c32:	lea    0x1a237(%rip),%rax        # 102ce70 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 1012c39:	mov    %rax,-0x120(%rbp)
 1012c40:	movl   $0x2,-0x108(%rbp)
 1012c4a:	movl   $0x1,-0xc0(%rbp)
 1012c54:	mov    -0x88(%rbp),%rax
 1012c5b:	mov    %rax,-0x48(%rbp)
 1012c5f:	movl   $0x0,-0xc0(%rbp)
 1012c69:	mov    -0x60(%rbp),%rcx
 1012c6d:	lea    -0x88(%rbp),%rax
 1012c74:	neg    %rax
 1012c77:	add    %rcx,%rax
 1012c7a:	lea    -0x88(%rbp),%rdx
 1012c81:	sub    %rcx,%rdx
 1012c84:	cmp    $0x8,%rax
 1012c88:	setb   %al
 1012c8b:	movzbl %al,%eax
 1012c8e:	cmp    $0x8,%rdx
 1012c92:	setb   %dl
 1012c95:	movzbl %dl,%edx
 1012c98:	or     %edx,%eax
 1012c9a:	jne    1012ce9 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x12d9>
 1012c9c:	mov    (%rcx),%rax
 1012c9f:	cmp    $0x0,%rax
 1012ca3:	je     1012cbf <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x12af>
 1012ca5:	sub    $0x10,%rax
 1012ca9:	mov    (%rax),%rax
 1012cac:	movabs $0x5000000000000001,%rdx
 1012cb6:	and    %rdx,%rax
 1012cb9:	cmp    $0x0,%rax
 1012cbd:	jne    1012ce9 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x12d9>
 1012cbf:	mov    (%rcx),%rax
 1012cc2:	mov    %rax,-0x88(%rbp)
 1012cc9:	mov    $0x8,%edx
 1012cce:	mov    $0x0,%esi
 1012cd3:	mov    %rdi,%r14
 1012cd6:	mov    %rcx,%rdi
 1012cd9:	call   1028940 <compiler_rt.fastMemset>
 1012cde:	mov    %r15,%r8
 1012ce1:	mov    %r14,%rdi
 1012ce4:	xchg   %rbx,%rdi
 1012ce7:	jmp    1012d2d <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x131d>
 1012ce9:	mov    %r15,%r8
 1012cec:	mov    %r8,%r15
 1012cef:	lea    -0x88(%rbp),%rdx
 1012cf6:	lea    0x1a173(%rip),%rsi        # 102ce70 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 1012cfd:	mov    %rdi,%r14
 1012d00:	call   10285a0 <myl_rc_native_take>
 1012d05:	mov    %r15,%r8
 1012d08:	mov    %r14,%rdi
 1012d0b:	cmp    $0x0,%eax
 1012d0e:	jne    1012d2a <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x131a>
 1012d10:	call   10210c0 <myl_rc_take_failure>
 1012d15:	mov    %rbx,%rdi
 1012d18:	mov    %eax,%esi
 1012d1a:	mov    %rdi,%rbx
 1012d1d:	call   1018810 <myl_qbe_rc_status>
 1012d22:	mov    %rbx,%rdi
 1012d25:	jmp    1012e9e <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x148e>
 1012d2a:	xchg   %rbx,%rdi
 1012d2d:	movl   $0x0,-0xd0(%rbp)
 1012d37:	lea    0x1a132(%rip),%rax        # 102ce70 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 1012d3e:	mov    %rax,-0x120(%rbp)
 1012d45:	movl   $0x2,-0x108(%rbp)
 1012d4f:	movl   $0x1,-0xc0(%rbp)
 1012d59:	mov    -0x88(%rbp),%rax
 1012d60:	mov    %rax,-0x40(%rbp)
 1012d64:	movl   $0x0,-0xc0(%rbp)
 1012d6e:	lea    -0x48(%rbp),%rax
 1012d72:	mov    %rax,-0x68(%rbp)
 1012d76:	mov    -0x48(%rbp),%rax
 1012d7a:	mov    %rax,-0xb0(%rbp)
 1012d81:	mov    -0x40(%rbp),%rax
 1012d85:	mov    %rax,-0xa8(%rbp)
 1012d8c:	lea    0x1a14d(%rip),%rax        # 102cee0 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 1012d93:	mov    %rax,-0x180(%rbp)
 1012d9a:	movl   $0x2,-0x168(%rbp)
 1012da4:	movl   $0x1,-0xd8(%rbp)
 1012dae:	lea    -0xb0(%rbp),%rax
 1012db5:	mov    %rax,-0x68(%rbp)
 1012db9:	movl   $0x0,-0xb8(%rbp)
 1012dc3:	mov    %r12d,%eax
 1012dc6:	or     %r13d,%eax
 1012dc9:	jne    1012e61 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1451>
 1012dcf:	mov    -0xb0(%rbp),%rax
 1012dd6:	cmp    $0x0,%rax
 1012dda:	je     1012df6 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x13e6>
 1012ddc:	sub    $0x10,%rax
 1012de0:	mov    (%rax),%rax
 1012de3:	movabs $0x5000000000000001,%rcx
 1012ded:	and    %rcx,%rax
 1012df0:	cmp    $0x0,%rax
 1012df4:	jne    1012e5c <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x144c>
 1012df6:	mov    -0xa8(%rbp),%rax
 1012dfd:	cmp    $0x0,%rax
 1012e01:	je     1012e1d <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x140d>
 1012e03:	sub    $0x10,%rax
 1012e07:	mov    (%rax),%rax
 1012e0a:	movabs $0x5000000000000001,%rcx
 1012e14:	and    %rcx,%rax
 1012e17:	cmp    $0x0,%rax
 1012e1b:	jne    1012e57 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1447>
 1012e1d:	mov    -0xb0(%rbp),%rax
 1012e24:	mov    %rax,-0x88(%rbp)
 1012e2b:	mov    -0xa8(%rbp),%rax
 1012e32:	mov    %rax,-0x80(%rbp)
 1012e36:	mov    $0x10,%edx
 1012e3b:	mov    $0x0,%esi
 1012e40:	mov    %rdi,%rbx
 1012e43:	lea    -0xb0(%rbp),%rdi
 1012e4a:	call   1028940 <compiler_rt.fastMemset>
 1012e4f:	mov    %rbx,%rdi
 1012e52:	jmp    1012ee5 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x14d5>
 1012e57:	xchg   %rdi,%rbx
 1012e5a:	jmp    1012e64 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1454>
 1012e5c:	xchg   %rdi,%rbx
 1012e5f:	jmp    1012e64 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1454>
 1012e61:	xchg   %rdi,%rbx
 1012e64:	lea    -0xb0(%rbp),%rcx
 1012e6b:	lea    -0x88(%rbp),%rdx
 1012e72:	lea    0x1a067(%rip),%rsi        # 102cee0 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 1012e79:	mov    %rdi,%r12
 1012e7c:	call   10285a0 <myl_rc_native_take>
 1012e81:	mov    %r12,%rdi
 1012e84:	cmp    $0x0,%eax
 1012e87:	jne    1012ee2 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x14d2>
 1012e89:	call   10210c0 <myl_rc_take_failure>
 1012e8e:	mov    %rbx,%rdi
 1012e91:	mov    %eax,%esi
 1012e93:	mov    %rdi,%rbx
 1012e96:	call   1018810 <myl_qbe_rc_status>
 1012e9b:	mov    %rbx,%rdi
 1012e9e:	lea    -0x1c0(%rbp),%rsi
 1012ea5:	mov    %rdi,%rbx
 1012ea8:	call   1018af0 <myl_qbe_rc_frame_cleanup>
 1012ead:	mov    %rbx,%rdi
 1012eb0:	lea    -0x1c0(%rbp),%rsi
 1012eb7:	call   1018980 <myl_qbe_rc_frame_leave>
 1012ebc:	mov    $0x10,%edx
 1012ec1:	mov    $0x0,%esi
 1012ec6:	lea    -0x1d0(%rbp),%rdi
 1012ecd:	call   1028940 <compiler_rt.fastMemset>
 1012ed2:	mov    -0x1d0(%rbp),%rax
 1012ed9:	mov    -0x1c8(%rbp),%rdx
 1012ee0:	jmp    1012f44 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1534>
 1012ee2:	mov    %rbx,%rdi
 1012ee5:	movl   $0x0,-0xd8(%rbp)
 1012eef:	lea    0x19fea(%rip),%rax        # 102cee0 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 1012ef6:	mov    %rax,-0x120(%rbp)
 1012efd:	movl   $0x2,-0x108(%rbp)
 1012f07:	movl   $0x1,-0xc0(%rbp)
 1012f11:	movl   $0x0,-0xc0(%rbp)
 1012f1b:	lea    -0x1c0(%rbp),%rsi
 1012f22:	mov    %rdi,%rbx
 1012f25:	call   1018af0 <myl_qbe_rc_frame_cleanup>
 1012f2a:	mov    %rbx,%rdi
 1012f2d:	lea    -0x1c0(%rbp),%rsi
 1012f34:	call   1018980 <myl_qbe_rc_frame_leave>
 1012f39:	mov    -0x88(%rbp),%rax
 1012f40:	mov    -0x80(%rbp),%rdx
 1012f44:	pop    %r15
 1012f46:	pop    %r14
 1012f48:	pop    %r13
 1012f4a:	pop    %r12
 1012f4c:	pop    %rbx
 1012f4d:	leave
 1012f4e:	ret
 1012f4f:	call   10191e0 <myl_qbe_fail_frame>
 1012f54:	ud2

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
