
.tmp-rc/profile/gap-allocator-llvm-gc-n12:     file format elf64-x86-64


Disassembly of section .text:

0000000001014e40 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531>:
 1014e40:	push   %r15
 1014e42:	push   %r14
 1014e44:	push   %r13
 1014e46:	push   %r12
 1014e48:	push   %rbx
 1014e49:	sub    $0x70,%rsp
 1014e4d:	mov    %rdi,%rbx
 1014e50:	cmp    %rsp,0x40(%rdi)
 1014e54:	ja     1015012 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1d2>
 1014e5a:	xor    %eax,%eax
 1014e5c:	mov    $0x0,%edx
 1014e61:	test   %rsi,%rsi
 1014e64:	je     1015004 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1c4>
 1014e6a:	mov    %rsi,%rax
 1014e6d:	neg    %rax
 1014e70:	jo     101501a <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1da>
 1014e76:	lea    0x258(%rbx),%r14
 1014e7d:	mov    0x268(%rbx),%r15
 1014e84:	dec    %rsi
 1014e87:	mov    %rbx,%rdi
 1014e8a:	mov    %rsi,%r12
 1014e8d:	call   1014e40 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531>
 1014e92:	mov    %rax,0x40(%rsp)
 1014e97:	mov    %rdx,0x48(%rsp)
 1014e9c:	mov    0x768(%rbx),%rax
 1014ea3:	lea    0x20(%rax),%rcx
 1014ea7:	cmp    0x770(%rbx),%rcx
 1014eae:	jbe    1014ef5 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xb5>
 1014eb0:	mov    0x268(%rbx),%rax
 1014eb7:	mov    %rax,0x10(%rsp)
 1014ebc:	lea    0x40(%rsp),%rax
 1014ec1:	mov    %rax,0x18(%rsp)
 1014ec6:	movq   $0x1009d08,0x20(%rsp)
 1014ecf:	lea    0x10(%rsp),%rax
 1014ed4:	mov    %rax,0x268(%rbx)
 1014edb:	mov    %r14,%rdi
 1014ede:	call   101de00 <myl_native_heap_alloc_small>
 1014ee3:	test   %rax,%rax
 1014ee6:	je     1015036 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1f6>
 1014eec:	mov    %r15,0x268(%rbx)
 1014ef3:	jmp    1014f18 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xd8>
 1014ef5:	mov    %rcx,0x768(%rbx)
 1014efc:	movq   $0x4,(%rax)
 1014f03:	movq   $0x1009a98,0x8(%rax)
 1014f0b:	vxorps %xmm0,%xmm0,%xmm0
 1014f0f:	vmovups %xmm0,0x10(%rax)
 1014f14:	add    $0x10,%rax
 1014f18:	mov    %r12,%rsi
 1014f1b:	vmovups 0x40(%rsp),%xmm0
 1014f21:	vmovups %xmm0,(%rax)
 1014f25:	mov    %rax,0x8(%rsp)
 1014f2a:	mov    0x268(%rbx),%rax
 1014f31:	mov    %rax,0x10(%rsp)
 1014f36:	lea    0x8(%rsp),%r12
 1014f3b:	mov    %r12,0x18(%rsp)
 1014f40:	movq   $0x1009c78,0x20(%rsp)
 1014f49:	lea    0x10(%rsp),%r13
 1014f4e:	mov    %r13,0x268(%rbx)
 1014f55:	mov    %rbx,%rdi
 1014f58:	call   1014e40 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531>
 1014f5d:	mov    %rax,0x30(%rsp)
 1014f62:	mov    %rdx,0x38(%rsp)
 1014f67:	mov    %r15,0x268(%rbx)
 1014f6e:	mov    0x768(%rbx),%rdx
 1014f75:	lea    0x20(%rdx),%rax
 1014f79:	cmp    0x770(%rbx),%rax
 1014f80:	jbe    1014fd2 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x192>
 1014f82:	mov    %r15,0x10(%rsp)
 1014f87:	mov    %r12,0x18(%rsp)
 1014f8c:	movq   $0x1009c78,0x20(%rsp)
 1014f95:	mov    %r13,0x50(%rsp)
 1014f9a:	lea    0x30(%rsp),%rax
 1014f9f:	mov    %rax,0x58(%rsp)
 1014fa4:	movq   $0x1009d08,0x60(%rsp)
 1014fad:	lea    0x50(%rsp),%rax
 1014fb2:	mov    %rax,0x268(%rbx)
 1014fb9:	mov    %r14,%rdi
 1014fbc:	call   101de00 <myl_native_heap_alloc_small>
 1014fc1:	test   %rax,%rax
 1014fc4:	je     101503e <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1fe>
 1014fc6:	mov    %rax,%rdx
 1014fc9:	mov    %r15,0x268(%rbx)
 1014fd0:	jmp    1014ff5 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x1b5>
 1014fd2:	mov    %rax,0x768(%rbx)
 1014fd9:	movq   $0x4,(%rdx)
 1014fe0:	movq   $0x1009a98,0x8(%rdx)
 1014fe8:	vxorps %xmm0,%xmm0,%xmm0
 1014fec:	vmovups %xmm0,0x10(%rdx)
 1014ff1:	add    $0x10,%rdx
 1014ff5:	vmovups 0x30(%rsp),%xmm0
 1014ffb:	vmovups %xmm0,(%rdx)
 1014fff:	mov    0x8(%rsp),%rax
 1015004:	add    $0x70,%rsp
 1015008:	pop    %rbx
 1015009:	pop    %r12
 101500b:	pop    %r13
 101500d:	pop    %r14
 101500f:	pop    %r15
 1015011:	ret
 1015012:	mov    %rbx,%rdi
 1015015:	call   101ad20 <myl_qbe_fail_frame>
 101501a:	movabs $0x8000000000000000,%rdx
 1015024:	mov    $0x1,%esi
 1015029:	mov    $0x1,%ecx
 101502e:	mov    %rbx,%rdi
 1015031:	call   101acb0 <myl_qbe_fail_overflow_op>
 1015036:	mov    %rbx,%rdi
 1015039:	call   101ac70 <myl_qbe_fail_allocation>
 101503e:	mov    %rbx,%rdi
 1015041:	call   101ac70 <myl_qbe_fail_allocation>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
