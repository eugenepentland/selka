
.tmp-rc/profile/gap-allocator-qbe-rc-repeat:     file format elf64-x86-64


Disassembly of section .text:

0000000001023870 <myl_rc_drain>:
 1023870:	push   %rbp
 1023871:	mov    %rsp,%rbp
 1023874:	push   %r15
 1023876:	push   %r14
 1023878:	push   %r13
 102387a:	push   %r12
 102387c:	push   %rbx
 102387d:	push   %rax
 102387e:	test   %rdi,%rdi
 1023881:	je     10239c7 <myl_rc_drain+0x157>
 1023887:	mov    %rdi,%rbx
 102388a:	mov    0x1608(%rdi),%rax
 1023891:	test   %rax,%rax
 1023894:	je     10239c7 <myl_rc_drain+0x157>
 102389a:	cmpl   $0x0,0x68(%rax)
 102389e:	jne    10239b8 <myl_rc_drain+0x148>
 10238a4:	cmpq   $0x0,0x58(%rax)
 10238a9:	jne    10239b8 <myl_rc_drain+0x148>
 10238af:	movl   $0x1,0x68(%rax)
 10238b6:	mov    0x60(%rax),%r13
 10238ba:	test   %r13,%r13
 10238bd:	je     10239b1 <myl_rc_drain+0x141>
 10238c3:	add    $0x60,%rax
 10238c7:	mov    $0x3c,%r12d
 10238cd:	mov    %rax,%rcx
 10238d0:	mov    0x0(%r13),%rax
 10238d4:	mov    %rax,(%rcx)
 10238d7:	mov    0x18(%r13),%rsi
 10238db:	mov    %rbx,%rdi
 10238de:	call   1021d30 <myl_rc_descriptor_find>
 10238e3:	test   %rax,%rax
 10238e6:	je     10239c7 <myl_rc_drain+0x157>
 10238ec:	bzhi   %r12,0x10(%r13),%r15
 10238f2:	lea    0x20(%r13),%r14
 10238f6:	shr    $0x2,%r15
 10238fa:	cmpl   $0x8,0x78(%rax)
 10238fe:	ja     1023920 <myl_rc_drain+0xb0>
 1023900:	mov    %rbx,%rdi
 1023903:	mov    %rax,%rsi
 1023906:	mov    %r14,%rdx
 1023909:	mov    %r15,%rcx
 102390c:	call   1023770 <myl_rc_flat_edges_release>
 1023911:	jmp    1023980 <myl_rc_drain+0x110>
 1023913:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1023920:	mov    0x18(%rax),%rax
 1023924:	test   %rax,%rax
 1023927:	je     1023931 <myl_rc_drain+0xc1>
 1023929:	mov    %rbx,%rdi
 102392c:	mov    %r14,%rsi
 102392f:	call   *%rax
 1023931:	mov    0x18(%r13),%rsi
 1023935:	mov    %rbx,%rdi
 1023938:	call   1021d30 <myl_rc_descriptor_find>
 102393d:	test   %rax,%rax
 1023940:	je     10239c7 <myl_rc_drain+0x157>
 1023946:	mov    0x1608(%rbx),%rcx
 102394d:	cmpq   $0x0,0x58(%rcx)
 1023952:	jne    10239c7 <myl_rc_drain+0x157>
 1023954:	mov    0x10(%rax),%rcx
 1023958:	test   %rcx,%rcx
 102395b:	je     102396a <myl_rc_drain+0xfa>
 102395d:	mov    %rbx,%rdi
 1023960:	mov    %r14,%rsi
 1023963:	mov    %r15,%rdx
 1023966:	call   *%rcx
 1023968:	jmp    1023980 <myl_rc_drain+0x110>
 102396a:	mov    0x8(%rax),%rsi
 102396e:	mov    %rbx,%rdi
 1023971:	mov    %r14,%rdx
 1023974:	mov    %r15,%rcx
 1023977:	call   1023660 <myl_rc_edges_release>
 102397c:	nopl   0x0(%rax)
 1023980:	mov    0x1608(%rbx),%rax
 1023987:	cmpq   $0x0,0x58(%rax)
 102398c:	jne    10239c7 <myl_rc_drain+0x157>
 102398e:	mov    %rbx,%rdi
 1023991:	mov    %r14,%rsi
 1023994:	call   10214b0 <myl_rc_allocator_retire>
 1023999:	mov    0x1608(%rbx),%rax
 10239a0:	lea    0x60(%rax),%rcx
 10239a4:	mov    0x60(%rax),%r13
 10239a8:	test   %r13,%r13
 10239ab:	jne    10238d0 <myl_rc_drain+0x60>
 10239b1:	movl   $0x0,0x68(%rax)
 10239b8:	add    $0x8,%rsp
 10239bc:	pop    %rbx
 10239bd:	pop    %r12
 10239bf:	pop    %r13
 10239c1:	pop    %r14
 10239c3:	pop    %r15
 10239c5:	pop    %rbp
 10239c6:	ret
 10239c7:	call   1020fce <myl_rc_invariant_failed>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
