
.tmp-rc/profile/gap-allocator-qbe-rc-repeat:     file format elf64-x86-64


Disassembly of section .text:

0000000001027430 <myl_rc_storage_alloc>:
 1027430:	push   %rbp
 1027431:	mov    %rsp,%rbp
 1027434:	push   %r15
 1027436:	push   %r14
 1027438:	push   %r13
 102743a:	push   %r12
 102743c:	push   %rbx
 102743d:	sub    $0x28,%rsp
 1027441:	test   %rdi,%rdi
 1027444:	je     10275cb <myl_rc_storage_alloc+0x19b>
 102744a:	mov    %rsi,%r14
 102744d:	test   %rsi,%rsi
 1027450:	je     10275cb <myl_rc_storage_alloc+0x19b>
 1027456:	mov    %rdi,%rbx
 1027459:	mov    0x1608(%rdi),%rax
 1027460:	test   %rax,%rax
 1027463:	je     10275cb <myl_rc_storage_alloc+0x19b>
 1027469:	mov    %ecx,%r15d
 102746c:	mov    %rdx,%r12
 102746f:	test   %ecx,%ecx
 1027471:	setne  %cl
 1027474:	cmp    $0x1,%rdx
 1027478:	setne  %dl
 102747b:	or     %cl,%dl
 102747d:	jne    102748b <myl_rc_storage_alloc+0x5b>
 102747f:	lea    0x14a(%rip),%rcx        # 10275d0 <allocate>
 1027486:	cmp    %rcx,(%rax)
 1027489:	je     10274e1 <myl_rc_storage_alloc+0xb1>
 102748b:	mov    %rbx,%rdi
 102748e:	mov    %r14,%rsi
 1027491:	call   1028100 <myl_rc_native_shape>
 1027496:	test   %rax,%rax
 1027499:	je     10275ba <myl_rc_storage_alloc+0x18a>
 102749f:	mov    %r14,-0x48(%rbp)
 10274a3:	mov    %r12,-0x40(%rbp)
 10274a7:	mov    %r15d,-0x38(%rbp)
 10274ab:	movl   $0x0,-0x34(%rbp)
 10274b2:	movq   $0x0,-0x30(%rbp)
 10274ba:	lea    -0x48(%rbp),%rsi
 10274be:	lea    -0x30(%rbp),%rdx
 10274c2:	mov    %rbx,%rdi
 10274c5:	call   10213b0 <myl_rc_new>
 10274ca:	test   %eax,%eax
 10274cc:	je     10274d8 <myl_rc_storage_alloc+0xa8>
 10274ce:	mov    %rbx,%rdi
 10274d1:	mov    %eax,%esi
 10274d3:	call   1021130 <myl_rc_record_failure>
 10274d8:	mov    -0x30(%rbp),%rax
 10274dc:	jmp    10275bc <myl_rc_storage_alloc+0x18c>
 10274e1:	mov    0x18(%rax),%r13
 10274e5:	cmp    %r14,0x210(%r13)
 10274ec:	je     1027566 <myl_rc_storage_alloc+0x136>
 10274ee:	mov    %rbx,%rdi
 10274f1:	mov    %r14,%rsi
 10274f4:	call   1028100 <myl_rc_native_shape>
 10274f9:	test   %rax,%rax
 10274fc:	je     10275ba <myl_rc_storage_alloc+0x18a>
 1027502:	cmpq   $0x10,0x8(%r14)
 1027507:	ja     102749f <myl_rc_storage_alloc+0x6f>
 1027509:	mov    (%r14),%rax
 102750c:	cmp    $0x1fe0,%rax
 1027512:	ja     102749f <myl_rc_storage_alloc+0x6f>
 1027514:	add    $0x20,%rax
 1027518:	mov    $0x20,%ecx
 102751d:	xor    %esi,%esi
 102751f:	lea    -0x1ca16(%rip),%rdx        # 100ab10 <strides>
 1027526:	jmp    1027538 <myl_rc_storage_alloc+0x108>
 1027528:	nopl   0x0(%rax,%rax,1)
 1027530:	mov    %r8,%rcx
 1027533:	cmp    %rcx,%rsi
 1027536:	jae    1027556 <myl_rc_storage_alloc+0x126>
 1027538:	mov    %rcx,%rdi
 102753b:	sub    %rsi,%rdi
 102753e:	shr    $1,%rdi
 1027541:	lea    (%rdi,%rsi,1),%r8
 1027545:	cmp    %rax,(%rdx,%r8,8)
 1027549:	jae    1027530 <myl_rc_storage_alloc+0x100>
 102754b:	add    %rdi,%rsi
 102754e:	inc    %rsi
 1027551:	cmp    %rcx,%rsi
 1027554:	jb     1027538 <myl_rc_storage_alloc+0x108>
 1027556:	mov    %r14,0x210(%r13)
 102755d:	mov    %rsi,0x218(%r13)
 1027564:	jmp    102756d <myl_rc_storage_alloc+0x13d>
 1027566:	mov    0x218(%r13),%rsi
 102756d:	mov    %rbx,%rdi
 1027570:	call   1027850 <slab_take>
 1027575:	test   %rax,%rax
 1027578:	je     10275ad <myl_rc_storage_alloc+0x17d>
 102757a:	movq   $0x1,(%rax)
 1027581:	movq   $0x0,0x8(%rax)
 1027589:	movq   $0x4,0x10(%rax)
 1027591:	mov    %r14,0x18(%rax)
 1027595:	vmovdqu 0x40(%rbx),%xmm0
 102759a:	vpcmpeqd %xmm1,%xmm1,%xmm1
 102759e:	vpsubq %xmm1,%xmm0,%xmm0
 10275a2:	vmovdqu %xmm0,0x40(%rbx)
 10275a7:	add    $0x20,%rax
 10275ab:	jmp    10275bc <myl_rc_storage_alloc+0x18c>
 10275ad:	mov    %rbx,%rdi
 10275b0:	mov    $0x1,%esi
 10275b5:	call   1021130 <myl_rc_record_failure>
 10275ba:	xor    %eax,%eax
 10275bc:	add    $0x28,%rsp
 10275c0:	pop    %rbx
 10275c1:	pop    %r12
 10275c3:	pop    %r13
 10275c5:	pop    %r14
 10275c7:	pop    %r15
 10275c9:	pop    %rbp
 10275ca:	ret
 10275cb:	call   1020fce <myl_rc_invariant_failed>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
