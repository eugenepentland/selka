
.tmp-rc/profile/gap-allocator-qbe-rc-repeat:     file format elf64-x86-64


Disassembly of section .text:

0000000001023770 <myl_rc_flat_edges_release>:
 1023770:	push   %rbp
 1023771:	mov    %rsp,%rbp
 1023774:	push   %r15
 1023776:	push   %r14
 1023778:	push   %r13
 102377a:	push   %r12
 102377c:	push   %rbx
 102377d:	sub    $0x18,%rsp
 1023781:	mov    %rcx,-0x30(%rbp)
 1023785:	test   %rdi,%rdi
 1023788:	je     1023866 <myl_rc_flat_edges_release+0xf6>
 102378e:	mov    %rdi,%r12
 1023791:	mov    0x1608(%rdi),%rax
 1023798:	test   %rax,%rax
 102379b:	je     1023866 <myl_rc_flat_edges_release+0xf6>
 10237a1:	cmpq   $0x0,0x58(%rax)
 10237a6:	jne    1023866 <myl_rc_flat_edges_release+0xf6>
 10237ac:	mov    %rsi,%r15
 10237af:	cmpl   $0x9,0x78(%rsi)
 10237b3:	jae    1023866 <myl_rc_flat_edges_release+0xf6>
 10237b9:	mov    %rdx,%r14
 10237bc:	mov    (%r15),%rax
 10237bf:	mov    (%rax),%rdi
 10237c2:	lea    -0x38(%rbp),%rdx
 10237c6:	mov    -0x30(%rbp),%rsi
 10237ca:	call   1021000 <myl_rc_size_mul>
 10237cf:	test   %eax,%eax
 10237d1:	je     1023866 <myl_rc_flat_edges_release+0xf6>
 10237d7:	test   %r14,%r14
 10237da:	jne    10237e7 <myl_rc_flat_edges_release+0x77>
 10237dc:	cmpq   $0x0,-0x38(%rbp)
 10237e1:	jne    1023866 <myl_rc_flat_edges_release+0xf6>
 10237e7:	cmpl   $0x0,0x78(%r15)
 10237ec:	sete   %al
 10237ef:	cmpq   $0x0,-0x30(%rbp)
 10237f4:	sete   %cl
 10237f7:	or     %al,%cl
 10237f9:	jne    1023857 <myl_rc_flat_edges_release+0xe7>
 10237fb:	mov    $0x1,%eax
 1023800:	xor    %r13d,%r13d
 1023803:	jmp    102381f <myl_rc_flat_edges_release+0xaf>
 1023805:	data16 cs nopw 0x0(%rax,%rax,1)
 1023810:	mov    (%r15),%rcx
 1023813:	add    (%rcx),%r14
 1023816:	inc    %r13
 1023819:	cmp    -0x30(%rbp),%r13
 102381d:	je     1023857 <myl_rc_flat_edges_release+0xe7>
 102381f:	test   %eax,%eax
 1023821:	mov    $0x0,%eax
 1023826:	je     1023810 <myl_rc_flat_edges_release+0xa0>
 1023828:	xor    %ebx,%ebx
 102382a:	nopw   0x0(%rax,%rax,1)
 1023830:	mov    0x38(%r15,%rbx,8),%rax
 1023835:	mov    (%r14,%rax,1),%rsi
 1023839:	movq   $0x0,(%r14,%rax,1)
 1023841:	mov    %r12,%rdi
 1023844:	call   1021550 <myl_rc_edge_release>
 1023849:	inc    %rbx
 102384c:	mov    0x78(%r15),%eax
 1023850:	cmp    %rax,%rbx
 1023853:	jb     1023830 <myl_rc_flat_edges_release+0xc0>
 1023855:	jmp    1023810 <myl_rc_flat_edges_release+0xa0>
 1023857:	add    $0x18,%rsp
 102385b:	pop    %rbx
 102385c:	pop    %r12
 102385e:	pop    %r13
 1023860:	pop    %r14
 1023862:	pop    %r15
 1023864:	pop    %rbp
 1023865:	ret
 1023866:	call   1020fce <myl_rc_invariant_failed>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
