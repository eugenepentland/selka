
.tmp-rc/profile/gap-allocator-llvm-gc-n12:     file format elf64-x86-64


Disassembly of section .text:

0000000001014da0 <myl_f_20f65c28671b40937c5bf23acc7c6f37e5a5ec0622e347b57685725df5ba9e50>:
 1014da0:	push   %r15
 1014da2:	push   %r14
 1014da4:	push   %rbx
 1014da5:	sub    $0x20,%rsp
 1014da9:	mov    %rdi,%rbx
 1014dac:	cmp    %rsp,0x40(%rdi)
 1014db0:	ja     1014e11 <myl_f_20f65c28671b40937c5bf23acc7c6f37e5a5ec0622e347b57685725df5ba9e50+0x71>
 1014db2:	mov    (%rsi),%rcx
 1014db5:	mov    $0x1,%eax
 1014dba:	test   %rcx,%rcx
 1014dbd:	je     1014e07 <myl_f_20f65c28671b40937c5bf23acc7c6f37e5a5ec0622e347b57685725df5ba9e50+0x67>
 1014dbf:	mov    0x8(%rsi),%r15
 1014dc3:	test   %r15,%r15
 1014dc6:	je     1014e07 <myl_f_20f65c28671b40937c5bf23acc7c6f37e5a5ec0622e347b57685725df5ba9e50+0x67>
 1014dc8:	vmovups (%rcx),%xmm0
 1014dcc:	vmovaps %xmm0,0x10(%rsp)
 1014dd2:	lea    0x10(%rsp),%rsi
 1014dd7:	mov    %rbx,%rdi
 1014dda:	call   1014da0 <myl_f_20f65c28671b40937c5bf23acc7c6f37e5a5ec0622e347b57685725df5ba9e50>
 1014ddf:	mov    %rax,%r14
 1014de2:	inc    %r14
 1014de5:	jo     1014e19 <myl_f_20f65c28671b40937c5bf23acc7c6f37e5a5ec0622e347b57685725df5ba9e50+0x79>
 1014de7:	vmovups (%r15),%xmm0
 1014dec:	vmovaps %xmm0,(%rsp)
 1014df1:	mov    %rsp,%rsi
 1014df4:	mov    %rbx,%rdi
 1014df7:	call   1014da0 <myl_f_20f65c28671b40937c5bf23acc7c6f37e5a5ec0622e347b57685725df5ba9e50>
 1014dfc:	mov    %rax,%rcx
 1014dff:	mov    %r14,%rax
 1014e02:	add    %rcx,%rax
 1014e05:	jo     1014e2b <myl_f_20f65c28671b40937c5bf23acc7c6f37e5a5ec0622e347b57685725df5ba9e50+0x8b>
 1014e07:	add    $0x20,%rsp
 1014e0b:	pop    %rbx
 1014e0c:	pop    %r14
 1014e0e:	pop    %r15
 1014e10:	ret
 1014e11:	mov    %rbx,%rdi
 1014e14:	call   101ad20 <myl_qbe_fail_frame>
 1014e19:	mov    $0x1,%edx
 1014e1e:	mov    %rbx,%rdi
 1014e21:	xor    %esi,%esi
 1014e23:	mov    %rax,%rcx
 1014e26:	call   101acb0 <myl_qbe_fail_overflow_op>
 1014e2b:	mov    %rbx,%rdi
 1014e2e:	xor    %esi,%esi
 1014e30:	mov    %r14,%rdx
 1014e33:	call   101acb0 <myl_qbe_fail_overflow_op>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
