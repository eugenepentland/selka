
.tmp-rc/profile/gap-allocator-llvm-rc-repeat:     file format elf64-x86-64


Disassembly of section .text:

000000000102a110 <slab_take>:
 102a110:	push   %rbp
 102a111:	mov    %rsp,%rbp
 102a114:	push   %r15
 102a116:	push   %r14
 102a118:	push   %r13
 102a11a:	push   %r12
 102a11c:	push   %rbx
 102a11d:	push   %rax
 102a11e:	test   %rdi,%rdi
 102a121:	je     102a3db <slab_take+0x2cb>
 102a127:	mov    %rdi,%rbx
 102a12a:	mov    0x1608(%rdi),%rax
 102a131:	test   %rax,%rax
 102a134:	je     102a3db <slab_take+0x2cb>
 102a13a:	mov    0x18(%rax),%r14
 102a13e:	mov    %rsi,%r15
 102a141:	shl    $0x4,%r15
 102a145:	mov    0x8(%r14,%r15,1),%rax
 102a14a:	test   %rax,%rax
 102a14d:	je     102a183 <slab_take+0x73>
 102a14f:	mov    0x38(%rax),%rdi
 102a153:	test   %rdi,%rdi
 102a156:	je     102a359 <slab_take+0x249>
 102a15c:	mov    (%rdi),%rcx
 102a15f:	mov    %rcx,0x38(%rax)
 102a163:	incq   0x30(%rax)
 102a167:	test   %rcx,%rcx
 102a16a:	jne    102a3ad <slab_take+0x29d>
 102a170:	mov    0x28(%rax),%rcx
 102a174:	cmp    0x48(%rax),%rcx
 102a178:	je     102a387 <slab_take+0x277>
 102a17e:	jmp    102a3ad <slab_take+0x29d>
 102a183:	mov    %rsi,%r12
 102a186:	mov    $0x10000,%esi
 102a18b:	mov    %rbx,%rdi
 102a18e:	call   102a3f0 <reserve>
 102a193:	test   %eax,%eax
 102a195:	je     102a2da <slab_take+0x1ca>
 102a19b:	mov    $0x10000,%edi
 102a1a0:	mov    $0x10000,%esi
 102a1a5:	call   102f020 <aligned_alloc@plt>
 102a1aa:	test   %rax,%rax
 102a1ad:	jne    102a29c <slab_take+0x18c>
 102a1b3:	xor    %r13d,%r13d
 102a1b6:	jmp    102a1d1 <slab_take+0xc1>
 102a1b8:	nopl   0x0(%rax,%rax,1)
 102a1c0:	add    $0x10,%r13
 102a1c4:	cmp    $0x200,%r13
 102a1cb:	je     102a288 <slab_take+0x178>
 102a1d1:	mov    0x1608(%rbx),%rax
 102a1d8:	test   %rax,%rax
 102a1db:	je     102a3db <slab_take+0x2cb>
 102a1e1:	mov    0x18(%rax),%rax
 102a1e5:	mov    0x8(%rax,%r13,1),%rdi
 102a1ea:	test   %rdi,%rdi
 102a1ed:	je     102a1c0 <slab_take+0xb0>
 102a1ef:	cmpq   $0x0,0x30(%rdi)
 102a1f4:	jne    102a1c0 <slab_take+0xb0>
 102a1f6:	mov    0x40(%rdi),%rcx
 102a1fa:	shl    $0x4,%rcx
 102a1fe:	add    %rcx,%rax
 102a201:	mov    0x10(%rdi),%rcx
 102a205:	mov    0x18(%rdi),%rdx
 102a209:	test   %rcx,%rcx
 102a20c:	je     102a273 <slab_take+0x163>
 102a20e:	mov    %rdx,0x18(%rcx)
 102a212:	test   %rdx,%rdx
 102a215:	je     102a21b <slab_take+0x10b>
 102a217:	mov    %rcx,0x10(%rdx)
 102a21b:	lea    0x10(%rdi),%rcx
 102a21f:	vpxor  %xmm0,%xmm0,%xmm0
 102a223:	vmovdqu %xmm0,(%rcx)
 102a227:	mov    (%rdi),%rdx
 102a22a:	mov    0x8(%rdi),%rcx
 102a22e:	test   %rdx,%rdx
 102a231:	je     102a27e <slab_take+0x16e>
 102a233:	mov    %rcx,0x8(%rdx)
 102a237:	test   %rcx,%rcx
 102a23a:	je     102a242 <slab_take+0x132>
 102a23c:	mov    (%rdi),%rax
 102a23f:	mov    %rax,(%rcx)
 102a242:	addq   $0xffffffffffff0000,0x18(%rbx)
 102a24a:	mov    0x1608(%rbx),%rax
 102a251:	test   %rax,%rax
 102a254:	je     102a3db <slab_take+0x2cb>
 102a25a:	mov    0x18(%rax),%rax
 102a25e:	addq   $0xffffffffffff0000,0x208(%rax)
 102a269:	call   102ece0 <free@plt>
 102a26e:	jmp    102a1c0 <slab_take+0xb0>
 102a273:	mov    %rdx,0x8(%rax)
 102a277:	test   %rdx,%rdx
 102a27a:	jne    102a217 <slab_take+0x107>
 102a27c:	jmp    102a21b <slab_take+0x10b>
 102a27e:	mov    %rcx,(%rax)
 102a281:	test   %rcx,%rcx
 102a284:	jne    102a23c <slab_take+0x12c>
 102a286:	jmp    102a242 <slab_take+0x132>
 102a288:	mov    $0x10000,%edi
 102a28d:	mov    $0x10000,%esi
 102a292:	call   102f020 <aligned_alloc@plt>
 102a297:	test   %rax,%rax
 102a29a:	je     102a2da <slab_take+0x1ca>
 102a29c:	vpxor  %xmm0,%xmm0,%xmm0
 102a2a0:	vmovdqa %ymm0,0x20(%rax)
 102a2a5:	vmovdqu %ymm0,0x30(%rax)
 102a2aa:	vmovdqa %ymm0,(%rax)
 102a2ae:	mov    0x100d4f0(,%r12,8),%rcx
 102a2b6:	mov    %rcx,0x20(%rax)
 102a2ba:	mov    %r12,0x40(%rax)
 102a2be:	cmp    $0xffb0,%rcx
 102a2c5:	ja     102a2eb <slab_take+0x1db>
 102a2c7:	mov    %rax,%rsi
 102a2ca:	mov    $0xffb0,%eax
 102a2cf:	xor    %edx,%edx
 102a2d1:	div    %ecx
 102a2d3:	mov    %eax,%ecx
 102a2d5:	mov    %rsi,%rax
 102a2d8:	jmp    102a2ed <slab_take+0x1dd>
 102a2da:	xor    %eax,%eax
 102a2dc:	add    $0x8,%rsp
 102a2e0:	pop    %rbx
 102a2e1:	pop    %r12
 102a2e3:	pop    %r13
 102a2e5:	pop    %r14
 102a2e7:	pop    %r15
 102a2e9:	pop    %rbp
 102a2ea:	ret
 102a2eb:	xor    %ecx,%ecx
 102a2ed:	mov    %rcx,0x48(%rax)
 102a2f1:	mov    0x1608(%rbx),%rcx
 102a2f8:	test   %rcx,%rcx
 102a2fb:	je     102a3db <slab_take+0x2cb>
 102a301:	mov    0x18(%rcx),%rcx
 102a305:	lea    (%rcx,%r15,1),%rdx
 102a309:	mov    (%rcx,%r15,1),%rsi
 102a30d:	mov    %rsi,0x8(%rax)
 102a311:	test   %rsi,%rsi
 102a314:	je     102a319 <slab_take+0x209>
 102a316:	mov    %rax,(%rsi)
 102a319:	mov    %rax,(%rdx)
 102a31c:	mov    0x8(%rdx),%rsi
 102a320:	movq   $0x0,0x10(%rax)
 102a328:	mov    %rsi,0x18(%rax)
 102a32c:	test   %rsi,%rsi
 102a32f:	je     102a335 <slab_take+0x225>
 102a331:	mov    %rax,0x10(%rsi)
 102a335:	mov    %rax,0x8(%rdx)
 102a339:	addq   $0x10000,0x18(%rbx)
 102a341:	addq   $0x10000,0x208(%rcx)
 102a34c:	mov    0x38(%rax),%rdi
 102a350:	test   %rdi,%rdi
 102a353:	jne    102a15c <slab_take+0x4c>
 102a359:	vmovdqu 0x28(%rax),%xmm0
 102a35e:	mov    0x28(%rax),%rcx
 102a362:	imul   0x20(%rax),%rcx
 102a367:	lea    (%rax,%rcx,1),%rdi
 102a36b:	add    $0x50,%rdi
 102a36f:	vpcmpeqd %xmm1,%xmm1,%xmm1
 102a373:	vpsubq %xmm1,%xmm0,%xmm0
 102a377:	vmovdqu %xmm0,0x28(%rax)
 102a37c:	vmovq  %xmm0,%rcx
 102a381:	cmp    0x48(%rax),%rcx
 102a385:	jne    102a3ad <slab_take+0x29d>
 102a387:	mov    0x10(%rax),%rcx
 102a38b:	mov    0x18(%rax),%rdx
 102a38f:	test   %rcx,%rcx
 102a392:	je     102a3c9 <slab_take+0x2b9>
 102a394:	mov    %rdx,0x18(%rcx)
 102a398:	lea    0x10(%rax),%rsi
 102a39c:	test   %rdx,%rdx
 102a39f:	je     102a3a5 <slab_take+0x295>
 102a3a1:	mov    %rcx,0x10(%rdx)
 102a3a5:	vpxor  %xmm0,%xmm0,%xmm0
 102a3a9:	vmovdqu %xmm0,(%rsi)
 102a3ad:	mov    0x20(%rax),%rdx
 102a3b1:	xor    %esi,%esi
 102a3b3:	add    $0x8,%rsp
 102a3b7:	pop    %rbx
 102a3b8:	pop    %r12
 102a3ba:	pop    %r13
 102a3bc:	pop    %r14
 102a3be:	pop    %r15
 102a3c0:	pop    %rbp
 102a3c1:	vzeroupper
 102a3c4:	jmp    102ec40 <memset@plt>
 102a3c9:	add    %r15,%r14
 102a3cc:	mov    %rdx,0x8(%r14)
 102a3d0:	lea    0x10(%rax),%rsi
 102a3d4:	test   %rdx,%rdx
 102a3d7:	jne    102a3a1 <slab_take+0x291>
 102a3d9:	jmp    102a3a5 <slab_take+0x295>
 102a3db:	vzeroupper
 102a3de:	call   1023be1 <myl_rc_invariant_failed>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
