
.tmp-rc/profile/gap-allocator-qbe-rc-repeat:     file format elf64-x86-64


Disassembly of section .text:

0000000001018b90 <myl_qbe_rc_frame_cleanup>:
 1018b90:	push   %rbp
 1018b91:	mov    %rsp,%rbp
 1018b94:	push   %r15
 1018b96:	push   %r14
 1018b98:	push   %r12
 1018b9a:	push   %rbx
 1018b9b:	test   %rdi,%rdi
 1018b9e:	je     1018c12 <myl_qbe_rc_frame_cleanup+0x82>
 1018ba0:	mov    %rsi,%rbx
 1018ba3:	test   %rsi,%rsi
 1018ba6:	je     1018c12 <myl_qbe_rc_frame_cleanup+0x82>
 1018ba8:	mov    %rdi,%r14
 1018bab:	cmp    %rbx,0x3d80(%rdi)
 1018bb2:	jne    1018c12 <myl_qbe_rc_frame_cleanup+0x82>
 1018bb4:	lea    0x258(%r14),%rdi
 1018bbb:	mov    0x18(%rbx),%rsi
 1018bbf:	call   1025e10 <myl_rc_scope_unwind>
 1018bc4:	mov    0x10(%rbx),%r15
 1018bc8:	test   %r15,%r15
 1018bcb:	je     1018c09 <myl_qbe_rc_frame_cleanup+0x79>
 1018bcd:	mov    %r15,%r12
 1018bd0:	shl    $0x5,%r12
 1018bd4:	add    $0xffffffffffffffe0,%r12
 1018bd8:	jmp    1018bf4 <myl_qbe_rc_frame_cleanup+0x64>
 1018bda:	nopw   0x0(%rax,%rax,1)
 1018be0:	add    %r12,%rsi
 1018be3:	mov    %r14,%rdi
 1018be6:	call   1018a80 <myl_qbe_rc_slot_drop>
 1018beb:	add    $0xffffffffffffffe0,%r12
 1018bef:	dec    %r15
 1018bf2:	je     1018c09 <myl_qbe_rc_frame_cleanup+0x79>
 1018bf4:	mov    0x8(%rbx),%rsi
 1018bf8:	mov    0x10(%rsi,%r12,1),%rax
 1018bfd:	test   %rax,%rax
 1018c00:	je     1018be0 <myl_qbe_rc_frame_cleanup+0x50>
 1018c02:	cmpl   $0x0,(%rax)
 1018c05:	jne    1018be0 <myl_qbe_rc_frame_cleanup+0x50>
 1018c07:	jmp    1018beb <myl_qbe_rc_frame_cleanup+0x5b>
 1018c09:	pop    %rbx
 1018c0a:	pop    %r12
 1018c0c:	pop    %r14
 1018c0e:	pop    %r15
 1018c10:	pop    %rbp
 1018c11:	ret
 1018c12:	call   1020fce <myl_rc_invariant_failed>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
