
.tmp-rc/profile/gap-allocator-qbe-gc-n12:     file format elf64-x86-64


Disassembly of section .text:

000000000100f960 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531>:
 100f960:	endbr64
 100f964:	push   %rbp
 100f965:	mov    %rsp,%rbp
 100f968:	sub    $0x98,%rsp
 100f96f:	push   %rbx
 100f970:	push   %r12
 100f972:	push   %r13
 100f974:	push   %r14
 100f976:	push   %r15
 100f978:	mov    %rsi,%r13
 100f97b:	mov    0x40(%rdi),%rax
 100f97f:	lea    -0x8(%rbp),%rcx
 100f983:	cmp    %rax,%rcx
 100f986:	jb     100fc3c <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x2dc>
 100f98c:	mov    %rdi,%rbx
 100f98f:	call   1015850 <myl_qbe_heap>
 100f994:	mov    %rbx,%rdi
 100f997:	mov    %rax,%r12
 100f99a:	mov    %rdi,%rbx
 100f99d:	call   1015620 <myl_qbe_root_mark>
 100f9a2:	mov    %r13,%rdx
 100f9a5:	mov    %rbx,%rdi
 100f9a8:	mov    %rax,%r13
 100f9ab:	cmp    $0x0,%rdx
 100f9af:	sete   %al
 100f9b2:	movzbq %al,%rax
 100f9b6:	lea    -0x28(%rbp),%rcx
 100f9ba:	mov    %rcx,%rbx
 100f9bd:	add    $0x8,%rbx
 100f9c1:	cmp    $0x0,%eax
 100f9c4:	jne    100fc12 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x2b2>
 100f9ca:	movabs $0x8000000000000001,%rax
 100f9d4:	cmp    %rax,%rdx
 100f9d7:	jl     100fbfb <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x29b>
 100f9dd:	mov    %rdx,%rsi
 100f9e0:	sub    $0x1,%rsi
 100f9e4:	mov    %rsi,%r15
 100f9e7:	mov    %rdi,%r14
 100f9ea:	call   100f960 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531>
 100f9ef:	mov    %r15,%rsi
 100f9f2:	mov    %r14,%rdi
 100f9f5:	mov    %rax,%rcx
 100f9f8:	mov    %rdx,%rax
 100f9fb:	mov    %rcx,-0x88(%rbp)
 100fa02:	mov    %rax,-0x80(%rbp)
 100fa06:	mov    0x510(%r12),%rcx
 100fa0e:	mov    0x518(%r12),%rdx
 100fa16:	mov    %rcx,%rax
 100fa19:	add    $0x20,%rax
 100fa1d:	cmp    %rdx,%rax
 100fa20:	setbe  %dl
 100fa23:	movzbq %dl,%rdx
 100fa27:	cmp    $0x0,%edx
 100fa2a:	jne    100fa87 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x127>
 100fa2c:	mov    0x10(%r12),%rax
 100fa31:	mov    %rax,-0x68(%rbp)
 100fa35:	lea    -0x88(%rbp),%rax
 100fa3c:	mov    %rax,-0x60(%rbp)
 100fa40:	lea    0x15269(%rip),%rax        # 1024cb0 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 100fa47:	mov    %rax,-0x58(%rbp)
 100fa4b:	lea    -0x68(%rbp),%rax
 100fa4f:	mov    %rax,0x10(%r12)
 100fa54:	mov    $0x1,%edx
 100fa59:	mov    %rsi,%r15
 100fa5c:	lea    0x1508d(%rip),%rsi        # 1024af0 <myl_t_1e414bd82e4b50b54939760a2d591f88da97e2f1c8252dbd7dcbc73438e46afb_body>
 100fa63:	mov    %rdi,%r14
 100fa66:	mov    %r12,%rdi
 100fa69:	call   101a550 <myl_native_heap_alloc_small>
 100fa6e:	mov    %r15,%rsi
 100fa71:	mov    %r14,%rdi
 100fa74:	cmp    $0x0,%eax
 100fa77:	jne    100fa80 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x120>
 100fa79:	call   10155d0 <myl_qbe_fail_allocation>
 100fa7e:	ud2
 100fa80:	mov    %r13,0x10(%r12)
 100fa85:	jmp    100fab8 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x158>
 100fa87:	mov    %rax,0x510(%r12)
 100fa8f:	movq   $0x4,(%rcx)
 100fa96:	lea    0x15053(%rip),%rax        # 1024af0 <myl_t_1e414bd82e4b50b54939760a2d591f88da97e2f1c8252dbd7dcbc73438e46afb_body>
 100fa9d:	mov    %rax,0x8(%rcx)
 100faa1:	mov    %rcx,%rax
 100faa4:	add    $0x10,%rax
 100faa8:	movq   $0x0,0x10(%rcx)
 100fab0:	movq   $0x0,0x18(%rcx)
 100fab8:	mov    -0x88(%rbp),%rcx
 100fabf:	mov    %rcx,(%rax)
 100fac2:	mov    -0x80(%rbp),%rcx
 100fac6:	mov    %rcx,0x8(%rax)
 100faca:	mov    %rax,-0x10(%rbp)
 100face:	mov    0x10(%r12),%rax
 100fad3:	mov    %rax,-0x68(%rbp)
 100fad7:	lea    -0x10(%rbp),%rax
 100fadb:	mov    %rax,-0x60(%rbp)
 100fadf:	lea    0x1515a(%rip),%rax        # 1024c40 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 100fae6:	mov    %rax,-0x58(%rbp)
 100faea:	lea    -0x68(%rbp),%rax
 100faee:	mov    %rax,0x10(%r12)
 100faf3:	mov    %rdi,%r14
 100faf6:	call   100f960 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531>
 100fafb:	mov    %r14,%rdi
 100fafe:	mov    %rax,%rcx
 100fb01:	mov    %rdx,%rax
 100fb04:	mov    %rcx,-0x78(%rbp)
 100fb08:	mov    %rax,-0x70(%rbp)
 100fb0c:	mov    %r13,0x10(%r12)
 100fb11:	mov    0x510(%r12),%rcx
 100fb19:	mov    0x518(%r12),%rdx
 100fb21:	mov    %rcx,%rax
 100fb24:	add    $0x20,%rax
 100fb28:	cmp    %rdx,%rax
 100fb2b:	jbe    100fb9e <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x23e>
 100fb2d:	mov    %r13,-0x68(%rbp)
 100fb31:	lea    -0x10(%rbp),%rax
 100fb35:	mov    %rax,-0x60(%rbp)
 100fb39:	lea    0x15100(%rip),%rax        # 1024c40 <myl_t_a1c2442e4002ee728b98173d58ce387c6ad105836f9a0a17ec38646df2a54d48>
 100fb40:	mov    %rax,-0x58(%rbp)
 100fb44:	lea    -0x68(%rbp),%rax
 100fb48:	mov    %rax,0x10(%r12)
 100fb4d:	lea    -0x68(%rbp),%rax
 100fb51:	mov    %rax,-0x48(%rbp)
 100fb55:	lea    -0x78(%rbp),%rax
 100fb59:	mov    %rax,-0x40(%rbp)
 100fb5d:	lea    0x1514c(%rip),%rax        # 1024cb0 <myl_t_e93372533f323b2f12783aa3a586135cf421486439c2cdcde47411b78f9839ec>
 100fb64:	mov    %rax,-0x38(%rbp)
 100fb68:	lea    -0x48(%rbp),%rax
 100fb6c:	mov    %rax,0x10(%r12)
 100fb71:	mov    $0x1,%edx
 100fb76:	lea    0x14f73(%rip),%rsi        # 1024af0 <myl_t_1e414bd82e4b50b54939760a2d591f88da97e2f1c8252dbd7dcbc73438e46afb_body>
 100fb7d:	mov    %rdi,%r14
 100fb80:	mov    %r12,%rdi
 100fb83:	call   101a550 <myl_native_heap_alloc_small>
 100fb88:	mov    %r14,%rdi
 100fb8b:	cmp    $0x0,%eax
 100fb8e:	jne    100fb97 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x237>
 100fb90:	call   10155d0 <myl_qbe_fail_allocation>
 100fb95:	ud2
 100fb97:	mov    %r13,0x10(%r12)
 100fb9c:	jmp    100fbcf <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x26f>
 100fb9e:	mov    %rax,0x510(%r12)
 100fba6:	movq   $0x4,(%rcx)
 100fbad:	lea    0x14f3c(%rip),%rax        # 1024af0 <myl_t_1e414bd82e4b50b54939760a2d591f88da97e2f1c8252dbd7dcbc73438e46afb_body>
 100fbb4:	mov    %rax,0x8(%rcx)
 100fbb8:	mov    %rcx,%rax
 100fbbb:	add    $0x10,%rax
 100fbbf:	movq   $0x0,0x10(%rcx)
 100fbc7:	movq   $0x0,0x18(%rcx)
 100fbcf:	mov    -0x78(%rbp),%rcx
 100fbd3:	mov    %rcx,(%rax)
 100fbd6:	mov    -0x70(%rbp),%rcx
 100fbda:	mov    %rcx,0x8(%rax)
 100fbde:	mov    %rax,-0x18(%rbp)
 100fbe2:	mov    -0x10(%rbp),%rax
 100fbe6:	mov    %rax,-0x28(%rbp)
 100fbea:	mov    -0x18(%rbp),%rax
 100fbee:	mov    %rax,(%rbx)
 100fbf1:	mov    -0x28(%rbp),%rax
 100fbf5:	mov    -0x20(%rbp),%rdx
 100fbf9:	jmp    100fc31 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x2d1>
 100fbfb:	mov    $0x40,%r8d
 100fc01:	mov    $0x1,%ecx
 100fc06:	mov    $0x1,%esi
 100fc0b:	call   1015710 <myl_qbe_fail_overflow_op>
 100fc10:	ud2
 100fc12:	movq   $0x0,-0x28(%rbp)
 100fc1a:	movq   $0x0,-0x18(%rbp)
 100fc22:	mov    -0x18(%rbp),%rax
 100fc26:	mov    %rax,(%rbx)
 100fc29:	mov    -0x28(%rbp),%rax
 100fc2d:	mov    -0x20(%rbp),%rdx
 100fc31:	pop    %r15
 100fc33:	pop    %r14
 100fc35:	pop    %r13
 100fc37:	pop    %r12
 100fc39:	pop    %rbx
 100fc3a:	leave
 100fc3b:	ret
 100fc3c:	call   1015860 <myl_qbe_fail_frame>
 100fc41:	ud2

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
