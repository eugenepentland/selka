
.tmp-rc/profile/gap-allocator-llvm-rc-repeat:     file format elf64-x86-64


Disassembly of section .text:

00000000010260a0 <myl_rc_drain>:
 10260a0:	push   %rbp
 10260a1:	mov    %rsp,%rbp
 10260a4:	push   %r15
 10260a6:	push   %r14
 10260a8:	push   %r13
 10260aa:	push   %r12
 10260ac:	push   %rbx
 10260ad:	push   %rax
 10260ae:	test   %rdi,%rdi
 10260b1:	je     102633b <myl_rc_drain+0x29b>
 10260b7:	mov    %rdi,%rbx
 10260ba:	mov    0x1608(%rdi),%rax
 10260c1:	test   %rax,%rax
 10260c4:	je     102633b <myl_rc_drain+0x29b>
 10260ca:	cmpl   $0x0,0x68(%rax)
 10260ce:	jne    102632c <myl_rc_drain+0x28c>
 10260d4:	cmpq   $0x0,0x58(%rax)
 10260d9:	jne    102632c <myl_rc_drain+0x28c>
 10260df:	movl   $0x1,0x68(%rax)
 10260e6:	mov    0x60(%rax),%r13
 10260ea:	test   %r13,%r13
 10260ed:	je     1026325 <myl_rc_drain+0x285>
 10260f3:	movabs $0xbf58476d1ce4e5b9,%r12
 10260fd:	nopl   (%rax)
 1026100:	mov    0x0(%r13),%rcx
 1026104:	mov    %rcx,0x60(%rax)
 1026108:	mov    0x18(%r13),%rcx
 102610c:	test   %rcx,%rcx
 102610f:	je     102633b <myl_rc_drain+0x29b>
 1026115:	test   %rax,%rax
 1026118:	je     102633b <myl_rc_drain+0x29b>
 102611e:	mov    0x40(%rax),%rdx
 1026122:	test   %rdx,%rdx
 1026125:	je     102633b <myl_rc_drain+0x29b>
 102612b:	mov    0x30(%rax),%rsi
 102612f:	mov    %rcx,%rdi
 1026132:	shr    $0x3,%rdi
 1026136:	mov    %rcx,%r8
 1026139:	shr    $0x21,%r8
 102613d:	xor    %rdi,%r8
 1026140:	imul   %r12,%r8
 1026144:	mov    %r8,%rdi
 1026147:	shr    $0x1b,%rdi
 102614b:	xor    %r8,%rdi
 102614e:	xor    $0x2,%rdi
 1026152:	dec    %rdx
 1026155:	and    %rdx,%rdi
 1026158:	lea    (%rdi,%rdi,4),%r8
 102615c:	mov    (%rsi,%r8,8),%r8
 1026160:	test   %r8,%r8
 1026163:	je     102633b <myl_rc_drain+0x29b>
 1026169:	lea    0x20(%r13),%r14
 102616d:	jmp    1026187 <myl_rc_drain+0xe7>
 102616f:	nop
 1026170:	inc    %rdi
 1026173:	and    %rdx,%rdi
 1026176:	lea    (%rdi,%rdi,4),%r8
 102617a:	mov    (%rsi,%r8,8),%r8
 102617e:	test   %r8,%r8
 1026181:	je     102633b <myl_rc_drain+0x29b>
 1026187:	cmp    %rcx,%r8
 102618a:	jne    1026170 <myl_rc_drain+0xd0>
 102618c:	lea    (%rdi,%rdi,4),%r8
 1026190:	cmpl   $0x2,0x20(%rsi,%r8,8)
 1026196:	jne    1026170 <myl_rc_drain+0xd0>
 1026198:	lea    (%rsi,%r8,8),%rdx
 102619c:	mov    0x8(%rdx),%rsi
 10261a0:	test   %rsi,%rsi
 10261a3:	je     102633b <myl_rc_drain+0x29b>
 10261a9:	mov    $0x3c,%edx
 10261ae:	bzhi   %rdx,0x10(%r13),%r15
 10261b4:	shr    $0x2,%r15
 10261b8:	cmpl   $0x8,0x78(%rsi)
 10261bc:	ja     10261f0 <myl_rc_drain+0x150>
 10261be:	mov    %rbx,%rdi
 10261c1:	mov    %r14,%rdx
 10261c4:	mov    %r15,%rcx
 10261c7:	call   1025f50 <myl_rc_flat_edges_release>
 10261cc:	mov    0x1608(%rbx),%rax
 10261d3:	cmpq   $0x0,0x58(%rax)
 10261d8:	je     10262f0 <myl_rc_drain+0x250>
 10261de:	jmp    102633b <myl_rc_drain+0x29b>
 10261e3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 10261f0:	mov    0x18(%rsi),%rdx
 10261f4:	test   %rdx,%rdx
 10261f7:	je     102620c <myl_rc_drain+0x16c>
 10261f9:	mov    %rbx,%rdi
 10261fc:	mov    %r14,%rsi
 10261ff:	call   *%rdx
 1026201:	mov    0x18(%r13),%rcx
 1026205:	mov    0x1608(%rbx),%rax
 102620c:	test   %rcx,%rcx
 102620f:	je     102633b <myl_rc_drain+0x29b>
 1026215:	test   %rax,%rax
 1026218:	je     102633b <myl_rc_drain+0x29b>
 102621e:	mov    0x40(%rax),%rdx
 1026222:	test   %rdx,%rdx
 1026225:	je     102633b <myl_rc_drain+0x29b>
 102622b:	mov    0x30(%rax),%rsi
 102622f:	mov    %rcx,%rdi
 1026232:	shr    $0x3,%rdi
 1026236:	mov    %rcx,%r8
 1026239:	shr    $0x21,%r8
 102623d:	xor    %rdi,%r8
 1026240:	imul   %r12,%r8
 1026244:	mov    %r8,%rdi
 1026247:	shr    $0x1b,%rdi
 102624b:	xor    %r8,%rdi
 102624e:	xor    $0x2,%rdi
 1026252:	dec    %rdx
 1026255:	jmp    1026263 <myl_rc_drain+0x1c3>
 1026257:	nopw   0x0(%rax,%rax,1)
 1026260:	inc    %rdi
 1026263:	and    %rdx,%rdi
 1026266:	lea    (%rdi,%rdi,4),%r8
 102626a:	mov    (%rsi,%r8,8),%r8
 102626e:	test   %r8,%r8
 1026271:	je     102633b <myl_rc_drain+0x29b>
 1026277:	cmp    %rcx,%r8
 102627a:	jne    1026260 <myl_rc_drain+0x1c0>
 102627c:	lea    (%rdi,%rdi,4),%r8
 1026280:	cmpl   $0x2,0x20(%rsi,%r8,8)
 1026286:	jne    1026260 <myl_rc_drain+0x1c0>
 1026288:	lea    (%rsi,%r8,8),%rcx
 102628c:	mov    0x8(%rcx),%rcx
 1026290:	test   %rcx,%rcx
 1026293:	je     102633b <myl_rc_drain+0x29b>
 1026299:	cmpq   $0x0,0x58(%rax)
 102629e:	jne    102633b <myl_rc_drain+0x29b>
 10262a4:	mov    0x10(%rcx),%rax
 10262a8:	test   %rax,%rax
 10262ab:	je     10262c8 <myl_rc_drain+0x228>
 10262ad:	mov    %rbx,%rdi
 10262b0:	mov    %r14,%rsi
 10262b3:	mov    %r15,%rdx
 10262b6:	call   *%rax
 10262b8:	mov    0x1608(%rbx),%rax
 10262bf:	cmpq   $0x0,0x58(%rax)
 10262c4:	je     10262f0 <myl_rc_drain+0x250>
 10262c6:	jmp    102633b <myl_rc_drain+0x29b>
 10262c8:	mov    0x8(%rcx),%rsi
 10262cc:	mov    %rbx,%rdi
 10262cf:	mov    %r14,%rdx
 10262d2:	mov    %r15,%rcx
 10262d5:	call   1025bd0 <myl_rc_edges_release>
 10262da:	mov    0x1608(%rbx),%rax
 10262e1:	cmpq   $0x0,0x58(%rax)
 10262e6:	jne    102633b <myl_rc_drain+0x29b>
 10262e8:	nopl   0x0(%rax,%rax,1)
 10262f0:	mov    0x10(%r13),%rcx
 10262f4:	movabs $0x4000000000000002,%rdx
 10262fe:	test   %rdx,%rcx
 1026301:	jne    102633b <myl_rc_drain+0x29b>
 1026303:	test   $0x1,%cl
 1026306:	je     102633b <myl_rc_drain+0x29b>
 1026308:	mov    %rbx,%rdi
 102630b:	mov    %r14,%rsi
 102630e:	call   *0x8(%rax)
 1026311:	mov    0x1608(%rbx),%rax
 1026318:	mov    0x60(%rax),%r13
 102631c:	test   %r13,%r13
 102631f:	jne    1026100 <myl_rc_drain+0x60>
 1026325:	movl   $0x0,0x68(%rax)
 102632c:	add    $0x8,%rsp
 1026330:	pop    %rbx
 1026331:	pop    %r12
 1026333:	pop    %r13
 1026335:	pop    %r14
 1026337:	pop    %r15
 1026339:	pop    %rbp
 102633a:	ret
 102633b:	call   1023be1 <myl_rc_invariant_failed>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
