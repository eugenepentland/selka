
.tmp-rc/profile/gap-allocator-llvm-rc-repeat:     file format elf64-x86-64


Disassembly of section .text:

0000000001025f50 <myl_rc_flat_edges_release>:
 1025f50:	push   %rbp
 1025f51:	mov    %rsp,%rbp
 1025f54:	push   %r15
 1025f56:	push   %r14
 1025f58:	push   %rbx
 1025f59:	push   %rax
 1025f5a:	test   %rdi,%rdi
 1025f5d:	je     1026099 <myl_rc_flat_edges_release+0x149>
 1025f63:	mov    0x1608(%rdi),%rax
 1025f6a:	test   %rax,%rax
 1025f6d:	je     1026099 <myl_rc_flat_edges_release+0x149>
 1025f73:	cmpq   $0x0,0x58(%rax)
 1025f78:	jne    1026099 <myl_rc_flat_edges_release+0x149>
 1025f7e:	mov    0x78(%rsi),%r10d
 1025f82:	cmp    $0x9,%r10d
 1025f86:	jae    1026099 <myl_rc_flat_edges_release+0x149>
 1025f8c:	mov    %rdx,%r8
 1025f8f:	mov    (%rsi),%rax
 1025f92:	mov    (%rax),%r9
 1025f95:	test   %r9,%r9
 1025f98:	je     1025fa6 <myl_rc_flat_edges_release+0x56>
 1025f9a:	mov    %r9,%rax
 1025f9d:	mul    %rcx
 1025fa0:	jo     1026099 <myl_rc_flat_edges_release+0x149>
 1025fa6:	test   %r8,%r8
 1025fa9:	jne    1025fbb <myl_rc_flat_edges_release+0x6b>
 1025fab:	mov    %rcx,%rax
 1025fae:	imul   %r9,%rax
 1025fb2:	test   %rax,%rax
 1025fb5:	jne    1026099 <myl_rc_flat_edges_release+0x149>
 1025fbb:	test   %r10d,%r10d
 1025fbe:	sete   %al
 1025fc1:	test   %rcx,%rcx
 1025fc4:	sete   %dl
 1025fc7:	or     %al,%dl
 1025fc9:	jne    102608e <myl_rc_flat_edges_release+0x13e>
 1025fcf:	mov    $0x1,%r10d
 1025fd5:	xor    %eax,%eax
 1025fd7:	movabs $0x4000000000000002,%rdx
 1025fe1:	jmp    1026005 <myl_rc_flat_edges_release+0xb5>
 1025fe3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1025ff0:	mov    (%rsi),%r9
 1025ff3:	mov    (%r9),%r9
 1025ff6:	add    %r9,%r8
 1025ff9:	inc    %rax
 1025ffc:	cmp    %rcx,%rax
 1025fff:	je     102608e <myl_rc_flat_edges_release+0x13e>
 1026005:	test   %r10d,%r10d
 1026008:	mov    $0x0,%r10d
 102600e:	je     1025ff6 <myl_rc_flat_edges_release+0xa6>
 1026010:	xor    %r9d,%r9d
 1026013:	jmp    102602c <myl_rc_flat_edges_release+0xdc>
 1026015:	data16 cs nopw 0x0(%rax,%rax,1)
 1026020:	inc    %r9
 1026023:	mov    0x78(%rsi),%r10d
 1026027:	cmp    %r10,%r9
 102602a:	jae    1025ff0 <myl_rc_flat_edges_release+0xa0>
 102602c:	mov    0x38(%rsi,%r9,8),%r11
 1026031:	mov    (%r8,%r11,1),%r10
 1026035:	movq   $0x0,(%r8,%r11,1)
 102603d:	test   %r10,%r10
 1026040:	je     1026020 <myl_rc_flat_edges_release+0xd0>
 1026042:	mov    -0x10(%r10),%r11
 1026046:	test   %rdx,%r11
 1026049:	jne    1026020 <myl_rc_flat_edges_release+0xd0>
 102604b:	mov    0x1608(%rdi),%rbx
 1026052:	test   %rbx,%rbx
 1026055:	je     1026099 <myl_rc_flat_edges_release+0x149>
 1026057:	test   $0x1,%r11b
 102605b:	jne    1026099 <myl_rc_flat_edges_release+0x149>
 102605d:	lea    -0x20(%r10),%r14
 1026061:	mov    (%r14),%r15
 1026064:	test   %r15,%r15
 1026067:	je     1026099 <myl_rc_flat_edges_release+0x149>
 1026069:	dec    %r15
 102606c:	mov    %r15,(%r14)
 102606f:	jne    1026020 <myl_rc_flat_edges_release+0xd0>
 1026071:	cmpq   $0x0,-0x18(%r10)
 1026076:	jne    1026020 <myl_rc_flat_edges_release+0xd0>
 1026078:	or     $0x1,%r11
 102607c:	mov    %r11,-0x10(%r10)
 1026080:	mov    0x60(%rbx),%r11
 1026084:	mov    %r11,-0x20(%r10)
 1026088:	mov    %r14,0x60(%rbx)
 102608c:	jmp    1026020 <myl_rc_flat_edges_release+0xd0>
 102608e:	add    $0x8,%rsp
 1026092:	pop    %rbx
 1026093:	pop    %r14
 1026095:	pop    %r15
 1026097:	pop    %rbp
 1026098:	ret
 1026099:	call   1023be1 <myl_rc_invariant_failed>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
