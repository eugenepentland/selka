
.tmp-rc/profile/gap-allocator-llvm-rc-n12:     file format elf64-x86-64


Disassembly of section .text:

0000000001016da0 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531>:
 1016da0:	push   %rbp
 1016da1:	push   %r15
 1016da3:	push   %r14
 1016da5:	push   %r13
 1016da7:	push   %r12
 1016da9:	push   %rbx
 1016daa:	sub    $0x1a8,%rsp
 1016db1:	mov    %rdi,%rbx
 1016db4:	cmp    %rsp,0x40(%rdi)
 1016db8:	ja     1017bfc <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xe5c>
 1016dbe:	mov    %rsi,0x180(%rsp)
 1016dc6:	mov    0x2c8(%rbx),%eax
 1016dcc:	mov    %eax,0xc(%rsp)
 1016dd0:	vxorps %xmm0,%xmm0,%xmm0
 1016dd4:	vmovups %ymm0,0x50(%rsp)
 1016dda:	vmovups %ymm0,0x40(%rsp)
 1016de0:	lea    0x50(%rsp),%rax
 1016de5:	vmovups %ymm0,0xb8(%rsp)
 1016dee:	vmovups %ymm0,0xd8(%rsp)
 1016df7:	vmovups %ymm0,0xf8(%rsp)
 1016e00:	vmovups %ymm0,0x118(%rsp)
 1016e09:	vmovups %ymm0,0x138(%rsp)
 1016e12:	movq   $0x0,0x158(%rsp)
 1016e1e:	movq   $0x1009850,0xa0(%rsp)
 1016e2a:	lea    0x180(%rsp),%rcx
 1016e32:	mov    %rcx,0xa8(%rsp)
 1016e3a:	lea    0x40(%rsp),%rcx
 1016e3f:	mov    %rcx,0xb0(%rsp)
 1016e47:	movq   $0x1009be8,0xc0(%rsp)
 1016e53:	lea    0x20(%rsp),%rcx
 1016e58:	mov    %rcx,0xc8(%rsp)
 1016e60:	lea    0x48(%rsp),%rcx
 1016e65:	mov    %rcx,0xd0(%rsp)
 1016e6d:	movq   $0x1009be8,0xe0(%rsp)
 1016e79:	lea    0x70(%rsp),%rdx
 1016e7e:	mov    %rdx,0xe8(%rsp)
 1016e86:	mov    %rax,0xf0(%rsp)
 1016e8e:	movq   $0x1009be8,0x100(%rsp)
 1016e9a:	lea    0x1a0(%rsp),%rax
 1016ea2:	mov    %rax,0x108(%rsp)
 1016eaa:	lea    0x58(%rsp),%rax
 1016eaf:	mov    %rax,0x110(%rsp)
 1016eb7:	movq   $0x1009be8,0x120(%rsp)
 1016ec3:	lea    0x10(%rsp),%r14
 1016ec8:	mov    %r14,0x128(%rsp)
 1016ed0:	lea    0x60(%rsp),%rax
 1016ed5:	mov    %rax,0x130(%rsp)
 1016edd:	movq   $0x1009be8,0x140(%rsp)
 1016ee9:	lea    0x188(%rsp),%r13
 1016ef1:	mov    %r13,0x148(%rsp)
 1016ef9:	lea    0x68(%rsp),%rbp
 1016efe:	mov    %rbp,0x150(%rsp)
 1016f06:	test   %rbx,%rbx
 1016f09:	je     1017be7 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xe47>
 1016f0f:	mov    0x1860(%rbx),%rax
 1016f16:	test   %rax,%rax
 1016f19:	je     1017be7 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xe47>
 1016f1f:	mov    0x3d80(%rbx),%rcx
 1016f26:	mov    0x70(%rax),%rax
 1016f2a:	mov    %rcx,0x80(%rsp)
 1016f32:	lea    0xa0(%rsp),%rcx
 1016f3a:	mov    %rcx,0x88(%rsp)
 1016f42:	movq   $0x6,0x90(%rsp)
 1016f4e:	mov    %rax,0x98(%rsp)
 1016f56:	lea    0x80(%rsp),%r12
 1016f5e:	mov    %r12,0x3d80(%rbx)
 1016f65:	test   %rsi,%rsi
 1016f68:	je     10170eb <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x34b>
 1016f6e:	mov    %rsi,0x30(%rsp)
 1016f73:	movq   $0x1,0x38(%rsp)
 1016f7c:	mov    %rsi,%rax
 1016f7f:	neg    %rax
 1016f82:	jo     1017c0c <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xe6c>
 1016f88:	mov    %r12,%r15
 1016f8b:	dec    %rsi
 1016f8e:	mov    %rsi,0x30(%rsp)
 1016f93:	mov    %rbx,%rdi
 1016f96:	vzeroupper
 1016f99:	call   1016da0 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531>
 1016f9e:	mov    %rax,0x10(%rsp)
 1016fa3:	mov    %rdx,0x18(%rsp)
 1016fa8:	movq   $0x100a308,0x120(%rsp)
 1016fb4:	movl   $0x2,0x138(%rsp)
 1016fbf:	mov    %rax,0x20(%rsp)
 1016fc4:	mov    %rdx,0x28(%rsp)
 1016fc9:	movq   $0x100a308,0xc0(%rsp)
 1016fd5:	movl   $0x2,0xd8(%rsp)
 1016fe0:	movl   $0x0,0x60(%rsp)
 1016fe8:	movl   $0x1,0x48(%rsp)
 1016ff0:	lea    0x20(%rsp),%rax
 1016ff5:	mov    %rax,0x30(%rsp)
 1016ffa:	cmpq   $0x0,0x1860(%rbx)
 1017002:	je     1017bf4 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xe54>
 1017008:	mov    0x2c8(%rbx),%ecx
 101700e:	mov    $0x10098c0,%esi
 1017013:	mov    $0x1,%edx
 1017018:	lea    0x258(%rbx),%rdi
 101701f:	call   10292a0 <myl_rc_storage_alloc>
 1017024:	test   %rax,%rax
 1017027:	je     1017bf4 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xe54>
 101702d:	mov    %rax,%r12
 1017030:	mov    %rax,0x188(%rsp)
 1017038:	movq   $0x1009930,0x140(%rsp)
 1017044:	mov    %r13,0x148(%rsp)
 101704c:	mov    %rbp,0x150(%rsp)
 1017054:	movl   $0x4,0x158(%rsp)
 101705f:	movl   $0x1,0x68(%rsp)
 1017067:	mov    0x30(%rsp),%rcx
 101706c:	mov    %rcx,%rax
 101706f:	sub    %r14,%rax
 1017072:	mov    %r14,%rdx
 1017075:	sub    %rcx,%rdx
 1017078:	cmp    $0x10,%rax
 101707c:	setb   %al
 101707f:	cmp    $0x10,%rdx
 1017083:	setb   %dl
 1017086:	or     %al,%dl
 1017088:	jne    10170c3 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x323>
 101708a:	mov    (%rcx),%rax
 101708d:	test   %rax,%rax
 1017090:	je     10170a2 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x302>
 1017092:	movabs $0x5000000000000001,%rdx
 101709c:	test   %rdx,-0x10(%rax)
 10170a0:	jne    10170c3 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x323>
 10170a2:	mov    0x8(%rcx),%rax
 10170a6:	test   %rax,%rax
 10170a9:	je     101726d <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x4cd>
 10170af:	movabs $0x5000000000000001,%rdx
 10170b9:	test   %rdx,-0x10(%rax)
 10170bd:	je     101726d <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x4cd>
 10170c3:	lea    0x10(%rsp),%rdx
 10170c8:	mov    $0x100a308,%esi
 10170cd:	lea    0x258(%rbx),%rdi
 10170d4:	mov    0xc(%rsp),%r8d
 10170d9:	call   102aa00 <myl_rc_native_take>
 10170de:	test   %eax,%eax
 10170e0:	jne    101727f <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x4df>
 10170e6:	jmp    1017352 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x5b2>
 10170eb:	movq   $0x1009fd8,0xe0(%rsp)
 10170f7:	movl   $0x2,0xf8(%rsp)
 1017102:	mov    %rdx,0x38(%rsp)
 1017107:	movq   $0x100a308,0x140(%rsp)
 1017113:	movl   $0x2,0x158(%rsp)
 101711e:	lea    0x190(%rsp),%rax
 1017126:	mov    %rax,0x148(%rsp)
 101712e:	mov    %rbp,0x150(%rsp)
 1017136:	vxorps %xmm0,%xmm0,%xmm0
 101713a:	vmovups %xmm0,0x190(%rsp)
 1017143:	movq   $0x0,0x10(%rsp)
 101714c:	movq   $0x0,0x70(%rsp)
 1017155:	movl   $0x0,0x50(%rsp)
 101715d:	movq   $0x1009fd8,0x120(%rsp)
 1017169:	movl   $0x2,0x138(%rsp)
 1017174:	movl   $0x0,0x60(%rsp)
 101717c:	vmovups 0x190(%rsp),%xmm0
 1017185:	vmovaps %xmm0,0x20(%rsp)
 101718b:	movq   $0x100a308,0xc0(%rsp)
 1017197:	movl   $0x2,0xd8(%rsp)
 10171a2:	movl   $0x1,0x48(%rsp)
 10171aa:	lea    0x20(%rsp),%rcx
 10171af:	mov    %rcx,0x30(%rsp)
 10171b4:	movl   $0x0,0x68(%rsp)
 10171bc:	mov    %rcx,%rax
 10171bf:	sub    %r14,%rax
 10171c2:	sub    %rcx,%r14
 10171c5:	cmp    $0x10,%rax
 10171c9:	setb   %al
 10171cc:	cmp    $0x10,%r14
 10171d0:	setb   %cl
 10171d3:	or     %al,%cl
 10171d5:	jne    1017209 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x469>
 10171d7:	movabs $0x5000000000000001,%rax
 10171e1:	mov    0x20(%rsp),%rcx
 10171e6:	test   %rcx,%rcx
 10171e9:	je     10171f1 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x451>
 10171eb:	test   %rax,-0x10(%rcx)
 10171ef:	jne    1017209 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x469>
 10171f1:	mov    0x28(%rsp),%rcx
 10171f6:	test   %rcx,%rcx
 10171f9:	je     1017566 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x7c6>
 10171ff:	test   %rax,-0x10(%rcx)
 1017203:	je     1017566 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x7c6>
 1017209:	lea    0x10(%rsp),%rdx
 101720e:	lea    0x20(%rsp),%rcx
 1017213:	mov    $0x100a308,%esi
 1017218:	lea    0x258(%rbx),%rdi
 101721f:	mov    0xc(%rsp),%r8d
 1017224:	vzeroupper
 1017227:	call   102aa00 <myl_rc_native_take>
 101722c:	test   %eax,%eax
 101722e:	je     10179cc <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xc2c>
 1017234:	cmp    %r12,0x3d80(%rbx)
 101723b:	movl   $0x0,0x48(%rsp)
 1017243:	movq   $0x100a308,0x120(%rsp)
 101724f:	movl   $0x2,0x138(%rsp)
 101725a:	movl   $0x0,0x60(%rsp)
 1017262:	je     10175a6 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x806>
 1017268:	jmp    1017be7 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xe47>
 101726d:	vmovups (%rcx),%xmm0
 1017271:	vmovaps %xmm0,0x10(%rsp)
 1017277:	vxorps %xmm0,%xmm0,%xmm0
 101727b:	vmovups %xmm0,(%rcx)
 101727f:	movq   $0x100a308,0x120(%rsp)
 101728b:	movl   $0x2,0x138(%rsp)
 1017296:	vmovaps 0x10(%rsp),%xmm0
 101729c:	vmovups %xmm0,(%r12)
 10172a2:	movl   $0x0,0x60(%rsp)
 10172aa:	mov    %r12,0x20(%rsp)
 10172af:	movq   $0x1009930,0xc0(%rsp)
 10172bb:	movl   $0x2,0xd8(%rsp)
 10172c6:	movl   $0x1,0x48(%rsp)
 10172ce:	mov    %r12,0x30(%rsp)
 10172d3:	movq   $0x0,0x178(%rsp)
 10172df:	movq   $0x1009fd8,0x140(%rsp)
 10172eb:	movl   $0x2,0x158(%rsp)
 10172f6:	lea    0x178(%rsp),%rax
 10172fe:	mov    %rax,0x148(%rsp)
 1017306:	mov    %rbp,0x150(%rsp)
 101730e:	movl   $0x1,0x68(%rsp)
 1017316:	movabs $0x5000000000000001,%rax
 1017320:	test   %rax,-0x10(%r12)
 1017325:	je     101737c <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x5dc>
 1017327:	lea    0x10(%rsp),%rdx
 101732c:	lea    0x30(%rsp),%rcx
 1017331:	mov    $0x1009930,%esi
 1017336:	lea    0x258(%rbx),%rdi
 101733d:	mov    0xc(%rsp),%r8d
 1017342:	call   102aa00 <myl_rc_native_take>
 1017347:	test   %eax,%eax
 1017349:	je     1017352 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x5b2>
 101734b:	mov    0x10(%rsp),%r12
 1017350:	jmp    1017381 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x5e1>
 1017352:	mov    0x1860(%rbx),%rcx
 1017359:	test   %rcx,%rcx
 101735c:	je     1017be7 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xe47>
 1017362:	mov    0x78(%rcx),%eax
 1017365:	movl   $0x0,0x78(%rcx)
 101736c:	test   %eax,%eax
 101736e:	mov    %r15,%r12
 1017371:	jne    10179ea <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xc4a>
 1017377:	jmp    1017a1f <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xc7f>
 101737c:	mov    %r12,0x10(%rsp)
 1017381:	movq   $0x1009930,0x120(%rsp)
 101738d:	movl   $0x2,0x138(%rsp)
 1017398:	mov    %r12,0x178(%rsp)
 10173a0:	movl   $0x0,0x60(%rsp)
 10173a8:	mov    %r12,0x20(%rsp)
 10173ad:	movq   $0x1009fd8,0xc0(%rsp)
 10173b9:	movl   $0x2,0xd8(%rsp)
 10173c4:	movl   $0x1,0x48(%rsp)
 10173cc:	lea    0x20(%rsp),%rax
 10173d1:	mov    %rax,0x30(%rsp)
 10173d6:	movl   $0x0,0x68(%rsp)
 10173de:	mov    0x180(%rsp),%rsi
 10173e6:	mov    %rsi,0x38(%rsp)
 10173eb:	movabs $0x8000000000000000,%rdx
 10173f5:	cmp    %rdx,%rsi
 10173f8:	je     1017c2b <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xe8b>
 10173fe:	dec    %rsi
 1017401:	mov    %rsi,0x38(%rsp)
 1017406:	mov    %rbx,%rdi
 1017409:	call   1016da0 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531>
 101740e:	mov    %rax,0x10(%rsp)
 1017413:	mov    %rdx,0x18(%rsp)
 1017418:	movq   $0x100a308,0x120(%rsp)
 1017424:	movl   $0x2,0x138(%rsp)
 101742f:	mov    %rax,0x70(%rsp)
 1017434:	mov    %rdx,0x78(%rsp)
 1017439:	movq   $0x100a308,0xe0(%rsp)
 1017445:	movl   $0x2,0xf8(%rsp)
 1017450:	movl   $0x0,0x60(%rsp)
 1017458:	movl   $0x1,0x50(%rsp)
 1017460:	lea    0x70(%rsp),%rax
 1017465:	mov    %rax,0x38(%rsp)
 101746a:	cmpq   $0x0,0x1860(%rbx)
 1017472:	je     1017c04 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xe64>
 1017478:	mov    %r15,%r12
 101747b:	mov    0x2c8(%rbx),%ecx
 1017481:	mov    $0x10098c0,%esi
 1017486:	mov    $0x1,%edx
 101748b:	lea    0x258(%rbx),%rdi
 1017492:	call   10292a0 <myl_rc_storage_alloc>
 1017497:	test   %rax,%rax
 101749a:	je     1017c04 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xe64>
 10174a0:	mov    %rax,%r15
 10174a3:	mov    %rax,0x188(%rsp)
 10174ab:	movq   $0x1009930,0x140(%rsp)
 10174b7:	mov    %r13,0x148(%rsp)
 10174bf:	mov    %rbp,0x150(%rsp)
 10174c7:	movl   $0x4,0x158(%rsp)
 10174d2:	movl   $0x1,0x68(%rsp)
 10174da:	lea    0x70(%rsp),%rdx
 10174df:	mov    %rdx,%rax
 10174e2:	sub    %r14,%rax
 10174e5:	mov    %r14,%rcx
 10174e8:	sub    %rdx,%rcx
 10174eb:	cmp    $0x10,%rax
 10174ef:	setb   %al
 10174f2:	cmp    $0x10,%rcx
 10174f6:	setb   %cl
 10174f9:	or     %al,%cl
 10174fb:	jne    1017539 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x799>
 10174fd:	mov    0x70(%rsp),%rax
 1017502:	test   %rax,%rax
 1017505:	je     1017517 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x777>
 1017507:	movabs $0x5000000000000001,%rcx
 1017511:	test   %rcx,-0x10(%rax)
 1017515:	jne    1017539 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x799>
 1017517:	mov    0x78(%rsp),%rax
 101751c:	test   %rax,%rax
 101751f:	je     1017611 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x871>
 1017525:	movabs $0x5000000000000001,%rcx
 101752f:	test   %rcx,-0x10(%rax)
 1017533:	je     1017611 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x871>
 1017539:	lea    0x10(%rsp),%rdx
 101753e:	lea    0x70(%rsp),%rcx
 1017543:	mov    $0x100a308,%esi
 1017548:	lea    0x258(%rbx),%rdi
 101754f:	mov    0xc(%rsp),%r8d
 1017554:	call   102aa00 <myl_rc_native_take>
 1017559:	test   %eax,%eax
 101755b:	jne    1017626 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x886>
 1017561:	jmp    10179cc <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xc2c>
 1017566:	vmovups 0x190(%rsp),%xmm0
 101756f:	vmovaps %xmm0,0x10(%rsp)
 1017575:	vxorps %xmm0,%xmm0,%xmm0
 1017579:	vmovaps %xmm0,0x20(%rsp)
 101757f:	movl   $0x0,0x48(%rsp)
 1017587:	movq   $0x100a308,0x120(%rsp)
 1017593:	movl   $0x2,0x138(%rsp)
 101759e:	movl   $0x0,0x60(%rsp)
 10175a6:	mov    0x98(%rsp),%rsi
 10175ae:	lea    0x258(%rbx),%rdi
 10175b5:	vzeroupper
 10175b8:	call   1027420 <myl_rc_scope_unwind>
 10175bd:	mov    0x90(%rsp),%r14
 10175c5:	test   %r14,%r14
 10175c8:	je     1017b8d <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xded>
 10175ce:	mov    %r14,%r15
 10175d1:	shl    $0x5,%r15
 10175d5:	add    $0xffffffffffffffe0,%r15
 10175d9:	jmp    10175f8 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x858>
 10175db:	nopl   0x0(%rax,%rax,1)
 10175e0:	add    %r15,%rsi
 10175e3:	mov    %rbx,%rdi
 10175e6:	call   101cdd0 <myl_qbe_rc_slot_drop>
 10175eb:	add    $0xffffffffffffffe0,%r15
 10175ef:	dec    %r14
 10175f2:	je     1017b8d <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xded>
 10175f8:	mov    0x88(%rsp),%rsi
 1017600:	mov    0x10(%rsi,%r15,1),%rax
 1017605:	test   %rax,%rax
 1017608:	je     10175e0 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x840>
 101760a:	cmpl   $0x0,(%rax)
 101760d:	jne    10175e0 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x840>
 101760f:	jmp    10175eb <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x84b>
 1017611:	vmovups 0x70(%rsp),%xmm0
 1017617:	vmovaps %xmm0,0x10(%rsp)
 101761d:	movq   $0x0,0x78(%rsp)
 1017626:	movq   $0x100a308,0x120(%rsp)
 1017632:	movl   $0x2,0x138(%rsp)
 101763d:	vmovaps 0x10(%rsp),%xmm0
 1017643:	vmovups %xmm0,(%r15)
 1017648:	movl   $0x0,0x60(%rsp)
 1017650:	mov    %r15,0x70(%rsp)
 1017655:	movq   $0x1009930,0xe0(%rsp)
 1017661:	movl   $0x2,0xf8(%rsp)
 101766c:	movl   $0x1,0x50(%rsp)
 1017674:	mov    %r15,0x38(%rsp)
 1017679:	movq   $0x0,0x170(%rsp)
 1017685:	movq   $0x1009fd8,0x140(%rsp)
 1017691:	movl   $0x2,0x158(%rsp)
 101769c:	lea    0x170(%rsp),%rax
 10176a4:	mov    %rax,0x148(%rsp)
 10176ac:	mov    %rbp,0x150(%rsp)
 10176b4:	movl   $0x1,0x68(%rsp)
 10176bc:	movabs $0x5000000000000001,%rax
 10176c6:	test   %rax,-0x10(%r15)
 10176ca:	je     10176fb <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x95b>
 10176cc:	lea    0x10(%rsp),%rdx
 10176d1:	lea    0x38(%rsp),%rcx
 10176d6:	mov    $0x1009930,%esi
 10176db:	lea    0x258(%rbx),%rdi
 10176e2:	mov    0xc(%rsp),%r8d
 10176e7:	call   102aa00 <myl_rc_native_take>
 10176ec:	test   %eax,%eax
 10176ee:	je     10179cc <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xc2c>
 10176f4:	mov    0x10(%rsp),%r15
 10176f9:	jmp    1017700 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0x960>
 10176fb:	mov    %r15,0x10(%rsp)
 1017700:	movq   $0x1009930,0x120(%rsp)
 101770c:	movl   $0x2,0x138(%rsp)
 1017717:	mov    %r15,0x170(%rsp)
 101771f:	movl   $0x0,0x60(%rsp)
 1017727:	mov    %r15,0x70(%rsp)
 101772c:	movq   $0x1009fd8,0xe0(%rsp)
 1017738:	movl   $0x2,0xf8(%rsp)
 1017743:	movl   $0x1,0x50(%rsp)
 101774b:	lea    0x70(%rsp),%rax
 1017750:	mov    %rax,0x38(%rsp)
 1017755:	vxorps %xmm0,%xmm0,%xmm0
 1017759:	vmovaps %xmm0,0x160(%rsp)
 1017762:	movq   $0x100a308,0x140(%rsp)
 101776e:	movl   $0x2,0x158(%rsp)
 1017779:	lea    0x160(%rsp),%rax
 1017781:	mov    %rax,0x148(%rsp)
 1017789:	mov    %rbp,0x150(%rsp)
 1017791:	movl   $0x1,0x68(%rsp)
 1017799:	mov    0x30(%rsp),%rcx
 101779e:	cmpl   $0x0,0x48(%rsp)
 10177a3:	je     10177ff <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xa5f>
 10177a5:	mov    %rcx,%rax
 10177a8:	sub    %r14,%rax
 10177ab:	mov    %r14,%rdx
 10177ae:	sub    %rcx,%rdx
 10177b1:	cmp    $0x8,%rax
 10177b5:	setb   %al
 10177b8:	cmp    $0x8,%rdx
 10177bc:	setb   %dl
 10177bf:	or     %al,%dl
 10177c1:	jne    10177db <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xa3b>
 10177c3:	mov    (%rcx),%rax
 10177c6:	test   %rax,%rax
 10177c9:	je     1017823 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xa83>
 10177cb:	movabs $0x5000000000000001,%rdx
 10177d5:	test   %rdx,-0x10(%rax)
 10177d9:	je     1017823 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xa83>
 10177db:	lea    0x10(%rsp),%rdx
 10177e0:	mov    $0x1009fd8,%esi
 10177e5:	lea    0x258(%rbx),%rdi
 10177ec:	mov    0xc(%rsp),%r8d
 10177f1:	call   102aa00 <myl_rc_native_take>
 10177f6:	test   %eax,%eax
 10177f8:	jne    101782f <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xa8f>
 10177fa:	jmp    10179cc <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xc2c>
 10177ff:	lea    0x10(%rsp),%rdx
 1017804:	mov    $0x1009fd8,%esi
 1017809:	lea    0x258(%rbx),%rdi
 1017810:	mov    0xc(%rsp),%r8d
 1017815:	call   102a490 <myl_rc_native_copy>
 101781a:	test   %eax,%eax
 101781c:	jne    1017837 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xa97>
 101781e:	jmp    10179cc <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xc2c>
 1017823:	mov    %rax,0x10(%rsp)
 1017828:	movq   $0x0,(%rcx)
 101782f:	movl   $0x0,0x48(%rsp)
 1017837:	movq   $0x1009fd8,0x120(%rsp)
 1017843:	movl   $0x2,0x138(%rsp)
 101784e:	mov    0x10(%rsp),%rax
 1017853:	mov    %rax,0x160(%rsp)
 101785b:	movl   $0x0,0x60(%rsp)
 1017863:	mov    0x38(%rsp),%rcx
 1017868:	mov    %rcx,%rax
 101786b:	sub    %r14,%rax
 101786e:	mov    %r14,%rdx
 1017871:	sub    %rcx,%rdx
 1017874:	cmp    $0x8,%rax
 1017878:	setb   %al
 101787b:	cmp    $0x8,%rdx
 101787f:	setb   %dl
 1017882:	or     %al,%dl
 1017884:	jne    101789e <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xafe>
 1017886:	mov    (%rcx),%rax
 1017889:	test   %rax,%rax
 101788c:	je     10178c2 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xb22>
 101788e:	movabs $0x5000000000000001,%rdx
 1017898:	test   %rdx,-0x10(%rax)
 101789c:	je     10178c2 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xb22>
 101789e:	lea    0x10(%rsp),%rdx
 10178a3:	mov    $0x1009fd8,%esi
 10178a8:	lea    0x258(%rbx),%rdi
 10178af:	mov    0xc(%rsp),%r8d
 10178b4:	call   102aa00 <myl_rc_native_take>
 10178b9:	test   %eax,%eax
 10178bb:	jne    10178ce <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xb2e>
 10178bd:	jmp    10179cc <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xc2c>
 10178c2:	mov    %rax,0x10(%rsp)
 10178c7:	movq   $0x0,(%rcx)
 10178ce:	movl   $0x0,0x50(%rsp)
 10178d6:	movq   $0x1009fd8,0x120(%rsp)
 10178e2:	movl   $0x2,0x138(%rsp)
 10178ed:	mov    0x10(%rsp),%rax
 10178f2:	mov    %rax,0x168(%rsp)
 10178fa:	movl   $0x0,0x60(%rsp)
 1017902:	mov    0x160(%rsp),%rax
 101790a:	mov    %rax,0x20(%rsp)
 101790f:	mov    0x168(%rsp),%rax
 1017917:	mov    %rax,0x28(%rsp)
 101791c:	movq   $0x100a308,0xc0(%rsp)
 1017928:	movl   $0x2,0xd8(%rsp)
 1017933:	movl   $0x1,0x48(%rsp)
 101793b:	lea    0x20(%rsp),%rcx
 1017940:	mov    %rcx,0x30(%rsp)
 1017945:	movl   $0x0,0x68(%rsp)
 101794d:	mov    %rcx,%rax
 1017950:	sub    %r14,%rax
 1017953:	sub    %rcx,%r14
 1017956:	cmp    $0x10,%rax
 101795a:	setb   %al
 101795d:	cmp    $0x10,%r14
 1017961:	setb   %cl
 1017964:	or     %al,%cl
 1017966:	jne    10179a4 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xc04>
 1017968:	mov    0x20(%rsp),%rax
 101796d:	test   %rax,%rax
 1017970:	je     1017982 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xbe2>
 1017972:	movabs $0x5000000000000001,%rcx
 101797c:	test   %rcx,-0x10(%rax)
 1017980:	jne    10179a4 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xc04>
 1017982:	mov    0x28(%rsp),%rax
 1017987:	test   %rax,%rax
 101798a:	je     1017ae1 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xd41>
 1017990:	movabs $0x5000000000000001,%rcx
 101799a:	test   %rcx,-0x10(%rax)
 101799e:	je     1017ae1 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xd41>
 10179a4:	lea    0x10(%rsp),%rdx
 10179a9:	lea    0x20(%rsp),%rcx
 10179ae:	mov    $0x100a308,%esi
 10179b3:	lea    0x258(%rbx),%rdi
 10179ba:	mov    0xc(%rsp),%r8d
 10179bf:	call   102aa00 <myl_rc_native_take>
 10179c4:	test   %eax,%eax
 10179c6:	jne    1017afa <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xd5a>
 10179cc:	mov    0x1860(%rbx),%rcx
 10179d3:	test   %rcx,%rcx
 10179d6:	je     1017be7 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xe47>
 10179dc:	mov    0x78(%rcx),%eax
 10179df:	movl   $0x0,0x78(%rcx)
 10179e6:	test   %eax,%eax
 10179e8:	je     1017a1f <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xc7f>
 10179ea:	cmp    $0x1,%eax
 10179ed:	jne    1017a04 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xc64>
 10179ef:	mov    $0x100745f,%esi
 10179f4:	cmpl   $0x0,0x2c4(%rbx)
 10179fb:	jne    1017a17 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xc77>
 10179fd:	mov    $0x1,%eax
 1017a02:	jmp    1017a0d <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xc6d>
 1017a04:	cmp    $0x4,%eax
 1017a07:	jae    1017bef <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xe4f>
 1017a0d:	mov    %eax,%eax
 1017a0f:	mov    0x100d2d0(,%rax,8),%rsi
 1017a17:	mov    %rbx,%rdi
 1017a1a:	call   101d7e0 <fail>
 1017a1f:	cmp    %r12,0x3d80(%rbx)
 1017a26:	jne    1017be7 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xe47>
 1017a2c:	mov    0x98(%rsp),%rsi
 1017a34:	lea    0x258(%rbx),%rdi
 1017a3b:	call   1027420 <myl_rc_scope_unwind>
 1017a40:	mov    0x90(%rsp),%r14
 1017a48:	test   %r14,%r14
 1017a4b:	je     1017a8d <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xced>
 1017a4d:	mov    %r14,%r15
 1017a50:	shl    $0x5,%r15
 1017a54:	add    $0xffffffffffffffe0,%r15
 1017a58:	jmp    1017a74 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xcd4>
 1017a5a:	nopw   0x0(%rax,%rax,1)
 1017a60:	add    %r15,%rsi
 1017a63:	mov    %rbx,%rdi
 1017a66:	call   101cdd0 <myl_qbe_rc_slot_drop>
 1017a6b:	add    $0xffffffffffffffe0,%r15
 1017a6f:	dec    %r14
 1017a72:	je     1017a8d <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xced>
 1017a74:	mov    0x88(%rsp),%rsi
 1017a7c:	mov    0x10(%rsi,%r15,1),%rax
 1017a81:	test   %rax,%rax
 1017a84:	je     1017a60 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xcc0>
 1017a86:	cmpl   $0x0,(%rax)
 1017a89:	jne    1017a60 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xcc0>
 1017a8b:	jmp    1017a6b <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xccb>
 1017a8d:	cmp    %r12,0x3d80(%rbx)
 1017a94:	jne    1017be7 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xe47>
 1017a9a:	mov    0x1860(%rbx),%rax
 1017aa1:	test   %rax,%rax
 1017aa4:	je     1017ab9 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xd19>
 1017aa6:	mov    0x70(%rax),%rax
 1017aaa:	cmp    0x98(%rsp),%rax
 1017ab2:	je     1017ac9 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xd29>
 1017ab4:	jmp    1017be7 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xe47>
 1017ab9:	xor    %eax,%eax
 1017abb:	cmp    0x98(%rsp),%rax
 1017ac3:	jne    1017be7 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xe47>
 1017ac9:	mov    0x80(%rsp),%rax
 1017ad1:	mov    %rax,0x3d80(%rbx)
 1017ad8:	xor    %eax,%eax
 1017ada:	xor    %edx,%edx
 1017adc:	jmp    1017bc9 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xe29>
 1017ae1:	vmovaps 0x160(%rsp),%xmm0
 1017aea:	vmovaps %xmm0,0x10(%rsp)
 1017af0:	vxorps %xmm0,%xmm0,%xmm0
 1017af4:	vmovaps %xmm0,0x20(%rsp)
 1017afa:	movl   $0x0,0x48(%rsp)
 1017b02:	movq   $0x100a308,0x120(%rsp)
 1017b0e:	movl   $0x2,0x138(%rsp)
 1017b19:	movl   $0x0,0x60(%rsp)
 1017b21:	cmp    %r12,0x3d80(%rbx)
 1017b28:	jne    1017be7 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xe47>
 1017b2e:	mov    0x98(%rsp),%rsi
 1017b36:	lea    0x258(%rbx),%rdi
 1017b3d:	call   1027420 <myl_rc_scope_unwind>
 1017b42:	mov    0x90(%rsp),%r14
 1017b4a:	test   %r14,%r14
 1017b4d:	je     1017b8d <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xded>
 1017b4f:	mov    %r14,%r15
 1017b52:	shl    $0x5,%r15
 1017b56:	add    $0xffffffffffffffe0,%r15
 1017b5a:	jmp    1017b74 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xdd4>
 1017b5c:	nopl   0x0(%rax)
 1017b60:	add    %r15,%rsi
 1017b63:	mov    %rbx,%rdi
 1017b66:	call   101cdd0 <myl_qbe_rc_slot_drop>
 1017b6b:	add    $0xffffffffffffffe0,%r15
 1017b6f:	dec    %r14
 1017b72:	je     1017b8d <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xded>
 1017b74:	mov    0x88(%rsp),%rsi
 1017b7c:	mov    0x10(%rsi,%r15,1),%rax
 1017b81:	test   %rax,%rax
 1017b84:	je     1017b60 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xdc0>
 1017b86:	cmpl   $0x0,(%rax)
 1017b89:	jne    1017b60 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xdc0>
 1017b8b:	jmp    1017b6b <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xdcb>
 1017b8d:	cmp    %r12,0x3d80(%rbx)
 1017b94:	jne    1017be7 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xe47>
 1017b96:	mov    0x1860(%rbx),%rax
 1017b9d:	test   %rax,%rax
 1017ba0:	je     1017bdb <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xe3b>
 1017ba2:	mov    0x70(%rax),%rax
 1017ba6:	cmp    0x98(%rsp),%rax
 1017bae:	jne    1017be7 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xe47>
 1017bb0:	mov    0x80(%rsp),%rax
 1017bb8:	mov    %rax,0x3d80(%rbx)
 1017bbf:	mov    0x10(%rsp),%rax
 1017bc4:	mov    0x18(%rsp),%rdx
 1017bc9:	add    $0x1a8,%rsp
 1017bd0:	pop    %rbx
 1017bd1:	pop    %r12
 1017bd3:	pop    %r13
 1017bd5:	pop    %r14
 1017bd7:	pop    %r15
 1017bd9:	pop    %rbp
 1017bda:	ret
 1017bdb:	xor    %eax,%eax
 1017bdd:	cmp    0x98(%rsp),%rax
 1017be5:	je     1017bb0 <myl_f_d05aa2a15fb3c40efeeb03bec445393f00074484cf01c8fb2da90ca6695a5531+0xe10>
 1017be7:	vzeroupper
 1017bea:	call   10230e1 <myl_rc_invariant_failed>
 1017bef:	call   102e220 <abort@plt>
 1017bf4:	mov    %rbx,%rdi
 1017bf7:	call   101de90 <myl_qbe_fail_allocation>
 1017bfc:	mov    %rbx,%rdi
 1017bff:	call   101df90 <myl_qbe_fail_frame>
 1017c04:	mov    %rbx,%rdi
 1017c07:	call   101de90 <myl_qbe_fail_allocation>
 1017c0c:	mov    $0x1,%esi
 1017c11:	mov    $0x1,%ecx
 1017c16:	mov    %rbx,%rdi
 1017c19:	movabs $0x8000000000000000,%rdx
 1017c23:	vzeroupper
 1017c26:	call   101df20 <myl_qbe_fail_overflow_op>
 1017c2b:	mov    $0x1,%esi
 1017c30:	mov    $0x1,%ecx
 1017c35:	mov    %rbx,%rdi
 1017c38:	call   101df20 <myl_qbe_fail_overflow_op>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
