const std = @import("std");
const count = @import("count_runtime.zig");
pub fn main(init: std.process.Init) !void {
    const text = try count.source(init.arena.allocator(), @embedFile("base.c"));
    try std.Io.File.stdout().writeStreamingAll(init.io, "#define MYL_ZERO_RC 1\n");
    try std.Io.File.stdout().writeStreamingAll(init.io, text);
}
