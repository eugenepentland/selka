import pathlib,subprocess,json,os,hashlib
root=pathlib.Path.cwd();out=root/'.tmp/memory-closeout/A09/trap-site'; compiler=root/'.zig-cache/o/01fee97bc983b9ba0bcb9b88e1105997/mylang'
env=dict(os.environ,MYLANG_COMPONENT_DIR='/home/epentland/ai/canopy/mylang-memory-20261012/.tmp/memory-closeout/coordinator/support5-install/libexec/mylang/components')
rows=[]
for name,src,args in [('repro',out/'repro.my',['x','y']),('full',root/'test/core/ce_elements.my',['x','y','z','w'])]:
 for mode,flags in [('debug',['--unoptimized']),('release',['--release'])]:
  dest=out/f'{name}-{mode}';llvm=dest.with_suffix('.ll')
  cmd=[str(compiler),'build',str(src),'--experimental-zero-rc',*flags,'--emit-llvm',str(llvm),'-o',str(dest),'--cache-dir',str(out/'cache')]
  p=subprocess.run(cmd,env=env,capture_output=True,text=True); row={'source':str(src),'mode':mode,'command':cmd,'build_status':p.returncode,'build_stdout':p.stdout,'build_stderr':p.stderr}
  if not p.returncode:
   q=subprocess.run([str(dest),*args],env=env,capture_output=True,text=True); row.update(status=q.returncode,stdout=q.stdout,stderr=q.stderr,sha256=hashlib.sha256(dest.read_bytes()).hexdigest())
  rows.append(row);(out/'results.json').write_text(json.dumps({'compiler':str(compiler),'compiler_sha256':hashlib.sha256(compiler.read_bytes()).hexdigest(),'cases':rows},indent=2)+'\n')
  print(name,mode,row.get('status',p.returncode),row.get('stderr',p.stderr),flush=True)
