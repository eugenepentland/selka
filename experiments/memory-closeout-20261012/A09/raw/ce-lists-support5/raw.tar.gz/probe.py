from pathlib import Path
import os,subprocess,json,hashlib,time
p=Path(__file__).resolve().parent
c=Path('/home/epentland/ai/canopy/mylang-memory-20261012/.tmp/memory-closeout/coordinator/support5-install/bin/mylang')
assert hashlib.sha256(c.read_bytes()).hexdigest()=='8b1898be7ad2f95cf53bf709f9d468b3bcfbabcaab2aaa7b5aa48d0163b2a789'
r={'compiler':str(c),'source_revision':'a1f19edf255c8c0886731d8d7cce450d5f657720','cases':{}}
for s in list(p.glob('*.my'))+[Path('test/core/ce_cow.my').resolve()]:
 row={'source':str(s),'sha256':hashlib.sha256(s.read_bytes()).hexdigest()}; r['cases'][s.stem]=row
 for label,flags in [('raw',[]),('facts',['--facts'])]:
  cmd=[str(c),'dump-ir',str(s),'--experimental-zero-rc',*flags]; t=time.time(); b=subprocess.run(cmd,capture_output=True,text=True,timeout=60)
  (p/(s.stem+'.'+label+'.ir')).write_text(b.stdout);(p/(s.stem+'.'+label+'.stderr')).write_text(b.stderr)
  row[label]={'argv':cmd,'status':b.returncode,'elapsed_correctness_only':time.time()-t}
 (p/'results.json').write_text(json.dumps(r,indent=2)+'\n')
 print(s.stem,row,flush=True)
