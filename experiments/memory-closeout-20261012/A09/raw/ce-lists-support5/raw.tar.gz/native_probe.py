from pathlib import Path
import subprocess,json,os,hashlib,sys
p=Path(__file__).resolve().parent
mode=sys.argv[1]; group=sys.argv[2]
o=p/(group+'-'+mode);o.mkdir()
c=Path('/home/epentland/ai/canopy/mylang-memory-20261012/.tmp/memory-closeout/coordinator/support5-install/bin/mylang')
sha=hashlib.sha256(c.read_bytes()).hexdigest();assert sha=='8b1898be7ad2f95cf53bf709f9d468b3bcfbabcaab2aaa7b5aa48d0163b2a789'
inline={'field_stores':'3.0 b 3 2 1\n','whole_store':'4\n','big_part':'3\n','slice_loops':'23 5\n','appends_loop':'8000\n','appends_several':'3 8\n'}
guests={'ce_cow':'30115815 20000 1500 1000 1 4 0\n5 1009 5 9\n2 2 1 0\n','ce_slices':'788980 0 0\n806 420 0 261 0 0 3244\n9 8 -1 -1\nc,def,, ,gh, \n9010 1023 13 435 15 10 7 2\n','ce_appends':'2729 1026 435284\n16 17 697512\n2729 2743 2729 770813\n2747 905629 48633\n10 771938\n','ce_elements':'4599556 78493 1.0 0.0\n18 13 22 18 1 6\na!!!!!/a!!!!!:2:11:6:2 b!!!!!/b!!!!!:2:13:6:2  2\na/-:1:1:0:0 b/q:2:3:0:1  2\nl1 d2 p1,2 n  d4 p2,3 lhey n  24\n7233 105 33 5 0\n120 9 4\n20 1000 -0.05232905378682199 77.0 a!!!!! changed 2 3\n'}
flags={'debug':['--unoptimized'],'release':['--release'],'verify':['--release','--verify-facts']}[mode]
r={'compiler':str(c),'compiler_sha256':sha,'revision':'a1f19edf255c8c0886731d8d7cce450d5f657720','group':group,'mode':mode,'cases':{}}
for name,expected in (inline if group=='inline' else guests).items():
 s=p/(name+'.my') if group=='inline' else Path('test/core',name+'.my').resolve()
 out=o/name;out.mkdir();binary=out/'program';ll=out/'program.ll';cmd=[str(c),'build',str(s),'--experimental-zero-rc','--counters',*flags,'--zig',os.environ['ZIG'],'--cache-dir',str(p/'native-cache'),'-o',str(binary),'--emit-llvm',str(ll)]
 b=subprocess.run(cmd,capture_output=True,text=True,timeout=180);(out/'build.stderr').write_text(b.stderr);(out/'build.stdout').write_text(b.stdout)
 row={'source':str(s),'source_sha256':hashlib.sha256(s.read_bytes()).hexdigest(),'argv':cmd,'build_status':b.returncode};r['cases'][name]=row
 if b.returncode==0:
  env=dict(os.environ);env['MYLANG_COUNTERS']=str(out/'counts.json');env.pop('MYL_CORE_LEAKCHECK',None)
  ran=subprocess.run([str(binary)],capture_output=True,text=True,env=env,timeout=180);row.update({'status':ran.returncode,'stdout':ran.stdout,'stderr':ran.stderr,'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'llvm_sha256':hashlib.sha256(ll.read_bytes()).hexdigest()})
  counts=json.loads((out/'counts.json').read_text());row['totals']=counts['totals'];row['passed']=ran.returncode==0 and ran.stdout==expected and ran.stderr=='' and counts['totals']['live_bytes_at_exit']==0
 (o/'results.json').write_text(json.dumps(r,indent=2)+'\n');print(name,row.get('passed',False),row.get('totals',{}),flush=True)
if any(not x.get('passed') for x in r['cases'].values()):raise SystemExit(1)
