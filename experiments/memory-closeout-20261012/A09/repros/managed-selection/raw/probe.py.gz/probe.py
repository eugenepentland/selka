from pathlib import Path
import subprocess,json,hashlib,os
root=Path.cwd();scratch=root/'.tmp/memory-closeout/A09/managed-selection';sources=root/'experiments/memory-closeout-20261012/A09/repros/managed-selection'
compiler=Path('/home/epentland/ai/canopy/mylang-memory-20261012/.tmp/memory-closeout/coordinator/support6-install/bin/mylang');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();assert sha(compiler)=='bc6432a75fc1fa0dbcbd2048a5c8dbe2909d7590e90ae729688ed4f6e69978d4'
rows=[]
for source in sorted(sources.glob('*.my')):
 for mode,command in [('checked',['check',str(source),'--experimental-zero-rc']),('ordinary-typed',['dump-typed',str(source)])]:
  argv=[str(compiler),*command];p=subprocess.run(argv,capture_output=True,text=True,timeout=60)
  for kind,text in [('stdout',p.stdout),('stderr',p.stderr)]: (scratch/(source.stem+'-'+mode+'.'+kind)).write_text(text)
  rows.append({'case':source.stem,'source':str(source),'source_sha256':sha(source),'mode':mode,'command':argv,'status':p.returncode,'stdout_path':str(scratch/(source.stem+'-'+mode+'.stdout')),'stderr_path':str(scratch/(source.stem+'-'+mode+'.stderr'))})
  print(source.stem,mode,p.returncode,p.stderr[:350],flush=True)
  (scratch/'results.json').write_text(json.dumps({'compiler':str(compiler),'compiler_sha256':sha(compiler),'compiler_source':'5167c588','cases':rows},indent=2)+'\n')
