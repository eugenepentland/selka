
/home/epentland/ai/canopy/mylang-worktrees/goal110-dict-read-20261004/.mylang-cache/goal110-dict-probe-debug/runner/bin/collections-my-llvm:     file format elf64-x86-64


Disassembly of section .text:

000000000105c850 <contains_walk>:
 105c850:	push   %rbp
 105c851:	mov    %rsp,%rbp
 105c854:	push   %r15
 105c856:	push   %r14
 105c858:	push   %rbx
 105c859:	push   %rax
 105c85a:	mov    %rdi,%rbx
 105c85d:	mov    0x24(%rdi),%r15d
 105c861:	cmp    $0x2,%r15d
 105c865:	je     105c877 <contains_walk+0x27>
 105c867:	cmp    $0x1,%r15d
 105c86b:	je     105c872 <contains_walk+0x22>
 105c86d:	test   %r15d,%r15d
 105c870:	jne    105c8a8 <contains_walk+0x58>
 105c872:	mov    (%rsi),%r14
 105c875:	jmp    105c8eb <contains_walk+0x9b>
 105c877:	mov    0x8(%rbx),%rax
 105c87b:	mov    (%rax),%rax
 105c87e:	movq   $0x0,-0x20(%rbp)
 105c886:	popcnt %rax,%rcx
 105c88b:	cmp    $0x1,%ecx
 105c88e:	jne    105c8cb <contains_walk+0x7b>
 105c890:	tzcnt  %rax,%rcx
 105c895:	cmp    $0x3,%rcx
 105c899:	ja     105c8cb <contains_walk+0x7b>
 105c89b:	jmp    *0x100b398(,%rcx,8)
 105c8a2:	movzbl (%rsi),%r14d
 105c8a6:	jmp    105c8eb <contains_walk+0x9b>
 105c8a8:	mov    %rbx,%rdi
 105c8ab:	call   105cac0 <probe_any>
 105c8b0:	mov    %rax,%rcx
 105c8b3:	movl   $0x0,0xf8(%rbx)
 105c8bd:	xor    %eax,%eax
 105c8bf:	cmp    $0xffffffffffffffff,%rcx
 105c8c3:	setne  %al
 105c8c6:	jmp    105ca65 <contains_walk+0x215>
 105c8cb:	cmp    $0x8,%rax
 105c8cf:	mov    $0x8,%edx
 105c8d4:	cmovb  %rax,%rdx
 105c8d8:	lea    -0x20(%rbp),%rdi
 105c8dc:	mov    %rsi,%r14
 105c8df:	call   1071310 <memcpy@plt>
 105c8e4:	mov    %r14,%rsi
 105c8e7:	mov    -0x20(%rbp),%r14
 105c8eb:	cmpl   $0x2,0xf8(%rbx)
 105c8f2:	jne    105c903 <contains_walk+0xb3>
 105c8f4:	xor    %eax,%eax
 105c8f6:	cmp    0xe0(%rbx),%r14
 105c8fd:	je     105ca65 <contains_walk+0x215>
 105c903:	mov    0xd8(%rbx),%rdi
 105c90a:	test   %rdi,%rdi
 105c90d:	je     105c984 <contains_walk+0x134>
 105c90f:	cmp    $0x1,%r15d
 105c913:	je     105c9b4 <contains_walk+0x164>
 105c919:	test   %r15d,%r15d
 105c91c:	jne    105ca3f <contains_walk+0x1ef>
 105c922:	mov    (%rsi),%rsi
 105c925:	mov    %rbx,%rdi
 105c928:	call   105cbe0 <probe_text>
 105c92d:	cmp    $0xffffffffffffffff,%rax
 105c931:	jne    105c992 <contains_walk+0x142>
 105c933:	cmpl   $0x0,0x24(%rbx)
 105c937:	je     105ca59 <contains_walk+0x209>
 105c93d:	mov    %edx,%eax
 105c93f:	cmp    $0xffffffff,%eax
 105c942:	je     105ca59 <contains_walk+0x209>
 105c948:	mov    %r14,0xe0(%rbx)
 105c94f:	movq   $0x0,0xe8(%rbx)
 105c95a:	mov    %rdx,0xf0(%rbx)
 105c961:	movl   $0x2,0xf8(%rbx)
 105c96b:	vxorps %xmm0,%xmm0,%xmm0
 105c96f:	vmovups %xmm0,0xfc(%rbx)
 105c977:	vmovups %xmm0,0x108(%rbx)
 105c97f:	jmp    105ca63 <contains_walk+0x213>
 105c984:	mov    %rbx,%rdi
 105c987:	call   105cac0 <probe_any>
 105c98c:	cmp    $0xffffffffffffffff,%rax
 105c990:	je     105c933 <contains_walk+0xe3>
 105c992:	mov    %r14,0xe0(%rbx)
 105c999:	mov    %rax,0xe8(%rbx)
 105c9a0:	movl   $0x1,0xf8(%rbx)
 105c9aa:	mov    $0x1,%eax
 105c9af:	jmp    105ca65 <contains_walk+0x215>
 105c9b4:	movabs $0x9e3779b97f4a7c15,%rdx
 105c9be:	xor    %r14,%rdx
 105c9c1:	movabs $0xbf58476d1ce4e5b9,%rax
 105c9cb:	mulx   %rax,%rax,%rcx
 105c9d0:	xor    %rax,%rcx
 105c9d3:	mov    %rcx,%rdx
 105c9d6:	shr    $0x20,%rdx
 105c9da:	xor    %rcx,%rdx
 105c9dd:	mov    0xd0(%rbx),%rsi
 105c9e4:	dec    %rdi
 105c9e7:	mov    %edi,%ecx
 105c9e9:	and    %edx,%ecx
 105c9eb:	mov    (%rsi,%rcx,8),%rax
 105c9ef:	test   %rax,%rax
 105c9f2:	je     105ca8f <contains_walk+0x23f>
 105c9f8:	mov    (%rbx),%r9
 105c9fb:	mov    0x30(%rbx),%r8
 105c9ff:	mov    0x20(%r9),%r9
 105ca03:	jmp    105ca1f <contains_walk+0x1cf>
 105ca05:	data16 cs nopw 0x0(%rax,%rax,1)
 105ca10:	inc    %rcx
 105ca13:	and    %rdi,%rcx
 105ca16:	mov    (%rsi,%rcx,8),%rax
 105ca1a:	test   %rax,%rax
 105ca1d:	je     105ca70 <contains_walk+0x220>
 105ca1f:	mov    %rax,%r10
 105ca22:	shr    $0x20,%r10
 105ca26:	cmp    %r10d,%edx
 105ca29:	jne    105ca10 <contains_walk+0x1c0>
 105ca2b:	mov    %eax,%eax
 105ca2d:	dec    %rax
 105ca30:	mov    %rax,%r10
 105ca33:	imul   %r8,%r10
 105ca37:	cmp    %r14,(%r9,%r10,1)
 105ca3b:	jne    105ca10 <contains_walk+0x1c0>
 105ca3d:	jmp    105ca77 <contains_walk+0x227>
 105ca3f:	mov    %rbx,%rdi
 105ca42:	mov    %r14,%rsi
 105ca45:	call   105cd80 <probe_scalar>
 105ca4a:	cmp    $0xffffffffffffffff,%rax
 105ca4e:	jne    105c992 <contains_walk+0x142>
 105ca54:	jmp    105c933 <contains_walk+0xe3>
 105ca59:	movl   $0x0,0xf8(%rbx)
 105ca63:	xor    %eax,%eax
 105ca65:	add    $0x8,%rsp
 105ca69:	pop    %rbx
 105ca6a:	pop    %r14
 105ca6c:	pop    %r15
 105ca6e:	pop    %rbp
 105ca6f:	ret
 105ca70:	mov    $0xffffffffffffffff,%rax
 105ca77:	mov    %ecx,%ecx
 105ca79:	shl    $0x20,%rdx
 105ca7d:	or     %rcx,%rdx
 105ca80:	cmp    $0xffffffffffffffff,%rax
 105ca84:	jne    105c992 <contains_walk+0x142>
 105ca8a:	jmp    105c933 <contains_walk+0xe3>
 105ca8f:	mov    $0xffffffffffffffff,%rax
 105ca96:	shl    $0x20,%rdx
 105ca9a:	or     %rcx,%rdx
 105ca9d:	cmp    $0xffffffffffffffff,%rax
 105caa1:	jne    105c992 <contains_walk+0x142>
 105caa7:	jmp    105c933 <contains_walk+0xe3>
 105caac:	mov    (%rsi),%r14d
 105caaf:	jmp    105c8eb <contains_walk+0x9b>
 105cab4:	movzwl (%rsi),%r14d
 105cab8:	jmp    105c8eb <contains_walk+0x9b>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
