
/home/epentland/ai/canopy/mylang-worktrees/goal110-dict-read-20261004/.mylang-cache/goal110-dict-probe-debug/runner/bin/collections-my-llvm:     file format elf64-x86-64


Disassembly of section .text:

000000000105d450 <myl_native_dictionary_read>:
 105d450:	push   %rbp
 105d451:	mov    %rsp,%rbp
 105d454:	push   %r15
 105d456:	push   %r14
 105d458:	push   %r13
 105d45a:	push   %r12
 105d45c:	push   %rbx
 105d45d:	push   %rax
 105d45e:	cmpl   $0x1,0xf8(%rdi)
 105d465:	jne    105d6db <myl_native_dictionary_read+0x28b>
 105d46b:	mov    0x24(%rdi),%r15d
 105d46f:	cmp    $0x2,%r15d
 105d473:	je     105d489 <myl_native_dictionary_read+0x39>
 105d475:	cmp    $0x1,%r15d
 105d479:	je     105d484 <myl_native_dictionary_read+0x34>
 105d47b:	test   %r15d,%r15d
 105d47e:	jne    105d6db <myl_native_dictionary_read+0x28b>
 105d484:	mov    (%rsi),%r14
 105d487:	jmp    105d4ec <myl_native_dictionary_read+0x9c>
 105d489:	mov    0x8(%rdi),%rax
 105d48d:	mov    (%rax),%rcx
 105d490:	movq   $0x0,-0x30(%rbp)
 105d498:	popcnt %rcx,%rax
 105d49d:	cmp    $0x1,%eax
 105d4a0:	jne    105d4ba <myl_native_dictionary_read+0x6a>
 105d4a2:	tzcnt  %rcx,%rax
 105d4a7:	cmp    $0x3,%rax
 105d4ab:	ja     105d4ba <myl_native_dictionary_read+0x6a>
 105d4ad:	jmp    *0x100b3f8(,%rax,8)
 105d4b4:	movzbl (%rsi),%r14d
 105d4b8:	jmp    105d4ec <myl_native_dictionary_read+0x9c>
 105d4ba:	cmp    $0x8,%rcx
 105d4be:	mov    $0x8,%eax
 105d4c3:	cmovb  %rcx,%rax
 105d4c7:	lea    -0x30(%rbp),%rcx
 105d4cb:	mov    %rdi,%r14
 105d4ce:	mov    %rcx,%rdi
 105d4d1:	mov    %rsi,%rbx
 105d4d4:	mov    %rdx,%r12
 105d4d7:	mov    %rax,%rdx
 105d4da:	call   1071310 <memcpy@plt>
 105d4df:	mov    %rbx,%rsi
 105d4e2:	mov    %r14,%rdi
 105d4e5:	mov    %r12,%rdx
 105d4e8:	mov    -0x30(%rbp),%r14
 105d4ec:	cmp    0xe0(%rdi),%r14
 105d4f3:	jne    105d6db <myl_native_dictionary_read+0x28b>
 105d4f9:	mov    (%rdi),%rcx
 105d4fc:	mov    0xe8(%rdi),%rax
 105d503:	cmp    (%rcx),%rax
 105d506:	jae    105d6db <myl_native_dictionary_read+0x28b>
 105d50c:	mov    0x30(%rdi),%rbx
 105d510:	imul   %rax,%rbx
 105d514:	add    0x20(%rcx),%rbx
 105d518:	cmp    $0x2,%r15d
 105d51c:	je     105d52c <myl_native_dictionary_read+0xdc>
 105d51e:	cmp    $0x1,%r15d
 105d522:	jne    105d55c <myl_native_dictionary_read+0x10c>
 105d524:	mov    (%rbx),%rax
 105d527:	jmp    105d5b0 <myl_native_dictionary_read+0x160>
 105d52c:	mov    0x8(%rdi),%rax
 105d530:	mov    (%rax),%rcx
 105d533:	movq   $0x0,-0x30(%rbp)
 105d53b:	popcnt %rcx,%rax
 105d540:	cmp    $0x1,%eax
 105d543:	jne    105d57b <myl_native_dictionary_read+0x12b>
 105d545:	tzcnt  %rcx,%rax
 105d54a:	cmp    $0x3,%rax
 105d54e:	ja     105d57b <myl_native_dictionary_read+0x12b>
 105d550:	jmp    *0x100b418(,%rax,8)
 105d557:	movzbl (%rbx),%eax
 105d55a:	jmp    105d5b0 <myl_native_dictionary_read+0x160>
 105d55c:	mov    (%rbx),%rcx
 105d55f:	mov    (%rsi),%r10
 105d562:	cmp    %r10,%rcx
 105d565:	je     105d5b9 <myl_native_dictionary_read+0x169>
 105d567:	testb  $0x4,0x10(%r10)
 105d56c:	jne    105d605 <myl_native_dictionary_read+0x1b5>
 105d572:	lea    0x18(%r10),%r8
 105d576:	jmp    105d614 <myl_native_dictionary_read+0x1c4>
 105d57b:	cmp    $0x8,%rcx
 105d57f:	mov    $0x8,%eax
 105d584:	cmovb  %rcx,%rax
 105d588:	lea    -0x30(%rbp),%rcx
 105d58c:	mov    %rdi,%r15
 105d58f:	mov    %rcx,%rdi
 105d592:	mov    %rsi,%r12
 105d595:	mov    %rbx,%rsi
 105d598:	mov    %rdx,%r13
 105d59b:	mov    %rax,%rdx
 105d59e:	call   1071310 <memcpy@plt>
 105d5a3:	mov    %r12,%rsi
 105d5a6:	mov    %r15,%rdi
 105d5a9:	mov    %r13,%rdx
 105d5ac:	mov    -0x30(%rbp),%rax
 105d5b0:	cmp    %r14,%rax
 105d5b3:	jne    105d6db <myl_native_dictionary_read+0x28b>
 105d5b9:	add    0x18(%rdi),%rbx
 105d5bd:	mov    0x10(%rdi),%rax
 105d5c1:	mov    (%rax),%rax
 105d5c4:	cmp    $0x8,%rax
 105d5c8:	jne    105d5d2 <myl_native_dictionary_read+0x182>
 105d5ca:	mov    (%rbx),%rax
 105d5cd:	mov    %rax,(%rdx)
 105d5d0:	jmp    105d5e0 <myl_native_dictionary_read+0x190>
 105d5d2:	mov    %rdx,%rdi
 105d5d5:	mov    %rbx,%rsi
 105d5d8:	mov    %rax,%rdx
 105d5db:	call   1071340 <memmove@plt>
 105d5e0:	mov    $0x1,%eax
 105d5e5:	add    $0x8,%rsp
 105d5e9:	pop    %rbx
 105d5ea:	pop    %r12
 105d5ec:	pop    %r13
 105d5ee:	pop    %r14
 105d5f0:	pop    %r15
 105d5f2:	pop    %rbp
 105d5f3:	ret
 105d5f4:	mov    (%rsi),%r14d
 105d5f7:	jmp    105d4ec <myl_native_dictionary_read+0x9c>
 105d5fc:	movzwl (%rsi),%r14d
 105d600:	jmp    105d4ec <myl_native_dictionary_read+0x9c>
 105d605:	mov    0x18(%r10),%r8
 105d609:	mov    0x14(%r10),%r9d
 105d60d:	add    %r9,%r8
 105d610:	add    $0x18,%r8
 105d614:	mov    0x8(%rcx),%r9
 105d618:	cmp    0x8(%r10),%r9
 105d61c:	jne    105d6db <myl_native_dictionary_read+0x28b>
 105d622:	cmp    $0x8,%r9
 105d626:	jb     105d647 <myl_native_dictionary_read+0x1f7>
 105d628:	xor    %r10d,%r10d
 105d62b:	lea    0x8(%r10),%r11
 105d62f:	cmp    %r9,%r11
 105d632:	jae    105d672 <myl_native_dictionary_read+0x222>
 105d634:	mov    0x18(%rcx,%r10,1),%r14
 105d639:	cmp    (%r8,%r10,1),%r14
 105d63d:	mov    %r11,%r10
 105d640:	je     105d62b <myl_native_dictionary_read+0x1db>
 105d642:	jmp    105d6db <myl_native_dictionary_read+0x28b>
 105d647:	cmp    $0x3,%r9
 105d64b:	jbe    105d68f <myl_native_dictionary_read+0x23f>
 105d64d:	mov    0x18(%rcx),%r10d
 105d651:	mov    -0x4(%r8,%r9,1),%r11d
 105d656:	xor    (%r8),%r10d
 105d659:	xor    0x14(%rcx,%r9,1),%r11d
 105d65e:	or     %r10d,%r11d
 105d661:	jmp    105d67c <myl_native_dictionary_read+0x22c>
 105d663:	mov    (%rbx),%eax
 105d665:	jmp    105d5b0 <myl_native_dictionary_read+0x160>
 105d66a:	movzwl (%rbx),%eax
 105d66d:	jmp    105d5b0 <myl_native_dictionary_read+0x160>
 105d672:	mov    0x10(%rcx,%r9,1),%rcx
 105d677:	cmp    -0x8(%r8,%r9,1),%rcx
 105d67c:	sete   %cl
 105d67f:	cmp    $0xffffffffffffffff,%rax
 105d683:	je     105d6db <myl_native_dictionary_read+0x28b>
 105d685:	test   %cl,%cl
 105d687:	jne    105d5b9 <myl_native_dictionary_read+0x169>
 105d68d:	jmp    105d6db <myl_native_dictionary_read+0x28b>
 105d68f:	test   %r9,%r9
 105d692:	je     105d5b9 <myl_native_dictionary_read+0x169>
 105d698:	movzbl 0x18(%rcx),%r10d
 105d69d:	cmp    (%r8),%r10b
 105d6a0:	jne    105d6db <myl_native_dictionary_read+0x28b>
 105d6a2:	cmp    $0x1,%r9
 105d6a6:	je     105d5b9 <myl_native_dictionary_read+0x169>
 105d6ac:	movzbl 0x19(%rcx),%r10d
 105d6b1:	cmp    0x1(%r8),%r10b
 105d6b5:	jne    105d6db <myl_native_dictionary_read+0x28b>
 105d6b7:	cmp    $0x2,%r9
 105d6bb:	je     105d5b9 <myl_native_dictionary_read+0x169>
 105d6c1:	movzbl 0x1a(%rcx),%ecx
 105d6c5:	cmp    0x2(%r8),%cl
 105d6c9:	setne  %cl
 105d6cc:	cmp    $0xffffffffffffffff,%rax
 105d6d0:	sete   %al
 105d6d3:	or     %cl,%al
 105d6d5:	je     105d5b9 <myl_native_dictionary_read+0x169>
 105d6db:	add    $0x8,%rsp
 105d6df:	pop    %rbx
 105d6e0:	pop    %r12
 105d6e2:	pop    %r13
 105d6e4:	pop    %r14
 105d6e6:	pop    %r15
 105d6e8:	pop    %rbp
 105d6e9:	jmp    105d6f0 <read_walk>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
