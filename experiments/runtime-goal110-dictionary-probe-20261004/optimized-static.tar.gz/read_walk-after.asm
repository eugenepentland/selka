
/home/epentland/ai/canopy/mylang-worktrees/goal110-dict-read-20261004/.mylang-cache/goal110-dict-probe-debug/runner/bin/collections-my-llvm:     file format elf64-x86-64


Disassembly of section .text:

000000000105d6f0 <read_walk>:
 105d6f0:	push   %rbp
 105d6f1:	mov    %rsp,%rbp
 105d6f4:	push   %r15
 105d6f6:	push   %r14
 105d6f8:	push   %r12
 105d6fa:	push   %rbx
 105d6fb:	sub    $0x10,%rsp
 105d6ff:	mov    %rdx,%r14
 105d702:	mov    %rdi,%rbx
 105d705:	mov    0x24(%rdi),%r12d
 105d709:	cmp    $0x2,%r12d
 105d70d:	je     105d71f <read_walk+0x2f>
 105d70f:	cmp    $0x1,%r12d
 105d713:	je     105d71a <read_walk+0x2a>
 105d715:	test   %r12d,%r12d
 105d718:	jne    105d750 <read_walk+0x60>
 105d71a:	mov    (%rsi),%r15
 105d71d:	jmp    105d78e <read_walk+0x9e>
 105d71f:	mov    0x8(%rbx),%rax
 105d723:	mov    (%rax),%rax
 105d726:	movq   $0x0,-0x28(%rbp)
 105d72e:	popcnt %rax,%rcx
 105d733:	cmp    $0x1,%ecx
 105d736:	jne    105d76e <read_walk+0x7e>
 105d738:	tzcnt  %rax,%rcx
 105d73d:	cmp    $0x3,%rcx
 105d741:	ja     105d76e <read_walk+0x7e>
 105d743:	jmp    *0x100b438(,%rcx,8)
 105d74a:	movzbl (%rsi),%r15d
 105d74e:	jmp    105d78e <read_walk+0x9e>
 105d750:	mov    %rbx,%rdi
 105d753:	call   105cac0 <probe_any>
 105d758:	movl   $0x0,0xf8(%rbx)
 105d762:	cmp    $0xffffffffffffffff,%rax
 105d766:	jne    105d84d <read_walk+0x15d>
 105d76c:	jmp    105d7a0 <read_walk+0xb0>
 105d76e:	cmp    $0x8,%rax
 105d772:	mov    $0x8,%edx
 105d777:	cmovb  %rax,%rdx
 105d77b:	lea    -0x28(%rbp),%rdi
 105d77f:	mov    %rsi,%r15
 105d782:	call   1071310 <memcpy@plt>
 105d787:	mov    %r15,%rsi
 105d78a:	mov    -0x28(%rbp),%r15
 105d78e:	cmpl   $0x2,0xf8(%rbx)
 105d795:	jne    105d7a7 <read_walk+0xb7>
 105d797:	cmp    0xe0(%rbx),%r15
 105d79e:	jne    105d7a7 <read_walk+0xb7>
 105d7a0:	xor    %eax,%eax
 105d7a2:	jmp    105d882 <read_walk+0x192>
 105d7a7:	mov    0xd8(%rbx),%rdi
 105d7ae:	test   %rdi,%rdi
 105d7b1:	je     105d827 <read_walk+0x137>
 105d7b3:	cmp    $0x1,%r12d
 105d7b7:	je     105d88f <read_walk+0x19f>
 105d7bd:	test   %r12d,%r12d
 105d7c0:	jne    105d90f <read_walk+0x21f>
 105d7c6:	mov    (%rsi),%rsi
 105d7c9:	mov    %rbx,%rdi
 105d7cc:	call   105cbe0 <probe_text>
 105d7d1:	cmp    $0xffffffffffffffff,%rax
 105d7d5:	jne    105d835 <read_walk+0x145>
 105d7d7:	cmpl   $0x0,0x24(%rbx)
 105d7db:	je     105d929 <read_walk+0x239>
 105d7e1:	mov    %edx,%eax
 105d7e3:	cmp    $0xffffffff,%eax
 105d7e6:	je     105d929 <read_walk+0x239>
 105d7ec:	mov    %r15,0xe0(%rbx)
 105d7f3:	movq   $0x0,0xe8(%rbx)
 105d7fe:	mov    %rdx,0xf0(%rbx)
 105d805:	movl   $0x2,0xf8(%rbx)
 105d80f:	vxorps %xmm0,%xmm0,%xmm0
 105d813:	vmovups %xmm0,0xfc(%rbx)
 105d81b:	vmovups %xmm0,0x108(%rbx)
 105d823:	xor    %eax,%eax
 105d825:	jmp    105d882 <read_walk+0x192>
 105d827:	mov    %rbx,%rdi
 105d82a:	call   105cac0 <probe_any>
 105d82f:	cmp    $0xffffffffffffffff,%rax
 105d833:	je     105d7d7 <read_walk+0xe7>
 105d835:	mov    %r15,0xe0(%rbx)
 105d83c:	mov    %rax,0xe8(%rbx)
 105d843:	movl   $0x1,0xf8(%rbx)
 105d84d:	imul   0x30(%rbx),%rax
 105d852:	mov    (%rbx),%rcx
 105d855:	add    0x20(%rcx),%rax
 105d859:	mov    0x10(%rbx),%rcx
 105d85d:	add    0x18(%rbx),%rax
 105d861:	mov    (%rcx),%rdx
 105d864:	cmp    $0x8,%rdx
 105d868:	jne    105d872 <read_walk+0x182>
 105d86a:	mov    (%rax),%rax
 105d86d:	mov    %rax,(%r14)
 105d870:	jmp    105d87d <read_walk+0x18d>
 105d872:	mov    %r14,%rdi
 105d875:	mov    %rax,%rsi
 105d878:	call   1071340 <memmove@plt>
 105d87d:	mov    $0x1,%eax
 105d882:	add    $0x10,%rsp
 105d886:	pop    %rbx
 105d887:	pop    %r12
 105d889:	pop    %r14
 105d88b:	pop    %r15
 105d88d:	pop    %rbp
 105d88e:	ret
 105d88f:	movabs $0x9e3779b97f4a7c15,%rdx
 105d899:	xor    %r15,%rdx
 105d89c:	movabs $0xbf58476d1ce4e5b9,%rax
 105d8a6:	mulx   %rax,%rax,%rcx
 105d8ab:	xor    %rax,%rcx
 105d8ae:	mov    %rcx,%rdx
 105d8b1:	shr    $0x20,%rdx
 105d8b5:	xor    %rcx,%rdx
 105d8b8:	mov    0xd0(%rbx),%rsi
 105d8bf:	dec    %rdi
 105d8c2:	mov    %edi,%ecx
 105d8c4:	and    %edx,%ecx
 105d8c6:	mov    (%rsi,%rcx,8),%rax
 105d8ca:	test   %rax,%rax
 105d8cd:	je     105d959 <read_walk+0x269>
 105d8d3:	mov    (%rbx),%r9
 105d8d6:	mov    0x30(%rbx),%r8
 105d8da:	mov    0x20(%r9),%r9
 105d8de:	jmp    105d8ef <read_walk+0x1ff>
 105d8e0:	inc    %rcx
 105d8e3:	and    %rdi,%rcx
 105d8e6:	mov    (%rsi,%rcx,8),%rax
 105d8ea:	test   %rax,%rax
 105d8ed:	je     105d93a <read_walk+0x24a>
 105d8ef:	mov    %rax,%r10
 105d8f2:	shr    $0x20,%r10
 105d8f6:	cmp    %r10d,%edx
 105d8f9:	jne    105d8e0 <read_walk+0x1f0>
 105d8fb:	mov    %eax,%eax
 105d8fd:	dec    %rax
 105d900:	mov    %rax,%r10
 105d903:	imul   %r8,%r10
 105d907:	cmp    %r15,(%r9,%r10,1)
 105d90b:	jne    105d8e0 <read_walk+0x1f0>
 105d90d:	jmp    105d941 <read_walk+0x251>
 105d90f:	mov    %rbx,%rdi
 105d912:	mov    %r15,%rsi
 105d915:	call   105cd80 <probe_scalar>
 105d91a:	cmp    $0xffffffffffffffff,%rax
 105d91e:	jne    105d835 <read_walk+0x145>
 105d924:	jmp    105d7d7 <read_walk+0xe7>
 105d929:	movl   $0x0,0xf8(%rbx)
 105d933:	xor    %eax,%eax
 105d935:	jmp    105d882 <read_walk+0x192>
 105d93a:	mov    $0xffffffffffffffff,%rax
 105d941:	mov    %ecx,%ecx
 105d943:	shl    $0x20,%rdx
 105d947:	or     %rcx,%rdx
 105d94a:	cmp    $0xffffffffffffffff,%rax
 105d94e:	jne    105d835 <read_walk+0x145>
 105d954:	jmp    105d7d7 <read_walk+0xe7>
 105d959:	mov    $0xffffffffffffffff,%rax
 105d960:	shl    $0x20,%rdx
 105d964:	or     %rcx,%rdx
 105d967:	cmp    $0xffffffffffffffff,%rax
 105d96b:	jne    105d835 <read_walk+0x145>
 105d971:	jmp    105d7d7 <read_walk+0xe7>
 105d976:	mov    (%rsi),%r15d
 105d979:	jmp    105d78e <read_walk+0x9e>
 105d97e:	movzwl (%rsi),%r15d
 105d982:	jmp    105d78e <read_walk+0x9e>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
