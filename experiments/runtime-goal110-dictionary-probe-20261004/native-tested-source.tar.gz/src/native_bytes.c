/* `memmem` is a GNU extension, so the feature macro has to precede <string.h>. */
#define _GNU_SOURCE
#include "native_bytes.h"
#include "native_rc_collections.h"
#include <stdlib.h>
#include <string.h>
#if defined(__SSE2__)
#include <emmintrin.h>
#endif
uint64_t myl_native_bytes_sum_xor(const unsigned char *storage, size_t count, uint64_t mask) {
    uint64_t total=0;
    unsigned char byte=(unsigned char)mask;
#if defined(__SSE2__)
    __m128i sum=_mm_setzero_si128(), flip=_mm_set1_epi8((char)byte);
    while (count>=16) {
        __m128i values=_mm_loadu_si128((const __m128i *)storage);
        sum=_mm_add_epi64(sum,_mm_sad_epu8(_mm_xor_si128(values,flip),_mm_setzero_si128()));
        storage+=16;
        count-=16;
    }
    uint64_t lanes[2];
    _mm_storeu_si128((__m128i *)lanes,sum);
    total=lanes[0]+lanes[1];
#endif
    while (count--) total+=(unsigned char)(*storage++ ^ byte);
    return total;
}
/* Splits on maximal runs of ASCII whitespace, dropping every empty piece. It is
   declared here rather than in the companion header so this file stays the only
   one the whitespace-split addition touches on the byte runtime side; the QBE
   emitter reaches it by symbol name. */
myl_native_list *myl_native_bytes_split_whitespace(myl_native_heap *, myl_native_bytes *);
/* Python endpoints clamp instead of trapping, matching managed list slices. */
static size_t endpoint(size_t length, int64_t value) {
    if (value>=0) return (uint64_t)value>length ? length : (size_t)value;
    uint64_t distance=(uint64_t)(-(value+1))+1;
    return distance>length ? 0 : length-(size_t)distance;
}
static myl_native_bytes *copy_range(myl_native_heap *heap, myl_native_bytes *input, size_t start, size_t count) {
    myl_native_root root;
    myl_native_root_push(heap,&root,&input,&myl_rc_pointer_leaf);
    myl_native_bytes *result=myl_native_list_new(heap,&myl_rc_octet_leaf,count);
    if (result) {
        if (count) memcpy(result->storage,(const unsigned char *)input->storage+start,count);
        result->length=count;
    }
    myl_native_root_pop(heap,&root);
    return result;
}
myl_native_bytes *myl_native_bytes_new(myl_native_heap *heap, const unsigned char *raw, size_t length) {
    myl_native_bytes *result=myl_native_list_new(heap,&myl_rc_octet_leaf,length);
    if (!result) return NULL;
    if (length) memcpy(result->storage,raw,length);
    result->length=length;
    return result;
}
myl_native_bytes *myl_native_bytes_copy(myl_native_heap *heap, myl_native_bytes *input) {
    return copy_range(heap,input,0,input->length);
}
int myl_native_bytes_equal(const myl_native_bytes *a, const myl_native_bytes *b) {
    if (a==b) return 1;
    if (!a || !b) return 0;
    return a->length==b->length && (!a->length || !memcmp(a->storage,b->storage,a->length));
}
/* A view is a byte string that reads another byte string's octets: `storage`
   points into the source's backing at the range start and `length` is the range
   length, so every read path — indexing, iteration, equality, search, slicing,
   decode, parsing — works on a view unchanged. The one thing a view adds is
   retention: its header carries the descriptor below, whose single traced field
   is the backing block, so the octets outlive the byte string that first owned
   them. The field lives in the list header's unused drop link, and the recorded
   pointer is the *storage block* rather than its owner: a block's own header
   sits immediately before it, which a mid-block content pointer would not have,
   and a frozen literal's block is immortal, so the collector never queues it. */
static const myl_native_field view_fields[] = {
    { .offset=offsetof(myl_native_list,work)+offsetof(myl_native_drop_link,owner), .type=&myl_rc_pointer_leaf }
};
static const myl_native_scan_entry view_scan[] = {
    { .offset=offsetof(myl_native_list,work)+offsetof(myl_native_drop_link,owner), .tag_offset=MYL_NATIVE_SCAN_ALWAYS }
};
static const myl_native_type view_header_type = {
    .size=sizeof(myl_native_list), .alignment=_Alignof(myl_native_list),
    .kind=MYL_NATIVE_RECORD, .fields=view_fields, .field_count=1,
    .trace_fields=view_fields, .trace_field_count=1, .trace_mode=MYL_NATIVE_TRACE_FIELDS,
    .scan=view_scan, .scan_count=1, .rc_id=MYL_RC_ID_BYTES_VIEW
};
static void rc_view_edges(myl_native_heap *heap, void *payload, size_t count) {
    (void)count;
    myl_rc_edge_release(heap,((myl_native_bytes *)payload)->work.owner);
}
static const myl_rc_shape rc_view_shape={.size=sizeof(myl_native_bytes),.kind=MYL_RC_SHAPE_NONE};
static myl_rc_status rc_bytes_clone_adapter(myl_native_heap *heap, const void *payload, unsigned region, void **out) {
    const myl_native_bytes *source=payload;
    unsigned saved=heap->region_depth;
    heap->region_depth=region;
    *out=myl_native_bytes_copy(heap,(myl_native_bytes *)source);
    heap->region_depth=saved;
    return myl_rc_native_result(heap,*out);
}
static const myl_rc_descriptor rc_view_descriptor={.type=&view_header_type,.shape=&rc_view_shape,.edges=rc_view_edges,.clone=rc_bytes_clone_adapter,.shell=rc_bytes_clone_adapter};
static const myl_rc_module rc_view_module={.abi=MYL_RC_ABI_VERSION,.descriptors=&rc_view_descriptor,.descriptor_count=1};
static int rc_view_prepare(myl_native_heap *heap) {
    if (!myl_rc_enabled(heap)) return 1;
    myl_rc_status status=myl_rc_module_register(heap,&rc_view_module);
    if (status!=MYL_RC_OK) myl_rc_record_failure(heap,status);
    return status==MYL_RC_OK;
}
static int rc_view_owner(myl_native_heap *heap, myl_native_bytes *view, void *owner) {
    if (myl_rc_enabled(heap)) {
        myl_rc_status status=myl_rc_owner_acquire(heap,owner);
        if (status!=MYL_RC_OK) { myl_rc_record_failure(heap,status); return 0; }
    }
    view->work.owner=owner;
    return 1;
}
/* The backing block a view of `source` must keep alive. A byte string owns the
   block its `storage` points into; a view already points into a block an
   earlier view recorded, so it hands that record on instead of deriving a
   header from a mid-block address. */
static void *view_backing(const myl_native_heap *heap, const myl_native_bytes *source) {
    if (myl_native_object_element(heap, source)==&view_header_type) return source->work.owner;
    return source->storage;
}
myl_native_bytes *myl_native_bytes_view(myl_native_heap *heap, myl_native_bytes *source, int64_t start, int64_t end) {
    if (!rc_view_prepare(heap)) return NULL;
    size_t first=endpoint(source->length,start), last=endpoint(source->length,end);
    size_t count=last>first ? last-first : 0;
    myl_native_root root;
    myl_native_root_push(heap,&root,&source,&myl_rc_pointer_leaf);
    myl_native_bytes *view=myl_native_heap_alloc(heap,&view_header_type,1);
    if (view) {
        view->element=&myl_rc_octet_leaf;
        view->length=count;
        view->capacity=count;
        view->storage=count ? (unsigned char *)source->storage+first : source->storage;
        if (!rc_view_owner(heap,view,view_backing(heap,source))) {
            myl_rc_owner_release(heap,view); view=NULL;
        }
    }
    myl_native_root_pop(heap,&root);
    return view;
}
/* Publish the buffer's current octets as an immutable byte string that reads
   them where they are. The snapshot is a view of the buffer's block, so no octet
   is copied, and it retains that block: the octets stay readable after the
   buffer itself is unreachable. The buffer keeps its octets and its length but
   is left with no spare capacity and marked, so the emitted append fast path
   cannot write into a block a snapshot reads, and the first write that follows
   moves the octets into a private block (see `buffer_ready`). That detach is
   what makes a published snapshot immutable. */
myl_native_bytes *myl_native_bytes_buffer_snapshot(myl_native_heap *heap, myl_native_bytes *buffer) {
    if (!rc_view_prepare(heap)) return NULL;
    myl_native_root root;
    myl_native_root_push(heap,&root,&buffer,&myl_rc_pointer_leaf);
    myl_native_bytes *snapshot=myl_native_heap_alloc(heap,&view_header_type,1);
    if (snapshot) {
        void *backing=view_backing(heap,buffer);
        snapshot->element=&myl_rc_octet_leaf;
        snapshot->length=buffer->length;
        snapshot->capacity=buffer->length;
        snapshot->storage=buffer->storage;
        if (!rc_view_owner(heap,snapshot,backing)) {
            myl_rc_owner_release(heap,snapshot); snapshot=NULL;
        } else {
            buffer->work.owner=backing;
            buffer->capacity=0;
        }
    }
    myl_native_root_pop(heap,&root);
    return snapshot;
}
/* Count the Unicode scalars of a byte string's octets in one validating pass, so
   measuring a range never decodes it. A word at a time is ASCII — one scalar per
   octet — and every other scalar is decoded with exactly the acceptance rules of
   `myl_native_text_valid_utf8`: a lead byte of 0xC2..0xF4 with that many
   continuation bytes, above the length's minimum and inside the scalar range. A
   malformed sequence reports MYL_BYTES_INVALID and no count. */
static int64_t scalar_count(const unsigned char *, size_t, int *);
int64_t myl_native_bytes_scalar_count(const myl_native_bytes *input, int *status) {
    return scalar_count(input->storage,input->length,status);
}
static int64_t scalar_count(const unsigned char *bytes, size_t length, int *status) {
    size_t at=0;
    int64_t count=0;
    while (at<length) {
        while (at+sizeof(uint64_t)<=length) {
            uint64_t word;
            memcpy(&word,bytes+at,sizeof word);
            if (word&UINT64_C(0x8080808080808080)) break;
            at+=sizeof(uint64_t);
            count+=8;
        }
        if (at<length && bytes[at]<0x80) { at+=1; count+=1; continue; }
        if (at==length) break;
        unsigned char first=bytes[at];
        unsigned remaining;
        uint32_t minimum;
        if (first>=0xc2 && first<=0xdf) { remaining=1; minimum=0x80; }
        else if (first>=0xe0 && first<=0xef) { remaining=2; minimum=0x800; }
        else if (first>=0xf0 && first<=0xf4) { remaining=3; minimum=0x10000; }
        else { *status=MYL_BYTES_INVALID; return 0; }
        if (remaining>length-at-1) { *status=MYL_BYTES_INVALID; return 0; }
        uint32_t point=first&((1u<<(6-remaining))-1u);
        for (unsigned index=0;index<remaining;++index) {
            unsigned char next=bytes[at+1+index];
            if ((next&0xc0)!=0x80) { *status=MYL_BYTES_INVALID; return 0; }
            point=(point<<6)|(next&63u);
        }
        if (point<minimum || point>0x10ffff || (point>=0xd800 && point<=0xdfff)) { *status=MYL_BYTES_INVALID; return 0; }
        at+=remaining+1;
        count+=1;
    }
    *status=MYL_BYTES_OK;
    return count;
}
int64_t myl_native_bytes_scalar_count_range(const myl_native_bytes *input, int64_t start, int64_t end, int *status) {
    size_t first=endpoint(input->length,start), last=endpoint(input->length,end);
    size_t count=last>first ? last-first : 0;
    return scalar_count((const unsigned char *)input->storage+first,count,status);
}
const unsigned char *myl_native_bytes_range(const myl_native_bytes *input, int64_t start, int64_t end, size_t *length) {
    size_t first=endpoint(input->length,start), last=endpoint(input->length,end);
    *length=last>first ? last-first : 0;
    return input->storage ? (const unsigned char *)input->storage+first : NULL;
}
myl_native_bytes *myl_native_bytes_concat(myl_native_heap *heap, myl_native_bytes *left, myl_native_bytes *right) {
    if (left->length>SIZE_MAX-right->length) return NULL;
    myl_native_root a,b;
    myl_native_root_push(heap,&a,&left,&myl_rc_pointer_leaf);
    myl_native_root_push(heap,&b,&right,&myl_rc_pointer_leaf);
    myl_native_bytes *result=myl_native_list_new(heap,&myl_rc_octet_leaf,left->length+right->length);
    if (result) {
        if (left->length) memcpy(result->storage,left->storage,left->length);
        if (right->length) memcpy((unsigned char *)result->storage+left->length,right->storage,right->length);
        result->length=left->length+right->length;
    }
    myl_native_root_pop(heap,&b); myl_native_root_pop(heap,&a);
    return result;
}
myl_native_bytes *myl_native_bytes_slice(myl_native_heap *heap, myl_native_bytes *input, int64_t start, int64_t end) {
    size_t first=endpoint(input->length,start), last=endpoint(input->length,end);
    return copy_range(heap,input,first,last>first ? last-first : 0);
}
static int matches(const myl_native_bytes *input, size_t at, const myl_native_bytes *needle) {
    if (needle->length>input->length-at) return 0;
    return !needle->length || !memcmp((const unsigned char *)input->storage+at,needle->storage,needle->length);
}
/* The first index of a contiguous subsequence, or -1 when it is absent. An empty
   needle matches at index zero. The one-octet and longer cases hand the scan to
   the libc bulk primitives, so a candidate position costs one comparison inside
   `memchr`/`memmem` rather than a `memcmp` call from this loop. */
int64_t myl_native_bytes_find(const myl_native_bytes *input, const myl_native_bytes *needle) {
    if (needle->length>input->length) return -1;
    const unsigned char *bytes=input->storage;
    if (!needle->length) return 0;
    const unsigned char *found;
    if (needle->length==1) found=memchr(bytes,((const unsigned char *)needle->storage)[0],input->length);
    else found=memmem(bytes,input->length,needle->storage,needle->length);
    return found ? (int64_t)(found-bytes) : -1;
}
/* The first index at or after `start` of any octet in the set `values`, or -1.
   `values` is a set, not a sequence: an empty one finds nothing and a repeated
   octet costs one bit. A one- or two-octet set is exactly `memchr` — one call,
   or two per window whose earlier hit wins — so the delimiter pairs a parser
   scans for cost one vectorized pass rather than a bit test per octet. A wider set builds a
   256-bit membership table on the stack and scans the remaining octets with it,
   so the search itself is a load, a shift and a test per octet. `start` clamps
   negative to zero and a start at or past the end finds nothing, so this is a
   search and never traps where an indexed read would. */
int64_t myl_native_bytes_find_any(const myl_native_bytes *input, const myl_native_bytes *values, int64_t start) {
    size_t length=input->length;
    size_t at = start<0 ? 0 : ((uint64_t)start>length ? length : (size_t)start);
    if (at>=length || !values->length) return -1;
    const unsigned char *bytes=input->storage;
    const unsigned char *set=values->storage;
    if (values->length==1) {
        const unsigned char *found=memchr(bytes+at,set[0],length-at);
        return found ? (int64_t)(found-bytes) : -1;
    }
    if (values->length==2 && set[0]!=set[1]) {
        /* A window at a time, doubling from 64 octets, and the second octet only
           up to the first's hit: a search stops within twice the distance to its
           answer, so a loop of searches over input missing one octet stays
           linear instead of rescanning to the end on every call. */
        size_t window=64;
        while (at<length) {
            size_t span=length-at<window ? length-at : window;
            const unsigned char *first=memchr(bytes+at,set[0],span);
            size_t bound=first ? (size_t)(first-(bytes+at)) : span;
            const unsigned char *second=bound ? memchr(bytes+at,set[1],bound) : NULL;
            if (second) return (int64_t)(second-bytes);
            if (first) return (int64_t)(first-bytes);
            at+=span;
            if (window<=SIZE_MAX/2) window*=2;
        }
        return -1;
    }
    uint64_t members[4]={0,0,0,0};
    for (size_t i=0;i<values->length;i++) members[set[i]>>6]|=(uint64_t)1<<(set[i]&63);
    for (size_t i=at;i<length;i++) if (members[bytes[i]>>6]>>(bytes[i]&63)&1) return (int64_t)i;
    return -1;
}
int myl_native_bytes_starts_with(const myl_native_bytes *input, const myl_native_bytes *prefix) {
    return prefix->length<=input->length && matches(input,0,prefix);
}
int myl_native_bytes_ends_with(const myl_native_bytes *input, const myl_native_bytes *suffix) {
    return suffix->length<=input->length && matches(input,input->length-suffix->length,suffix);
}
/* PY-TEXT-ORDER-1: lexicographic octet order, a shorter prefix first, as
   Python orders `bytes`: -1, 0 or 1. Reads both operands in place. */
int myl_native_bytes_compare(const myl_native_bytes *a, const myl_native_bytes *b) {
    size_t count=a->length<b->length?a->length:b->length;
    int order=count?memcmp(a->storage,b->storage,count):0;
    if (order) return order<0?-1:1;
    return a->length<b->length?-1:a->length>b->length?1:0;
}
int myl_native_bytes_has_byte(const myl_native_bytes *input, int64_t value) {
    if (value<0 || value>255) return 0;
    const unsigned char *bytes=input->storage;
    for (size_t i=0;i<input->length;i++) if (bytes[i]==(unsigned char)value) return 1;
    return 0;
}
/* The same cut as the text split: the shared bulk search finds each separator,
   and counting the cuts first allocates the result list once at its final
   length, so filling it never grows it. */
myl_native_list *myl_native_bytes_split(myl_native_heap *heap, myl_native_bytes *input, myl_native_bytes *separator) {
    if (!separator->length) return NULL;
    const size_t width=separator->length;
    size_t pieces=myl_native_octets_count(input->storage,input->length,separator->storage,width)+1;
    myl_native_root a,b,c;
    myl_native_root_push(heap,&a,&input,&myl_rc_pointer_leaf);
    myl_native_root_push(heap,&b,&separator,&myl_rc_pointer_leaf);
    myl_native_list *result=myl_native_list_new(heap,&myl_rc_pointer_leaf,pieces);
    myl_native_root_push(heap,&c,&result,&myl_rc_pointer_leaf);
    if (result) {
        size_t start=0;
        for (size_t left=pieces; left; left--) {
            size_t hit=left>1 ? myl_native_octets_find((const unsigned char *)input->storage+start,input->length-start,separator->storage,width) : SIZE_MAX;
            size_t end=hit==SIZE_MAX ? input->length : start+hit;
            myl_native_bytes *piece=copy_range(heap,input,start,end-start);
            if (!piece) { if (myl_rc_enabled(heap)) myl_rc_native_abort(heap,result); result=NULL; break; }
            /* The reserved slot is written in place, as an append that finds
               room writes it; the collector traces the whole reservation. */
            ((myl_native_bytes **)result->storage)[result->length++]=piece;
            result->generation++;
            if (end==input->length) break;
            start=end+width;
        }
    }
    myl_native_root_pop(heap,&c); myl_native_root_pop(heap,&b); myl_native_root_pop(heap,&a);
    return result;
}
/* The six octets Python's `bytes.split()` treats as whitespace: space, tab,
   line feed, carriage return, vertical tab and form feed. */
static int byte_space(unsigned char value) {
    return value==' ' || value=='\t' || value=='\n' || value=='\r' || value==0x0b || value==0x0c;
}
/* Python's no-argument byte split: break the receiver on maximal runs of ASCII
   whitespace and keep only the nonempty pieces, so leading, trailing and
   doubled whitespace produce no empty byte string. */
myl_native_list *myl_native_bytes_split_whitespace(myl_native_heap *heap, myl_native_bytes *input) {
    myl_native_root a,b;
    myl_native_root_push(heap,&a,&input,&myl_rc_pointer_leaf);
    myl_native_list *result=myl_native_list_new(heap,&myl_rc_pointer_leaf,0);
    myl_native_root_push(heap,&b,&result,&myl_rc_pointer_leaf);
    if (result) {
        const unsigned char *octets=input->storage;
        size_t cursor=0;
        while (cursor<input->length) {
            while (cursor<input->length && byte_space(octets[cursor])) cursor++;
            size_t start=cursor;
            while (cursor<input->length && !byte_space(octets[cursor])) cursor++;
            if (start==cursor) break;
            myl_native_bytes *piece=copy_range(heap,input,start,cursor-start);
            int appended=piece && myl_native_list_append(heap,result,&piece);
            if (myl_rc_enabled(heap)) myl_rc_owner_release(heap,piece);
            if (!appended) { if (myl_rc_enabled(heap)) myl_rc_native_abort(heap,result); result=NULL; break; }
        }
    }
    myl_native_root_pop(heap,&b); myl_native_root_pop(heap,&a);
    return result;
}
myl_native_bytes *myl_native_bytes_join(myl_native_heap *heap, myl_native_bytes *separator, myl_native_list *list) {
    size_t count=0;
    myl_native_bytes **items=list->storage;
    for (size_t i=0;i<list->length;i++) {
        if (items[i]->length>SIZE_MAX-count) return NULL;
        count+=items[i]->length;
        if (i) { if (separator->length>SIZE_MAX-count) return NULL; count+=separator->length; }
    }
    myl_native_root a,b;
    myl_native_root_push(heap,&a,&separator,&myl_rc_pointer_leaf); myl_native_root_push(heap,&b,&list,&myl_rc_pointer_leaf);
    myl_native_bytes *result=myl_native_list_new(heap,&myl_rc_octet_leaf,count);
    if (result) {
        unsigned char *output=result->storage;
        size_t at=0;
        items=list->storage;
        for (size_t i=0;i<list->length;i++) {
            if (i && separator->length) { memcpy(output+at,separator->storage,separator->length); at+=separator->length; }
            if (items[i]->length) memcpy(output+at,items[i]->storage,items[i]->length);
            at+=items[i]->length;
        }
        result->length=count;
    }
    myl_native_root_pop(heap,&b); myl_native_root_pop(heap,&a);
    return result;
}
myl_native_list *myl_native_bytes_to_list(myl_native_heap *heap, myl_native_bytes *input) {
    myl_native_root root;
    myl_native_root_push(heap,&root,&input,&myl_rc_pointer_leaf);
    myl_native_list *result=myl_native_list_new(heap,&myl_rc_word_leaf,input->length);
    if (result) {
        const unsigned char *bytes=input->storage;
        int64_t *output=result->storage;
        for (size_t i=0;i<input->length;i++) output[i]=(int64_t)bytes[i];
        result->length=input->length;
    }
    myl_native_root_pop(heap,&root);
    return result;
}
myl_native_bytes *myl_native_bytes_from_list(myl_native_heap *heap, myl_native_list *list, int *status) {
    const int64_t *values=list->storage;
    *status=MYL_BYTES_OK;
    for (size_t i=0;i<list->length;i++) if (values[i]<0 || values[i]>255) { *status=MYL_BYTES_RANGE;return NULL; }
    myl_native_root root;
    myl_native_root_push(heap,&root,&list,&myl_rc_pointer_leaf);
    myl_native_bytes *result=myl_native_list_new(heap,&myl_rc_octet_leaf,list->length);
    if (result) {
        values=list->storage;
        unsigned char *output=result->storage;
        for (size_t i=0;i<list->length;i++) output[i]=(unsigned char)values[i];
        result->length=list->length;
    } else *status=MYL_BYTES_MEMORY;
    myl_native_root_pop(heap,&root);
    return result;
}
myl_native_text *myl_native_bytes_hex(myl_native_heap *heap, myl_native_bytes *input) {
    static const char digits[]="0123456789abcdef";
    if (input->length>SIZE_MAX/2) return NULL;
    /* Two lowercase hexadecimal digits per octet, written straight into the
       text's own payload: every digit is ASCII, so no encoding pass follows. */
    myl_native_text *result=myl_native_text_build(heap,input->length*2);
    if (!result) return NULL;
    unsigned char *text=(unsigned char *)myl_native_text_storage(result);
    const unsigned char *bytes=input->storage;
    for (size_t i=0;i<input->length;i++) {
        text[i*2]=(unsigned char)digits[bytes[i]>>4];
        text[i*2+1]=(unsigned char)digits[bytes[i]&15];
    }
    myl_native_text_publish(result,input->length*2,1);
    return result;
}
/* Hexadecimal parsing reads the UTF-8 encoding so a non-ASCII digit is rejected
   exactly where the VM rejects it. */
static int hex_digit(unsigned char value) {
    if (value>='0' && value<='9') return value-'0';
    if (value>='a' && value<='f') return value-'a'+10;
    if (value>='A' && value<='F') return value-'A'+10;
    return -1;
}
myl_native_bytes *myl_native_bytes_from_hex(myl_native_heap *heap, myl_native_text *input, int *status) {
    *status=MYL_BYTES_MEMORY;
    /* The digits are the text's own payload, so the parse reads them in place
       and only the decoded octets are copied. A non-ASCII octet is one no
       `hex_digit` accepts, which is exactly where the VM rejects it. */
    size_t required=input?input->bytes:0;
    const unsigned char *raw=input?myl_native_text_payload(input):NULL;
    if (required%2) { *status=MYL_BYTES_INVALID;return NULL; }
    for (size_t i=0;i<required;i++) if (hex_digit(raw[i])<0) { *status=MYL_BYTES_INVALID;return NULL; }
    unsigned char *decoded=malloc(required?required/2:1);
    if (!decoded) return NULL;
    for (size_t i=0;i<required;i+=2) decoded[i/2]=(unsigned char)(hex_digit(raw[i])*16+hex_digit(raw[i+1]));
    myl_native_root root;
    myl_native_root_push(heap,&root,&input,&myl_rc_pointer_leaf);
    myl_native_bytes *result=myl_native_bytes_new(heap,decoded,required/2);
    myl_native_root_pop(heap,&root);
    free(decoded);
    if (result) *status=MYL_BYTES_OK;
    return result;
}
myl_native_bytes *myl_native_bytes_encode(myl_native_heap *heap, myl_native_text *input) {
    size_t required=myl_native_text_utf8(input,NULL,0);
    if (required==SIZE_MAX) return NULL;
    myl_native_root root;
    myl_native_root_push(heap,&root,&input,&myl_rc_pointer_leaf);
    myl_native_bytes *result=myl_native_list_new(heap,&myl_rc_octet_leaf,required);
    if (result) {
        myl_native_text_utf8(input,result->storage,required);
        result->length=required;
    }
    myl_native_root_pop(heap,&root);
    return result;
}
myl_native_text *myl_native_bytes_decode(myl_native_heap *heap, myl_native_bytes *input, int *status) {
    int invalid=0;
    myl_native_root root;
    myl_native_root_push(heap,&root,&input,&myl_rc_pointer_leaf);
    myl_native_text *result=myl_native_text_from_utf8_checked(heap,input->storage,input->length,&invalid);
    myl_native_root_pop(heap,&root);
    *status=result ? MYL_BYTES_OK:(invalid ? MYL_BYTES_INVALID:MYL_BYTES_MEMORY);
    return result;
}
myl_native_text *myl_native_bytes_decode_range(myl_native_heap *heap, myl_native_bytes *input, int64_t start, int64_t end, int *status) {
    int invalid=0;
    size_t first=endpoint(input->length,start), last=endpoint(input->length,end);
    size_t count=last>first ? last-first : 0;
    myl_native_root root;
    myl_native_root_push(heap,&root,&input,&myl_rc_pointer_leaf);
    myl_native_text *result=myl_native_text_from_utf8_checked(heap,(const unsigned char *)input->storage+first,count,&invalid);
    myl_native_root_pop(heap,&root);
    *status=result ? MYL_BYTES_OK:(invalid ? MYL_BYTES_INVALID:MYL_BYTES_MEMORY);
    return result;
}
/* One managed byte string can hold spare capacity beyond its length: `length` is
   what every reader sees and `capacity` is what its backing can hold. These
   entry points append into that spare capacity and double it when it runs out,
   so appending N octets performs O(log N) growth allocations and no allocation
   per appended fragment. Byte-string identity is stable across growth, which is
   what lets one managed object be mutated through the ordinary byte surface. A
   frozen literal's storage belongs to the whole image, so a mutating entry point
   refuses an immortal receiver instead of writing storage the image owns. */
/* Whether this payload is shared frozen storage rather than one heap object. */
static int buffer_frozen(const myl_native_heap *heap, const myl_native_bytes *buffer) {
    return myl_native_object_immortal(heap,buffer);
}
/* Grow the backing to hold `needed` octets. The first block is one cache line
   and later blocks double, so the count of growth allocations stays logarithmic.
   The grown block joins the buffer's own arena, so an append performed inside a
   younger arena never leaves an older buffer owning storage about to be
   bulk released.

   A backing big enough to be its own one-slot segment is extended in place
   instead: the octets it already holds are exactly the ones the copy would
   rewrite, and the pages behind them are exactly the ones the copy would fault
   a second time for, so a doubling buffer costs its final size in memory
   traffic rather than twice it. A moved reservation is only ever observed
   through the header this stores it back into: a buffer whose block a snapshot
   reads is detached by `buffer_ready` before it reaches here, and `view` refuses
   a mutable receiver, so no other value points into the block being moved. */
static int buffer_grow(myl_native_heap *heap, myl_native_bytes *buffer, size_t needed) {
    if (needed<=buffer->capacity) return 1;
    size_t capacity=buffer->capacity<64 ? 64 : buffer->capacity;
    while (capacity<needed) {
        if (capacity>SIZE_MAX/2) return 0;
        capacity*=2;
    }
    void *storage=myl_native_heap_extend(heap,buffer->storage,capacity);
    if (storage) {
        buffer->storage=storage;
        buffer->capacity=capacity;
        return 1;
    }
    storage=myl_native_heap_alloc_at(heap,buffer->element,capacity,myl_native_object_region(heap,buffer));
    if (!storage) return 0;
    if (buffer->length) memcpy(storage,buffer->storage,buffer->length);
    void *old=buffer->storage;
    buffer->storage=storage;
    buffer->capacity=capacity;
    if (myl_rc_enabled(heap)) myl_rc_owner_release(heap,old);
    return 1;
}
/* Make the buffer's backing private and big enough for `needed` octets. A buffer
   whose block a published snapshot reads carries that block in its drop link and
   has no spare capacity, so this is where the octets move into a block no
   snapshot can see — the copy is the price of the first write after a snapshot,
   and a buffer that is never written again pays nothing. The new block is sized
   the way the ordinary grow would size it, so the write that follows finds room
   already reserved. */
static int buffer_ready(myl_native_heap *heap, myl_native_bytes *buffer, size_t needed) {
    if (buffer->work.owner) {
        size_t capacity=buffer->length<64 ? 64 : buffer->length;
        while (capacity<needed) {
            if (capacity>SIZE_MAX/2) return 0;
            capacity*=2;
        }
        void *storage=myl_native_heap_alloc_at(heap,buffer->element,capacity,myl_native_object_region(heap,buffer));
        if (!storage) return 0;
        if (buffer->length) memcpy(storage,buffer->storage,buffer->length);
        void *old=buffer->storage;
        buffer->storage=storage;
        buffer->capacity=capacity;
        buffer->work.owner=NULL;
        if (myl_rc_enabled(heap)) myl_rc_owner_release(heap,old);
    }
    return buffer_grow(heap,buffer,needed);
}
/* Make the buffer's backing private and able to hold `needed` octets while it
   and one companion value stay reachable, because either allocation may collect
   before this call stores the new storage. Room that is already reserved in a
   private backing allocates nothing, so it collects nothing and needs no roots:
   a capacity-sufficient append costs two tests here instead of two root records
   on every call. A request that adds no octets at all — `reserve(0)` — changes
   nothing, which is also what leaves a marked buffer marked. */
static int buffer_ready_rooted(myl_native_heap *heap, myl_native_bytes *buffer, void *companion, size_t needed) {
    if (needed<=buffer->capacity && !buffer->work.owner) return 1;
    if (needed<=buffer->length) return 1;
    myl_native_root buffer_root, companion_root;
    myl_native_root_push(heap,&buffer_root,&buffer,&myl_rc_pointer_leaf);
    if (companion) myl_native_root_push(heap,&companion_root,companion,&myl_rc_pointer_leaf);
    int ready=buffer_ready(heap,buffer,needed);
    if (companion) myl_native_root_pop(heap,&companion_root);
    myl_native_root_pop(heap,&buffer_root);
    return ready;
}
int myl_native_bytes_buffer_reserve(myl_native_heap *heap, myl_native_bytes *buffer, int64_t extra) {
    if (extra<0) return MYL_BYTES_REFUSED;
    if (buffer_frozen(heap,buffer)) return extra==0 ? MYL_BYTES_WROTE : MYL_BYTES_REFUSED;
    if ((uint64_t)extra>SIZE_MAX-buffer->length) return MYL_BYTES_FAILED;
    if (!buffer_ready_rooted(heap,buffer,NULL,buffer->length+(size_t)extra)) return MYL_BYTES_FAILED;
    return MYL_BYTES_WROTE;
}
int myl_native_bytes_buffer_append_byte(myl_native_heap *heap, myl_native_bytes *buffer, int64_t value) {
    if (value<0 || value>255) return MYL_BYTES_REFUSED;
    if (buffer_frozen(heap,buffer)) return MYL_BYTES_REFUSED;
    if (buffer->length==SIZE_MAX) return MYL_BYTES_FAILED;
    if (!buffer_ready_rooted(heap,buffer,NULL,buffer->length+1)) return MYL_BYTES_FAILED;
    ((unsigned char *)buffer->storage)[buffer->length++]=(unsigned char)value;
    return MYL_BYTES_WROTE;
}
int myl_native_bytes_buffer_append_range(myl_native_heap *heap, myl_native_bytes *buffer, myl_native_bytes *data, int64_t start, int64_t end) {
    if (start<0 || end<start || (uint64_t)end>data->length) return MYL_BYTES_REFUSED;
    if (buffer_frozen(heap,buffer)) return MYL_BYTES_REFUSED;
    size_t count=(size_t)(end-start);
    if (!count) return MYL_BYTES_WROTE;
    if (count>SIZE_MAX-buffer->length) return MYL_BYTES_FAILED;
    if (!buffer_ready_rooted(heap,buffer,&data,buffer->length+count)) return MYL_BYTES_FAILED;
    /* `data` may be the buffer itself. Growth reallocates the buffer's backing,
       so the source is read back through the rooted pointer afterwards; the
       destination is always the end, past every copied octet, so the two ranges
       never overlap even then. */
    memcpy((unsigned char *)buffer->storage+buffer->length,(const unsigned char *)data->storage+(size_t)start,count);
    buffer->length+=count;
    return MYL_BYTES_WROTE;
}
int myl_native_bytes_buffer_append_utf8(myl_native_heap *heap, myl_native_bytes *buffer, myl_native_text *text) {
    if (buffer_frozen(heap,buffer)) return MYL_BYTES_REFUSED;
    /* A text's payload is already the UTF-8 the buffer wants, so appending one
       copies octets straight out of it: the text is rooted across the buffer's
       growth and its payload address is stable, because a managed object never
       moves. */
    size_t required=text?text->bytes:0;
    if (required>SIZE_MAX-buffer->length) return MYL_BYTES_FAILED;
    if (!required) return MYL_BYTES_WROTE;
    if (!buffer_ready_rooted(heap,buffer,&text,buffer->length+required)) return MYL_BYTES_FAILED;
    memcpy((unsigned char *)buffer->storage+buffer->length,myl_native_text_payload(text),required);
    buffer->length+=required;
    return MYL_BYTES_WROTE;
}
/* Decimal spelling of one signed integer, written least significant digit first
   and reversed in place. `-(value+1)+1` is the magnitude in unsigned
   arithmetic, so the minimum signed value formats without overflowing. */
static size_t decimal_digits(unsigned char *digits, int64_t value) {
    unsigned char *at=digits;
    uint64_t magnitude=value<0 ? (uint64_t)(-(value+1))+1 : (uint64_t)value;
    do { *at++=(unsigned char)('0'+magnitude%10); magnitude/=10; } while (magnitude);
    if (value<0) *at++='-';
    for (unsigned char *left=digits,*right=at-1;left<right;left++,right--) {
        unsigned char held=*left; *left=*right; *right=held;
    }
    return (size_t)(at-digits);
}
int myl_native_bytes_buffer_append_raw(myl_native_heap *heap, myl_native_bytes *buffer, const unsigned char *data, size_t count) {
    if (buffer_frozen(heap,buffer)) return MYL_BYTES_REFUSED;
    if (!count) return MYL_BYTES_WROTE;
    if (count>SIZE_MAX-buffer->length) return MYL_BYTES_FAILED;
    uintptr_t source=(uintptr_t)data, start=(uintptr_t)buffer->storage;
    int internal=buffer->storage && source>=start && source-start<buffer->length;
    size_t offset=internal?(size_t)(source-start):0;
    if (!buffer_ready_rooted(heap,buffer,NULL,buffer->length+count)) return MYL_BYTES_FAILED;
    if (internal) data=(const unsigned char *)buffer->storage+offset;
    memcpy((unsigned char *)buffer->storage+buffer->length,data,count);
    buffer->length+=count;
    return MYL_BYTES_WROTE;
}
int myl_native_bytes_buffer_append_int(myl_native_heap *heap, myl_native_bytes *buffer, int64_t value) {
    if (buffer_frozen(heap,buffer)) return MYL_BYTES_REFUSED;
    unsigned char digits[20];
    size_t width=decimal_digits(digits,value);
    if (width>SIZE_MAX-buffer->length) return MYL_BYTES_FAILED;
    if (!buffer_ready_rooted(heap,buffer,NULL,buffer->length+width)) return MYL_BYTES_FAILED;
    memcpy((unsigned char *)buffer->storage+buffer->length,digits,width);
    buffer->length+=width;
    return MYL_BYTES_WROTE;
}
void myl_native_bytes_copy_octets(void *destination, const void *source, size_t count) {
    if (count) memcpy(destination,source,count);
}
