
/home/epentland/ai/canopy/mylang-worktrees/d9-rc-mut-argument-astra/.tmp-mut-argument/field-list-read/proof-final-llvm-production:     file format elf64-x86-64


Disassembly of section .text:

000000000111c370 <myl_f_22849c51a4fd631aa66144da38552fb710206c5e57b8268459a8dc3a6dbcd390>:
 111c370:	55                   	push   %rbp
 111c371:	41 57                	push   %r15
 111c373:	41 56                	push   %r14
 111c375:	41 55                	push   %r13
 111c377:	41 54                	push   %r12
 111c379:	53                   	push   %rbx
 111c37a:	48 81 ec 38 02 00 00 	sub    $0x238,%rsp
 111c381:	48 c7 44 24 68 00 00 	movq   $0x0,0x68(%rsp)
 111c388:	00 00 
 111c38a:	48 c7 44 24 18 00 00 	movq   $0x0,0x18(%rsp)
 111c391:	00 00 
 111c393:	8b 87 c8 02 00 00    	mov    0x2c8(%rdi),%eax
 111c399:	89 44 24 14          	mov    %eax,0x14(%rsp)
 111c39d:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
 111c3a1:	c5 fc 11 44 24 40    	vmovups %ymm0,0x40(%rsp)
 111c3a7:	c5 fc 11 44 24 20    	vmovups %ymm0,0x20(%rsp)
 111c3ad:	48 8d 44 24 40       	lea    0x40(%rsp),%rax
 111c3b2:	48 c7 84 24 b8 00 00 	movq   $0x1011158,0xb8(%rsp)
 111c3b9:	00 58 11 01 01 
 111c3be:	c7 84 24 d0 00 00 00 	movl   $0x2,0xd0(%rsp)
 111c3c5:	02 00 00 00 
 111c3c9:	48 89 b4 24 c0 00 00 	mov    %rsi,0xc0(%rsp)
 111c3d0:	00 
 111c3d1:	48 8d 4c 24 20       	lea    0x20(%rsp),%rcx
 111c3d6:	48 89 8c 24 c8 00 00 	mov    %rcx,0xc8(%rsp)
 111c3dd:	00 
 111c3de:	48 c7 84 24 d8 00 00 	movq   $0x1011158,0xd8(%rsp)
 111c3e5:	00 58 11 01 01 
 111c3ea:	c7 84 24 f0 00 00 00 	movl   $0x2,0xf0(%rsp)
 111c3f1:	02 00 00 00 
 111c3f5:	48 8d 8c 24 10 02 00 	lea    0x210(%rsp),%rcx
 111c3fc:	00 
 111c3fd:	48 89 8c 24 e0 00 00 	mov    %rcx,0xe0(%rsp)
 111c404:	00 
 111c405:	48 8d 4c 24 28       	lea    0x28(%rsp),%rcx
 111c40a:	48 89 8c 24 e8 00 00 	mov    %rcx,0xe8(%rsp)
 111c411:	00 
 111c412:	48 c7 84 24 f8 00 00 	movq   $0x100dad8,0xf8(%rsp)
 111c419:	00 d8 da 00 01 
 111c41e:	c7 84 24 10 01 00 00 	movl   $0x2,0x110(%rsp)
 111c425:	02 00 00 00 
 111c429:	4c 8d 74 24 68       	lea    0x68(%rsp),%r14
 111c42e:	4c 89 b4 24 00 01 00 	mov    %r14,0x100(%rsp)
 111c435:	00 
 111c436:	4c 8d 64 24 30       	lea    0x30(%rsp),%r12
 111c43b:	4c 89 a4 24 08 01 00 	mov    %r12,0x108(%rsp)
 111c442:	00 
 111c443:	48 c7 84 24 18 01 00 	movq   $0x100dad8,0x118(%rsp)
 111c44a:	00 d8 da 00 01 
 111c44f:	c7 84 24 30 01 00 00 	movl   $0x2,0x130(%rsp)
 111c456:	02 00 00 00 
 111c45a:	48 8d 4c 24 18       	lea    0x18(%rsp),%rcx
 111c45f:	48 89 8c 24 20 01 00 	mov    %rcx,0x120(%rsp)
 111c466:	00 
 111c467:	48 8d 4c 24 38       	lea    0x38(%rsp),%rcx
 111c46c:	48 89 8c 24 28 01 00 	mov    %rcx,0x128(%rsp)
 111c473:	00 
 111c474:	48 c7 84 24 38 01 00 	movq   $0x100e7a8,0x138(%rsp)
 111c47b:	00 a8 e7 00 01 
 111c480:	c7 84 24 50 01 00 00 	movl   $0x0,0x150(%rsp)
 111c487:	00 00 00 00 
 111c48b:	48 8d 8c 24 e8 01 00 	lea    0x1e8(%rsp),%rcx
 111c492:	00 
 111c493:	48 89 8c 24 40 01 00 	mov    %rcx,0x140(%rsp)
 111c49a:	00 
 111c49b:	48 89 84 24 48 01 00 	mov    %rax,0x148(%rsp)
 111c4a2:	00 
 111c4a3:	48 c7 84 24 58 01 00 	movq   $0x100e7a8,0x158(%rsp)
 111c4aa:	00 a8 e7 00 01 
 111c4af:	c7 84 24 70 01 00 00 	movl   $0x0,0x170(%rsp)
 111c4b6:	00 00 00 00 
 111c4ba:	48 8d 84 24 c0 01 00 	lea    0x1c0(%rsp),%rax
 111c4c1:	00 
 111c4c2:	48 89 84 24 60 01 00 	mov    %rax,0x160(%rsp)
 111c4c9:	00 
 111c4ca:	48 8d 44 24 48       	lea    0x48(%rsp),%rax
 111c4cf:	48 89 84 24 68 01 00 	mov    %rax,0x168(%rsp)
 111c4d6:	00 
 111c4d7:	48 c7 84 24 78 01 00 	movq   $0x100e7a8,0x178(%rsp)
 111c4de:	00 a8 e7 00 01 
 111c4e3:	c7 84 24 90 01 00 00 	movl   $0x0,0x190(%rsp)
 111c4ea:	00 00 00 00 
 111c4ee:	48 8d 84 24 90 00 00 	lea    0x90(%rsp),%rax
 111c4f5:	00 
 111c4f6:	48 89 84 24 80 01 00 	mov    %rax,0x180(%rsp)
 111c4fd:	00 
 111c4fe:	48 8d 44 24 50       	lea    0x50(%rsp),%rax
 111c503:	48 89 84 24 88 01 00 	mov    %rax,0x188(%rsp)
 111c50a:	00 
 111c50b:	48 c7 84 24 98 01 00 	movq   $0x100e7a8,0x198(%rsp)
 111c512:	00 a8 e7 00 01 
 111c517:	c7 84 24 b0 01 00 00 	movl   $0x0,0x1b0(%rsp)
 111c51e:	00 00 00 00 
 111c522:	48 8d 84 24 b8 01 00 	lea    0x1b8(%rsp),%rax
 111c529:	00 
 111c52a:	48 89 84 24 a0 01 00 	mov    %rax,0x1a0(%rsp)
 111c531:	00 
 111c532:	48 8d 44 24 58       	lea    0x58(%rsp),%rax
 111c537:	48 89 84 24 a8 01 00 	mov    %rax,0x1a8(%rsp)
 111c53e:	00 
 111c53f:	48 85 ff             	test   %rdi,%rdi
 111c542:	0f 84 e1 06 00 00    	je     111cc29 <myl_f_22849c51a4fd631aa66144da38552fb710206c5e57b8268459a8dc3a6dbcd390+0x8b9>
 111c548:	48 89 fb             	mov    %rdi,%rbx
 111c54b:	48 8b 87 60 18 00 00 	mov    0x1860(%rdi),%rax
 111c552:	48 85 c0             	test   %rax,%rax
 111c555:	0f 84 ce 06 00 00    	je     111cc29 <myl_f_22849c51a4fd631aa66144da38552fb710206c5e57b8268459a8dc3a6dbcd390+0x8b9>
 111c55b:	49 89 f7             	mov    %rsi,%r15
 111c55e:	48 be 00 00 00 00 00 	movabs $0x8000000000000000,%rsi
 111c565:	00 00 80 
 111c568:	48 8b 8b 80 3d 00 00 	mov    0x3d80(%rbx),%rcx
 111c56f:	48 8b 40 70          	mov    0x70(%rax),%rax
 111c573:	48 89 4c 24 70       	mov    %rcx,0x70(%rsp)
 111c578:	48 8d 8c 24 b8 00 00 	lea    0xb8(%rsp),%rcx
 111c57f:	00 
 111c580:	48 89 4c 24 78       	mov    %rcx,0x78(%rsp)
 111c585:	48 c7 84 24 80 00 00 	movq   $0x8,0x80(%rsp)
 111c58c:	00 08 00 00 00 
 111c591:	48 89 84 24 88 00 00 	mov    %rax,0x88(%rsp)
 111c598:	00 
 111c599:	48 8d 6c 24 70       	lea    0x70(%rsp),%rbp
 111c59e:	48 89 ab 80 3d 00 00 	mov    %rbp,0x3d80(%rbx)
 111c5a5:	49 8b 57 18          	mov    0x18(%r15),%rdx
 111c5a9:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
 111c5ae:	48 c7 04 24 02 00 00 	movq   $0x2,(%rsp)
 111c5b5:	00 
 111c5b6:	48 8d 46 fd          	lea    -0x3(%rsi),%rax
 111c5ba:	48 39 c2             	cmp    %rax,%rdx
 111c5bd:	0f 8f 73 06 00 00    	jg     111cc36 <myl_f_22849c51a4fd631aa66144da38552fb710206c5e57b8268459a8dc3a6dbcd390+0x8c6>
 111c5c3:	4c 8d ab 58 02 00 00 	lea    0x258(%rbx),%r13
 111c5ca:	48 83 c2 02          	add    $0x2,%rdx
 111c5ce:	48 89 14 24          	mov    %rdx,(%rsp)
 111c5d2:	49 89 57 18          	mov    %rdx,0x18(%r15)
 111c5d6:	4c 89 7c 24 08       	mov    %r15,0x8(%rsp)
 111c5db:	49 8b 47 08          	mov    0x8(%r15),%rax
 111c5df:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
 111c5e4:	48 8d 94 24 90 00 00 	lea    0x90(%rsp),%rdx
 111c5eb:	00 
 111c5ec:	48 8d 4c 24 08       	lea    0x8(%rsp),%rcx
 111c5f1:	be d8 da 00 01       	mov    $0x100dad8,%esi
 111c5f6:	4c 89 ef             	mov    %r13,%rdi
 111c5f9:	c5 f8 77             	vzeroupper
 111c5fc:	e8 df 28 15 00       	call   126eee0 <myl_rc_native_loan>
 111c601:	85 c0                	test   %eax,%eax
 111c603:	0f 84 65 02 00 00    	je     111c86e <myl_f_22849c51a4fd631aa66144da38552fb710206c5e57b8268459a8dc3a6dbcd390+0x4fe>
 111c609:	48 8d ac 24 38 01 00 	lea    0x138(%rsp),%rbp
 111c610:	00 
 111c611:	48 c7 84 24 78 01 00 	movq   $0x100dad8,0x178(%rsp)
 111c618:	00 d8 da 00 01 
 111c61d:	c7 84 24 90 01 00 00 	movl   $0x10,0x190(%rsp)
 111c624:	10 00 00 00 
 111c628:	c7 44 24 50 01 00 00 	movl   $0x1,0x50(%rsp)
 111c62f:	00 
 111c630:	83 7c 24 40 00       	cmpl   $0x0,0x40(%rsp)
 111c635:	74 14                	je     111c64b <myl_f_22849c51a4fd631aa66144da38552fb710206c5e57b8268459a8dc3a6dbcd390+0x2db>
 111c637:	48 89 df             	mov    %rbx,%rdi
 111c63a:	48 89 ee             	mov    %rbp,%rsi
 111c63d:	e8 2e ec 13 00       	call   125b270 <myl_qbe_rc_slot_drop>
 111c642:	8b 8c 24 90 01 00 00 	mov    0x190(%rsp),%ecx
 111c649:	eb 05                	jmp    111c650 <myl_f_22849c51a4fd631aa66144da38552fb710206c5e57b8268459a8dc3a6dbcd390+0x2e0>
 111c64b:	b9 10 00 00 00       	mov    $0x10,%ecx
 111c650:	48 8b 84 24 90 00 00 	mov    0x90(%rsp),%rax
 111c657:	00 
 111c658:	48 89 84 24 e8 01 00 	mov    %rax,0x1e8(%rsp)
 111c65f:	00 
 111c660:	48 c7 84 24 38 01 00 	movq   $0x100dad8,0x138(%rsp)
 111c667:	00 d8 da 00 01 
 111c66c:	89 8c 24 50 01 00 00 	mov    %ecx,0x150(%rsp)
 111c673:	c7 44 24 50 00 00 00 	movl   $0x0,0x50(%rsp)
 111c67a:	00 
 111c67b:	c7 44 24 40 01 00 00 	movl   $0x1,0x40(%rsp)
 111c682:	00 
 111c683:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
 111c688:	f6 c1 18             	test   $0x18,%cl
 111c68b:	0f 84 05 02 00 00    	je     111c896 <myl_f_22849c51a4fd631aa66144da38552fb710206c5e57b8268459a8dc3a6dbcd390+0x526>
 111c691:	48 8d 94 24 90 00 00 	lea    0x90(%rsp),%rdx
 111c698:	00 
 111c699:	48 8d 4c 24 08       	lea    0x8(%rsp),%rcx
 111c69e:	be d8 da 00 01       	mov    $0x100dad8,%esi
 111c6a3:	4c 89 ef             	mov    %r13,%rdi
 111c6a6:	e8 35 28 15 00       	call   126eee0 <myl_rc_native_loan>
 111c6ab:	85 c0                	test   %eax,%eax
 111c6ad:	0f 84 fb 02 00 00    	je     111c9ae <myl_f_22849c51a4fd631aa66144da38552fb710206c5e57b8268459a8dc3a6dbcd390+0x63e>
 111c6b3:	48 c7 84 24 78 01 00 	movq   $0x100dad8,0x178(%rsp)
 111c6ba:	00 d8 da 00 01 
 111c6bf:	c7 84 24 90 01 00 00 	movl   $0x10,0x190(%rsp)
 111c6c6:	10 00 00 00 
 111c6ca:	c7 44 24 50 01 00 00 	movl   $0x1,0x50(%rsp)
 111c6d1:	00 
 111c6d2:	83 7c 24 40 00       	cmpl   $0x0,0x40(%rsp)
 111c6d7:	74 0b                	je     111c6e4 <myl_f_22849c51a4fd631aa66144da38552fb710206c5e57b8268459a8dc3a6dbcd390+0x374>
 111c6d9:	48 89 df             	mov    %rbx,%rdi
 111c6dc:	48 89 ee             	mov    %rbp,%rsi
 111c6df:	e8 8c eb 13 00       	call   125b270 <myl_qbe_rc_slot_drop>
 111c6e4:	83 7c 24 30 00       	cmpl   $0x0,0x30(%rsp)
 111c6e9:	74 10                	je     111c6fb <myl_f_22849c51a4fd631aa66144da38552fb710206c5e57b8268459a8dc3a6dbcd390+0x38b>
 111c6eb:	48 8d b4 24 f8 00 00 	lea    0xf8(%rsp),%rsi
 111c6f2:	00 
 111c6f3:	48 89 df             	mov    %rbx,%rdi
 111c6f6:	e8 75 eb 13 00       	call   125b270 <myl_qbe_rc_slot_drop>
 111c6fb:	48 8b 84 24 90 00 00 	mov    0x90(%rsp),%rax
 111c702:	00 
 111c703:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
 111c708:	c7 44 24 50 00 00 00 	movl   $0x0,0x50(%rsp)
 111c70f:	00 
 111c710:	48 c7 84 24 f8 00 00 	movq   $0x100dad8,0xf8(%rsp)
 111c717:	00 d8 da 00 01 
 111c71c:	4c 89 b4 24 00 01 00 	mov    %r14,0x100(%rsp)
 111c723:	00 
 111c724:	4c 89 a4 24 08 01 00 	mov    %r12,0x108(%rsp)
 111c72b:	00 
 111c72c:	8b 84 24 90 01 00 00 	mov    0x190(%rsp),%eax
 111c733:	89 84 24 10 01 00 00 	mov    %eax,0x110(%rsp)
 111c73a:	c7 44 24 30 01 00 00 	movl   $0x1,0x30(%rsp)
 111c741:	00 
 111c742:	49 8b 57 18          	mov    0x18(%r15),%rdx
 111c746:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
 111c74b:	83 7c 24 40 00       	cmpl   $0x0,0x40(%rsp)
 111c750:	74 10                	je     111c762 <myl_f_22849c51a4fd631aa66144da38552fb710206c5e57b8268459a8dc3a6dbcd390+0x3f2>
 111c752:	48 89 df             	mov    %rbx,%rdi
 111c755:	48 89 ee             	mov    %rbp,%rsi
 111c758:	e8 13 eb 13 00       	call   125b270 <myl_qbe_rc_slot_drop>
 111c75d:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
 111c762:	48 c7 04 24 02 00 00 	movq   $0x2,(%rsp)
 111c769:	00 
 111c76a:	49 be 00 00 00 00 00 	movabs $0x8000000000000000,%r14
 111c771:	00 00 80 
 111c774:	49 8d 46 02          	lea    0x2(%r14),%rax
 111c778:	48 39 c2             	cmp    %rax,%rdx
 111c77b:	0f 8c c7 04 00 00    	jl     111cc48 <myl_f_22849c51a4fd631aa66144da38552fb710206c5e57b8268459a8dc3a6dbcd390+0x8d8>
 111c781:	48 8d 72 fe          	lea    -0x2(%rdx),%rsi
 111c785:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
 111c78c:	00 
 111c78d:	48 8b 4c 24 68       	mov    0x68(%rsp),%rcx
 111c792:	48 8b 01             	mov    (%rcx),%rax
 111c795:	48 83 fa 01          	cmp    $0x1,%rdx
 111c799:	48 8d 6c 24 70       	lea    0x70(%rsp),%rbp
 111c79e:	7f 15                	jg     111c7b5 <myl_f_22849c51a4fd631aa66144da38552fb710206c5e57b8268459a8dc3a6dbcd390+0x445>
 111c7a0:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
 111c7a5:	48 85 c0             	test   %rax,%rax
 111c7a8:	0f 88 c9 04 00 00    	js     111cc77 <myl_f_22849c51a4fd631aa66144da38552fb710206c5e57b8268459a8dc3a6dbcd390+0x907>
 111c7ae:	48 89 34 24          	mov    %rsi,(%rsp)
 111c7b2:	48 01 c6             	add    %rax,%rsi
 111c7b5:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
 111c7ba:	48 39 c6             	cmp    %rax,%rsi
 111c7bd:	0f 83 97 04 00 00    	jae    111cc5a <myl_f_22849c51a4fd631aa66144da38552fb710206c5e57b8268459a8dc3a6dbcd390+0x8ea>
 111c7c3:	48 8b 41 20          	mov    0x20(%rcx),%rax
 111c7c7:	48 8b 14 f0          	mov    (%rax,%rsi,8),%rdx
 111c7cb:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
 111c7d0:	48 c7 04 24 00 01 00 	movq   $0x100,(%rsp)
 111c7d7:	00 
 111c7d8:	48 b8 00 00 00 00 00 	movabs $0xff80000000000000,%rax
 111c7df:	00 80 ff 
 111c7e2:	48 01 d0             	add    %rdx,%rax
 111c7e5:	48 c1 e8 38          	shr    $0x38,%rax
 111c7e9:	3d fe 00 00 00       	cmp    $0xfe,%eax
 111c7ee:	0f 86 71 04 00 00    	jbe    111cc65 <myl_f_22849c51a4fd631aa66144da38552fb710206c5e57b8268459a8dc3a6dbcd390+0x8f5>
 111c7f4:	48 c1 e2 08          	shl    $0x8,%rdx
 111c7f8:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
 111c7fd:	4c 89 3c 24          	mov    %r15,(%rsp)
 111c801:	49 8b 47 08          	mov    0x8(%r15),%rax
 111c805:	48 89 04 24          	mov    %rax,(%rsp)
 111c809:	48 8d 94 24 90 00 00 	lea    0x90(%rsp),%rdx
 111c810:	00 
 111c811:	48 89 e1             	mov    %rsp,%rcx
 111c814:	be d8 da 00 01       	mov    $0x100dad8,%esi
 111c819:	4c 89 ef             	mov    %r13,%rdi
 111c81c:	e8 bf 26 15 00       	call   126eee0 <myl_rc_native_loan>
 111c821:	85 c0                	test   %eax,%eax
 111c823:	74 49                	je     111c86e <myl_f_22849c51a4fd631aa66144da38552fb710206c5e57b8268459a8dc3a6dbcd390+0x4fe>
 111c825:	48 8d ac 24 58 01 00 	lea    0x158(%rsp),%rbp
 111c82c:	00 
 111c82d:	48 c7 84 24 78 01 00 	movq   $0x100dad8,0x178(%rsp)
 111c834:	00 d8 da 00 01 
 111c839:	c7 84 24 90 01 00 00 	movl   $0x10,0x190(%rsp)
 111c840:	10 00 00 00 
 111c844:	c7 44 24 50 01 00 00 	movl   $0x1,0x50(%rsp)
 111c84b:	00 
 111c84c:	83 7c 24 48 00       	cmpl   $0x0,0x48(%rsp)
 111c851:	0f 84 bc 00 00 00    	je     111c913 <myl_f_22849c51a4fd631aa66144da38552fb710206c5e57b8268459a8dc3a6dbcd390+0x5a3>
 111c857:	48 89 df             	mov    %rbx,%rdi
 111c85a:	48 89 ee             	mov    %rbp,%rsi
 111c85d:	e8 0e ea 13 00       	call   125b270 <myl_qbe_rc_slot_drop>
 111c862:	8b 8c 24 90 01 00 00 	mov    0x190(%rsp),%ecx
 111c869:	e9 aa 00 00 00       	jmp    111c918 <myl_f_22849c51a4fd631aa66144da38552fb710206c5e57b8268459a8dc3a6dbcd390+0x5a8>
 111c86e:	48 8b 8b 60 18 00 00 	mov    0x1860(%rbx),%rcx
 111c875:	48 85 c9             	test   %rcx,%rcx
 111c878:	0f 84 ab 03 00 00    	je     111cc29 <myl_f_22849c51a4fd631aa66144da38552fb710206c5e57b8268459a8dc3a6dbcd390+0x8b9>
 111c87e:	8b 41 78             	mov    0x78(%rcx),%eax
 111c881:	c7 41 78 00 00 00 00 	movl   $0x0,0x78(%rcx)
 111c888:	48 85 c0             	test   %rax,%rax
 111c88b:	0f 85 41 01 00 00    	jne    111c9d2 <myl_f_22849c51a4fd631aa66144da38552fb710206c5e57b8268459a8dc3a6dbcd390+0x662>
 111c891:	e9 6a 01 00 00       	jmp    111ca00 <myl_f_22849c51a4fd631aa66144da38552fb710206c5e57b8268459a8dc3a6dbcd390+0x690>
 111c896:	48 85 c0             	test   %rax,%rax
 111c899:	74 38                	je     111c8d3 <myl_f_22849c51a4fd631aa66144da38552fb710206c5e57b8268459a8dc3a6dbcd390+0x563>
 111c89b:	48 b9 01 00 00 00 00 	movabs $0x5000000000000001,%rcx
 111c8a2:	00 00 50 
 111c8a5:	48 85 48 f0          	test   %rcx,-0x10(%rax)
 111c8a9:	74 28                	je     111c8d3 <myl_f_22849c51a4fd631aa66144da38552fb710206c5e57b8268459a8dc3a6dbcd390+0x563>
 111c8ab:	48 8d 94 24 90 00 00 	lea    0x90(%rsp),%rdx
 111c8b2:	00 
 111c8b3:	48 8d 4c 24 08       	lea    0x8(%rsp),%rcx
 111c8b8:	be d8 da 00 01       	mov    $0x100dad8,%esi
 111c8bd:	4c 89 ef             	mov    %r13,%rdi
 111c8c0:	44 8b 44 24 14       	mov    0x14(%rsp),%r8d
 111c8c5:	e8 b6 1e 15 00       	call   126e780 <myl_rc_native_take>
 111c8ca:	85 c0                	test   %eax,%eax
 111c8cc:	75 0e                	jne    111c8dc <myl_f_22849c51a4fd631aa66144da38552fb710206c5e57b8268459a8dc3a6dbcd390+0x56c>
 111c8ce:	e9 db 00 00 00       	jmp    111c9ae <myl_f_22849c51a4fd631aa66144da38552fb710206c5e57b8268459a8dc3a6dbcd390+0x63e>
 111c8d3:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
 111c8da:	00 00 
 111c8dc:	c7 44 24 40 00 00 00 	movl   $0x0,0x40(%rsp)
 111c8e3:	00 
 111c8e4:	48 c7 84 24 78 01 00 	movq   $0x100dad8,0x178(%rsp)
 111c8eb:	00 d8 da 00 01 
 111c8f0:	c7 84 24 90 01 00 00 	movl   $0x2,0x190(%rsp)
 111c8f7:	02 00 00 00 
 111c8fb:	c7 44 24 50 01 00 00 	movl   $0x1,0x50(%rsp)
 111c902:	00 
 111c903:	83 7c 24 30 00       	cmpl   $0x0,0x30(%rsp)
 111c908:	0f 85 dd fd ff ff    	jne    111c6eb <myl_f_22849c51a4fd631aa66144da38552fb710206c5e57b8268459a8dc3a6dbcd390+0x37b>
 111c90e:	e9 e8 fd ff ff       	jmp    111c6fb <myl_f_22849c51a4fd631aa66144da38552fb710206c5e57b8268459a8dc3a6dbcd390+0x38b>
 111c913:	b9 10 00 00 00       	mov    $0x10,%ecx
 111c918:	48 8b 84 24 90 00 00 	mov    0x90(%rsp),%rax
 111c91f:	00 
 111c920:	48 89 84 24 c0 01 00 	mov    %rax,0x1c0(%rsp)
 111c927:	00 
 111c928:	48 c7 84 24 58 01 00 	movq   $0x100dad8,0x158(%rsp)
 111c92f:	00 d8 da 00 01 
 111c934:	89 8c 24 70 01 00 00 	mov    %ecx,0x170(%rsp)
 111c93b:	c7 44 24 50 00 00 00 	movl   $0x0,0x50(%rsp)
 111c942:	00 
 111c943:	c7 44 24 48 01 00 00 	movl   $0x1,0x48(%rsp)
 111c94a:	00 
 111c94b:	48 89 04 24          	mov    %rax,(%rsp)
 111c94f:	f6 c1 18             	test   $0x18,%cl
 111c952:	0f 84 0f 01 00 00    	je     111ca67 <myl_f_22849c51a4fd631aa66144da38552fb710206c5e57b8268459a8dc3a6dbcd390+0x6f7>
 111c958:	48 8d 94 24 90 00 00 	lea    0x90(%rsp),%rdx
 111c95f:	00 
 111c960:	48 89 e1             	mov    %rsp,%rcx
 111c963:	be d8 da 00 01       	mov    $0x100dad8,%esi
 111c968:	4c 89 ef             	mov    %r13,%rdi
 111c96b:	e8 70 25 15 00       	call   126eee0 <myl_rc_native_loan>
 111c970:	85 c0                	test   %eax,%eax
 111c972:	74 3a                	je     111c9ae <myl_f_22849c51a4fd631aa66144da38552fb710206c5e57b8268459a8dc3a6dbcd390+0x63e>
 111c974:	48 c7 84 24 78 01 00 	movq   $0x100dad8,0x178(%rsp)
 111c97b:	00 d8 da 00 01 
 111c980:	c7 84 24 90 01 00 00 	movl   $0x10,0x190(%rsp)
 111c987:	10 00 00 00 
 111c98b:	c7 44 24 50 01 00 00 	movl   $0x1,0x50(%rsp)
 111c992:	00 
 111c993:	83 7c 24 48 00       	cmpl   $0x0,0x48(%rsp)
 111c998:	0f 84 5a 01 00 00    	je     111caf8 <myl_f_22849c51a4fd631aa66144da38552fb710206c5e57b8268459a8dc3a6dbcd390+0x788>
 111c99e:	48 89 df             	mov    %rbx,%rdi
 111c9a1:	48 89 ee             	mov    %rbp,%rsi
 111c9a4:	e8 c7 e8 13 00       	call   125b270 <myl_qbe_rc_slot_drop>
 111c9a9:	e9 4a 01 00 00       	jmp    111caf8 <myl_f_22849c51a4fd631aa66144da38552fb710206c5e57b8268459a8dc3a6dbcd390+0x788>
 111c9ae:	48 8b 8b 60 18 00 00 	mov    0x1860(%rbx),%rcx
 111c9b5:	48 85 c9             	test   %rcx,%rcx
 111c9b8:	0f 84 6b 02 00 00    	je     111cc29 <myl_f_22849c51a4fd631aa66144da38552fb710206c5e57b8268459a8dc3a6dbcd390+0x8b9>
 111c9be:	8b 41 78             	mov    0x78(%rcx),%eax
 111c9c1:	c7 41 78 00 00 00 00 	movl   $0x0,0x78(%rcx)
 111c9c8:	48 85 c0             	test   %rax,%rax
 111c9cb:	48 8d 6c 24 70       	lea    0x70(%rsp),%rbp
 111c9d0:	74 2e                	je     111ca00 <myl_f_22849c51a4fd631aa66144da38552fb710206c5e57b8268459a8dc3a6dbcd390+0x690>
 111c9d2:	83 f8 01             	cmp    $0x1,%eax
 111c9d5:	75 10                	jne    111c9e7 <myl_f_22849c51a4fd631aa66144da38552fb710206c5e57b8268459a8dc3a6dbcd390+0x677>
 111c9d7:	be fb 8e 00 01       	mov    $0x1008efb,%esi
 111c9dc:	83 bb c4 02 00 00 00 	cmpl   $0x0,0x2c4(%rbx)
 111c9e3:	75 13                	jne    111c9f8 <myl_f_22849c51a4fd631aa66144da38552fb710206c5e57b8268459a8dc3a6dbcd390+0x688>
 111c9e5:	eb 09                	jmp    111c9f0 <myl_f_22849c51a4fd631aa66144da38552fb710206c5e57b8268459a8dc3a6dbcd390+0x680>
 111c9e7:	83 f8 04             	cmp    $0x4,%eax
 111c9ea:	0f 83 41 02 00 00    	jae    111cc31 <myl_f_22849c51a4fd631aa66144da38552fb710206c5e57b8268459a8dc3a6dbcd390+0x8c1>
 111c9f0:	48 8b 34 c5 c8 00 0b 	mov    0x10b00c8(,%rax,8),%rsi
 111c9f7:	01 
 111c9f8:	48 89 df             	mov    %rbx,%rdi
 111c9fb:	e8 70 f9 13 00       	call   125c370 <fail>
 111ca00:	48 89 df             	mov    %rbx,%rdi
 111ca03:	48 89 ee             	mov    %rbp,%rsi
 111ca06:	e8 65 ed 13 00       	call   125b770 <myl_qbe_rc_frame_cleanup>
 111ca0b:	48 39 ab 80 3d 00 00 	cmp    %rbp,0x3d80(%rbx)
 111ca12:	0f 85 11 02 00 00    	jne    111cc29 <myl_f_22849c51a4fd631aa66144da38552fb710206c5e57b8268459a8dc3a6dbcd390+0x8b9>
 111ca18:	48 8b 83 60 18 00 00 	mov    0x1860(%rbx),%rax
 111ca1f:	48 85 c0             	test   %rax,%rax
 111ca22:	74 13                	je     111ca37 <myl_f_22849c51a4fd631aa66144da38552fb710206c5e57b8268459a8dc3a6dbcd390+0x6c7>
 111ca24:	48 8b 40 70          	mov    0x70(%rax),%rax
 111ca28:	48 3b 84 24 88 00 00 	cmp    0x88(%rsp),%rax
 111ca2f:	00 
 111ca30:	74 15                	je     111ca47 <myl_f_22849c51a4fd631aa66144da38552fb710206c5e57b8268459a8dc3a6dbcd390+0x6d7>
 111ca32:	e9 f2 01 00 00       	jmp    111cc29 <myl_f_22849c51a4fd631aa66144da38552fb710206c5e57b8268459a8dc3a6dbcd390+0x8b9>
 111ca37:	31 c0                	xor    %eax,%eax
 111ca39:	48 3b 84 24 88 00 00 	cmp    0x88(%rsp),%rax
 111ca40:	00 
 111ca41:	0f 85 e2 01 00 00    	jne    111cc29 <myl_f_22849c51a4fd631aa66144da38552fb710206c5e57b8268459a8dc3a6dbcd390+0x8b9>
 111ca47:	31 c0                	xor    %eax,%eax
 111ca49:	48 8b 4c 24 70       	mov    0x70(%rsp),%rcx
 111ca4e:	48 89 8b 80 3d 00 00 	mov    %rcx,0x3d80(%rbx)
 111ca55:	48 81 c4 38 02 00 00 	add    $0x238,%rsp
 111ca5c:	5b                   	pop    %rbx
 111ca5d:	41 5c                	pop    %r12
 111ca5f:	41 5d                	pop    %r13
 111ca61:	41 5e                	pop    %r14
 111ca63:	41 5f                	pop    %r15
 111ca65:	5d                   	pop    %rbp
 111ca66:	c3                   	ret
 111ca67:	48 85 c0             	test   %rax,%rax
 111ca6a:	74 5d                	je     111cac9 <myl_f_22849c51a4fd631aa66144da38552fb710206c5e57b8268459a8dc3a6dbcd390+0x759>
 111ca6c:	48 b9 01 00 00 00 00 	movabs $0x5000000000000001,%rcx
 111ca73:	00 00 50 
 111ca76:	48 85 48 f0          	test   %rcx,-0x10(%rax)
 111ca7a:	74 4d                	je     111cac9 <myl_f_22849c51a4fd631aa66144da38552fb710206c5e57b8268459a8dc3a6dbcd390+0x759>
 111ca7c:	48 8d 94 24 90 00 00 	lea    0x90(%rsp),%rdx
 111ca83:	00 
 111ca84:	48 89 e1             	mov    %rsp,%rcx
 111ca87:	be d8 da 00 01       	mov    $0x100dad8,%esi
 111ca8c:	4c 89 ef             	mov    %r13,%rdi
 111ca8f:	44 8b 44 24 14       	mov    0x14(%rsp),%r8d
 111ca94:	e8 e7 1c 15 00       	call   126e780 <myl_rc_native_take>
 111ca99:	85 c0                	test   %eax,%eax
 111ca9b:	75 34                	jne    111cad1 <myl_f_22849c51a4fd631aa66144da38552fb710206c5e57b8268459a8dc3a6dbcd390+0x761>
 111ca9d:	48 8b 83 60 18 00 00 	mov    0x1860(%rbx),%rax
 111caa4:	48 85 c0             	test   %rax,%rax
 111caa7:	0f 84 7c 01 00 00    	je     111cc29 <myl_f_22849c51a4fd631aa66144da38552fb710206c5e57b8268459a8dc3a6dbcd390+0x8b9>
 111caad:	8b 70 78             	mov    0x78(%rax),%esi
 111cab0:	c7 40 78 00 00 00 00 	movl   $0x0,0x78(%rax)
 111cab7:	48 89 df             	mov    %rbx,%rdi
 111caba:	e8 01 e7 13 00       	call   125b1c0 <myl_qbe_rc_status>
 111cabf:	48 8d 6c 24 70       	lea    0x70(%rsp),%rbp
 111cac4:	e9 37 ff ff ff       	jmp    111ca00 <myl_f_22849c51a4fd631aa66144da38552fb710206c5e57b8268459a8dc3a6dbcd390+0x690>
 111cac9:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
 111cad0:	00 
 111cad1:	c7 44 24 48 00 00 00 	movl   $0x0,0x48(%rsp)
 111cad8:	00 
 111cad9:	48 c7 84 24 78 01 00 	movq   $0x100dad8,0x178(%rsp)
 111cae0:	00 d8 da 00 01 
 111cae5:	c7 84 24 90 01 00 00 	movl   $0x2,0x190(%rsp)
 111caec:	02 00 00 00 
 111caf0:	c7 44 24 50 01 00 00 	movl   $0x1,0x50(%rsp)
 111caf7:	00 
 111caf8:	83 7c 24 38 00       	cmpl   $0x0,0x38(%rsp)
 111cafd:	74 10                	je     111cb0f <myl_f_22849c51a4fd631aa66144da38552fb710206c5e57b8268459a8dc3a6dbcd390+0x79f>
 111caff:	48 8d b4 24 18 01 00 	lea    0x118(%rsp),%rsi
 111cb06:	00 
 111cb07:	48 89 df             	mov    %rbx,%rdi
 111cb0a:	e8 61 e7 13 00       	call   125b270 <myl_qbe_rc_slot_drop>
 111cb0f:	48 8b 84 24 90 00 00 	mov    0x90(%rsp),%rax
 111cb16:	00 
 111cb17:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
 111cb1c:	c7 44 24 50 00 00 00 	movl   $0x0,0x50(%rsp)
 111cb23:	00 
 111cb24:	48 c7 84 24 18 01 00 	movq   $0x100dad8,0x118(%rsp)
 111cb2b:	00 d8 da 00 01 
 111cb30:	48 8d 44 24 18       	lea    0x18(%rsp),%rax
 111cb35:	48 89 84 24 20 01 00 	mov    %rax,0x120(%rsp)
 111cb3c:	00 
 111cb3d:	48 8d 44 24 38       	lea    0x38(%rsp),%rax
 111cb42:	48 89 84 24 28 01 00 	mov    %rax,0x128(%rsp)
 111cb49:	00 
 111cb4a:	8b 84 24 90 01 00 00 	mov    0x190(%rsp),%eax
 111cb51:	89 84 24 30 01 00 00 	mov    %eax,0x130(%rsp)
 111cb58:	c7 44 24 38 01 00 00 	movl   $0x1,0x38(%rsp)
 111cb5f:	00 
 111cb60:	49 8b 57 18          	mov    0x18(%r15),%rdx
 111cb64:	48 89 14 24          	mov    %rdx,(%rsp)
 111cb68:	83 7c 24 48 00       	cmpl   $0x0,0x48(%rsp)
 111cb6d:	74 0f                	je     111cb7e <myl_f_22849c51a4fd631aa66144da38552fb710206c5e57b8268459a8dc3a6dbcd390+0x80e>
 111cb6f:	48 89 df             	mov    %rbx,%rdi
 111cb72:	48 89 ee             	mov    %rbp,%rsi
 111cb75:	e8 f6 e6 13 00       	call   125b270 <myl_qbe_rc_slot_drop>
 111cb7a:	48 8b 14 24          	mov    (%rsp),%rdx
 111cb7e:	4c 39 f2             	cmp    %r14,%rdx
 111cb81:	0f 84 00 01 00 00    	je     111cc87 <myl_f_22849c51a4fd631aa66144da38552fb710206c5e57b8268459a8dc3a6dbcd390+0x917>
 111cb87:	48 8d 72 ff          	lea    -0x1(%rdx),%rsi
 111cb8b:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
 111cb90:	48 8b 01             	mov    (%rcx),%rax
 111cb93:	48 85 d2             	test   %rdx,%rdx
 111cb96:	4c 8d 7c 24 70       	lea    0x70(%rsp),%r15
 111cb9b:	7f 10                	jg     111cbad <myl_f_22849c51a4fd631aa66144da38552fb710206c5e57b8268459a8dc3a6dbcd390+0x83d>
 111cb9d:	48 89 04 24          	mov    %rax,(%rsp)
 111cba1:	48 85 c0             	test   %rax,%rax
 111cba4:	0f 88 07 01 00 00    	js     111ccb1 <myl_f_22849c51a4fd631aa66144da38552fb710206c5e57b8268459a8dc3a6dbcd390+0x941>
 111cbaa:	48 01 c6             	add    %rax,%rsi
 111cbad:	48 89 34 24          	mov    %rsi,(%rsp)
 111cbb1:	48 39 c6             	cmp    %rax,%rsi
 111cbb4:	0f 83 e2 00 00 00    	jae    111cc9c <myl_f_22849c51a4fd631aa66144da38552fb710206c5e57b8268459a8dc3a6dbcd390+0x92c>
 111cbba:	48 8b 41 20          	mov    0x20(%rcx),%rax
 111cbbe:	48 8b 0c f0          	mov    (%rax,%rsi,8),%rcx
 111cbc2:	48 89 0c 24          	mov    %rcx,(%rsp)
 111cbc6:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
 111cbcb:	48 89 d0             	mov    %rdx,%rax
 111cbce:	48 01 c8             	add    %rcx,%rax
 111cbd1:	0f 80 d0 00 00 00    	jo     111cca7 <myl_f_22849c51a4fd631aa66144da38552fb710206c5e57b8268459a8dc3a6dbcd390+0x937>
 111cbd7:	49 89 c6             	mov    %rax,%r14
 111cbda:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
 111cbdf:	48 89 df             	mov    %rbx,%rdi
 111cbe2:	4c 89 fe             	mov    %r15,%rsi
 111cbe5:	e8 86 eb 13 00       	call   125b770 <myl_qbe_rc_frame_cleanup>
 111cbea:	4c 39 bb 80 3d 00 00 	cmp    %r15,0x3d80(%rbx)
 111cbf1:	75 36                	jne    111cc29 <myl_f_22849c51a4fd631aa66144da38552fb710206c5e57b8268459a8dc3a6dbcd390+0x8b9>
 111cbf3:	48 8b 83 60 18 00 00 	mov    0x1860(%rbx),%rax
 111cbfa:	48 85 c0             	test   %rax,%rax
 111cbfd:	74 17                	je     111cc16 <myl_f_22849c51a4fd631aa66144da38552fb710206c5e57b8268459a8dc3a6dbcd390+0x8a6>
 111cbff:	48 8b 48 70          	mov    0x70(%rax),%rcx
 111cc03:	4c 89 f0             	mov    %r14,%rax
 111cc06:	48 3b 8c 24 88 00 00 	cmp    0x88(%rsp),%rcx
 111cc0d:	00 
 111cc0e:	0f 84 35 fe ff ff    	je     111ca49 <myl_f_22849c51a4fd631aa66144da38552fb710206c5e57b8268459a8dc3a6dbcd390+0x6d9>
 111cc14:	eb 13                	jmp    111cc29 <myl_f_22849c51a4fd631aa66144da38552fb710206c5e57b8268459a8dc3a6dbcd390+0x8b9>
 111cc16:	31 c9                	xor    %ecx,%ecx
 111cc18:	4c 89 f0             	mov    %r14,%rax
 111cc1b:	48 3b 8c 24 88 00 00 	cmp    0x88(%rsp),%rcx
 111cc22:	00 
 111cc23:	0f 84 20 fe ff ff    	je     111ca49 <myl_f_22849c51a4fd631aa66144da38552fb710206c5e57b8268459a8dc3a6dbcd390+0x6d9>
 111cc29:	c5 f8 77             	vzeroupper
 111cc2c:	e8 6d 8b 14 00       	call   126579e <myl_rc_invariant_failed>
 111cc31:	e8 da 63 15 00       	call   1273010 <abort@plt>
 111cc36:	b9 02 00 00 00       	mov    $0x2,%ecx
 111cc3b:	48 89 df             	mov    %rbx,%rdi
 111cc3e:	31 f6                	xor    %esi,%esi
 111cc40:	c5 f8 77             	vzeroupper
 111cc43:	e8 e8 00 14 00       	call   125cd30 <myl_qbe_fail_overflow_op>
 111cc48:	be 01 00 00 00       	mov    $0x1,%esi
 111cc4d:	b9 02 00 00 00       	mov    $0x2,%ecx
 111cc52:	48 89 df             	mov    %rbx,%rdi
 111cc55:	e8 d6 00 14 00       	call   125cd30 <myl_qbe_fail_overflow_op>
 111cc5a:	48 89 df             	mov    %rbx,%rdi
 111cc5d:	48 89 c2             	mov    %rax,%rdx
 111cc60:	e8 fb ff 13 00       	call   125cc60 <myl_qbe_fail_normalized_index_bounds>
 111cc65:	be 02 00 00 00       	mov    $0x2,%esi
 111cc6a:	b9 00 01 00 00       	mov    $0x100,%ecx
 111cc6f:	48 89 df             	mov    %rbx,%rdi
 111cc72:	e8 b9 00 14 00       	call   125cd30 <myl_qbe_fail_overflow_op>
 111cc77:	ba 40 01 00 00       	mov    $0x140,%edx
 111cc7c:	48 89 df             	mov    %rbx,%rdi
 111cc7f:	48 89 c6             	mov    %rax,%rsi
 111cc82:	e8 09 01 14 00       	call   125cd90 <myl_qbe_fail_cast>
 111cc87:	be 01 00 00 00       	mov    $0x1,%esi
 111cc8c:	b9 01 00 00 00       	mov    $0x1,%ecx
 111cc91:	48 89 df             	mov    %rbx,%rdi
 111cc94:	4c 89 f2             	mov    %r14,%rdx
 111cc97:	e8 94 00 14 00       	call   125cd30 <myl_qbe_fail_overflow_op>
 111cc9c:	48 89 df             	mov    %rbx,%rdi
 111cc9f:	48 89 c2             	mov    %rax,%rdx
 111cca2:	e8 b9 ff 13 00       	call   125cc60 <myl_qbe_fail_normalized_index_bounds>
 111cca7:	48 89 df             	mov    %rbx,%rdi
 111ccaa:	31 f6                	xor    %esi,%esi
 111ccac:	e8 7f 00 14 00       	call   125cd30 <myl_qbe_fail_overflow_op>
 111ccb1:	ba 40 01 00 00       	mov    $0x140,%edx
 111ccb6:	48 89 df             	mov    %rbx,%rdi
 111ccb9:	48 89 c6             	mov    %rax,%rsi
 111ccbc:	e8 cf 00 14 00       	call   125cd90 <myl_qbe_fail_cast>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
