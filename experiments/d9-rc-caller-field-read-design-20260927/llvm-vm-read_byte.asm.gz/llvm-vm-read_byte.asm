
/home/epentland/ai/canopy/mylang-worktrees/d9-rc-mut-argument-astra/.tmp-mut-argument/field-list-read/proof-final-llvm-production:     file format elf64-x86-64


Disassembly of section .text:

000000000124f340 <myl_f_fa0a495025828a635f8203a4c546663c235c2574b972f1294569bb6fadb2fcc2>:
 124f340:	55                   	push   %rbp
 124f341:	41 57                	push   %r15
 124f343:	41 56                	push   %r14
 124f345:	41 55                	push   %r13
 124f347:	41 54                	push   %r12
 124f349:	53                   	push   %rbx
 124f34a:	48 81 ec a8 01 00 00 	sub    $0x1a8,%rsp
 124f351:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
 124f358:	00 00 
 124f35a:	8b af c8 02 00 00    	mov    0x2c8(%rdi),%ebp
 124f360:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
 124f364:	c5 fc 11 44 24 20    	vmovups %ymm0,0x20(%rsp)
 124f36a:	c5 fc 11 44 24 10    	vmovups %ymm0,0x10(%rsp)
 124f370:	48 8d 44 24 20       	lea    0x20(%rsp),%rax
 124f375:	48 c7 44 24 68 58 11 	movq   $0x1011158,0x68(%rsp)
 124f37c:	01 01 
 124f37e:	c7 84 24 80 00 00 00 	movl   $0x2,0x80(%rsp)
 124f385:	02 00 00 00 
 124f389:	48 89 74 24 70       	mov    %rsi,0x70(%rsp)
 124f38e:	48 8d 4c 24 10       	lea    0x10(%rsp),%rcx
 124f393:	48 89 4c 24 78       	mov    %rcx,0x78(%rsp)
 124f398:	48 c7 84 24 88 00 00 	movq   $0x100dad8,0x88(%rsp)
 124f39f:	00 d8 da 00 01 
 124f3a4:	c7 84 24 a0 00 00 00 	movl   $0x2,0xa0(%rsp)
 124f3ab:	02 00 00 00 
 124f3af:	48 8d 4c 24 08       	lea    0x8(%rsp),%rcx
 124f3b4:	48 89 8c 24 90 00 00 	mov    %rcx,0x90(%rsp)
 124f3bb:	00 
 124f3bc:	4c 8d 74 24 18       	lea    0x18(%rsp),%r14
 124f3c1:	4c 89 b4 24 98 00 00 	mov    %r14,0x98(%rsp)
 124f3c8:	00 
 124f3c9:	48 c7 84 24 a8 00 00 	movq   $0x1011158,0xa8(%rsp)
 124f3d0:	00 58 11 01 01 
 124f3d5:	c7 84 24 c0 00 00 00 	movl   $0x2,0xc0(%rsp)
 124f3dc:	02 00 00 00 
 124f3e0:	48 8d 8c 24 80 01 00 	lea    0x180(%rsp),%rcx
 124f3e7:	00 
 124f3e8:	48 89 8c 24 b0 00 00 	mov    %rcx,0xb0(%rsp)
 124f3ef:	00 
 124f3f0:	48 89 84 24 b8 00 00 	mov    %rax,0xb8(%rsp)
 124f3f7:	00 
 124f3f8:	48 c7 84 24 c8 00 00 	movq   $0x100e7a8,0xc8(%rsp)
 124f3ff:	00 a8 e7 00 01 
 124f404:	c7 84 24 e0 00 00 00 	movl   $0x0,0xe0(%rsp)
 124f40b:	00 00 00 00 
 124f40f:	48 8d 84 24 58 01 00 	lea    0x158(%rsp),%rax
 124f416:	00 
 124f417:	48 89 84 24 d0 00 00 	mov    %rax,0xd0(%rsp)
 124f41e:	00 
 124f41f:	48 8d 44 24 28       	lea    0x28(%rsp),%rax
 124f424:	48 89 84 24 d8 00 00 	mov    %rax,0xd8(%rsp)
 124f42b:	00 
 124f42c:	48 c7 84 24 e8 00 00 	movq   $0x100e7a8,0xe8(%rsp)
 124f433:	00 a8 e7 00 01 
 124f438:	c7 84 24 00 01 00 00 	movl   $0x0,0x100(%rsp)
 124f43f:	00 00 00 00 
 124f443:	48 8d 84 24 28 01 00 	lea    0x128(%rsp),%rax
 124f44a:	00 
 124f44b:	48 89 84 24 f0 00 00 	mov    %rax,0xf0(%rsp)
 124f452:	00 
 124f453:	48 8d 44 24 30       	lea    0x30(%rsp),%rax
 124f458:	48 89 84 24 f8 00 00 	mov    %rax,0xf8(%rsp)
 124f45f:	00 
 124f460:	48 c7 84 24 08 01 00 	movq   $0x100e7a8,0x108(%rsp)
 124f467:	00 a8 e7 00 01 
 124f46c:	c7 84 24 20 01 00 00 	movl   $0x0,0x120(%rsp)
 124f473:	00 00 00 00 
 124f477:	48 8d 84 24 50 01 00 	lea    0x150(%rsp),%rax
 124f47e:	00 
 124f47f:	48 89 84 24 10 01 00 	mov    %rax,0x110(%rsp)
 124f486:	00 
 124f487:	48 8d 44 24 38       	lea    0x38(%rsp),%rax
 124f48c:	48 89 84 24 18 01 00 	mov    %rax,0x118(%rsp)
 124f493:	00 
 124f494:	48 85 ff             	test   %rdi,%rdi
 124f497:	0f 84 ef 03 00 00    	je     124f88c <myl_f_fa0a495025828a635f8203a4c546663c235c2574b972f1294569bb6fadb2fcc2+0x54c>
 124f49d:	48 89 fb             	mov    %rdi,%rbx
 124f4a0:	48 8b 87 60 18 00 00 	mov    0x1860(%rdi),%rax
 124f4a7:	48 85 c0             	test   %rax,%rax
 124f4aa:	0f 84 dc 03 00 00    	je     124f88c <myl_f_fa0a495025828a635f8203a4c546663c235c2574b972f1294569bb6fadb2fcc2+0x54c>
 124f4b0:	49 89 f7             	mov    %rsi,%r15
 124f4b3:	4c 8d ab 58 02 00 00 	lea    0x258(%rbx),%r13
 124f4ba:	48 8b 8b 80 3d 00 00 	mov    0x3d80(%rbx),%rcx
 124f4c1:	48 8b 40 70          	mov    0x70(%rax),%rax
 124f4c5:	48 89 4c 24 48       	mov    %rcx,0x48(%rsp)
 124f4ca:	48 8d 4c 24 68       	lea    0x68(%rsp),%rcx
 124f4cf:	48 89 4c 24 50       	mov    %rcx,0x50(%rsp)
 124f4d4:	48 c7 44 24 58 06 00 	movq   $0x6,0x58(%rsp)
 124f4db:	00 00 
 124f4dd:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
 124f4e2:	48 8d 44 24 48       	lea    0x48(%rsp),%rax
 124f4e7:	48 89 83 80 3d 00 00 	mov    %rax,0x3d80(%rbx)
 124f4ee:	48 8b 46 08          	mov    0x8(%rsi),%rax
 124f4f2:	48 89 04 24          	mov    %rax,(%rsp)
 124f4f6:	48 8d 94 24 28 01 00 	lea    0x128(%rsp),%rdx
 124f4fd:	00 
 124f4fe:	48 89 e1             	mov    %rsp,%rcx
 124f501:	be d8 da 00 01       	mov    $0x100dad8,%esi
 124f506:	4c 89 ef             	mov    %r13,%rdi
 124f509:	c5 f8 77             	vzeroupper
 124f50c:	e8 cf f9 01 00       	call   126eee0 <myl_rc_native_loan>
 124f511:	85 c0                	test   %eax,%eax
 124f513:	0f 84 6c 02 00 00    	je     124f785 <myl_f_fa0a495025828a635f8203a4c546663c235c2574b972f1294569bb6fadb2fcc2+0x445>
 124f519:	48 8d b4 24 c8 00 00 	lea    0xc8(%rsp),%rsi
 124f520:	00 
 124f521:	48 c7 84 24 e8 00 00 	movq   $0x100dad8,0xe8(%rsp)
 124f528:	00 d8 da 00 01 
 124f52d:	c7 84 24 00 01 00 00 	movl   $0x10,0x100(%rsp)
 124f534:	10 00 00 00 
 124f538:	c7 44 24 30 01 00 00 	movl   $0x1,0x30(%rsp)
 124f53f:	00 
 124f540:	83 7c 24 28 00       	cmpl   $0x0,0x28(%rsp)
 124f545:	74 14                	je     124f55b <myl_f_fa0a495025828a635f8203a4c546663c235c2574b972f1294569bb6fadb2fcc2+0x21b>
 124f547:	48 89 df             	mov    %rbx,%rdi
 124f54a:	49 89 f4             	mov    %rsi,%r12
 124f54d:	e8 1e bd 00 00       	call   125b270 <myl_qbe_rc_slot_drop>
 124f552:	8b 8c 24 00 01 00 00 	mov    0x100(%rsp),%ecx
 124f559:	eb 08                	jmp    124f563 <myl_f_fa0a495025828a635f8203a4c546663c235c2574b972f1294569bb6fadb2fcc2+0x223>
 124f55b:	49 89 f4             	mov    %rsi,%r12
 124f55e:	b9 10 00 00 00       	mov    $0x10,%ecx
 124f563:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
 124f56a:	00 
 124f56b:	48 89 84 24 58 01 00 	mov    %rax,0x158(%rsp)
 124f572:	00 
 124f573:	48 c7 84 24 c8 00 00 	movq   $0x100dad8,0xc8(%rsp)
 124f57a:	00 d8 da 00 01 
 124f57f:	89 8c 24 e0 00 00 00 	mov    %ecx,0xe0(%rsp)
 124f586:	c7 44 24 30 00 00 00 	movl   $0x0,0x30(%rsp)
 124f58d:	00 
 124f58e:	c7 44 24 28 01 00 00 	movl   $0x1,0x28(%rsp)
 124f595:	00 
 124f596:	48 89 04 24          	mov    %rax,(%rsp)
 124f59a:	f6 c1 18             	test   $0x18,%cl
 124f59d:	0f 84 a2 01 00 00    	je     124f745 <myl_f_fa0a495025828a635f8203a4c546663c235c2574b972f1294569bb6fadb2fcc2+0x405>
 124f5a3:	48 8d 94 24 28 01 00 	lea    0x128(%rsp),%rdx
 124f5aa:	00 
 124f5ab:	48 89 e1             	mov    %rsp,%rcx
 124f5ae:	be d8 da 00 01       	mov    $0x100dad8,%esi
 124f5b3:	4c 89 ef             	mov    %r13,%rdi
 124f5b6:	e8 25 f9 01 00       	call   126eee0 <myl_rc_native_loan>
 124f5bb:	85 c0                	test   %eax,%eax
 124f5bd:	0f 84 c2 01 00 00    	je     124f785 <myl_f_fa0a495025828a635f8203a4c546663c235c2574b972f1294569bb6fadb2fcc2+0x445>
 124f5c3:	48 c7 84 24 e8 00 00 	movq   $0x100dad8,0xe8(%rsp)
 124f5ca:	00 d8 da 00 01 
 124f5cf:	c7 84 24 00 01 00 00 	movl   $0x10,0x100(%rsp)
 124f5d6:	10 00 00 00 
 124f5da:	c7 44 24 30 01 00 00 	movl   $0x1,0x30(%rsp)
 124f5e1:	00 
 124f5e2:	83 7c 24 28 00       	cmpl   $0x0,0x28(%rsp)
 124f5e7:	74 0b                	je     124f5f4 <myl_f_fa0a495025828a635f8203a4c546663c235c2574b972f1294569bb6fadb2fcc2+0x2b4>
 124f5e9:	48 89 df             	mov    %rbx,%rdi
 124f5ec:	4c 89 e6             	mov    %r12,%rsi
 124f5ef:	e8 7c bc 00 00       	call   125b270 <myl_qbe_rc_slot_drop>
 124f5f4:	4c 8d ac 24 88 00 00 	lea    0x88(%rsp),%r13
 124f5fb:	00 
 124f5fc:	83 7c 24 18 00       	cmpl   $0x0,0x18(%rsp)
 124f601:	74 0b                	je     124f60e <myl_f_fa0a495025828a635f8203a4c546663c235c2574b972f1294569bb6fadb2fcc2+0x2ce>
 124f603:	48 89 df             	mov    %rbx,%rdi
 124f606:	4c 89 ee             	mov    %r13,%rsi
 124f609:	e8 62 bc 00 00       	call   125b270 <myl_qbe_rc_slot_drop>
 124f60e:	48 8b 8c 24 28 01 00 	mov    0x128(%rsp),%rcx
 124f615:	00 
 124f616:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
 124f61b:	c7 44 24 30 00 00 00 	movl   $0x0,0x30(%rsp)
 124f622:	00 
 124f623:	48 c7 84 24 88 00 00 	movq   $0x100dad8,0x88(%rsp)
 124f62a:	00 d8 da 00 01 
 124f62f:	48 8d 44 24 08       	lea    0x8(%rsp),%rax
 124f634:	48 89 84 24 90 00 00 	mov    %rax,0x90(%rsp)
 124f63b:	00 
 124f63c:	4c 89 b4 24 98 00 00 	mov    %r14,0x98(%rsp)
 124f643:	00 
 124f644:	8b 84 24 00 01 00 00 	mov    0x100(%rsp),%eax
 124f64b:	89 84 24 a0 00 00 00 	mov    %eax,0xa0(%rsp)
 124f652:	c7 44 24 18 01 00 00 	movl   $0x1,0x18(%rsp)
 124f659:	00 
 124f65a:	4c 89 3c 24          	mov    %r15,(%rsp)
 124f65e:	49 8b 77 18          	mov    0x18(%r15),%rsi
 124f662:	48 89 34 24          	mov    %rsi,(%rsp)
 124f666:	83 7c 24 28 00       	cmpl   $0x0,0x28(%rsp)
 124f66b:	74 14                	je     124f681 <myl_f_fa0a495025828a635f8203a4c546663c235c2574b972f1294569bb6fadb2fcc2+0x341>
 124f66d:	48 89 df             	mov    %rbx,%rdi
 124f670:	4c 89 e6             	mov    %r12,%rsi
 124f673:	e8 f8 bb 00 00       	call   125b270 <myl_qbe_rc_slot_drop>
 124f678:	48 8b 34 24          	mov    (%rsp),%rsi
 124f67c:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
 124f681:	48 8b 01             	mov    (%rcx),%rax
 124f684:	48 85 f6             	test   %rsi,%rsi
 124f687:	79 10                	jns    124f699 <myl_f_fa0a495025828a635f8203a4c546663c235c2574b972f1294569bb6fadb2fcc2+0x359>
 124f689:	48 89 04 24          	mov    %rax,(%rsp)
 124f68d:	48 85 c0             	test   %rax,%rax
 124f690:	0f 88 1d 02 00 00    	js     124f8b3 <myl_f_fa0a495025828a635f8203a4c546663c235c2574b972f1294569bb6fadb2fcc2+0x573>
 124f696:	48 01 c6             	add    %rax,%rsi
 124f699:	48 89 34 24          	mov    %rsi,(%rsp)
 124f69d:	48 39 c6             	cmp    %rax,%rsi
 124f6a0:	0f 83 f3 01 00 00    	jae    124f899 <myl_f_fa0a495025828a635f8203a4c546663c235c2574b972f1294569bb6fadb2fcc2+0x559>
 124f6a6:	48 8b 41 20          	mov    0x20(%rcx),%rax
 124f6aa:	48 8b 2c f0          	mov    (%rax,%rsi,8),%rbp
 124f6ae:	48 89 2c 24          	mov    %rbp,(%rsp)
 124f6b2:	83 7c 24 18 00       	cmpl   $0x0,0x18(%rsp)
 124f6b7:	74 0b                	je     124f6c4 <myl_f_fa0a495025828a635f8203a4c546663c235c2574b972f1294569bb6fadb2fcc2+0x384>
 124f6b9:	48 89 df             	mov    %rbx,%rdi
 124f6bc:	4c 89 ee             	mov    %r13,%rsi
 124f6bf:	e8 ac bb 00 00       	call   125b270 <myl_qbe_rc_slot_drop>
 124f6c4:	4c 89 3c 24          	mov    %r15,(%rsp)
 124f6c8:	49 8b 47 18          	mov    0x18(%r15),%rax
 124f6cc:	48 89 04 24          	mov    %rax,(%rsp)
 124f6d0:	83 7c 24 28 00       	cmpl   $0x0,0x28(%rsp)
 124f6d5:	74 0f                	je     124f6e6 <myl_f_fa0a495025828a635f8203a4c546663c235c2574b972f1294569bb6fadb2fcc2+0x3a6>
 124f6d7:	48 89 df             	mov    %rbx,%rdi
 124f6da:	4c 89 e6             	mov    %r12,%rsi
 124f6dd:	e8 8e bb 00 00       	call   125b270 <myl_qbe_rc_slot_drop>
 124f6e2:	48 8b 04 24          	mov    (%rsp),%rax
 124f6e6:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
 124f6ed:	ff ff 7f 
 124f6f0:	48 39 d0             	cmp    %rdx,%rax
 124f6f3:	0f 84 ab 01 00 00    	je     124f8a4 <myl_f_fa0a495025828a635f8203a4c546663c235c2574b972f1294569bb6fadb2fcc2+0x564>
 124f6f9:	48 ff c0             	inc    %rax
 124f6fc:	49 89 47 18          	mov    %rax,0x18(%r15)
 124f700:	48 89 2c 24          	mov    %rbp,(%rsp)
 124f704:	48 89 df             	mov    %rbx,%rdi
 124f707:	4c 8d 74 24 48       	lea    0x48(%rsp),%r14
 124f70c:	4c 89 f6             	mov    %r14,%rsi
 124f70f:	e8 5c c0 00 00       	call   125b770 <myl_qbe_rc_frame_cleanup>
 124f714:	4c 39 b3 80 3d 00 00 	cmp    %r14,0x3d80(%rbx)
 124f71b:	0f 85 6b 01 00 00    	jne    124f88c <myl_f_fa0a495025828a635f8203a4c546663c235c2574b972f1294569bb6fadb2fcc2+0x54c>
 124f721:	48 8b 83 60 18 00 00 	mov    0x1860(%rbx),%rax
 124f728:	48 85 c0             	test   %rax,%rax
 124f72b:	0f 84 ea 00 00 00    	je     124f81b <myl_f_fa0a495025828a635f8203a4c546663c235c2574b972f1294569bb6fadb2fcc2+0x4db>
 124f731:	48 8b 40 70          	mov    0x70(%rax),%rax
 124f735:	48 3b 44 24 60       	cmp    0x60(%rsp),%rax
 124f73a:	0f 84 e4 00 00 00    	je     124f824 <myl_f_fa0a495025828a635f8203a4c546663c235c2574b972f1294569bb6fadb2fcc2+0x4e4>
 124f740:	e9 47 01 00 00       	jmp    124f88c <myl_f_fa0a495025828a635f8203a4c546663c235c2574b972f1294569bb6fadb2fcc2+0x54c>
 124f745:	48 85 c0             	test   %rax,%rax
 124f748:	0f 84 f7 00 00 00    	je     124f845 <myl_f_fa0a495025828a635f8203a4c546663c235c2574b972f1294569bb6fadb2fcc2+0x505>
 124f74e:	48 b9 01 00 00 00 00 	movabs $0x5000000000000001,%rcx
 124f755:	00 00 50 
 124f758:	48 85 48 f0          	test   %rcx,-0x10(%rax)
 124f75c:	0f 84 e3 00 00 00    	je     124f845 <myl_f_fa0a495025828a635f8203a4c546663c235c2574b972f1294569bb6fadb2fcc2+0x505>
 124f762:	48 8d 94 24 28 01 00 	lea    0x128(%rsp),%rdx
 124f769:	00 
 124f76a:	48 89 e1             	mov    %rsp,%rcx
 124f76d:	be d8 da 00 01       	mov    $0x100dad8,%esi
 124f772:	4c 89 ef             	mov    %r13,%rdi
 124f775:	41 89 e8             	mov    %ebp,%r8d
 124f778:	e8 03 f0 01 00       	call   126e780 <myl_rc_native_take>
 124f77d:	85 c0                	test   %eax,%eax
 124f77f:	0f 85 c8 00 00 00    	jne    124f84d <myl_f_fa0a495025828a635f8203a4c546663c235c2574b972f1294569bb6fadb2fcc2+0x50d>
 124f785:	48 8b 8b 60 18 00 00 	mov    0x1860(%rbx),%rcx
 124f78c:	48 85 c9             	test   %rcx,%rcx
 124f78f:	0f 84 f7 00 00 00    	je     124f88c <myl_f_fa0a495025828a635f8203a4c546663c235c2574b972f1294569bb6fadb2fcc2+0x54c>
 124f795:	8b 41 78             	mov    0x78(%rcx),%eax
 124f798:	c7 41 78 00 00 00 00 	movl   $0x0,0x78(%rcx)
 124f79f:	85 c0                	test   %eax,%eax
 124f7a1:	74 35                	je     124f7d8 <myl_f_fa0a495025828a635f8203a4c546663c235c2574b972f1294569bb6fadb2fcc2+0x498>
 124f7a3:	83 f8 01             	cmp    $0x1,%eax
 124f7a6:	75 15                	jne    124f7bd <myl_f_fa0a495025828a635f8203a4c546663c235c2574b972f1294569bb6fadb2fcc2+0x47d>
 124f7a8:	be fb 8e 00 01       	mov    $0x1008efb,%esi
 124f7ad:	83 bb c4 02 00 00 00 	cmpl   $0x0,0x2c4(%rbx)
 124f7b4:	75 1a                	jne    124f7d0 <myl_f_fa0a495025828a635f8203a4c546663c235c2574b972f1294569bb6fadb2fcc2+0x490>
 124f7b6:	b8 01 00 00 00       	mov    $0x1,%eax
 124f7bb:	eb 09                	jmp    124f7c6 <myl_f_fa0a495025828a635f8203a4c546663c235c2574b972f1294569bb6fadb2fcc2+0x486>
 124f7bd:	83 f8 04             	cmp    $0x4,%eax
 124f7c0:	0f 83 ce 00 00 00    	jae    124f894 <myl_f_fa0a495025828a635f8203a4c546663c235c2574b972f1294569bb6fadb2fcc2+0x554>
 124f7c6:	89 c0                	mov    %eax,%eax
 124f7c8:	48 8b 34 c5 c8 00 0b 	mov    0x10b00c8(,%rax,8),%rsi
 124f7cf:	01 
 124f7d0:	48 89 df             	mov    %rbx,%rdi
 124f7d3:	e8 98 cb 00 00       	call   125c370 <fail>
 124f7d8:	48 89 df             	mov    %rbx,%rdi
 124f7db:	4c 8d 74 24 48       	lea    0x48(%rsp),%r14
 124f7e0:	4c 89 f6             	mov    %r14,%rsi
 124f7e3:	e8 88 bf 00 00       	call   125b770 <myl_qbe_rc_frame_cleanup>
 124f7e8:	4c 39 b3 80 3d 00 00 	cmp    %r14,0x3d80(%rbx)
 124f7ef:	0f 85 97 00 00 00    	jne    124f88c <myl_f_fa0a495025828a635f8203a4c546663c235c2574b972f1294569bb6fadb2fcc2+0x54c>
 124f7f5:	48 8b 83 60 18 00 00 	mov    0x1860(%rbx),%rax
 124f7fc:	48 85 c0             	test   %rax,%rax
 124f7ff:	74 0d                	je     124f80e <myl_f_fa0a495025828a635f8203a4c546663c235c2574b972f1294569bb6fadb2fcc2+0x4ce>
 124f801:	48 8b 40 70          	mov    0x70(%rax),%rax
 124f805:	48 3b 44 24 60       	cmp    0x60(%rsp),%rax
 124f80a:	74 0b                	je     124f817 <myl_f_fa0a495025828a635f8203a4c546663c235c2574b972f1294569bb6fadb2fcc2+0x4d7>
 124f80c:	eb 7e                	jmp    124f88c <myl_f_fa0a495025828a635f8203a4c546663c235c2574b972f1294569bb6fadb2fcc2+0x54c>
 124f80e:	31 c0                	xor    %eax,%eax
 124f810:	48 3b 44 24 60       	cmp    0x60(%rsp),%rax
 124f815:	75 75                	jne    124f88c <myl_f_fa0a495025828a635f8203a4c546663c235c2574b972f1294569bb6fadb2fcc2+0x54c>
 124f817:	31 ed                	xor    %ebp,%ebp
 124f819:	eb 09                	jmp    124f824 <myl_f_fa0a495025828a635f8203a4c546663c235c2574b972f1294569bb6fadb2fcc2+0x4e4>
 124f81b:	31 c0                	xor    %eax,%eax
 124f81d:	48 3b 44 24 60       	cmp    0x60(%rsp),%rax
 124f822:	75 68                	jne    124f88c <myl_f_fa0a495025828a635f8203a4c546663c235c2574b972f1294569bb6fadb2fcc2+0x54c>
 124f824:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
 124f829:	48 89 83 80 3d 00 00 	mov    %rax,0x3d80(%rbx)
 124f830:	48 89 e8             	mov    %rbp,%rax
 124f833:	48 81 c4 a8 01 00 00 	add    $0x1a8,%rsp
 124f83a:	5b                   	pop    %rbx
 124f83b:	41 5c                	pop    %r12
 124f83d:	41 5d                	pop    %r13
 124f83f:	41 5e                	pop    %r14
 124f841:	41 5f                	pop    %r15
 124f843:	5d                   	pop    %rbp
 124f844:	c3                   	ret
 124f845:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
 124f84c:	00 
 124f84d:	c7 44 24 28 00 00 00 	movl   $0x0,0x28(%rsp)
 124f854:	00 
 124f855:	48 c7 84 24 e8 00 00 	movq   $0x100dad8,0xe8(%rsp)
 124f85c:	00 d8 da 00 01 
 124f861:	c7 84 24 00 01 00 00 	movl   $0x2,0x100(%rsp)
 124f868:	02 00 00 00 
 124f86c:	c7 44 24 30 01 00 00 	movl   $0x1,0x30(%rsp)
 124f873:	00 
 124f874:	4c 8d ac 24 88 00 00 	lea    0x88(%rsp),%r13
 124f87b:	00 
 124f87c:	83 7c 24 18 00       	cmpl   $0x0,0x18(%rsp)
 124f881:	0f 85 7c fd ff ff    	jne    124f603 <myl_f_fa0a495025828a635f8203a4c546663c235c2574b972f1294569bb6fadb2fcc2+0x2c3>
 124f887:	e9 82 fd ff ff       	jmp    124f60e <myl_f_fa0a495025828a635f8203a4c546663c235c2574b972f1294569bb6fadb2fcc2+0x2ce>
 124f88c:	c5 f8 77             	vzeroupper
 124f88f:	e8 0a 5f 01 00       	call   126579e <myl_rc_invariant_failed>
 124f894:	e8 77 37 02 00       	call   1273010 <abort@plt>
 124f899:	48 89 df             	mov    %rbx,%rdi
 124f89c:	48 89 c2             	mov    %rax,%rdx
 124f89f:	e8 bc d3 00 00       	call   125cc60 <myl_qbe_fail_normalized_index_bounds>
 124f8a4:	b9 01 00 00 00       	mov    $0x1,%ecx
 124f8a9:	48 89 df             	mov    %rbx,%rdi
 124f8ac:	31 f6                	xor    %esi,%esi
 124f8ae:	e8 7d d4 00 00       	call   125cd30 <myl_qbe_fail_overflow_op>
 124f8b3:	ba 40 01 00 00       	mov    $0x140,%edx
 124f8b8:	48 89 df             	mov    %rbx,%rdi
 124f8bb:	48 89 c6             	mov    %rax,%rsi
 124f8be:	e8 cd d4 00 00       	call   125cd90 <myl_qbe_fail_cast>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
