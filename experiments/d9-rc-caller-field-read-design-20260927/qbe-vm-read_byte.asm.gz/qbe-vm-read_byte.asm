
/home/epentland/ai/canopy/mylang-worktrees/d9-rc-mut-argument-astra/.tmp-mut-argument/field-list-read/proof-final-qbe-production:     file format elf64-x86-64


Disassembly of section .text:

00000000012c2bf0 <myl_f_fa0a495025828a635f8203a4c546663c235c2574b972f1294569bb6fadb2fcc2>:
 12c2bf0:	f3 0f 1e fa          	endbr64
 12c2bf4:	55                   	push   %rbp
 12c2bf5:	48 89 e5             	mov    %rsp,%rbp
 12c2bf8:	48 81 ec b8 01 00 00 	sub    $0x1b8,%rsp
 12c2bff:	53                   	push   %rbx
 12c2c00:	41 54                	push   %r12
 12c2c02:	41 55                	push   %r13
 12c2c04:	41 56                	push   %r14
 12c2c06:	41 57                	push   %r15
 12c2c08:	49 89 f5             	mov    %rsi,%r13
 12c2c0b:	48 89 fb             	mov    %rdi,%rbx
 12c2c0e:	48 c7 45 b8 00 00 00 	movq   $0x0,-0x48(%rbp)
 12c2c15:	00 
 12c2c16:	48 89 df             	mov    %rbx,%rdi
 12c2c19:	e8 92 86 00 00       	call   12cb2b0 <myl_qbe_heap>
 12c2c1e:	48 89 c7             	mov    %rax,%rdi
 12c2c21:	49 89 fc             	mov    %rdi,%r12
 12c2c24:	48 89 df             	mov    %rbx,%rdi
 12c2c27:	e8 a4 b0 00 00       	call   12cdcd0 <myl_qbe_region_mark>
 12c2c2c:	4c 89 e7             	mov    %r12,%rdi
 12c2c2f:	48 89 45 f8          	mov    %rax,-0x8(%rbp)
 12c2c33:	ba 30 00 00 00       	mov    $0x30,%edx
 12c2c38:	be 00 00 00 00       	mov    $0x0,%esi
 12c2c3d:	49 89 fc             	mov    %rdi,%r12
 12c2c40:	48 8d bd 30 ff ff ff 	lea    -0xd0(%rbp),%rdi
 12c2c47:	e8 c4 f6 01 00       	call   12e2310 <compiler_rt.fastMemset>
 12c2c4c:	4c 89 e7             	mov    %r12,%rdi
 12c2c4f:	48 8d 05 62 82 0f 00 	lea    0xf8262(%rip),%rax        # 13baeb8 <myl_t_c000f22f7ee44dea31e81b0a933c1dec3a560f42212434ae24333c6a58c466f9>
 12c2c56:	48 89 85 70 fe ff ff 	mov    %rax,-0x190(%rbp)
 12c2c5d:	c7 85 88 fe ff ff 02 	movl   $0x2,-0x178(%rbp)
 12c2c64:	00 00 00 
 12c2c67:	4c 89 ad 78 fe ff ff 	mov    %r13,-0x188(%rbp)
 12c2c6e:	48 8d 85 30 ff ff ff 	lea    -0xd0(%rbp),%rax
 12c2c75:	48 89 85 80 fe ff ff 	mov    %rax,-0x180(%rbp)
 12c2c7c:	48 8d 85 70 fe ff ff 	lea    -0x190(%rbp),%rax
 12c2c83:	48 89 c6             	mov    %rax,%rsi
 12c2c86:	48 83 c6 20          	add    $0x20,%rsi
 12c2c8a:	48 8d 05 d7 56 0f 00 	lea    0xf56d7(%rip),%rax        # 13b8368 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527>
 12c2c91:	48 89 85 90 fe ff ff 	mov    %rax,-0x170(%rbp)
 12c2c98:	c7 85 a8 fe ff ff 02 	movl   $0x2,-0x158(%rbp)
 12c2c9f:	00 00 00 
 12c2ca2:	48 8d 45 b8          	lea    -0x48(%rbp),%rax
 12c2ca6:	48 89 85 98 fe ff ff 	mov    %rax,-0x168(%rbp)
 12c2cad:	48 8d 85 30 ff ff ff 	lea    -0xd0(%rbp),%rax
 12c2cb4:	49 89 c4             	mov    %rax,%r12
 12c2cb7:	49 83 c4 08          	add    $0x8,%r12
 12c2cbb:	4c 89 65 f0          	mov    %r12,-0x10(%rbp)
 12c2cbf:	4c 89 a5 a0 fe ff ff 	mov    %r12,-0x160(%rbp)
 12c2cc6:	48 8d 05 eb 81 0f 00 	lea    0xf81eb(%rip),%rax        # 13baeb8 <myl_t_c000f22f7ee44dea31e81b0a933c1dec3a560f42212434ae24333c6a58c466f9>
 12c2ccd:	48 89 85 b0 fe ff ff 	mov    %rax,-0x150(%rbp)
 12c2cd4:	c7 85 c8 fe ff ff 02 	movl   $0x2,-0x138(%rbp)
 12c2cdb:	00 00 00 
 12c2cde:	48 8d 45 c0          	lea    -0x40(%rbp),%rax
 12c2ce2:	48 89 85 b8 fe ff ff 	mov    %rax,-0x148(%rbp)
 12c2ce9:	48 8d 85 30 ff ff ff 	lea    -0xd0(%rbp),%rax
 12c2cf0:	48 83 c0 10          	add    $0x10,%rax
 12c2cf4:	48 89 85 c0 fe ff ff 	mov    %rax,-0x140(%rbp)
 12c2cfb:	48 8d 85 70 fe ff ff 	lea    -0x190(%rbp),%rax
 12c2d02:	49 89 c6             	mov    %rax,%r14
 12c2d05:	49 83 c6 60          	add    $0x60,%r14
 12c2d09:	48 8d 05 a0 4d d9 ff 	lea    -0x26b260(%rip),%rax        # 1057ab0 <myl_t_385cfdbc00ec32031699460779c15099b2bba3cad0e440fffb08e10df0acb9e1>
 12c2d10:	48 89 85 d0 fe ff ff 	mov    %rax,-0x130(%rbp)
 12c2d17:	c7 85 e8 fe ff ff 00 	movl   $0x0,-0x118(%rbp)
 12c2d1e:	00 00 00 
 12c2d21:	48 8d 85 60 ff ff ff 	lea    -0xa0(%rbp),%rax
 12c2d28:	48 89 85 d8 fe ff ff 	mov    %rax,-0x128(%rbp)
 12c2d2f:	48 8d 85 30 ff ff ff 	lea    -0xd0(%rbp),%rax
 12c2d36:	48 83 c0 18          	add    $0x18,%rax
 12c2d3a:	48 89 85 e0 fe ff ff 	mov    %rax,-0x120(%rbp)
 12c2d41:	48 8d 05 68 4d d9 ff 	lea    -0x26b298(%rip),%rax        # 1057ab0 <myl_t_385cfdbc00ec32031699460779c15099b2bba3cad0e440fffb08e10df0acb9e1>
 12c2d48:	48 89 85 f0 fe ff ff 	mov    %rax,-0x110(%rbp)
 12c2d4f:	c7 85 08 ff ff ff 00 	movl   $0x0,-0xf8(%rbp)
 12c2d56:	00 00 00 
 12c2d59:	48 8d 45 88          	lea    -0x78(%rbp),%rax
 12c2d5d:	48 89 85 f8 fe ff ff 	mov    %rax,-0x108(%rbp)
 12c2d64:	48 8d 85 30 ff ff ff 	lea    -0xd0(%rbp),%rax
 12c2d6b:	48 83 c0 20          	add    $0x20,%rax
 12c2d6f:	48 89 85 00 ff ff ff 	mov    %rax,-0x100(%rbp)
 12c2d76:	48 8d 05 33 4d d9 ff 	lea    -0x26b2cd(%rip),%rax        # 1057ab0 <myl_t_385cfdbc00ec32031699460779c15099b2bba3cad0e440fffb08e10df0acb9e1>
 12c2d7d:	48 89 85 10 ff ff ff 	mov    %rax,-0xf0(%rbp)
 12c2d84:	c7 85 28 ff ff ff 00 	movl   $0x0,-0xd8(%rbp)
 12c2d8b:	00 00 00 
 12c2d8e:	48 8d 45 b0          	lea    -0x50(%rbp),%rax
 12c2d92:	48 89 85 18 ff ff ff 	mov    %rax,-0xe8(%rbp)
 12c2d99:	48 8d 85 30 ff ff ff 	lea    -0xd0(%rbp),%rax
 12c2da0:	48 83 c0 28          	add    $0x28,%rax
 12c2da4:	48 89 85 20 ff ff ff 	mov    %rax,-0xe0(%rbp)
 12c2dab:	b9 06 00 00 00       	mov    $0x6,%ecx
 12c2db0:	48 8d 95 70 fe ff ff 	lea    -0x190(%rbp),%rdx
 12c2db7:	49 89 f7             	mov    %rsi,%r15
 12c2dba:	48 8d b5 50 fe ff ff 	lea    -0x1b0(%rbp),%rsi
 12c2dc1:	49 89 fc             	mov    %rdi,%r12
 12c2dc4:	48 89 df             	mov    %rbx,%rdi
 12c2dc7:	e8 54 74 00 00       	call   12ca220 <myl_qbe_rc_frame_enter>
 12c2dcc:	4c 89 fe             	mov    %r15,%rsi
 12c2dcf:	4c 89 e7             	mov    %r12,%rdi
 12c2dd2:	4c 89 6d e8          	mov    %r13,-0x18(%rbp)
 12c2dd6:	49 8b 45 08          	mov    0x8(%r13),%rax
 12c2dda:	48 89 45 e8          	mov    %rax,-0x18(%rbp)
 12c2dde:	48 8d 4d e8          	lea    -0x18(%rbp),%rcx
 12c2de2:	48 8d 55 88          	lea    -0x78(%rbp),%rdx
 12c2de6:	49 89 f7             	mov    %rsi,%r15
 12c2de9:	48 8d 35 78 55 0f 00 	lea    0xf5578(%rip),%rsi        # 13b8368 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527>
 12c2df0:	49 89 fc             	mov    %rdi,%r12
 12c2df3:	e8 f8 ea 01 00       	call   12e18f0 <myl_rc_native_loan>
 12c2df8:	4c 89 fe             	mov    %r15,%rsi
 12c2dfb:	4c 89 e7             	mov    %r12,%rdi
 12c2dfe:	4c 8b 65 f0          	mov    -0x10(%rbp),%r12
 12c2e02:	4c 8b 45 f8          	mov    -0x8(%rbp),%r8
 12c2e06:	83 f8 00             	cmp    $0x0,%eax
 12c2e09:	75 1a                	jne    12c2e25 <myl_f_fa0a495025828a635f8203a4c546663c235c2574b972f1294569bb6fadb2fcc2+0x235>
 12c2e0b:	e8 20 67 01 00       	call   12d9530 <myl_rc_take_failure>
 12c2e10:	48 89 df             	mov    %rbx,%rdi
 12c2e13:	89 c6                	mov    %eax,%esi
 12c2e15:	48 89 fb             	mov    %rdi,%rbx
 12c2e18:	e8 13 73 00 00       	call   12ca130 <myl_qbe_rc_status>
 12c2e1d:	48 89 df             	mov    %rbx,%rdi
 12c2e20:	e9 0c 02 00 00       	jmp    12c3031 <myl_f_fa0a495025828a635f8203a4c546663c235c2574b972f1294569bb6fadb2fcc2+0x441>
 12c2e25:	48 8d 05 3c 55 0f 00 	lea    0xf553c(%rip),%rax        # 13b8368 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527>
 12c2e2c:	48 89 85 f0 fe ff ff 	mov    %rax,-0x110(%rbp)
 12c2e33:	c7 85 08 ff ff ff 02 	movl   $0x2,-0xf8(%rbp)
 12c2e3a:	00 00 00 
 12c2e3d:	c7 85 08 ff ff ff 10 	movl   $0x10,-0xf8(%rbp)
 12c2e44:	00 00 00 
 12c2e47:	c7 85 50 ff ff ff 01 	movl   $0x1,-0xb0(%rbp)
 12c2e4e:	00 00 00 
 12c2e51:	8b 85 48 ff ff ff    	mov    -0xb8(%rbp),%eax
 12c2e57:	83 f8 00             	cmp    $0x0,%eax
 12c2e5a:	74 1f                	je     12c2e7b <myl_f_fa0a495025828a635f8203a4c546663c235c2574b972f1294569bb6fadb2fcc2+0x28b>
 12c2e5c:	49 89 f7             	mov    %rsi,%r15
 12c2e5f:	4c 89 f6             	mov    %r14,%rsi
 12c2e62:	49 89 fc             	mov    %rdi,%r12
 12c2e65:	48 89 df             	mov    %rbx,%rdi
 12c2e68:	e8 93 74 00 00       	call   12ca300 <myl_qbe_rc_slot_drop>
 12c2e6d:	4c 89 fe             	mov    %r15,%rsi
 12c2e70:	4c 89 e7             	mov    %r12,%rdi
 12c2e73:	4c 8b 65 f0          	mov    -0x10(%rbp),%r12
 12c2e77:	4c 8b 45 f8          	mov    -0x8(%rbp),%r8
 12c2e7b:	48 8b 45 88          	mov    -0x78(%rbp),%rax
 12c2e7f:	48 89 85 60 ff ff ff 	mov    %rax,-0xa0(%rbp)
 12c2e86:	48 8d 05 db 54 0f 00 	lea    0xf54db(%rip),%rax        # 13b8368 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527>
 12c2e8d:	48 89 85 d0 fe ff ff 	mov    %rax,-0x130(%rbp)
 12c2e94:	c7 85 e8 fe ff ff 02 	movl   $0x2,-0x118(%rbp)
 12c2e9b:	00 00 00 
 12c2e9e:	8b 8d 08 ff ff ff    	mov    -0xf8(%rbp),%ecx
 12c2ea4:	89 8d e8 fe ff ff    	mov    %ecx,-0x118(%rbp)
 12c2eaa:	c7 85 50 ff ff ff 00 	movl   $0x0,-0xb0(%rbp)
 12c2eb1:	00 00 00 
 12c2eb4:	c7 85 48 ff ff ff 01 	movl   $0x1,-0xb8(%rbp)
 12c2ebb:	00 00 00 
 12c2ebe:	48 8b 85 60 ff ff ff 	mov    -0xa0(%rbp),%rax
 12c2ec5:	48 89 45 e8          	mov    %rax,-0x18(%rbp)
 12c2ec9:	83 e1 18             	and    $0x18,%ecx
 12c2ecc:	83 f9 00             	cmp    $0x0,%ecx
 12c2ecf:	0f 84 99 00 00 00    	je     12c2f6e <myl_f_fa0a495025828a635f8203a4c546663c235c2574b972f1294569bb6fadb2fcc2+0x37e>
 12c2ed5:	48 8d 4d e8          	lea    -0x18(%rbp),%rcx
 12c2ed9:	48 8d 55 88          	lea    -0x78(%rbp),%rdx
 12c2edd:	49 89 f7             	mov    %rsi,%r15
 12c2ee0:	48 8d 35 81 54 0f 00 	lea    0xf5481(%rip),%rsi        # 13b8368 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527>
 12c2ee7:	49 89 fc             	mov    %rdi,%r12
 12c2eea:	e8 01 ea 01 00       	call   12e18f0 <myl_rc_native_loan>
 12c2eef:	4c 89 fe             	mov    %r15,%rsi
 12c2ef2:	4c 89 e7             	mov    %r12,%rdi
 12c2ef5:	4c 8b 65 f0          	mov    -0x10(%rbp),%r12
 12c2ef9:	83 f8 00             	cmp    $0x0,%eax
 12c2efc:	75 1a                	jne    12c2f18 <myl_f_fa0a495025828a635f8203a4c546663c235c2574b972f1294569bb6fadb2fcc2+0x328>
 12c2efe:	e8 2d 66 01 00       	call   12d9530 <myl_rc_take_failure>
 12c2f03:	48 89 df             	mov    %rbx,%rdi
 12c2f06:	89 c6                	mov    %eax,%esi
 12c2f08:	48 89 fb             	mov    %rdi,%rbx
 12c2f0b:	e8 20 72 00 00       	call   12ca130 <myl_qbe_rc_status>
 12c2f10:	48 89 df             	mov    %rbx,%rdi
 12c2f13:	e9 19 01 00 00       	jmp    12c3031 <myl_f_fa0a495025828a635f8203a4c546663c235c2574b972f1294569bb6fadb2fcc2+0x441>
 12c2f18:	48 89 df             	mov    %rbx,%rdi
 12c2f1b:	48 8d 05 46 54 0f 00 	lea    0xf5446(%rip),%rax        # 13b8368 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527>
 12c2f22:	48 89 85 f0 fe ff ff 	mov    %rax,-0x110(%rbp)
 12c2f29:	c7 85 08 ff ff ff 02 	movl   $0x2,-0xf8(%rbp)
 12c2f30:	00 00 00 
 12c2f33:	c7 85 08 ff ff ff 10 	movl   $0x10,-0xf8(%rbp)
 12c2f3a:	00 00 00 
 12c2f3d:	c7 85 50 ff ff ff 01 	movl   $0x1,-0xb0(%rbp)
 12c2f44:	00 00 00 
 12c2f47:	8b 85 48 ff ff ff    	mov    -0xb8(%rbp),%eax
 12c2f4d:	83 f8 00             	cmp    $0x0,%eax
 12c2f50:	74 14                	je     12c2f66 <myl_f_fa0a495025828a635f8203a4c546663c235c2574b972f1294569bb6fadb2fcc2+0x376>
 12c2f52:	49 89 f7             	mov    %rsi,%r15
 12c2f55:	4c 89 f6             	mov    %r14,%rsi
 12c2f58:	48 89 fb             	mov    %rdi,%rbx
 12c2f5b:	e8 a0 73 00 00       	call   12ca300 <myl_qbe_rc_slot_drop>
 12c2f60:	4c 89 fe             	mov    %r15,%rsi
 12c2f63:	48 89 df             	mov    %rbx,%rdi
 12c2f66:	4c 89 e3             	mov    %r12,%rbx
 12c2f69:	e9 1d 01 00 00       	jmp    12c308b <myl_f_fa0a495025828a635f8203a4c546663c235c2574b972f1294569bb6fadb2fcc2+0x49b>
 12c2f6e:	48 87 df             	xchg   %rbx,%rdi
 12c2f71:	48 8d 55 88          	lea    -0x78(%rbp),%rdx
 12c2f75:	48 8d 4d e8          	lea    -0x18(%rbp),%rcx
 12c2f79:	48 29 d1             	sub    %rdx,%rcx
 12c2f7c:	4c 8d 4d e8          	lea    -0x18(%rbp),%r9
 12c2f80:	48 8d 55 88          	lea    -0x78(%rbp),%rdx
 12c2f84:	4c 29 ca             	sub    %r9,%rdx
 12c2f87:	48 83 f9 08          	cmp    $0x8,%rcx
 12c2f8b:	0f 92 c1             	setb   %cl
 12c2f8e:	0f b6 c9             	movzbl %cl,%ecx
 12c2f91:	48 83 fa 08          	cmp    $0x8,%rdx
 12c2f95:	0f 92 c2             	setb   %dl
 12c2f98:	0f b6 d2             	movzbl %dl,%edx
 12c2f9b:	09 d1                	or     %edx,%ecx
 12c2f9d:	75 51                	jne    12c2ff0 <myl_f_fa0a495025828a635f8203a4c546663c235c2574b972f1294569bb6fadb2fcc2+0x400>
 12c2f9f:	48 83 f8 00          	cmp    $0x0,%rax
 12c2fa3:	74 1a                	je     12c2fbf <myl_f_fa0a495025828a635f8203a4c546663c235c2574b972f1294569bb6fadb2fcc2+0x3cf>
 12c2fa5:	48 83 e8 10          	sub    $0x10,%rax
 12c2fa9:	48 8b 00             	mov    (%rax),%rax
 12c2fac:	48 b9 01 00 00 00 00 	movabs $0x5000000000000001,%rcx
 12c2fb3:	00 00 50 
 12c2fb6:	48 21 c8             	and    %rcx,%rax
 12c2fb9:	48 83 f8 00          	cmp    $0x0,%rax
 12c2fbd:	75 2c                	jne    12c2feb <myl_f_fa0a495025828a635f8203a4c546663c235c2574b972f1294569bb6fadb2fcc2+0x3fb>
 12c2fbf:	48 8b 45 e8          	mov    -0x18(%rbp),%rax
 12c2fc3:	48 89 45 88          	mov    %rax,-0x78(%rbp)
 12c2fc7:	ba 08 00 00 00       	mov    $0x8,%edx
 12c2fcc:	49 89 f7             	mov    %rsi,%r15
 12c2fcf:	be 00 00 00 00       	mov    $0x0,%esi
 12c2fd4:	48 89 fb             	mov    %rdi,%rbx
 12c2fd7:	48 8d 7d e8          	lea    -0x18(%rbp),%rdi
 12c2fdb:	e8 30 f3 01 00       	call   12e2310 <compiler_rt.fastMemset>
 12c2fe0:	4c 89 fe             	mov    %r15,%rsi
 12c2fe3:	48 89 df             	mov    %rbx,%rdi
 12c2fe6:	4c 89 e3             	mov    %r12,%rbx
 12c2fe9:	eb 74                	jmp    12c305f <myl_f_fa0a495025828a635f8203a4c546663c235c2574b972f1294569bb6fadb2fcc2+0x46f>
 12c2feb:	48 87 fb             	xchg   %rdi,%rbx
 12c2fee:	eb 03                	jmp    12c2ff3 <myl_f_fa0a495025828a635f8203a4c546663c235c2574b972f1294569bb6fadb2fcc2+0x403>
 12c2ff0:	48 87 fb             	xchg   %rdi,%rbx
 12c2ff3:	48 8d 4d e8          	lea    -0x18(%rbp),%rcx
 12c2ff7:	48 8d 55 88          	lea    -0x78(%rbp),%rdx
 12c2ffb:	49 89 f7             	mov    %rsi,%r15
 12c2ffe:	48 8d 35 63 53 0f 00 	lea    0xf5363(%rip),%rsi        # 13b8368 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527>
 12c3005:	49 89 fc             	mov    %rdi,%r12
 12c3008:	e8 13 e6 01 00       	call   12e1620 <myl_rc_native_take>
 12c300d:	4c 89 fe             	mov    %r15,%rsi
 12c3010:	4c 89 e7             	mov    %r12,%rdi
 12c3013:	4c 8b 65 f0          	mov    -0x10(%rbp),%r12
 12c3017:	83 f8 00             	cmp    $0x0,%eax
 12c301a:	75 3d                	jne    12c3059 <myl_f_fa0a495025828a635f8203a4c546663c235c2574b972f1294569bb6fadb2fcc2+0x469>
 12c301c:	e8 0f 65 01 00       	call   12d9530 <myl_rc_take_failure>
 12c3021:	48 89 df             	mov    %rbx,%rdi
 12c3024:	89 c6                	mov    %eax,%esi
 12c3026:	48 89 fb             	mov    %rdi,%rbx
 12c3029:	e8 02 71 00 00       	call   12ca130 <myl_qbe_rc_status>
 12c302e:	48 89 df             	mov    %rbx,%rdi
 12c3031:	48 8d b5 50 fe ff ff 	lea    -0x1b0(%rbp),%rsi
 12c3038:	48 89 fb             	mov    %rdi,%rbx
 12c303b:	e8 f0 73 00 00       	call   12ca430 <myl_qbe_rc_frame_cleanup>
 12c3040:	48 89 df             	mov    %rbx,%rdi
 12c3043:	48 8d b5 50 fe ff ff 	lea    -0x1b0(%rbp),%rsi
 12c304a:	e8 51 72 00 00       	call   12ca2a0 <myl_qbe_rc_frame_leave>
 12c304f:	b8 00 00 00 00       	mov    $0x0,%eax
 12c3054:	e9 14 02 00 00       	jmp    12c326d <myl_f_fa0a495025828a635f8203a4c546663c235c2574b972f1294569bb6fadb2fcc2+0x67d>
 12c3059:	48 89 df             	mov    %rbx,%rdi
 12c305c:	4c 89 e3             	mov    %r12,%rbx
 12c305f:	c7 85 48 ff ff ff 00 	movl   $0x0,-0xb8(%rbp)
 12c3066:	00 00 00 
 12c3069:	48 8d 05 f8 52 0f 00 	lea    0xf52f8(%rip),%rax        # 13b8368 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527>
 12c3070:	48 89 85 f0 fe ff ff 	mov    %rax,-0x110(%rbp)
 12c3077:	c7 85 08 ff ff ff 02 	movl   $0x2,-0xf8(%rbp)
 12c307e:	00 00 00 
 12c3081:	c7 85 50 ff ff ff 01 	movl   $0x1,-0xb0(%rbp)
 12c3088:	00 00 00 
 12c308b:	8b 85 38 ff ff ff    	mov    -0xc8(%rbp),%eax
 12c3091:	83 f8 00             	cmp    $0x0,%eax
 12c3094:	74 11                	je     12c30a7 <myl_f_fa0a495025828a635f8203a4c546663c235c2574b972f1294569bb6fadb2fcc2+0x4b7>
 12c3096:	49 89 f7             	mov    %rsi,%r15
 12c3099:	49 89 fc             	mov    %rdi,%r12
 12c309c:	e8 5f 72 00 00       	call   12ca300 <myl_qbe_rc_slot_drop>
 12c30a1:	4c 89 fe             	mov    %r15,%rsi
 12c30a4:	4c 89 e7             	mov    %r12,%rdi
 12c30a7:	48 8b 45 88          	mov    -0x78(%rbp),%rax
 12c30ab:	48 89 45 b8          	mov    %rax,-0x48(%rbp)
 12c30af:	c7 85 50 ff ff ff 00 	movl   $0x0,-0xb0(%rbp)
 12c30b6:	00 00 00 
 12c30b9:	48 8d 05 a8 52 0f 00 	lea    0xf52a8(%rip),%rax        # 13b8368 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527>
 12c30c0:	48 89 85 90 fe ff ff 	mov    %rax,-0x170(%rbp)
 12c30c7:	c7 85 a8 fe ff ff 02 	movl   $0x2,-0x158(%rbp)
 12c30ce:	00 00 00 
 12c30d1:	48 8d 45 b8          	lea    -0x48(%rbp),%rax
 12c30d5:	48 89 85 98 fe ff ff 	mov    %rax,-0x168(%rbp)
 12c30dc:	48 89 9d a0 fe ff ff 	mov    %rbx,-0x160(%rbp)
 12c30e3:	8b 85 08 ff ff ff    	mov    -0xf8(%rbp),%eax
 12c30e9:	89 85 a8 fe ff ff    	mov    %eax,-0x158(%rbp)
 12c30ef:	c7 85 38 ff ff ff 01 	movl   $0x1,-0xc8(%rbp)
 12c30f6:	00 00 00 
 12c30f9:	4c 89 6d e8          	mov    %r13,-0x18(%rbp)
 12c30fd:	49 8b 45 18          	mov    0x18(%r13),%rax
 12c3101:	48 89 45 e8          	mov    %rax,-0x18(%rbp)
 12c3105:	8b 85 48 ff ff ff    	mov    -0xb8(%rbp),%eax
 12c310b:	83 f8 00             	cmp    $0x0,%eax
 12c310e:	74 14                	je     12c3124 <myl_f_fa0a495025828a635f8203a4c546663c235c2574b972f1294569bb6fadb2fcc2+0x534>
 12c3110:	49 89 f4             	mov    %rsi,%r12
 12c3113:	4c 89 f6             	mov    %r14,%rsi
 12c3116:	48 89 fb             	mov    %rdi,%rbx
 12c3119:	e8 e2 71 00 00       	call   12ca300 <myl_qbe_rc_slot_drop>
 12c311e:	4c 89 e6             	mov    %r12,%rsi
 12c3121:	48 89 df             	mov    %rbx,%rdi
 12c3124:	48 8b 4d e8          	mov    -0x18(%rbp),%rcx
 12c3128:	48 89 4d e8          	mov    %rcx,-0x18(%rbp)
 12c312c:	48 83 f9 00          	cmp    $0x0,%rcx
 12c3130:	0f 9c c0             	setl   %al
 12c3133:	48 0f b6 c0          	movzbq %al,%rax
 12c3137:	48 89 45 e8          	mov    %rax,-0x18(%rbp)
 12c313b:	7d 4e                	jge    12c318b <myl_f_fa0a495025828a635f8203a4c546663c235c2574b972f1294569bb6fadb2fcc2+0x59b>
 12c313d:	48 8b 45 b8          	mov    -0x48(%rbp),%rax
 12c3141:	48 89 f3             	mov    %rsi,%rbx
 12c3144:	48 8b 30             	mov    (%rax),%rsi
 12c3147:	48 89 75 e8          	mov    %rsi,-0x18(%rbp)
 12c314b:	48 b8 ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rax
 12c3152:	ff ff 7f 
 12c3155:	48 39 c6             	cmp    %rax,%rsi
 12c3158:	0f 87 46 01 00 00    	ja     12c32a4 <myl_f_fa0a495025828a635f8203a4c546663c235c2574b972f1294569bb6fadb2fcc2+0x6b4>
 12c315e:	48 89 75 e8          	mov    %rsi,-0x18(%rbp)
 12c3162:	48 89 c8             	mov    %rcx,%rax
 12c3165:	48 01 f0             	add    %rsi,%rax
 12c3168:	48 89 f2             	mov    %rsi,%rdx
 12c316b:	48 31 c2             	xor    %rax,%rdx
 12c316e:	49 89 c8             	mov    %rcx,%r8
 12c3171:	49 31 c0             	xor    %rax,%r8
 12c3174:	4c 21 c2             	and    %r8,%rdx
 12c3177:	48 83 fa 00          	cmp    $0x0,%rdx
 12c317b:	0f 8c 0e 01 00 00    	jl     12c328f <myl_f_fa0a495025828a635f8203a4c546663c235c2574b972f1294569bb6fadb2fcc2+0x69f>
 12c3181:	48 89 c1             	mov    %rax,%rcx
 12c3184:	48 89 de             	mov    %rbx,%rsi
 12c3187:	48 89 4d e8          	mov    %rcx,-0x18(%rbp)
 12c318b:	48 89 4d e8          	mov    %rcx,-0x18(%rbp)
 12c318f:	48 8b 45 b8          	mov    -0x48(%rbp),%rax
 12c3193:	48 8b 10             	mov    (%rax),%rdx
 12c3196:	48 39 d1             	cmp    %rdx,%rcx
 12c3199:	72 0a                	jb     12c31a5 <myl_f_fa0a495025828a635f8203a4c546663c235c2574b972f1294569bb6fadb2fcc2+0x5b5>
 12c319b:	48 89 ce             	mov    %rcx,%rsi
 12c319e:	e8 2d 7d 00 00       	call   12caed0 <myl_qbe_fail_normalized_index_bounds>
 12c31a3:	0f 0b                	ud2
 12c31a5:	48 8b 40 20          	mov    0x20(%rax),%rax
 12c31a9:	48 8b 04 c8          	mov    (%rax,%rcx,8),%rax
 12c31ad:	48 89 45 e8          	mov    %rax,-0x18(%rbp)
 12c31b1:	48 89 c3             	mov    %rax,%rbx
 12c31b4:	8b 85 38 ff ff ff    	mov    -0xc8(%rbp),%eax
 12c31ba:	83 f8 00             	cmp    $0x0,%eax
 12c31bd:	75 08                	jne    12c31c7 <myl_f_fa0a495025828a635f8203a4c546663c235c2574b972f1294569bb6fadb2fcc2+0x5d7>
 12c31bf:	48 89 d8             	mov    %rbx,%rax
 12c31c2:	4c 89 f6             	mov    %r14,%rsi
 12c31c5:	eb 11                	jmp    12c31d8 <myl_f_fa0a495025828a635f8203a4c546663c235c2574b972f1294569bb6fadb2fcc2+0x5e8>
 12c31c7:	49 89 fc             	mov    %rdi,%r12
 12c31ca:	e8 31 71 00 00       	call   12ca300 <myl_qbe_rc_slot_drop>
 12c31cf:	4c 89 f6             	mov    %r14,%rsi
 12c31d2:	4c 89 e7             	mov    %r12,%rdi
 12c31d5:	48 89 d8             	mov    %rbx,%rax
 12c31d8:	4c 89 6d e8          	mov    %r13,-0x18(%rbp)
 12c31dc:	49 8b 4d 18          	mov    0x18(%r13),%rcx
 12c31e0:	48 89 4d e8          	mov    %rcx,-0x18(%rbp)
 12c31e4:	48 89 c3             	mov    %rax,%rbx
 12c31e7:	8b 85 48 ff ff ff    	mov    -0xb8(%rbp),%eax
 12c31ed:	83 f8 00             	cmp    $0x0,%eax
 12c31f0:	75 08                	jne    12c31fa <myl_f_fa0a495025828a635f8203a4c546663c235c2574b972f1294569bb6fadb2fcc2+0x60a>
 12c31f2:	48 89 d8             	mov    %rbx,%rax
 12c31f5:	4c 89 ee             	mov    %r13,%rsi
 12c31f8:	eb 11                	jmp    12c320b <myl_f_fa0a495025828a635f8203a4c546663c235c2574b972f1294569bb6fadb2fcc2+0x61b>
 12c31fa:	49 89 fc             	mov    %rdi,%r12
 12c31fd:	e8 fe 70 00 00       	call   12ca300 <myl_qbe_rc_slot_drop>
 12c3202:	4c 89 ee             	mov    %r13,%rsi
 12c3205:	4c 89 e7             	mov    %r12,%rdi
 12c3208:	48 89 d8             	mov    %rbx,%rax
 12c320b:	48 8b 55 e8          	mov    -0x18(%rbp),%rdx
 12c320f:	48 b9 fe ff ff ff ff 	movabs $0x7ffffffffffffffe,%rcx
 12c3216:	ff ff 7f 
 12c3219:	48 39 ca             	cmp    %rcx,%rdx
 12c321c:	7f 5a                	jg     12c3278 <myl_f_fa0a495025828a635f8203a4c546663c235c2574b972f1294569bb6fadb2fcc2+0x688>
 12c321e:	48 89 c3             	mov    %rax,%rbx
 12c3221:	48 89 d0             	mov    %rdx,%rax
 12c3224:	48 83 c0 01          	add    $0x1,%rax
 12c3228:	48 89 45 e8          	mov    %rax,-0x18(%rbp)
 12c322c:	48 89 75 e8          	mov    %rsi,-0x18(%rbp)
 12c3230:	48 89 75 e8          	mov    %rsi,-0x18(%rbp)
 12c3234:	48 89 75 e8          	mov    %rsi,-0x18(%rbp)
 12c3238:	48 89 75 e8          	mov    %rsi,-0x18(%rbp)
 12c323c:	48 89 46 18          	mov    %rax,0x18(%rsi)
 12c3240:	48 c7 45 e8 00 00 00 	movq   $0x0,-0x18(%rbp)
 12c3247:	00 
 12c3248:	48 89 5d e8          	mov    %rbx,-0x18(%rbp)
 12c324c:	48 8d b5 50 fe ff ff 	lea    -0x1b0(%rbp),%rsi
 12c3253:	49 89 fc             	mov    %rdi,%r12
 12c3256:	e8 d5 71 00 00       	call   12ca430 <myl_qbe_rc_frame_cleanup>
 12c325b:	4c 89 e7             	mov    %r12,%rdi
 12c325e:	48 8d b5 50 fe ff ff 	lea    -0x1b0(%rbp),%rsi
 12c3265:	e8 36 70 00 00       	call   12ca2a0 <myl_qbe_rc_frame_leave>
 12c326a:	48 89 d8             	mov    %rbx,%rax
 12c326d:	41 5f                	pop    %r15
 12c326f:	41 5e                	pop    %r14
 12c3271:	41 5d                	pop    %r13
 12c3273:	41 5c                	pop    %r12
 12c3275:	5b                   	pop    %rbx
 12c3276:	c9                   	leave
 12c3277:	c3                   	ret
 12c3278:	41 b8 40 00 00 00    	mov    $0x40,%r8d
 12c327e:	b9 01 00 00 00       	mov    $0x1,%ecx
 12c3283:	be 00 00 00 00       	mov    $0x0,%esi
 12c3288:	e8 63 7e 00 00       	call   12cb0f0 <myl_qbe_fail_overflow_op>
 12c328d:	0f 0b                	ud2
 12c328f:	41 b8 40 00 00 00    	mov    $0x40,%r8d
 12c3295:	48 89 f2             	mov    %rsi,%rdx
 12c3298:	be 00 00 00 00       	mov    $0x0,%esi
 12c329d:	e8 4e 7e 00 00       	call   12cb0f0 <myl_qbe_fail_overflow_op>
 12c32a2:	0f 0b                	ud2
 12c32a4:	ba 40 01 00 00       	mov    $0x140,%edx
 12c32a9:	e8 82 7f 00 00       	call   12cb230 <myl_qbe_fail_cast>
 12c32ae:	0f 0b                	ud2

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
