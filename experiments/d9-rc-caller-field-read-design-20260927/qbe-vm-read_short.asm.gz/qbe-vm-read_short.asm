
/home/epentland/ai/canopy/mylang-worktrees/d9-rc-mut-argument-astra/.tmp-mut-argument/field-list-read/proof-final-qbe-production:     file format elf64-x86-64


Disassembly of section .text:

0000000001290230 <myl_f_22849c51a4fd631aa66144da38552fb710206c5e57b8268459a8dc3a6dbcd390>:
 1290230:	f3 0f 1e fa          	endbr64
 1290234:	55                   	push   %rbp
 1290235:	48 89 e5             	mov    %rsp,%rbp
 1290238:	48 81 ec 68 02 00 00 	sub    $0x268,%rsp
 129023f:	53                   	push   %rbx
 1290240:	41 54                	push   %r12
 1290242:	41 55                	push   %r13
 1290244:	41 56                	push   %r14
 1290246:	41 57                	push   %r15
 1290248:	49 89 f5             	mov    %rsi,%r13
 129024b:	48 89 fb             	mov    %rdi,%rbx
 129024e:	48 c7 45 b0 00 00 00 	movq   $0x0,-0x50(%rbp)
 1290255:	00 
 1290256:	48 c7 45 b8 00 00 00 	movq   $0x0,-0x48(%rbp)
 129025d:	00 
 129025e:	48 89 df             	mov    %rbx,%rdi
 1290261:	e8 4a b0 03 00       	call   12cb2b0 <myl_qbe_heap>
 1290266:	48 89 c7             	mov    %rax,%rdi
 1290269:	49 89 fc             	mov    %rdi,%r12
 129026c:	48 89 df             	mov    %rbx,%rdi
 129026f:	e8 5c da 03 00       	call   12cdcd0 <myl_qbe_region_mark>
 1290274:	4c 89 e7             	mov    %r12,%rdi
 1290277:	48 89 45 e0          	mov    %rax,-0x20(%rbp)
 129027b:	ba 40 00 00 00       	mov    $0x40,%edx
 1290280:	be 00 00 00 00       	mov    $0x0,%esi
 1290285:	49 89 fc             	mov    %rdi,%r12
 1290288:	48 8d bd c8 fe ff ff 	lea    -0x138(%rbp),%rdi
 129028f:	e8 7c 20 05 00       	call   12e2310 <compiler_rt.fastMemset>
 1290294:	4c 89 e7             	mov    %r12,%rdi
 1290297:	48 8d 05 1a ac 12 00 	lea    0x12ac1a(%rip),%rax        # 13baeb8 <myl_t_c000f22f7ee44dea31e81b0a933c1dec3a560f42212434ae24333c6a58c466f9>
 129029e:	48 89 85 c8 fd ff ff 	mov    %rax,-0x238(%rbp)
 12902a5:	c7 85 e0 fd ff ff 02 	movl   $0x2,-0x220(%rbp)
 12902ac:	00 00 00 
 12902af:	4c 89 ad d0 fd ff ff 	mov    %r13,-0x230(%rbp)
 12902b6:	48 8d 85 c8 fe ff ff 	lea    -0x138(%rbp),%rax
 12902bd:	48 89 85 d8 fd ff ff 	mov    %rax,-0x228(%rbp)
 12902c4:	48 8d 05 ed ab 12 00 	lea    0x12abed(%rip),%rax        # 13baeb8 <myl_t_c000f22f7ee44dea31e81b0a933c1dec3a560f42212434ae24333c6a58c466f9>
 12902cb:	48 89 85 e8 fd ff ff 	mov    %rax,-0x218(%rbp)
 12902d2:	c7 85 00 fe ff ff 02 	movl   $0x2,-0x200(%rbp)
 12902d9:	00 00 00 
 12902dc:	48 8d 45 88          	lea    -0x78(%rbp),%rax
 12902e0:	48 89 85 f0 fd ff ff 	mov    %rax,-0x210(%rbp)
 12902e7:	48 8d 85 c8 fe ff ff 	lea    -0x138(%rbp),%rax
 12902ee:	48 83 c0 08          	add    $0x8,%rax
 12902f2:	48 89 85 f8 fd ff ff 	mov    %rax,-0x208(%rbp)
 12902f9:	48 8d 85 c8 fd ff ff 	lea    -0x238(%rbp),%rax
 1290300:	48 89 c1             	mov    %rax,%rcx
 1290303:	48 83 c1 40          	add    $0x40,%rcx
 1290307:	48 89 4d f0          	mov    %rcx,-0x10(%rbp)
 129030b:	48 8d 05 56 80 12 00 	lea    0x128056(%rip),%rax        # 13b8368 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527>
 1290312:	48 89 85 08 fe ff ff 	mov    %rax,-0x1f8(%rbp)
 1290319:	c7 85 20 fe ff ff 02 	movl   $0x2,-0x1e0(%rbp)
 1290320:	00 00 00 
 1290323:	48 8d 45 b0          	lea    -0x50(%rbp),%rax
 1290327:	48 89 85 10 fe ff ff 	mov    %rax,-0x1f0(%rbp)
 129032e:	48 8d 85 c8 fe ff ff 	lea    -0x138(%rbp),%rax
 1290335:	48 83 c0 10          	add    $0x10,%rax
 1290339:	48 89 45 e8          	mov    %rax,-0x18(%rbp)
 129033d:	48 89 85 18 fe ff ff 	mov    %rax,-0x1e8(%rbp)
 1290344:	48 8d 85 c8 fd ff ff 	lea    -0x238(%rbp),%rax
 129034b:	49 89 c6             	mov    %rax,%r14
 129034e:	49 83 c6 60          	add    $0x60,%r14
 1290352:	4c 89 75 d0          	mov    %r14,-0x30(%rbp)
 1290356:	48 8d 05 0b 80 12 00 	lea    0x12800b(%rip),%rax        # 13b8368 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527>
 129035d:	48 89 85 28 fe ff ff 	mov    %rax,-0x1d8(%rbp)
 1290364:	c7 85 40 fe ff ff 02 	movl   $0x2,-0x1c0(%rbp)
 129036b:	00 00 00 
 129036e:	48 8d 45 b8          	lea    -0x48(%rbp),%rax
 1290372:	48 89 85 30 fe ff ff 	mov    %rax,-0x1d0(%rbp)
 1290379:	48 8d 85 c8 fe ff ff 	lea    -0x138(%rbp),%rax
 1290380:	49 89 c4             	mov    %rax,%r12
 1290383:	49 83 c4 18          	add    $0x18,%r12
 1290387:	4c 89 65 d8          	mov    %r12,-0x28(%rbp)
 129038b:	4c 89 a5 38 fe ff ff 	mov    %r12,-0x1c8(%rbp)
 1290392:	48 8d 85 c8 fd ff ff 	lea    -0x238(%rbp),%rax
 1290399:	49 89 c7             	mov    %rax,%r15
 129039c:	49 81 c7 80 00 00 00 	add    $0x80,%r15
 12903a3:	48 8d 05 06 77 dc ff 	lea    -0x2388fa(%rip),%rax        # 1057ab0 <myl_t_385cfdbc00ec32031699460779c15099b2bba3cad0e440fffb08e10df0acb9e1>
 12903aa:	48 89 85 48 fe ff ff 	mov    %rax,-0x1b8(%rbp)
 12903b1:	c7 85 60 fe ff ff 00 	movl   $0x0,-0x1a0(%rbp)
 12903b8:	00 00 00 
 12903bb:	48 8d 85 08 ff ff ff 	lea    -0xf8(%rbp),%rax
 12903c2:	48 89 85 50 fe ff ff 	mov    %rax,-0x1b0(%rbp)
 12903c9:	48 8d 85 c8 fe ff ff 	lea    -0x138(%rbp),%rax
 12903d0:	48 83 c0 20          	add    $0x20,%rax
 12903d4:	48 89 85 58 fe ff ff 	mov    %rax,-0x1a8(%rbp)
 12903db:	48 8d 85 c8 fd ff ff 	lea    -0x238(%rbp),%rax
 12903e2:	48 89 c6             	mov    %rax,%rsi
 12903e5:	48 81 c6 a0 00 00 00 	add    $0xa0,%rsi
 12903ec:	48 8d 05 bd 76 dc ff 	lea    -0x238943(%rip),%rax        # 1057ab0 <myl_t_385cfdbc00ec32031699460779c15099b2bba3cad0e440fffb08e10df0acb9e1>
 12903f3:	48 89 85 68 fe ff ff 	mov    %rax,-0x198(%rbp)
 12903fa:	c7 85 80 fe ff ff 00 	movl   $0x0,-0x180(%rbp)
 1290401:	00 00 00 
 1290404:	48 8d 85 30 ff ff ff 	lea    -0xd0(%rbp),%rax
 129040b:	48 89 85 70 fe ff ff 	mov    %rax,-0x190(%rbp)
 1290412:	48 8d 85 c8 fe ff ff 	lea    -0x138(%rbp),%rax
 1290419:	48 83 c0 28          	add    $0x28,%rax
 129041d:	48 89 85 78 fe ff ff 	mov    %rax,-0x188(%rbp)
 1290424:	48 8d 05 85 76 dc ff 	lea    -0x23897b(%rip),%rax        # 1057ab0 <myl_t_385cfdbc00ec32031699460779c15099b2bba3cad0e440fffb08e10df0acb9e1>
 129042b:	48 89 85 88 fe ff ff 	mov    %rax,-0x178(%rbp)
 1290432:	c7 85 a0 fe ff ff 00 	movl   $0x0,-0x160(%rbp)
 1290439:	00 00 00 
 129043c:	48 8d 85 58 ff ff ff 	lea    -0xa8(%rbp),%rax
 1290443:	48 89 85 90 fe ff ff 	mov    %rax,-0x170(%rbp)
 129044a:	48 8d 85 c8 fe ff ff 	lea    -0x138(%rbp),%rax
 1290451:	48 83 c0 30          	add    $0x30,%rax
 1290455:	48 89 85 98 fe ff ff 	mov    %rax,-0x168(%rbp)
 129045c:	48 8d 05 4d 76 dc ff 	lea    -0x2389b3(%rip),%rax        # 1057ab0 <myl_t_385cfdbc00ec32031699460779c15099b2bba3cad0e440fffb08e10df0acb9e1>
 1290463:	48 89 85 a8 fe ff ff 	mov    %rax,-0x158(%rbp)
 129046a:	c7 85 c0 fe ff ff 00 	movl   $0x0,-0x140(%rbp)
 1290471:	00 00 00 
 1290474:	48 8d 45 80          	lea    -0x80(%rbp),%rax
 1290478:	48 89 85 b0 fe ff ff 	mov    %rax,-0x150(%rbp)
 129047f:	48 8d 85 c8 fe ff ff 	lea    -0x138(%rbp),%rax
 1290486:	48 83 c0 38          	add    $0x38,%rax
 129048a:	48 89 85 b8 fe ff ff 	mov    %rax,-0x148(%rbp)
 1290491:	b9 08 00 00 00       	mov    $0x8,%ecx
 1290496:	48 8d 95 c8 fd ff ff 	lea    -0x238(%rbp),%rdx
 129049d:	49 89 f6             	mov    %rsi,%r14
 12904a0:	48 8d b5 a8 fd ff ff 	lea    -0x258(%rbp),%rsi
 12904a7:	49 89 fc             	mov    %rdi,%r12
 12904aa:	48 89 df             	mov    %rbx,%rdi
 12904ad:	e8 6e 9d 03 00       	call   12ca220 <myl_qbe_rc_frame_enter>
 12904b2:	4c 89 f6             	mov    %r14,%rsi
 12904b5:	4c 89 e7             	mov    %r12,%rdi
 12904b8:	4c 89 6d c0          	mov    %r13,-0x40(%rbp)
 12904bc:	49 8b 45 18          	mov    0x18(%r13),%rax
 12904c0:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
 12904c4:	8b 85 e8 fe ff ff    	mov    -0x118(%rbp),%eax
 12904ca:	83 f8 00             	cmp    $0x0,%eax
 12904cd:	74 17                	je     12904e6 <myl_f_22849c51a4fd631aa66144da38552fb710206c5e57b8268459a8dc3a6dbcd390+0x2b6>
 12904cf:	49 89 f6             	mov    %rsi,%r14
 12904d2:	4c 89 fe             	mov    %r15,%rsi
 12904d5:	49 89 fc             	mov    %rdi,%r12
 12904d8:	48 89 df             	mov    %rbx,%rdi
 12904db:	e8 20 9e 03 00       	call   12ca300 <myl_qbe_rc_slot_drop>
 12904e0:	4c 89 f6             	mov    %r14,%rsi
 12904e3:	4c 89 e7             	mov    %r12,%rdi
 12904e6:	48 c7 45 c8 02 00 00 	movq   $0x2,-0x38(%rbp)
 12904ed:	00 
 12904ee:	48 8b 55 c0          	mov    -0x40(%rbp),%rdx
 12904f2:	48 b8 fd ff ff ff ff 	movabs $0x7ffffffffffffffd,%rax
 12904f9:	ff ff 7f 
 12904fc:	48 39 c2             	cmp    %rax,%rdx
 12904ff:	0f 8f 15 0a 00 00    	jg     1290f1a <myl_f_22849c51a4fd631aa66144da38552fb710206c5e57b8268459a8dc3a6dbcd390+0xcea>
 1290505:	48 89 d0             	mov    %rdx,%rax
 1290508:	48 83 c0 02          	add    $0x2,%rax
 129050c:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
 1290510:	4c 89 6d c0          	mov    %r13,-0x40(%rbp)
 1290514:	4c 89 6d c0          	mov    %r13,-0x40(%rbp)
 1290518:	4c 89 6d c0          	mov    %r13,-0x40(%rbp)
 129051c:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
 1290520:	4c 89 6d c0          	mov    %r13,-0x40(%rbp)
 1290524:	49 89 45 18          	mov    %rax,0x18(%r13)
 1290528:	48 c7 45 c0 00 00 00 	movq   $0x0,-0x40(%rbp)
 129052f:	00 
 1290530:	4c 89 6d c0          	mov    %r13,-0x40(%rbp)
 1290534:	49 8b 45 08          	mov    0x8(%r13),%rax
 1290538:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
 129053c:	48 8d 4d c0          	lea    -0x40(%rbp),%rcx
 1290540:	48 8d 95 58 ff ff ff 	lea    -0xa8(%rbp),%rdx
 1290547:	49 89 f6             	mov    %rsi,%r14
 129054a:	48 8d 35 17 7e 12 00 	lea    0x127e17(%rip),%rsi        # 13b8368 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527>
 1290551:	49 89 fc             	mov    %rdi,%r12
 1290554:	e8 97 13 05 00       	call   12e18f0 <myl_rc_native_loan>
 1290559:	4c 89 f6             	mov    %r14,%rsi
 129055c:	4c 89 e7             	mov    %r12,%rdi
 129055f:	4c 8b 45 e0          	mov    -0x20(%rbp),%r8
 1290563:	83 f8 00             	cmp    $0x0,%eax
 1290566:	75 1a                	jne    1290582 <myl_f_22849c51a4fd631aa66144da38552fb710206c5e57b8268459a8dc3a6dbcd390+0x352>
 1290568:	e8 c3 8f 04 00       	call   12d9530 <myl_rc_take_failure>
 129056d:	48 89 df             	mov    %rbx,%rdi
 1290570:	89 c6                	mov    %eax,%esi
 1290572:	48 89 fb             	mov    %rdi,%rbx
 1290575:	e8 b6 9b 03 00       	call   12ca130 <myl_qbe_rc_status>
 129057a:	48 89 df             	mov    %rbx,%rdi
 129057d:	e9 04 07 00 00       	jmp    1290c86 <myl_f_22849c51a4fd631aa66144da38552fb710206c5e57b8268459a8dc3a6dbcd390+0xa56>
 1290582:	48 8d 05 df 7d 12 00 	lea    0x127ddf(%rip),%rax        # 13b8368 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527>
 1290589:	48 89 85 88 fe ff ff 	mov    %rax,-0x178(%rbp)
 1290590:	c7 85 a0 fe ff ff 02 	movl   $0x2,-0x160(%rbp)
 1290597:	00 00 00 
 129059a:	c7 85 a0 fe ff ff 10 	movl   $0x10,-0x160(%rbp)
 12905a1:	00 00 00 
 12905a4:	c7 85 f8 fe ff ff 01 	movl   $0x1,-0x108(%rbp)
 12905ab:	00 00 00 
 12905ae:	8b 85 e8 fe ff ff    	mov    -0x118(%rbp),%eax
 12905b4:	83 f8 00             	cmp    $0x0,%eax
 12905b7:	74 1b                	je     12905d4 <myl_f_22849c51a4fd631aa66144da38552fb710206c5e57b8268459a8dc3a6dbcd390+0x3a4>
 12905b9:	49 89 f6             	mov    %rsi,%r14
 12905bc:	4c 89 fe             	mov    %r15,%rsi
 12905bf:	49 89 fc             	mov    %rdi,%r12
 12905c2:	48 89 df             	mov    %rbx,%rdi
 12905c5:	e8 36 9d 03 00       	call   12ca300 <myl_qbe_rc_slot_drop>
 12905ca:	4c 89 f6             	mov    %r14,%rsi
 12905cd:	4c 89 e7             	mov    %r12,%rdi
 12905d0:	4c 8b 45 e0          	mov    -0x20(%rbp),%r8
 12905d4:	48 8b 85 58 ff ff ff 	mov    -0xa8(%rbp),%rax
 12905db:	48 89 85 08 ff ff ff 	mov    %rax,-0xf8(%rbp)
 12905e2:	48 8d 05 7f 7d 12 00 	lea    0x127d7f(%rip),%rax        # 13b8368 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527>
 12905e9:	48 89 85 48 fe ff ff 	mov    %rax,-0x1b8(%rbp)
 12905f0:	c7 85 60 fe ff ff 02 	movl   $0x2,-0x1a0(%rbp)
 12905f7:	00 00 00 
 12905fa:	8b 8d a0 fe ff ff    	mov    -0x160(%rbp),%ecx
 1290600:	89 8d 60 fe ff ff    	mov    %ecx,-0x1a0(%rbp)
 1290606:	c7 85 f8 fe ff ff 00 	movl   $0x0,-0x108(%rbp)
 129060d:	00 00 00 
 1290610:	c7 85 e8 fe ff ff 01 	movl   $0x1,-0x118(%rbp)
 1290617:	00 00 00 
 129061a:	48 8b 85 08 ff ff ff 	mov    -0xf8(%rbp),%rax
 1290621:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
 1290625:	83 e1 18             	and    $0x18,%ecx
 1290628:	83 f9 00             	cmp    $0x0,%ecx
 129062b:	0f 84 b8 00 00 00    	je     12906e9 <myl_f_22849c51a4fd631aa66144da38552fb710206c5e57b8268459a8dc3a6dbcd390+0x4b9>
 1290631:	48 8d 4d c0          	lea    -0x40(%rbp),%rcx
 1290635:	48 8d 95 58 ff ff ff 	lea    -0xa8(%rbp),%rdx
 129063c:	49 89 f6             	mov    %rsi,%r14
 129063f:	48 8d 35 22 7d 12 00 	lea    0x127d22(%rip),%rsi        # 13b8368 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527>
 1290646:	49 89 fc             	mov    %rdi,%r12
 1290649:	e8 a2 12 05 00       	call   12e18f0 <myl_rc_native_loan>
 129064e:	4c 89 f6             	mov    %r14,%rsi
 1290651:	4c 89 e7             	mov    %r12,%rdi
 1290654:	89 c2                	mov    %eax,%edx
 1290656:	48 8b 45 e8          	mov    -0x18(%rbp),%rax
 129065a:	48 8b 4d f0          	mov    -0x10(%rbp),%rcx
 129065e:	4c 8b 45 e0          	mov    -0x20(%rbp),%r8
 1290662:	83 fa 00             	cmp    $0x0,%edx
 1290665:	75 1a                	jne    1290681 <myl_f_22849c51a4fd631aa66144da38552fb710206c5e57b8268459a8dc3a6dbcd390+0x451>
 1290667:	e8 c4 8e 04 00       	call   12d9530 <myl_rc_take_failure>
 129066c:	48 89 df             	mov    %rbx,%rdi
 129066f:	89 c6                	mov    %eax,%esi
 1290671:	48 89 fb             	mov    %rdi,%rbx
 1290674:	e8 b7 9a 03 00       	call   12ca130 <myl_qbe_rc_status>
 1290679:	48 89 df             	mov    %rbx,%rdi
 129067c:	e9 05 06 00 00       	jmp    1290c86 <myl_f_22849c51a4fd631aa66144da38552fb710206c5e57b8268459a8dc3a6dbcd390+0xa56>
 1290681:	48 8d 15 e0 7c 12 00 	lea    0x127ce0(%rip),%rdx        # 13b8368 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527>
 1290688:	48 89 95 88 fe ff ff 	mov    %rdx,-0x178(%rbp)
 129068f:	c7 85 a0 fe ff ff 02 	movl   $0x2,-0x160(%rbp)
 1290696:	00 00 00 
 1290699:	c7 85 a0 fe ff ff 10 	movl   $0x10,-0x160(%rbp)
 12906a0:	00 00 00 
 12906a3:	c7 85 f8 fe ff ff 01 	movl   $0x1,-0x108(%rbp)
 12906aa:	00 00 00 
 12906ad:	8b 95 e8 fe ff ff    	mov    -0x118(%rbp),%edx
 12906b3:	83 fa 00             	cmp    $0x0,%edx
 12906b6:	74 23                	je     12906db <myl_f_22849c51a4fd631aa66144da38552fb710206c5e57b8268459a8dc3a6dbcd390+0x4ab>
 12906b8:	49 89 f6             	mov    %rsi,%r14
 12906bb:	4c 89 fe             	mov    %r15,%rsi
 12906be:	49 89 fc             	mov    %rdi,%r12
 12906c1:	48 89 df             	mov    %rbx,%rdi
 12906c4:	e8 37 9c 03 00       	call   12ca300 <myl_qbe_rc_slot_drop>
 12906c9:	4c 89 f6             	mov    %r14,%rsi
 12906cc:	4c 89 e7             	mov    %r12,%rdi
 12906cf:	48 8b 45 e8          	mov    -0x18(%rbp),%rax
 12906d3:	48 8b 4d f0          	mov    -0x10(%rbp),%rcx
 12906d7:	4c 8b 45 e0          	mov    -0x20(%rbp),%r8
 12906db:	49 89 f6             	mov    %rsi,%r14
 12906de:	48 89 ce             	mov    %rcx,%rsi
 12906e1:	48 87 df             	xchg   %rbx,%rdi
 12906e4:	e9 17 01 00 00       	jmp    1290800 <myl_f_22849c51a4fd631aa66144da38552fb710206c5e57b8268459a8dc3a6dbcd390+0x5d0>
 12906e9:	48 8d 95 58 ff ff ff 	lea    -0xa8(%rbp),%rdx
 12906f0:	48 8d 4d c0          	lea    -0x40(%rbp),%rcx
 12906f4:	48 29 d1             	sub    %rdx,%rcx
 12906f7:	4c 8d 4d c0          	lea    -0x40(%rbp),%r9
 12906fb:	48 8d 95 58 ff ff ff 	lea    -0xa8(%rbp),%rdx
 1290702:	4c 29 ca             	sub    %r9,%rdx
 1290705:	48 83 f9 08          	cmp    $0x8,%rcx
 1290709:	0f 92 c1             	setb   %cl
 129070c:	0f b6 c9             	movzbl %cl,%ecx
 129070f:	48 83 fa 08          	cmp    $0x8,%rdx
 1290713:	0f 92 c2             	setb   %dl
 1290716:	0f b6 d2             	movzbl %dl,%edx
 1290719:	09 d1                	or     %edx,%ecx
 129071b:	75 61                	jne    129077e <myl_f_22849c51a4fd631aa66144da38552fb710206c5e57b8268459a8dc3a6dbcd390+0x54e>
 129071d:	48 83 f8 00          	cmp    $0x0,%rax
 1290721:	74 1a                	je     129073d <myl_f_22849c51a4fd631aa66144da38552fb710206c5e57b8268459a8dc3a6dbcd390+0x50d>
 1290723:	48 83 e8 10          	sub    $0x10,%rax
 1290727:	48 8b 00             	mov    (%rax),%rax
 129072a:	48 b9 01 00 00 00 00 	movabs $0x5000000000000001,%rcx
 1290731:	00 00 50 
 1290734:	48 21 c8             	and    %rcx,%rax
 1290737:	48 83 f8 00          	cmp    $0x0,%rax
 129073b:	75 41                	jne    129077e <myl_f_22849c51a4fd631aa66144da38552fb710206c5e57b8268459a8dc3a6dbcd390+0x54e>
 129073d:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
 1290741:	48 89 85 58 ff ff ff 	mov    %rax,-0xa8(%rbp)
 1290748:	ba 08 00 00 00       	mov    $0x8,%edx
 129074d:	49 89 f6             	mov    %rsi,%r14
 1290750:	be 00 00 00 00       	mov    $0x0,%esi
 1290755:	49 89 fc             	mov    %rdi,%r12
 1290758:	48 8d 7d c0          	lea    -0x40(%rbp),%rdi
 129075c:	e8 af 1b 05 00       	call   12e2310 <compiler_rt.fastMemset>
 1290761:	4c 89 f6             	mov    %r14,%rsi
 1290764:	4c 89 e7             	mov    %r12,%rdi
 1290767:	48 8b 45 e8          	mov    -0x18(%rbp),%rax
 129076b:	48 8b 4d f0          	mov    -0x10(%rbp),%rcx
 129076f:	4c 8b 45 e0          	mov    -0x20(%rbp),%r8
 1290773:	49 89 f6             	mov    %rsi,%r14
 1290776:	48 89 ce             	mov    %rcx,%rsi
 1290779:	48 87 df             	xchg   %rbx,%rdi
 129077c:	eb 56                	jmp    12907d4 <myl_f_22849c51a4fd631aa66144da38552fb710206c5e57b8268459a8dc3a6dbcd390+0x5a4>
 129077e:	48 8d 4d c0          	lea    -0x40(%rbp),%rcx
 1290782:	48 8d 95 58 ff ff ff 	lea    -0xa8(%rbp),%rdx
 1290789:	49 89 f6             	mov    %rsi,%r14
 129078c:	48 8d 35 d5 7b 12 00 	lea    0x127bd5(%rip),%rsi        # 13b8368 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527>
 1290793:	49 89 fc             	mov    %rdi,%r12
 1290796:	e8 85 0e 05 00       	call   12e1620 <myl_rc_native_take>
 129079b:	4c 89 f6             	mov    %r14,%rsi
 129079e:	4c 89 e7             	mov    %r12,%rdi
 12907a1:	89 c1                	mov    %eax,%ecx
 12907a3:	48 8b 45 e8          	mov    -0x18(%rbp),%rax
 12907a7:	49 89 f6             	mov    %rsi,%r14
 12907aa:	48 8b 75 f0          	mov    -0x10(%rbp),%rsi
 12907ae:	4c 8b 45 e0          	mov    -0x20(%rbp),%r8
 12907b2:	83 f9 00             	cmp    $0x0,%ecx
 12907b5:	75 1a                	jne    12907d1 <myl_f_22849c51a4fd631aa66144da38552fb710206c5e57b8268459a8dc3a6dbcd390+0x5a1>
 12907b7:	e8 74 8d 04 00       	call   12d9530 <myl_rc_take_failure>
 12907bc:	48 89 df             	mov    %rbx,%rdi
 12907bf:	89 c6                	mov    %eax,%esi
 12907c1:	48 89 fb             	mov    %rdi,%rbx
 12907c4:	e8 67 99 03 00       	call   12ca130 <myl_qbe_rc_status>
 12907c9:	48 89 df             	mov    %rbx,%rdi
 12907cc:	e9 b5 04 00 00       	jmp    1290c86 <myl_f_22849c51a4fd631aa66144da38552fb710206c5e57b8268459a8dc3a6dbcd390+0xa56>
 12907d1:	48 87 df             	xchg   %rbx,%rdi
 12907d4:	c7 85 e8 fe ff ff 00 	movl   $0x0,-0x118(%rbp)
 12907db:	00 00 00 
 12907de:	48 8d 0d 83 7b 12 00 	lea    0x127b83(%rip),%rcx        # 13b8368 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527>
 12907e5:	48 89 8d 88 fe ff ff 	mov    %rcx,-0x178(%rbp)
 12907ec:	c7 85 a0 fe ff ff 02 	movl   $0x2,-0x160(%rbp)
 12907f3:	00 00 00 
 12907f6:	c7 85 f8 fe ff ff 01 	movl   $0x1,-0x108(%rbp)
 12907fd:	00 00 00 
 1290800:	8b 8d d8 fe ff ff    	mov    -0x128(%rbp),%ecx
 1290806:	83 f9 00             	cmp    $0x0,%ecx
 1290809:	75 08                	jne    1290813 <myl_f_22849c51a4fd631aa66144da38552fb710206c5e57b8268459a8dc3a6dbcd390+0x5e3>
 129080b:	4c 89 fe             	mov    %r15,%rsi
 129080e:	4d 89 c7             	mov    %r8,%r15
 1290811:	eb 16                	jmp    1290829 <myl_f_22849c51a4fd631aa66144da38552fb710206c5e57b8268459a8dc3a6dbcd390+0x5f9>
 1290813:	49 89 fc             	mov    %rdi,%r12
 1290816:	e8 e5 9a 03 00       	call   12ca300 <myl_qbe_rc_slot_drop>
 129081b:	4c 89 fe             	mov    %r15,%rsi
 129081e:	4c 89 e7             	mov    %r12,%rdi
 1290821:	48 8b 45 e8          	mov    -0x18(%rbp),%rax
 1290825:	4c 8b 7d e0          	mov    -0x20(%rbp),%r15
 1290829:	48 8b 8d 58 ff ff ff 	mov    -0xa8(%rbp),%rcx
 1290830:	48 89 4d b0          	mov    %rcx,-0x50(%rbp)
 1290834:	c7 85 f8 fe ff ff 00 	movl   $0x0,-0x108(%rbp)
 129083b:	00 00 00 
 129083e:	48 8d 0d 23 7b 12 00 	lea    0x127b23(%rip),%rcx        # 13b8368 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527>
 1290845:	48 89 8d 08 fe ff ff 	mov    %rcx,-0x1f8(%rbp)
 129084c:	c7 85 20 fe ff ff 02 	movl   $0x2,-0x1e0(%rbp)
 1290853:	00 00 00 
 1290856:	48 8d 4d b0          	lea    -0x50(%rbp),%rcx
 129085a:	48 89 8d 10 fe ff ff 	mov    %rcx,-0x1f0(%rbp)
 1290861:	48 89 85 18 fe ff ff 	mov    %rax,-0x1e8(%rbp)
 1290868:	8b 85 a0 fe ff ff    	mov    -0x160(%rbp),%eax
 129086e:	89 85 20 fe ff ff    	mov    %eax,-0x1e0(%rbp)
 1290874:	c7 85 d8 fe ff ff 01 	movl   $0x1,-0x128(%rbp)
 129087b:	00 00 00 
 129087e:	4c 89 6d c0          	mov    %r13,-0x40(%rbp)
 1290882:	49 8b 45 18          	mov    0x18(%r13),%rax
 1290886:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
 129088a:	8b 85 e8 fe ff ff    	mov    -0x118(%rbp),%eax
 1290890:	83 f8 00             	cmp    $0x0,%eax
 1290893:	75 08                	jne    129089d <myl_f_22849c51a4fd631aa66144da38552fb710206c5e57b8268459a8dc3a6dbcd390+0x66d>
 1290895:	4c 89 f6             	mov    %r14,%rsi
 1290898:	4d 89 f8             	mov    %r15,%r8
 129089b:	eb 11                	jmp    12908ae <myl_f_22849c51a4fd631aa66144da38552fb710206c5e57b8268459a8dc3a6dbcd390+0x67e>
 129089d:	49 89 fc             	mov    %rdi,%r12
 12908a0:	e8 5b 9a 03 00       	call   12ca300 <myl_qbe_rc_slot_drop>
 12908a5:	4d 89 f8             	mov    %r15,%r8
 12908a8:	4c 89 f6             	mov    %r14,%rsi
 12908ab:	4c 89 e7             	mov    %r12,%rdi
 12908ae:	48 c7 45 c8 02 00 00 	movq   $0x2,-0x38(%rbp)
 12908b5:	00 
 12908b6:	48 8b 55 c0          	mov    -0x40(%rbp),%rdx
 12908ba:	48 b8 02 00 00 00 00 	movabs $0x8000000000000002,%rax
 12908c1:	00 00 80 
 12908c4:	48 39 c2             	cmp    %rax,%rdx
 12908c7:	0f 8c 36 06 00 00    	jl     1290f03 <myl_f_22849c51a4fd631aa66144da38552fb710206c5e57b8268459a8dc3a6dbcd390+0xcd3>
 12908cd:	48 89 d1             	mov    %rdx,%rcx
 12908d0:	48 83 e9 02          	sub    $0x2,%rcx
 12908d4:	48 89 4d c0          	mov    %rcx,-0x40(%rbp)
 12908d8:	48 89 4d c0          	mov    %rcx,-0x40(%rbp)
 12908dc:	48 c7 45 c8 00 00 00 	movq   $0x0,-0x38(%rbp)
 12908e3:	00 
 12908e4:	48 83 f9 00          	cmp    $0x0,%rcx
 12908e8:	0f 9c c0             	setl   %al
 12908eb:	48 0f b6 c0          	movzbq %al,%rax
 12908ef:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
 12908f3:	7d 52                	jge    1290947 <myl_f_22849c51a4fd631aa66144da38552fb710206c5e57b8268459a8dc3a6dbcd390+0x717>
 12908f5:	48 8b 45 b0          	mov    -0x50(%rbp),%rax
 12908f9:	49 89 f4             	mov    %rsi,%r12
 12908fc:	48 8b 30             	mov    (%rax),%rsi
 12908ff:	48 89 75 c0          	mov    %rsi,-0x40(%rbp)
 1290903:	48 b8 ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rax
 129090a:	ff ff 7f 
 129090d:	48 39 c6             	cmp    %rax,%rsi
 1290910:	0f 87 e1 05 00 00    	ja     1290ef7 <myl_f_22849c51a4fd631aa66144da38552fb710206c5e57b8268459a8dc3a6dbcd390+0xcc7>
 1290916:	48 89 75 c0          	mov    %rsi,-0x40(%rbp)
 129091a:	48 89 4d c8          	mov    %rcx,-0x38(%rbp)
 129091e:	48 89 f0             	mov    %rsi,%rax
 1290921:	48 01 c8             	add    %rcx,%rax
 1290924:	48 89 f2             	mov    %rsi,%rdx
 1290927:	48 31 c2             	xor    %rax,%rdx
 129092a:	49 89 c9             	mov    %rcx,%r9
 129092d:	49 31 c1             	xor    %rax,%r9
 1290930:	4c 21 ca             	and    %r9,%rdx
 1290933:	48 83 fa 00          	cmp    $0x0,%rdx
 1290937:	0f 8c a5 05 00 00    	jl     1290ee2 <myl_f_22849c51a4fd631aa66144da38552fb710206c5e57b8268459a8dc3a6dbcd390+0xcb2>
 129093d:	48 89 c1             	mov    %rax,%rcx
 1290940:	4c 89 e6             	mov    %r12,%rsi
 1290943:	48 89 4d c0          	mov    %rcx,-0x40(%rbp)
 1290947:	48 89 4d c0          	mov    %rcx,-0x40(%rbp)
 129094b:	48 8b 45 b0          	mov    -0x50(%rbp),%rax
 129094f:	48 8b 10             	mov    (%rax),%rdx
 1290952:	48 39 d1             	cmp    %rdx,%rcx
 1290955:	72 0d                	jb     1290964 <myl_f_22849c51a4fd631aa66144da38552fb710206c5e57b8268459a8dc3a6dbcd390+0x734>
 1290957:	48 89 ce             	mov    %rcx,%rsi
 129095a:	48 89 fb             	mov    %rdi,%rbx
 129095d:	e8 6e a5 03 00       	call   12caed0 <myl_qbe_fail_normalized_index_bounds>
 1290962:	0f 0b                	ud2
 1290964:	48 87 fb             	xchg   %rdi,%rbx
 1290967:	48 8b 40 20          	mov    0x20(%rax),%rax
 129096b:	48 8b 14 c8          	mov    (%rax,%rcx,8),%rdx
 129096f:	48 89 55 c0          	mov    %rdx,-0x40(%rbp)
 1290973:	48 c7 45 c8 00 01 00 	movq   $0x100,-0x38(%rbp)
 129097a:	00 
 129097b:	48 69 c2 00 01 00 00 	imul   $0x100,%rdx,%rax
 1290982:	b9 ff ff ff ff       	mov    $0xffffffff,%ecx
 1290987:	49 89 d3             	mov    %rdx,%r11
 129098a:	49 21 cb             	and    %rcx,%r11
 129098d:	49 89 d2             	mov    %rdx,%r10
 1290990:	49 c1 ea 20          	shr    $0x20,%r10
 1290994:	49 69 cb 00 01 00 00 	imul   $0x100,%r11,%rcx
 129099b:	48 c1 e9 20          	shr    $0x20,%rcx
 129099f:	4d 69 ca 00 01 00 00 	imul   $0x100,%r10,%r9
 12909a6:	49 01 c9             	add    %rcx,%r9
 12909a9:	b9 ff ff ff ff       	mov    $0xffffffff,%ecx
 12909ae:	4c 21 c9             	and    %r9,%rcx
 12909b1:	49 c1 e9 20          	shr    $0x20,%r9
 12909b5:	4d 6b db 00          	imul   $0x0,%r11,%r11
 12909b9:	4c 01 d9             	add    %r11,%rcx
 12909bc:	48 c1 e9 20          	shr    $0x20,%rcx
 12909c0:	4d 6b d2 00          	imul   $0x0,%r10,%r10
 12909c4:	4d 01 d1             	add    %r10,%r9
 12909c7:	4c 01 c9             	add    %r9,%rcx
 12909ca:	48 83 fa 00          	cmp    $0x0,%rdx
 12909ce:	41 0f 9c c1          	setl   %r9b
 12909d2:	4d 0f b6 c9          	movzbq %r9b,%r9
 12909d6:	49 f7 d9             	neg    %r9
 12909d9:	4d 89 ca             	mov    %r9,%r10
 12909dc:	49 81 e2 00 01 00 00 	and    $0x100,%r10
 12909e3:	49 89 d1             	mov    %rdx,%r9
 12909e6:	49 83 e1 00          	and    $0x0,%r9
 12909ea:	4c 29 d1             	sub    %r10,%rcx
 12909ed:	4c 29 c9             	sub    %r9,%rcx
 12909f0:	4d 89 c7             	mov    %r8,%r15
 12909f3:	49 89 c0             	mov    %rax,%r8
 12909f6:	49 c1 f8 3f          	sar    $0x3f,%r8
 12909fa:	49 39 c8             	cmp    %rcx,%r8
 12909fd:	0f 85 c5 04 00 00    	jne    1290ec8 <myl_f_22849c51a4fd631aa66144da38552fb710206c5e57b8268459a8dc3a6dbcd390+0xc98>
 1290a03:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
 1290a07:	4c 89 6d c8          	mov    %r13,-0x38(%rbp)
 1290a0b:	49 8b 45 08          	mov    0x8(%r13),%rax
 1290a0f:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
 1290a13:	48 8d 4d c8          	lea    -0x38(%rbp),%rcx
 1290a17:	48 8d 95 58 ff ff ff 	lea    -0xa8(%rbp),%rdx
 1290a1e:	49 89 f6             	mov    %rsi,%r14
 1290a21:	48 8d 35 40 79 12 00 	lea    0x127940(%rip),%rsi        # 13b8368 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527>
 1290a28:	49 89 fc             	mov    %rdi,%r12
 1290a2b:	e8 c0 0e 05 00       	call   12e18f0 <myl_rc_native_loan>
 1290a30:	4c 89 f6             	mov    %r14,%rsi
 1290a33:	4c 89 e7             	mov    %r12,%rdi
 1290a36:	4c 8b 65 d8          	mov    -0x28(%rbp),%r12
 1290a3a:	4c 8b 75 d0          	mov    -0x30(%rbp),%r14
 1290a3e:	83 f8 00             	cmp    $0x0,%eax
 1290a41:	75 1a                	jne    1290a5d <myl_f_22849c51a4fd631aa66144da38552fb710206c5e57b8268459a8dc3a6dbcd390+0x82d>
 1290a43:	e8 e8 8a 04 00       	call   12d9530 <myl_rc_take_failure>
 1290a48:	48 89 df             	mov    %rbx,%rdi
 1290a4b:	89 c6                	mov    %eax,%esi
 1290a4d:	48 89 fb             	mov    %rdi,%rbx
 1290a50:	e8 db 96 03 00       	call   12ca130 <myl_qbe_rc_status>
 1290a55:	48 89 df             	mov    %rbx,%rdi
 1290a58:	e9 29 02 00 00       	jmp    1290c86 <myl_f_22849c51a4fd631aa66144da38552fb710206c5e57b8268459a8dc3a6dbcd390+0xa56>
 1290a5d:	48 8d 05 04 79 12 00 	lea    0x127904(%rip),%rax        # 13b8368 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527>
 1290a64:	48 89 85 88 fe ff ff 	mov    %rax,-0x178(%rbp)
 1290a6b:	c7 85 a0 fe ff ff 02 	movl   $0x2,-0x160(%rbp)
 1290a72:	00 00 00 
 1290a75:	c7 85 a0 fe ff ff 10 	movl   $0x10,-0x160(%rbp)
 1290a7c:	00 00 00 
 1290a7f:	c7 85 f8 fe ff ff 01 	movl   $0x1,-0x108(%rbp)
 1290a86:	00 00 00 
 1290a89:	8b 85 f0 fe ff ff    	mov    -0x110(%rbp),%eax
 1290a8f:	83 f8 00             	cmp    $0x0,%eax
 1290a92:	75 05                	jne    1290a99 <myl_f_22849c51a4fd631aa66144da38552fb710206c5e57b8268459a8dc3a6dbcd390+0x869>
 1290a94:	4d 89 f8             	mov    %r15,%r8
 1290a97:	eb 1f                	jmp    1290ab8 <myl_f_22849c51a4fd631aa66144da38552fb710206c5e57b8268459a8dc3a6dbcd390+0x888>
 1290a99:	49 89 f6             	mov    %rsi,%r14
 1290a9c:	49 89 fc             	mov    %rdi,%r12
 1290a9f:	48 89 df             	mov    %rbx,%rdi
 1290aa2:	e8 59 98 03 00       	call   12ca300 <myl_qbe_rc_slot_drop>
 1290aa7:	4d 89 f8             	mov    %r15,%r8
 1290aaa:	4c 89 f6             	mov    %r14,%rsi
 1290aad:	4c 89 e7             	mov    %r12,%rdi
 1290ab0:	4c 8b 65 d8          	mov    -0x28(%rbp),%r12
 1290ab4:	4c 8b 75 d0          	mov    -0x30(%rbp),%r14
 1290ab8:	48 8b 85 58 ff ff ff 	mov    -0xa8(%rbp),%rax
 1290abf:	48 89 85 30 ff ff ff 	mov    %rax,-0xd0(%rbp)
 1290ac6:	48 8d 05 9b 78 12 00 	lea    0x12789b(%rip),%rax        # 13b8368 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527>
 1290acd:	48 89 85 68 fe ff ff 	mov    %rax,-0x198(%rbp)
 1290ad4:	c7 85 80 fe ff ff 02 	movl   $0x2,-0x180(%rbp)
 1290adb:	00 00 00 
 1290ade:	8b 8d a0 fe ff ff    	mov    -0x160(%rbp),%ecx
 1290ae4:	89 8d 80 fe ff ff    	mov    %ecx,-0x180(%rbp)
 1290aea:	c7 85 f8 fe ff ff 00 	movl   $0x0,-0x108(%rbp)
 1290af1:	00 00 00 
 1290af4:	c7 85 f0 fe ff ff 01 	movl   $0x1,-0x110(%rbp)
 1290afb:	00 00 00 
 1290afe:	48 8b 85 30 ff ff ff 	mov    -0xd0(%rbp),%rax
 1290b05:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
 1290b09:	83 e1 18             	and    $0x18,%ecx
 1290b0c:	83 f9 00             	cmp    $0x0,%ecx
 1290b0f:	0f 84 9c 00 00 00    	je     1290bb1 <myl_f_22849c51a4fd631aa66144da38552fb710206c5e57b8268459a8dc3a6dbcd390+0x981>
 1290b15:	48 8d 4d c8          	lea    -0x38(%rbp),%rcx
 1290b19:	48 8d 95 58 ff ff ff 	lea    -0xa8(%rbp),%rdx
 1290b20:	49 89 f7             	mov    %rsi,%r15
 1290b23:	48 8d 35 3e 78 12 00 	lea    0x12783e(%rip),%rsi        # 13b8368 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527>
 1290b2a:	49 89 fe             	mov    %rdi,%r14
 1290b2d:	e8 be 0d 05 00       	call   12e18f0 <myl_rc_native_loan>
 1290b32:	4c 89 fe             	mov    %r15,%rsi
 1290b35:	4c 89 f7             	mov    %r14,%rdi
 1290b38:	4c 8b 75 d0          	mov    -0x30(%rbp),%r14
 1290b3c:	83 f8 00             	cmp    $0x0,%eax
 1290b3f:	75 1a                	jne    1290b5b <myl_f_22849c51a4fd631aa66144da38552fb710206c5e57b8268459a8dc3a6dbcd390+0x92b>
 1290b41:	e8 ea 89 04 00       	call   12d9530 <myl_rc_take_failure>
 1290b46:	48 89 df             	mov    %rbx,%rdi
 1290b49:	89 c6                	mov    %eax,%esi
 1290b4b:	48 89 fb             	mov    %rdi,%rbx
 1290b4e:	e8 dd 95 03 00       	call   12ca130 <myl_qbe_rc_status>
 1290b53:	48 89 df             	mov    %rbx,%rdi
 1290b56:	e9 2b 01 00 00       	jmp    1290c86 <myl_f_22849c51a4fd631aa66144da38552fb710206c5e57b8268459a8dc3a6dbcd390+0xa56>
 1290b5b:	48 89 df             	mov    %rbx,%rdi
 1290b5e:	48 8d 05 03 78 12 00 	lea    0x127803(%rip),%rax        # 13b8368 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527>
 1290b65:	48 89 85 88 fe ff ff 	mov    %rax,-0x178(%rbp)
 1290b6c:	c7 85 a0 fe ff ff 02 	movl   $0x2,-0x160(%rbp)
 1290b73:	00 00 00 
 1290b76:	c7 85 a0 fe ff ff 10 	movl   $0x10,-0x160(%rbp)
 1290b7d:	00 00 00 
 1290b80:	c7 85 f8 fe ff ff 01 	movl   $0x1,-0x108(%rbp)
 1290b87:	00 00 00 
 1290b8a:	8b 85 f0 fe ff ff    	mov    -0x110(%rbp),%eax
 1290b90:	83 f8 00             	cmp    $0x0,%eax
 1290b93:	74 11                	je     1290ba6 <myl_f_22849c51a4fd631aa66144da38552fb710206c5e57b8268459a8dc3a6dbcd390+0x976>
 1290b95:	49 89 f7             	mov    %rsi,%r15
 1290b98:	48 89 fb             	mov    %rdi,%rbx
 1290b9b:	e8 60 97 03 00       	call   12ca300 <myl_qbe_rc_slot_drop>
 1290ba0:	4c 89 fe             	mov    %r15,%rsi
 1290ba3:	48 89 df             	mov    %rbx,%rdi
 1290ba6:	4c 87 f6             	xchg   %r14,%rsi
 1290ba9:	4c 89 eb             	mov    %r13,%rbx
 1290bac:	e9 2f 01 00 00       	jmp    1290ce0 <myl_f_22849c51a4fd631aa66144da38552fb710206c5e57b8268459a8dc3a6dbcd390+0xab0>
 1290bb1:	48 87 df             	xchg   %rbx,%rdi
 1290bb4:	48 8d 95 58 ff ff ff 	lea    -0xa8(%rbp),%rdx
 1290bbb:	48 8d 4d c8          	lea    -0x38(%rbp),%rcx
 1290bbf:	48 29 d1             	sub    %rdx,%rcx
 1290bc2:	4c 8d 4d c8          	lea    -0x38(%rbp),%r9
 1290bc6:	48 8d 95 58 ff ff ff 	lea    -0xa8(%rbp),%rdx
 1290bcd:	4c 29 ca             	sub    %r9,%rdx
 1290bd0:	48 83 f9 08          	cmp    $0x8,%rcx
 1290bd4:	0f 92 c1             	setb   %cl
 1290bd7:	0f b6 c9             	movzbl %cl,%ecx
 1290bda:	48 83 fa 08          	cmp    $0x8,%rdx
 1290bde:	0f 92 c2             	setb   %dl
 1290be1:	0f b6 d2             	movzbl %dl,%edx
 1290be4:	09 d1                	or     %edx,%ecx
 1290be6:	75 57                	jne    1290c3f <myl_f_22849c51a4fd631aa66144da38552fb710206c5e57b8268459a8dc3a6dbcd390+0xa0f>
 1290be8:	48 83 f8 00          	cmp    $0x0,%rax
 1290bec:	74 1a                	je     1290c08 <myl_f_22849c51a4fd631aa66144da38552fb710206c5e57b8268459a8dc3a6dbcd390+0x9d8>
 1290bee:	48 83 e8 10          	sub    $0x10,%rax
 1290bf2:	48 8b 00             	mov    (%rax),%rax
 1290bf5:	48 b9 01 00 00 00 00 	movabs $0x5000000000000001,%rcx
 1290bfc:	00 00 50 
 1290bff:	48 21 c8             	and    %rcx,%rax
 1290c02:	48 83 f8 00          	cmp    $0x0,%rax
 1290c06:	75 32                	jne    1290c3a <myl_f_22849c51a4fd631aa66144da38552fb710206c5e57b8268459a8dc3a6dbcd390+0xa0a>
 1290c08:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
 1290c0c:	48 89 85 58 ff ff ff 	mov    %rax,-0xa8(%rbp)
 1290c13:	ba 08 00 00 00       	mov    $0x8,%edx
 1290c18:	49 89 f7             	mov    %rsi,%r15
 1290c1b:	be 00 00 00 00       	mov    $0x0,%esi
 1290c20:	48 89 fb             	mov    %rdi,%rbx
 1290c23:	48 8d 7d c8          	lea    -0x38(%rbp),%rdi
 1290c27:	e8 e4 16 05 00       	call   12e2310 <compiler_rt.fastMemset>
 1290c2c:	4c 89 fe             	mov    %r15,%rsi
 1290c2f:	4c 87 f6             	xchg   %r14,%rsi
 1290c32:	48 89 df             	mov    %rbx,%rdi
 1290c35:	4c 89 eb             	mov    %r13,%rbx
 1290c38:	eb 7a                	jmp    1290cb4 <myl_f_22849c51a4fd631aa66144da38552fb710206c5e57b8268459a8dc3a6dbcd390+0xa84>
 1290c3a:	48 87 fb             	xchg   %rdi,%rbx
 1290c3d:	eb 03                	jmp    1290c42 <myl_f_22849c51a4fd631aa66144da38552fb710206c5e57b8268459a8dc3a6dbcd390+0xa12>
 1290c3f:	48 87 fb             	xchg   %rdi,%rbx
 1290c42:	48 8d 4d c8          	lea    -0x38(%rbp),%rcx
 1290c46:	48 8d 95 58 ff ff ff 	lea    -0xa8(%rbp),%rdx
 1290c4d:	49 89 f7             	mov    %rsi,%r15
 1290c50:	48 8d 35 11 77 12 00 	lea    0x127711(%rip),%rsi        # 13b8368 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527>
 1290c57:	49 89 fe             	mov    %rdi,%r14
 1290c5a:	e8 c1 09 05 00       	call   12e1620 <myl_rc_native_take>
 1290c5f:	4c 89 fe             	mov    %r15,%rsi
 1290c62:	4c 89 f7             	mov    %r14,%rdi
 1290c65:	49 89 f6             	mov    %rsi,%r14
 1290c68:	48 8b 75 d0          	mov    -0x30(%rbp),%rsi
 1290c6c:	83 f8 00             	cmp    $0x0,%eax
 1290c6f:	75 3d                	jne    1290cae <myl_f_22849c51a4fd631aa66144da38552fb710206c5e57b8268459a8dc3a6dbcd390+0xa7e>
 1290c71:	e8 ba 88 04 00       	call   12d9530 <myl_rc_take_failure>
 1290c76:	48 89 df             	mov    %rbx,%rdi
 1290c79:	89 c6                	mov    %eax,%esi
 1290c7b:	48 89 fb             	mov    %rdi,%rbx
 1290c7e:	e8 ad 94 03 00       	call   12ca130 <myl_qbe_rc_status>
 1290c83:	48 89 df             	mov    %rbx,%rdi
 1290c86:	48 8d b5 a8 fd ff ff 	lea    -0x258(%rbp),%rsi
 1290c8d:	48 89 fb             	mov    %rdi,%rbx
 1290c90:	e8 9b 97 03 00       	call   12ca430 <myl_qbe_rc_frame_cleanup>
 1290c95:	48 89 df             	mov    %rbx,%rdi
 1290c98:	48 8d b5 a8 fd ff ff 	lea    -0x258(%rbp),%rsi
 1290c9f:	e8 fc 95 03 00       	call   12ca2a0 <myl_qbe_rc_frame_leave>
 1290ca4:	b8 00 00 00 00       	mov    $0x0,%eax
 1290ca9:	e9 bf 01 00 00       	jmp    1290e6d <myl_f_22849c51a4fd631aa66144da38552fb710206c5e57b8268459a8dc3a6dbcd390+0xc3d>
 1290cae:	48 89 df             	mov    %rbx,%rdi
 1290cb1:	4c 89 eb             	mov    %r13,%rbx
 1290cb4:	c7 85 f0 fe ff ff 00 	movl   $0x0,-0x110(%rbp)
 1290cbb:	00 00 00 
 1290cbe:	48 8d 05 a3 76 12 00 	lea    0x1276a3(%rip),%rax        # 13b8368 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527>
 1290cc5:	48 89 85 88 fe ff ff 	mov    %rax,-0x178(%rbp)
 1290ccc:	c7 85 a0 fe ff ff 02 	movl   $0x2,-0x160(%rbp)
 1290cd3:	00 00 00 
 1290cd6:	c7 85 f8 fe ff ff 01 	movl   $0x1,-0x108(%rbp)
 1290cdd:	00 00 00 
 1290ce0:	8b 85 e0 fe ff ff    	mov    -0x120(%rbp),%eax
 1290ce6:	83 f8 00             	cmp    $0x0,%eax
 1290ce9:	75 05                	jne    1290cf0 <myl_f_22849c51a4fd631aa66144da38552fb710206c5e57b8268459a8dc3a6dbcd390+0xac0>
 1290ceb:	4c 89 f6             	mov    %r14,%rsi
 1290cee:	eb 0e                	jmp    1290cfe <myl_f_22849c51a4fd631aa66144da38552fb710206c5e57b8268459a8dc3a6dbcd390+0xace>
 1290cf0:	49 89 fd             	mov    %rdi,%r13
 1290cf3:	e8 08 96 03 00       	call   12ca300 <myl_qbe_rc_slot_drop>
 1290cf8:	4c 89 f6             	mov    %r14,%rsi
 1290cfb:	4c 89 ef             	mov    %r13,%rdi
 1290cfe:	48 8b 85 58 ff ff ff 	mov    -0xa8(%rbp),%rax
 1290d05:	48 89 45 b8          	mov    %rax,-0x48(%rbp)
 1290d09:	c7 85 f8 fe ff ff 00 	movl   $0x0,-0x108(%rbp)
 1290d10:	00 00 00 
 1290d13:	48 8d 05 4e 76 12 00 	lea    0x12764e(%rip),%rax        # 13b8368 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527>
 1290d1a:	48 89 85 28 fe ff ff 	mov    %rax,-0x1d8(%rbp)
 1290d21:	c7 85 40 fe ff ff 02 	movl   $0x2,-0x1c0(%rbp)
 1290d28:	00 00 00 
 1290d2b:	48 8d 45 b8          	lea    -0x48(%rbp),%rax
 1290d2f:	48 89 85 30 fe ff ff 	mov    %rax,-0x1d0(%rbp)
 1290d36:	4c 89 a5 38 fe ff ff 	mov    %r12,-0x1c8(%rbp)
 1290d3d:	8b 85 a0 fe ff ff    	mov    -0x160(%rbp),%eax
 1290d43:	89 85 40 fe ff ff    	mov    %eax,-0x1c0(%rbp)
 1290d49:	c7 85 e0 fe ff ff 01 	movl   $0x1,-0x120(%rbp)
 1290d50:	00 00 00 
 1290d53:	48 89 5d c8          	mov    %rbx,-0x38(%rbp)
 1290d57:	48 8b 43 18          	mov    0x18(%rbx),%rax
 1290d5b:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
 1290d5f:	8b 85 f0 fe ff ff    	mov    -0x110(%rbp),%eax
 1290d65:	83 f8 00             	cmp    $0x0,%eax
 1290d68:	74 0b                	je     1290d75 <myl_f_22849c51a4fd631aa66144da38552fb710206c5e57b8268459a8dc3a6dbcd390+0xb45>
 1290d6a:	48 89 fb             	mov    %rdi,%rbx
 1290d6d:	e8 8e 95 03 00       	call   12ca300 <myl_qbe_rc_slot_drop>
 1290d72:	48 89 df             	mov    %rbx,%rdi
 1290d75:	48 8b 55 c8          	mov    -0x38(%rbp),%rdx
 1290d79:	48 b8 01 00 00 00 00 	movabs $0x8000000000000001,%rax
 1290d80:	00 00 80 
 1290d83:	48 39 c2             	cmp    %rax,%rdx
 1290d86:	0f 8c 25 01 00 00    	jl     1290eb1 <myl_f_22849c51a4fd631aa66144da38552fb710206c5e57b8268459a8dc3a6dbcd390+0xc81>
 1290d8c:	48 89 d1             	mov    %rdx,%rcx
 1290d8f:	48 83 e9 01          	sub    $0x1,%rcx
 1290d93:	48 89 4d c8          	mov    %rcx,-0x38(%rbp)
 1290d97:	48 89 4d c8          	mov    %rcx,-0x38(%rbp)
 1290d9b:	48 83 f9 00          	cmp    $0x0,%rcx
 1290d9f:	0f 9c c0             	setl   %al
 1290da2:	48 0f b6 c0          	movzbq %al,%rax
 1290da6:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
 1290daa:	7d 48                	jge    1290df4 <myl_f_22849c51a4fd631aa66144da38552fb710206c5e57b8268459a8dc3a6dbcd390+0xbc4>
 1290dac:	48 8b 45 b8          	mov    -0x48(%rbp),%rax
 1290db0:	48 8b 30             	mov    (%rax),%rsi
 1290db3:	48 89 75 c8          	mov    %rsi,-0x38(%rbp)
 1290db7:	48 b8 ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rax
 1290dbe:	ff ff 7f 
 1290dc1:	48 39 c6             	cmp    %rax,%rsi
 1290dc4:	0f 87 db 00 00 00    	ja     1290ea5 <myl_f_22849c51a4fd631aa66144da38552fb710206c5e57b8268459a8dc3a6dbcd390+0xc75>
 1290dca:	48 89 75 c8          	mov    %rsi,-0x38(%rbp)
 1290dce:	48 89 f0             	mov    %rsi,%rax
 1290dd1:	48 01 c8             	add    %rcx,%rax
 1290dd4:	48 89 f2             	mov    %rsi,%rdx
 1290dd7:	48 31 c2             	xor    %rax,%rdx
 1290dda:	49 89 c8             	mov    %rcx,%r8
 1290ddd:	49 31 c0             	xor    %rax,%r8
 1290de0:	4c 21 c2             	and    %r8,%rdx
 1290de3:	48 83 fa 00          	cmp    $0x0,%rdx
 1290de7:	0f 8c a3 00 00 00    	jl     1290e90 <myl_f_22849c51a4fd631aa66144da38552fb710206c5e57b8268459a8dc3a6dbcd390+0xc60>
 1290ded:	48 89 c1             	mov    %rax,%rcx
 1290df0:	48 89 4d c8          	mov    %rcx,-0x38(%rbp)
 1290df4:	48 89 4d c8          	mov    %rcx,-0x38(%rbp)
 1290df8:	48 8b 45 b8          	mov    -0x48(%rbp),%rax
 1290dfc:	48 8b 10             	mov    (%rax),%rdx
 1290dff:	48 39 d1             	cmp    %rdx,%rcx
 1290e02:	72 0a                	jb     1290e0e <myl_f_22849c51a4fd631aa66144da38552fb710206c5e57b8268459a8dc3a6dbcd390+0xbde>
 1290e04:	48 89 ce             	mov    %rcx,%rsi
 1290e07:	e8 c4 a0 03 00       	call   12caed0 <myl_qbe_fail_normalized_index_bounds>
 1290e0c:	0f 0b                	ud2
 1290e0e:	48 8b 40 20          	mov    0x20(%rax),%rax
 1290e12:	48 8b 0c c8          	mov    (%rax,%rcx,8),%rcx
 1290e16:	48 89 4d c8          	mov    %rcx,-0x38(%rbp)
 1290e1a:	48 8b 55 c0          	mov    -0x40(%rbp),%rdx
 1290e1e:	48 89 c8             	mov    %rcx,%rax
 1290e21:	48 01 d0             	add    %rdx,%rax
 1290e24:	49 89 cc             	mov    %rcx,%r12
 1290e27:	48 89 d1             	mov    %rdx,%rcx
 1290e2a:	48 31 c1             	xor    %rax,%rcx
 1290e2d:	48 89 d3             	mov    %rdx,%rbx
 1290e30:	4c 89 e2             	mov    %r12,%rdx
 1290e33:	48 31 c2             	xor    %rax,%rdx
 1290e36:	48 21 d1             	and    %rdx,%rcx
 1290e39:	48 83 f9 00          	cmp    $0x0,%rcx
 1290e3d:	7c 39                	jl     1290e78 <myl_f_22849c51a4fd631aa66144da38552fb710206c5e57b8268459a8dc3a6dbcd390+0xc48>
 1290e3f:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
 1290e43:	48 8d b5 a8 fd ff ff 	lea    -0x258(%rbp),%rsi
 1290e4a:	49 89 fd             	mov    %rdi,%r13
 1290e4d:	e8 de 95 03 00       	call   12ca430 <myl_qbe_rc_frame_cleanup>
 1290e52:	4c 89 ef             	mov    %r13,%rdi
 1290e55:	48 8d b5 a8 fd ff ff 	lea    -0x258(%rbp),%rsi
 1290e5c:	e8 3f 94 03 00       	call   12ca2a0 <myl_qbe_rc_frame_leave>
 1290e61:	4c 89 e1             	mov    %r12,%rcx
 1290e64:	48 89 da             	mov    %rbx,%rdx
 1290e67:	48 89 c8             	mov    %rcx,%rax
 1290e6a:	48 01 d0             	add    %rdx,%rax
 1290e6d:	41 5f                	pop    %r15
 1290e6f:	41 5e                	pop    %r14
 1290e71:	41 5d                	pop    %r13
 1290e73:	41 5c                	pop    %r12
 1290e75:	5b                   	pop    %rbx
 1290e76:	c9                   	leave
 1290e77:	c3                   	ret
 1290e78:	48 89 da             	mov    %rbx,%rdx
 1290e7b:	4c 89 e1             	mov    %r12,%rcx
 1290e7e:	41 b8 40 00 00 00    	mov    $0x40,%r8d
 1290e84:	be 00 00 00 00       	mov    $0x0,%esi
 1290e89:	e8 62 a2 03 00       	call   12cb0f0 <myl_qbe_fail_overflow_op>
 1290e8e:	0f 0b                	ud2
 1290e90:	41 b8 40 00 00 00    	mov    $0x40,%r8d
 1290e96:	48 89 f2             	mov    %rsi,%rdx
 1290e99:	be 00 00 00 00       	mov    $0x0,%esi
 1290e9e:	e8 4d a2 03 00       	call   12cb0f0 <myl_qbe_fail_overflow_op>
 1290ea3:	0f 0b                	ud2
 1290ea5:	ba 40 01 00 00       	mov    $0x140,%edx
 1290eaa:	e8 81 a3 03 00       	call   12cb230 <myl_qbe_fail_cast>
 1290eaf:	0f 0b                	ud2
 1290eb1:	41 b8 40 00 00 00    	mov    $0x40,%r8d
 1290eb7:	b9 01 00 00 00       	mov    $0x1,%ecx
 1290ebc:	be 01 00 00 00       	mov    $0x1,%esi
 1290ec1:	e8 2a a2 03 00       	call   12cb0f0 <myl_qbe_fail_overflow_op>
 1290ec6:	0f 0b                	ud2
 1290ec8:	48 89 df             	mov    %rbx,%rdi
 1290ecb:	41 b8 40 00 00 00    	mov    $0x40,%r8d
 1290ed1:	b9 00 01 00 00       	mov    $0x100,%ecx
 1290ed6:	be 02 00 00 00       	mov    $0x2,%esi
 1290edb:	e8 10 a2 03 00       	call   12cb0f0 <myl_qbe_fail_overflow_op>
 1290ee0:	0f 0b                	ud2
 1290ee2:	41 b8 40 00 00 00    	mov    $0x40,%r8d
 1290ee8:	48 89 f2             	mov    %rsi,%rdx
 1290eeb:	be 00 00 00 00       	mov    $0x0,%esi
 1290ef0:	e8 fb a1 03 00       	call   12cb0f0 <myl_qbe_fail_overflow_op>
 1290ef5:	0f 0b                	ud2
 1290ef7:	ba 40 01 00 00       	mov    $0x140,%edx
 1290efc:	e8 2f a3 03 00       	call   12cb230 <myl_qbe_fail_cast>
 1290f01:	0f 0b                	ud2
 1290f03:	41 b8 40 00 00 00    	mov    $0x40,%r8d
 1290f09:	b9 02 00 00 00       	mov    $0x2,%ecx
 1290f0e:	be 01 00 00 00       	mov    $0x1,%esi
 1290f13:	e8 d8 a1 03 00       	call   12cb0f0 <myl_qbe_fail_overflow_op>
 1290f18:	0f 0b                	ud2
 1290f1a:	48 89 df             	mov    %rbx,%rdi
 1290f1d:	41 b8 40 00 00 00    	mov    $0x40,%r8d
 1290f23:	b9 02 00 00 00       	mov    $0x2,%ecx
 1290f28:	be 00 00 00 00       	mov    $0x0,%esi
 1290f2d:	e8 be a1 03 00       	call   12cb0f0 <myl_qbe_fail_overflow_op>
 1290f32:	0f 0b                	ud2

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
