
.tmp-mut-argument/scalar-run/nbody-llvm-after-rc:     file format elf64-x86-64


Disassembly of section .text:

0000000001017ab0 <myl_f_381cfb6e1e428419d5d6b5d113be06a9023d6407ebe388791ec3d59100d87ec5>:
 1017ab0:	55                   	push   %rbp
 1017ab1:	41 57                	push   %r15
 1017ab3:	41 56                	push   %r14
 1017ab5:	41 55                	push   %r13
 1017ab7:	41 54                	push   %r12
 1017ab9:	53                   	push   %rbx
 1017aba:	48 81 ec e8 01 00 00 	sub    $0x1e8,%rsp
 1017ac1:	48 89 74 24 28       	mov    %rsi,0x28(%rsp)
 1017ac6:	c5 f9 57 c0          	vxorpd %xmm0,%xmm0,%xmm0
 1017aca:	c5 fd 11 84 24 90 00 	vmovupd %ymm0,0x90(%rsp)
 1017ad1:	00 00 
 1017ad3:	48 c7 84 24 b0 00 00 	movq   $0x10023f8,0xb0(%rsp)
 1017ada:	00 f8 23 00 01 
 1017adf:	c7 84 24 c8 00 00 00 	movl   $0x2,0xc8(%rsp)
 1017ae6:	02 00 00 00 
 1017aea:	48 8d 44 24 28       	lea    0x28(%rsp),%rax
 1017aef:	48 89 84 24 b8 00 00 	mov    %rax,0xb8(%rsp)
 1017af6:	00 
 1017af7:	48 8d 84 24 90 00 00 	lea    0x90(%rsp),%rax
 1017afe:	00 
 1017aff:	48 89 84 24 c0 00 00 	mov    %rax,0xc0(%rsp)
 1017b06:	00 
 1017b07:	48 c7 84 24 d0 00 00 	movq   $0x1001cf8,0xd0(%rsp)
 1017b0e:	00 f8 1c 00 01 
 1017b13:	c7 84 24 e8 00 00 00 	movl   $0x0,0xe8(%rsp)
 1017b1a:	00 00 00 00 
 1017b1e:	48 8d 84 24 b0 01 00 	lea    0x1b0(%rsp),%rax
 1017b25:	00 
 1017b26:	48 89 84 24 d8 00 00 	mov    %rax,0xd8(%rsp)
 1017b2d:	00 
 1017b2e:	48 8d 84 24 98 00 00 	lea    0x98(%rsp),%rax
 1017b35:	00 
 1017b36:	48 89 84 24 e0 00 00 	mov    %rax,0xe0(%rsp)
 1017b3d:	00 
 1017b3e:	48 c7 84 24 f0 00 00 	movq   $0x1001cf8,0xf0(%rsp)
 1017b45:	00 f8 1c 00 01 
 1017b4a:	c7 84 24 08 01 00 00 	movl   $0x0,0x108(%rsp)
 1017b51:	00 00 00 00 
 1017b55:	48 8d 84 24 78 01 00 	lea    0x178(%rsp),%rax
 1017b5c:	00 
 1017b5d:	48 89 84 24 f8 00 00 	mov    %rax,0xf8(%rsp)
 1017b64:	00 
 1017b65:	48 8d 84 24 a0 00 00 	lea    0xa0(%rsp),%rax
 1017b6c:	00 
 1017b6d:	48 89 84 24 00 01 00 	mov    %rax,0x100(%rsp)
 1017b74:	00 
 1017b75:	48 c7 84 24 10 01 00 	movq   $0x1001cf8,0x110(%rsp)
 1017b7c:	00 f8 1c 00 01 
 1017b81:	c7 84 24 28 01 00 00 	movl   $0x0,0x128(%rsp)
 1017b88:	00 00 00 00 
 1017b8c:	48 8d 84 24 70 01 00 	lea    0x170(%rsp),%rax
 1017b93:	00 
 1017b94:	48 89 84 24 18 01 00 	mov    %rax,0x118(%rsp)
 1017b9b:	00 
 1017b9c:	48 8d 84 24 a8 00 00 	lea    0xa8(%rsp),%rax
 1017ba3:	00 
 1017ba4:	48 89 84 24 20 01 00 	mov    %rax,0x120(%rsp)
 1017bab:	00 
 1017bac:	48 85 ff             	test   %rdi,%rdi
 1017baf:	0f 84 75 02 00 00    	je     1017e2a <myl_f_381cfb6e1e428419d5d6b5d113be06a9023d6407ebe388791ec3d59100d87ec5+0x37a>
 1017bb5:	48 89 fb             	mov    %rdi,%rbx
 1017bb8:	48 8b 87 60 18 00 00 	mov    0x1860(%rdi),%rax
 1017bbf:	48 85 c0             	test   %rax,%rax
 1017bc2:	0f 84 62 02 00 00    	je     1017e2a <myl_f_381cfb6e1e428419d5d6b5d113be06a9023d6407ebe388791ec3d59100d87ec5+0x37a>
 1017bc8:	49 89 f6             	mov    %rsi,%r14
 1017bcb:	48 8b 8b 80 3d 00 00 	mov    0x3d80(%rbx),%rcx
 1017bd2:	48 8b 40 70          	mov    0x70(%rax),%rax
 1017bd6:	48 89 4c 24 30       	mov    %rcx,0x30(%rsp)
 1017bdb:	48 8d 8c 24 b0 00 00 	lea    0xb0(%rsp),%rcx
 1017be2:	00 
 1017be3:	48 89 4c 24 38       	mov    %rcx,0x38(%rsp)
 1017be8:	48 c7 44 24 40 04 00 	movq   $0x4,0x40(%rsp)
 1017bef:	00 00 
 1017bf1:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
 1017bf6:	4c 8d 7c 24 30       	lea    0x30(%rsp),%r15
 1017bfb:	4c 89 bb 80 3d 00 00 	mov    %r15,0x3d80(%rbx)
 1017c02:	4c 8b 26             	mov    (%rsi),%r12
 1017c05:	4d 85 e4             	test   %r12,%r12
 1017c08:	0f 88 44 02 00 00    	js     1017e52 <myl_f_381cfb6e1e428419d5d6b5d113be06a9023d6407ebe388791ec3d59100d87ec5+0x3a2>
 1017c0e:	0f 84 bb 01 00 00    	je     1017dcf <myl_f_381cfb6e1e428419d5d6b5d113be06a9023d6407ebe388791ec3d59100d87ec5+0x31f>
 1017c14:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
 1017c19:	c5 d9 57 e4          	vxorpd %xmm4,%xmm4,%xmm4
 1017c1d:	bb 38 00 00 00       	mov    $0x38,%ebx
 1017c22:	45 31 ed             	xor    %r13d,%r13d
 1017c25:	c5 d1 57 ed          	vxorpd %xmm5,%xmm5,%xmm5
 1017c29:	eb 12                	jmp    1017c3d <myl_f_381cfb6e1e428419d5d6b5d113be06a9023d6407ebe388791ec3d59100d87ec5+0x18d>
 1017c2b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
 1017c30:	48 83 c3 38          	add    $0x38,%rbx
 1017c34:	4d 39 e5             	cmp    %r12,%r13
 1017c37:	0f 84 81 01 00 00    	je     1017dbe <myl_f_381cfb6e1e428419d5d6b5d113be06a9023d6407ebe388791ec3d59100d87ec5+0x30e>
 1017c3d:	49 8b 16             	mov    (%r14),%rdx
 1017c40:	49 39 d5             	cmp    %rdx,%r13
 1017c43:	0f 83 f9 01 00 00    	jae    1017e42 <myl_f_381cfb6e1e428419d5d6b5d113be06a9023d6407ebe388791ec3d59100d87ec5+0x392>
 1017c49:	49 8b 46 20          	mov    0x20(%r14),%rax
 1017c4d:	49 6b cd 38          	imul   $0x38,%r13,%rcx
 1017c51:	c5 f8 10 44 08 20    	vmovups 0x20(%rax,%rcx,1),%xmm0
 1017c57:	c5 fc 10 0c 08       	vmovups (%rax,%rcx,1),%ymm1
 1017c5c:	48 8b 44 08 30       	mov    0x30(%rax,%rcx,1),%rax
 1017c61:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
 1017c68:	00 
 1017c69:	c5 fc 11 4c 24 50    	vmovups %ymm1,0x50(%rsp)
 1017c6f:	c5 f8 29 44 24 70    	vmovaps %xmm0,0x70(%rsp)
 1017c75:	c5 fb 10 05 a3 9c fe 	vmovsd -0x1635d(%rip),%xmm0        # 1001920 <__abi_tag+0x1624>
 1017c7c:	ff 
 1017c7d:	c5 fb 59 84 24 80 00 	vmulsd 0x80(%rsp),%xmm0,%xmm0
 1017c84:	00 00 
 1017c86:	c5 fb 10 4c 24 68    	vmovsd 0x68(%rsp),%xmm1
 1017c8c:	c5 f3 59 c9          	vmulsd %xmm1,%xmm1,%xmm1
 1017c90:	c5 fb 10 54 24 70    	vmovsd 0x70(%rsp),%xmm2
 1017c96:	c5 fb 10 5c 24 78    	vmovsd 0x78(%rsp),%xmm3
 1017c9c:	c5 eb 59 d2          	vmulsd %xmm2,%xmm2,%xmm2
 1017ca0:	c5 f3 58 ca          	vaddsd %xmm2,%xmm1,%xmm1
 1017ca4:	c5 e3 59 d3          	vmulsd %xmm3,%xmm3,%xmm2
 1017ca8:	c5 eb 58 c9          	vaddsd %xmm1,%xmm2,%xmm1
 1017cac:	c5 fb 59 c1          	vmulsd %xmm1,%xmm0,%xmm0
 1017cb0:	c5 d3 58 e8          	vaddsd %xmm0,%xmm5,%xmm5
 1017cb4:	49 ff c5             	inc    %r13
 1017cb7:	4d 39 e5             	cmp    %r12,%r13
 1017cba:	0f 8d 70 ff ff ff    	jge    1017c30 <myl_f_381cfb6e1e428419d5d6b5d113be06a9023d6407ebe388791ec3d59100d87ec5+0x180>
 1017cc0:	c5 fb 10 74 24 50    	vmovsd 0x50(%rsp),%xmm6
 1017cc6:	49 89 df             	mov    %rbx,%r15
 1017cc9:	4c 89 ed             	mov    %r13,%rbp
 1017ccc:	c5 fb 11 74 24 10    	vmovsd %xmm6,0x10(%rsp)
 1017cd2:	eb 4e                	jmp    1017d22 <myl_f_381cfb6e1e428419d5d6b5d113be06a9023d6407ebe388791ec3d59100d87ec5+0x272>
 1017cd4:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
 1017cdb:	00 00 00 00 00 
 1017ce0:	c5 fb 11 6c 24 20    	vmovsd %xmm5,0x20(%rsp)
 1017ce6:	c5 fb 11 5c 24 18    	vmovsd %xmm3,0x18(%rsp)
 1017cec:	c5 f8 77             	vzeroupper
 1017cef:	e8 cc 36 01 00       	call   102b3c0 <sqrt@plt>
 1017cf4:	c5 fb 10 5c 24 18    	vmovsd 0x18(%rsp),%xmm3
 1017cfa:	c5 fb 10 74 24 10    	vmovsd 0x10(%rsp),%xmm6
 1017d00:	c5 fb 10 6c 24 20    	vmovsd 0x20(%rsp),%xmm5
 1017d06:	c5 d9 57 e4          	vxorpd %xmm4,%xmm4,%xmm4
 1017d0a:	c5 e3 5e c0          	vdivsd %xmm0,%xmm3,%xmm0
 1017d0e:	c5 d3 5c e8          	vsubsd %xmm0,%xmm5,%xmm5
 1017d12:	48 ff c5             	inc    %rbp
 1017d15:	49 83 c7 38          	add    $0x38,%r15
 1017d19:	49 39 ec             	cmp    %rbp,%r12
 1017d1c:	0f 84 0e ff ff ff    	je     1017c30 <myl_f_381cfb6e1e428419d5d6b5d113be06a9023d6407ebe388791ec3d59100d87ec5+0x180>
 1017d22:	49 8b 16             	mov    (%r14),%rdx
 1017d25:	48 39 d5             	cmp    %rdx,%rbp
 1017d28:	0f 83 04 01 00 00    	jae    1017e32 <myl_f_381cfb6e1e428419d5d6b5d113be06a9023d6407ebe388791ec3d59100d87ec5+0x382>
 1017d2e:	49 8b 46 20          	mov    0x20(%r14),%rax
 1017d32:	c4 c1 78 10 44 07 20 	vmovups 0x20(%r15,%rax,1),%xmm0
 1017d39:	49 8b 4c 07 30       	mov    0x30(%r15,%rax,1),%rcx
 1017d3e:	c4 c1 7c 10 0c 07    	vmovups (%r15,%rax,1),%ymm1
 1017d44:	c5 fc 11 8c 24 30 01 	vmovups %ymm1,0x130(%rsp)
 1017d4b:	00 00 
 1017d4d:	48 89 8c 24 60 01 00 	mov    %rcx,0x160(%rsp)
 1017d54:	00 
 1017d55:	c5 f8 29 84 24 50 01 	vmovaps %xmm0,0x150(%rsp)
 1017d5c:	00 00 
 1017d5e:	c5 cb 5c 84 24 30 01 	vsubsd 0x130(%rsp),%xmm6,%xmm0
 1017d65:	00 00 
 1017d67:	c5 fb 10 4c 24 58    	vmovsd 0x58(%rsp),%xmm1
 1017d6d:	c5 fb 10 54 24 60    	vmovsd 0x60(%rsp),%xmm2
 1017d73:	c5 f3 5c 8c 24 38 01 	vsubsd 0x138(%rsp),%xmm1,%xmm1
 1017d7a:	00 00 
 1017d7c:	c5 eb 5c 94 24 40 01 	vsubsd 0x140(%rsp),%xmm2,%xmm2
 1017d83:	00 00 
 1017d85:	c5 fb 10 9c 24 80 00 	vmovsd 0x80(%rsp),%xmm3
 1017d8c:	00 00 
 1017d8e:	c5 e3 59 9c 24 60 01 	vmulsd 0x160(%rsp),%xmm3,%xmm3
 1017d95:	00 00 
 1017d97:	c5 fb 59 c0          	vmulsd %xmm0,%xmm0,%xmm0
 1017d9b:	c5 f3 59 c9          	vmulsd %xmm1,%xmm1,%xmm1
 1017d9f:	c5 fb 58 c1          	vaddsd %xmm1,%xmm0,%xmm0
 1017da3:	c5 eb 59 ca          	vmulsd %xmm2,%xmm2,%xmm1
 1017da7:	c5 fb 58 c1          	vaddsd %xmm1,%xmm0,%xmm0
 1017dab:	c5 f9 2e c4          	vucomisd %xmm4,%xmm0
 1017daf:	0f 82 2b ff ff ff    	jb     1017ce0 <myl_f_381cfb6e1e428419d5d6b5d113be06a9023d6407ebe388791ec3d59100d87ec5+0x230>
 1017db5:	c5 fb 51 c0          	vsqrtsd %xmm0,%xmm0,%xmm0
 1017db9:	e9 4c ff ff ff       	jmp    1017d0a <myl_f_381cfb6e1e428419d5d6b5d113be06a9023d6407ebe388791ec3d59100d87ec5+0x25a>
 1017dbe:	c4 c1 f9 7e ee       	vmovq  %xmm5,%r14
 1017dc3:	48 8b 5c 24 08       	mov    0x8(%rsp),%rbx
 1017dc8:	4c 8d 7c 24 30       	lea    0x30(%rsp),%r15
 1017dcd:	eb 03                	jmp    1017dd2 <myl_f_381cfb6e1e428419d5d6b5d113be06a9023d6407ebe388791ec3d59100d87ec5+0x322>
 1017dcf:	45 31 f6             	xor    %r14d,%r14d
 1017dd2:	48 89 df             	mov    %rbx,%rdi
 1017dd5:	4c 89 fe             	mov    %r15,%rsi
 1017dd8:	c5 f8 77             	vzeroupper
 1017ddb:	e8 40 2d 00 00       	call   101ab20 <myl_qbe_rc_frame_cleanup>
 1017de0:	4c 39 bb 80 3d 00 00 	cmp    %r15,0x3d80(%rbx)
 1017de7:	75 41                	jne    1017e2a <myl_f_381cfb6e1e428419d5d6b5d113be06a9023d6407ebe388791ec3d59100d87ec5+0x37a>
 1017de9:	48 8b 83 60 18 00 00 	mov    0x1860(%rbx),%rax
 1017df0:	48 85 c0             	test   %rax,%rax
 1017df3:	74 2c                	je     1017e21 <myl_f_381cfb6e1e428419d5d6b5d113be06a9023d6407ebe388791ec3d59100d87ec5+0x371>
 1017df5:	48 8b 40 70          	mov    0x70(%rax),%rax
 1017df9:	48 3b 44 24 48       	cmp    0x48(%rsp),%rax
 1017dfe:	75 2a                	jne    1017e2a <myl_f_381cfb6e1e428419d5d6b5d113be06a9023d6407ebe388791ec3d59100d87ec5+0x37a>
 1017e00:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
 1017e05:	48 89 83 80 3d 00 00 	mov    %rax,0x3d80(%rbx)
 1017e0c:	4c 89 f0             	mov    %r14,%rax
 1017e0f:	48 81 c4 e8 01 00 00 	add    $0x1e8,%rsp
 1017e16:	5b                   	pop    %rbx
 1017e17:	41 5c                	pop    %r12
 1017e19:	41 5d                	pop    %r13
 1017e1b:	41 5e                	pop    %r14
 1017e1d:	41 5f                	pop    %r15
 1017e1f:	5d                   	pop    %rbp
 1017e20:	c3                   	ret
 1017e21:	31 c0                	xor    %eax,%eax
 1017e23:	48 3b 44 24 48       	cmp    0x48(%rsp),%rax
 1017e28:	74 d6                	je     1017e00 <myl_f_381cfb6e1e428419d5d6b5d113be06a9023d6407ebe388791ec3d59100d87ec5+0x350>
 1017e2a:	c5 f8 77             	vzeroupper
 1017e2d:	e8 62 84 00 00       	call   1020294 <myl_rc_invariant_failed>
 1017e32:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
 1017e37:	48 89 ee             	mov    %rbp,%rsi
 1017e3a:	c5 f8 77             	vzeroupper
 1017e3d:	e8 7e 3f 00 00       	call   101bdc0 <myl_qbe_fail_normalized_index_bounds>
 1017e42:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
 1017e47:	4c 89 ee             	mov    %r13,%rsi
 1017e4a:	c5 f8 77             	vzeroupper
 1017e4d:	e8 6e 3f 00 00       	call   101bdc0 <myl_qbe_fail_normalized_index_bounds>
 1017e52:	48 89 df             	mov    %rbx,%rdi
 1017e55:	4c 89 e6             	mov    %r12,%rsi
 1017e58:	c5 f8 77             	vzeroupper
 1017e5b:	e8 40 40 00 00       	call   101bea0 <myl_qbe_fail_cast>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
