
.tmp-mut-argument/scalar-run/nbody-llvm-before-rc:     file format elf64-x86-64


Disassembly of section .text:

0000000001017a40 <myl_f_381cfb6e1e428419d5d6b5d113be06a9023d6407ebe388791ec3d59100d87ec5>:
 1017a40:	55                   	push   %rbp
 1017a41:	41 57                	push   %r15
 1017a43:	41 56                	push   %r14
 1017a45:	41 55                	push   %r13
 1017a47:	41 54                	push   %r12
 1017a49:	53                   	push   %rbx
 1017a4a:	48 81 ec e8 01 00 00 	sub    $0x1e8,%rsp
 1017a51:	48 89 74 24 28       	mov    %rsi,0x28(%rsp)
 1017a56:	c5 f9 57 c0          	vxorpd %xmm0,%xmm0,%xmm0
 1017a5a:	c5 fd 11 84 24 90 00 	vmovupd %ymm0,0x90(%rsp)
 1017a61:	00 00 
 1017a63:	48 c7 84 24 b0 00 00 	movq   $0x10023f8,0xb0(%rsp)
 1017a6a:	00 f8 23 00 01 
 1017a6f:	c7 84 24 c8 00 00 00 	movl   $0x2,0xc8(%rsp)
 1017a76:	02 00 00 00 
 1017a7a:	48 8d 44 24 28       	lea    0x28(%rsp),%rax
 1017a7f:	48 89 84 24 b8 00 00 	mov    %rax,0xb8(%rsp)
 1017a86:	00 
 1017a87:	48 8d 84 24 90 00 00 	lea    0x90(%rsp),%rax
 1017a8e:	00 
 1017a8f:	48 89 84 24 c0 00 00 	mov    %rax,0xc0(%rsp)
 1017a96:	00 
 1017a97:	48 c7 84 24 d0 00 00 	movq   $0x1001cf8,0xd0(%rsp)
 1017a9e:	00 f8 1c 00 01 
 1017aa3:	c7 84 24 e8 00 00 00 	movl   $0x0,0xe8(%rsp)
 1017aaa:	00 00 00 00 
 1017aae:	48 8d 84 24 b0 01 00 	lea    0x1b0(%rsp),%rax
 1017ab5:	00 
 1017ab6:	48 89 84 24 d8 00 00 	mov    %rax,0xd8(%rsp)
 1017abd:	00 
 1017abe:	48 8d 84 24 98 00 00 	lea    0x98(%rsp),%rax
 1017ac5:	00 
 1017ac6:	48 89 84 24 e0 00 00 	mov    %rax,0xe0(%rsp)
 1017acd:	00 
 1017ace:	48 c7 84 24 f0 00 00 	movq   $0x1001cf8,0xf0(%rsp)
 1017ad5:	00 f8 1c 00 01 
 1017ada:	c7 84 24 08 01 00 00 	movl   $0x0,0x108(%rsp)
 1017ae1:	00 00 00 00 
 1017ae5:	48 8d 84 24 78 01 00 	lea    0x178(%rsp),%rax
 1017aec:	00 
 1017aed:	48 89 84 24 f8 00 00 	mov    %rax,0xf8(%rsp)
 1017af4:	00 
 1017af5:	48 8d 84 24 a0 00 00 	lea    0xa0(%rsp),%rax
 1017afc:	00 
 1017afd:	48 89 84 24 00 01 00 	mov    %rax,0x100(%rsp)
 1017b04:	00 
 1017b05:	48 c7 84 24 10 01 00 	movq   $0x1001cf8,0x110(%rsp)
 1017b0c:	00 f8 1c 00 01 
 1017b11:	c7 84 24 28 01 00 00 	movl   $0x0,0x128(%rsp)
 1017b18:	00 00 00 00 
 1017b1c:	48 8d 84 24 70 01 00 	lea    0x170(%rsp),%rax
 1017b23:	00 
 1017b24:	48 89 84 24 18 01 00 	mov    %rax,0x118(%rsp)
 1017b2b:	00 
 1017b2c:	48 8d 84 24 a8 00 00 	lea    0xa8(%rsp),%rax
 1017b33:	00 
 1017b34:	48 89 84 24 20 01 00 	mov    %rax,0x120(%rsp)
 1017b3b:	00 
 1017b3c:	48 85 ff             	test   %rdi,%rdi
 1017b3f:	0f 84 75 02 00 00    	je     1017dba <myl_f_381cfb6e1e428419d5d6b5d113be06a9023d6407ebe388791ec3d59100d87ec5+0x37a>
 1017b45:	48 89 fb             	mov    %rdi,%rbx
 1017b48:	48 8b 87 60 18 00 00 	mov    0x1860(%rdi),%rax
 1017b4f:	48 85 c0             	test   %rax,%rax
 1017b52:	0f 84 62 02 00 00    	je     1017dba <myl_f_381cfb6e1e428419d5d6b5d113be06a9023d6407ebe388791ec3d59100d87ec5+0x37a>
 1017b58:	49 89 f6             	mov    %rsi,%r14
 1017b5b:	48 8b 8b 80 3d 00 00 	mov    0x3d80(%rbx),%rcx
 1017b62:	48 8b 40 70          	mov    0x70(%rax),%rax
 1017b66:	48 89 4c 24 30       	mov    %rcx,0x30(%rsp)
 1017b6b:	48 8d 8c 24 b0 00 00 	lea    0xb0(%rsp),%rcx
 1017b72:	00 
 1017b73:	48 89 4c 24 38       	mov    %rcx,0x38(%rsp)
 1017b78:	48 c7 44 24 40 04 00 	movq   $0x4,0x40(%rsp)
 1017b7f:	00 00 
 1017b81:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
 1017b86:	4c 8d 7c 24 30       	lea    0x30(%rsp),%r15
 1017b8b:	4c 89 bb 80 3d 00 00 	mov    %r15,0x3d80(%rbx)
 1017b92:	4c 8b 26             	mov    (%rsi),%r12
 1017b95:	4d 85 e4             	test   %r12,%r12
 1017b98:	0f 88 44 02 00 00    	js     1017de2 <myl_f_381cfb6e1e428419d5d6b5d113be06a9023d6407ebe388791ec3d59100d87ec5+0x3a2>
 1017b9e:	0f 84 bb 01 00 00    	je     1017d5f <myl_f_381cfb6e1e428419d5d6b5d113be06a9023d6407ebe388791ec3d59100d87ec5+0x31f>
 1017ba4:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
 1017ba9:	c5 d9 57 e4          	vxorpd %xmm4,%xmm4,%xmm4
 1017bad:	bb 38 00 00 00       	mov    $0x38,%ebx
 1017bb2:	45 31 ed             	xor    %r13d,%r13d
 1017bb5:	c5 d1 57 ed          	vxorpd %xmm5,%xmm5,%xmm5
 1017bb9:	eb 12                	jmp    1017bcd <myl_f_381cfb6e1e428419d5d6b5d113be06a9023d6407ebe388791ec3d59100d87ec5+0x18d>
 1017bbb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
 1017bc0:	48 83 c3 38          	add    $0x38,%rbx
 1017bc4:	4d 39 e5             	cmp    %r12,%r13
 1017bc7:	0f 84 81 01 00 00    	je     1017d4e <myl_f_381cfb6e1e428419d5d6b5d113be06a9023d6407ebe388791ec3d59100d87ec5+0x30e>
 1017bcd:	49 8b 16             	mov    (%r14),%rdx
 1017bd0:	49 39 d5             	cmp    %rdx,%r13
 1017bd3:	0f 83 f9 01 00 00    	jae    1017dd2 <myl_f_381cfb6e1e428419d5d6b5d113be06a9023d6407ebe388791ec3d59100d87ec5+0x392>
 1017bd9:	49 8b 46 20          	mov    0x20(%r14),%rax
 1017bdd:	49 6b cd 38          	imul   $0x38,%r13,%rcx
 1017be1:	c5 f8 10 44 08 20    	vmovups 0x20(%rax,%rcx,1),%xmm0
 1017be7:	c5 fc 10 0c 08       	vmovups (%rax,%rcx,1),%ymm1
 1017bec:	48 8b 44 08 30       	mov    0x30(%rax,%rcx,1),%rax
 1017bf1:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
 1017bf8:	00 
 1017bf9:	c5 fc 11 4c 24 50    	vmovups %ymm1,0x50(%rsp)
 1017bff:	c5 f8 29 44 24 70    	vmovaps %xmm0,0x70(%rsp)
 1017c05:	c5 fb 10 05 13 9d fe 	vmovsd -0x162ed(%rip),%xmm0        # 1001920 <__abi_tag+0x1624>
 1017c0c:	ff 
 1017c0d:	c5 fb 59 84 24 80 00 	vmulsd 0x80(%rsp),%xmm0,%xmm0
 1017c14:	00 00 
 1017c16:	c5 fb 10 4c 24 68    	vmovsd 0x68(%rsp),%xmm1
 1017c1c:	c5 f3 59 c9          	vmulsd %xmm1,%xmm1,%xmm1
 1017c20:	c5 fb 10 54 24 70    	vmovsd 0x70(%rsp),%xmm2
 1017c26:	c5 fb 10 5c 24 78    	vmovsd 0x78(%rsp),%xmm3
 1017c2c:	c5 eb 59 d2          	vmulsd %xmm2,%xmm2,%xmm2
 1017c30:	c5 f3 58 ca          	vaddsd %xmm2,%xmm1,%xmm1
 1017c34:	c5 e3 59 d3          	vmulsd %xmm3,%xmm3,%xmm2
 1017c38:	c5 eb 58 c9          	vaddsd %xmm1,%xmm2,%xmm1
 1017c3c:	c5 fb 59 c1          	vmulsd %xmm1,%xmm0,%xmm0
 1017c40:	c5 d3 58 e8          	vaddsd %xmm0,%xmm5,%xmm5
 1017c44:	49 ff c5             	inc    %r13
 1017c47:	4d 39 e5             	cmp    %r12,%r13
 1017c4a:	0f 8d 70 ff ff ff    	jge    1017bc0 <myl_f_381cfb6e1e428419d5d6b5d113be06a9023d6407ebe388791ec3d59100d87ec5+0x180>
 1017c50:	c5 fb 10 74 24 50    	vmovsd 0x50(%rsp),%xmm6
 1017c56:	49 89 df             	mov    %rbx,%r15
 1017c59:	4c 89 ed             	mov    %r13,%rbp
 1017c5c:	c5 fb 11 74 24 10    	vmovsd %xmm6,0x10(%rsp)
 1017c62:	eb 4e                	jmp    1017cb2 <myl_f_381cfb6e1e428419d5d6b5d113be06a9023d6407ebe388791ec3d59100d87ec5+0x272>
 1017c64:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
 1017c6b:	00 00 00 00 00 
 1017c70:	c5 fb 11 6c 24 20    	vmovsd %xmm5,0x20(%rsp)
 1017c76:	c5 fb 11 5c 24 18    	vmovsd %xmm3,0x18(%rsp)
 1017c7c:	c5 f8 77             	vzeroupper
 1017c7f:	e8 cc 36 01 00       	call   102b350 <sqrt@plt>
 1017c84:	c5 fb 10 5c 24 18    	vmovsd 0x18(%rsp),%xmm3
 1017c8a:	c5 fb 10 74 24 10    	vmovsd 0x10(%rsp),%xmm6
 1017c90:	c5 fb 10 6c 24 20    	vmovsd 0x20(%rsp),%xmm5
 1017c96:	c5 d9 57 e4          	vxorpd %xmm4,%xmm4,%xmm4
 1017c9a:	c5 e3 5e c0          	vdivsd %xmm0,%xmm3,%xmm0
 1017c9e:	c5 d3 5c e8          	vsubsd %xmm0,%xmm5,%xmm5
 1017ca2:	48 ff c5             	inc    %rbp
 1017ca5:	49 83 c7 38          	add    $0x38,%r15
 1017ca9:	49 39 ec             	cmp    %rbp,%r12
 1017cac:	0f 84 0e ff ff ff    	je     1017bc0 <myl_f_381cfb6e1e428419d5d6b5d113be06a9023d6407ebe388791ec3d59100d87ec5+0x180>
 1017cb2:	49 8b 16             	mov    (%r14),%rdx
 1017cb5:	48 39 d5             	cmp    %rdx,%rbp
 1017cb8:	0f 83 04 01 00 00    	jae    1017dc2 <myl_f_381cfb6e1e428419d5d6b5d113be06a9023d6407ebe388791ec3d59100d87ec5+0x382>
 1017cbe:	49 8b 46 20          	mov    0x20(%r14),%rax
 1017cc2:	c4 c1 78 10 44 07 20 	vmovups 0x20(%r15,%rax,1),%xmm0
 1017cc9:	49 8b 4c 07 30       	mov    0x30(%r15,%rax,1),%rcx
 1017cce:	c4 c1 7c 10 0c 07    	vmovups (%r15,%rax,1),%ymm1
 1017cd4:	c5 fc 11 8c 24 30 01 	vmovups %ymm1,0x130(%rsp)
 1017cdb:	00 00 
 1017cdd:	48 89 8c 24 60 01 00 	mov    %rcx,0x160(%rsp)
 1017ce4:	00 
 1017ce5:	c5 f8 29 84 24 50 01 	vmovaps %xmm0,0x150(%rsp)
 1017cec:	00 00 
 1017cee:	c5 cb 5c 84 24 30 01 	vsubsd 0x130(%rsp),%xmm6,%xmm0
 1017cf5:	00 00 
 1017cf7:	c5 fb 10 4c 24 58    	vmovsd 0x58(%rsp),%xmm1
 1017cfd:	c5 fb 10 54 24 60    	vmovsd 0x60(%rsp),%xmm2
 1017d03:	c5 f3 5c 8c 24 38 01 	vsubsd 0x138(%rsp),%xmm1,%xmm1
 1017d0a:	00 00 
 1017d0c:	c5 eb 5c 94 24 40 01 	vsubsd 0x140(%rsp),%xmm2,%xmm2
 1017d13:	00 00 
 1017d15:	c5 fb 10 9c 24 80 00 	vmovsd 0x80(%rsp),%xmm3
 1017d1c:	00 00 
 1017d1e:	c5 e3 59 9c 24 60 01 	vmulsd 0x160(%rsp),%xmm3,%xmm3
 1017d25:	00 00 
 1017d27:	c5 fb 59 c0          	vmulsd %xmm0,%xmm0,%xmm0
 1017d2b:	c5 f3 59 c9          	vmulsd %xmm1,%xmm1,%xmm1
 1017d2f:	c5 fb 58 c1          	vaddsd %xmm1,%xmm0,%xmm0
 1017d33:	c5 eb 59 ca          	vmulsd %xmm2,%xmm2,%xmm1
 1017d37:	c5 fb 58 c1          	vaddsd %xmm1,%xmm0,%xmm0
 1017d3b:	c5 f9 2e c4          	vucomisd %xmm4,%xmm0
 1017d3f:	0f 82 2b ff ff ff    	jb     1017c70 <myl_f_381cfb6e1e428419d5d6b5d113be06a9023d6407ebe388791ec3d59100d87ec5+0x230>
 1017d45:	c5 fb 51 c0          	vsqrtsd %xmm0,%xmm0,%xmm0
 1017d49:	e9 4c ff ff ff       	jmp    1017c9a <myl_f_381cfb6e1e428419d5d6b5d113be06a9023d6407ebe388791ec3d59100d87ec5+0x25a>
 1017d4e:	c4 c1 f9 7e ee       	vmovq  %xmm5,%r14
 1017d53:	48 8b 5c 24 08       	mov    0x8(%rsp),%rbx
 1017d58:	4c 8d 7c 24 30       	lea    0x30(%rsp),%r15
 1017d5d:	eb 03                	jmp    1017d62 <myl_f_381cfb6e1e428419d5d6b5d113be06a9023d6407ebe388791ec3d59100d87ec5+0x322>
 1017d5f:	45 31 f6             	xor    %r14d,%r14d
 1017d62:	48 89 df             	mov    %rbx,%rdi
 1017d65:	4c 89 fe             	mov    %r15,%rsi
 1017d68:	c5 f8 77             	vzeroupper
 1017d6b:	e8 40 2d 00 00       	call   101aab0 <myl_qbe_rc_frame_cleanup>
 1017d70:	4c 39 bb 80 3d 00 00 	cmp    %r15,0x3d80(%rbx)
 1017d77:	75 41                	jne    1017dba <myl_f_381cfb6e1e428419d5d6b5d113be06a9023d6407ebe388791ec3d59100d87ec5+0x37a>
 1017d79:	48 8b 83 60 18 00 00 	mov    0x1860(%rbx),%rax
 1017d80:	48 85 c0             	test   %rax,%rax
 1017d83:	74 2c                	je     1017db1 <myl_f_381cfb6e1e428419d5d6b5d113be06a9023d6407ebe388791ec3d59100d87ec5+0x371>
 1017d85:	48 8b 40 70          	mov    0x70(%rax),%rax
 1017d89:	48 3b 44 24 48       	cmp    0x48(%rsp),%rax
 1017d8e:	75 2a                	jne    1017dba <myl_f_381cfb6e1e428419d5d6b5d113be06a9023d6407ebe388791ec3d59100d87ec5+0x37a>
 1017d90:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
 1017d95:	48 89 83 80 3d 00 00 	mov    %rax,0x3d80(%rbx)
 1017d9c:	4c 89 f0             	mov    %r14,%rax
 1017d9f:	48 81 c4 e8 01 00 00 	add    $0x1e8,%rsp
 1017da6:	5b                   	pop    %rbx
 1017da7:	41 5c                	pop    %r12
 1017da9:	41 5d                	pop    %r13
 1017dab:	41 5e                	pop    %r14
 1017dad:	41 5f                	pop    %r15
 1017daf:	5d                   	pop    %rbp
 1017db0:	c3                   	ret
 1017db1:	31 c0                	xor    %eax,%eax
 1017db3:	48 3b 44 24 48       	cmp    0x48(%rsp),%rax
 1017db8:	74 d6                	je     1017d90 <myl_f_381cfb6e1e428419d5d6b5d113be06a9023d6407ebe388791ec3d59100d87ec5+0x350>
 1017dba:	c5 f8 77             	vzeroupper
 1017dbd:	e8 62 84 00 00       	call   1020224 <myl_rc_invariant_failed>
 1017dc2:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
 1017dc7:	48 89 ee             	mov    %rbp,%rsi
 1017dca:	c5 f8 77             	vzeroupper
 1017dcd:	e8 7e 3f 00 00       	call   101bd50 <myl_qbe_fail_normalized_index_bounds>
 1017dd2:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
 1017dd7:	4c 89 ee             	mov    %r13,%rsi
 1017dda:	c5 f8 77             	vzeroupper
 1017ddd:	e8 6e 3f 00 00       	call   101bd50 <myl_qbe_fail_normalized_index_bounds>
 1017de2:	48 89 df             	mov    %rbx,%rdi
 1017de5:	4c 89 e6             	mov    %r12,%rsi
 1017de8:	c5 f8 77             	vzeroupper
 1017deb:	e8 40 40 00 00       	call   101be30 <myl_qbe_fail_cast>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
