
.tmp-mut-argument/scalar-run/nbody-qbe-after-rc:     file format elf64-x86-64


Disassembly of section .text:

000000000100a110 <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85>:
 100a110:	f3 0f 1e fa          	endbr64
 100a114:	55                   	push   %rbp
 100a115:	48 89 e5             	mov    %rsp,%rbp
 100a118:	48 81 ec f8 05 00 00 	sub    $0x5f8,%rsp
 100a11f:	53                   	push   %rbx
 100a120:	41 54                	push   %r12
 100a122:	41 55                	push   %r13
 100a124:	41 56                	push   %r14
 100a126:	41 57                	push   %r15
 100a128:	49 89 d5             	mov    %rdx,%r13
 100a12b:	ba 20 00 00 00       	mov    $0x20,%edx
 100a130:	49 89 f4             	mov    %rsi,%r12
 100a133:	be 00 00 00 00       	mov    $0x0,%esi
 100a138:	48 89 fb             	mov    %rdi,%rbx
 100a13b:	48 8d bd 50 fb ff ff 	lea    -0x4b0(%rbp),%rdi
 100a142:	e8 c9 40 01 00       	call   101e210 <compiler_rt.fastMemset>
 100a147:	4c 89 ea             	mov    %r13,%rdx
 100a14a:	4c 89 e6             	mov    %r12,%rsi
 100a14d:	48 89 df             	mov    %rbx,%rdi
 100a150:	49 89 d5             	mov    %rdx,%r13
 100a153:	ba 20 00 00 00       	mov    $0x20,%edx
 100a158:	49 89 f4             	mov    %rsi,%r12
 100a15b:	be 00 00 00 00       	mov    $0x0,%esi
 100a160:	48 89 fb             	mov    %rdi,%rbx
 100a163:	48 8d bd 70 fb ff ff 	lea    -0x490(%rbp),%rdi
 100a16a:	e8 a1 40 01 00       	call   101e210 <compiler_rt.fastMemset>
 100a16f:	4c 89 ea             	mov    %r13,%rdx
 100a172:	4c 89 e6             	mov    %r12,%rsi
 100a175:	48 89 df             	mov    %rbx,%rdi
 100a178:	49 89 d5             	mov    %rdx,%r13
 100a17b:	ba 20 00 00 00       	mov    $0x20,%edx
 100a180:	49 89 f4             	mov    %rsi,%r12
 100a183:	be 00 00 00 00       	mov    $0x0,%esi
 100a188:	48 89 fb             	mov    %rdi,%rbx
 100a18b:	48 8d bd 90 fb ff ff 	lea    -0x470(%rbp),%rdi
 100a192:	e8 79 40 01 00       	call   101e210 <compiler_rt.fastMemset>
 100a197:	4c 89 ea             	mov    %r13,%rdx
 100a19a:	4c 89 e6             	mov    %r12,%rsi
 100a19d:	48 89 df             	mov    %rbx,%rdi
 100a1a0:	49 89 d5             	mov    %rdx,%r13
 100a1a3:	ba 20 00 00 00       	mov    $0x20,%edx
 100a1a8:	49 89 f4             	mov    %rsi,%r12
 100a1ab:	be 00 00 00 00       	mov    $0x0,%esi
 100a1b0:	48 89 fb             	mov    %rdi,%rbx
 100a1b3:	48 8d bd b0 fb ff ff 	lea    -0x450(%rbp),%rdi
 100a1ba:	e8 51 40 01 00       	call   101e210 <compiler_rt.fastMemset>
 100a1bf:	4c 89 ea             	mov    %r13,%rdx
 100a1c2:	4c 89 e6             	mov    %r12,%rsi
 100a1c5:	48 89 df             	mov    %rbx,%rdi
 100a1c8:	49 89 d5             	mov    %rdx,%r13
 100a1cb:	ba 20 00 00 00       	mov    $0x20,%edx
 100a1d0:	49 89 f4             	mov    %rsi,%r12
 100a1d3:	be 00 00 00 00       	mov    $0x0,%esi
 100a1d8:	48 89 fb             	mov    %rdi,%rbx
 100a1db:	48 8d bd d0 fb ff ff 	lea    -0x430(%rbp),%rdi
 100a1e2:	e8 29 40 01 00       	call   101e210 <compiler_rt.fastMemset>
 100a1e7:	4c 89 ea             	mov    %r13,%rdx
 100a1ea:	4c 89 e6             	mov    %r12,%rsi
 100a1ed:	48 89 df             	mov    %rbx,%rdi
 100a1f0:	49 89 d5             	mov    %rdx,%r13
 100a1f3:	ba 20 00 00 00       	mov    $0x20,%edx
 100a1f8:	49 89 f4             	mov    %rsi,%r12
 100a1fb:	be 00 00 00 00       	mov    $0x0,%esi
 100a200:	48 89 fb             	mov    %rdi,%rbx
 100a203:	48 8d bd f0 fb ff ff 	lea    -0x410(%rbp),%rdi
 100a20a:	e8 01 40 01 00       	call   101e210 <compiler_rt.fastMemset>
 100a20f:	4c 89 ea             	mov    %r13,%rdx
 100a212:	4c 89 e6             	mov    %r12,%rsi
 100a215:	48 89 df             	mov    %rbx,%rdi
 100a218:	49 89 d5             	mov    %rdx,%r13
 100a21b:	ba 20 00 00 00       	mov    $0x20,%edx
 100a220:	49 89 f4             	mov    %rsi,%r12
 100a223:	be 00 00 00 00       	mov    $0x0,%esi
 100a228:	48 89 fb             	mov    %rdi,%rbx
 100a22b:	48 8d bd 10 fc ff ff 	lea    -0x3f0(%rbp),%rdi
 100a232:	e8 d9 3f 01 00       	call   101e210 <compiler_rt.fastMemset>
 100a237:	4c 89 ea             	mov    %r13,%rdx
 100a23a:	4c 89 e6             	mov    %r12,%rsi
 100a23d:	48 89 df             	mov    %rbx,%rdi
 100a240:	49 89 d5             	mov    %rdx,%r13
 100a243:	ba 20 00 00 00       	mov    $0x20,%edx
 100a248:	49 89 f4             	mov    %rsi,%r12
 100a24b:	be 00 00 00 00       	mov    $0x0,%esi
 100a250:	48 89 fb             	mov    %rdi,%rbx
 100a253:	48 8d bd 30 fc ff ff 	lea    -0x3d0(%rbp),%rdi
 100a25a:	e8 b1 3f 01 00       	call   101e210 <compiler_rt.fastMemset>
 100a25f:	4c 89 ea             	mov    %r13,%rdx
 100a262:	4c 89 e6             	mov    %r12,%rsi
 100a265:	48 89 df             	mov    %rbx,%rdi
 100a268:	49 89 d5             	mov    %rdx,%r13
 100a26b:	ba 20 00 00 00       	mov    $0x20,%edx
 100a270:	49 89 f4             	mov    %rsi,%r12
 100a273:	be 00 00 00 00       	mov    $0x0,%esi
 100a278:	48 89 fb             	mov    %rdi,%rbx
 100a27b:	48 8d bd 50 fc ff ff 	lea    -0x3b0(%rbp),%rdi
 100a282:	e8 89 3f 01 00       	call   101e210 <compiler_rt.fastMemset>
 100a287:	4c 89 ea             	mov    %r13,%rdx
 100a28a:	4c 89 e6             	mov    %r12,%rsi
 100a28d:	48 89 df             	mov    %rbx,%rdi
 100a290:	49 89 d5             	mov    %rdx,%r13
 100a293:	ba 20 00 00 00       	mov    $0x20,%edx
 100a298:	49 89 f4             	mov    %rsi,%r12
 100a29b:	be 00 00 00 00       	mov    $0x0,%esi
 100a2a0:	48 89 fb             	mov    %rdi,%rbx
 100a2a3:	48 8d bd 70 fc ff ff 	lea    -0x390(%rbp),%rdi
 100a2aa:	e8 61 3f 01 00       	call   101e210 <compiler_rt.fastMemset>
 100a2af:	4c 89 ea             	mov    %r13,%rdx
 100a2b2:	4c 89 e6             	mov    %r12,%rsi
 100a2b5:	48 89 df             	mov    %rbx,%rdi
 100a2b8:	49 89 d5             	mov    %rdx,%r13
 100a2bb:	ba 20 00 00 00       	mov    $0x20,%edx
 100a2c0:	49 89 f4             	mov    %rsi,%r12
 100a2c3:	be 00 00 00 00       	mov    $0x0,%esi
 100a2c8:	48 89 fb             	mov    %rdi,%rbx
 100a2cb:	48 8d bd 90 fc ff ff 	lea    -0x370(%rbp),%rdi
 100a2d2:	e8 39 3f 01 00       	call   101e210 <compiler_rt.fastMemset>
 100a2d7:	4c 89 ea             	mov    %r13,%rdx
 100a2da:	4c 89 e6             	mov    %r12,%rsi
 100a2dd:	48 89 df             	mov    %rbx,%rdi
 100a2e0:	49 89 d5             	mov    %rdx,%r13
 100a2e3:	ba 20 00 00 00       	mov    $0x20,%edx
 100a2e8:	49 89 f4             	mov    %rsi,%r12
 100a2eb:	be 00 00 00 00       	mov    $0x0,%esi
 100a2f0:	48 89 fb             	mov    %rdi,%rbx
 100a2f3:	48 8d bd b0 fc ff ff 	lea    -0x350(%rbp),%rdi
 100a2fa:	e8 11 3f 01 00       	call   101e210 <compiler_rt.fastMemset>
 100a2ff:	4c 89 ea             	mov    %r13,%rdx
 100a302:	4c 89 e6             	mov    %r12,%rsi
 100a305:	48 89 df             	mov    %rbx,%rdi
 100a308:	49 89 d5             	mov    %rdx,%r13
 100a30b:	ba 20 00 00 00       	mov    $0x20,%edx
 100a310:	49 89 f4             	mov    %rsi,%r12
 100a313:	be 00 00 00 00       	mov    $0x0,%esi
 100a318:	48 89 fb             	mov    %rdi,%rbx
 100a31b:	48 8d bd d0 fc ff ff 	lea    -0x330(%rbp),%rdi
 100a322:	e8 e9 3e 01 00       	call   101e210 <compiler_rt.fastMemset>
 100a327:	4c 89 ea             	mov    %r13,%rdx
 100a32a:	4c 89 e6             	mov    %r12,%rsi
 100a32d:	48 89 df             	mov    %rbx,%rdi
 100a330:	49 89 d5             	mov    %rdx,%r13
 100a333:	ba 20 00 00 00       	mov    $0x20,%edx
 100a338:	49 89 f4             	mov    %rsi,%r12
 100a33b:	be 00 00 00 00       	mov    $0x0,%esi
 100a340:	48 89 fb             	mov    %rdi,%rbx
 100a343:	48 8d bd f0 fc ff ff 	lea    -0x310(%rbp),%rdi
 100a34a:	e8 c1 3e 01 00       	call   101e210 <compiler_rt.fastMemset>
 100a34f:	4c 89 ea             	mov    %r13,%rdx
 100a352:	4c 89 e6             	mov    %r12,%rsi
 100a355:	48 89 df             	mov    %rbx,%rdi
 100a358:	49 89 d5             	mov    %rdx,%r13
 100a35b:	ba 20 00 00 00       	mov    $0x20,%edx
 100a360:	49 89 f4             	mov    %rsi,%r12
 100a363:	be 00 00 00 00       	mov    $0x0,%esi
 100a368:	48 89 fb             	mov    %rdi,%rbx
 100a36b:	48 8d bd 10 fd ff ff 	lea    -0x2f0(%rbp),%rdi
 100a372:	e8 99 3e 01 00       	call   101e210 <compiler_rt.fastMemset>
 100a377:	4c 89 ea             	mov    %r13,%rdx
 100a37a:	4c 89 e6             	mov    %r12,%rsi
 100a37d:	48 89 df             	mov    %rbx,%rdi
 100a380:	49 89 d5             	mov    %rdx,%r13
 100a383:	ba 20 00 00 00       	mov    $0x20,%edx
 100a388:	49 89 f4             	mov    %rsi,%r12
 100a38b:	be 00 00 00 00       	mov    $0x0,%esi
 100a390:	48 89 fb             	mov    %rdi,%rbx
 100a393:	48 8d bd 30 fd ff ff 	lea    -0x2d0(%rbp),%rdi
 100a39a:	e8 71 3e 01 00       	call   101e210 <compiler_rt.fastMemset>
 100a39f:	4c 89 ea             	mov    %r13,%rdx
 100a3a2:	4c 89 e6             	mov    %r12,%rsi
 100a3a5:	48 89 df             	mov    %rbx,%rdi
 100a3a8:	49 89 d5             	mov    %rdx,%r13
 100a3ab:	ba 20 00 00 00       	mov    $0x20,%edx
 100a3b0:	49 89 f4             	mov    %rsi,%r12
 100a3b3:	be 00 00 00 00       	mov    $0x0,%esi
 100a3b8:	48 89 fb             	mov    %rdi,%rbx
 100a3bb:	48 8d bd 50 fd ff ff 	lea    -0x2b0(%rbp),%rdi
 100a3c2:	e8 49 3e 01 00       	call   101e210 <compiler_rt.fastMemset>
 100a3c7:	4c 89 ea             	mov    %r13,%rdx
 100a3ca:	4c 89 e6             	mov    %r12,%rsi
 100a3cd:	48 89 df             	mov    %rbx,%rdi
 100a3d0:	49 89 d5             	mov    %rdx,%r13
 100a3d3:	ba 20 00 00 00       	mov    $0x20,%edx
 100a3d8:	49 89 f4             	mov    %rsi,%r12
 100a3db:	be 00 00 00 00       	mov    $0x0,%esi
 100a3e0:	48 89 fb             	mov    %rdi,%rbx
 100a3e3:	48 8d bd 70 fd ff ff 	lea    -0x290(%rbp),%rdi
 100a3ea:	e8 21 3e 01 00       	call   101e210 <compiler_rt.fastMemset>
 100a3ef:	4c 89 ea             	mov    %r13,%rdx
 100a3f2:	4c 89 e6             	mov    %r12,%rsi
 100a3f5:	48 89 df             	mov    %rbx,%rdi
 100a3f8:	49 89 d5             	mov    %rdx,%r13
 100a3fb:	ba 20 00 00 00       	mov    $0x20,%edx
 100a400:	49 89 f4             	mov    %rsi,%r12
 100a403:	be 00 00 00 00       	mov    $0x0,%esi
 100a408:	48 89 fb             	mov    %rdi,%rbx
 100a40b:	48 8d bd 90 fd ff ff 	lea    -0x270(%rbp),%rdi
 100a412:	e8 f9 3d 01 00       	call   101e210 <compiler_rt.fastMemset>
 100a417:	4c 89 ea             	mov    %r13,%rdx
 100a41a:	4c 89 e6             	mov    %r12,%rsi
 100a41d:	48 89 df             	mov    %rbx,%rdi
 100a420:	49 89 d5             	mov    %rdx,%r13
 100a423:	ba 20 00 00 00       	mov    $0x20,%edx
 100a428:	49 89 f4             	mov    %rsi,%r12
 100a42b:	be 00 00 00 00       	mov    $0x0,%esi
 100a430:	48 89 fb             	mov    %rdi,%rbx
 100a433:	48 8d bd b0 fd ff ff 	lea    -0x250(%rbp),%rdi
 100a43a:	e8 d1 3d 01 00       	call   101e210 <compiler_rt.fastMemset>
 100a43f:	4c 89 ea             	mov    %r13,%rdx
 100a442:	4c 89 e6             	mov    %r12,%rsi
 100a445:	48 89 df             	mov    %rbx,%rdi
 100a448:	49 89 d5             	mov    %rdx,%r13
 100a44b:	ba 20 00 00 00       	mov    $0x20,%edx
 100a450:	49 89 f4             	mov    %rsi,%r12
 100a453:	be 00 00 00 00       	mov    $0x0,%esi
 100a458:	48 89 fb             	mov    %rdi,%rbx
 100a45b:	48 8d bd d0 fd ff ff 	lea    -0x230(%rbp),%rdi
 100a462:	e8 a9 3d 01 00       	call   101e210 <compiler_rt.fastMemset>
 100a467:	4c 89 ea             	mov    %r13,%rdx
 100a46a:	4c 89 e6             	mov    %r12,%rsi
 100a46d:	48 89 df             	mov    %rbx,%rdi
 100a470:	49 89 d5             	mov    %rdx,%r13
 100a473:	ba 20 00 00 00       	mov    $0x20,%edx
 100a478:	49 89 f4             	mov    %rsi,%r12
 100a47b:	be 00 00 00 00       	mov    $0x0,%esi
 100a480:	48 89 fb             	mov    %rdi,%rbx
 100a483:	48 8d bd f0 fd ff ff 	lea    -0x210(%rbp),%rdi
 100a48a:	e8 81 3d 01 00       	call   101e210 <compiler_rt.fastMemset>
 100a48f:	4c 89 ea             	mov    %r13,%rdx
 100a492:	4c 89 e6             	mov    %r12,%rsi
 100a495:	48 89 df             	mov    %rbx,%rdi
 100a498:	49 89 d5             	mov    %rdx,%r13
 100a49b:	ba 20 00 00 00       	mov    $0x20,%edx
 100a4a0:	49 89 f4             	mov    %rsi,%r12
 100a4a3:	be 00 00 00 00       	mov    $0x0,%esi
 100a4a8:	48 89 fb             	mov    %rdi,%rbx
 100a4ab:	48 8d bd 10 fe ff ff 	lea    -0x1f0(%rbp),%rdi
 100a4b2:	e8 59 3d 01 00       	call   101e210 <compiler_rt.fastMemset>
 100a4b7:	4c 89 ea             	mov    %r13,%rdx
 100a4ba:	4c 89 e6             	mov    %r12,%rsi
 100a4bd:	48 89 df             	mov    %rbx,%rdi
 100a4c0:	49 89 d5             	mov    %rdx,%r13
 100a4c3:	ba 20 00 00 00       	mov    $0x20,%edx
 100a4c8:	49 89 f4             	mov    %rsi,%r12
 100a4cb:	be 00 00 00 00       	mov    $0x0,%esi
 100a4d0:	48 89 fb             	mov    %rdi,%rbx
 100a4d3:	48 8d bd 30 fe ff ff 	lea    -0x1d0(%rbp),%rdi
 100a4da:	e8 31 3d 01 00       	call   101e210 <compiler_rt.fastMemset>
 100a4df:	4c 89 ea             	mov    %r13,%rdx
 100a4e2:	4c 89 e6             	mov    %r12,%rsi
 100a4e5:	48 89 df             	mov    %rbx,%rdi
 100a4e8:	49 89 d5             	mov    %rdx,%r13
 100a4eb:	ba 20 00 00 00       	mov    $0x20,%edx
 100a4f0:	49 89 f4             	mov    %rsi,%r12
 100a4f3:	be 00 00 00 00       	mov    $0x0,%esi
 100a4f8:	48 89 fb             	mov    %rdi,%rbx
 100a4fb:	48 8d bd 50 fe ff ff 	lea    -0x1b0(%rbp),%rdi
 100a502:	e8 09 3d 01 00       	call   101e210 <compiler_rt.fastMemset>
 100a507:	4c 89 ea             	mov    %r13,%rdx
 100a50a:	4c 89 e6             	mov    %r12,%rsi
 100a50d:	48 89 df             	mov    %rbx,%rdi
 100a510:	49 89 d5             	mov    %rdx,%r13
 100a513:	ba 20 00 00 00       	mov    $0x20,%edx
 100a518:	49 89 f4             	mov    %rsi,%r12
 100a51b:	be 00 00 00 00       	mov    $0x0,%esi
 100a520:	48 89 fb             	mov    %rdi,%rbx
 100a523:	48 8d bd 70 fe ff ff 	lea    -0x190(%rbp),%rdi
 100a52a:	e8 e1 3c 01 00       	call   101e210 <compiler_rt.fastMemset>
 100a52f:	4c 89 ea             	mov    %r13,%rdx
 100a532:	4c 89 e6             	mov    %r12,%rsi
 100a535:	48 89 df             	mov    %rbx,%rdi
 100a538:	49 89 d5             	mov    %rdx,%r13
 100a53b:	ba 20 00 00 00       	mov    $0x20,%edx
 100a540:	49 89 f4             	mov    %rsi,%r12
 100a543:	be 00 00 00 00       	mov    $0x0,%esi
 100a548:	48 89 fb             	mov    %rdi,%rbx
 100a54b:	48 8d bd 90 fe ff ff 	lea    -0x170(%rbp),%rdi
 100a552:	e8 b9 3c 01 00       	call   101e210 <compiler_rt.fastMemset>
 100a557:	4c 89 ea             	mov    %r13,%rdx
 100a55a:	4c 89 e6             	mov    %r12,%rsi
 100a55d:	48 89 df             	mov    %rbx,%rdi
 100a560:	49 89 d5             	mov    %rdx,%r13
 100a563:	ba 20 00 00 00       	mov    $0x20,%edx
 100a568:	49 89 f4             	mov    %rsi,%r12
 100a56b:	be 00 00 00 00       	mov    $0x0,%esi
 100a570:	48 89 fb             	mov    %rdi,%rbx
 100a573:	48 8d bd b0 fe ff ff 	lea    -0x150(%rbp),%rdi
 100a57a:	e8 91 3c 01 00       	call   101e210 <compiler_rt.fastMemset>
 100a57f:	4c 89 ea             	mov    %r13,%rdx
 100a582:	4c 89 e6             	mov    %r12,%rsi
 100a585:	48 89 df             	mov    %rbx,%rdi
 100a588:	49 89 d5             	mov    %rdx,%r13
 100a58b:	ba 20 00 00 00       	mov    $0x20,%edx
 100a590:	49 89 f4             	mov    %rsi,%r12
 100a593:	be 00 00 00 00       	mov    $0x0,%esi
 100a598:	48 89 fb             	mov    %rdi,%rbx
 100a59b:	48 8d bd d0 fe ff ff 	lea    -0x130(%rbp),%rdi
 100a5a2:	e8 69 3c 01 00       	call   101e210 <compiler_rt.fastMemset>
 100a5a7:	4c 89 ea             	mov    %r13,%rdx
 100a5aa:	4c 89 e6             	mov    %r12,%rsi
 100a5ad:	48 89 df             	mov    %rbx,%rdi
 100a5b0:	49 89 d5             	mov    %rdx,%r13
 100a5b3:	ba 20 00 00 00       	mov    $0x20,%edx
 100a5b8:	49 89 f4             	mov    %rsi,%r12
 100a5bb:	be 00 00 00 00       	mov    $0x0,%esi
 100a5c0:	48 89 fb             	mov    %rdi,%rbx
 100a5c3:	48 8d bd f0 fe ff ff 	lea    -0x110(%rbp),%rdi
 100a5ca:	e8 41 3c 01 00       	call   101e210 <compiler_rt.fastMemset>
 100a5cf:	4c 89 ea             	mov    %r13,%rdx
 100a5d2:	4c 89 e6             	mov    %r12,%rsi
 100a5d5:	48 89 df             	mov    %rbx,%rdi
 100a5d8:	49 89 d5             	mov    %rdx,%r13
 100a5db:	ba 20 00 00 00       	mov    $0x20,%edx
 100a5e0:	49 89 f4             	mov    %rsi,%r12
 100a5e3:	be 00 00 00 00       	mov    $0x0,%esi
 100a5e8:	48 89 fb             	mov    %rdi,%rbx
 100a5eb:	48 8d bd 10 ff ff ff 	lea    -0xf0(%rbp),%rdi
 100a5f2:	e8 19 3c 01 00       	call   101e210 <compiler_rt.fastMemset>
 100a5f7:	4c 89 ea             	mov    %r13,%rdx
 100a5fa:	4c 89 e6             	mov    %r12,%rsi
 100a5fd:	48 89 df             	mov    %rbx,%rdi
 100a600:	49 89 d5             	mov    %rdx,%r13
 100a603:	ba 20 00 00 00       	mov    $0x20,%edx
 100a608:	49 89 f4             	mov    %rsi,%r12
 100a60b:	be 00 00 00 00       	mov    $0x0,%esi
 100a610:	48 89 fb             	mov    %rdi,%rbx
 100a613:	48 8d bd 30 ff ff ff 	lea    -0xd0(%rbp),%rdi
 100a61a:	e8 f1 3b 01 00       	call   101e210 <compiler_rt.fastMemset>
 100a61f:	4c 89 ea             	mov    %r13,%rdx
 100a622:	4c 89 e6             	mov    %r12,%rsi
 100a625:	48 89 df             	mov    %rbx,%rdi
 100a628:	49 89 d5             	mov    %rdx,%r13
 100a62b:	ba 20 00 00 00       	mov    $0x20,%edx
 100a630:	49 89 f4             	mov    %rsi,%r12
 100a633:	be 00 00 00 00       	mov    $0x0,%esi
 100a638:	48 89 fb             	mov    %rdi,%rbx
 100a63b:	48 8d bd 50 ff ff ff 	lea    -0xb0(%rbp),%rdi
 100a642:	e8 c9 3b 01 00       	call   101e210 <compiler_rt.fastMemset>
 100a647:	4c 89 ea             	mov    %r13,%rdx
 100a64a:	4c 89 e6             	mov    %r12,%rsi
 100a64d:	48 89 df             	mov    %rbx,%rdi
 100a650:	49 89 d4             	mov    %rdx,%r12
 100a653:	ba 20 00 00 00       	mov    $0x20,%edx
 100a658:	49 89 f5             	mov    %rsi,%r13
 100a65b:	be 00 00 00 00       	mov    $0x0,%esi
 100a660:	48 89 fb             	mov    %rdi,%rbx
 100a663:	48 8d bd 70 ff ff ff 	lea    -0x90(%rbp),%rdi
 100a66a:	e8 a1 3b 01 00       	call   101e210 <compiler_rt.fastMemset>
 100a66f:	4c 89 ee             	mov    %r13,%rsi
 100a672:	48 89 df             	mov    %rbx,%rdi
 100a675:	48 89 75 90          	mov    %rsi,-0x70(%rbp)
 100a679:	48 89 fb             	mov    %rdi,%rbx
 100a67c:	e8 2f 66 00 00       	call   1010cb0 <myl_qbe_region_mark>
 100a681:	4c 89 e2             	mov    %r12,%rdx
 100a684:	48 89 df             	mov    %rbx,%rdi
 100a687:	49 89 d4             	mov    %rdx,%r12
 100a68a:	ba 20 00 00 00       	mov    $0x20,%edx
 100a68f:	be 00 00 00 00       	mov    $0x0,%esi
 100a694:	48 89 fb             	mov    %rdi,%rbx
 100a697:	48 8d bd b8 fa ff ff 	lea    -0x548(%rbp),%rdi
 100a69e:	e8 6d 3b 01 00       	call   101e210 <compiler_rt.fastMemset>
 100a6a3:	4c 89 e2             	mov    %r12,%rdx
 100a6a6:	48 89 df             	mov    %rbx,%rdi
 100a6a9:	48 8d 05 e8 54 02 00 	lea    0x254e8(%rip),%rax        # 102fb98 <myl_t_d2ff6b5d68a6b89029b6a5ef080c84cb7b1d6f1f652f01bb7d01c31027f36c39>
 100a6b0:	48 89 85 38 fa ff ff 	mov    %rax,-0x5c8(%rbp)
 100a6b7:	c7 85 50 fa ff ff 02 	movl   $0x2,-0x5b0(%rbp)
 100a6be:	00 00 00 
 100a6c1:	48 8d 45 90          	lea    -0x70(%rbp),%rax
 100a6c5:	48 89 85 40 fa ff ff 	mov    %rax,-0x5c0(%rbp)
 100a6cc:	48 8d 85 b8 fa ff ff 	lea    -0x548(%rbp),%rax
 100a6d3:	48 89 85 48 fa ff ff 	mov    %rax,-0x5b8(%rbp)
 100a6da:	48 8d 05 2f 7a ff ff 	lea    -0x85d1(%rip),%rax        # 1002110 <myl_t_385cfdbc00ec32031699460779c15099b2bba3cad0e440fffb08e10df0acb9e1>
 100a6e1:	48 89 85 58 fa ff ff 	mov    %rax,-0x5a8(%rbp)
 100a6e8:	c7 85 70 fa ff ff 00 	movl   $0x0,-0x590(%rbp)
 100a6ef:	00 00 00 
 100a6f2:	48 8d 85 d8 fa ff ff 	lea    -0x528(%rbp),%rax
 100a6f9:	48 89 85 60 fa ff ff 	mov    %rax,-0x5a0(%rbp)
 100a700:	48 8d 85 b8 fa ff ff 	lea    -0x548(%rbp),%rax
 100a707:	48 83 c0 08          	add    $0x8,%rax
 100a70b:	48 89 85 68 fa ff ff 	mov    %rax,-0x598(%rbp)
 100a712:	48 8d 05 f7 79 ff ff 	lea    -0x8609(%rip),%rax        # 1002110 <myl_t_385cfdbc00ec32031699460779c15099b2bba3cad0e440fffb08e10df0acb9e1>
 100a719:	48 89 85 78 fa ff ff 	mov    %rax,-0x588(%rbp)
 100a720:	c7 85 90 fa ff ff 00 	movl   $0x0,-0x570(%rbp)
 100a727:	00 00 00 
 100a72a:	48 8d 85 10 fb ff ff 	lea    -0x4f0(%rbp),%rax
 100a731:	48 89 85 80 fa ff ff 	mov    %rax,-0x580(%rbp)
 100a738:	48 8d 85 b8 fa ff ff 	lea    -0x548(%rbp),%rax
 100a73f:	48 83 c0 10          	add    $0x10,%rax
 100a743:	48 89 85 88 fa ff ff 	mov    %rax,-0x578(%rbp)
 100a74a:	48 8d 05 bf 79 ff ff 	lea    -0x8641(%rip),%rax        # 1002110 <myl_t_385cfdbc00ec32031699460779c15099b2bba3cad0e440fffb08e10df0acb9e1>
 100a751:	48 89 85 98 fa ff ff 	mov    %rax,-0x568(%rbp)
 100a758:	c7 85 b0 fa ff ff 00 	movl   $0x0,-0x550(%rbp)
 100a75f:	00 00 00 
 100a762:	48 8d 85 48 fb ff ff 	lea    -0x4b8(%rbp),%rax
 100a769:	48 89 85 a0 fa ff ff 	mov    %rax,-0x560(%rbp)
 100a770:	48 8d 85 b8 fa ff ff 	lea    -0x548(%rbp),%rax
 100a777:	48 83 c0 18          	add    $0x18,%rax
 100a77b:	48 89 85 a8 fa ff ff 	mov    %rax,-0x558(%rbp)
 100a782:	b9 04 00 00 00       	mov    $0x4,%ecx
 100a787:	49 89 d4             	mov    %rdx,%r12
 100a78a:	48 8d 95 38 fa ff ff 	lea    -0x5c8(%rbp),%rdx
 100a791:	48 8d b5 18 fa ff ff 	lea    -0x5e8(%rbp),%rsi
 100a798:	48 89 fb             	mov    %rdi,%rbx
 100a79b:	e8 60 3d 00 00       	call   100e500 <myl_qbe_rc_frame_enter>
 100a7a0:	4c 89 e2             	mov    %r12,%rdx
 100a7a3:	48 89 df             	mov    %rbx,%rdi
 100a7a6:	48 8b 45 90          	mov    -0x70(%rbp),%rax
 100a7aa:	48 8b 30             	mov    (%rax),%rsi
 100a7ad:	48 b8 ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rax
 100a7b4:	ff ff 7f 
 100a7b7:	48 39 c6             	cmp    %rax,%rsi
 100a7ba:	0f 87 99 23 00 00    	ja     100cb59 <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x2a49>
 100a7c0:	66 48 0f 6e c2       	movq   %rdx,%xmm0
 100a7c5:	f2 0f 11 45 f0       	movsd  %xmm0,-0x10(%rbp)
 100a7ca:	49 89 f5             	mov    %rsi,%r13
 100a7cd:	bb 00 00 00 00       	mov    $0x0,%ebx
 100a7d2:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
 100a7d9:	00 00 00 
 100a7dc:	0f 1f 40 00          	nopl   0x0(%rax)
 100a7e0:	4c 39 eb             	cmp    %r13,%rbx
 100a7e3:	0f 8d 9d 19 00 00    	jge    100c186 <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x2076>
 100a7e9:	48 b8 fe ff ff ff ff 	movabs $0x7ffffffffffffffe,%rax
 100a7f0:	ff ff 7f 
 100a7f3:	48 39 c3             	cmp    %rax,%rbx
 100a7f6:	0f 8f 70 19 00 00    	jg     100c16c <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x205c>
 100a7fc:	49 89 dc             	mov    %rbx,%r12
 100a7ff:	49 83 c4 01          	add    $0x1,%r12
 100a803:	4c 89 65 d0          	mov    %r12,-0x30(%rbp)
 100a807:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
 100a80e:	00 00 
 100a810:	4d 39 ec             	cmp    %r13,%r12
 100a813:	0f 8d 45 19 00 00    	jge    100c15e <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x204e>
 100a819:	48 8b 45 90          	mov    -0x70(%rbp),%rax
 100a81d:	48 83 fb 00          	cmp    $0x0,%rbx
 100a821:	7c 05                	jl     100a828 <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x718>
 100a823:	49 89 de             	mov    %rbx,%r14
 100a826:	eb 35                	jmp    100a85d <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x74d>
 100a828:	48 8b 30             	mov    (%rax),%rsi
 100a82b:	48 b9 ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rcx
 100a832:	ff ff 7f 
 100a835:	48 39 ce             	cmp    %rcx,%rsi
 100a838:	0f 87 14 19 00 00    	ja     100c152 <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x2042>
 100a83e:	49 89 f6             	mov    %rsi,%r14
 100a841:	49 01 de             	add    %rbx,%r14
 100a844:	48 89 f1             	mov    %rsi,%rcx
 100a847:	4c 31 f1             	xor    %r14,%rcx
 100a84a:	48 89 da             	mov    %rbx,%rdx
 100a84d:	4c 31 f2             	xor    %r14,%rdx
 100a850:	48 21 d1             	and    %rdx,%rcx
 100a853:	48 83 f9 00          	cmp    $0x0,%rcx
 100a857:	0f 8c da 18 00 00    	jl     100c137 <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x2027>
 100a85d:	48 8b 08             	mov    (%rax),%rcx
 100a860:	49 39 ce             	cmp    %rcx,%r14
 100a863:	0f 83 c1 18 00 00    	jae    100c12a <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x201a>
 100a869:	48 8b 48 20          	mov    0x20(%rax),%rcx
 100a86d:	49 6b d6 38          	imul   $0x38,%r14,%rdx
 100a871:	48 8b 34 11          	mov    (%rcx,%rdx,1),%rsi
 100a875:	48 89 75 98          	mov    %rsi,-0x68(%rbp)
 100a879:	48 8b 74 11 08       	mov    0x8(%rcx,%rdx,1),%rsi
 100a87e:	48 89 75 a0          	mov    %rsi,-0x60(%rbp)
 100a882:	48 8b 74 11 10       	mov    0x10(%rcx,%rdx,1),%rsi
 100a887:	48 89 75 a8          	mov    %rsi,-0x58(%rbp)
 100a88b:	48 8b 74 11 18       	mov    0x18(%rcx,%rdx,1),%rsi
 100a890:	48 89 75 b0          	mov    %rsi,-0x50(%rbp)
 100a894:	48 8b 74 11 20       	mov    0x20(%rcx,%rdx,1),%rsi
 100a899:	48 89 75 b8          	mov    %rsi,-0x48(%rbp)
 100a89d:	48 8b 74 11 28       	mov    0x28(%rcx,%rdx,1),%rsi
 100a8a2:	48 89 75 c0          	mov    %rsi,-0x40(%rbp)
 100a8a6:	48 8b 4c 11 30       	mov    0x30(%rcx,%rdx,1),%rcx
 100a8ab:	48 89 4d c8          	mov    %rcx,-0x38(%rbp)
 100a8af:	4c 8b 45 98          	mov    -0x68(%rbp),%r8
 100a8b3:	49 83 fc 00          	cmp    $0x0,%r12
 100a8b7:	7c 05                	jl     100a8be <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x7ae>
 100a8b9:	4d 89 e6             	mov    %r12,%r14
 100a8bc:	eb 35                	jmp    100a8f3 <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x7e3>
 100a8be:	48 8b 30             	mov    (%rax),%rsi
 100a8c1:	48 b9 ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rcx
 100a8c8:	ff ff 7f 
 100a8cb:	48 39 ce             	cmp    %rcx,%rsi
 100a8ce:	0f 87 4a 18 00 00    	ja     100c11e <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x200e>
 100a8d4:	49 89 f6             	mov    %rsi,%r14
 100a8d7:	4d 01 e6             	add    %r12,%r14
 100a8da:	48 89 f1             	mov    %rsi,%rcx
 100a8dd:	4c 31 f1             	xor    %r14,%rcx
 100a8e0:	4c 89 e2             	mov    %r12,%rdx
 100a8e3:	4c 31 f2             	xor    %r14,%rdx
 100a8e6:	48 21 d1             	and    %rdx,%rcx
 100a8e9:	48 83 f9 00          	cmp    $0x0,%rcx
 100a8ed:	0f 8c 13 18 00 00    	jl     100c106 <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x1ff6>
 100a8f3:	48 8b 08             	mov    (%rax),%rcx
 100a8f6:	49 39 ce             	cmp    %rcx,%r14
 100a8f9:	0f 83 fa 17 00 00    	jae    100c0f9 <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x1fe9>
 100a8ff:	48 8b 48 20          	mov    0x20(%rax),%rcx
 100a903:	49 6b d6 38          	imul   $0x38,%r14,%rdx
 100a907:	48 8b 34 11          	mov    (%rcx,%rdx,1),%rsi
 100a90b:	48 89 75 98          	mov    %rsi,-0x68(%rbp)
 100a90f:	48 8b 74 11 08       	mov    0x8(%rcx,%rdx,1),%rsi
 100a914:	48 89 75 a0          	mov    %rsi,-0x60(%rbp)
 100a918:	48 8b 74 11 10       	mov    0x10(%rcx,%rdx,1),%rsi
 100a91d:	48 89 75 a8          	mov    %rsi,-0x58(%rbp)
 100a921:	48 8b 74 11 18       	mov    0x18(%rcx,%rdx,1),%rsi
 100a926:	48 89 75 b0          	mov    %rsi,-0x50(%rbp)
 100a92a:	48 8b 74 11 20       	mov    0x20(%rcx,%rdx,1),%rsi
 100a92f:	48 89 75 b8          	mov    %rsi,-0x48(%rbp)
 100a933:	48 8b 74 11 28       	mov    0x28(%rcx,%rdx,1),%rsi
 100a938:	48 89 75 c0          	mov    %rsi,-0x40(%rbp)
 100a93c:	48 8b 4c 11 30       	mov    0x30(%rcx,%rdx,1),%rcx
 100a941:	48 89 4d c8          	mov    %rcx,-0x38(%rbp)
 100a945:	48 8b 55 98          	mov    -0x68(%rbp),%rdx
 100a949:	48 83 fb 00          	cmp    $0x0,%rbx
 100a94d:	7c 05                	jl     100a954 <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x844>
 100a94f:	49 89 de             	mov    %rbx,%r14
 100a952:	eb 35                	jmp    100a989 <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x879>
 100a954:	48 8b 30             	mov    (%rax),%rsi
 100a957:	48 b9 ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rcx
 100a95e:	ff ff 7f 
 100a961:	48 39 ce             	cmp    %rcx,%rsi
 100a964:	0f 87 83 17 00 00    	ja     100c0ed <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x1fdd>
 100a96a:	49 89 f6             	mov    %rsi,%r14
 100a96d:	49 01 de             	add    %rbx,%r14
 100a970:	48 89 f1             	mov    %rsi,%rcx
 100a973:	4c 31 f1             	xor    %r14,%rcx
 100a976:	49 89 d9             	mov    %rbx,%r9
 100a979:	4d 31 f1             	xor    %r14,%r9
 100a97c:	4c 21 c9             	and    %r9,%rcx
 100a97f:	48 83 f9 00          	cmp    $0x0,%rcx
 100a983:	0f 8c 49 17 00 00    	jl     100c0d2 <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x1fc2>
 100a989:	48 8b 08             	mov    (%rax),%rcx
 100a98c:	49 39 ce             	cmp    %rcx,%r14
 100a98f:	0f 83 30 17 00 00    	jae    100c0c5 <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x1fb5>
 100a995:	48 8b 48 20          	mov    0x20(%rax),%rcx
 100a999:	49 6b f6 38          	imul   $0x38,%r14,%rsi
 100a99d:	4c 8b 0c 31          	mov    (%rcx,%rsi,1),%r9
 100a9a1:	4c 89 4d 98          	mov    %r9,-0x68(%rbp)
 100a9a5:	4c 8b 4c 31 08       	mov    0x8(%rcx,%rsi,1),%r9
 100a9aa:	4c 89 4d a0          	mov    %r9,-0x60(%rbp)
 100a9ae:	4c 8b 4c 31 10       	mov    0x10(%rcx,%rsi,1),%r9
 100a9b3:	4c 89 4d a8          	mov    %r9,-0x58(%rbp)
 100a9b7:	4c 8b 4c 31 18       	mov    0x18(%rcx,%rsi,1),%r9
 100a9bc:	4c 89 4d b0          	mov    %r9,-0x50(%rbp)
 100a9c0:	4c 8b 4c 31 20       	mov    0x20(%rcx,%rsi,1),%r9
 100a9c5:	4c 89 4d b8          	mov    %r9,-0x48(%rbp)
 100a9c9:	4c 8b 4c 31 28       	mov    0x28(%rcx,%rsi,1),%r9
 100a9ce:	4c 89 4d c0          	mov    %r9,-0x40(%rbp)
 100a9d2:	48 8b 4c 31 30       	mov    0x30(%rcx,%rsi,1),%rcx
 100a9d7:	48 89 4d c8          	mov    %rcx,-0x38(%rbp)
 100a9db:	48 8b 75 a0          	mov    -0x60(%rbp),%rsi
 100a9df:	49 83 fc 00          	cmp    $0x0,%r12
 100a9e3:	7c 05                	jl     100a9ea <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x8da>
 100a9e5:	4d 89 e6             	mov    %r12,%r14
 100a9e8:	eb 35                	jmp    100aa1f <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x90f>
 100a9ea:	4c 8b 08             	mov    (%rax),%r9
 100a9ed:	48 b9 ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rcx
 100a9f4:	ff ff 7f 
 100a9f7:	49 39 c9             	cmp    %rcx,%r9
 100a9fa:	0f 87 b6 16 00 00    	ja     100c0b6 <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x1fa6>
 100aa00:	4d 89 ce             	mov    %r9,%r14
 100aa03:	4d 01 e6             	add    %r12,%r14
 100aa06:	4c 89 c9             	mov    %r9,%rcx
 100aa09:	4c 31 f1             	xor    %r14,%rcx
 100aa0c:	4d 89 e2             	mov    %r12,%r10
 100aa0f:	4d 31 f2             	xor    %r14,%r10
 100aa12:	4c 21 d1             	and    %r10,%rcx
 100aa15:	48 83 f9 00          	cmp    $0x0,%rcx
 100aa19:	0f 8c 7c 16 00 00    	jl     100c09b <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x1f8b>
 100aa1f:	48 8b 08             	mov    (%rax),%rcx
 100aa22:	49 39 ce             	cmp    %rcx,%r14
 100aa25:	0f 83 63 16 00 00    	jae    100c08e <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x1f7e>
 100aa2b:	48 8b 48 20          	mov    0x20(%rax),%rcx
 100aa2f:	4d 6b ce 38          	imul   $0x38,%r14,%r9
 100aa33:	4e 8b 14 09          	mov    (%rcx,%r9,1),%r10
 100aa37:	4c 89 55 98          	mov    %r10,-0x68(%rbp)
 100aa3b:	4e 8b 54 09 08       	mov    0x8(%rcx,%r9,1),%r10
 100aa40:	4c 89 55 a0          	mov    %r10,-0x60(%rbp)
 100aa44:	4e 8b 54 09 10       	mov    0x10(%rcx,%r9,1),%r10
 100aa49:	4c 89 55 a8          	mov    %r10,-0x58(%rbp)
 100aa4d:	4e 8b 54 09 18       	mov    0x18(%rcx,%r9,1),%r10
 100aa52:	4c 89 55 b0          	mov    %r10,-0x50(%rbp)
 100aa56:	4e 8b 54 09 20       	mov    0x20(%rcx,%r9,1),%r10
 100aa5b:	4c 89 55 b8          	mov    %r10,-0x48(%rbp)
 100aa5f:	4e 8b 54 09 28       	mov    0x28(%rcx,%r9,1),%r10
 100aa64:	4c 89 55 c0          	mov    %r10,-0x40(%rbp)
 100aa68:	4a 8b 4c 09 30       	mov    0x30(%rcx,%r9,1),%rcx
 100aa6d:	48 89 4d c8          	mov    %rcx,-0x38(%rbp)
 100aa71:	48 8b 4d a0          	mov    -0x60(%rbp),%rcx
 100aa75:	48 83 fb 00          	cmp    $0x0,%rbx
 100aa79:	7c 05                	jl     100aa80 <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x970>
 100aa7b:	49 89 de             	mov    %rbx,%r14
 100aa7e:	eb 35                	jmp    100aab5 <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x9a5>
 100aa80:	4c 8b 08             	mov    (%rax),%r9
 100aa83:	49 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%r10
 100aa8a:	ff ff 7f 
 100aa8d:	4d 39 d1             	cmp    %r10,%r9
 100aa90:	0f 87 e9 15 00 00    	ja     100c07f <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x1f6f>
 100aa96:	4d 89 ce             	mov    %r9,%r14
 100aa99:	49 01 de             	add    %rbx,%r14
 100aa9c:	4d 89 ca             	mov    %r9,%r10
 100aa9f:	4d 31 f2             	xor    %r14,%r10
 100aaa2:	49 89 db             	mov    %rbx,%r11
 100aaa5:	4d 31 f3             	xor    %r14,%r11
 100aaa8:	4d 21 da             	and    %r11,%r10
 100aaab:	49 83 fa 00          	cmp    $0x0,%r10
 100aaaf:	0f 8c ac 15 00 00    	jl     100c061 <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x1f51>
 100aab5:	4c 8b 08             	mov    (%rax),%r9
 100aab8:	4d 39 ce             	cmp    %r9,%r14
 100aabb:	0f 83 93 15 00 00    	jae    100c054 <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x1f44>
 100aac1:	4c 8b 48 20          	mov    0x20(%rax),%r9
 100aac5:	4d 6b d6 38          	imul   $0x38,%r14,%r10
 100aac9:	4f 8b 1c 11          	mov    (%r9,%r10,1),%r11
 100aacd:	4c 89 5d 98          	mov    %r11,-0x68(%rbp)
 100aad1:	4f 8b 5c 11 08       	mov    0x8(%r9,%r10,1),%r11
 100aad6:	4c 89 5d a0          	mov    %r11,-0x60(%rbp)
 100aada:	4f 8b 5c 11 10       	mov    0x10(%r9,%r10,1),%r11
 100aadf:	4c 89 5d a8          	mov    %r11,-0x58(%rbp)
 100aae3:	4f 8b 5c 11 18       	mov    0x18(%r9,%r10,1),%r11
 100aae8:	4c 89 5d b0          	mov    %r11,-0x50(%rbp)
 100aaec:	4f 8b 5c 11 20       	mov    0x20(%r9,%r10,1),%r11
 100aaf1:	4c 89 5d b8          	mov    %r11,-0x48(%rbp)
 100aaf5:	4f 8b 5c 11 28       	mov    0x28(%r9,%r10,1),%r11
 100aafa:	4c 89 5d c0          	mov    %r11,-0x40(%rbp)
 100aafe:	4f 8b 4c 11 30       	mov    0x30(%r9,%r10,1),%r9
 100ab03:	4c 89 4d c8          	mov    %r9,-0x38(%rbp)
 100ab07:	4c 8b 4d a8          	mov    -0x58(%rbp),%r9
 100ab0b:	49 83 fc 00          	cmp    $0x0,%r12
 100ab0f:	7c 05                	jl     100ab16 <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0xa06>
 100ab11:	4d 89 e6             	mov    %r12,%r14
 100ab14:	eb 35                	jmp    100ab4b <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0xa3b>
 100ab16:	4c 8b 10             	mov    (%rax),%r10
 100ab19:	49 bb ff ff ff ff ff 	movabs $0x7fffffffffffffff,%r11
 100ab20:	ff ff 7f 
 100ab23:	4d 39 da             	cmp    %r11,%r10
 100ab26:	0f 87 19 15 00 00    	ja     100c045 <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x1f35>
 100ab2c:	4d 89 d6             	mov    %r10,%r14
 100ab2f:	4d 01 e6             	add    %r12,%r14
 100ab32:	4d 89 d3             	mov    %r10,%r11
 100ab35:	4d 31 f3             	xor    %r14,%r11
 100ab38:	4d 89 e7             	mov    %r12,%r15
 100ab3b:	4d 31 f7             	xor    %r14,%r15
 100ab3e:	4d 21 fb             	and    %r15,%r11
 100ab41:	49 83 fb 00          	cmp    $0x0,%r11
 100ab45:	0f 8c df 14 00 00    	jl     100c02a <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x1f1a>
 100ab4b:	4c 8b 10             	mov    (%rax),%r10
 100ab4e:	4d 39 d6             	cmp    %r10,%r14
 100ab51:	0f 83 c6 14 00 00    	jae    100c01d <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x1f0d>
 100ab57:	48 8b 40 20          	mov    0x20(%rax),%rax
 100ab5b:	4d 6b d6 38          	imul   $0x38,%r14,%r10
 100ab5f:	4e 8b 1c 10          	mov    (%rax,%r10,1),%r11
 100ab63:	4c 89 5d 98          	mov    %r11,-0x68(%rbp)
 100ab67:	4e 8b 5c 10 08       	mov    0x8(%rax,%r10,1),%r11
 100ab6c:	4c 89 5d a0          	mov    %r11,-0x60(%rbp)
 100ab70:	4e 8b 5c 10 10       	mov    0x10(%rax,%r10,1),%r11
 100ab75:	4c 89 5d a8          	mov    %r11,-0x58(%rbp)
 100ab79:	4e 8b 5c 10 18       	mov    0x18(%rax,%r10,1),%r11
 100ab7e:	4c 89 5d b0          	mov    %r11,-0x50(%rbp)
 100ab82:	4e 8b 5c 10 20       	mov    0x20(%rax,%r10,1),%r11
 100ab87:	4c 89 5d b8          	mov    %r11,-0x48(%rbp)
 100ab8b:	4e 8b 5c 10 28       	mov    0x28(%rax,%r10,1),%r11
 100ab90:	4c 89 5d c0          	mov    %r11,-0x40(%rbp)
 100ab94:	4a 8b 44 10 30       	mov    0x30(%rax,%r10,1),%rax
 100ab99:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
 100ab9d:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
 100aba1:	66 49 0f 6e c1       	movq   %r9,%xmm0
 100aba6:	66 48 0f 6e c8       	movq   %rax,%xmm1
 100abab:	f2 0f 5c c1          	subsd  %xmm1,%xmm0
 100abaf:	66 48 0f 7e c0       	movq   %xmm0,%rax
 100abb4:	66 49 0f 6e c0       	movq   %r8,%xmm0
 100abb9:	66 48 0f 6e ca       	movq   %rdx,%xmm1
 100abbe:	f2 0f 5c c1          	subsd  %xmm1,%xmm0
 100abc2:	66 48 0f 7e c2       	movq   %xmm0,%rdx
 100abc7:	66 48 0f 6e ea       	movq   %rdx,%xmm5
 100abcc:	f2 0f 11 6d d8       	movsd  %xmm5,-0x28(%rbp)
 100abd1:	f2 0f 10 c5          	movsd  %xmm5,%xmm0
 100abd5:	f2 0f 59 c5          	mulsd  %xmm5,%xmm0
 100abd9:	66 48 0f 7e c2       	movq   %xmm0,%rdx
 100abde:	66 48 0f 6e c6       	movq   %rsi,%xmm0
 100abe3:	66 48 0f 6e c9       	movq   %rcx,%xmm1
 100abe8:	f2 0f 5c c1          	subsd  %xmm1,%xmm0
 100abec:	66 48 0f 7e c1       	movq   %xmm0,%rcx
 100abf1:	66 48 0f 6e e1       	movq   %rcx,%xmm4
 100abf6:	f2 0f 11 65 e0       	movsd  %xmm4,-0x20(%rbp)
 100abfb:	f2 0f 10 c4          	movsd  %xmm4,%xmm0
 100abff:	f2 0f 59 c4          	mulsd  %xmm4,%xmm0
 100ac03:	66 48 0f 7e c1       	movq   %xmm0,%rcx
 100ac08:	66 48 0f 6e c2       	movq   %rdx,%xmm0
 100ac0d:	66 48 0f 6e c9       	movq   %rcx,%xmm1
 100ac12:	f2 0f 58 c1          	addsd  %xmm1,%xmm0
 100ac16:	66 48 0f 7e c1       	movq   %xmm0,%rcx
 100ac1b:	66 48 0f 6e d8       	movq   %rax,%xmm3
 100ac20:	f2 0f 11 5d e8       	movsd  %xmm3,-0x18(%rbp)
 100ac25:	f2 0f 10 c3          	movsd  %xmm3,%xmm0
 100ac29:	f2 0f 59 c3          	mulsd  %xmm3,%xmm0
 100ac2d:	66 48 0f 7e c0       	movq   %xmm0,%rax
 100ac32:	66 48 0f 6e c1       	movq   %rcx,%xmm0
 100ac37:	66 48 0f 6e c8       	movq   %rax,%xmm1
 100ac3c:	f2 0f 58 c1          	addsd  %xmm1,%xmm0
 100ac40:	66 49 0f 7e c7       	movq   %xmm0,%r15
 100ac45:	4c 89 fa             	mov    %r15,%rdx
 100ac48:	be 02 00 00 00       	mov    $0x2,%esi
 100ac4d:	49 89 fe             	mov    %rdi,%r14
 100ac50:	e8 2b 43 00 00       	call   100ef80 <myl_qbe_float_unary>
 100ac55:	4c 89 f7             	mov    %r14,%rdi
 100ac58:	48 89 c2             	mov    %rax,%rdx
 100ac5b:	f2 0f 10 45 f0       	movsd  -0x10(%rbp),%xmm0
 100ac60:	f2 0f 10 5d e8       	movsd  -0x18(%rbp),%xmm3
 100ac65:	f2 0f 10 65 e0       	movsd  -0x20(%rbp),%xmm4
 100ac6a:	f2 0f 10 6d d8       	movsd  -0x28(%rbp),%xmm5
 100ac6f:	48 8b 45 90          	mov    -0x70(%rbp),%rax
 100ac73:	48 83 fb 00          	cmp    $0x0,%rbx
 100ac77:	7c 05                	jl     100ac7e <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0xb6e>
 100ac79:	49 89 de             	mov    %rbx,%r14
 100ac7c:	eb 35                	jmp    100acb3 <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0xba3>
 100ac7e:	48 8b 30             	mov    (%rax),%rsi
 100ac81:	48 b9 ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rcx
 100ac88:	ff ff 7f 
 100ac8b:	48 39 ce             	cmp    %rcx,%rsi
 100ac8e:	0f 87 7d 13 00 00    	ja     100c011 <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x1f01>
 100ac94:	49 89 f6             	mov    %rsi,%r14
 100ac97:	49 01 de             	add    %rbx,%r14
 100ac9a:	48 89 f1             	mov    %rsi,%rcx
 100ac9d:	4c 31 f1             	xor    %r14,%rcx
 100aca0:	49 89 d8             	mov    %rbx,%r8
 100aca3:	4d 31 f0             	xor    %r14,%r8
 100aca6:	4c 21 c1             	and    %r8,%rcx
 100aca9:	48 83 f9 00          	cmp    $0x0,%rcx
 100acad:	0f 8c 43 13 00 00    	jl     100bff6 <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x1ee6>
 100acb3:	48 8b 08             	mov    (%rax),%rcx
 100acb6:	49 39 ce             	cmp    %rcx,%r14
 100acb9:	0f 83 2a 13 00 00    	jae    100bfe9 <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x1ed9>
 100acbf:	48 8b 48 20          	mov    0x20(%rax),%rcx
 100acc3:	49 6b f6 38          	imul   $0x38,%r14,%rsi
 100acc7:	4c 8b 04 31          	mov    (%rcx,%rsi,1),%r8
 100accb:	4c 89 45 98          	mov    %r8,-0x68(%rbp)
 100accf:	4c 8b 44 31 08       	mov    0x8(%rcx,%rsi,1),%r8
 100acd4:	4c 89 45 a0          	mov    %r8,-0x60(%rbp)
 100acd8:	4c 8b 44 31 10       	mov    0x10(%rcx,%rsi,1),%r8
 100acdd:	4c 89 45 a8          	mov    %r8,-0x58(%rbp)
 100ace1:	4c 8b 44 31 18       	mov    0x18(%rcx,%rsi,1),%r8
 100ace6:	4c 89 45 b0          	mov    %r8,-0x50(%rbp)
 100acea:	4c 8b 44 31 20       	mov    0x20(%rcx,%rsi,1),%r8
 100acef:	4c 89 45 b8          	mov    %r8,-0x48(%rbp)
 100acf3:	4c 8b 44 31 28       	mov    0x28(%rcx,%rsi,1),%r8
 100acf8:	4c 89 45 c0          	mov    %r8,-0x40(%rbp)
 100acfc:	48 8b 4c 31 30       	mov    0x30(%rcx,%rsi,1),%rcx
 100ad01:	48 89 4d c8          	mov    %rcx,-0x38(%rbp)
 100ad05:	4c 8b 45 b0          	mov    -0x50(%rbp),%r8
 100ad09:	49 83 fc 00          	cmp    $0x0,%r12
 100ad0d:	7c 05                	jl     100ad14 <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0xc04>
 100ad0f:	4d 89 e6             	mov    %r12,%r14
 100ad12:	eb 35                	jmp    100ad49 <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0xc39>
 100ad14:	48 8b 30             	mov    (%rax),%rsi
 100ad17:	48 b9 ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rcx
 100ad1e:	ff ff 7f 
 100ad21:	48 39 ce             	cmp    %rcx,%rsi
 100ad24:	0f 87 b3 12 00 00    	ja     100bfdd <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x1ecd>
 100ad2a:	49 89 f6             	mov    %rsi,%r14
 100ad2d:	4d 01 e6             	add    %r12,%r14
 100ad30:	48 89 f1             	mov    %rsi,%rcx
 100ad33:	4c 31 f1             	xor    %r14,%rcx
 100ad36:	4d 89 e1             	mov    %r12,%r9
 100ad39:	4d 31 f1             	xor    %r14,%r9
 100ad3c:	4c 21 c9             	and    %r9,%rcx
 100ad3f:	48 83 f9 00          	cmp    $0x0,%rcx
 100ad43:	0f 8c 7c 12 00 00    	jl     100bfc5 <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x1eb5>
 100ad49:	48 8b 08             	mov    (%rax),%rcx
 100ad4c:	49 39 ce             	cmp    %rcx,%r14
 100ad4f:	0f 83 63 12 00 00    	jae    100bfb8 <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x1ea8>
 100ad55:	48 8b 48 20          	mov    0x20(%rax),%rcx
 100ad59:	49 6b f6 38          	imul   $0x38,%r14,%rsi
 100ad5d:	4c 8b 0c 31          	mov    (%rcx,%rsi,1),%r9
 100ad61:	4c 89 4d 98          	mov    %r9,-0x68(%rbp)
 100ad65:	4c 8b 4c 31 08       	mov    0x8(%rcx,%rsi,1),%r9
 100ad6a:	4c 89 4d a0          	mov    %r9,-0x60(%rbp)
 100ad6e:	4c 8b 4c 31 10       	mov    0x10(%rcx,%rsi,1),%r9
 100ad73:	4c 89 4d a8          	mov    %r9,-0x58(%rbp)
 100ad77:	4c 8b 4c 31 18       	mov    0x18(%rcx,%rsi,1),%r9
 100ad7c:	4c 89 4d b0          	mov    %r9,-0x50(%rbp)
 100ad80:	4c 8b 4c 31 20       	mov    0x20(%rcx,%rsi,1),%r9
 100ad85:	4c 89 4d b8          	mov    %r9,-0x48(%rbp)
 100ad89:	4c 8b 4c 31 28       	mov    0x28(%rcx,%rsi,1),%r9
 100ad8e:	4c 89 4d c0          	mov    %r9,-0x40(%rbp)
 100ad92:	48 8b 4c 31 30       	mov    0x30(%rcx,%rsi,1),%rcx
 100ad97:	48 89 4d c8          	mov    %rcx,-0x38(%rbp)
 100ad9b:	48 8b 75 c8          	mov    -0x38(%rbp),%rsi
 100ad9f:	48 83 fb 00          	cmp    $0x0,%rbx
 100ada3:	7c 05                	jl     100adaa <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0xc9a>
 100ada5:	49 89 de             	mov    %rbx,%r14
 100ada8:	eb 35                	jmp    100addf <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0xccf>
 100adaa:	4c 8b 08             	mov    (%rax),%r9
 100adad:	48 b9 ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rcx
 100adb4:	ff ff 7f 
 100adb7:	49 39 c9             	cmp    %rcx,%r9
 100adba:	0f 87 e9 11 00 00    	ja     100bfa9 <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x1e99>
 100adc0:	4d 89 ce             	mov    %r9,%r14
 100adc3:	49 01 de             	add    %rbx,%r14
 100adc6:	4c 89 c9             	mov    %r9,%rcx
 100adc9:	4c 31 f1             	xor    %r14,%rcx
 100adcc:	49 89 da             	mov    %rbx,%r10
 100adcf:	4d 31 f2             	xor    %r14,%r10
 100add2:	4c 21 d1             	and    %r10,%rcx
 100add5:	48 83 f9 00          	cmp    $0x0,%rcx
 100add9:	0f 8c ac 11 00 00    	jl     100bf8b <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x1e7b>
 100addf:	48 8b 08             	mov    (%rax),%rcx
 100ade2:	49 39 ce             	cmp    %rcx,%r14
 100ade5:	0f 83 93 11 00 00    	jae    100bf7e <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x1e6e>
 100adeb:	4c 8b 48 20          	mov    0x20(%rax),%r9
 100adef:	49 6b ce 38          	imul   $0x38,%r14,%rcx
 100adf3:	4d 8b 14 09          	mov    (%r9,%rcx,1),%r10
 100adf7:	4c 89 55 98          	mov    %r10,-0x68(%rbp)
 100adfb:	4d 8b 54 09 08       	mov    0x8(%r9,%rcx,1),%r10
 100ae00:	4c 89 55 a0          	mov    %r10,-0x60(%rbp)
 100ae04:	4d 8b 54 09 10       	mov    0x10(%r9,%rcx,1),%r10
 100ae09:	4c 89 55 a8          	mov    %r10,-0x58(%rbp)
 100ae0d:	4d 8b 54 09 18       	mov    0x18(%r9,%rcx,1),%r10
 100ae12:	4c 89 55 b0          	mov    %r10,-0x50(%rbp)
 100ae16:	4d 8b 54 09 20       	mov    0x20(%r9,%rcx,1),%r10
 100ae1b:	4c 89 55 b8          	mov    %r10,-0x48(%rbp)
 100ae1f:	4d 8b 54 09 28       	mov    0x28(%r9,%rcx,1),%r10
 100ae24:	4c 89 55 c0          	mov    %r10,-0x40(%rbp)
 100ae28:	4d 8b 54 09 30       	mov    0x30(%r9,%rcx,1),%r10
 100ae2d:	4c 89 55 c8          	mov    %r10,-0x38(%rbp)
 100ae31:	4d 8b 14 09          	mov    (%r9,%rcx,1),%r10
 100ae35:	4c 89 55 98          	mov    %r10,-0x68(%rbp)
 100ae39:	4d 8b 54 09 08       	mov    0x8(%r9,%rcx,1),%r10
 100ae3e:	4c 89 55 a0          	mov    %r10,-0x60(%rbp)
 100ae42:	4d 8b 54 09 10       	mov    0x10(%r9,%rcx,1),%r10
 100ae47:	4c 89 55 a8          	mov    %r10,-0x58(%rbp)
 100ae4b:	4d 8b 54 09 18       	mov    0x18(%r9,%rcx,1),%r10
 100ae50:	4c 89 55 b0          	mov    %r10,-0x50(%rbp)
 100ae54:	4d 8b 54 09 20       	mov    0x20(%r9,%rcx,1),%r10
 100ae59:	4c 89 55 b8          	mov    %r10,-0x48(%rbp)
 100ae5d:	4d 8b 54 09 28       	mov    0x28(%r9,%rcx,1),%r10
 100ae62:	4c 89 55 c0          	mov    %r10,-0x40(%rbp)
 100ae66:	4d 8b 4c 09 30       	mov    0x30(%r9,%rcx,1),%r9
 100ae6b:	4c 89 4d c8          	mov    %r9,-0x38(%rbp)
 100ae6f:	66 49 0f 6e c8       	movq   %r8,%xmm1
 100ae74:	66 48 0f 6e d6       	movq   %rsi,%xmm2
 100ae79:	f2 0f 59 d5          	mulsd  %xmm5,%xmm2
 100ae7d:	66 48 0f 7e d6       	movq   %xmm2,%rsi
 100ae82:	66 48 0f 6e f6       	movq   %rsi,%xmm6
 100ae87:	66 49 0f 6e d7       	movq   %r15,%xmm2
 100ae8c:	66 48 0f 6e fa       	movq   %rdx,%xmm7
 100ae91:	f2 0f 59 d7          	mulsd  %xmm7,%xmm2
 100ae95:	66 48 0f 7e d2       	movq   %xmm2,%rdx
 100ae9a:	66 48 0f 6e d2       	movq   %rdx,%xmm2
 100ae9f:	f2 44 0f 10 fa       	movsd  %xmm2,%xmm15
 100aea4:	f2 0f 10 d0          	movsd  %xmm0,%xmm2
 100aea8:	f2 41 0f 5e d7       	divsd  %xmm15,%xmm2
 100aead:	66 48 0f 7e d2       	movq   %xmm2,%rdx
 100aeb2:	66 48 0f 6e d2       	movq   %rdx,%xmm2
 100aeb7:	f2 0f 59 f2          	mulsd  %xmm2,%xmm6
 100aebb:	66 48 0f 7e f2       	movq   %xmm6,%rdx
 100aec0:	66 48 0f 6e f2       	movq   %rdx,%xmm6
 100aec5:	f2 0f 5c ce          	subsd  %xmm6,%xmm1
 100aec9:	66 48 0f 7e ca       	movq   %xmm1,%rdx
 100aece:	48 89 55 b0          	mov    %rdx,-0x50(%rbp)
 100aed2:	c7 85 d0 fa ff ff 00 	movl   $0x0,-0x530(%rbp)
 100aed9:	00 00 00 
 100aedc:	48 8b 10             	mov    (%rax),%rdx
 100aedf:	49 39 d6             	cmp    %rdx,%r14
 100aee2:	0f 83 8c 10 00 00    	jae    100bf74 <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x1e64>
 100aee8:	48 8b 50 20          	mov    0x20(%rax),%rdx
 100aeec:	48 8b 45 98          	mov    -0x68(%rbp),%rax
 100aef0:	48 89 04 11          	mov    %rax,(%rcx,%rdx,1)
 100aef4:	48 8b 45 a0          	mov    -0x60(%rbp),%rax
 100aef8:	48 89 44 11 08       	mov    %rax,0x8(%rcx,%rdx,1)
 100aefd:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
 100af01:	48 89 44 11 10       	mov    %rax,0x10(%rcx,%rdx,1)
 100af06:	48 8b 45 b0          	mov    -0x50(%rbp),%rax
 100af0a:	48 89 44 11 18       	mov    %rax,0x18(%rcx,%rdx,1)
 100af0f:	48 8b 45 b8          	mov    -0x48(%rbp),%rax
 100af13:	48 89 44 11 20       	mov    %rax,0x20(%rcx,%rdx,1)
 100af18:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
 100af1c:	48 89 44 11 28       	mov    %rax,0x28(%rcx,%rdx,1)
 100af21:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
 100af25:	48 89 44 11 30       	mov    %rax,0x30(%rcx,%rdx,1)
 100af2a:	48 8b 45 90          	mov    -0x70(%rbp),%rax
 100af2e:	48 83 fb 00          	cmp    $0x0,%rbx
 100af32:	7c 05                	jl     100af39 <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0xe29>
 100af34:	49 89 de             	mov    %rbx,%r14
 100af37:	eb 35                	jmp    100af6e <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0xe5e>
 100af39:	48 8b 30             	mov    (%rax),%rsi
 100af3c:	48 b9 ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rcx
 100af43:	ff ff 7f 
 100af46:	48 39 ce             	cmp    %rcx,%rsi
 100af49:	0f 87 19 10 00 00    	ja     100bf68 <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x1e58>
 100af4f:	49 89 f6             	mov    %rsi,%r14
 100af52:	49 01 de             	add    %rbx,%r14
 100af55:	48 89 f1             	mov    %rsi,%rcx
 100af58:	4c 31 f1             	xor    %r14,%rcx
 100af5b:	48 89 da             	mov    %rbx,%rdx
 100af5e:	4c 31 f2             	xor    %r14,%rdx
 100af61:	48 21 d1             	and    %rdx,%rcx
 100af64:	48 83 f9 00          	cmp    $0x0,%rcx
 100af68:	0f 8c df 0f 00 00    	jl     100bf4d <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x1e3d>
 100af6e:	48 8b 08             	mov    (%rax),%rcx
 100af71:	49 39 ce             	cmp    %rcx,%r14
 100af74:	0f 83 c6 0f 00 00    	jae    100bf40 <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x1e30>
 100af7a:	48 8b 48 20          	mov    0x20(%rax),%rcx
 100af7e:	49 6b d6 38          	imul   $0x38,%r14,%rdx
 100af82:	48 8b 34 11          	mov    (%rcx,%rdx,1),%rsi
 100af86:	48 89 75 98          	mov    %rsi,-0x68(%rbp)
 100af8a:	48 8b 74 11 08       	mov    0x8(%rcx,%rdx,1),%rsi
 100af8f:	48 89 75 a0          	mov    %rsi,-0x60(%rbp)
 100af93:	48 8b 74 11 10       	mov    0x10(%rcx,%rdx,1),%rsi
 100af98:	48 89 75 a8          	mov    %rsi,-0x58(%rbp)
 100af9c:	48 8b 74 11 18       	mov    0x18(%rcx,%rdx,1),%rsi
 100afa1:	48 89 75 b0          	mov    %rsi,-0x50(%rbp)
 100afa5:	48 8b 74 11 20       	mov    0x20(%rcx,%rdx,1),%rsi
 100afaa:	48 89 75 b8          	mov    %rsi,-0x48(%rbp)
 100afae:	48 8b 74 11 28       	mov    0x28(%rcx,%rdx,1),%rsi
 100afb3:	48 89 75 c0          	mov    %rsi,-0x40(%rbp)
 100afb7:	48 8b 4c 11 30       	mov    0x30(%rcx,%rdx,1),%rcx
 100afbc:	48 89 4d c8          	mov    %rcx,-0x38(%rbp)
 100afc0:	48 8b 75 b8          	mov    -0x48(%rbp),%rsi
 100afc4:	49 83 fc 00          	cmp    $0x0,%r12
 100afc8:	7c 05                	jl     100afcf <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0xebf>
 100afca:	4d 89 e6             	mov    %r12,%r14
 100afcd:	eb 35                	jmp    100b004 <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0xef4>
 100afcf:	4c 8b 08             	mov    (%rax),%r9
 100afd2:	48 b9 ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rcx
 100afd9:	ff ff 7f 
 100afdc:	49 39 c9             	cmp    %rcx,%r9
 100afdf:	0f 87 4c 0f 00 00    	ja     100bf31 <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x1e21>
 100afe5:	4d 89 ce             	mov    %r9,%r14
 100afe8:	4d 01 e6             	add    %r12,%r14
 100afeb:	4c 89 c9             	mov    %r9,%rcx
 100afee:	4c 31 f1             	xor    %r14,%rcx
 100aff1:	4c 89 e2             	mov    %r12,%rdx
 100aff4:	4c 31 f2             	xor    %r14,%rdx
 100aff7:	48 21 d1             	and    %rdx,%rcx
 100affa:	48 83 f9 00          	cmp    $0x0,%rcx
 100affe:	0f 8c 12 0f 00 00    	jl     100bf16 <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x1e06>
 100b004:	48 8b 08             	mov    (%rax),%rcx
 100b007:	49 39 ce             	cmp    %rcx,%r14
 100b00a:	0f 83 f9 0e 00 00    	jae    100bf09 <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x1df9>
 100b010:	48 8b 48 20          	mov    0x20(%rax),%rcx
 100b014:	49 6b d6 38          	imul   $0x38,%r14,%rdx
 100b018:	4c 8b 04 11          	mov    (%rcx,%rdx,1),%r8
 100b01c:	4c 89 45 98          	mov    %r8,-0x68(%rbp)
 100b020:	4c 8b 44 11 08       	mov    0x8(%rcx,%rdx,1),%r8
 100b025:	4c 89 45 a0          	mov    %r8,-0x60(%rbp)
 100b029:	4c 8b 44 11 10       	mov    0x10(%rcx,%rdx,1),%r8
 100b02e:	4c 89 45 a8          	mov    %r8,-0x58(%rbp)
 100b032:	4c 8b 44 11 18       	mov    0x18(%rcx,%rdx,1),%r8
 100b037:	4c 89 45 b0          	mov    %r8,-0x50(%rbp)
 100b03b:	4c 8b 44 11 20       	mov    0x20(%rcx,%rdx,1),%r8
 100b040:	4c 89 45 b8          	mov    %r8,-0x48(%rbp)
 100b044:	4c 8b 44 11 28       	mov    0x28(%rcx,%rdx,1),%r8
 100b049:	4c 89 45 c0          	mov    %r8,-0x40(%rbp)
 100b04d:	48 8b 4c 11 30       	mov    0x30(%rcx,%rdx,1),%rcx
 100b052:	48 89 4d c8          	mov    %rcx,-0x38(%rbp)
 100b056:	48 8b 55 c8          	mov    -0x38(%rbp),%rdx
 100b05a:	48 83 fb 00          	cmp    $0x0,%rbx
 100b05e:	7c 05                	jl     100b065 <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0xf55>
 100b060:	49 89 de             	mov    %rbx,%r14
 100b063:	eb 35                	jmp    100b09a <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0xf8a>
 100b065:	4c 8b 08             	mov    (%rax),%r9
 100b068:	48 b9 ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rcx
 100b06f:	ff ff 7f 
 100b072:	49 39 c9             	cmp    %rcx,%r9
 100b075:	0f 87 7f 0e 00 00    	ja     100befa <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x1dea>
 100b07b:	4d 89 ce             	mov    %r9,%r14
 100b07e:	49 01 de             	add    %rbx,%r14
 100b081:	4c 89 c9             	mov    %r9,%rcx
 100b084:	4c 31 f1             	xor    %r14,%rcx
 100b087:	49 89 d8             	mov    %rbx,%r8
 100b08a:	4d 31 f0             	xor    %r14,%r8
 100b08d:	4c 21 c1             	and    %r8,%rcx
 100b090:	48 83 f9 00          	cmp    $0x0,%rcx
 100b094:	0f 8c 42 0e 00 00    	jl     100bedc <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x1dcc>
 100b09a:	48 8b 08             	mov    (%rax),%rcx
 100b09d:	49 39 ce             	cmp    %rcx,%r14
 100b0a0:	0f 83 29 0e 00 00    	jae    100becf <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x1dbf>
 100b0a6:	4c 8b 40 20          	mov    0x20(%rax),%r8
 100b0aa:	49 6b ce 38          	imul   $0x38,%r14,%rcx
 100b0ae:	4d 8b 0c 08          	mov    (%r8,%rcx,1),%r9
 100b0b2:	4c 89 4d 98          	mov    %r9,-0x68(%rbp)
 100b0b6:	4d 8b 4c 08 08       	mov    0x8(%r8,%rcx,1),%r9
 100b0bb:	4c 89 4d a0          	mov    %r9,-0x60(%rbp)
 100b0bf:	4d 8b 4c 08 10       	mov    0x10(%r8,%rcx,1),%r9
 100b0c4:	4c 89 4d a8          	mov    %r9,-0x58(%rbp)
 100b0c8:	4d 8b 4c 08 18       	mov    0x18(%r8,%rcx,1),%r9
 100b0cd:	4c 89 4d b0          	mov    %r9,-0x50(%rbp)
 100b0d1:	4d 8b 4c 08 20       	mov    0x20(%r8,%rcx,1),%r9
 100b0d6:	4c 89 4d b8          	mov    %r9,-0x48(%rbp)
 100b0da:	4d 8b 4c 08 28       	mov    0x28(%r8,%rcx,1),%r9
 100b0df:	4c 89 4d c0          	mov    %r9,-0x40(%rbp)
 100b0e3:	4d 8b 4c 08 30       	mov    0x30(%r8,%rcx,1),%r9
 100b0e8:	4c 89 4d c8          	mov    %r9,-0x38(%rbp)
 100b0ec:	4d 8b 0c 08          	mov    (%r8,%rcx,1),%r9
 100b0f0:	4c 89 4d 98          	mov    %r9,-0x68(%rbp)
 100b0f4:	4d 8b 4c 08 08       	mov    0x8(%r8,%rcx,1),%r9
 100b0f9:	4c 89 4d a0          	mov    %r9,-0x60(%rbp)
 100b0fd:	4d 8b 4c 08 10       	mov    0x10(%r8,%rcx,1),%r9
 100b102:	4c 89 4d a8          	mov    %r9,-0x58(%rbp)
 100b106:	4d 8b 4c 08 18       	mov    0x18(%r8,%rcx,1),%r9
 100b10b:	4c 89 4d b0          	mov    %r9,-0x50(%rbp)
 100b10f:	4d 8b 4c 08 20       	mov    0x20(%r8,%rcx,1),%r9
 100b114:	4c 89 4d b8          	mov    %r9,-0x48(%rbp)
 100b118:	4d 8b 4c 08 28       	mov    0x28(%r8,%rcx,1),%r9
 100b11d:	4c 89 4d c0          	mov    %r9,-0x40(%rbp)
 100b121:	4d 8b 44 08 30       	mov    0x30(%r8,%rcx,1),%r8
 100b126:	4c 89 45 c8          	mov    %r8,-0x38(%rbp)
 100b12a:	66 48 0f 6e ce       	movq   %rsi,%xmm1
 100b12f:	66 48 0f 6e f2       	movq   %rdx,%xmm6
 100b134:	f2 0f 59 f4          	mulsd  %xmm4,%xmm6
 100b138:	66 48 0f 7e f2       	movq   %xmm6,%rdx
 100b13d:	66 48 0f 6e f2       	movq   %rdx,%xmm6
 100b142:	f2 0f 59 f2          	mulsd  %xmm2,%xmm6
 100b146:	66 48 0f 7e f2       	movq   %xmm6,%rdx
 100b14b:	66 48 0f 6e f2       	movq   %rdx,%xmm6
 100b150:	f2 0f 5c ce          	subsd  %xmm6,%xmm1
 100b154:	66 48 0f 7e ca       	movq   %xmm1,%rdx
 100b159:	48 89 55 b8          	mov    %rdx,-0x48(%rbp)
 100b15d:	c7 85 d0 fa ff ff 00 	movl   $0x0,-0x530(%rbp)
 100b164:	00 00 00 
 100b167:	48 8b 10             	mov    (%rax),%rdx
 100b16a:	49 39 d6             	cmp    %rdx,%r14
 100b16d:	0f 83 52 0d 00 00    	jae    100bec5 <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x1db5>
 100b173:	48 8b 50 20          	mov    0x20(%rax),%rdx
 100b177:	48 8b 45 98          	mov    -0x68(%rbp),%rax
 100b17b:	48 89 04 11          	mov    %rax,(%rcx,%rdx,1)
 100b17f:	48 8b 45 a0          	mov    -0x60(%rbp),%rax
 100b183:	48 89 44 11 08       	mov    %rax,0x8(%rcx,%rdx,1)
 100b188:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
 100b18c:	48 89 44 11 10       	mov    %rax,0x10(%rcx,%rdx,1)
 100b191:	48 8b 45 b0          	mov    -0x50(%rbp),%rax
 100b195:	48 89 44 11 18       	mov    %rax,0x18(%rcx,%rdx,1)
 100b19a:	48 8b 45 b8          	mov    -0x48(%rbp),%rax
 100b19e:	48 89 44 11 20       	mov    %rax,0x20(%rcx,%rdx,1)
 100b1a3:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
 100b1a7:	48 89 44 11 28       	mov    %rax,0x28(%rcx,%rdx,1)
 100b1ac:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
 100b1b0:	48 89 44 11 30       	mov    %rax,0x30(%rcx,%rdx,1)
 100b1b5:	48 8b 45 90          	mov    -0x70(%rbp),%rax
 100b1b9:	48 83 fb 00          	cmp    $0x0,%rbx
 100b1bd:	7c 05                	jl     100b1c4 <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x10b4>
 100b1bf:	49 89 de             	mov    %rbx,%r14
 100b1c2:	eb 35                	jmp    100b1f9 <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x10e9>
 100b1c4:	48 8b 30             	mov    (%rax),%rsi
 100b1c7:	48 b9 ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rcx
 100b1ce:	ff ff 7f 
 100b1d1:	48 39 ce             	cmp    %rcx,%rsi
 100b1d4:	0f 87 df 0c 00 00    	ja     100beb9 <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x1da9>
 100b1da:	49 89 f6             	mov    %rsi,%r14
 100b1dd:	49 01 de             	add    %rbx,%r14
 100b1e0:	48 89 f1             	mov    %rsi,%rcx
 100b1e3:	4c 31 f1             	xor    %r14,%rcx
 100b1e6:	48 89 da             	mov    %rbx,%rdx
 100b1e9:	4c 31 f2             	xor    %r14,%rdx
 100b1ec:	48 21 d1             	and    %rdx,%rcx
 100b1ef:	48 83 f9 00          	cmp    $0x0,%rcx
 100b1f3:	0f 8c a5 0c 00 00    	jl     100be9e <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x1d8e>
 100b1f9:	48 8b 08             	mov    (%rax),%rcx
 100b1fc:	49 39 ce             	cmp    %rcx,%r14
 100b1ff:	0f 83 8c 0c 00 00    	jae    100be91 <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x1d81>
 100b205:	48 8b 48 20          	mov    0x20(%rax),%rcx
 100b209:	49 6b d6 38          	imul   $0x38,%r14,%rdx
 100b20d:	48 8b 34 11          	mov    (%rcx,%rdx,1),%rsi
 100b211:	48 89 75 98          	mov    %rsi,-0x68(%rbp)
 100b215:	48 8b 74 11 08       	mov    0x8(%rcx,%rdx,1),%rsi
 100b21a:	48 89 75 a0          	mov    %rsi,-0x60(%rbp)
 100b21e:	48 8b 74 11 10       	mov    0x10(%rcx,%rdx,1),%rsi
 100b223:	48 89 75 a8          	mov    %rsi,-0x58(%rbp)
 100b227:	48 8b 74 11 18       	mov    0x18(%rcx,%rdx,1),%rsi
 100b22c:	48 89 75 b0          	mov    %rsi,-0x50(%rbp)
 100b230:	48 8b 74 11 20       	mov    0x20(%rcx,%rdx,1),%rsi
 100b235:	48 89 75 b8          	mov    %rsi,-0x48(%rbp)
 100b239:	48 8b 74 11 28       	mov    0x28(%rcx,%rdx,1),%rsi
 100b23e:	48 89 75 c0          	mov    %rsi,-0x40(%rbp)
 100b242:	48 8b 4c 11 30       	mov    0x30(%rcx,%rdx,1),%rcx
 100b247:	48 89 4d c8          	mov    %rcx,-0x38(%rbp)
 100b24b:	48 8b 75 c0          	mov    -0x40(%rbp),%rsi
 100b24f:	49 83 fc 00          	cmp    $0x0,%r12
 100b253:	7c 05                	jl     100b25a <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x114a>
 100b255:	4d 89 e6             	mov    %r12,%r14
 100b258:	eb 35                	jmp    100b28f <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x117f>
 100b25a:	4c 8b 08             	mov    (%rax),%r9
 100b25d:	48 b9 ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rcx
 100b264:	ff ff 7f 
 100b267:	49 39 c9             	cmp    %rcx,%r9
 100b26a:	0f 87 12 0c 00 00    	ja     100be82 <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x1d72>
 100b270:	4d 89 ce             	mov    %r9,%r14
 100b273:	4d 01 e6             	add    %r12,%r14
 100b276:	4c 89 c9             	mov    %r9,%rcx
 100b279:	4c 31 f1             	xor    %r14,%rcx
 100b27c:	4c 89 e2             	mov    %r12,%rdx
 100b27f:	4c 31 f2             	xor    %r14,%rdx
 100b282:	48 21 d1             	and    %rdx,%rcx
 100b285:	48 83 f9 00          	cmp    $0x0,%rcx
 100b289:	0f 8c d8 0b 00 00    	jl     100be67 <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x1d57>
 100b28f:	48 8b 08             	mov    (%rax),%rcx
 100b292:	49 39 ce             	cmp    %rcx,%r14
 100b295:	0f 83 bf 0b 00 00    	jae    100be5a <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x1d4a>
 100b29b:	48 8b 48 20          	mov    0x20(%rax),%rcx
 100b29f:	49 6b d6 38          	imul   $0x38,%r14,%rdx
 100b2a3:	4c 8b 04 11          	mov    (%rcx,%rdx,1),%r8
 100b2a7:	4c 89 45 98          	mov    %r8,-0x68(%rbp)
 100b2ab:	4c 8b 44 11 08       	mov    0x8(%rcx,%rdx,1),%r8
 100b2b0:	4c 89 45 a0          	mov    %r8,-0x60(%rbp)
 100b2b4:	4c 8b 44 11 10       	mov    0x10(%rcx,%rdx,1),%r8
 100b2b9:	4c 89 45 a8          	mov    %r8,-0x58(%rbp)
 100b2bd:	4c 8b 44 11 18       	mov    0x18(%rcx,%rdx,1),%r8
 100b2c2:	4c 89 45 b0          	mov    %r8,-0x50(%rbp)
 100b2c6:	4c 8b 44 11 20       	mov    0x20(%rcx,%rdx,1),%r8
 100b2cb:	4c 89 45 b8          	mov    %r8,-0x48(%rbp)
 100b2cf:	4c 8b 44 11 28       	mov    0x28(%rcx,%rdx,1),%r8
 100b2d4:	4c 89 45 c0          	mov    %r8,-0x40(%rbp)
 100b2d8:	48 8b 4c 11 30       	mov    0x30(%rcx,%rdx,1),%rcx
 100b2dd:	48 89 4d c8          	mov    %rcx,-0x38(%rbp)
 100b2e1:	48 8b 55 c8          	mov    -0x38(%rbp),%rdx
 100b2e5:	48 83 fb 00          	cmp    $0x0,%rbx
 100b2e9:	7c 05                	jl     100b2f0 <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x11e0>
 100b2eb:	49 89 de             	mov    %rbx,%r14
 100b2ee:	eb 35                	jmp    100b325 <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x1215>
 100b2f0:	4c 8b 08             	mov    (%rax),%r9
 100b2f3:	48 b9 ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rcx
 100b2fa:	ff ff 7f 
 100b2fd:	49 39 c9             	cmp    %rcx,%r9
 100b300:	0f 87 45 0b 00 00    	ja     100be4b <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x1d3b>
 100b306:	4d 89 ce             	mov    %r9,%r14
 100b309:	49 01 de             	add    %rbx,%r14
 100b30c:	4c 89 c9             	mov    %r9,%rcx
 100b30f:	4c 31 f1             	xor    %r14,%rcx
 100b312:	49 89 d8             	mov    %rbx,%r8
 100b315:	4d 31 f0             	xor    %r14,%r8
 100b318:	4c 21 c1             	and    %r8,%rcx
 100b31b:	48 83 f9 00          	cmp    $0x0,%rcx
 100b31f:	0f 8c 08 0b 00 00    	jl     100be2d <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x1d1d>
 100b325:	48 8b 08             	mov    (%rax),%rcx
 100b328:	49 39 ce             	cmp    %rcx,%r14
 100b32b:	0f 83 ef 0a 00 00    	jae    100be20 <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x1d10>
 100b331:	4c 8b 40 20          	mov    0x20(%rax),%r8
 100b335:	49 6b ce 38          	imul   $0x38,%r14,%rcx
 100b339:	4d 8b 0c 08          	mov    (%r8,%rcx,1),%r9
 100b33d:	4c 89 4d 98          	mov    %r9,-0x68(%rbp)
 100b341:	4d 8b 4c 08 08       	mov    0x8(%r8,%rcx,1),%r9
 100b346:	4c 89 4d a0          	mov    %r9,-0x60(%rbp)
 100b34a:	4d 8b 4c 08 10       	mov    0x10(%r8,%rcx,1),%r9
 100b34f:	4c 89 4d a8          	mov    %r9,-0x58(%rbp)
 100b353:	4d 8b 4c 08 18       	mov    0x18(%r8,%rcx,1),%r9
 100b358:	4c 89 4d b0          	mov    %r9,-0x50(%rbp)
 100b35c:	4d 8b 4c 08 20       	mov    0x20(%r8,%rcx,1),%r9
 100b361:	4c 89 4d b8          	mov    %r9,-0x48(%rbp)
 100b365:	4d 8b 4c 08 28       	mov    0x28(%r8,%rcx,1),%r9
 100b36a:	4c 89 4d c0          	mov    %r9,-0x40(%rbp)
 100b36e:	4d 8b 4c 08 30       	mov    0x30(%r8,%rcx,1),%r9
 100b373:	4c 89 4d c8          	mov    %r9,-0x38(%rbp)
 100b377:	4d 8b 0c 08          	mov    (%r8,%rcx,1),%r9
 100b37b:	4c 89 4d 98          	mov    %r9,-0x68(%rbp)
 100b37f:	4d 8b 4c 08 08       	mov    0x8(%r8,%rcx,1),%r9
 100b384:	4c 89 4d a0          	mov    %r9,-0x60(%rbp)
 100b388:	4d 8b 4c 08 10       	mov    0x10(%r8,%rcx,1),%r9
 100b38d:	4c 89 4d a8          	mov    %r9,-0x58(%rbp)
 100b391:	4d 8b 4c 08 18       	mov    0x18(%r8,%rcx,1),%r9
 100b396:	4c 89 4d b0          	mov    %r9,-0x50(%rbp)
 100b39a:	4d 8b 4c 08 20       	mov    0x20(%r8,%rcx,1),%r9
 100b39f:	4c 89 4d b8          	mov    %r9,-0x48(%rbp)
 100b3a3:	4d 8b 4c 08 28       	mov    0x28(%r8,%rcx,1),%r9
 100b3a8:	4c 89 4d c0          	mov    %r9,-0x40(%rbp)
 100b3ac:	4d 8b 44 08 30       	mov    0x30(%r8,%rcx,1),%r8
 100b3b1:	4c 89 45 c8          	mov    %r8,-0x38(%rbp)
 100b3b5:	66 48 0f 6e ce       	movq   %rsi,%xmm1
 100b3ba:	66 48 0f 6e f2       	movq   %rdx,%xmm6
 100b3bf:	f2 0f 59 f3          	mulsd  %xmm3,%xmm6
 100b3c3:	66 48 0f 7e f2       	movq   %xmm6,%rdx
 100b3c8:	66 48 0f 6e f2       	movq   %rdx,%xmm6
 100b3cd:	f2 0f 59 f2          	mulsd  %xmm2,%xmm6
 100b3d1:	66 48 0f 7e f2       	movq   %xmm6,%rdx
 100b3d6:	66 48 0f 6e f2       	movq   %rdx,%xmm6
 100b3db:	f2 0f 5c ce          	subsd  %xmm6,%xmm1
 100b3df:	66 48 0f 7e ca       	movq   %xmm1,%rdx
 100b3e4:	48 89 55 c0          	mov    %rdx,-0x40(%rbp)
 100b3e8:	c7 85 d0 fa ff ff 00 	movl   $0x0,-0x530(%rbp)
 100b3ef:	00 00 00 
 100b3f2:	48 8b 10             	mov    (%rax),%rdx
 100b3f5:	49 39 d6             	cmp    %rdx,%r14
 100b3f8:	0f 83 18 0a 00 00    	jae    100be16 <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x1d06>
 100b3fe:	48 8b 50 20          	mov    0x20(%rax),%rdx
 100b402:	48 8b 45 98          	mov    -0x68(%rbp),%rax
 100b406:	48 89 04 11          	mov    %rax,(%rcx,%rdx,1)
 100b40a:	48 8b 45 a0          	mov    -0x60(%rbp),%rax
 100b40e:	48 89 44 11 08       	mov    %rax,0x8(%rcx,%rdx,1)
 100b413:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
 100b417:	48 89 44 11 10       	mov    %rax,0x10(%rcx,%rdx,1)
 100b41c:	48 8b 45 b0          	mov    -0x50(%rbp),%rax
 100b420:	48 89 44 11 18       	mov    %rax,0x18(%rcx,%rdx,1)
 100b425:	48 8b 45 b8          	mov    -0x48(%rbp),%rax
 100b429:	48 89 44 11 20       	mov    %rax,0x20(%rcx,%rdx,1)
 100b42e:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
 100b432:	48 89 44 11 28       	mov    %rax,0x28(%rcx,%rdx,1)
 100b437:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
 100b43b:	48 89 44 11 30       	mov    %rax,0x30(%rcx,%rdx,1)
 100b440:	48 8b 45 90          	mov    -0x70(%rbp),%rax
 100b444:	49 83 fc 00          	cmp    $0x0,%r12
 100b448:	7c 05                	jl     100b44f <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x133f>
 100b44a:	4d 89 e6             	mov    %r12,%r14
 100b44d:	eb 35                	jmp    100b484 <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x1374>
 100b44f:	48 8b 30             	mov    (%rax),%rsi
 100b452:	48 b9 ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rcx
 100b459:	ff ff 7f 
 100b45c:	48 39 ce             	cmp    %rcx,%rsi
 100b45f:	0f 87 a5 09 00 00    	ja     100be0a <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x1cfa>
 100b465:	49 89 f6             	mov    %rsi,%r14
 100b468:	4d 01 e6             	add    %r12,%r14
 100b46b:	48 89 f1             	mov    %rsi,%rcx
 100b46e:	4c 31 f1             	xor    %r14,%rcx
 100b471:	4c 89 e2             	mov    %r12,%rdx
 100b474:	4c 31 f2             	xor    %r14,%rdx
 100b477:	48 21 d1             	and    %rdx,%rcx
 100b47a:	48 83 f9 00          	cmp    $0x0,%rcx
 100b47e:	0f 8c 6e 09 00 00    	jl     100bdf2 <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x1ce2>
 100b484:	48 8b 08             	mov    (%rax),%rcx
 100b487:	49 39 ce             	cmp    %rcx,%r14
 100b48a:	0f 83 55 09 00 00    	jae    100bde5 <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x1cd5>
 100b490:	48 8b 48 20          	mov    0x20(%rax),%rcx
 100b494:	49 6b d6 38          	imul   $0x38,%r14,%rdx
 100b498:	48 8b 34 11          	mov    (%rcx,%rdx,1),%rsi
 100b49c:	48 89 75 98          	mov    %rsi,-0x68(%rbp)
 100b4a0:	48 8b 74 11 08       	mov    0x8(%rcx,%rdx,1),%rsi
 100b4a5:	48 89 75 a0          	mov    %rsi,-0x60(%rbp)
 100b4a9:	48 8b 74 11 10       	mov    0x10(%rcx,%rdx,1),%rsi
 100b4ae:	48 89 75 a8          	mov    %rsi,-0x58(%rbp)
 100b4b2:	48 8b 74 11 18       	mov    0x18(%rcx,%rdx,1),%rsi
 100b4b7:	48 89 75 b0          	mov    %rsi,-0x50(%rbp)
 100b4bb:	48 8b 74 11 20       	mov    0x20(%rcx,%rdx,1),%rsi
 100b4c0:	48 89 75 b8          	mov    %rsi,-0x48(%rbp)
 100b4c4:	48 8b 74 11 28       	mov    0x28(%rcx,%rdx,1),%rsi
 100b4c9:	48 89 75 c0          	mov    %rsi,-0x40(%rbp)
 100b4cd:	48 8b 4c 11 30       	mov    0x30(%rcx,%rdx,1),%rcx
 100b4d2:	48 89 4d c8          	mov    %rcx,-0x38(%rbp)
 100b4d6:	48 8b 75 b0          	mov    -0x50(%rbp),%rsi
 100b4da:	48 83 fb 00          	cmp    $0x0,%rbx
 100b4de:	7c 05                	jl     100b4e5 <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x13d5>
 100b4e0:	49 89 de             	mov    %rbx,%r14
 100b4e3:	eb 35                	jmp    100b51a <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x140a>
 100b4e5:	4c 8b 08             	mov    (%rax),%r9
 100b4e8:	48 b9 ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rcx
 100b4ef:	ff ff 7f 
 100b4f2:	49 39 c9             	cmp    %rcx,%r9
 100b4f5:	0f 87 db 08 00 00    	ja     100bdd6 <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x1cc6>
 100b4fb:	4d 89 ce             	mov    %r9,%r14
 100b4fe:	49 01 de             	add    %rbx,%r14
 100b501:	4c 89 c9             	mov    %r9,%rcx
 100b504:	4c 31 f1             	xor    %r14,%rcx
 100b507:	48 89 da             	mov    %rbx,%rdx
 100b50a:	4c 31 f2             	xor    %r14,%rdx
 100b50d:	48 21 d1             	and    %rdx,%rcx
 100b510:	48 83 f9 00          	cmp    $0x0,%rcx
 100b514:	0f 8c 9e 08 00 00    	jl     100bdb8 <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x1ca8>
 100b51a:	48 8b 08             	mov    (%rax),%rcx
 100b51d:	49 39 ce             	cmp    %rcx,%r14
 100b520:	0f 83 85 08 00 00    	jae    100bdab <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x1c9b>
 100b526:	48 8b 48 20          	mov    0x20(%rax),%rcx
 100b52a:	49 6b d6 38          	imul   $0x38,%r14,%rdx
 100b52e:	4c 8b 04 11          	mov    (%rcx,%rdx,1),%r8
 100b532:	4c 89 45 98          	mov    %r8,-0x68(%rbp)
 100b536:	4c 8b 44 11 08       	mov    0x8(%rcx,%rdx,1),%r8
 100b53b:	4c 89 45 a0          	mov    %r8,-0x60(%rbp)
 100b53f:	4c 8b 44 11 10       	mov    0x10(%rcx,%rdx,1),%r8
 100b544:	4c 89 45 a8          	mov    %r8,-0x58(%rbp)
 100b548:	4c 8b 44 11 18       	mov    0x18(%rcx,%rdx,1),%r8
 100b54d:	4c 89 45 b0          	mov    %r8,-0x50(%rbp)
 100b551:	4c 8b 44 11 20       	mov    0x20(%rcx,%rdx,1),%r8
 100b556:	4c 89 45 b8          	mov    %r8,-0x48(%rbp)
 100b55a:	4c 8b 44 11 28       	mov    0x28(%rcx,%rdx,1),%r8
 100b55f:	4c 89 45 c0          	mov    %r8,-0x40(%rbp)
 100b563:	48 8b 4c 11 30       	mov    0x30(%rcx,%rdx,1),%rcx
 100b568:	48 89 4d c8          	mov    %rcx,-0x38(%rbp)
 100b56c:	48 8b 55 c8          	mov    -0x38(%rbp),%rdx
 100b570:	49 83 fc 00          	cmp    $0x0,%r12
 100b574:	7c 05                	jl     100b57b <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x146b>
 100b576:	4d 89 e6             	mov    %r12,%r14
 100b579:	eb 35                	jmp    100b5b0 <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x14a0>
 100b57b:	4c 8b 08             	mov    (%rax),%r9
 100b57e:	48 b9 ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rcx
 100b585:	ff ff 7f 
 100b588:	49 39 c9             	cmp    %rcx,%r9
 100b58b:	0f 87 0b 08 00 00    	ja     100bd9c <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x1c8c>
 100b591:	4d 89 ce             	mov    %r9,%r14
 100b594:	4d 01 e6             	add    %r12,%r14
 100b597:	4c 89 c9             	mov    %r9,%rcx
 100b59a:	4c 31 f1             	xor    %r14,%rcx
 100b59d:	4d 89 e0             	mov    %r12,%r8
 100b5a0:	4d 31 f0             	xor    %r14,%r8
 100b5a3:	4c 21 c1             	and    %r8,%rcx
 100b5a6:	48 83 f9 00          	cmp    $0x0,%rcx
 100b5aa:	0f 8c d1 07 00 00    	jl     100bd81 <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x1c71>
 100b5b0:	48 8b 08             	mov    (%rax),%rcx
 100b5b3:	49 39 ce             	cmp    %rcx,%r14
 100b5b6:	0f 83 b8 07 00 00    	jae    100bd74 <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x1c64>
 100b5bc:	4c 8b 40 20          	mov    0x20(%rax),%r8
 100b5c0:	49 6b ce 38          	imul   $0x38,%r14,%rcx
 100b5c4:	4d 8b 0c 08          	mov    (%r8,%rcx,1),%r9
 100b5c8:	4c 89 4d 98          	mov    %r9,-0x68(%rbp)
 100b5cc:	4d 8b 4c 08 08       	mov    0x8(%r8,%rcx,1),%r9
 100b5d1:	4c 89 4d a0          	mov    %r9,-0x60(%rbp)
 100b5d5:	4d 8b 4c 08 10       	mov    0x10(%r8,%rcx,1),%r9
 100b5da:	4c 89 4d a8          	mov    %r9,-0x58(%rbp)
 100b5de:	4d 8b 4c 08 18       	mov    0x18(%r8,%rcx,1),%r9
 100b5e3:	4c 89 4d b0          	mov    %r9,-0x50(%rbp)
 100b5e7:	4d 8b 4c 08 20       	mov    0x20(%r8,%rcx,1),%r9
 100b5ec:	4c 89 4d b8          	mov    %r9,-0x48(%rbp)
 100b5f0:	4d 8b 4c 08 28       	mov    0x28(%r8,%rcx,1),%r9
 100b5f5:	4c 89 4d c0          	mov    %r9,-0x40(%rbp)
 100b5f9:	4d 8b 4c 08 30       	mov    0x30(%r8,%rcx,1),%r9
 100b5fe:	4c 89 4d c8          	mov    %r9,-0x38(%rbp)
 100b602:	4d 8b 0c 08          	mov    (%r8,%rcx,1),%r9
 100b606:	4c 89 4d 98          	mov    %r9,-0x68(%rbp)
 100b60a:	4d 8b 4c 08 08       	mov    0x8(%r8,%rcx,1),%r9
 100b60f:	4c 89 4d a0          	mov    %r9,-0x60(%rbp)
 100b613:	4d 8b 4c 08 10       	mov    0x10(%r8,%rcx,1),%r9
 100b618:	4c 89 4d a8          	mov    %r9,-0x58(%rbp)
 100b61c:	4d 8b 4c 08 18       	mov    0x18(%r8,%rcx,1),%r9
 100b621:	4c 89 4d b0          	mov    %r9,-0x50(%rbp)
 100b625:	4d 8b 4c 08 20       	mov    0x20(%r8,%rcx,1),%r9
 100b62a:	4c 89 4d b8          	mov    %r9,-0x48(%rbp)
 100b62e:	4d 8b 4c 08 28       	mov    0x28(%r8,%rcx,1),%r9
 100b633:	4c 89 4d c0          	mov    %r9,-0x40(%rbp)
 100b637:	4d 8b 44 08 30       	mov    0x30(%r8,%rcx,1),%r8
 100b63c:	4c 89 45 c8          	mov    %r8,-0x38(%rbp)
 100b640:	66 48 0f 6e ce       	movq   %rsi,%xmm1
 100b645:	66 48 0f 6e f2       	movq   %rdx,%xmm6
 100b64a:	f2 0f 59 ee          	mulsd  %xmm6,%xmm5
 100b64e:	66 48 0f 7e ea       	movq   %xmm5,%rdx
 100b653:	66 48 0f 6e ea       	movq   %rdx,%xmm5
 100b658:	f2 0f 59 ea          	mulsd  %xmm2,%xmm5
 100b65c:	66 48 0f 7e ea       	movq   %xmm5,%rdx
 100b661:	66 48 0f 6e ea       	movq   %rdx,%xmm5
 100b666:	f2 0f 58 cd          	addsd  %xmm5,%xmm1
 100b66a:	66 48 0f 7e ca       	movq   %xmm1,%rdx
 100b66f:	48 89 55 b0          	mov    %rdx,-0x50(%rbp)
 100b673:	c7 85 d0 fa ff ff 00 	movl   $0x0,-0x530(%rbp)
 100b67a:	00 00 00 
 100b67d:	48 8b 10             	mov    (%rax),%rdx
 100b680:	49 39 d6             	cmp    %rdx,%r14
 100b683:	0f 83 e1 06 00 00    	jae    100bd6a <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x1c5a>
 100b689:	48 8b 50 20          	mov    0x20(%rax),%rdx
 100b68d:	48 8b 45 98          	mov    -0x68(%rbp),%rax
 100b691:	48 89 04 11          	mov    %rax,(%rcx,%rdx,1)
 100b695:	48 8b 45 a0          	mov    -0x60(%rbp),%rax
 100b699:	48 89 44 11 08       	mov    %rax,0x8(%rcx,%rdx,1)
 100b69e:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
 100b6a2:	48 89 44 11 10       	mov    %rax,0x10(%rcx,%rdx,1)
 100b6a7:	48 8b 45 b0          	mov    -0x50(%rbp),%rax
 100b6ab:	48 89 44 11 18       	mov    %rax,0x18(%rcx,%rdx,1)
 100b6b0:	48 8b 45 b8          	mov    -0x48(%rbp),%rax
 100b6b4:	48 89 44 11 20       	mov    %rax,0x20(%rcx,%rdx,1)
 100b6b9:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
 100b6bd:	48 89 44 11 28       	mov    %rax,0x28(%rcx,%rdx,1)
 100b6c2:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
 100b6c6:	48 89 44 11 30       	mov    %rax,0x30(%rcx,%rdx,1)
 100b6cb:	48 8b 45 90          	mov    -0x70(%rbp),%rax
 100b6cf:	49 83 fc 00          	cmp    $0x0,%r12
 100b6d3:	7c 05                	jl     100b6da <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x15ca>
 100b6d5:	4d 89 e6             	mov    %r12,%r14
 100b6d8:	eb 35                	jmp    100b70f <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x15ff>
 100b6da:	48 8b 30             	mov    (%rax),%rsi
 100b6dd:	48 b9 ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rcx
 100b6e4:	ff ff 7f 
 100b6e7:	48 39 ce             	cmp    %rcx,%rsi
 100b6ea:	0f 87 6e 06 00 00    	ja     100bd5e <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x1c4e>
 100b6f0:	49 89 f6             	mov    %rsi,%r14
 100b6f3:	4d 01 e6             	add    %r12,%r14
 100b6f6:	48 89 f1             	mov    %rsi,%rcx
 100b6f9:	4c 31 f1             	xor    %r14,%rcx
 100b6fc:	4c 89 e2             	mov    %r12,%rdx
 100b6ff:	4c 31 f2             	xor    %r14,%rdx
 100b702:	48 21 d1             	and    %rdx,%rcx
 100b705:	48 83 f9 00          	cmp    $0x0,%rcx
 100b709:	0f 8c 37 06 00 00    	jl     100bd46 <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x1c36>
 100b70f:	48 8b 08             	mov    (%rax),%rcx
 100b712:	49 39 ce             	cmp    %rcx,%r14
 100b715:	0f 83 1e 06 00 00    	jae    100bd39 <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x1c29>
 100b71b:	48 8b 48 20          	mov    0x20(%rax),%rcx
 100b71f:	49 6b d6 38          	imul   $0x38,%r14,%rdx
 100b723:	48 8b 34 11          	mov    (%rcx,%rdx,1),%rsi
 100b727:	48 89 75 98          	mov    %rsi,-0x68(%rbp)
 100b72b:	48 8b 74 11 08       	mov    0x8(%rcx,%rdx,1),%rsi
 100b730:	48 89 75 a0          	mov    %rsi,-0x60(%rbp)
 100b734:	48 8b 74 11 10       	mov    0x10(%rcx,%rdx,1),%rsi
 100b739:	48 89 75 a8          	mov    %rsi,-0x58(%rbp)
 100b73d:	48 8b 74 11 18       	mov    0x18(%rcx,%rdx,1),%rsi
 100b742:	48 89 75 b0          	mov    %rsi,-0x50(%rbp)
 100b746:	48 8b 74 11 20       	mov    0x20(%rcx,%rdx,1),%rsi
 100b74b:	48 89 75 b8          	mov    %rsi,-0x48(%rbp)
 100b74f:	48 8b 74 11 28       	mov    0x28(%rcx,%rdx,1),%rsi
 100b754:	48 89 75 c0          	mov    %rsi,-0x40(%rbp)
 100b758:	48 8b 4c 11 30       	mov    0x30(%rcx,%rdx,1),%rcx
 100b75d:	48 89 4d c8          	mov    %rcx,-0x38(%rbp)
 100b761:	48 8b 75 b8          	mov    -0x48(%rbp),%rsi
 100b765:	48 83 fb 00          	cmp    $0x0,%rbx
 100b769:	7c 05                	jl     100b770 <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x1660>
 100b76b:	49 89 de             	mov    %rbx,%r14
 100b76e:	eb 35                	jmp    100b7a5 <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x1695>
 100b770:	4c 8b 08             	mov    (%rax),%r9
 100b773:	48 b9 ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rcx
 100b77a:	ff ff 7f 
 100b77d:	49 39 c9             	cmp    %rcx,%r9
 100b780:	0f 87 a4 05 00 00    	ja     100bd2a <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x1c1a>
 100b786:	4d 89 ce             	mov    %r9,%r14
 100b789:	49 01 de             	add    %rbx,%r14
 100b78c:	4c 89 c9             	mov    %r9,%rcx
 100b78f:	4c 31 f1             	xor    %r14,%rcx
 100b792:	48 89 da             	mov    %rbx,%rdx
 100b795:	4c 31 f2             	xor    %r14,%rdx
 100b798:	48 21 d1             	and    %rdx,%rcx
 100b79b:	48 83 f9 00          	cmp    $0x0,%rcx
 100b79f:	0f 8c 67 05 00 00    	jl     100bd0c <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x1bfc>
 100b7a5:	48 8b 08             	mov    (%rax),%rcx
 100b7a8:	49 39 ce             	cmp    %rcx,%r14
 100b7ab:	0f 83 4e 05 00 00    	jae    100bcff <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x1bef>
 100b7b1:	48 8b 48 20          	mov    0x20(%rax),%rcx
 100b7b5:	49 6b d6 38          	imul   $0x38,%r14,%rdx
 100b7b9:	4c 8b 04 11          	mov    (%rcx,%rdx,1),%r8
 100b7bd:	4c 89 45 98          	mov    %r8,-0x68(%rbp)
 100b7c1:	4c 8b 44 11 08       	mov    0x8(%rcx,%rdx,1),%r8
 100b7c6:	4c 89 45 a0          	mov    %r8,-0x60(%rbp)
 100b7ca:	4c 8b 44 11 10       	mov    0x10(%rcx,%rdx,1),%r8
 100b7cf:	4c 89 45 a8          	mov    %r8,-0x58(%rbp)
 100b7d3:	4c 8b 44 11 18       	mov    0x18(%rcx,%rdx,1),%r8
 100b7d8:	4c 89 45 b0          	mov    %r8,-0x50(%rbp)
 100b7dc:	4c 8b 44 11 20       	mov    0x20(%rcx,%rdx,1),%r8
 100b7e1:	4c 89 45 b8          	mov    %r8,-0x48(%rbp)
 100b7e5:	4c 8b 44 11 28       	mov    0x28(%rcx,%rdx,1),%r8
 100b7ea:	4c 89 45 c0          	mov    %r8,-0x40(%rbp)
 100b7ee:	48 8b 4c 11 30       	mov    0x30(%rcx,%rdx,1),%rcx
 100b7f3:	48 89 4d c8          	mov    %rcx,-0x38(%rbp)
 100b7f7:	48 8b 55 c8          	mov    -0x38(%rbp),%rdx
 100b7fb:	49 83 fc 00          	cmp    $0x0,%r12
 100b7ff:	7c 05                	jl     100b806 <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x16f6>
 100b801:	4d 89 e6             	mov    %r12,%r14
 100b804:	eb 35                	jmp    100b83b <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x172b>
 100b806:	4c 8b 08             	mov    (%rax),%r9
 100b809:	48 b9 ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rcx
 100b810:	ff ff 7f 
 100b813:	49 39 c9             	cmp    %rcx,%r9
 100b816:	0f 87 d4 04 00 00    	ja     100bcf0 <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x1be0>
 100b81c:	4d 89 ce             	mov    %r9,%r14
 100b81f:	4d 01 e6             	add    %r12,%r14
 100b822:	4c 89 c9             	mov    %r9,%rcx
 100b825:	4c 31 f1             	xor    %r14,%rcx
 100b828:	4d 89 e0             	mov    %r12,%r8
 100b82b:	4d 31 f0             	xor    %r14,%r8
 100b82e:	4c 21 c1             	and    %r8,%rcx
 100b831:	48 83 f9 00          	cmp    $0x0,%rcx
 100b835:	0f 8c 9a 04 00 00    	jl     100bcd5 <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x1bc5>
 100b83b:	48 8b 08             	mov    (%rax),%rcx
 100b83e:	49 39 ce             	cmp    %rcx,%r14
 100b841:	0f 83 81 04 00 00    	jae    100bcc8 <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x1bb8>
 100b847:	4c 8b 40 20          	mov    0x20(%rax),%r8
 100b84b:	49 6b ce 38          	imul   $0x38,%r14,%rcx
 100b84f:	4d 8b 0c 08          	mov    (%r8,%rcx,1),%r9
 100b853:	4c 89 4d 98          	mov    %r9,-0x68(%rbp)
 100b857:	4d 8b 4c 08 08       	mov    0x8(%r8,%rcx,1),%r9
 100b85c:	4c 89 4d a0          	mov    %r9,-0x60(%rbp)
 100b860:	4d 8b 4c 08 10       	mov    0x10(%r8,%rcx,1),%r9
 100b865:	4c 89 4d a8          	mov    %r9,-0x58(%rbp)
 100b869:	4d 8b 4c 08 18       	mov    0x18(%r8,%rcx,1),%r9
 100b86e:	4c 89 4d b0          	mov    %r9,-0x50(%rbp)
 100b872:	4d 8b 4c 08 20       	mov    0x20(%r8,%rcx,1),%r9
 100b877:	4c 89 4d b8          	mov    %r9,-0x48(%rbp)
 100b87b:	4d 8b 4c 08 28       	mov    0x28(%r8,%rcx,1),%r9
 100b880:	4c 89 4d c0          	mov    %r9,-0x40(%rbp)
 100b884:	4d 8b 4c 08 30       	mov    0x30(%r8,%rcx,1),%r9
 100b889:	4c 89 4d c8          	mov    %r9,-0x38(%rbp)
 100b88d:	4d 8b 0c 08          	mov    (%r8,%rcx,1),%r9
 100b891:	4c 89 4d 98          	mov    %r9,-0x68(%rbp)
 100b895:	4d 8b 4c 08 08       	mov    0x8(%r8,%rcx,1),%r9
 100b89a:	4c 89 4d a0          	mov    %r9,-0x60(%rbp)
 100b89e:	4d 8b 4c 08 10       	mov    0x10(%r8,%rcx,1),%r9
 100b8a3:	4c 89 4d a8          	mov    %r9,-0x58(%rbp)
 100b8a7:	4d 8b 4c 08 18       	mov    0x18(%r8,%rcx,1),%r9
 100b8ac:	4c 89 4d b0          	mov    %r9,-0x50(%rbp)
 100b8b0:	4d 8b 4c 08 20       	mov    0x20(%r8,%rcx,1),%r9
 100b8b5:	4c 89 4d b8          	mov    %r9,-0x48(%rbp)
 100b8b9:	4d 8b 4c 08 28       	mov    0x28(%r8,%rcx,1),%r9
 100b8be:	4c 89 4d c0          	mov    %r9,-0x40(%rbp)
 100b8c2:	4d 8b 44 08 30       	mov    0x30(%r8,%rcx,1),%r8
 100b8c7:	4c 89 45 c8          	mov    %r8,-0x38(%rbp)
 100b8cb:	66 48 0f 6e ce       	movq   %rsi,%xmm1
 100b8d0:	66 48 0f 6e ea       	movq   %rdx,%xmm5
 100b8d5:	f2 0f 59 e5          	mulsd  %xmm5,%xmm4
 100b8d9:	66 48 0f 7e e2       	movq   %xmm4,%rdx
 100b8de:	66 48 0f 6e e2       	movq   %rdx,%xmm4
 100b8e3:	f2 0f 59 e2          	mulsd  %xmm2,%xmm4
 100b8e7:	66 48 0f 7e e2       	movq   %xmm4,%rdx
 100b8ec:	66 48 0f 6e e2       	movq   %rdx,%xmm4
 100b8f1:	f2 0f 58 cc          	addsd  %xmm4,%xmm1
 100b8f5:	66 48 0f 7e ca       	movq   %xmm1,%rdx
 100b8fa:	48 89 55 b8          	mov    %rdx,-0x48(%rbp)
 100b8fe:	c7 85 d0 fa ff ff 00 	movl   $0x0,-0x530(%rbp)
 100b905:	00 00 00 
 100b908:	48 8b 10             	mov    (%rax),%rdx
 100b90b:	49 39 d6             	cmp    %rdx,%r14
 100b90e:	0f 83 aa 03 00 00    	jae    100bcbe <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x1bae>
 100b914:	48 8b 50 20          	mov    0x20(%rax),%rdx
 100b918:	48 8b 45 98          	mov    -0x68(%rbp),%rax
 100b91c:	48 89 04 11          	mov    %rax,(%rcx,%rdx,1)
 100b920:	48 8b 45 a0          	mov    -0x60(%rbp),%rax
 100b924:	48 89 44 11 08       	mov    %rax,0x8(%rcx,%rdx,1)
 100b929:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
 100b92d:	48 89 44 11 10       	mov    %rax,0x10(%rcx,%rdx,1)
 100b932:	48 8b 45 b0          	mov    -0x50(%rbp),%rax
 100b936:	48 89 44 11 18       	mov    %rax,0x18(%rcx,%rdx,1)
 100b93b:	48 8b 45 b8          	mov    -0x48(%rbp),%rax
 100b93f:	48 89 44 11 20       	mov    %rax,0x20(%rcx,%rdx,1)
 100b944:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
 100b948:	48 89 44 11 28       	mov    %rax,0x28(%rcx,%rdx,1)
 100b94d:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
 100b951:	48 89 44 11 30       	mov    %rax,0x30(%rcx,%rdx,1)
 100b956:	48 8b 45 90          	mov    -0x70(%rbp),%rax
 100b95a:	49 83 fc 00          	cmp    $0x0,%r12
 100b95e:	7c 05                	jl     100b965 <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x1855>
 100b960:	4d 89 e6             	mov    %r12,%r14
 100b963:	eb 35                	jmp    100b99a <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x188a>
 100b965:	48 8b 30             	mov    (%rax),%rsi
 100b968:	48 b9 ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rcx
 100b96f:	ff ff 7f 
 100b972:	48 39 ce             	cmp    %rcx,%rsi
 100b975:	0f 87 37 03 00 00    	ja     100bcb2 <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x1ba2>
 100b97b:	49 89 f6             	mov    %rsi,%r14
 100b97e:	4d 01 e6             	add    %r12,%r14
 100b981:	48 89 f1             	mov    %rsi,%rcx
 100b984:	4c 31 f1             	xor    %r14,%rcx
 100b987:	4c 89 e2             	mov    %r12,%rdx
 100b98a:	4c 31 f2             	xor    %r14,%rdx
 100b98d:	48 21 d1             	and    %rdx,%rcx
 100b990:	48 83 f9 00          	cmp    $0x0,%rcx
 100b994:	0f 8c 00 03 00 00    	jl     100bc9a <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x1b8a>
 100b99a:	48 8b 08             	mov    (%rax),%rcx
 100b99d:	49 39 ce             	cmp    %rcx,%r14
 100b9a0:	0f 83 e7 02 00 00    	jae    100bc8d <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x1b7d>
 100b9a6:	48 8b 48 20          	mov    0x20(%rax),%rcx
 100b9aa:	49 6b d6 38          	imul   $0x38,%r14,%rdx
 100b9ae:	48 8b 34 11          	mov    (%rcx,%rdx,1),%rsi
 100b9b2:	48 89 75 98          	mov    %rsi,-0x68(%rbp)
 100b9b6:	48 8b 74 11 08       	mov    0x8(%rcx,%rdx,1),%rsi
 100b9bb:	48 89 75 a0          	mov    %rsi,-0x60(%rbp)
 100b9bf:	48 8b 74 11 10       	mov    0x10(%rcx,%rdx,1),%rsi
 100b9c4:	48 89 75 a8          	mov    %rsi,-0x58(%rbp)
 100b9c8:	48 8b 74 11 18       	mov    0x18(%rcx,%rdx,1),%rsi
 100b9cd:	48 89 75 b0          	mov    %rsi,-0x50(%rbp)
 100b9d1:	48 8b 74 11 20       	mov    0x20(%rcx,%rdx,1),%rsi
 100b9d6:	48 89 75 b8          	mov    %rsi,-0x48(%rbp)
 100b9da:	48 8b 74 11 28       	mov    0x28(%rcx,%rdx,1),%rsi
 100b9df:	48 89 75 c0          	mov    %rsi,-0x40(%rbp)
 100b9e3:	48 8b 4c 11 30       	mov    0x30(%rcx,%rdx,1),%rcx
 100b9e8:	48 89 4d c8          	mov    %rcx,-0x38(%rbp)
 100b9ec:	48 8b 75 c0          	mov    -0x40(%rbp),%rsi
 100b9f0:	48 83 fb 00          	cmp    $0x0,%rbx
 100b9f4:	7c 05                	jl     100b9fb <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x18eb>
 100b9f6:	49 89 de             	mov    %rbx,%r14
 100b9f9:	eb 35                	jmp    100ba30 <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x1920>
 100b9fb:	4c 8b 08             	mov    (%rax),%r9
 100b9fe:	48 b9 ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rcx
 100ba05:	ff ff 7f 
 100ba08:	49 39 c9             	cmp    %rcx,%r9
 100ba0b:	0f 87 6d 02 00 00    	ja     100bc7e <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x1b6e>
 100ba11:	4d 89 ce             	mov    %r9,%r14
 100ba14:	49 01 de             	add    %rbx,%r14
 100ba17:	4c 89 c9             	mov    %r9,%rcx
 100ba1a:	4c 31 f1             	xor    %r14,%rcx
 100ba1d:	48 89 da             	mov    %rbx,%rdx
 100ba20:	4c 31 f2             	xor    %r14,%rdx
 100ba23:	48 21 d1             	and    %rdx,%rcx
 100ba26:	48 83 f9 00          	cmp    $0x0,%rcx
 100ba2a:	0f 8c 30 02 00 00    	jl     100bc60 <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x1b50>
 100ba30:	48 8b 08             	mov    (%rax),%rcx
 100ba33:	49 39 ce             	cmp    %rcx,%r14
 100ba36:	0f 83 17 02 00 00    	jae    100bc53 <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x1b43>
 100ba3c:	48 8b 48 20          	mov    0x20(%rax),%rcx
 100ba40:	49 6b d6 38          	imul   $0x38,%r14,%rdx
 100ba44:	4c 8b 04 11          	mov    (%rcx,%rdx,1),%r8
 100ba48:	4c 89 45 98          	mov    %r8,-0x68(%rbp)
 100ba4c:	4c 8b 44 11 08       	mov    0x8(%rcx,%rdx,1),%r8
 100ba51:	4c 89 45 a0          	mov    %r8,-0x60(%rbp)
 100ba55:	4c 8b 44 11 10       	mov    0x10(%rcx,%rdx,1),%r8
 100ba5a:	4c 89 45 a8          	mov    %r8,-0x58(%rbp)
 100ba5e:	4c 8b 44 11 18       	mov    0x18(%rcx,%rdx,1),%r8
 100ba63:	4c 89 45 b0          	mov    %r8,-0x50(%rbp)
 100ba67:	4c 8b 44 11 20       	mov    0x20(%rcx,%rdx,1),%r8
 100ba6c:	4c 89 45 b8          	mov    %r8,-0x48(%rbp)
 100ba70:	4c 8b 44 11 28       	mov    0x28(%rcx,%rdx,1),%r8
 100ba75:	4c 89 45 c0          	mov    %r8,-0x40(%rbp)
 100ba79:	48 8b 4c 11 30       	mov    0x30(%rcx,%rdx,1),%rcx
 100ba7e:	48 89 4d c8          	mov    %rcx,-0x38(%rbp)
 100ba82:	48 8b 55 c8          	mov    -0x38(%rbp),%rdx
 100ba86:	49 83 fc 00          	cmp    $0x0,%r12
 100ba8a:	7c 05                	jl     100ba91 <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x1981>
 100ba8c:	4d 89 e6             	mov    %r12,%r14
 100ba8f:	eb 35                	jmp    100bac6 <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x19b6>
 100ba91:	4c 8b 08             	mov    (%rax),%r9
 100ba94:	48 b9 ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rcx
 100ba9b:	ff ff 7f 
 100ba9e:	49 39 c9             	cmp    %rcx,%r9
 100baa1:	0f 87 9d 01 00 00    	ja     100bc44 <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x1b34>
 100baa7:	4d 89 ce             	mov    %r9,%r14
 100baaa:	4d 01 e6             	add    %r12,%r14
 100baad:	4c 89 c9             	mov    %r9,%rcx
 100bab0:	4c 31 f1             	xor    %r14,%rcx
 100bab3:	4d 89 e0             	mov    %r12,%r8
 100bab6:	4d 31 f0             	xor    %r14,%r8
 100bab9:	4c 21 c1             	and    %r8,%rcx
 100babc:	48 83 f9 00          	cmp    $0x0,%rcx
 100bac0:	0f 8c 63 01 00 00    	jl     100bc29 <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x1b19>
 100bac6:	48 8b 08             	mov    (%rax),%rcx
 100bac9:	49 39 ce             	cmp    %rcx,%r14
 100bacc:	0f 83 4a 01 00 00    	jae    100bc1c <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x1b0c>
 100bad2:	4c 8b 40 20          	mov    0x20(%rax),%r8
 100bad6:	49 6b ce 38          	imul   $0x38,%r14,%rcx
 100bada:	4d 8b 0c 08          	mov    (%r8,%rcx,1),%r9
 100bade:	4c 89 4d 98          	mov    %r9,-0x68(%rbp)
 100bae2:	4d 8b 4c 08 08       	mov    0x8(%r8,%rcx,1),%r9
 100bae7:	4c 89 4d a0          	mov    %r9,-0x60(%rbp)
 100baeb:	4d 8b 4c 08 10       	mov    0x10(%r8,%rcx,1),%r9
 100baf0:	4c 89 4d a8          	mov    %r9,-0x58(%rbp)
 100baf4:	4d 8b 4c 08 18       	mov    0x18(%r8,%rcx,1),%r9
 100baf9:	4c 89 4d b0          	mov    %r9,-0x50(%rbp)
 100bafd:	4d 8b 4c 08 20       	mov    0x20(%r8,%rcx,1),%r9
 100bb02:	4c 89 4d b8          	mov    %r9,-0x48(%rbp)
 100bb06:	4d 8b 4c 08 28       	mov    0x28(%r8,%rcx,1),%r9
 100bb0b:	4c 89 4d c0          	mov    %r9,-0x40(%rbp)
 100bb0f:	4d 8b 4c 08 30       	mov    0x30(%r8,%rcx,1),%r9
 100bb14:	4c 89 4d c8          	mov    %r9,-0x38(%rbp)
 100bb18:	4d 8b 0c 08          	mov    (%r8,%rcx,1),%r9
 100bb1c:	4c 89 4d 98          	mov    %r9,-0x68(%rbp)
 100bb20:	4d 8b 4c 08 08       	mov    0x8(%r8,%rcx,1),%r9
 100bb25:	4c 89 4d a0          	mov    %r9,-0x60(%rbp)
 100bb29:	4d 8b 4c 08 10       	mov    0x10(%r8,%rcx,1),%r9
 100bb2e:	4c 89 4d a8          	mov    %r9,-0x58(%rbp)
 100bb32:	4d 8b 4c 08 18       	mov    0x18(%r8,%rcx,1),%r9
 100bb37:	4c 89 4d b0          	mov    %r9,-0x50(%rbp)
 100bb3b:	4d 8b 4c 08 20       	mov    0x20(%r8,%rcx,1),%r9
 100bb40:	4c 89 4d b8          	mov    %r9,-0x48(%rbp)
 100bb44:	4d 8b 4c 08 28       	mov    0x28(%r8,%rcx,1),%r9
 100bb49:	4c 89 4d c0          	mov    %r9,-0x40(%rbp)
 100bb4d:	4d 8b 44 08 30       	mov    0x30(%r8,%rcx,1),%r8
 100bb52:	4c 89 45 c8          	mov    %r8,-0x38(%rbp)
 100bb56:	66 48 0f 6e ce       	movq   %rsi,%xmm1
 100bb5b:	66 48 0f 6e e2       	movq   %rdx,%xmm4
 100bb60:	f2 0f 59 dc          	mulsd  %xmm4,%xmm3
 100bb64:	66 48 0f 7e da       	movq   %xmm3,%rdx
 100bb69:	66 48 0f 6e da       	movq   %rdx,%xmm3
 100bb6e:	f2 0f 59 d3          	mulsd  %xmm3,%xmm2
 100bb72:	66 48 0f 7e d2       	movq   %xmm2,%rdx
 100bb77:	66 48 0f 6e d2       	movq   %rdx,%xmm2
 100bb7c:	f2 0f 58 ca          	addsd  %xmm2,%xmm1
 100bb80:	66 48 0f 7e ca       	movq   %xmm1,%rdx
 100bb85:	48 89 55 c0          	mov    %rdx,-0x40(%rbp)
 100bb89:	c7 85 d0 fa ff ff 00 	movl   $0x0,-0x530(%rbp)
 100bb90:	00 00 00 
 100bb93:	48 8b 10             	mov    (%rax),%rdx
 100bb96:	49 39 d6             	cmp    %rdx,%r14
 100bb99:	73 77                	jae    100bc12 <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x1b02>
 100bb9b:	48 8b 50 20          	mov    0x20(%rax),%rdx
 100bb9f:	48 8b 45 98          	mov    -0x68(%rbp),%rax
 100bba3:	48 89 04 11          	mov    %rax,(%rcx,%rdx,1)
 100bba7:	48 8b 45 a0          	mov    -0x60(%rbp),%rax
 100bbab:	48 89 44 11 08       	mov    %rax,0x8(%rcx,%rdx,1)
 100bbb0:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
 100bbb4:	48 89 44 11 10       	mov    %rax,0x10(%rcx,%rdx,1)
 100bbb9:	48 8b 45 b0          	mov    -0x50(%rbp),%rax
 100bbbd:	48 89 44 11 18       	mov    %rax,0x18(%rcx,%rdx,1)
 100bbc2:	48 8b 45 b8          	mov    -0x48(%rbp),%rax
 100bbc6:	48 89 44 11 20       	mov    %rax,0x20(%rcx,%rdx,1)
 100bbcb:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
 100bbcf:	48 89 44 11 28       	mov    %rax,0x28(%rcx,%rdx,1)
 100bbd4:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
 100bbd8:	48 89 44 11 30       	mov    %rax,0x30(%rcx,%rdx,1)
 100bbdd:	48 b8 fe ff ff ff ff 	movabs $0x7ffffffffffffffe,%rax
 100bbe4:	ff ff 7f 
 100bbe7:	49 39 c4             	cmp    %rax,%r12
 100bbea:	7f 09                	jg     100bbf5 <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x1ae5>
 100bbec:	49 83 c4 01          	add    $0x1,%r12
 100bbf0:	e9 1b ec ff ff       	jmp    100a810 <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x700>
 100bbf5:	4c 89 e2             	mov    %r12,%rdx
 100bbf8:	41 b8 40 00 00 00    	mov    $0x40,%r8d
 100bbfe:	b9 01 00 00 00       	mov    $0x1,%ecx
 100bc03:	49 89 d4             	mov    %rdx,%r12
 100bc06:	be 00 00 00 00       	mov    $0x0,%esi
 100bc0b:	e8 90 31 00 00       	call   100eda0 <myl_qbe_fail_overflow_op>
 100bc10:	0f 0b                	ud2
 100bc12:	4c 89 f6             	mov    %r14,%rsi
 100bc15:	e8 16 31 00 00       	call   100ed30 <myl_qbe_fail_normalized_index_bounds>
 100bc1a:	0f 0b                	ud2
 100bc1c:	48 89 ca             	mov    %rcx,%rdx
 100bc1f:	4c 89 f6             	mov    %r14,%rsi
 100bc22:	e8 09 31 00 00       	call   100ed30 <myl_qbe_fail_normalized_index_bounds>
 100bc27:	0f 0b                	ud2
 100bc29:	4c 89 ce             	mov    %r9,%rsi
 100bc2c:	41 b8 40 00 00 00    	mov    $0x40,%r8d
 100bc32:	4c 89 e1             	mov    %r12,%rcx
 100bc35:	48 89 f2             	mov    %rsi,%rdx
 100bc38:	be 00 00 00 00       	mov    $0x0,%esi
 100bc3d:	e8 5e 31 00 00       	call   100eda0 <myl_qbe_fail_overflow_op>
 100bc42:	0f 0b                	ud2
 100bc44:	4c 89 ce             	mov    %r9,%rsi
 100bc47:	ba 40 01 00 00       	mov    $0x140,%edx
 100bc4c:	e8 8f 32 00 00       	call   100eee0 <myl_qbe_fail_cast>
 100bc51:	0f 0b                	ud2
 100bc53:	48 89 ca             	mov    %rcx,%rdx
 100bc56:	4c 89 f6             	mov    %r14,%rsi
 100bc59:	e8 d2 30 00 00       	call   100ed30 <myl_qbe_fail_normalized_index_bounds>
 100bc5e:	0f 0b                	ud2
 100bc60:	48 89 da             	mov    %rbx,%rdx
 100bc63:	4c 89 ce             	mov    %r9,%rsi
 100bc66:	41 b8 40 00 00 00    	mov    $0x40,%r8d
 100bc6c:	48 89 d1             	mov    %rdx,%rcx
 100bc6f:	48 89 f2             	mov    %rsi,%rdx
 100bc72:	be 00 00 00 00       	mov    $0x0,%esi
 100bc77:	e8 24 31 00 00       	call   100eda0 <myl_qbe_fail_overflow_op>
 100bc7c:	0f 0b                	ud2
 100bc7e:	4c 89 ce             	mov    %r9,%rsi
 100bc81:	ba 40 01 00 00       	mov    $0x140,%edx
 100bc86:	e8 55 32 00 00       	call   100eee0 <myl_qbe_fail_cast>
 100bc8b:	0f 0b                	ud2
 100bc8d:	48 89 ca             	mov    %rcx,%rdx
 100bc90:	4c 89 f6             	mov    %r14,%rsi
 100bc93:	e8 98 30 00 00       	call   100ed30 <myl_qbe_fail_normalized_index_bounds>
 100bc98:	0f 0b                	ud2
 100bc9a:	41 b8 40 00 00 00    	mov    $0x40,%r8d
 100bca0:	4c 89 e1             	mov    %r12,%rcx
 100bca3:	48 89 f2             	mov    %rsi,%rdx
 100bca6:	be 00 00 00 00       	mov    $0x0,%esi
 100bcab:	e8 f0 30 00 00       	call   100eda0 <myl_qbe_fail_overflow_op>
 100bcb0:	0f 0b                	ud2
 100bcb2:	ba 40 01 00 00       	mov    $0x140,%edx
 100bcb7:	e8 24 32 00 00       	call   100eee0 <myl_qbe_fail_cast>
 100bcbc:	0f 0b                	ud2
 100bcbe:	4c 89 f6             	mov    %r14,%rsi
 100bcc1:	e8 6a 30 00 00       	call   100ed30 <myl_qbe_fail_normalized_index_bounds>
 100bcc6:	0f 0b                	ud2
 100bcc8:	48 89 ca             	mov    %rcx,%rdx
 100bccb:	4c 89 f6             	mov    %r14,%rsi
 100bcce:	e8 5d 30 00 00       	call   100ed30 <myl_qbe_fail_normalized_index_bounds>
 100bcd3:	0f 0b                	ud2
 100bcd5:	4c 89 ce             	mov    %r9,%rsi
 100bcd8:	41 b8 40 00 00 00    	mov    $0x40,%r8d
 100bcde:	4c 89 e1             	mov    %r12,%rcx
 100bce1:	48 89 f2             	mov    %rsi,%rdx
 100bce4:	be 00 00 00 00       	mov    $0x0,%esi
 100bce9:	e8 b2 30 00 00       	call   100eda0 <myl_qbe_fail_overflow_op>
 100bcee:	0f 0b                	ud2
 100bcf0:	4c 89 ce             	mov    %r9,%rsi
 100bcf3:	ba 40 01 00 00       	mov    $0x140,%edx
 100bcf8:	e8 e3 31 00 00       	call   100eee0 <myl_qbe_fail_cast>
 100bcfd:	0f 0b                	ud2
 100bcff:	48 89 ca             	mov    %rcx,%rdx
 100bd02:	4c 89 f6             	mov    %r14,%rsi
 100bd05:	e8 26 30 00 00       	call   100ed30 <myl_qbe_fail_normalized_index_bounds>
 100bd0a:	0f 0b                	ud2
 100bd0c:	48 89 da             	mov    %rbx,%rdx
 100bd0f:	4c 89 ce             	mov    %r9,%rsi
 100bd12:	41 b8 40 00 00 00    	mov    $0x40,%r8d
 100bd18:	48 89 d1             	mov    %rdx,%rcx
 100bd1b:	48 89 f2             	mov    %rsi,%rdx
 100bd1e:	be 00 00 00 00       	mov    $0x0,%esi
 100bd23:	e8 78 30 00 00       	call   100eda0 <myl_qbe_fail_overflow_op>
 100bd28:	0f 0b                	ud2
 100bd2a:	4c 89 ce             	mov    %r9,%rsi
 100bd2d:	ba 40 01 00 00       	mov    $0x140,%edx
 100bd32:	e8 a9 31 00 00       	call   100eee0 <myl_qbe_fail_cast>
 100bd37:	0f 0b                	ud2
 100bd39:	48 89 ca             	mov    %rcx,%rdx
 100bd3c:	4c 89 f6             	mov    %r14,%rsi
 100bd3f:	e8 ec 2f 00 00       	call   100ed30 <myl_qbe_fail_normalized_index_bounds>
 100bd44:	0f 0b                	ud2
 100bd46:	41 b8 40 00 00 00    	mov    $0x40,%r8d
 100bd4c:	4c 89 e1             	mov    %r12,%rcx
 100bd4f:	48 89 f2             	mov    %rsi,%rdx
 100bd52:	be 00 00 00 00       	mov    $0x0,%esi
 100bd57:	e8 44 30 00 00       	call   100eda0 <myl_qbe_fail_overflow_op>
 100bd5c:	0f 0b                	ud2
 100bd5e:	ba 40 01 00 00       	mov    $0x140,%edx
 100bd63:	e8 78 31 00 00       	call   100eee0 <myl_qbe_fail_cast>
 100bd68:	0f 0b                	ud2
 100bd6a:	4c 89 f6             	mov    %r14,%rsi
 100bd6d:	e8 be 2f 00 00       	call   100ed30 <myl_qbe_fail_normalized_index_bounds>
 100bd72:	0f 0b                	ud2
 100bd74:	48 89 ca             	mov    %rcx,%rdx
 100bd77:	4c 89 f6             	mov    %r14,%rsi
 100bd7a:	e8 b1 2f 00 00       	call   100ed30 <myl_qbe_fail_normalized_index_bounds>
 100bd7f:	0f 0b                	ud2
 100bd81:	4c 89 ce             	mov    %r9,%rsi
 100bd84:	41 b8 40 00 00 00    	mov    $0x40,%r8d
 100bd8a:	4c 89 e1             	mov    %r12,%rcx
 100bd8d:	48 89 f2             	mov    %rsi,%rdx
 100bd90:	be 00 00 00 00       	mov    $0x0,%esi
 100bd95:	e8 06 30 00 00       	call   100eda0 <myl_qbe_fail_overflow_op>
 100bd9a:	0f 0b                	ud2
 100bd9c:	4c 89 ce             	mov    %r9,%rsi
 100bd9f:	ba 40 01 00 00       	mov    $0x140,%edx
 100bda4:	e8 37 31 00 00       	call   100eee0 <myl_qbe_fail_cast>
 100bda9:	0f 0b                	ud2
 100bdab:	48 89 ca             	mov    %rcx,%rdx
 100bdae:	4c 89 f6             	mov    %r14,%rsi
 100bdb1:	e8 7a 2f 00 00       	call   100ed30 <myl_qbe_fail_normalized_index_bounds>
 100bdb6:	0f 0b                	ud2
 100bdb8:	48 89 da             	mov    %rbx,%rdx
 100bdbb:	4c 89 ce             	mov    %r9,%rsi
 100bdbe:	41 b8 40 00 00 00    	mov    $0x40,%r8d
 100bdc4:	48 89 d1             	mov    %rdx,%rcx
 100bdc7:	48 89 f2             	mov    %rsi,%rdx
 100bdca:	be 00 00 00 00       	mov    $0x0,%esi
 100bdcf:	e8 cc 2f 00 00       	call   100eda0 <myl_qbe_fail_overflow_op>
 100bdd4:	0f 0b                	ud2
 100bdd6:	4c 89 ce             	mov    %r9,%rsi
 100bdd9:	ba 40 01 00 00       	mov    $0x140,%edx
 100bdde:	e8 fd 30 00 00       	call   100eee0 <myl_qbe_fail_cast>
 100bde3:	0f 0b                	ud2
 100bde5:	48 89 ca             	mov    %rcx,%rdx
 100bde8:	4c 89 f6             	mov    %r14,%rsi
 100bdeb:	e8 40 2f 00 00       	call   100ed30 <myl_qbe_fail_normalized_index_bounds>
 100bdf0:	0f 0b                	ud2
 100bdf2:	41 b8 40 00 00 00    	mov    $0x40,%r8d
 100bdf8:	4c 89 e1             	mov    %r12,%rcx
 100bdfb:	48 89 f2             	mov    %rsi,%rdx
 100bdfe:	be 00 00 00 00       	mov    $0x0,%esi
 100be03:	e8 98 2f 00 00       	call   100eda0 <myl_qbe_fail_overflow_op>
 100be08:	0f 0b                	ud2
 100be0a:	ba 40 01 00 00       	mov    $0x140,%edx
 100be0f:	e8 cc 30 00 00       	call   100eee0 <myl_qbe_fail_cast>
 100be14:	0f 0b                	ud2
 100be16:	4c 89 f6             	mov    %r14,%rsi
 100be19:	e8 12 2f 00 00       	call   100ed30 <myl_qbe_fail_normalized_index_bounds>
 100be1e:	0f 0b                	ud2
 100be20:	48 89 ca             	mov    %rcx,%rdx
 100be23:	4c 89 f6             	mov    %r14,%rsi
 100be26:	e8 05 2f 00 00       	call   100ed30 <myl_qbe_fail_normalized_index_bounds>
 100be2b:	0f 0b                	ud2
 100be2d:	48 89 da             	mov    %rbx,%rdx
 100be30:	4c 89 ce             	mov    %r9,%rsi
 100be33:	41 b8 40 00 00 00    	mov    $0x40,%r8d
 100be39:	48 89 d1             	mov    %rdx,%rcx
 100be3c:	48 89 f2             	mov    %rsi,%rdx
 100be3f:	be 00 00 00 00       	mov    $0x0,%esi
 100be44:	e8 57 2f 00 00       	call   100eda0 <myl_qbe_fail_overflow_op>
 100be49:	0f 0b                	ud2
 100be4b:	4c 89 ce             	mov    %r9,%rsi
 100be4e:	ba 40 01 00 00       	mov    $0x140,%edx
 100be53:	e8 88 30 00 00       	call   100eee0 <myl_qbe_fail_cast>
 100be58:	0f 0b                	ud2
 100be5a:	48 89 ca             	mov    %rcx,%rdx
 100be5d:	4c 89 f6             	mov    %r14,%rsi
 100be60:	e8 cb 2e 00 00       	call   100ed30 <myl_qbe_fail_normalized_index_bounds>
 100be65:	0f 0b                	ud2
 100be67:	4c 89 ce             	mov    %r9,%rsi
 100be6a:	41 b8 40 00 00 00    	mov    $0x40,%r8d
 100be70:	4c 89 e1             	mov    %r12,%rcx
 100be73:	48 89 f2             	mov    %rsi,%rdx
 100be76:	be 00 00 00 00       	mov    $0x0,%esi
 100be7b:	e8 20 2f 00 00       	call   100eda0 <myl_qbe_fail_overflow_op>
 100be80:	0f 0b                	ud2
 100be82:	4c 89 ce             	mov    %r9,%rsi
 100be85:	ba 40 01 00 00       	mov    $0x140,%edx
 100be8a:	e8 51 30 00 00       	call   100eee0 <myl_qbe_fail_cast>
 100be8f:	0f 0b                	ud2
 100be91:	48 89 ca             	mov    %rcx,%rdx
 100be94:	4c 89 f6             	mov    %r14,%rsi
 100be97:	e8 94 2e 00 00       	call   100ed30 <myl_qbe_fail_normalized_index_bounds>
 100be9c:	0f 0b                	ud2
 100be9e:	48 89 da             	mov    %rbx,%rdx
 100bea1:	41 b8 40 00 00 00    	mov    $0x40,%r8d
 100bea7:	48 89 d1             	mov    %rdx,%rcx
 100beaa:	48 89 f2             	mov    %rsi,%rdx
 100bead:	be 00 00 00 00       	mov    $0x0,%esi
 100beb2:	e8 e9 2e 00 00       	call   100eda0 <myl_qbe_fail_overflow_op>
 100beb7:	0f 0b                	ud2
 100beb9:	ba 40 01 00 00       	mov    $0x140,%edx
 100bebe:	e8 1d 30 00 00       	call   100eee0 <myl_qbe_fail_cast>
 100bec3:	0f 0b                	ud2
 100bec5:	4c 89 f6             	mov    %r14,%rsi
 100bec8:	e8 63 2e 00 00       	call   100ed30 <myl_qbe_fail_normalized_index_bounds>
 100becd:	0f 0b                	ud2
 100becf:	48 89 ca             	mov    %rcx,%rdx
 100bed2:	4c 89 f6             	mov    %r14,%rsi
 100bed5:	e8 56 2e 00 00       	call   100ed30 <myl_qbe_fail_normalized_index_bounds>
 100beda:	0f 0b                	ud2
 100bedc:	48 89 da             	mov    %rbx,%rdx
 100bedf:	4c 89 ce             	mov    %r9,%rsi
 100bee2:	41 b8 40 00 00 00    	mov    $0x40,%r8d
 100bee8:	48 89 d1             	mov    %rdx,%rcx
 100beeb:	48 89 f2             	mov    %rsi,%rdx
 100beee:	be 00 00 00 00       	mov    $0x0,%esi
 100bef3:	e8 a8 2e 00 00       	call   100eda0 <myl_qbe_fail_overflow_op>
 100bef8:	0f 0b                	ud2
 100befa:	4c 89 ce             	mov    %r9,%rsi
 100befd:	ba 40 01 00 00       	mov    $0x140,%edx
 100bf02:	e8 d9 2f 00 00       	call   100eee0 <myl_qbe_fail_cast>
 100bf07:	0f 0b                	ud2
 100bf09:	48 89 ca             	mov    %rcx,%rdx
 100bf0c:	4c 89 f6             	mov    %r14,%rsi
 100bf0f:	e8 1c 2e 00 00       	call   100ed30 <myl_qbe_fail_normalized_index_bounds>
 100bf14:	0f 0b                	ud2
 100bf16:	4c 89 ce             	mov    %r9,%rsi
 100bf19:	41 b8 40 00 00 00    	mov    $0x40,%r8d
 100bf1f:	4c 89 e1             	mov    %r12,%rcx
 100bf22:	48 89 f2             	mov    %rsi,%rdx
 100bf25:	be 00 00 00 00       	mov    $0x0,%esi
 100bf2a:	e8 71 2e 00 00       	call   100eda0 <myl_qbe_fail_overflow_op>
 100bf2f:	0f 0b                	ud2
 100bf31:	4c 89 ce             	mov    %r9,%rsi
 100bf34:	ba 40 01 00 00       	mov    $0x140,%edx
 100bf39:	e8 a2 2f 00 00       	call   100eee0 <myl_qbe_fail_cast>
 100bf3e:	0f 0b                	ud2
 100bf40:	48 89 ca             	mov    %rcx,%rdx
 100bf43:	4c 89 f6             	mov    %r14,%rsi
 100bf46:	e8 e5 2d 00 00       	call   100ed30 <myl_qbe_fail_normalized_index_bounds>
 100bf4b:	0f 0b                	ud2
 100bf4d:	48 89 da             	mov    %rbx,%rdx
 100bf50:	41 b8 40 00 00 00    	mov    $0x40,%r8d
 100bf56:	48 89 d1             	mov    %rdx,%rcx
 100bf59:	48 89 f2             	mov    %rsi,%rdx
 100bf5c:	be 00 00 00 00       	mov    $0x0,%esi
 100bf61:	e8 3a 2e 00 00       	call   100eda0 <myl_qbe_fail_overflow_op>
 100bf66:	0f 0b                	ud2
 100bf68:	ba 40 01 00 00       	mov    $0x140,%edx
 100bf6d:	e8 6e 2f 00 00       	call   100eee0 <myl_qbe_fail_cast>
 100bf72:	0f 0b                	ud2
 100bf74:	4c 89 f6             	mov    %r14,%rsi
 100bf77:	e8 b4 2d 00 00       	call   100ed30 <myl_qbe_fail_normalized_index_bounds>
 100bf7c:	0f 0b                	ud2
 100bf7e:	48 89 ca             	mov    %rcx,%rdx
 100bf81:	4c 89 f6             	mov    %r14,%rsi
 100bf84:	e8 a7 2d 00 00       	call   100ed30 <myl_qbe_fail_normalized_index_bounds>
 100bf89:	0f 0b                	ud2
 100bf8b:	48 89 da             	mov    %rbx,%rdx
 100bf8e:	4c 89 ce             	mov    %r9,%rsi
 100bf91:	41 b8 40 00 00 00    	mov    $0x40,%r8d
 100bf97:	48 89 d1             	mov    %rdx,%rcx
 100bf9a:	48 89 f2             	mov    %rsi,%rdx
 100bf9d:	be 00 00 00 00       	mov    $0x0,%esi
 100bfa2:	e8 f9 2d 00 00       	call   100eda0 <myl_qbe_fail_overflow_op>
 100bfa7:	0f 0b                	ud2
 100bfa9:	4c 89 ce             	mov    %r9,%rsi
 100bfac:	ba 40 01 00 00       	mov    $0x140,%edx
 100bfb1:	e8 2a 2f 00 00       	call   100eee0 <myl_qbe_fail_cast>
 100bfb6:	0f 0b                	ud2
 100bfb8:	48 89 ca             	mov    %rcx,%rdx
 100bfbb:	4c 89 f6             	mov    %r14,%rsi
 100bfbe:	e8 6d 2d 00 00       	call   100ed30 <myl_qbe_fail_normalized_index_bounds>
 100bfc3:	0f 0b                	ud2
 100bfc5:	41 b8 40 00 00 00    	mov    $0x40,%r8d
 100bfcb:	4c 89 e1             	mov    %r12,%rcx
 100bfce:	48 89 f2             	mov    %rsi,%rdx
 100bfd1:	be 00 00 00 00       	mov    $0x0,%esi
 100bfd6:	e8 c5 2d 00 00       	call   100eda0 <myl_qbe_fail_overflow_op>
 100bfdb:	0f 0b                	ud2
 100bfdd:	ba 40 01 00 00       	mov    $0x140,%edx
 100bfe2:	e8 f9 2e 00 00       	call   100eee0 <myl_qbe_fail_cast>
 100bfe7:	0f 0b                	ud2
 100bfe9:	48 89 ca             	mov    %rcx,%rdx
 100bfec:	4c 89 f6             	mov    %r14,%rsi
 100bfef:	e8 3c 2d 00 00       	call   100ed30 <myl_qbe_fail_normalized_index_bounds>
 100bff4:	0f 0b                	ud2
 100bff6:	48 89 da             	mov    %rbx,%rdx
 100bff9:	41 b8 40 00 00 00    	mov    $0x40,%r8d
 100bfff:	48 89 d1             	mov    %rdx,%rcx
 100c002:	48 89 f2             	mov    %rsi,%rdx
 100c005:	be 00 00 00 00       	mov    $0x0,%esi
 100c00a:	e8 91 2d 00 00       	call   100eda0 <myl_qbe_fail_overflow_op>
 100c00f:	0f 0b                	ud2
 100c011:	ba 40 01 00 00       	mov    $0x140,%edx
 100c016:	e8 c5 2e 00 00       	call   100eee0 <myl_qbe_fail_cast>
 100c01b:	0f 0b                	ud2
 100c01d:	4c 89 d2             	mov    %r10,%rdx
 100c020:	4c 89 f6             	mov    %r14,%rsi
 100c023:	e8 08 2d 00 00       	call   100ed30 <myl_qbe_fail_normalized_index_bounds>
 100c028:	0f 0b                	ud2
 100c02a:	4c 89 d6             	mov    %r10,%rsi
 100c02d:	41 b8 40 00 00 00    	mov    $0x40,%r8d
 100c033:	4c 89 e1             	mov    %r12,%rcx
 100c036:	48 89 f2             	mov    %rsi,%rdx
 100c039:	be 00 00 00 00       	mov    $0x0,%esi
 100c03e:	e8 5d 2d 00 00       	call   100eda0 <myl_qbe_fail_overflow_op>
 100c043:	0f 0b                	ud2
 100c045:	4c 89 d6             	mov    %r10,%rsi
 100c048:	ba 40 01 00 00       	mov    $0x140,%edx
 100c04d:	e8 8e 2e 00 00       	call   100eee0 <myl_qbe_fail_cast>
 100c052:	0f 0b                	ud2
 100c054:	4c 89 ca             	mov    %r9,%rdx
 100c057:	4c 89 f6             	mov    %r14,%rsi
 100c05a:	e8 d1 2c 00 00       	call   100ed30 <myl_qbe_fail_normalized_index_bounds>
 100c05f:	0f 0b                	ud2
 100c061:	48 89 da             	mov    %rbx,%rdx
 100c064:	4c 89 ce             	mov    %r9,%rsi
 100c067:	41 b8 40 00 00 00    	mov    $0x40,%r8d
 100c06d:	48 89 d1             	mov    %rdx,%rcx
 100c070:	48 89 f2             	mov    %rsi,%rdx
 100c073:	be 00 00 00 00       	mov    $0x0,%esi
 100c078:	e8 23 2d 00 00       	call   100eda0 <myl_qbe_fail_overflow_op>
 100c07d:	0f 0b                	ud2
 100c07f:	4c 89 ce             	mov    %r9,%rsi
 100c082:	ba 40 01 00 00       	mov    $0x140,%edx
 100c087:	e8 54 2e 00 00       	call   100eee0 <myl_qbe_fail_cast>
 100c08c:	0f 0b                	ud2
 100c08e:	48 89 ca             	mov    %rcx,%rdx
 100c091:	4c 89 f6             	mov    %r14,%rsi
 100c094:	e8 97 2c 00 00       	call   100ed30 <myl_qbe_fail_normalized_index_bounds>
 100c099:	0f 0b                	ud2
 100c09b:	4c 89 ce             	mov    %r9,%rsi
 100c09e:	41 b8 40 00 00 00    	mov    $0x40,%r8d
 100c0a4:	4c 89 e1             	mov    %r12,%rcx
 100c0a7:	48 89 f2             	mov    %rsi,%rdx
 100c0aa:	be 00 00 00 00       	mov    $0x0,%esi
 100c0af:	e8 ec 2c 00 00       	call   100eda0 <myl_qbe_fail_overflow_op>
 100c0b4:	0f 0b                	ud2
 100c0b6:	4c 89 ce             	mov    %r9,%rsi
 100c0b9:	ba 40 01 00 00       	mov    $0x140,%edx
 100c0be:	e8 1d 2e 00 00       	call   100eee0 <myl_qbe_fail_cast>
 100c0c3:	0f 0b                	ud2
 100c0c5:	48 89 ca             	mov    %rcx,%rdx
 100c0c8:	4c 89 f6             	mov    %r14,%rsi
 100c0cb:	e8 60 2c 00 00       	call   100ed30 <myl_qbe_fail_normalized_index_bounds>
 100c0d0:	0f 0b                	ud2
 100c0d2:	48 89 da             	mov    %rbx,%rdx
 100c0d5:	41 b8 40 00 00 00    	mov    $0x40,%r8d
 100c0db:	48 89 d1             	mov    %rdx,%rcx
 100c0de:	48 89 f2             	mov    %rsi,%rdx
 100c0e1:	be 00 00 00 00       	mov    $0x0,%esi
 100c0e6:	e8 b5 2c 00 00       	call   100eda0 <myl_qbe_fail_overflow_op>
 100c0eb:	0f 0b                	ud2
 100c0ed:	ba 40 01 00 00       	mov    $0x140,%edx
 100c0f2:	e8 e9 2d 00 00       	call   100eee0 <myl_qbe_fail_cast>
 100c0f7:	0f 0b                	ud2
 100c0f9:	48 89 ca             	mov    %rcx,%rdx
 100c0fc:	4c 89 f6             	mov    %r14,%rsi
 100c0ff:	e8 2c 2c 00 00       	call   100ed30 <myl_qbe_fail_normalized_index_bounds>
 100c104:	0f 0b                	ud2
 100c106:	41 b8 40 00 00 00    	mov    $0x40,%r8d
 100c10c:	4c 89 e1             	mov    %r12,%rcx
 100c10f:	48 89 f2             	mov    %rsi,%rdx
 100c112:	be 00 00 00 00       	mov    $0x0,%esi
 100c117:	e8 84 2c 00 00       	call   100eda0 <myl_qbe_fail_overflow_op>
 100c11c:	0f 0b                	ud2
 100c11e:	ba 40 01 00 00       	mov    $0x140,%edx
 100c123:	e8 b8 2d 00 00       	call   100eee0 <myl_qbe_fail_cast>
 100c128:	0f 0b                	ud2
 100c12a:	48 89 ca             	mov    %rcx,%rdx
 100c12d:	4c 89 f6             	mov    %r14,%rsi
 100c130:	e8 fb 2b 00 00       	call   100ed30 <myl_qbe_fail_normalized_index_bounds>
 100c135:	0f 0b                	ud2
 100c137:	48 89 da             	mov    %rbx,%rdx
 100c13a:	41 b8 40 00 00 00    	mov    $0x40,%r8d
 100c140:	48 89 d1             	mov    %rdx,%rcx
 100c143:	48 89 f2             	mov    %rsi,%rdx
 100c146:	be 00 00 00 00       	mov    $0x0,%esi
 100c14b:	e8 50 2c 00 00       	call   100eda0 <myl_qbe_fail_overflow_op>
 100c150:	0f 0b                	ud2
 100c152:	ba 40 01 00 00       	mov    $0x140,%edx
 100c157:	e8 84 2d 00 00       	call   100eee0 <myl_qbe_fail_cast>
 100c15c:	0f 0b                	ud2
 100c15e:	48 8b 5d d0          	mov    -0x30(%rbp),%rbx
 100c162:	f2 0f 10 45 f0       	movsd  -0x10(%rbp),%xmm0
 100c167:	e9 74 e6 ff ff       	jmp    100a7e0 <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x6d0>
 100c16c:	48 89 da             	mov    %rbx,%rdx
 100c16f:	41 b8 40 00 00 00    	mov    $0x40,%r8d
 100c175:	b9 01 00 00 00       	mov    $0x1,%ecx
 100c17a:	be 00 00 00 00       	mov    $0x0,%esi
 100c17f:	e8 1c 2c 00 00       	call   100eda0 <myl_qbe_fail_overflow_op>
 100c184:	0f 0b                	ud2
 100c186:	f2 0f 10 45 f0       	movsd  -0x10(%rbp),%xmm0
 100c18b:	4c 89 ee             	mov    %r13,%rsi
 100c18e:	49 89 f5             	mov    %rsi,%r13
 100c191:	b8 00 00 00 00       	mov    $0x0,%eax
 100c196:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
 100c19d:	00 00 00 
 100c1a0:	4c 39 e8             	cmp    %r13,%rax
 100c1a3:	0f 8d 82 09 00 00    	jge    100cb2b <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x2a1b>
 100c1a9:	48 8b 4d 90          	mov    -0x70(%rbp),%rcx
 100c1ad:	48 83 f8 00          	cmp    $0x0,%rax
 100c1b1:	7c 05                	jl     100c1b8 <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x20a8>
 100c1b3:	48 89 c6             	mov    %rax,%rsi
 100c1b6:	eb 35                	jmp    100c1ed <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x20dd>
 100c1b8:	4c 8b 09             	mov    (%rcx),%r9
 100c1bb:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
 100c1c2:	ff ff 7f 
 100c1c5:	49 39 d1             	cmp    %rdx,%r9
 100c1c8:	0f 87 4e 09 00 00    	ja     100cb1c <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x2a0c>
 100c1ce:	4c 89 ce             	mov    %r9,%rsi
 100c1d1:	48 01 c6             	add    %rax,%rsi
 100c1d4:	4c 89 ca             	mov    %r9,%rdx
 100c1d7:	48 31 f2             	xor    %rsi,%rdx
 100c1da:	49 89 c0             	mov    %rax,%r8
 100c1dd:	49 31 f0             	xor    %rsi,%r8
 100c1e0:	4c 21 c2             	and    %r8,%rdx
 100c1e3:	48 83 fa 00          	cmp    $0x0,%rdx
 100c1e7:	0f 8c 14 09 00 00    	jl     100cb01 <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x29f1>
 100c1ed:	48 8b 11             	mov    (%rcx),%rdx
 100c1f0:	48 39 d6             	cmp    %rdx,%rsi
 100c1f3:	0f 83 01 09 00 00    	jae    100cafa <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x29ea>
 100c1f9:	48 8b 51 20          	mov    0x20(%rcx),%rdx
 100c1fd:	48 6b f6 38          	imul   $0x38,%rsi,%rsi
 100c201:	4c 8b 04 32          	mov    (%rdx,%rsi,1),%r8
 100c205:	4c 89 45 98          	mov    %r8,-0x68(%rbp)
 100c209:	4c 8b 44 32 08       	mov    0x8(%rdx,%rsi,1),%r8
 100c20e:	4c 89 45 a0          	mov    %r8,-0x60(%rbp)
 100c212:	4c 8b 44 32 10       	mov    0x10(%rdx,%rsi,1),%r8
 100c217:	4c 89 45 a8          	mov    %r8,-0x58(%rbp)
 100c21b:	4c 8b 44 32 18       	mov    0x18(%rdx,%rsi,1),%r8
 100c220:	4c 89 45 b0          	mov    %r8,-0x50(%rbp)
 100c224:	4c 8b 44 32 20       	mov    0x20(%rdx,%rsi,1),%r8
 100c229:	4c 89 45 b8          	mov    %r8,-0x48(%rbp)
 100c22d:	4c 8b 44 32 28       	mov    0x28(%rdx,%rsi,1),%r8
 100c232:	4c 89 45 c0          	mov    %r8,-0x40(%rbp)
 100c236:	48 8b 54 32 30       	mov    0x30(%rdx,%rsi,1),%rdx
 100c23b:	48 89 55 c8          	mov    %rdx,-0x38(%rbp)
 100c23f:	4c 8b 4d 98          	mov    -0x68(%rbp),%r9
 100c243:	48 83 f8 00          	cmp    $0x0,%rax
 100c247:	7c 05                	jl     100c24e <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x213e>
 100c249:	48 89 c6             	mov    %rax,%rsi
 100c24c:	eb 35                	jmp    100c283 <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x2173>
 100c24e:	4c 8b 11             	mov    (%rcx),%r10
 100c251:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
 100c258:	ff ff 7f 
 100c25b:	49 39 d2             	cmp    %rdx,%r10
 100c25e:	0f 87 87 08 00 00    	ja     100caeb <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x29db>
 100c264:	4c 89 d6             	mov    %r10,%rsi
 100c267:	48 01 c6             	add    %rax,%rsi
 100c26a:	4c 89 d2             	mov    %r10,%rdx
 100c26d:	48 31 f2             	xor    %rsi,%rdx
 100c270:	49 89 c0             	mov    %rax,%r8
 100c273:	49 31 f0             	xor    %rsi,%r8
 100c276:	4c 21 c2             	and    %r8,%rdx
 100c279:	48 83 fa 00          	cmp    $0x0,%rdx
 100c27d:	0f 8c 4d 08 00 00    	jl     100cad0 <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x29c0>
 100c283:	48 8b 11             	mov    (%rcx),%rdx
 100c286:	48 39 d6             	cmp    %rdx,%rsi
 100c289:	0f 83 3a 08 00 00    	jae    100cac9 <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x29b9>
 100c28f:	48 8b 51 20          	mov    0x20(%rcx),%rdx
 100c293:	48 6b f6 38          	imul   $0x38,%rsi,%rsi
 100c297:	4c 8b 04 32          	mov    (%rdx,%rsi,1),%r8
 100c29b:	4c 89 45 98          	mov    %r8,-0x68(%rbp)
 100c29f:	4c 8b 44 32 08       	mov    0x8(%rdx,%rsi,1),%r8
 100c2a4:	4c 89 45 a0          	mov    %r8,-0x60(%rbp)
 100c2a8:	4c 8b 44 32 10       	mov    0x10(%rdx,%rsi,1),%r8
 100c2ad:	4c 89 45 a8          	mov    %r8,-0x58(%rbp)
 100c2b1:	4c 8b 44 32 18       	mov    0x18(%rdx,%rsi,1),%r8
 100c2b6:	4c 89 45 b0          	mov    %r8,-0x50(%rbp)
 100c2ba:	4c 8b 44 32 20       	mov    0x20(%rdx,%rsi,1),%r8
 100c2bf:	4c 89 45 b8          	mov    %r8,-0x48(%rbp)
 100c2c3:	4c 8b 44 32 28       	mov    0x28(%rdx,%rsi,1),%r8
 100c2c8:	4c 89 45 c0          	mov    %r8,-0x40(%rbp)
 100c2cc:	48 8b 54 32 30       	mov    0x30(%rdx,%rsi,1),%rdx
 100c2d1:	48 89 55 c8          	mov    %rdx,-0x38(%rbp)
 100c2d5:	4c 8b 45 b0          	mov    -0x50(%rbp),%r8
 100c2d9:	48 83 f8 00          	cmp    $0x0,%rax
 100c2dd:	7c 05                	jl     100c2e4 <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x21d4>
 100c2df:	48 89 c6             	mov    %rax,%rsi
 100c2e2:	eb 35                	jmp    100c319 <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x2209>
 100c2e4:	4c 8b 11             	mov    (%rcx),%r10
 100c2e7:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
 100c2ee:	ff ff 7f 
 100c2f1:	49 39 d2             	cmp    %rdx,%r10
 100c2f4:	0f 87 c0 07 00 00    	ja     100caba <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x29aa>
 100c2fa:	4c 89 d6             	mov    %r10,%rsi
 100c2fd:	48 01 c6             	add    %rax,%rsi
 100c300:	4c 89 d2             	mov    %r10,%rdx
 100c303:	48 31 f2             	xor    %rsi,%rdx
 100c306:	49 89 c3             	mov    %rax,%r11
 100c309:	49 31 f3             	xor    %rsi,%r11
 100c30c:	4c 21 da             	and    %r11,%rdx
 100c30f:	48 83 fa 00          	cmp    $0x0,%rdx
 100c313:	0f 8c 86 07 00 00    	jl     100ca9f <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x298f>
 100c319:	48 8b 11             	mov    (%rcx),%rdx
 100c31c:	48 39 d6             	cmp    %rdx,%rsi
 100c31f:	0f 83 73 07 00 00    	jae    100ca98 <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x2988>
 100c325:	4c 8b 51 20          	mov    0x20(%rcx),%r10
 100c329:	48 6b d6 38          	imul   $0x38,%rsi,%rdx
 100c32d:	4d 8b 1c 12          	mov    (%r10,%rdx,1),%r11
 100c331:	4c 89 5d 98          	mov    %r11,-0x68(%rbp)
 100c335:	4d 8b 5c 12 08       	mov    0x8(%r10,%rdx,1),%r11
 100c33a:	4c 89 5d a0          	mov    %r11,-0x60(%rbp)
 100c33e:	4d 8b 5c 12 10       	mov    0x10(%r10,%rdx,1),%r11
 100c343:	4c 89 5d a8          	mov    %r11,-0x58(%rbp)
 100c347:	4d 8b 5c 12 18       	mov    0x18(%r10,%rdx,1),%r11
 100c34c:	4c 89 5d b0          	mov    %r11,-0x50(%rbp)
 100c350:	4d 8b 5c 12 20       	mov    0x20(%r10,%rdx,1),%r11
 100c355:	4c 89 5d b8          	mov    %r11,-0x48(%rbp)
 100c359:	4d 8b 5c 12 28       	mov    0x28(%r10,%rdx,1),%r11
 100c35e:	4c 89 5d c0          	mov    %r11,-0x40(%rbp)
 100c362:	4d 8b 5c 12 30       	mov    0x30(%r10,%rdx,1),%r11
 100c367:	4c 89 5d c8          	mov    %r11,-0x38(%rbp)
 100c36b:	4d 8b 1c 12          	mov    (%r10,%rdx,1),%r11
 100c36f:	4c 89 5d 98          	mov    %r11,-0x68(%rbp)
 100c373:	4d 8b 5c 12 08       	mov    0x8(%r10,%rdx,1),%r11
 100c378:	4c 89 5d a0          	mov    %r11,-0x60(%rbp)
 100c37c:	4d 8b 5c 12 10       	mov    0x10(%r10,%rdx,1),%r11
 100c381:	4c 89 5d a8          	mov    %r11,-0x58(%rbp)
 100c385:	4d 8b 5c 12 18       	mov    0x18(%r10,%rdx,1),%r11
 100c38a:	4c 89 5d b0          	mov    %r11,-0x50(%rbp)
 100c38e:	4d 8b 5c 12 20       	mov    0x20(%r10,%rdx,1),%r11
 100c393:	4c 89 5d b8          	mov    %r11,-0x48(%rbp)
 100c397:	4d 8b 5c 12 28       	mov    0x28(%r10,%rdx,1),%r11
 100c39c:	4c 89 5d c0          	mov    %r11,-0x40(%rbp)
 100c3a0:	4d 8b 54 12 30       	mov    0x30(%r10,%rdx,1),%r10
 100c3a5:	4c 89 55 c8          	mov    %r10,-0x38(%rbp)
 100c3a9:	66 49 0f 6e c9       	movq   %r9,%xmm1
 100c3ae:	66 49 0f 6e d0       	movq   %r8,%xmm2
 100c3b3:	f2 0f 59 d0          	mulsd  %xmm0,%xmm2
 100c3b7:	66 49 0f 7e d0       	movq   %xmm2,%r8
 100c3bc:	66 49 0f 6e d0       	movq   %r8,%xmm2
 100c3c1:	f2 0f 58 ca          	addsd  %xmm2,%xmm1
 100c3c5:	66 49 0f 7e c8       	movq   %xmm1,%r8
 100c3ca:	4c 89 45 98          	mov    %r8,-0x68(%rbp)
 100c3ce:	c7 85 d0 fa ff ff 00 	movl   $0x0,-0x530(%rbp)
 100c3d5:	00 00 00 
 100c3d8:	4c 8b 01             	mov    (%rcx),%r8
 100c3db:	4c 39 c6             	cmp    %r8,%rsi
 100c3de:	0f 83 aa 06 00 00    	jae    100ca8e <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x297e>
 100c3e4:	48 8b 71 20          	mov    0x20(%rcx),%rsi
 100c3e8:	48 8b 4d 98          	mov    -0x68(%rbp),%rcx
 100c3ec:	48 89 0c 32          	mov    %rcx,(%rdx,%rsi,1)
 100c3f0:	48 8b 4d a0          	mov    -0x60(%rbp),%rcx
 100c3f4:	48 89 4c 32 08       	mov    %rcx,0x8(%rdx,%rsi,1)
 100c3f9:	48 8b 4d a8          	mov    -0x58(%rbp),%rcx
 100c3fd:	48 89 4c 32 10       	mov    %rcx,0x10(%rdx,%rsi,1)
 100c402:	48 8b 4d b0          	mov    -0x50(%rbp),%rcx
 100c406:	48 89 4c 32 18       	mov    %rcx,0x18(%rdx,%rsi,1)
 100c40b:	48 8b 4d b8          	mov    -0x48(%rbp),%rcx
 100c40f:	48 89 4c 32 20       	mov    %rcx,0x20(%rdx,%rsi,1)
 100c414:	48 8b 4d c0          	mov    -0x40(%rbp),%rcx
 100c418:	48 89 4c 32 28       	mov    %rcx,0x28(%rdx,%rsi,1)
 100c41d:	48 8b 4d c8          	mov    -0x38(%rbp),%rcx
 100c421:	48 89 4c 32 30       	mov    %rcx,0x30(%rdx,%rsi,1)
 100c426:	48 8b 4d 90          	mov    -0x70(%rbp),%rcx
 100c42a:	48 83 f8 00          	cmp    $0x0,%rax
 100c42e:	7c 05                	jl     100c435 <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x2325>
 100c430:	48 89 c6             	mov    %rax,%rsi
 100c433:	eb 35                	jmp    100c46a <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x235a>
 100c435:	4c 8b 09             	mov    (%rcx),%r9
 100c438:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
 100c43f:	ff ff 7f 
 100c442:	49 39 d1             	cmp    %rdx,%r9
 100c445:	0f 87 34 06 00 00    	ja     100ca7f <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x296f>
 100c44b:	4c 89 ce             	mov    %r9,%rsi
 100c44e:	48 01 c6             	add    %rax,%rsi
 100c451:	4c 89 ca             	mov    %r9,%rdx
 100c454:	48 31 f2             	xor    %rsi,%rdx
 100c457:	49 89 c0             	mov    %rax,%r8
 100c45a:	49 31 f0             	xor    %rsi,%r8
 100c45d:	4c 21 c2             	and    %r8,%rdx
 100c460:	48 83 fa 00          	cmp    $0x0,%rdx
 100c464:	0f 8c fa 05 00 00    	jl     100ca64 <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x2954>
 100c46a:	48 8b 11             	mov    (%rcx),%rdx
 100c46d:	48 39 d6             	cmp    %rdx,%rsi
 100c470:	0f 83 e7 05 00 00    	jae    100ca5d <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x294d>
 100c476:	48 8b 51 20          	mov    0x20(%rcx),%rdx
 100c47a:	48 6b f6 38          	imul   $0x38,%rsi,%rsi
 100c47e:	4c 8b 04 32          	mov    (%rdx,%rsi,1),%r8
 100c482:	4c 89 45 98          	mov    %r8,-0x68(%rbp)
 100c486:	4c 8b 44 32 08       	mov    0x8(%rdx,%rsi,1),%r8
 100c48b:	4c 89 45 a0          	mov    %r8,-0x60(%rbp)
 100c48f:	4c 8b 44 32 10       	mov    0x10(%rdx,%rsi,1),%r8
 100c494:	4c 89 45 a8          	mov    %r8,-0x58(%rbp)
 100c498:	4c 8b 44 32 18       	mov    0x18(%rdx,%rsi,1),%r8
 100c49d:	4c 89 45 b0          	mov    %r8,-0x50(%rbp)
 100c4a1:	4c 8b 44 32 20       	mov    0x20(%rdx,%rsi,1),%r8
 100c4a6:	4c 89 45 b8          	mov    %r8,-0x48(%rbp)
 100c4aa:	4c 8b 44 32 28       	mov    0x28(%rdx,%rsi,1),%r8
 100c4af:	4c 89 45 c0          	mov    %r8,-0x40(%rbp)
 100c4b3:	48 8b 54 32 30       	mov    0x30(%rdx,%rsi,1),%rdx
 100c4b8:	48 89 55 c8          	mov    %rdx,-0x38(%rbp)
 100c4bc:	4c 8b 4d a0          	mov    -0x60(%rbp),%r9
 100c4c0:	48 83 f8 00          	cmp    $0x0,%rax
 100c4c4:	7c 05                	jl     100c4cb <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x23bb>
 100c4c6:	48 89 c6             	mov    %rax,%rsi
 100c4c9:	eb 35                	jmp    100c500 <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x23f0>
 100c4cb:	4c 8b 11             	mov    (%rcx),%r10
 100c4ce:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
 100c4d5:	ff ff 7f 
 100c4d8:	49 39 d2             	cmp    %rdx,%r10
 100c4db:	0f 87 6d 05 00 00    	ja     100ca4e <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x293e>
 100c4e1:	4c 89 d6             	mov    %r10,%rsi
 100c4e4:	48 01 c6             	add    %rax,%rsi
 100c4e7:	4c 89 d2             	mov    %r10,%rdx
 100c4ea:	48 31 f2             	xor    %rsi,%rdx
 100c4ed:	49 89 c0             	mov    %rax,%r8
 100c4f0:	49 31 f0             	xor    %rsi,%r8
 100c4f3:	4c 21 c2             	and    %r8,%rdx
 100c4f6:	48 83 fa 00          	cmp    $0x0,%rdx
 100c4fa:	0f 8c 33 05 00 00    	jl     100ca33 <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x2923>
 100c500:	48 8b 11             	mov    (%rcx),%rdx
 100c503:	48 39 d6             	cmp    %rdx,%rsi
 100c506:	0f 83 20 05 00 00    	jae    100ca2c <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x291c>
 100c50c:	48 8b 51 20          	mov    0x20(%rcx),%rdx
 100c510:	48 6b f6 38          	imul   $0x38,%rsi,%rsi
 100c514:	4c 8b 04 32          	mov    (%rdx,%rsi,1),%r8
 100c518:	4c 89 45 98          	mov    %r8,-0x68(%rbp)
 100c51c:	4c 8b 44 32 08       	mov    0x8(%rdx,%rsi,1),%r8
 100c521:	4c 89 45 a0          	mov    %r8,-0x60(%rbp)
 100c525:	4c 8b 44 32 10       	mov    0x10(%rdx,%rsi,1),%r8
 100c52a:	4c 89 45 a8          	mov    %r8,-0x58(%rbp)
 100c52e:	4c 8b 44 32 18       	mov    0x18(%rdx,%rsi,1),%r8
 100c533:	4c 89 45 b0          	mov    %r8,-0x50(%rbp)
 100c537:	4c 8b 44 32 20       	mov    0x20(%rdx,%rsi,1),%r8
 100c53c:	4c 89 45 b8          	mov    %r8,-0x48(%rbp)
 100c540:	4c 8b 44 32 28       	mov    0x28(%rdx,%rsi,1),%r8
 100c545:	4c 89 45 c0          	mov    %r8,-0x40(%rbp)
 100c549:	48 8b 54 32 30       	mov    0x30(%rdx,%rsi,1),%rdx
 100c54e:	48 89 55 c8          	mov    %rdx,-0x38(%rbp)
 100c552:	4c 8b 45 b8          	mov    -0x48(%rbp),%r8
 100c556:	48 83 f8 00          	cmp    $0x0,%rax
 100c55a:	7c 05                	jl     100c561 <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x2451>
 100c55c:	48 89 c6             	mov    %rax,%rsi
 100c55f:	eb 35                	jmp    100c596 <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x2486>
 100c561:	4c 8b 11             	mov    (%rcx),%r10
 100c564:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
 100c56b:	ff ff 7f 
 100c56e:	49 39 d2             	cmp    %rdx,%r10
 100c571:	0f 87 a6 04 00 00    	ja     100ca1d <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x290d>
 100c577:	4c 89 d6             	mov    %r10,%rsi
 100c57a:	48 01 c6             	add    %rax,%rsi
 100c57d:	4c 89 d2             	mov    %r10,%rdx
 100c580:	48 31 f2             	xor    %rsi,%rdx
 100c583:	49 89 c3             	mov    %rax,%r11
 100c586:	49 31 f3             	xor    %rsi,%r11
 100c589:	4c 21 da             	and    %r11,%rdx
 100c58c:	48 83 fa 00          	cmp    $0x0,%rdx
 100c590:	0f 8c 6c 04 00 00    	jl     100ca02 <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x28f2>
 100c596:	48 8b 11             	mov    (%rcx),%rdx
 100c599:	48 39 d6             	cmp    %rdx,%rsi
 100c59c:	0f 83 59 04 00 00    	jae    100c9fb <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x28eb>
 100c5a2:	4c 8b 51 20          	mov    0x20(%rcx),%r10
 100c5a6:	48 6b d6 38          	imul   $0x38,%rsi,%rdx
 100c5aa:	4d 8b 1c 12          	mov    (%r10,%rdx,1),%r11
 100c5ae:	4c 89 5d 98          	mov    %r11,-0x68(%rbp)
 100c5b2:	4d 8b 5c 12 08       	mov    0x8(%r10,%rdx,1),%r11
 100c5b7:	4c 89 5d a0          	mov    %r11,-0x60(%rbp)
 100c5bb:	4d 8b 5c 12 10       	mov    0x10(%r10,%rdx,1),%r11
 100c5c0:	4c 89 5d a8          	mov    %r11,-0x58(%rbp)
 100c5c4:	4d 8b 5c 12 18       	mov    0x18(%r10,%rdx,1),%r11
 100c5c9:	4c 89 5d b0          	mov    %r11,-0x50(%rbp)
 100c5cd:	4d 8b 5c 12 20       	mov    0x20(%r10,%rdx,1),%r11
 100c5d2:	4c 89 5d b8          	mov    %r11,-0x48(%rbp)
 100c5d6:	4d 8b 5c 12 28       	mov    0x28(%r10,%rdx,1),%r11
 100c5db:	4c 89 5d c0          	mov    %r11,-0x40(%rbp)
 100c5df:	4d 8b 5c 12 30       	mov    0x30(%r10,%rdx,1),%r11
 100c5e4:	4c 89 5d c8          	mov    %r11,-0x38(%rbp)
 100c5e8:	4d 8b 1c 12          	mov    (%r10,%rdx,1),%r11
 100c5ec:	4c 89 5d 98          	mov    %r11,-0x68(%rbp)
 100c5f0:	4d 8b 5c 12 08       	mov    0x8(%r10,%rdx,1),%r11
 100c5f5:	4c 89 5d a0          	mov    %r11,-0x60(%rbp)
 100c5f9:	4d 8b 5c 12 10       	mov    0x10(%r10,%rdx,1),%r11
 100c5fe:	4c 89 5d a8          	mov    %r11,-0x58(%rbp)
 100c602:	4d 8b 5c 12 18       	mov    0x18(%r10,%rdx,1),%r11
 100c607:	4c 89 5d b0          	mov    %r11,-0x50(%rbp)
 100c60b:	4d 8b 5c 12 20       	mov    0x20(%r10,%rdx,1),%r11
 100c610:	4c 89 5d b8          	mov    %r11,-0x48(%rbp)
 100c614:	4d 8b 5c 12 28       	mov    0x28(%r10,%rdx,1),%r11
 100c619:	4c 89 5d c0          	mov    %r11,-0x40(%rbp)
 100c61d:	4d 8b 54 12 30       	mov    0x30(%r10,%rdx,1),%r10
 100c622:	4c 89 55 c8          	mov    %r10,-0x38(%rbp)
 100c626:	66 49 0f 6e c9       	movq   %r9,%xmm1
 100c62b:	66 49 0f 6e d0       	movq   %r8,%xmm2
 100c630:	f2 0f 59 d0          	mulsd  %xmm0,%xmm2
 100c634:	66 49 0f 7e d0       	movq   %xmm2,%r8
 100c639:	66 49 0f 6e d0       	movq   %r8,%xmm2
 100c63e:	f2 0f 58 ca          	addsd  %xmm2,%xmm1
 100c642:	66 49 0f 7e c8       	movq   %xmm1,%r8
 100c647:	4c 89 45 a0          	mov    %r8,-0x60(%rbp)
 100c64b:	c7 85 d0 fa ff ff 00 	movl   $0x0,-0x530(%rbp)
 100c652:	00 00 00 
 100c655:	4c 8b 01             	mov    (%rcx),%r8
 100c658:	4c 39 c6             	cmp    %r8,%rsi
 100c65b:	0f 83 90 03 00 00    	jae    100c9f1 <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x28e1>
 100c661:	48 8b 71 20          	mov    0x20(%rcx),%rsi
 100c665:	48 8b 4d 98          	mov    -0x68(%rbp),%rcx
 100c669:	48 89 0c 32          	mov    %rcx,(%rdx,%rsi,1)
 100c66d:	48 8b 4d a0          	mov    -0x60(%rbp),%rcx
 100c671:	48 89 4c 32 08       	mov    %rcx,0x8(%rdx,%rsi,1)
 100c676:	48 8b 4d a8          	mov    -0x58(%rbp),%rcx
 100c67a:	48 89 4c 32 10       	mov    %rcx,0x10(%rdx,%rsi,1)
 100c67f:	48 8b 4d b0          	mov    -0x50(%rbp),%rcx
 100c683:	48 89 4c 32 18       	mov    %rcx,0x18(%rdx,%rsi,1)
 100c688:	48 8b 4d b8          	mov    -0x48(%rbp),%rcx
 100c68c:	48 89 4c 32 20       	mov    %rcx,0x20(%rdx,%rsi,1)
 100c691:	48 8b 4d c0          	mov    -0x40(%rbp),%rcx
 100c695:	48 89 4c 32 28       	mov    %rcx,0x28(%rdx,%rsi,1)
 100c69a:	48 8b 4d c8          	mov    -0x38(%rbp),%rcx
 100c69e:	48 89 4c 32 30       	mov    %rcx,0x30(%rdx,%rsi,1)
 100c6a3:	48 8b 4d 90          	mov    -0x70(%rbp),%rcx
 100c6a7:	48 83 f8 00          	cmp    $0x0,%rax
 100c6ab:	7c 05                	jl     100c6b2 <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x25a2>
 100c6ad:	48 89 c6             	mov    %rax,%rsi
 100c6b0:	eb 35                	jmp    100c6e7 <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x25d7>
 100c6b2:	4c 8b 09             	mov    (%rcx),%r9
 100c6b5:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
 100c6bc:	ff ff 7f 
 100c6bf:	49 39 d1             	cmp    %rdx,%r9
 100c6c2:	0f 87 1a 03 00 00    	ja     100c9e2 <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x28d2>
 100c6c8:	4c 89 ce             	mov    %r9,%rsi
 100c6cb:	48 01 c6             	add    %rax,%rsi
 100c6ce:	4c 89 ca             	mov    %r9,%rdx
 100c6d1:	48 31 f2             	xor    %rsi,%rdx
 100c6d4:	49 89 c0             	mov    %rax,%r8
 100c6d7:	49 31 f0             	xor    %rsi,%r8
 100c6da:	4c 21 c2             	and    %r8,%rdx
 100c6dd:	48 83 fa 00          	cmp    $0x0,%rdx
 100c6e1:	0f 8c e0 02 00 00    	jl     100c9c7 <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x28b7>
 100c6e7:	48 8b 11             	mov    (%rcx),%rdx
 100c6ea:	48 39 d6             	cmp    %rdx,%rsi
 100c6ed:	0f 83 cd 02 00 00    	jae    100c9c0 <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x28b0>
 100c6f3:	48 8b 51 20          	mov    0x20(%rcx),%rdx
 100c6f7:	48 6b f6 38          	imul   $0x38,%rsi,%rsi
 100c6fb:	4c 8b 04 32          	mov    (%rdx,%rsi,1),%r8
 100c6ff:	4c 89 45 98          	mov    %r8,-0x68(%rbp)
 100c703:	4c 8b 44 32 08       	mov    0x8(%rdx,%rsi,1),%r8
 100c708:	4c 89 45 a0          	mov    %r8,-0x60(%rbp)
 100c70c:	4c 8b 44 32 10       	mov    0x10(%rdx,%rsi,1),%r8
 100c711:	4c 89 45 a8          	mov    %r8,-0x58(%rbp)
 100c715:	4c 8b 44 32 18       	mov    0x18(%rdx,%rsi,1),%r8
 100c71a:	4c 89 45 b0          	mov    %r8,-0x50(%rbp)
 100c71e:	4c 8b 44 32 20       	mov    0x20(%rdx,%rsi,1),%r8
 100c723:	4c 89 45 b8          	mov    %r8,-0x48(%rbp)
 100c727:	4c 8b 44 32 28       	mov    0x28(%rdx,%rsi,1),%r8
 100c72c:	4c 89 45 c0          	mov    %r8,-0x40(%rbp)
 100c730:	48 8b 54 32 30       	mov    0x30(%rdx,%rsi,1),%rdx
 100c735:	48 89 55 c8          	mov    %rdx,-0x38(%rbp)
 100c739:	4c 8b 4d a8          	mov    -0x58(%rbp),%r9
 100c73d:	48 83 f8 00          	cmp    $0x0,%rax
 100c741:	7c 05                	jl     100c748 <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x2638>
 100c743:	48 89 c6             	mov    %rax,%rsi
 100c746:	eb 35                	jmp    100c77d <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x266d>
 100c748:	4c 8b 11             	mov    (%rcx),%r10
 100c74b:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
 100c752:	ff ff 7f 
 100c755:	49 39 d2             	cmp    %rdx,%r10
 100c758:	0f 87 53 02 00 00    	ja     100c9b1 <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x28a1>
 100c75e:	4c 89 d6             	mov    %r10,%rsi
 100c761:	48 01 c6             	add    %rax,%rsi
 100c764:	4c 89 d2             	mov    %r10,%rdx
 100c767:	48 31 f2             	xor    %rsi,%rdx
 100c76a:	49 89 c0             	mov    %rax,%r8
 100c76d:	49 31 f0             	xor    %rsi,%r8
 100c770:	4c 21 c2             	and    %r8,%rdx
 100c773:	48 83 fa 00          	cmp    $0x0,%rdx
 100c777:	0f 8c 19 02 00 00    	jl     100c996 <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x2886>
 100c77d:	48 8b 11             	mov    (%rcx),%rdx
 100c780:	48 39 d6             	cmp    %rdx,%rsi
 100c783:	0f 83 06 02 00 00    	jae    100c98f <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x287f>
 100c789:	48 8b 51 20          	mov    0x20(%rcx),%rdx
 100c78d:	48 6b f6 38          	imul   $0x38,%rsi,%rsi
 100c791:	4c 8b 04 32          	mov    (%rdx,%rsi,1),%r8
 100c795:	4c 89 45 98          	mov    %r8,-0x68(%rbp)
 100c799:	4c 8b 44 32 08       	mov    0x8(%rdx,%rsi,1),%r8
 100c79e:	4c 89 45 a0          	mov    %r8,-0x60(%rbp)
 100c7a2:	4c 8b 44 32 10       	mov    0x10(%rdx,%rsi,1),%r8
 100c7a7:	4c 89 45 a8          	mov    %r8,-0x58(%rbp)
 100c7ab:	4c 8b 44 32 18       	mov    0x18(%rdx,%rsi,1),%r8
 100c7b0:	4c 89 45 b0          	mov    %r8,-0x50(%rbp)
 100c7b4:	4c 8b 44 32 20       	mov    0x20(%rdx,%rsi,1),%r8
 100c7b9:	4c 89 45 b8          	mov    %r8,-0x48(%rbp)
 100c7bd:	4c 8b 44 32 28       	mov    0x28(%rdx,%rsi,1),%r8
 100c7c2:	4c 89 45 c0          	mov    %r8,-0x40(%rbp)
 100c7c6:	48 8b 54 32 30       	mov    0x30(%rdx,%rsi,1),%rdx
 100c7cb:	48 89 55 c8          	mov    %rdx,-0x38(%rbp)
 100c7cf:	4c 8b 45 c0          	mov    -0x40(%rbp),%r8
 100c7d3:	48 83 f8 00          	cmp    $0x0,%rax
 100c7d7:	7c 05                	jl     100c7de <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x26ce>
 100c7d9:	48 89 c6             	mov    %rax,%rsi
 100c7dc:	eb 35                	jmp    100c813 <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x2703>
 100c7de:	4c 8b 11             	mov    (%rcx),%r10
 100c7e1:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
 100c7e8:	ff ff 7f 
 100c7eb:	49 39 d2             	cmp    %rdx,%r10
 100c7ee:	0f 87 8c 01 00 00    	ja     100c980 <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x2870>
 100c7f4:	4c 89 d6             	mov    %r10,%rsi
 100c7f7:	48 01 c6             	add    %rax,%rsi
 100c7fa:	4c 89 d2             	mov    %r10,%rdx
 100c7fd:	48 31 f2             	xor    %rsi,%rdx
 100c800:	49 89 c3             	mov    %rax,%r11
 100c803:	49 31 f3             	xor    %rsi,%r11
 100c806:	4c 21 da             	and    %r11,%rdx
 100c809:	48 83 fa 00          	cmp    $0x0,%rdx
 100c80d:	0f 8c 52 01 00 00    	jl     100c965 <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x2855>
 100c813:	48 8b 11             	mov    (%rcx),%rdx
 100c816:	48 39 d6             	cmp    %rdx,%rsi
 100c819:	0f 83 3f 01 00 00    	jae    100c95e <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x284e>
 100c81f:	4c 8b 51 20          	mov    0x20(%rcx),%r10
 100c823:	48 6b d6 38          	imul   $0x38,%rsi,%rdx
 100c827:	4d 8b 1c 12          	mov    (%r10,%rdx,1),%r11
 100c82b:	4c 89 5d 98          	mov    %r11,-0x68(%rbp)
 100c82f:	4d 8b 5c 12 08       	mov    0x8(%r10,%rdx,1),%r11
 100c834:	4c 89 5d a0          	mov    %r11,-0x60(%rbp)
 100c838:	4d 8b 5c 12 10       	mov    0x10(%r10,%rdx,1),%r11
 100c83d:	4c 89 5d a8          	mov    %r11,-0x58(%rbp)
 100c841:	4d 8b 5c 12 18       	mov    0x18(%r10,%rdx,1),%r11
 100c846:	4c 89 5d b0          	mov    %r11,-0x50(%rbp)
 100c84a:	4d 8b 5c 12 20       	mov    0x20(%r10,%rdx,1),%r11
 100c84f:	4c 89 5d b8          	mov    %r11,-0x48(%rbp)
 100c853:	4d 8b 5c 12 28       	mov    0x28(%r10,%rdx,1),%r11
 100c858:	4c 89 5d c0          	mov    %r11,-0x40(%rbp)
 100c85c:	4d 8b 5c 12 30       	mov    0x30(%r10,%rdx,1),%r11
 100c861:	4c 89 5d c8          	mov    %r11,-0x38(%rbp)
 100c865:	4d 8b 1c 12          	mov    (%r10,%rdx,1),%r11
 100c869:	4c 89 5d 98          	mov    %r11,-0x68(%rbp)
 100c86d:	4d 8b 5c 12 08       	mov    0x8(%r10,%rdx,1),%r11
 100c872:	4c 89 5d a0          	mov    %r11,-0x60(%rbp)
 100c876:	4d 8b 5c 12 10       	mov    0x10(%r10,%rdx,1),%r11
 100c87b:	4c 89 5d a8          	mov    %r11,-0x58(%rbp)
 100c87f:	4d 8b 5c 12 18       	mov    0x18(%r10,%rdx,1),%r11
 100c884:	4c 89 5d b0          	mov    %r11,-0x50(%rbp)
 100c888:	4d 8b 5c 12 20       	mov    0x20(%r10,%rdx,1),%r11
 100c88d:	4c 89 5d b8          	mov    %r11,-0x48(%rbp)
 100c891:	4d 8b 5c 12 28       	mov    0x28(%r10,%rdx,1),%r11
 100c896:	4c 89 5d c0          	mov    %r11,-0x40(%rbp)
 100c89a:	4d 8b 54 12 30       	mov    0x30(%r10,%rdx,1),%r10
 100c89f:	4c 89 55 c8          	mov    %r10,-0x38(%rbp)
 100c8a3:	66 49 0f 6e c9       	movq   %r9,%xmm1
 100c8a8:	66 49 0f 6e d0       	movq   %r8,%xmm2
 100c8ad:	f2 0f 59 d0          	mulsd  %xmm0,%xmm2
 100c8b1:	66 49 0f 7e d0       	movq   %xmm2,%r8
 100c8b6:	66 49 0f 6e d0       	movq   %r8,%xmm2
 100c8bb:	f2 0f 58 ca          	addsd  %xmm2,%xmm1
 100c8bf:	66 49 0f 7e c8       	movq   %xmm1,%r8
 100c8c4:	4c 89 45 a8          	mov    %r8,-0x58(%rbp)
 100c8c8:	c7 85 d0 fa ff ff 00 	movl   $0x0,-0x530(%rbp)
 100c8cf:	00 00 00 
 100c8d2:	4c 8b 01             	mov    (%rcx),%r8
 100c8d5:	4c 39 c6             	cmp    %r8,%rsi
 100c8d8:	73 7a                	jae    100c954 <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x2844>
 100c8da:	48 8b 71 20          	mov    0x20(%rcx),%rsi
 100c8de:	48 8b 4d 98          	mov    -0x68(%rbp),%rcx
 100c8e2:	48 89 0c 32          	mov    %rcx,(%rdx,%rsi,1)
 100c8e6:	48 8b 4d a0          	mov    -0x60(%rbp),%rcx
 100c8ea:	48 89 4c 32 08       	mov    %rcx,0x8(%rdx,%rsi,1)
 100c8ef:	48 8b 4d a8          	mov    -0x58(%rbp),%rcx
 100c8f3:	48 89 4c 32 10       	mov    %rcx,0x10(%rdx,%rsi,1)
 100c8f8:	48 8b 4d b0          	mov    -0x50(%rbp),%rcx
 100c8fc:	48 89 4c 32 18       	mov    %rcx,0x18(%rdx,%rsi,1)
 100c901:	48 8b 4d b8          	mov    -0x48(%rbp),%rcx
 100c905:	48 89 4c 32 20       	mov    %rcx,0x20(%rdx,%rsi,1)
 100c90a:	48 8b 4d c0          	mov    -0x40(%rbp),%rcx
 100c90e:	48 89 4c 32 28       	mov    %rcx,0x28(%rdx,%rsi,1)
 100c913:	48 8b 4d c8          	mov    -0x38(%rbp),%rcx
 100c917:	48 89 4c 32 30       	mov    %rcx,0x30(%rdx,%rsi,1)
 100c91c:	48 b9 fe ff ff ff ff 	movabs $0x7ffffffffffffffe,%rcx
 100c923:	ff ff 7f 
 100c926:	48 39 c8             	cmp    %rcx,%rax
 100c929:	7f 09                	jg     100c934 <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x2824>
 100c92b:	48 83 c0 01          	add    $0x1,%rax
 100c92f:	e9 6c f8 ff ff       	jmp    100c1a0 <myl_f_e40dfff1a71eb7baf65ea49495977ddd33d81611a9c59c5573fc42205baa7e85+0x2090>
 100c934:	48 89 c1             	mov    %rax,%rcx
 100c937:	41 b8 40 00 00 00    	mov    $0x40,%r8d
 100c93d:	48 89 c8             	mov    %rcx,%rax
 100c940:	b9 01 00 00 00       	mov    $0x1,%ecx
 100c945:	48 89 c2             	mov    %rax,%rdx
 100c948:	be 00 00 00 00       	mov    $0x0,%esi
 100c94d:	e8 4e 24 00 00       	call   100eda0 <myl_qbe_fail_overflow_op>
 100c952:	0f 0b                	ud2
 100c954:	4c 89 c2             	mov    %r8,%rdx
 100c957:	e8 d4 23 00 00       	call   100ed30 <myl_qbe_fail_normalized_index_bounds>
 100c95c:	0f 0b                	ud2
 100c95e:	e8 cd 23 00 00       	call   100ed30 <myl_qbe_fail_normalized_index_bounds>
 100c963:	0f 0b                	ud2
 100c965:	48 89 c1             	mov    %rax,%rcx
 100c968:	4c 89 d6             	mov    %r10,%rsi
 100c96b:	41 b8 40 00 00 00    	mov    $0x40,%r8d
 100c971:	48 89 f2             	mov    %rsi,%rdx
 100c974:	be 00 00 00 00       	mov    $0x0,%esi
 100c979:	e8 22 24 00 00       	call   100eda0 <myl_qbe_fail_overflow_op>
 100c97e:	0f 0b                	ud2
 100c980:	4c 89 d6             	mov    %r10,%rsi
 100c983:	ba 40 01 00 00       	mov    $0x140,%edx
 100c988:	e8 53 25 00 00       	call   100eee0 <myl_qbe_fail_cast>
 100c98d:	0f 0b                	ud2
 100c98f:	e8 9c 23 00 00       	call   100ed30 <myl_qbe_fail_normalized_index_bounds>
 100c994:	0f 0b                	ud2
 100c996:	48 89 c1             	mov    %rax,%rcx
 100c999:	4c 89 d6             	mov    %r10,%rsi
 100c99c:	41 b8 40 00 00 00    	mov    $0x40,%r8d
 100c9a2:	48 89 f2             	mov    %rsi,%rdx
 100c9a5:	be 00 00 00 00       	mov    $0x0,%esi
 100c9aa:	e8 f1 23 00 00       	call   100eda0 <myl_qbe_fail_overflow_op>
 100c9af:	0f 0b                	ud2
 100c9b1:	4c 89 d6             	mov    %r10,%rsi
 100c9b4:	ba 40 01 00 00       	mov    $0x140,%edx
 100c9b9:	e8 22 25 00 00       	call   100eee0 <myl_qbe_fail_cast>
 100c9be:	0f 0b                	ud2
 100c9c0:	e8 6b 23 00 00       	call   100ed30 <myl_qbe_fail_normalized_index_bounds>
 100c9c5:	0f 0b                	ud2
 100c9c7:	48 89 c1             	mov    %rax,%rcx
 100c9ca:	4c 89 ce             	mov    %r9,%rsi
 100c9cd:	41 b8 40 00 00 00    	mov    $0x40,%r8d
 100c9d3:	48 89 f2             	mov    %rsi,%rdx
 100c9d6:	be 00 00 00 00       	mov    $0x0,%esi
 100c9db:	e8 c0 23 00 00       	call   100eda0 <myl_qbe_fail_overflow_op>
 100c9e0:	0f 0b                	ud2
 100c9e2:	4c 89 ce             	mov    %r9,%rsi
 100c9e5:	ba 40 01 00 00       	mov    $0x140,%edx
 100c9ea:	e8 f1 24 00 00       	call   100eee0 <myl_qbe_fail_cast>
 100c9ef:	0f 0b                	ud2
 100c9f1:	4c 89 c2             	mov    %r8,%rdx
 100c9f4:	e8 37 23 00 00       	call   100ed30 <myl_qbe_fail_normalized_index_bounds>
 100c9f9:	0f 0b                	ud2
 100c9fb:	e8 30 23 00 00       	call   100ed30 <myl_qbe_fail_normalized_index_bounds>
 100ca00:	0f 0b                	ud2
 100ca02:	48 89 c1             	mov    %rax,%rcx
 100ca05:	4c 89 d6             	mov    %r10,%rsi
 100ca08:	41 b8 40 00 00 00    	mov    $0x40,%r8d
 100ca0e:	48 89 f2             	mov    %rsi,%rdx
 100ca11:	be 00 00 00 00       	mov    $0x0,%esi
 100ca16:	e8 85 23 00 00       	call   100eda0 <myl_qbe_fail_overflow_op>
 100ca1b:	0f 0b                	ud2
 100ca1d:	4c 89 d6             	mov    %r10,%rsi
 100ca20:	ba 40 01 00 00       	mov    $0x140,%edx
 100ca25:	e8 b6 24 00 00       	call   100eee0 <myl_qbe_fail_cast>
 100ca2a:	0f 0b                	ud2
 100ca2c:	e8 ff 22 00 00       	call   100ed30 <myl_qbe_fail_normalized_index_bounds>
 100ca31:	0f 0b                	ud2
 100ca33:	48 89 c1             	mov    %rax,%rcx
 100ca36:	4c 89 d6             	mov    %r10,%rsi
 100ca39:	41 b8 40 00 00 00    	mov    $0x40,%r8d
 100ca3f:	48 89 f2             	mov    %rsi,%rdx
 100ca42:	be 00 00 00 00       	mov    $0x0,%esi
 100ca47:	e8 54 23 00 00       	call   100eda0 <myl_qbe_fail_overflow_op>
 100ca4c:	0f 0b                	ud2
 100ca4e:	4c 89 d6             	mov    %r10,%rsi
 100ca51:	ba 40 01 00 00       	mov    $0x140,%edx
 100ca56:	e8 85 24 00 00       	call   100eee0 <myl_qbe_fail_cast>
 100ca5b:	0f 0b                	ud2
 100ca5d:	e8 ce 22 00 00       	call   100ed30 <myl_qbe_fail_normalized_index_bounds>
 100ca62:	0f 0b                	ud2
 100ca64:	48 89 c1             	mov    %rax,%rcx
 100ca67:	4c 89 ce             	mov    %r9,%rsi
 100ca6a:	41 b8 40 00 00 00    	mov    $0x40,%r8d
 100ca70:	48 89 f2             	mov    %rsi,%rdx
 100ca73:	be 00 00 00 00       	mov    $0x0,%esi
 100ca78:	e8 23 23 00 00       	call   100eda0 <myl_qbe_fail_overflow_op>
 100ca7d:	0f 0b                	ud2
 100ca7f:	4c 89 ce             	mov    %r9,%rsi
 100ca82:	ba 40 01 00 00       	mov    $0x140,%edx
 100ca87:	e8 54 24 00 00       	call   100eee0 <myl_qbe_fail_cast>
 100ca8c:	0f 0b                	ud2
 100ca8e:	4c 89 c2             	mov    %r8,%rdx
 100ca91:	e8 9a 22 00 00       	call   100ed30 <myl_qbe_fail_normalized_index_bounds>
 100ca96:	0f 0b                	ud2
 100ca98:	e8 93 22 00 00       	call   100ed30 <myl_qbe_fail_normalized_index_bounds>
 100ca9d:	0f 0b                	ud2
 100ca9f:	48 89 c1             	mov    %rax,%rcx
 100caa2:	4c 89 d6             	mov    %r10,%rsi
 100caa5:	41 b8 40 00 00 00    	mov    $0x40,%r8d
 100caab:	48 89 f2             	mov    %rsi,%rdx
 100caae:	be 00 00 00 00       	mov    $0x0,%esi
 100cab3:	e8 e8 22 00 00       	call   100eda0 <myl_qbe_fail_overflow_op>
 100cab8:	0f 0b                	ud2
 100caba:	4c 89 d6             	mov    %r10,%rsi
 100cabd:	ba 40 01 00 00       	mov    $0x140,%edx
 100cac2:	e8 19 24 00 00       	call   100eee0 <myl_qbe_fail_cast>
 100cac7:	0f 0b                	ud2
 100cac9:	e8 62 22 00 00       	call   100ed30 <myl_qbe_fail_normalized_index_bounds>
 100cace:	0f 0b                	ud2
 100cad0:	48 89 c1             	mov    %rax,%rcx
 100cad3:	4c 89 d6             	mov    %r10,%rsi
 100cad6:	41 b8 40 00 00 00    	mov    $0x40,%r8d
 100cadc:	48 89 f2             	mov    %rsi,%rdx
 100cadf:	be 00 00 00 00       	mov    $0x0,%esi
 100cae4:	e8 b7 22 00 00       	call   100eda0 <myl_qbe_fail_overflow_op>
 100cae9:	0f 0b                	ud2
 100caeb:	4c 89 d6             	mov    %r10,%rsi
 100caee:	ba 40 01 00 00       	mov    $0x140,%edx
 100caf3:	e8 e8 23 00 00       	call   100eee0 <myl_qbe_fail_cast>
 100caf8:	0f 0b                	ud2
 100cafa:	e8 31 22 00 00       	call   100ed30 <myl_qbe_fail_normalized_index_bounds>
 100caff:	0f 0b                	ud2
 100cb01:	48 89 c1             	mov    %rax,%rcx
 100cb04:	4c 89 ce             	mov    %r9,%rsi
 100cb07:	41 b8 40 00 00 00    	mov    $0x40,%r8d
 100cb0d:	48 89 f2             	mov    %rsi,%rdx
 100cb10:	be 00 00 00 00       	mov    $0x0,%esi
 100cb15:	e8 86 22 00 00       	call   100eda0 <myl_qbe_fail_overflow_op>
 100cb1a:	0f 0b                	ud2
 100cb1c:	4c 89 ce             	mov    %r9,%rsi
 100cb1f:	ba 40 01 00 00       	mov    $0x140,%edx
 100cb24:	e8 b7 23 00 00       	call   100eee0 <myl_qbe_fail_cast>
 100cb29:	0f 0b                	ud2
 100cb2b:	48 8d b5 18 fa ff ff 	lea    -0x5e8(%rbp),%rsi
 100cb32:	48 89 fb             	mov    %rdi,%rbx
 100cb35:	e8 d6 1b 00 00       	call   100e710 <myl_qbe_rc_frame_cleanup>
 100cb3a:	48 89 df             	mov    %rbx,%rdi
 100cb3d:	48 8d b5 18 fa ff ff 	lea    -0x5e8(%rbp),%rsi
 100cb44:	e8 37 1a 00 00       	call   100e580 <myl_qbe_rc_frame_leave>
 100cb49:	b8 00 00 00 00       	mov    $0x0,%eax
 100cb4e:	41 5f                	pop    %r15
 100cb50:	41 5e                	pop    %r14
 100cb52:	41 5d                	pop    %r13
 100cb54:	41 5c                	pop    %r12
 100cb56:	5b                   	pop    %rbx
 100cb57:	c9                   	leave
 100cb58:	c3                   	ret
 100cb59:	ba 40 01 00 00       	mov    $0x140,%edx
 100cb5e:	e8 7d 23 00 00       	call   100eee0 <myl_qbe_fail_cast>
 100cb63:	0f 0b                	ud2

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
