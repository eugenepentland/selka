
/home/epentland/ai/canopy/mylang-worktrees/d9-rc-mut-argument-astra/.tmp-mut-argument/loan-measure/qbe-after-production:     file format elf64-x86-64


Disassembly of section .text:

000000000110b820 <myl_rc_native_unloan>:
 110b820:	55                   	push   %rbp
 110b821:	48 89 e5             	mov    %rsp,%rbp
 110b824:	41 57                	push   %r15
 110b826:	41 56                	push   %r14
 110b828:	41 54                	push   %r12
 110b82a:	53                   	push   %rbx
 110b82b:	49 89 d6             	mov    %rdx,%r14
 110b82e:	49 89 f4             	mov    %rsi,%r12
 110b831:	48 89 fb             	mov    %rdi,%rbx
 110b834:	e8 87 84 ff ff       	call   1103cc0 <myl_rc_descriptor_find>
 110b839:	48 85 c0             	test   %rax,%rax
 110b83c:	0f 84 9a 00 00 00    	je     110b8dc <myl_rc_native_unloan+0xbc>
 110b842:	49 89 c7             	mov    %rax,%r15
 110b845:	83 78 7c 00          	cmpl   $0x0,0x7c(%rax)
 110b849:	74 7a                	je     110b8c5 <myl_rc_native_unloan+0xa5>
 110b84b:	49 83 3c 24 00       	cmpq   $0x0,(%r12)
 110b850:	74 73                	je     110b8c5 <myl_rc_native_unloan+0xa5>
 110b852:	48 85 db             	test   %rbx,%rbx
 110b855:	0f 84 81 00 00 00    	je     110b8dc <myl_rc_native_unloan+0xbc>
 110b85b:	48 8b 83 08 16 00 00 	mov    0x1608(%rbx),%rax
 110b862:	48 85 c0             	test   %rax,%rax
 110b865:	74 75                	je     110b8dc <myl_rc_native_unloan+0xbc>
 110b867:	4d 85 f6             	test   %r14,%r14
 110b86a:	74 70                	je     110b8dc <myl_rc_native_unloan+0xbc>
 110b86c:	48 83 78 58 00       	cmpq   $0x0,0x58(%rax)
 110b871:	75 69                	jne    110b8dc <myl_rc_native_unloan+0xbc>
 110b873:	41 83 7f 78 00       	cmpl   $0x0,0x78(%r15)
 110b878:	74 2b                	je     110b8a5 <myl_rc_native_unloan+0x85>
 110b87a:	45 31 e4             	xor    %r12d,%r12d
 110b87d:	0f 1f 00             	nopl   (%rax)
 110b880:	4b 8b 44 e7 38       	mov    0x38(%r15,%r12,8),%rax
 110b885:	49 8b 34 06          	mov    (%r14,%rax,1),%rsi
 110b889:	49 c7 04 06 00 00 00 	movq   $0x0,(%r14,%rax,1)
 110b890:	00 
 110b891:	48 89 df             	mov    %rbx,%rdi
 110b894:	e8 87 7d ff ff       	call   1103620 <myl_rc_hold_edge_release>
 110b899:	49 ff c4             	inc    %r12
 110b89c:	41 8b 47 78          	mov    0x78(%r15),%eax
 110b8a0:	49 39 c4             	cmp    %rax,%r12
 110b8a3:	72 db                	jb     110b880 <myl_rc_native_unloan+0x60>
 110b8a5:	49 8b 07             	mov    (%r15),%rax
 110b8a8:	48 8b 10             	mov    (%rax),%rdx
 110b8ab:	4c 89 f7             	mov    %r14,%rdi
 110b8ae:	31 f6                	xor    %esi,%esi
 110b8b0:	e8 2b 05 00 00       	call   110bde0 <compiler_rt.fastMemset>
 110b8b5:	48 89 df             	mov    %rbx,%rdi
 110b8b8:	5b                   	pop    %rbx
 110b8b9:	41 5c                	pop    %r12
 110b8bb:	41 5e                	pop    %r14
 110b8bd:	41 5f                	pop    %r15
 110b8bf:	5d                   	pop    %rbp
 110b8c0:	e9 8b 9f ff ff       	jmp    1105850 <myl_rc_drain>
 110b8c5:	49 8b 77 08          	mov    0x8(%r15),%rsi
 110b8c9:	48 89 df             	mov    %rbx,%rdi
 110b8cc:	4c 89 f2             	mov    %r14,%rdx
 110b8cf:	5b                   	pop    %rbx
 110b8d0:	41 5c                	pop    %r12
 110b8d2:	41 5e                	pop    %r14
 110b8d4:	41 5f                	pop    %r15
 110b8d6:	5d                   	pop    %rbp
 110b8d7:	e9 e4 a1 ff ff       	jmp    1105ac0 <myl_rc_loan_drop>
 110b8dc:	e8 ed 75 ff ff       	call   1102ece <myl_rc_invariant_failed>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
