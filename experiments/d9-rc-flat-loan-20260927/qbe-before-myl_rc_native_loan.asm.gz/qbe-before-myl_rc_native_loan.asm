
/home/epentland/ai/canopy/mylang-worktrees/d9-rc-mut-argument-astra/.tmp-mut-argument/loan-measure/qbe-before-production:     file format elf64-x86-64


Disassembly of section .text:

000000000110b4f0 <myl_rc_native_loan>:
 110b4f0:	55                   	push   %rbp
 110b4f1:	48 89 e5             	mov    %rsp,%rbp
 110b4f4:	41 57                	push   %r15
 110b4f6:	41 56                	push   %r14
 110b4f8:	41 55                	push   %r13
 110b4fa:	41 54                	push   %r12
 110b4fc:	53                   	push   %rbx
 110b4fd:	50                   	push   %rax
 110b4fe:	49 89 cf             	mov    %rcx,%r15
 110b501:	49 89 d6             	mov    %rdx,%r14
 110b504:	49 89 f5             	mov    %rsi,%r13
 110b507:	48 89 fb             	mov    %rdi,%rbx
 110b50a:	e8 01 f9 ff ff       	call   110ae10 <myl_rc_native_shape>
 110b50f:	48 85 c0             	test   %rax,%rax
 110b512:	74 35                	je     110b549 <myl_rc_native_loan+0x59>
 110b514:	49 89 c4             	mov    %rax,%r12
 110b517:	48 89 df             	mov    %rbx,%rdi
 110b51a:	4c 89 ee             	mov    %r13,%rsi
 110b51d:	e8 ae a5 ff ff       	call   1105ad0 <myl_rc_native_has_unique>
 110b522:	85 c0                	test   %eax,%eax
 110b524:	75 4b                	jne    110b571 <myl_rc_native_loan+0x81>
 110b526:	48 89 df             	mov    %rbx,%rdi
 110b529:	4c 89 e6             	mov    %r12,%rsi
 110b52c:	4c 89 f2             	mov    %r14,%rdx
 110b52f:	4c 89 f9             	mov    %r15,%rcx
 110b532:	e8 f9 d2 ff ff       	call   1108830 <myl_rc_loan_copy>
 110b537:	85 c0                	test   %eax,%eax
 110b539:	74 20                	je     110b55b <myl_rc_native_loan+0x6b>
 110b53b:	48 89 df             	mov    %rbx,%rdi
 110b53e:	89 c6                	mov    %eax,%esi
 110b540:	e8 ab 7a ff ff       	call   1102ff0 <myl_rc_record_failure>
 110b545:	31 db                	xor    %ebx,%ebx
 110b547:	eb 17                	jmp    110b560 <myl_rc_native_loan+0x70>
 110b549:	49 8b 55 00          	mov    0x0(%r13),%rdx
 110b54d:	31 db                	xor    %ebx,%ebx
 110b54f:	4c 89 f7             	mov    %r14,%rdi
 110b552:	31 f6                	xor    %esi,%esi
 110b554:	e8 47 05 00 00       	call   110baa0 <compiler_rt.fastMemset>
 110b559:	eb 05                	jmp    110b560 <myl_rc_native_loan+0x70>
 110b55b:	bb 01 00 00 00       	mov    $0x1,%ebx
 110b560:	89 d8                	mov    %ebx,%eax
 110b562:	48 83 c4 08          	add    $0x8,%rsp
 110b566:	5b                   	pop    %rbx
 110b567:	41 5c                	pop    %r12
 110b569:	41 5d                	pop    %r13
 110b56b:	41 5e                	pop    %r14
 110b56d:	41 5f                	pop    %r15
 110b56f:	5d                   	pop    %rbp
 110b570:	c3                   	ret
 110b571:	e8 18 79 ff ff       	call   1102e8e <myl_rc_invariant_failed>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
