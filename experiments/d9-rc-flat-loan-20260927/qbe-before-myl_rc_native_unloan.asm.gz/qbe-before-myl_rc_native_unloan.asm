
/home/epentland/ai/canopy/mylang-worktrees/d9-rc-mut-argument-astra/.tmp-mut-argument/loan-measure/qbe-before-production:     file format elf64-x86-64


Disassembly of section .text:

000000000110b580 <myl_rc_native_unloan>:
 110b580:	55                   	push   %rbp
 110b581:	48 89 e5             	mov    %rsp,%rbp
 110b584:	41 56                	push   %r14
 110b586:	53                   	push   %rbx
 110b587:	48 89 d3             	mov    %rdx,%rbx
 110b58a:	49 89 fe             	mov    %rdi,%r14
 110b58d:	e8 ce 86 ff ff       	call   1103c60 <myl_rc_descriptor_find>
 110b592:	48 85 c0             	test   %rax,%rax
 110b595:	74 13                	je     110b5aa <myl_rc_native_unloan+0x2a>
 110b597:	48 8b 70 08          	mov    0x8(%rax),%rsi
 110b59b:	4c 89 f7             	mov    %r14,%rdi
 110b59e:	48 89 da             	mov    %rbx,%rdx
 110b5a1:	5b                   	pop    %rbx
 110b5a2:	41 5e                	pop    %r14
 110b5a4:	5d                   	pop    %rbp
 110b5a5:	e9 66 a4 ff ff       	jmp    1105a10 <myl_rc_loan_drop>
 110b5aa:	e8 df 78 ff ff       	call   1102e8e <myl_rc_invariant_failed>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
