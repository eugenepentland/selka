
/home/epentland/ai/canopy/mylang-worktrees/d9-rc-mut-argument-astra/.tmp-mut-argument/loan-measure/llvm-before-production:     file format elf64-x86-64


Disassembly of section .text:

0000000001103fa0 <myl_rc_native_loan>:
 1103fa0:	55                   	push   %rbp
 1103fa1:	48 89 e5             	mov    %rsp,%rbp
 1103fa4:	41 57                	push   %r15
 1103fa6:	41 56                	push   %r14
 1103fa8:	41 55                	push   %r13
 1103faa:	41 54                	push   %r12
 1103fac:	53                   	push   %rbx
 1103fad:	48 81 ec f8 01 00 00 	sub    $0x1f8,%rsp
 1103fb4:	49 89 cf             	mov    %rcx,%r15
 1103fb7:	49 89 d6             	mov    %rdx,%r14
 1103fba:	49 89 f5             	mov    %rsi,%r13
 1103fbd:	48 89 fb             	mov    %rdi,%rbx
 1103fc0:	e8 fb f4 ff ff       	call   11034c0 <myl_rc_native_shape>
 1103fc5:	48 85 c0             	test   %rax,%rax
 1103fc8:	0f 84 d6 01 00 00    	je     11041a4 <myl_rc_native_loan+0x204>
 1103fce:	49 89 c4             	mov    %rax,%r12
 1103fd1:	48 89 df             	mov    %rbx,%rdi
 1103fd4:	4c 89 ee             	mov    %r13,%rsi
 1103fd7:	e8 64 9d ff ff       	call   10fdd40 <myl_rc_native_has_unique>
 1103fdc:	85 c0                	test   %eax,%eax
 1103fde:	0f 85 f9 01 00 00    	jne    11041dd <myl_rc_native_loan+0x23d>
 1103fe4:	48 85 db             	test   %rbx,%rbx
 1103fe7:	0f 84 f0 01 00 00    	je     11041dd <myl_rc_native_loan+0x23d>
 1103fed:	4d 39 fe             	cmp    %r15,%r14
 1103ff0:	0f 84 e7 01 00 00    	je     11041dd <myl_rc_native_loan+0x23d>
 1103ff6:	4d 85 ff             	test   %r15,%r15
 1103ff9:	0f 84 de 01 00 00    	je     11041dd <myl_rc_native_loan+0x23d>
 1103fff:	48 8b 8b 08 16 00 00 	mov    0x1608(%rbx),%rcx
 1104006:	48 85 c9             	test   %rcx,%rcx
 1104009:	0f 84 ce 01 00 00    	je     11041dd <myl_rc_native_loan+0x23d>
 110400f:	48 8b 41 40          	mov    0x40(%rcx),%rax
 1104013:	48 85 c0             	test   %rax,%rax
 1104016:	0f 84 c1 01 00 00    	je     11041dd <myl_rc_native_loan+0x23d>
 110401c:	48 8b 49 30          	mov    0x30(%rcx),%rcx
 1104020:	4c 89 e2             	mov    %r12,%rdx
 1104023:	48 c1 ea 03          	shr    $0x3,%rdx
 1104027:	4c 89 e6             	mov    %r12,%rsi
 110402a:	48 c1 ee 21          	shr    $0x21,%rsi
 110402e:	48 31 d6             	xor    %rdx,%rsi
 1104031:	48 bf b9 e5 e4 1c 6d 	movabs $0xbf58476d1ce4e5b9,%rdi
 1104038:	47 58 bf 
 110403b:	48 0f af fe          	imul   %rsi,%rdi
 110403f:	48 89 fa             	mov    %rdi,%rdx
 1104042:	48 c1 ea 1b          	shr    $0x1b,%rdx
 1104046:	48 31 fa             	xor    %rdi,%rdx
 1104049:	48 83 f2 01          	xor    $0x1,%rdx
 110404d:	48 ff c8             	dec    %rax
 1104050:	eb 11                	jmp    1104063 <myl_rc_native_loan+0xc3>
 1104052:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1104059:	1f 84 00 00 00 00 00 
 1104060:	48 ff c2             	inc    %rdx
 1104063:	48 21 c2             	and    %rax,%rdx
 1104066:	48 8d 34 92          	lea    (%rdx,%rdx,4),%rsi
 110406a:	48 8b 34 f1          	mov    (%rcx,%rsi,8),%rsi
 110406e:	48 85 f6             	test   %rsi,%rsi
 1104071:	0f 84 66 01 00 00    	je     11041dd <myl_rc_native_loan+0x23d>
 1104077:	4c 39 e6             	cmp    %r12,%rsi
 110407a:	75 e4                	jne    1104060 <myl_rc_native_loan+0xc0>
 110407c:	48 8d 34 92          	lea    (%rdx,%rdx,4),%rsi
 1104080:	83 7c f1 20 01       	cmpl   $0x1,0x20(%rcx,%rsi,8)
 1104085:	75 d9                	jne    1104060 <myl_rc_native_loan+0xc0>
 1104087:	48 8d 04 f1          	lea    (%rcx,%rsi,8),%rax
 110408b:	4c 8b 60 08          	mov    0x8(%rax),%r12
 110408f:	4d 85 e4             	test   %r12,%r12
 1104092:	0f 84 45 01 00 00    	je     11041dd <myl_rc_native_loan+0x23d>
 1104098:	4c 89 f0             	mov    %r14,%rax
 110409b:	49 8b 14 24          	mov    (%r12),%rdx
 110409f:	4c 29 f8             	sub    %r15,%rax
 11040a2:	77 06                	ja     11040aa <myl_rc_native_loan+0x10a>
 11040a4:	4c 89 f8             	mov    %r15,%rax
 11040a7:	4c 29 f0             	sub    %r14,%rax
 11040aa:	48 39 d0             	cmp    %rdx,%rax
 11040ad:	0f 82 2a 01 00 00    	jb     11041dd <myl_rc_native_loan+0x23d>
 11040b3:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
 11040b7:	c5 fc 11 45 80       	vmovups %ymm0,-0x80(%rbp)
 11040bc:	c5 fc 11 85 60 ff ff 	vmovups %ymm0,-0xa0(%rbp)
 11040c3:	ff 
 11040c4:	c5 fc 11 85 40 ff ff 	vmovups %ymm0,-0xc0(%rbp)
 11040cb:	ff 
 11040cc:	c5 fc 11 85 20 ff ff 	vmovups %ymm0,-0xe0(%rbp)
 11040d3:	ff 
 11040d4:	c5 fc 11 85 00 ff ff 	vmovups %ymm0,-0x100(%rbp)
 11040db:	ff 
 11040dc:	c5 fc 11 85 e0 fe ff 	vmovups %ymm0,-0x120(%rbp)
 11040e3:	ff 
 11040e4:	48 c7 45 a0 00 00 00 	movq   $0x0,-0x60(%rbp)
 11040eb:	00 
 11040ec:	48 89 5d a8          	mov    %rbx,-0x58(%rbp)
 11040f0:	48 8d 85 e0 fd ff ff 	lea    -0x220(%rbp),%rax
 11040f7:	48 89 45 b0          	mov    %rax,-0x50(%rbp)
 11040fb:	48 c7 45 b8 08 00 00 	movq   $0x8,-0x48(%rbp)
 1104102:	00 
 1104103:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
 1104107:	c5 f8 11 45 c0       	vmovups %xmm0,-0x40(%rbp)
 110410c:	48 8d 85 e0 fe ff ff 	lea    -0x120(%rbp),%rax
 1104113:	48 89 45 d0          	mov    %rax,-0x30(%rbp)
 1104117:	4c 89 f7             	mov    %r14,%rdi
 110411a:	31 f6                	xor    %esi,%esi
 110411c:	c5 f8 77             	vzeroupper
 110411f:	e8 ec 0a 00 00       	call   1104c10 <memset@plt>
 1104124:	48 8d 7d a8          	lea    -0x58(%rbp),%rdi
 1104128:	4c 89 e6             	mov    %r12,%rsi
 110412b:	e8 d0 c5 ff ff       	call   1100700 <prepare_frames>
 1104130:	41 bd 01 00 00 00    	mov    $0x1,%r13d
 1104136:	85 c0                	test   %eax,%eax
 1104138:	75 44                	jne    110417e <myl_rc_native_loan+0x1de>
 110413a:	41 b8 01 00 00 00    	mov    $0x1,%r8d
 1104140:	48 89 df             	mov    %rbx,%rdi
 1104143:	4c 89 e6             	mov    %r12,%rsi
 1104146:	4c 89 f2             	mov    %r14,%rdx
 1104149:	4c 89 f9             	mov    %r15,%rcx
 110414c:	e8 bf 9d ff ff       	call   10fdf10 <myl_rc_value_seed>
 1104151:	48 8d 7d a8          	lea    -0x58(%rbp),%rdi
 1104155:	41 b8 c0 1f 10 01    	mov    $0x1101fc0,%r8d
 110415b:	4c 89 e6             	mov    %r12,%rsi
 110415e:	4c 89 f2             	mov    %r14,%rdx
 1104161:	4c 89 f9             	mov    %r15,%rcx
 1104164:	e8 57 c7 ff ff       	call   11008c0 <visit>
 1104169:	85 c0                	test   %eax,%eax
 110416b:	74 5d                	je     11041ca <myl_rc_native_loan+0x22a>
 110416d:	41 89 c5             	mov    %eax,%r13d
 1104170:	48 89 df             	mov    %rbx,%rdi
 1104173:	4c 89 e6             	mov    %r12,%rsi
 1104176:	4c 89 f2             	mov    %r14,%rdx
 1104179:	e8 b2 9a ff ff       	call   10fdc30 <myl_rc_loan_drop>
 110417e:	48 8d 7d a8          	lea    -0x58(%rbp),%rdi
 1104182:	45 31 ff             	xor    %r15d,%r15d
 1104185:	31 f6                	xor    %esi,%esi
 1104187:	e8 c4 d8 ff ff       	call   1101a50 <dispose_walk>
 110418c:	48 8b 83 08 16 00 00 	mov    0x1608(%rbx),%rax
 1104193:	48 85 c0             	test   %rax,%rax
 1104196:	74 45                	je     11041dd <myl_rc_native_loan+0x23d>
 1104198:	83 78 78 00          	cmpl   $0x0,0x78(%rax)
 110419c:	75 17                	jne    11041b5 <myl_rc_native_loan+0x215>
 110419e:	44 89 68 78          	mov    %r13d,0x78(%rax)
 11041a2:	eb 11                	jmp    11041b5 <myl_rc_native_loan+0x215>
 11041a4:	49 8b 55 00          	mov    0x0(%r13),%rdx
 11041a8:	45 31 ff             	xor    %r15d,%r15d
 11041ab:	4c 89 f7             	mov    %r14,%rdi
 11041ae:	31 f6                	xor    %esi,%esi
 11041b0:	e8 5b 0a 00 00       	call   1104c10 <memset@plt>
 11041b5:	44 89 f8             	mov    %r15d,%eax
 11041b8:	48 81 c4 f8 01 00 00 	add    $0x1f8,%rsp
 11041bf:	5b                   	pop    %rbx
 11041c0:	41 5c                	pop    %r12
 11041c2:	41 5d                	pop    %r13
 11041c4:	41 5e                	pop    %r14
 11041c6:	41 5f                	pop    %r15
 11041c8:	5d                   	pop    %rbp
 11041c9:	c3                   	ret
 11041ca:	48 8d 7d a8          	lea    -0x58(%rbp),%rdi
 11041ce:	31 f6                	xor    %esi,%esi
 11041d0:	e8 7b d8 ff ff       	call   1101a50 <dispose_walk>
 11041d5:	41 bf 01 00 00 00    	mov    $0x1,%r15d
 11041db:	eb d8                	jmp    11041b5 <myl_rc_native_loan+0x215>
 11041dd:	e8 12 71 ff ff       	call   10fb2f4 <myl_rc_invariant_failed>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
