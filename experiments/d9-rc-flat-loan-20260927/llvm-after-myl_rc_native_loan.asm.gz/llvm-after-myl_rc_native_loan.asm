
/home/epentland/ai/canopy/mylang-worktrees/d9-rc-mut-argument-astra/.tmp-mut-argument/loan-measure/llvm-after-production:     file format elf64-x86-64


Disassembly of section .text:

00000000011040d0 <myl_rc_native_loan>:
 11040d0:	55                   	push   %rbp
 11040d1:	48 89 e5             	mov    %rsp,%rbp
 11040d4:	41 57                	push   %r15
 11040d6:	41 56                	push   %r14
 11040d8:	41 55                	push   %r13
 11040da:	41 54                	push   %r12
 11040dc:	53                   	push   %rbx
 11040dd:	48 81 ec 08 02 00 00 	sub    $0x208,%rsp
 11040e4:	49 89 cf             	mov    %rcx,%r15
 11040e7:	49 89 d6             	mov    %rdx,%r14
 11040ea:	49 89 f4             	mov    %rsi,%r12
 11040ed:	48 89 fb             	mov    %rdi,%rbx
 11040f0:	48 85 ff             	test   %rdi,%rdi
 11040f3:	0f 84 e4 00 00 00    	je     11041dd <myl_rc_native_loan+0x10d>
 11040f9:	48 8b 83 08 16 00 00 	mov    0x1608(%rbx),%rax
 1104100:	48 85 c0             	test   %rax,%rax
 1104103:	0f 94 c1             	sete   %cl
 1104106:	4d 85 e4             	test   %r12,%r12
 1104109:	0f 94 c2             	sete   %dl
 110410c:	08 ca                	or     %cl,%dl
 110410e:	0f 85 c9 00 00 00    	jne    11041dd <myl_rc_native_loan+0x10d>
 1104114:	48 8b 48 40          	mov    0x40(%rax),%rcx
 1104118:	48 85 c9             	test   %rcx,%rcx
 110411b:	0f 84 bc 00 00 00    	je     11041dd <myl_rc_native_loan+0x10d>
 1104121:	49 b8 b9 e5 e4 1c 6d 	movabs $0xbf58476d1ce4e5b9,%r8
 1104128:	47 58 bf 
 110412b:	48 8b 50 30          	mov    0x30(%rax),%rdx
 110412f:	4c 89 e6             	mov    %r12,%rsi
 1104132:	48 c1 ee 03          	shr    $0x3,%rsi
 1104136:	4c 89 e7             	mov    %r12,%rdi
 1104139:	48 c1 ef 21          	shr    $0x21,%rdi
 110413d:	48 31 f7             	xor    %rsi,%rdi
 1104140:	49 0f af f8          	imul   %r8,%rdi
 1104144:	48 89 fe             	mov    %rdi,%rsi
 1104147:	48 c1 ee 1b          	shr    $0x1b,%rsi
 110414b:	48 31 fe             	xor    %rdi,%rsi
 110414e:	48 83 f6 02          	xor    $0x2,%rsi
 1104152:	48 ff c9             	dec    %rcx
 1104155:	eb 0c                	jmp    1104163 <myl_rc_native_loan+0x93>
 1104157:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
 110415e:	00 00 
 1104160:	48 ff c6             	inc    %rsi
 1104163:	48 21 ce             	and    %rcx,%rsi
 1104166:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
 110416a:	48 8b 3c fa          	mov    (%rdx,%rdi,8),%rdi
 110416e:	48 85 ff             	test   %rdi,%rdi
 1104171:	74 6a                	je     11041dd <myl_rc_native_loan+0x10d>
 1104173:	4c 39 e7             	cmp    %r12,%rdi
 1104176:	75 e8                	jne    1104160 <myl_rc_native_loan+0x90>
 1104178:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
 110417c:	83 7c fa 20 02       	cmpl   $0x2,0x20(%rdx,%rdi,8)
 1104181:	75 dd                	jne    1104160 <myl_rc_native_loan+0x90>
 1104183:	48 8d 0c fa          	lea    (%rdx,%rdi,8),%rcx
 1104187:	4c 8b 69 08          	mov    0x8(%rcx),%r13
 110418b:	4d 85 ed             	test   %r13,%r13
 110418e:	74 4d                	je     11041dd <myl_rc_native_loan+0x10d>
 1104190:	41 83 7d 7c 00       	cmpl   $0x0,0x7c(%r13)
 1104195:	74 40                	je     11041d7 <myl_rc_native_loan+0x107>
 1104197:	49 8b 4d 00          	mov    0x0(%r13),%rcx
 110419b:	48 8b 11             	mov    (%rcx),%rdx
 110419e:	48 85 d2             	test   %rdx,%rdx
 11041a1:	74 34                	je     11041d7 <myl_rc_native_loan+0x107>
 11041a3:	4d 39 fe             	cmp    %r15,%r14
 11041a6:	0f 84 c0 03 00 00    	je     110456c <myl_rc_native_loan+0x49c>
 11041ac:	4d 85 ff             	test   %r15,%r15
 11041af:	0f 84 b7 03 00 00    	je     110456c <myl_rc_native_loan+0x49c>
 11041b5:	48 83 78 58 00       	cmpq   $0x0,0x58(%rax)
 11041ba:	0f 85 ac 03 00 00    	jne    110456c <myl_rc_native_loan+0x49c>
 11041c0:	4c 89 f0             	mov    %r14,%rax
 11041c3:	4c 29 f8             	sub    %r15,%rax
 11041c6:	77 06                	ja     11041ce <myl_rc_native_loan+0xfe>
 11041c8:	4c 89 f8             	mov    %r15,%rax
 11041cb:	4c 29 f0             	sub    %r14,%rax
 11041ce:	48 39 d0             	cmp    %rdx,%rax
 11041d1:	0f 83 2d 02 00 00    	jae    1104404 <myl_rc_native_loan+0x334>
 11041d7:	4d 8b 6d 08          	mov    0x8(%r13),%r13
 11041db:	eb 0e                	jmp    11041eb <myl_rc_native_loan+0x11b>
 11041dd:	48 89 df             	mov    %rbx,%rdi
 11041e0:	4c 89 e6             	mov    %r12,%rsi
 11041e3:	e8 08 f4 ff ff       	call   11035f0 <myl_rc_native_shape>
 11041e8:	49 89 c5             	mov    %rax,%r13
 11041eb:	4d 85 ed             	test   %r13,%r13
 11041ee:	0f 84 d7 01 00 00    	je     11043cb <myl_rc_native_loan+0x2fb>
 11041f4:	48 89 df             	mov    %rbx,%rdi
 11041f7:	4c 89 e6             	mov    %r12,%rsi
 11041fa:	e8 71 9c ff ff       	call   10fde70 <myl_rc_native_has_unique>
 11041ff:	85 c0                	test   %eax,%eax
 1104201:	0f 85 65 03 00 00    	jne    110456c <myl_rc_native_loan+0x49c>
 1104207:	48 85 db             	test   %rbx,%rbx
 110420a:	0f 84 5c 03 00 00    	je     110456c <myl_rc_native_loan+0x49c>
 1104210:	4d 39 fe             	cmp    %r15,%r14
 1104213:	0f 84 53 03 00 00    	je     110456c <myl_rc_native_loan+0x49c>
 1104219:	4d 85 ff             	test   %r15,%r15
 110421c:	0f 84 4a 03 00 00    	je     110456c <myl_rc_native_loan+0x49c>
 1104222:	48 8b 8b 08 16 00 00 	mov    0x1608(%rbx),%rcx
 1104229:	48 85 c9             	test   %rcx,%rcx
 110422c:	0f 84 3a 03 00 00    	je     110456c <myl_rc_native_loan+0x49c>
 1104232:	48 8b 41 40          	mov    0x40(%rcx),%rax
 1104236:	48 85 c0             	test   %rax,%rax
 1104239:	0f 84 2d 03 00 00    	je     110456c <myl_rc_native_loan+0x49c>
 110423f:	48 8b 49 30          	mov    0x30(%rcx),%rcx
 1104243:	4c 89 ea             	mov    %r13,%rdx
 1104246:	48 c1 ea 03          	shr    $0x3,%rdx
 110424a:	4c 89 ee             	mov    %r13,%rsi
 110424d:	48 c1 ee 21          	shr    $0x21,%rsi
 1104251:	48 31 d6             	xor    %rdx,%rsi
 1104254:	48 bf b9 e5 e4 1c 6d 	movabs $0xbf58476d1ce4e5b9,%rdi
 110425b:	47 58 bf 
 110425e:	48 0f af fe          	imul   %rsi,%rdi
 1104262:	48 89 fa             	mov    %rdi,%rdx
 1104265:	48 c1 ea 1b          	shr    $0x1b,%rdx
 1104269:	48 31 fa             	xor    %rdi,%rdx
 110426c:	48 83 f2 01          	xor    $0x1,%rdx
 1104270:	48 ff c8             	dec    %rax
 1104273:	eb 0e                	jmp    1104283 <myl_rc_native_loan+0x1b3>
 1104275:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
 110427c:	00 00 00 00 
 1104280:	48 ff c2             	inc    %rdx
 1104283:	48 21 c2             	and    %rax,%rdx
 1104286:	48 8d 34 92          	lea    (%rdx,%rdx,4),%rsi
 110428a:	48 8b 34 f1          	mov    (%rcx,%rsi,8),%rsi
 110428e:	48 85 f6             	test   %rsi,%rsi
 1104291:	0f 84 d5 02 00 00    	je     110456c <myl_rc_native_loan+0x49c>
 1104297:	4c 39 ee             	cmp    %r13,%rsi
 110429a:	75 e4                	jne    1104280 <myl_rc_native_loan+0x1b0>
 110429c:	48 8d 34 92          	lea    (%rdx,%rdx,4),%rsi
 11042a0:	83 7c f1 20 01       	cmpl   $0x1,0x20(%rcx,%rsi,8)
 11042a5:	75 d9                	jne    1104280 <myl_rc_native_loan+0x1b0>
 11042a7:	48 8d 04 f1          	lea    (%rcx,%rsi,8),%rax
 11042ab:	4c 8b 60 08          	mov    0x8(%rax),%r12
 11042af:	4d 85 e4             	test   %r12,%r12
 11042b2:	0f 84 b4 02 00 00    	je     110456c <myl_rc_native_loan+0x49c>
 11042b8:	4c 89 f0             	mov    %r14,%rax
 11042bb:	49 8b 14 24          	mov    (%r12),%rdx
 11042bf:	4c 29 f8             	sub    %r15,%rax
 11042c2:	77 06                	ja     11042ca <myl_rc_native_loan+0x1fa>
 11042c4:	4c 89 f8             	mov    %r15,%rax
 11042c7:	4c 29 f0             	sub    %r14,%rax
 11042ca:	48 39 d0             	cmp    %rdx,%rax
 11042cd:	0f 82 99 02 00 00    	jb     110456c <myl_rc_native_loan+0x49c>
 11042d3:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
 11042d7:	c5 fc 11 85 70 ff ff 	vmovups %ymm0,-0x90(%rbp)
 11042de:	ff 
 11042df:	c5 fc 11 85 50 ff ff 	vmovups %ymm0,-0xb0(%rbp)
 11042e6:	ff 
 11042e7:	c5 fc 11 85 30 ff ff 	vmovups %ymm0,-0xd0(%rbp)
 11042ee:	ff 
 11042ef:	c5 fc 11 85 10 ff ff 	vmovups %ymm0,-0xf0(%rbp)
 11042f6:	ff 
 11042f7:	c5 fc 11 85 f0 fe ff 	vmovups %ymm0,-0x110(%rbp)
 11042fe:	ff 
 11042ff:	c5 fc 11 85 d0 fe ff 	vmovups %ymm0,-0x130(%rbp)
 1104306:	ff 
 1104307:	48 c7 45 90 00 00 00 	movq   $0x0,-0x70(%rbp)
 110430e:	00 
 110430f:	48 89 5d a0          	mov    %rbx,-0x60(%rbp)
 1104313:	48 8d 85 d0 fd ff ff 	lea    -0x230(%rbp),%rax
 110431a:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
 110431e:	48 c7 45 b0 08 00 00 	movq   $0x8,-0x50(%rbp)
 1104325:	00 
 1104326:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
 110432a:	c5 f8 11 45 b8       	vmovups %xmm0,-0x48(%rbp)
 110432f:	48 8d 85 d0 fe ff ff 	lea    -0x130(%rbp),%rax
 1104336:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
 110433a:	4c 89 f7             	mov    %r14,%rdi
 110433d:	31 f6                	xor    %esi,%esi
 110433f:	c5 f8 77             	vzeroupper
 1104342:	e8 39 0d 00 00       	call   1105080 <memset@plt>
 1104347:	48 8d 7d a0          	lea    -0x60(%rbp),%rdi
 110434b:	4c 89 e6             	mov    %r12,%rsi
 110434e:	e8 dd c4 ff ff       	call   1100830 <prepare_frames>
 1104353:	41 bd 01 00 00 00    	mov    $0x1,%r13d
 1104359:	85 c0                	test   %eax,%eax
 110435b:	75 44                	jne    11043a1 <myl_rc_native_loan+0x2d1>
 110435d:	41 b8 01 00 00 00    	mov    $0x1,%r8d
 1104363:	48 89 df             	mov    %rbx,%rdi
 1104366:	4c 89 e6             	mov    %r12,%rsi
 1104369:	4c 89 f2             	mov    %r14,%rdx
 110436c:	4c 89 f9             	mov    %r15,%rcx
 110436f:	e8 cc 9c ff ff       	call   10fe040 <myl_rc_value_seed>
 1104374:	48 8d 7d a0          	lea    -0x60(%rbp),%rdi
 1104378:	41 b8 f0 20 10 01    	mov    $0x11020f0,%r8d
 110437e:	4c 89 e6             	mov    %r12,%rsi
 1104381:	4c 89 f2             	mov    %r14,%rdx
 1104384:	4c 89 f9             	mov    %r15,%rcx
 1104387:	e8 64 c6 ff ff       	call   11009f0 <visit>
 110438c:	85 c0                	test   %eax,%eax
 110438e:	74 61                	je     11043f1 <myl_rc_native_loan+0x321>
 1104390:	41 89 c5             	mov    %eax,%r13d
 1104393:	48 89 df             	mov    %rbx,%rdi
 1104396:	4c 89 e6             	mov    %r12,%rsi
 1104399:	4c 89 f2             	mov    %r14,%rdx
 110439c:	e8 bf 99 ff ff       	call   10fdd60 <myl_rc_loan_drop>
 11043a1:	48 8d 7d a0          	lea    -0x60(%rbp),%rdi
 11043a5:	45 31 ff             	xor    %r15d,%r15d
 11043a8:	31 f6                	xor    %esi,%esi
 11043aa:	e8 d1 d7 ff ff       	call   1101b80 <dispose_walk>
 11043af:	48 8b 83 08 16 00 00 	mov    0x1608(%rbx),%rax
 11043b6:	48 85 c0             	test   %rax,%rax
 11043b9:	0f 84 ad 01 00 00    	je     110456c <myl_rc_native_loan+0x49c>
 11043bf:	83 78 78 00          	cmpl   $0x0,0x78(%rax)
 11043c3:	75 17                	jne    11043dc <myl_rc_native_loan+0x30c>
 11043c5:	44 89 68 78          	mov    %r13d,0x78(%rax)
 11043c9:	eb 11                	jmp    11043dc <myl_rc_native_loan+0x30c>
 11043cb:	49 8b 14 24          	mov    (%r12),%rdx
 11043cf:	45 31 ff             	xor    %r15d,%r15d
 11043d2:	4c 89 f7             	mov    %r14,%rdi
 11043d5:	31 f6                	xor    %esi,%esi
 11043d7:	e8 a4 0c 00 00       	call   1105080 <memset@plt>
 11043dc:	44 89 f8             	mov    %r15d,%eax
 11043df:	48 81 c4 08 02 00 00 	add    $0x208,%rsp
 11043e6:	5b                   	pop    %rbx
 11043e7:	41 5c                	pop    %r12
 11043e9:	41 5d                	pop    %r13
 11043eb:	41 5e                	pop    %r14
 11043ed:	41 5f                	pop    %r15
 11043ef:	5d                   	pop    %rbp
 11043f0:	c3                   	ret
 11043f1:	48 8d 7d a0          	lea    -0x60(%rbp),%rdi
 11043f5:	31 f6                	xor    %esi,%esi
 11043f7:	e8 84 d7 ff ff       	call   1101b80 <dispose_walk>
 11043fc:	41 bf 01 00 00 00    	mov    $0x1,%r15d
 1104402:	eb d8                	jmp    11043dc <myl_rc_native_loan+0x30c>
 1104404:	4c 89 f7             	mov    %r14,%rdi
 1104407:	4c 89 fe             	mov    %r15,%rsi
 110440a:	e8 81 0c 00 00       	call   1105090 <memcpy@plt>
 110440f:	41 83 7d 78 00       	cmpl   $0x0,0x78(%r13)
 1104414:	0f 84 57 01 00 00    	je     1104571 <myl_rc_native_loan+0x4a1>
 110441a:	31 c0                	xor    %eax,%eax
 110441c:	49 8b 4c c5 38       	mov    0x38(%r13,%rax,8),%rcx
 1104421:	49 c7 04 0e 00 00 00 	movq   $0x0,(%r14,%rcx,1)
 1104428:	00 
 1104429:	48 ff c0             	inc    %rax
 110442c:	41 8b 4d 78          	mov    0x78(%r13),%ecx
 1104430:	48 39 c8             	cmp    %rcx,%rax
 1104433:	72 e7                	jb     110441c <myl_rc_native_loan+0x34c>
 1104435:	85 c9                	test   %ecx,%ecx
 1104437:	0f 84 34 01 00 00    	je     1104571 <myl_rc_native_loan+0x4a1>
 110443d:	ba 01 00 00 00       	mov    $0x1,%edx
 1104442:	49 bb 02 00 00 00 00 	movabs $0x4000000000000002,%r11
 1104449:	00 00 40 
 110444c:	31 c9                	xor    %ecx,%ecx
 110444e:	eb 1d                	jmp    110446d <myl_rc_native_loan+0x39d>
 1104450:	4d 85 d9             	test   %r11,%r9
 1104453:	0f 84 b5 00 00 00    	je     110450e <myl_rc_native_loan+0x43e>
 1104459:	4b 89 34 06          	mov    %rsi,(%r14,%r8,1)
 110445d:	48 ff c1             	inc    %rcx
 1104460:	41 8b 55 78          	mov    0x78(%r13),%edx
 1104464:	48 39 d1             	cmp    %rdx,%rcx
 1104467:	0f 83 04 01 00 00    	jae    1104571 <myl_rc_native_loan+0x4a1>
 110446d:	4d 8b 44 cd 38       	mov    0x38(%r13,%rcx,8),%r8
 1104472:	4b 8b 34 07          	mov    (%r15,%r8,1),%rsi
 1104476:	48 85 f6             	test   %rsi,%rsi
 1104479:	74 de                	je     1104459 <myl_rc_native_loan+0x389>
 110447b:	4c 8b 4e f8          	mov    -0x8(%rsi),%r9
 110447f:	48 8b bb 08 16 00 00 	mov    0x1608(%rbx),%rdi
 1104486:	48 85 ff             	test   %rdi,%rdi
 1104489:	0f 94 c0             	sete   %al
 110448c:	4d 85 c9             	test   %r9,%r9
 110448f:	41 0f 94 c2          	sete   %r10b
 1104493:	41 08 c2             	or     %al,%r10b
 1104496:	75 71                	jne    1104509 <myl_rc_native_loan+0x439>
 1104498:	4c 8b 57 40          	mov    0x40(%rdi),%r10
 110449c:	4d 85 d2             	test   %r10,%r10
 110449f:	74 68                	je     1104509 <myl_rc_native_loan+0x439>
 11044a1:	48 89 7d d0          	mov    %rdi,-0x30(%rbp)
 11044a5:	4c 8b 5f 30          	mov    0x30(%rdi),%r11
 11044a9:	4c 89 c8             	mov    %r9,%rax
 11044ac:	48 c1 e8 03          	shr    $0x3,%rax
 11044b0:	4c 89 cf             	mov    %r9,%rdi
 11044b3:	48 c1 ef 21          	shr    $0x21,%rdi
 11044b7:	48 31 c7             	xor    %rax,%rdi
 11044ba:	48 b8 b9 e5 e4 1c 6d 	movabs $0xbf58476d1ce4e5b9,%rax
 11044c1:	47 58 bf 
 11044c4:	48 0f af f8          	imul   %rax,%rdi
 11044c8:	49 89 fc             	mov    %rdi,%r12
 11044cb:	49 c1 ec 1b          	shr    $0x1b,%r12
 11044cf:	49 31 fc             	xor    %rdi,%r12
 11044d2:	49 83 f4 02          	xor    $0x2,%r12
 11044d6:	49 ff ca             	dec    %r10
 11044d9:	eb 03                	jmp    11044de <myl_rc_native_loan+0x40e>
 11044db:	49 ff c4             	inc    %r12
 11044de:	4d 21 d4             	and    %r10,%r12
 11044e1:	4b 8d 04 a4          	lea    (%r12,%r12,4),%rax
 11044e5:	49 8b 04 c3          	mov    (%r11,%rax,8),%rax
 11044e9:	48 85 c0             	test   %rax,%rax
 11044ec:	74 4f                	je     110453d <myl_rc_native_loan+0x46d>
 11044ee:	4c 39 c8             	cmp    %r9,%rax
 11044f1:	75 e8                	jne    11044db <myl_rc_native_loan+0x40b>
 11044f3:	4b 8d 04 a4          	lea    (%r12,%r12,4),%rax
 11044f7:	41 83 7c c3 20 02    	cmpl   $0x2,0x20(%r11,%rax,8)
 11044fd:	75 dc                	jne    11044db <myl_rc_native_loan+0x40b>
 11044ff:	49 8d 04 c3          	lea    (%r11,%rax,8),%rax
 1104503:	4c 8b 50 08          	mov    0x8(%rax),%r10
 1104507:	eb 37                	jmp    1104540 <myl_rc_native_loan+0x470>
 1104509:	45 31 d2             	xor    %r10d,%r10d
 110450c:	eb 40                	jmp    110454e <myl_rc_native_loan+0x47e>
 110450e:	48 85 ff             	test   %rdi,%rdi
 1104511:	74 59                	je     110456c <myl_rc_native_loan+0x49c>
 1104513:	41 f6 c1 01          	test   $0x1,%r9b
 1104517:	75 53                	jne    110456c <myl_rc_native_loan+0x49c>
 1104519:	4c 8b 46 e8          	mov    -0x18(%rsi),%r8
 110451d:	48 8b 46 e0          	mov    -0x20(%rsi),%rax
 1104521:	4c 09 c0             	or     %r8,%rax
 1104524:	74 46                	je     110456c <myl_rc_native_loan+0x49c>
 1104526:	49 83 f8 ff          	cmp    $0xffffffffffffffff,%r8
 110452a:	74 58                	je     1104584 <myl_rc_native_loan+0x4b4>
 110452c:	49 ff c0             	inc    %r8
 110452f:	4c 89 46 e8          	mov    %r8,-0x18(%rsi)
 1104533:	4d 8b 44 cd 38       	mov    0x38(%r13,%rcx,8),%r8
 1104538:	e9 1c ff ff ff       	jmp    1104459 <myl_rc_native_loan+0x389>
 110453d:	45 31 d2             	xor    %r10d,%r10d
 1104540:	49 bb 02 00 00 00 00 	movabs $0x4000000000000002,%r11
 1104547:	00 00 40 
 110454a:	48 8b 7d d0          	mov    -0x30(%rbp),%rdi
 110454e:	4c 8b 4e f0          	mov    -0x10(%rsi),%r9
 1104552:	41 f6 c1 02          	test   $0x2,%r9b
 1104556:	0f 85 f4 fe ff ff    	jne    1104450 <myl_rc_native_loan+0x380>
 110455c:	4d 85 d2             	test   %r10,%r10
 110455f:	74 0b                	je     110456c <myl_rc_native_loan+0x49c>
 1104561:	49 83 7a 18 00       	cmpq   $0x0,0x18(%r10)
 1104566:	0f 84 e4 fe ff ff    	je     1104450 <myl_rc_native_loan+0x380>
 110456c:	e8 73 6e ff ff       	call   10fb3e4 <myl_rc_invariant_failed>
 1104571:	48 89 df             	mov    %rbx,%rdi
 1104574:	e8 47 94 ff ff       	call   10fd9c0 <myl_rc_drain>
 1104579:	41 bf 01 00 00 00    	mov    $0x1,%r15d
 110457f:	e9 58 fe ff ff       	jmp    11043dc <myl_rc_native_loan+0x30c>
 1104584:	48 83 7f 58 00       	cmpq   $0x0,0x58(%rdi)
 1104589:	75 e1                	jne    110456c <myl_rc_native_loan+0x49c>
 110458b:	85 d2                	test   %edx,%edx
 110458d:	0f 84 89 00 00 00    	je     110461c <myl_rc_native_loan+0x54c>
 1104593:	31 c9                	xor    %ecx,%ecx
 1104595:	eb 0c                	jmp    11045a3 <myl_rc_native_loan+0x4d3>
 1104597:	48 ff c1             	inc    %rcx
 110459a:	41 8b 45 78          	mov    0x78(%r13),%eax
 110459e:	48 39 c1             	cmp    %rax,%rcx
 11045a1:	73 79                	jae    110461c <myl_rc_native_loan+0x54c>
 11045a3:	49 8b 44 cd 38       	mov    0x38(%r13,%rcx,8),%rax
 11045a8:	49 8b 14 06          	mov    (%r14,%rax,1),%rdx
 11045ac:	49 c7 04 06 00 00 00 	movq   $0x0,(%r14,%rax,1)
 11045b3:	00 
 11045b4:	48 85 d2             	test   %rdx,%rdx
 11045b7:	74 de                	je     1104597 <myl_rc_native_loan+0x4c7>
 11045b9:	48 8b 72 f0          	mov    -0x10(%rdx),%rsi
 11045bd:	4c 85 de             	test   %r11,%rsi
 11045c0:	75 d5                	jne    1104597 <myl_rc_native_loan+0x4c7>
 11045c2:	48 8b bb 08 16 00 00 	mov    0x1608(%rbx),%rdi
 11045c9:	48 85 ff             	test   %rdi,%rdi
 11045cc:	74 9e                	je     110456c <myl_rc_native_loan+0x49c>
 11045ce:	40 f6 c6 01          	test   $0x1,%sil
 11045d2:	75 98                	jne    110456c <myl_rc_native_loan+0x49c>
 11045d4:	48 83 7a e0 00       	cmpq   $0x0,-0x20(%rdx)
 11045d9:	4c 8b 42 e8          	mov    -0x18(%rdx),%r8
 11045dd:	74 0e                	je     11045ed <myl_rc_native_loan+0x51d>
 11045df:	4d 85 c0             	test   %r8,%r8
 11045e2:	74 88                	je     110456c <myl_rc_native_loan+0x49c>
 11045e4:	49 ff c8             	dec    %r8
 11045e7:	4c 89 42 e8          	mov    %r8,-0x18(%rdx)
 11045eb:	eb aa                	jmp    1104597 <myl_rc_native_loan+0x4c7>
 11045ed:	4d 85 c0             	test   %r8,%r8
 11045f0:	0f 84 76 ff ff ff    	je     110456c <myl_rc_native_loan+0x49c>
 11045f6:	49 ff c8             	dec    %r8
 11045f9:	4c 89 42 e8          	mov    %r8,-0x18(%rdx)
 11045fd:	75 98                	jne    1104597 <myl_rc_native_loan+0x4c7>
 11045ff:	48 8d 42 e0          	lea    -0x20(%rdx),%rax
 1104603:	48 83 ce 01          	or     $0x1,%rsi
 1104607:	48 89 72 f0          	mov    %rsi,-0x10(%rdx)
 110460b:	48 8b 77 60          	mov    0x60(%rdi),%rsi
 110460f:	48 89 72 e0          	mov    %rsi,-0x20(%rdx)
 1104613:	48 89 47 60          	mov    %rax,0x60(%rdi)
 1104617:	e9 7b ff ff ff       	jmp    1104597 <myl_rc_native_loan+0x4c7>
 110461c:	49 8b 45 00          	mov    0x0(%r13),%rax
 1104620:	48 8b 10             	mov    (%rax),%rdx
 1104623:	45 31 ff             	xor    %r15d,%r15d
 1104626:	4c 89 f7             	mov    %r14,%rdi
 1104629:	31 f6                	xor    %esi,%esi
 110462b:	e8 50 0a 00 00       	call   1105080 <memset@plt>
 1104630:	48 89 df             	mov    %rbx,%rdi
 1104633:	e8 88 93 ff ff       	call   10fd9c0 <myl_rc_drain>
 1104638:	48 8b 83 08 16 00 00 	mov    0x1608(%rbx),%rax
 110463f:	48 85 c0             	test   %rax,%rax
 1104642:	0f 84 24 ff ff ff    	je     110456c <myl_rc_native_loan+0x49c>
 1104648:	83 78 78 00          	cmpl   $0x0,0x78(%rax)
 110464c:	0f 85 8a fd ff ff    	jne    11043dc <myl_rc_native_loan+0x30c>
 1104652:	c7 40 78 02 00 00 00 	movl   $0x2,0x78(%rax)
 1104659:	e9 7e fd ff ff       	jmp    11043dc <myl_rc_native_loan+0x30c>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
