
/home/epentland/ai/canopy/mylang-worktrees/d9-rc-mut-argument-astra/.tmp-mut-argument/loan-measure/qbe-after-production:     file format elf64-x86-64


Disassembly of section .text:

000000000110b5a0 <myl_rc_native_loan>:
 110b5a0:	55                   	push   %rbp
 110b5a1:	48 89 e5             	mov    %rsp,%rbp
 110b5a4:	41 57                	push   %r15
 110b5a6:	41 56                	push   %r14
 110b5a8:	41 55                	push   %r13
 110b5aa:	41 54                	push   %r12
 110b5ac:	53                   	push   %rbx
 110b5ad:	48 83 ec 28          	sub    $0x28,%rsp
 110b5b1:	48 89 4d c8          	mov    %rcx,-0x38(%rbp)
 110b5b5:	49 89 d6             	mov    %rdx,%r14
 110b5b8:	49 89 f4             	mov    %rsi,%r12
 110b5bb:	48 89 fb             	mov    %rdi,%rbx
 110b5be:	e8 fd 86 ff ff       	call   1103cc0 <myl_rc_descriptor_find>
 110b5c3:	48 85 c0             	test   %rax,%rax
 110b5c6:	0f 84 bb 00 00 00    	je     110b687 <myl_rc_native_loan+0xe7>
 110b5cc:	49 89 c5             	mov    %rax,%r13
 110b5cf:	4c 89 65 c0          	mov    %r12,-0x40(%rbp)
 110b5d3:	83 78 7c 00          	cmpl   $0x0,0x7c(%rax)
 110b5d7:	74 62                	je     110b63b <myl_rc_native_loan+0x9b>
 110b5d9:	49 8b 45 00          	mov    0x0(%r13),%rax
 110b5dd:	48 8b 10             	mov    (%rax),%rdx
 110b5e0:	48 85 d2             	test   %rdx,%rdx
 110b5e3:	74 56                	je     110b63b <myl_rc_native_loan+0x9b>
 110b5e5:	48 85 db             	test   %rbx,%rbx
 110b5e8:	48 8b 4d c8          	mov    -0x38(%rbp),%rcx
 110b5ec:	0f 84 1b 02 00 00    	je     110b80d <myl_rc_native_loan+0x26d>
 110b5f2:	48 8b 83 08 16 00 00 	mov    0x1608(%rbx),%rax
 110b5f9:	48 85 c0             	test   %rax,%rax
 110b5fc:	0f 84 0b 02 00 00    	je     110b80d <myl_rc_native_loan+0x26d>
 110b602:	49 39 ce             	cmp    %rcx,%r14
 110b605:	0f 84 02 02 00 00    	je     110b80d <myl_rc_native_loan+0x26d>
 110b60b:	48 85 c9             	test   %rcx,%rcx
 110b60e:	0f 84 f9 01 00 00    	je     110b80d <myl_rc_native_loan+0x26d>
 110b614:	4d 85 f6             	test   %r14,%r14
 110b617:	0f 84 f0 01 00 00    	je     110b80d <myl_rc_native_loan+0x26d>
 110b61d:	48 83 78 58 00       	cmpq   $0x0,0x58(%rax)
 110b622:	0f 85 e5 01 00 00    	jne    110b80d <myl_rc_native_loan+0x26d>
 110b628:	4c 89 f0             	mov    %r14,%rax
 110b62b:	48 29 c8             	sub    %rcx,%rax
 110b62e:	77 06                	ja     110b636 <myl_rc_native_loan+0x96>
 110b630:	48 89 c8             	mov    %rcx,%rax
 110b633:	4c 29 f0             	sub    %r14,%rax
 110b636:	48 39 d0             	cmp    %rdx,%rax
 110b639:	73 75                	jae    110b6b0 <myl_rc_native_loan+0x110>
 110b63b:	4d 8b 7d 08          	mov    0x8(%r13),%r15
 110b63f:	4c 8b 65 c0          	mov    -0x40(%rbp),%r12
 110b643:	4d 85 ff             	test   %r15,%r15
 110b646:	74 52                	je     110b69a <myl_rc_native_loan+0xfa>
 110b648:	48 89 df             	mov    %rbx,%rdi
 110b64b:	4c 89 e6             	mov    %r12,%rsi
 110b64e:	e8 2d a5 ff ff       	call   1105b80 <myl_rc_native_has_unique>
 110b653:	85 c0                	test   %eax,%eax
 110b655:	0f 85 b2 01 00 00    	jne    110b80d <myl_rc_native_loan+0x26d>
 110b65b:	48 89 df             	mov    %rbx,%rdi
 110b65e:	4c 89 fe             	mov    %r15,%rsi
 110b661:	4c 89 f2             	mov    %r14,%rdx
 110b664:	48 8b 4d c8          	mov    -0x38(%rbp),%rcx
 110b668:	e8 73 d2 ff ff       	call   11088e0 <myl_rc_loan_copy>
 110b66d:	85 c0                	test   %eax,%eax
 110b66f:	0f 84 f1 00 00 00    	je     110b766 <myl_rc_native_loan+0x1c6>
 110b675:	48 89 df             	mov    %rbx,%rdi
 110b678:	89 c6                	mov    %eax,%esi
 110b67a:	e8 b1 79 ff ff       	call   1103030 <myl_rc_record_failure>
 110b67f:	45 31 e4             	xor    %r12d,%r12d
 110b682:	e9 e5 00 00 00       	jmp    110b76c <myl_rc_native_loan+0x1cc>
 110b687:	48 89 df             	mov    %rbx,%rdi
 110b68a:	4c 89 e6             	mov    %r12,%rsi
 110b68d:	e8 2e f8 ff ff       	call   110aec0 <myl_rc_native_shape>
 110b692:	49 89 c7             	mov    %rax,%r15
 110b695:	4d 85 ff             	test   %r15,%r15
 110b698:	75 ae                	jne    110b648 <myl_rc_native_loan+0xa8>
 110b69a:	49 8b 14 24          	mov    (%r12),%rdx
 110b69e:	45 31 e4             	xor    %r12d,%r12d
 110b6a1:	4c 89 f7             	mov    %r14,%rdi
 110b6a4:	31 f6                	xor    %esi,%esi
 110b6a6:	e8 35 07 00 00       	call   110bde0 <compiler_rt.fastMemset>
 110b6ab:	e9 bc 00 00 00       	jmp    110b76c <myl_rc_native_loan+0x1cc>
 110b6b0:	48 89 5d d0          	mov    %rbx,-0x30(%rbp)
 110b6b4:	4c 89 f7             	mov    %r14,%rdi
 110b6b7:	4c 8b 7d c8          	mov    -0x38(%rbp),%r15
 110b6bb:	4c 89 fe             	mov    %r15,%rsi
 110b6be:	e8 1d 0c 00 00       	call   110c2e0 <compiler_rt.memcpy.memcpyFast>
 110b6c3:	41 83 7d 78 00       	cmpl   $0x0,0x78(%r13)
 110b6c8:	0f 84 8f 00 00 00    	je     110b75d <myl_rc_native_loan+0x1bd>
 110b6ce:	31 c0                	xor    %eax,%eax
 110b6d0:	49 8b 4c c5 38       	mov    0x38(%r13,%rax,8),%rcx
 110b6d5:	49 c7 04 0e 00 00 00 	movq   $0x0,(%r14,%rcx,1)
 110b6dc:	00 
 110b6dd:	48 ff c0             	inc    %rax
 110b6e0:	41 8b 4d 78          	mov    0x78(%r13),%ecx
 110b6e4:	48 39 c8             	cmp    %rcx,%rax
 110b6e7:	72 e7                	jb     110b6d0 <myl_rc_native_loan+0x130>
 110b6e9:	85 c9                	test   %ecx,%ecx
 110b6eb:	74 70                	je     110b75d <myl_rc_native_loan+0x1bd>
 110b6ed:	31 db                	xor    %ebx,%ebx
 110b6ef:	90                   	nop
 110b6f0:	49 8b 44 dd 38       	mov    0x38(%r13,%rbx,8),%rax
 110b6f5:	4d 8b 24 07          	mov    (%r15,%rax,1),%r12
 110b6f9:	4d 85 e4             	test   %r12,%r12
 110b6fc:	74 2a                	je     110b728 <myl_rc_native_loan+0x188>
 110b6fe:	49 8b 74 24 f8       	mov    -0x8(%r12),%rsi
 110b703:	48 8b 7d d0          	mov    -0x30(%rbp),%rdi
 110b707:	e8 b4 85 ff ff       	call   1103cc0 <myl_rc_descriptor_find>
 110b70c:	41 f6 44 24 f0 02    	testb  $0x2,-0x10(%r12)
 110b712:	75 14                	jne    110b728 <myl_rc_native_loan+0x188>
 110b714:	48 85 c0             	test   %rax,%rax
 110b717:	0f 84 f0 00 00 00    	je     110b80d <myl_rc_native_loan+0x26d>
 110b71d:	48 83 78 18 00       	cmpq   $0x0,0x18(%rax)
 110b722:	0f 85 e5 00 00 00    	jne    110b80d <myl_rc_native_loan+0x26d>
 110b728:	48 c7 45 b8 00 00 00 	movq   $0x0,-0x48(%rbp)
 110b72f:	00 
 110b730:	48 8b 7d d0          	mov    -0x30(%rbp),%rdi
 110b734:	4c 89 e6             	mov    %r12,%rsi
 110b737:	48 8d 55 b8          	lea    -0x48(%rbp),%rdx
 110b73b:	e8 70 7e ff ff       	call   11035b0 <myl_rc_hold_acquire>
 110b740:	85 c0                	test   %eax,%eax
 110b742:	75 3a                	jne    110b77e <myl_rc_native_loan+0x1de>
 110b744:	49 8b 44 dd 38       	mov    0x38(%r13,%rbx,8),%rax
 110b749:	4d 89 24 06          	mov    %r12,(%r14,%rax,1)
 110b74d:	48 ff c3             	inc    %rbx
 110b750:	41 8b 45 78          	mov    0x78(%r13),%eax
 110b754:	48 39 c3             	cmp    %rax,%rbx
 110b757:	4c 8b 7d c8          	mov    -0x38(%rbp),%r15
 110b75b:	72 93                	jb     110b6f0 <myl_rc_native_loan+0x150>
 110b75d:	48 8b 7d d0          	mov    -0x30(%rbp),%rdi
 110b761:	e8 ea a0 ff ff       	call   1105850 <myl_rc_drain>
 110b766:	41 bc 01 00 00 00    	mov    $0x1,%r12d
 110b76c:	44 89 e0             	mov    %r12d,%eax
 110b76f:	48 83 c4 28          	add    $0x28,%rsp
 110b773:	5b                   	pop    %rbx
 110b774:	41 5c                	pop    %r12
 110b776:	41 5d                	pop    %r13
 110b778:	41 5e                	pop    %r14
 110b77a:	41 5f                	pop    %r15
 110b77c:	5d                   	pop    %rbp
 110b77d:	c3                   	ret
 110b77e:	41 89 c7             	mov    %eax,%r15d
 110b781:	48 8b 45 d0          	mov    -0x30(%rbp),%rax
 110b785:	48 8b 80 08 16 00 00 	mov    0x1608(%rax),%rax
 110b78c:	48 85 c0             	test   %rax,%rax
 110b78f:	74 7c                	je     110b80d <myl_rc_native_loan+0x26d>
 110b791:	48 83 78 58 00       	cmpq   $0x0,0x58(%rax)
 110b796:	75 75                	jne    110b80d <myl_rc_native_loan+0x26d>
 110b798:	41 83 7d 78 00       	cmpl   $0x0,0x78(%r13)
 110b79d:	4c 8b 65 d0          	mov    -0x30(%rbp),%r12
 110b7a1:	74 32                	je     110b7d5 <myl_rc_native_loan+0x235>
 110b7a3:	31 db                	xor    %ebx,%ebx
 110b7a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
 110b7ac:	00 00 00 00 
 110b7b0:	49 8b 44 dd 38       	mov    0x38(%r13,%rbx,8),%rax
 110b7b5:	49 8b 34 06          	mov    (%r14,%rax,1),%rsi
 110b7b9:	49 c7 04 06 00 00 00 	movq   $0x0,(%r14,%rax,1)
 110b7c0:	00 
 110b7c1:	4c 89 e7             	mov    %r12,%rdi
 110b7c4:	e8 57 7e ff ff       	call   1103620 <myl_rc_hold_edge_release>
 110b7c9:	48 ff c3             	inc    %rbx
 110b7cc:	41 8b 45 78          	mov    0x78(%r13),%eax
 110b7d0:	48 39 c3             	cmp    %rax,%rbx
 110b7d3:	72 db                	jb     110b7b0 <myl_rc_native_loan+0x210>
 110b7d5:	49 8b 45 00          	mov    0x0(%r13),%rax
 110b7d9:	48 8b 10             	mov    (%rax),%rdx
 110b7dc:	4c 89 e3             	mov    %r12,%rbx
 110b7df:	45 31 e4             	xor    %r12d,%r12d
 110b7e2:	4c 89 f7             	mov    %r14,%rdi
 110b7e5:	31 f6                	xor    %esi,%esi
 110b7e7:	e8 f4 05 00 00       	call   110bde0 <compiler_rt.fastMemset>
 110b7ec:	48 89 df             	mov    %rbx,%rdi
 110b7ef:	e8 5c a0 ff ff       	call   1105850 <myl_rc_drain>
 110b7f4:	45 85 ff             	test   %r15d,%r15d
 110b7f7:	0f 88 3e fe ff ff    	js     110b63b <myl_rc_native_loan+0x9b>
 110b7fd:	48 89 df             	mov    %rbx,%rdi
 110b800:	44 89 fe             	mov    %r15d,%esi
 110b803:	e8 28 78 ff ff       	call   1103030 <myl_rc_record_failure>
 110b808:	e9 5f ff ff ff       	jmp    110b76c <myl_rc_native_loan+0x1cc>
 110b80d:	e8 bc 76 ff ff       	call   1102ece <myl_rc_invariant_failed>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
