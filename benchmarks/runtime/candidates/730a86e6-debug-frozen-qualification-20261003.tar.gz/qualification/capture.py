import json
from pathlib import Path
import sys
from datetime import datetime, timezone

root = Path('/home/epentland/ai/canopy/mylang-worktrees/runtime-parity-harness-20261003')
sys.path.insert(0, str(root / 'benchmarks/runtime'))
import runner
from build_compiler import validate_receipt
sys.path.insert(0, str(root / 'benchmarks/runtime/expanded'))
from registry import inventory, checksum
sys.path.insert(0, str(root / 'benchmarks/runtime/diagnostics'))
from backend_receipts import capture

work = Path(__file__).resolve().parent
manifest_path = work.parent / 'runner/manifest.json'
manifest_hash = runner.digest(manifest_path)
manifest = json.loads(manifest_path.read_text())
identity = manifest['identity']
receipt = identity['compiler_build_receipt']
assert receipt['receipt']['source_revision'] == '730a86e62b47c922dc1411d24b5868c3bd2132f3'
assert receipt['receipt']['compiler_optimize'] == 'Debug'
helpers = [Path(__file__), root / 'benchmarks/runtime/runner.py', root / 'benchmarks/runtime/build_compiler.py',
           root / 'benchmarks/runtime/expanded/registry.py', root / 'benchmarks/runtime/diagnostics/backend_receipts.py']
helper_hashes = {str(path): runner.digest(path) for path in helpers}

def verify_inputs():
    assert runner.digest(manifest_path) == manifest_hash
    assert runner.digest(receipt['path']) == receipt['sha256']
    validate_receipt(receipt['receipt'], identity['tools']['mylang']['path'], artifacts=True)
    for name, path in identity['binary_paths'].items():
        assert runner.digest(path) == manifest['binary_hashes'][name]
    assert runner.digest(manifest_path.parent / 'native_clock.o') == manifest['binary_hashes']['native_clock.o']
    assert helper_hashes == {str(path): runner.digest(path) for path in helpers}
    for path, expected in identity['sources'].items():
        assert runner.digest(root / 'benchmarks/runtime' / path) == expected

verify_inputs()
backends = capture(identity['binary_paths'])
assert len(backends) == 8
report = {'schema': 'mylang-runtime-frozen-edge-qualification-v1', 'purpose': 'Correctness qualification; no performance claims',
          'status': 'in_progress', 'started_utc': datetime.now(timezone.utc).isoformat(),
          'manifest': {'path': str(manifest_path), 'sha256': manifest_hash}, 'identity': identity,
          'binary_hashes': manifest['binary_hashes'], 'effective_backends_before': backends,
          'helper_hashes': helper_hashes, 'checks': [], 'cpu': 2, 'timing_lock': str(runner.TIMING_LOCK),
          'limitations': ['All40 frozen cases on two MyLang backends at the three ordinary edge parameters; this is not a six-arm acceptance run.',
                          'Clock/checksum protocol validated and elapsed values omitted; Debug host compiler and RF guests are explicitly recorded.',
                          'RF/Debug emitted guest equivalence is not assumed; final acceptance requires a separate RF host receipt.']}
for case, meta in inventory().items():
    for size, seed, count in ((2, 1, 1), (3, 42, 7), (17, 999983, 31)):
        for arm in ('my-llvm', 'my-qbe'):
            binary = identity['binary_paths'][meta['group'] + '/' + arm]
            value = checksum(case, size, count, seed)
            result = runner.invoke(Path(binary), case, size, count, seed, 2, value)
            result.pop('kernel_ns')
            result.pop('process_wall_ns')
            report['checks'].append({'case': case, 'size': size, 'iterations': count, 'seed': seed, 'arm': arm,
                'expected_checksum': value, 'clock_protocol_validated': True,
                'command': ['taskset', '-c', '2', binary, case, str(size), str(count), str(seed)], **result})
assert len(report['checks']) == 240
assert len({tuple(row[key] for key in ('case', 'size', 'iterations', 'seed', 'arm')) for row in report['checks']}) == 240
verify_inputs()
after = capture(identity['binary_paths'])
assert after == backends
report.update(status='correctness_complete', effective_backends_after=after, finished_utc=datetime.now(timezone.utc).isoformat())
(work / 'qualification.json').write_text(json.dumps(report, indent=2) + '\n')
print('PASS corrected730a86e6: 240 frozen MyLang edge cells; emitted LLVM O3/LTO and QBE backends verified')
