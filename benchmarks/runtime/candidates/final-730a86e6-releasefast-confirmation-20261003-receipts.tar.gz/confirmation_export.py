#!/usr/bin/env python3
"""Bind independent RF confirmation to fixed-target statuses without archived pairing."""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def format_ratio(row, inverse=False):
    ratio=row['ratio_of_medians'];low,high=row['paired_bootstrap_95_interval']
    if inverse:ratio,low,high=1/ratio,1/high,1/low
    return f'{ratio:.4f} [{low:.4f},{high:.4f}]'


def export(comparison_path, confirmation_path, prefix):
    full=json.loads(comparison_path.read_text());confirm=json.loads(confirmation_path.read_text())
    if full['candidate_identity']['source_revision']!=confirm['inputs']['candidate']['identity']['source_revision']:
        raise ValueError('confirmation source mismatch')
    indexes={(r['case'],r['size'],r['numerator'],r['denominator']):r for r in confirm['comparisons']}
    outcomes=[];winlines=[]
    for r in full['comparisons']:
        key=(r['case'],r['size'],'candidate/'+r['arm'],'original/'+r['frozen_reference_arm']);c=indexes.get(key)
        provisional=r['paired_bootstrap_95_interval'][1]<1
        confirmed=bool(c and c['paired_bootstrap_95_interval'][1]<1 and provisional)
        accepted=bool(confirmed and r['ratio_to_frozen_target']<=1)
        status='frozen_target_met_and_independently_faster' if accepted else 'independently_faster_original_but_frozen_target_open' if confirmed else 'provisional_win_not_confirmed' if provisional else 'no_demonstrated_faster_claim'
        outcomes.append({**r,'confirmation':c,'independently_faster_than_original':confirmed,'frozen_target_met_and_confirmed':accepted,'final_evidence_status':status})
        if provisional:
            ctext=format_ratio(c) if c else 'not captured'
            winlines.append(f"| {r['case']} / {r['profile']} | {r['arm']} | {r['ratio_to_frozen_target']:.4f} | {r['ratio_to_concurrent_frozen_reference']:.4f} [{r['paired_bootstrap_95_interval'][0]:.4f},{r['paired_bootstrap_95_interval'][1]:.4f}] | {ctext} | {status} |")
    rows=[]
    for case in dict.fromkeys(p['case'] for p in confirm['plans']):
        for arm in ('my-llvm','my-qbe'):
            values=[]
            for profile in ('small','large'):
                plan=next(p for p in confirm['plans'] if p['case']==case and p['profile']==profile)
                values.append(format_ratio(indexes[(case,plan['size'],'candidate/'+arm,'main/'+arm)]))
            for profile in ('small','large'):
                plan=next(p for p in confirm['plans'] if p['case']==case and p['profile']==profile)
                values.append(format_ratio(indexes[(case,plan['size'],'policy/'+arm,'candidate/'+arm)],True))
            rows.append('| '+case+' | '+arm+' | '+' | '.join(values)+' |')
    env=confirm['environment'];counts=dict(Counter(x['final_evidence_status'] for x in outcomes))
    text=f'''This independent session reran exact final source
`{confirm['inputs']['candidate']['identity']['source_revision']}` on the final
ReleaseFast guests after the complete six-arm milestone. It preselected six
regression families and JSON/Lox, then added every provisional original-reference
win family. Eleven cases, both frozen sizes, seven guests, 15 randomized rounds
and three warmups provide {len(confirm['samples'])} samples, {len(confirm['warmups'])} warmups,
{len(confirm['qualification'])} selected edge probes and {len(confirm['memory'])} RSS probes.
The scalar-policy manifest also passed {len(confirm['new_source_qualification'])} full-inventory
MyLang edge checks. Independent diagnostic replay validates all 154 groups.

All guest invocations used CPU2/global timing lock. CPU2 busy average
{env['per_core_busy_percent_sampling']['2']:.2f}%, sibling CPU3
{env['per_core_busy_percent_sampling']['3']:.2f}%; powersave was active.
Frequency warnings: {env['warnings']}. Average load does not exclude short interference.
The main/final comparison uses ReleaseFast host compilers at exact source1fd1d566
and730a86e6. Scalar-policy1ec host is Debug, guests ReleaseFast; this extra control
is qualified by its recorded mode and no general guest-equivalence assumption.
No archived timing rounds are paired.

The full capture has 7 numerical frozen closures and153 rows still above1.00.
A demonstrated-faster-original claim requires upper paired95% bounds below1 in
both the full session and this independent session. Meeting the frozen target
additionally requires the full frozen ratio<=1.00. Fixed-target arithmetic alone
and near-target rows do not establish independent speed evidence.

| Provisional family / size | Backend | Full frozen ratio | Full concurrent original ratio,95% interval | Independent original ratio,95% interval | Final evidence status |
|---|---|---:|---:|---:|---|
'''+'\n'.join(winlines)+'''

All160 backend/case/size outcomes, including unselected/open targets, are retained
in the companion status JSON. Confirmation does not silently remove any target.
Same-session current-main/final and scalar-policy controls follow:

| Case | Backend | Small final/main,95% interval | Large final/main,95% interval | Small final/policy,95% interval | Large final/policy,95% interval |
|---|---|---:|---:|---:|---:|
'''+'\n'.join(rows)+'''

The final/policy columns are exact reciprocals of the recorded policy/final
ratios, with interval endpoints inverted; they do not create a new unrecorded
measurement. Current-main/final ratios and original-reference ratios use only
new same-session rounds. The generic diagnostic tool warning that one session
alone is not independent proof remains true in isolation; this artifact binds
it as the second session after the separately retained full milestone.

Intervals are exploratory and uncorrected for repeated tuning, winner selection
or multiple comparisons. No application ratio is an additive causal contribution;
profiles and counting-mode ownership diagnostics are separate. The frozen
all-arm common-ISA limitation, calibration limits, single-probe RSS and missing
guest compile-duration measurements remain. No aggregate score pools workloads.
'''+f"\nRaw confirmation SHA256: `{sha(confirmation_path)}`.\nFull comparison SHA256: `{sha(comparison_path)}`.\nFinal evidence counts: `{counts}`.\n"
    prefix.with_name(prefix.name+'-README.md').write_text(text)
    doc={'schema':'mylang-runtime-final-confirmation-status-v1','source_revision':full['candidate_identity']['source_revision'],
         'comparison_path':str(comparison_path),'comparison_sha256':sha(comparison_path),'confirmation_path':str(confirmation_path),
         'confirmation_sha256':sha(confirmation_path),'generator_path':str(Path(__file__).resolve()),'generator_sha256':sha(Path(__file__)),
         'counts':counts,'outcomes':outcomes,'coverage_by_level':dict(Counter(r['level'] for r in outcomes)),
         'limitations':['Every faster claim requires both captured upper paired intervals<1; numerical closure additionally requires full frozen ratio<=1.',
                        'Unselected targets retain full results and no demonstrated-faster claim.','No archived rounds are paired; intervals are exploratory.']}
    prefix.with_name(prefix.name+'-status.json').write_text(json.dumps(doc,indent=2)+'\n')
    print('PASS confirmation outcome export:',counts)


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('comparison',type=Path);p.add_argument('confirmation',type=Path);p.add_argument('--prefix',type=Path,required=True);a=p.parse_args();export(a.comparison,a.confirmation,a.prefix)
