#!/usr/bin/env python3
"""Render all-six-arm and resource tables from independently verified evidence."""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import statistics
import subprocess
import shutil
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'benchmarks/runtime'))
from compare_candidate import target_rows
sys.path.insert(0, str(ROOT / 'benchmarks/runtime/expanded'))
from verify import verify
ARMS = ('rust', 'go', 'zig-safe', 'zig-fast', 'my-llvm', 'my-qbe')
LABELS = ('Rust', 'Go', 'Zig ReleaseSafe', 'Zig ReleaseFast', 'MyLang LLVM', 'MyLang QBE')


def export(path, prefix):
    raw = path.read_bytes()
    report = json.loads(raw)
    verify(report, artifacts=True)
    targets, _ = target_rows()
    groups = {}
    for r in report['samples']:
        groups.setdefault((r['case'], r['size'], r['arm']), []).append(r['kernel_ns'] / r['iterations'])
    rss = {(r['case'], r['size'], r['arm']): r['peak_rss_kib'] for r in report['memory']}
    rows = []
    lines = [f"Source `{report['identity']['source_revision']}`; session `{report['measurement_session_id']}`.", '',
             'Each cell is the median **ns per contract iteration (ratio to the exact frozen original target)**.',
             'The original winner is fixed at 1.00 by its historical median. Current medians and any current-fastest dashboard are separate.',
             'This complete table covers all four languages and both MyLang backends; it preserves all original compiler/runtime flags.',
             'Reference binaries are hash-verified reuses, not newly compiled references. All-arm common-ISA timing remains unestablished.', '',
             '| Case / size | Frozen original target ns (arm) | ' + ' | '.join(LABELS) + ' |',
             '|---|---:|' + '---:|' * len(ARMS)]
    for p in report['plans']:
        key = (p['case'], p['size']); t = targets[key]
        values = []
        for arm in ARMS:
            ns = statistics.median(groups[(*key, arm)])
            values.append(f"{ns:.4f} ({ns / t['target_ns_per_iteration']:.3f})")
            rows.append({'case': key[0], 'size': key[1], 'profile': p['profile'], 'level': p['level'], 'unit': p['unit'],
                         'arm': arm, 'median_ns_per_iteration': ns, 'frozen_target_ns_per_iteration': t['target_ns_per_iteration'],
                         'ratio_to_frozen_target': ns / t['target_ns_per_iteration'], 'peak_rss_kib_single_probe': rss[(*key, arm)]})
        lines.append('| '+p['case']+' / '+p['profile']+' | '+f"{t['target_ns_per_iteration']:.4f} ({t['reference_arm']})"+' | '+' | '.join(values)+' |')
    lines += ['', 'Frozen ratios condition on historical medians. They do not imply a same-session comparison or confidence interval.',
              'The companion 160-row comparison table contains the concurrent original-reference ratios and paired intervals.',
              'All current-main changes require fresh paired source evidence; no archived rounds are paired here.',
              'Intervals and provisional wins require an independent confirmation session before a demonstrated-faster claim.']
    prefix.with_name(prefix.name+'-six-arm.md').write_text('\n'.join(lines)+'\n')
    resources = []; logs = []
    rlines = ['Resource measurements for the exact final source and guest inventory.', '',
              'Binary bytes and ELF .text bytes are static file observations. Peak RSS is one whole-process probe per cell,',
              'including fixtures/runtime/teardown; it is neither a repeated distribution nor kernel-live memory.',
              'Compile logs record commands/status/streams but no timed guest compile duration. The host build receipt',
              'records one elapsed build interval with its cache/slot/load state; it is not a comparative compiler-speed result.', '',
              '| Guest group / arm | Binary bytes | ELF .text bytes | Binary SHA256 |', '|---|---:|---:|---|']
    for name, binary in report['identity']['binary_paths'].items():
        b = Path(binary)
        command = ['size', '-A', str(b)]
        done = subprocess.run(command, check=True, capture_output=True, text=True)
        text_bytes = sum(int(line.split()[1]) for line in done.stdout.splitlines() if line.split() and line.split()[0] == '.text')
        sha = hashlib.sha256(b.read_bytes()).hexdigest()
        if sha != report['binary_hashes'][name]:
            raise ValueError('changed resource executable')
        r = {'name': name, 'binary_path': str(b), 'binary_bytes': b.stat().st_size, 'elf_text_bytes': text_bytes, 'sha256': sha,
             'size_command': command, 'size_stdout': done.stdout}
        resources.append(r)
        rlines.append(f'| {name} | {r["binary_bytes"]} | {text_bytes} | `{sha}` |')
    rlines += ['', 'Every cell below reports the recorded single-process peak RSS in KiB.', '',
               '| Case / size | '+ ' | '.join(LABELS)+' |', '|---|'+'---:|'*len(ARMS)]
    for p in report['plans']:
        rlines.append('| '+p['case']+' / '+p['profile']+' | '+' | '.join(str(rss[(p['case'],p['size'],arm)]) for arm in ARMS)+' |')
    limited = [p for p in report['plans'] if p['calibration']['limited']]
    rlines += ['', f'{len(limited)} of 80 plans hit a calibration limit; reasons: '+str(dict(Counter(p['calibration']['reason'] for p in limited)))+'.',
               'Limited rows retain their original calibration policy and are not silently recalibrated.',
               'Tiny or optimized-away kernels, host interference, CPU frequency and unequal original ISA policies remain measurement limits.']
    prefix.with_name(prefix.name+'-resources.md').write_text('\n'.join(rlines)+'\n')
    receipt=report['identity']['compiler_build_receipt']['receipt']
    output={'schema':'mylang-runtime-final-dashboard-v1','source_revision':report['identity']['source_revision'],
            'session':report['measurement_session_id'],'report_path':str(path),'report_sha256':hashlib.sha256(raw).hexdigest(),
            'resource_tool':{'path':str(Path(shutil.which('size')).resolve()),'sha256':hashlib.sha256(Path(shutil.which('size')).resolve().read_bytes()).hexdigest(),'version':subprocess.check_output(['size','--version'],text=True).splitlines()[0]},
            'generator_path':str(Path(__file__).resolve()),'generator_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            'arms':list(ARMS),'cells':rows,'resources':resources,'calibration_limits':limited,
            'compiler_build_started_utc':receipt['started_utc'],'compiler_build_finished_utc':receipt['finished_utc'],
            'compile_time_limitation':'Guest build durations were not measured; one host build interval is not a comparative speed result.'}
    prefix.with_name(prefix.name+'-dashboard.json').write_text(json.dumps(output,indent=2)+'\n')
    print('PASS final dashboard: 480 six-arm cells, 24 guests, 480 RSS probes')


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('report',type=Path);p.add_argument('--prefix',type=Path,required=True);a=p.parse_args();export(a.report,a.prefix)
