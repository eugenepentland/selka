import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys

root = Path('/home/epentland/ai/canopy/mylang-worktrees/runtime-parity-harness-20261003')
sys.path.insert(0, str(root / 'benchmarks/runtime'))
import runner
from build_compiler import validate_receipt

work = Path(__file__).resolve().parent
receipt_path = work.parent / 'compiler-receipt.json'
receipt = json.loads(receipt_path.read_text())
validate_receipt(receipt, receipt['compiler_path'], artifacts=True)
source_root = Path(receipt['source_root'])
eligible = work.parent / 'eligible'
built = json.loads((eligible / 'build-manifest.json').read_text())
wrapper = source_root / 'experiments/runtime-parity-local-list-20261003/eligible-admission-wrap.c'
zig = receipt['zig']['path']
environment = runner.runtime_environment()
environment.update(built['private_cache_environment'])
logs = []

def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def command(argv):
    actual = [str(root / 'scripts/build-slot.sh'), 'build', *map(str, argv)]
    done = subprocess.run(actual, env=environment, capture_output=True, text=True, timeout=1800)
    logs.append({'command': actual, 'exit_status': done.returncode, 'stdout': done.stdout, 'stderr': done.stderr})
    (work / 'build-log.json').write_text(json.dumps(logs, indent=2) + '\n')
    if done.returncode:
        raise RuntimeError(done.stdout + done.stderr)

bindings = {str(Path(__file__)): digest(__file__), str(receipt_path): digest(receipt_path),
            str(wrapper): digest(wrapper), str(eligible / 'build-manifest.json'): digest(eligible / 'build-manifest.json')}
timed_hashes = {path: digest(path) for path in built['binaries'].values()}
rows = []
for backend in ('qbe', 'llvm'):
    if backend == 'qbe':
        guest = Path(built['binaries']['after/my-qbe'])
        scope = 'Recorded objects of the exact unwrapped timed QBE guest; instrumented relink is not timed.'
    else:
        guest = work / 'llvm-o3-no-lto'
        scope = 'Separate LLVM O3 ReleaseFast non-LTO admission companion; this is not the LLVM O3/LTO timed guest.'
        command([receipt['compiler_path'], 'build', eligible / 'sources/eligible-bench.my',
                 '--zig', zig, '--qbe', source_root / 'zig-out/bin/qbe', '--backend', 'llvm',
                 '--mode', 'ReleaseFast', '--llvm-opt', '3', '--keep-symbols', '--link', eligible / 'clock.o',
                 '--cache-dir', work / 'llvm-cache', '-o', guest])
    manifest_path = Path(str(guest) + '.qbe-manifest.json')
    manifest = json.loads(manifest_path.read_text())
    assert manifest['backend'] == backend and not manifest['lto']
    objects = Path(manifest['functions'][0]['object']).parent
    link_receipts = list(objects.glob('link-*.args'))
    assert len(link_receipts) == 1
    link_receipt = link_receipts[0]
    obj = work / ('wrap-' + backend + '.o')
    command([zig, 'cc', '-O3', '-UNDEBUG', '-I', source_root / 'src', '-c', wrapper, '-o', obj])
    counted = work / ('counted-' + backend)
    args = []
    for item in link_receipt.read_bytes().split(b'\0'):
        if item == b'\x01objects':
            args.extend(str(path) for path in sorted(objects.glob('*.o')))
            args.append(str(obj))
        elif item == b'\x01output':
            args.append(str(counted))
        else:
            args.append(item.decode())
    command([zig, *args, '--wrap=myl_qbe_local_list'])
    before = {str(path): digest(path) for path in [guest, manifest_path, link_receipt, obj, counted, *objects.glob('*.o')]}
    env = {**environment, 'LOCAL_LIST_ITERATIONS': '1000000', 'LOCAL_LIST_SEED': '17'}
    with runner.timing_lock():
        done = subprocess.run(['taskset', '-c', '2', str(counted)], env=env, capture_output=True, text=True, timeout=120)
    match = re.fullmatch(r'eligible list execution: hot=(\d+) cold=(\d+)\n', done.stderr)
    assert match and int(match[1]) > 0 and int(match[2]) <= 1
    output = runner.validate(subprocess.CompletedProcess(done.args, done.returncode, done.stdout, ''), 101999913)
    assert before == {path: digest(path) for path in before}
    stdout = work / (backend + '-stdout.txt')
    stderr = work / (backend + '-stderr.txt')
    stdout.write_text(done.stdout)
    stderr.write_text(done.stderr)
    rows.append({'backend': backend, 'guest_mode': 'ReleaseFast', 'optimization': manifest['optimization'],
                 'lto': manifest['lto'], 'scope': scope, 'hot': int(match[1]), 'cold': int(match[2]),
                 'checksum': output['checksum'], 'exit_status': done.returncode,
                 'command': ['taskset', '-c', '2', str(counted)],
                 'environment_inputs': {'LOCAL_LIST_ITERATIONS': 1000000, 'LOCAL_LIST_SEED': 17},
                 'artifact_hashes': {**before, str(stdout): digest(stdout), str(stderr): digest(stderr)}})
assert timed_hashes == {path: digest(path) for path in timed_hashes}
assert bindings == {path: digest(path) for path in bindings}
validate_receipt(receipt, receipt['compiler_path'], artifacts=True)
report = {'schema': 'mylang-runtime-eligible-admission-v1', 'purpose': 'Instrumented admission correctness; no timing claims',
          'source_revision': receipt['source_revision'], 'compiler_receipt': str(receipt_path),
          'input_hashes': bindings, 'first_failed_validation_log': {'path': str(work / 'first-failed-validation.log'),
              'sha256': digest(work / 'first-failed-validation.log'),
              'reason': 'Ordinary guest validator rejected expected instrumented wrapper stderr; fixed by validating its exact counter line separately.'},
          'timed_binary_hashes_before': timed_hashes,
          'timed_binary_hashes_after': timed_hashes, 'rows': rows, 'build_logs': logs,
          'limitations': ['Counters count actual helper calls in instrumented relinks, not allocation/epoch/RC events.',
                          'LLVM companion disables LTO because the original LLVM LTO frame-map link scratch objects/receipt are not retained.',
                          'Clock output was oracle/protocol validated; elapsed values are deliberately omitted from this diagnostic receipt.']}
(work / 'admission.json').write_text(json.dumps(report, indent=2) + '\n')
print([(row['backend'], row['hot'], row['cold']) for row in rows])
